package com.ai.bdx.frame.approval.bean;

import java.util.Date;
import java.io.Serializable;
public class ApApproveList implements Serializable {
	
	 /** 
	  * serialVersionUID:TODO 
	  */
	private static final long serialVersionUID = 1L;
	private String approval_id;// 要审批的对象ID
	private String approve_flow_id;// 审批使用的流程ID
	private Integer approve_seq;// 审批次序
	private Integer approve_level;// 审批级别
	private String approve_userid;// 审批人
	private Integer approve_token;// 审批持有令牌，谁持有令牌谁才能审批
	private String approve_advice;// 审批意见
	private Integer auth_flag;//转发审批人标示 0 原流程审批人 1 转发的审批人
	private String remind_date;
	private String forecast_date;
	private String approve_flag;//审批标示 0 - 待审批 确认  	1 - 通过 	2 - 不通过 	9 - 终止
	private String confirm_explain;
	private Date update_time;//最后审批确认时间
	private String approve_type;//流程类型  1 审批 2 确认
    private Date create_time;//创建时间
	
	//增加描述字段
	private String approve_level_desc;//审批确认等级描述
	private String approve_type_desc;//审批确认类型描述
	private String approve_flag_desc;//审批状态描述
	private String approve_user;// 审批人
	public String getApproval_id() {
		return approval_id;
	}

	public void setApproval_id(String approval_id) {
		this.approval_id = approval_id;
	}

	public String getApprove_flow_id() {
		return approve_flow_id;
	}

	public void setApprove_flow_id(String approve_flow_id) {
		this.approve_flow_id = approve_flow_id;
	}

	public Integer getApprove_seq() {
		return approve_seq;
	}

	public void setApprove_seq(Integer approve_seq) {
		this.approve_seq = approve_seq;
	}

	public Integer getApprove_level() {
		return approve_level;
	}

	public void setApprove_level(Integer approve_level) {
		this.approve_level = approve_level;
	}

	public String getApprove_userid() {
		return approve_userid;
	}

	public void setApprove_userid(String approve_userid) {
		this.approve_userid = approve_userid;
	}

	public Integer getApprove_token() {
		return approve_token;
	}

	public void setApprove_token(Integer approve_token) {
		this.approve_token = approve_token;
	}

	public String getApprove_advice() {
		return approve_advice;
	}

	public void setApprove_advice(String approve_advice) {
		this.approve_advice = approve_advice;
	}

	public Integer getAuth_flag() {
		return auth_flag;
	}

	public void setAuth_flag(Integer auth_flag) {
		this.auth_flag = auth_flag;
	}

	public String getRemind_date() {
		return remind_date;
	}

	public void setRemind_date(String remind_date) {
		this.remind_date = remind_date;
	}

	public String getForecast_date() {
		return forecast_date;
	}

	public void setForecast_date(String forecast_date) {
		this.forecast_date = forecast_date;
	}

	public String getApprove_flag() {
		return approve_flag;
	}

	public void setApprove_flag(String approve_flag) {
		this.approve_flag = approve_flag;
	}

	public String getConfirm_explain() {
		return confirm_explain;
	}

	public void setConfirm_explain(String confirm_explain) {
		this.confirm_explain = confirm_explain;
	}

	public Date getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Date update_time) {
		this.update_time = update_time;
	}

	public String getApprove_type() {
		return approve_type;
	}

	public void setApprove_type(String approve_type) {
		this.approve_type = approve_type;
	}

	public String getApprove_level_desc() {
		return approve_level_desc;
	}

	public void setApprove_level_desc(String approve_level_desc) {
		this.approve_level_desc = approve_level_desc;
	}

	public String getApprove_type_desc() {
		return approve_type_desc;
	}

	public void setApprove_type_desc(String approve_type_desc) {
		this.approve_type_desc = approve_type_desc;
	}

	public String getApprove_flag_desc() {
		return approve_flag_desc;
	}

	public void setApprove_flag_desc(String approve_flag_desc) {
		this.approve_flag_desc = approve_flag_desc;
	}

	public Date getCreate_time() {
		return create_time;
	}

	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}

	public String getApprove_user() {
		return approve_user;
	}

	public void setApprove_user(String approve_user) {
		this.approve_user = approve_user;
	}

	
}
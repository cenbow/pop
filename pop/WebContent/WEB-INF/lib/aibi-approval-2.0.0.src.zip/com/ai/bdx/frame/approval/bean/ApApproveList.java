/*     */ package com.ai.bdx.frame.approval.bean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class ApApproveList
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String approval_id;
/*     */   private String approve_flow_id;
/*     */   private Integer approve_seq;
/*     */   private Integer approve_level;
/*     */   private String approve_userid;
/*     */   private Integer approve_token;
/*     */   private String approve_advice;
/*     */   private Integer auth_flag;
/*     */   private String remind_date;
/*     */   private String forecast_date;
/*     */   private String approve_flag;
/*     */   private String confirm_explain;
/*     */   private Date update_time;
/*     */   private String approve_type;
/*     */   private Date create_time;
/*     */   private String approve_level_desc;
/*     */   private String approve_type_desc;
/*     */   private String approve_flag_desc;
/*     */   private String approve_user;
/*     */ 
/*     */   public String getApproval_id()
/*     */   {
/*  33 */     return this.approval_id;
/*     */   }
/*     */ 
/*     */   public void setApproval_id(String approval_id) {
/*  37 */     this.approval_id = approval_id;
/*     */   }
/*     */ 
/*     */   public String getApprove_flow_id() {
/*  41 */     return this.approve_flow_id;
/*     */   }
/*     */ 
/*     */   public void setApprove_flow_id(String approve_flow_id) {
/*  45 */     this.approve_flow_id = approve_flow_id;
/*     */   }
/*     */ 
/*     */   public Integer getApprove_seq() {
/*  49 */     return this.approve_seq;
/*     */   }
/*     */ 
/*     */   public void setApprove_seq(Integer approve_seq) {
/*  53 */     this.approve_seq = approve_seq;
/*     */   }
/*     */ 
/*     */   public Integer getApprove_level() {
/*  57 */     return this.approve_level;
/*     */   }
/*     */ 
/*     */   public void setApprove_level(Integer approve_level) {
/*  61 */     this.approve_level = approve_level;
/*     */   }
/*     */ 
/*     */   public String getApprove_userid() {
/*  65 */     return this.approve_userid;
/*     */   }
/*     */ 
/*     */   public void setApprove_userid(String approve_userid) {
/*  69 */     this.approve_userid = approve_userid;
/*     */   }
/*     */ 
/*     */   public Integer getApprove_token() {
/*  73 */     return this.approve_token;
/*     */   }
/*     */ 
/*     */   public void setApprove_token(Integer approve_token) {
/*  77 */     this.approve_token = approve_token;
/*     */   }
/*     */ 
/*     */   public String getApprove_advice() {
/*  81 */     return this.approve_advice;
/*     */   }
/*     */ 
/*     */   public void setApprove_advice(String approve_advice) {
/*  85 */     this.approve_advice = approve_advice;
/*     */   }
/*     */ 
/*     */   public Integer getAuth_flag() {
/*  89 */     return this.auth_flag;
/*     */   }
/*     */ 
/*     */   public void setAuth_flag(Integer auth_flag) {
/*  93 */     this.auth_flag = auth_flag;
/*     */   }
/*     */ 
/*     */   public String getRemind_date() {
/*  97 */     return this.remind_date;
/*     */   }
/*     */ 
/*     */   public void setRemind_date(String remind_date) {
/* 101 */     this.remind_date = remind_date;
/*     */   }
/*     */ 
/*     */   public String getForecast_date() {
/* 105 */     return this.forecast_date;
/*     */   }
/*     */ 
/*     */   public void setForecast_date(String forecast_date) {
/* 109 */     this.forecast_date = forecast_date;
/*     */   }
/*     */ 
/*     */   public String getApprove_flag() {
/* 113 */     return this.approve_flag;
/*     */   }
/*     */ 
/*     */   public void setApprove_flag(String approve_flag) {
/* 117 */     this.approve_flag = approve_flag;
/*     */   }
/*     */ 
/*     */   public String getConfirm_explain() {
/* 121 */     return this.confirm_explain;
/*     */   }
/*     */ 
/*     */   public void setConfirm_explain(String confirm_explain) {
/* 125 */     this.confirm_explain = confirm_explain;
/*     */   }
/*     */ 
/*     */   public Date getUpdate_time() {
/* 129 */     return this.update_time;
/*     */   }
/*     */ 
/*     */   public void setUpdate_time(Date update_time) {
/* 133 */     this.update_time = update_time;
/*     */   }
/*     */ 
/*     */   public String getApprove_type() {
/* 137 */     return this.approve_type;
/*     */   }
/*     */ 
/*     */   public void setApprove_type(String approve_type) {
/* 141 */     this.approve_type = approve_type;
/*     */   }
/*     */ 
/*     */   public String getApprove_level_desc() {
/* 145 */     return this.approve_level_desc;
/*     */   }
/*     */ 
/*     */   public void setApprove_level_desc(String approve_level_desc) {
/* 149 */     this.approve_level_desc = approve_level_desc;
/*     */   }
/*     */ 
/*     */   public String getApprove_type_desc() {
/* 153 */     return this.approve_type_desc;
/*     */   }
/*     */ 
/*     */   public void setApprove_type_desc(String approve_type_desc) {
/* 157 */     this.approve_type_desc = approve_type_desc;
/*     */   }
/*     */ 
/*     */   public String getApprove_flag_desc() {
/* 161 */     return this.approve_flag_desc;
/*     */   }
/*     */ 
/*     */   public void setApprove_flag_desc(String approve_flag_desc) {
/* 165 */     this.approve_flag_desc = approve_flag_desc;
/*     */   }
/*     */ 
/*     */   public Date getCreate_time() {
/* 169 */     return this.create_time;
/*     */   }
/*     */ 
/*     */   public void setCreate_time(Date create_time) {
/* 173 */     this.create_time = create_time;
/*     */   }
/*     */ 
/*     */   public String getApprove_user() {
/* 177 */     return this.approve_user;
/*     */   }
/*     */ 
/*     */   public void setApprove_user(String approve_user) {
/* 181 */     this.approve_user = approve_user;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.bean.ApApproveList
 * JD-Core Version:    0.6.2
 */
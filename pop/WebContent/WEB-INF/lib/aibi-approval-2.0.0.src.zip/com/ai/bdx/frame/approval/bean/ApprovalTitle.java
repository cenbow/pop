/*    */ package com.ai.bdx.frame.approval.bean;
/*    */ 
/*    */ public class ApprovalTitle
/*    */ {
/*    */   private Integer key;
/*    */   private String desc;
/*    */   private Integer currentStat;
/*    */   private Integer stat;
/*    */   private String style;
/*    */ 
/*    */   public Integer getKey()
/*    */   {
/* 12 */     return this.key;
/*    */   }
/*    */   public void setKey(Integer key) {
/* 15 */     this.key = key;
/*    */   }
/*    */   public String getDesc() {
/* 18 */     return this.desc;
/*    */   }
/*    */   public void setDesc(String desc) {
/* 21 */     this.desc = desc;
/*    */   }
/*    */   public Integer getCurrentStat() {
/* 24 */     return this.currentStat;
/*    */   }
/*    */   public void setCurrentStat(Integer currentStat) {
/* 27 */     this.currentStat = currentStat;
/*    */   }
/*    */   public Integer getStat() {
/* 30 */     return this.stat;
/*    */   }
/*    */   public void setStat(Integer stat) {
/* 33 */     this.stat = stat;
/*    */   }
/*    */   public String getStyle() {
/* 36 */     return this.style;
/*    */   }
/*    */   public void setStyle(String style) {
/* 39 */     this.style = style;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.bean.ApprovalTitle
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.bean;

public class ApprovalTitle {

	private Integer  key;//当前阶段标示
	private String desc;//当前阶段中文描述
	private Integer currentStat;//当前阶段
	private Integer stat;//策略状态 
	private String style;//样式
	
	public Integer getKey() {
		return key;
	}
	public void setKey(Integer key) {
		this.key = key;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Integer getCurrentStat() {
		return currentStat;
	}
	public void setCurrentStat(Integer currentStat) {
		this.currentStat = currentStat;
	}
	public Integer getStat() {
		return stat;
	}
	public void setStat(Integer stat) {
		this.stat = stat;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	
	
}

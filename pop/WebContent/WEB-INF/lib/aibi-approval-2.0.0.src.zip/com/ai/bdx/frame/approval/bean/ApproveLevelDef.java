/*    */ package com.ai.bdx.frame.approval.bean;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class ApproveLevelDef
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Integer approve_level;
/*    */   private String approve_flow_id;
/*    */   private Integer approve_obj_type;
/*    */   private String approve_obj_id;
/*    */   private Integer auth_flag;
/*    */ 
/*    */   public Integer getApprove_level()
/*    */   {
/* 18 */     return this.approve_level;
/*    */   }
/*    */   public void setApprove_level(Integer approve_level) {
/* 21 */     this.approve_level = approve_level;
/*    */   }
/*    */   public String getApprove_flow_id() {
/* 24 */     return this.approve_flow_id;
/*    */   }
/*    */   public void setApprove_flow_id(String approve_flow_id) {
/* 27 */     this.approve_flow_id = approve_flow_id;
/*    */   }
/*    */   public Integer getApprove_obj_type() {
/* 30 */     return this.approve_obj_type;
/*    */   }
/*    */   public void setApprove_obj_type(Integer approve_obj_type) {
/* 33 */     this.approve_obj_type = approve_obj_type;
/*    */   }
/*    */   public String getApprove_obj_id() {
/* 36 */     return this.approve_obj_id;
/*    */   }
/*    */   public void setApprove_obj_id(String approve_obj_id) {
/* 39 */     this.approve_obj_id = approve_obj_id;
/*    */   }
/*    */   public Integer getAuth_flag() {
/* 42 */     return this.auth_flag;
/*    */   }
/*    */   public void setAuth_flag(Integer auth_flag) {
/* 45 */     this.auth_flag = auth_flag;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.bean.ApproveLevelDef
 * JD-Core Version:    0.6.2
 */
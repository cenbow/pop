package com.ai.bdx.frame.approval.bean;

import java.io.Serializable;
//审批级别
public class ApproveLevelDef implements Serializable {

	
	 /** 
	  * serialVersionUID:TODO 
	  */
	private static final long serialVersionUID = 1L;
	private Integer approve_level;
	private String approve_flow_id;
	private Integer  approve_obj_type;
	private String approve_obj_id;
	private Integer auth_flag;
	public Integer getApprove_level() {
		return approve_level;
	}
	public void setApprove_level(Integer approve_level) {
		this.approve_level = approve_level;
	}
	public String getApprove_flow_id() {
		return approve_flow_id;
	}
	public void setApprove_flow_id(String approve_flow_id) {
		this.approve_flow_id = approve_flow_id;
	}
	public Integer getApprove_obj_type() {
		return approve_obj_type;
	}
	public void setApprove_obj_type(Integer approve_obj_type) {
		this.approve_obj_type = approve_obj_type;
	}
	public String getApprove_obj_id() {
		return approve_obj_id;
	}
	public void setApprove_obj_id(String approve_obj_id) {
		this.approve_obj_id = approve_obj_id;
	}
	public Integer getAuth_flag() {
		return auth_flag;
	}
	public void setAuth_flag(Integer auth_flag) {
		this.auth_flag = auth_flag;
	}
	
	
	
}

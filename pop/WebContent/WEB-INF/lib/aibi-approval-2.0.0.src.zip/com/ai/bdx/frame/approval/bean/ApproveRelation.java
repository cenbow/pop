/*    */ package com.ai.bdx.frame.approval.bean;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public class ApproveRelation
/*    */ {
/*    */   private String approve_userid;
/*    */   private Integer deptid;
/*    */   private String approve_create_userid;
/*    */   private Date create_time;
/*    */   private Integer position_id;
/*    */   private String approve_userid_email;
/*    */   private String approve_userid_msisdn;
/*    */   private String cityid;
/*    */   private Integer auth_flag;
/*    */ 
/*    */   public String getApprove_userid()
/*    */   {
/* 20 */     return this.approve_userid;
/*    */   }
/*    */   public void setApprove_userid(String approve_userid) {
/* 23 */     this.approve_userid = approve_userid;
/*    */   }
/*    */   public Integer getDeptid() {
/* 26 */     return this.deptid;
/*    */   }
/*    */   public void setDeptid(Integer deptid) {
/* 29 */     this.deptid = deptid;
/*    */   }
/*    */   public String getApprove_create_userid() {
/* 32 */     return this.approve_create_userid;
/*    */   }
/*    */   public void setApprove_create_userid(String approve_create_userid) {
/* 35 */     this.approve_create_userid = approve_create_userid;
/*    */   }
/*    */   public Date getCreate_time() {
/* 38 */     return this.create_time;
/*    */   }
/*    */   public void setCreate_time(Date create_time) {
/* 41 */     this.create_time = create_time;
/*    */   }
/*    */   public Integer getPosition_id() {
/* 44 */     return this.position_id;
/*    */   }
/*    */   public void setPosition_id(Integer position_id) {
/* 47 */     this.position_id = position_id;
/*    */   }
/*    */   public String getApprove_userid_email() {
/* 50 */     return this.approve_userid_email;
/*    */   }
/*    */   public void setApprove_userid_email(String approve_userid_email) {
/* 53 */     this.approve_userid_email = approve_userid_email;
/*    */   }
/*    */   public String getApprove_userid_msisdn() {
/* 56 */     return this.approve_userid_msisdn;
/*    */   }
/*    */   public void setApprove_userid_msisdn(String approve_userid_msisdn) {
/* 59 */     this.approve_userid_msisdn = approve_userid_msisdn;
/*    */   }
/*    */   public String getCityid() {
/* 62 */     return this.cityid;
/*    */   }
/*    */   public void setCityid(String cityid) {
/* 65 */     this.cityid = cityid;
/*    */   }
/*    */   public Integer getAuth_flag() {
/* 68 */     return this.auth_flag;
/*    */   }
/*    */   public void setAuth_flag(Integer auth_flag) {
/* 71 */     this.auth_flag = auth_flag;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.bean.ApproveRelation
 * JD-Core Version:    0.6.2
 */
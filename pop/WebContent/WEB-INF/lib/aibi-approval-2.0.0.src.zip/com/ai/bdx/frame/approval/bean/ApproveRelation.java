package com.ai.bdx.frame.approval.bean;

import java.util.Date;

/**
 * 
 * 审批人和部门对应关系
 */
public class ApproveRelation {
	private String approve_userid;
	private Integer deptid;
	private String approve_create_userid;
	private Date create_time;
	private Integer position_id;
	private String approve_userid_email;
	private String approve_userid_msisdn;
	private String cityid;
	private Integer auth_flag;
	public String getApprove_userid() {
		return approve_userid;
	}
	public void setApprove_userid(String approve_userid) {
		this.approve_userid = approve_userid;
	}
	public Integer getDeptid() {
		return deptid;
	}
	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}
	public String getApprove_create_userid() {
		return approve_create_userid;
	}
	public void setApprove_create_userid(String approve_create_userid) {
		this.approve_create_userid = approve_create_userid;
	}
	public Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	public Integer getPosition_id() {
		return position_id;
	}
	public void setPosition_id(Integer position_id) {
		this.position_id = position_id;
	}
	public String getApprove_userid_email() {
		return approve_userid_email;
	}
	public void setApprove_userid_email(String approve_userid_email) {
		this.approve_userid_email = approve_userid_email;
	}
	public String getApprove_userid_msisdn() {
		return approve_userid_msisdn;
	}
	public void setApprove_userid_msisdn(String approve_userid_msisdn) {
		this.approve_userid_msisdn = approve_userid_msisdn;
	}
	public String getCityid() {
		return cityid;
	}
	public void setCityid(String cityid) {
		this.cityid = cityid;
	}
	public Integer getAuth_flag() {
		return auth_flag;
	}
	public void setAuth_flag(Integer auth_flag) {
		this.auth_flag = auth_flag;
	}
}

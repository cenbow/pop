package com.ai.bdx.frame.approval.bean;

public class ApproveTriggerCondDef {
	private Integer approve_level;
	private String approve_flow_id;
	private String approve_trigger_cond_id;
	private String cond_indi_id;
	private String cond_operator;
	private String cond_indi_value;
	private Integer approve_obj_type;
	private String approve_obj_id;
	private Integer approve_trigger_cond_pri;
	public Integer getApprove_level() {
		return approve_level;
	}
	public void setApprove_level(Integer approve_level) {
		this.approve_level = approve_level;
	}
	public String getApprove_flow_id() {
		return approve_flow_id;
	}
	public void setApprove_flow_id(String approve_flow_id) {
		this.approve_flow_id = approve_flow_id;
	}
	public String getApprove_trigger_cond_id() {
		return approve_trigger_cond_id;
	}
	public void setApprove_trigger_cond_id(String approve_trigger_cond_id) {
		this.approve_trigger_cond_id = approve_trigger_cond_id;
	}
	public String getCond_indi_id() {
		return cond_indi_id;
	}
	public void setCond_indi_id(String cond_indi_id) {
		this.cond_indi_id = cond_indi_id;
	}
	public String getCond_operator() {
		return cond_operator;
	}
	public void setCond_operator(String cond_operator) {
		this.cond_operator = cond_operator;
	}
	public String getCond_indi_value() {
		return cond_indi_value;
	}
	public void setCond_indi_value(String cond_indi_value) {
		this.cond_indi_value = cond_indi_value;
	}
	public Integer getApprove_obj_type() {
		return approve_obj_type;
	}
	public void setApprove_obj_type(Integer approve_obj_type) {
		this.approve_obj_type = approve_obj_type;
	}
	public String getApprove_obj_id() {
		return approve_obj_id;
	}
	public void setApprove_obj_id(String approve_obj_id) {
		this.approve_obj_id = approve_obj_id;
	}
	public Integer getApprove_trigger_cond_pri() {
		return approve_trigger_cond_pri;
	}
	public void setApprove_trigger_cond_pri(Integer approve_trigger_cond_pri) {
		this.approve_trigger_cond_pri = approve_trigger_cond_pri;
	}
	
}

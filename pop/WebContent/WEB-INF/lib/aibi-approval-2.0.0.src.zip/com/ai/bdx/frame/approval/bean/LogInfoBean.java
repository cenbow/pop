/*    */ package com.ai.bdx.frame.approval.bean;
/*    */ 
/*    */ public class LogInfoBean
/*    */ {
/*    */   private String userId;
/*    */   private String resourceType;
/*    */   private String operaterType;
/*    */   private String resourceId;
/*    */   private String resourceName;
/*    */   private String operationDesc;
/*    */ 
/*    */   public String getUserId()
/*    */   {
/* 16 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public void setUserId(String userId) {
/* 20 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   public String getResourceType() {
/* 24 */     return this.resourceType;
/*    */   }
/*    */ 
/*    */   public void setResourceType(String resourceType) {
/* 28 */     this.resourceType = resourceType;
/*    */   }
/*    */ 
/*    */   public String getOperaterType() {
/* 32 */     return this.operaterType;
/*    */   }
/*    */ 
/*    */   public void setOperaterType(String operaterType) {
/* 36 */     this.operaterType = operaterType;
/*    */   }
/*    */ 
/*    */   public String getResourceId() {
/* 40 */     return this.resourceId;
/*    */   }
/*    */ 
/*    */   public void setResourceId(String resourceId) {
/* 44 */     this.resourceId = resourceId;
/*    */   }
/*    */ 
/*    */   public String getResourceName() {
/* 48 */     return this.resourceName;
/*    */   }
/*    */ 
/*    */   public void setResourceName(String resourceName) {
/* 52 */     this.resourceName = resourceName;
/*    */   }
/*    */ 
/*    */   public String getOperationDesc() {
/* 56 */     return this.operationDesc;
/*    */   }
/*    */ 
/*    */   public void setOperationDesc(String operationDesc) {
/* 60 */     this.operationDesc = operationDesc;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.bean.LogInfoBean
 * JD-Core Version:    0.6.2
 */
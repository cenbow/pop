/*    */ package com.ai.bdx.frame.approval.bean;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlSeginfoObj
/*    */   implements Serializable
/*    */ {
/*    */   private String campsegId;
/*    */   private String objCode;
/*    */   private String objName;
/*    */   private String objCost;
/*    */ 
/*    */   public String getCampsegId()
/*    */   {
/* 14 */     return this.campsegId;
/*    */   }
/*    */ 
/*    */   public void setCampsegId(String campsegId) {
/* 18 */     this.campsegId = campsegId;
/*    */   }
/*    */ 
/*    */   public String getObjCode() {
/* 22 */     return this.objCode;
/*    */   }
/*    */ 
/*    */   public void setObjCode(String objCode) {
/* 26 */     this.objCode = objCode;
/*    */   }
/*    */ 
/*    */   public String getObjName() {
/* 30 */     return this.objName;
/*    */   }
/*    */ 
/*    */   public void setObjName(String objName) {
/* 34 */     this.objName = objName;
/*    */   }
/*    */ 
/*    */   public String getObjCost() {
/* 38 */     return this.objCost;
/*    */   }
/*    */ 
/*    */   public void setObjCost(String objCost) {
/* 42 */     this.objCost = objCost;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.bean.MtlSeginfoObj
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.bean;

public class MtlSeginfoObj implements java.io.Serializable {

	private String campsegId;

	private String objCode;

	private String objName;

	private String objCost;

	public String getCampsegId() {
		return campsegId;
	}

	public void setCampsegId(String campsegId) {
		this.campsegId = campsegId;
	}

	public String getObjCode() {
		return objCode;
	}

	public void setObjCode(String objCode) {
		this.objCode = objCode;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getObjCost() {
		return objCost;
	}

	public void setObjCost(String objCost) {
		this.objCost = objCost;
	}

}

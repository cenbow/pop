/*    */ package com.ai.bdx.frame.approval.bean;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class SystemVarInfoBean
/*    */   implements Serializable
/*    */ {
/*    */   private String varId;
/*    */   private String madId;
/*    */   private String columnName;
/*    */   private String relTable;
/*    */   private String relTableKey;
/*    */   private String relTableValue;
/*    */   private String varSource;
/*    */ 
/*    */   public String getVarId()
/*    */   {
/* 23 */     return this.varId;
/*    */   }
/*    */ 
/*    */   public void setVarId(String varId) {
/* 27 */     this.varId = varId;
/*    */   }
/*    */ 
/*    */   public String getMadId() {
/* 31 */     return this.madId;
/*    */   }
/*    */ 
/*    */   public void setMadId(String madId) {
/* 35 */     this.madId = madId;
/*    */   }
/*    */ 
/*    */   public String getColumnName() {
/* 39 */     return this.columnName;
/*    */   }
/*    */ 
/*    */   public void setColumnName(String columnName) {
/* 43 */     this.columnName = columnName;
/*    */   }
/*    */ 
/*    */   public String getRelTable() {
/* 47 */     return this.relTable;
/*    */   }
/*    */ 
/*    */   public void setRelTable(String relTable) {
/* 51 */     this.relTable = relTable;
/*    */   }
/*    */ 
/*    */   public String getRelTableKey() {
/* 55 */     return this.relTableKey;
/*    */   }
/*    */ 
/*    */   public void setRelTableKey(String relTableKey) {
/* 59 */     this.relTableKey = relTableKey;
/*    */   }
/*    */ 
/*    */   public String getRelTableValue() {
/* 63 */     return this.relTableValue;
/*    */   }
/*    */ 
/*    */   public void setRelTableValue(String relTableValue) {
/* 67 */     this.relTableValue = relTableValue;
/*    */   }
/*    */ 
/*    */   public String getVarSource() {
/* 71 */     return this.varSource;
/*    */   }
/*    */ 
/*    */   public void setVarSource(String varSource) {
/* 75 */     this.varSource = varSource;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 80 */     return "madId:" + this.madId + ",columnName:" + this.columnName + ",relTable:" + this.relTable + ",relTableKey:" + this.relTableKey + ",relTableValue:" + this.relTableValue + ",varSource:" + this.varSource;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.bean.SystemVarInfoBean
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.approval.controller;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveLevelDefId;
/*     */ import com.ai.bdx.frame.approval.service.IMpmCommonService;
/*     */ import com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService;
/*     */ import com.ai.bdx.frame.approval.util.MpmUtil;
/*     */ import com.ai.bdx.frame.approval.util.RequestUtils;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.sf.json.JSONArray;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ import org.apache.commons.beanutils.PropertyUtilsBean;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ @Controller
/*     */ @RequestMapping({"/approvalDef/*"})
/*     */ public class ApprovalDefController extends BaseController
/*     */ {
/*  46 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   @Autowired
/*     */   private IMtlApproveFlowDefService service;
/*     */ 
/*     */   @Autowired
/*     */   private IUserPrivilegeCommonService userPrivilegeService;
/*     */ 
/*     */   @Autowired
/*     */   IMpmCommonService commonService;
/*     */ 
/*     */   @RequestMapping({"list"})
/*     */   public void list(String page, String rows, String approveFlowName, HttpServletRequest request, HttpServletResponse resp) {
/*  62 */     Map result = new HashMap();
/*     */     try {
/*  64 */       if (StringUtil.isEmpty(page)) {
/*  65 */         page = "1";
/*     */       }
/*  67 */       if (StringUtil.isEmpty(rows)) {
/*  68 */         rows = "10";
/*     */       }
/*  70 */       initAttributes(request);
/*  71 */       MtlApproveFlowDef searchCond = new MtlApproveFlowDef();
/*  72 */       if (!this.userGroupId.equals("1")) {
/*  73 */         searchCond.setCreateUserid(this.userId);
/*     */       }
/*  75 */       searchCond.setApproveFlowName(approveFlowName);
/*  76 */       result = this.service.findApproveFlow(searchCond, Integer.valueOf(Integer.parseInt(page) - 1), Integer.valueOf(Integer.parseInt(rows)));
/*  77 */       List list = (List)result.get("result");
/*  78 */       List rowsList = new ArrayList();
/*  79 */       for (MtlApproveFlowDef mtlApproveFlowDef : list) {
/*  80 */         Map row = new HashMap();
/*  81 */         row.put("approveFlowId", mtlApproveFlowDef.getApproveFlowId());
/*  82 */         row.put("approveFlowName", mtlApproveFlowDef.getApproveFlowName());
/*  83 */         row.put("approveFlowAccessToken", Short.valueOf(mtlApproveFlowDef.getApproveFlowAccessToken()));
/*  84 */         row.put("approveFlowLevelCnt", mtlApproveFlowDef.getApproveFlowLevelCnt());
/*  85 */         row.put("createUserid", mtlApproveFlowDef.getCreateUserid());
/*  86 */         IUser user = this.userPrivilegeService.getUser(mtlApproveFlowDef.getCreateUserid());
/*  87 */         if (user == null)
/*  88 */           row.put("createUsername", mtlApproveFlowDef.getCreateUserid());
/*     */         else {
/*  90 */           row.put("createUsername", user.getUsername());
/*     */         }
/*  92 */         row.put("createTime", MpmUtil.date2String(mtlApproveFlowDef.getCreateTime()));
/*  93 */         rowsList.add(row);
/*     */       }
/*  95 */       result.put("rows", rowsList);
/*  96 */       result.remove("result");
/*     */     } catch (Exception e) {
/*  98 */       log.error("获取流程定义列表异常", e);
/*  99 */       result.put("total", Integer.valueOf(0));
/* 100 */       result.put("rows", "[]");
/*     */     }
/* 102 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"delete"})
/*     */   public void delete(String approveFlowIdsStr, HttpServletResponse resp)
/*     */   {
/* 108 */     Map result = new HashMap();
/*     */     try {
/* 110 */       if (StringUtil.isNotEmpty(approveFlowIdsStr)) {
/* 111 */         String[] approveFlowIds = approveFlowIdsStr.split(",");
/* 112 */         for (int i = 0; i < approveFlowIds.length; i++) {
/* 113 */           this.service.deleteApproveFlowDef(approveFlowIds[i]);
/*     */         }
/* 115 */         result.put("errorMsg", "");
/*     */       } else {
/* 117 */         result.put("errorMsg", "没有要删除的数据！");
/*     */       }
/*     */     } catch (Exception e) {
/* 120 */       log.error("删除流程定义异常", e);
/* 121 */       result.put("errorMsg", e.getMessage());
/*     */     }
/* 123 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"toAddOrUpdate"})
/*     */   public ModelAndView toUpdate(String approveFlowId, HttpServletRequest req, HttpServletResponse resp)
/*     */   {
/* 129 */     Map model = new HashMap();
/*     */     try {
/* 131 */       if (StringUtil.isNotEmpty(approveFlowId)) {
/* 132 */         MtlApproveFlowDef flow = this.service.getApproveFlowDef(approveFlowId);
/*     */ 
/* 134 */         List levelList = this.service.getApproveLevelDefByFlow(approveFlowId);
/* 135 */         TreeMap retMap = new TreeMap();
/* 136 */         if ((levelList != null) && (levelList.size() > 0))
/*     */         {
/* 138 */           for (int i = 0; i < levelList.size(); i++) {
/* 139 */             MtlApproveLevelDef level = (MtlApproveLevelDef)levelList.get(i);
/* 140 */             level.setApproveObjName(this.service.getApproveObjNameByTypeAndIdCache(level.getId().getApproveObjType(), level.getId().getApproveObjId()));
/*     */ 
/* 142 */             List list = (List)retMap.get(level.getId().getApproveLevel());
/* 143 */             if (list == null) {
/* 144 */               list = new ArrayList();
/* 145 */               list.add(level);
/* 146 */               retMap.put(level.getId().getApproveLevel(), list);
/*     */             } else {
/* 148 */               list.add(level);
/*     */             }
/*     */           }
/*     */         }
/* 152 */         model.put("flowDef", flow);
/* 153 */         model.put("level", retMap);
/*     */       }
/*     */     } catch (Exception e) {
/* 156 */       log.error("预新建或修改流程定义异常", e);
/*     */     }
/* 158 */     return new ModelAndView("/manage/approvalDefAdd", model);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"saveOrUpdate"})
/*     */   public void save(String approveFlowId, String approveFlowName, String approveFlowAccessToken, String flowType, String approveFlowDefStr, HttpServletRequest req, HttpServletResponse resp)
/*     */   {
/* 165 */     Map result = new HashMap();
/*     */     try {
/* 167 */       initAttributes(req);
/* 168 */       MtlApproveFlowDef flowDef = new MtlApproveFlowDef();
/* 169 */       Map params = RequestUtils.getParameterMap(req);
/* 170 */       BeanUtils.populate(flowDef, params);
/* 171 */       flowDef.setCreateUserid(this.userId);
/* 172 */       String deptId = String.valueOf(this.user.getDepartmentid());
/* 173 */       if (StringUtil.isNotEmpty(flowDef.getFirstApproveUser())) {
/* 174 */         IUser firstUser = this.userPrivilegeService.getUser(flowDef.getFirstApproveUser());
/* 175 */         if (firstUser != null) {
/* 176 */           deptId = String.valueOf(firstUser.getDepartmentid());
/*     */         }
/*     */       }
/* 179 */       flowDef.setDeptId(deptId);
/* 180 */       flowDef.setCityid(this.user.getCityid());
/*     */ 
/* 182 */       if (this.commonService.isNameExist(flowDef.getApproveFlowName(), flowDef.getApproveFlowId(), "ap_approve_flow_def", false)) {
/* 183 */         result.put("errorMsg", "流程名称已经存在，请重新输入审批流程名称");
/*     */       } else {
/* 185 */         this.service.saveApproveFlowDef(flowDef, deptId);
/* 186 */         result.put("errorMsg", "");
/*     */       }
/*     */     } catch (Exception e) {
/* 189 */       log.error("新建或修改流程定义异常", e);
/* 190 */       result.put("errorMsg", e.getMessage());
/*     */     }
/* 192 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"view"})
/*     */   public void view(String approveFlowId, HttpServletResponse resp)
/*     */   {
/* 198 */     List rows = new ArrayList();
/*     */     try {
/* 200 */       if (StringUtil.isNotEmpty(approveFlowId))
/*     */       {
/* 203 */         List levelList = this.service.getApproveLevelDefByFlow(approveFlowId);
/*     */ 
/* 205 */         TreeMap retMap = new TreeMap();
/* 206 */         if ((levelList != null) && (levelList.size() > 0))
/*     */         {
/* 208 */           for (int i = 0; i < levelList.size(); i++) {
/* 209 */             MtlApproveLevelDef level = (MtlApproveLevelDef)levelList.get(i);
/* 210 */             level.setApproveObjName(this.service.getApproveObjNameByTypeAndIdCache(level.getId().getApproveObjType(), level.getId().getApproveObjId()));
/*     */ 
/* 212 */             List list = (List)retMap.get(level.getId().getApproveLevel());
/* 213 */             if (list == null) {
/* 214 */               list = new ArrayList();
/* 215 */               list.add(level);
/* 216 */               retMap.put(level.getId().getApproveLevel(), list);
/*     */             } else {
/* 218 */               list.add(level);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 223 */         Set set = retMap.entrySet();
/* 224 */         for (Map.Entry entry : set) {
/* 225 */           Map row = new HashMap();
/* 226 */           row.put("id", entry.getKey());
/* 227 */           row.put("name", "第【" + entry.getKey() + "】级审批");
/* 228 */           List children = new ArrayList();
/* 229 */           for (MtlApproveLevelDef mtlApproveLevelDef : (List)entry.getValue()) {
/* 230 */             Map child = new HashMap();
/* 231 */             child.put("id", mtlApproveLevelDef.getId().getApproveObjId());
/* 232 */             child.put("name", mtlApproveLevelDef.getApproveObjName());
/* 233 */             child.put("approveObjType", mtlApproveLevelDef.getId().getApproveObjType());
/* 234 */             children.add(child);
/*     */           }
/* 236 */           row.put("children", children);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 240 */       log.error("查看审批级别定义信息异常", e);
/*     */     }
/* 242 */     outJson(resp, JSONArray.fromObject(rows).toString());
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> beanToMap(Object obj)
/*     */   {
/* 247 */     Map params = new HashMap(0);
/*     */     try {
/* 249 */       PropertyUtilsBean propertyUtilsBean = new PropertyUtilsBean();
/* 250 */       PropertyDescriptor[] descriptors = propertyUtilsBean.getPropertyDescriptors(obj);
/* 251 */       for (int i = 0; i < descriptors.length; i++) {
/* 252 */         String name = descriptors[i].getName();
/* 253 */         if (!StringUtils.equals(name, "class"))
/* 254 */           params.put(name, propertyUtilsBean.getNestedProperty(obj, name));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 258 */       e.printStackTrace();
/*     */     }
/* 260 */     return params;
/*     */   }
/*     */ 
/*     */   public void setService(IMtlApproveFlowDefService service) {
/* 264 */     this.service = service;
/*     */   }
/*     */ 
/*     */   public void setUserPrivilegeService(IUserPrivilegeCommonService userPrivilegeService) {
/* 268 */     this.userPrivilegeService = userPrivilegeService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.controller.ApprovalDefController
 * JD-Core Version:    0.6.2
 */
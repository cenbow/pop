package com.ai.bdx.frame.approval.controller;

import java.beans.PropertyDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
import com.ai.bdx.frame.approval.service.IMpmCommonService;
import com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService;
import com.ai.bdx.frame.approval.util.MpmUtil;
import com.ai.bdx.frame.approval.util.RequestUtils;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.utils.string.StringUtil;

/**
 * 审批流程定义
 * @author lixiangqian
 *
 */
@Controller
@RequestMapping("/approvalDef/*")
public class ApprovalDefController extends BaseController {
	private static Logger log = LogManager.getLogger();

	@Autowired
	private IMtlApproveFlowDefService service;

	@Autowired
	private IUserPrivilegeCommonService userPrivilegeService;
	
	@Autowired
	IMpmCommonService commonService;
	
	//流程定义列表
	@SuppressWarnings("unchecked")
	@RequestMapping("list")
	public void list(String page, String rows, String approveFlowName, HttpServletRequest request,
			HttpServletResponse resp) {
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			if (StringUtil.isEmpty(page)) {
				page = DEFAULT_PAGE;
			}
			if (StringUtil.isEmpty(rows)) {
				rows = DEFAULT_RUMS;
			}
			initAttributes(request);
			MtlApproveFlowDef searchCond = new MtlApproveFlowDef();
			if (!userGroupId.equals(MpmCONST.SYSTEM_ADMIN_GROUP_ID)) {
				searchCond.setCreateUserid(userId);
			}
			searchCond.setApproveFlowName(approveFlowName);
			result = service.findApproveFlow(searchCond, Integer.parseInt(page) - 1, Integer.parseInt(rows));
			List<MtlApproveFlowDef> list = (List<MtlApproveFlowDef>) result.get("result");
			List<Map<String, Object>> rowsList = new ArrayList<Map<String, Object>>();
			for (MtlApproveFlowDef mtlApproveFlowDef : list) {
				Map<String, Object> row = new HashMap<String, Object>();
				row.put("approveFlowId", mtlApproveFlowDef.getApproveFlowId());
				row.put("approveFlowName", mtlApproveFlowDef.getApproveFlowName());
				row.put("approveFlowAccessToken", mtlApproveFlowDef.getApproveFlowAccessToken());
				row.put("approveFlowLevelCnt", mtlApproveFlowDef.getApproveFlowLevelCnt());
				row.put("createUserid", mtlApproveFlowDef.getCreateUserid());
				IUser user = userPrivilegeService.getUser(mtlApproveFlowDef.getCreateUserid());
				if (user == null) {
					row.put("createUsername", mtlApproveFlowDef.getCreateUserid());
				} else {
					row.put("createUsername", user.getUsername());
				}
				row.put("createTime", MpmUtil.date2String(mtlApproveFlowDef.getCreateTime()));
				rowsList.add(row);
			}
			result.put("rows", rowsList);
			result.remove("result");
		} catch (Exception e) {
			log.error("获取流程定义列表异常", e);
			result.put("total", 0);
			result.put("rows", "[]");
		}
		toJsonView(resp, result);
	}

	//删除流程定义
	@RequestMapping("delete")
	public void delete(String approveFlowIdsStr, HttpServletResponse resp) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			if (StringUtil.isNotEmpty(approveFlowIdsStr)) {
				String[] approveFlowIds = approveFlowIdsStr.split(",");
				for (int i = 0; i < approveFlowIds.length; i++) {
					service.deleteApproveFlowDef(approveFlowIds[i]);
				}
				result.put("errorMsg", "");
			} else {
				result.put("errorMsg", "没有要删除的数据！");
			}
		} catch (Exception e) {
			log.error("删除流程定义异常", e);
			result.put("errorMsg", e.getMessage());
		}
		toJsonView(resp, result);
	}

	//预新建或修改流程定义
	@RequestMapping("toAddOrUpdate")
	public ModelAndView toUpdate(String approveFlowId, HttpServletRequest req, HttpServletResponse resp) {
		Map<String, Object> model = new HashMap<String, Object>();
		try {
			if (StringUtil.isNotEmpty(approveFlowId)) {
				MtlApproveFlowDef flow = service.getApproveFlowDef(approveFlowId);
				//取审批级别定义
				List<?> levelList = service.getApproveLevelDefByFlow(approveFlowId);
				TreeMap<Integer, List<MtlApproveLevelDef>> retMap = new TreeMap<Integer, List<MtlApproveLevelDef>>();
				if (levelList != null && levelList.size() > 0) {
					MtlApproveLevelDef level;
					for (int i = 0; i < levelList.size(); i++) {
						level = (MtlApproveLevelDef) levelList.get(i);
						level.setApproveObjName(service.getApproveObjNameByTypeAndIdCache(level.getId()
								.getApproveObjType(), level.getId().getApproveObjId()));
						List<MtlApproveLevelDef> list = retMap.get(level.getId().getApproveLevel());
						if (list == null) {
							list = new ArrayList<MtlApproveLevelDef>();
							list.add(level);
							retMap.put(level.getId().getApproveLevel(), list);
						} else {
							list.add(level);
						}
					}
				}
				model.put("flowDef", flow);
				model.put("level", retMap);
			}
		} catch (Exception e) {
			log.error("预新建或修改流程定义异常", e);
		}
		return new ModelAndView("/manage/approvalDefAdd", model);
	}

	//新建或修改流程定义
	@RequestMapping("saveOrUpdate")
	public void save(String approveFlowId, String approveFlowName, String approveFlowAccessToken, String flowType,
			String approveFlowDefStr, HttpServletRequest req, HttpServletResponse resp) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			initAttributes(req);
			MtlApproveFlowDef flowDef = new MtlApproveFlowDef();
			Map<String, String> params = RequestUtils.getParameterMap(req);
			BeanUtils.populate(flowDef, params);
			flowDef.setCreateUserid(userId);
			String deptId = String.valueOf(this.user.getDepartmentid());
			if (StringUtil.isNotEmpty(flowDef.getFirstApproveUser())) {
				IUser firstUser = userPrivilegeService.getUser(flowDef.getFirstApproveUser());
				if (firstUser != null) {
					deptId = String.valueOf(firstUser.getDepartmentid());
				}
			}
			flowDef.setDeptId(deptId);
			flowDef.setCityid(this.user.getCityid());
			//保存前先进行名称是否重复判断
			if (commonService.isNameExist(flowDef.getApproveFlowName(), flowDef.getApproveFlowId(), MpmCONST.MPM_APPROVE_FLOW_DEF, false)) {
				result.put("errorMsg", "流程名称已经存在，请重新输入审批流程名称");
			}else{
				service.saveApproveFlowDef(flowDef, deptId);
				result.put("errorMsg", "");
			}
		} catch (Exception e) {
			log.error("新建或修改流程定义异常", e);
			result.put("errorMsg", e.getMessage());
		}
		toJsonView(resp, result);
	}

	//查看审批级别定义信息
	@RequestMapping("view")
	public void view(String approveFlowId, HttpServletResponse resp) {
		List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
		try {
			if (StringUtil.isNotEmpty(approveFlowId)) {
				//取审批级别定义信息
				@SuppressWarnings("unchecked")
				List<MtlApproveLevelDef> levelList = (List<MtlApproveLevelDef>) service
						.getApproveLevelDefByFlow(approveFlowId);
				TreeMap<Integer, List<MtlApproveLevelDef>> retMap = new TreeMap<Integer, List<MtlApproveLevelDef>>();
				if (levelList != null && levelList.size() > 0) {
					MtlApproveLevelDef level;
					for (int i = 0; i < levelList.size(); i++) {
						level = (MtlApproveLevelDef) levelList.get(i);
						level.setApproveObjName(service.getApproveObjNameByTypeAndIdCache(level.getId()
								.getApproveObjType(), level.getId().getApproveObjId()));
						List<MtlApproveLevelDef> list = retMap.get(level.getId().getApproveLevel());
						if (list == null) {
							list = new ArrayList<MtlApproveLevelDef>();
							list.add(level);
							retMap.put(level.getId().getApproveLevel(), list);
						} else {
							list.add(level);
						}
					}
				}
				//从查询结果构建审批树
				Set<Entry<Integer, List<MtlApproveLevelDef>>> set = retMap.entrySet();
				for (Entry<Integer, List<MtlApproveLevelDef>> entry : set) {
					Map<String, Object> row = new HashMap<String, Object>();
					row.put("id", entry.getKey());
					row.put("name", "第【" + entry.getKey() + "】级审批");
					List<Map<String, Object>> children = new ArrayList<Map<String, Object>>();
					for (MtlApproveLevelDef mtlApproveLevelDef : entry.getValue()) {
						Map<String, Object> child = new HashMap<String, Object>();
						child.put("id", mtlApproveLevelDef.getId().getApproveObjId());
						child.put("name", mtlApproveLevelDef.getApproveObjName());
						child.put("approveObjType", mtlApproveLevelDef.getId().getApproveObjType());
						children.add(child);
					}
					row.put("children", children);
				}
			}
		} catch (Exception e) {
			log.error("查看审批级别定义信息异常", e);
		}
		outJson(resp, JSONArray.fromObject(rows).toString());
	}

	//将javabean转为map类型，然后返回一个map类型的值
	public static Map<String, Object> beanToMap(Object obj) {
		Map<String, Object> params = new HashMap<String, Object>(0);
		try {
			PropertyUtilsBean propertyUtilsBean = new PropertyUtilsBean();
			PropertyDescriptor[] descriptors = propertyUtilsBean.getPropertyDescriptors(obj);
			for (int i = 0; i < descriptors.length; i++) {
				String name = descriptors[i].getName();
				if (!StringUtils.equals(name, "class")) {
					params.put(name, propertyUtilsBean.getNestedProperty(obj, name));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return params;
	}

	public void setService(IMtlApproveFlowDefService service) {
		this.service = service;
	}

	public void setUserPrivilegeService(IUserPrivilegeCommonService userPrivilegeService) {
		this.userPrivilegeService = userPrivilegeService;
	}
}

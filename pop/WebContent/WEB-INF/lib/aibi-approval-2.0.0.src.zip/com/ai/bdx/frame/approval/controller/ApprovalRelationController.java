package com.ai.bdx.frame.approval.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ai.bdx.frame.approval.model.MtlApproveRelation;
import com.ai.bdx.frame.approval.service.IMpmApproveRelationSvc;
import com.ai.bdx.frame.approval.util.MpmUtil;
import com.ai.bdx.frame.approval.util.TreeNode;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.IUserCompany;
import com.asiainfo.biframe.utils.string.StringUtil;

/**
 * 审批关系
 * @author lixiangqian
 *
 */
@Controller
@RequestMapping("/approvalRelation/*")
public class ApprovalRelationController extends BaseController {
	private static Logger log = LogManager.getLogger();

	@Autowired
	private IMpmApproveRelationSvc service;

	@Autowired
	private IUserPrivilegeCommonService userPrivilegeService;

	//审批关系列表
	@SuppressWarnings("unchecked")
	@RequestMapping("list")
	public void list(String page, String rows, String deptId, String approveUserid, HttpServletRequest request,
			HttpServletResponse resp) {
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			if (StringUtil.isEmpty(page)) {
				page = DEFAULT_PAGE;
			}
			if (StringUtil.isEmpty(rows)) {
				rows = DEFAULT_RUMS;
			}
			MtlApproveRelation svc = new MtlApproveRelation();
			if (StringUtil.isNotEmpty(deptId)) {
				svc.getId().setDeptId(Integer.valueOf(deptId));
			} else {
				svc.getId().setDeptId(null);
			}
			if (StringUtil.isNotEmpty(approveUserid)) {
				svc.getId().setApproveUserid(approveUserid);
			} else {
				svc.getId().setApproveUserid(null);
			}
			result = service.findApproveAll(svc, Integer.parseInt(page) - 1, Integer.parseInt(rows));
			List<MtlApproveRelation> list = (List<MtlApproveRelation>) result.get("result");
			List<Map<String, Object>> rowsList = new ArrayList<Map<String, Object>>();
			for (MtlApproveRelation mtlApproveRelation : list) {
				Map<String, Object> row = new HashMap<String, Object>();
				String _deptId = mtlApproveRelation.getId().getDeptId().toString();
				String _deptName = null;
				IUserCompany userCompany = userPrivilegeService.getUserCompanyById(_deptId);
				if (userCompany == null) {
					_deptName = _deptId;
				} else {
					_deptName = userCompany.getTitle();
				}
				row.put("deptName", _deptName);
				row.put("deptId", _deptId);
				row.put("approveUserid", mtlApproveRelation.getId().getApproveUserid());
				IUser approveUser = userPrivilegeService.getUser(mtlApproveRelation.getId().getApproveUserid());
				if (approveUser == null) {
					row.put("approveUsername", mtlApproveRelation.getId().getApproveUserid());
				} else {
					row.put("approveUsername", approveUser.getUsername());
				}
				row.put("approveCreateUserid", mtlApproveRelation.getApproveCreateUserid());
				IUser user = userPrivilegeService.getUser(mtlApproveRelation.getApproveCreateUserid());
				if (user == null) {
					row.put("approveCreateUsername", mtlApproveRelation.getApproveCreateUserid());
				} else {
					row.put("approveCreateUsername", user.getUsername());
				}
				row.put("createTime", MpmUtil.date2String(mtlApproveRelation.getCreateTime()));
				row.put("approveUseridMsisdn", mtlApproveRelation.getApproveUseridMsisdn());
				row.put("approveUseridEmail", mtlApproveRelation.getApproveUseridEmail());
				rowsList.add(row);
			}
			result.put("rows", rowsList);
			result.remove("result");
		} catch (Exception e) {
			log.error("获取审批关系列表异常", e);
			result.put("total", 0);
			result.put("rows", "[]");
		}
		toJsonView(resp, result);
	}

	//获取组织树
	@RequestMapping("getGroupTree")
	public void getGroupTree(String searchText, HttpServletResponse resp) {
		List<TreeNode> nodeList = new ArrayList<TreeNode>();
		List<TreeNode> resultList = new ArrayList<TreeNode>();
		try {
			List<IUserCompany>  companys = userPrivilegeService.getAllUserCompany();
			Map<String, TreeNode> allNodes = new HashMap<String, TreeNode>();
			Set<String> parentIds = new HashSet<String>();
			for (IUserCompany userCompany : companys) {
				TreeNode treeNode = new TreeNode();
				String companyId = userCompany.getDeptid().toString();
				treeNode.setId(companyId);
				treeNode.setPid(String.valueOf(userCompany.getParentid()));
				treeNode.setText(userCompany.getTitle());
				treeNode.setQtip(userCompany.getTitle());
				treeNode.setDisabled(false);
				nodeList.add(treeNode);
				allNodes.put(companyId, treeNode);
				parentIds.add(String.valueOf(userCompany.getParentid()));
			}
			if(StringUtil.isNotEmpty(searchText)){
				//从叶子节点搜索开始，先找到叶子节点
				List<IUserCompany> leafs = new ArrayList<IUserCompany>();
				for (IUserCompany userCompany : companys) {
					String companyId = userCompany.getDeptid().toString();
					if (!parentIds.contains(companyId)) {//找叶子节点
						leafs.add(userCompany);
					}
				}
				List<String> matchNodeIds = new ArrayList<String>();
				for (IUserCompany iUserCompany : leafs) {
					TreeNode currentNode = allNodes.get(iUserCompany.getDeptid().toString());
					if (iUserCompany.getTitle().contains(searchText)) {
						markCompanyTree(currentNode, allNodes,matchNodeIds);
					}else{
						markCompanyTree(searchText, currentNode, allNodes, matchNodeIds);
					}
				}
				Iterator<TreeNode> iterator = nodeList.iterator();
				while (iterator.hasNext()) {
					TreeNode node =iterator.next();
					if (matchNodeIds.contains(node.getId())) {
						resultList.add(node);
					}
				}
				toJsonView(resp,resultList);
				return;
			}
		} catch (Exception e) {
			log.error("获取驱动类型分类异常", e);
		}
		toJsonView(resp,nodeList);
	}
	
	/**
	 * 递归标记true，从叶子到根节点
	 * @param currentNode
	 * @param allNodes
	 */
	public void markCompanyTree(TreeNode currentNode, Map<String, TreeNode> allNodes, List<String> matchNodeIds){
		if (currentNode.isMatch()) {//若已经标记过，就不再递归标记
			return;
		}else{
			matchNodeIds.add(currentNode.getId());
			String pid = currentNode.getPid();
			if("0".equals(pid) || "".equals(pid) || "-1".equals(pid)){//根节点
				return;
			}else{
				TreeNode parentNode = allNodes.get(currentNode.getPid());
				if (parentNode != null) {
					markCompanyTree(parentNode, allNodes, matchNodeIds);
				}
			}
		}
	}
	
	/**
	 * 不匹配节点递归标记--从叶子节点到根节点
	 * @param searchText
	 * @param currentNode
	 * @param allNodes
	 */
	public void markCompanyTree(String searchText, TreeNode currentNode, Map<String, TreeNode> allNodes, List<String> matchNodeIds){
		currentNode.setMatch(false);
		String pid = currentNode.getPid();
		if("".equals(pid) || "-1".equals(pid)){//根节点
			return;
		}
		TreeNode parentNode = allNodes.get(pid);
		if(parentNode != null){
			if (parentNode.getText().contains(searchText)) {//匹配上，进行标记
				markCompanyTree(parentNode, allNodes, matchNodeIds);
			}else{//匹配不上进行自递归
				markCompanyTree(searchText, parentNode, allNodes, matchNodeIds);
			}
		}
	}

	//获取用户树
	@RequestMapping("getUserTree")
	public void getUserTree(String id, String searchText, HttpServletResponse resp) {
		List<TreeNode> nodeList = new ArrayList<TreeNode>();
		JsonConfig config = new JsonConfig();
		try {
			List<IUserCompany> it = null;
			if(StringUtil.isEmpty(id)){
				id = "0";
			}
			if (StringUtil.isEmpty(searchText)) {//异步加载
				String companyId = id.replace("dept_", "");
				if ("-1".equals(companyId)) {//加载未知虚节点数据
					Iterator<?> iter = userPrivilegeService.getUsersByCompany("0").iterator();
					while (iter.hasNext()) {
						IUser user = (IUser) iter.next();
						TreeNode subTreeNode = new TreeNode();
						subTreeNode.setId(user.getUserid());
						subTreeNode.setPid("dept_" + "-1");
						subTreeNode.setText(user.getUsername());
						subTreeNode.setQtip(user.getUsername());
						nodeList.add(subTreeNode);
					}
				} else {//加载公司下一级子公司或人员信息
					it = userPrivilegeService.getSubUserCompanyByPId(companyId);
					for (IUserCompany userCompany : it) {
						TreeNode treeNode = new TreeNode();
						treeNode.setId("dept_" + userCompany.getDeptid());
						treeNode.setPid("dept_" + userCompany.getParentid());
						treeNode.setText(userCompany.getTitle());
						treeNode.setQtip(userCompany.getTitle());
						treeNode.setLeaf(false);
						treeNode.setDisabled(true);
						treeNode.setIsParent(true);
						nodeList.add(treeNode);
					}
					
					if (!"0".equals(companyId) ) {
						Iterator<?> iter = userPrivilegeService.getUsersByCompany(companyId).iterator();
						while (iter.hasNext()) {
							IUser user = (IUser) iter.next();
							TreeNode subTreeNode = new TreeNode();
							subTreeNode.setId(user.getUserid());
							subTreeNode.setPid("dept_" + companyId);
							subTreeNode.setText(user.getUsername());
							subTreeNode.setQtip(user.getUsername());
							nodeList.add(subTreeNode);
						}
					}else{//虚节点，用来存放父节点为0
						TreeNode treeNode = new TreeNode();
						treeNode.setId("dept_" + "-1");
						treeNode.setPid("dept_" + "0");
						treeNode.setText("未知");
						treeNode.setQtip("未知");
						treeNode.setLeaf(false);
						treeNode.setDisabled(true);
						treeNode.setIsParent(true);
						nodeList.add(treeNode);
					}
				}
				config.setExcludes(new String[]{"children"});
				outJson(resp, JSONArray.fromObject(nodeList, config).toString());
			} else {//搜索时，一次性全部加载
				@SuppressWarnings("unchecked")
				List<IUser> allUsers = (List<IUser>)userPrivilegeService.getAllUser();
				List<TreeNode> leafNodes = new ArrayList<TreeNode>();
				for (IUser iUser : allUsers) {
					if (iUser.getUsername().contains(searchText)) {
						TreeNode subTreeNode = new TreeNode();
						subTreeNode.setId(iUser.getUserid());
						subTreeNode.setPid("dept_" + iUser.getDepartmentid());
						subTreeNode.setText(iUser.getUsername());
						subTreeNode.setQtip(iUser.getUsername());
						leafNodes.add(subTreeNode);
					}
				}
				List<IUserCompany>  companys = userPrivilegeService.getAllUserCompany();
				Map<String, IUserCompany> allCompanys = new HashMap<String, IUserCompany>();
				for (IUserCompany userCompany : companys) {
					String companyId = userCompany.getDeptid().toString();
					allCompanys.put(companyId, userCompany);
				}
				List<TreeNode> markedParentNode = new ArrayList<TreeNode>();
				List<String> markedParentIds = new ArrayList<String>();
				for (TreeNode leafNode : leafNodes) {
					if (markedParentIds.contains(leafNode.getPid())) {
						continue;
					}
					String companyId = leafNode.getPid().replace("dept_", "");
					IUserCompany userCompany = allCompanys.get(companyId);
					TreeNode treeNode = new TreeNode();
					treeNode.setId("dept_" + userCompany.getDeptid());
					treeNode.setPid("dept_" + userCompany.getParentid());
					treeNode.setText(userCompany.getTitle());
					treeNode.setQtip(userCompany.getTitle());
					treeNode.setLeaf(false);
					treeNode.setDisabled(true);
					treeNode.setIsParent(true);
					markParentCompanyNode(treeNode, allCompanys, markedParentNode, markedParentIds);//标记父组织节点
				}
				Collections.reverse(markedParentNode);
				leafNodes.addAll(0, markedParentNode);
				toJsonView(resp, leafNodes);
			}
		} catch (Exception e) {
			log.error("获取用户树异常", e);
		}
	}
	
	//标记父组织节点
	private void markParentCompanyNode(TreeNode subNode,
			Map<String, IUserCompany> allCompanys,
			List<TreeNode> markedParentNode, List<String> markedParentIds) {
		//标记当前节点
		markedParentNode.add(subNode);
		markedParentIds.add(subNode.getId());
		//查找父节点
		String pid = subNode.getPid();
		if(StringUtil.isEmpty(pid) || "0".equals(pid) || "-1".equals(pid)){
			return;
		}
		IUserCompany userCompany = allCompanys.get(pid.replace("dept_",""));
		if (userCompany == null) {
			return;
		}
		TreeNode treeNode = new TreeNode();
		treeNode.setId("dept_" + userCompany.getDeptid());
		treeNode.setPid("dept_" + userCompany.getParentid());
		treeNode.setText(userCompany.getTitle());
		treeNode.setQtip(userCompany.getTitle());
		treeNode.setLeaf(false);
		treeNode.setDisabled(true);
		treeNode.setIsParent(true);
		markParentCompanyNode(treeNode, allCompanys, markedParentNode, markedParentIds);
	}

	//保存审批关系
	@RequestMapping("save")
	public void save(String deptId, String approveUserid, HttpServletRequest req, HttpServletResponse resp) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			if (service.ApproveRelationExist(deptId)) {
				result.put("errorMsg", "已经为该部门设置了审批人！");
			} else {
				MtlApproveRelation svc = new MtlApproveRelation();
				svc.getId().setDeptId(Integer.valueOf(deptId));
				svc.getId().setApproveUserid(approveUserid);
				initAttributes(req);
				svc.setApproveCreateUserid(user.getUserid());
				Calendar cal = Calendar.getInstance();
				svc.setCreateTime(cal.getTime());
				svc.setPositionId(Integer.valueOf(0));
				IUser approveUser = userPrivilegeService.getUser(approveUserid);
				svc.setApproveUseridEmail(approveUser.getEmail());
				svc.setApproveUseridMsisdn(approveUser.getMobilePhone());
				svc.setCityid(approveUser.getCityid());
				service.saveApprove(svc);
				result.put("errorMsg", "");
			}
		} catch (Exception e) {
			log.error("保存审批关系异常", e);
			result.put("errorMsg", e.getMessage());
		}
		toJsonView(resp, result);
	}

	//保存审批关系
	@RequestMapping("update")
	public void update(String deptId, String approveUserid, String beforeApproveUserid, String beforeCreateUserid,
			HttpServletRequest req, HttpServletResponse resp) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			MtlApproveRelation svc = new MtlApproveRelation();
			svc.getId().setDeptId(Integer.valueOf(deptId));
			svc.getId().setApproveUserid(approveUserid);
			initAttributes(req);
			svc.setApproveCreateUserid(user.getUserid());
			Calendar cal = Calendar.getInstance();
			svc.setCreateTime(cal.getTime());
			svc.setPositionId(Integer.valueOf(0));
			IUser approveUser = userPrivilegeService.getUser(approveUserid);
			svc.setApproveUseridEmail(approveUser.getEmail());
			svc.setApproveUseridMsisdn(approveUser.getMobilePhone());
			svc.setCityid(approveUser.getCityid());
			if (null != approveUser.getEmail()) {
				svc.setApproveUseridEmail(approveUser.getEmail());
			}
			if (null != approveUser.getMobilePhone()) {
				svc.setApproveUseridMsisdn(approveUser.getMobilePhone());
			}
			svc.setBeforeApproveUserid(beforeApproveUserid);
			svc.setBeforeCreateUserid(beforeCreateUserid);
			if (!approveUserid.equals(beforeApproveUserid)) {//修改了主键
				service.updateByJdbc(svc);
			} else {
				service.updateByHiberite(svc);
			}
			service.updateByHiberite(svc);
			result.put("errorMsg", "");
		} catch (Exception e) {
			log.error("保存审批关系异常", e);
			result.put("errorMsg", e.getMessage());
		}
		toJsonView(resp, result);
	}

	//删除审批关系
	@RequestMapping("delete")
	public void delete(String deptIdsStr, String approveUseridsStr, HttpServletResponse resp) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			if (StringUtil.isNotEmpty(deptIdsStr) && StringUtil.isNotEmpty(approveUseridsStr)) {
				String[] deptIds = deptIdsStr.split(",");
				String[] approveUserids = approveUseridsStr.split(",");
				for (int i = 0; i < deptIds.length; i++) {
					String deptId = deptIds[i];
					String approveUserid = approveUserids[i];
					MtlApproveRelation svc = new MtlApproveRelation();
					svc.getId().setDeptId(Integer.valueOf(deptId));
					svc.getId().setApproveUserid(approveUserid);
					service.deleteApprove(svc);
				}
				result.put("errorMsg", "");
			} else {
				result.put("errorMsg", "没有要删除的数据！");
			}
		} catch (Exception e) {
			log.error("删除审批关系异常", e);
			result.put("errorMsg", e.getMessage());
		}
		toJsonView(resp, result);
	}

	public void setService(IMpmApproveRelationSvc service) {
		this.service = service;
	}

	public void setUserPrivilegeService(IUserPrivilegeCommonService userPrivilegeService) {
		this.userPrivilegeService = userPrivilegeService;
	}
}

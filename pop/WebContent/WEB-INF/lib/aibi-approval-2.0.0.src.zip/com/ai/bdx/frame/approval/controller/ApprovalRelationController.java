/*     */ package com.ai.bdx.frame.approval.controller;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveRelation;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveRelationKey;
/*     */ import com.ai.bdx.frame.approval.service.IMpmApproveRelationSvc;
/*     */ import com.ai.bdx.frame.approval.util.MpmUtil;
/*     */ import com.ai.bdx.frame.approval.util.TreeNode;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JsonConfig;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ 
/*     */ @Controller
/*     */ @RequestMapping({"/approvalRelation/*"})
/*     */ public class ApprovalRelationController extends BaseController
/*     */ {
/*  42 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   @Autowired
/*     */   private IMpmApproveRelationSvc service;
/*     */ 
/*     */   @Autowired
/*     */   private IUserPrivilegeCommonService userPrivilegeService;
/*     */ 
/*     */   @RequestMapping({"list"})
/*     */   public void list(String page, String rows, String deptId, String approveUserid, HttpServletRequest request, HttpServletResponse resp)
/*     */   {
/*  55 */     Map result = new HashMap();
/*     */     try {
/*  57 */       if (StringUtil.isEmpty(page)) {
/*  58 */         page = "1";
/*     */       }
/*  60 */       if (StringUtil.isEmpty(rows)) {
/*  61 */         rows = "10";
/*     */       }
/*  63 */       MtlApproveRelation svc = new MtlApproveRelation();
/*  64 */       if (StringUtil.isNotEmpty(deptId))
/*  65 */         svc.getId().setDeptId(Integer.valueOf(deptId));
/*     */       else {
/*  67 */         svc.getId().setDeptId(null);
/*     */       }
/*  69 */       if (StringUtil.isNotEmpty(approveUserid))
/*  70 */         svc.getId().setApproveUserid(approveUserid);
/*     */       else {
/*  72 */         svc.getId().setApproveUserid(null);
/*     */       }
/*  74 */       result = this.service.findApproveAll(svc, Integer.valueOf(Integer.parseInt(page) - 1), Integer.valueOf(Integer.parseInt(rows)));
/*  75 */       List list = (List)result.get("result");
/*  76 */       List rowsList = new ArrayList();
/*  77 */       for (MtlApproveRelation mtlApproveRelation : list) {
/*  78 */         Map row = new HashMap();
/*  79 */         String _deptId = mtlApproveRelation.getId().getDeptId().toString();
/*  80 */         String _deptName = null;
/*  81 */         IUserCompany userCompany = this.userPrivilegeService.getUserCompanyById(_deptId);
/*  82 */         if (userCompany == null)
/*  83 */           _deptName = _deptId;
/*     */         else {
/*  85 */           _deptName = userCompany.getTitle();
/*     */         }
/*  87 */         row.put("deptName", _deptName);
/*  88 */         row.put("deptId", _deptId);
/*  89 */         row.put("approveUserid", mtlApproveRelation.getId().getApproveUserid());
/*  90 */         IUser approveUser = this.userPrivilegeService.getUser(mtlApproveRelation.getId().getApproveUserid());
/*  91 */         if (approveUser == null)
/*  92 */           row.put("approveUsername", mtlApproveRelation.getId().getApproveUserid());
/*     */         else {
/*  94 */           row.put("approveUsername", approveUser.getUsername());
/*     */         }
/*  96 */         row.put("approveCreateUserid", mtlApproveRelation.getApproveCreateUserid());
/*  97 */         IUser user = this.userPrivilegeService.getUser(mtlApproveRelation.getApproveCreateUserid());
/*  98 */         if (user == null)
/*  99 */           row.put("approveCreateUsername", mtlApproveRelation.getApproveCreateUserid());
/*     */         else {
/* 101 */           row.put("approveCreateUsername", user.getUsername());
/*     */         }
/* 103 */         row.put("createTime", MpmUtil.date2String(mtlApproveRelation.getCreateTime()));
/* 104 */         row.put("approveUseridMsisdn", mtlApproveRelation.getApproveUseridMsisdn());
/* 105 */         row.put("approveUseridEmail", mtlApproveRelation.getApproveUseridEmail());
/* 106 */         rowsList.add(row);
/*     */       }
/* 108 */       result.put("rows", rowsList);
/* 109 */       result.remove("result");
/*     */     } catch (Exception e) {
/* 111 */       log.error("获取审批关系列表异常", e);
/* 112 */       result.put("total", Integer.valueOf(0));
/* 113 */       result.put("rows", "[]");
/*     */     }
/* 115 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"getGroupTree"})
/*     */   public void getGroupTree(String searchText, HttpServletResponse resp)
/*     */   {
/* 121 */     List nodeList = new ArrayList();
/* 122 */     List resultList = new ArrayList();
/*     */     try {
/* 124 */       List companys = this.userPrivilegeService.getAllUserCompany();
/* 125 */       Map allNodes = new HashMap();
/* 126 */       Set parentIds = new HashSet();
/*     */       TreeNode treeNode;
/* 127 */       for (IUserCompany userCompany : companys) {
/* 128 */         treeNode = new TreeNode();
/* 129 */         String companyId = userCompany.getDeptid().toString();
/* 130 */         treeNode.setId(companyId);
/* 131 */         treeNode.setPid(String.valueOf(userCompany.getParentid()));
/* 132 */         treeNode.setText(userCompany.getTitle());
/* 133 */         treeNode.setQtip(userCompany.getTitle());
/* 134 */         treeNode.setDisabled(false);
/* 135 */         nodeList.add(treeNode);
/* 136 */         allNodes.put(companyId, treeNode);
/* 137 */         parentIds.add(String.valueOf(userCompany.getParentid()));
/*     */       }
/* 139 */       if (StringUtil.isNotEmpty(searchText))
/*     */       {
/* 141 */         List leafs = new ArrayList();
/*     */         String companyId;
/* 142 */         for (IUserCompany userCompany : companys) {
/* 143 */           companyId = userCompany.getDeptid().toString();
/* 144 */           if (!parentIds.contains(companyId)) {
/* 145 */             leafs.add(userCompany);
/*     */           }
/*     */         }
/* 148 */         Object matchNodeIds = new ArrayList();
/* 149 */         for (IUserCompany iUserCompany : leafs) {
/* 150 */           TreeNode currentNode = (TreeNode)allNodes.get(iUserCompany.getDeptid().toString());
/* 151 */           if (iUserCompany.getTitle().contains(searchText))
/* 152 */             markCompanyTree(currentNode, allNodes, (List)matchNodeIds);
/*     */           else {
/* 154 */             markCompanyTree(searchText, currentNode, allNodes, (List)matchNodeIds);
/*     */           }
/*     */         }
/* 157 */         Iterator iterator = nodeList.iterator();
/* 158 */         while (iterator.hasNext()) {
/* 159 */           TreeNode node = (TreeNode)iterator.next();
/* 160 */           if (((List)matchNodeIds).contains(node.getId())) {
/* 161 */             resultList.add(node);
/*     */           }
/*     */         }
/* 164 */         toJsonView(resp, resultList);
/* 165 */         return;
/*     */       }
/*     */     } catch (Exception e) {
/* 168 */       log.error("获取驱动类型分类异常", e);
/*     */ 
/* 170 */       toJsonView(resp, nodeList);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void markCompanyTree(TreeNode currentNode, Map<String, TreeNode> allNodes, List<String> matchNodeIds)
/*     */   {
/* 179 */     if (currentNode.isMatch()) {
/* 180 */       return;
/*     */     }
/* 182 */     matchNodeIds.add(currentNode.getId());
/* 183 */     String pid = currentNode.getPid();
/* 184 */     if (("0".equals(pid)) || ("".equals(pid)) || ("-1".equals(pid))) {
/* 185 */       return;
/*     */     }
/* 187 */     TreeNode parentNode = (TreeNode)allNodes.get(currentNode.getPid());
/* 188 */     if (parentNode != null)
/* 189 */       markCompanyTree(parentNode, allNodes, matchNodeIds);
/*     */   }
/*     */ 
/*     */   public void markCompanyTree(String searchText, TreeNode currentNode, Map<String, TreeNode> allNodes, List<String> matchNodeIds)
/*     */   {
/* 202 */     currentNode.setMatch(false);
/* 203 */     String pid = currentNode.getPid();
/* 204 */     if (("".equals(pid)) || ("-1".equals(pid))) {
/* 205 */       return;
/*     */     }
/* 207 */     TreeNode parentNode = (TreeNode)allNodes.get(pid);
/* 208 */     if (parentNode != null)
/* 209 */       if (parentNode.getText().contains(searchText))
/* 210 */         markCompanyTree(parentNode, allNodes, matchNodeIds);
/*     */       else
/* 212 */         markCompanyTree(searchText, parentNode, allNodes, matchNodeIds);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"getUserTree"})
/*     */   public void getUserTree(String id, String searchText, HttpServletResponse resp)
/*     */   {
/* 220 */     List nodeList = new ArrayList();
/* 221 */     JsonConfig config = new JsonConfig();
/*     */     try {
/* 223 */       List it = null;
/* 224 */       if (StringUtil.isEmpty(id))
/* 225 */         id = "0";
/*     */       TreeNode subTreeNode;
/* 227 */       if (StringUtil.isEmpty(searchText)) {
/* 228 */         String companyId = id.replace("dept_", "");
/*     */         IUser user;
/* 229 */         if ("-1".equals(companyId)) {
/* 230 */           Iterator iter = this.userPrivilegeService.getUsersByCompany("0").iterator();
/* 231 */           while (iter.hasNext()) {
/* 232 */             user = (IUser)iter.next();
/* 233 */             TreeNode subTreeNode = new TreeNode();
/* 234 */             subTreeNode.setId(user.getUserid());
/* 235 */             subTreeNode.setPid("dept_-1");
/* 236 */             subTreeNode.setText(user.getUsername());
/* 237 */             subTreeNode.setQtip(user.getUsername());
/* 238 */             nodeList.add(subTreeNode);
/*     */           }
/*     */         } else {
/* 241 */           it = this.userPrivilegeService.getSubUserCompanyByPId(companyId);
/* 242 */           for (IUserCompany userCompany : it) {
/* 243 */             TreeNode treeNode = new TreeNode();
/* 244 */             treeNode.setId("dept_" + userCompany.getDeptid());
/* 245 */             treeNode.setPid("dept_" + userCompany.getParentid());
/* 246 */             treeNode.setText(userCompany.getTitle());
/* 247 */             treeNode.setQtip(userCompany.getTitle());
/* 248 */             treeNode.setLeaf(false);
/* 249 */             treeNode.setDisabled(true);
/* 250 */             treeNode.setIsParent(true);
/* 251 */             nodeList.add(treeNode);
/*     */           }
/*     */ 
/* 254 */           if (!"0".equals(companyId)) {
/* 255 */             Iterator iter = this.userPrivilegeService.getUsersByCompany(companyId).iterator();
/* 256 */             while (iter.hasNext()) {
/* 257 */               IUser user = (IUser)iter.next();
/* 258 */               subTreeNode = new TreeNode();
/* 259 */               subTreeNode.setId(user.getUserid());
/* 260 */               subTreeNode.setPid("dept_" + companyId);
/* 261 */               subTreeNode.setText(user.getUsername());
/* 262 */               subTreeNode.setQtip(user.getUsername());
/* 263 */               nodeList.add(subTreeNode);
/*     */             }
/*     */           } else {
/* 266 */             TreeNode treeNode = new TreeNode();
/* 267 */             treeNode.setId("dept_-1");
/* 268 */             treeNode.setPid("dept_0");
/* 269 */             treeNode.setText("未知");
/* 270 */             treeNode.setQtip("未知");
/* 271 */             treeNode.setLeaf(false);
/* 272 */             treeNode.setDisabled(true);
/* 273 */             treeNode.setIsParent(true);
/* 274 */             nodeList.add(treeNode);
/*     */           }
/*     */         }
/* 277 */         config.setExcludes(new String[] { "children" });
/* 278 */         outJson(resp, JSONArray.fromObject(nodeList, config).toString());
/*     */       }
/*     */       else {
/* 281 */         List allUsers = this.userPrivilegeService.getAllUser();
/* 282 */         List leafNodes = new ArrayList();
/* 283 */         for (IUser iUser : allUsers) {
/* 284 */           if (iUser.getUsername().contains(searchText)) {
/* 285 */             TreeNode subTreeNode = new TreeNode();
/* 286 */             subTreeNode.setId(iUser.getUserid());
/* 287 */             subTreeNode.setPid("dept_" + iUser.getDepartmentid());
/* 288 */             subTreeNode.setText(iUser.getUsername());
/* 289 */             subTreeNode.setQtip(iUser.getUsername());
/* 290 */             leafNodes.add(subTreeNode);
/*     */           }
/*     */         }
/* 293 */         List companys = this.userPrivilegeService.getAllUserCompany();
/* 294 */         Map allCompanys = new HashMap();
/* 295 */         for (IUserCompany userCompany : companys) {
/* 296 */           String companyId = userCompany.getDeptid().toString();
/* 297 */           allCompanys.put(companyId, userCompany);
/*     */         }
/* 299 */         List markedParentNode = new ArrayList();
/* 300 */         Object markedParentIds = new ArrayList();
/* 301 */         for (TreeNode leafNode : leafNodes)
/* 302 */           if (!((List)markedParentIds).contains(leafNode.getPid()))
/*     */           {
/* 305 */             String companyId = leafNode.getPid().replace("dept_", "");
/* 306 */             IUserCompany userCompany = (IUserCompany)allCompanys.get(companyId);
/* 307 */             TreeNode treeNode = new TreeNode();
/* 308 */             if (userCompany != null)
/*     */             {
/* 310 */               treeNode.setId("dept_" + userCompany.getDeptid());
/* 311 */               treeNode.setPid("dept_" + userCompany.getParentid());
/* 312 */               treeNode.setText(userCompany.getTitle());
/* 313 */               treeNode.setQtip(userCompany.getTitle());
/*     */             }
/* 315 */             treeNode.setLeaf(false);
/* 316 */             treeNode.setDisabled(true);
/* 317 */             treeNode.setIsParent(true);
/* 318 */             markParentCompanyNode(treeNode, allCompanys, markedParentNode, (List)markedParentIds);
/*     */           }
/* 320 */         Collections.reverse(markedParentNode);
/* 321 */         leafNodes.addAll(0, markedParentNode);
/* 322 */         toJsonView(resp, leafNodes);
/*     */       }
/*     */     } catch (Exception e) {
/* 325 */       log.error("获取用户树异常", e);
/* 326 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void markParentCompanyNode(TreeNode subNode, Map<String, IUserCompany> allCompanys, List<TreeNode> markedParentNode, List<String> markedParentIds)
/*     */   {
/* 335 */     markedParentNode.add(subNode);
/* 336 */     markedParentIds.add(subNode.getId());
/*     */ 
/* 338 */     String pid = subNode.getPid();
/* 339 */     if ((StringUtil.isEmpty(pid)) || ("0".equals(pid)) || ("-1".equals(pid))) {
/* 340 */       return;
/*     */     }
/* 342 */     IUserCompany userCompany = (IUserCompany)allCompanys.get(pid.replace("dept_", ""));
/* 343 */     if (userCompany == null) {
/* 344 */       return;
/*     */     }
/* 346 */     TreeNode treeNode = new TreeNode();
/* 347 */     treeNode.setId("dept_" + userCompany.getDeptid());
/* 348 */     treeNode.setPid("dept_" + userCompany.getParentid());
/* 349 */     treeNode.setText(userCompany.getTitle());
/* 350 */     treeNode.setQtip(userCompany.getTitle());
/* 351 */     treeNode.setLeaf(false);
/* 352 */     treeNode.setDisabled(true);
/* 353 */     treeNode.setIsParent(true);
/* 354 */     markParentCompanyNode(treeNode, allCompanys, markedParentNode, markedParentIds);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"save"})
/*     */   public void save(String deptId, String approveUserid, HttpServletRequest req, HttpServletResponse resp)
/*     */   {
/* 360 */     Map result = new HashMap();
/*     */     try {
/* 362 */       if (this.service.ApproveRelationExist(deptId)) {
/* 363 */         result.put("errorMsg", "已经为该部门设置了审批人！");
/*     */       } else {
/* 365 */         MtlApproveRelation svc = new MtlApproveRelation();
/* 366 */         svc.getId().setDeptId(Integer.valueOf(deptId));
/* 367 */         svc.getId().setApproveUserid(approveUserid);
/* 368 */         initAttributes(req);
/* 369 */         svc.setApproveCreateUserid(this.user.getUserid());
/* 370 */         Calendar cal = Calendar.getInstance();
/* 371 */         svc.setCreateTime(cal.getTime());
/* 372 */         svc.setPositionId(Integer.valueOf(0));
/* 373 */         IUser approveUser = this.userPrivilegeService.getUser(approveUserid);
/* 374 */         svc.setApproveUseridEmail(approveUser.getEmail());
/* 375 */         svc.setApproveUseridMsisdn(approveUser.getMobilePhone());
/* 376 */         svc.setCityid(approveUser.getCityid());
/* 377 */         this.service.saveApprove(svc);
/* 378 */         result.put("errorMsg", "");
/*     */       }
/*     */     } catch (Exception e) {
/* 381 */       log.error("保存审批关系异常", e);
/* 382 */       result.put("errorMsg", e.getMessage());
/*     */     }
/* 384 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"update"})
/*     */   public void update(String deptId, String approveUserid, String beforeApproveUserid, String beforeCreateUserid, HttpServletRequest req, HttpServletResponse resp)
/*     */   {
/* 391 */     Map result = new HashMap();
/*     */     try {
/* 393 */       MtlApproveRelation svc = new MtlApproveRelation();
/* 394 */       svc.getId().setDeptId(Integer.valueOf(deptId));
/* 395 */       svc.getId().setApproveUserid(approveUserid);
/* 396 */       initAttributes(req);
/* 397 */       svc.setApproveCreateUserid(this.user.getUserid());
/* 398 */       Calendar cal = Calendar.getInstance();
/* 399 */       svc.setCreateTime(cal.getTime());
/* 400 */       svc.setPositionId(Integer.valueOf(0));
/* 401 */       IUser approveUser = this.userPrivilegeService.getUser(approveUserid);
/* 402 */       svc.setApproveUseridEmail(approveUser.getEmail());
/* 403 */       svc.setApproveUseridMsisdn(approveUser.getMobilePhone());
/* 404 */       svc.setCityid(approveUser.getCityid());
/* 405 */       if (approveUser.getEmail() != null) {
/* 406 */         svc.setApproveUseridEmail(approveUser.getEmail());
/*     */       }
/* 408 */       if (approveUser.getMobilePhone() != null) {
/* 409 */         svc.setApproveUseridMsisdn(approveUser.getMobilePhone());
/*     */       }
/* 411 */       svc.setBeforeApproveUserid(beforeApproveUserid);
/* 412 */       svc.setBeforeCreateUserid(beforeCreateUserid);
/* 413 */       if (!approveUserid.equals(beforeApproveUserid))
/* 414 */         this.service.updateByJdbc(svc);
/*     */       else {
/* 416 */         this.service.updateByHiberite(svc);
/*     */       }
/* 418 */       this.service.updateByHiberite(svc);
/* 419 */       result.put("errorMsg", "");
/*     */     } catch (Exception e) {
/* 421 */       log.error("保存审批关系异常", e);
/* 422 */       result.put("errorMsg", e.getMessage());
/*     */     }
/* 424 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"delete"})
/*     */   public void delete(String deptIdsStr, String approveUseridsStr, HttpServletResponse resp)
/*     */   {
/* 430 */     Map result = new HashMap();
/*     */     try {
/* 432 */       if ((StringUtil.isNotEmpty(deptIdsStr)) && (StringUtil.isNotEmpty(approveUseridsStr))) {
/* 433 */         String[] deptIds = deptIdsStr.split(",");
/* 434 */         String[] approveUserids = approveUseridsStr.split(",");
/* 435 */         for (int i = 0; i < deptIds.length; i++) {
/* 436 */           String deptId = deptIds[i];
/* 437 */           String approveUserid = approveUserids[i];
/* 438 */           MtlApproveRelation svc = new MtlApproveRelation();
/* 439 */           svc.getId().setDeptId(Integer.valueOf(deptId));
/* 440 */           svc.getId().setApproveUserid(approveUserid);
/* 441 */           this.service.deleteApprove(svc);
/*     */         }
/* 443 */         result.put("errorMsg", "");
/*     */       } else {
/* 445 */         result.put("errorMsg", "没有要删除的数据！");
/*     */       }
/*     */     } catch (Exception e) {
/* 448 */       log.error("删除审批关系异常", e);
/* 449 */       result.put("errorMsg", e.getMessage());
/*     */     }
/* 451 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   public void setService(IMpmApproveRelationSvc service) {
/* 455 */     this.service = service;
/*     */   }
/*     */ 
/*     */   public void setUserPrivilegeService(IUserPrivilegeCommonService userPrivilegeService) {
/* 459 */     this.userPrivilegeService = userPrivilegeService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.controller.ApprovalRelationController
 * JD-Core Version:    0.6.2
 */
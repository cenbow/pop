/*    */ package com.ai.bdx.frame.approval.controller;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.IUser;
/*    */ import com.asiainfo.biframe.privilege.IUserSession;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import com.asiainfo.biframe.utils.json.JsonUtil;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Collection;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import net.sf.json.JSONArray;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class BaseController
/*    */ {
/* 19 */   private static Logger log = LogManager.getLogger();
/*    */ 
/* 23 */   protected final String DEFAULT_PAGE = "1";
/*    */ 
/* 27 */   protected final String DEFAULT_RUMS = "10";
/*    */   protected IUser user;
/*    */   protected String userGroupId;
/*    */   protected String userId;
/*    */ 
/*    */   protected void toJsonView(HttpServletResponse resp, Object obj)
/*    */   {
/* 41 */     resp.setCharacterEncoding("utf-8");
/* 42 */     resp.setContentType("text/html");
/*    */     try {
/* 44 */       String jsonStr = null;
/* 45 */       if ((obj instanceof Collection))
/* 46 */         jsonStr = JSONArray.fromObject(obj).toString();
/*    */       else {
/* 48 */         jsonStr = JsonUtil.Object2JsonString(obj);
/*    */       }
/* 50 */       resp.getWriter().write(jsonStr);
/*    */     } catch (Exception e) {
/* 52 */       log.error("输出json异常", e);
/* 53 */       throw new RuntimeException("输出json异常:" + e.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void outJson(HttpServletResponse resp, String jsonString) {
/* 58 */     resp.setCharacterEncoding("utf-8");
/* 59 */     resp.setContentType("text/html");
/*    */     try {
/* 61 */       resp.getWriter().write(jsonString);
/*    */     } catch (Exception e) {
/* 63 */       log.error("输出json异常", e);
/* 64 */       throw new RuntimeException("输出json异常:" + e.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void initAttributes(HttpServletRequest request) throws Exception {
/* 69 */     IUserSession userSession = (IUserSession)request.getSession().getAttribute("biplatform_user");
/* 70 */     log.debug("userSession=[" + userSession + "]");
/* 71 */     if (userSession == null) {
/* 72 */       String msg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.notLoginPrompt");
/* 73 */       log.info("msg=[" + msg + "]");
/* 74 */       throw new Exception(msg);
/*    */     }
/* 76 */     this.userId = userSession.getUserID();
/* 77 */     this.userGroupId = userSession.getGroupId();
/* 78 */     this.user = userSession.getUser();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.controller.BaseController
 * JD-Core Version:    0.6.2
 */
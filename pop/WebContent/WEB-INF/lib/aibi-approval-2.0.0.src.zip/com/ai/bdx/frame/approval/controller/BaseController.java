package com.ai.bdx.frame.approval.controller;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.IUserSession;
import com.asiainfo.biframe.utils.i18n.LocaleUtil;
import com.asiainfo.biframe.utils.json.JsonUtil;

public class BaseController {
	private static Logger log = LogManager.getLogger();
	/**
	 * 默认页索引
	 */
	protected final String DEFAULT_PAGE = "1";
	/**
	 * 默认页大小
	 */
	protected final String DEFAULT_RUMS = "10";
	/**
	 * 当前登录用户
	 */
	protected IUser user;
	/**
	 * 当前登录用户所在组
	 */
	protected String userGroupId;
	/**
	 * 当前登录用户iid
	 */
	protected String userId;
	protected void toJsonView(HttpServletResponse resp,Object obj) {
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html");
		try {
			String jsonStr = null;
			if(obj instanceof Collection){
				jsonStr = JSONArray.fromObject(obj).toString();
			}else{
				jsonStr = JsonUtil.Object2JsonString(obj);
			}
			resp.getWriter().write(jsonStr);
		} catch (Exception e) {
			log.error("输出json异常",e);
			throw new RuntimeException("输出json异常:"+e.getMessage());
		}
	}
	
	protected void outJson(HttpServletResponse resp,String jsonString) {
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html");
		try {
			resp.getWriter().write(jsonString);
		} catch (Exception e) {
			log.error("输出json异常",e);
			throw new RuntimeException("输出json异常:"+e.getMessage());
		}
	}
	
	protected void initAttributes(HttpServletRequest request) throws Exception {
		IUserSession userSession = (IUserSession) request.getSession().getAttribute("biplatform_user");
		log.debug((new StringBuilder()).append("userSession=[").append(userSession).append("]").toString());
		if (userSession == null) {
			String msg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.notLoginPrompt");
			log.info((new StringBuilder()).append("msg=[").append(msg).append("]").toString());
			throw new Exception(msg);
		} else {
			userId = userSession.getUserID();
			userGroupId = userSession.getGroupId();
			user = userSession.getUser();
		}
	}
}

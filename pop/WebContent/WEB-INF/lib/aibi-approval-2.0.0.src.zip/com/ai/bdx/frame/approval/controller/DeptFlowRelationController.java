package com.ai.bdx.frame.approval.controller;

import java.beans.PropertyDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelationId;
import com.ai.bdx.frame.approval.service.IDimDeptFlowRelationService;
import com.ai.bdx.frame.approval.service.IMpmCommonService;
import com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService;
import com.ai.bdx.frame.approval.util.DrvTypeUtil;
import com.ai.bdx.frame.approval.util.MpmCache;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.service.IdNameMapper;
import com.asiainfo.biframe.utils.string.StringUtil;

/**
 * 审批流程定义
 * @author lixiangqian
 *
 */
@SuppressWarnings("deprecation")
@Controller
@RequestMapping("/deptFlowRelation/*")
public class DeptFlowRelationController extends BaseController {
	private static Logger log = LogManager.getLogger();

	@Autowired
	private IDimDeptFlowRelationService service;

	@Autowired
	private IUserPrivilegeCommonService userPrivilegeService;

	@Autowired
	IMpmCommonService commonService;

	@Autowired
	@Qualifier(MpmCONST.DIM_CITY_SERVICE)
	IdNameMapper dimPubCity;

	@Autowired
	@Qualifier(MpmCONST.DIM_DEPTID_SERVICE)
	IdNameMapper dimDeptId;

	@Autowired
	@Qualifier(MpmCONST.MTL_APPROVE_FLOW)
	IdNameMapper approveFlow;

	@Autowired
	IMtlApproveFlowDefService approveService;

	//流程定义列表
	@SuppressWarnings({ "unchecked" })
	@RequestMapping("list")
	public void list(String page, String rows, String campDrvId, String cityId, String relationType, String deptId,
			HttpServletRequest request, HttpServletResponse resp) {
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			if (StringUtil.isEmpty(page)) {
				page = DEFAULT_PAGE;
			}
			if (StringUtil.isEmpty(rows)) {
				rows = DEFAULT_RUMS;
			}
			DimDeptFlowRelation dimDeptFlowRelation = new DimDeptFlowRelation();
			DimDeptFlowRelationId id = new DimDeptFlowRelationId();
			id.setCampDrvId(campDrvId);
			id.setCityId(cityId);
			id.setRelationType(relationType);
			id.setDeptId(deptId);
			dimDeptFlowRelation.setId(id);

			result = service.findDeptFlowActions(dimDeptFlowRelation, Integer.parseInt(page) - 1,
					Integer.parseInt(rows));
			List<DimDeptFlowRelation> list = (List<DimDeptFlowRelation>) result.get("result");
			List<Map<String, Object>> rowsList = new ArrayList<Map<String, Object>>();
			List<LabelValueBean> approveDrvDimTableList = commonService.getAllApproveDrvDimTable();
			Map<String, String> approveDrvDimTableMap = new HashMap<String, String>();
			if (approveDrvDimTableList != null && approveDrvDimTableList.size() > 0) {
				for (LabelValueBean b : approveDrvDimTableList) {
					approveDrvDimTableMap.put(b.getValue(), b.getLabel());
				}
			}
			DrvTypeUtil.init();
			for (DimDeptFlowRelation deptFlowRelation : list) {
				Map<String, Object> row = new HashMap<String, Object>();
				String drvType2 = "";
				String _relationType = deptFlowRelation.getId().getRelationType();
				if (_relationType != null) {
					drvType2 = approveDrvDimTableMap.get(_relationType);
				} else {
					drvType2 = "--";
				}
				row.put("drvTypeClassify", drvType2);//驱动类型分类名称
				row.put("drvType", DrvTypeUtil.getVal(_relationType, deptFlowRelation.getId().getCampDrvId()));//驱动类名称
				String cityName = null;
				if (StringUtil.isNotEmpty(deptFlowRelation.getId().getCityId())
						&& !"-1".equals(deptFlowRelation.getId().getCityId())) {
					cityName = dimPubCity.getNameById(deptFlowRelation.getId().getCityId());
				} else {
					cityName = "--";
				}
				row.put("cityName", cityName);
				row.put("deptName", dimDeptId.getNameById(deptFlowRelation.getId().getDeptId()));
				row.put("approveFlowName", approveFlow.getNameById(deptFlowRelation.getId().getApproveFlowId()));
				String flowTypeName = null;
				if ("1".equals(deptFlowRelation.getId().getFlow_type())) {
					flowTypeName = "审批";
				} else if ("2".equals(deptFlowRelation.getId().getFlow_type())) {
					flowTypeName = "确认";
				} else {
					flowTypeName = "未知";
				}
				row.put("flowTypeName", flowTypeName);
				row.putAll(beanToMap(deptFlowRelation.getId()));
				rowsList.add(row);
			}
			result.put("rows", rowsList);
			result.remove("result");
		} catch (Exception e) {
			log.error("获取流程定义列表异常", e);
			result.put("total", 0);
			result.put("rows", "[]");
		}
		toJsonView(resp, result);
	}

	//删除流程定义
	@RequestMapping("delete")
	public void delete(String campDrvIds, String relationTypes, String flow_types, String approveFlowIds,
			String cityIds, String deptIds, HttpServletResponse resp) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			if (StringUtil.isNotEmpty(campDrvIds)) {
				String[] _campDrvIds = campDrvIds.split(",");
				String[] _relationTypes = relationTypes.split(",");
				String[] _flow_types = flow_types.split(",");
				String[] _approveFlowIds = approveFlowIds.split(",");
				String[] _cityIds = StringUtil.isNotEmpty(cityIds) ? cityIds.split(",")
						: new String[_campDrvIds.length];
				String[] _deptIds = StringUtil.isNotEmpty(deptIds) ? deptIds.split(",")
						: new String[_campDrvIds.length];
				for (int i = 0; i < _approveFlowIds.length; i++) {
					//service.deleteApproveFlowDef(approveFlowIds[i]);
					DimDeptFlowRelationId ddfr = new DimDeptFlowRelationId();
					ddfr.setCampDrvId(_campDrvIds[i]);
					ddfr.setRelationType(_relationTypes[i]);
					ddfr.setFlow_type(_flow_types[i]);
					ddfr.setApproveFlowId(_approveFlowIds[i]);
					if (i < _cityIds.length) {
						if (StringUtil.isNotEmpty(_cityIds[i])) {
							ddfr.setCityId(_cityIds[i]);
						} else {
							ddfr.setCityId("-1");
						}
					} else {
						ddfr.setCityId("-1");
					}
					if (i < _deptIds.length) {
						if (StringUtil.isNotEmpty(_deptIds[i])) {
							ddfr.setDeptId(_deptIds[i]);
						} else {
							ddfr.setDeptId("-1");
						}
					} else {
						ddfr.setDeptId("-1");
					}
					service.delete(ddfr);
				}
				result.put("errorMsg", "");
			} else {
				result.put("errorMsg", "没有要删除的数据！");
			}
		} catch (Exception e) {
			log.error("删除流程定义异常", e);
			result.put("errorMsg", e.getMessage());
		}
		toJsonView(resp, result);
	}

	//保存
	@RequestMapping("save")
	public void save(String relationType, String campDrvId, String cityId, String deptId, String flow_type,
			String approveFlowId, HttpServletResponse resp) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			//定义DimDeptFlowRelation
			DimDeptFlowRelation dimDeptFlowRelation = new DimDeptFlowRelation();
			DimDeptFlowRelationId id = new DimDeptFlowRelationId();
			String mo = "-1";
			//判断审批类型是否为空，如果为空插入-1
			if (null == relationType) {
				dimDeptFlowRelation.getId().setRelationType(mo);
			} else {
				id.setRelationType(relationType);
			}
			//判断驱动类型是否为空，如果为空插入-1，避免主键为空
			if (null == campDrvId) {
				id.setCampDrvId(mo);
			} else {
				id.setCampDrvId(campDrvId);
			}
			if (StringUtil.isEmpty(cityId)) {
				cityId = "-1";
			}
			if (StringUtil.isEmpty(deptId)) {
				deptId = "-1";
			}
			//判断渠道类型是否为空，如果为空插入-1，避免主键为空
			id.setCityId(cityId);
			id.setDeptId(deptId);
			id.setFlow_type(flow_type);
			dimDeptFlowRelation.setId(id);
			if (service.isObjectExist(id)) {
				result.put("errorMsg", "该流程已存在，请重新配置！");
			} else {
				id.setApproveFlowId(approveFlowId);
				//保存资源渠道确认流程对应关系信息
				service.save(dimDeptFlowRelation);
				result.put("errorMsg", "");
			}
		} catch (Exception e) {
			log.error("保存流程异常", e);
			result.put("errorMsg", e.getMessage());
		}
		toJsonView(resp, result);
	}

	//获取所有流程
	@SuppressWarnings("unchecked")
	@RequestMapping("getAllFlows")
	public void getAllFlows(HttpServletResponse resp) {
		List<LabelValueBean> list = new ArrayList<LabelValueBean>();
		try {
			list = (List<LabelValueBean>) approveService.getAllApproveFlowDefAsLabelValueBean();
		} catch (Exception e) {
			log.error("获取所有流程异常", e);
		}
		outJson(resp, JSONArray.fromObject(list).toString());
	}

	//获取所有流程类型
	@RequestMapping("getAllRelationTypes")
	public void getAllRelationTypes(HttpServletResponse resp) {
		List<LabelValueBean> list = new ArrayList<LabelValueBean>();
		try {
			@SuppressWarnings("unchecked")
			Map<String, Object> flowTypeMap = MpmCache.getInstance().getMapByType(MpmCONST.FOLW_TYPE);
			Set<Entry<String, Object>> sets = flowTypeMap.entrySet();
			for (Entry<String, Object> entry : sets) {
				LabelValueBean bean = new LabelValueBean();
				bean.setLabel(entry.getValue().toString());
				bean.setValue(entry.getKey());
				list.add(bean);
			}
		} catch (Exception e) {
			log.error("获取所有流程类型异常", e);
		}
		outJson(resp, JSONArray.fromObject(list).toString());
	}

	//获取城市列表
	@SuppressWarnings("unchecked")
	@RequestMapping("getCityList")
	public void getCityList(HttpServletRequest request, HttpServletResponse resp) {
		List<LabelValueBean> list = new ArrayList<LabelValueBean>();
		try {
			initAttributes(request);
			list = (List<LabelValueBean>) userPrivilegeService.getUserCityList(userId);
		} catch (Exception e) {
			log.error("获取城市列表异常", e);
		}
		outJson(resp, JSONArray.fromObject(list).toString());
	}

	//将javabean转为map类型，然后返回一个map类型的值
	public static Map<String, Object> beanToMap(Object obj) {
		Map<String, Object> params = new HashMap<String, Object>(0);
		try {
			PropertyUtilsBean propertyUtilsBean = new PropertyUtilsBean();
			PropertyDescriptor[] descriptors = propertyUtilsBean.getPropertyDescriptors(obj);
			for (int i = 0; i < descriptors.length; i++) {
				String name = descriptors[i].getName();
				if (!StringUtils.equals(name, "class")) {
					params.put(name, propertyUtilsBean.getNestedProperty(obj, name));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return params;
	}
}

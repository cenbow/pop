/*     */ package com.ai.bdx.frame.approval.controller;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;
/*     */ import com.ai.bdx.frame.approval.model.DimDeptFlowRelationId;
/*     */ import com.ai.bdx.frame.approval.service.IDimDeptFlowRelationService;
/*     */ import com.ai.bdx.frame.approval.service.IMpmCommonService;
/*     */ import com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService;
/*     */ import com.ai.bdx.frame.approval.util.DrvTypeUtil;
/*     */ import com.ai.bdx.frame.approval.util.MpmCache;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.service.IdNameMapper;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.sf.json.JSONArray;
/*     */ import org.apache.commons.beanutils.PropertyUtilsBean;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.annotation.Qualifier;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ 
/*     */ @Controller
/*     */ @RequestMapping({"/deptFlowRelation/*"})
/*     */ public class DeptFlowRelationController extends BaseController
/*     */ {
/*  47 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   @Autowired
/*     */   private IDimDeptFlowRelationService service;
/*     */ 
/*     */   @Autowired
/*     */   private IUserPrivilegeCommonService userPrivilegeService;
/*     */ 
/*     */   @Autowired
/*     */   IMpmCommonService commonService;
/*     */ 
/*     */   @Autowired
/*     */   @Qualifier("dimPubCity")
/*     */   IdNameMapper dimPubCity;
/*     */ 
/*     */   @Autowired
/*     */   @Qualifier("dimDeptId")
/*     */   IdNameMapper dimDeptId;
/*     */ 
/*     */   @Autowired
/*     */   @Qualifier("approveFlow")
/*     */   IdNameMapper approveFlow;
/*     */ 
/*     */   @Autowired
/*     */   IMtlApproveFlowDefService approveService;
/*     */ 
/*  78 */   @RequestMapping({"list"})
/*     */   public void list(String page, String rows, String campDrvId, String cityId, String relationType, String deptId, HttpServletRequest request, HttpServletResponse resp) { Map result = new HashMap();
/*     */     try {
/*  80 */       if (StringUtil.isEmpty(page)) {
/*  81 */         page = "1";
/*     */       }
/*  83 */       if (StringUtil.isEmpty(rows)) {
/*  84 */         rows = "10";
/*     */       }
/*  86 */       DimDeptFlowRelation dimDeptFlowRelation = new DimDeptFlowRelation();
/*  87 */       DimDeptFlowRelationId id = new DimDeptFlowRelationId();
/*  88 */       id.setCampDrvId(campDrvId);
/*  89 */       id.setCityId(cityId);
/*  90 */       id.setRelationType(relationType);
/*  91 */       id.setDeptId(deptId);
/*  92 */       dimDeptFlowRelation.setId(id);
/*     */ 
/*  94 */       result = this.service.findDeptFlowActions(dimDeptFlowRelation, Integer.valueOf(Integer.parseInt(page) - 1), Integer.valueOf(Integer.parseInt(rows)));
/*     */ 
/*  96 */       List list = (List)result.get("result");
/*  97 */       List rowsList = new ArrayList();
/*  98 */       List approveDrvDimTableList = this.commonService.getAllApproveDrvDimTable();
/*  99 */       Map approveDrvDimTableMap = new HashMap();
/* 100 */       if ((approveDrvDimTableList != null) && (approveDrvDimTableList.size() > 0)) {
/* 101 */         for (LabelValueBean b : approveDrvDimTableList) {
/* 102 */           approveDrvDimTableMap.put(b.getValue(), b.getLabel());
/*     */         }
/*     */       }
/* 105 */       DrvTypeUtil.init();
/* 106 */       for (DimDeptFlowRelation deptFlowRelation : list) {
/* 107 */         Map row = new HashMap();
/* 108 */         String drvType2 = "";
/* 109 */         String _relationType = deptFlowRelation.getId().getRelationType();
/* 110 */         if (_relationType != null)
/* 111 */           drvType2 = (String)approveDrvDimTableMap.get(_relationType);
/*     */         else {
/* 113 */           drvType2 = "--";
/*     */         }
/* 115 */         row.put("drvTypeClassify", drvType2);
/* 116 */         row.put("drvType", DrvTypeUtil.getVal(_relationType, deptFlowRelation.getId().getCampDrvId()));
/* 117 */         String cityName = null;
/* 118 */         if ((StringUtil.isNotEmpty(deptFlowRelation.getId().getCityId())) && (!"-1".equals(deptFlowRelation.getId().getCityId())))
/*     */         {
/* 120 */           cityName = this.dimPubCity.getNameById(deptFlowRelation.getId().getCityId());
/*     */         }
/* 122 */         else cityName = "--";
/*     */ 
/* 124 */         row.put("cityName", cityName);
/* 125 */         row.put("deptName", this.dimDeptId.getNameById(deptFlowRelation.getId().getDeptId()));
/* 126 */         row.put("approveFlowName", this.approveFlow.getNameById(deptFlowRelation.getId().getApproveFlowId()));
/* 127 */         String flowTypeName = null;
/* 128 */         if ("1".equals(deptFlowRelation.getId().getFlow_type()))
/* 129 */           flowTypeName = "审批";
/* 130 */         else if ("2".equals(deptFlowRelation.getId().getFlow_type()))
/* 131 */           flowTypeName = "确认";
/*     */         else {
/* 133 */           flowTypeName = "未知";
/*     */         }
/* 135 */         row.put("flowTypeName", flowTypeName);
/* 136 */         row.putAll(beanToMap(deptFlowRelation.getId()));
/* 137 */         rowsList.add(row);
/*     */       }
/* 139 */       result.put("rows", rowsList);
/* 140 */       result.remove("result");
/*     */     } catch (Exception e) {
/* 142 */       log.error("获取流程定义列表异常", e);
/* 143 */       result.put("total", Integer.valueOf(0));
/* 144 */       result.put("rows", "[]");
/*     */     }
/* 146 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"delete"})
/*     */   public void delete(String campDrvIds, String relationTypes, String flow_types, String approveFlowIds, String cityIds, String deptIds, HttpServletResponse resp)
/*     */   {
/* 153 */     Map result = new HashMap();
/*     */     try {
/* 155 */       if (StringUtil.isNotEmpty(campDrvIds)) {
/* 156 */         String[] _campDrvIds = campDrvIds.split(",");
/* 157 */         String[] _relationTypes = relationTypes.split(",");
/* 158 */         String[] _flow_types = flow_types.split(",");
/* 159 */         String[] _approveFlowIds = approveFlowIds.split(",");
/* 160 */         String[] _cityIds = StringUtil.isNotEmpty(cityIds) ? cityIds.split(",") : new String[_campDrvIds.length];
/*     */ 
/* 162 */         String[] _deptIds = StringUtil.isNotEmpty(deptIds) ? deptIds.split(",") : new String[_campDrvIds.length];
/*     */ 
/* 164 */         for (int i = 0; i < _approveFlowIds.length; i++)
/*     */         {
/* 166 */           DimDeptFlowRelationId ddfr = new DimDeptFlowRelationId();
/* 167 */           ddfr.setCampDrvId(_campDrvIds[i]);
/* 168 */           ddfr.setRelationType(_relationTypes[i]);
/* 169 */           ddfr.setFlow_type(_flow_types[i]);
/* 170 */           ddfr.setApproveFlowId(_approveFlowIds[i]);
/* 171 */           if (i < _cityIds.length) {
/* 172 */             if (StringUtil.isNotEmpty(_cityIds[i]))
/* 173 */               ddfr.setCityId(_cityIds[i]);
/*     */             else
/* 175 */               ddfr.setCityId("-1");
/*     */           }
/*     */           else {
/* 178 */             ddfr.setCityId("-1");
/*     */           }
/* 180 */           if (i < _deptIds.length) {
/* 181 */             if (StringUtil.isNotEmpty(_deptIds[i]))
/* 182 */               ddfr.setDeptId(_deptIds[i]);
/*     */             else
/* 184 */               ddfr.setDeptId("-1");
/*     */           }
/*     */           else {
/* 187 */             ddfr.setDeptId("-1");
/*     */           }
/* 189 */           this.service.delete(ddfr);
/*     */         }
/* 191 */         result.put("errorMsg", "");
/*     */       } else {
/* 193 */         result.put("errorMsg", "没有要删除的数据！");
/*     */       }
/*     */     } catch (Exception e) {
/* 196 */       log.error("删除流程定义异常", e);
/* 197 */       result.put("errorMsg", e.getMessage());
/*     */     }
/* 199 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"save"})
/*     */   public void save(String relationType, String campDrvId, String cityId, String deptId, String flow_type, String approveFlowId, HttpServletResponse resp)
/*     */   {
/* 206 */     Map result = new HashMap();
/*     */     try
/*     */     {
/* 209 */       DimDeptFlowRelation dimDeptFlowRelation = new DimDeptFlowRelation();
/* 210 */       DimDeptFlowRelationId id = new DimDeptFlowRelationId();
/* 211 */       String mo = "-1";
/*     */ 
/* 213 */       if (null == relationType)
/* 214 */         dimDeptFlowRelation.getId().setRelationType(mo);
/*     */       else {
/* 216 */         id.setRelationType(relationType);
/*     */       }
/*     */ 
/* 219 */       if (null == campDrvId)
/* 220 */         id.setCampDrvId(mo);
/*     */       else {
/* 222 */         id.setCampDrvId(campDrvId);
/*     */       }
/* 224 */       if (StringUtil.isEmpty(cityId)) {
/* 225 */         cityId = "-1";
/*     */       }
/* 227 */       if (StringUtil.isEmpty(deptId)) {
/* 228 */         deptId = "-1";
/*     */       }
/*     */ 
/* 231 */       id.setCityId(cityId);
/* 232 */       id.setDeptId(deptId);
/* 233 */       id.setFlow_type(flow_type);
/* 234 */       dimDeptFlowRelation.setId(id);
/* 235 */       if (this.service.isObjectExist(id)) {
/* 236 */         result.put("errorMsg", "该流程已存在，请重新配置！");
/*     */       } else {
/* 238 */         id.setApproveFlowId(approveFlowId);
/*     */ 
/* 240 */         this.service.save(dimDeptFlowRelation);
/* 241 */         result.put("errorMsg", "");
/*     */       }
/*     */     } catch (Exception e) {
/* 244 */       log.error("保存流程异常", e);
/* 245 */       result.put("errorMsg", e.getMessage());
/*     */     }
/* 247 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"getAllFlows"})
/*     */   public void getAllFlows(HttpServletResponse resp)
/*     */   {
/* 254 */     List list = new ArrayList();
/*     */     try {
/* 256 */       list = this.approveService.getAllApproveFlowDefAsLabelValueBean();
/*     */     } catch (Exception e) {
/* 258 */       log.error("获取所有流程异常", e);
/*     */     }
/* 260 */     outJson(resp, JSONArray.fromObject(list).toString());
/*     */   }
/*     */ 
/*     */   @RequestMapping({"getAllRelationTypes"})
/*     */   public void getAllRelationTypes(HttpServletResponse resp)
/*     */   {
/* 266 */     List list = new ArrayList();
/*     */     try
/*     */     {
/* 269 */       Map flowTypeMap = MpmCache.getInstance().getMapByType("dingyiliuchengleixing");
/* 270 */       Set sets = flowTypeMap.entrySet();
/* 271 */       for (Map.Entry entry : sets) {
/* 272 */         LabelValueBean bean = new LabelValueBean();
/* 273 */         bean.setLabel(entry.getValue().toString());
/* 274 */         bean.setValue((String)entry.getKey());
/* 275 */         list.add(bean);
/*     */       }
/*     */     } catch (Exception e) {
/* 278 */       log.error("获取所有流程类型异常", e);
/*     */     }
/* 280 */     outJson(resp, JSONArray.fromObject(list).toString());
/*     */   }
/*     */ 
/*     */   @RequestMapping({"getCityList"})
/*     */   public void getCityList(HttpServletRequest request, HttpServletResponse resp)
/*     */   {
/* 287 */     List list = new ArrayList();
/*     */     try {
/* 289 */       initAttributes(request);
/* 290 */       list = this.userPrivilegeService.getUserCityList(this.userId);
/*     */     } catch (Exception e) {
/* 292 */       log.error("获取城市列表异常", e);
/*     */     }
/* 294 */     outJson(resp, JSONArray.fromObject(list).toString());
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> beanToMap(Object obj)
/*     */   {
/* 299 */     Map params = new HashMap(0);
/*     */     try {
/* 301 */       PropertyUtilsBean propertyUtilsBean = new PropertyUtilsBean();
/* 302 */       PropertyDescriptor[] descriptors = propertyUtilsBean.getPropertyDescriptors(obj);
/* 303 */       for (int i = 0; i < descriptors.length; i++) {
/* 304 */         String name = descriptors[i].getName();
/* 305 */         if (!StringUtils.equals(name, "class"))
/* 306 */           params.put(name, propertyUtilsBean.getNestedProperty(obj, name));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 310 */       e.printStackTrace();
/*     */     }
/* 312 */     return params;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.controller.DeptFlowRelationController
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.model.DimCampDrvType;
import com.ai.bdx.frame.approval.service.IMpmCommonService;
import com.ai.bdx.frame.approval.service.IMpmSysActflowDefSvc;
import com.ai.bdx.frame.approval.util.DrvTypeUtil;
import com.ai.bdx.frame.approval.util.MpmCache;
import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
import com.asiainfo.biframe.utils.string.StringUtil;

/**
 * 驱动类型
 * @author lixiangqian
 *
 */
@Controller
@RequestMapping("/drvType/*")
public class DrvTypeController extends BaseController {
	private static Logger log = LogManager.getLogger();

	//驱动列表
	@SuppressWarnings("unchecked")
	@RequestMapping("list")
	public void list(String page, String rows, String drvTypeClassify, String drvType, HttpServletRequest request, HttpServletResponse resp) {
		//List<LabelValueBean> approveDrvDimTableList = new ArrayList<LabelValueBean>();
		IMpmCommonService commonService;
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("total", 0);
		result.put("rows", "[]");
		try {
			commonService = (IMpmCommonService) SystemServiceLocator.getInstance().getService(
					MpmCONST.COMMON_SERVICE_BEAN_ID);
			DimCampDrvType dab = new DimCampDrvType();
			if (StringUtil.isEmpty(page)) {
				page = DEFAULT_PAGE;
			}
			if (StringUtil.isEmpty(rows)) {
				rows = DEFAULT_RUMS;
			}
			dab.setTableID(drvTypeClassify);
			dab.setTableColVal(drvType);
			result = commonService.findCampDrvList(dab, Integer.parseInt(page) - 1, Integer.parseInt(rows));
			List<DimCampDrvType> list = (List<DimCampDrvType>) result.get("result");
			List<Map<String, Object>> rowsList = new ArrayList<Map<String, Object>>();
			List<LabelValueBean> approveDrvDimTableList = commonService.getAllApproveDrvDimTable();
			Map<String, String> approveDrvDimTableMap = new HashMap<String, String>();
			if (approveDrvDimTableList != null && approveDrvDimTableList.size() > 0) {
				for (LabelValueBean b : approveDrvDimTableList) {
					approveDrvDimTableMap.put(b.getValue(), b.getLabel());
				}
			}
			DrvTypeUtil.init();
			for (DimCampDrvType dimCampDrvType : list) {
				Map<String, Object> row = new HashMap<String, Object>();
				row.put("campDrvId", dimCampDrvType.getCampDrvId());
				String tableID = dimCampDrvType.getTableID();
				String drvType2 = "";
				if (tableID != null) {
					drvType2 = approveDrvDimTableMap.get(tableID);
				} else {
					drvType2 = "--";
				}
				row.put("drvTypeClassify", drvType2);
				row.put("drvType", DrvTypeUtil.getVal(dimCampDrvType.getTableID(),dimCampDrvType.getTableColVal()));
				row.put("flowModel", MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_MTL_SYSACT_FLOW, String.valueOf(dimCampDrvType.getFlowId())));
				row.put("drvDisabled", MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_USER_HANDLE_FLAG, String.valueOf(dimCampDrvType.getDrvDesabled())));
				row.put("campDrvDesc", dimCampDrvType.getCampDrvDesc());
				row.put("tableID", dimCampDrvType.getTableID());
				row.put("tableColVal", dimCampDrvType.getTableColVal());
				row.put("drvDesabled", dimCampDrvType.getDrvDesabled());
				row.put("flowId", dimCampDrvType.getFlowId());
				rowsList.add(row);
			}
			result.put("rows", rowsList);
			result.remove("result");
		} catch (Exception e) {
			log.error("获取驱动类型列表异常", e);
		}
		toJsonView(resp, result);
	}
	
	//获取驱动类型分类
	@RequestMapping("getDrvTypeClassifys")
	public void getDrvTypeClassifys(HttpServletResponse resp){
		List<LabelValueBean> approveDrvDimTableList = new ArrayList<LabelValueBean>();
		LabelValueBean label = new LabelValueBean();
		label.setLabel("全部");
		label.setValue("-1");
		approveDrvDimTableList.add(label);
		try {
			IMpmCommonService commonService = (IMpmCommonService) SystemServiceLocator.getInstance().getService(MpmCONST.COMMON_SERVICE_BEAN_ID);
			approveDrvDimTableList.addAll(commonService.getAllApproveDrvDimTable());
		} catch (Exception e) {
			log.error("获取驱动类型分类异常", e);
		}
		outJson(resp, JSONArray.fromObject(approveDrvDimTableList).toString());
	}
	
	//根据驱动类型分类查询驱动类型
	@RequestMapping("getDrvTypes")
	public void getDrvTypes(String drvTypeClassifyId, HttpServletResponse resp){
		JSONArray arr = new JSONArray();
		JSONObject json = new JSONObject();
		json.put("code", "-1");
		json.put("val", "全部");
		arr.add(json);
		try {
			IMpmCommonService commonService = (IMpmCommonService) SystemServiceLocator.getInstance().getService(MpmCONST.COMMON_SERVICE_BEAN_ID);
			String approveDrvDimTableList = commonService.getAllApproveDrvDimTableConByid(drvTypeClassifyId);
			JSONArray arr2 = JSONArray.fromObject(approveDrvDimTableList);
			arr.addAll(arr2);
		} catch (Exception e) {
			log.error("获取驱动类型分类异常", e);
		}
		outJson(resp, arr.toString());
	}
	
	//查询所有流程模式
	@RequestMapping("getFLowModels")
	public void getFLowModels(HttpServletResponse resp){
		List<LabelValueBean> fLowModels = new ArrayList<LabelValueBean>();
		try {
			IMpmSysActflowDefSvc service = (IMpmSysActflowDefSvc) SystemServiceLocator.getInstance().getService(MpmCONST.SYS_ACTFLOWDEF_SERVICE_BEAN_ID);
			@SuppressWarnings("unchecked")
			List<LabelValueBean> sysActFlowList = (List<LabelValueBean>)service.getCampSysActFlowDefList();
			fLowModels.addAll(sysActFlowList);
		} catch (Exception e) {
			log.error("获取驱动类型分类异常", e);
		}
		outJson(resp, JSONArray.fromObject(fLowModels).toString());
	}
	
	//保存渠道类型
	@RequestMapping("saveDrvType")
	public void saveDrvType(String campDrvId, String tableID, String tableColVal, String flowId, String drvDesabled, String campDrvDesc, HttpServletResponse resp){
		Map<String, String> result = new HashMap<String, String>();
		try {
			//MpmCommonService.isDrvExist(theForm.tableID.value,theForm.tableColVal.value,theForm.flowId.value,theForm.campDrvId.value,{callback:function(data){nameExist = data;},async:false});
			IMpmCommonService commonService = (IMpmCommonService) SystemServiceLocator.getInstance().getService(MpmCONST.COMMON_SERVICE_BEAN_ID);
			boolean isDrvExist = commonService.isDrvExist(tableID, tableColVal, flowId, campDrvId);
			if(isDrvExist){
				result.put("errorMsg", "已经存在或者每个驱动只能配置一个流程模式,请重新配置后再保存！");
			}else{
				DimCampDrvType dcdt = new DimCampDrvType();
				dcdt.setTableID(tableID);
				dcdt.setTableColVal(tableColVal);
				dcdt.setFlowId(flowId);
				dcdt.setDrvDesabled(Short.valueOf(drvDesabled));
				dcdt.setCampDrvDesc(campDrvDesc);
				if(StringUtil.isNotEmpty(campDrvId)){
					dcdt.setCampDrvId(Short.valueOf(campDrvId));
				}else{
					int maxCampDrvId=commonService.getMaxCampDrvId();
					if(maxCampDrvId == -2 || maxCampDrvId == -1){ //不能等于-1和0；跳过；
						maxCampDrvId = 0;
					}
					dcdt.setCampDrvId(Short.valueOf(String.valueOf((maxCampDrvId + 1))));
				}
				commonService.saveCampDrvType(dcdt);
				result.put("errorMsg", "");
			}
		} catch (Exception e) {
			log.error("保存渠道类型异常", e);
			result.put("errorMsg", e.getMessage());
		}
		toJsonView(resp, result);
	}
	
	//检查已经存在或者每个驱动只能配置一个流程模式
	@RequestMapping("checkDrvExist")
	public void checkDrvExist(String campDrvId, String tableID, String tableColVal, String flowId, String drvDisabled, String campDrvDesc, HttpServletResponse resp){
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			IMpmCommonService commonService = (IMpmCommonService) SystemServiceLocator.getInstance().getService(MpmCONST.COMMON_SERVICE_BEAN_ID);
			boolean isDrvExist = commonService.isDrvExist(tableID, tableColVal, flowId, campDrvId);
			if(isDrvExist){
				result.put("flag", true);
			}else{
				result.put("flag", false);
			}
		} catch (Exception e) {
			log.error("保存渠道类型异常", e);
			result.put("errorMsg", e.getMessage());
		}
		toJsonView(resp, result);
	}
}

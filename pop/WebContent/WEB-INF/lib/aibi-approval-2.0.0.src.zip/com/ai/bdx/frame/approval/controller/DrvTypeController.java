/*     */ package com.ai.bdx.frame.approval.controller;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.model.DimCampDrvType;
/*     */ import com.ai.bdx.frame.approval.service.IMpmCommonService;
/*     */ import com.ai.bdx.frame.approval.service.IMpmSysActflowDefSvc;
/*     */ import com.ai.bdx.frame.approval.util.DrvTypeUtil;
/*     */ import com.ai.bdx.frame.approval.util.MpmCache;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ 
/*     */ @Controller
/*     */ @RequestMapping({"/drvType/*"})
/*     */ public class DrvTypeController extends BaseController
/*     */ {
/*  37 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   @RequestMapping({"list"})
/*     */   public void list(String page, String rows, String drvTypeClassify, String drvType, HttpServletRequest request, HttpServletResponse resp)
/*     */   {
/*  45 */     Map result = new HashMap();
/*  46 */     result.put("total", Integer.valueOf(0));
/*  47 */     result.put("rows", "[]");
/*     */     try {
/*  49 */       IMpmCommonService commonService = (IMpmCommonService)SystemServiceLocator.getInstance().getService("commonService");
/*     */ 
/*  51 */       DimCampDrvType dab = new DimCampDrvType();
/*  52 */       if (StringUtil.isEmpty(page)) {
/*  53 */         page = "1";
/*     */       }
/*  55 */       if (StringUtil.isEmpty(rows)) {
/*  56 */         rows = "10";
/*     */       }
/*  58 */       dab.setTableID(drvTypeClassify);
/*  59 */       dab.setTableColVal(drvType);
/*  60 */       result = commonService.findCampDrvList(dab, Integer.valueOf(Integer.parseInt(page) - 1), Integer.valueOf(Integer.parseInt(rows)));
/*  61 */       List list = (List)result.get("result");
/*  62 */       List rowsList = new ArrayList();
/*  63 */       List approveDrvDimTableList = commonService.getAllApproveDrvDimTable();
/*  64 */       Map approveDrvDimTableMap = new HashMap();
/*  65 */       if ((approveDrvDimTableList != null) && (approveDrvDimTableList.size() > 0)) {
/*  66 */         for (LabelValueBean b : approveDrvDimTableList) {
/*  67 */           approveDrvDimTableMap.put(b.getValue(), b.getLabel());
/*     */         }
/*     */       }
/*  70 */       DrvTypeUtil.init();
/*  71 */       for (DimCampDrvType dimCampDrvType : list) {
/*  72 */         Map row = new HashMap();
/*  73 */         row.put("campDrvId", dimCampDrvType.getCampDrvId());
/*  74 */         String tableID = dimCampDrvType.getTableID();
/*  75 */         String drvType2 = "";
/*  76 */         if (tableID != null)
/*  77 */           drvType2 = (String)approveDrvDimTableMap.get(tableID);
/*     */         else {
/*  79 */           drvType2 = "--";
/*     */         }
/*  81 */         row.put("drvTypeClassify", drvType2);
/*  82 */         row.put("drvType", DrvTypeUtil.getVal(dimCampDrvType.getTableID(), dimCampDrvType.getTableColVal()));
/*  83 */         row.put("flowModel", MpmCache.getInstance().getNameByKeyFromDic("dimActflow", String.valueOf(dimCampDrvType.getFlowId())));
/*  84 */         row.put("drvDisabled", MpmCache.getInstance().getNameByTypeAndKey("user_handle_flag", String.valueOf(dimCampDrvType.getDrvDesabled())));
/*  85 */         row.put("campDrvDesc", dimCampDrvType.getCampDrvDesc());
/*  86 */         row.put("tableID", dimCampDrvType.getTableID());
/*  87 */         row.put("tableColVal", dimCampDrvType.getTableColVal());
/*  88 */         row.put("drvDesabled", dimCampDrvType.getDrvDesabled());
/*  89 */         row.put("flowId", dimCampDrvType.getFlowId());
/*  90 */         rowsList.add(row);
/*     */       }
/*  92 */       result.put("rows", rowsList);
/*  93 */       result.remove("result");
/*     */     } catch (Exception e) {
/*  95 */       log.error("获取驱动类型列表异常", e);
/*     */     }
/*  97 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"getDrvTypeClassifys"})
/*     */   public void getDrvTypeClassifys(HttpServletResponse resp)
/*     */   {
/* 103 */     List approveDrvDimTableList = new ArrayList();
/* 104 */     LabelValueBean label = new LabelValueBean();
/* 105 */     label.setLabel("全部");
/* 106 */     label.setValue("-1");
/* 107 */     approveDrvDimTableList.add(label);
/*     */     try {
/* 109 */       IMpmCommonService commonService = (IMpmCommonService)SystemServiceLocator.getInstance().getService("commonService");
/* 110 */       approveDrvDimTableList.addAll(commonService.getAllApproveDrvDimTable());
/*     */     } catch (Exception e) {
/* 112 */       log.error("获取驱动类型分类异常", e);
/*     */     }
/* 114 */     outJson(resp, JSONArray.fromObject(approveDrvDimTableList).toString());
/*     */   }
/*     */ 
/*     */   @RequestMapping({"getDrvTypes"})
/*     */   public void getDrvTypes(String drvTypeClassifyId, HttpServletResponse resp)
/*     */   {
/* 120 */     JSONArray arr = new JSONArray();
/* 121 */     JSONObject json = new JSONObject();
/* 122 */     json.put("code", "-1");
/* 123 */     json.put("val", "全部");
/* 124 */     arr.add(json);
/*     */     try {
/* 126 */       IMpmCommonService commonService = (IMpmCommonService)SystemServiceLocator.getInstance().getService("commonService");
/* 127 */       String approveDrvDimTableList = commonService.getAllApproveDrvDimTableConByid(drvTypeClassifyId);
/* 128 */       JSONArray arr2 = JSONArray.fromObject(approveDrvDimTableList);
/* 129 */       arr.addAll(arr2);
/*     */     } catch (Exception e) {
/* 131 */       log.error("获取驱动类型分类异常", e);
/*     */     }
/* 133 */     outJson(resp, arr.toString());
/*     */   }
/*     */ 
/*     */   @RequestMapping({"getFLowModels"})
/*     */   public void getFLowModels(HttpServletResponse resp)
/*     */   {
/* 139 */     List fLowModels = new ArrayList();
/*     */     try {
/* 141 */       IMpmSysActflowDefSvc service = (IMpmSysActflowDefSvc)SystemServiceLocator.getInstance().getService("mpmSysActFlowDefService");
/*     */ 
/* 143 */       List sysActFlowList = service.getCampSysActFlowDefList();
/* 144 */       fLowModels.addAll(sysActFlowList);
/*     */     } catch (Exception e) {
/* 146 */       log.error("获取驱动类型分类异常", e);
/*     */     }
/* 148 */     outJson(resp, JSONArray.fromObject(fLowModels).toString());
/*     */   }
/*     */ 
/*     */   @RequestMapping({"saveDrvType"})
/*     */   public void saveDrvType(String campDrvId, String tableID, String tableColVal, String flowId, String drvDesabled, String campDrvDesc, HttpServletResponse resp)
/*     */   {
/* 154 */     Map result = new HashMap();
/*     */     try
/*     */     {
/* 157 */       IMpmCommonService commonService = (IMpmCommonService)SystemServiceLocator.getInstance().getService("commonService");
/* 158 */       boolean isDrvExist = commonService.isDrvExist(tableID, tableColVal, flowId, campDrvId);
/* 159 */       if (isDrvExist) {
/* 160 */         result.put("errorMsg", "已经存在或者每个驱动只能配置一个流程模式,请重新配置后再保存！");
/*     */       } else {
/* 162 */         DimCampDrvType dcdt = new DimCampDrvType();
/* 163 */         dcdt.setTableID(tableID);
/* 164 */         dcdt.setTableColVal(tableColVal);
/* 165 */         dcdt.setFlowId(flowId);
/* 166 */         dcdt.setDrvDesabled(Short.valueOf(drvDesabled));
/* 167 */         dcdt.setCampDrvDesc(campDrvDesc);
/* 168 */         if (StringUtil.isNotEmpty(campDrvId)) {
/* 169 */           dcdt.setCampDrvId(Short.valueOf(campDrvId));
/*     */         } else {
/* 171 */           int maxCampDrvId = commonService.getMaxCampDrvId().shortValue();
/* 172 */           if ((maxCampDrvId == -2) || (maxCampDrvId == -1)) {
/* 173 */             maxCampDrvId = 0;
/*     */           }
/* 175 */           dcdt.setCampDrvId(Short.valueOf(String.valueOf(maxCampDrvId + 1)));
/*     */         }
/* 177 */         commonService.saveCampDrvType(dcdt);
/* 178 */         result.put("errorMsg", "");
/*     */       }
/*     */     } catch (Exception e) {
/* 181 */       log.error("保存渠道类型异常", e);
/* 182 */       result.put("errorMsg", e.getMessage());
/*     */     }
/* 184 */     toJsonView(resp, result);
/*     */   }
/*     */ 
/*     */   @RequestMapping({"checkDrvExist"})
/*     */   public void checkDrvExist(String campDrvId, String tableID, String tableColVal, String flowId, String drvDisabled, String campDrvDesc, HttpServletResponse resp)
/*     */   {
/* 190 */     Map result = new HashMap();
/*     */     try {
/* 192 */       IMpmCommonService commonService = (IMpmCommonService)SystemServiceLocator.getInstance().getService("commonService");
/* 193 */       boolean isDrvExist = commonService.isDrvExist(tableID, tableColVal, flowId, campDrvId);
/* 194 */       if (isDrvExist)
/* 195 */         result.put("flag", Boolean.valueOf(true));
/*     */       else
/* 197 */         result.put("flag", Boolean.valueOf(false));
/*     */     }
/*     */     catch (Exception e) {
/* 200 */       log.error("保存渠道类型异常", e);
/* 201 */       result.put("errorMsg", e.getMessage());
/*     */     }
/* 203 */     toJsonView(resp, result);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.controller.DrvTypeController
 * JD-Core Version:    0.6.2
 */
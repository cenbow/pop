package com.ai.bdx.frame.approval.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/index/*")
public class IndexController {
	private static Logger log = LogManager.getLogger();
	
	@RequestMapping("welcome")
	public String welcome(ModelMap model, String userName, HttpServletRequest req) {
		log.info("username:"+req.getParameter("userName"));
		model.addAttribute("message", "你好，世界");
		return "demo";
	}
}
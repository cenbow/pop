package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.bean.ApApproveList;
import com.ai.bdx.frame.approval.bean.ApproveLevelDef;
import com.ai.bdx.frame.approval.bean.ApproveRelation;
import java.util.List;
import java.util.Map;

public abstract interface ApprovalDao
{
  public abstract List<?> getObjectsBySQL(String paramString, Map<String, Object> paramMap)
    throws Exception;

  public abstract List<?> getObjectsByHQL(String paramString, Map<String, Object> paramMap)
    throws Exception;

  public abstract int executeBySQL(String paramString, Map<String, Object> paramMap)
    throws Exception;

  public abstract int saveApprovalList(String paramString, List<ApApproveList> paramList)
    throws Exception;

  public abstract List<ApproveLevelDef> getApprovalListByFlowId(String paramString)
    throws Exception;

  public abstract ApproveRelation findByUserDeptId(String paramString1, String paramString2)
    throws Exception;

  public abstract int saveApApproveList(ApApproveList paramApApproveList)
    throws Exception;

  public abstract List getApproveTriggerCondDefByFlowAndLevel(String paramString, Integer paramInteger)
    throws Exception;

  public abstract List<ApApproveList> getApprovalProcess(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract int updateApprovalToken(String paramString1, String paramString2, Integer paramInteger1, Integer paramInteger2, String paramString3, Integer paramInteger3, String paramString4)
    throws Exception;

  public abstract List<ApApproveList> getNextApprovalProcess(ApApproveList paramApApproveList)
    throws Exception;

  public abstract int updateApprovalFlag(String paramString1, String paramString2, String paramString3, Integer paramInteger1, String paramString4, Integer paramInteger2, String paramString5)
    throws Exception;

  public abstract Integer getMaxApprovalSeq(String paramString1, String paramString2)
    throws Exception;

  public abstract String getApproveDrvType(String paramString1, String paramString2)
    throws Exception;

  public abstract List<ApApproveList> getFirstApprovalOrConfimUser(String paramString1, String paramString2)
    throws Exception;

  public abstract List<?> getSampleLevelApproverByCurrentApproval(ApApproveList paramApApproveList)
    throws Exception;

  public abstract List<String> getCurrentApproversByApprovalID(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.ApprovalDao
 * JD-Core Version:    0.6.2
 */
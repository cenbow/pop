package com.ai.bdx.frame.approval.dao;

import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.bean.ApApproveList;
import com.ai.bdx.frame.approval.bean.ApproveLevelDef;
import com.ai.bdx.frame.approval.bean.ApproveRelation;

public interface ApprovalDao {

	/**
	 * 
	 * getObjectsBySQL:根据sql查询对象列表
	 * @param sql
	 * @param params
	 * @return
	 * @throws PopException 
	 * @return List<?>
	 */
	public List<?> getObjectsBySQL(String sql,Map<String, Object> params) throws Exception;
	/**
	 * 
	 * getObjectsByHQL:根据hql查询对象列表
	 * @param hql
	 * @param params
	 * @return
	 * @throws PopException 
	 * @return List<?>
	 */
	public List<?> getObjectsByHQL(String hql,Map<String,Object> params) throws Exception;
     /**
      * 
      * executeBySQL:执行sql
      * @param sql
      * @param params
      * @return
      * @throws PopException 
      * @return int
      */
	public int executeBySQL(String sql,Map<String,Object> params) throws Exception;
	/**
	 * 
	 * saveApprovalList:保存列表
	 * @param sql
	 * @param list
	 * @return
	 * @throws PopException 
	 * @return int
	 */
	public int saveApprovalList(String sql,List<ApApproveList> list) throws Exception;
	
	/**
	 * 
	 * getApprovalListByFlowId:根据流程ID获取所有审批级别
	 * @param flowId
	 * @return
	 * @throws PopException 
	 * @return List<?>
	 */
	public List<ApproveLevelDef> getApprovalListByFlowId(String flowId)throws Exception;
	/**
	 * 
	 * findByUserDeptId:根据user或者dept查询部门用户关系
	 * @param deptId
	 * @param approveUserid
	 * @return 
	 * @return ApproveRelation
	 */
	public ApproveRelation findByUserDeptId(String deptId,  String approveUserid) throws Exception;
	/**
	 * 
	 * saveApApproveList:保存ApApproveList
	 * @param campSegApprover 
	 * @return void
	 */
	public int saveApApproveList(ApApproveList campSegApprover)throws Exception;
	/**
	 * 
	 * getApproveTriggerCondDefByFlowAndLevel:取审批级别中定义的触发条件对应的审批人
	 * @param approvalFlowId
	 * @param approve_level
	 * @return 
	 * @return List
	 */
	public List getApproveTriggerCondDefByFlowAndLevel(String approvalFlowId,
			Integer approve_level)throws Exception;
	/**
	 * 获取审批进程
	 * @param approvalId
	 * @param approvalType
	 * @return
	 */
	public List<ApApproveList> getApprovalProcess(String approvalId, String approvalType,String approvalToken)throws Exception;
	/**
	 * 更新审批确认令牌持有人
	 * @param approvalId
	 * @param approvalType
	 * @param approvalTokenFalse
	 */
	public int updateApprovalToken(String approvalId, String approvalType,
			Integer approvalToken,Integer currentApprovalSeq,String approve_flow_id,Integer approve_level,String approve_userid)throws Exception;
	
	/**
	 * 
	 * getNextApprovalProcess:根据当前审批节点查询下级审批所有人
	 * @param ap 当前审批节点
	 * @return 
	 * @return ApApproveList
	 */
	public List<ApApproveList> getNextApprovalProcess(ApApproveList ap)throws Exception;
	
	/**
	 * 更新审批确认标示
	 * @param approvalId
	 * @param approvalType
	 * @param approve_flag
	 * @param currentApprovalSeq
	 * @param approve_flow_id
	 * @param approve_level
	 * @param approve_userid
	 * @return
	 */
	public int updateApprovalFlag(String approvalId, String approvalType,
			String approve_flag,Integer currentApprovalSeq,String approve_flow_id,Integer approve_level,String approve_userid) throws Exception;
	/**
	 * 获取当前审批过程最大序号
	 * @param approvalId
	 * @param approvalType
	 * @return
	 */
	public Integer getMaxApprovalSeq(String approvalId, String approvalType) throws Exception;
	/**
	 * 根据驱动类型分类和驱动类型查询流程模式
	 * @param drvTypeID
	 * @param drvID
	 * @return
	 */
	public String getApproveDrvType(String drvTypeID, String drvID) throws Exception;
	/**
	 * 查询出第一审批人或者确认人
	 * @param approvalId
	 * @param flowTypeApprovl
	 */
	public List<ApApproveList> getFirstApprovalOrConfimUser(String approvalId,
			String flowTypeApprovl) throws Exception;
	/**
	 * 
	 * getSampleLevelApproverByCurrentApproval:根据同级别审批人查找在同级别是否还有审批人
	 * @param currentApproval
	 * @return 
	 * @return List<?>
	 */
	public List<?> getSampleLevelApproverByCurrentApproval(
			ApApproveList currentApproval) throws Exception;
	/**
	 * 
	 * getCurrentApproversByApprovalID:根据审批对象ID查询所有当前审批人
	 * @param approvalID
	 * @return
	 * @throws Exception 
	 * @return List<String>
	 */
	public List<String> getCurrentApproversByApprovalID(String approvalID) throws Exception;
	
}

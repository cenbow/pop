package com.ai.bdx.frame.approval.dao;

import java.util.List;
import java.util.Map;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.DimCampDrvType;
import com.ai.bdx.frame.approval.model.MtlPlanExecType;
import com.ai.bdx.frame.approval.model.DimDrvRoleManager;

/*
 * Created on 9:58:03 AM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IDimCampDrvTypeDao {

	/**
	 * 获取所有的驱动类型列表
	 * @return list
	 * @throws Exception
	 */
	public List getAllDrvType() throws Exception;

	/**
	 * 通过驱动类型标识获取驱动类型对象
	 * @param drvTypeId
	 * @return 驱动类型对象
	 * @throws Exception
	 */
	public DimCampDrvType getDrvType(Short drvTypeId) throws Exception;

	/**
	 * 通过类型获取驱动类型列表
	 * @param type
	 * @return 驱动呢类型列表集合
	 * @throws Exception
	 */
	public List getCampDrvTypeListByType(final String type) throws Exception;

	/**
	 * 获取父类直接子节点驱动类型列表
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public List getSubCampDrvTypeList(final String type) throws Exception;

	/**
	 * 得到所有未禁用的驱动类型列表；
	 * @return
	 * @throws Exception
	 */
	public Object[] getAllDrvTypesEnabled() throws Exception;

	/**
	 * 通过角色取所有活动驱动类型信息（List形式）
	 * @return 带活动驱动类型信息的DimCampDrvType List
	 * @throws MpmException
	 */
	public DimDrvRoleManager  getAllCampDrvTypeByRoleId(Short campDrvId,String roleId,Short roleFlag) throws MpmException;

	/**
	 * 判断用户是否拥有该活动类型的权限
	 * @param campDrvId
	 * @param roleId
	 * @param groupId
	 * @return
	 * @throws MpmException
	 */
	public boolean getUserDrvAuth(Short campDrvId,String userId,String groupId) throws MpmException;

	/**
	 * 取营销场景模板
	 * @param campDrvId
	 * @return
	 * @throws MpmException
	 */
	public List getScenesBycampDrvId(String campDrvId) throws MpmException;

	/**
	 * 取营销场景元素List
	 * @param ScenesId 场景ID
	 * @return
	 * @throws MpmException
	 */
	public List getScenesElementsMap(String scenesId) throws MpmException;

	/**
	 * 查询活动类型
	 * @param drvinfo
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws Exception
	 */
	public Map findCampDrvList(DimCampDrvType drvinfo, final Integer curPage, final Integer pageSize) throws Exception;

	/**
	 * 查找所有的执行计划
	 * @param planExecTypeId
	 * @return
	 * @throws MpmException
	 */
	public List getPlanExecTypeMap(MtlPlanExecType mpet) throws MpmException;

	/**
	 * 保存或更新活动类型
	 * @param dcdt
	 * @throws MpmException
	 */
	public void save(DimCampDrvType dcdt) throws MpmException;

	/**
	 * 获取最新的活动类型编号
	 * @return
	 * @throws Exception
	 */
	public Short getMaxCampDrvId() throws Exception;

	/**
	 *
	 * @param planExecId
	 * @return
	 * @throws MpmException
	 */
	public List findPlanExecAll() throws MpmException ;

	/**
	 *
	 * @param planExecId
	 * @return
	 * @throws MpmException
	 */
	public MtlPlanExecType getPlanExecById(String  planExecId) throws MpmException;

	/**
	 * 根据场景ID获取场景对象
	 * @param scenesId
	 * @return
	 */
	//public MtlScenesTemplet getScenesTemplet(String scenesId);
}

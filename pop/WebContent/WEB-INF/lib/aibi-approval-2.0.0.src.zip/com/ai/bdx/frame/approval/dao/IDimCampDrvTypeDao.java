package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.DimCampDrvType;
import com.ai.bdx.frame.approval.model.DimDrvRoleManager;
import com.ai.bdx.frame.approval.model.MtlPlanExecType;
import java.util.List;
import java.util.Map;

public abstract interface IDimCampDrvTypeDao
{
  public abstract List getAllDrvType()
    throws Exception;

  public abstract DimCampDrvType getDrvType(Short paramShort)
    throws Exception;

  public abstract List getCampDrvTypeListByType(String paramString)
    throws Exception;

  public abstract List getSubCampDrvTypeList(String paramString)
    throws Exception;

  public abstract Object[] getAllDrvTypesEnabled()
    throws Exception;

  public abstract DimDrvRoleManager getAllCampDrvTypeByRoleId(Short paramShort1, String paramString, Short paramShort2)
    throws MpmException;

  public abstract boolean getUserDrvAuth(Short paramShort, String paramString1, String paramString2)
    throws MpmException;

  public abstract List getScenesBycampDrvId(String paramString)
    throws MpmException;

  public abstract List getScenesElementsMap(String paramString)
    throws MpmException;

  public abstract Map findCampDrvList(DimCampDrvType paramDimCampDrvType, Integer paramInteger1, Integer paramInteger2)
    throws Exception;

  public abstract List getPlanExecTypeMap(MtlPlanExecType paramMtlPlanExecType)
    throws MpmException;

  public abstract void save(DimCampDrvType paramDimCampDrvType)
    throws MpmException;

  public abstract Short getMaxCampDrvId()
    throws Exception;

  public abstract List findPlanExecAll()
    throws MpmException;

  public abstract MtlPlanExecType getPlanExecById(String paramString)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao
 * JD-Core Version:    0.6.2
 */
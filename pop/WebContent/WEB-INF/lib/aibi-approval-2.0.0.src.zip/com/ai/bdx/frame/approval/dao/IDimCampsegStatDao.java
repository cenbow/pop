package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.DimCampsegStat;
import java.util.List;

public abstract interface IDimCampsegStatDao
{
  public abstract DimCampsegStat getCampsegStat(Short paramShort)
    throws Exception;

  public abstract List<?> getAllCampsegStat()
    throws Exception;

  public abstract List<?> getAllCampsegStatVisible()
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IDimCampsegStatDao
 * JD-Core Version:    0.6.2
 */
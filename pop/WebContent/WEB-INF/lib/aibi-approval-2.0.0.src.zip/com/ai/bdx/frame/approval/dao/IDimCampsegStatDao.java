package com.ai.bdx.frame.approval.dao;

import java.util.List;

import com.ai.bdx.frame.approval.model.DimCampsegStat;

public interface IDimCampsegStatDao {

	public DimCampsegStat getCampsegStat(Short campsegStatId) throws Exception;

	public List<?> getAllCampsegStat() throws Exception;

	/**
	 * 得到所有可见的活动状态 by chengxc
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<?> getAllCampsegStatVisible() throws Exception;

}

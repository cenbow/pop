package com.ai.bdx.frame.approval.dao;


import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimChannelUserRelationForm;
import com.ai.bdx.frame.approval.model.DimChannelUserRelation;

/**
 * 
 * Created on 2008-3-7
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author qixf
 * @version 1.0
 */
public interface IDimChannelUserRelationDao {
	/**
	 * 查询资源渠道确认人对应信息
	 * @param resourceId
	 * @param userId
	 * @param confirmType
	 * @return
	 * @throws Exception
	 */
	public DimChannelUserRelation getChannelTypeId(Integer resourceId, String userId, Short confirmType) throws Exception;

	/**
	 * 查询资源渠道确认人对应信息
	 * @param channelType
	 * @param channelId
	 * @param confirmType
	 * @return
	 * @throws Exception
	 */
	public DimChannelUserRelation getChannelTypeId(Short channelType, String channelId, int confirmType) throws Exception;

	/**
	 * 查询所有资源渠道确认人对应信息
	 * @return
	 * @throws Exception
	 */
	public List getAllChannelType() throws Exception;

	/**
	 * 查询资源渠道确认人对应信息
	 * @param searchForm
	 * @return
	 * @throws MpmException
	 */
	public Map searchChannelUserRelation(DimChannelUserRelationForm searchForm, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 保存资源渠道确认人对应信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void save(DimChannelUserRelation dimChannelUserRelation) throws MpmException;

	/**
	 * 删除资源渠道确认人对应信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void delete(DimChannelUserRelationForm searchForm) throws MpmException;

	/**
	 * 更新旧的确认人为新的确认人
	 * @param userid
	 * @param newUserid
	 * @param authFlag
	 * @throws Exception
	 */
	public void updateUserId(String userid, String newUserid, int authFlag) throws Exception;
}

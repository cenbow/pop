package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimChannelUserRelationForm;
import com.ai.bdx.frame.approval.model.DimChannelUserRelation;
import java.util.List;
import java.util.Map;

public abstract interface IDimChannelUserRelationDao
{
  public abstract DimChannelUserRelation getChannelTypeId(Integer paramInteger, String paramString, Short paramShort)
    throws Exception;

  public abstract DimChannelUserRelation getChannelTypeId(Short paramShort, String paramString, int paramInt)
    throws Exception;

  public abstract List getAllChannelType()
    throws Exception;

  public abstract Map searchChannelUserRelation(DimChannelUserRelationForm paramDimChannelUserRelationForm, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void save(DimChannelUserRelation paramDimChannelUserRelation)
    throws MpmException;

  public abstract void delete(DimChannelUserRelationForm paramDimChannelUserRelationForm)
    throws MpmException;

  public abstract void updateUserId(String paramString1, String paramString2, int paramInt)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao
 * JD-Core Version:    0.6.2
 */
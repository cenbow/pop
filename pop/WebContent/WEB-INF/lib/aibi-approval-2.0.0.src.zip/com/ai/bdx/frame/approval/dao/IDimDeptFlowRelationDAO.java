package com.ai.bdx.frame.approval.dao;


import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimDeptFlowRelationForm;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;

public interface IDimDeptFlowRelationDAO {


	public abstract void save(DimDeptFlowRelation transientInstance);

	public abstract void delete(DimDeptFlowRelation persistentInstance);

	public abstract DimDeptFlowRelation findById(com.ai.bdx.frame.approval.model.DimDeptFlowRelationId id);

	public abstract List findByExample(DimDeptFlowRelation instance);

	public abstract List findByProperty(String propertyName, Object value);

	public abstract List findByRelationType(Object relationType);

	public abstract List findByApproveFlowId(Object approveFlowId);

	public abstract List findAll();

	public abstract DimDeptFlowRelation merge(
			DimDeptFlowRelation detachedInstance);

	public abstract void attachDirty(DimDeptFlowRelation instance);

	public abstract void attachClean(DimDeptFlowRelation instance);



	/* (non-Javadoc)
	 * @see hibernate.IDimDeptFlowRelation#findAll()
	 */

	/**
	 * 查询审批权限配置对应信息
	 * @param searchForm
	 * @return
	 * @throws MpmException
	 */
	public Map searchDeptFlowRelation(DimDeptFlowRelationForm searchForm, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 保存审批权限配置对应信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void delete(DimDeptFlowRelationForm searchForm) throws MpmException;

	/**
	 * 删除审批权限配置对应信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
//	public void save(DimDeptFlowRelation dimDeptFlowRelation) throws MpmException;

	/**
	 * 取审批权限配置对应信息
	 * @param rid
	 * @param cType
	 * @return
	 * @throws MpmException
	 */
	public DimDeptFlowRelation getDeptFlowRelation(int rid, Short cType) throws MpmException;

	/**
	 * 取审批权限配置对应信息
	 * @param deptflow
	 * @param channelId
	 * @param confirmType
	 * @return
	 * @throws MpmException
	 */
	public DimDeptFlowRelation getDeptFlowRelation(Short channelType, String channelId, int confirmType) throws MpmException;

	/**
	 * 取所有审批权限配置对应信息
	 * @param rid
	 * @param cType
	 * @return
	 * @throws MpmException
	 */
	public List getAllDeptFlowRelation() throws MpmException;
	
	/**
	 * 查询审批权限配置对应信息
	 * @param dimDeptFlowRelation
	 * @param pageSize
	 * @param curPage
	 * @return
	 * @throws MpmException
	 */
	public Map findDeptFlowAction(DimDeptFlowRelation dimDeptFlowRelation, Integer curPage, Integer pageSize) throws MpmException;
	/**
	 * 根据id查询审批权限配置对应信息
	 * @param id
	 * @return
	 * @throws MpmException
	 */
//	public DimDeptFlowRelation findById(DimDeptFlowRelationId id) throws MpmException ;
}
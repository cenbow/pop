package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimDeptFlowRelationForm;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelationId;
import java.util.List;
import java.util.Map;

public abstract interface IDimDeptFlowRelationDAO
{
  public abstract void save(DimDeptFlowRelation paramDimDeptFlowRelation);

  public abstract void delete(DimDeptFlowRelation paramDimDeptFlowRelation);

  public abstract DimDeptFlowRelation findById(DimDeptFlowRelationId paramDimDeptFlowRelationId);

  public abstract List findByExample(DimDeptFlowRelation paramDimDeptFlowRelation);

  public abstract List findByProperty(String paramString, Object paramObject);

  public abstract List findByRelationType(Object paramObject);

  public abstract List findByApproveFlowId(Object paramObject);

  public abstract List findAll();

  public abstract DimDeptFlowRelation merge(DimDeptFlowRelation paramDimDeptFlowRelation);

  public abstract void attachDirty(DimDeptFlowRelation paramDimDeptFlowRelation);

  public abstract void attachClean(DimDeptFlowRelation paramDimDeptFlowRelation);

  public abstract Map searchDeptFlowRelation(DimDeptFlowRelationForm paramDimDeptFlowRelationForm, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void delete(DimDeptFlowRelationForm paramDimDeptFlowRelationForm)
    throws MpmException;

  public abstract DimDeptFlowRelation getDeptFlowRelation(int paramInt, Short paramShort)
    throws MpmException;

  public abstract DimDeptFlowRelation getDeptFlowRelation(Short paramShort, String paramString, int paramInt)
    throws MpmException;

  public abstract List getAllDeptFlowRelation()
    throws MpmException;

  public abstract Map findDeptFlowAction(DimDeptFlowRelation paramDimDeptFlowRelation, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IDimDeptFlowRelationDAO
 * JD-Core Version:    0.6.2
 */
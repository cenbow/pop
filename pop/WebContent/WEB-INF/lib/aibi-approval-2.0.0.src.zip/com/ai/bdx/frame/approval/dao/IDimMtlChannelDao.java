package com.ai.bdx.frame.approval.dao;

import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChannelForm;
import com.ai.bdx.frame.approval.model.DimMtlChannel;

public interface IDimMtlChannelDao {

	/**
	 * 取渠道信息定义
	 * @param channelId
	 * @return
	 * @throws Exception
	 */
	public DimMtlChannel getMtlChannel(String channelId) throws Exception;

	/**
	 * 查询渠道信息定义
	 * @param channel
	 * @return
	 * @throws Exception
	 */
	public List findMtlChannel(DimMtlChannel channel) throws Exception;

	/**
	 * 查询渠渠道信息定义信息(分页)
	 * @param searchForm
	 * @return
	 * @throws MpmException
	 */
	public Map searchMtlChannel(DimMtlChannelForm searchForm, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 保存渠道信息定义信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void save(DimMtlChannel dimMtlChannel) throws MpmException;

	/**
	 * 删除资渠道信息定义信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void delete(DimMtlChannelForm searchForm) throws MpmException;

	/**
	 * 取得所有彩信类型；
	 * @return
	 */
	public List getAllMmsType();

	/**
	 * 取得该类型的所有彩信；
	 * @param typeId
	 * @return
	 */
	public List getAllMmsContentByType(String typeId);

	/**
	 * 取得彩信类型名；
	 * @param id
	 * @return
	 */
	public String getTypeName(String id);

	/**
	 * 得到某渠道类型的所有渠道；
	 * @param channelType
	 * @return
	 */
	public List getBsChannelsByType(String channelType);

	/**
	 * 获取指定类型对应所有渠道
	 * @param channeltypeId
	 * @return
	 * @throws MpmException
	 */
	public List<DimMtlChannel> getChannelsByType(Short channeltypeId) throws MpmException;

	/**
	 * 获取指定类型对应所有渠道(查询创建人自己活创建人为空的记录)
	 * @param channeltypeId
	 * @param createUser
	 * @return
	 * @throws MpmException
	 */
	public List<DimMtlChannel> getChannelsByType(Short channeltypeId,String createUser) throws MpmException;
	
	/**
	 * 为每个渠道类型获取一个对应的渠道
	 * @return
	 * @throws MpmException
	 */
	public List<DimMtlChannel> getOneChannelForEachType(Short channeltypeId) throws MpmException;
}

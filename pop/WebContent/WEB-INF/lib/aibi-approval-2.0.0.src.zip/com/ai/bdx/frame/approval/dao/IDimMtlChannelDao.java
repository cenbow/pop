package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChannelForm;
import com.ai.bdx.frame.approval.model.DimMtlChannel;
import java.util.List;
import java.util.Map;

public abstract interface IDimMtlChannelDao
{
  public abstract DimMtlChannel getMtlChannel(String paramString)
    throws Exception;

  public abstract List findMtlChannel(DimMtlChannel paramDimMtlChannel)
    throws Exception;

  public abstract Map searchMtlChannel(DimMtlChannelForm paramDimMtlChannelForm, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void save(DimMtlChannel paramDimMtlChannel)
    throws MpmException;

  public abstract void delete(DimMtlChannelForm paramDimMtlChannelForm)
    throws MpmException;

  public abstract List getAllMmsType();

  public abstract List getAllMmsContentByType(String paramString);

  public abstract String getTypeName(String paramString);

  public abstract List getBsChannelsByType(String paramString);

  public abstract List<DimMtlChannel> getChannelsByType(Short paramShort)
    throws MpmException;

  public abstract List<DimMtlChannel> getChannelsByType(Short paramShort, String paramString)
    throws MpmException;

  public abstract List<DimMtlChannel> getOneChannelForEachType(Short paramShort)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IDimMtlChannelDao
 * JD-Core Version:    0.6.2
 */
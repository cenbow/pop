package com.ai.bdx.frame.approval.dao;


import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm;
import com.ai.bdx.frame.approval.model.DimMtlChanneltype;

/**
 * Created on Jan 4, 2008 4:56:34 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IDimMtlChanneltypeDao {

	/**
	 * 取某个渠道类型的定义
	 * @param channeltypeId
	 * @return
	 * @throws Exception
	 */
	public DimMtlChanneltype getMtlChanneltype(Short channeltypeId) throws Exception;

	/**
	 * 查询渠道类型定义
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public List findMtlChanneltype(DimMtlChanneltype type) throws Exception;

	/**
	 * 查询渠道类型定义信息(分页)
	 * @param searchForm
	 * @return
	 * @throws MpmException
	 */
	public Map searchMtlChanneltype(DimMtlChanneltypeForm searchForm, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 保存渠道类型定义信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void save(DimMtlChanneltype dimMtlChanneltype) throws MpmException;

	/**
	 * 删除资渠道类型定义信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void delete(DimMtlChanneltypeForm searchForm) throws MpmException;
	/**
	 * 根据渠道类型Id取渠道类型的接触类型
	 * @param channelTypeId
	 * @throws MpmException
	 */
	public Integer findContactTypeByChannelType(Integer channelTypeId) throws MpmException;

	/**
	 * 根据渠道类型和渠道取接触控制类型；
	 * @param channelTypeId
	 * @param channelId
	 * @return
	 * @throws MpmException
	 */
	public Short findContactTypeByChannelTypeAndId(Short channelTypeId, String channelId) throws MpmException;
	/**
	 * 根据渠道类型id取渠道的派单方式
	 * @param channelTypeId
	 * @throws MpmException
	 */
	public Integer getSendOddTypeByChannelType(Integer channelTypeId) throws MpmException;

	/**
	 * 获取所有渠道类型
	 * @return
	 * @throws Exception
	 */
	public List<DimMtlChanneltype> getAllChannelType(String containsEvent) throws MpmException;
	
	/**
	 * 获取渠道类型,剔除综合网关
	 * @return
	 * @throws Exception
	 */
	public List<DimMtlChanneltype> getAllChannelType(String containsEvent,String isRejectWebGateWay) throws MpmException;
	
	/**
	 * 根据系统标识,获取所有渠道类型
	 * @return
	 * @throws Exception
	 */
	public List getAllChannelTypeForSys(String SysId) throws MpmException;
	
	/**
	 * 从mcd_user_channel_relation表（存放用户偏好渠道）获取所有渠道类型
	 * @return
	 * @throws Exception
	 */
	public List getAllChannelTypeFromUserChannelRelation() throws MpmException;
}

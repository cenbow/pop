package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm;
import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
import java.util.List;
import java.util.Map;

public abstract interface IDimMtlChanneltypeDao
{
  public abstract DimMtlChanneltype getMtlChanneltype(Short paramShort)
    throws Exception;

  public abstract List findMtlChanneltype(DimMtlChanneltype paramDimMtlChanneltype)
    throws Exception;

  public abstract Map searchMtlChanneltype(DimMtlChanneltypeForm paramDimMtlChanneltypeForm, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void save(DimMtlChanneltype paramDimMtlChanneltype)
    throws MpmException;

  public abstract void delete(DimMtlChanneltypeForm paramDimMtlChanneltypeForm)
    throws MpmException;

  public abstract Integer findContactTypeByChannelType(Integer paramInteger)
    throws MpmException;

  public abstract Short findContactTypeByChannelTypeAndId(Short paramShort, String paramString)
    throws MpmException;

  public abstract Integer getSendOddTypeByChannelType(Integer paramInteger)
    throws MpmException;

  public abstract List<DimMtlChanneltype> getAllChannelType(String paramString)
    throws MpmException;

  public abstract List<DimMtlChanneltype> getAllChannelType(String paramString1, String paramString2)
    throws MpmException;

  public abstract List getAllChannelTypeForSys(String paramString)
    throws MpmException;

  public abstract List getAllChannelTypeFromUserChannelRelation()
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao
 * JD-Core Version:    0.6.2
 */
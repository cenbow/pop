package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.DimPubChannel;
import java.util.List;

public abstract interface IDimPubChannelDao
{
  public abstract List getObjList()
    throws Exception;

  public abstract List getObjListByChannleType(String paramString)
    throws Exception;

  public abstract DimPubChannel getPubChannel(String paramString)
    throws Exception;

  public abstract List findPubChannel(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IDimPubChannelDao
 * JD-Core Version:    0.6.2
 */
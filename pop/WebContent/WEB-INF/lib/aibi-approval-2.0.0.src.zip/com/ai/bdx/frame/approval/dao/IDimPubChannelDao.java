package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.DimPubChannel;

public interface IDimPubChannelDao {

	public List getObjList() throws Exception;

	public List getObjListByChannleType(String channelTypeId) throws Exception;

	public DimPubChannel getPubChannel(String channelId) throws Exception;

	/**
	 * 查询渠道信息
	 * @param channelIds 渠道编号（形如：'1','2','3',...）
	 * @return
	 * @throws Exception
	 */
	public List findPubChannel(String channelIds) throws Exception;
}

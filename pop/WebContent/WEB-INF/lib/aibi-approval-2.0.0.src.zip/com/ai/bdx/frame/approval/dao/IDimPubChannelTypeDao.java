package com.ai.bdx.frame.approval.dao;

import java.util.List;

import com.ai.bdx.frame.approval.model.DimPubChanneltype;

public interface IDimPubChannelTypeDao {

	/**
	 * 取所有渠道类型信息（渠道类型0、3除外）
	 * @return
	 * @throws Exception
	 */
	public List getObjList() throws Exception;

	/**
	 * 根据主键取渠道类型信息
	 * @param channelTypeId
	 * @return
	 * @throws Exception
	 */
	public DimPubChanneltype getChanneltype(Integer channelTypeId) throws Exception;

	/**
	 * 取所有的渠道类型信息
	 * @return
	 * @throws Exception
	 */
	public List getAllChannelType() throws Exception;
}

package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.DimResType;
import java.util.List;

public abstract interface IDimResTypeDao
{
  public abstract List findAll()
    throws Exception;

  public abstract DimResType findById(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IDimResTypeDao
 * JD-Core Version:    0.6.2
 */
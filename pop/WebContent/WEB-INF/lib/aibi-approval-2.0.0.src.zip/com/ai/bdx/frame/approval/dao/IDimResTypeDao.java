package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.DimResType;

/*
 * Created on 10:06:32 AM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb  zhoulb@asiainfo.com
 * @version 1.0
 */
public interface IDimResTypeDao {

	public List findAll() throws Exception;

	public DimResType findById(String resType) throws Exception;
}

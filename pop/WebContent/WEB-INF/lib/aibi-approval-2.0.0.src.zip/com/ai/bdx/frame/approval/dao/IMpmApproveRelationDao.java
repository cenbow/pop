package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlApproveRelation;
import java.util.List;
import org.springframework.dao.DataAccessException;

public abstract interface IMpmApproveRelationDao
{
  public abstract MtlApproveRelation save(MtlApproveRelation paramMtlApproveRelation)
    throws DataAccessException;

  public abstract void update(MtlApproveRelation paramMtlApproveRelation)
    throws DataAccessException;

  public abstract void updateByJdbc(MtlApproveRelation paramMtlApproveRelation)
    throws DataAccessException;

  public abstract void deleteByUserid(MtlApproveRelation paramMtlApproveRelation)
    throws DataAccessException;

  public abstract MtlApproveRelation findByUserid(String paramString1, String paramString2)
    throws DataAccessException;

  public abstract List findByCondtion(String paramString1, String paramString2, String paramString3)
    throws DataAccessException;

  public abstract List findAll()
    throws DataAccessException;

  public abstract List findByApproveUserId(String paramString)
    throws Exception;

  public abstract int getUserMaxApproveLevel(String paramString)
    throws Exception;

  public abstract boolean getFirstUserOnApprove(String paramString1, String paramString2)
    throws Exception;

  public abstract boolean getLastUserOnApprove(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract short getUserApproveLevel(String paramString1, String paramString2)
    throws Exception;

  public abstract MtlApproveRelation getNextApproveUser(String paramString, int paramInt)
    throws Exception;

  public abstract MtlApproveRelation getPreApproveUser(String paramString1, String paramString2)
    throws Exception;

  public abstract boolean isFirstUserApprove(String paramString)
    throws Exception;

  public abstract boolean isNextApproveExist(String paramString1, String paramString2)
    throws Exception;

  public abstract boolean isPreApproveExist(String paramString1, String paramString2)
    throws Exception;

  public abstract void updateApproveUserid(String paramString1, String paramString2, int paramInt)
    throws Exception;

  public abstract List getApproveRelationByDeptId(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMpmApproveRelationDao
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ai.bdx.frame.approval.model.MtlApproveRelation;

/**
 * <p>Title: Aiomni</p>
 *
 * <p>Description: Aiomni 营销管理－审批关系定义管理</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: 亚信中国 [www.asiainfo.com]</p>
 *
 * @author zhoulb [zhoulb@asiainfo.com]
 * @version 1.0
 */
public interface IMpmApproveRelationDao {

	/**
	 * 插入一条记录
	 * @param mtlApproveRelation
	 * @return
	 * @throws DataAccessException
	 */
	public MtlApproveRelation save(MtlApproveRelation mtlApproveRelation) throws DataAccessException;

	/**
	 * 更新记录
	 * @param mtlApproveRelation
	 * @throws DataAccessException
	 */
	public void update(MtlApproveRelation mtlApproveRelation) throws DataAccessException;

	/**
	 * 通过hiberate修改一条记录
	 * @param svc
	 * @throws DataAccessException
	 */
	public void updateByJdbc(MtlApproveRelation svc) throws DataAccessException;

	/**
	 * 删除记录
	 * @param mtlApproveRelation
	 * @throws DataAccessException
	 */
	public void deleteByUserid(MtlApproveRelation mtlApproveRelation) throws DataAccessException;

	/**
	 * 根据主键返回一条记录
	 * @param deptId
	 * @param approveUserid
	 * @return
	 * @throws DataAccessException
	 */
	public MtlApproveRelation findByUserid(String deptId, String approveUserid) throws DataAccessException;

	/**
	 * 
	 * @param deptId
	 * @param approveUserid
	 * @param approveLevel
	 * @return
	 * @throws DataAccessException
	 */
	public List findByCondtion(String deptId, String approveUserid, String approveLevel) throws DataAccessException;

	/**
	 * 返回所有记录
	 * @return
	 * @throws DataAccessException
	 */
	public List findAll() throws DataAccessException;

	/**
	 * 返回所有审批人员记录
	 * @param approveUserid
	 * @return
	 * @throws Exception
	 */
	public List findByApproveUserId(String approveUserid) throws Exception;

	/**
	 * 活得定义在某个用户上的最高审批级别
	 * @param createUserId
	 * @return
	 * @throws Exception
	 */
	public int getUserMaxApproveLevel(String createUserId) throws Exception;

	/**
	 * 获得指定策划人的第一个审批人
	 * @param createUserId
	 * @return
	 */
	public boolean getFirstUserOnApprove(String createUserId, String approveUserId) throws Exception;

	/**
	 * 获得指定活动的最后一个审批人
	 * @param createUserId
	 * @return
	 */
	public boolean getLastUserOnApprove(String createUserId, String approveUserId, String camp_id) throws Exception;

	/**
	 * 获得指定审批人的审批级别
	 * @param createUserId
	 * @param approveUserId
	 * @return
	 * @throws Exception
	 */
	public short getUserApproveLevel(String createUserId, String approveUserId) throws Exception;

	/**
	 * 获得下一个审批人信息
	 * @param createUserid
	 * @param nextApproveLev
	 * @return
	 * @throws Exception
	 */
	public MtlApproveRelation getNextApproveUser(String createUserid, int nextApproveLev) throws Exception;

	/**
	 * 获得上一个审批人信息
	 * @param createUserid
	 * @param approveUserid
	 * @return
	 * @throws Exception
	 */
	public MtlApproveRelation getPreApproveUser(String createUserid, String approveUserid) throws Exception;

	/**
	 * 判断对该用户有没有维护审批关系
	 * @param createUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isFirstUserApprove(String createUserId) throws Exception;

	/**
	 * 判断该用户是否定义了上级审批关系
	 * @param createUserid
	 * @return
	 * @throws Exception
	 */
	public boolean isNextApproveExist(String createUserid, String approveUserid) throws Exception;

	/**
	 * 判断该用户是否定义了下级审批关系。
	 * @param createUserid
	 * @return
	 * @throws Exception
	 */
	public boolean isPreApproveExist(String createUserid, String approveUserid) throws Exception;

	/**
	 * 审批授权
	 * @param approveUserId
	 * @param authUserid
	 * @throws Exception
	 */
	public void updateApproveUserid(String approveUserId, String authUserid, int authFlag) throws Exception;

	/**
	 * 查询部门是否有审批人
	 * @param deptId
	 * @return
	 * @throws Exception
	 */
	public List getApproveRelationByDeptId(String deptId) throws Exception;

}
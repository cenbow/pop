package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlCampDataSource;
import java.util.List;

public abstract interface IMpmCampDataSourceDao
{
  public abstract MtlCampDataSource insert(MtlCampDataSource paramMtlCampDataSource);

  public abstract void updateByTabname(MtlCampDataSource paramMtlCampDataSource);

  public abstract void deleteByTabname(String paramString);

  public abstract MtlCampDataSource findByTabCname(String paramString);

  public abstract MtlCampDataSource findByTabname(String paramString);

  public abstract List findByCondtion(MtlCampDataSource paramMtlCampDataSource);

  public abstract List findAll();

  public abstract List findBySourceTypeWithColumns(Short[] paramArrayOfShort)
    throws Exception;

  public abstract List findBySourceNameWithColumns(String[] paramArrayOfString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMpmCampDataSourceDao
 * JD-Core Version:    0.6.2
 */
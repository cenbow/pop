package com.ai.bdx.frame.approval.dao;

import java.util.List;

import com.ai.bdx.frame.approval.model.MtlCampDataSource;

/**
 * <p>Title: Aiomni</p>
 *
 * <p>Description: Aiomni 营销管理－数据源管理</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: 亚信中国 [www.asiainfo.com]</p>
 *
 * @author zhoulb [zhoulb@asiainfo.com]
 * @version 1.0
 */
public interface IMpmCampDataSourceDao {

	/**
	 * 向数据源表mtl_camp_datasource表插入一条记录
	 * @param mtlCampDataSource
	 * @return void
	 */
	public MtlCampDataSource insert(MtlCampDataSource mtlCampDataSource);

	/**
	 * 通过id更新数据源表mtl_camp_datasource表记录
	 * @param mtlCampDataSource
	 * @return void
	 */
	public void updateByTabname(MtlCampDataSource mtlCampDataSource);

	/**
	 * 通过id删除数据源表mtl_camp_datasource表记录
	 * @param mtlCampDataSource
	 * @return void
	 */
	public void deleteByTabname(String tablename);
	public MtlCampDataSource findByTabCname(String tablecname);

	/**
	 * 通过id查询数据源表mtl_camp_datasource表记录
	 * @param mtlCampDataSource
	 * @return void
	 */
	public MtlCampDataSource findByTabname(String tablename);

	/**
	 * 通过条件组合查询数据源表mtl_camp_datasource表记录
	 * @param mtlCampDataSource
	 */
	public List findByCondtion(MtlCampDataSource mtlCampDataSource);

	/**
	 * 返回表的所有记录
	 */
	public List findAll();

	/**
	 * 取指定类型的数据源信息（包括数据源的字段）
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public List findBySourceTypeWithColumns(Short[] type) throws Exception;

	/**
	 * 取指定名称的数据源信息（包括数据源的字段）
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public List findBySourceNameWithColumns(String[] sourceNames) throws Exception;
}

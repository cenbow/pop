package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
import java.util.List;
import java.util.Map;
import org.springframework.dao.DataAccessException;

public abstract interface IMpmCampDatasrcColumnDao
{
  public abstract MtlCampDatasrcColumn insertDatasrcColumn(MtlCampDatasrcColumn paramMtlCampDatasrcColumn);

  public abstract void deleteByStr(String paramString1, String paramString2, String paramString3);

  public abstract void updateByHiberate(MtlCampDatasrcColumn paramMtlCampDatasrcColumn);

  public abstract void updateByJdbc(MtlCampDatasrcColumn paramMtlCampDatasrcColumn)
    throws DataAccessException;

  public abstract Map findByTabname(String paramString, Integer paramInteger1, Integer paramInteger2);

  public abstract MtlCampDatasrcColumn findByColname(String paramString);

  public abstract MtlCampDatasrcColumn findByColCname(String paramString)
    throws MpmException;

  public abstract MtlCampDatasrcColumn findByColCname(String paramString1, String paramString2)
    throws MpmException;

  public abstract MtlCampDatasrcColumn getCampDatasrcColumn(String paramString1, String paramString2)
    throws Exception;

  public abstract List findByCondtion(MtlCampDatasrcColumn paramMtlCampDatasrcColumn);

  public abstract List findAll();

  public abstract List getAllClass()
    throws DataAccessException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMpmCampDatasrcColumnDao
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;

/**
 * <p>Title: Aiomni</p>
 *
 * <p>Description: Aiomni 营销管理－数据源管理</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: 亚信中国 [www.asiainfo.com]</p>
 *
 * @author zhoulb [zhoulb@asiainfo.com]
 * @version 1.0
 */
public interface IMpmCampDatasrcColumnDao {
	/**
	 * 插入数据源字段记录
	 * @param mtlCampDatasrcColumn
	 * @return
	 */
	public MtlCampDatasrcColumn insertDatasrcColumn(MtlCampDatasrcColumn mtlCampDatasrcColumn);

	/**
	 * 通过条件组合删除记录
	 * @param tableName
	 * @param columnName
	 * @param columnpk
	 */
	public void deleteByStr(String tableName, String columnName, String columnpk);

	/**
	 * 通过hiberate修改一条记录
	 * @param mtlCampDatasrcColumn
	 */
	public void updateByHiberate(MtlCampDatasrcColumn mtlCampDatasrcColumn);

	/**
	 * 通过jdbc修改一条记录
	 * @param mtlCampDatasrcColumn
	 * @throws DataAccessException
	 */
	public void updateByJdbc(MtlCampDatasrcColumn mtlCampDatasrcColumn) throws DataAccessException;

	/**
	 * 通过表名返回所有字段信息（分页使用）
	 * @param tabname
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	public Map findByTabname(String tabname, Integer curPage, Integer pageSize);

	/**
	 * 通过字段名返回一条字段记录
	 * @param colname
	 * @return
	 */
	public MtlCampDatasrcColumn findByColname(String colname);
	public MtlCampDatasrcColumn findByColCname(String colCname)throws MpmException;
	public MtlCampDatasrcColumn findByColCname(String colCname,String sourceName) throws MpmException;
	
	/**
	 * 根据数据源表名及字段名取字段信息
	 * @param sourceName
	 * @param colName
	 * @return
	 * @throws Exception
	 */
	public MtlCampDatasrcColumn getCampDatasrcColumn(String sourceName, String colName) throws Exception;

	/**
	 * 通过条件组合查询记录
	 * @param mtlCampDatasrcColumn
	 * @return
	 */
	public List findByCondtion(MtlCampDatasrcColumn mtlCampDatasrcColumn);

	/**
	 * 返回所有的字段信息记录
	 * @return
	 */
	public List findAll();

	/**
	 * 得到所有的字段分类信息
	 * @return
	 * @throws DataAccessException
	 */
	public List getAllClass() throws DataAccessException;
}

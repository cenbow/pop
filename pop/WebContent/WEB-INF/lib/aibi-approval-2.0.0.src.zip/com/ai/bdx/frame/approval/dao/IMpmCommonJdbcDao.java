package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.exception.MpmException;
import java.util.List;
import org.apache.struts.util.LabelValueBean;

public abstract interface IMpmCommonJdbcDao
{
  public abstract List getDimCompBrand()
    throws Exception;

  public abstract boolean isNameExist(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws Exception;

  public abstract boolean isNameExistForInt(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws Exception;

  public abstract int isDimColumnExists(String paramString1, String paramString2);

  public abstract boolean isNameExistForDataColumn(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws Exception;

  public abstract String getUserDeptPolicyCache(String paramString, int paramInt)
    throws Exception;

  public abstract void deleteCampsegUserProcessResult(String paramString)
    throws Exception;

  public abstract List getCampsegCostListByResType(String paramString1, String paramString2)
    throws Exception;

  public abstract String getFirstExistTable(String[] paramArrayOfString)
    throws Exception;

  public abstract List getExistTables(String[] paramArrayOfString)
    throws Exception;

  public abstract String getCompanyTreeHtml()
    throws Exception;

  public abstract void updatePublicizeComb(String paramString1, String paramString2)
    throws Exception;

  public abstract List getCampChannelTypeMap()
    throws Exception;

  public abstract String getApproveFlowidByChannelTypeAndId(String paramString1, String paramString2)
    throws MpmException;

  public abstract List getCampChannelIdMap(int paramInt)
    throws Exception;

  public abstract List getAllChannel()
    throws Exception;

  public abstract String getApproveFlowid(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws MpmException;

  public abstract String getApproveFlowid(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract String getApproveFlowid(String paramString1, String paramString2)
    throws MpmException;

  public abstract String excludeBlackList(String paramString1, String paramString2);

  public abstract List<LabelValueBean> getBsMmsContent()
    throws Exception;

  public abstract List getMtlCampRuleTypeMap()
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao;

import java.util.List;

import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.approval.exception.MpmException;

/**
 * Created on 2:55:48 PM
 *
 * <p>Title: </p>
 * <p>Description: 营销管理系统通过JDBC直接访问数据库的功用方法借口�?/p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
/**
 * @author dengshu
 *
 */
public interface IMpmCommonJdbcDao {

	/**
	 * 获得竞争对手品牌
	 * 
	 * @return list List LabelValueBean对象集合
	 * @throws Exception
	 */
	public List getDimCompBrand() throws Exception;

	/**
	 * 判断某个表（tableName）中，某个字�?nameColumn)上是否存在某个�?name)
	 * 
	 * @param name
	 * @param id
	 * @param nameColumn
	 * @param tableName
	 * @return
	 * @throws Exception
	 */
	public boolean isNameExist(String name, String id, String idColumn, String nameColumn, String tableName)
			throws Exception;

	/**
	 * 判断某个表（tableName）中，某个字�?nameColumn)上是否存在某个�?name) （当字段数据类型为整型时�?
	 * 
	 * @param name
	 * @param id
	 * @param idColumn
	 * @param nameColumn
	 * @param tableName
	 * @return
	 * @throws Exception
	 */
	public boolean isNameExistForInt(String name, String id, String idColumn, String nameColumn, String tableName)
			throws Exception;

	/**
	 * 约束维表字段
	 * 
	 * @param columnName
	 * @param sourceName
	 * @return
	 */
	public int isDimColumnExists(String columnName, String sourceName);

	/**
	 * 当主键为两个字段�?判断重名)
	 * 
	 * @param name
	 * @param id
	 * @param idColumn
	 * @param nameColumn
	 * @param tableName
	 * @param flag
	 * @return
	 * @throws Exception
	 */
	public boolean isNameExistForDataColumn(String name, String id, String idColumn, String nameColumn, String tableName)
			throws Exception;

	/**
	 * 判断用户是否是部�?分公司领�?
	 * 
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	// public boolean isUserDeptLeader(String userId) throws Exception;
	/**
	 * 判断用户是否是部�?分公司领导，如果不是，返回此用户的userId；如果是，返回部分及子部分下所有用户的userId
	 * 
	 * @param userId
	 * @return 多个userId，格式如�?userId1','userId2',...�?
	 * @throws MpmException
	 */
	public String getUserDeptPolicyCache(String userId, int deptId) throws Exception;

	/**
	 * 删除一个活动波次在策划过程中涉及的用户处理表数据（筛选过程表、细分过程表、筛选结果用户表�?
	 * 
	 * @param campsegId
	 * @throws Exception
	 */
	public void deleteCampsegUserProcessResult(String campsegId) throws Exception;

	/**
	 * 取活动波次中某种类型的成本信�?
	 * 
	 * @param resType
	 * @param campsegId
	 * @return
	 * @throws Exception
	 */
	public List getCampsegCostListByResType(String resType, String campsegId) throws Exception;

	/**
	 * 判断表是否存在，返回最先存在的一张表
	 * 
	 * @param userbaseTables
	 * @return 返回最先存在的一张表
	 * @throws Exception
	 */
	public String getFirstExistTable(String[] userbaseTables) throws Exception;

	/**
	 * 给定一个表名数组，返回物理表存在的表名列表
	 * 
	 * @param userbaseTables
	 * @return List(element=表名)
	 * @throws Exception
	 */
	public List getExistTables(String[] userbaseTables) throws Exception;

	/**
	 * 取公司组织结构的html代码信息
	 * 
	 * @return
	 * @throws Exception
	 */
	public String getCompanyTreeHtml() throws Exception;

	/**
	 * 更新营销活动定义�?修改宣传方案组合编号),更新MTL_publicize_reslist表中campseg_id字段为活动编�?
	 * 
	 * @param campsegId
	 * @param publicizeCombId
	 * @throws Exception
	 */
	public void updatePublicizeComb(String campsegId, String publicizeCombId) throws Exception;

	/**
	 * @return
	 */
	public List getCampChannelTypeMap() throws Exception;

	public String getApproveFlowidByChannelTypeAndId(String type, String cid) throws MpmException;

	public List getCampChannelIdMap(int channeltypeId) throws Exception;

	public List getAllChannel() throws Exception;

	/**
	 * 取默认的审批流程
	 * 
	 * @param userid
	 * @param campDrvId
	 * @param channeltypeId
	 * @param approveType
	 * @return
	 * @throws MpmException
	 */
	public String getApproveFlowid(String userid, String campDrvId, String channeltypeId, String channelId,
			String approveType) throws MpmException;

	/**
	 * 取默认的审批流程
	 * 
	 * @param userid
	 * @param campDrvId
	 * @param channeltypeId
	 * @param approveType
	 * @return
	 * @throws MpmException
	 */
	public String getApproveFlowid(String userid, String campDrvId, String approveType) throws MpmException;

	/**
	 * 取陕西审批流程
	 * 
	 * @param userid
	 * @param campDrvId
	 * @param channeltypeId
	 * @param approveType
	 * @return
	 * @throws MpmException
	 */
	public String getApproveFlowid(String userid, String approveType) throws MpmException;

	/*
	 *
	 */
	public String excludeBlackList(String srcTable, String avoidCustTypes);

	/**
	 * 获取彩信列表�?
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<LabelValueBean> getBsMmsContent() throws Exception;

	public List getMtlCampRuleTypeMap() throws Exception;
}

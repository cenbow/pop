package com.ai.bdx.frame.approval.dao;

import java.util.List;
import com.ai.bdx.frame.approval.model.MtlCostList;

/**
 * <p>
 * Title: Aiomni
 * </p>
 *
 * <p>
 * Description: Aiomni 营销管理－数据源管理
 * </p>
 *
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 *
 * <p>
 * Company: 亚信中国 [www.asiainfo.com]
 * </p>
 *
 * @author zhoulb [zhoulb@asiainfo.com]
 * @version 1.0
 */

public interface IMpmCostListDao {
	/**
	 * 返回所有的成本信息记录
	 * 
	 * @return
	 * @throws Exception
	 */
	public List findAll() throws Exception;

	/**
	 * 通过成本类型编码返回一条记录
	 * 
	 * @param costCode
	 * @return
	 * @throws Exception
	 */
	public MtlCostList findByCode(String costCode) throws Exception;

	/**
	 * 删除一条记录
	 * 
	 * @param resCode
	 * @throws Exception
	 */
	public void delete(String resCode) throws Exception;

	/**
	 * 插入一条记录
	 * 
	 * @param mtlCostList
	 * @return
	 * @throws Exception
	 */
	public MtlCostList save(MtlCostList mtlCostList) throws Exception;

	/**
	 * 修改一条记录
	 * 
	 * @param mtlCostList
	 * @throws Exception
	 */
	public void update(MtlCostList mtlCostList) throws Exception;

}

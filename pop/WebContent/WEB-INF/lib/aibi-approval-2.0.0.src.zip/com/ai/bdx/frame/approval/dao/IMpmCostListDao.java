package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlCostList;
import java.util.List;

public abstract interface IMpmCostListDao
{
  public abstract List findAll()
    throws Exception;

  public abstract MtlCostList findByCode(String paramString)
    throws Exception;

  public abstract void delete(String paramString)
    throws Exception;

  public abstract MtlCostList save(MtlCostList paramMtlCostList)
    throws Exception;

  public abstract void update(MtlCostList paramMtlCostList)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMpmCostListDao
 * JD-Core Version:    0.6.2
 */
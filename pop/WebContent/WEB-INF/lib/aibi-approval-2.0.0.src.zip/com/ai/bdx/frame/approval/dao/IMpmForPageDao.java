package com.ai.bdx.frame.approval.dao;

import java.util.Map;

import com.ai.bdx.frame.approval.model.MtlApproveRelation;
import com.ai.bdx.frame.approval.model.MtlCostList;
import com.ai.bdx.frame.approval.model.MtlResList;
import com.ai.bdx.frame.approval.model.MtlSysActflowDef;


public interface IMpmForPageDao {
	/**
	 * 字段信息分页
	 * @param tabname
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	public Map findDataSourceByTabname(String tabname, String columnName, String columnCname, Integer curPage, Integer pageSize);

	/**
	 * 活动流程分页
	 * @param svc
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	public Map findActStepflowAll(MtlSysActflowDef svc, Integer curPage, Integer pageSize);

	/**
	 * 实体分页
	 * @param svc
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	public Map findResAll(MtlResList svc, Integer curPage, Integer pageSize);

	/**
	 * 成本类型分页
	 * @param svc
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	public Map findCostAll(MtlCostList svc, Integer curPage, Integer pageSize);


	/**
	 * 审批关系分页
	 * @param svc
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	public Map findApproveRelationAll(MtlApproveRelation svc, Integer curPage, Integer pageSize);

	/**
	 * 导出字段信息分页
	 * @param campDrvId
	 * @param sourceName
	 * @param columnName
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	public Map findDataExportItem(String campDrvId, String sourceName, String columnName, Integer curPage, Integer pageSize);

	/**
	 * 活动模板字段信息分页
	 * @param activeTempletId
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	public Map findActTempletById(String activeTempletId, Integer curPage, Integer pageSize);


	/**
	 * 
	 * @param tablename
	 * @return
	 */
	public boolean isExists(String tablename);
	
	
}

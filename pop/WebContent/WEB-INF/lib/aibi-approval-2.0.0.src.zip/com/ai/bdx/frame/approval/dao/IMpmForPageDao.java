package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlApproveRelation;
import com.ai.bdx.frame.approval.model.MtlCostList;
import com.ai.bdx.frame.approval.model.MtlResList;
import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
import java.util.Map;

public abstract interface IMpmForPageDao
{
  public abstract Map findDataSourceByTabname(String paramString1, String paramString2, String paramString3, Integer paramInteger1, Integer paramInteger2);

  public abstract Map findActStepflowAll(MtlSysActflowDef paramMtlSysActflowDef, Integer paramInteger1, Integer paramInteger2);

  public abstract Map findResAll(MtlResList paramMtlResList, Integer paramInteger1, Integer paramInteger2);

  public abstract Map findCostAll(MtlCostList paramMtlCostList, Integer paramInteger1, Integer paramInteger2);

  public abstract Map findApproveRelationAll(MtlApproveRelation paramMtlApproveRelation, Integer paramInteger1, Integer paramInteger2);

  public abstract Map findDataExportItem(String paramString1, String paramString2, String paramString3, Integer paramInteger1, Integer paramInteger2);

  public abstract Map findActTempletById(String paramString, Integer paramInteger1, Integer paramInteger2);

  public abstract boolean isExists(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMpmForPageDao
 * JD-Core Version:    0.6.2
 */
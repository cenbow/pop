package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.MtlSysActflowDef;

public interface IMpmSysActflowDefDao {

	/**
	 * 返回所有的活动流程
	 * @return
	 */
	public List findAll();

	/**
	 * 插入一条活动流程信息
	 * @param mtlSysActflowDef
	 * @return
	 * @throws Exception
	 */
	public String save(MtlSysActflowDef mtlSysActflowDef) throws Exception;

	/**
	 * 删除一条记录
	 * @param flowId
	 * @return
	 * @throws Exception
	 */
	public boolean deleteById(String flowId) throws Exception;

	/**
	 * 根据活动流程编码返回一条记录
	 * @param flowId
	 * @return
	 * @throws Exception
	 */
	public MtlSysActflowDef findById(String flowId) throws Exception;

	/**
	 * 修改一条记录
	 * @param mtlSysActflowDef
	 * @return
	 * @throws Exception
	 */
	public boolean update(MtlSysActflowDef mtlSysActflowDef) throws Exception;

	/**
	 * 根据编号取活动流程定义信息
	 * @param flowId
	 * @return
	 * @throws Exception
	 */
	public MtlSysActflowDef getSysActFlowDef(String flowId) throws Exception;

	/**
	 * 取所有活动流程定义信息
	 * @return
	 * @throws Exception
	 */
	public List getAllSysActFlow() throws Exception;

	/**
	 * 取营销活动内置流程定义信息
	 * @return
	 * @throws Exception
	 */
	public List getCampSysActFlow() throws Exception;

	/**
	 * 取小于等于某个审批级别的所有活动流程定义信息
	 * @param approveLevel
	 * @return
	 * @throws Exception
	 * @deprecated 不再使用 wuwl 2007-6-21
	 */
	public List getSysActFlowDefMapByLevel(int approveLevel) throws Exception;

	/**
	 * 查看审批流程是否被使用。
	 * @param approveFlowId
	 * @return
	 * @throws Exception
	 */
	public boolean getActFlowByApproveflowid(String approveFlowId) throws Exception;
	
}

package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
import java.util.List;

public abstract interface IMpmSysActflowDefDao
{
  public abstract List findAll();

  public abstract String save(MtlSysActflowDef paramMtlSysActflowDef)
    throws Exception;

  public abstract boolean deleteById(String paramString)
    throws Exception;

  public abstract MtlSysActflowDef findById(String paramString)
    throws Exception;

  public abstract boolean update(MtlSysActflowDef paramMtlSysActflowDef)
    throws Exception;

  public abstract MtlSysActflowDef getSysActFlowDef(String paramString)
    throws Exception;

  public abstract List getAllSysActFlow()
    throws Exception;

  public abstract List getCampSysActFlow()
    throws Exception;

  /** @deprecated */
  public abstract List getSysActFlowDefMapByLevel(int paramInt)
    throws Exception;

  public abstract boolean getActFlowByApproveflowid(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMpmSysActflowDefDao
 * JD-Core Version:    0.6.2
 */
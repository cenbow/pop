package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.MtlSysFlowstepDef;

public interface IMpmSysFlowstepDefDao {
	/**
	 * 删除一条活动流程步骤信息
	 * @param flowId
	 * @throws Exception
	 */
	public void deleteById(String flowId) throws Exception;

	/**
	 * 插入或修改一条活动流程步骤信息
	 * @param mtlSysFlowstepDef
	 * @return
	 * @throws Exception
	 */
	public MtlSysFlowstepDef saveOrUpdate(MtlSysFlowstepDef mtlSysFlowstepDef) throws Exception;

	/**
	 * 取某个流程对应的所有步骤编号
	 * @param flowId
	 * @return
	 * @throws Exception
	 */
	public List getSysFlowstepDefByFlowId(String flowId) throws Exception;
}

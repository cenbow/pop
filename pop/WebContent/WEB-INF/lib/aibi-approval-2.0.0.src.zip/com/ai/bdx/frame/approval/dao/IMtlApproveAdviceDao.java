package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlApproveAdvice;
import com.ai.bdx.frame.approval.model.MtlApproveAdviceId;
import java.util.List;
import java.util.Map;

public abstract interface IMtlApproveAdviceDao
{
  public abstract MtlApproveAdvice getApproveAdviceById(MtlApproveAdviceId paramMtlApproveAdviceId)
    throws Exception;

  public abstract List getAdviceActUserId(String paramString1, String paramString2, Short paramShort)
    throws Exception;

  public abstract void deleteAdviceByActUserIds(String paramString1, String paramString2, String paramString3, Short paramShort)
    throws Exception;

  public abstract List findApproveAdvice(MtlApproveAdvice paramMtlApproveAdvice)
    throws Exception;

  public abstract List findApproveAdviceWithCampsegInfo(MtlApproveAdvice paramMtlApproveAdvice, String paramString)
    throws Exception;

  public abstract Map findApproveAdvice(MtlApproveAdvice paramMtlApproveAdvice, Integer paramInteger1, Integer paramInteger2)
    throws Exception;

  public abstract void saveMtlApproveAdvice(MtlApproveAdvice paramMtlApproveAdvice)
    throws Exception;

  public abstract void updateMtlApproveAdvice(MtlApproveAdvice paramMtlApproveAdvice)
    throws Exception;

  public abstract void updateApproveAdviceSponorUserId(String paramString1, String paramString2, String paramString3, Short paramShort)
    throws Exception;

  public abstract void updateApproveAdviceActEndFlag(String paramString1, String paramString2, Short paramShort1, Short paramShort2)
    throws Exception;

  public abstract void deleteMtlApproveAdvice(MtlApproveAdviceId paramMtlApproveAdviceId)
    throws Exception;

  public abstract List findApproveAdviceWithCampInfo(MtlApproveAdvice paramMtlApproveAdvice, String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlApproveAdviceDao
 * JD-Core Version:    0.6.2
 */
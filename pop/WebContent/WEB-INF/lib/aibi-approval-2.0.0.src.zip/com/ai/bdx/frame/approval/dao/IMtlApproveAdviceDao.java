package com.ai.bdx.frame.approval.dao;

import java.util.List;
import java.util.Map;
import com.ai.bdx.frame.approval.model.MtlApproveAdvice;
import com.ai.bdx.frame.approval.model.MtlApproveAdviceId;

/**
 * Created on May 28, 2007 1:32:13 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlApproveAdviceDao {

	/**
	 * 通过主键查询审批建议信息
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public MtlApproveAdvice getApproveAdviceById(MtlApproveAdviceId id) throws Exception;

	/**
	 * 取发起人都邀请了哪些用户
	 * @param campsegId
	 * @param sponorUserId
	 * @param sponorType
	 * @return list(每个element是一个userId，String类型对象)
	 */
	public List getAdviceActUserId(String campsegId, String sponorUserId, Short sponorType) throws Exception;

	/**
	 * 删除参与审批提意见的数据
	 * @param campsegId
	 * @param sponorUserId
	 * @param actUserIds (形如'userId1','userId2',....形式)
	 * @param sponorType
	 * @return
	 * @throws Exception
	 */
	public void deleteAdviceByActUserIds(String campsegId, String sponorUserId, String actUserIds, Short sponorType) throws Exception;

	/**
	 * 根据条件查询审批建议信息
	 * @param advice
	 * @return
	 * @throws Exception
	 */
	public List findApproveAdvice(MtlApproveAdvice advice) throws Exception;

	/**
	 * 根据条件查询审批建议信息(带活动波次的名称及优先级信息)
	 * @param advice
	 * @return
	 * @throws Exception
	 */
	public List findApproveAdviceWithCampsegInfo(MtlApproveAdvice advice,String subject) throws Exception;

	/**
	 * 根据条件分页查询审批建议信息
	 * @param advice
	 * @param currPage
	 * @param pageSize
	 * @return
	 * @throws Exception
	 */
	public Map findApproveAdvice(MtlApproveAdvice advice, final Integer currPage, final Integer pageSize) throws Exception;

	/**
	 * 保存审批建议信息
	 * @param advice
	 * @throws Exception
	 */
	public void saveMtlApproveAdvice(MtlApproveAdvice advice) throws Exception;

	/**
	 * 更新审批建议信息
	 * @param advice
	 * @throws Exception
	 */
	public void updateMtlApproveAdvice(MtlApproveAdvice advice) throws Exception;

	/**
	 * 更新审批建议中原发起人为新发起人
	 * @param campsegId
	 * @param oldSponorUserId
	 * @param newSponorUserId
	 * @param sponorType
	 * @throws Exception
	 */
	public void updateApproveAdviceSponorUserId(String campsegId, String oldSponorUserId, String newSponorUserId, Short sponorType) throws Exception;

	/**
	 * 更新审批建议中的参与标志
	 * @param campsegId
	 * @param oldSponorUserId
	 * @param newSponorUserId
	 * @param sponorType
	 * @throws Exception
	 */
	public void updateApproveAdviceActEndFlag(String campsegId, String sponorUserId, Short actEndFlag, Short sponorType) throws Exception;

	/**
	 * 通过条件删除审批建议信息
	 * @param id
	 * @throws Exception
	 */
	public void deleteMtlApproveAdvice(MtlApproveAdviceId id) throws Exception;

	public List findApproveAdviceWithCampInfo(MtlApproveAdvice advice,String subject) throws Exception;
}

package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.MtlApproveAuth;
import com.ai.bdx.frame.approval.model.MtlApproveAuthId;

/**
 * Created on May 28, 2007 1:32:13 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb
 * @version 1.0
 */
public interface IMtlApproveAuthDao {
	/**
	 * 保存委派信息
	 * @param id
	 * @throws Exception
	 */
	public void save(MtlApproveAuth auth) throws Exception;

	/**
	 * 删除委派信息
	 * @param auth
	 * @throws Exception
	 */
	public void delete(MtlApproveAuth auth) throws Exception;

	/**
	 * 取得当前登陆工号的委派信息
	 * @param authUserid
	 * @return
	 * @throws Exception
	 */
	public MtlApproveAuth getById(MtlApproveAuthId id) throws Exception;

	/**
	 * 得到当前登陆工号能委派的人员信息
	 * @param authUserid
	 * @return
	 * @throws Exception
	 */
	public List getAuthRelation(String authUserid) throws Exception;
}

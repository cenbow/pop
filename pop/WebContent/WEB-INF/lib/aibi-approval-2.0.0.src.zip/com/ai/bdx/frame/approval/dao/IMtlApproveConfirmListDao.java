package com.ai.bdx.frame.approval.dao;


import java.util.List;
import com.ai.bdx.frame.approval.model.MtlApproveConfirmAppoint;
import com.ai.bdx.frame.approval.model.MtlApproveConfirmList;

public interface IMtlApproveConfirmListDao {

	/**
	 * 保存一条活动确认资源人员记录
	 * @param svc
	 * @throws Exception
	 */
	public void save(MtlApproveConfirmList svc) throws Exception;

	/**
	 * 修改一条活动确认资源人员记录
	 * @param svc
	 * @throws Exception
	 */
	public void update(MtlApproveConfirmList svc) throws Exception;

	/**
	 * 删除一条活动确认资源人员记录
	 * @param svc
	 * @throws Exception
	 */
	public void delete(MtlApproveConfirmList svc) throws Exception;

	/**
	 * 根据查询条件查询确认资源人员信息
	 * @param searchCond
	 * @return
	 * @throws Exception
	 */
	public List findByCond(MtlApproveConfirmList searchCond) throws Exception;

	/**
	 * 根据查询条件查询确认资源人员信息
	 * @param campsegId
	 * @param confirmId
	 * @param resourceId
	 * @param confirmUserid
	 * @return
	 * @throws Exception
	 */
	public List findById(String campsegId, String confirmId, String resourceId, String confirmUserid, String approveFlowId, Short approveSeq, Short approveLevel) throws Exception;

	/**
	 * 查询当前持有令牌的确认资源人员信息；
	 * @param campsegId
	 * @param confirmFlag
	 * @param resourceId
	 * @param confirmUserid
	 * @param approveFlowId
	 * @param approveSeq
	 * @param approveLevel
	 * @return
	 * @throws Exception
	 */
	public List findCurrentById(String campsegId, String confirmFlag, String resourceId, String confirmUserid, String approveFlowId, Short approveSeq, Short approveLevel) throws Exception ;
	/**
	 * 查询需要确认资源的活动波次
	 * @param confirmUserid
	 * @return
	 * @throws Exception
	 */
	public List findByUserFlag(String confirmUserid) throws Exception;

	public List findConfirmedByUserFlag(String confirmUserid) throws Exception;

	/**
	 * 根据波次标识删除
	 * @param campsegId
	 * @throws Exception
	 */
	public void deleteByCampsegid(String campsegId) throws Exception;

	/**
	 * 根据是否确认资源来查询记录
	 * @param flag
	 * @return
	 * @throws Exception
	 */
	public List findByFlag(String flag) throws Exception;
	
	/**
	 * 根据是否确认资源来查询记录并且以确认人分组
	 * @param flag
	 * @return
	 * @throws Exception
	 */
	public List findByFlagGroupByUser(String flag) throws Exception;

	//public List findByUserid(String userid)throws Exception;
	//caihao add
	public String checkConfirmEnd(String campsegId) throws Exception;

	/**
	 * 更新营销案、营销活动资源的确认人
	 * @param confirmUserid
	 * @param newConfirmUserid
	 * @param authFlag
	 * @throws Exception
	 */
	public void updateConfirmUserId(String confirmUserid, String newConfirmUserid, int authFlag) throws Exception;

	/**
	 * @param 判断某人对某一活动/营销案的所有/某一资源确认情况
	 * @param userid
	 * @return
	 * @throws Exception
	 */
	public String checkConfirmEnd(String campsegId, String userid, Integer resourceId) throws Exception;

	/**
	 * @param 取审批流程第一个审批人
	 * @return
	 * @throws Exception
	 */
	public List findCampsegApprover(MtlApproveConfirmList approver) throws Exception;

	/**
	 * @param approveFlowId
	 * @param campsegId
	 * @param confirmUserId
	 * @param token
	 * @throws Exception
	 */
	public void updateCampsegConfirmToken(String approveFlowId, String campsegId, String confirmUserId, Short seq, Short token, Integer resourceId) throws Exception;

	/**
	 * @param caihao add 2007-07-25 判断某一渠道是否有确认不通过的情况
	 * @param userid
	 * @param resourceId
	 * @return
	 * @throws Exception
	 */
	public boolean checkConfirmFailed(String campsegId, Integer resourceId) throws Exception;

	/**
	 * 更新确认审批委派记录
	 * @param approver
	 * @throws Exception
	 */
	public void updateApprover(MtlApproveConfirmList approver) throws Exception;

	/**
	 * 更新确认审批委派记录
	 * @param authUserid
	 * @param consignorUserid
	 * @param campsegId
	 * @param approveSeq
	 * @param authFlag
	 * @throws Exception
	 */
	public void updateByLevel(String authUserid, String consignorUserid, String campsegId, Short approveSeq, int authFlag) throws Exception;
	
	
	/**
	 * 查看某项资源的确认是否完成
	 * @param campsegId
	 * @param resourceId
	 * @param confirmFlag
	 * @return
	 * @throws Exception
	 */
	public boolean checkConfirmFinished(String campsegId, Short resourceId , int confirmFlag) throws Exception ;
	
	/**
	 * 更新营销确认状态
	 * @param campsegId 营销ID
	 * @param resourceId 资源ID
	 * @param confirmFlag 更新后的确认状态
	 * @throws Exception
	 */
	public void updateCampsegConfirmFlag(String campsegId, Integer resourceId, String confirmFlag) throws Exception;
	
	/**
	 * 取得确认流程的第一个确认人信息；
	 * @param campsegId
	 * @param resourceId
	 */
	public MtlApproveConfirmList getFirstApprover(String campsegId, String flowId, Integer resourceId);
	
	/**
	 * 取得当前确认人信息；
	 * @param campsegId
	 * @param flowId
	 * @param userId
	 * @param resourceId
	 * @param token
	 * @return
	 */
	public MtlApproveConfirmList getApproveConfirmList(String campsegId, String flowId, String userId, Integer resourceId, Short token);
	
	/**
	 * 校验活动是否全部确认完毕
	 * @param campsegRootid
	 * @return
	 */
	public String checkConfirmAllFinished(String campsegRootid);
	
	/**
	 * 获取活动下需要该用户确认的子活动
	 * @param campsegId
	 * @param userId
	 * @return
	 */
	public List findByCampsegIdUserId(String campsegId,String userId);
	
	/**
	 * 获取确认委派列表
	 * @return
	 * @throws Exception 
	 */
	public List<MtlApproveConfirmAppoint> getApproveConfirmAppointList() throws Exception;
	
	/**
	 * 营销活动确认委派
	 * @param campsegId 营销活动id
	 * @param userId 用户id
	 * @param delegrateUserId 确认用户id
	 * @param delegrateAdvise 委派建议
	 */
	public void updateApprover(String campsegId, String userId, String delegrateUserId, String delegrateAdvise) throws Exception;

}

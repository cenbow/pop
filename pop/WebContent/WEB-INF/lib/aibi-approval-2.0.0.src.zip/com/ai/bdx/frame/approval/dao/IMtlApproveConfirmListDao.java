package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlApproveConfirmAppoint;
import com.ai.bdx.frame.approval.model.MtlApproveConfirmList;
import java.util.List;

public abstract interface IMtlApproveConfirmListDao
{
  public abstract void save(MtlApproveConfirmList paramMtlApproveConfirmList)
    throws Exception;

  public abstract void update(MtlApproveConfirmList paramMtlApproveConfirmList)
    throws Exception;

  public abstract void delete(MtlApproveConfirmList paramMtlApproveConfirmList)
    throws Exception;

  public abstract List findByCond(MtlApproveConfirmList paramMtlApproveConfirmList)
    throws Exception;

  public abstract List findById(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Short paramShort1, Short paramShort2)
    throws Exception;

  public abstract List findCurrentById(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Short paramShort1, Short paramShort2)
    throws Exception;

  public abstract List findByUserFlag(String paramString)
    throws Exception;

  public abstract List findConfirmedByUserFlag(String paramString)
    throws Exception;

  public abstract void deleteByCampsegid(String paramString)
    throws Exception;

  public abstract List findByFlag(String paramString)
    throws Exception;

  public abstract List findByFlagGroupByUser(String paramString)
    throws Exception;

  public abstract String checkConfirmEnd(String paramString)
    throws Exception;

  public abstract void updateConfirmUserId(String paramString1, String paramString2, int paramInt)
    throws Exception;

  public abstract String checkConfirmEnd(String paramString1, String paramString2, Integer paramInteger)
    throws Exception;

  public abstract List findCampsegApprover(MtlApproveConfirmList paramMtlApproveConfirmList)
    throws Exception;

  public abstract void updateCampsegConfirmToken(String paramString1, String paramString2, String paramString3, Short paramShort1, Short paramShort2, Integer paramInteger)
    throws Exception;

  public abstract boolean checkConfirmFailed(String paramString, Integer paramInteger)
    throws Exception;

  public abstract void updateApprover(MtlApproveConfirmList paramMtlApproveConfirmList)
    throws Exception;

  public abstract void updateByLevel(String paramString1, String paramString2, String paramString3, Short paramShort, int paramInt)
    throws Exception;

  public abstract boolean checkConfirmFinished(String paramString, Short paramShort, int paramInt)
    throws Exception;

  public abstract void updateCampsegConfirmFlag(String paramString1, Integer paramInteger, String paramString2)
    throws Exception;

  public abstract MtlApproveConfirmList getFirstApprover(String paramString1, String paramString2, Integer paramInteger);

  public abstract MtlApproveConfirmList getApproveConfirmList(String paramString1, String paramString2, String paramString3, Integer paramInteger, Short paramShort);

  public abstract String checkConfirmAllFinished(String paramString);

  public abstract List findByCampsegIdUserId(String paramString1, String paramString2);

  public abstract List<MtlApproveConfirmAppoint> getApproveConfirmAppointList()
    throws Exception;

  public abstract void updateApprover(String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlApproveConfirmListDao
 * JD-Core Version:    0.6.2
 */
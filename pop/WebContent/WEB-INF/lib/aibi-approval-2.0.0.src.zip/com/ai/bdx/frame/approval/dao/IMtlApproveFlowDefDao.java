package com.ai.bdx.frame.approval.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;

/**
 * Created on Apr 26, 2007 2:40:47 PM
 * 
 * <p>
 * Title:
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: asiainfo.,Ltd
 * </p>
 * 
 * @author weilin.wu wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlApproveFlowDefDao {

	/**
	 * 获取所有审批流程定义信息
	 * 
	 * @return
	 * @throws Exception
	 */
	public List getAllApproveFlowDef() throws Exception;

	public List getAllApproveFlowDef(String userid) throws Exception;

	/**
	 * 根据流程编码审批流程定义信息
	 * 
	 * @param approveFlowId
	 * @return
	 * @throws Exception
	 */
	public MtlApproveFlowDef getApproveFlowDef(String approveFlowId)
			throws Exception;

	/**
	 * 根据审批流程编码取流程定义信息(包括每个审批级别的定义、每个审批级别的触发条件定义信息)
	 * 
	 * @param approveFlowId
	 * @return
	 * @throws Exception
	 */
	public MtlApproveFlowDef getApproveFlowDefWithAllChilds(String approveFlowId)
			throws Exception;

	/**
	 * 根据查询条件分页取审批流程定义信息
	 * 
	 * @param searchCond
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws Exception
	 */
	public Map findApproveFlow(MtlApproveFlowDef searchCond, Integer curPage,
			Integer pageSize) throws Exception;

	/**
	 * 删除审批流程定义信息
	 * 
	 * @param approveFlowId
	 * @throws Exception
	 */
	public void deleteApproveFlowDef(String approveFlowId) throws Exception;

	/**
	 * 保存审批流程定义信息
	 * 
	 * @param def
	 * @throws Exception
	 */
	public Serializable saveApproveFlowDef(MtlApproveFlowDef def)
			throws Exception;

	/**
	 * 更新审批流程定义信息
	 * 
	 * @param def
	 * @throws Exception
	 */
	public void updateApproveFlowDef(MtlApproveFlowDef def) throws Exception;

	public List getFirstApproveUser(String deptId) throws Exception;
}

package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

public abstract interface IMtlApproveFlowDefDao
{
  public abstract List getAllApproveFlowDef()
    throws Exception;

  public abstract List getAllApproveFlowDef(String paramString)
    throws Exception;

  public abstract MtlApproveFlowDef getApproveFlowDef(String paramString)
    throws Exception;

  public abstract MtlApproveFlowDef getApproveFlowDefWithAllChilds(String paramString)
    throws Exception;

  public abstract Map findApproveFlow(MtlApproveFlowDef paramMtlApproveFlowDef, Integer paramInteger1, Integer paramInteger2)
    throws Exception;

  public abstract void deleteApproveFlowDef(String paramString)
    throws Exception;

  public abstract Serializable saveApproveFlowDef(MtlApproveFlowDef paramMtlApproveFlowDef)
    throws Exception;

  public abstract void updateApproveFlowDef(MtlApproveFlowDef paramMtlApproveFlowDef)
    throws Exception;

  public abstract List getFirstApproveUser(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao
 * JD-Core Version:    0.6.2
 */
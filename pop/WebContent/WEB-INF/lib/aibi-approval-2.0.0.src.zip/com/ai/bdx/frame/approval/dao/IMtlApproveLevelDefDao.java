package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
import com.ai.bdx.frame.approval.model.MtlApproveLevelDefId;

/**
 * Created on Apr 27, 2007 2:22:27 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlApproveLevelDefDao {

	/**
	 * 根据审批流程编号、审批级别取审批级别定义信息
	 * @param flowId
	 * @param level
	 * @return
	 * @throws Exception
	 */
	public MtlApproveLevelDef getApproveLevelDef(MtlApproveLevelDefId id) throws Exception;

	/**
	 * 取审批流程下定义的所有审批级别信息
	 * @param flowId
	 * @return
	 * @throws Exception
	 */
	public List getApproveLevelDefByFlow(String flowId) throws Exception;

	/**
	 * 保存审批级别定义信息
	 * @param def
	 * @throws Exception
	 */
	public void saveApproveLevelDef(MtlApproveLevelDef def) throws Exception;

	/**
	 * 删除审批级别定义信息
	 * @param flowId
	 * @param level
	 * @throws Exception
	 */
	public void deleteApproveLevelDef(MtlApproveLevelDefId id) throws Exception;

	/**
	 * 删除审批流程下定义的所有审批级别信息
	 * @param flowId
	 * @throws Exception
	 */
	public void deleteApproveLevelDefByFlow(String flowId) throws Exception;

	/**
	 * 更新审批委派信息
	 * @param authUserid
	 * @param consingorUserid
	 * @throws Exception
	 */
	public void updateApproveLevelDef(String authUserid, String consingorUserid, int authFlag) throws Exception;
}

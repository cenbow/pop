package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
import com.ai.bdx.frame.approval.model.MtlApproveLevelDefId;
import java.util.List;

public abstract interface IMtlApproveLevelDefDao
{
  public abstract MtlApproveLevelDef getApproveLevelDef(MtlApproveLevelDefId paramMtlApproveLevelDefId)
    throws Exception;

  public abstract List getApproveLevelDefByFlow(String paramString)
    throws Exception;

  public abstract void saveApproveLevelDef(MtlApproveLevelDef paramMtlApproveLevelDef)
    throws Exception;

  public abstract void deleteApproveLevelDef(MtlApproveLevelDefId paramMtlApproveLevelDefId)
    throws Exception;

  public abstract void deleteApproveLevelDefByFlow(String paramString)
    throws Exception;

  public abstract void updateApproveLevelDef(String paramString1, String paramString2, int paramInt)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao
 * JD-Core Version:    0.6.2
 */
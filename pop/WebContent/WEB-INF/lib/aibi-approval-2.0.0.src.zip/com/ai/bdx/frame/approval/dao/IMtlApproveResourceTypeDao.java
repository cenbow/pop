package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.MtlApproveResourceTypeForm;
import com.ai.bdx.frame.approval.model.MtlApproveResourceType;
import java.util.List;
import java.util.Map;

public abstract interface IMtlApproveResourceTypeDao
{
  public abstract List findAll()
    throws Exception;

  public abstract MtlApproveResourceType getRourceById(Integer paramInteger)
    throws Exception;

  public abstract List findFlag(Integer paramInteger)
    throws Exception;

  public abstract List findByFlag(short paramShort)
    throws Exception;

  public abstract Map searchMtlApproveResourceType(MtlApproveResourceTypeForm paramMtlApproveResourceTypeForm, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void save(MtlApproveResourceType paramMtlApproveResourceType)
    throws MpmException;

  public abstract void delete(MtlApproveResourceTypeForm paramMtlApproveResourceTypeForm)
    throws MpmException;

  public abstract void update(MtlApproveResourceType paramMtlApproveResourceType)
    throws MpmException;

  public abstract MtlApproveResourceType getRourceByName(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlApproveResourceTypeDao
 * JD-Core Version:    0.6.2
 */
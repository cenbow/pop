package com.ai.bdx.frame.approval.dao;

import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.MtlApproveResourceTypeForm;
import com.ai.bdx.frame.approval.model.MtlApproveResourceType;

/**
 * Created on Oct 30, 2006 3:58:49 PM
 * 
 * <p>Title: </p>
 * <p>Description: 确认资源类型DAO接口类</p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb
 * @version 1.0
 */
public interface IMtlApproveResourceTypeDao {

	/**
	 * 查询所在有的确认资源
	 * @return
	 * @throws Exception
	 */
	public List findAll() throws Exception;

	/**
	 * 根据Id查找对应的确认资源
	 * @param resourceId
	 * @return
	 * @throws Exception
	 */
	public MtlApproveResourceType getRourceById(Integer resourceId) throws Exception;

	/**
	 * @param resourceId
	 * @return
	 * @throws Exception
	 */
	public List findFlag(Integer resourceId) throws Exception;

	/**
	 * @param resourceFlag
	 * @return
	 * @throws Exception
	 */
	public List findByFlag(short resourceFlag) throws Exception;

	/**
	 * @param 分页查询资源类型
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 */
	public Map searchMtlApproveResourceType(MtlApproveResourceTypeForm resourceForm, final Integer curPage, final Integer pageSize) throws MpmException;

	/**
	 * @param 保存
	 * @throws MpmException
	 */

	public void save(MtlApproveResourceType mtlApproveResourceType) throws MpmException;

	/**
	 * @param 删除
	 * @throws MpmException
	 */
	/**
	 * @param searchForm
	 * @throws MpmException
	 */
	public void delete(MtlApproveResourceTypeForm searchForm) throws MpmException;

	public void update(MtlApproveResourceType mtlApproveResourceType) throws MpmException;

	/**
	 * @param 根据资源名称取得资源类型信息
	 * @return
	 * @throws Exception
	 */
	public MtlApproveResourceType getRourceByName(String resourceName) throws Exception;

}

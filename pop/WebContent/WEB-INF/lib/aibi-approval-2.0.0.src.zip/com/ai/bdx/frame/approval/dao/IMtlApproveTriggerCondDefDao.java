package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDef;
import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDefId;

/**
 * Created on Apr 27, 2007 2:29:13 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlApproveTriggerCondDefDao {

	/**
	 * 根据主键取审批触发条件定义
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public MtlApproveTriggerCondDef getApproveTriggerCondDef(MtlApproveTriggerCondDefId id) throws Exception;

	/**
	 * 取审批流程中某个审批级别下定义的所有审批触发条件
	 * @param flowId
	 * @param level
	 * @return
	 * @throws Exception
	 */
	public List getApproveTriggerCondDefByFlowAndLevel(String flowId, Integer level) throws Exception;

	/**
	 * 取审批流程中定义的所有审批触发条件
	 * @param flowId
	 * @return
	 * @throws Exception
	 */
	public List getApproveTriggerCondDefByFlow(String flowId) throws Exception;

	/**
	 * 保存审批触发条件定义
	 * @param def
	 * @throws Exception
	 */
	public void saveApproveTriggerCondDef(MtlApproveTriggerCondDef def) throws Exception;

	/**
	 * 更新审批触发条件定义
	 * @param def
	 * @throws Exception
	 */
	public void updateApproveTriggerCondDef(MtlApproveTriggerCondDef def) throws Exception;

	/**
	 * 根据主键删除审批触发条件定义
	 * @param id
	 * @throws Exception
	 */
	public void deleteApproveTriggerCondDef(MtlApproveTriggerCondDefId id) throws Exception;

	/**
	 * 删除审批流程中定义的所有审批触发条件
	 * @param flowId
	 * @throws Exception
	 */
	public void deleteApproveTriggerCondDefByFlow(String flowId) throws Exception;

	/**
	 * 删除审批流程中某个审批级别下所有的审批触发条件定义
	 * @param flowId
	 * @param level
	 * @throws Exception
	 */
	public void deleteApproveTriggerCondDefByFlowAndLevel(String flowId, Integer level) throws Exception;
}

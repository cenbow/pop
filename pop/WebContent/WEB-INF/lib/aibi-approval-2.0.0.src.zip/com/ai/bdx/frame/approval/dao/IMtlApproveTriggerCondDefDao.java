package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDef;
import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDefId;
import java.util.List;

public abstract interface IMtlApproveTriggerCondDefDao
{
  public abstract MtlApproveTriggerCondDef getApproveTriggerCondDef(MtlApproveTriggerCondDefId paramMtlApproveTriggerCondDefId)
    throws Exception;

  public abstract List getApproveTriggerCondDefByFlowAndLevel(String paramString, Integer paramInteger)
    throws Exception;

  public abstract List getApproveTriggerCondDefByFlow(String paramString)
    throws Exception;

  public abstract void saveApproveTriggerCondDef(MtlApproveTriggerCondDef paramMtlApproveTriggerCondDef)
    throws Exception;

  public abstract void updateApproveTriggerCondDef(MtlApproveTriggerCondDef paramMtlApproveTriggerCondDef)
    throws Exception;

  public abstract void deleteApproveTriggerCondDef(MtlApproveTriggerCondDefId paramMtlApproveTriggerCondDefId)
    throws Exception;

  public abstract void deleteApproveTriggerCondDefByFlow(String paramString)
    throws Exception;

  public abstract void deleteApproveTriggerCondDefByFlowAndLevel(String paramString, Integer paramInteger)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondIndi;
import java.util.List;

public abstract interface IMtlApproveTriggerCondIndiDao
{
  public abstract MtlApproveTriggerCondIndi getApproveTriggerCondIndi(String paramString)
    throws Exception;

  public abstract void saveApproveTriggerCondIndi(MtlApproveTriggerCondIndi paramMtlApproveTriggerCondIndi)
    throws Exception;

  public abstract void updateApproveTriggerCondIndi(MtlApproveTriggerCondIndi paramMtlApproveTriggerCondIndi)
    throws Exception;

  public abstract void deleteApproveTriggerCondIndi(String paramString)
    throws Exception;

  public abstract List getAllApproveTriggerCondIndi()
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao
 * JD-Core Version:    0.6.2
 */
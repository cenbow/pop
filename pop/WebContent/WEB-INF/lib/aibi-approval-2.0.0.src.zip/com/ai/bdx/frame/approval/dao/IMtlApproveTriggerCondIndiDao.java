package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondIndi;

/**
 * Created on Apr 28, 2007 5:10:36 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlApproveTriggerCondIndiDao {

	/**
	 * 取指定指标编号的指标定义信息
	 * @param indiId
	 * @return
	 * @throws Exception
	 */
	public MtlApproveTriggerCondIndi getApproveTriggerCondIndi(String indiId) throws Exception;

	/**
	 * 保存指标定义信息
	 * @param indi
	 * @throws Exception
	 */
	public void saveApproveTriggerCondIndi(MtlApproveTriggerCondIndi indi) throws Exception;

	/**
	 * 更新指标定义信息
	 * @param indi
	 * @throws Exception
	 */
	public void updateApproveTriggerCondIndi(MtlApproveTriggerCondIndi indi) throws Exception;

	/**
	 * 删除指定指标编号的指标信息
	 * @param indiId
	 * @throws Exception
	 */
	public void deleteApproveTriggerCondIndi(String indiId) throws Exception;

	/**
	 * 取所有指标定义信息
	 * @return
	 * @throws Exception
	 */
	public List getAllApproveTriggerCondIndi() throws Exception;
}

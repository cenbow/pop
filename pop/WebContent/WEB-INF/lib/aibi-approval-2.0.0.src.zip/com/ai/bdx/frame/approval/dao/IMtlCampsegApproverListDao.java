package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.MtlCampsegApproverList;
import com.ai.bdx.frame.approval.model.MtlCampsegApproverListId;

/**
 * Created on May 17, 2007 1:15:28 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlCampsegApproverListDao {

	/**
	 * 更新活动波次审批人的审批令牌
	 * @param approveFlowId
	 * @param campsegId
	 * @param approveUserId
	 * @param token
	 * @throws Exception
	 */
	public void updateCampsegApproverToken(String approveFlowId, String campsegId, String approveUserId, Short seq, Short token) throws Exception;

	/**
	 * 根据主键取活动波次对应的审批人信息
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public MtlCampsegApproverList getCampsegApprover(MtlCampsegApproverListId id) throws Exception;

	/**
	 * 保存活动波次对应的审批人信息
	 * @param approver
	 * @throws Exception
	 */
	public void saveCampsegApprover(MtlCampsegApproverList approver) throws Exception;

	/**
	 * 根据主键删除活动波次对应的审批人信息
	 * @param id
	 * @throws Exception
	 */
	public void deleteCampsegApprover(MtlCampsegApproverListId id) throws Exception;

	/**
	 * 删除活动波次对应的所有审批人信息
	 * @param campsegId
	 * @throws Exception
	 */
	public void deleteCampsegApproverByCampsegId(String campsegId) throws Exception;

	/**
	 * 更新活动波次对应的审批人信息
	 * @param approver
	 * @throws Exception
	 */
	public void updateCampsegApprover(MtlCampsegApproverList approver) throws Exception;

	/**
	 * 更新活动波次的原审批人为新的审批人
	 * @param campsegId
	 * @param oldApprover
	 * @param newApprover
	 * @throws Exception
	 */
	public void updateCampsegApprover(String campsegId, String oldApprover, String newApprover) throws Exception;

	/**
	 * 根据条件查询活动波次对应的审批人信息
	 * @param approver
	 * @return
	 * @throws Exception
	 */
	public List findCampsegApprover(MtlCampsegApproverList approver) throws Exception;
	
	/**
	 * 根据条件查询活动波次对应的审批人信息
	 * @param approver
	 * @return
	 * @throws Exception
	 */
	public List findCampsegApproverList(MtlCampsegApproverList approver) throws Exception;

	/**
	 * jdbc更新记录
	 * @param approver
	 * @throws Exception
	 */
	public void updateApprover(MtlCampsegApproverList approver) throws Exception;

	/**
	 * 更新审批委派信息
	 * @param authUserid
	 * @param consignorUserid
	 * @param campsegId
	 * @param approveSeq
	 * @throws Exception
	 */
	public void updateByLevel(String authUserid, String consignorUserid, String campsegId, Short approveSeq, int authFlag) throws Exception;

	/**
	 * 
	 * @param campsegId
	 * @param approveUserid
	 * @return
	 * @throws Exception
	 */
	public List findCampsegApprover(String campsegId, String approveUserid) throws Exception;
	
	/**
	 * 获取审批信息；
	 * @param campsegId
	 * @param userId
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public MtlCampsegApproverList getCampsegApproverList(String campsegId, String userId, Short token) throws Exception;

	/**
	 * 查询都有哪些营销活动使用了此审批流程
	 * @param flowId
	 * @return
	 * @throws Exception
	 */
	public int countCampsegApproverByFlowId(String flowId) throws Exception;
	public int countCampsegApproverByFlowId1(String flowId) throws Exception;
	/**
	 * 得到第一个审批人的序号；
	 * @param campsegId
	 * @return
	 */
	public MtlCampsegApproverList getFirstApprover(String campsegId);
}

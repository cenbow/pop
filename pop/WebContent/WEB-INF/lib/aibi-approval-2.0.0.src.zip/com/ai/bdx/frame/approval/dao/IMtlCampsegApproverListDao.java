package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlCampsegApproverList;
import com.ai.bdx.frame.approval.model.MtlCampsegApproverListId;
import java.util.List;

public abstract interface IMtlCampsegApproverListDao
{
  public abstract void updateCampsegApproverToken(String paramString1, String paramString2, String paramString3, Short paramShort1, Short paramShort2)
    throws Exception;

  public abstract MtlCampsegApproverList getCampsegApprover(MtlCampsegApproverListId paramMtlCampsegApproverListId)
    throws Exception;

  public abstract void saveCampsegApprover(MtlCampsegApproverList paramMtlCampsegApproverList)
    throws Exception;

  public abstract void deleteCampsegApprover(MtlCampsegApproverListId paramMtlCampsegApproverListId)
    throws Exception;

  public abstract void deleteCampsegApproverByCampsegId(String paramString)
    throws Exception;

  public abstract void updateCampsegApprover(MtlCampsegApproverList paramMtlCampsegApproverList)
    throws Exception;

  public abstract void updateCampsegApprover(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract List findCampsegApprover(MtlCampsegApproverList paramMtlCampsegApproverList)
    throws Exception;

  public abstract List findCampsegApproverList(MtlCampsegApproverList paramMtlCampsegApproverList)
    throws Exception;

  public abstract void updateApprover(MtlCampsegApproverList paramMtlCampsegApproverList)
    throws Exception;

  public abstract void updateByLevel(String paramString1, String paramString2, String paramString3, Short paramShort, int paramInt)
    throws Exception;

  public abstract List findCampsegApprover(String paramString1, String paramString2)
    throws Exception;

  public abstract MtlCampsegApproverList getCampsegApproverList(String paramString1, String paramString2, Short paramShort)
    throws Exception;

  public abstract int countCampsegApproverByFlowId(String paramString)
    throws Exception;

  public abstract int countCampsegApproverByFlowId1(String paramString)
    throws Exception;

  public abstract MtlCampsegApproverList getFirstApprover(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao
 * JD-Core Version:    0.6.2
 */
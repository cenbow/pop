package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
import com.ai.bdx.frame.approval.model.MtlCampsegProgressId;
import java.util.List;

public abstract interface IMtlCampsegProgressDao
{
  public abstract List findCampsegProgress(MtlCampsegProgress paramMtlCampsegProgress)
    throws Exception;

  public abstract boolean findCampsegByProformResult(String paramString)
    throws Exception;

  public abstract MtlCampsegProgress getCampsegProgress(MtlCampsegProgressId paramMtlCampsegProgressId)
    throws Exception;

  public abstract MtlCampsegProgress getCampPropProgress(String paramString1, Short paramShort, String paramString2)
    throws Exception;

  public abstract void saveCampsegProgress(MtlCampsegProgress paramMtlCampsegProgress)
    throws Exception;

  public abstract void saveOrUpdateCampsegProgress(MtlCampsegProgress paramMtlCampsegProgress)
    throws Exception;

  public abstract void deleteCampsegProgress(MtlCampsegProgressId paramMtlCampsegProgressId)
    throws Exception;

  public abstract void deleteAllCampsegProgress(String paramString);

  public abstract void updateCampsegProgress(MtlCampsegProgress paramMtlCampsegProgress)
    throws Exception;

  public abstract void updateCampsegProgressResult(String paramString1, String paramString2, Short paramShort, String paramString3)
    throws Exception;

  public abstract void updateCampProgressFlag(String paramString1, String paramString2, Short[] paramArrayOfShort, Short paramShort)
    throws Exception;

  public abstract void updateCampPropProgressFlagAndResult(String paramString1, String paramString2, Short paramShort, String paramString3)
    throws Exception;

  public abstract void updateCampsegProgressFlag(String paramString1, String paramString2, Short[] paramArrayOfShort, Short paramShort)
    throws Exception;

  public abstract void updateCampsegProgressBySegid(String paramString, Short paramShort)
    throws Exception;

  public abstract Short getCampsegProgressStatus(MtlCampsegProgressId paramMtlCampsegProgressId)
    throws Exception;

  public abstract List getCampsegProgressflowstate(String paramString)
    throws Exception;

  public abstract List getCampsegProgressflow(String paramString)
    throws Exception;

  public abstract MtlCampsegProgress getCampPropProgressByseg(String paramString1, Short paramShort, String paramString2)
    throws Exception;

  public abstract MtlCampsegProgress getCampPropProgressByCond(String paramString1, Short paramShort, String paramString2)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlCampsegProgressDao
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
import com.ai.bdx.frame.approval.model.MtlCampsegProgressId;

/*
 * Created on 5:34:20 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlCampsegProgressDao {

	/**
	 * 活动步骤执行结果信息查询
	 * @param progress
	 * @return
	 * @throws Exception
	 */
	public List findCampsegProgress(MtlCampsegProgress progress) throws Exception;

	/**
	 * 查找特定执行结果的步骤信息
	 * @param proformResult
	 * @return
	 * @throws Exception
	 */
	public boolean findCampsegByProformResult(String proformResult) throws Exception;

	/**
	 * 根据主键取活动步骤(客户属性选择步骤除外)执行结果信息
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public MtlCampsegProgress getCampsegProgress(MtlCampsegProgressId id) throws Exception;

	/**
	 * 根据主键取活动在客户属性选择步骤执行的结果信息
	 * @param campId
	 * @param stepId
	 * @param flowId
	 * @return
	 * @throws Exception
	 */
	public MtlCampsegProgress getCampPropProgress(String campId, Short stepId, String flowId) throws Exception;

	/**
	 * 保存活动步骤执行结果信息
	 * @param progress
	 * @throws Exception
	 */
	public void saveCampsegProgress(MtlCampsegProgress progress) throws Exception;
	
	/**
	 * 保存或跟新活动步骤执行结果信息
	 * @param progress
	 * @throws Exception
	 */
	public void saveOrUpdateCampsegProgress(MtlCampsegProgress progress) throws Exception;

	/**
	 * 根据主键删除活动步骤执行结果信息
	 * @param id
	 * @throws Exception
	 */
	public void deleteCampsegProgress(MtlCampsegProgressId id) throws Exception;
	
	/**
	 * 删除活动步骤信息
	 * @param campsegId
	 */
	public void deleteAllCampsegProgress(String campsegId);

	/**
	 * 更新活动步骤执行的结果信息
	 * @param progress
	 * @throws Exception
	 */
	public void updateCampsegProgress(MtlCampsegProgress progress) throws Exception;

	/**
	 * 更新活动步骤执行结果信息
	 * @param campsegId
	 * @param flowId
	 * @param stepId
	 * @param result
	 * @throws Exception
	 */
	public void updateCampsegProgressResult(String campsegId, String flowId, Short stepId, String result) throws Exception;

	/**
	 * 更新活动下所有活动各个步骤的执行标示（一般是客户属性字段变更后调用此方法）
	 * @param campId
	 * @param flowId
	 * @param flag
	 * @throws Exception
	 */
	public void updateCampProgressFlag(String campId, String flowId, Short[] stepIds, Short flag) throws Exception;

	/**
	 * 更新活动下所有活动“客户属性设置”步骤的执行状态和执行结果信息
	 * @param campId
	 * @param flowId
	 * @param flag
	 * @throws Exception
	 */
	public void updateCampPropProgressFlagAndResult(String campId, String flowId, Short flag, String result) throws Exception;

	/**
	 * 更新活动某些步骤的执行状态
	 * @param campsegId
	 * @param flowId
	 * @param stepId
	 * @param flag
	 * @throws Exception
	 */
	public void updateCampsegProgressFlag(String campsegId, String flowId, Short[] stepIds, Short flag) throws Exception;

	/**
	 * 更新活动的执行状态
	 * @param campsegId
	 * @param flowId
	 * @param stepId
	 * @param flag
	 * @throws Exception
	 */
	public void updateCampsegProgressBySegid(String campsegId, Short flag) throws Exception;

	/**
	 * 获得活动中某一步骤的状态
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public Short getCampsegProgressStatus(MtlCampsegProgressId id) throws Exception;

	public List getCampsegProgressflowstate(String campsegId) throws Exception;

	/**
	 * 取客户群各步骤的执行情况
	 * @param campsegId
	 * @return
	 * @throws Exception
	 */
	public List getCampsegProgressflow(String custGroupId) throws Exception;

	/**
	 * 通过活动编号得到模板编码
	 */
	public MtlCampsegProgress getCampPropProgressByseg(String campsegId, Short stepId, String flowId) throws Exception;

	/**
	 * 通过客户群编号，步骤编号、流程名称查找
	 * @param campsegId
	 * @param stepId
	 * @param flowId
	 * @return
	 * @throws Exception
	 */
	public MtlCampsegProgress getCampPropProgressByCond(String campsegId, Short stepId, String flowId) throws Exception;
}

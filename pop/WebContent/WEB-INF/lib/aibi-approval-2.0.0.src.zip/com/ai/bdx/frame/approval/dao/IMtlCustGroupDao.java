package com.ai.bdx.frame.approval.dao;

import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCiCustMapping;
import com.ai.bdx.frame.approval.model.MtlCustGroup;

/**
 * Created on Oct 22, 2007 11:19:31 AM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlCustGroupDao {

	/**
	 * 按分页方式查询客户群信息
	 * @param custGroup
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 */
	public Map findCustGroup(MtlCustGroup custGroup, Integer curPage, Integer pageSize) throws Exception;

	/**
	 * 
	 * @param custGroup
	 * @return
	 * @throws MpmException
	 */
	public List findCustGroup(MtlCustGroup custGroup) throws Exception;

	/**
	 * 取客户群信息
	 * @param custGroupId
	 * @return
	 * @throws Exception
	 */
	public MtlCustGroup getCustGroup(String custGroupId) throws Exception;

	/**
	 * 保存客户群信息
	 * @param custGroup
	 * @throws Exception
	 */
	public String saveCustGroup(MtlCustGroup custGroup) throws Exception;

	/**
	 * 更新客户群信息
	 * @param custGroup
	 * @throws Exception
	 */
	public void updateCustGroup(MtlCustGroup custGroup) throws Exception;

	/**
	 * 更新给定map中表字段名的值
	 * @param columnAndValueMap
	 * @throws Exception
	 */
	public void updateCustGroup(Map columnAndValueMap, String custGroupId) throws Exception;

	/**
	 * 删除客户群信息
	 * @param custGroupId
	 * @param atempletId
	 * @throws Exception
	 */
	public void deleteCustGroup(String custGroupId, String atempletId) throws Exception;

	/**
	 * 判断客户群信息是否可以修改
	 * @param custGroupId
	 * @param custGroupType
	 * @return
	 * @throws Exception
	 */
	public boolean isCustGroupCanModify(String custGroupId, Short custGroupType) throws Exception;

	/**
	 * 判断客户群信息是否可以删除
	 * @param custGroupId
	 * @param custGroupType
	 * @return
	 * @throws Exception
	 */
	public boolean isCustGroupCanDelete(String custGroupId, Short custGroupType) throws Exception;

	public List findCustGroupIdByCampsegId(String CampsegId) throws Exception;

	/**
	 * 复制客户群信息
	 * @param sourceCustGroupId
	 * @param custGroupType
	 * @param newCustGroupId
	 * @throws Exception
	 */
	public void saveCustGroupCopy(String sourceCustGroupId, Short custGroupType, String newCustGroupId) throws Exception;

	/**
	 * 得到营销执行效果的反馈代码
	 * @return
	 * @throws Exception
	 */
	public List findFeedbackStatus(String feedbackStatusId, Short flagId,Short channeltypeId,String channelId) throws Exception;

	/**
	 * 根据标识获取执行反馈信息
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public List findFeedbackStatusById(String id) throws Exception;

	/**
	 * 外部系统传入营销活动编号、客户手机号码，
	 *  查询单个用户号码的历史营销活动信息
	 * @param productNo 客户号码
	 * @param promotionId 营销活动编号
	 * @param promotionTypeId 促销业务类别
	 * @param nums 取记录数目
	 * @param type 取记录类型
	 * @return 历史营销活动信息类
	 */
	public List findCustCampsegHistory(String productNo, String promotionId, String promotionTypeId, int nums, int type) throws Exception;
	
	/**
	 * 保存从CI过来的客户群ID和在MCD侧custgroup表中ID的映射关系；
	 * @param mtlCiCust
	 * @return
	 * @throws Exception
	 */
	public String saveMtlCiCustMapping(MtlCiCustMapping mtlCiCust) throws Exception;
	
	/**
	 * 由CIID得到MCD的客户群ID；
	 * @param ciCustId
	 * @return
	 * @throws Exception
	 */
	public String getMtlCustIdByCiId(String ciCustId) throws Exception;
}

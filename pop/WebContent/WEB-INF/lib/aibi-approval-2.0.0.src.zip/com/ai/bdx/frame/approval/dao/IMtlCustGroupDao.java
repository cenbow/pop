package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlCiCustMapping;
import com.ai.bdx.frame.approval.model.MtlCustGroup;
import java.util.List;
import java.util.Map;

public abstract interface IMtlCustGroupDao
{
  public abstract Map findCustGroup(MtlCustGroup paramMtlCustGroup, Integer paramInteger1, Integer paramInteger2)
    throws Exception;

  public abstract List findCustGroup(MtlCustGroup paramMtlCustGroup)
    throws Exception;

  public abstract MtlCustGroup getCustGroup(String paramString)
    throws Exception;

  public abstract String saveCustGroup(MtlCustGroup paramMtlCustGroup)
    throws Exception;

  public abstract void updateCustGroup(MtlCustGroup paramMtlCustGroup)
    throws Exception;

  public abstract void updateCustGroup(Map paramMap, String paramString)
    throws Exception;

  public abstract void deleteCustGroup(String paramString1, String paramString2)
    throws Exception;

  public abstract boolean isCustGroupCanModify(String paramString, Short paramShort)
    throws Exception;

  public abstract boolean isCustGroupCanDelete(String paramString, Short paramShort)
    throws Exception;

  public abstract List findCustGroupIdByCampsegId(String paramString)
    throws Exception;

  public abstract void saveCustGroupCopy(String paramString1, Short paramShort, String paramString2)
    throws Exception;

  public abstract List findFeedbackStatus(String paramString1, Short paramShort1, Short paramShort2, String paramString2)
    throws Exception;

  public abstract List findFeedbackStatusById(String paramString)
    throws Exception;

  public abstract List findCustCampsegHistory(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
    throws Exception;

  public abstract String saveMtlCiCustMapping(MtlCiCustMapping paramMtlCiCustMapping)
    throws Exception;

  public abstract String getMtlCustIdByCiId(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlCustGroupDao
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlProcBeat;
import com.ai.bdx.frame.approval.model.MtlProcBeatId;
import java.util.List;

public abstract interface IMtlProcBeatDao
{
  public abstract void save(MtlProcBeat paramMtlProcBeat);

  public abstract void updateBeatTime(MtlProcBeat paramMtlProcBeat);

  public abstract void updateBeatStatus(int paramInt);

  public abstract void delete(MtlProcBeat paramMtlProcBeat);

  public abstract MtlProcBeat findById(MtlProcBeatId paramMtlProcBeatId);

  public abstract List findBeatRecord();

  public abstract List findByProcId(Integer paramInteger);

  public abstract List findByExample(MtlProcBeat paramMtlProcBeat);

  public abstract List findByProperty(String paramString, Object paramObject);

  public abstract List findAll();

  public abstract MtlProcBeat merge(MtlProcBeat paramMtlProcBeat);

  public abstract void attachDirty(MtlProcBeat paramMtlProcBeat);

  public abstract void attachClean(MtlProcBeat paramMtlProcBeat);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlProcBeatDao
 * JD-Core Version:    0.6.2
 */
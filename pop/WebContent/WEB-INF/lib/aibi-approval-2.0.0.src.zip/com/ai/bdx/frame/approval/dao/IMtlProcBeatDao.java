package com.ai.bdx.frame.approval.dao;

import java.util.List;

import com.ai.bdx.frame.approval.model.MtlProcBeat;
import com.ai.bdx.frame.approval.model.MtlProcBeatId;

public interface IMtlProcBeatDao {

	public abstract void save(MtlProcBeat transientInstance);
	
	public abstract void updateBeatTime(MtlProcBeat transientInstance);
	
	public abstract void updateBeatStatus(int processId);

	public abstract void delete(MtlProcBeat persistentInstance);

	public abstract MtlProcBeat findById(MtlProcBeatId id);

	public abstract List findBeatRecord();
	
	public abstract List findByProcId(Integer procId);
	
	public abstract List findByExample(MtlProcBeat instance);

	public abstract List findByProperty(String propertyName, Object value);

	public abstract List findAll();

	public abstract MtlProcBeat merge(MtlProcBeat detachedInstance);

	public abstract void attachDirty(MtlProcBeat instance);

	public abstract void attachClean(MtlProcBeat instance);
}
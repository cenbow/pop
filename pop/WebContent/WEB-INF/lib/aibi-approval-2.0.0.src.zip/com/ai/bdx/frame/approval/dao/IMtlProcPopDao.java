package com.ai.bdx.frame.approval.dao;

import java.util.List;

import com.ai.bdx.frame.approval.model.MtlProcPop;
import com.ai.bdx.frame.approval.model.MtlProcPopId;

public interface IMtlProcPopDao {

	public abstract void save(MtlProcPop transientInstance);

	public abstract void delete(MtlProcPop persistentInstance);

	public abstract MtlProcPop findById(MtlProcPopId id);
	
	public abstract List findPopRecord(final Integer procId);

	public abstract List findByExample(MtlProcPop instance);

	public abstract List findByProperty(String propertyName, Object value);

	public abstract List findAll();

	public abstract MtlProcPop merge(MtlProcPop detachedInstance);

	public abstract void attachDirty(MtlProcPop instance);

	public abstract void attachClean(MtlProcPop instance);

}
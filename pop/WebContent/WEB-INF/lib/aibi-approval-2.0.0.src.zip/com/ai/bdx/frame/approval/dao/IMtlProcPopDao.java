package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlProcPop;
import com.ai.bdx.frame.approval.model.MtlProcPopId;
import java.util.List;

public abstract interface IMtlProcPopDao
{
  public abstract void save(MtlProcPop paramMtlProcPop);

  public abstract void delete(MtlProcPop paramMtlProcPop);

  public abstract MtlProcPop findById(MtlProcPopId paramMtlProcPopId);

  public abstract List findPopRecord(Integer paramInteger);

  public abstract List findByExample(MtlProcPop paramMtlProcPop);

  public abstract List findByProperty(String paramString, Object paramObject);

  public abstract List findAll();

  public abstract MtlProcPop merge(MtlProcPop paramMtlProcPop);

  public abstract void attachDirty(MtlProcPop paramMtlProcPop);

  public abstract void attachClean(MtlProcPop paramMtlProcPop);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlProcPopDao
 * JD-Core Version:    0.6.2
 */
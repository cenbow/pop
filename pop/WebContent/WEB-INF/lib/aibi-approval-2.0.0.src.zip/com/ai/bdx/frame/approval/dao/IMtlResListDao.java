package com.ai.bdx.frame.approval.dao;

import com.ai.bdx.frame.approval.model.MtlResList;
import java.util.List;

public abstract interface IMtlResListDao
{
  public abstract List getResObjList();

  public abstract List getResFlackObjList();

  public abstract List getResEntityObjList();

  public abstract String save(MtlResList paramMtlResList)
    throws Exception;

  public abstract void update(MtlResList paramMtlResList)
    throws Exception;

  public abstract void delete(String paramString)
    throws Exception;

  public abstract MtlResList findByCode(String paramString1, String paramString2)
    throws Exception;

  public abstract List findByCostCode(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlResListDao
 * JD-Core Version:    0.6.2
 */
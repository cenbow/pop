package com.ai.bdx.frame.approval.dao;


import java.util.List;

import com.ai.bdx.frame.approval.model.MtlResList;

public interface IMtlResListDao {

	public List getResObjList();

	/**
	 * 返回宣传物品列表
	 * @return
	 */
	public List getResFlackObjList();

	/**
	 * 返回馈赠实物列表
	 * @return
	 */
	public List getResEntityObjList();

	/**
	 * 插入一条实体记录
	 * @param mtlResList
	 * @return
	 * @throws Exception
	 */
	public String save(MtlResList mtlResList) throws Exception;

	/**
	 * 修改一条实体记录
	 * @param mtlResList
	 * @throws Exception
	 */
	public void update(MtlResList mtlResList) throws Exception;

	/**
	 * 删除一条实体记录
	 * @param resCode
	 * @throws Exception
	 */
	public void delete(String resCode) throws Exception;

	/**
	 * 跟踪实体标识和实体标志返回一条实体信息
	 * @param resCode
	 * @param resFlag
	 * @return
	 * @throws Exception
	 */
	public MtlResList findByCode(String resCode, String resFlag) throws Exception;

	/**
	 * 根据成本类型返回实体信息集合
	 * @param costCode
	 * @return
	 * @throws Exception
	 */
	public List findByCostCode(String costCode) throws Exception;
}

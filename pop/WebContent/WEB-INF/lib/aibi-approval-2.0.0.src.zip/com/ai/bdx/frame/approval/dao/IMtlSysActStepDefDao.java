package com.ai.bdx.frame.approval.dao;

import java.util.List;

public abstract interface IMtlSysActStepDefDao
{
  public abstract List<?> getSysActStepAll()
    throws Exception;

  public abstract String getSysActStepArray()
    throws Exception;

  public abstract String getExistsStepArray(String paramString)
    throws Exception;

  public abstract List<?> getSysActStepDefByFlowId(String paramString, Short paramShort)
    throws Exception;

  public abstract List<?> getHandChgStatusAct(String paramString)
    throws Exception;

  public abstract String getSegArray(String paramString)
    throws Exception;

  public abstract String getSegStepArray(String paramString)
    throws Exception;

  public abstract List<?> getSegCanStatus(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract boolean updateCampsegStatus(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract boolean deleteCampseg(String paramString1, String paramString2)
    throws Exception;

  public abstract boolean deleteCamp(String paramString)
    throws Exception;

  public abstract boolean insertCampsegBak(String paramString)
    throws Exception;

  public abstract boolean insertCampBak(String paramString)
    throws Exception;

  public abstract boolean getCampsegStatus(String paramString)
    throws Exception;

  public abstract boolean updateCampStatus(String paramString1, String paramString2)
    throws Exception;

  public abstract boolean updateCampsegApproveResult(String paramString)
    throws Exception;

  public abstract boolean updateCampApproveResult(String paramString)
    throws Exception;

  public abstract boolean updateCampsegApproveNums(String paramString)
    throws Exception;

  public abstract boolean updateCampSegConfirmFlag(String paramString, short paramShort)
    throws Exception;

  public abstract boolean updateCampConfirmFlag(String paramString, short paramShort)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.IMtlSysActStepDefDao
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao;

import java.util.List;

/*
 * Created on 3:44:39 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlSysActStepDefDao {

	// public MtlSysActstepDef getSysActStepDef(Short stepId) throws Exception;
	// public MtlStatChangeHist saveSegHis(MtlStatChangeHist mtlStatChangeHist)
	// throws Exception;
	
	
	public List<?> getSysActStepAll() throws Exception;

	public String getSysActStepArray() throws Exception;

	public String getExistsStepArray(String flowId) throws Exception;

	public List<?> getSysActStepDefByFlowId(String flowId, Short stepPhase)
			throws Exception;

	public List<?> getHandChgStatusAct(String createUserid) throws Exception;

	public String getSegArray(String createUserid) throws Exception;

	public String getSegStepArray(String campseg_id) throws Exception;

	public List<?> getSegCanStatus(String campId, String campsegId,
			String campsegStatId) throws Exception;

	public boolean updateCampsegStatus(String campId, String campsegId,
			String campsegStatId) throws Exception;

	public boolean deleteCampseg(String campId, String campsegId)
			throws Exception;

	public boolean deleteCamp(String campId) throws Exception;

	public boolean insertCampsegBak(String campId) throws Exception;

	public boolean insertCampBak(String campId) throws Exception;

	public boolean getCampsegStatus(String campId) throws Exception;

	public boolean updateCampStatus(String campId, String campStatus)
			throws Exception;

	public boolean updateCampsegApproveResult(String campsegId)
			throws Exception;

	public boolean updateCampApproveResult(String campsegId) throws Exception;

	public boolean updateCampsegApproveNums(String campsegId) throws Exception;

	public boolean updateCampSegConfirmFlag(String campsegId,
			short campsegConfrimFlag) throws Exception;

	public boolean updateCampConfirmFlag(String campId, short campsegConfrimFlag)
			throws Exception;

}

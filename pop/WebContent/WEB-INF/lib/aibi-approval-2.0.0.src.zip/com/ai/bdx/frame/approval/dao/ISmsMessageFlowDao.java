package com.ai.bdx.frame.approval.dao;

import java.util.List;

import com.ai.bdx.frame.approval.model.SmsMessageFlowId;

/**
 * 短息发送Dao
 * @author guoyj
 *
 */
public interface ISmsMessageFlowDao {

	public void saveSMSFlow(SmsMessageFlowId smsMessage) throws Exception;

	public void saveSMSFlowBatch(List<SmsMessageFlowId> msgList) throws Exception;

	public List getCustNumber() throws Exception;

}

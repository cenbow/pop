/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.bean.ApApproveList;
/*     */ import com.ai.bdx.frame.approval.bean.ApproveLevelDef;
/*     */ import com.ai.bdx.frame.approval.bean.ApproveRelation;
/*     */ import com.ai.bdx.frame.approval.bean.ApproveTriggerCondDef;
/*     */ import com.ai.bdx.frame.approval.dao.ApprovalDao;
/*     */ import com.ai.bdx.frame.approval.util.ApprovalCONST;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.transform.Transformers;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class ApprovalDaoImpl extends HibernateDaoSupport
/*     */   implements ApprovalDao
/*     */ {
/*     */   public List<?> getObjectsBySQL(String sql, Map<String, Object> params)
/*     */     throws Exception
/*     */   {
/*  34 */     SQLQuery sqlQuery = getSession().createSQLQuery(sql);
/*  35 */     if ((params != null) && (params.size() > 0)) {
/*  36 */       for (Map.Entry entry : params.entrySet()) {
/*  37 */         sqlQuery.setParameter((String)entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/*  40 */     List list = sqlQuery.list();
/*  41 */     return list;
/*     */   }
/*     */ 
/*     */   public List<?> getObjectsByHQL(String hql, Map<String, Object> params)
/*     */     throws Exception
/*     */   {
/*  55 */     Query query = getSession().createQuery(hql);
/*  56 */     if ((params != null) && (params.size() > 0)) {
/*  57 */       for (Map.Entry entry : params.entrySet()) {
/*  58 */         query.setParameter((String)entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/*  61 */     return query.list();
/*     */   }
/*     */ 
/*     */   public int executeBySQL(String sql, Map<String, Object> params)
/*     */     throws Exception
/*     */   {
/*  75 */     SQLQuery sqlQuery = getSession().createSQLQuery(sql);
/*  76 */     if ((params != null) && (params.size() > 0)) {
/*  77 */       for (Map.Entry entry : params.entrySet()) {
/*  78 */         sqlQuery.setParameter((String)entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/*  81 */     return sqlQuery.executeUpdate();
/*     */   }
/*     */ 
/*     */   public int saveApprovalList(String sql, List<ApApproveList> list)
/*     */     throws Exception
/*     */   {
/*  93 */     int result = 0;
/*  94 */     if ((list != null) && (list.size() > 0)) {
/*  95 */       SQLQuery sqlQuery = getSession().createSQLQuery(sql);
/*  96 */       for (int i = 0; i < list.size(); i++) {
/*  97 */         ApApproveList ap = (ApApproveList)list.get(i);
/*     */ 
/* 102 */         sqlQuery.setParameter(0, ap.getApproval_id());
/* 103 */         sqlQuery.setParameter(1, ap.getApprove_flow_id());
/* 104 */         sqlQuery.setParameter(2, ap.getApprove_seq());
/* 105 */         sqlQuery.setParameter(3, ap.getApprove_level());
/* 106 */         sqlQuery.setParameter(4, ap.getApprove_userid());
/* 107 */         sqlQuery.setParameter(5, ap.getApprove_token());
/* 108 */         sqlQuery.setParameter(6, ap.getApprove_advice());
/* 109 */         sqlQuery.setParameter(7, ap.getAuth_flag());
/* 110 */         sqlQuery.setParameter(8, ap.getRemind_date());
/* 111 */         sqlQuery.setParameter(9, ap.getForecast_date());
/* 112 */         sqlQuery.setParameter(10, ap.getApprove_flag());
/* 113 */         sqlQuery.setParameter(11, ap.getConfirm_explain());
/* 114 */         sqlQuery.setParameter(10, ap.getUpdate_time());
/* 115 */         sqlQuery.setParameter(10, ap.getApprove_type());
/*     */ 
/* 117 */         int count = sqlQuery.executeUpdate();
/* 118 */         result += count;
/*     */       }
/*     */     }
/* 121 */     return result;
/*     */   }
/*     */ 
/*     */   public List<ApproveLevelDef> getApprovalListByFlowId(String flowId)
/*     */     throws Exception
/*     */   {
/* 133 */     String sql = "select * from ap_approve_level_def where approve_flow_id=:approve_flow_id order by approve_level asc";
/* 134 */     SQLQuery q = getSession().createSQLQuery(sql);
/* 135 */     q.setParameter("approve_flow_id", flowId);
/*     */ 
/* 137 */     q.addScalar("approve_level", Hibernate.INTEGER);
/* 138 */     q.addScalar("approve_flow_id", Hibernate.STRING);
/* 139 */     q.addScalar("approve_obj_type", Hibernate.INTEGER);
/* 140 */     q.addScalar("approve_obj_id", Hibernate.STRING);
/* 141 */     q.addScalar("auth_flag", Hibernate.INTEGER);
/* 142 */     q.setResultTransformer(Transformers.aliasToBean(ApproveLevelDef.class));
/* 143 */     List list = q.list();
/* 144 */     return list;
/*     */   }
/*     */ 
/*     */   public ApproveRelation findByUserDeptId(String deptId, String approveUserid)
/*     */     throws Exception
/*     */   {
/* 156 */     StringBuffer sql = new StringBuffer("select * from ap_approve_relation where 1=1");
/* 157 */     Map p = new HashMap();
/* 158 */     if (StringUtil.isNotEmpty(deptId)) {
/* 159 */       sql.append(" and deptid=:deptid");
/* 160 */       p.put("deptid", deptId);
/*     */     }
/* 162 */     if (StringUtil.isNotEmpty(approveUserid)) {
/* 163 */       sql.append(" and approve_userid=:approve_userid");
/* 164 */       p.put("approve_userid", approveUserid);
/*     */     }
/* 166 */     SQLQuery sqlQuery = getSession().createSQLQuery(sql.toString());
/* 167 */     if ((p != null) && (p.size() > 0)) {
/* 168 */       for (Map.Entry entry : p.entrySet()) {
/* 169 */         sqlQuery.setParameter((String)entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/* 172 */     sqlQuery.addScalar("approve_userid", Hibernate.STRING);
/* 173 */     sqlQuery.addScalar("deptid", Hibernate.INTEGER);
/* 174 */     sqlQuery.addScalar("approve_create_userid", Hibernate.STRING);
/* 175 */     sqlQuery.addScalar("create_time", Hibernate.DATE);
/* 176 */     sqlQuery.addScalar("position_id", Hibernate.INTEGER);
/* 177 */     sqlQuery.addScalar("approve_userid_email", Hibernate.STRING);
/* 178 */     sqlQuery.addScalar("approve_userid_msisdn", Hibernate.STRING);
/* 179 */     sqlQuery.addScalar("cityid", Hibernate.STRING);
/* 180 */     sqlQuery.addScalar("auth_flag", Hibernate.INTEGER);
/* 181 */     sqlQuery.setResultTransformer(Transformers.aliasToBean(ApproveRelation.class));
/* 182 */     List list = sqlQuery.list();
/* 183 */     if ((list != null) && (list.size() > 0)) {
/* 184 */       return (ApproveRelation)list.get(0);
/*     */     }
/* 186 */     return null;
/*     */   }
/*     */ 
/*     */   public int saveApApproveList(ApApproveList ap)
/*     */     throws Exception
/*     */   {
/* 197 */     String sql = " insert into ap_approve_list(approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type,create_time)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
/* 198 */     if (ap != null) {
/* 199 */       SQLQuery sqlQuery = getSession().createSQLQuery(sql);
/*     */ 
/* 203 */       sqlQuery.setParameter(0, ap.getApproval_id());
/* 204 */       sqlQuery.setParameter(1, ap.getApprove_flow_id());
/* 205 */       sqlQuery.setParameter(2, ap.getApprove_seq());
/* 206 */       sqlQuery.setParameter(3, ap.getApprove_level());
/* 207 */       sqlQuery.setParameter(4, ap.getApprove_userid());
/* 208 */       sqlQuery.setParameter(5, ap.getApprove_token());
/* 209 */       sqlQuery.setParameter(6, ap.getApprove_advice());
/* 210 */       sqlQuery.setParameter(7, ap.getAuth_flag());
/* 211 */       sqlQuery.setParameter(8, ap.getRemind_date());
/* 212 */       sqlQuery.setParameter(9, ap.getForecast_date());
/* 213 */       sqlQuery.setParameter(10, ap.getApprove_flag());
/* 214 */       sqlQuery.setParameter(11, ap.getConfirm_explain());
/* 215 */       sqlQuery.setParameter(12, ap.getUpdate_time());
/* 216 */       sqlQuery.setParameter(13, ap.getApprove_type());
/* 217 */       sqlQuery.setParameter(14, ap.getCreate_time());
/* 218 */       int count = sqlQuery.executeUpdate();
/* 219 */       return count;
/*     */     }
/* 221 */     return 0;
/*     */   }
/*     */ 
/*     */   public List<?> getApproveTriggerCondDefByFlowAndLevel(String approvalFlowId, Integer approve_level) throws Exception
/*     */   {
/* 226 */     String sql = "select approve_level,approve_flow_id,approve_trigger_cond_id,cond_indi_id,cond_operator,cond_indi_value,approve_obj_type,approve_obj_id,approve_trigger_cond_pri from ap_approve_trigger_cond_def where 1=1 and approve_level=:approve_level and approve_flow_id=:approve_flow_id  order by approve_level,approve_trigger_cond_id";
/* 227 */     SQLQuery sqlQuery = getSession().createSQLQuery(sql);
/* 228 */     sqlQuery.setParameter("approve_level", approve_level);
/* 229 */     sqlQuery.setParameter("approve_flow_id", approvalFlowId);
/* 230 */     sqlQuery.addEntity(ApproveTriggerCondDef.class);
/* 231 */     List list = sqlQuery.list();
/* 232 */     return list;
/*     */   }
/*     */ 
/*     */   public List<ApApproveList> getApprovalProcess(String approvalId, String approvalType, String approvalToken) throws Exception
/*     */   {
/* 237 */     String sql = "select approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type from ap_approve_list a where a.approval_id=:approval_id ";
/* 238 */     if (StringUtil.isNotEmpty(approvalType)) {
/* 239 */       sql = sql + " and a.approve_type=:approve_type ";
/*     */     }
/* 241 */     if (StringUtil.isNotEmpty(approvalToken)) {
/* 242 */       sql = sql + " and a.approve_token=:approve_token ";
/*     */     }
/* 244 */     sql = sql + " order by a.approve_seq,a.approve_level asc";
/* 245 */     SQLQuery q = getSession().createSQLQuery(sql);
/* 246 */     q.setParameter("approval_id", approvalId);
/* 247 */     if (StringUtil.isNotEmpty(approvalType)) {
/* 248 */       q.setParameter("approve_type", approvalType);
/*     */     }
/* 250 */     if (StringUtil.isNotEmpty(approvalToken)) {
/* 251 */       q.setParameter("approve_token", approvalToken);
/*     */     }
/* 253 */     q.addScalar("approval_id", Hibernate.STRING);
/* 254 */     q.addScalar("approve_flow_id", Hibernate.STRING);
/* 255 */     q.addScalar("approve_seq", Hibernate.INTEGER);
/* 256 */     q.addScalar("approve_level", Hibernate.INTEGER);
/* 257 */     q.addScalar("approve_userid", Hibernate.STRING);
/* 258 */     q.addScalar("approve_token", Hibernate.INTEGER);
/* 259 */     q.addScalar("approve_advice", Hibernate.STRING);
/* 260 */     q.addScalar("auth_flag", Hibernate.INTEGER);
/* 261 */     q.addScalar("remind_date", Hibernate.STRING);
/* 262 */     q.addScalar("forecast_date", Hibernate.STRING);
/* 263 */     q.addScalar("approve_flag", Hibernate.STRING);
/* 264 */     q.addScalar("confirm_explain", Hibernate.STRING);
/* 265 */     q.addScalar("update_time", Hibernate.DATE);
/* 266 */     q.addScalar("approve_type", Hibernate.STRING);
/* 267 */     q.setResultTransformer(Transformers.aliasToBean(ApApproveList.class));
/* 268 */     List list = q.list();
/* 269 */     return list;
/*     */   }
/*     */ 
/*     */   public Integer getMaxApprovalSeq(String approvalId, String approvalType) throws Exception
/*     */   {
/* 274 */     String sql = "select max(a.approve_seq) approve_seq from ap_approve_list a where a.approval_id=:approval_id and a.approve_type=:approve_type ";
/* 275 */     SQLQuery sqlQuery = getSession().createSQLQuery(sql);
/* 276 */     sqlQuery.setParameter("approval_id", approvalId);
/* 277 */     sqlQuery.setParameter("approve_type", approvalType);
/* 278 */     List list = sqlQuery.list();
/* 279 */     if ((list != null) && (list.size() > 0)) {
/* 280 */       Integer max = (Integer)list.get(0);
/* 281 */       return max;
/*     */     }
/* 283 */     return null;
/*     */   }
/*     */ 
/*     */   public String getApproveDrvType(String drvTypeID, String drvID) throws Exception
/*     */   {
/* 288 */     String sql = "select flow_id from ap_approve_drv_type where table_id=:table_id and table_col_val =:table_col_val";
/* 289 */     SQLQuery sqlQuery = getSession().createSQLQuery(sql);
/* 290 */     sqlQuery.setParameter("table_id", drvTypeID);
/* 291 */     sqlQuery.setParameter("table_col_val", drvID);
/* 292 */     List list = sqlQuery.list();
/* 293 */     if ((list != null) && (list.size() > 0)) {
/* 294 */       return (String)list.get(0);
/*     */     }
/* 296 */     return null;
/*     */   }
/*     */ 
/*     */   public List<ApApproveList> getFirstApprovalOrConfimUser(String approvalId, String approve_type)
/*     */     throws Exception
/*     */   {
/* 316 */     String sql = "select approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type from ap_approve_list a where  a.approve_level=(select min(a.approve_level) from ap_approve_list a where a.approval_id =:approval_id1  and a.approve_type =:approve_type1) and a.approval_id=:approval_id and a.approve_type=:approve_type order by a.approve_seq,a.approve_level asc";
/* 317 */     SQLQuery q = getSession().createSQLQuery(sql);
/* 318 */     q.setParameter("approval_id1", approvalId);
/* 319 */     q.setParameter("approve_type1", approve_type);
/* 320 */     q.setParameter("approval_id", approvalId);
/* 321 */     q.setParameter("approve_type", approve_type);
/*     */ 
/* 324 */     q.addScalar("approval_id", Hibernate.STRING);
/* 325 */     q.addScalar("approve_flow_id", Hibernate.STRING);
/* 326 */     q.addScalar("approve_seq", Hibernate.INTEGER);
/* 327 */     q.addScalar("approve_level", Hibernate.INTEGER);
/* 328 */     q.addScalar("approve_userid", Hibernate.STRING);
/* 329 */     q.addScalar("approve_token", Hibernate.INTEGER);
/* 330 */     q.addScalar("approve_advice", Hibernate.STRING);
/* 331 */     q.addScalar("auth_flag", Hibernate.INTEGER);
/* 332 */     q.addScalar("remind_date", Hibernate.STRING);
/* 333 */     q.addScalar("forecast_date", Hibernate.STRING);
/* 334 */     q.addScalar("approve_flag", Hibernate.STRING);
/* 335 */     q.addScalar("confirm_explain", Hibernate.STRING);
/* 336 */     q.addScalar("update_time", Hibernate.DATE);
/* 337 */     q.addScalar("approve_type", Hibernate.STRING);
/* 338 */     q.setResultTransformer(Transformers.aliasToBean(ApApproveList.class));
/* 339 */     List list = q.list();
/* 340 */     return list;
/*     */   }
/*     */ 
/*     */   public List<ApApproveList> getNextApprovalProcess(ApApproveList currentApproveList)
/*     */     throws Exception
/*     */   {
/* 355 */     String sql = "select approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type from ap_approve_list a where a.approval_id=:approval_id and a.approve_type=:approve_type and a.approve_level=:approve_level and a.approve_flow_id=:approve_flow_id  order by a.approve_seq,a.approve_level asc";
/*     */ 
/* 362 */     SQLQuery q = getSession().createSQLQuery(sql);
/* 363 */     q.setParameter("approval_id", currentApproveList.getApproval_id());
/* 364 */     q.setParameter("approve_type", currentApproveList.getApprove_type());
/* 365 */     q.setParameter("approve_level", Integer.valueOf(currentApproveList.getApprove_level() == null ? 0 : currentApproveList.getApprove_level().intValue() + 1));
/* 366 */     q.setParameter("approve_flow_id", currentApproveList.getApprove_flow_id());
/*     */ 
/* 369 */     q.addScalar("approval_id", Hibernate.STRING);
/* 370 */     q.addScalar("approve_flow_id", Hibernate.STRING);
/* 371 */     q.addScalar("approve_seq", Hibernate.INTEGER);
/* 372 */     q.addScalar("approve_level", Hibernate.INTEGER);
/* 373 */     q.addScalar("approve_userid", Hibernate.STRING);
/* 374 */     q.addScalar("approve_token", Hibernate.INTEGER);
/* 375 */     q.addScalar("approve_advice", Hibernate.STRING);
/* 376 */     q.addScalar("auth_flag", Hibernate.INTEGER);
/* 377 */     q.addScalar("remind_date", Hibernate.STRING);
/* 378 */     q.addScalar("forecast_date", Hibernate.STRING);
/* 379 */     q.addScalar("approve_flag", Hibernate.STRING);
/* 380 */     q.addScalar("confirm_explain", Hibernate.STRING);
/* 381 */     q.addScalar("update_time", Hibernate.DATE);
/* 382 */     q.addScalar("approve_type", Hibernate.STRING);
/* 383 */     q.setResultTransformer(Transformers.aliasToBean(ApApproveList.class));
/* 384 */     List list = q.list();
/* 385 */     return list;
/*     */   }
/*     */ 
/*     */   public int updateApprovalToken(String approvalId, String approvalType, Integer approvalToken, Integer currentApprovalSeq, String approve_flow_id, Integer approve_level, String approve_userid)
/*     */     throws Exception
/*     */   {
/* 406 */     String sql = "update ap_approve_list a set a.approve_token=:approve_token  where a.approval_id=:approval_id and a.approve_flow_id=:approve_flow_id and  a.approve_seq=:approve_seq and a.approve_level=:approve_level and a.approve_type=:approve_type and a.approve_userid=:approve_userid";
/*     */ 
/* 409 */     SQLQuery q = getSession().createSQLQuery(sql);
/* 410 */     q.setParameter("approve_token", approvalToken);
/* 411 */     q.setParameter("approval_id", approvalId);
/* 412 */     q.setParameter("approve_flow_id", approve_flow_id);
/* 413 */     q.setParameter("approve_seq", currentApprovalSeq);
/* 414 */     q.setParameter("approve_level", approve_level);
/* 415 */     q.setParameter("approve_type", approvalType);
/* 416 */     q.setParameter("approve_userid", approve_userid);
/* 417 */     return q.executeUpdate();
/*     */   }
/*     */ 
/*     */   public int updateApprovalFlag(String approvalId, String approvalType, String approve_flag, Integer currentApprovalSeq, String approve_flow_id, Integer approve_level, String approve_userid)
/*     */     throws Exception
/*     */   {
/* 434 */     String sql = "update ap_approve_list a set a.approve_flag=:approve_flag,update_time=:update_time  where a.approval_id=:approval_id and a.approve_flow_id=:approve_flow_id and  a.approve_seq=:approve_seq and a.approve_level=:approve_level and a.approve_type=:approve_type and a.approve_userid=:approve_userid";
/*     */ 
/* 437 */     SQLQuery q = getSession().createSQLQuery(sql);
/* 438 */     q.setParameter("approve_flag", approve_flag);
/* 439 */     q.setParameter("update_time", new Date());
/*     */ 
/* 441 */     q.setParameter("approval_id", approvalId);
/* 442 */     q.setParameter("approve_flow_id", approve_flow_id);
/* 443 */     q.setParameter("approve_seq", currentApprovalSeq);
/* 444 */     q.setParameter("approve_level", approve_level);
/* 445 */     q.setParameter("approve_type", approvalType);
/* 446 */     q.setParameter("approve_userid", approve_userid);
/* 447 */     return q.executeUpdate();
/*     */   }
/*     */ 
/*     */   public List<?> getSampleLevelApproverByCurrentApproval(ApApproveList currentApproval)
/*     */     throws Exception
/*     */   {
/* 460 */     String sql = "select approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type from ap_approve_list a where a.approval_id=:approval_id and a.approve_type=:approve_type and a.approve_flow_id=:approve_flow_id and a.approve_level=:approve_level and a.approve_token=:approve_token order by a.approve_seq,a.approve_level asc";
/*     */ 
/* 463 */     SQLQuery q = getSession().createSQLQuery(sql);
/* 464 */     q.setParameter("approval_id", currentApproval.getApproval_id());
/* 465 */     q.setParameter("approve_type", currentApproval.getApprove_type());
/* 466 */     q.setParameter("approve_level", Integer.valueOf(currentApproval.getApprove_level() == null ? 1 : currentApproval.getApprove_level().intValue()));
/* 467 */     q.setParameter("approve_flow_id", currentApproval.getApprove_flow_id());
/* 468 */     q.setParameter("approve_token", ApprovalCONST.APPROVE_TOKEN_HOLD);
/*     */ 
/* 471 */     q.addScalar("approval_id", Hibernate.STRING);
/* 472 */     q.addScalar("approve_flow_id", Hibernate.STRING);
/* 473 */     q.addScalar("approve_seq", Hibernate.INTEGER);
/* 474 */     q.addScalar("approve_level", Hibernate.INTEGER);
/* 475 */     q.addScalar("approve_userid", Hibernate.STRING);
/* 476 */     q.addScalar("approve_token", Hibernate.INTEGER);
/* 477 */     q.addScalar("approve_advice", Hibernate.STRING);
/* 478 */     q.addScalar("auth_flag", Hibernate.INTEGER);
/* 479 */     q.addScalar("remind_date", Hibernate.STRING);
/* 480 */     q.addScalar("forecast_date", Hibernate.STRING);
/* 481 */     q.addScalar("approve_flag", Hibernate.STRING);
/* 482 */     q.addScalar("confirm_explain", Hibernate.STRING);
/* 483 */     q.addScalar("update_time", Hibernate.DATE);
/* 484 */     q.addScalar("approve_type", Hibernate.STRING);
/* 485 */     q.setResultTransformer(Transformers.aliasToBean(ApApproveList.class));
/* 486 */     List list = q.list();
/* 487 */     return list;
/*     */   }
/*     */ 
/*     */   public List<String> getCurrentApproversByApprovalID(String approvalID)
/*     */     throws Exception
/*     */   {
/* 500 */     String sql = "select a.approve_userid from ap_approve_list a where  1=1 and a.approval_id=:approval_id and a.approve_token=:approve_token";
/* 501 */     SQLQuery q = getSession().createSQLQuery(sql);
/* 502 */     q.setParameter("approval_id", approvalID);
/* 503 */     q.setParameter("approve_token", ApprovalCONST.APPROVE_TOKEN_HOLD);
/* 504 */     return q.list();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.ApprovalDaoImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.bean.ApApproveList;
import com.ai.bdx.frame.approval.bean.ApproveLevelDef;
import com.ai.bdx.frame.approval.bean.ApproveRelation;
import com.ai.bdx.frame.approval.bean.ApproveTriggerCondDef;
import com.ai.bdx.frame.approval.dao.ApprovalDao;
import com.ai.bdx.frame.approval.util.ApprovalCONST;
import com.asiainfo.biframe.utils.string.StringUtil;

public class ApprovalDaoImpl extends HibernateDaoSupport implements ApprovalDao {

    /**
     * 
     * getObjectsBySQL:根据sql查询对象列表
     * @param sql
     * @param params
     * @return
     * @throws PopException 
     * @see com.ai.bdx.pop.dao.ApprovalDao#getObjectsBySQL(java.lang.String, java.util.Map)
     */
	public List<?> getObjectsBySQL(String sql, Map<String, Object> params)
			throws Exception {
		SQLQuery sqlQuery=this.getSession().createSQLQuery(sql);
		if(params!=null&&params.size()>0){
			for (Map.Entry<String, Object> entry : params.entrySet()) {
				sqlQuery.setParameter(entry.getKey(), entry.getValue());
			}
		}
		List<?> list=sqlQuery.list();
		return list;
	}

	/**
	 * 
	 * getObjectsByHQL:根据hql查询对象列表
	 * @param hql
	 * @param params
	 * @return
	 * @throws PopException 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#getObjectsByHQL(java.lang.String, java.util.Map)
	 */
	public List<?> getObjectsByHQL(String hql, Map<String, Object> params)
			throws Exception {
		Query query=this.getSession().createQuery(hql);
		if(params!=null&&params.size()>0){
			for (Map.Entry<String, Object> entry : params.entrySet()) {
				query.setParameter(entry.getKey(), entry.getValue());
			}
		}
		return query.list();
	}

	/**
	 * 
	 * executeBySQL:执行sql
	 * @param sql
	 * @param params
	 * @return
	 * @throws PopException 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#executeBySQL(java.lang.String, java.util.Map)
	 */
	public int executeBySQL(String sql, Map<String, Object> params)
			throws Exception {
		SQLQuery sqlQuery=this.getSession().createSQLQuery(sql);
		if(params!=null&&params.size()>0){
			for (Map.Entry<String, Object> entry : params.entrySet()) {
				sqlQuery.setParameter(entry.getKey(), entry.getValue());
			}
		}
		return sqlQuery.executeUpdate();
	}
    /**
     * 
     * saveApprovalList:保存列表
     * @param sql
     * @param list
     * @return
     * @throws PopException 
     * @see com.ai.bdx.pop.dao.ApprovalDao#saveApprovalList(java.lang.String, java.util.List)
     */
 	public int saveApprovalList(String sql, List<ApApproveList> list)throws Exception {
 		int result=0;
 		if(list!=null&&list.size()>0){
 			SQLQuery sqlQuery=this.getSession().createSQLQuery(sql);
 			for(int i=0;i<list.size();i++){
 				ApApproveList ap=list.get(i);
 				//approval_id,approve_flow_id,approve_seq,approve_level,
 				//approve_userid,approve_token,approve_advice,auth_flag,
 				//remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type
 				
 				sqlQuery.setParameter(0, ap.getApproval_id());
 				sqlQuery.setParameter(1, ap.getApprove_flow_id());
 				sqlQuery.setParameter(2, ap.getApprove_seq());
 				sqlQuery.setParameter(3, ap.getApprove_level());
 				sqlQuery.setParameter(4, ap.getApprove_userid());
 				sqlQuery.setParameter(5, ap.getApprove_token());
 				sqlQuery.setParameter(6, ap.getApprove_advice());
 				sqlQuery.setParameter(7, ap.getAuth_flag());
 				sqlQuery.setParameter(8, ap.getRemind_date());
 				sqlQuery.setParameter(9, ap.getForecast_date());
 				sqlQuery.setParameter(10, ap.getApprove_flag());
 				sqlQuery.setParameter(11, ap.getConfirm_explain());
 				sqlQuery.setParameter(10, ap.getUpdate_time());
 				sqlQuery.setParameter(10, ap.getApprove_type());
 				
 				int count=sqlQuery.executeUpdate();
				result+=count;
 			}
 		}
		return result;
	}

	/**
	 * 
	 * getApprovalListByFlowId:根据流程ID获取审批级别
	 * @param flowId
	 * @return
	 * @throws PopException 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#getApprovalListByFlowId(java.lang.String)
	 */
	public List<ApproveLevelDef> getApprovalListByFlowId(String flowId) throws Exception {
		String sql="select * from ap_approve_level_def where approve_flow_id=:approve_flow_id order by approve_level asc";
		SQLQuery q=this.getSession().createSQLQuery(sql);
		q.setParameter("approve_flow_id", flowId);
		
		q.addScalar("approve_level", Hibernate.INTEGER);
        q.addScalar("approve_flow_id", Hibernate.STRING);
        q.addScalar("approve_obj_type", Hibernate.INTEGER);
        q.addScalar("approve_obj_id", Hibernate.STRING);
        q.addScalar("auth_flag", Hibernate.INTEGER);
        q.setResultTransformer(Transformers.aliasToBean(ApproveLevelDef.class));
		List<ApproveLevelDef> list=q.list();
		return list;
	}

	/**
	 * 
	 * findByUserDeptId:根据user或者dept查询部门用户关系
	 * @param deptId
	 * @param approveUserid
	 * @return 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#findByUserDeptId(java.lang.String, java.lang.String)
	 */
	public ApproveRelation findByUserDeptId(String deptId, String approveUserid) throws Exception{
		StringBuffer sql=new StringBuffer("select * from ap_approve_relation where 1=1");
		 Map<String,Object> p=new HashMap<String,Object>();
		if(StringUtil.isNotEmpty(deptId)){
			sql.append(" and deptid=:deptid");
			p.put("deptid", deptId);
		}
		if(StringUtil.isNotEmpty(approveUserid)){
			sql.append(" and approve_userid=:approve_userid");
			p.put("approve_userid", approveUserid);
		}
		SQLQuery sqlQuery=this.getSession().createSQLQuery(sql.toString());
		if(p!=null&&p.size()>0){
			for (Map.Entry<String, Object> entry : p.entrySet()) {
				sqlQuery.setParameter(entry.getKey(), entry.getValue());
			}
		}
		 sqlQuery.addScalar("approve_userid", Hibernate.STRING);
		 sqlQuery.addScalar("deptid", Hibernate.INTEGER);
		 sqlQuery.addScalar("approve_create_userid", Hibernate.STRING);
		 sqlQuery.addScalar("create_time", Hibernate.DATE);
		 sqlQuery.addScalar("position_id", Hibernate.INTEGER);
		 sqlQuery.addScalar("approve_userid_email", Hibernate.STRING);
		 sqlQuery.addScalar("approve_userid_msisdn", Hibernate.STRING);
		 sqlQuery.addScalar("cityid", Hibernate.STRING);
		 sqlQuery.addScalar("auth_flag", Hibernate.INTEGER);
        sqlQuery.setResultTransformer(Transformers.aliasToBean(ApproveRelation.class));
		List<?> list=sqlQuery.list();
		if(list!=null&&list.size()>0){
			return (ApproveRelation) list.get(0);
		}else{
			return null;
		}
	}

	/**
	 * 
	 * saveApApproveList:
	 * @param ap 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#saveApApproveList(com.ai.bdx.pop.bean.ApApproveList)
	 */
	public int saveApApproveList(ApApproveList ap) throws Exception{
		String sql = " insert into ap_approve_list(approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type,create_time)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		if (ap != null) {
			SQLQuery sqlQuery = this.getSession().createSQLQuery(sql);
			// approval_id,approve_flow_id,approve_seq,approve_level,
			// approve_userid,approve_token,approve_advice,auth_flag,
			// remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type
			sqlQuery.setParameter(0, ap.getApproval_id());
			sqlQuery.setParameter(1, ap.getApprove_flow_id());
			sqlQuery.setParameter(2, ap.getApprove_seq());
			sqlQuery.setParameter(3, ap.getApprove_level());
			sqlQuery.setParameter(4, ap.getApprove_userid());
			sqlQuery.setParameter(5, ap.getApprove_token());
			sqlQuery.setParameter(6, ap.getApprove_advice());
			sqlQuery.setParameter(7, ap.getAuth_flag());
			sqlQuery.setParameter(8, ap.getRemind_date());
			sqlQuery.setParameter(9, ap.getForecast_date());
			sqlQuery.setParameter(10, ap.getApprove_flag());
			sqlQuery.setParameter(11, ap.getConfirm_explain());
			sqlQuery.setParameter(12, ap.getUpdate_time());
			sqlQuery.setParameter(13, ap.getApprove_type());
			sqlQuery.setParameter(14, ap.getCreate_time());
			int count = sqlQuery.executeUpdate();
			return count;
		}
		return 0;
	}

	public List<?> getApproveTriggerCondDefByFlowAndLevel(String approvalFlowId,
			Integer approve_level)throws Exception {
		String sql="select approve_level,approve_flow_id,approve_trigger_cond_id,cond_indi_id,cond_operator,cond_indi_value,approve_obj_type,approve_obj_id,approve_trigger_cond_pri from ap_approve_trigger_cond_def where 1=1 and approve_level=:approve_level and approve_flow_id=:approve_flow_id  order by approve_level,approve_trigger_cond_id";
		SQLQuery sqlQuery=this.getSession().createSQLQuery(sql);
		sqlQuery.setParameter("approve_level",approve_level);
		sqlQuery.setParameter("approve_flow_id",approvalFlowId);
		sqlQuery.addEntity(ApproveTriggerCondDef.class);
		List<?> list=sqlQuery.list();
		return list;
	}


	public List<ApApproveList> getApprovalProcess(String approvalId, String approvalType,String approvalToken) throws Exception{
		 String sql="select approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type from ap_approve_list a where a.approval_id=:approval_id ";
		if(StringUtil.isNotEmpty(approvalType)){
			sql=sql+" and a.approve_type=:approve_type ";
		}
		if(StringUtil.isNotEmpty(approvalToken)){
			sql=sql+" and a.approve_token=:approve_token ";
		}
		sql+=" order by a.approve_seq,a.approve_level asc";
		 SQLQuery q=this.getSession().createSQLQuery(sql);
		 q.setParameter("approval_id",approvalId);
		 if(StringUtil.isNotEmpty(approvalType)){
			 q.setParameter("approve_type",approvalType); 
		 }
		 if(StringUtil.isNotEmpty(approvalToken)){
			 q.setParameter("approve_token",approvalToken); 
		 }
		 q.addScalar("approval_id", Hibernate.STRING);
	     q.addScalar("approve_flow_id", Hibernate.STRING);
	     q.addScalar("approve_seq", Hibernate.INTEGER);
	     q.addScalar("approve_level", Hibernate.INTEGER);
	     q.addScalar("approve_userid", Hibernate.STRING);
	     q.addScalar("approve_token", Hibernate.INTEGER);
	     q.addScalar("approve_advice", Hibernate.STRING);
	     q.addScalar("auth_flag", Hibernate.INTEGER);
	     q.addScalar("remind_date", Hibernate.STRING);
	     q.addScalar("forecast_date", Hibernate.STRING);
	     q.addScalar("approve_flag", Hibernate.STRING);////0 - 待审批 确认  	1 - 通过 	2 - 不通过 	9 - 终止
	     q.addScalar("confirm_explain", Hibernate.STRING);
	     q.addScalar("update_time", Hibernate.DATE);
	     q.addScalar("approve_type", Hibernate.STRING);
	     q.setResultTransformer(Transformers.aliasToBean(ApApproveList.class));
		 List<ApApproveList> list=q.list();
		 return list;
	}


	public Integer getMaxApprovalSeq(String approvalId, String approvalType) throws Exception{
		String sql="select max(a.approve_seq) approve_seq from ap_approve_list a where a.approval_id=:approval_id and a.approve_type=:approve_type ";
		SQLQuery sqlQuery=this.getSession().createSQLQuery(sql);
		sqlQuery.setParameter("approval_id", approvalId);
		sqlQuery.setParameter("approve_type", approvalType);
		List<?> list=sqlQuery.list();
		if(list!=null&&list.size()>0){
			Integer max=(Integer) list.get(0);
			 return max;
		}
		return null;
	}

	@Override
	public String getApproveDrvType(String drvTypeID, String drvID) throws Exception{
		 String sql="select flow_id from ap_approve_drv_type where table_id=:table_id and table_col_val =:table_col_val";
		 SQLQuery sqlQuery=this.getSession().createSQLQuery(sql);
		 sqlQuery.setParameter("table_id", drvTypeID);
		 sqlQuery.setParameter("table_col_val", drvID);
		 List<?> list=sqlQuery.list();
		 if(list!=null&&list.size()>0){
			 return (String) list.get(0);
		 }else{
			 return null; 
		 }
		
	}


	
	
	/****************************************修改过方法******************************************************************/
    /**
     * 
     * getFirstApprovalOrConfimUser:
     * @param approvalId
     * @param approve_type
     * @return 
     * @see com.ai.bdx.pop.dao.ApprovalDao#getFirstApprovalOrConfimUser(java.lang.String, java.lang.String)
     */
	public List<ApApproveList> getFirstApprovalOrConfimUser(String approvalId,
			String approve_type) throws Exception{
			//先取得第一级审批级别，然后根据第一审批级别获取该级别所有审批人	
			 String sql="select approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type from ap_approve_list a where  a.approve_level=(select min(a.approve_level) from ap_approve_list a where a.approval_id =:approval_id1  and a.approve_type =:approve_type1) and a.approval_id=:approval_id and a.approve_type=:approve_type order by a.approve_seq,a.approve_level asc";
			 SQLQuery q=this.getSession().createSQLQuery(sql);
			 q.setParameter("approval_id1", approvalId);
			 q.setParameter("approve_type1", approve_type);
			 q.setParameter("approval_id",approvalId);
			 q.setParameter("approve_type",approve_type);
			 
			 
			 q.addScalar("approval_id", Hibernate.STRING);
		     q.addScalar("approve_flow_id", Hibernate.STRING);
		     q.addScalar("approve_seq", Hibernate.INTEGER);
		     q.addScalar("approve_level", Hibernate.INTEGER);
		     q.addScalar("approve_userid", Hibernate.STRING);
		     q.addScalar("approve_token", Hibernate.INTEGER);
		     q.addScalar("approve_advice", Hibernate.STRING);
		     q.addScalar("auth_flag", Hibernate.INTEGER);
		     q.addScalar("remind_date", Hibernate.STRING);
		     q.addScalar("forecast_date", Hibernate.STRING);
		     q.addScalar("approve_flag", Hibernate.STRING);////0 - 待审批 确认  	1 - 通过 	2 - 不通过 	9 - 终止
		     q.addScalar("confirm_explain", Hibernate.STRING);
		     q.addScalar("update_time", Hibernate.DATE);
		     q.addScalar("approve_type", Hibernate.STRING);
		     q.setResultTransformer(Transformers.aliasToBean(ApApproveList.class));
			 List<ApApproveList> list=q.list();
			 return list;
	}

	
	/**
	 * 
	 * getNextApprovalProcess:找到下级审批所有人
	 * @param currentApproveList
	 * @return 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#getNextApprovalProcess(com.ai.bdx.pop.bean.ApApproveList)
	 */
	

	public List<ApApproveList> getNextApprovalProcess(ApApproveList currentApproveList) throws Exception{
		
		String sql="select approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type from ap_approve_list a where"
				+ " a.approval_id=:approval_id and a.approve_type=:approve_type and a.approve_level=:approve_level and a.approve_flow_id=:approve_flow_id "
				+ " order by a.approve_seq,a.approve_level asc";
		
		/*String sql="select approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type from ap_approve_list a where"
				+ " a.approval_id=:approval_id and a.approve_type=:approve_type and a.approve_flow_id=:approve_flow_id and "
				+ " a.approve_seq=:approve_seq order by a.approve_seq,a.approve_level asc";*/
		 SQLQuery q=this.getSession().createSQLQuery(sql);
		 q.setParameter("approval_id",currentApproveList.getApproval_id());
		 q.setParameter("approve_type",currentApproveList.getApprove_type());
		 q.setParameter("approve_level",currentApproveList.getApprove_level()==null?0:currentApproveList.getApprove_level()+1);
		 q.setParameter("approve_flow_id",currentApproveList.getApprove_flow_id());
		 //q.setParameter("approve_seq",currentApproveList.getApprove_seq()==null?0:currentApproveList.getApprove_seq()+1);
		 
		 q.addScalar("approval_id", Hibernate.STRING);
	     q.addScalar("approve_flow_id", Hibernate.STRING);
	     q.addScalar("approve_seq", Hibernate.INTEGER);
	     q.addScalar("approve_level", Hibernate.INTEGER);
	     q.addScalar("approve_userid", Hibernate.STRING);
	     q.addScalar("approve_token", Hibernate.INTEGER);
	     q.addScalar("approve_advice", Hibernate.STRING);
	     q.addScalar("auth_flag", Hibernate.INTEGER);
	     q.addScalar("remind_date", Hibernate.STRING);
	     q.addScalar("forecast_date", Hibernate.STRING);
	     q.addScalar("approve_flag", Hibernate.STRING);////0 - 待审批 确认  	1 - 通过 	2 - 不通过 	9 - 终止
	     q.addScalar("confirm_explain", Hibernate.STRING);
	     q.addScalar("update_time", Hibernate.DATE);
	     q.addScalar("approve_type", Hibernate.STRING);
	     q.setResultTransformer(Transformers.aliasToBean(ApApproveList.class));
		List<ApApproveList> list= q.list();
		return list;
	}

	
	
	
	/**
	 * 
	 * updateApprovalToken:
	 * @param approvalId
	 * @param approvalType
	 * @param approvalToken
	 * @param currentApprovalSeq
	 * @param approve_flow_id
	 * @param approve_level
	 * @param approve_userid
	 * @return 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#updateApprovalToken(java.lang.String, java.lang.String, java.lang.Integer, java.lang.Integer, java.lang.String, java.lang.Integer, java.lang.String)
	 */
	public int updateApprovalToken(String approvalId, String approvalType,
			Integer approvalToken,Integer currentApprovalSeq,String approve_flow_id,Integer approve_level,String approve_userid) throws Exception{
		 String sql="update ap_approve_list a set a.approve_token=:approve_token  where a.approval_id=:approval_id"
					+ " and a.approve_flow_id=:approve_flow_id and  a.approve_seq=:approve_seq and a.approve_level=:approve_level and"
					+ " a.approve_type=:approve_type and a.approve_userid=:approve_userid";
		 SQLQuery q=this.getSession().createSQLQuery(sql);
		 q.setParameter("approve_token", approvalToken);
		 q.setParameter("approval_id", approvalId);
		 q.setParameter("approve_flow_id", approve_flow_id);
		 q.setParameter("approve_seq", currentApprovalSeq);
		 q.setParameter("approve_level", approve_level);
		 q.setParameter("approve_type", approvalType);
		 q.setParameter("approve_userid", approve_userid);
		return  q.executeUpdate();
	}
	/**
	 * 
	 * updateApprovalFlag:
	 * @param approvalId
	 * @param approvalType
	 * @param approve_flag
	 * @param currentApprovalSeq
	 * @param approve_flow_id
	 * @param approve_level
	 * @param approve_userid
	 * @return 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#updateApprovalFlag(java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.lang.String, java.lang.Integer, java.lang.String)
	 */
	public int updateApprovalFlag(String approvalId, String approvalType,
			String approve_flag,Integer currentApprovalSeq,String approve_flow_id,Integer approve_level,String approve_userid) throws Exception{
		 String sql="update ap_approve_list a set a.approve_flag=:approve_flag,update_time=:update_time  where a.approval_id=:approval_id"
					+ " and a.approve_flow_id=:approve_flow_id and  a.approve_seq=:approve_seq and a.approve_level=:approve_level and"
					+ " a.approve_type=:approve_type and a.approve_userid=:approve_userid";
		 SQLQuery q=this.getSession().createSQLQuery(sql);
		 q.setParameter("approve_flag", approve_flag);
		 q.setParameter("update_time", new java.util.Date());
		 
		 q.setParameter("approval_id", approvalId);
		 q.setParameter("approve_flow_id", approve_flow_id);
		 q.setParameter("approve_seq", currentApprovalSeq);
		 q.setParameter("approve_level", approve_level);
		 q.setParameter("approve_type", approvalType);
		 q.setParameter("approve_userid", approve_userid);
		return  q.executeUpdate();
	}
	
	/**
	 * 
	 * getSampleLevelApproverByCurrentApproval:根据同级别审批人查找在同级别是否还有审批人
	 * @param currentApproval 当前级别审批信息
	 * @return 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#getSampleLevelApproverByCurrentApproval(com.ai.bdx.pop.bean.ApApproveList)
	 */
	public List<?> getSampleLevelApproverByCurrentApproval(
			ApApproveList currentApproval) throws Exception{
	
				String sql="select approval_id,approve_flow_id,approve_seq,approve_level,approve_userid,approve_token,approve_advice,auth_flag,remind_date,forecast_date,approve_flag,confirm_explain,update_time,approve_type from ap_approve_list a where"
						+ " a.approval_id=:approval_id and a.approve_type=:approve_type and a.approve_flow_id=:approve_flow_id and a.approve_level=:approve_level"
						+ " and a.approve_token=:approve_token order by a.approve_seq,a.approve_level asc";
				SQLQuery q=this.getSession().createSQLQuery(sql);
				 q.setParameter("approval_id",currentApproval.getApproval_id());
				 q.setParameter("approve_type",currentApproval.getApprove_type());
				 q.setParameter("approve_level",currentApproval.getApprove_level()==null?1:currentApproval.getApprove_level());
				 q.setParameter("approve_flow_id",currentApproval.getApprove_flow_id());
				 q.setParameter("approve_token",ApprovalCONST.APPROVE_TOKEN_HOLD);
				 //q.setParameter("approve_seq",currentApproveList.getApprove_seq()==null?0:currentApproveList.getApprove_seq()+1);
				 
				 q.addScalar("approval_id", Hibernate.STRING);
			     q.addScalar("approve_flow_id", Hibernate.STRING);
			     q.addScalar("approve_seq", Hibernate.INTEGER);
			     q.addScalar("approve_level", Hibernate.INTEGER);
			     q.addScalar("approve_userid", Hibernate.STRING);
			     q.addScalar("approve_token", Hibernate.INTEGER);
			     q.addScalar("approve_advice", Hibernate.STRING);
			     q.addScalar("auth_flag", Hibernate.INTEGER);
			     q.addScalar("remind_date", Hibernate.STRING);
			     q.addScalar("forecast_date", Hibernate.STRING);
			     q.addScalar("approve_flag", Hibernate.STRING);////0 - 待审批 确认  	1 - 通过 	2 - 不通过 	9 - 终止
			     q.addScalar("confirm_explain", Hibernate.STRING);
			     q.addScalar("update_time", Hibernate.DATE);
			     q.addScalar("approve_type", Hibernate.STRING);
			     q.setResultTransformer(Transformers.aliasToBean(ApApproveList.class));
			     List<?> list= q.list();
			    return list;
	}


	/**
	 * 
	 * getCurrentApproversByApprovalID:根据审批对象ID查询所有当前审批人
	 * @param approvalID
	 * @return
	 * @throws Exception 
	 * @see com.ai.bdx.pop.dao.ApprovalDao#getCurrentApproversByApprovalID(java.lang.String)
	 */
	public List<String> getCurrentApproversByApprovalID(String approvalID) throws Exception {
		String sql = "select a.approve_userid from ap_approve_list a where  1=1 and a.approval_id=:approval_id and a.approve_token=:approve_token";
		SQLQuery q=this.getSession().createSQLQuery(sql);
		q.setParameter("approval_id", approvalID);
		q.setParameter("approve_token", ApprovalCONST.APPROVE_TOKEN_HOLD);
		return q.list();
	}
	
}

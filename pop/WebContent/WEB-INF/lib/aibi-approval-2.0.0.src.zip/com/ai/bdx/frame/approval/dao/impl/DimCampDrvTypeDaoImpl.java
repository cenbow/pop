package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.DimCampDrvType;
import com.ai.bdx.frame.approval.model.DimDrvRoleManager;
import com.ai.bdx.frame.approval.model.MtlPlanExecType;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

/**
 * Created on 10:00:19 AM
 *
 * <p>Title: 营销案驱动类型service实现类</p>
 * <p>Description: 取营销案驱动类型</p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
/**
 * @author zhoulb
 *
 */
public class DimCampDrvTypeDaoImpl extends HibernateDaoSupport implements
		IDimCampDrvTypeDao {
	private static Logger log = LogManager.getLogger();

	public DimCampDrvTypeDaoImpl() {
		super();
	}

	public Map findCampDrvList(DimCampDrvType drvinfo, final Integer curPage,
			final Integer pageSize) throws Exception {
		StringBuffer sb = new StringBuffer();
		sb.append("select dcdt from DimCampDrvType dcdt  where 1=1 ");
		if (drvinfo.getCampDrvId() != null
				&& drvinfo.getCampDrvId().shortValue() != -1) {
			sb.append(" and dcdt.campDrvId=" + drvinfo.getCampDrvId() + "");
		}
		if(drvinfo.getTableID()!=null&&!drvinfo.getTableID().equals("-1")){
			sb.append(" and dcdt.tableID=" + drvinfo.getTableID() + "");
		}
		if(drvinfo.getTableColVal()!=null&&!drvinfo.getTableColVal().equals("-1")){
			sb.append(" and dcdt.tableColVal=" + drvinfo.getTableColVal() + "");
		}
		sb.append(" order by dcdt.campDrvId");
		final String sql = sb.toString();
		Map map = (Map) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session arg0)
							throws HibernateException, SQLException {
						Query query = arg0.createQuery(sql);
						Map map = new HashMap();
						int totalCnt = query.list().size();
						if (totalCnt < 1) {
							map.put("total", Integer.valueOf(0));
							map.put("result", new ArrayList());
							return map;
						}
						query.setFirstResult(pageSize.intValue()
								* curPage.intValue());
						query.setMaxResults(pageSize.intValue());
						List list = query.list();
						map.put("total", Integer.valueOf(totalCnt));
						map.put("result", list);
						return map;
					}
				});
		return map;
	}

	/*
	 * （非 Javadoc）
	 * 
	 * @see com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao#getAllDrvType()
	 */
	public List getAllDrvType() throws Exception {
		// String sql = "from DimCampDrvType dcdt where dcdt.campDrvId <> " +
		// MpmCONST.MPM_DRV_TYPE_COMMON + " order by dcdt.campDrvId";
		String sql = "from DimCampDrvType dcdt where 1=1  order by dcdt.campDrvId";
		return getHibernateTemplate().find(sql);
	}

	public Object[] getAllDrvTypesEnabled() throws Exception {
		Object[] obj = new Object[2];
		List result = new ArrayList();
		List parentFilterList = new ArrayList();
		String sql = "from DimCampDrvType dcdt where  dcdt.drvDesabled is null or dcdt.drvDesabled <> 1 order by dcdt.campDrvId";
		result = getHibernateTemplate().find(sql);
		String parentFilterSql = " from DimCampDrvType dcdt where dcdt.drvDesabled = 1";

		List tmpList = getHibernateTemplate().find(parentFilterSql);

		if (tmpList != null && !tmpList.isEmpty()) {
			for (Iterator<DimCampDrvType> it = tmpList.iterator(); it.hasNext();) {
				DimCampDrvType filterDrv = it.next();
				parentFilterList.add(filterDrv.getCampDrvId());
			}
		}

		tmpList = null;

		obj[0] = result;
		obj[1] = parentFilterList;

		return obj;
	}

	public DimDrvRoleManager getAllCampDrvTypeByRoleId(Short campDrvId,
			String roleId, Short roleFlag) throws MpmException {
		DimDrvRoleManager ddrm = null;

		try {
			String sql = "from DimDrvRoleManager ddrm where  ddrm.id.roleId='"
					+ roleId + "' and ddrm.roleFlag=" + roleFlag
					+ " and ddrm.id.campDrvId=" + campDrvId;
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				ddrm = (DimDrvRoleManager) list.get(0);
			}

		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.tgjsqhdqdl"));
		}
		return ddrm;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao#getUserDrvAuth(java.lang.Short,
	 * java.lang.String, java.lang.String)
	 */
	public boolean getUserDrvAuth(Short campDrvId, String userId, String groupId)
			throws MpmException {
		boolean flag = false;
		try {
			DimDrvRoleManager ddrm = null;
			String sql = "from DimDrvRoleManager ddrm where ddrm.id.campDrvId = "
					+ campDrvId + " and ( ";
			sql = sql + "  ( ddrm.id.roleId = '" + userId
					+ "' and ddrm.roleFlag = "
					+ MpmCONST.MTL_DRV_AUTH_FLAG_USER + ")";
			if (groupId != null && groupId.length() > 0) {
				sql = sql + " or ( ddrm.id.roleId = '" + groupId
						+ "' and ddrm.roleFlag = "
						+ MpmCONST.MTL_DRV_AUTH_FLAG_GROUP + " )";

			}
			sql = sql + ")";
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				for (int i = 0; i < list.size(); i++) {
					ddrm = (DimDrvRoleManager) list.get(i);
					if (ddrm != null
							&& ddrm.getAccessToken() == MpmCONST.MTL_DRV_AUTH_TOKEN_NO
							&& ddrm.getRoleFlag() == MpmCONST.MTL_DRV_AUTH_FLAG_USER) { // 对用户授权的优先级比用户组高
						flag = false;
						break;
					} else {
						if (ddrm != null
								&& ddrm.getAccessToken() == MpmCONST.MTL_DRV_AUTH_TOKEN_YES
								&& ddrm.getRoleFlag() == MpmCONST.MTL_DRV_AUTH_FLAG_USER) {
							flag = true;
							break;
						} else {
							if (ddrm != null
									&& ddrm.getAccessToken() == MpmCONST.MTL_DRV_AUTH_TOKEN_NO
									&& ddrm.getRoleFlag() == MpmCONST.MTL_DRV_AUTH_FLAG_GROUP) {
								flag = false;
							} else {
								flag = true;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.hqmyhsfyyh"));
		}
		return flag;
	}

	/*
	 * （非 Javadoc）
	 * 
	 * @see com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao#getDrvType(java.lang.Short)
	 */
	public DimCampDrvType getDrvType(Short drvTypeId) throws Exception {
		DimCampDrvType obj = null;
		try {
			obj = (DimCampDrvType) this.getHibernateTemplate().get(
					DimCampDrvType.class, drvTypeId);
		} catch (Exception e) {
			log.error("", e);
		}
		return obj;
	}

	/*
	 * （非 Javadoc）
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao#getScenesBycampDrvId(java.lang.
	 * String)
	 */
	public List getScenesBycampDrvId(String campDrvId) throws MpmException {
		// TODO 自动生成方法存根
		return this.getHibernateTemplate().find(
				"from MtlScenesTemplet mst where mst.campDrvId=" + campDrvId);
	}

	/*
	 * （非 Javadoc）
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao#getCampDrvTypeListByType(java.lang
	 * .String)
	 */
	public List getCampDrvTypeListByType(final String type) throws Exception {
		String sql = "";
		if (type != null && type.equals("0")) {
			sql = "from DimCampDrvType dcdt where dcdt.parentId = -1 order by dcdt.campDrvId";
		} else {
			sql = "from DimCampDrvType dcdt where dcdt.campDrvId not in(select distinct ins.parentId from DimCampDrvType ins) order by dcdt.campDrvId";
		}
		return this.getHibernateTemplate().find(sql);
	}

	public List getSubCampDrvTypeList(final String type) throws Exception {
		String hql = "from DimCampDrvType dcdt where dcdt.parentId = ? order by dcdt.campDrvId";
		return this.getHibernateTemplate().find(hql, Short.valueOf(type));
	}

	public Short getMaxCampDrvId() throws Exception {
		Short maxId = 0;
		try {
			String sql = "select max(dcdt.campDrvId) from DimCampDrvType dcdt where 1=1";
			List result = this.getHibernateTemplate().find(sql);
			maxId = Short.valueOf(String.valueOf(result.get(0)));
		} catch (Exception e) {

		}
		return maxId;
	}

	/*
	 * （非 Javadoc）
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao#getScenesElementsMap(java.lang.
	 * String)
	 */
	public List getScenesElementsMap(String scenesId) throws MpmException {
		// TODO 自动生成方法存根
		return this.getHibernateTemplate().find(
				"from MtlScenesElements mst where mst.id.scenesId='" + scenesId
						+ "'");
	}

	/*
	 * （非 Javadoc）
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao#getScenesElementsMap(java.lang.
	 * String)
	 */
	public List getPlanExecTypeMap(MtlPlanExecType mpet) throws MpmException {
		List result = new ArrayList();
		try {
			String sql = "from MtlPlanExecType mpet where 1=1 ";
			if (mpet != null && mpet.getPlanExecId() != null
					&& mpet.getPlanExecId().trim().length() > 0) {
				sql = sql + " and mpet.planExecId = '" + mpet.getPlanExecId()
						+ "'";
			}
			result = this.getHibernateTemplate().find(sql);
		} catch (Exception e) {

		}
		return result;
	}

	public MtlPlanExecType getPlanExecById(String planExecId)
			throws MpmException {
		MtlPlanExecType result = new MtlPlanExecType();
		try {
			String sql = "from MtlPlanExecType mpet where 1=1 ";
			if (planExecId != null && planExecId.trim().length() > 0) {
				sql = sql + " and mpet.planExecId = '" + planExecId + "'";
			}
			List execList = this.getHibernateTemplate().find(sql);
			if (execList != null) {
				result = (MtlPlanExecType) execList.get(0);
			}
		} catch (Exception e) {

		}
		return result;
	}

	public List findPlanExecAll() throws MpmException {
		List result = new ArrayList();
		try {
			String sql = "from MtlPlanExecType mpet where 1=1 order by mpet.planExecId";
			result = this.getHibernateTemplate().find(sql);
		} catch (Exception e) {

		}
		return result;
	}

	public void save(DimCampDrvType dcdt) throws MpmException {
		this.getHibernateTemplate().saveOrUpdate(dcdt);
	}

	/*public MtlScenesTemplet getScenesTemplet(String scenesId) {
		MtlScenesTemplet obj = null;
		try {
			obj = (MtlScenesTemplet) this.getHibernateTemplate().get(
					MtlScenesTemplet.class, scenesId);
		} catch (Exception e) {
			log.error("", e);
		}
		return obj;
	}*/

}

/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.model.DimCampDrvType;
/*     */ import com.ai.bdx.frame.approval.model.DimDrvRoleManager;
/*     */ import com.ai.bdx.frame.approval.model.MtlPlanExecType;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class DimCampDrvTypeDaoImpl extends HibernateDaoSupport
/*     */   implements IDimCampDrvTypeDao
/*     */ {
/*  40 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public Map findCampDrvList(DimCampDrvType drvinfo, final Integer curPage, final Integer pageSize)
/*     */     throws Exception
/*     */   {
/*  48 */     StringBuffer sb = new StringBuffer();
/*  49 */     sb.append("select dcdt from DimCampDrvType dcdt  where 1=1 ");
/*  50 */     if ((drvinfo.getCampDrvId() != null) && (drvinfo.getCampDrvId().shortValue() != -1))
/*     */     {
/*  52 */       sb.append(" and dcdt.campDrvId=" + drvinfo.getCampDrvId() + "");
/*     */     }
/*  54 */     if ((drvinfo.getTableID() != null) && (!drvinfo.getTableID().equals("-1"))) {
/*  55 */       sb.append(" and dcdt.tableID=" + drvinfo.getTableID() + "");
/*     */     }
/*  57 */     if ((drvinfo.getTableColVal() != null) && (!drvinfo.getTableColVal().equals("-1"))) {
/*  58 */       sb.append(" and dcdt.tableColVal=" + drvinfo.getTableColVal() + "");
/*     */     }
/*  60 */     sb.append(" order by dcdt.campDrvId");
/*  61 */     final String sql = sb.toString();
/*  62 */     Map map = (Map)getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session arg0) throws HibernateException, SQLException
/*     */       {
/*  66 */         Query query = arg0.createQuery(sql);
/*  67 */         Map map = new HashMap();
/*  68 */         int totalCnt = query.list().size();
/*  69 */         if (totalCnt < 1) {
/*  70 */           map.put("total", Integer.valueOf(0));
/*  71 */           map.put("result", new ArrayList());
/*  72 */           return map;
/*     */         }
/*  74 */         query.setFirstResult(pageSize.intValue() * curPage.intValue());
/*     */ 
/*  76 */         query.setMaxResults(pageSize.intValue());
/*  77 */         List list = query.list();
/*  78 */         map.put("total", Integer.valueOf(totalCnt));
/*  79 */         map.put("result", list);
/*  80 */         return map;
/*     */       }
/*     */     });
/*  83 */     return map;
/*     */   }
/*     */ 
/*     */   public List getAllDrvType()
/*     */     throws Exception
/*     */   {
/*  94 */     String sql = "from DimCampDrvType dcdt where 1=1  order by dcdt.campDrvId";
/*  95 */     return getHibernateTemplate().find(sql);
/*     */   }
/*     */ 
/*     */   public Object[] getAllDrvTypesEnabled() throws Exception {
/*  99 */     Object[] obj = new Object[2];
/* 100 */     List result = new ArrayList();
/* 101 */     List parentFilterList = new ArrayList();
/* 102 */     String sql = "from DimCampDrvType dcdt where  dcdt.drvDesabled is null or dcdt.drvDesabled <> 1 order by dcdt.campDrvId";
/* 103 */     result = getHibernateTemplate().find(sql);
/* 104 */     String parentFilterSql = " from DimCampDrvType dcdt where dcdt.drvDesabled = 1";
/*     */ 
/* 106 */     List tmpList = getHibernateTemplate().find(parentFilterSql);
/*     */     Iterator it;
/* 108 */     if ((tmpList != null) && (!tmpList.isEmpty())) {
/* 109 */       for (it = tmpList.iterator(); it.hasNext(); ) {
/* 110 */         DimCampDrvType filterDrv = (DimCampDrvType)it.next();
/* 111 */         parentFilterList.add(filterDrv.getCampDrvId());
/*     */       }
/*     */     }
/*     */ 
/* 115 */     tmpList = null;
/*     */ 
/* 117 */     obj[0] = result;
/* 118 */     obj[1] = parentFilterList;
/*     */ 
/* 120 */     return obj;
/*     */   }
/*     */ 
/*     */   public DimDrvRoleManager getAllCampDrvTypeByRoleId(Short campDrvId, String roleId, Short roleFlag) throws MpmException
/*     */   {
/* 125 */     DimDrvRoleManager ddrm = null;
/*     */     try
/*     */     {
/* 128 */       String sql = "from DimDrvRoleManager ddrm where  ddrm.id.roleId='" + roleId + "' and ddrm.roleFlag=" + roleFlag + " and ddrm.id.campDrvId=" + campDrvId;
/*     */ 
/* 131 */       List list = getHibernateTemplate().find(sql);
/* 132 */       if ((list != null) && (list.size() > 0))
/* 133 */         ddrm = (DimDrvRoleManager)list.get(0);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 137 */       log.error("", e);
/* 138 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgjsqhdqdl"));
/*     */     }
/*     */ 
/* 141 */     return ddrm;
/*     */   }
/*     */ 
/*     */   public boolean getUserDrvAuth(Short campDrvId, String userId, String groupId)
/*     */     throws MpmException
/*     */   {
/* 153 */     boolean flag = false;
/*     */     try {
/* 155 */       DimDrvRoleManager ddrm = null;
/* 156 */       String sql = "from DimDrvRoleManager ddrm where ddrm.id.campDrvId = " + campDrvId + " and ( ";
/*     */ 
/* 158 */       sql = sql + "  ( ddrm.id.roleId = '" + userId + "' and ddrm.roleFlag = " + 1 + ")";
/*     */ 
/* 161 */       if ((groupId != null) && (groupId.length() > 0)) {
/* 162 */         sql = sql + " or ( ddrm.id.roleId = '" + groupId + "' and ddrm.roleFlag = " + 2 + " )";
/*     */       }
/*     */ 
/* 167 */       sql = sql + ")";
/* 168 */       List list = getHibernateTemplate().find(sql);
/* 169 */       if ((list != null) && (list.size() > 0)) {
/* 170 */         for (int i = 0; i < list.size(); i++) {
/* 171 */           ddrm = (DimDrvRoleManager)list.get(i);
/* 172 */           if ((ddrm != null) && (ddrm.getAccessToken().shortValue() == 0) && (ddrm.getRoleFlag().shortValue() == 1))
/*     */           {
/* 175 */             flag = false;
/* 176 */             break;
/*     */           }
/* 178 */           if ((ddrm != null) && (ddrm.getAccessToken().shortValue() == 1) && (ddrm.getRoleFlag().shortValue() == 1))
/*     */           {
/* 181 */             flag = true;
/* 182 */             break;
/*     */           }
/* 184 */           if ((ddrm != null) && (ddrm.getAccessToken().shortValue() == 0) && (ddrm.getRoleFlag().shortValue() == 2))
/*     */           {
/* 187 */             flag = false;
/*     */           }
/* 189 */           else flag = true;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 196 */       log.error("", e);
/* 197 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqmyhsfyyh"));
/*     */     }
/*     */ 
/* 200 */     return flag;
/*     */   }
/*     */ 
/*     */   public DimCampDrvType getDrvType(Short drvTypeId)
/*     */     throws Exception
/*     */   {
/* 209 */     DimCampDrvType obj = null;
/*     */     try {
/* 211 */       obj = (DimCampDrvType)getHibernateTemplate().get(DimCampDrvType.class, drvTypeId);
/*     */     }
/*     */     catch (Exception e) {
/* 214 */       log.error("", e);
/*     */     }
/* 216 */     return obj;
/*     */   }
/*     */ 
/*     */   public List getScenesBycampDrvId(String campDrvId)
/*     */     throws MpmException
/*     */   {
/* 228 */     return getHibernateTemplate().find("from MtlScenesTemplet mst where mst.campDrvId=" + campDrvId);
/*     */   }
/*     */ 
/*     */   public List getCampDrvTypeListByType(String type)
/*     */     throws Exception
/*     */   {
/* 240 */     String sql = "";
/* 241 */     if ((type != null) && (type.equals("0")))
/* 242 */       sql = "from DimCampDrvType dcdt where dcdt.parentId = -1 order by dcdt.campDrvId";
/*     */     else {
/* 244 */       sql = "from DimCampDrvType dcdt where dcdt.campDrvId not in(select distinct ins.parentId from DimCampDrvType ins) order by dcdt.campDrvId";
/*     */     }
/* 246 */     return getHibernateTemplate().find(sql);
/*     */   }
/*     */ 
/*     */   public List getSubCampDrvTypeList(String type) throws Exception {
/* 250 */     String hql = "from DimCampDrvType dcdt where dcdt.parentId = ? order by dcdt.campDrvId";
/* 251 */     return getHibernateTemplate().find(hql, Short.valueOf(type));
/*     */   }
/*     */ 
/*     */   public Short getMaxCampDrvId() throws Exception {
/* 255 */     Short maxId = Short.valueOf((short)0);
/*     */     try {
/* 257 */       String sql = "select max(dcdt.campDrvId) from DimCampDrvType dcdt where 1=1";
/* 258 */       List result = getHibernateTemplate().find(sql);
/* 259 */       maxId = Short.valueOf(String.valueOf(result.get(0)));
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 263 */     return maxId;
/*     */   }
/*     */ 
/*     */   public List getScenesElementsMap(String scenesId)
/*     */     throws MpmException
/*     */   {
/* 275 */     return getHibernateTemplate().find("from MtlScenesElements mst where mst.id.scenesId='" + scenesId + "'");
/*     */   }
/*     */ 
/*     */   public List getPlanExecTypeMap(MtlPlanExecType mpet)
/*     */     throws MpmException
/*     */   {
/* 288 */     List result = new ArrayList();
/*     */     try {
/* 290 */       String sql = "from MtlPlanExecType mpet where 1=1 ";
/* 291 */       if ((mpet != null) && (mpet.getPlanExecId() != null) && (mpet.getPlanExecId().trim().length() > 0))
/*     */       {
/* 293 */         sql = sql + " and mpet.planExecId = '" + mpet.getPlanExecId() + "'";
/*     */       }
/*     */ 
/* 296 */       result = getHibernateTemplate().find(sql);
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 300 */     return result;
/*     */   }
/*     */ 
/*     */   public MtlPlanExecType getPlanExecById(String planExecId) throws MpmException
/*     */   {
/* 305 */     MtlPlanExecType result = new MtlPlanExecType();
/*     */     try {
/* 307 */       String sql = "from MtlPlanExecType mpet where 1=1 ";
/* 308 */       if ((planExecId != null) && (planExecId.trim().length() > 0)) {
/* 309 */         sql = sql + " and mpet.planExecId = '" + planExecId + "'";
/*     */       }
/* 311 */       List execList = getHibernateTemplate().find(sql);
/* 312 */       if (execList != null)
/* 313 */         result = (MtlPlanExecType)execList.get(0);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/* 318 */     return result;
/*     */   }
/*     */ 
/*     */   public List findPlanExecAll() throws MpmException {
/* 322 */     List result = new ArrayList();
/*     */     try {
/* 324 */       String sql = "from MtlPlanExecType mpet where 1=1 order by mpet.planExecId";
/* 325 */       result = getHibernateTemplate().find(sql);
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 329 */     return result;
/*     */   }
/*     */ 
/*     */   public void save(DimCampDrvType dcdt) throws MpmException {
/* 333 */     getHibernateTemplate().saveOrUpdate(dcdt);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.DimCampDrvTypeDaoImpl
 * JD-Core Version:    0.6.2
 */
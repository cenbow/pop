package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IDimCampsegStatDao;
import com.ai.bdx.frame.approval.model.DimCampsegStat;

public class DimCampsegStatDaoImpl extends HibernateDaoSupport implements IDimCampsegStatDao {

	public DimCampsegStatDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DimCampsegStat getCampsegStat(Short campsegStatId) throws Exception {
		return (DimCampsegStat) this.getHibernateTemplate().get(DimCampsegStat.class, campsegStatId);
	}

	public List getAllCampsegStat() throws Exception {
		//		String sql = "from DimCampsegStat dcs order by dcs.campsegStatId";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery("from DimCampsegStat dcs where dcs.campsegStatVisible < 2 order by dcs.campsegStatId");
				return query.list();
			}
		});
	}

	public List getAllCampsegStatVisible() throws Exception {
		//		String sql = "from DimCampsegStat dcs order by dcs.campsegStatId";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery("from DimCampsegStat dcs where dcs.campsegStatVisible=0 order by dcs.campsegStatId");
				return query.list();
			}
		});
	}

}

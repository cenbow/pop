/*    */ package com.ai.bdx.frame.approval.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimCampsegStatDao;
/*    */ import com.ai.bdx.frame.approval.model.DimCampsegStat;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.Query;
/*    */ import org.hibernate.Session;
/*    */ import org.springframework.orm.hibernate3.HibernateCallback;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class DimCampsegStatDaoImpl extends HibernateDaoSupport
/*    */   implements IDimCampsegStatDao
/*    */ {
/*    */   public DimCampsegStat getCampsegStat(Short campsegStatId)
/*    */     throws Exception
/*    */   {
/* 23 */     return (DimCampsegStat)getHibernateTemplate().get(DimCampsegStat.class, campsegStatId);
/*    */   }
/*    */ 
/*    */   public List getAllCampsegStat()
/*    */     throws Exception
/*    */   {
/* 30 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*    */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 32 */         Query query = s.createQuery("from DimCampsegStat dcs where dcs.campsegStatVisible < 2 order by dcs.campsegStatId");
/* 33 */         return query.list();
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   public List getAllCampsegStatVisible()
/*    */     throws Exception
/*    */   {
/* 42 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*    */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 44 */         Query query = s.createQuery("from DimCampsegStat dcs where dcs.campsegStatVisible=0 order by dcs.campsegStatId");
/* 45 */         return query.list();
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.DimCampsegStatDaoImpl
 * JD-Core Version:    0.6.2
 */
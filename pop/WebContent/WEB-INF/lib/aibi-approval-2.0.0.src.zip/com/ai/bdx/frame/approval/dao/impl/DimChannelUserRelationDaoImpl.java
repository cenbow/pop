package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimChannelUserRelationForm;
import com.ai.bdx.frame.approval.model.DimChannelUserRelation;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;

public class DimChannelUserRelationDaoImpl extends HibernateDaoSupport implements IDimChannelUserRelationDao {
	private static Logger log = LogManager.getLogger();

	public DimChannelUserRelationDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	//caihao add 从DimChannelUserRelation取得channeltypeId
	public DimChannelUserRelation getChannelTypeId(Integer resourceId, String userId, Short confirmType) throws Exception {

		try {
			DimChannelUserRelation dimChannelUserRelation = null;
			String sql = "from  DimChannelUserRelation a where a.resourceId=" + resourceId;
			if (userId != null && !userId.equals("")) {
				sql += " and a.id.userId = '" + userId + "'";
			}
			if (confirmType != null) {
				sql += " and a.id.confirmType=" + confirmType;
			}
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				dimChannelUserRelation = (DimChannelUserRelation) list.get(0);
			}
			return dimChannelUserRelation;
		} catch (Exception e) {
			throw e;
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao#getChannelTypeId(java.lang.Short, java.lang.String, int)
	 */
	public DimChannelUserRelation getChannelTypeId(Short channelType, String channelId, int confirmType) throws Exception {
		// TODO 自动生成方法存根
		try {
			DimChannelUserRelation dimChannelUserRelation = null;
			String sql = "from  DimChannelUserRelation a where 1=1 ";
			if (channelType != null) {
				sql += " and a.id.channeltypeId = " + channelType;
			}
			if (channelId != null && channelId.trim().length() > 0) {
				sql += " and a.id.channelId = '" + channelId + "'";
			}
			if (confirmType != -1) {
				sql += " and a.id.confirmType=" + confirmType;
			}
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				dimChannelUserRelation = (DimChannelUserRelation) list.get(0);
			}
			return dimChannelUserRelation;
		} catch (Exception e) {
			throw e;
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao#getAllChannelType()
	 */
	public List getAllChannelType() throws Exception {
		// TODO 自动生成方法存根
		try {
			String sql = "from  DimChannelUserRelation";
			List list = this.getHibernateTemplate().find(sql);

			return list;
		} catch (Exception e) {
			throw e;
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao#save(com.ai.bdx.frame.approval.model.DimChannelUserRelation)
	 */
	public void save(DimChannelUserRelation dimChannelUserRelation) throws MpmException {
		// TODO 自动生成方法存根
		this.getHibernateTemplate().deleteAll(this.getSession().createQuery("from  DimChannelUserRelation a where a.resourceId=" + dimChannelUserRelation.getResourceId() + " and a.id.confirmType=" + dimChannelUserRelation.getId().getConfirmType()).list());
		this.getHibernateTemplate().save(dimChannelUserRelation);
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao#searchChannelUserRelation(com.ai.bdx.frame.approval.form.DimChannelUserRelationForm)
	 */
	public Map searchChannelUserRelation(DimChannelUserRelationForm searchForm, final Integer curPage, final Integer pageSize) throws MpmException {
		// TODO 自动生成方法存根
		StringBuffer sql = new StringBuffer("from  DimChannelUserRelation a where 1=1 ");
		if (searchForm.getResourceId() != -1) {
			sql.append(" and a.resourceId=").append(searchForm.getResourceId());
		}
		sql.append(" order by a.resourceId");
		final String sql1 = sql.toString();
		Map map = (Map) this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
				Query query = arg0.createQuery(sql1);
				Map map = new HashMap();
				int totalCnt = query.list().size();
				if (totalCnt < 1) {
					map.put("total", Integer.valueOf(0));
					map.put("result", new ArrayList());
					return map;
				}
				query.setFirstResult(pageSize.intValue() * curPage.intValue());
				query.setMaxResults(pageSize.intValue());
				List list = query.list();
				map.put("total", Integer.valueOf(totalCnt));
				map.put("result", list);

				return map;
			}
		});

		return map;
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao#delete(com.ai.bdx.frame.approval.form.DimChannelUserRelationForm)
	 */
	public void delete(DimChannelUserRelationForm searchForm) throws MpmException {
		// TODO 自动生成方法存根
		this.getHibernateTemplate().deleteAll(this.getSession().createQuery("from  DimChannelUserRelation a where a.resourceId=" + searchForm.getResourceId() + " and a.id.confirmType=" + searchForm.getConfirmType()).list());
	}

	public void updateUserId(final String userid, final String newUserid, final int authFlag) throws Exception {
		this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException, SQLException {
				Sqlca sqlca = null;
				try {
					sqlca = new Sqlca(session.connection());
					String sql = "update ap_channel_user_relation set user_id=?,auth_flag=? where user_id=?";
					log.debug(sql);
					sqlca.execute(sql,new Object[]{newUserid,authFlag,userid});
				} catch (Exception e) {

				} finally {
					if (sqlca != null) {
						sqlca.close();
					}
				}
				return null;
			}
		});
	}
}

/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.form.DimChannelUserRelationForm;
/*     */ import com.ai.bdx.frame.approval.model.DimChannelUserRelation;
/*     */ import com.ai.bdx.frame.approval.model.DimChannelUserRelationId;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class DimChannelUserRelationDaoImpl extends HibernateDaoSupport
/*     */   implements IDimChannelUserRelationDao
/*     */ {
/*  23 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public DimChannelUserRelation getChannelTypeId(Integer resourceId, String userId, Short confirmType)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  34 */       DimChannelUserRelation dimChannelUserRelation = null;
/*  35 */       String sql = "from  DimChannelUserRelation a where a.resourceId=" + resourceId;
/*  36 */       if ((userId != null) && (!userId.equals(""))) {
/*  37 */         sql = sql + " and a.id.userId = '" + userId + "'";
/*     */       }
/*  39 */       if (confirmType != null) {
/*  40 */         sql = sql + " and a.id.confirmType=" + confirmType;
/*     */       }
/*  42 */       List list = getHibernateTemplate().find(sql);
/*  43 */       if ((list != null) && (list.size() > 0));
/*  44 */       return (DimChannelUserRelation)list.get(0);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  48 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public DimChannelUserRelation getChannelTypeId(Short channelType, String channelId, int confirmType)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  58 */       DimChannelUserRelation dimChannelUserRelation = null;
/*  59 */       String sql = "from  DimChannelUserRelation a where 1=1 ";
/*  60 */       if (channelType != null) {
/*  61 */         sql = sql + " and a.id.channeltypeId = " + channelType;
/*     */       }
/*  63 */       if ((channelId != null) && (channelId.trim().length() > 0)) {
/*  64 */         sql = sql + " and a.id.channelId = '" + channelId + "'";
/*     */       }
/*  66 */       if (confirmType != -1) {
/*  67 */         sql = sql + " and a.id.confirmType=" + confirmType;
/*     */       }
/*  69 */       List list = getHibernateTemplate().find(sql);
/*  70 */       if ((list != null) && (list.size() > 0));
/*  71 */       return (DimChannelUserRelation)list.get(0);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  75 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getAllChannelType()
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  85 */       String sql = "from  DimChannelUserRelation";
/*  86 */       return getHibernateTemplate().find(sql);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  90 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void save(DimChannelUserRelation dimChannelUserRelation)
/*     */     throws MpmException
/*     */   {
/*  99 */     getHibernateTemplate().deleteAll(getSession().createQuery("from  DimChannelUserRelation a where a.resourceId=" + dimChannelUserRelation.getResourceId() + " and a.id.confirmType=" + dimChannelUserRelation.getId().getConfirmType()).list());
/* 100 */     getHibernateTemplate().save(dimChannelUserRelation);
/*     */   }
/*     */ 
/*     */   public Map searchChannelUserRelation(DimChannelUserRelationForm searchForm, final Integer curPage, final Integer pageSize)
/*     */     throws MpmException
/*     */   {
/* 108 */     StringBuffer sql = new StringBuffer("from  DimChannelUserRelation a where 1=1 ");
/* 109 */     if (searchForm.getResourceId() != -1) {
/* 110 */       sql.append(" and a.resourceId=").append(searchForm.getResourceId());
/*     */     }
/* 112 */     sql.append(" order by a.resourceId");
/* 113 */     final String sql1 = sql.toString();
/* 114 */     Map map = (Map)getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/* 116 */         Query query = arg0.createQuery(sql1);
/* 117 */         Map map = new HashMap();
/* 118 */         int totalCnt = query.list().size();
/* 119 */         if (totalCnt < 1) {
/* 120 */           map.put("total", Integer.valueOf(0));
/* 121 */           map.put("result", new ArrayList());
/* 122 */           return map;
/*     */         }
/* 124 */         query.setFirstResult(pageSize.intValue() * curPage.intValue());
/* 125 */         query.setMaxResults(pageSize.intValue());
/* 126 */         List list = query.list();
/* 127 */         map.put("total", Integer.valueOf(totalCnt));
/* 128 */         map.put("result", list);
/*     */ 
/* 130 */         return map;
/*     */       }
/*     */     });
/* 134 */     return map;
/*     */   }
/*     */ 
/*     */   public void delete(DimChannelUserRelationForm searchForm)
/*     */     throws MpmException
/*     */   {
/* 142 */     getHibernateTemplate().deleteAll(getSession().createQuery("from  DimChannelUserRelation a where a.resourceId=" + searchForm.getResourceId() + " and a.id.confirmType=" + searchForm.getConfirmType()).list());
/*     */   }
/*     */ 
/*     */   public void updateUserId(final String userid, final String newUserid, final int authFlag) throws Exception {
/* 146 */     getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/* 148 */         Sqlca sqlca = null;
/*     */         try {
/* 150 */           sqlca = new Sqlca(session.connection());
/* 151 */           String sql = "update ap_channel_user_relation set user_id=?,auth_flag=? where user_id=?";
/* 152 */           DimChannelUserRelationDaoImpl.log.debug(sql);
/* 153 */           sqlca.execute(sql, new Object[] { newUserid, Integer.valueOf(authFlag), userid });
/*     */         } catch (Exception e) {
/*     */         }
/*     */         finally {
/* 157 */           if (sqlca != null) {
/* 158 */             sqlca.close();
/*     */           }
/*     */         }
/* 161 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.DimChannelUserRelationDaoImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IDimDeptFlowRelationDAO;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimDeptFlowRelationForm;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;

/**
 * Data access object (DAO) for domain model class DimDeptFlowRelation.
 *
 * @see hibernate.DimDeptFlowRelation
 * @author MyEclipse Persistence Tools
 */

public class DimDeptFlowRelationDAOImpl extends HibernateDaoSupport implements IDimDeptFlowRelationDAO {
	private static Logger log = LogManager.getLogger();
// property constants
public static final String RELATION_TYPE = "relationType";
public static final String APPROVE_FLOW_ID = "approveFlowId";

@Override
protected void initDao() {
// do nothing
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#save(hibernate.DimDeptFlowRelation)
*/
@Override
public void save(DimDeptFlowRelation transientInstance) {
log.debug("saving DimDeptFlowRelation instance");
try {
	getHibernateTemplate().save(transientInstance);
	log.debug("save successful");
} catch (RuntimeException re) {
	log.error("save failed", re);
	throw re;
}
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#delete(hibernate.DimDeptFlowRelation)
*/
@Override
public void delete(DimDeptFlowRelation persistentInstance) {
log.debug("deleting DimDeptFlowRelation instance");
try {
	getHibernateTemplate().delete(persistentInstance);
	log.debug("delete successful");
} catch (RuntimeException re) {
	log.error("delete failed", re);
	throw re;
}
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#findById(hibernate.DimDeptFlowRelationId)
*/
@Override
public DimDeptFlowRelation findById(com.ai.bdx.frame.approval.model.DimDeptFlowRelationId id) {
log.debug("getting DimDeptFlowRelation instance with id: " + id);
try {
	String queryString = "from com.ai.bdx.frame.approval.model.DimDeptFlowRelation rel where rel.id.cityId=? and rel.id.deptId=? and rel.id.campDrvId=? and rel.id.relationType=? and rel.id.flow_type=?";
	Object[] values = new Object[]{id.getCityId(), id.getDeptId(), id.getCampDrvId(), id.getRelationType(), id.getFlow_type()};
	@SuppressWarnings("unchecked")
	List<DimDeptFlowRelation> list = (List<DimDeptFlowRelation>)getHibernateTemplate().find(queryString, values);
	if(list.size()>0){
		return list.get(0);
	}else{
		return null;
	}
} catch (RuntimeException re) {
	log.error("get failed", re);
	throw re;
}
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#findByExample(hibernate.DimDeptFlowRelation)
*/
@Override
public List findByExample(DimDeptFlowRelation instance) {
log.debug("finding DimDeptFlowRelation instance by example");
try {
	List results = getHibernateTemplate().findByExample(instance);
	log.debug("find by example successful, result size: "
			+ results.size());
	return results;
} catch (RuntimeException re) {
	log.error("find by example failed", re);
	throw re;
}
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#findByProperty(java.lang.String, java.lang.Object)
*/
@Override
public List findByProperty(String propertyName, Object value) {
log.debug("finding DimDeptFlowRelation instance with property: "
		+ propertyName + ", value: " + value);
try {
	String queryString = "from DimDeptFlowRelation as model where model."
			+ propertyName + "= ?";
	return getHibernateTemplate().find(queryString, value);
} catch (RuntimeException re) {
	log.error("find by property name failed", re);
	throw re;
}
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#findByRelationType(java.lang.Object)
*/
@Override
public List findByRelationType(Object relationType) {
return findByProperty(RELATION_TYPE, relationType);
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#findByApproveFlowId(java.lang.Object)
*/
@Override
public List findByApproveFlowId(Object approveFlowId) {
return findByProperty(APPROVE_FLOW_ID, approveFlowId);
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#findAll()
*/
@Override
public List findAll() {
log.debug("finding all DimDeptFlowRelation instances");
try {
	String queryString = "from DimDeptFlowRelation";
	return getHibernateTemplate().find(queryString);
} catch (RuntimeException re) {
	log.error("find all failed", re);
	throw re;
}
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#merge(hibernate.DimDeptFlowRelation)
*/
@Override
public DimDeptFlowRelation merge(DimDeptFlowRelation detachedInstance) {
log.debug("merging DimDeptFlowRelation instance");
try {
	DimDeptFlowRelation result = (DimDeptFlowRelation) getHibernateTemplate()
			.merge(detachedInstance);
	log.debug("merge successful");
	return result;
} catch (RuntimeException re) {
	log.error("merge failed", re);
	throw re;
}
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#attachDirty(hibernate.DimDeptFlowRelation)
*/
@Override
public void attachDirty(DimDeptFlowRelation instance) {
log.debug("attaching dirty DimDeptFlowRelation instance");
try {
	getHibernateTemplate().saveOrUpdate(instance);
	log.debug("attach successful");
} catch (RuntimeException re) {
	log.error("attach failed", re);
	throw re;
}
}

/* (non-Javadoc)
* @see hibernate.IDimDeptFlowRelationDAO#attachClean(hibernate.DimDeptFlowRelation)
*/
@Override
public void attachClean(DimDeptFlowRelation instance) {
log.debug("attaching clean DimDeptFlowRelation instance");
try {
	getHibernateTemplate().lock(instance, LockMode.NONE);
	log.debug("attach successful");
} catch (RuntimeException re) {
	log.error("attach failed", re);
	throw re;
}
}

public static IDimDeptFlowRelationDAO getFromApplicationContext(
	ApplicationContext ctx) {
return (IDimDeptFlowRelationDAO) ctx.getBean("DimDeptFlowRelationDAO");
}


//	private Logger log = LogManager.getLogger();

	public DimDeptFlowRelationDAOImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void delete(DimDeptFlowRelationForm searchForm) throws MpmException {
		// TODO Auto-generated method stub

	}

//	public List findAll() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	public DimDeptFlowRelation findById(DimDeptFlowRelationId id) throws MpmException {
//		return (DimDeptFlowRelation)this.getHibernateTemplate().get(DimDeptFlowRelation.class, id);
//	}

	@Override
	public List getAllDeptFlowRelation() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DimDeptFlowRelation getDeptFlowRelation(int rid, Short cType)
			throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}


//	public void save(DimDeptFlowRelation dimDeptFlowRelation)
//			throws MpmException {
//		// TODO Auto-generated method stub
//		this.getHibernateTemplate().saveOrUpdate(dimDeptFlowRelation);
//	}

	@Override
	public Map searchDeptFlowRelation(DimDeptFlowRelationForm searchForm,
			Integer curPage, Integer pageSize) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DimDeptFlowRelation getDeptFlowRelation(Short channelType,
			String channelId, int confirmType) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map findDeptFlowAction(DimDeptFlowRelation dimDeptFlowRelation,final Integer curPage,final Integer  pageSize) throws MpmException {
		// TODO Auto-generated method stub

		final String sql = this.generateSqlForDeptFlow(dimDeptFlowRelation);
		HibernateCallback callback = new HibernateCallback() {
			@Override
			public Object doInHibernate(Session session) throws HibernateException {
				Map map = new HashMap();
				List result = new ArrayList();

				Query query = session.createQuery(sql);

				Integer total = Integer.valueOf(query.list().size());

				query.setFirstResult(pageSize.intValue() * curPage.intValue());
				query.setMaxResults(pageSize.intValue());
				result = query.list();

				Iterator it = result.iterator();

				if (result.size() == 0) {
					map.put("total", Integer.valueOf(0));
					map.put("result", new ArrayList());
					return map;
				}

				map.put("total", total);
				map.put("result", result);
				return map;
			}
		};

		return (Map) getHibernateTemplate().execute(callback);
	}

	private String generateSqlForDeptFlow(DimDeptFlowRelation dimDeptFlowRelation) {
		// TODO Auto-generated method stub
		String sql = "from DimDeptFlowRelation mcb  where 1=1 ";
		if (dimDeptFlowRelation.getId().getApproveFlowId() != null && dimDeptFlowRelation.getId().getApproveFlowId().length() > 0 && !dimDeptFlowRelation.getId().getApproveFlowId().equals("-2")) {
			sql += " and mcb.id.approveFlowId = '" + dimDeptFlowRelation.getId().getApproveFlowId().trim()+"'";
		}

		if (dimDeptFlowRelation.getId().getRelationType() != null &&!dimDeptFlowRelation.getId().getRelationType().trim().equals("-1")) {
			sql += " and mcb.id.relationType ='" + dimDeptFlowRelation.getId().getRelationType()+ "' ";;
		}

		if (dimDeptFlowRelation.getId().getCampDrvId() != null &&!dimDeptFlowRelation.getId().getCampDrvId().trim().equals("-1")) {
			sql += " and mcb.id.campDrvId ='" + dimDeptFlowRelation.getId().getCampDrvId()+ "' ";;
		}


		if (dimDeptFlowRelation.getId().getCityId() != null  && !dimDeptFlowRelation.getId().getCityId().equals("-1")) {
			sql += " and mcb.id.cityId ='" + dimDeptFlowRelation.getId().getCityId().trim() + "' ";
		}

		if (dimDeptFlowRelation.getId().getDeptId() != null  && !dimDeptFlowRelation.getId().getDeptId().equals("-2")) {
			sql += " and mcb.id.deptId ='" + dimDeptFlowRelation.getId().getDeptId().trim() + "' ";
		}


		sql += " order by mcb.id.relationType desc";
		log.debug("============:"+sql+":");
		return sql;
	}


}
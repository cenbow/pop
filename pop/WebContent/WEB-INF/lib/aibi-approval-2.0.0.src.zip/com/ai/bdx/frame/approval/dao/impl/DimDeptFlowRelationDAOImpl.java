/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimDeptFlowRelationDAO;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.form.DimDeptFlowRelationForm;
/*     */ import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;
/*     */ import com.ai.bdx.frame.approval.model.DimDeptFlowRelationId;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class DimDeptFlowRelationDAOImpl extends HibernateDaoSupport
/*     */   implements IDimDeptFlowRelationDAO
/*     */ {
/*  32 */   private static Logger log = LogManager.getLogger();
/*     */   public static final String RELATION_TYPE = "relationType";
/*     */   public static final String APPROVE_FLOW_ID = "approveFlowId";
/*     */ 
/*     */   protected void initDao()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void save(DimDeptFlowRelation transientInstance)
/*     */   {
/*  47 */     log.debug("saving DimDeptFlowRelation instance");
/*     */     try {
/*  49 */       getHibernateTemplate().save(transientInstance);
/*  50 */       log.debug("save successful");
/*     */     } catch (RuntimeException re) {
/*  52 */       log.error("save failed", re);
/*  53 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(DimDeptFlowRelation persistentInstance)
/*     */   {
/*  62 */     log.debug("deleting DimDeptFlowRelation instance");
/*     */     try {
/*  64 */       getHibernateTemplate().delete(persistentInstance);
/*  65 */       log.debug("delete successful");
/*     */     } catch (RuntimeException re) {
/*  67 */       log.error("delete failed", re);
/*  68 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public DimDeptFlowRelation findById(DimDeptFlowRelationId id)
/*     */   {
/*  77 */     log.debug("getting DimDeptFlowRelation instance with id: " + id);
/*     */     try {
/*  79 */       String queryString = "from com.ai.bdx.frame.approval.model.DimDeptFlowRelation rel where rel.id.cityId=? and rel.id.deptId=? and rel.id.campDrvId=? and rel.id.relationType=? and rel.id.flow_type=?";
/*  80 */       Object[] values = { id.getCityId(), id.getDeptId(), id.getCampDrvId(), id.getRelationType(), id.getFlow_type() };
/*     */ 
/*  82 */       List list = getHibernateTemplate().find(queryString, values);
/*  83 */       if (list.size() > 0) {
/*  84 */         return (DimDeptFlowRelation)list.get(0);
/*     */       }
/*  86 */       return null;
/*     */     }
/*     */     catch (RuntimeException re) {
/*  89 */       log.error("get failed", re);
/*  90 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findByExample(DimDeptFlowRelation instance)
/*     */   {
/*  99 */     log.debug("finding DimDeptFlowRelation instance by example");
/*     */     try {
/* 101 */       List results = getHibernateTemplate().findByExample(instance);
/* 102 */       log.debug("find by example successful, result size: " + results.size());
/*     */ 
/* 104 */       return results;
/*     */     } catch (RuntimeException re) {
/* 106 */       log.error("find by example failed", re);
/* 107 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findByProperty(String propertyName, Object value)
/*     */   {
/* 116 */     log.debug("finding DimDeptFlowRelation instance with property: " + propertyName + ", value: " + value);
/*     */     try
/*     */     {
/* 119 */       String queryString = "from DimDeptFlowRelation as model where model." + propertyName + "= ?";
/*     */ 
/* 121 */       return getHibernateTemplate().find(queryString, value);
/*     */     } catch (RuntimeException re) {
/* 123 */       log.error("find by property name failed", re);
/* 124 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findByRelationType(Object relationType)
/*     */   {
/* 133 */     return findByProperty("relationType", relationType);
/*     */   }
/*     */ 
/*     */   public List findByApproveFlowId(Object approveFlowId)
/*     */   {
/* 141 */     return findByProperty("approveFlowId", approveFlowId);
/*     */   }
/*     */ 
/*     */   public List findAll()
/*     */   {
/* 149 */     log.debug("finding all DimDeptFlowRelation instances");
/*     */     try {
/* 151 */       String queryString = "from DimDeptFlowRelation";
/* 152 */       return getHibernateTemplate().find(queryString);
/*     */     } catch (RuntimeException re) {
/* 154 */       log.error("find all failed", re);
/* 155 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public DimDeptFlowRelation merge(DimDeptFlowRelation detachedInstance)
/*     */   {
/* 164 */     log.debug("merging DimDeptFlowRelation instance");
/*     */     try {
/* 166 */       DimDeptFlowRelation result = (DimDeptFlowRelation)getHibernateTemplate().merge(detachedInstance);
/*     */ 
/* 168 */       log.debug("merge successful");
/* 169 */       return result;
/*     */     } catch (RuntimeException re) {
/* 171 */       log.error("merge failed", re);
/* 172 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void attachDirty(DimDeptFlowRelation instance)
/*     */   {
/* 181 */     log.debug("attaching dirty DimDeptFlowRelation instance");
/*     */     try {
/* 183 */       getHibernateTemplate().saveOrUpdate(instance);
/* 184 */       log.debug("attach successful");
/*     */     } catch (RuntimeException re) {
/* 186 */       log.error("attach failed", re);
/* 187 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void attachClean(DimDeptFlowRelation instance)
/*     */   {
/* 196 */     log.debug("attaching clean DimDeptFlowRelation instance");
/*     */     try {
/* 198 */       getHibernateTemplate().lock(instance, LockMode.NONE);
/* 199 */       log.debug("attach successful");
/*     */     } catch (RuntimeException re) {
/* 201 */       log.error("attach failed", re);
/* 202 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static IDimDeptFlowRelationDAO getFromApplicationContext(ApplicationContext ctx)
/*     */   {
/* 208 */     return (IDimDeptFlowRelationDAO)ctx.getBean("DimDeptFlowRelationDAO");
/*     */   }
/*     */ 
/*     */   public void delete(DimDeptFlowRelationForm searchForm)
/*     */     throws MpmException
/*     */   {
/*     */   }
/*     */ 
/*     */   public List getAllDeptFlowRelation()
/*     */     throws MpmException
/*     */   {
/* 236 */     return null;
/*     */   }
/*     */ 
/*     */   public DimDeptFlowRelation getDeptFlowRelation(int rid, Short cType)
/*     */     throws MpmException
/*     */   {
/* 243 */     return null;
/*     */   }
/*     */ 
/*     */   public Map searchDeptFlowRelation(DimDeptFlowRelationForm searchForm, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/* 257 */     return null;
/*     */   }
/*     */ 
/*     */   public DimDeptFlowRelation getDeptFlowRelation(Short channelType, String channelId, int confirmType)
/*     */     throws MpmException
/*     */   {
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */   public Map findDeptFlowAction(DimDeptFlowRelation dimDeptFlowRelation, final Integer curPage, final Integer pageSize)
/*     */     throws MpmException
/*     */   {
/* 271 */     final String sql = generateSqlForDeptFlow(dimDeptFlowRelation);
/* 272 */     HibernateCallback callback = new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session session) throws HibernateException {
/* 275 */         Map map = new HashMap();
/* 276 */         List result = new ArrayList();
/*     */ 
/* 278 */         Query query = session.createQuery(sql);
/*     */ 
/* 280 */         Integer total = Integer.valueOf(query.list().size());
/*     */ 
/* 282 */         query.setFirstResult(pageSize.intValue() * curPage.intValue());
/* 283 */         query.setMaxResults(pageSize.intValue());
/* 284 */         result = query.list();
/*     */ 
/* 286 */         Iterator it = result.iterator();
/*     */ 
/* 288 */         if (result.size() == 0) {
/* 289 */           map.put("total", Integer.valueOf(0));
/* 290 */           map.put("result", new ArrayList());
/* 291 */           return map;
/*     */         }
/*     */ 
/* 294 */         map.put("total", total);
/* 295 */         map.put("result", result);
/* 296 */         return map;
/*     */       }
/*     */     };
/* 300 */     return (Map)getHibernateTemplate().execute(callback);
/*     */   }
/*     */ 
/*     */   private String generateSqlForDeptFlow(DimDeptFlowRelation dimDeptFlowRelation)
/*     */   {
/* 305 */     String sql = "from DimDeptFlowRelation mcb  where 1=1 ";
/* 306 */     if ((dimDeptFlowRelation.getId().getApproveFlowId() != null) && (dimDeptFlowRelation.getId().getApproveFlowId().length() > 0) && (!dimDeptFlowRelation.getId().getApproveFlowId().equals("-2"))) {
/* 307 */       sql = sql + " and mcb.id.approveFlowId = '" + dimDeptFlowRelation.getId().getApproveFlowId().trim() + "'";
/*     */     }
/*     */ 
/* 310 */     if ((dimDeptFlowRelation.getId().getRelationType() != null) && (!dimDeptFlowRelation.getId().getRelationType().trim().equals("-1"))) {
/* 311 */       sql = sql + " and mcb.id.relationType ='" + dimDeptFlowRelation.getId().getRelationType() + "' ";
/*     */     }
/*     */ 
/* 314 */     if ((dimDeptFlowRelation.getId().getCampDrvId() != null) && (!dimDeptFlowRelation.getId().getCampDrvId().trim().equals("-1"))) {
/* 315 */       sql = sql + " and mcb.id.campDrvId ='" + dimDeptFlowRelation.getId().getCampDrvId() + "' ";
/*     */     }
/*     */ 
/* 319 */     if ((dimDeptFlowRelation.getId().getCityId() != null) && (!dimDeptFlowRelation.getId().getCityId().equals("-1"))) {
/* 320 */       sql = sql + " and mcb.id.cityId ='" + dimDeptFlowRelation.getId().getCityId().trim() + "' ";
/*     */     }
/*     */ 
/* 323 */     if ((dimDeptFlowRelation.getId().getDeptId() != null) && (!dimDeptFlowRelation.getId().getDeptId().equals("-2"))) {
/* 324 */       sql = sql + " and mcb.id.deptId ='" + dimDeptFlowRelation.getId().getDeptId().trim() + "' ";
/*     */     }
/*     */ 
/* 328 */     sql = sql + " order by mcb.id.relationType desc";
/* 329 */     log.debug("============:" + sql + ":");
/* 330 */     return sql;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.DimDeptFlowRelationDAOImpl
 * JD-Core Version:    0.6.2
 */
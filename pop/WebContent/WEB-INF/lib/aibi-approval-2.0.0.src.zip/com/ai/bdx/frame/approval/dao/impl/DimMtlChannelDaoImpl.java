/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.form.DimMtlChannelForm;
/*     */ import com.ai.bdx.frame.approval.model.DimMtlChannel;
/*     */ import com.ai.bdx.frame.approval.util.MpmUtil;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class DimMtlChannelDaoImpl extends HibernateDaoSupport
/*     */   implements IDimMtlChannelDao
/*     */ {
/*     */   public List findMtlChannel(final DimMtlChannel channel)
/*     */     throws Exception
/*     */   {
/*  51 */     boolean flag = false;
/*  52 */     if ((channel.getCampId() != null) && (channel.getCampId().length() > 0)) {
/*  53 */       String sql2 = "select count(*) from mtl_camp_channeltype a where a.camp_id=:camp_id  and a.channeltype_id=:channeltype_id";
/*  54 */       final String strSql2 = sql2;
/*  55 */       List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session session) throws HibernateException, SQLException
/*     */         {
/*  59 */           Query query = session.createSQLQuery(strSql2);
/*  60 */           query.setParameter("camp_id", channel.getCampId());
/*  61 */           query.setParameter("channeltype_id", Integer.valueOf(channel.getChanneltypeId().intValue()));
/*     */ 
/*  63 */           return query.list();
/*     */         }
/*     */       });
/*  66 */       int listsize = 0;
/*  67 */       String dbtype = Configure.getInstance().getProperty("MPM_DBTYPE");
/*  68 */       if ("db2".equalsIgnoreCase(dbtype))
/*  69 */         listsize = ((Integer)list.get(0)).intValue();
/*  70 */       else if ("mysql".equalsIgnoreCase(dbtype)) {
/*  71 */         listsize = ((BigInteger)list.get(0)).intValue();
/*     */       }
/*     */       else {
/*  74 */         listsize = ((BigDecimal)list.get(0)).intValue();
/*     */       }
/*  76 */       if (listsize > 0) {
/*  77 */         flag = true;
/*     */       }
/*     */     }
/*     */ 
/*  81 */     StringBuffer sql = new StringBuffer("from DimMtlChannel dmc where 1=1 ");
/*  82 */     if (channel != null) {
/*  83 */       if (channel.getChanneltypeId() != null) {
/*  84 */         sql.append(" and dmc.channeltypeId=").append(channel.getChanneltypeId());
/*     */       }
/*     */ 
/*  87 */       if ((channel.getChannelId() != null) && (channel.getChannelId().length() > 0))
/*     */       {
/*  89 */         if (channel.getChannelId().indexOf(",") > 0) {
/*  90 */           sql.append(" and dmc.channelId in (").append(MpmUtil.formatSqlInString(channel.getChannelId())).append(")");
/*     */         }
/*     */         else
/*     */         {
/*  94 */           sql.append(" and dmc.channelId='").append(channel.getChannelId()).append("'");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  99 */       if (flag) {
/* 100 */         sql.append(" and dmc.channelId in(select a.id.channelId from MtlCampChanneltype as a where a.id.campId='").append(channel.getCampId()).append("' and a.id.channeltypeId=").append(channel.getChanneltypeId()).append(")");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 114 */     sql.append(" order by dmc.channelId");
/* 115 */     final String strSql = sql.toString();
/* 116 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/* 119 */         Query query = session.createQuery(strSql);
/* 120 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public DimMtlChannel getMtlChannel(String channelId)
/*     */     throws Exception
/*     */   {
/* 134 */     return (DimMtlChannel)getHibernateTemplate().get(DimMtlChannel.class, channelId);
/*     */   }
/*     */ 
/*     */   public void delete(DimMtlChannelForm searchForm)
/*     */     throws MpmException
/*     */   {
/* 147 */     getHibernateTemplate().deleteAll(getSession().createQuery("from  DimMtlChannel a where a.channelId=" + searchForm.getChannelId()).list());
/*     */   }
/*     */ 
/*     */   public void save(DimMtlChannel dimMtlChannel)
/*     */     throws MpmException
/*     */   {
/* 163 */     getHibernateTemplate().deleteAll(getSession().createQuery("from  DimMtlChannel a where a.channelId='" + dimMtlChannel.getChannelId() + "'").list());
/*     */ 
/* 169 */     getHibernateTemplate().save(dimMtlChannel);
/*     */   }
/*     */ 
/*     */   public Map searchMtlChannel(DimMtlChannelForm searchForm, final Integer curPage, final Integer pageSize)
/*     */     throws MpmException
/*     */   {
/* 182 */     String sql = "from  DimMtlChannel a where 1=1 ";
/* 183 */     if (searchForm.getChanneltypeId().shortValue() != -1) {
/* 184 */       sql = sql + " and a.channeltypeId=" + searchForm.getChanneltypeId();
/*     */     }
/* 186 */     sql = sql + " order by a.channeltypeId";
/* 187 */     final String sql1 = sql;
/* 188 */     Map map = (Map)getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session arg0) throws HibernateException, SQLException
/*     */       {
/* 192 */         Query query = arg0.createQuery(sql1);
/* 193 */         Map map = new HashMap();
/* 194 */         int totalCnt = query.list().size();
/* 195 */         if (totalCnt < 1) {
/* 196 */           map.put("total", Integer.valueOf(0));
/* 197 */           map.put("result", new ArrayList());
/* 198 */           return map;
/*     */         }
/* 200 */         query.setFirstResult(pageSize.intValue() * curPage.intValue());
/*     */ 
/* 202 */         query.setMaxResults(pageSize.intValue());
/* 203 */         List list = query.list();
/* 204 */         map.put("total", Integer.valueOf(totalCnt));
/* 205 */         map.put("result", list);
/*     */ 
/* 207 */         return map;
/*     */       }
/*     */     });
/* 210 */     return map;
/*     */   }
/*     */ 
/*     */   public List getAllMmsContentByType(String typeId)
/*     */   {
/* 215 */     String sql = "from BsMmsContent bmc where bmc.bsMmsType.id='" + typeId + "' and bmc.status = 0";
/*     */ 
/* 217 */     final String tmpSql = sql;
/* 218 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 221 */         Query query = s.createQuery(tmpSql);
/* 222 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List getAllMmsType() {
/* 228 */     String sql = "from BsMmsType bmt where bmt.channelType='MMS'";
/* 229 */     final String tmpSql = sql;
/* 230 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 233 */         Query query = s.createQuery(tmpSql);
/* 234 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public String getTypeName(final String id) {
/* 240 */     String sql = "select bmt.name from BsMmsType bmt where bmt.channelType='MMS' and id=:id";
/* 241 */     String name = id;
/* 242 */     final String tmpSql = sql;
/* 243 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 246 */         Query query = s.createQuery(tmpSql);
/* 247 */         query.setParameter("id", id);
/* 248 */         return query.list();
/*     */       }
/*     */     });
/* 252 */     if ((list != null) && (!list.isEmpty())) {
/* 253 */       name = (String)list.get(0);
/*     */     }
/*     */ 
/* 256 */     return name;
/*     */   }
/*     */ 
/*     */   public List getBsChannelsByType(String channelType) {
/* 260 */     String sql = "from BsChannel bc where bc.channelType='" + channelType + "'";
/*     */ 
/* 262 */     final String tmpSql = sql;
/* 263 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 266 */         Query query = s.createQuery(tmpSql);
/* 267 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List<DimMtlChannel> getChannelsByType(Short channeltypeId)
/*     */     throws MpmException
/*     */   {
/* 275 */     String hql = "from DimMtlChannel a where a.channeltypeId = ? order by a.channelId";
/* 276 */     return getHibernateTemplate().find(hql, channeltypeId);
/*     */   }
/*     */ 
/*     */   public List<DimMtlChannel> getChannelsByType(Short channeltypeId, String createUser)
/*     */     throws MpmException
/*     */   {
/* 282 */     String hql = "from DimMtlChannel a where a.channeltypeId = " + channeltypeId + " and (a.createUser = '" + createUser + "' or a.createUser is null)";
/*     */ 
/* 285 */     return getHibernateTemplate().find(hql);
/*     */   }
/*     */ 
/*     */   public List<DimMtlChannel> getOneChannelForEachType(Short channeltypeId)
/*     */     throws MpmException
/*     */   {
/* 297 */     String hql = "from DimMtlChannel a where a.channeltypeId = " + channeltypeId + " and a.channelId not in (select distinct b.campId from DimMtlChannel b where (b.campId is not null and b.campId<>'')) " + " ) order by a.channelId";
/*     */ 
/* 301 */     getHibernateTemplate().setMaxResults(1);
/* 302 */     List list = getHibernateTemplate().find(hql);
/* 303 */     getHibernateTemplate().setMaxResults(0);
/* 304 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.DimMtlChannelDaoImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChannelForm;
import com.ai.bdx.frame.approval.model.DimMtlChannel;
import com.ai.bdx.frame.approval.util.MpmUtil;
import com.asiainfo.biframe.utils.config.Configure;

/**
 * Created on Jan 10, 2008 1:52:14 PM
 *
 * <p>
 * Title:
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: asiainfo.,Ltd
 * </p>
 * 
 * @author weilin.wu wuwl2@asiainfo.com
 * @version 1.0
 */
public class DimMtlChannelDaoImpl extends HibernateDaoSupport implements
		IDimMtlChannelDao {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimMtlChannelDao#findMtlChannel(com.ai
	 * .bdx.frame.approval.model.DimMtlChannel)
	 */
	public List findMtlChannel(final DimMtlChannel channel) throws Exception {
		boolean flag = false;
		if (channel.getCampId() != null && channel.getCampId().length() > 0) {
			String sql2 = "select count(*) from mtl_camp_channeltype a where a.camp_id=:camp_id  and a.channeltype_id=:channeltype_id";
			final String strSql2 = sql2;
			List list = this.getHibernateTemplate().executeFind(
					new HibernateCallback() {
						public Object doInHibernate(Session session)
								throws HibernateException, SQLException {
							Query query = session.createSQLQuery(strSql2);
							query.setParameter("camp_id", channel.getCampId());
							query.setParameter("channeltype_id", channel
									.getChanneltypeId().intValue());
							return query.list();
						}
					});
			int listsize = 0;
			String dbtype = Configure.getInstance().getProperty("MPM_DBTYPE");
			if ("db2".equalsIgnoreCase(dbtype)) {
				listsize = (Integer) list.get(0);
			} else if ("mysql".equalsIgnoreCase(dbtype)) {
				listsize = ((java.math.BigInteger) list.get(0)).intValue();

			} else {// Oracle
				listsize = ((java.math.BigDecimal) list.get(0)).intValue();
			}
			if (listsize > 0) {
				flag = true;
			}
		}

		StringBuffer sql = new StringBuffer("from DimMtlChannel dmc where 1=1 ");
		if (channel != null) {
			if (channel.getChanneltypeId() != null) {
				sql.append(" and dmc.channeltypeId=").append(
						channel.getChanneltypeId());
			}
			if (channel.getChannelId() != null
					&& channel.getChannelId().length() > 0) {
				if (channel.getChannelId().indexOf(",") > 0) {
					sql.append(" and dmc.channelId in (")
							.append(MpmUtil.formatSqlInString(channel
									.getChannelId())).append(")");
				} else {
					sql.append(" and dmc.channelId='")
							.append(channel.getChannelId()).append("'");
				}
			}
			// 对应营销案已经有限制渠道类型了
			if (flag) {
				sql.append(
						" and dmc.channelId in(select a.id.channelId from MtlCampChanneltype as a where a.id.campId='")
						.append(channel.getCampId())
						.append("' and a.id.channeltypeId=")
						.append(channel.getChanneltypeId()).append(")");
			}
			/*
			 * boolean ifo =
			 * BooleanUtils.toBoolean(Configure.getInstance().getProperty
			 * ("IN_FLOW_OPERATION")); if (ifo) {//流量运营流程 sql +=
			 * " and dmc.channelId not in (SELECT distinct mcd.channelId FROM  MtlCampSeginfo as mcs , MtlChannelDef as mcd WHERE mcs.campsegId=mcd.id.campsegId and mcs.campsegStatId < 90 and mcd.channeltypeId="
			 * + channel.getChanneltypeId() + ")"; }
			 */
		}
		sql.append(" order by dmc.channelId");
		final String strSql = sql.toString();
		return this.getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session session)
					throws HibernateException, SQLException {
				Query query = session.createQuery(strSql);
				return query.list();
			}

		});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimMtlChannelDao#getMtlChannel(java.lang
	 * .String)
	 */
	public DimMtlChannel getMtlChannel(String channelId) throws Exception {
		return (DimMtlChannel) this.getHibernateTemplate().get(
				DimMtlChannel.class, channelId);
	}

	/*
	 * （非 Javadoc）
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimMtlChannelDao#delete(com.ai.bdx.frame
	 * .approval.form.DimMtlChannelForm)
	 */
	public void delete(DimMtlChannelForm searchForm) throws MpmException {
		// TODO 自动生成方法存根
		this.getHibernateTemplate().deleteAll(
				this.getSession()
						.createQuery(
								"from  DimMtlChannel a where a.channelId="
										+ searchForm.getChannelId()).list());
	}

	/*
	 * （非 Javadoc）
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimMtlChannelDao#save(com.ai.bdx.frame
	 * .approval.model.DimMtlChannel)
	 */
	public void save(final DimMtlChannel dimMtlChannel) throws MpmException {
		// TODO 自动生成方法存根
		this.getHibernateTemplate().deleteAll(
				this.getSession()
						.createQuery(
								"from  DimMtlChannel a where a.channelId='"
										+ dimMtlChannel.getChannelId() + "'")
						.list());
		this.getHibernateTemplate().save(dimMtlChannel);
	}

	/*
	 * （非 Javadoc）
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IDimMtlChannelDao#searchMtlChannel(com.
	 * ai.bdx.frame.approval.form.DimMtlChannelForm, java.lang.Integer,
	 * java.lang.Integer)
	 */
	public Map searchMtlChannel(DimMtlChannelForm searchForm,
			final Integer curPage, final Integer pageSize) throws MpmException {
		String sql = "from  DimMtlChannel a where 1=1 ";
		if (searchForm.getChanneltypeId().shortValue() != -1) {
			sql += " and a.channeltypeId=" + searchForm.getChanneltypeId();
		}
		sql += " order by a.channeltypeId";
		final String sql1 = sql;
		Map map = (Map) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session arg0)
							throws HibernateException, SQLException {
						Query query = arg0.createQuery(sql1);
						Map map = new HashMap();
						int totalCnt = query.list().size();
						if (totalCnt < 1) {
							map.put("total", Integer.valueOf(0));
							map.put("result", new ArrayList());
							return map;
						}
						query.setFirstResult(pageSize.intValue()
								* curPage.intValue());
						query.setMaxResults(pageSize.intValue());
						List list = query.list();
						map.put("total", Integer.valueOf(totalCnt));
						map.put("result", list);

						return map;
					}
				});
		return map;
	}
	
	// bmc.status = 0有效，1删除；
	public List getAllMmsContentByType(String typeId) {
		String sql = "from BsMmsContent bmc where bmc.bsMmsType.id='" + typeId
				+ "' and bmc.status = 0";
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	public List getAllMmsType() {
		String sql = "from BsMmsType bmt where bmt.channelType='MMS'";
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	public String getTypeName(final String id) {
		String sql = "select bmt.name from BsMmsType bmt where bmt.channelType='MMS' and id=:id";
		String name = id;
		final String tmpSql = sql;
		List list = getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);
				query.setParameter("id", id);
				return query.list();
			}
		});

		if (list != null && !list.isEmpty()) {
			name = (String) list.get(0);
		}

		return name;
	}

	public List getBsChannelsByType(String channelType) {
		String sql = "from BsChannel bc where bc.channelType='" + channelType
				+ "'";
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	@Override
	public List<DimMtlChannel> getChannelsByType(Short channeltypeId)
			throws MpmException {
		String hql = "from DimMtlChannel a where a.channeltypeId = ? order by a.channelId";
		return getHibernateTemplate().find(hql, channeltypeId);
	}

	@Override
	public List<DimMtlChannel> getChannelsByType(Short channeltypeId,
			String createUser) throws MpmException {
		String hql = "from DimMtlChannel a where a.channeltypeId = "
				+ channeltypeId + " and (a.createUser = '" + createUser
				+ "' or a.createUser is null)";
		return getHibernateTemplate().find(hql);
	}

	/**
	 * 为每个渠道类型获取一个对应的渠道
	 * 
	 * @return
	 * @throws MpmException
	 */
	@Override
	public List<DimMtlChannel> getOneChannelForEachType(Short channeltypeId)
			throws MpmException {
		String hql = "from DimMtlChannel a where a.channeltypeId = "
				+ channeltypeId
				+ " and a.channelId not in (select distinct b.campId from DimMtlChannel b where (b.campId is not null and b.campId<>'')) "
				+ " ) order by a.channelId";
		getHibernateTemplate().setMaxResults(1);
		List list = getHibernateTemplate().find(hql);
		getHibernateTemplate().setMaxResults(0);
		return list;
	}
}

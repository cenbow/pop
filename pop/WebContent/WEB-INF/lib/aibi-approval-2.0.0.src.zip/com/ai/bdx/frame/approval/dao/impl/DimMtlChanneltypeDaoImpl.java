/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm;
/*     */ import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class DimMtlChanneltypeDaoImpl extends HibernateDaoSupport
/*     */   implements IDimMtlChanneltypeDao
/*     */ {
/*  41 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public DimMtlChanneltype getMtlChanneltype(Short channeltypeId) throws Exception {
/*  44 */     return (DimMtlChanneltype)getHibernateTemplate().get(DimMtlChanneltype.class, channeltypeId);
/*     */   }
/*     */ 
/*     */   public List findMtlChanneltype(DimMtlChanneltype type) throws Exception {
/*  48 */     String sql = "from DimMtlChanneltype dmc where 1=1 ";
/*  49 */     if ((type != null) && 
/*  50 */       (type.getChanneltypeId() != null)) {
/*  51 */       sql = sql + " and dmc.channeltypeId=" + type.getChanneltypeId();
/*     */     }
/*     */ 
/*  54 */     sql = sql + " order by dmc.channeltypeId";
/*  55 */     final String strSql = sql;
/*  56 */     return (List)getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/*  58 */         Query query = session.createQuery(strSql);
/*  59 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void delete(DimMtlChanneltypeForm searchForm)
/*     */     throws MpmException
/*     */   {
/*  70 */     getHibernateTemplate().deleteAll(getSession().createQuery("from  DimMtlChanneltype a where a.channeltypeId=" + searchForm.getChanneltypeId()).list());
/*     */   }
/*     */ 
/*     */   public void save(DimMtlChanneltype dimMtlChanneltype)
/*     */     throws MpmException
/*     */   {
/*  78 */     getHibernateTemplate().deleteAll(getSession().createQuery("from  DimMtlChanneltype a where a.channeltypeId=" + dimMtlChanneltype.getChanneltypeId()).list());
/*  79 */     getHibernateTemplate().save(dimMtlChanneltype);
/*     */   }
/*     */ 
/*     */   public Map searchMtlChanneltype(DimMtlChanneltypeForm searchForm, final Integer curPage, final Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*  87 */     String sql = "from  DimMtlChanneltype a where 1=1 ";
/*  88 */     if (searchForm.getChanneltypeId().shortValue() != -1) {
/*  89 */       sql = sql + " and a.channeltypeId=" + searchForm.getChanneltypeId();
/*     */     }
/*  91 */     sql = sql + " order by a.channeltypeId";
/*  92 */     final String sql1 = sql;
/*  93 */     Map map = (Map)getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/*  95 */         Query query = arg0.createQuery(sql1);
/*  96 */         Map map = new HashMap();
/*  97 */         int totalCnt = query.list().size();
/*  98 */         if (totalCnt < 1) {
/*  99 */           map.put("total", Integer.valueOf(0));
/* 100 */           map.put("result", new ArrayList());
/* 101 */           return map;
/*     */         }
/* 103 */         query.setFirstResult(pageSize.intValue() * curPage.intValue());
/* 104 */         query.setMaxResults(pageSize.intValue());
/* 105 */         List list = query.list();
/* 106 */         map.put("total", Integer.valueOf(totalCnt));
/* 107 */         map.put("result", list);
/*     */ 
/* 109 */         return map;
/*     */       }
/*     */     });
/* 112 */     return map;
/*     */   }
/*     */ 
/*     */   public Integer findContactTypeByChannelType(final Integer channelTypeId) throws MpmException
/*     */   {
/* 117 */     String sql = "select a.contactType from DimMtlChanneltype a where a.channeltypeId=:channeltypeId";
/* 118 */     Integer contactType = (Integer)getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/* 120 */         Query query = arg0.createQuery("select a.contactType from DimMtlChanneltype a where a.channeltypeId=:channeltypeId");
/* 121 */         query.setParameter("channeltypeId", Short.valueOf(channelTypeId.shortValue()));
/* 122 */         return query.uniqueResult();
/*     */       }
/*     */     });
/* 125 */     return contactType;
/*     */   }
/*     */ 
/*     */   public Short findContactTypeByChannelTypeAndId(final Short channelTypeId, final String channelId) throws MpmException {
/* 129 */     Short contactType = Short.valueOf((short)1);
/*     */ 
/* 132 */     String allSql = "select a.contactType from MtlDimContactControlType a where a.channeltypeId=:channeltypeId";
/* 133 */     List contactList = (List)getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/* 135 */         Query query = arg0.createQuery("select a.contactType from MtlDimContactControlType a where a.channeltypeId=:channeltypeId");
/* 136 */         query.setParameter("channeltypeId", channelTypeId);
/* 137 */         return query.list();
/*     */       }
/*     */     });
/* 142 */     if ((contactList != null) && (contactList.size() > 1)) {
/* 143 */       String sql = "select a.contactType from MtlDimContactControlType a where a.channeltypeId=:channelTypeId and a.channelId=:channelId";
/*     */ 
/* 145 */       List contactListMuti = (List)getHibernateTemplate().execute(new HibernateCallback() {
/*     */         public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/* 147 */           Query query = arg0.createQuery("select a.contactType from MtlDimContactControlType a where a.channeltypeId=:channelTypeId and a.channelId=:channelId");
/* 148 */           query.setParameter("channelTypeId", channelTypeId);
/* 149 */           query.setParameter("channelId", channelId);
/* 150 */           return query.list();
/*     */         }
/*     */       });
/* 154 */       if ((contactListMuti != null) && (contactListMuti.size() > 0)) {
/* 155 */         contactList.clear();
/* 156 */         contactList.addAll(contactListMuti);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 163 */     if ((contactList != null) && (contactList.size() > 0)) {
/* 164 */       contactType = (Short)contactList.get(0);
/*     */     }
/*     */ 
/* 167 */     return contactType;
/*     */   }
/*     */ 
/*     */   public Integer getSendOddTypeByChannelType(final Integer channelTypeId) throws MpmException
/*     */   {
/* 172 */     String sql = "select a.autoSendOdd from DimMtlChanneltype a where a.channeltypeId=:channelTypeId";
/* 173 */     Integer autoSendOdd = (Integer)getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/* 175 */         Query query = arg0.createQuery("select a.autoSendOdd from DimMtlChanneltype a where a.channeltypeId=:channelTypeId");
/* 176 */         query.setParameter("channelTypeId", Short.valueOf(channelTypeId.shortValue()));
/* 177 */         return query.uniqueResult();
/*     */       }
/*     */     });
/* 180 */     return autoSendOdd;
/*     */   }
/*     */ 
/*     */   public List<DimMtlChanneltype> getAllChannelType(String containsEvent) throws MpmException {
/* 184 */     String sql = "from DimMtlChanneltype where 1 = 1 ";
/* 185 */     if ((StringUtil.isNotEmpty(containsEvent)) && ("1".equals(containsEvent))) {
/* 186 */       sql = sql + " and initiativeType = ? order by displayOrder ";
/* 187 */       return getHibernateTemplate().find(sql, Integer.valueOf(containsEvent));
/*     */     }
/* 189 */     sql = sql + " order by displayOrder ";
/* 190 */     return getHibernateTemplate().find(sql);
/*     */   }
/*     */ 
/*     */   public List<DimMtlChanneltype> getAllChannelType(String containsEvent, String isRejectWebGateWay)
/*     */     throws MpmException
/*     */   {
/* 196 */     StringBuffer sql = new StringBuffer("from DimMtlChanneltype where 1 = 1 ");
/* 197 */     if ((StringUtil.isNotEmpty(isRejectWebGateWay)) && ("1".equals(isRejectWebGateWay))) {
/* 198 */       sql.append(" and  channeltypeId !=914");
/*     */     }
/* 200 */     if ((StringUtil.isNotEmpty(containsEvent)) && ("1".equals(containsEvent))) {
/* 201 */       sql.append(" and initiativeType = ? order by displayOrder ");
/* 202 */       return getHibernateTemplate().find(sql.toString(), Integer.valueOf(containsEvent));
/*     */     }
/* 204 */     sql.append(" order by displayOrder ");
/* 205 */     return getHibernateTemplate().find(sql.toString());
/*     */   }
/*     */ 
/*     */   public List getAllChannelTypeForSys(String SysId) throws MpmException
/*     */   {
/* 210 */     String sql = "select distinct dim from DimMtlChanneltype dim,MtlSysChannelRelation b where 1 = 1 and dim.channeltypeId=b.channelTypeId and b.systemId=?";
/* 211 */     return getHibernateTemplate().find(sql, new Object[] { SysId });
/*     */   }
/*     */ 
/*     */   public List getAllChannelTypeFromUserChannelRelation()
/*     */     throws MpmException
/*     */   {
/* 221 */     ConnectionEx conn = null;
/* 222 */     Sqlca sqlca = null;
/*     */ 
/* 224 */     String sql = "select distinct(cr.prefer_channel) as prefer_channel from mcd_user_channel_relation cr order by cr.prefer_channel";
/* 225 */     List list = new ArrayList();
/*     */     try
/*     */     {
/* 228 */       conn = new ConnectionEx("JDBC_APP");
/* 229 */       sqlca = new Sqlca(conn);
/* 230 */       String finaSQL = sqlca.getPagedSql(sql, 1, 1000);
/* 231 */       sqlca.execute(finaSQL);
/* 232 */       String channeltype_id = null;
/* 233 */       while (sqlca.next()) {
/* 234 */         channeltype_id = sqlca.getString("prefer_channel");
/* 235 */         list.add(channeltype_id);
/*     */       }
/*     */     } catch (Exception e) {
/* 238 */       log.error("", e);
/*     */     } finally {
/* 240 */       if (sqlca != null)
/* 241 */         sqlca.close();
/*     */       try {
/* 243 */         if (!conn.isClosed())
/* 244 */           conn.close();
/*     */       }
/*     */       catch (Exception e) {
/* 247 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 250 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.DimMtlChanneltypeDaoImpl
 * JD-Core Version:    0.6.2
 */
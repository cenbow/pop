package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm;
import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
import com.asiainfo.biframe.utils.string.StringUtil;

/**
 * Created on Jan 4, 2008 5:03:41 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class DimMtlChanneltypeDaoImpl extends HibernateDaoSupport implements IDimMtlChanneltypeDao {

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao#getMtlChanneltype(java.lang.Short)
	 */
	private static Logger log = LogManager.getLogger();
	
	public DimMtlChanneltype getMtlChanneltype(Short channeltypeId) throws Exception {
		return (DimMtlChanneltype) this.getHibernateTemplate().get(DimMtlChanneltype.class, channeltypeId);
	}

	public List findMtlChanneltype(DimMtlChanneltype type) throws Exception {
		String sql = "from DimMtlChanneltype dmc where 1=1 ";
		if (type != null) {
			if (type.getChanneltypeId() != null) {
				sql += " and dmc.channeltypeId=" + type.getChanneltypeId();
			}
		}
		sql += " order by dmc.channeltypeId";
		final String strSql = sql;
		return (List) this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException, SQLException {
				Query query = session.createQuery(strSql);
				return query.list();
			}

		});
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao#delete(com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm)
	 */
	public void delete(final DimMtlChanneltypeForm searchForm) throws MpmException {
		// TODO 自动生成方法存根
		this.getHibernateTemplate().deleteAll(this.getSession().createQuery("from  DimMtlChanneltype a where a.channeltypeId=" + searchForm.getChanneltypeId()).list());
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao#save(com.ai.bdx.frame.approval.model.DimMtlChanneltype)
	 */
	public void save(DimMtlChanneltype dimMtlChanneltype) throws MpmException {
		// TODO 自动生成方法存根
		this.getHibernateTemplate().deleteAll(this.getSession().createQuery("from  DimMtlChanneltype a where a.channeltypeId=" + dimMtlChanneltype.getChanneltypeId()).list());
		this.getHibernateTemplate().save(dimMtlChanneltype);
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao#searchMtlChanneltype(com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm, java.lang.Integer, java.lang.Integer)
	 */
	public Map searchMtlChanneltype(DimMtlChanneltypeForm searchForm, final Integer curPage, final Integer pageSize) throws MpmException {
		// TODO 自动生成方法存根
		String sql = "from  DimMtlChanneltype a where 1=1 ";
		if (searchForm.getChanneltypeId().shortValue() != -1) {
			sql += " and a.channeltypeId=" + searchForm.getChanneltypeId();
		}
		sql += " order by a.channeltypeId";
		final String sql1 = sql;
		Map map = (Map) this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
				Query query = arg0.createQuery(sql1);
				Map map = new HashMap();
				int totalCnt = query.list().size();
				if (totalCnt < 1) {
					map.put("total", Integer.valueOf(0));
					map.put("result", new ArrayList());
					return map;
				}
				query.setFirstResult(pageSize.intValue() * curPage.intValue());
				query.setMaxResults(pageSize.intValue());
				List list = query.list();
				map.put("total", Integer.valueOf(totalCnt));
				map.put("result", list);

				return map;
			}
		});
		return map;
	}


	public Integer findContactTypeByChannelType(final Integer channelTypeId) throws MpmException {
		final String sql = "select a.contactType from DimMtlChanneltype a where a.channeltypeId=:channeltypeId";
		Integer contactType = (Integer) this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
				Query query = arg0.createQuery(sql);
				query.setParameter("channeltypeId", channelTypeId.shortValue());
				return query.uniqueResult();
			}
		});
		return contactType;
	}

	public Short findContactTypeByChannelTypeAndId(final Short channelTypeId, final String channelId) throws MpmException {
		Short contactType = Short.valueOf((short)1);

		//先按照渠道类型取；
		final String allSql = "select a.contactType from MtlDimContactControlType a where a.channeltypeId=:channeltypeId";
		List contactList =  (List) this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
				Query query = arg0.createQuery(allSql);
				query.setParameter("channeltypeId", channelTypeId);
				return query.list();
			}
		});

		//如果该渠道类型对应多个接触控制类型
		if(contactList != null && contactList.size() > 1) {
			final String sql = "select a.contactType from MtlDimContactControlType a where a.channeltypeId=:channelTypeId and a.channelId=:channelId";

			List contactListMuti = (List) this.getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
					Query query = arg0.createQuery(sql);
					query.setParameter("channelTypeId", channelTypeId);
					query.setParameter("channelId", channelId);
					return query.list();
				}
			});
			//如果按照渠道类型和渠道能取到接触类型，就是用这种方式获取。
			if(contactListMuti != null && contactListMuti.size() > 0) {
				contactList.clear();
				contactList.addAll(contactListMuti);
			}

			//否则仍按照渠道类型取。

		}

		if(contactList != null && contactList.size() > 0) {
			contactType = (Short) contactList.get(0);
		}

		return contactType;
	}

	public Integer getSendOddTypeByChannelType(final Integer channelTypeId)
			throws MpmException {
		final String sql = "select a.autoSendOdd from DimMtlChanneltype a where a.channeltypeId=:channelTypeId" ;
		Integer autoSendOdd = (Integer) this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
				Query query = arg0.createQuery(sql);
				query.setParameter("channelTypeId", channelTypeId.shortValue());
				return query.uniqueResult();
			}
		});
		return autoSendOdd;
	}

	public List<DimMtlChanneltype> getAllChannelType(String containsEvent) throws MpmException {
		String sql = "from DimMtlChanneltype where 1 = 1 ";
		if(StringUtil.isNotEmpty(containsEvent) && "1".equals(containsEvent)){
			sql += " and initiativeType = ? order by displayOrder ";
			return this.getHibernateTemplate().find(sql,Integer.valueOf(containsEvent));
		}else{
			sql += " order by displayOrder ";
			return this.getHibernateTemplate().find(sql);
		}
	}
	
	
	public List<DimMtlChanneltype> getAllChannelType(String containsEvent,String isRejectWebGateWay) throws MpmException {
		StringBuffer sql = new StringBuffer("from DimMtlChanneltype where 1 = 1 ");
		if(StringUtil.isNotEmpty(isRejectWebGateWay) && "1".equals(isRejectWebGateWay)){
			sql.append(" and  channeltypeId !=914");
		}
		if(StringUtil.isNotEmpty(containsEvent) && "1".equals(containsEvent)){
			sql.append(" and initiativeType = ? order by displayOrder ");
			return this.getHibernateTemplate().find(sql.toString(),Integer.valueOf(containsEvent));
		}else{
			sql.append(" order by displayOrder ");
			return this.getHibernateTemplate().find(sql.toString());
		}
	}
	
	public List getAllChannelTypeForSys(String SysId) throws MpmException {
		String sql = "select distinct dim from DimMtlChanneltype dim,MtlSysChannelRelation b where 1 = 1 and dim.channeltypeId=b.channelTypeId and b.systemId=?";
		return this.getHibernateTemplate().find(sql,new Object[]{SysId});
	}
	
	/**
	 * 从mcd_user_channel_relation表（存放用户偏好渠道）获取所有渠道类型
	 * @return
	 * @throws Exception
	 */
	public List getAllChannelTypeFromUserChannelRelation() throws MpmException {
		
		ConnectionEx conn = null;
		Sqlca sqlca = null;

		String sql = "select distinct(cr.prefer_channel) as prefer_channel from mcd_user_channel_relation cr order by cr.prefer_channel";
		List<String> list = new ArrayList<String>();

		try {
			conn = new ConnectionEx("JDBC_APP");
			sqlca = new Sqlca(conn);
			String finaSQL = sqlca.getPagedSql(sql, 1, 1000);
			sqlca.execute(finaSQL);
			String channeltype_id = null;
			while (sqlca.next()) {
				channeltype_id = sqlca.getString("prefer_channel");
				list.add(channeltype_id);
			}
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null)
				sqlca.close();
			try {
				if (!conn.isClosed()) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}
}

/*    */ package com.ai.bdx.frame.approval.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimPubChannelDao;
/*    */ import com.ai.bdx.frame.approval.model.DimPubChannel;
/*    */ import com.ai.bdx.frame.approval.util.MpmHtmlHelper;
/*    */ import com.asiainfo.biframe.utils.string.StringUtil;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.Query;
/*    */ import org.hibernate.Session;
/*    */ import org.springframework.orm.hibernate3.HibernateCallback;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class DimPubChannelDaoImpl extends HibernateDaoSupport
/*    */   implements IDimPubChannelDao
/*    */ {
/*    */   public List getObjList()
/*    */     throws Exception
/*    */   {
/* 22 */     return getHibernateTemplate().find("from DimPubChannel channel order by channel.channeltypeId, channel.channelName");
/*    */   }
/*    */ 
/*    */   public DimPubChannel getPubChannel(String channelId) throws Exception
/*    */   {
/* 27 */     return (DimPubChannel)getHibernateTemplate().get(DimPubChannel.class, channelId);
/*    */   }
/*    */ 
/*    */   public List getObjListByChannleType(String channelTypeId) throws Exception
/*    */   {
/* 32 */     if (StringUtil.isEmpty(channelTypeId)) {
/* 33 */       return getHibernateTemplate().find("from DimPubChannel channel order by channel.channeltypeId, channel.channelName");
/*    */     }
/* 35 */     return getHibernateTemplate().find("from DimPubChannel channel where channel.channeltypeId = " + channelTypeId + " order by channel.channelName");
/*    */   }
/*    */ 
/*    */   public List findPubChannel(String strChannelIds)
/*    */     throws Exception
/*    */   {
/* 41 */     String channelIds = strChannelIds;
/* 42 */     List lst = new ArrayList();
/*    */     try
/*    */     {
/* 47 */       channelIds = MpmHtmlHelper.removeComma(channelIds);
/*    */ 
/* 52 */       final String tmpIds = channelIds;
/* 53 */       lst = getHibernateTemplate().executeFind(new HibernateCallback()
/*    */       {
/*    */         public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 56 */           Query query = s.createQuery("from DimPubChannel dpc where dpc.channelId in (" + tmpIds + ")");
/* 57 */           return query.list();
/*    */         } } );
/*    */     }
/*    */     catch (Exception e) {
/* 61 */       throw e;
/*    */     }
/* 63 */     return lst;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.DimPubChannelDaoImpl
 * JD-Core Version:    0.6.2
 */
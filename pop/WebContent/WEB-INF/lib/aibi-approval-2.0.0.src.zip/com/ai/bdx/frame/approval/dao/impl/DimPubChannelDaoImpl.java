package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IDimPubChannelDao;
import com.ai.bdx.frame.approval.model.DimPubChannel;
import com.ai.bdx.frame.approval.util.MpmHtmlHelper;
import com.asiainfo.biframe.utils.string.StringUtil;

public class DimPubChannelDaoImpl extends HibernateDaoSupport implements IDimPubChannelDao {
	@Override
	public List getObjList() throws Exception {
		return this.getHibernateTemplate().find("from DimPubChannel channel order by channel.channeltypeId, channel.channelName");
	}

	@Override
	public DimPubChannel getPubChannel(String channelId) throws Exception {
		return (DimPubChannel) this.getHibernateTemplate().get(DimPubChannel.class, channelId);
	}

	@Override
	public List getObjListByChannleType(String channelTypeId) throws Exception {
		if (StringUtil.isEmpty(channelTypeId)) {
			return this.getHibernateTemplate().find("from DimPubChannel channel order by channel.channeltypeId, channel.channelName");
		} else {
			return this.getHibernateTemplate().find("from DimPubChannel channel " + "where channel.channeltypeId = " + channelTypeId + " order by channel.channelName");
		}
	}

	@Override
	public List findPubChannel(String strChannelIds) throws Exception {
	 String channelIds = strChannelIds;
     List lst = new ArrayList();
     try{
		//浙江的channelId是整形的……
//		String province = Configure.getInstance().getProperty("PROVINCE");
//		if (province != null && province.equalsIgnoreCase("zhejiang"))
			channelIds = MpmHtmlHelper.removeComma(channelIds);

		//		String sql = " from DimPubChannel dpc where dpc.channelId in (" + channelIds + ")";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		final String tmpIds = channelIds;
		lst = getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery("from DimPubChannel dpc where dpc.channelId in (" + tmpIds + ")");
				return query.list();
			}
		});}
     catch(Exception e){
    	 throw e;
     }
		 return lst;
	}
}

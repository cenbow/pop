package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IDimPubChannelTypeDao;
import com.ai.bdx.frame.approval.model.DimPubChanneltype;
import com.asiainfo.biframe.utils.config.Configure;

public class DimPubChannelTypeDaoImpl extends HibernateDaoSupport implements IDimPubChannelTypeDao {
	public List getObjList() throws Exception {
		//浙江用，浙江的渠道类型表dim_pub_channeltype中存在重复及channeltype_id为空的纪录
		//		return this.getHibernateTemplate().find("select distinct channelType from DimPubChanneltype channelType " +
		//				"where channelType.channeltypeId is not null and length(channelType.channeltypeId) > 0 order by channelType.channeltypeName");

		//		String sql = "from DimPubChanneltype channelType order by channelType.channeltypeName";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();

		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery("from DimPubChanneltype channelType order by channelType.channeltypeName");
				return query.list();
			}
		});
	}

	public DimPubChanneltype getChanneltype(Integer channelTypeId) throws Exception {

		//浙江的channelTypeId采用的是channeltype_id2，可能会有多条记录
		String province = Configure.getInstance().getProperty("PROVINCE");
//		if (province != null && province.equalsIgnoreCase("zhejiang")) {
//			//			String sql = "from DimPubChanneltype dpc where dpc.channeltypeId=" + channelTypeId;
//			//			Query query = this.getSession().createQuery(sql);
//			final Integer tmpId = channelTypeId;
//			List list = getHibernateTemplate().executeFind(new HibernateCallback() {
//				public Object doInHibernate(Session s) throws HibernateException, SQLException {
//					Query query = s.createQuery("from DimPubChanneltype dpc where dpc.channeltypeId=" + tmpId);
//					return query.list();
//				}
//			});
//			if (list.size() > 0)
//				return (DimPubChanneltype) list.get(0);
//			else
//				return null;
//		} else {
			return (DimPubChanneltype) this.getHibernateTemplate().get(DimPubChanneltype.class, channelTypeId);
	//	}
	}

	public List getAllChannelType() throws Exception {
		//String sql = "select distinct dp from DimPubChanneltype dp where dp.channeltypeId is not null and length(dp.channeltypeId) > 0 order by dp.channeltypeName";
		//		String sql = "from DimPubChanneltype channelType order by channelType.channeltypeName";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery("from DimPubChanneltype channelType order by channelType.channeltypeName");
				return query.list();
			}
		});
	}
}

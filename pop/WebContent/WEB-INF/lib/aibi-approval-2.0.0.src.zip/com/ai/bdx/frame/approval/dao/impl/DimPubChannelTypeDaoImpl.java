/*    */ package com.ai.bdx.frame.approval.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimPubChannelTypeDao;
/*    */ import com.ai.bdx.frame.approval.model.DimPubChanneltype;
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.Query;
/*    */ import org.hibernate.Session;
/*    */ import org.springframework.orm.hibernate3.HibernateCallback;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class DimPubChannelTypeDaoImpl extends HibernateDaoSupport
/*    */   implements IDimPubChannelTypeDao
/*    */ {
/*    */   public List getObjList()
/*    */     throws Exception
/*    */   {
/* 26 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*    */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 28 */         Query query = s.createQuery("from DimPubChanneltype channelType order by channelType.channeltypeName");
/* 29 */         return query.list();
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   public DimPubChanneltype getChanneltype(Integer channelTypeId)
/*    */     throws Exception
/*    */   {
/* 37 */     String province = Configure.getInstance().getProperty("PROVINCE");
/*    */ 
/* 53 */     return (DimPubChanneltype)getHibernateTemplate().get(DimPubChanneltype.class, channelTypeId);
/*    */   }
/*    */ 
/*    */   public List getAllChannelType()
/*    */     throws Exception
/*    */   {
/* 62 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*    */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 64 */         Query query = s.createQuery("from DimPubChanneltype channelType order by channelType.channeltypeName");
/* 65 */         return query.list();
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.DimPubChannelTypeDaoImpl
 * JD-Core Version:    0.6.2
 */
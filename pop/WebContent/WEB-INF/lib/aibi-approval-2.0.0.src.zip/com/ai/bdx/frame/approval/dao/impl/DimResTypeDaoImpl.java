package com.ai.bdx.frame.approval.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IDimResTypeDao;
import com.ai.bdx.frame.approval.model.DimResType;

/*
 * Created on 10:08:28 AM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb  zhoulb@asiainfo.com
 * @version 1.0
 */
public class DimResTypeDaoImpl extends HibernateDaoSupport implements
		IDimResTypeDao {
	private static Logger log = LogManager.getLogger();

	public DimResTypeDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 返回所有记录
	 * 
	 * @return
	 * @throws Exception
	 */
	public List findAll() throws Exception {
		List result = new ArrayList();
		try {
			String sql = "from DimResType as a order by a.resType";
			result = this.getHibernateTemplate().find(sql);
		} catch (Exception e) {
			log.error("", e);
		}
		return result;
	}

	/**
	 * 根据resType返回相应记录
	 * 
	 * @param resType
	 * @return
	 * @throws Exception
	 */
	public DimResType findById(String resType) throws Exception {
		DimResType result = new DimResType();
		try {
			String sql = "from DimResType as a where a.resType=" + resType + "";
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				result = (DimResType) list.get(0);
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return result;
	}

}

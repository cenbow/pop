/*    */ package com.ai.bdx.frame.approval.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimResTypeDao;
/*    */ import com.ai.bdx.frame.approval.model.DimResType;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class DimResTypeDaoImpl extends HibernateDaoSupport
/*    */   implements IDimResTypeDao
/*    */ {
/* 25 */   private static Logger log = LogManager.getLogger();
/*    */ 
/*    */   public List findAll()
/*    */     throws Exception
/*    */   {
/* 39 */     List result = new ArrayList();
/*    */     try {
/* 41 */       String sql = "from DimResType as a order by a.resType";
/* 42 */       result = getHibernateTemplate().find(sql);
/*    */     } catch (Exception e) {
/* 44 */       log.error("", e);
/*    */     }
/* 46 */     return result;
/*    */   }
/*    */ 
/*    */   public DimResType findById(String resType)
/*    */     throws Exception
/*    */   {
/* 57 */     DimResType result = new DimResType();
/*    */     try {
/* 59 */       String sql = "from DimResType as a where a.resType=" + resType + "";
/* 60 */       List list = getHibernateTemplate().find(sql);
/* 61 */       if ((list != null) && (list.size() > 0))
/* 62 */         result = (DimResType)list.get(0);
/*    */     }
/*    */     catch (Exception e) {
/* 65 */       log.error("", e);
/*    */     }
/* 67 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.DimResTypeDaoImpl
 * JD-Core Version:    0.6.2
 */
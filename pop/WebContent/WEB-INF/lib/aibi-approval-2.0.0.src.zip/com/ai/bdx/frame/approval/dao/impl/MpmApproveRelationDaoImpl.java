/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMpmApproveRelationDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveRelation;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveRelationKey;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.impl.SessionImpl;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MpmApproveRelationDaoImpl extends HibernateDaoSupport
/*     */   implements IMpmApproveRelationDao
/*     */ {
/*  21 */   public static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public MtlApproveRelation save(MtlApproveRelation mtlApproveRelation) throws DataAccessException {
/*     */     try {
/*  25 */       getHibernateTemplate().save(mtlApproveRelation);
/*     */     } catch (DataAccessException de) {
/*  27 */       log.error("", de);
/*     */     }
/*  29 */     return mtlApproveRelation;
/*     */   }
/*     */ 
/*     */   public void update(MtlApproveRelation mtlApproveRelation) throws DataAccessException {
/*     */     try {
/*  34 */       getHibernateTemplate().saveOrUpdate(mtlApproveRelation);
/*     */     } catch (DataAccessException de) {
/*  36 */       log.error("", de);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateByJdbc(MtlApproveRelation svc) throws DataAccessException
/*     */   {
/*  42 */     StringBuffer sql = null;
/*  43 */     Sqlca sqlca = null;
/*     */     try {
/*  45 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/*  46 */       sql = new StringBuffer("update ap_approve_relation set deptid=?,approve_userid=?,position_id=?,approve_create_userid=?,approve_userid_email=?,approve_userid_msisdn=? where deptId=? and approve_userid=?");
/*  47 */       Object[] args = { svc.getId().getDeptId(), svc.getId().getApproveUserid(), svc.getPositionId(), svc.getApproveCreateUserid(), svc.getApproveUseridEmail(), svc.getApproveUseridMsisdn(), Integer.valueOf(Integer.parseInt(svc.getBeforeCreateUserid())), svc.getBeforeApproveUserid() };
/*     */ 
/*  52 */       sqlca.execute(sql.toString(), args);
/*     */     } catch (Exception e) {
/*  54 */       log.error("", e);
/*     */     } finally {
/*  56 */       if (sqlca != null)
/*  57 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteByUserid(MtlApproveRelation svc) throws DataAccessException
/*     */   {
/*     */     try {
/*  64 */       StringBuffer sql = new StringBuffer("");
/*  65 */       sql.append("from MtlApproveRelation as a where 1=1 ");
/*  66 */       if (svc.getId().getDeptId() != null) {
/*  67 */         sql.append(" and a.id.deptId=" + svc.getId().getDeptId() + "");
/*     */       }
/*  69 */       if ((svc.getId().getApproveUserid() != null) && (!"".equals(svc.getId().getApproveUserid()))) {
/*  70 */         sql.append(" and a.id.approveUserid='" + svc.getId().getApproveUserid() + "'");
/*     */       }
/*  72 */       getHibernateTemplate().deleteAll(getSession().createQuery(sql.toString()).list());
/*     */     } catch (DataAccessException de) {
/*  74 */       log.error("", de);
/*     */     }
/*     */   }
/*     */ 
/*     */   public MtlApproveRelation findByUserid(String deptId, String approveUserid) throws DataAccessException
/*     */   {
/*  80 */     MtlApproveRelation result = new MtlApproveRelation();
/*     */     try {
/*  82 */       StringBuffer sql = new StringBuffer("from MtlApproveRelation as a where 1=1 ");
/*  83 */       if ((deptId != null) && (!"".equals(deptId))) {
/*  84 */         sql.append(" and a.id.deptId=" + deptId + "");
/*     */       }
/*  86 */       if ((approveUserid != null) && (!"".equals(approveUserid))) {
/*  87 */         sql.append(" and a.id.approveUserid='" + approveUserid + "'");
/*     */       }
/*  89 */       List list = getHibernateTemplate().find(sql.toString());
/*  90 */       if ((list != null) && (list.size() > 0))
/*  91 */         result = (MtlApproveRelation)list.get(0);
/*     */     }
/*     */     catch (DataAccessException de) {
/*  94 */       log.error("", de);
/*     */     }
/*  96 */     return result;
/*     */   }
/*     */ 
/*     */   public List findByCondtion(String deptId, String approveUserid, String approveLevel) throws DataAccessException {
/* 100 */     List list = new ArrayList();
/*     */     try {
/* 102 */       String sql = "from MtlApproveRelation as a where 1=1 ";
/* 103 */       if ((deptId != null) && (!"".equals(deptId))) {
/* 104 */         sql = sql + " and a.id.deptId=" + deptId + "";
/*     */       }
/* 106 */       if ((approveUserid != null) && (!"".equals(approveUserid))) {
/* 107 */         sql = sql + " and a.id.approveUserid='" + approveUserid + "'";
/*     */       }
/*     */ 
/* 112 */       sql = sql + " order by a.id.deptId";
/* 113 */       list = getHibernateTemplate().find(sql.toString());
/*     */     } catch (DataAccessException de) {
/* 115 */       log.error("", de);
/*     */     }
/* 117 */     return list;
/*     */   }
/*     */ 
/*     */   public List getApproveRelationByDeptId(String deptId) {
/* 121 */     List list = new ArrayList();
/*     */     try {
/* 123 */       String sql = "from MtlApproveRelation as a where 1=1 ";
/* 124 */       if ((deptId != null) && (!"".equals(deptId))) {
/* 125 */         sql = sql + " and a.id.deptId=" + deptId + "";
/*     */       }
/*     */ 
/* 128 */       sql = sql + " order by a.id.deptId";
/* 129 */       list = getHibernateTemplate().find(sql.toString());
/*     */     } catch (DataAccessException de) {
/* 131 */       log.error("", de);
/*     */     }
/* 133 */     return list;
/*     */   }
/*     */ 
/*     */   public List findAll() throws DataAccessException {
/* 137 */     List list = new ArrayList();
/*     */     try {
/* 139 */       String sql = "from MtlApproveRelation as a  order by a.id.deptId";
/* 140 */       list = getHibernateTemplate().find(sql);
/*     */     } catch (DataAccessException de) {
/* 142 */       log.error("", de);
/*     */     }
/* 144 */     return list;
/*     */   }
/*     */ 
/*     */   public List findByApproveUserId(String approveUserid) throws Exception {
/* 148 */     return getHibernateTemplate().find(" from MtlApproveRelation approve where approve.id.approveUserid='" + approveUserid + "'");
/*     */   }
/*     */ 
/*     */   public int getUserMaxApproveLevel(String createUserId) throws Exception {
/* 152 */     Sqlca sqlca = null;
/* 153 */     int res = 0;
/*     */     try {
/* 155 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 156 */       String sql = "select max(approve_level) from ap_approve_relation where create_userid=?";
/* 157 */       sqlca.execute(sql, new Object[] { createUserId });
/* 158 */       if (sqlca.next())
/* 159 */         res = sqlca.getInt(1);
/*     */     }
/*     */     catch (Exception e) {
/* 162 */       throw e;
/*     */     } finally {
/* 164 */       if (sqlca != null) {
/* 165 */         sqlca.close();
/*     */       }
/*     */     }
/* 168 */     return res;
/*     */   }
/*     */ 
/*     */   public boolean getFirstUserOnApprove(String createUserId, String approveUserId) throws Exception {
/* 172 */     Sqlca sqlca = null;
/* 173 */     boolean flag = false;
/*     */     try {
/* 175 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 176 */       String sql = "select * from ap_approve_relation where approve_level = (select min(approve_level) from MTL_approve_relation where create_userid=?)  and approve_userid=?";
/* 177 */       sqlca.execute(sql, new Object[] { createUserId, approveUserId });
/* 178 */       if (sqlca.next())
/* 179 */         flag = true;
/*     */     }
/*     */     catch (Exception e) {
/* 182 */       throw e;
/*     */     } finally {
/* 184 */       if (sqlca != null) {
/* 185 */         sqlca.close();
/*     */       }
/*     */     }
/* 188 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean getLastUserOnApprove(String createUserId, String approveUserId, String camp_id) throws Exception {
/* 192 */     Sqlca sqlca = null;
/* 193 */     boolean flag = false;
/*     */     try {
/* 195 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/*     */ 
/* 197 */       String sql = "select * from ap_approve_relation where approve_level = (select approve_lev from MTL_camp_baseinfo where camp_id=?) and approve_userid=? and create_userid=?";
/* 198 */       sqlca.execute(sql, new Object[] { camp_id, approveUserId, createUserId });
/* 199 */       if (sqlca.next())
/* 200 */         flag = true;
/*     */     }
/*     */     catch (Exception e) {
/* 203 */       throw e;
/*     */     } finally {
/* 205 */       if (sqlca != null) {
/* 206 */         sqlca.close();
/*     */       }
/*     */     }
/* 209 */     return flag;
/*     */   }
/*     */ 
/*     */   public short getUserApproveLevel(String createUserId, String approveUserId) throws Exception {
/* 213 */     Sqlca sqlca = null;
/* 214 */     int level = 0;
/*     */     try {
/* 216 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 217 */       String sql = "select approve_level from ap_approve_relation where create_userid=? and approve_userid=?";
/* 218 */       sqlca.execute(sql, new Object[] { createUserId, approveUserId });
/* 219 */       if (sqlca.next())
/* 220 */         level = sqlca.getInt(1);
/*     */     }
/*     */     catch (Exception e) {
/* 223 */       throw e;
/*     */     } finally {
/* 225 */       if (sqlca != null) {
/* 226 */         sqlca.close();
/*     */       }
/*     */     }
/* 229 */     return Integer.valueOf(level).shortValue();
/*     */   }
/*     */ 
/*     */   public MtlApproveRelation getNextApproveUser(String needApproveUserid, int nextApproveLev) throws Exception
/*     */   {
/* 234 */     MtlApproveRelation mtlApproveRelation = new MtlApproveRelation();
/*     */ 
/* 253 */     return mtlApproveRelation;
/*     */   }
/*     */ 
/*     */   public MtlApproveRelation getPreApproveUser(String createUserid, String approveUserid) throws Exception
/*     */   {
/* 258 */     Sqlca sqlca = null;
/* 259 */     MtlApproveRelation mtlApproveRelation = new MtlApproveRelation();
/*     */     try {
/* 261 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 262 */       String sql = " select approve_userid from ap_approve_relation relation where relation.create_userid ='" + createUserid + "' " + "and relation.approve_level = (" + "select  relation2.approve_level-1  from MTL_approve_relation relation2 " + "where relation2.create_userid ='" + createUserid + "' " + "and relation2.approve_userid ='" + approveUserid + "')";
/*     */ 
/* 264 */       sqlca.execute(sql);
/* 265 */       if (sqlca.next())
/* 266 */         mtlApproveRelation = findByUserid(createUserid, sqlca.getString("approve_userid"));
/*     */     }
/*     */     catch (Exception e) {
/* 269 */       throw e;
/*     */     } finally {
/* 271 */       if (sqlca != null) {
/* 272 */         sqlca.close();
/*     */       }
/*     */     }
/* 275 */     return mtlApproveRelation;
/*     */   }
/*     */ 
/*     */   public boolean isNextApproveExist(String createUserid, String approveLevel) throws Exception {
/* 279 */     boolean flag = false;
/*     */     try {
/* 281 */       String sql = "from MtlApproveRelation as a where a.id.createUserid='" + createUserid + "'" + " and a.approveLevel=" + approveLevel + "+1";
/* 282 */       List list = getHibernateTemplate().find(sql);
/* 283 */       if ((list != null) && (list.size() > 0))
/* 284 */         flag = true;
/*     */     }
/*     */     catch (Exception e) {
/* 287 */       throw e;
/*     */     }
/* 289 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean isPreApproveExist(String createUserid, String approveLevel) throws Exception {
/* 293 */     boolean flag = false;
/*     */     try {
/* 295 */       String sql = "from MtlApproveRelation as a where a.id.createUserid='" + createUserid + "'" + " and a.approveLevel=" + approveLevel + "-1";
/* 296 */       List list = getHibernateTemplate().find(sql);
/* 297 */       if ((list != null) && (list.size() > 0))
/* 298 */         flag = true;
/*     */     }
/*     */     catch (Exception e) {
/* 301 */       throw e;
/*     */     }
/* 303 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean isFirstUserApprove(String createUserId) throws Exception {
/* 307 */     boolean flag = false;
/*     */     try {
/* 309 */       String sql = "from MtlApproveRelation as a where a.id.createUserid='" + createUserId + "'";
/* 310 */       List list = getHibernateTemplate().find(sql);
/* 311 */       if ((list != null) && (list.size() > 0))
/* 312 */         flag = true;
/*     */     }
/*     */     catch (Exception e) {
/* 315 */       throw e;
/*     */     }
/* 317 */     return flag;
/*     */   }
/*     */ 
/*     */   public void updateApproveUserid(String approveUserId, String authUserid, int authFlag) throws Exception {
/* 321 */     String sql = "";
/* 322 */     Sqlca sqlca = null;
/*     */     try {
/* 324 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 325 */       if (authFlag == 1)
/* 326 */         sql = "update ap_approve_relation set approve_userid=?,auth_flag=? where approve_userid=?";
/*     */       else {
/* 328 */         sql = "update ap_approve_relation set approve_userid=?,auth_flag=? where approve_userid=? and auth_flag=1";
/*     */       }
/* 330 */       Object[] args = { approveUserId, Integer.valueOf(authFlag), authUserid };
/* 331 */       sqlca.execute(sql, args);
/*     */     } catch (Exception e) {
/* 333 */       log.error("", e);
/*     */     } finally {
/* 335 */       if (sqlca != null)
/* 336 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MpmApproveRelationDaoImpl
 * JD-Core Version:    0.6.2
 */
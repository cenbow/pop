package com.ai.bdx.frame.approval.dao.impl;


import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.impl.SessionImpl;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ai.bdx.frame.approval.dao.IMpmApproveRelationDao;
import com.ai.bdx.frame.approval.model.MtlApproveRelation;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;

/**
 * 审批关系定义数据库操作
 * @author zhoulb
 * @version 1.0
 */
public class MpmApproveRelationDaoImpl extends HibernateDaoSupport implements IMpmApproveRelationDao {
	public static Logger log = LogManager.getLogger();

	public MtlApproveRelation save(MtlApproveRelation mtlApproveRelation) throws DataAccessException {
		try {
			this.getHibernateTemplate().save(mtlApproveRelation);
		} catch (DataAccessException de) {
			log.error("",de);
		}
		return mtlApproveRelation;
	}

	public void update(MtlApproveRelation mtlApproveRelation) throws DataAccessException {
		try {
			this.getHibernateTemplate().saveOrUpdate(mtlApproveRelation);
		} catch (DataAccessException de) {
			log.error("",de);
		}
		return;
	}

	public void updateByJdbc(MtlApproveRelation svc) throws DataAccessException {
		StringBuffer sql = null;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			sql = new StringBuffer("update ap_approve_relation set deptid=?,approve_userid=?,position_id=?,approve_create_userid=?,approve_userid_email=?,approve_userid_msisdn=? where deptId=? and approve_userid=?");
			Object[] args = new Object[]{svc.getId().getDeptId(), svc.getId().getApproveUserid()
								, svc.getPositionId(),svc.getApproveCreateUserid()
								,svc.getApproveUseridEmail(),svc.getApproveUseridMsisdn()
								,Integer.parseInt(svc.getBeforeCreateUserid())
								,svc.getBeforeApproveUserid()};
			sqlca.execute(sql.toString(), args);
		} catch (Exception e) {
			log.error("",e);
		} finally {
			if (sqlca != null){
				sqlca.close();
			}
		}
	}

	public void deleteByUserid(MtlApproveRelation svc) throws DataAccessException {
		try {
			StringBuffer sql = new StringBuffer("");
			sql.append("from MtlApproveRelation as a where 1=1 ");
			if (svc.getId().getDeptId() != null) {
				sql.append(" and a.id.deptId=" + svc.getId().getDeptId() + "");
			}
			if (svc.getId().getApproveUserid() != null && !"".equals(svc.getId().getApproveUserid())) {
				sql.append(" and a.id.approveUserid='" + svc.getId().getApproveUserid() + "'");
			}
			this.getHibernateTemplate().deleteAll(this.getSession().createQuery(sql.toString()).list());
		} catch (DataAccessException de) {
			log.error("",de);
		}
		return;
	}

	public MtlApproveRelation findByUserid(String deptId, String approveUserid) throws DataAccessException {
		MtlApproveRelation result = new MtlApproveRelation();
		try {
			StringBuffer sql = new StringBuffer("from MtlApproveRelation as a where 1=1 ");
			if (deptId != null && !"".equals(deptId)) {
				sql.append(" and a.id.deptId=" + deptId + "");
			}
			if (approveUserid != null && !"".equals(approveUserid)) {
				sql.append(" and a.id.approveUserid='" + approveUserid + "'");
			}
			List list = getHibernateTemplate().find(sql.toString());
			if (list != null && list.size() > 0){
				result = (MtlApproveRelation) list.get(0);
			}
		} catch (DataAccessException de) {
			log.error("",de);
		}
		return result;
	}

	public List findByCondtion(String deptId, String approveUserid, String approveLevel) throws DataAccessException {
		List list = new ArrayList();
		try {
			String sql = "from MtlApproveRelation as a where 1=1 ";
			if (deptId != null && !"".equals(deptId)) {
				sql = sql + " and a.id.deptId=" + deptId + "";
			}
			if (approveUserid != null && !"".equals(approveUserid)) {
				sql = sql + " and a.id.approveUserid='" + approveUserid + "'";
			}
			//    	     if(approveLevel != null && !"".equals(approveLevel)){
			//    	    	 sql = sql + " and a.approveLevel="+approveLevel;
			//    	     }
			sql += " order by a.id.deptId";
			list = getHibernateTemplate().find(sql.toString());
		} catch (DataAccessException de) {
			log.error("",de);
		}
		return list;
	}

	public List getApproveRelationByDeptId(String deptId){
		List list = new ArrayList();
		try {
			String sql = "from MtlApproveRelation as a where 1=1 ";
			if (deptId != null && !"".equals(deptId)) {
				sql = sql + " and a.id.deptId=" + deptId + "";
			}

			sql += " order by a.id.deptId";
			list = getHibernateTemplate().find(sql.toString());
		} catch (DataAccessException de) {
			log.error("",de);
		}
		return list;
	}

	public List findAll() throws DataAccessException {
		List list = new ArrayList();
		try {
			String sql = "from MtlApproveRelation as a  order by a.id.deptId";
			list = getHibernateTemplate().find(sql);
		} catch (DataAccessException de) {
			log.error("",de);
		}
		return list;
	}

	public List findByApproveUserId(String approveUserid) throws Exception {
		return this.getHibernateTemplate().find(" from MtlApproveRelation approve" + " where approve.id.approveUserid='" + approveUserid + "'");
	}

	public int getUserMaxApproveLevel(String createUserId) throws Exception {
		Sqlca sqlca = null;
		int res = 0;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "select max(approve_level) from ap_approve_relation where create_userid=?";
			sqlca.execute(sql, new Object[]{createUserId});
			if (sqlca.next()) {
				res = sqlca.getInt(1);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null){
				sqlca.close();
			}
		}
		return res;
	}

	public boolean getFirstUserOnApprove(String createUserId, String approveUserId) throws Exception {
		Sqlca sqlca = null;
		boolean flag = false;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "select * from ap_approve_relation where approve_level = (select min(approve_level) from MTL_approve_relation where create_userid=?)  and approve_userid=?";
			sqlca.execute(sql, new Object[]{createUserId,approveUserId});
			if (sqlca.next()) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null){
				sqlca.close();
			}
		}
		return flag;
	}

	public boolean getLastUserOnApprove(String createUserId, String approveUserId, String camp_id) throws Exception {
		Sqlca sqlca = null;
		boolean flag = false;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			//cuowu
			String sql = "select * from ap_approve_relation where approve_level = (select approve_lev from MTL_camp_baseinfo where camp_id=?) and approve_userid=? and create_userid=?";
			sqlca.execute(sql, new Object[]{camp_id,approveUserId,createUserId});
			if (sqlca.next()) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null){
				sqlca.close();
			}
		}
		return flag;
	}

	public short getUserApproveLevel(String createUserId, String approveUserId) throws Exception {
		Sqlca sqlca = null;
		int level = 0;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "select approve_level from ap_approve_relation where create_userid=? and approve_userid=?";
			sqlca.execute(sql, new Object[]{createUserId,approveUserId});
			if (sqlca.next()) {
				level = sqlca.getInt(1);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null){
				sqlca.close();
			}
		}
		return (Integer.valueOf(level)).shortValue();
	}

	public MtlApproveRelation getNextApproveUser(String needApproveUserid, int nextApproveLev) throws Exception {
		//        	Sqlca sqlca = null;
		MtlApproveRelation mtlApproveRelation = new MtlApproveRelation();
		//        	try {
		//        		sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
		//        		String sql = " select approve_userid from ap_approve_relation relation " +
		//        			"where relation.create_userid ='"+createUserid+"' " +
		//        			"and relation.approve_level = (" +
		//        			"select  relation2.approve_level+1  from ap_approve_relation relation2 " +
		//        			"where relation2.create_userid ='"+createUserid+"' " +
		//        			"and relation2.approve_userid ='"+approveUserid+"')";
		//        		sqlca.execute(sql);
		//        		if (sqlca.next()) {
		//        			mtlApproveRelation=this.findByUserid(createUserid,sqlca.getString("approve_userid"));
		//        		}
		//        	} catch (Exception e) {
		//        		throw e;
		//        	} finally {
		//        		if (sqlca != null)
		//        			sqlca.close();
		//        	}
		return mtlApproveRelation;

	}

	public MtlApproveRelation getPreApproveUser(String createUserid, String approveUserid) throws Exception {
		Sqlca sqlca = null;
		MtlApproveRelation mtlApproveRelation = new MtlApproveRelation();
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = " select approve_userid from ap_approve_relation relation " + "where relation.create_userid ='" + createUserid + "' " + "and relation.approve_level = (" + "select  relation2.approve_level-1  from MTL_approve_relation relation2 "
					+ "where relation2.create_userid ='" + createUserid + "' " + "and relation2.approve_userid ='" + approveUserid + "')";
			sqlca.execute(sql);
			if (sqlca.next()) {
				mtlApproveRelation = this.findByUserid(createUserid, sqlca.getString("approve_userid"));
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null){
				sqlca.close();
			}
		}
		return mtlApproveRelation;
	}

	public boolean isNextApproveExist(String createUserid, String approveLevel) throws Exception {
		boolean flag = false;
		try {
			String sql = "from MtlApproveRelation as a where a.id.createUserid='" + createUserid + "'" + " and a.approveLevel=" + approveLevel + "+1";
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		}
		return flag;
	}

	public boolean isPreApproveExist(String createUserid, String approveLevel) throws Exception {
		boolean flag = false;
		try {
			String sql = "from MtlApproveRelation as a where a.id.createUserid='" + createUserid + "'" + " and a.approveLevel=" + approveLevel + "-1";
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		}
		return flag;
	}

	public boolean isFirstUserApprove(String createUserId) throws Exception {
		boolean flag = false;
		try {
			String sql = "from MtlApproveRelation as a where a.id.createUserid='" + createUserId + "'";
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		}
		return flag;
	}

	public void updateApproveUserid(String approveUserId, String authUserid, int authFlag) throws Exception {
		String sql = "";
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			if (authFlag == 1){
				sql = "update ap_approve_relation set approve_userid=?,auth_flag=? where approve_userid=?";
			}else{
				sql = "update ap_approve_relation set approve_userid=?,auth_flag=? where approve_userid=? and auth_flag=1";
			}
			Object[] args = new Object[]{approveUserId,authFlag,authUserid};
			sqlca.execute(sql, args);
		} catch (Exception e) {
			log.error("",e);
		} finally {
			if (sqlca != null){
				sqlca.close();
			}
		}
	}

}

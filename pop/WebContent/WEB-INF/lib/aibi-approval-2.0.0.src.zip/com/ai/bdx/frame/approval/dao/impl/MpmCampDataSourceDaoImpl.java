package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMpmCampDataSourceDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCampDataSource;

/**
 * 数据源管理数据库操作
 * 
 * @author zhoulb
 * @version 1.0
 */

public class MpmCampDataSourceDaoImpl extends HibernateDaoSupport implements
		IMpmCampDataSourceDao {
	public static Logger log = LogManager.getLogger();

	/**
	 * 向数据源表mtl_camp_datasource表插入一条记录
	 * 
	 * @param mtlCampDataSource
	 * @return void
	 */
	public MtlCampDataSource insert(MtlCampDataSource mtlCampDataSource)
			throws DataAccessException {
		try {
			getHibernateTemplate().save(mtlCampDataSource);
		} catch (DataAccessException de) {
			log.error("", de);
		}
		return mtlCampDataSource;
	}

	/**
	 * 通过id更新数据源表mtl_camp_datasource表记录
	 * 
	 * @param mtlCampDataSource
	 * @return void
	 */
	public void updateByTabname(MtlCampDataSource mtlCampDataSource)
			throws DataAccessException {
		try {
			getHibernateTemplate().update(mtlCampDataSource);
		} catch (DataAccessException de) {
			log.error("", de);
		}
		return;
	}

	/**
	 * 通过id删除数据源表mtl_camp_datasource表记录
	 * 
	 * @param mtlCampDataSource
	 * @return void
	 */
	public void deleteByTabname(String tablename) throws DataAccessException {
		try {
			final String sql = "from MtlCampDataSource as a where "
					+ " a.sourceName='" + tablename.trim() + "'";
			// getHibernateTemplate().delete(sql);
			this.getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session arg0)
						throws HibernateException, SQLException {
					Query query = arg0.createQuery("delete " + sql);
					query.executeUpdate();
					return null;
				}
			});
		} catch (DataAccessException de) {
			log.error("", de);
		}
		return;
	}

	/**
	 * 通过id查询数据源表mtl_camp_datasource表记录
	 * 
	 * @param mtlCampDataSource
	 * @return MtlCampDataSource
	 */
	public MtlCampDataSource findByTabname(String tablename)
			throws DataAccessException {
		MtlCampDataSource mtlCampDataSource = new MtlCampDataSource();
		try {
			String sql = "from MtlCampDataSource as a where "
					+ " a.sourceName='" + tablename.trim() + "'";
			List list = getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				mtlCampDataSource = (MtlCampDataSource) list.get(0);
			}
		} catch (DataAccessException de) {
			log.error("", de);
		}
		return mtlCampDataSource;
	}

	/**
	 * 通过id查询数据源表mtl_camp_datasource表记录
	 * 
	 * @param mtlCampDataSource
	 * @return MtlCampDataSource
	 */
	public MtlCampDataSource findByTabCname(String tablecname)
			throws DataAccessException {
		MtlCampDataSource mtlCampDataSource = null;
		try {
			String sql = "from MtlCampDataSource as a where "
					+ " a.sourceCname='" + tablecname.trim() + "'";
			List list = getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				mtlCampDataSource = (MtlCampDataSource) list.get(0);
			}
		} catch (DataAccessException de) {
			log.error("", de);
		}
		return mtlCampDataSource;
	}

	/**
	 * 通过条件组合查询数据源表mtl_camp_datasource表记录
	 * 
	 * @param mtlCampDataSource
	 */
	public List findByCondtion(MtlCampDataSource mtlCampDataSource)
			throws MpmException {
		List list = new ArrayList();
		try {
			StringBuffer sql = new StringBuffer(
					"from MtlCampDataSource as a where ");
			if (mtlCampDataSource.getSourceName() != null
					&& !mtlCampDataSource.getSourceName().trim().equals("")) {
				sql.append(" a.sourceName='"
						+ mtlCampDataSource.getSourceName() + "' and");
			}

			// 处理最终结果sql字符串
			if (sql.charAt(sql.length() - 1) == 'd') {
				sql.setLength(sql.length() - 3);
			} else {
				sql.setLength(sql.length() - 6);
			}
			list = getHibernateTemplate().find(sql.toString());
		} catch (MpmException de) {
			log.error("", de);
		}
		return list;
	}

	/**
	 * 返回表所有记录
	 */
	public List findAll() throws DataAccessException {
		List list = new ArrayList();
		try {
			String sql = "from MtlCampDataSource as a  where a.sourceType in("
					+ MpmCONST.SOURCE_TABLE_TYPE_BASE + ","
					+ MpmCONST.SOURCE_TABLE_TYPE_EXTEND
					+ ") order by a.sourceName";
			list = getHibernateTemplate().find(sql);
		} catch (DataAccessException de) {
			log.error("", de);
		}
		return list;
	}

	/**
	 *
	 */
	public List findBySourceTypeWithColumns(Short[] type) throws Exception {
		String sql = "from MtlCampDataSource mcds where mcds.sourceName<>'mtl_comp_userinfo' and mcds.sourceStatus="
				+ MpmCONST.SOURCE_TABLE_STATUS_VALID;
		for (int i = 0; type != null && i < type.length; i++) {
			if (i == 0) {
				sql += " and (";
			}
			sql += " mcds.sourceType=" + type[i];
			if (i == (type.length - 1)) {
				sql += ")";
			} else {
				sql += " or ";
			}
		}
		// Query query = this.getSession().createQuery(sql);
		final String tmpSql = sql;
		List list = getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
		MtlCampDataSource obj;
		// 取每个数据源表的字段信息
		for (int i = 0; i < list.size(); i++) {
			obj = (MtlCampDataSource) list.get(i);
			obj.getColumns().iterator();
		}
		return list;
	}

	public List findBySourceNameWithColumns(String[] sourceNames)
			throws Exception {
		String sql = "from MtlCampDataSource mcds where 1=1 ";
		for (int i = 0; sourceNames != null && i < sourceNames.length; i++) {
			if (i == 0) {
				sql += " and (";
			}
			sql += " mcds.sourceName='" + sourceNames[i] + "'";
			if (i == (sourceNames.length - 1)) {
				sql += ")";
			} else {
				sql += " or ";
			}
		}

		// Query query = this.getSession().createQuery(sql);
		// List list = query.list();
		final String tmpSql = sql;
		List list = getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});

		MtlCampDataSource obj;
		// 取每个数据源表的字段信息
		for (int i = 0; i < list.size(); i++) {
			obj = (MtlCampDataSource) list.get(i);
			obj.getColumns().iterator();
		}
		return list;
	}
}

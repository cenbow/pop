/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMpmCampDataSourceDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampDataSource;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MpmCampDataSourceDaoImpl extends HibernateDaoSupport
/*     */   implements IMpmCampDataSourceDao
/*     */ {
/*  30 */   public static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public MtlCampDataSource insert(MtlCampDataSource mtlCampDataSource)
/*     */     throws DataAccessException
/*     */   {
/*     */     try
/*     */     {
/*  41 */       getHibernateTemplate().save(mtlCampDataSource);
/*     */     } catch (DataAccessException de) {
/*  43 */       log.error("", de);
/*     */     }
/*  45 */     return mtlCampDataSource;
/*     */   }
/*     */ 
/*     */   public void updateByTabname(MtlCampDataSource mtlCampDataSource)
/*     */     throws DataAccessException
/*     */   {
/*     */     try
/*     */     {
/*  57 */       getHibernateTemplate().update(mtlCampDataSource);
/*     */     } catch (DataAccessException de) {
/*  59 */       log.error("", de);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteByTabname(String tablename)
/*     */     throws DataAccessException
/*     */   {
/*     */     try
/*     */     {
/*  72 */       final String sql = "from MtlCampDataSource as a where  a.sourceName='" + tablename.trim() + "'";
/*     */ 
/*  75 */       getHibernateTemplate().execute(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/*  78 */           Query query = arg0.createQuery("delete " + sql);
/*  79 */           query.executeUpdate();
/*  80 */           return null;
/*     */         } } );
/*     */     }
/*     */     catch (DataAccessException de) {
/*  84 */       log.error("", de);
/*     */     }
/*     */   }
/*     */ 
/*     */   public MtlCampDataSource findByTabname(String tablename)
/*     */     throws DataAccessException
/*     */   {
/*  97 */     MtlCampDataSource mtlCampDataSource = new MtlCampDataSource();
/*     */     try {
/*  99 */       String sql = "from MtlCampDataSource as a where  a.sourceName='" + tablename.trim() + "'";
/*     */ 
/* 101 */       List list = getHibernateTemplate().find(sql);
/* 102 */       if ((list != null) && (list.size() > 0))
/* 103 */         mtlCampDataSource = (MtlCampDataSource)list.get(0);
/*     */     }
/*     */     catch (DataAccessException de) {
/* 106 */       log.error("", de);
/*     */     }
/* 108 */     return mtlCampDataSource;
/*     */   }
/*     */ 
/*     */   public MtlCampDataSource findByTabCname(String tablecname)
/*     */     throws DataAccessException
/*     */   {
/* 119 */     MtlCampDataSource mtlCampDataSource = null;
/*     */     try {
/* 121 */       String sql = "from MtlCampDataSource as a where  a.sourceCname='" + tablecname.trim() + "'";
/*     */ 
/* 123 */       List list = getHibernateTemplate().find(sql);
/* 124 */       if ((list != null) && (list.size() > 0))
/* 125 */         mtlCampDataSource = (MtlCampDataSource)list.get(0);
/*     */     }
/*     */     catch (DataAccessException de) {
/* 128 */       log.error("", de);
/*     */     }
/* 130 */     return mtlCampDataSource;
/*     */   }
/*     */ 
/*     */   public List findByCondtion(MtlCampDataSource mtlCampDataSource)
/*     */     throws MpmException
/*     */   {
/* 140 */     List list = new ArrayList();
/*     */     try {
/* 142 */       StringBuffer sql = new StringBuffer("from MtlCampDataSource as a where ");
/*     */ 
/* 144 */       if ((mtlCampDataSource.getSourceName() != null) && (!mtlCampDataSource.getSourceName().trim().equals("")))
/*     */       {
/* 146 */         sql.append(" a.sourceName='" + mtlCampDataSource.getSourceName() + "' and");
/*     */       }
/*     */ 
/* 151 */       if (sql.charAt(sql.length() - 1) == 'd')
/* 152 */         sql.setLength(sql.length() - 3);
/*     */       else {
/* 154 */         sql.setLength(sql.length() - 6);
/*     */       }
/* 156 */       list = getHibernateTemplate().find(sql.toString());
/*     */     } catch (MpmException de) {
/* 158 */       log.error("", de);
/*     */     }
/* 160 */     return list;
/*     */   }
/*     */ 
/*     */   public List findAll()
/*     */     throws DataAccessException
/*     */   {
/* 167 */     List list = new ArrayList();
/*     */     try {
/* 169 */       String sql = "from MtlCampDataSource as a  where a.sourceType in(1,2) order by a.sourceName";
/*     */ 
/* 173 */       list = getHibernateTemplate().find(sql);
/*     */     } catch (DataAccessException de) {
/* 175 */       log.error("", de);
/*     */     }
/* 177 */     return list;
/*     */   }
/*     */ 
/*     */   public List findBySourceTypeWithColumns(Short[] type)
/*     */     throws Exception
/*     */   {
/* 184 */     String sql = "from MtlCampDataSource mcds where mcds.sourceName<>'mtl_comp_userinfo' and mcds.sourceStatus=1";
/*     */ 
/* 186 */     for (int i = 0; (type != null) && (i < type.length); i++) {
/* 187 */       if (i == 0) {
/* 188 */         sql = sql + " and (";
/*     */       }
/* 190 */       sql = sql + " mcds.sourceType=" + type[i];
/* 191 */       if (i == type.length - 1)
/* 192 */         sql = sql + ")";
/*     */       else {
/* 194 */         sql = sql + " or ";
/*     */       }
/*     */     }
/*     */ 
/* 198 */     final String tmpSql = sql;
/* 199 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 202 */         Query query = s.createQuery(tmpSql);
/* 203 */         return query.list();
/*     */       }
/*     */     });
/* 208 */     for (int i = 0; i < list.size(); i++) {
/* 209 */       MtlCampDataSource obj = (MtlCampDataSource)list.get(i);
/* 210 */       obj.getColumns().iterator();
/*     */     }
/* 212 */     return list;
/*     */   }
/*     */ 
/*     */   public List findBySourceNameWithColumns(String[] sourceNames) throws Exception
/*     */   {
/* 217 */     String sql = "from MtlCampDataSource mcds where 1=1 ";
/* 218 */     for (int i = 0; (sourceNames != null) && (i < sourceNames.length); i++) {
/* 219 */       if (i == 0) {
/* 220 */         sql = sql + " and (";
/*     */       }
/* 222 */       sql = sql + " mcds.sourceName='" + sourceNames[i] + "'";
/* 223 */       if (i == sourceNames.length - 1)
/* 224 */         sql = sql + ")";
/*     */       else {
/* 226 */         sql = sql + " or ";
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 232 */     final String tmpSql = sql;
/* 233 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 236 */         Query query = s.createQuery(tmpSql);
/* 237 */         return query.list();
/*     */       }
/*     */     });
/* 243 */     for (int i = 0; i < list.size(); i++) {
/* 244 */       MtlCampDataSource obj = (MtlCampDataSource)list.get(i);
/* 245 */       obj.getColumns().iterator();
/*     */     }
/* 247 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MpmCampDataSourceDaoImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMpmCampDatasrcColumnDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumnId;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.impl.SessionImpl;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MpmCampDatasrcColumnDaoImpl extends HibernateDaoSupport
/*     */   implements IMpmCampDatasrcColumnDao
/*     */ {
/*  33 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public MtlCampDatasrcColumn insertDatasrcColumn(MtlCampDatasrcColumn mtlCampDatasrcColumn)
/*     */     throws DataAccessException
/*     */   {
/*  38 */     getHibernateTemplate().save(mtlCampDatasrcColumn);
/*  39 */     return mtlCampDatasrcColumn;
/*     */   }
/*     */ 
/*     */   public void deleteByStr(String tableName, String columnName, String columnpk)
/*     */     throws DataAccessException
/*     */   {
/*     */     try
/*     */     {
/*  48 */       StringBuffer sql = new StringBuffer("from MtlCampDatasrcColumn as a where 1=1 and");
/*     */ 
/*  50 */       if (!"".equals(tableName.trim())) {
/*  51 */         sql.append(" a.id.sourceName='" + tableName.trim() + "' and");
/*     */       }
/*  53 */       if (!"".equals(columnName.trim())) {
/*  54 */         sql.append(" a.id.columnName='" + columnName.trim() + "' and");
/*     */       }
/*  56 */       if (!"".equals(columnpk.trim())) {
/*  57 */         sql.append(" a.id.columnName||'-'||a.id.sourceName in " + columnpk);
/*     */       }
/*     */ 
/*  61 */       if (sql.charAt(sql.length() - 1) == 'd') {
/*  62 */         sql.setLength(sql.length() - 3);
/*     */       }
/*  64 */       final String delsql = sql.toString();
/*     */ 
/*  66 */       getHibernateTemplate().execute(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/*  69 */           Query query = arg0.createQuery("delete " + delsql);
/*  70 */           query.executeUpdate();
/*  71 */           return null;
/*     */         } } );
/*     */     }
/*     */     catch (DataAccessException de) {
/*  75 */       log.error("", de);
/*  76 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateByHiberate(MtlCampDatasrcColumn mtlCampDatasrcColumn)
/*     */     throws DataAccessException
/*     */   {
/*     */     try
/*     */     {
/*  86 */       getHibernateTemplate().saveOrUpdate(mtlCampDatasrcColumn);
/*     */     } catch (DataAccessException e) {
/*  88 */       log.error("", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateByJdbc(MtlCampDatasrcColumn svc)
/*     */     throws DataAccessException
/*     */   {
/*  98 */     Sqlca sqlca = null;
/*     */     try {
/* 100 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 101 */       String sql = "update mtl_camp_datasrc_column set column_name=?,column_type=?,column_cname=?,column_flag=?,column_desc=?,column_datatype=?,column_status=? where column_name=? and source_name=?";
/* 102 */       sqlca.execute(sql, new Object[] { svc.getId().getColumnName(), Integer.valueOf(Integer.parseInt(svc.getId().getColumnType())), svc.getColumnCname(), Integer.valueOf(Integer.parseInt(svc.getColumnFlag())), svc.getColumnDesc(), svc.getColumnDatatype(), svc.getColumnStatus(), svc.getBeforeColumnName(), svc.getId().getSourceName() });
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 112 */       log.error("", e);
/*     */     } finally {
/* 114 */       if (sqlca != null)
/* 115 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map findByTabname(String tabname, Integer curPage, Integer pageSize)
/*     */     throws DataAccessException
/*     */   {
/* 126 */     HashMap map = new HashMap();
/* 127 */     Sqlca sqlca = null;
/*     */     try {
/* 129 */       List list = new ArrayList();
/* 130 */       Integer total = Integer.valueOf(0);
/* 131 */       String sql = " from MtlCampDatasrcColumn as a where a.id.sourceName=?";
/* 132 */       list = getHibernateTemplate().find(sql, new Object[] { tabname.trim() });
/*     */ 
/* 134 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 135 */       StringBuffer sb = new StringBuffer();
/* 136 */       sqlca.execute("select count(*) total from mtl_camp_Datasrc_column as a where a.source_name=?", new Object[] { tabname.trim() });
/*     */ 
/* 139 */       while (sqlca.next()) {
/* 140 */         total = Integer.valueOf(sqlca.getString("total"));
/*     */       }
/* 142 */       map.put("total", total);
/* 143 */       map.put("result", list);
/*     */     } catch (Exception de) {
/* 145 */       log.error("", de);
/*     */     } finally {
/* 147 */       if (sqlca != null) {
/* 148 */         sqlca.close();
/*     */       }
/*     */     }
/* 151 */     return map;
/*     */   }
/*     */ 
/*     */   public MtlCampDatasrcColumn findByColname(String colname)
/*     */     throws DataAccessException
/*     */   {
/* 159 */     MtlCampDatasrcColumn obj = new MtlCampDatasrcColumn();
/*     */     try {
/* 161 */       String sql = "from MtlCampDatasrcColumn as a  where a.columnName = '" + colname.trim() + "'";
/*     */ 
/* 163 */       List list = getHibernateTemplate().find(sql);
/* 164 */       if ((list != null) && (list.size() > 0))
/* 165 */         obj = (MtlCampDatasrcColumn)list.get(0);
/*     */     }
/*     */     catch (DataAccessException de) {
/* 168 */       log.error("", de);
/*     */     }
/* 170 */     return obj;
/*     */   }
/*     */ 
/*     */   public MtlCampDatasrcColumn findByColCname(String colCname)
/*     */     throws MpmException
/*     */   {
/* 178 */     MtlCampDatasrcColumn obj = null;
/*     */     try {
/* 180 */       String sql = "from MtlCampDatasrcColumn as a  where a.columnCname='" + colCname.trim() + "'";
/*     */ 
/* 182 */       List list = getHibernateTemplate().find(sql);
/* 183 */       if ((list != null) && (list.size() > 0))
/* 184 */         obj = (MtlCampDatasrcColumn)list.get(0);
/*     */     }
/*     */     catch (MpmException de) {
/* 187 */       log.error("", de);
/*     */     }
/* 189 */     return obj;
/*     */   }
/*     */ 
/*     */   public MtlCampDatasrcColumn findByColCname(String colCname, String sourceName) throws MpmException
/*     */   {
/* 194 */     MtlCampDatasrcColumn obj = null;
/*     */     try {
/* 196 */       String sql = "from MtlCampDatasrcColumn as a  where a.columnCname='" + colCname.trim() + "' and a.id.sourceName='" + sourceName.trim() + "'";
/*     */ 
/* 200 */       List list = getHibernateTemplate().find(sql);
/* 201 */       if ((list != null) && (list.size() > 0))
/* 202 */         obj = (MtlCampDatasrcColumn)list.get(0);
/*     */     }
/*     */     catch (MpmException de) {
/* 205 */       log.error("", de);
/*     */     }
/* 207 */     return obj;
/*     */   }
/*     */ 
/*     */   public MtlCampDatasrcColumn getCampDatasrcColumn(String sourceName, String colName) throws Exception
/*     */   {
/* 212 */     MtlCampDatasrcColumn obj = null;
/* 213 */     String sql = "from MtlCampDatasrcColumn a where a.id.columnName='" + colName.trim() + "' and a.id.sourceName='" + sourceName.trim() + "'";
/*     */ 
/* 216 */     List list = getHibernateTemplate().find(sql);
/* 217 */     if ((list != null) && (list.size() > 0)) {
/* 218 */       obj = (MtlCampDatasrcColumn)list.get(0);
/*     */     }
/* 220 */     return obj;
/*     */   }
/*     */ 
/*     */   public List findByCondtion(MtlCampDatasrcColumn obj)
/*     */     throws DataAccessException
/*     */   {
/* 229 */     List list = new ArrayList();
/*     */     try {
/* 231 */       StringBuffer sql = new StringBuffer("from MtlCampDatasrcColumn as a where 1=1 ");
/*     */ 
/* 233 */       if ((obj.getId().getColumnName() != null) && (!"".equals(obj.getId().getColumnName())))
/*     */       {
/* 235 */         sql.append(" and a.id.columnName='" + obj.getId().getColumnName() + "'");
/*     */       }
/*     */ 
/* 238 */       if ((obj.getId().getSourceName() != null) && (!"".equals(obj.getId().getSourceName())))
/*     */       {
/* 240 */         sql.append(" and a.id.sourceName='" + obj.getId().getSourceName() + "'");
/*     */       }
/*     */ 
/* 243 */       if ((obj.getId().getColumnType() != null) && (!"".equals(obj.getId().getColumnType())))
/*     */       {
/* 245 */         sql.append(" and a.id.columnType=" + obj.getId().getColumnType() + "");
/*     */       }
/*     */ 
/* 248 */       if ((obj.getColumnClass() != null) && (obj.getColumnClass().length() > 0))
/*     */       {
/* 250 */         sql.append(" and a.columnClass=" + obj.getColumnClass());
/*     */       }
/* 252 */       list = getHibernateTemplate().find(sql.toString());
/*     */     } catch (DataAccessException de) {
/* 254 */       log.error("", de);
/*     */     }
/* 256 */     return list;
/*     */   }
/*     */ 
/*     */   public List findAll()
/*     */     throws DataAccessException
/*     */   {
/* 265 */     List list = new ArrayList();
/*     */     try {
/* 267 */       String sql = "from MtlCampDatasrcColumn as a order by a.id.columnName";
/* 268 */       list = getHibernateTemplate().find(sql);
/*     */     } catch (DataAccessException de) {
/* 270 */       log.error("", de);
/*     */     }
/*     */ 
/* 273 */     return list;
/*     */   }
/*     */ 
/*     */   public List getAllClass()
/*     */     throws DataAccessException
/*     */   {
/* 283 */     return getHibernateTemplate().find("from DimColumnClass dcc order by dcc.classId");
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MpmCampDatasrcColumnDaoImpl
 * JD-Core Version:    0.6.2
 */
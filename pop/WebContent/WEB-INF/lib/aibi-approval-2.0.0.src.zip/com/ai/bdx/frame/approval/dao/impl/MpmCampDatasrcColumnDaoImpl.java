package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.impl.SessionImpl;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMpmCampDatasrcColumnDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;

/**
 * 数据源管理数据库操作
 * 
 * @author zhoulb
 *
 */

public class MpmCampDatasrcColumnDaoImpl extends HibernateDaoSupport implements
		IMpmCampDatasrcColumnDao {
	private static Logger log = LogManager.getLogger();

	public MtlCampDatasrcColumn insertDatasrcColumn(
			MtlCampDatasrcColumn mtlCampDatasrcColumn)
			throws DataAccessException {
		getHibernateTemplate().save(mtlCampDatasrcColumn);
		return mtlCampDatasrcColumn;
	}

	/**
	 *
	 */
	public void deleteByStr(String tableName, String columnName, String columnpk)
			throws DataAccessException {
		try {
			StringBuffer sql = new StringBuffer(
					"from MtlCampDatasrcColumn as a where 1=1 and");
			if (!"".equals(tableName.trim())) {
				sql.append(" a.id.sourceName='" + tableName.trim() + "' and");
			}
			if (!"".equals(columnName.trim())) {
				sql.append(" a.id.columnName='" + columnName.trim() + "' and");
			}
			if (!"".equals(columnpk.trim())) {
				sql.append(" a.id.columnName||'-'||a.id.sourceName in "
						+ columnpk);
			}

			if (sql.charAt(sql.length() - 1) == 'd') {
				sql.setLength(sql.length() - 3);
			}
			final String delsql = sql.toString();
			// getHibernateTemplate().delete(sql.toString());
			this.getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session arg0)
						throws HibernateException, SQLException {
					Query query = arg0.createQuery("delete " + delsql);
					query.executeUpdate();
					return null;
				}
			});
		} catch (DataAccessException de) {
			log.error("", de);
			return;
		}
	}

	/**
	 * 保存或更新字段信息
	 */
	public void updateByHiberate(MtlCampDatasrcColumn mtlCampDatasrcColumn)
			throws DataAccessException {
		try {
			getHibernateTemplate().saveOrUpdate(mtlCampDatasrcColumn);
		} catch (DataAccessException e) {
			log.error("", e);
		}
		return;
	}

	/**
	 * 保存或更新字段信息
	 */
	public void updateByJdbc(MtlCampDatasrcColumn svc)
			throws DataAccessException {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl) this.getSession()).connection());
			String sql = "update mtl_camp_datasrc_column set column_name=?,column_type=?,column_cname=?,column_flag=?,column_desc=?,column_datatype=?,column_status=? where column_name=? and source_name=?";
			sqlca.execute(
					sql,
					new Object[] { svc.getId().getColumnName(),
							Integer.parseInt(svc.getId().getColumnType()),
							svc.getColumnCname(),
							Integer.parseInt(svc.getColumnFlag()),
							svc.getColumnDesc(), svc.getColumnDatatype(),
							svc.getColumnStatus(), svc.getBeforeColumnName(),
							svc.getId().getSourceName() });
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
		return;
	}

	/**
	 * 通过表名来查询字段信息
	 */
	public Map findByTabname(String tabname, Integer curPage, Integer pageSize)
			throws DataAccessException {
		HashMap map = new HashMap();
		Sqlca sqlca = null;
		try {
			List list = new ArrayList();
			Integer total = Integer.valueOf(0);
			String sql = " from MtlCampDatasrcColumn as a where a.id.sourceName=?";
			list = getHibernateTemplate().find(sql,
					new Object[] { tabname.trim() });
			sqlca = new Sqlca(((SessionImpl) this.getSession()).connection());
			StringBuffer sb = new StringBuffer();
			sqlca.execute(
					"select count(*) total from mtl_camp_Datasrc_column as a where a.source_name=?",
					new Object[] { tabname.trim() });
			while (sqlca.next()) {
				total = Integer.valueOf(sqlca.getString("total"));
			}
			map.put("total", total);
			map.put("result", list);
		} catch (Exception de) {
			log.error("", de);
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
		return map;
	}

	/**
	 * 通过字段名来查询字段信息
	 */
	public MtlCampDatasrcColumn findByColname(String colname)
			throws DataAccessException {
		MtlCampDatasrcColumn obj = new MtlCampDatasrcColumn();
		try {
			String sql = "from MtlCampDatasrcColumn as a  where a.columnName = '"
					+ colname.trim() + "'";
			List list = getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				obj = (MtlCampDatasrcColumn) list.get(0);
			}
		} catch (DataAccessException de) {
			log.error("", de);
		}
		return obj;
	}

	/**
	 * 通过字段名来查询字段信息
	 */
	public MtlCampDatasrcColumn findByColCname(String colCname)
			throws MpmException {
		MtlCampDatasrcColumn obj = null;
		try {
			String sql = "from MtlCampDatasrcColumn as a  where a.columnCname='"
					+ colCname.trim() + "'";
			List list = getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				obj = (MtlCampDatasrcColumn) list.get(0);
			}
		} catch (MpmException de) {
			log.error("", de);
		}
		return obj;
	}

	public MtlCampDatasrcColumn findByColCname(String colCname,
			String sourceName) throws MpmException {
		MtlCampDatasrcColumn obj = null;
		try {
			String sql = "from MtlCampDatasrcColumn as a  where a.columnCname='"
					+ colCname.trim()
					+ "' and a.id.sourceName='"
					+ sourceName.trim() + "'";
			List list = getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				obj = (MtlCampDatasrcColumn) list.get(0);
			}
		} catch (MpmException de) {
			log.error("", de);
		}
		return obj;
	}

	public MtlCampDatasrcColumn getCampDatasrcColumn(String sourceName,
			String colName) throws Exception {
		MtlCampDatasrcColumn obj = null;
		String sql = "from MtlCampDatasrcColumn a where a.id.columnName='"
				+ colName.trim() + "' and a.id.sourceName='"
				+ sourceName.trim() + "'";
		List list = getHibernateTemplate().find(sql);
		if (list != null && list.size() > 0) {
			obj = (MtlCampDatasrcColumn) list.get(0);
		}
		return obj;
	}

	/**
	 * 通过条件组合查询字段信息
	 *
	 */
	public List findByCondtion(MtlCampDatasrcColumn obj)
			throws DataAccessException {
		List list = new ArrayList();
		try {
			StringBuffer sql = new StringBuffer(
					"from MtlCampDatasrcColumn as a where 1=1 ");
			if (obj.getId().getColumnName() != null
					&& !"".equals(obj.getId().getColumnName())) {
				sql.append(" and a.id.columnName='"
						+ obj.getId().getColumnName() + "'");
			}
			if (obj.getId().getSourceName() != null
					&& !"".equals(obj.getId().getSourceName())) {
				sql.append(" and a.id.sourceName='"
						+ obj.getId().getSourceName() + "'");
			}
			if (obj.getId().getColumnType() != null
					&& !"".equals(obj.getId().getColumnType())) {
				sql.append(" and a.id.columnType="
						+ obj.getId().getColumnType() + "");
			}
			if (obj.getColumnClass() != null
					&& obj.getColumnClass().length() > 0) {
				sql.append(" and a.columnClass=" + obj.getColumnClass());
			}
			list = getHibernateTemplate().find(sql.toString());
		} catch (DataAccessException de) {
			log.error("", de);
		}
		return list;
	}

	/**
	 * 查询所有的记录
	 * 
	 * @return List
	 */
	public List findAll() throws DataAccessException {
		List list = new ArrayList();
		try {
			String sql = "from MtlCampDatasrcColumn as a order by a.id.columnName";
			list = getHibernateTemplate().find(sql);
		} catch (DataAccessException de) {
			log.error("", de);
			;
		}
		return list;
	}

	/**
	 * 得到所有的字段分类信息
	 * 
	 * @return
	 * @throws DataAccessException
	 */
	public List getAllClass() throws DataAccessException {
		return this.getHibernateTemplate().find(
				"from DimColumnClass dcc order by dcc.classId");
	}
}

/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.util.MpmConfigure;
/*     */ import com.ai.bdx.frame.approval.util.MpmHtmlHelper;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import com.ai.bdx.frame.approval.util.MpmUtil;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.RowMapperResultSetExtractor;
/*     */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*     */ 
/*     */ public class MpmCommonJdbcDaoImpl extends JdbcDaoSupport
/*     */   implements IMpmCommonJdbcDao
/*     */ {
/*  42 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*  44 */   IUserPrivilegeCommonService mpmUserPrivilegeService = null;
/*     */ 
/*     */   public List getDimCompBrand()
/*     */     throws Exception
/*     */   {
/*  55 */     List list = new ArrayList();
/*  56 */     String sql = "select COMP_BRAND_ID, COMPBRAND_NAME from DIM_COMP_BRAND  where ACTIVE_FLAG =1";
/*     */ 
/*  58 */     list = (List)getJdbcTemplate().query(sql, new RowMapperResultSetExtractor(new RowMapper()
/*     */     {
/*     */       public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
/*  61 */         return new LabelValueBean(rs.getString("COMPBRAND_NAME"), rs.getString("COMP_BRAND_ID"));
/*     */       }
/*     */     }
/*     */     , 0));
/*     */ 
/*  65 */     return list;
/*     */   }
/*     */ 
/*     */   public List getCampChannelTypeMap()
/*     */     throws Exception
/*     */   {
/*  72 */     List list = new ArrayList();
/*  73 */     String sql = "select CHANNELTYPE_ID, CHANNELTYPE_NAME from AP_MTL_CHANNELTYPE";
/*  74 */     list = getJdbcTemplate().queryForList(sql);
/*  75 */     return list;
/*     */   }
/*     */ 
/*     */   public List getMtlCampRuleTypeMap()
/*     */     throws Exception
/*     */   {
/*  81 */     List list = new ArrayList();
/*  82 */     String sql = "select RULE_TYPE_ID, RULE_TYPE_NAME from DIM_MTL_CAMP_RULE_TYPE";
/*  83 */     list = getJdbcTemplate().queryForList(sql);
/*  84 */     return list;
/*     */   }
/*     */ 
/*     */   public List getCampChannelIdMap(int channeltypeId)
/*     */     throws Exception
/*     */   {
/*  91 */     List list = new ArrayList();
/*  92 */     StringBuffer sql = new StringBuffer();
/*  93 */     sql.append("select CHANNEL_ID, CHANNEL_NAME from ap_mtl_channel where channeltype_id=").append(channeltypeId);
/*     */ 
/*  97 */     list = getJdbcTemplate().queryForList(sql.toString());
/*  98 */     return list;
/*     */   }
/*     */ 
/*     */   public List getAllChannel()
/*     */     throws Exception
/*     */   {
/* 104 */     List list = null;
/*     */     try {
/* 106 */       String sql = "select  *  from ap_mtl_channel";
/* 107 */       list = getJdbcTemplate().queryForList(sql);
/*     */     } catch (Exception e) {
/* 109 */       log.error("", e);
/*     */     }
/* 111 */     return list;
/*     */   }
/*     */ 
/*     */   public boolean isNameExistForDataColumn(String name, String id, String idColumn, String nameColumn, String tableName)
/*     */     throws Exception
/*     */   {
/* 117 */     boolean res = true;
/* 118 */     StringBuffer sql = new StringBuffer();
/* 119 */     sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ").append(nameColumn).append("='").append(name).append("'");
/*     */ 
/* 123 */     if ((id != null) && (id.length() > 0) && (idColumn != null) && (idColumn.length() > 0)) {
/* 124 */       sql.append(" and ").append(idColumn).append("='").append(id).append("'");
/*     */     }
/*     */ 
/* 127 */     log.debug(">>isNameExist(): " + sql);
/* 128 */     int cnt = getJdbcTemplate().queryForInt(sql.toString());
/* 129 */     if (cnt < 1) {
/* 130 */       res = false;
/*     */     }
/* 132 */     return res;
/*     */   }
/*     */ 
/*     */   public boolean isNameExist(String name, String id, String idColumn, String nameColumn, String tableName)
/*     */     throws Exception
/*     */   {
/* 138 */     boolean res = true;
/*     */ 
/* 140 */     StringBuffer sql = new StringBuffer();
/* 141 */     if (tableName.equals("mtl_ir_indi_define")) {
/* 142 */       sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ").append(nameColumn).append(" like '%").append(name).append("'");
/*     */     }
/* 147 */     else if (tableName.equals("mtl_targetuser_file"))
/*     */     {
/* 149 */       sql.append("select count(source_cname) from MTL_CAMP_DATA_SOURCE where source_cname='").append(name).append("'");
/*     */ 
/* 154 */       log.debug(">>isNameExist(): " + sql);
/* 155 */       int cnt = getJdbcTemplate().queryForInt(sql.toString());
/* 156 */       if (cnt > 0) {
/* 157 */         return true;
/*     */       }
/* 159 */       sql.delete(0, sql.length());
/*     */ 
/* 161 */       sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ").append(nameColumn).append("='").append(name).append("'");
/*     */     }
/*     */     else
/*     */     {
/* 166 */       sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ").append(nameColumn).append("='").append(name).append("'");
/*     */     }
/*     */ 
/* 171 */     if ((id != null) && (id.length() > 0) && (idColumn != null) && (idColumn.length() > 0)) {
/* 172 */       if ((tableName.equalsIgnoreCase("AP_APPROVE_DRV_TYPE")) || (tableName.equalsIgnoreCase("EVENT_TAG_DEFINE"))) {
/* 173 */         sql.append(" and ").append(idColumn).append("<>").append(id);
/*     */       }
/*     */       else {
/* 176 */         sql.append(" and ").append(idColumn).append("<>'").append(id).append("'");
/*     */       }
/*     */     }
/*     */ 
/* 180 */     log.debug(">>isNameExist(): " + sql);
/* 181 */     int cnt = getJdbcTemplate().queryForInt(sql.toString());
/* 182 */     if (cnt < 1) {
/* 183 */       res = false;
/*     */     }
/* 185 */     return res;
/*     */   }
/*     */ 
/*     */   public boolean isNameExistForInt(String name, String id, String idColumn, String nameColumn, String tableName)
/*     */     throws Exception
/*     */   {
/* 191 */     boolean res = true;
/* 192 */     StringBuffer sql = new StringBuffer();
/* 193 */     sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ").append(nameColumn).append("=").append(name).append("");
/*     */ 
/* 197 */     if ((id != null) && (id.length() > 0) && (idColumn != null) && (idColumn.length() > 0))
/*     */     {
/* 199 */       sql.append(" and ").append(idColumn).append("<>").append(id).append("");
/*     */     }
/* 201 */     log.debug(">>isNameExist(): " + sql);
/* 202 */     int cnt = getJdbcTemplate().queryForInt(sql.toString());
/* 203 */     if (cnt < 1) {
/* 204 */       res = false;
/*     */     }
/* 206 */     return res;
/*     */   }
/*     */ 
/*     */   public int isDimColumnExists(String columnName, String sourceName)
/*     */   {
/* 211 */     int res = 0;
/*     */     try {
/* 213 */       String sql = " select * from " + sourceName + " where 1=2";
/* 214 */       log.debug(">>isDimColumnExists(): " + sql);
/* 215 */       getJdbcTemplate().execute(sql);
/*     */     } catch (Exception e) {
/* 217 */       return 1;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 222 */       String sql = " select count(" + columnName + ") from " + sourceName + " where 1=2";
/* 223 */       log.debug(">>isDimColumnExists(): " + sql);
/* 224 */       cnt = getJdbcTemplate().queryForInt(sql);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       int cnt;
/* 226 */       return 2;
/*     */     }
/*     */ 
/* 229 */     return res;
/*     */   }
/*     */ 
/*     */   public String getUserDeptPolicyCache(String userId, int deptId) throws Exception
/*     */   {
/* 234 */     String res = "";
/* 235 */     Sqlca sqlca = null;
/*     */     try {
/* 237 */       sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 239 */       StringBuffer sql = new StringBuffer();
/* 240 */       sql.append("select a.userId from user_user a,(select deptId from user_company where deptId=").append(deptId).append(" or parentId=").append(deptId).append(") b where a.departmentId=b.deptId");
/*     */ 
/* 246 */       log.debug(">>getUserDeptPolicyCache(): \n" + sql);
/* 247 */       sqlca.execute(sql.toString());
/* 248 */       while (sqlca.next()) {
/* 249 */         res = res + "'" + sqlca.getString("userId") + "',";
/*     */       }
/* 251 */       if (res.length() > 0)
/* 252 */         res = res.substring(0, res.length() - 1);
/*     */     }
/*     */     catch (Exception e) {
/* 255 */       throw e;
/*     */     } finally {
/* 257 */       if (sqlca != null) {
/* 258 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 261 */     return res;
/*     */   }
/*     */ 
/*     */   // ERROR //
/*     */   @java.lang.Deprecated
/*     */   public void deleteCampsegUserProcessResult(String campsegId)
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: aload_2
/*     */     //   3: ifnull +21 -> 24
/*     */     //   6: aload_2
/*     */     //   7: invokevirtual 75	com/asiainfo/biframe/utils/database/jdbc/Sqlca:close	()V
/*     */     //   10: goto +14 -> 24
/*     */     //   13: astore_3
/*     */     //   14: aload_2
/*     */     //   15: ifnull +7 -> 22
/*     */     //   18: aload_2
/*     */     //   19: invokevirtual 75	com/asiainfo/biframe/utils/database/jdbc/Sqlca:close	()V
/*     */     //   22: aload_3
/*     */     //   23: athrow
/*     */     //   24: return
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   13	14	13	finally
/*     */   }
/*     */ 
/*     */   public List getCampsegCostListByResType(String resType, String campsegId)
/*     */     throws Exception
/*     */   {
/* 331 */     List list = new ArrayList();
/*     */ 
/* 333 */     StringBuffer sqlSb = new StringBuffer();
/* 334 */     String linkTable = "";
/*     */ 
/* 336 */     if ((resType.equals("10")) || (resType.equals("50"))) {
/* 337 */       linkTable = "mtl_channel_cost";
/*     */     }
/* 340 */     else if ((resType.equals("30")) || (resType.equals("40"))) {
/* 341 */       linkTable = "MTL_publicize_reslist";
/*     */     }
/* 344 */     else if (resType.equals("20")) {
/* 345 */       linkTable = "(select a.campseg_id,b.cost_no from mtl_camp_segInfo a,mtl_plan_cost b where a.camp_id=b.camp_id and a.campseg_id='" + campsegId + "')";
/*     */     }
/*     */ 
/* 349 */     if ((!resType.equals("30")) && (!resType.equals("40"))) {
/* 350 */       sqlSb.append("select t3.res_name,t3.res_type,t2.res_nums,t2.res_price,t2.res_cost \n").append(" from " + linkTable + " t1,MTL_resource_cost_plan t2,MTL_res_list t3 \n").append(" where t1.campseg_id='" + campsegId + "' and t2.cost_no=t1.cost_no \n").append(" and t2.res_code=t3.res_code and t3.res_type=" + resType);
/*     */     }
/*     */     else
/*     */     {
/* 355 */       sqlSb.append("select t3.res_name,t3.res_type,t2.res_nums,t2.res_price,t2.res_cost \n").append(" from " + linkTable + " t1,MTL_resource_cost_plan t2,MTL_res_list t3,mtl_publicize_plan t5 \n").append(" where 1=1 ").append(" and t5.publicize_comb_id=t4.proform_result and t1.publicize_id = t5.publicize_id ").append(" and t2.cost_no=t1.cost_no \n").append(" and t2.res_code=t3.res_code and t3.res_type=" + resType);
/*     */     }
/*     */ 
/* 364 */     list = (List)getJdbcTemplate().query(sqlSb.toString(), new RowMapperResultSetExtractor(new RowMapper()
/*     */     {
/*     */       public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 367 */         String[] tmpArr = new String[5];
/* 368 */         tmpArr[0] = rs.getString("res_name");
/* 369 */         tmpArr[1] = rs.getString("res_type");
/* 370 */         tmpArr[2] = rs.getString("res_nums");
/* 371 */         tmpArr[3] = rs.getString("res_price");
/* 372 */         tmpArr[4] = rs.getString("res_cost");
/* 373 */         return tmpArr;
/*     */       }
/*     */     }
/*     */     , 0));
/*     */ 
/* 377 */     return list;
/*     */   }
/*     */ 
/*     */   public String getFirstExistTable(String[] userbaseTables) throws Exception
/*     */   {
/* 382 */     String res = "";
/* 383 */     String strType = MpmUtil.getDBType();
/* 384 */     Sqlca sqlca = new Sqlca(new ConnectionEx());
/* 385 */     sqlca.setDBMSType(strType);
/* 386 */     String strSql = "";
/*     */ 
/* 388 */     int len = userbaseTables.length;
/* 389 */     int i = 0; if (i < len) {
/* 390 */       String tableName = userbaseTables[i];
/* 391 */       strSql = sqlca.getCheckTableIsExistSql(tableName);
/*     */       try
/*     */       {
/* 399 */         StringBuffer sqlBuffer = new StringBuffer();
/* 400 */         sqlBuffer.append("select count(*) from ").append(tableName).append(" where 1=2");
/* 401 */         getJdbcTemplate().execute(sqlBuffer.toString());
/*     */ 
/* 404 */         res = tableName;
/*     */ 
/* 408 */         if (sqlca != null)
/* 409 */           sqlca.closeAll();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 408 */         if (sqlca != null)
/* 409 */           sqlca.closeAll();
/*     */       }
/*     */       finally
/*     */       {
/* 408 */         if (sqlca != null) {
/* 409 */           sqlca.closeAll();
/*     */         }
/*     */       }
/*     */     }
/* 413 */     return res;
/*     */   }
/*     */ 
/*     */   public List getExistTables(String[] userbaseTables) throws Exception
/*     */   {
/* 418 */     List list = new ArrayList();
/*     */ 
/* 420 */     for (int i = 0; i < userbaseTables.length; i++) {
/* 421 */       String tableName = userbaseTables[i];
/*     */       try {
/* 423 */         StringBuffer sqlBuffer = new StringBuffer();
/* 424 */         sqlBuffer.append("select * from ").append(tableName).append(" where 1=2");
/* 425 */         getJdbcTemplate().execute(sqlBuffer.toString());
/*     */ 
/* 428 */         list.add(tableName);
/*     */       }
/*     */       catch (Exception e) {
/*     */       }
/*     */     }
/* 433 */     return list;
/*     */   }
/*     */ 
/*     */   public String getCompanyTreeHtml() throws Exception
/*     */   {
/* 438 */     Sqlca sqlca = null;
/*     */     try {
/* 440 */       sqlca = new Sqlca(new ConnectionEx());
/* 441 */       String strPageFormat = "<font style='cursor:hand' onClick='onSelecCompany(this)' MYID='[ID]' MYNAME='[S]'>[S]</font></a>";
/* 442 */       return MpmHtmlHelper.getCompanyTree(sqlca, strPageFormat, strPageFormat, false, true);
/*     */     } catch (Exception e) {
/* 444 */       throw e;
/*     */     } finally {
/* 446 */       if (sqlca != null)
/* 447 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updatePublicizeComb(String campsegId, String publicizeCombId)
/*     */     throws Exception
/*     */   {
/* 462 */     Sqlca sqlca = null;
/* 463 */     Sqlca sqlca1 = null;
/*     */     try {
/* 465 */       sqlca = new Sqlca(getConnection());
/* 466 */       sqlca1 = new Sqlca(getConnection());
/* 467 */       StringBuffer sqlBuffer = new StringBuffer();
/* 468 */       sqlBuffer.append("update mtl_camp_seginfo set publicize_comb_id='").append(publicizeCombId).append("' where campseg_id='").append(campsegId).append("'");
/*     */ 
/* 473 */       sqlca.execute(sqlBuffer.toString());
/* 474 */       sqlBuffer.delete(0, sqlBuffer.length());
/*     */     } catch (Exception e) {
/* 476 */       throw e;
/*     */     } finally {
/* 478 */       if (sqlca1 != null) {
/* 479 */         sqlca1.close();
/*     */       }
/* 481 */       if (sqlca != null)
/* 482 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getApproveFlowidByChannelTypeAndId(String type, String cid)
/*     */     throws MpmException
/*     */   {
/* 496 */     String res = "";
/* 497 */     Sqlca sqlca = null;
/*     */     try {
/* 499 */       sqlca = new Sqlca(getConnection());
/* 500 */       StringBuffer sql = new StringBuffer();
/* 501 */       sql.append("select approve_flow_id from ap_approve_flow_def where channeltype_id=").append(type).append(" and channel_id='").append(cid).append("'");
/*     */ 
/* 507 */       sqlca.execute(sql.toString());
/* 508 */       while (sqlca.next())
/* 509 */         res = sqlca.getString("approve_flow_id");
/*     */     }
/*     */     catch (Exception e) {
/* 512 */       log.error("", e);
/*     */     } finally {
/* 514 */       if (sqlca != null) {
/* 515 */         sqlca.close();
/*     */       }
/*     */     }
/* 518 */     return res;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowid(String userid, String campDrvId, String channeltypeId, String channelId, String approveType)
/*     */     throws MpmException
/*     */   {
/* 531 */     String res = "";
/* 532 */     Sqlca sqlca = null;
/*     */     try {
/* 534 */       IUser user = getMpmUserPrivilegeService().getUser(userid);
/* 535 */       sqlca = new Sqlca(getConnection());
/* 536 */       sqlca.setAutoCommit(false);
/*     */ 
/* 538 */       StringBuffer sql = new StringBuffer();
/* 539 */       if (approveType.equals("1")) {
/* 540 */         sql.append("select approve_flow_id from ap_dept_flow_relation where city_id in('").append(user.getCityid()).append("','-1') and dept_id in('").append(user.getDepartmentid()).append("','-1') and approve_type=1 order by city_id,dept_id desc");
/*     */ 
/* 548 */         sqlca.execute(sql.toString());
/* 549 */         sql.delete(0, sql.length());
/* 550 */         while (sqlca.next()) {
/* 551 */           res = sqlca.getString("approve_flow_id");
/*     */         }
/* 553 */         if (StringUtil.isEmpty(res)) {
/* 554 */           sql.append("select approve_flow_id from ap_approve_flow_def where approve_flow_name='default1'");
/*     */ 
/* 557 */           sqlca.execute(sql.toString());
/* 558 */           sql.delete(0, sql.length());
/* 559 */           while (sqlca.next()) {
/* 560 */             res = sqlca.getString("approve_flow_id");
/*     */           }
/*     */         }
/* 563 */         log.debug("营销案的审批流程sql:" + sql);
/* 564 */       } else if (approveType.equals("2")) {
/* 565 */         String how_to_show_data = MpmConfigure.getInstance().getProperty("HOW_TO_SHOW_DATA");
/* 566 */         if ("0".equals(how_to_show_data)) {
/* 567 */           sql.append("select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id,dept_id from ap_dept_flow_relation where city_id='").append(user.getCityid()).append("' and  approve_type=2");
/*     */         }
/*     */         else
/*     */         {
/* 574 */           sql.append("select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id ,dept_id  from ap_dept_flow_relation where city_id='").append(user.getCityid()).append("' and dept_id='").append(user.getDepartmentid()).append("' and approve_type=2");
/*     */         }
/*     */ 
/* 583 */         sqlca.execute(sql.toString());
/* 584 */         sql.delete(0, sql.length());
/* 585 */         Map deptFlow = new HashMap();
/* 586 */         log.debug("营销活动的审批流程sql:" + sql);
/* 587 */         while (sqlca.next()) {
/* 588 */           String campdid = sqlca.getInt("camp_drv_id") + "";
/* 589 */           String channeltid = sqlca.getInt("channeltype_id") + "";
/* 590 */           String channelid = sqlca.getInt("channel_id") + "";
/* 591 */           String retype = sqlca.getInt("relation_type") + "";
/* 592 */           String approvefid = sqlca.getString("approve_flow_id");
/* 593 */           String deptId = sqlca.getString("dept_id");
/* 594 */           if ((retype.equals("1")) && (campdid.equals(campDrvId))) {
/* 595 */             deptFlow.put(deptId, approvefid);
/*     */           }
/* 597 */           if ((retype.equals("2")) && (((channeltid.equals(channeltypeId)) && (channelid.equals(channelId))) || ((channeltid.equals(channeltypeId)) && (channelid.equals("-1")))))
/*     */           {
/* 600 */             res = approvefid;
/* 601 */             break;
/*     */           }
/* 603 */           if ((retype.equals("3")) && (channeltid.equals(channeltypeId)) && ((channelid.equals(channelId)) || (channelid.equals("-1"))) && (campdid.equals(campDrvId)))
/*     */           {
/* 605 */             res = approvefid;
/* 606 */             break;
/*     */           }
/* 608 */           if (retype.equals("4")) {
/* 609 */             res = approvefid;
/* 610 */             break;
/*     */           }
/*     */         }
/* 613 */         if (StringUtil.isEmpty(res)) {
/* 614 */           res = StringUtil.isEmpty((String)deptFlow.get(String.valueOf(user.getDepartmentid()))) ? (String)deptFlow.get("-1") : (String)deptFlow.get(String.valueOf(user.getDepartmentid()));
/*     */         }
/*     */ 
/* 619 */         if (StringUtil.isEmpty(res)) {
/* 620 */           sql.append("select approve_flow_id from ap_approve_flow_def where approve_flow_name='default2'");
/*     */ 
/* 623 */           sqlca.execute(sql.toString());
/* 624 */           while (sqlca.next())
/* 625 */             res = sqlca.getString("approve_flow_id");
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 630 */       log.error("", e);
/*     */     } finally {
/* 632 */       if (sqlca != null) {
/* 633 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 636 */     log.debug("获取到流程id:" + res);
/* 637 */     return res;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowid(String userid, String campDrvId, String approveType) throws MpmException {
/* 641 */     String res = "";
/* 642 */     Sqlca sqlca = null;
/*     */     try {
/* 644 */       IUser user = getMpmUserPrivilegeService().getUser(userid);
/* 645 */       sqlca = new Sqlca(getConnection());
/* 646 */       sqlca.setAutoCommit(false);
/*     */ 
/* 648 */       StringBuffer sql = new StringBuffer();
/* 649 */       if (approveType.equals("1")) {
/* 650 */         sql.append("select approve_flow_id from ap_dept_flow_relation where city_id in('").append(user.getCityid()).append("','-1') and dept_id in('").append(user.getDepartmentid()).append("','-1') and approve_type=1 order by city_id,dept_id desc");
/*     */ 
/* 658 */         sqlca.execute(sql.toString());
/* 659 */         sql.delete(0, sql.length());
/* 660 */         while (sqlca.next()) {
/* 661 */           res = sqlca.getString("approve_flow_id");
/*     */         }
/* 663 */         if (StringUtil.isEmpty(res.trim())) {
/* 664 */           sql.append("select approve_flow_id from ap_approve_flow_def where approve_flow_name='default1'");
/*     */ 
/* 667 */           sqlca.execute(sql.toString());
/* 668 */           sql.delete(0, sql.length());
/* 669 */           while (sqlca.next()) {
/* 670 */             res = sqlca.getString("approve_flow_id");
/*     */           }
/*     */         }
/* 673 */         log.debug("营销案的审批流程sql:" + sql);
/* 674 */       } else if (approveType.equals("2")) {
/* 675 */         String how_to_show_data = MpmConfigure.getInstance().getProperty("HOW_TO_SHOW_DATA");
/* 676 */         if ("0".equals(how_to_show_data))
/*     */         {
/* 678 */           sql.append("select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id,dept_id from ap_dept_flow_relation where city_id='").append(user.getCityid()).append("'  and approve_type=2");
/*     */         }
/*     */         else
/*     */         {
/* 685 */           sql.append("select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id ,dept_id from ap_dept_flow_relation where city_id='").append(user.getCityid()).append("' and dept_id='").append(user.getDepartmentid()).append("' and approve_type=2");
/*     */         }
/*     */ 
/* 694 */         log.debug("营销活动审批流程：sql:" + sql + " 用户地市：" + user.getCityid() + "部门:" + user.getDepartmentid());
/* 695 */         sqlca.execute(sql.toString());
/* 696 */         sql.delete(0, sql.length());
/* 697 */         Map deptFlow = new HashMap();
/* 698 */         while (sqlca.next()) {
/* 699 */           String campdid = sqlca.getInt("camp_drv_id") + "";
/* 700 */           String retype = sqlca.getInt("relation_type") + "";
/* 701 */           String approvefid = sqlca.getString("approve_flow_id");
/* 702 */           String deptId = sqlca.getString("dept_id");
/* 703 */           if ((retype.equals("1")) && (campdid.equals(campDrvId))) {
/* 704 */             deptFlow.put(deptId, approvefid);
/*     */           }
/* 706 */           if (retype.equals("2")) {
/* 707 */             res = approvefid;
/* 708 */             break;
/*     */           }
/* 710 */           if (retype.equals("3")) {
/* 711 */             res = approvefid;
/* 712 */             break;
/*     */           }
/* 714 */           if (retype.equals("4")) {
/* 715 */             res = approvefid;
/* 716 */             break;
/*     */           }
/*     */         }
/* 719 */         if (StringUtil.isEmpty(res)) {
/* 720 */           res = StringUtil.isEmpty((String)deptFlow.get(String.valueOf(user.getDepartmentid()))) ? (String)deptFlow.get("-1") : (String)deptFlow.get(String.valueOf(user.getDepartmentid()));
/*     */         }
/*     */ 
/* 725 */         if (StringUtil.isEmpty(res)) {
/* 726 */           String sqlTemp = "select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id from ap_dept_flow_relation where dept_id=? and approve_type=2";
/* 727 */           sqlca.execute(sqlTemp, new Object[] { String.valueOf(user.getDepartmentid()) });
/* 728 */           while (sqlca.next()) {
/* 729 */             res = sqlca.getString("approve_flow_id");
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 734 */         if (StringUtil.isEmpty(res)) {
/* 735 */           sqlca.execute("select approve_flow_id from ap_approve_flow_def where approve_flow_name='default2'");
/* 736 */           while (sqlca.next())
/* 737 */             res = sqlca.getString("approve_flow_id");
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 742 */       log.error("", e);
/*     */     } finally {
/* 744 */       if (sqlca != null) {
/* 745 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 748 */     log.debug("获取到流程id:" + res);
/* 749 */     return res;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowid(String userid, String approveType) throws MpmException {
/* 753 */     String res = "";
/* 754 */     Sqlca sqlca = null;
/*     */     try {
/* 756 */       IUser user = getMpmUserPrivilegeService().getUser(userid);
/* 757 */       sqlca = new Sqlca(getConnection());
/* 758 */       sqlca.setAutoCommit(false);
/*     */ 
/* 760 */       StringBuffer sql = new StringBuffer();
/* 761 */       if (approveType.equals("1")) {
/* 762 */         sql.append("select approve_flow_id from ap_approve_flow_def where FIRST_APPROVE_USER='").append(userid).append("'");
/*     */ 
/* 767 */         sqlca.execute(sql.toString());
/* 768 */         while (sqlca.next()) {
/* 769 */           res = sqlca.getString("APPROVE_FLOW_ID");
/*     */         }
/* 771 */         log.debug("营销案的审批流程sql:" + sql);
/* 772 */       } else if (approveType.equals("2"))
/*     */       {
/* 774 */         sql.append("select APPROVE_FLOW_ID from ap_approve_flow_def where FIRST_APPROVE_USER = '").append(userid).append("'");
/*     */ 
/* 779 */         sqlca.execute(sql.toString());
/* 780 */         while (sqlca.next())
/* 781 */           res = sqlca.getString("APPROVE_FLOW_ID");
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 785 */       e.printStackTrace();
/*     */     } finally {
/* 787 */       if (sqlca != null)
/* 788 */         sqlca.closeAll();
/*     */     }
/* 790 */     log.debug("获取到流程id:" + res);
/* 791 */     return res;
/*     */   }
/*     */ 
/*     */   public String excludeBlackList(String srcTable, String avoidCustTypes)
/*     */   {
/* 812 */     String cnum = "0";
/*     */     try {
/* 814 */       if ((avoidCustTypes != null) && (avoidCustTypes.length() > 0)) {
/* 815 */         String blackList = "MTL_BOTHER_AVOID";
/* 816 */         StringBuffer sql = new StringBuffer();
/* 817 */         sql.append("delete from ").append(srcTable).append(" where product_no in(").append(" select product_no from ").append(blackList).append(" where AVOID_CUST_TYPE in (").append(avoidCustTypes).append(")").append(")");
/*     */ 
/* 820 */         this.logger.info(MpmLocaleUtil.getMessage("mcd.java.tcmdr") + sql);
/* 821 */         getJdbcTemplate().execute(sql.toString());
/*     */       }
/* 823 */       StringBuffer sqlBuffer = new StringBuffer();
/* 824 */       sqlBuffer.append("select count(product_no) from ").append(srcTable);
/*     */ 
/* 828 */       cnum = getJdbcTemplate().queryForInt(sqlBuffer.toString()) + "";
/*     */ 
/* 832 */       return cnum;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 829 */       ex = 
/* 832 */         ex;
/*     */ 
/* 830 */       log.error("", ex);
/*     */ 
/* 832 */       return cnum; } finally {  } return cnum;
/*     */   }
/*     */ 
/*     */   public IUserPrivilegeCommonService getMpmUserPrivilegeService()
/*     */   {
/* 838 */     if (this.mpmUserPrivilegeService == null) {
/*     */       try {
/* 840 */         this.mpmUserPrivilegeService = ((IUserPrivilegeCommonService)SystemServiceLocator.getInstance().getService("userPrivilegeCommonService"));
/*     */       }
/*     */       catch (Exception e) {
/* 843 */         log.error("", e);
/*     */       }
/*     */     }
/* 846 */     return this.mpmUserPrivilegeService;
/*     */   }
/*     */ 
/*     */   public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
/* 850 */     this.mpmUserPrivilegeService = mpmUserPrivilegeService;
/*     */   }
/*     */ 
/*     */   public List<LabelValueBean> getBsMmsContent()
/*     */     throws Exception
/*     */   {
/* 860 */     List list = new ArrayList();
/* 861 */     String sql = "select id,name from BS_MMS_CONTENT order by create_date desc";
/*     */ 
/* 863 */     list = (List)getJdbcTemplate().query(sql, new RowMapperResultSetExtractor(new RowMapper()
/*     */     {
/*     */       public Object mapRow(ResultSet rs, int rowNum) throws SQLException
/*     */       {
/* 867 */         return new LabelValueBean(rs.getString("name"), rs.getString("id"));
/*     */       }
/*     */     }
/*     */     , 0));
/*     */ 
/* 871 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MpmCommonJdbcDaoImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.util.MpmConfigure;
import com.ai.bdx.frame.approval.util.MpmHtmlHelper;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
import com.ai.bdx.frame.approval.util.MpmUtil;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
import com.asiainfo.biframe.utils.string.StringUtil;

/*
 * Created on 2:57:54 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MpmCommonJdbcDaoImpl extends JdbcDaoSupport implements IMpmCommonJdbcDao {
	private static Logger log = LogManager.getLogger();

	IUserPrivilegeCommonService mpmUserPrivilegeService = null;

	public MpmCommonJdbcDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	// 获得竞争对手品牌
	@Override
	public List getDimCompBrand() throws Exception {

		List list = new ArrayList();
		String sql = "select COMP_BRAND_ID, COMPBRAND_NAME from DIM_COMP_BRAND  where ACTIVE_FLAG =1";
		// list = this.getJdbcTemplate().queryForList(sql);
		list = (List) this.getJdbcTemplate().query(sql, new RowMapperResultSetExtractor(new RowMapper() {
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new LabelValueBean(rs.getString("COMPBRAND_NAME"), rs.getString("COMP_BRAND_ID"));
			}
		}, 0));

		return list;
	}

	// 获得营销渠道类型
	@Override
	public List getCampChannelTypeMap() throws Exception {

		List list = new ArrayList();
		String sql = "select CHANNELTYPE_ID, CHANNELTYPE_NAME from AP_MTL_CHANNELTYPE";
		list = this.getJdbcTemplate().queryForList(sql);
		return list;
	}

	// 获得营销规则类型
	public List getMtlCampRuleTypeMap() throws Exception {

		List list = new ArrayList();
		String sql = "select RULE_TYPE_ID, RULE_TYPE_NAME from DIM_MTL_CAMP_RULE_TYPE";
		list = this.getJdbcTemplate().queryForList(sql);
		return list;
	}

	// 获得营销渠道信息
	@Override
	public List getCampChannelIdMap(int channeltypeId) throws Exception {

		List list = new ArrayList();
		StringBuffer sql = new StringBuffer();
		sql.append("select CHANNEL_ID, CHANNEL_NAME from ap_mtl_channel where channeltype_id=").append(channeltypeId);
		// String sql =
		// "select CHANNEL_ID, CHANNEL_NAME from ap_mtl_channel where channeltype_id="
		// + channeltypeId;
		list = this.getJdbcTemplate().queryForList(sql.toString());
		return list;
	}

	// 获得全部营销渠道信息
	@Override
	public List getAllChannel() throws Exception {
		List list = null;
		try {
			String sql = "select  *  from ap_mtl_channel";
			list = this.getJdbcTemplate().queryForList(sql);
		} catch (Exception e) {
			log.error("", e);
		}
		return list;
	}

	@Override
	public boolean isNameExistForDataColumn(String name, String id, String idColumn, String nameColumn, String tableName)
			throws Exception {
		boolean res = true;
		StringBuffer sql = new StringBuffer();
		sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ")
				.append(nameColumn).append("='").append(name).append("'");
		// String sql = "select count(" + nameColumn + ") from " + tableName +
		// " where " + nameColumn + "='" + name + "'";
		if (id != null && id.length() > 0 && idColumn != null && idColumn.length() > 0) {
			sql.append(" and ").append(idColumn).append("='").append(id).append("'");
			// sql += " and " + idColumn + "='" + id + "'";
		}
		log.debug(">>isNameExist(): " + sql);
		int cnt = this.getJdbcTemplate().queryForInt(sql.toString());
		if (cnt < 1) {
			res = false;
		}
		return res;
	}

	@Override
	public boolean isNameExist(String name, String id, String idColumn, String nameColumn, String tableName)
			throws Exception {
		boolean res = true;
		// String sql = "";
		StringBuffer sql = new StringBuffer();
		if (tableName.equals(MpmCONST.MPM_RES_NAME_TYPE_IDINDI)) {
			sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ")
					.append(nameColumn).append(" like '%").append(name).append("'");
			// sql = "select count(" + nameColumn + ") from " + tableName +
			// " where " + nameColumn + " like '%" + name
			// + "'";
		} else if (tableName.equals(MpmCONST.MPM_TARGETUSER_FILE)) {
			// 先检查数据源表中是否有重名的存在
			sql.append("select count(source_cname) from MTL_CAMP_DATA_SOURCE where source_cname='").append(name)
					.append("'");
			// sql =
			// "select count(source_cname) from MTL_CAMP_DATA_SOURCE where source_cname='"
			// + name + "'";
			log.debug(">>isNameExist(): " + sql);
			int cnt = this.getJdbcTemplate().queryForInt(sql.toString());
			if (cnt > 0) {
				return true;
			}
			sql.delete(0, sql.length());
			// 再检查用户上载目标客户表中是否有重名的存�?
			sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ")
					.append(nameColumn).append("='").append(name).append("'");
			// sql = "select count(" + nameColumn + ") from " + tableName +
			// " where " + nameColumn + "='" + name + "'";
		} else {
			sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ")
					.append(nameColumn).append("='").append(name).append("'");
			// sql = "select count(" + nameColumn + ") from " + tableName +
			// " where " + nameColumn + "='" + name + "'";
		}
		if (id != null && id.length() > 0 && idColumn != null && idColumn.length() > 0) {
			if (tableName.equalsIgnoreCase("AP_APPROVE_DRV_TYPE") || tableName.equalsIgnoreCase("EVENT_TAG_DEFINE")) {
				sql.append(" and ").append(idColumn).append("<>").append(id);
				// sql += " and " + idColumn + "<>" + id;
			} else {
				sql.append(" and ").append(idColumn).append("<>'").append(id).append("'");
				// sql += " and " + idColumn + "<>'" + id + "'";
			}
		}
		log.debug(">>isNameExist(): " + sql);
		int cnt = this.getJdbcTemplate().queryForInt(sql.toString());
		if (cnt < 1) {
			res = false;
		}
		return res;
	}

	@Override
	public boolean isNameExistForInt(String name, String id, String idColumn, String nameColumn, String tableName)
			throws Exception {
		boolean res = true;
		StringBuffer sql = new StringBuffer();
		sql.append("select count(").append(nameColumn).append(") from ").append(tableName).append(" where ")
				.append(nameColumn).append("=").append(name).append("");
		// String sql = "select count(" + nameColumn + ") from " + tableName +
		// " where " + nameColumn + "=" + name + "";
		if (id != null && id.length() > 0 && idColumn != null && idColumn.length() > 0) {
			// sql += " and " + idColumn + "<>" + id + "";
			sql.append(" and ").append(idColumn).append("<>").append(id).append("");
		}
		log.debug(">>isNameExist(): " + sql);
		int cnt = this.getJdbcTemplate().queryForInt(sql.toString());
		if (cnt < 1) {
			res = false;
		}
		return res;
	}

	@Override
	public int isDimColumnExists(String columnName, String sourceName) {
		int res = 0;
		try {
			String sql = " select * from " + sourceName + " where 1=2";
			log.debug(">>isDimColumnExists(): " + sql);
			this.getJdbcTemplate().execute(sql);
		} catch (Exception e) {
			res = 1;
			return res;
		}

		try {
			String sql = " select count(" + columnName + ") from " + sourceName + " where 1=2";
			log.debug(">>isDimColumnExists(): " + sql);
			int cnt = this.getJdbcTemplate().queryForInt(sql);
		} catch (Exception e) {
			res = 2;
			return res;
		}
		return res;
	}

	@Override
	public String getUserDeptPolicyCache(String userId, int deptId) throws Exception {
		String res = "";
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(new ConnectionEx());
			// 只支�?级部门或分公�?
			StringBuffer sql = new StringBuffer();
			sql.append("select a.userId from user_user a,(select deptId from user_company where deptId=")
					.append(deptId).append(" or parentId=").append(deptId).append(") b where a.departmentId=b.deptId");
			// String sql =
			// "select a.userId from user_user a,(select deptId from user_company where deptId="
			// + deptId
			// + " or parentId=" + deptId + ") b where a.departmentId=b.deptId";
			log.debug(">>getUserDeptPolicyCache(): \n" + sql);
			sqlca.execute(sql.toString());
			while (sqlca.next()) {
				res += "'" + sqlca.getString("userId") + "',";
			}
			if (res.length() > 0) {
				res = res.substring(0, res.length() - 1);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
		return res;
	}

	/**
	 * @deprecated added by wwl 2006-11-3
	 */
	@Override
	@Deprecated
	public void deleteCampsegUserProcessResult(String campsegId) throws Exception {
		Sqlca sqlca = null;
		try {
			// sqlca = new Sqlca(this.getConnection());

			// //删除短信、彩信回复设计表
			// String sql =
			// "delete from MTL_sms_mms_code_def where campseg_id='" + campsegId
			// + "'";
			// log.debug(">>deleteCampsegUserProcessResult() 1." + sql);
			// sqlca.execute(sql);
			//
			// //删除执行客户筛选进度表
			// sql = "delete from mtl_userfilter_process where campseg_id='" +
			// campsegId + "'";
			// log.debug(">>deleteCampsegUserProcessResult() 2." + sql);
			// sqlca.execute(sql);
			//
			// //删除�?
			// sql = "delete from mtl_channel_cost where campseg_id='" +
			// campsegId + "'";
			// log.debug(">>deleteCampsegUserProcessResult() 3." + sql);
			// sqlca.execute(sql);
			//
			// //删除�?
			// sql = "delete from mtl_resource_cost_plan where campseg_id='" +
			// campsegId + "'";
			// log.debug(">>deleteCampsegUserProcessResult() 4." + sql);
			// sqlca.execute(sql);
			//
			// //删除客户营销渠道设计
			// sql = "delete from MTL_userseg_channel_plan where campseg_id='" +
			// campsegId + "'";
			// log.debug(">>deleteCampsegUserProcessResult() 5." + sql);
			// sqlca.execute(sql);
			//
			// //删除细分执行结果
			// sql = "delete from MTL_subsection_result where campseg_id='" +
			// campsegId + "'";
			// log.debug(">>deleteCampsegUserProcessResult() 6." + sql);
			// sqlca.execute(sql);
			//
			// //删除活动波次筛选出来的用户
			// try {
			// sql = "drop table mtl_duser_" + campsegId;
			// log.debug(">>deleteCampsegUserProcessResult() 3." + sql);
			// sqlca.execute(sql);
			// } catch (Exception e) {
			// //用户表有可能不存在，错误暂不做处�?
			// log.error("",e);
			// }
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	@Override
	public List getCampsegCostListByResType(String resType, String campsegId) throws Exception {
		List list = new ArrayList();

		StringBuffer sqlSb = new StringBuffer();
		String linkTable = "";
		// 渠道接触成本、渠道馈赠实物成本从mtl_channel_cost关联
		if (resType.equals(MpmCONST.RESTYPE_ENTITY) || resType.equals(MpmCONST.RESTYPE_CHANNEL)) {
			linkTable = "mtl_channel_cost";
		}
		// 宣传媒体成本、宣传实物成本从MTL_publicize_reslist关联
		else if (resType.equals(MpmCONST.RESTYPE_MEDIA) || resType.equals(MpmCONST.RESTYPE_FLACK)) {
			linkTable = "MTL_publicize_reslist";
		}
		// 资费优惠从mtl_plan_cost关联
		else if (resType.equals(MpmCONST.RESTYPE_FAVORATE)) {
			linkTable = "(select a.campseg_id,b.cost_no from mtl_camp_segInfo a,mtl_plan_cost b where a.camp_id=b.camp_id and a.campseg_id='"
					+ campsegId + "')";
		}

		if (!resType.equals(MpmCONST.RESTYPE_MEDIA) && !resType.equals(MpmCONST.RESTYPE_FLACK)) {
			sqlSb.append("select t3.res_name,t3.res_type,t2.res_nums,t2.res_price,t2.res_cost \n")
					.append(" from " + linkTable + " t1,MTL_resource_cost_plan t2,MTL_res_list t3 \n")
					.append(" where t1.campseg_id='" + campsegId + "' and t2.cost_no=t1.cost_no \n")
					.append(" and t2.res_code=t3.res_code and t3.res_type=" + resType);
		} else {
			sqlSb.append("select t3.res_name,t3.res_type,t2.res_nums,t2.res_price,t2.res_cost \n")
					.append(" from " + linkTable
							+ " t1,MTL_resource_cost_plan t2,MTL_res_list t3,mtl_publicize_plan t5 \n")
					.append(" where 1=1 ")
					.append(" and t5.publicize_comb_id=t4.proform_result and t1.publicize_id = t5.publicize_id ")
					.append(" and t2.cost_no=t1.cost_no \n")
					.append(" and t2.res_code=t3.res_code and t3.res_type=" + resType);
		}

		list = (List) this.getJdbcTemplate().query(sqlSb.toString(), new RowMapperResultSetExtractor(new RowMapper() {
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				String tmpArr[] = new String[5];
				tmpArr[0] = rs.getString("res_name");
				tmpArr[1] = rs.getString("res_type");
				tmpArr[2] = rs.getString("res_nums");
				tmpArr[3] = rs.getString("res_price");
				tmpArr[4] = rs.getString("res_cost");
				return tmpArr;
			}
		}, 0));

		return list;
	}

	@Override
	public String getFirstExistTable(String[] userbaseTables) throws Exception {
		String res = "";
		String strType = MpmUtil.getDBType();
		Sqlca sqlca = new Sqlca(new ConnectionEx());
		sqlca.setDBMSType(strType);
		String strSql = "";
		String tableName;
		int len = userbaseTables.length;
		for (int i = 0; i < len; i++) {
			tableName = userbaseTables[i];
			strSql = sqlca.getCheckTableIsExistSql(tableName);
			// List result = this.getJdbcTemplate().queryForList(strSql);
			// if (result != null && result.size() > 0) {
			// res = tableName;
			// break;
			// }
			// modified by zhoulb
			try {
				StringBuffer sqlBuffer = new StringBuffer();
				sqlBuffer.append("select count(*) from ").append(tableName).append(" where 1=2");
				this.getJdbcTemplate().execute(sqlBuffer.toString());
				// this.getJdbcTemplate().execute("select count(*) from " +
				// tableName + " where 1=2");
				res = tableName;
				break;
			} catch (Exception e) {
			} finally {
				if (sqlca != null) {
					sqlca.closeAll();
				}
			}
		}
		return res;
	}

	@Override
	public List getExistTables(String[] userbaseTables) throws Exception {
		List list = new ArrayList();
		String tableName;
		for (int i = 0; i < userbaseTables.length; i++) {
			tableName = userbaseTables[i];
			try {
				StringBuffer sqlBuffer = new StringBuffer();
				sqlBuffer.append("select * from ").append(tableName).append(" where 1=2");
				this.getJdbcTemplate().execute(sqlBuffer.toString());
				// this.getJdbcTemplate().execute("select * from " + tableName +
				// " where 1=2");
				list.add(tableName);
			} catch (Exception e) {
				// 不需要处理此错误
			}
		}
		return list;
	}

	@Override
	public String getCompanyTreeHtml() throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(new ConnectionEx());
			String strPageFormat = "<font style='cursor:hand' onClick='onSelecCompany(this)' MYID='[ID]' MYNAME='[S]'>[S]</font></a>";
			return MpmHtmlHelper.getCompanyTree(sqlca, strPageFormat, strPageFormat, false, true);
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
	}

	/*
	 * （非 Javadoc�?
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao#updatePublicizeComb(java
	 * .lang.String, java.lang.String)
	 */
	@Override
	public void updatePublicizeComb(String campsegId, String publicizeCombId) throws Exception {
		// TODO 自动生成方法存根
		Sqlca sqlca = null;
		Sqlca sqlca1 = null;
		try {
			sqlca = new Sqlca(this.getConnection());
			sqlca1 = new Sqlca(this.getConnection());
			StringBuffer sqlBuffer = new StringBuffer();
			sqlBuffer.append("update mtl_camp_seginfo set publicize_comb_id='").append(publicizeCombId)
					.append("' where campseg_id='").append(campsegId).append("'");
			// sqlca.execute("update mtl_camp_seginfo set publicize_comb_id='" +
			// publicizeCombId + "' where campseg_id='"
			// + campsegId + "'");
			sqlca.execute(sqlBuffer.toString());
			sqlBuffer.delete(0, sqlBuffer.length());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca1 != null) {
				sqlca1.close();
			}
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	/*
	 * （非 Javadoc�?
	 * 
	 * @see com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao#
	 * getApproveFlowidByChannelTypeAndId(java.lang.String, java.lang.String)
	 */
	@Override
	public String getApproveFlowidByChannelTypeAndId(String type, String cid) throws MpmException {
		// TODO 自动生成方法存根
		String res = "";
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(this.getConnection());
			StringBuffer sql = new StringBuffer();
			sql.append("select approve_flow_id from ap_approve_flow_def where channeltype_id=").append(type)
					.append(" and channel_id='").append(cid).append("'");
			// String sql =
			// "select approve_flow_id from ap_approve_flow_def where channeltype_id="
			// + type
			// + " and channel_id='" + cid + "'";
			sqlca.execute(sql.toString());
			while (sqlca.next()) {
				res = sqlca.getString("approve_flow_id");
			}
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
		return res;
	}

	/*
	 * （
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao#getApproveFlowid(java.lang
	 * .String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public String getApproveFlowid(String userid, String campDrvId, String channeltypeId, String channelId,
			String approveType) throws MpmException {
		String res = "";
		Sqlca sqlca = null;
		try {
			IUser user = getMpmUserPrivilegeService().getUser(userid);
			sqlca = new Sqlca(this.getConnection());
			sqlca.setAutoCommit(false);
			// String sql = "";
			StringBuffer sql = new StringBuffer();
			if (approveType.equals("1")) {// 营销案的默认审批流程
				sql.append("select approve_flow_id from ap_dept_flow_relation where city_id in('")
						.append(user.getCityid()).append("','-1') and dept_id in('").append(user.getDepartmentid())
						.append("','-1') and approve_type=1 order by city_id,dept_id desc");
				// sql =
				// "select approve_flow_id from ap_dept_flow_relation where city_id in('"
				// + user.getCityid()
				// + "','-1') and dept_id in('" + user.getDepartmentid()
				// + "','-1') and approve_type=1 order by city_id,dept_id desc";
				sqlca.execute(sql.toString());
				sql.delete(0, sql.length());
				while (sqlca.next()) {
					res = sqlca.getString("approve_flow_id");
				}
				if (StringUtil.isEmpty(res)) {
					sql.append("select approve_flow_id from ap_approve_flow_def where approve_flow_name='default1'");
					// sql =
					// "select approve_flow_id from ap_approve_flow_def where approve_flow_name='default1'";
					sqlca.execute(sql.toString());
					sql.delete(0, sql.length());
					while (sqlca.next()) {
						res = sqlca.getString("approve_flow_id");
					}
				}
				log.debug("营销案的审批流程sql:" + sql);
			} else if (approveType.equals("2")) {// 营销活动的默认审批流�?
				String how_to_show_data = MpmConfigure.getInstance().getProperty("HOW_TO_SHOW_DATA");
				if ("0".equals(how_to_show_data)) {
					sql.append(
							"select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id,dept_id from ap_dept_flow_relation where city_id='")
							.append(user.getCityid()).append("' and  approve_type=2");
					// sql =
					// "select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id,dept_id from ap_dept_flow_relation where city_id='"
					// + user.getCityid() + "' and  approve_type=2";
				} else {
					sql.append(
							"select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id ,dept_id  from ap_dept_flow_relation where city_id='")
							.append(user.getCityid()).append("' and dept_id='").append(user.getDepartmentid())
							.append("' and approve_type=2");
					// sql =
					// "select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id ,dept_id  from ap_dept_flow_relation where city_id='"
					// + user.getCityid() + "' and dept_id='" +
					// user.getDepartmentid() + "' and approve_type=2";
				}
				sqlca.execute(sql.toString());
				sql.delete(0, sql.length());
				Map<String, String> deptFlow = new HashMap<String, String>();
				log.debug("营销活动的审批流程sql:" + sql);
				while (sqlca.next()) {
					String campdid = sqlca.getInt("camp_drv_id") + "";
					String channeltid = sqlca.getInt("channeltype_id") + "";
					String channelid = sqlca.getInt("channel_id") + "";
					String retype = sqlca.getInt("relation_type") + "";
					String approvefid = sqlca.getString("approve_flow_id");
					String deptId = sqlca.getString("dept_id");
					if (retype.equals("1") && campdid.equals(campDrvId)) {// 1---只使用camp_drv_id
						deptFlow.put(deptId, approvefid);
					}
					if (retype.equals("2")
							&& ((channeltid.equals(channeltypeId) && channelid.equals(channelId)) || (channeltid
									.equals(channeltypeId) && channelid.equals("-1")))) {// 2---只使用channeltype_id
						res = approvefid;
						break;
					}
					if (retype.equals("3") && channeltid.equals(channeltypeId)
							&& (channelid.equals(channelId) || channelid.equals("-1")) && campdid.equals(campDrvId)) {// 3---camp_drv_id,channeltype_id都使�?
						res = approvefid;
						break;
					}
					if (retype.equals("4")) {// 4---camp_drv_id,channeltype_id都不使用
						res = approvefid;
						break;
					}
				}
				if (StringUtil.isEmpty(res)) {// 仅按活动类型获取配置流程,则按部门优先获取流程
					res = StringUtil.isEmpty(deptFlow.get(String.valueOf(user.getDepartmentid()))) ? deptFlow.get("-1")
							: deptFlow.get(String.valueOf(user.getDepartmentid()));
				}

				// 取系统默认流程
				if (StringUtil.isEmpty(res)) {
					sql.append("select approve_flow_id from ap_approve_flow_def where approve_flow_name='default2'");
					// sql =
					// "select approve_flow_id from ap_approve_flow_def where approve_flow_name='default2'";
					sqlca.execute(sql.toString());
					while (sqlca.next()) {
						res = sqlca.getString("approve_flow_id");
					}
				}
			}
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
		log.debug("获取到流程id:" + res);
		return res;
	}

	public String getApproveFlowid(String userid, String campDrvId, String approveType) throws MpmException {
		String res = "";
		Sqlca sqlca = null;
		try {
			IUser user = getMpmUserPrivilegeService().getUser(userid);
			sqlca = new Sqlca(this.getConnection());
			sqlca.setAutoCommit(false);
			// String sql = "";
			StringBuffer sql = new StringBuffer();
			if (approveType.equals("1")) {// 营销案的默认审批流程
				sql.append("select approve_flow_id from ap_dept_flow_relation where city_id in('")
						.append(user.getCityid()).append("','-1') and dept_id in('").append(user.getDepartmentid())
						.append("','-1') and approve_type=1 order by city_id,dept_id desc");
				// sql =
				// "select approve_flow_id from ap_dept_flow_relation where city_id in('"
				// + user.getCityid()
				// + "','-1') and dept_id in('" + user.getDepartmentid()
				// + "','-1') and approve_type=1 order by city_id,dept_id desc";
				sqlca.execute(sql.toString());
				sql.delete(0, sql.length());
				while (sqlca.next()) {
					res = sqlca.getString("approve_flow_id");
				}
				if (StringUtil.isEmpty(res.trim())) {
					sql.append("select approve_flow_id from ap_approve_flow_def where approve_flow_name='default1'");
					// sql =
					// "select approve_flow_id from ap_approve_flow_def where approve_flow_name='default1'";
					sqlca.execute(sql.toString());
					sql.delete(0, sql.length());
					while (sqlca.next()) {
						res = sqlca.getString("approve_flow_id");
					}
				}
				log.debug("营销案的审批流程sql:" + sql);
			} else if (approveType.equals("2")) {// 营销活动的默认审批流�?
				String how_to_show_data = MpmConfigure.getInstance().getProperty("HOW_TO_SHOW_DATA");
				if ("0".equals(how_to_show_data)) {

					sql.append(
							"select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id,dept_id from ap_dept_flow_relation where city_id='")
							.append(user.getCityid()).append("'  and approve_type=2");
					// sql =
					// "select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id,dept_id from ap_dept_flow_relation where city_id='"
					// + user.getCityid() + "'  and approve_type=2";
				} else {
					sql.append(
							"select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id ,dept_id from ap_dept_flow_relation where city_id='")
							.append(user.getCityid()).append("' and dept_id='").append(user.getDepartmentid())
							.append("' and approve_type=2");
					// sql =
					// "select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id ,dept_id from ap_dept_flow_relation where city_id='"
					// + user.getCityid() + "' and dept_id='" +
					// user.getDepartmentid() + "' and approve_type=2";
				}
				log.debug("营销活动审批流程：sql:" + sql + " 用户地市：" + user.getCityid() + "部门:" + user.getDepartmentid());
				sqlca.execute(sql.toString());
				sql.delete(0, sql.length());
				Map<String, String> deptFlow = new HashMap<String, String>();
				while (sqlca.next()) {
					String campdid = sqlca.getInt("camp_drv_id") + "";
					String retype = sqlca.getInt("relation_type") + "";
					String approvefid = sqlca.getString("approve_flow_id");
					String deptId = sqlca.getString("dept_id");
					if (retype.equals("1") && campdid.equals(campDrvId)) {// 1---只使用camp_drv_id
						deptFlow.put(deptId, approvefid);
					}
					if (retype.equals("2")) {// 2---只使用channeltype_id
						res = approvefid;
						break;
					}
					if (retype.equals("3")) {// 3---camp_drv_id,channeltype_id都使�?
						res = approvefid;
						break;
					}
					if (retype.equals("4")) {// 4---camp_drv_id,channeltype_id都不使用
						res = approvefid;
						break;
					}
				}
				if (StringUtil.isEmpty(res)) {// 仅按活动类型获取配置流程,则按部门优先获取流程
					res = StringUtil.isEmpty(deptFlow.get(String.valueOf(user.getDepartmentid()))) ? deptFlow.get("-1")
							: deptFlow.get(String.valueOf(user.getDepartmentid()));
				}

				// 根据地市+部门找不到 审批流程时，再根据部门找一次，看是否能找到
				if (StringUtil.isEmpty(res)) {
					String sqlTemp = "select camp_drv_id,channeltype_id,channel_id,relation_type,approve_flow_id from ap_dept_flow_relation where dept_id=? and approve_type=2";
					sqlca.execute(sqlTemp, new Object[] { String.valueOf(user.getDepartmentid()) });
					while (sqlca.next()) {
						res = sqlca.getString("approve_flow_id");
					}
				}

				// 取系统默认流程
				if (StringUtil.isEmpty(res)) {
					sqlca.execute("select approve_flow_id from ap_approve_flow_def where approve_flow_name='default2'");
					while (sqlca.next()) {
						res = sqlca.getString("approve_flow_id");
					}
				}
			}
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
		log.debug("获取到流程id:" + res);
		return res;
	}

	public String getApproveFlowid(String userid, String approveType) throws MpmException {
		String res = "";
		Sqlca sqlca = null;
		try {
			IUser user = getMpmUserPrivilegeService().getUser(userid);
			sqlca = new Sqlca(this.getConnection());
			sqlca.setAutoCommit(false);
			// String sql = "";
			StringBuffer sql = new StringBuffer();
			if (approveType.equals("1")) {// 营销案的默认审批流程
				sql.append("select approve_flow_id from ap_approve_flow_def where FIRST_APPROVE_USER='").append(userid)
						.append("'");
				// sql =
				// "select approve_flow_id from ap_approve_flow_def where FIRST_APPROVE_USER='"
				// + userid + "'";
				sqlca.execute(sql.toString());
				while (sqlca.next()) {
					res = sqlca.getString("APPROVE_FLOW_ID");
				}
				log.debug("营销案的审批流程sql:" + sql);
			} else if (approveType.equals("2")) {// 营销活动的默认审批流

				sql.append("select APPROVE_FLOW_ID from ap_approve_flow_def where FIRST_APPROVE_USER = '")
						.append(userid).append("'");
				// sql =
				// "select APPROVE_FLOW_ID from ap_approve_flow_def where FIRST_APPROVE_USER = '"
				// + userid + "'";
				sqlca.execute(sql.toString());
				while (sqlca.next()) {
					res = sqlca.getString("APPROVE_FLOW_ID");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (sqlca != null)
				sqlca.closeAll();
		}
		log.debug("获取到流程id:" + res);
		return res;
	}

	/*
	 * （非 Javadoc�?
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao#LoadBotherAvoidFile(com.
	 * asiainfo.biapp.mcd.form.MtlBotherAvoidForm)
	 */

	/*
	 * （非 Javadoc�?
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao#excludeBlackList(java.lang
	 * .String, java.lang.String)
	 */
	@Override
	public String excludeBlackList(String srcTable, String avoidCustTypes) {
		// TODO 自动生成方法存根
		String cnum = "0";
		try {
			if (avoidCustTypes != null && avoidCustTypes.length() > 0) {
				String blackList = "MTL_BOTHER_AVOID";
				StringBuffer sql = new StringBuffer();
				sql.append("delete from ").append(srcTable).append(" where product_no in(")
						.append(" select product_no from ").append(blackList).append(" where AVOID_CUST_TYPE in (")
						.append(avoidCustTypes).append(")").append(")");
				logger.info(MpmLocaleUtil.getMessage("mcd.java.tcmdr") + sql);
				getJdbcTemplate().execute(sql.toString());
			}
			StringBuffer sqlBuffer = new StringBuffer();
			sqlBuffer.append("select count(product_no) from ").append(srcTable);
			// cnum =
			// this.getJdbcTemplate().queryForInt("select count(product_no) from "
			// + srcTable) + "";
			cnum = this.getJdbcTemplate().queryForInt(sqlBuffer.toString()) + "";
		} catch (Exception ex) {
			log.error("", ex);
		} finally {
			return cnum;
		}

	}

	public IUserPrivilegeCommonService getMpmUserPrivilegeService() {
		if (mpmUserPrivilegeService == null) {
			try {
				mpmUserPrivilegeService = (IUserPrivilegeCommonService) SystemServiceLocator.getInstance().getService(
						MpmCONST.MPM_USER_PRIVILEGE_SERVICE);
			} catch (Exception e) {
				log.error("", e);
			}
		}
		return mpmUserPrivilegeService;
	}

	public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
		this.mpmUserPrivilegeService = mpmUserPrivilegeService;
	}

	/**
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<LabelValueBean> getBsMmsContent() throws Exception {

		List<LabelValueBean> list = new ArrayList();
		String sql = "select id,name from BS_MMS_CONTENT order by create_date desc";
		// list = this.getJdbcTemplate().queryForList(sql);
		list = (List<LabelValueBean>) this.getJdbcTemplate().query(sql,
				new RowMapperResultSetExtractor(new RowMapper() {
					@Override
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
						return new LabelValueBean(rs.getString("name"), rs.getString("id"));
					}
				}, 0));

		return list;
	}
}
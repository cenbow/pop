/*    */ package com.ai.bdx.frame.approval.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IMpmCostListDao;
/*    */ import com.ai.bdx.frame.approval.model.MtlCostList;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class MpmCostListDaoImpl extends HibernateDaoSupport
/*    */   implements IMpmCostListDao
/*    */ {
/* 16 */   private static Logger log = LogManager.getLogger();
/*    */ 
/*    */   public List findAll()
/*    */     throws Exception
/*    */   {
/* 25 */     List list = new ArrayList();
/*    */     try {
/* 27 */       String sql = "from MtlCostList as a order by a.costCode";
/* 28 */       list = getHibernateTemplate().find(sql);
/*    */     } catch (DataAccessException e) {
/* 30 */       log.error("", e);
/*    */     }
/* 32 */     return list;
/*    */   }
/*    */ 
/*    */   public MtlCostList findByCode(String costCode) throws Exception {
/* 36 */     MtlCostList result = new MtlCostList();
/*    */     try {
/* 38 */       String sql = "from MtlCostList as a where a.costCode=" + costCode + "";
/*    */ 
/* 40 */       List list = getHibernateTemplate().find(sql);
/* 41 */       if ((list != null) && (list.size() > 0))
/* 42 */         result = (MtlCostList)list.get(0);
/*    */     }
/*    */     catch (DataAccessException e) {
/* 45 */       log.error("", e);
/*    */     }
/* 47 */     return result;
/*    */   }
/*    */ 
/*    */   public void delete(String resCode)
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 58 */       String sql = "from MtlCostList as a where a.costCode=" + resCode + "";
/*    */ 
/* 60 */       getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*    */     }
/*    */     catch (DataAccessException e) {
/* 63 */       log.error("", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public MtlCostList save(MtlCostList mtlCostList)
/*    */     throws Exception
/*    */   {
/* 76 */     MtlCostList result = new MtlCostList();
/*    */     try {
/* 78 */       getHibernateTemplate().save(mtlCostList);
/* 79 */       result = mtlCostList;
/*    */     } catch (DataAccessException e) {
/* 81 */       log.error("", e);
/*    */     }
/* 83 */     return result;
/*    */   }
/*    */ 
/*    */   public void update(MtlCostList mtlCostList)
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 94 */       getHibernateTemplate().update(mtlCostList);
/*    */     } catch (DataAccessException e) {
/* 96 */       log.error("", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MpmCostListDaoImpl
 * JD-Core Version:    0.6.2
 */
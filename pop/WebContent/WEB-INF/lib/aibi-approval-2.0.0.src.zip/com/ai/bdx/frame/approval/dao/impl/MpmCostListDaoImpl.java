package com.ai.bdx.frame.approval.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMpmCostListDao;
import com.ai.bdx.frame.approval.model.MtlCostList;

public class MpmCostListDaoImpl extends HibernateDaoSupport implements
		IMpmCostListDao {
	private static Logger log = LogManager.getLogger();

	/**
	 * 返回所有的记录
	 * 
	 * @return
	 * @throws Exception
	 */
	public List findAll() throws Exception {
		List list = new ArrayList();
		try {
			String sql = "from MtlCostList as a order by a.costCode";
			list = this.getHibernateTemplate().find(sql);
		} catch (DataAccessException e) {
			log.error("", e);
		}
		return list;
	}

	public MtlCostList findByCode(String costCode) throws Exception {
		MtlCostList result = new MtlCostList();
		try {
			String sql = "from MtlCostList as a where a.costCode=" + costCode
					+ "";
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				result = (MtlCostList) list.get(0);
			}
		} catch (DataAccessException e) {
			log.error("", e);
		}
		return result;
	}

	/**
	 * 删除一条记录
	 * 
	 * @param resCode
	 * @throws Exception
	 */
	public void delete(String resCode) throws Exception {
		try {
			String sql = "from MtlCostList as a where a.costCode=" + resCode
					+ "";
			this.getHibernateTemplate().deleteAll(
					this.getHibernateTemplate().find(sql));
		} catch (DataAccessException e) {
			log.error("", e);
		}
		return;
	}

	/**
	 * 插入一条记录
	 * 
	 * @param mtlCostList
	 * @return
	 * @throws Exception
	 */
	public MtlCostList save(MtlCostList mtlCostList) throws Exception {
		MtlCostList result = new MtlCostList();
		try {
			this.getHibernateTemplate().save(mtlCostList);
			result = mtlCostList;
		} catch (DataAccessException e) {
			log.error("", e);
		}
		return result;
	}

	/**
	 * 修改一条记录
	 * 
	 * @param mtlCostList
	 * @throws Exception
	 */
	public void update(MtlCostList mtlCostList) throws Exception {
		try {
			this.getHibernateTemplate().update(mtlCostList);
		} catch (DataAccessException e) {
			log.error("", e);
		}
		return;
	}

}

/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveRelation;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveRelationKey;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumnId;
/*     */ import com.ai.bdx.frame.approval.model.MtlCostList;
/*     */ import com.ai.bdx.frame.approval.model.MtlDataExportItem;
/*     */ import com.ai.bdx.frame.approval.model.MtlDataExportItemKey;
/*     */ import com.ai.bdx.frame.approval.model.MtlResList;
/*     */ import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlTempletActiveField;
/*     */ import com.ai.bdx.frame.approval.model.MtlTempletActiveFieldId;
/*     */ import com.ai.bdx.frame.approval.util.MpmUtil;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.RowMapperResultSetExtractor;
/*     */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*     */ 
/*     */ public class MpmForPageDaoImpl extends JdbcDaoSupport
/*     */   implements IMpmForPageDao
/*     */ {
/*  43 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public boolean isExists(String tablename)
/*     */   {
/*  47 */     Sqlca sqlca = null;
/*  48 */     boolean result = false;
/*     */     try {
/*  50 */       sqlca = new Sqlca(getConnection());
/*  51 */       StringBuffer sqlBuffer = new StringBuffer();
/*  52 */       sqlBuffer.append("select count(*) from ").append(tablename).append(" where 1=2");
/*     */ 
/*  54 */       sqlca.execute(sqlBuffer.toString());
/*  55 */       result = true;
/*     */     } catch (Exception e) {
/*     */     } finally {
/*  58 */       if (sqlca != null) {
/*  59 */         sqlca.close();
/*     */       }
/*     */     }
/*  62 */     return result;
/*     */   }
/*     */ 
/*     */   public Map findActTempletById(String activeTempletId, Integer curPage, Integer pageSize)
/*     */   {
/*  69 */     HashMap map = new HashMap();
/*     */     try {
/*  71 */       Integer total = Integer.valueOf(0);
/*  72 */       String column = " column_name,source_name,column_type,column_cname,active_templet_id,";
/*  73 */       String condition = "";
/*  74 */       String sql = " select * from mtl_templet_active_field where 1=1 ";
/*  75 */       if ((activeTempletId != null) && (!"".equals(activeTempletId))) {
/*  76 */         sql = sql + " and active_templet_id='" + activeTempletId + "'";
/*  77 */         condition = condition + " and active_templet_id='" + activeTempletId + "'";
/*     */       }
/*     */ 
/*  80 */       String sqlPaged = MpmUtil.getPagedSql(sql, column, "column_name", curPage.intValue(), pageSize.intValue());
/*     */ 
/*  83 */       List list = (List)getJdbcTemplate().query(sqlPaged, new RowMapperResultSetExtractor(new RowMapper()
/*     */       {
/*     */         public Object mapRow(ResultSet rs, int rowNum)
/*     */           throws SQLException
/*     */         {
/*  88 */           return MpmForPageDaoImpl.this.getActiveTempletColumn(rs);
/*     */         }
/*     */       }
/*     */       , 0));
/*     */ 
/*  91 */       sql = MpmUtil.getCountTotalSql("mtl_templet_active_field", "column_name", " 1=1" + condition, null);
/*     */ 
/*  93 */       total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
/*     */ 
/*  95 */       map.put("total", total);
/*  96 */       map.put("result", list);
/*     */     } catch (Exception de) {
/*  98 */       log.error("", de);
/*     */     }
/* 100 */     return map;
/*     */   }
/*     */ 
/*     */   private MtlTempletActiveField getActiveTempletColumn(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/* 113 */     MtlTempletActiveField svc = new MtlTempletActiveField();
/* 114 */     String tmpStr = rs.getString("column_name");
/* 115 */     if (tmpStr == null) {
/* 116 */       return null;
/*     */     }
/* 118 */     svc.getId().setColumnName(tmpStr);
/* 119 */     svc.getId().setSourceName(rs.getString("source_name"));
/* 120 */     svc.getId().setColumnType(Short.valueOf(rs.getString("column_type")));
/* 121 */     svc.setColumnCname(rs.getString("column_cname"));
/* 122 */     svc.getId().setActiveTempletId(rs.getString("active_templet_id"));
/* 123 */     return svc;
/*     */   }
/*     */ 
/*     */   public Map findDataExportItem(String campDrvId, String sourceName, String columnName, Integer curPage, Integer pageSize)
/*     */   {
/* 135 */     HashMap map = new HashMap();
/*     */     try {
/* 137 */       Integer total = Integer.valueOf(0);
/* 138 */       String column = " camp_drv_id,column_name,column_cname,source_name,column_type,column_dest,dimcolumn_desc_flag,";
/* 139 */       String condition = "";
/* 140 */       String sql = " select * from mtl_data_export_item where 1=1 ";
/* 141 */       if ((campDrvId != null) && (!"".equals(campDrvId))) {
/* 142 */         condition = condition + " and camp_drv_id=" + campDrvId;
/*     */       }
/* 144 */       if ((sourceName != null) && (!"".equals(sourceName))) {
/* 145 */         condition = condition + " and camp_drv_id=" + campDrvId;
/*     */       }
/* 147 */       if ((columnName != null) && (!"".equals(columnName))) {
/* 148 */         condition = condition + " and camp_drv_id=" + campDrvId;
/*     */       }
/* 150 */       sql = sql + condition + " order by camp_drv_id";
/* 151 */       String sqlPaged = MpmUtil.getPagedSql(sql, column, "camp_drv_id", curPage.intValue(), pageSize.intValue());
/*     */ 
/* 154 */       List list = (List)getJdbcTemplate().query(sqlPaged, new RowMapperResultSetExtractor(new RowMapper()
/*     */       {
/*     */         public Object mapRow(ResultSet rs, int rowNum)
/*     */           throws SQLException
/*     */         {
/* 159 */           return MpmForPageDaoImpl.this.getDataExportItem(rs);
/*     */         }
/*     */       }
/*     */       , 0));
/*     */ 
/* 163 */       sql = MpmUtil.getCountTotalSql("mtl_data_export_item", "camp_drv_id", " 1=1" + condition, null);
/*     */ 
/* 166 */       total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
/*     */ 
/* 168 */       map.put("total", total);
/* 169 */       map.put("result", list);
/*     */     } catch (Exception de) {
/* 171 */       log.error("", de);
/*     */     }
/* 173 */     return map;
/*     */   }
/*     */ 
/*     */   private MtlDataExportItem getDataExportItem(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/* 185 */     MtlDataExportItem svc = new MtlDataExportItem();
/* 186 */     String tmpStr = rs.getString("camp_drv_id");
/* 187 */     if (tmpStr == null) {
/* 188 */       return null;
/*     */     }
/* 190 */     svc.getId().setCampDrvId(Short.valueOf(tmpStr));
/* 191 */     svc.getId().setColumnName(rs.getString("column_name"));
/* 192 */     svc.getId().setSourceName(rs.getString("source_name"));
/* 193 */     svc.setColumnType(Short.valueOf(rs.getString("column_type")));
/* 194 */     svc.setColumnDest(Integer.valueOf(rs.getString("column_dest")));
/* 195 */     svc.setDimcolumnDescFlag(Short.valueOf(rs.getString("dimcolumn_desc_flag")));
/*     */ 
/* 197 */     svc.setColumnCname(rs.getString("column_cname"));
/*     */ 
/* 199 */     return svc;
/*     */   }
/*     */ 
/*     */   public Map findDataSourceByTabname(String tabname, String columnName, String columnCname, Integer curPage, Integer pageSize)
/*     */     throws DataAccessException
/*     */   {
/* 209 */     HashMap map = new HashMap();
/*     */     try {
/* 211 */       Integer total = Integer.valueOf(0);
/* 212 */       String condition = "";
/* 213 */       String column = " column_name,column_cname,column_class,column_flag,source_name,column_datatype,column_desc,column_type,column_status,";
/* 214 */       String sql = " select * from mtl_camp_datasrc_column where 1=1 ";
/*     */ 
/* 216 */       if ((tabname != null) && (!"".equals(tabname))) {
/* 217 */         condition = condition + " and source_name='" + tabname + "'";
/*     */       }
/* 219 */       if ((columnName != null) && (!"".equals(columnName))) {
/* 220 */         condition = condition + " and column_name like '%" + columnName.trim() + "%' ";
/*     */       }
/*     */ 
/* 223 */       if ((columnCname != null) && (!"".equals(columnCname))) {
/* 224 */         condition = condition + " and column_cname like '%" + columnCname.trim() + "%' ";
/*     */       }
/*     */ 
/* 227 */       sql = sql + condition + " order by column_class";
/* 228 */       String sqlPaged = MpmUtil.getPagedSql(sql, column, "column_name", curPage.intValue(), pageSize.intValue());
/*     */ 
/* 232 */       this.logger.debug("\n" + sqlPaged);
/* 233 */       List list = (List)getJdbcTemplate().query(sqlPaged, new RowMapperResultSetExtractor(new RowMapper()
/*     */       {
/*     */         public Object mapRow(ResultSet rs, int rowNum)
/*     */           throws SQLException
/*     */         {
/* 238 */           return MpmForPageDaoImpl.this.getDataBaseResultSet(rs);
/*     */         }
/*     */       }
/*     */       , 0));
/*     */ 
/* 241 */       sql = MpmUtil.getCountTotalSql("mtl_camp_datasrc_column", "column_name", " 1=1 " + condition, null);
/*     */ 
/* 244 */       this.logger.debug("\n" + sql);
/*     */ 
/* 246 */       total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
/* 247 */       map.put("total", total);
/* 248 */       map.put("result", list);
/*     */     } catch (Exception de) {
/* 250 */       log.error("", de);
/*     */     }
/* 252 */     return map;
/*     */   }
/*     */ 
/*     */   private MtlCampDatasrcColumn getDataBaseResultSet(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/* 263 */     MtlCampDatasrcColumn svc = new MtlCampDatasrcColumn();
/* 264 */     MtlCampDatasrcColumnId child = new MtlCampDatasrcColumnId();
/* 265 */     String tmpStr = rs.getString("source_name");
/* 266 */     if (tmpStr == null) {
/* 267 */       return null;
/*     */     }
/* 269 */     child.setColumnName(rs.getString("column_name"));
/* 270 */     child.setColumnType(rs.getString("column_type"));
/* 271 */     child.setSourceName(tmpStr);
/* 272 */     svc.setId(child);
/* 273 */     svc.setColumnClass(rs.getString("column_class"));
/* 274 */     svc.setColumnCname(rs.getString("column_cname"));
/* 275 */     svc.setColumnDatatype(rs.getString("column_datatype"));
/* 276 */     svc.setColumnDesc(rs.getString("column_desc"));
/* 277 */     svc.setColumnFlag(rs.getString("column_flag"));
/* 278 */     svc.setColumnStatus(Short.valueOf(rs.getString("column_status")));
/* 279 */     return svc;
/*     */   }
/*     */ 
/*     */   public Map findActStepflowAll(MtlSysActflowDef svc, Integer curPage, Integer pageSize)
/*     */     throws DataAccessException
/*     */   {
/* 288 */     HashMap map = new HashMap();
/*     */     try {
/* 290 */       Integer total = Integer.valueOf(0);
/* 291 */       String column = " flow_id,flow_name,flow_desc,approve_flow_id,create_userid,create_time,warn_flag,status_chg_type,camp_type,";
/* 292 */       String sql = " select * from ap_sys_actflow_def where 1=1 ";
/* 293 */       String condition = "";
/* 294 */       if (svc.getFlowId() != null) {
/* 295 */         condition = condition + " and flow_id='" + svc.getFlowId() + "'";
/*     */       }
/*     */ 
/* 298 */       if (svc.getCreateUserid() != null) {
/* 299 */         condition = condition + " and create_userid='" + svc.getCreateUserid() + "'";
/*     */       }
/*     */ 
/* 307 */       if (svc.getStatusChgType() != null) {
/* 308 */         condition = condition + " and status_chg_type=" + svc.getStatusChgType();
/*     */       }
/*     */ 
/* 311 */       sql = sql + condition + " order by flow_name";
/* 312 */       String sqlPaged = MpmUtil.getPagedSql(sql, column, "flow_name", curPage.intValue(), pageSize.intValue());
/*     */ 
/* 314 */       List list = (List)getJdbcTemplate().query(sqlPaged, new RowMapperResultSetExtractor(new RowMapper()
/*     */       {
/*     */         public Object mapRow(ResultSet rs, int rowNum)
/*     */           throws SQLException
/*     */         {
/* 319 */           return MpmForPageDaoImpl.this.getActflowResultSet(rs);
/*     */         }
/*     */       }
/*     */       , 0));
/*     */ 
/* 322 */       sql = MpmUtil.getCountTotalSql("ap_sys_actflow_def", "flow_id", " 1=1" + condition, null);
/*     */ 
/* 324 */       total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
/* 325 */       map.put("total", total);
/* 326 */       map.put("result", list);
/*     */     } catch (Exception de) {
/* 328 */       log.error("", de);
/*     */     }
/* 330 */     return map;
/*     */   }
/*     */ 
/*     */   private MtlSysActflowDef getActflowResultSet(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/* 341 */     MtlSysActflowDef svc = new MtlSysActflowDef();
/* 342 */     String tmpStr = rs.getString("flow_id");
/* 343 */     if (tmpStr == null) {
/* 344 */       return null;
/*     */     }
/* 346 */     svc.setFlowId(tmpStr);
/* 347 */     svc.setFlowName(rs.getString("flow_name"));
/* 348 */     svc.setFlowDesc(rs.getString("flow_desc"));
/*     */ 
/* 351 */     svc.setCreateUserid(rs.getString("create_userid"));
/* 352 */     svc.setCreateTime(rs.getDate("create_time"));
/* 353 */     svc.setWarnFlag(Short.valueOf(rs.getString("warn_flag")));
/* 354 */     svc.setStatusChgType(Integer.valueOf(rs.getString("status_chg_type")));
/* 355 */     svc.setCampType(Short.valueOf(rs.getString("camp_type")));
/* 356 */     return svc;
/*     */   }
/*     */ 
/*     */   public Map findResAll(MtlResList svc, Integer curPage, Integer pageSize)
/*     */   {
/* 365 */     HashMap map = new HashMap();
/*     */     try {
/* 367 */       Integer total = Integer.valueOf(0);
/* 368 */       String column = " res_code,res_name,res_flag,res_type,res_price,cost_code,res_desc,";
/* 369 */       String sql = " select * from mtl_res_list where 1=1 ";
/* 370 */       String condition = "";
/* 371 */       if (svc.getResCode() != null) {
/* 372 */         condition = condition + " and res_code='" + svc.getResCode() + "'";
/*     */       }
/*     */       else {
/* 375 */         condition = condition + " and substr(res_code,1,3)<>'RES'";
/*     */       }
/* 377 */       if (svc.getCostCode() != null) {
/* 378 */         condition = condition + " and cost_code=" + svc.getCostCode();
/*     */       }
/* 380 */       if (svc.getResFlag() != null) {
/* 381 */         condition = condition + " and res_flag=" + svc.getResFlag();
/*     */       }
/* 383 */       if (svc.getResType() != null) {
/* 384 */         condition = condition + " and res_type=" + svc.getResType();
/*     */       }
/* 386 */       sql = sql + condition + " order by res_code";
/* 387 */       String sqlPaged = MpmUtil.getPagedSql(sql, column, "res_code", curPage.intValue(), pageSize.intValue());
/*     */ 
/* 389 */       List list = (List)getJdbcTemplate().query(sqlPaged, new RowMapperResultSetExtractor(new RowMapper()
/*     */       {
/*     */         public Object mapRow(ResultSet rs, int rowNum)
/*     */           throws SQLException
/*     */         {
/* 394 */           return MpmForPageDaoImpl.this.getResResultSet(rs);
/*     */         }
/*     */       }
/*     */       , 0));
/*     */ 
/* 398 */       sql = MpmUtil.getCountTotalSql("mtl_res_list", "res_code", " 1=1 " + condition, null);
/*     */ 
/* 401 */       total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
/*     */ 
/* 403 */       map.put("total", total);
/* 404 */       map.put("result", list);
/*     */     } catch (Exception de) {
/* 406 */       log.error("", de);
/*     */     }
/* 408 */     return map;
/*     */   }
/*     */ 
/*     */   private MtlResList getResResultSet(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/* 418 */     MtlResList svc = new MtlResList();
/* 419 */     String tmpStr = rs.getString("res_code");
/* 420 */     if (tmpStr == null) {
/* 421 */       return null;
/*     */     }
/* 423 */     svc.setResCode(tmpStr);
/* 424 */     svc.setResName(rs.getString("res_name"));
/* 425 */     svc.setResFlag(Short.valueOf(rs.getString("res_flag")));
/* 426 */     svc.setResType(Long.valueOf(rs.getString("res_type")));
/* 427 */     tmpStr = rs.getString("res_price");
/* 428 */     if (tmpStr == null)
/* 429 */       svc.setResPrice(Double.valueOf(0.0D));
/*     */     else {
/* 431 */       svc.setResPrice(Double.valueOf(tmpStr));
/*     */     }
/* 433 */     svc.setResDesc(rs.getString("res_desc"));
/* 434 */     svc.setCostCode(Long.valueOf(rs.getString("cost_code")));
/* 435 */     return svc;
/*     */   }
/*     */ 
/*     */   public Map findCostAll(MtlCostList svc, Integer curPage, Integer pageSize)
/*     */   {
/* 447 */     HashMap map = new HashMap();
/*     */     try {
/* 449 */       Integer total = Integer.valueOf(0);
/* 450 */       String column = " cost_code,cost_name,cost_desc,cost_type,";
/* 451 */       String sql = " select * from ap_cost_list where 1=1 ";
/* 452 */       String condition = "";
/* 453 */       if (svc.getCostCode() != null) {
/* 454 */         condition = condition + " and cost_code=" + svc.getCostCode();
/*     */       }
/* 456 */       if (svc.getCostType() != null) {
/* 457 */         condition = condition + " and cost_type=" + svc.getCostType();
/*     */       }
/* 459 */       sql = sql + condition + " order by cost_code";
/*     */ 
/* 461 */       String sqlPaged = MpmUtil.getPagedSql(sql, column, "cost_code", curPage.intValue(), pageSize.intValue());
/*     */ 
/* 464 */       List list = (List)getJdbcTemplate().query(sqlPaged, new RowMapperResultSetExtractor(new RowMapper()
/*     */       {
/*     */         public Object mapRow(ResultSet rs, int rowNum)
/*     */           throws SQLException
/*     */         {
/* 469 */           return MpmForPageDaoImpl.this.getCostResultSet(rs);
/*     */         }
/*     */       }
/*     */       , 0));
/*     */ 
/* 472 */       sql = MpmUtil.getCountTotalSql("ap_cost_list", "cost_code", " 1=1" + condition, null);
/*     */ 
/* 474 */       total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
/* 475 */       map.put("total", total);
/* 476 */       map.put("result", list);
/*     */     } catch (Exception de) {
/* 478 */       log.error("", de);
/*     */     }
/* 480 */     return map;
/*     */   }
/*     */ 
/*     */   private MtlCostList getCostResultSet(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/* 492 */     MtlCostList svc = new MtlCostList();
/* 493 */     String tmpStr = rs.getString("cost_code");
/* 494 */     if (tmpStr == null) {
/* 495 */       return null;
/*     */     }
/* 497 */     svc.setCostCode(Long.valueOf(tmpStr));
/* 498 */     svc.setCostName(rs.getString("cost_name"));
/* 499 */     svc.setCostDesc(rs.getString("cost_desc"));
/* 500 */     svc.setCostType(Long.valueOf(rs.getString("cost_type")));
/* 501 */     return svc;
/*     */   }
/*     */ 
/*     */   public Map findApproveRelationAll(MtlApproveRelation svc, Integer curPage, Integer pageSize)
/*     */   {
/* 513 */     HashMap map = new HashMap();
/*     */     try {
/* 515 */       Integer total = Integer.valueOf(0);
/* 516 */       String column = " DEPTID,APPROVE_USERID,APPROVE_CREATE_USERID,CREATE_TIME,POSITION_ID,APPROVE_USERID_EMAIL,APPROVE_USERID_MSISDN,";
/* 517 */       String sql = " select * from AP_APPROVE_RELATION where 1=1 ";
/* 518 */       String condition = "";
/* 519 */       if (svc.getId().getDeptId() != null) {
/* 520 */         condition = condition + " and deptid=" + svc.getId().getDeptId() + "";
/*     */       }
/*     */ 
/* 523 */       if (svc.getId().getApproveUserid() != null) {
/* 524 */         condition = condition + " and approve_userid='" + svc.getId().getApproveUserid() + "'";
/*     */       }
/*     */ 
/* 531 */       if (svc.getCreateTime() != null) {
/* 532 */         condition = condition + " and create_time='" + svc.getCreateTime() + "'";
/*     */       }
/*     */ 
/* 535 */       if (svc.getPositionId() != null) {
/* 536 */         condition = condition + " and position_id=" + svc.getPositionId();
/*     */       }
/*     */ 
/* 539 */       if (svc.getApproveCreateUserid() != null) {
/* 540 */         condition = condition + " and approve_create_userid='" + svc.getApproveCreateUserid() + "'";
/*     */       }
/*     */ 
/* 543 */       if (svc.getCityid() != null) {
/* 544 */         condition = condition + " and cityid in (" + svc.getCityid() + ")";
/*     */       }
/*     */ 
/* 547 */       sql = sql + condition + " order by deptid";
/* 548 */       String sqlPaged = MpmUtil.getPagedSql(sql, column, "DEPTID", curPage.intValue(), pageSize.intValue());
/*     */ 
/* 550 */       List list = (List)getJdbcTemplate().query(sqlPaged, new RowMapperResultSetExtractor(new RowMapper()
/*     */       {
/*     */         public Object mapRow(ResultSet rs, int rowNum)
/*     */           throws SQLException
/*     */         {
/* 555 */           return MpmForPageDaoImpl.this.getApproveResultSet(rs);
/*     */         }
/*     */       }
/*     */       , 0));
/*     */ 
/* 558 */       sql = MpmUtil.getCountTotalSql("AP_APPROVE_RELATION", "DEPTID", " 1=1" + condition, null);
/*     */ 
/* 560 */       total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
/* 561 */       map.put("total", total);
/* 562 */       map.put("result", list);
/*     */     } catch (Exception de) {
/* 564 */       log.error("", de);
/*     */     }
/* 566 */     return map;
/*     */   }
/*     */ 
/*     */   private MtlApproveRelation getApproveResultSet(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/* 577 */     MtlApproveRelation svc = new MtlApproveRelation();
/* 578 */     String tmpStr = rs.getString("DEPTID");
/* 579 */     if (tmpStr == null) {
/* 580 */       return null;
/*     */     }
/* 582 */     svc.getId().setDeptId(Integer.valueOf(tmpStr));
/* 583 */     svc.getId().setApproveUserid(rs.getString("APPROVE_USERID"));
/*     */ 
/* 585 */     svc.setApproveCreateUserid(rs.getString("APPROVE_CREATE_USERID"));
/* 586 */     String dbType = Configure.getInstance().getProperty("MPM_DBTYPE");
/* 587 */     if ("mysql".equalsIgnoreCase(dbType))
/* 588 */       svc.setCreateTime(rs.getTimestamp("CREATE_TIME"));
/*     */     else {
/* 590 */       svc.setCreateTime(rs.getDate("CREATE_TIME"));
/*     */     }
/*     */ 
/* 593 */     svc.setApproveUseridEmail(rs.getString("APPROVE_USERID_EMAIL"));
/* 594 */     svc.setApproveUseridMsisdn(rs.getString("APPROVE_USERID_MSISDN"));
/*     */ 
/* 597 */     return svc;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MpmForPageDaoImpl
 * JD-Core Version:    0.6.2
 */
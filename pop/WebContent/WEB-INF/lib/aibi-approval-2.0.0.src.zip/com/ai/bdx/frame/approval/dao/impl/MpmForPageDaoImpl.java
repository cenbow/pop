package com.ai.bdx.frame.approval.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
import com.ai.bdx.frame.approval.model.MtlApproveRelation;
import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumnId;
import com.ai.bdx.frame.approval.model.MtlCostList;
import com.ai.bdx.frame.approval.model.MtlDataExportItem;
import com.ai.bdx.frame.approval.model.MtlResList;
import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
import com.ai.bdx.frame.approval.model.MtlTempletActive;
import com.ai.bdx.frame.approval.model.MtlTempletActiveField;
import com.ai.bdx.frame.approval.util.MpmUtil;
import com.asiainfo.biframe.utils.config.Configure;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
import com.asiainfo.biframe.utils.string.StringUtil;

//import com.ibm.db2.jcc.a.r;

/**
 * 数据源管理数据库操作
 * 
 * @author zhoulb
 *
 */

public class MpmForPageDaoImpl extends JdbcDaoSupport implements IMpmForPageDao {
	private static Logger log = LogManager.getLogger();

	@Override
	public boolean isExists(String tablename) {
		Sqlca sqlca = null;
		boolean result = false;
		try {
			sqlca = new Sqlca(this.getConnection());
			StringBuffer sqlBuffer = new StringBuffer();
			sqlBuffer.append("select count(*) from ").append(tablename)
					.append(" where 1=2");
			sqlca.execute(sqlBuffer.toString());
			result = true;
		} catch (Exception e) {
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
		return result;
	}

	
	@Override
	public Map findActTempletById(String activeTempletId, Integer curPage,
			Integer pageSize) {
		HashMap map = new HashMap();
		try {
			Integer total = Integer.valueOf(0);
			String column = " column_name,source_name,column_type,column_cname,active_templet_id,";
			String condition = "";
			String sql = " select * from mtl_templet_active_field where 1=1 ";
			if (activeTempletId != null && !"".equals(activeTempletId)) {
				sql = sql + " and active_templet_id='" + activeTempletId + "'";
				condition = condition + " and active_templet_id='"
						+ activeTempletId + "'";
			}
			String sqlPaged = MpmUtil.getPagedSql(sql, column, "column_name",
					curPage.intValue(), pageSize.intValue());
			// logger.debug("sql="+sqlPaged);
			List list = (List) getJdbcTemplate().query(sqlPaged,
					new RowMapperResultSetExtractor(new RowMapper() {
						@Override
						public Object mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return getActiveTempletColumn(rs);
						}
					}, 0));
			sql = MpmUtil.getCountTotalSql("mtl_templet_active_field",
					"column_name", " 1=1" + condition, null);
			total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
			// logger.debug("***result="+list+"\ntotal="+total);
			map.put("total", total);
			map.put("result", list);
		} catch (Exception de) {
			log.error("", de);
		}
		return map;
	}


	/**
	 * 活动字段信息分页 中间过程，将表中的字段值对应到bo的属性
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private MtlTempletActiveField getActiveTempletColumn(ResultSet rs)
			throws SQLException {
		MtlTempletActiveField svc = new MtlTempletActiveField();
		String tmpStr = rs.getString("column_name");
		if (tmpStr == null) {
			return null;
		}
		svc.getId().setColumnName(tmpStr);
		svc.getId().setSourceName(rs.getString("source_name"));
		svc.getId().setColumnType(Short.valueOf(rs.getString("column_type")));
		svc.setColumnCname(rs.getString("column_cname"));
		svc.getId().setActiveTempletId(rs.getString("active_templet_id"));
		return svc;
	}
	/**
	 * 数据导出定义分类
	 * 
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	@Override
	public Map findDataExportItem(String campDrvId, String sourceName,
			String columnName, Integer curPage, Integer pageSize) {
		HashMap map = new HashMap();
		try {
			Integer total = Integer.valueOf(0);
			String column = " camp_drv_id,column_name,column_cname,source_name,column_type,column_dest,dimcolumn_desc_flag,";
			String condition = "";
			String sql = " select * from mtl_data_export_item where 1=1 ";
			if (campDrvId != null && !"".equals(campDrvId)) {
				condition = condition + " and camp_drv_id=" + campDrvId;
			}
			if (sourceName != null && !"".equals(sourceName)) {
				condition = condition + " and camp_drv_id=" + campDrvId;
			}
			if (columnName != null && !"".equals(columnName)) {
				condition = condition + " and camp_drv_id=" + campDrvId;
			}
			sql = sql + condition + " order by camp_drv_id";
			String sqlPaged = MpmUtil.getPagedSql(sql, column, "camp_drv_id",
					curPage.intValue(), pageSize.intValue());
			// logger.debug("sql="+sqlPaged);
			List list = (List) getJdbcTemplate().query(sqlPaged,
					new RowMapperResultSetExtractor(new RowMapper() {
						@Override
						public Object mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return getDataExportItem(rs);
						}
					}, 0));
			// logger.debug("list="+list);
			sql = MpmUtil.getCountTotalSql("mtl_data_export_item",
					"camp_drv_id", " 1=1" + condition, null);
			// logger.debug("sql="+sql);
			total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
			// logger.debug("total="+total);
			map.put("total", total);
			map.put("result", list);
		} catch (Exception de) {
			log.error("", de);
		}
		return map;
	}

	/**
	 * 数据导出定义分页 中间过程，将表中的字段值对应到bo的属性
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private MtlDataExportItem getDataExportItem(ResultSet rs)
			throws SQLException {
		MtlDataExportItem svc = new MtlDataExportItem();
		String tmpStr = rs.getString("camp_drv_id");
		if (tmpStr == null) {
			return null;
		}
		svc.getId().setCampDrvId(Short.valueOf(tmpStr));
		svc.getId().setColumnName(rs.getString("column_name"));
		svc.getId().setSourceName(rs.getString("source_name"));
		svc.setColumnType(Short.valueOf(rs.getString("column_type")));
		svc.setColumnDest(Integer.valueOf(rs.getString("column_dest")));
		svc.setDimcolumnDescFlag(Short.valueOf(rs
				.getString("dimcolumn_desc_flag")));
		svc.setColumnCname(rs.getString("column_cname"));

		return svc;
	}

	/**
	 * 数据源管理分页 通过表名来查询字段信息
	 */
	@Override
	public Map findDataSourceByTabname(String tabname, String columnName,
			String columnCname, Integer curPage, Integer pageSize)
			throws DataAccessException {
		HashMap map = new HashMap();
		try {
			Integer total = Integer.valueOf(0);
			String condition = "";
			String column = " column_name,column_cname,column_class,column_flag,source_name,column_datatype,column_desc,column_type,column_status,";
			String sql = " select * from mtl_camp_datasrc_column where 1=1 ";

			if (tabname != null && !"".equals(tabname)) {
				condition = condition + " and source_name='" + tabname + "'";
			}
			if (columnName != null && !"".equals(columnName)) {
				condition = condition + " and column_name like '%"
						+ columnName.trim() + "%' ";
			}
			if (columnCname != null && !"".equals(columnCname)) {
				condition = condition + " and column_cname like '%"
						+ columnCname.trim() + "%' ";
			}
			sql = sql + condition + " order by column_class";
			String sqlPaged = MpmUtil.getPagedSql(sql, column, "column_name",
					curPage.intValue(), pageSize.intValue());
			// removed by wwl 2007-01-16 “order by”加到前面2行代码中
			// sqlPaged = sqlPaged + " order by column_class";
			logger.debug("\n" + sqlPaged);
			List list = (List) this.getJdbcTemplate().query(sqlPaged,
					new RowMapperResultSetExtractor(new RowMapper() {
						@Override
						public Object mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return getDataBaseResultSet(rs);
						}
					}, 0));
			sql = MpmUtil.getCountTotalSql("mtl_camp_datasrc_column",
					"column_name", " 1=1 " + condition, null);
			// log.debug("========================1="+curPage.intValue()+"=========2="+pageSize.intValue());
			logger.debug("\n" + sql);

			total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
			map.put("total", total);
			map.put("result", list);
		} catch (Exception de) {
			log.error("", de);
		}
		return map;
	}
	/**
	 * 数据源管理分页 中间过程，将表中的字段值对应到bo的属性
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private MtlCampDatasrcColumn getDataBaseResultSet(ResultSet rs)
			throws SQLException {
		MtlCampDatasrcColumn svc = new MtlCampDatasrcColumn();
		MtlCampDatasrcColumnId child = new MtlCampDatasrcColumnId();
		String tmpStr = rs.getString("source_name");
		if (tmpStr == null) {
			return null;
		}
		child.setColumnName(rs.getString("column_name"));
		child.setColumnType(rs.getString("column_type"));
		child.setSourceName(tmpStr);
		svc.setId(child);
		svc.setColumnClass(rs.getString("column_class"));
		svc.setColumnCname(rs.getString("column_cname"));
		svc.setColumnDatatype(rs.getString("column_datatype"));
		svc.setColumnDesc(rs.getString("column_desc"));
		svc.setColumnFlag(rs.getString("column_flag"));
		svc.setColumnStatus(Short.valueOf(rs.getString("column_status")));
		return svc;
	}

	/**
	 * 活动流程定义分页 通过表名来查询字段信息
	 */
	@Override
	public Map findActStepflowAll(MtlSysActflowDef svc, Integer curPage,
			Integer pageSize) throws DataAccessException {
		HashMap map = new HashMap();
		try {
			Integer total = Integer.valueOf(0);
			String column = " flow_id,flow_name,flow_desc,approve_flow_id,create_userid,create_time,warn_flag,status_chg_type,camp_type,";
			String sql = " select * from ap_sys_actflow_def where 1=1 ";
			String condition = "";
			if (svc.getFlowId() != null) {
				condition = condition + " and flow_id='" + svc.getFlowId()
						+ "'";
			}
			if (svc.getCreateUserid() != null) {
				condition = condition + " and create_userid='"
						+ svc.getCreateUserid() + "'";
			}
			// if(svc.getApproveFlowId() != null &&
			// svc.getApproveFlowId().length() > 0){
			// condition = condition +
			// " and approve_flow_id='"+svc.getApproveFlowId() + "'";
			// }
			if (svc.getStatusChgType() != null) {
				condition = condition + " and status_chg_type="
						+ svc.getStatusChgType();
			}
			sql = sql + condition + " order by flow_name";
			String sqlPaged = MpmUtil.getPagedSql(sql, column, "flow_name",
					curPage.intValue(), pageSize.intValue());
			List list = (List) this.getJdbcTemplate().query(sqlPaged,
					new RowMapperResultSetExtractor(new RowMapper() {
						@Override
						public Object mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return getActflowResultSet(rs);
						}
					}, 0));
			sql = MpmUtil.getCountTotalSql("ap_sys_actflow_def", "flow_id",
					" 1=1" + condition, null);
			total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
			map.put("total", total);
			map.put("result", list);
		} catch (Exception de) {
			log.error("", de);
		}
		return map;
	}
	/**
	 * 活动流程定义分页 中间过程，将表中的字段值对应到bo的属性
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private MtlSysActflowDef getActflowResultSet(ResultSet rs)
			throws SQLException {
		MtlSysActflowDef svc = new MtlSysActflowDef();
		String tmpStr = rs.getString("flow_id");
		if (tmpStr == null) {
			return null;
		}
		svc.setFlowId(tmpStr);
		svc.setFlowName(rs.getString("flow_name"));
		svc.setFlowDesc(rs.getString("flow_desc"));
		// svc.setApproveLev(Short.valueOf(rs.getString("approve_lev")));
		// svc.setApproveFlowId(rs.getString("approve_flow_id"));
		svc.setCreateUserid(rs.getString("create_userid"));
		svc.setCreateTime(rs.getDate("create_time"));
		svc.setWarnFlag(Short.valueOf(rs.getString("warn_flag")));
		svc.setStatusChgType(Integer.valueOf(rs.getString("status_chg_type")));
		svc.setCampType(Short.valueOf(rs.getString("camp_type")));
		return svc;
	}


	/**
	 * 实体管理分页
	 */
	@Override
	public Map findResAll(MtlResList svc, Integer curPage, Integer pageSize) {
		HashMap map = new HashMap();
		try {
			Integer total = Integer.valueOf(0);
			String column = " res_code,res_name,res_flag,res_type,res_price,cost_code,res_desc,";
			String sql = " select * from mtl_res_list where 1=1 ";
			String condition = "";
			if (svc.getResCode() != null) {
				condition = condition + " and res_code='" + svc.getResCode()
						+ "'";
			} else {
				condition = condition + " and substr(res_code,1,3)<>'RES'";
			}
			if (svc.getCostCode() != null) {
				condition = condition + " and cost_code=" + svc.getCostCode();
			}
			if (svc.getResFlag() != null) {
				condition = condition + " and res_flag=" + svc.getResFlag();
			}
			if (svc.getResType() != null) {
				condition = condition + " and res_type=" + svc.getResType();
			}
			sql = sql + condition + " order by res_code";
			String sqlPaged = MpmUtil.getPagedSql(sql, column, "res_code",
					curPage.intValue(), pageSize.intValue());
			List list = (List) this.getJdbcTemplate().query(sqlPaged,
					new RowMapperResultSetExtractor(new RowMapper() {
						@Override
						public Object mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return getResResultSet(rs);
						}
					}, 0));

			sql = MpmUtil.getCountTotalSql("mtl_res_list", "res_code", " 1=1 "
					+ condition, null);

			total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));

			map.put("total", total);
			map.put("result", list);
		} catch (Exception de) {
			log.error("", de);
		}
		return map;
	}
	/**
	 * 实体管理分页 中间过程，将表中的字段值对应到bo的属性
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private MtlResList getResResultSet(ResultSet rs) throws SQLException {
		MtlResList svc = new MtlResList();
		String tmpStr = rs.getString("res_code");
		if (tmpStr == null) {
			return null;
		}
		svc.setResCode(tmpStr);
		svc.setResName(rs.getString("res_name"));
		svc.setResFlag(Short.valueOf(rs.getString("res_flag")));
		svc.setResType(Long.valueOf(rs.getString("res_type")));
		tmpStr = rs.getString("res_price");
		if (tmpStr == null) {
			svc.setResPrice(Double.valueOf(0.00));
		} else {
			svc.setResPrice(Double.valueOf(tmpStr));
		}
		svc.setResDesc(rs.getString("res_desc"));
		svc.setCostCode(Long.valueOf(rs.getString("cost_code")));
		return svc;
	}

	/**
	 * 成本类型管理分类
	 * 
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	@Override
	public Map findCostAll(MtlCostList svc, Integer curPage, Integer pageSize) {
		HashMap map = new HashMap();
		try {
			Integer total = Integer.valueOf(0);
			String column = " cost_code,cost_name,cost_desc,cost_type,";
			String sql = " select * from ap_cost_list where 1=1 ";
			String condition = "";
			if (svc.getCostCode() != null) {
				condition = condition + " and cost_code=" + svc.getCostCode();
			}
			if (svc.getCostType() != null) {
				condition = condition + " and cost_type=" + svc.getCostType();
			}
			sql = sql + condition + " order by cost_code";

			String sqlPaged = MpmUtil.getPagedSql(sql, column, "cost_code",
					curPage.intValue(), pageSize.intValue());

			List list = (List) getJdbcTemplate().query(sqlPaged,
					new RowMapperResultSetExtractor(new RowMapper() {
						@Override
						public Object mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return getCostResultSet(rs);
						}
					}, 0));
			sql = MpmUtil.getCountTotalSql("ap_cost_list", "cost_code", " 1=1"
					+ condition, null);
			total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
			map.put("total", total);
			map.put("result", list);
		} catch (Exception de) {
			log.error("", de);
		}
		return map;
	}


	/**
	 * 成本管理分页 中间过程，将表中的字段值对应到bo的属性
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private MtlCostList getCostResultSet(ResultSet rs) throws SQLException {
		MtlCostList svc = new MtlCostList();
		String tmpStr = rs.getString("cost_code");
		if (tmpStr == null) {
			return null;
		}
		svc.setCostCode(Long.valueOf(tmpStr));
		svc.setCostName(rs.getString("cost_name"));
		svc.setCostDesc(rs.getString("cost_desc"));
		svc.setCostType(Long.valueOf(rs.getString("cost_type")));
		return svc;
	}
	/**
	 * 审批关系定义分类
	 * 
	 * @param curPage
	 * @param pageSize
	 * @return
	 */
	@Override
	public Map findApproveRelationAll(MtlApproveRelation svc, Integer curPage,
			Integer pageSize) {
		HashMap map = new HashMap();
		try {
			Integer total = Integer.valueOf(0);
			String column = " DEPTID,APPROVE_USERID,APPROVE_CREATE_USERID,CREATE_TIME,POSITION_ID,APPROVE_USERID_EMAIL,APPROVE_USERID_MSISDN,";
			String sql = " select * from AP_APPROVE_RELATION where 1=1 ";
			String condition = "";
			if (svc.getId().getDeptId() != null) {
				condition = condition + " and deptid="
						+ svc.getId().getDeptId() + "";
			}
			if (svc.getId().getApproveUserid() != null) {
				condition = condition + " and approve_userid='"
						+ svc.getId().getApproveUserid() + "'";
			}
			// if(svc.getApproveLevel() != null){
			// condition = condition +
			// " and approve_level="+svc.getApproveLevel();
			// }
			if (svc.getCreateTime() != null) {
				condition = condition + " and create_time='"
						+ svc.getCreateTime() + "'";
			}
			if (svc.getPositionId() != null) {
				condition = condition + " and position_id="
						+ svc.getPositionId();
			}
			if (svc.getApproveCreateUserid() != null) {
				condition = condition + " and approve_create_userid='"
						+ svc.getApproveCreateUserid() + "'";
			}
			if (svc.getCityid() != null) {
				condition = condition + " and cityid in (" + svc.getCityid()
						+ ")";
			}
			sql = sql + condition + " order by deptid";
			String sqlPaged = MpmUtil.getPagedSql(sql, column, "DEPTID",curPage.intValue(), pageSize.intValue());
			// logger.debug("sql="+sqlPaged);
			List list = (List) this.getJdbcTemplate().query(sqlPaged,
					new RowMapperResultSetExtractor(new RowMapper() {
						@Override
						public Object mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return getApproveResultSet(rs);
						}
					}, 0));
			sql = MpmUtil.getCountTotalSql("AP_APPROVE_RELATION", "DEPTID",
					" 1=1" + condition, null);
			total = Integer.valueOf(getJdbcTemplate().queryForInt(sql));
			map.put("total", total);
			map.put("result", list);
		} catch (Exception de) {
			log.error("", de);
		}
		return map;
	}
	/**
	 * 指标定义分页 中间过程，将表中的字段值对应到bo的属性
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private MtlApproveRelation getApproveResultSet(ResultSet rs)
			throws SQLException {
		MtlApproveRelation svc = new MtlApproveRelation();
		String tmpStr = rs.getString("DEPTID");
		if (tmpStr == null) {
			return null;
		}
		svc.getId().setDeptId(Integer.valueOf(tmpStr));
		svc.getId().setApproveUserid(rs.getString("APPROVE_USERID"));
		// svc.setApproveLevel(Short.valueOf(rs.getString("APPROVE_LEVEL")));
		svc.setApproveCreateUserid(rs.getString("APPROVE_CREATE_USERID"));
		String dbType = Configure.getInstance().getProperty("MPM_DBTYPE");
		if ("mysql".equalsIgnoreCase(dbType)) {
			svc.setCreateTime(rs.getTimestamp("CREATE_TIME"));
		} else {
			svc.setCreateTime(rs.getDate("CREATE_TIME"));
		}
		// svc.setPositionId(Integer.valueOf(rs.getString("POSITION_ID")));
		svc.setApproveUseridEmail(rs.getString("APPROVE_USERID_EMAIL"));
		svc.setApproveUseridMsisdn(rs.getString("APPROVE_USERID_MSISDN"));
		// svc.setApproverDeptid(Integer.valueOf(rs.getString("APPROVER_DEPTID")));
		// svc.setCreatorDeptid(Integer.valueOf(rs.getString("CREATOR_DEPTID")));
		return svc;
	}

}

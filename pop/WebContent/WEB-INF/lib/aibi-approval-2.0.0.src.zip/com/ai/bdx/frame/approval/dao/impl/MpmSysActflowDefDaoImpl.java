package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMpmSysActflowDefDao;
import com.ai.bdx.frame.approval.model.MtlSysActflowDef;

public class MpmSysActflowDefDaoImpl extends HibernateDaoSupport implements
		IMpmSysActflowDefDao {
	public static Logger log = LogManager.getLogger();

	/**
	 * 返回所有的活动流程信息
	 * 
	 * @return list
	 */
	@Override
	public List findAll() throws DataAccessException {
		List list = new ArrayList();
		try {
			String sql = "from MtlSysActflowDef as a order by a.flowName";
			list = getHibernateTemplate().find(sql);
			return list;
		} catch (DataAccessException de) {
			log.error("", de);
			return null;
		}
	}

	/**
	 * 插入一条记录
	 * 
	 * @param MtlSysActflowDef
	 * @return boolean
	 */
	@Override
	public String save(MtlSysActflowDef mtlSysActflowDef) {
		try {
			String svc = (String) getHibernateTemplate().save(mtlSysActflowDef);
			return svc;
		} catch (DataAccessException de) {
			log.error("", de);
			return null;
		}
	}

	/**
	 * 修改一条记录
	 * 
	 * @param MtlSysActflowDef
	 * @return boolean
	 */
	@Override
	public boolean update(MtlSysActflowDef mtlSysActflowDef) {
		boolean flag = true;
		try {
			getHibernateTemplate().update(mtlSysActflowDef);
			flag = true;
		} catch (DataAccessException de) {
			log.error("", de);
		}
		return flag;
	}

	/**
	 * 根据flowId删除一条记录
	 * 
	 * @param flowId
	 * @return boolean
	 */
	@Override
	public boolean deleteById(String flowId) {
		boolean flag = false;
		try {
			final String sql = "from MtlSysActflowDef as a where a.flowId='"
					+ flowId + "'";
			// getHibernateTemplate().delete(sql);
			this.getHibernateTemplate().execute(new HibernateCallback() {
				@Override
				public Object doInHibernate(Session arg0)
						throws HibernateException, SQLException {
					Query query = arg0.createQuery("delete " + sql);
					query.executeUpdate();
					return null;
				}
			});
			flag = true;
		} catch (DataAccessException de) {
			log.error("", de);
			return false;
		}
		return flag;
	}

	@Override
	public MtlSysActflowDef findById(String flowId) {
		try {
			String sql = "from MtlSysActflowDef as a where a.flowId='" + flowId
					+ "'";
			List list = getHibernateTemplate().find(sql);
			MtlSysActflowDef mtlSysActflowDef = new MtlSysActflowDef();
			if (list != null && list.size() > 0) {
				mtlSysActflowDef = (MtlSysActflowDef) list.get(0);
			}
			return mtlSysActflowDef;
		} catch (DataAccessException de) {
			log.error("", de);
			return null;
		}
	}

	@Override
	public MtlSysActflowDef getSysActFlowDef(String flowId) throws Exception {
		MtlSysActflowDef obj = null;
		try {
			obj = (MtlSysActflowDef) this.getHibernateTemplate().get(
					MtlSysActflowDef.class, flowId);
		} catch (Exception e) {
			throw e;
		}
		return obj;
	}

	@Override
	public List getAllSysActFlow() throws Exception {
		return this.getHibernateTemplate().find(
				"from MtlSysActflowDef as a order by a.flowName");
	}

	@Override
	public List getCampSysActFlow() throws Exception {
		return this
				.getHibernateTemplate()
				.find("from MtlSysActflowDef as a where a.campType in(0,1,2) order by a.flowName");
	}

	/**
	 * @deprecated 不再使用 wuwl 2007-6-21
	 */
	@Override
	@Deprecated
	public List getSysActFlowDefMapByLevel(int approveLevel) throws Exception {
		return this.getHibernateTemplate().find(
				"from MtlSysActflowDef mad where mad.approveLev<="
						+ approveLevel + " order by mad.flowName");
	}

	@Override
	public boolean getActFlowByApproveflowid(String approveFlowId)
			throws Exception {
		boolean flag = false;
		try {
			List list = this.getHibernateTemplate().find(
					"from MtlSysActflowDef mad where mad.approveFlowId='"
							+ approveFlowId + "'");
			if (list != null && list.size() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return flag;
	}
}

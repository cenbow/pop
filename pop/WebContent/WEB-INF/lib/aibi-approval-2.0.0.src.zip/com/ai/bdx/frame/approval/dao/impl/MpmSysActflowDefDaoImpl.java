/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMpmSysActflowDefDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MpmSysActflowDefDaoImpl extends HibernateDaoSupport
/*     */   implements IMpmSysActflowDefDao
/*     */ {
/*  21 */   public static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public List findAll()
/*     */     throws DataAccessException
/*     */   {
/*  30 */     List list = new ArrayList();
/*     */     try {
/*  32 */       String sql = "from MtlSysActflowDef as a order by a.flowName";
/*  33 */       return getHibernateTemplate().find(sql);
/*     */     }
/*     */     catch (DataAccessException de) {
/*  36 */       log.error("", de);
/*  37 */     }return null;
/*     */   }
/*     */ 
/*     */   public String save(MtlSysActflowDef mtlSysActflowDef)
/*     */   {
/*     */     try
/*     */     {
/*  50 */       return (String)getHibernateTemplate().save(mtlSysActflowDef);
/*     */     }
/*     */     catch (DataAccessException de) {
/*  53 */       log.error("", de);
/*  54 */     }return null;
/*     */   }
/*     */ 
/*     */   public boolean update(MtlSysActflowDef mtlSysActflowDef)
/*     */   {
/*  66 */     boolean flag = true;
/*     */     try {
/*  68 */       getHibernateTemplate().update(mtlSysActflowDef);
/*  69 */       flag = true;
/*     */     } catch (DataAccessException de) {
/*  71 */       log.error("", de);
/*     */     }
/*  73 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean deleteById(String flowId)
/*     */   {
/*  84 */     boolean flag = false;
/*     */     try {
/*  86 */       final String sql = "from MtlSysActflowDef as a where a.flowId='" + flowId + "'";
/*     */ 
/*  89 */       getHibernateTemplate().execute(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session arg0) throws HibernateException, SQLException
/*     */         {
/*  93 */           Query query = arg0.createQuery("delete " + sql);
/*  94 */           query.executeUpdate();
/*  95 */           return null;
/*     */         }
/*     */       });
/*  98 */       flag = true;
/*     */     } catch (DataAccessException de) {
/* 100 */       log.error("", de);
/* 101 */       return false;
/*     */     }
/* 103 */     return flag;
/*     */   }
/*     */ 
/*     */   public MtlSysActflowDef findById(String flowId)
/*     */   {
/*     */     try {
/* 109 */       String sql = "from MtlSysActflowDef as a where a.flowId='" + flowId + "'";
/*     */ 
/* 111 */       List list = getHibernateTemplate().find(sql);
/* 112 */       MtlSysActflowDef mtlSysActflowDef = new MtlSysActflowDef();
/* 113 */       if ((list != null) && (list.size() > 0));
/* 114 */       return (MtlSysActflowDef)list.get(0);
/*     */     }
/*     */     catch (DataAccessException de)
/*     */     {
/* 118 */       log.error("", de);
/* 119 */     }return null;
/*     */   }
/*     */ 
/*     */   public MtlSysActflowDef getSysActFlowDef(String flowId)
/*     */     throws Exception
/*     */   {
/* 125 */     MtlSysActflowDef obj = null;
/*     */     try {
/* 127 */       obj = (MtlSysActflowDef)getHibernateTemplate().get(MtlSysActflowDef.class, flowId);
/*     */     }
/*     */     catch (Exception e) {
/* 130 */       throw e;
/*     */     }
/* 132 */     return obj;
/*     */   }
/*     */ 
/*     */   public List getAllSysActFlow() throws Exception
/*     */   {
/* 137 */     return getHibernateTemplate().find("from MtlSysActflowDef as a order by a.flowName");
/*     */   }
/*     */ 
/*     */   public List getCampSysActFlow()
/*     */     throws Exception
/*     */   {
/* 143 */     return getHibernateTemplate().find("from MtlSysActflowDef as a where a.campType in(0,1,2) order by a.flowName");
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public List getSysActFlowDefMapByLevel(int approveLevel)
/*     */     throws Exception
/*     */   {
/* 154 */     return getHibernateTemplate().find("from MtlSysActflowDef mad where mad.approveLev<=" + approveLevel + " order by mad.flowName");
/*     */   }
/*     */ 
/*     */   public boolean getActFlowByApproveflowid(String approveFlowId)
/*     */     throws Exception
/*     */   {
/* 162 */     boolean flag = false;
/*     */     try {
/* 164 */       List list = getHibernateTemplate().find("from MtlSysActflowDef mad where mad.approveFlowId='" + approveFlowId + "'");
/*     */ 
/* 167 */       if ((list != null) && (list.size() > 0))
/* 168 */         flag = true;
/*     */     }
/*     */     catch (Exception e) {
/* 171 */       log.error("", e);
/*     */     }
/* 173 */     return flag;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MpmSysActflowDefDaoImpl
 * JD-Core Version:    0.6.2
 */
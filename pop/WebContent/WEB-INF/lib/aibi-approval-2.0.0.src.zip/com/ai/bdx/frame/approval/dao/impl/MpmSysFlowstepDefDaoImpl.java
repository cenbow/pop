package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMpmSysFlowstepDefDao;
import com.ai.bdx.frame.approval.model.MtlSysFlowstepDef;

public class MpmSysFlowstepDefDaoImpl extends HibernateDaoSupport implements IMpmSysFlowstepDefDao {

	public void deleteById(String flowId) throws Exception {
		try {
			final String sql = "from MtlSysFlowstepDef as a where a.id.flowId='" + flowId + "'";
			//getHibernateTemplate().delete(sql);
			this.getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
					Query query = arg0.createQuery("delete " + sql);
					query.executeUpdate();
					return null;
				}
			});
		} catch (Exception e) {
			throw e;
		}
	}

	public MtlSysFlowstepDef saveOrUpdate(MtlSysFlowstepDef mtlSysFlowstepDef) throws Exception {
		try {
			//logger.debug("flowId="+mtlSysFlowstepDef.getId().getFlowId()+"\nstepId"+mtlSysFlowstepDef.getId().getStepId());
			this.getHibernateTemplate().save(mtlSysFlowstepDef);
		} catch (Exception e) {
			throw e;
		}
		return mtlSysFlowstepDef;
	}

	public List getSysFlowstepDefByFlowId(String flowId) throws Exception {
		String sql = "from MtlSysFlowstepDef as a where a.id.flowId='" + flowId + "' order by a.id.stepId";
		//    	Query query = this.getSession().createQuery(sql);
		//    	return query.list();
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}
}

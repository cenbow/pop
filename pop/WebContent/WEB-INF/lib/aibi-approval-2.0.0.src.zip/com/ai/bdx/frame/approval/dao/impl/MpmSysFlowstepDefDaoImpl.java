/*    */ package com.ai.bdx.frame.approval.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IMpmSysFlowstepDefDao;
/*    */ import com.ai.bdx.frame.approval.model.MtlSysFlowstepDef;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.Query;
/*    */ import org.hibernate.Session;
/*    */ import org.springframework.orm.hibernate3.HibernateCallback;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class MpmSysFlowstepDefDaoImpl extends HibernateDaoSupport
/*    */   implements IMpmSysFlowstepDefDao
/*    */ {
/*    */   public void deleteById(String flowId)
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 19 */       final String sql = "from MtlSysFlowstepDef as a where a.id.flowId='" + flowId + "'";
/*    */ 
/* 21 */       getHibernateTemplate().execute(new HibernateCallback() {
/*    */         public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/* 23 */           Query query = arg0.createQuery("delete " + sql);
/* 24 */           query.executeUpdate();
/* 25 */           return null;
/*    */         } } );
/*    */     }
/*    */     catch (Exception e) {
/* 29 */       throw e;
/*    */     }
/*    */   }
/*    */ 
/*    */   public MtlSysFlowstepDef saveOrUpdate(MtlSysFlowstepDef mtlSysFlowstepDef) throws Exception
/*    */   {
/*    */     try {
/* 36 */       getHibernateTemplate().save(mtlSysFlowstepDef);
/*    */     } catch (Exception e) {
/* 38 */       throw e;
/*    */     }
/* 40 */     return mtlSysFlowstepDef;
/*    */   }
/*    */ 
/*    */   public List getSysFlowstepDefByFlowId(String flowId) throws Exception {
/* 44 */     String sql = "from MtlSysFlowstepDef as a where a.id.flowId='" + flowId + "' order by a.id.stepId";
/*    */ 
/* 47 */     final String tmpSql = sql;
/* 48 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*    */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 50 */         Query query = s.createQuery(tmpSql);
/* 51 */         return query.list();
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MpmSysFlowstepDefDaoImpl
 * JD-Core Version:    0.6.2
 */
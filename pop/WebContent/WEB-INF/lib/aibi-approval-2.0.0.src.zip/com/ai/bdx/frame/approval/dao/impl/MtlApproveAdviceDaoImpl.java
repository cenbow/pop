package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.impl.SessionImpl;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMtlApproveAdviceDao;
import com.ai.bdx.frame.approval.model.MtlApproveAdvice;
import com.ai.bdx.frame.approval.model.MtlApproveAdviceId;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;

/**
 * Created on May 28, 2007 1:37:13 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlApproveAdviceDaoImpl extends HibernateDaoSupport implements IMtlApproveAdviceDao {
	private static Logger log = LogManager.getLogger();
	/**
	 *
	 */
	public MtlApproveAdviceDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.asiainfo.biapp.mcd.dao.IMtlApproveAdviceDao#deleteMtlApproveAdvice(com.asiainfo.biapp.mcd.model.MtlApproveAdviceId)
	 */
	public void deleteMtlApproveAdvice(MtlApproveAdviceId id) throws Exception {
		String sql = "from MtlApproveAdvice maa where 1=1 ";
		if (id.getCampsegId() != null) {
			sql += " and maa.campsegId='" + id.getCampsegId() + "'";
		}
		if (id.getSponorUserId() != null) {
			sql += " and maa.sponorUserId='" + id.getSponorUserId() + "'";
		}
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
	}

	/* (non-Javadoc)
	 * @see com.asiainfo.biapp.mcd.dao.IMtlApproveAdviceDao#findApproveAdvice(com.asiainfo.biapp.mcd.model.MtlApproveAdvice)
	 */
	public List findApproveAdvice(MtlApproveAdvice advice) throws Exception {
		String sql = "from MtlApproveAdvice maa where 1=1 ";
		if (advice.getId().getCampsegId() != null) {
			sql += " and maa.id.campsegId='" + advice.getId().getCampsegId() + "'";
		}
		if (advice.getId().getSponorUserId() != null) {
			sql += " and maa.id.sponorUserId='" + advice.getId().getSponorUserId() + "'";
		}
		if (advice.getActEndFlag() != null) {
			sql += " and maa.actEndFlag=" + advice.getActEndFlag();
		}
		if (advice.getId().getActorUserId() != null && advice.getId().getActorUserId().length() > 0) {
			sql += " and maa.id.actorUserId='" + advice.getId().getActorUserId() + "'";
		}
		if (advice.getId().getSponsorType() != null) {
			sql += " and maa.id.sponsorType=" + advice.getId().getSponsorType();
		}
		if (advice.getSponsorDate() != null && advice.getSponsorDate().length() > 0) {
			sql += " and maa.sponsorDate>='" + advice.getSponsorDate() + "'";
		}
		sql += " order by maa.actTime desc";
		return this.getHibernateTemplate().find(sql);
	}

	public List findApproveAdviceWithCampsegInfo(MtlApproveAdvice advice,String subject) throws Exception {
		String sql = "select maa.actEndFlag,mcs.campPriId,mcs.campId,mcs.campsegId,mcs.campsegName,maa.id.sponorUserId,maa.sponsorDate,maa.actTime,'',mcs.createUserid " + " from MtlApproveAdvice maa,MtlCampSeginfo mcs "
				+ " where mcs.campsegId=maa.id.campsegId ";
		if (advice.getId().getCampsegId() != null) {
			sql += " and maa.id.campsegId='" + advice.getId().getCampsegId() + "'";
		}
		if (advice.getId().getSponorUserId() != null) {
			sql += " and maa.id.sponorUserId='" + advice.getId().getSponorUserId() + "'";
		}
		if (advice.getActEndFlag() != null) {
			sql += " and maa.actEndFlag=" + advice.getActEndFlag();
		}
		if (advice.getId().getActorUserId() != null && advice.getId().getActorUserId().length() > 0) {
			sql += " and maa.id.actorUserId='" + advice.getId().getActorUserId() + "'";
		}
		if (advice.getId().getSponsorType() != null) {
			sql += " and maa.id.sponsorType=" + advice.getId().getSponsorType();
		}
		if (advice.getSponsorDate() != null && advice.getSponsorDate().length() > 0) {
			sql += " and maa.sponsorDate>='" + advice.getSponsorDate() + "'";
		}
		//added by caosj 2009-05-27
		if (subject != null && subject.trim().length()>0){
			sql += " and mcs.campDrvId = " + MpmCONST.MTL_CAMP_DRV_TYPE_ID; ;
		}
		sql += " order by mcs.campPriId";
		return this.getHibernateTemplate().find(sql);
	}

	//caihao add 29/11/07
	public List findApproveAdviceWithCampInfo(MtlApproveAdvice advice,String subject) throws Exception {
		StringBuffer sql=new StringBuffer();
		 sql.append("select maa.actEndFlag,mcb.campPriId,mcb.campId,mcb.campName,maa.id.sponorUserId,maa.sponsorDate,maa.actTime,mcb.createUserid ").append(" from MtlApproveAdvice maa,MtlCampBaseinfo mcb ").append(" where mcb.campId=maa.id.campsegId ");
				//String sql = "select maa.actEndFlag,mcb.campPriId,mcb.campId,mcb.campName,maa.id.sponorUserId,maa.sponsorDate,maa.actTime,mcb.createUserid " + " from MtlApproveAdvice maa,MtlCampBaseinfo mcb " + " where mcb.campId=maa.id.campsegId ";
		if (advice.getId().getCampsegId() != null) {
			sql.append( " and maa.id.campsegId='").append( advice.getId().getCampsegId()).append("'");
			//sql += " and maa.id.campsegId='" + advice.getId().getCampsegId() + "'";
		}
		if (advice.getId().getSponorUserId() != null) {
			sql.append(" and maa.id.sponorUserId='").append( advice.getId().getSponorUserId()).append("'");
			//sql += " and maa.id.sponorUserId='" + advice.getId().getSponorUserId() + "'";
		}
		if (advice.getActEndFlag() != null) {
			sql.append(" and maa.actEndFlag=").append(advice.getActEndFlag());
//			sql += " and maa.actEndFlag=" + advice.getActEndFlag();
		}
		if (advice.getId().getActorUserId() != null && advice.getId().getActorUserId().length() > 0) {
			sql.append(" and maa.id.actorUserId='").append( advice.getId().getActorUserId()).append("'");
			//sql += " and maa.id.actorUserId='" + advice.getId().getActorUserId() + "'";
		}
		if (advice.getId().getSponsorType() != null) {
			sql.append(" and maa.id.sponsorType=").append( advice.getId().getSponsorType());
			//sql += " and maa.id.sponsorType=" + advice.getId().getSponsorType();
		}
		if (advice.getSponsorDate() != null && advice.getSponsorDate().length() > 0) {
			sql.append(" and maa.sponsorDate>='").append( advice.getSponsorDate()).append("'");
			//sql += " and maa.sponsorDate>='" + advice.getSponsorDate() + "'";
		}
		//added by caosj 2009-05-27
		if (subject != null && subject.trim().length()>0){
			//sql += " and mcb.campDrvId = " + MpmCONST.MTL_CAMP_DRV_TYPE_ID; ;
			sql.append( " and mcb.campDrvId = ").append( MpmCONST.MTL_CAMP_DRV_TYPE_ID);
		}
		sql.append(" order by mcb.campPriId");
//		sql += " order by mcb.campPriId";
		return this.getHibernateTemplate().find(sql.toString());
	}

	public Map findApproveAdvice(MtlApproveAdvice advice, final Integer currPage, final Integer pageSize) throws Exception {
		Map retmap;
		String sql = "from MtlApproveAdvice maa where 1=1 ";
		if (advice.getId().getCampsegId() != null) {
			sql += " and maa.id.campsegId='" + advice.getId().getCampsegId() + "'";
		}
		if (advice.getId().getSponorUserId() != null) {
			sql += " and maa.id.sponorUserId='" + advice.getId().getSponorUserId() + "'";
		}
		if (advice.getActEndFlag() != null) {
			sql += " and maa.actEndFlag=" + advice.getActEndFlag();
		}
		if (advice.getId().getActorUserId() != null && advice.getId().getActorUserId().length() > 0) {
			sql += " and maa.id.actorUserId='" + advice.getId().getActorUserId() + "'";
		}
		if (advice.getId().getSponsorType() != null) {
			sql += " and maa.id.sponsorType=" + advice.getId().getSponsorType();
		}
		if (advice.getSponsorDate() != null && advice.getSponsorDate().length() > 0) {
			sql += " and maa.sponsorDate>='" + advice.getSponsorDate() + "'";
		}
		final String tmpSql = sql;
		retmap = (Map) this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException, SQLException {
				Map map = new HashMap();
				Query query = session.createQuery(tmpSql);
				Integer totalCnt = Integer.valueOf(query.list().size());
				query.setFirstResult(pageSize.intValue() * currPage.intValue());
				query.setMaxResults(pageSize.intValue());
				List result = query.list();
				if (result.size() == 0) {
					map.put("total", Integer.valueOf(0));
					map.put("result", new ArrayList());
					return map;
				}

				map.put("total", totalCnt);
				map.put("result", result);
				return map;
			}
		});
		return retmap;
	}

	/* (non-Javadoc)
	 * @see com.asiainfo.biapp.mcd.dao.IMtlApproveAdviceDao#getApproveAdviceById(com.asiainfo.biapp.mcd.model.MtlApproveAdviceId)
	 */
	public MtlApproveAdvice getApproveAdviceById(MtlApproveAdviceId id) throws Exception {
		return (MtlApproveAdvice) this.getHibernateTemplate().get(MtlApproveAdvice.class, id);
	}

	/* (non-Javadoc)
	 * @see com.asiainfo.biapp.mcd.dao.IMtlApproveAdviceDao#saveMtlApproveAdvice(com.asiainfo.biapp.mcd.model.MtlApproveAdvice)
	 */
	public void saveMtlApproveAdvice(MtlApproveAdvice advice) throws Exception {
		log.debug(advice.toString());
		this.getHibernateTemplate().save(advice);
	}

	/* (non-Javadoc)
	 * @see com.asiainfo.biapp.mcd.dao.IMtlApproveAdviceDao#updateMtlApproveAdvice(com.asiainfo.biapp.mcd.model.MtlApproveAdvice)
	 */
	public void updateMtlApproveAdvice(MtlApproveAdvice advice) throws Exception {
		this.getHibernateTemplate().update(advice);
	}

	public void updateApproveAdviceSponorUserId(String campsegId, String oldSponorUserId, String newSponorUserId, Short sponorType) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			StringBuffer sql=new StringBuffer();
			sql.append("update mtl_approve_advice set sponor_User_Id='").append(newSponorUserId ).append( "' where campseg_id='").append(campsegId).append("'").append(" and sponsor_Type=").append(sponorType).append(" and sponor_User_Id='").append(oldSponorUserId).append("'");
			//String sql = "update mtl_approve_advice set sponor_User_Id='" + newSponorUserId + "' where campseg_id='" + campsegId + "'" + " and sponsor_Type=" + sponorType + " and sponor_User_Id='" + oldSponorUserId + "'";
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	public void updateApproveAdviceActEndFlag(String campsegId, String sponorUserId, Short actEndFlag, Short sponorType) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			StringBuffer sql=new StringBuffer();
			 sql.append("update mtl_approve_advice set act_end_flag=").append(actEndFlag).append(" where campseg_id='").append(campsegId).append("'").append(" and sponsor_Type=").append(sponorType).append(" and sponor_User_Id='").append(sponorUserId ).append("'");
//			String sql = "update mtl_approve_advice set act_end_flag=" + actEndFlag + " where campseg_id='" + campsegId + "'" + " and sponsor_Type=" + sponorType + " and sponor_User_Id='" + sponorUserId + "'";
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	public List getAdviceActUserId(String campsegId, String sponorUserId, Short sponorType) throws Exception {
		List retlist = new ArrayList();
		String sql = "from MtlApproveAdvice maa " + " where maa.id.campsegId='" + campsegId + "' " + " and maa.id.sponorUserId='" + sponorUserId + "' " + " and maa.id.sponsorType=" + sponorType.toString();
		final String tmpSql = sql;
		retlist = (List) this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException, SQLException {
				List list = new ArrayList();
				Query query = session.createQuery(tmpSql);
				Iterator it = query.list().iterator();
				MtlApproveAdvice advice;
				while (it.hasNext()) {
					advice = (MtlApproveAdvice) it.next();
					list.add(advice.getId().getActorUserId());
				}
				return list;
			}
		});
		return retlist;
	}

	public void deleteAdviceByActUserIds(String campsegId, String sponorUserId, String actUserIds, Short sponorType) throws Exception {
		String sql = "from MtlApproveAdvice maa " + " where maa.id.campsegId='" + campsegId + "' " + " and maa.id.sponorUserId='" + sponorUserId + "' " + " and maa.id.sponsorType=" + sponorType.toString() + " and maa.id.actorUserId in (" + actUserIds + ")";
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
	}
}

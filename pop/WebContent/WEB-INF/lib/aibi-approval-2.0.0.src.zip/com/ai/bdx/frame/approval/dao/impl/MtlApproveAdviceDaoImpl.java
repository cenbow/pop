/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveAdviceDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveAdvice;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveAdviceId;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.impl.SessionImpl;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlApproveAdviceDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlApproveAdviceDao
/*     */ {
/*  37 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public void deleteMtlApproveAdvice(MtlApproveAdviceId id)
/*     */     throws Exception
/*     */   {
/*  49 */     String sql = "from MtlApproveAdvice maa where 1=1 ";
/*  50 */     if (id.getCampsegId() != null) {
/*  51 */       sql = sql + " and maa.campsegId='" + id.getCampsegId() + "'";
/*     */     }
/*  53 */     if (id.getSponorUserId() != null) {
/*  54 */       sql = sql + " and maa.sponorUserId='" + id.getSponorUserId() + "'";
/*     */     }
/*  56 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ 
/*     */   public List findApproveAdvice(MtlApproveAdvice advice)
/*     */     throws Exception
/*     */   {
/*  63 */     String sql = "from MtlApproveAdvice maa where 1=1 ";
/*  64 */     if (advice.getId().getCampsegId() != null) {
/*  65 */       sql = sql + " and maa.id.campsegId='" + advice.getId().getCampsegId() + "'";
/*     */     }
/*  67 */     if (advice.getId().getSponorUserId() != null) {
/*  68 */       sql = sql + " and maa.id.sponorUserId='" + advice.getId().getSponorUserId() + "'";
/*     */     }
/*  70 */     if (advice.getActEndFlag() != null) {
/*  71 */       sql = sql + " and maa.actEndFlag=" + advice.getActEndFlag();
/*     */     }
/*  73 */     if ((advice.getId().getActorUserId() != null) && (advice.getId().getActorUserId().length() > 0)) {
/*  74 */       sql = sql + " and maa.id.actorUserId='" + advice.getId().getActorUserId() + "'";
/*     */     }
/*  76 */     if (advice.getId().getSponsorType() != null) {
/*  77 */       sql = sql + " and maa.id.sponsorType=" + advice.getId().getSponsorType();
/*     */     }
/*  79 */     if ((advice.getSponsorDate() != null) && (advice.getSponsorDate().length() > 0)) {
/*  80 */       sql = sql + " and maa.sponsorDate>='" + advice.getSponsorDate() + "'";
/*     */     }
/*  82 */     sql = sql + " order by maa.actTime desc";
/*  83 */     return getHibernateTemplate().find(sql);
/*     */   }
/*     */ 
/*     */   public List findApproveAdviceWithCampsegInfo(MtlApproveAdvice advice, String subject) throws Exception {
/*  87 */     String sql = "select maa.actEndFlag,mcs.campPriId,mcs.campId,mcs.campsegId,mcs.campsegName,maa.id.sponorUserId,maa.sponsorDate,maa.actTime,'',mcs.createUserid  from MtlApproveAdvice maa,MtlCampSeginfo mcs  where mcs.campsegId=maa.id.campsegId ";
/*     */ 
/*  89 */     if (advice.getId().getCampsegId() != null) {
/*  90 */       sql = sql + " and maa.id.campsegId='" + advice.getId().getCampsegId() + "'";
/*     */     }
/*  92 */     if (advice.getId().getSponorUserId() != null) {
/*  93 */       sql = sql + " and maa.id.sponorUserId='" + advice.getId().getSponorUserId() + "'";
/*     */     }
/*  95 */     if (advice.getActEndFlag() != null) {
/*  96 */       sql = sql + " and maa.actEndFlag=" + advice.getActEndFlag();
/*     */     }
/*  98 */     if ((advice.getId().getActorUserId() != null) && (advice.getId().getActorUserId().length() > 0)) {
/*  99 */       sql = sql + " and maa.id.actorUserId='" + advice.getId().getActorUserId() + "'";
/*     */     }
/* 101 */     if (advice.getId().getSponsorType() != null) {
/* 102 */       sql = sql + " and maa.id.sponsorType=" + advice.getId().getSponsorType();
/*     */     }
/* 104 */     if ((advice.getSponsorDate() != null) && (advice.getSponsorDate().length() > 0)) {
/* 105 */       sql = sql + " and maa.sponsorDate>='" + advice.getSponsorDate() + "'";
/*     */     }
/*     */ 
/* 108 */     if ((subject != null) && (subject.trim().length() > 0)) {
/* 109 */       sql = sql + " and mcs.campDrvId = 10";
/*     */     }
/* 111 */     sql = sql + " order by mcs.campPriId";
/* 112 */     return getHibernateTemplate().find(sql);
/*     */   }
/*     */ 
/*     */   public List findApproveAdviceWithCampInfo(MtlApproveAdvice advice, String subject) throws Exception
/*     */   {
/* 117 */     StringBuffer sql = new StringBuffer();
/* 118 */     sql.append("select maa.actEndFlag,mcb.campPriId,mcb.campId,mcb.campName,maa.id.sponorUserId,maa.sponsorDate,maa.actTime,mcb.createUserid ").append(" from MtlApproveAdvice maa,MtlCampBaseinfo mcb ").append(" where mcb.campId=maa.id.campsegId ");
/*     */ 
/* 120 */     if (advice.getId().getCampsegId() != null) {
/* 121 */       sql.append(" and maa.id.campsegId='").append(advice.getId().getCampsegId()).append("'");
/*     */     }
/*     */ 
/* 124 */     if (advice.getId().getSponorUserId() != null) {
/* 125 */       sql.append(" and maa.id.sponorUserId='").append(advice.getId().getSponorUserId()).append("'");
/*     */     }
/*     */ 
/* 128 */     if (advice.getActEndFlag() != null) {
/* 129 */       sql.append(" and maa.actEndFlag=").append(advice.getActEndFlag());
/*     */     }
/*     */ 
/* 132 */     if ((advice.getId().getActorUserId() != null) && (advice.getId().getActorUserId().length() > 0)) {
/* 133 */       sql.append(" and maa.id.actorUserId='").append(advice.getId().getActorUserId()).append("'");
/*     */     }
/*     */ 
/* 136 */     if (advice.getId().getSponsorType() != null) {
/* 137 */       sql.append(" and maa.id.sponsorType=").append(advice.getId().getSponsorType());
/*     */     }
/*     */ 
/* 140 */     if ((advice.getSponsorDate() != null) && (advice.getSponsorDate().length() > 0)) {
/* 141 */       sql.append(" and maa.sponsorDate>='").append(advice.getSponsorDate()).append("'");
/*     */     }
/*     */ 
/* 145 */     if ((subject != null) && (subject.trim().length() > 0))
/*     */     {
/* 147 */       sql.append(" and mcb.campDrvId = ").append("10");
/*     */     }
/* 149 */     sql.append(" order by mcb.campPriId");
/*     */ 
/* 151 */     return getHibernateTemplate().find(sql.toString());
/*     */   }
/*     */ 
/*     */   public Map findApproveAdvice(MtlApproveAdvice advice, final Integer currPage, final Integer pageSize) throws Exception
/*     */   {
/* 156 */     String sql = "from MtlApproveAdvice maa where 1=1 ";
/* 157 */     if (advice.getId().getCampsegId() != null) {
/* 158 */       sql = sql + " and maa.id.campsegId='" + advice.getId().getCampsegId() + "'";
/*     */     }
/* 160 */     if (advice.getId().getSponorUserId() != null) {
/* 161 */       sql = sql + " and maa.id.sponorUserId='" + advice.getId().getSponorUserId() + "'";
/*     */     }
/* 163 */     if (advice.getActEndFlag() != null) {
/* 164 */       sql = sql + " and maa.actEndFlag=" + advice.getActEndFlag();
/*     */     }
/* 166 */     if ((advice.getId().getActorUserId() != null) && (advice.getId().getActorUserId().length() > 0)) {
/* 167 */       sql = sql + " and maa.id.actorUserId='" + advice.getId().getActorUserId() + "'";
/*     */     }
/* 169 */     if (advice.getId().getSponsorType() != null) {
/* 170 */       sql = sql + " and maa.id.sponsorType=" + advice.getId().getSponsorType();
/*     */     }
/* 172 */     if ((advice.getSponsorDate() != null) && (advice.getSponsorDate().length() > 0)) {
/* 173 */       sql = sql + " and maa.sponsorDate>='" + advice.getSponsorDate() + "'";
/*     */     }
/* 175 */     final String tmpSql = sql;
/* 176 */     Map retmap = (Map)getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/* 178 */         Map map = new HashMap();
/* 179 */         Query query = session.createQuery(tmpSql);
/* 180 */         Integer totalCnt = Integer.valueOf(query.list().size());
/* 181 */         query.setFirstResult(pageSize.intValue() * currPage.intValue());
/* 182 */         query.setMaxResults(pageSize.intValue());
/* 183 */         List result = query.list();
/* 184 */         if (result.size() == 0) {
/* 185 */           map.put("total", Integer.valueOf(0));
/* 186 */           map.put("result", new ArrayList());
/* 187 */           return map;
/*     */         }
/*     */ 
/* 190 */         map.put("total", totalCnt);
/* 191 */         map.put("result", result);
/* 192 */         return map;
/*     */       }
/*     */     });
/* 195 */     return retmap;
/*     */   }
/*     */ 
/*     */   public MtlApproveAdvice getApproveAdviceById(MtlApproveAdviceId id)
/*     */     throws Exception
/*     */   {
/* 202 */     return (MtlApproveAdvice)getHibernateTemplate().get(MtlApproveAdvice.class, id);
/*     */   }
/*     */ 
/*     */   public void saveMtlApproveAdvice(MtlApproveAdvice advice)
/*     */     throws Exception
/*     */   {
/* 209 */     log.debug(advice.toString());
/* 210 */     getHibernateTemplate().save(advice);
/*     */   }
/*     */ 
/*     */   public void updateMtlApproveAdvice(MtlApproveAdvice advice)
/*     */     throws Exception
/*     */   {
/* 217 */     getHibernateTemplate().update(advice);
/*     */   }
/*     */ 
/*     */   public void updateApproveAdviceSponorUserId(String campsegId, String oldSponorUserId, String newSponorUserId, Short sponorType) throws Exception {
/* 221 */     Sqlca sqlca = null;
/*     */     try {
/* 223 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 224 */       StringBuffer sql = new StringBuffer();
/* 225 */       sql.append("update mtl_approve_advice set sponor_User_Id='").append(newSponorUserId).append("' where campseg_id='").append(campsegId).append("'").append(" and sponsor_Type=").append(sponorType).append(" and sponor_User_Id='").append(oldSponorUserId).append("'");
/*     */ 
/* 227 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 229 */       throw e;
/*     */     } finally {
/* 231 */       if (sqlca != null)
/* 232 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateApproveAdviceActEndFlag(String campsegId, String sponorUserId, Short actEndFlag, Short sponorType) throws Exception
/*     */   {
/* 238 */     Sqlca sqlca = null;
/*     */     try {
/* 240 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 241 */       StringBuffer sql = new StringBuffer();
/* 242 */       sql.append("update mtl_approve_advice set act_end_flag=").append(actEndFlag).append(" where campseg_id='").append(campsegId).append("'").append(" and sponsor_Type=").append(sponorType).append(" and sponor_User_Id='").append(sponorUserId).append("'");
/*     */ 
/* 244 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 246 */       throw e;
/*     */     } finally {
/* 248 */       if (sqlca != null)
/* 249 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getAdviceActUserId(String campsegId, String sponorUserId, Short sponorType) throws Exception
/*     */   {
/* 255 */     List retlist = new ArrayList();
/* 256 */     String sql = "from MtlApproveAdvice maa  where maa.id.campsegId='" + campsegId + "' " + " and maa.id.sponorUserId='" + sponorUserId + "' " + " and maa.id.sponsorType=" + sponorType.toString();
/* 257 */     final String tmpSql = sql;
/* 258 */     retlist = (List)getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/* 260 */         List list = new ArrayList();
/* 261 */         Query query = session.createQuery(tmpSql);
/* 262 */         Iterator it = query.list().iterator();
/*     */ 
/* 264 */         while (it.hasNext()) {
/* 265 */           MtlApproveAdvice advice = (MtlApproveAdvice)it.next();
/* 266 */           list.add(advice.getId().getActorUserId());
/*     */         }
/* 268 */         return list;
/*     */       }
/*     */     });
/* 271 */     return retlist;
/*     */   }
/*     */ 
/*     */   public void deleteAdviceByActUserIds(String campsegId, String sponorUserId, String actUserIds, Short sponorType) throws Exception {
/* 275 */     String sql = "from MtlApproveAdvice maa  where maa.id.campsegId='" + campsegId + "' " + " and maa.id.sponorUserId='" + sponorUserId + "' " + " and maa.id.sponsorType=" + sponorType.toString() + " and maa.id.actorUserId in (" + actUserIds + ")";
/* 276 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlApproveAdviceDaoImpl
 * JD-Core Version:    0.6.2
 */
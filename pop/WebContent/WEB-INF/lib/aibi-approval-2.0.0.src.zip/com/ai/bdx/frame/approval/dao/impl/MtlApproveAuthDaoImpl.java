package com.ai.bdx.frame.approval.dao.impl;


import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMtlApproveAuthDao;
import com.ai.bdx.frame.approval.model.MtlApproveAuth;
import com.ai.bdx.frame.approval.model.MtlApproveAuthId;

/**
 * Created on May 28, 2007 1:37:13 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb
 * @version 1.0
 */
public class MtlApproveAuthDaoImpl extends HibernateDaoSupport implements IMtlApproveAuthDao {
	public static Logger log = LogManager.getLogger();
	/**
	 *
	 */
	public MtlApproveAuthDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveAdviceDao#deleteMtlApproveAdvice(com.ai.bdx.frame.approval.model.MtlApproveAdviceId)
	 */
	public void save(MtlApproveAuth auth) throws Exception {
		this.getHibernateTemplate().save(auth);
	}

	public void delete(final MtlApproveAuth auth) throws Exception {
		String sql = "from MtlApproveAuth maa where maa.id.authUserid='" + auth.getId().getAuthUserid() + "' and maa.id.authType=" + auth.getId().getAuthType();
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
	}

	public MtlApproveAuth getById(MtlApproveAuthId id) throws Exception {
		return (MtlApproveAuth) this.getHibernateTemplate().get(MtlApproveAuth.class, id);
	}

	public List getAuthRelation(String authUserid) throws Exception {
		List result = null;
		try {
			result = this.getHibernateTemplate().find("from MtlApproveConsignor maa where maa.authUserid='" + authUserid + "'");
		} catch (Exception e) {
log.error("",e);
		}
		return result;
	}
}

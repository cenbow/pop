/*    */ package com.ai.bdx.frame.approval.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IMtlApproveAuthDao;
/*    */ import com.ai.bdx.frame.approval.model.MtlApproveAuth;
/*    */ import com.ai.bdx.frame.approval.model.MtlApproveAuthId;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class MtlApproveAuthDaoImpl extends HibernateDaoSupport
/*    */   implements IMtlApproveAuthDao
/*    */ {
/* 25 */   public static Logger log = LogManager.getLogger();
/*    */ 
/*    */   public void save(MtlApproveAuth auth)
/*    */     throws Exception
/*    */   {
/* 37 */     getHibernateTemplate().save(auth);
/*    */   }
/*    */ 
/*    */   public void delete(MtlApproveAuth auth) throws Exception {
/* 41 */     String sql = "from MtlApproveAuth maa where maa.id.authUserid='" + auth.getId().getAuthUserid() + "' and maa.id.authType=" + auth.getId().getAuthType();
/* 42 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*    */   }
/*    */ 
/*    */   public MtlApproveAuth getById(MtlApproveAuthId id) throws Exception {
/* 46 */     return (MtlApproveAuth)getHibernateTemplate().get(MtlApproveAuth.class, id);
/*    */   }
/*    */ 
/*    */   public List getAuthRelation(String authUserid) throws Exception {
/* 50 */     List result = null;
/*    */     try {
/* 52 */       result = getHibernateTemplate().find("from MtlApproveConsignor maa where maa.authUserid='" + authUserid + "'");
/*    */     } catch (Exception e) {
/* 54 */       log.error("", e);
/*    */     }
/* 56 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlApproveAuthDaoImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.List;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.impl.SessionImpl;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMtlApproveConfirmListDao;
import com.ai.bdx.frame.approval.model.MtlApproveConfirmAppoint;
import com.ai.bdx.frame.approval.model.MtlApproveConfirmList;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
import com.asiainfo.biframe.utils.string.StringUtil;

/*
 * Created on 9:32:39 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb
 * @version 1.0
 */
public class MtlApproveConfirmListDaoImpl extends HibernateDaoSupport implements IMtlApproveConfirmListDao {
	private static Logger log = LogManager.getLogger();

	public MtlApproveConfirmListDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void save(MtlApproveConfirmList svc) throws Exception {
		String sql = " from MtlApproveConfirmList mac where 1=1";
		if (svc.getId().getResourceId() != null && svc.getId().getResourceId().intValue() > 0) {
			sql += " and mac.id.resourceId=" + svc.getId().getResourceId();
		}
		if (svc.getId().getCampsegId() != null && svc.getId().getCampsegId().length() > 0) {
			sql += " and mac.id.campsegId='" + svc.getId().getCampsegId() + "'";
		}
		if (svc.getId().getConfirmUserid() != null && svc.getId().getConfirmUserid().length() > 0) {
			sql += " and mac.id.confirmUserid='" + svc.getId().getConfirmUserid() + "'";
		}
		if(svc.getId().getApproveLevel() != null) {
			sql += " and mac.id.approveLevel=" + svc.getId().getApproveLevel().shortValue();
		}
		if (svc.getId().getChannelNo() != null) {
			sql += " and mac.id.channelNo=" + svc.getId().getChannelNo() + "";
		}

		List list = this.getHibernateTemplate().find(sql);
		if (CollectionUtils.isEmpty(list)) {
			this.getHibernateTemplate().save(svc);
		} else {
			MtlApproveConfirmList svc1 = (MtlApproveConfirmList) list.get(0);
			svc1.setConfirmExplain(svc.getConfirmExplain());
			svc1.setForecastDate(svc.getForecastDate());
			svc1.setRemindDate(svc.getRemindDate());
			svc1.setConfirmFlag(Short.valueOf("0"));
			this.getHibernateTemplate().update(svc1);
		}
	}

	public void update(MtlApproveConfirmList svc) throws Exception {
		this.getHibernateTemplate().update(svc);
	}

	public void delete(MtlApproveConfirmList svc) throws Exception {
		this.getHibernateTemplate().delete(svc);
	}

	public List findByCond(MtlApproveConfirmList searchCond) throws Exception {
		try {
			String sql = " from MtlApproveConfirmList mac where 1=1";
			if (searchCond.getId().getResourceId() != null && searchCond.getId().getResourceId().intValue() > 0) {
				sql += " and mac.id.resourceId=" + searchCond.getId().getResourceId();
			}
			if (searchCond.getId().getCampsegId() != null && searchCond.getId().getCampsegId().length() > 0) {
				sql += " and mac.id.campsegId='" + searchCond.getId().getCampsegId() + "'";
			}
			if (searchCond.getId().getConfirmUserid() != null && searchCond.getId().getConfirmUserid().length() > 0) {
				sql += " and mac.id.confirmUserid='" + searchCond.getId().getConfirmUserid() + "'";
			}
			sql += " order by mac.remindDate";
			return this.getHibernateTemplate().find(sql);
		} catch (Exception e) {
			throw e;
		}
	}

	// caihao modified 2008-7-21
	public List findById(String campsegId, String confirmFlag, String resourceId, String confirmUserid, String approveFlowId, Short approveSeq, Short approveLevel) throws Exception {
		try {
			String sql = " from MtlApproveConfirmList mac where 1=1 ";
			if (resourceId != null && resourceId.length() > 0) {
				sql += " and mac.id.resourceId=" + resourceId;
			}
			if (confirmFlag != null && confirmFlag.length() > 0) {
				sql += " and mac.confirmFlag in (" + confirmFlag + ")";
			}
			if (campsegId != null && campsegId.length() > 0) {
				sql += " and mac.id.campsegId='" + campsegId + "'";
			}
			if (confirmUserid != null && confirmUserid.length() > 0) {
				sql += " and mac.id.confirmUserid='" + confirmUserid + "'";
			}
			if (approveFlowId != null && approveFlowId.length() > 0) {
				sql += " and mac.id.approveFlowId='" + approveFlowId + "'";
			}
			if (approveSeq != null) {
				sql += " and mac.id.approveSeq=" + approveSeq;
			}
			if (approveLevel != null) {
				sql += " and mac.id.approveLevel=" + approveLevel;
			}
			sql += " order by mac.id.approveSeq,mac.id.resourceId,mac.id.confirmUserid";

			List list = this.getHibernateTemplate().find(sql);

			return list;
		} catch (Exception e) {
			throw e;
		}
	}

	// caihao modified 2008-7-21
	public List findCurrentById(String campsegId, String confirmFlag, String resourceId, String confirmUserid, String approveFlowId, Short approveSeq, Short approveLevel) throws Exception {
		try {
			String sql = " from MtlApproveConfirmList mac where 1=1 and mac.approveToken=1";
			if (resourceId != null && resourceId.length() > 0) {
				sql += " and mac.id.resourceId=" + resourceId;
			}
			if (confirmFlag != null && confirmFlag.length() > 0) {
				sql += " and mac.confirmFlag in (" + confirmFlag + ")";
			}
			if (campsegId != null && campsegId.length() > 0) {
				sql += " and mac.id.campsegId='" + campsegId + "'";
			}
			if (confirmUserid != null && confirmUserid.length() > 0) {
				sql += " and mac.id.confirmUserid='" + confirmUserid + "'";
			}
			if (approveFlowId != null && approveFlowId.length() > 0) {
				sql += " and mac.id.approveFlowId='" + approveFlowId + "'";
			}
			if (approveSeq != null) {
				sql += " and mac.id.approveSeq=" + approveSeq;
			}
			if (approveLevel != null) {
				sql += " and mac.id.approveLevel=" + approveLevel;
			}
			sql += " order by mac.id.approveSeq,mac.id.resourceId,mac.id.confirmUserid";

			List list = this.getHibernateTemplate().find(sql);

			return list;
		} catch (Exception e) {
			throw e;
		}
	}

	public List findCampsegApprover(MtlApproveConfirmList approver) throws Exception {
		String sql = "from MtlApproveConfirmList mcal where 1=1 ";
		if (approver.getId() != null && approver.getId().getApproveFlowId() != null) {
			sql += " and mcal.id.approveFlowId='" + approver.getId().getApproveFlowId() + "'";
		}
		if (approver.getId() != null && approver.getId().getCampsegId() != null) {
			sql += " and mcal.id.campsegId='" + approver.getId().getCampsegId() + "'";
		}
		if (approver.getId() != null && approver.getId().getResourceId() != null) {
			sql += " and mcal.id.resourceId=" + approver.getId().getResourceId();
		}

		if (approver.getId().getConfirmUserid() != null) {
			sql += " and mcal.id.confirmUserid='" + approver.getId().getConfirmUserid() + "'";
		}
		if (approver.getApproveToken() != null) {
			sql += " and mcal.approveToken=" + approver.getApproveToken();
		}
		if (approver.getId() != null && approver.getId().getApproveLevel() != null) {
			sql += " and mcal.id.approveLevel=" + approver.getId().getApproveLevel();
		}
		if (approver.getId() != null && approver.getId().getApproveSeq() != null) {
			sql += " and mcal.id.approveSeq=" + approver.getId().getApproveSeq();
		}
		sql += " order by mcal.id.approveSeq";

		final String tmpSql = sql;
		return this.getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	public MtlApproveConfirmList getApproveConfirmList(String campsegId, String flowId, String userId, Integer resourceId, Short token) {
		String sql = "from MtlApproveConfirmList mcal where 1=1 ";
		if (flowId != null && !"".equals(flowId)) {
			sql += " and mcal.id.approveFlowId='" + flowId + "'";
		}
		if (campsegId != null && !"".equals(campsegId)) {
			sql += " and mcal.id.campsegId='" + campsegId + "'";
		}
		if (resourceId != null) {
			sql += " and mcal.id.resourceId=" + resourceId;
		}

		if (userId != null) {
			sql += " and mcal.id.confirmUserid='" + userId + "'";
		}
		if (token != null) {
			sql += " and mcal.approveToken=" + token;
		}
		sql += " order by mcal.id.approveSeq";

		final String tmpSql = sql;
		List list = this.getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});

		if(list != null && !list.isEmpty()) {
			return (MtlApproveConfirmList) list.get(0);
		}

		return null;
	}

	@SuppressWarnings("deprecation")
	public void updateCampsegConfirmToken(String approveFlowId, String campsegId, String confirmUserId, Short seq, Short token, Integer resourceId) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			StringBuffer sql=new StringBuffer();
			sql.append("update ap_approve_confirm_list set approve_token=").append(token).append( " where 1=1 ");
			//String sql = "update ap_approve_confirm_list set approve_token=" + token + " where 1=1 ";
			
			if (approveFlowId != null && approveFlowId.length() > 0) {
				sql.append(" and approve_flow_id='").append( approveFlowId).append("'");
//				sql += " and approve_flow_id='" + approveFlowId + "'";
			}
			if (campsegId != null && campsegId.length() > 0) {
//				sql += " and campseg_id='" + campsegId + "'";
				sql.append(" and campseg_id='").append( campsegId).append( "'");
			}
			if (resourceId != null) {
				sql.append(" and resource_id=").append( resourceId);
//				sql += " and resource_id=" + resourceId;
			}
			if (confirmUserId != null && confirmUserId.length() > 0) {
				sql.append(" and confirm_userid='").append( confirmUserId).append("'");
			}
			if(seq != null && seq > 0) {
				sql.append(" and APPROVE_SEQ=").append(seq);
				//sql += " and APPROVE_SEQ=" + seq;
			}
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	public MtlApproveConfirmList getFirstApprover(String campsegId, String flowId, Integer resourceId) {
		String sql = "from MtlApproveConfirmList mcal where 1=1 ";
		if (flowId != null) {
			sql += " and mcal.id.approveFlowId='" + flowId + "'";
		}
		if (campsegId != null) {
			sql += " and mcal.id.campsegId='" + campsegId + "'";
		}
		if (resourceId != null) {
			sql += " and mcal.id.resourceId=" + resourceId;
		}

		sql += " order by mcal.id.approveSeq";

		final String tmpSql = sql;
		List list =  this.getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});

		if(list != null && !list.isEmpty()) {
			return (MtlApproveConfirmList) list.get(0);
		}

		return null;
	}

	public void updateCampsegConfirmFlag(String campsegId, Integer resourceId, String confirmFlag) throws Exception {

		if(StringUtil.isEmpty(campsegId)||StringUtil.isEmpty(resourceId)) {
			return ;
		}
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			StringBuffer sql=new StringBuffer();
			sql.append( "update ap_approve_confirm_list set confirm_flag =").append(confirmFlag).append( " where campseg_id='")
					.append(campsegId).append( "' and resource_id=").append( resourceId);
			//String sql = "update ap_approve_confirm_list set confirm_flag =" + confirmFlag + " where campseg_id='"
			//				+ campsegId + "' and resource_id=" + resourceId;
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	public List findByFlag(String flag) throws Exception {
		try {
			String sql = " from MtlApproveConfirmList mac where mac.confirmFlag=" + flag+" and mac.approveToken = 1";
			return this.getHibernateTemplate().find(sql);
		} catch (Exception e) {
			throw e;
		}
	}
	
	public List findByCampsegIdUserId(String campsegId,String userId) {
		String sql = "from MtlApproveConfirmList mac where mac.approveToken = 1 and mac.campsegRootid= ? and mac.id.confirmUserid = ? ";
		return this.getHibernateTemplate().find(sql, new Object[]{campsegId,userId});
	}

	public List findByFlagGroupByUser(String flag) throws Exception {
		// TODO Auto-generated method stub
		try {
			String sql = " from MtlApproveConfirmList mac where mac.confirmFlag=" + flag + " group by mac.confirmUserid";
			return this.getHibernateTemplate().find(sql);
		} catch (Exception e) {
			throw e;
		}
	}

	public List findByUserFlag(String confirmUserid) throws Exception {
		List list = this.getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.confirmUserid='" + confirmUserid + "' and mcl.confirmFlag=0 and mcl.approveToken = 1");

		return list;
	}

	public List findConfirmedByUserFlag(String confirmUserid) throws Exception {
		
		StringBuffer sqlBuffer=new StringBuffer();
		sqlBuffer.append("select mcl.id.campsegId,mcl.forecastDate,mcl.id.confirmUserid,mcl.id.resourceId from MtlApproveConfirmList mcl where 1=1").append( " and mcl.id.confirmUserid='").append( confirmUserid).append( "' and mcl.confirmFlag in(1,2) ");
		List list = this.getHibernateTemplate().find(sqlBuffer.toString());
		//List list = this.getHibernateTemplate().find("select mcl.id.campsegId,mcl.forecastDate,mcl.id.confirmUserid,mcl.id.resourceId from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.confirmUserid='" + confirmUserid + "' and mcl.confirmFlag in(1,2) ");

		for (int i = 0; i < list.size(); i++) {
			Object[] obj = (Object[]) list.get(i);

			List list2 = this.getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.confirmUserid='" + (String) obj[2] + "'" + " and mcl.id.campsegId='" + (String) obj[0] + "'" + " and mcl.confirmFlag=0");

			if (list2.size() > 0) {
				list.remove(i);
				i--;

			}

		}
		return list;
	}

	public void deleteByCampsegid(final String campsegId) throws Exception {
		String sql = " from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.campsegId='" + campsegId + "'";
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
		this.getSession().flush();
	}

	// caihao add 判断某一活动/营销案的所有资源确认情况
	public String checkConfirmEnd(String campsegId) throws Exception {
		List list = this.getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.campsegId='" + campsegId + "' and mcl.confirmFlag = 2 ");
		if (list.size() > 0) {
			return "notPassed";
		} 


		list = this.getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.campsegId='" + campsegId + "' and mcl.confirmFlag in(0,2,9) ");
		if (list.size() <= 0) {
			return "yes";
		}

		list = this.getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.campsegId='" + campsegId + "' and mcl.confirmFlag =0");
		if (list.size() > 0) {
			return "notFinished";
		}else {
			return "";
		}
	}
	
	// 判断是否活动下所有子活动的资源确认完毕
	public String checkConfirmAllFinished(String campsegRootid) {
		List list = this.getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1" + " and mcl.campsegRootid='" + campsegRootid + "' and mcl.confirmFlag = 2");
		if (list.size() > 0) {
			return "notPassed";
		}
		
		list = this.getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1" + " and mcl.campsegRootid='" + campsegRootid + "' and mcl.confirmFlag in(0,2,9) ");
		if (list.size() <= 0) {
			return "yes";
		}

		list = this.getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1" + " and mcl.campsegRootid='" + campsegRootid + "' and mcl.confirmFlag =0");
		if (list.size() > 0) {
			return "notFinished";
		}else {
			return "";
		}
	}

	// caihao add 判断某人对某一活动/营销案的所有/某一资源确认情况
	public String checkConfirmEnd(String campsegId, String userid, Integer resourceId) throws Exception {
		String sql = " from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.campsegId='" + campsegId + "' and mcl.id.confirmUserid='" + userid + "'";
		if (resourceId != null) {
			sql += " and mcl.id.resourceId=" + resourceId;
		}
		sql += " and mcl.confirmFlag =0";
		List list = this.getHibernateTemplate().find(sql);
		if (list.size() > 0) {
			return "notFinished";
		} else {
			return "confirmed";
		}

	}

	//caihao add 2007-07-25 判断某一渠道是否有确认不通过的情况
	public boolean checkConfirmFailed(String campsegId, Integer resourceId) throws Exception {
		String sql = " from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.campsegId='" + campsegId + "'";
		//+ "' and mcl.id.confirmUserid='" + userid + "'";
		if (resourceId != null) {
			sql += " and mcl.id.resourceId=" + resourceId;
		}
		sql += " and mcl.confirmFlag =" + MpmCONST.MPM_CONFIRM_FLAG_CANNOT;
		List list = this.getHibernateTemplate().find(sql);
		if (list.size() > 0) {
			return true;
		} else {
			return false;
		}

	}

	public boolean checkConfirmFinished(String campsegId, Short resourceId , int confirmFlag) throws Exception {
		String sql = " from MtlApproveConfirmList mcl where 1=1" + " and mcl.id.campsegId='" + campsegId + "'";
		if (resourceId != null) {
			sql += " and mcl.id.resourceId=" + resourceId;
		}
		sql += " and mcl.confirmFlag !=" + confirmFlag;
		List list = this.getHibernateTemplate().find(sql);
		if (list.size() > 0) {
			return false;
		} else {
			return true;
		}

	}

	public void updateConfirmUserId(final String confirmUserid, final String newConfirmUserid, final int authFlag) throws Exception {
		this.getHibernateTemplate().execute(new HibernateCallback() {
			@SuppressWarnings("deprecation")
			public Object doInHibernate(Session session) throws HibernateException, SQLException {
				Sqlca sqlca = null;
				try {
					sqlca = new Sqlca(session.connection());
					StringBuffer sql=new StringBuffer();
					 sql.append( "update ap_approve_confirm_list set confirm_userid='" ).append( newConfirmUserid).append( "',auth_flag=").append(authFlag).append( " where confirm_userid='").append( confirmUserid).append( "' and confirm_flag = 0");
					//String sql = "update ap_approve_confirm_list set confirm_userid='" + newConfirmUserid + "',auth_flag=" + authFlag + " where confirm_userid='" + confirmUserid + "' and confirm_flag = 0";
					// if(authFlag != 1)
					// sql += " and auth_flag=1";
					log.debug(sql);
					sqlca.execute(sql.toString());
				} catch (Exception e) {

				} finally {
					if (sqlca != null) {
						sqlca.close();
					}
				}
				return null;
			}
		});
	}

	public void updateApprover(MtlApproveConfirmList approver) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			StringBuffer sql=new StringBuffer();
			//String sql = null;
			if (approver.getAuthFlag() != null && approver.getAuthFlag().shortValue() == 1) {
				sql.append( "update ap_approve_confirm_list set confirm_userid='").append( approver.getId().getConfirmUserid()).append( "',auth_flag=").append( approver.getAuthFlag()).append( " where campseg_id='").append( approver.getId().getCampsegId()).append( "' and approve_flow_id='")
					.append( approver.getId().getApproveFlowId()).append("' and approve_seq=").append( approver.getId().getApproveSeq()).append( " and approve_level=").append( approver.getId().getApproveLevel());
				//sql = "update ap_approve_confirm_list set confirm_userid='" + approver.getId().getConfirmUserid() + "',auth_flag=" + approver.getAuthFlag() + " where campseg_id='" + approver.getId().getCampsegId() + "' and approve_flow_id='"
				//		+ approver.getId().getApproveFlowId() + "' and approve_seq=" + approver.getId().getApproveSeq() + " and approve_level=" + approver.getId().getApproveLevel();
			} else {
				sql.append("update ap_approve_confirm_list set confirm_userid='").append(approver.getId().getConfirmUserid()).append( "',auth_flag=").append( approver.getAuthFlag()).append(" where campseg_id='").append( approver.getId().getCampsegId()).append("' and approve_flow_id='")
						.append( approver.getId().getApproveFlowId()).append( "' and approve_seq=").append( approver.getId().getApproveSeq()).append( " and approve_level=").append( approver.getId().getApproveLevel()).append(" and auth_flag=1");
				//sql = "update ap_approve_confirm_list set confirm_userid='" + approver.getId().getConfirmUserid() + "',auth_flag=" + approver.getAuthFlag() + " where campseg_id='" + approver.getId().getCampsegId() + "' and approve_flow_id='"
				//		+ approver.getId().getApproveFlowId() + "' and approve_seq=" + approver.getId().getApproveSeq() + " and approve_level=" + approver.getId().getApproveLevel() + " and auth_flag=1";
			}

			sqlca.execute(sql.toString());
		} catch (Exception e) {
log.error("",e);
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	public void updateByLevel(String authUserid, String consignorUserid, String campsegId, Short approveSeq, int authFlag) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			StringBuffer sql=new StringBuffer();
			//String sql = null;
			if (authFlag == 1) {
				sql.append("update ap_approve_confirm_list set confirm_userid='").append(consignorUserid).append( "',auth_flag=").append( authFlag).append(" where confirm_userid='").append( authUserid).append(  "' and campseg_id='").append(campsegId).append("' and approve_seq>").append(approveSeq);
				//sql = "update ap_approve_confirm_list set confirm_userid='" + consignorUserid + "',auth_flag=" + authFlag + " where confirm_userid='" + authUserid + "' and campseg_id='" + campsegId + "' and approve_seq>" + approveSeq;
			} else {
				sql.append("update ap_approve_confirm_list set confirm_userid='").append( consignorUserid).append("',auth_flag=").append(authFlag).append(" where confirm_userid='").append( authUserid).append("' and campseg_id='").append( campsegId).append( "' and approve_seq>").append( approveSeq).append(" and auth_flag=1");
				//sql = "update ap_approve_confirm_list set confirm_userid='" + consignorUserid + "',auth_flag=" + authFlag + " where confirm_userid='" + authUserid + "' and campseg_id='" + campsegId + "' and approve_seq>" + approveSeq + " and auth_flag=1";
			}
			sqlca.execute(sql.toString());
		} catch (Exception e) {
log.error("",e);
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}
	
	public List<MtlApproveConfirmAppoint> getApproveConfirmAppointList() throws Exception{
		return this.getHibernateTemplate().find(" from MtlApproveConfirmAppoint order by orderSeq ");
	}

	public void updateApprover(String campsegId, String userId, String delegrateUserId, String delegrateAdvise) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "update ap_approve_confirm_list set confirm_userid= '{delegrateUserId}', confirm_advice='{delegrateAdvise}' where confirm_userid = '{userId}' and campseg_id = '{campsegId}'";
			String execSql = sql.replace("{delegrateUserId}", delegrateUserId)
					            .replace("{delegrateAdvise}", delegrateAdvise)
					            .replace("{userId}", userId)
					            .replace("{campsegId}", campsegId);
			sqlca.execute(execSql);

			sqlca.execute(sql);
		} catch (Exception e) {
log.error("",e);
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

}

/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveConfirmListDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveConfirmAppoint;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveConfirmList;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveConfirmListId;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.impl.SessionImpl;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlApproveConfirmListDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlApproveConfirmListDao
/*     */ {
/*  34 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public void save(MtlApproveConfirmList svc)
/*     */     throws Exception
/*     */   {
/*  42 */     String sql = " from MtlApproveConfirmList mac where 1=1";
/*  43 */     if ((svc.getId().getResourceId() != null) && (svc.getId().getResourceId().intValue() > 0)) {
/*  44 */       sql = sql + " and mac.id.resourceId=" + svc.getId().getResourceId();
/*     */     }
/*  46 */     if ((svc.getId().getCampsegId() != null) && (svc.getId().getCampsegId().length() > 0)) {
/*  47 */       sql = sql + " and mac.id.campsegId='" + svc.getId().getCampsegId() + "'";
/*     */     }
/*  49 */     if ((svc.getId().getConfirmUserid() != null) && (svc.getId().getConfirmUserid().length() > 0)) {
/*  50 */       sql = sql + " and mac.id.confirmUserid='" + svc.getId().getConfirmUserid() + "'";
/*     */     }
/*  52 */     if (svc.getId().getApproveLevel() != null) {
/*  53 */       sql = sql + " and mac.id.approveLevel=" + svc.getId().getApproveLevel().shortValue();
/*     */     }
/*  55 */     if (svc.getId().getChannelNo() != null) {
/*  56 */       sql = sql + " and mac.id.channelNo=" + svc.getId().getChannelNo() + "";
/*     */     }
/*     */ 
/*  59 */     List list = getHibernateTemplate().find(sql);
/*  60 */     if (CollectionUtils.isEmpty(list)) {
/*  61 */       getHibernateTemplate().save(svc);
/*     */     } else {
/*  63 */       MtlApproveConfirmList svc1 = (MtlApproveConfirmList)list.get(0);
/*  64 */       svc1.setConfirmExplain(svc.getConfirmExplain());
/*  65 */       svc1.setForecastDate(svc.getForecastDate());
/*  66 */       svc1.setRemindDate(svc.getRemindDate());
/*  67 */       svc1.setConfirmFlag(Short.valueOf("0"));
/*  68 */       getHibernateTemplate().update(svc1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void update(MtlApproveConfirmList svc) throws Exception {
/*  73 */     getHibernateTemplate().update(svc);
/*     */   }
/*     */ 
/*     */   public void delete(MtlApproveConfirmList svc) throws Exception {
/*  77 */     getHibernateTemplate().delete(svc);
/*     */   }
/*     */ 
/*     */   public List findByCond(MtlApproveConfirmList searchCond) throws Exception {
/*     */     try {
/*  82 */       String sql = " from MtlApproveConfirmList mac where 1=1";
/*  83 */       if ((searchCond.getId().getResourceId() != null) && (searchCond.getId().getResourceId().intValue() > 0)) {
/*  84 */         sql = sql + " and mac.id.resourceId=" + searchCond.getId().getResourceId();
/*     */       }
/*  86 */       if ((searchCond.getId().getCampsegId() != null) && (searchCond.getId().getCampsegId().length() > 0)) {
/*  87 */         sql = sql + " and mac.id.campsegId='" + searchCond.getId().getCampsegId() + "'";
/*     */       }
/*  89 */       if ((searchCond.getId().getConfirmUserid() != null) && (searchCond.getId().getConfirmUserid().length() > 0)) {
/*  90 */         sql = sql + " and mac.id.confirmUserid='" + searchCond.getId().getConfirmUserid() + "'";
/*     */       }
/*  92 */       sql = sql + " order by mac.remindDate";
/*  93 */       return getHibernateTemplate().find(sql);
/*     */     } catch (Exception e) {
/*  95 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findById(String campsegId, String confirmFlag, String resourceId, String confirmUserid, String approveFlowId, Short approveSeq, Short approveLevel) throws Exception
/*     */   {
/*     */     try {
/* 102 */       String sql = " from MtlApproveConfirmList mac where 1=1 ";
/* 103 */       if ((resourceId != null) && (resourceId.length() > 0)) {
/* 104 */         sql = sql + " and mac.id.resourceId=" + resourceId;
/*     */       }
/* 106 */       if ((confirmFlag != null) && (confirmFlag.length() > 0)) {
/* 107 */         sql = sql + " and mac.confirmFlag in (" + confirmFlag + ")";
/*     */       }
/* 109 */       if ((campsegId != null) && (campsegId.length() > 0)) {
/* 110 */         sql = sql + " and mac.id.campsegId='" + campsegId + "'";
/*     */       }
/* 112 */       if ((confirmUserid != null) && (confirmUserid.length() > 0)) {
/* 113 */         sql = sql + " and mac.id.confirmUserid='" + confirmUserid + "'";
/*     */       }
/* 115 */       if ((approveFlowId != null) && (approveFlowId.length() > 0)) {
/* 116 */         sql = sql + " and mac.id.approveFlowId='" + approveFlowId + "'";
/*     */       }
/* 118 */       if (approveSeq != null) {
/* 119 */         sql = sql + " and mac.id.approveSeq=" + approveSeq;
/*     */       }
/* 121 */       if (approveLevel != null) {
/* 122 */         sql = sql + " and mac.id.approveLevel=" + approveLevel;
/*     */       }
/* 124 */       sql = sql + " order by mac.id.approveSeq,mac.id.resourceId,mac.id.confirmUserid";
/*     */ 
/* 126 */       return getHibernateTemplate().find(sql);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 130 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findCurrentById(String campsegId, String confirmFlag, String resourceId, String confirmUserid, String approveFlowId, Short approveSeq, Short approveLevel) throws Exception
/*     */   {
/*     */     try {
/* 137 */       String sql = " from MtlApproveConfirmList mac where 1=1 and mac.approveToken=1";
/* 138 */       if ((resourceId != null) && (resourceId.length() > 0)) {
/* 139 */         sql = sql + " and mac.id.resourceId=" + resourceId;
/*     */       }
/* 141 */       if ((confirmFlag != null) && (confirmFlag.length() > 0)) {
/* 142 */         sql = sql + " and mac.confirmFlag in (" + confirmFlag + ")";
/*     */       }
/* 144 */       if ((campsegId != null) && (campsegId.length() > 0)) {
/* 145 */         sql = sql + " and mac.id.campsegId='" + campsegId + "'";
/*     */       }
/* 147 */       if ((confirmUserid != null) && (confirmUserid.length() > 0)) {
/* 148 */         sql = sql + " and mac.id.confirmUserid='" + confirmUserid + "'";
/*     */       }
/* 150 */       if ((approveFlowId != null) && (approveFlowId.length() > 0)) {
/* 151 */         sql = sql + " and mac.id.approveFlowId='" + approveFlowId + "'";
/*     */       }
/* 153 */       if (approveSeq != null) {
/* 154 */         sql = sql + " and mac.id.approveSeq=" + approveSeq;
/*     */       }
/* 156 */       if (approveLevel != null) {
/* 157 */         sql = sql + " and mac.id.approveLevel=" + approveLevel;
/*     */       }
/* 159 */       sql = sql + " order by mac.id.approveSeq,mac.id.resourceId,mac.id.confirmUserid";
/*     */ 
/* 161 */       return getHibernateTemplate().find(sql);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 165 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findCampsegApprover(MtlApproveConfirmList approver) throws Exception {
/* 170 */     String sql = "from MtlApproveConfirmList mcal where 1=1 ";
/* 171 */     if ((approver.getId() != null) && (approver.getId().getApproveFlowId() != null)) {
/* 172 */       sql = sql + " and mcal.id.approveFlowId='" + approver.getId().getApproveFlowId() + "'";
/*     */     }
/* 174 */     if ((approver.getId() != null) && (approver.getId().getCampsegId() != null)) {
/* 175 */       sql = sql + " and mcal.id.campsegId='" + approver.getId().getCampsegId() + "'";
/*     */     }
/* 177 */     if ((approver.getId() != null) && (approver.getId().getResourceId() != null)) {
/* 178 */       sql = sql + " and mcal.id.resourceId=" + approver.getId().getResourceId();
/*     */     }
/*     */ 
/* 181 */     if (approver.getId().getConfirmUserid() != null) {
/* 182 */       sql = sql + " and mcal.id.confirmUserid='" + approver.getId().getConfirmUserid() + "'";
/*     */     }
/* 184 */     if (approver.getApproveToken() != null) {
/* 185 */       sql = sql + " and mcal.approveToken=" + approver.getApproveToken();
/*     */     }
/* 187 */     if ((approver.getId() != null) && (approver.getId().getApproveLevel() != null)) {
/* 188 */       sql = sql + " and mcal.id.approveLevel=" + approver.getId().getApproveLevel();
/*     */     }
/* 190 */     if ((approver.getId() != null) && (approver.getId().getApproveSeq() != null)) {
/* 191 */       sql = sql + " and mcal.id.approveSeq=" + approver.getId().getApproveSeq();
/*     */     }
/* 193 */     sql = sql + " order by mcal.id.approveSeq";
/*     */ 
/* 195 */     final String tmpSql = sql;
/* 196 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 198 */         Query query = s.createQuery(tmpSql);
/* 199 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public MtlApproveConfirmList getApproveConfirmList(String campsegId, String flowId, String userId, Integer resourceId, Short token) {
/* 205 */     String sql = "from MtlApproveConfirmList mcal where 1=1 ";
/* 206 */     if ((flowId != null) && (!"".equals(flowId))) {
/* 207 */       sql = sql + " and mcal.id.approveFlowId='" + flowId + "'";
/*     */     }
/* 209 */     if ((campsegId != null) && (!"".equals(campsegId))) {
/* 210 */       sql = sql + " and mcal.id.campsegId='" + campsegId + "'";
/*     */     }
/* 212 */     if (resourceId != null) {
/* 213 */       sql = sql + " and mcal.id.resourceId=" + resourceId;
/*     */     }
/*     */ 
/* 216 */     if (userId != null) {
/* 217 */       sql = sql + " and mcal.id.confirmUserid='" + userId + "'";
/*     */     }
/* 219 */     if (token != null) {
/* 220 */       sql = sql + " and mcal.approveToken=" + token;
/*     */     }
/* 222 */     sql = sql + " order by mcal.id.approveSeq";
/*     */ 
/* 224 */     final String tmpSql = sql;
/* 225 */     List list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 227 */         Query query = s.createQuery(tmpSql);
/* 228 */         return query.list();
/*     */       }
/*     */     });
/* 232 */     if ((list != null) && (!list.isEmpty())) {
/* 233 */       return (MtlApproveConfirmList)list.get(0);
/*     */     }
/*     */ 
/* 236 */     return null;
/*     */   }
/*     */ 
/*     */   public void updateCampsegConfirmToken(String approveFlowId, String campsegId, String confirmUserId, Short seq, Short token, Integer resourceId) throws Exception
/*     */   {
/* 241 */     Sqlca sqlca = null;
/*     */     try {
/* 243 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 244 */       StringBuffer sql = new StringBuffer();
/* 245 */       sql.append("update ap_approve_confirm_list set approve_token=").append(token).append(" where 1=1 ");
/*     */ 
/* 248 */       if ((approveFlowId != null) && (approveFlowId.length() > 0)) {
/* 249 */         sql.append(" and approve_flow_id='").append(approveFlowId).append("'");
/*     */       }
/*     */ 
/* 252 */       if ((campsegId != null) && (campsegId.length() > 0))
/*     */       {
/* 254 */         sql.append(" and campseg_id='").append(campsegId).append("'");
/*     */       }
/* 256 */       if (resourceId != null) {
/* 257 */         sql.append(" and resource_id=").append(resourceId);
/*     */       }
/*     */ 
/* 260 */       if ((confirmUserId != null) && (confirmUserId.length() > 0)) {
/* 261 */         sql.append(" and confirm_userid='").append(confirmUserId).append("'");
/*     */       }
/* 263 */       if ((seq != null) && (seq.shortValue() > 0)) {
/* 264 */         sql.append(" and APPROVE_SEQ=").append(seq);
/*     */       }
/*     */ 
/* 267 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 269 */       throw e;
/*     */     } finally {
/* 271 */       if (sqlca != null)
/* 272 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public MtlApproveConfirmList getFirstApprover(String campsegId, String flowId, Integer resourceId)
/*     */   {
/* 278 */     String sql = "from MtlApproveConfirmList mcal where 1=1 ";
/* 279 */     if (flowId != null) {
/* 280 */       sql = sql + " and mcal.id.approveFlowId='" + flowId + "'";
/*     */     }
/* 282 */     if (campsegId != null) {
/* 283 */       sql = sql + " and mcal.id.campsegId='" + campsegId + "'";
/*     */     }
/* 285 */     if (resourceId != null) {
/* 286 */       sql = sql + " and mcal.id.resourceId=" + resourceId;
/*     */     }
/*     */ 
/* 289 */     sql = sql + " order by mcal.id.approveSeq";
/*     */ 
/* 291 */     final String tmpSql = sql;
/* 292 */     List list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 294 */         Query query = s.createQuery(tmpSql);
/* 295 */         return query.list();
/*     */       }
/*     */     });
/* 299 */     if ((list != null) && (!list.isEmpty())) {
/* 300 */       return (MtlApproveConfirmList)list.get(0);
/*     */     }
/*     */ 
/* 303 */     return null;
/*     */   }
/*     */ 
/*     */   public void updateCampsegConfirmFlag(String campsegId, Integer resourceId, String confirmFlag) throws Exception
/*     */   {
/* 308 */     if ((StringUtil.isEmpty(campsegId)) || (StringUtil.isEmpty(resourceId))) {
/* 309 */       return;
/*     */     }
/* 311 */     Sqlca sqlca = null;
/*     */     try {
/* 313 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 314 */       StringBuffer sql = new StringBuffer();
/* 315 */       sql.append("update ap_approve_confirm_list set confirm_flag =").append(confirmFlag).append(" where campseg_id='").append(campsegId).append("' and resource_id=").append(resourceId);
/*     */ 
/* 319 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 321 */       throw e;
/*     */     } finally {
/* 323 */       if (sqlca != null)
/* 324 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findByFlag(String flag) throws Exception
/*     */   {
/*     */     try {
/* 331 */       String sql = " from MtlApproveConfirmList mac where mac.confirmFlag=" + flag + " and mac.approveToken = 1";
/* 332 */       return getHibernateTemplate().find(sql);
/*     */     } catch (Exception e) {
/* 334 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findByCampsegIdUserId(String campsegId, String userId) {
/* 339 */     String sql = "from MtlApproveConfirmList mac where mac.approveToken = 1 and mac.campsegRootid= ? and mac.id.confirmUserid = ? ";
/* 340 */     return getHibernateTemplate().find(sql, new Object[] { campsegId, userId });
/*     */   }
/*     */ 
/*     */   public List findByFlagGroupByUser(String flag) throws Exception
/*     */   {
/*     */     try {
/* 346 */       String sql = " from MtlApproveConfirmList mac where mac.confirmFlag=" + flag + " group by mac.confirmUserid";
/* 347 */       return getHibernateTemplate().find(sql);
/*     */     } catch (Exception e) {
/* 349 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findByUserFlag(String confirmUserid) throws Exception {
/* 354 */     List list = getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1 and mcl.id.confirmUserid='" + confirmUserid + "' and mcl.confirmFlag=0 and mcl.approveToken = 1");
/*     */ 
/* 356 */     return list;
/*     */   }
/*     */ 
/*     */   public List findConfirmedByUserFlag(String confirmUserid) throws Exception
/*     */   {
/* 361 */     StringBuffer sqlBuffer = new StringBuffer();
/* 362 */     sqlBuffer.append("select mcl.id.campsegId,mcl.forecastDate,mcl.id.confirmUserid,mcl.id.resourceId from MtlApproveConfirmList mcl where 1=1").append(" and mcl.id.confirmUserid='").append(confirmUserid).append("' and mcl.confirmFlag in(1,2) ");
/* 363 */     List list = getHibernateTemplate().find(sqlBuffer.toString());
/*     */ 
/* 366 */     for (int i = 0; i < list.size(); i++) {
/* 367 */       Object[] obj = (Object[])list.get(i);
/*     */ 
/* 369 */       List list2 = getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1 and mcl.id.confirmUserid='" + (String)obj[2] + "'" + " and mcl.id.campsegId='" + (String)obj[0] + "'" + " and mcl.confirmFlag=0");
/*     */ 
/* 371 */       if (list2.size() > 0) {
/* 372 */         list.remove(i);
/* 373 */         i--;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 378 */     return list;
/*     */   }
/*     */ 
/*     */   public void deleteByCampsegid(String campsegId) throws Exception {
/* 382 */     String sql = " from MtlApproveConfirmList mcl where 1=1 and mcl.id.campsegId='" + campsegId + "'";
/* 383 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/* 384 */     getSession().flush();
/*     */   }
/*     */ 
/*     */   public String checkConfirmEnd(String campsegId) throws Exception
/*     */   {
/* 389 */     List list = getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1 and mcl.id.campsegId='" + campsegId + "' and mcl.confirmFlag = 2 ");
/* 390 */     if (list.size() > 0) {
/* 391 */       return "notPassed";
/*     */     }
/*     */ 
/* 395 */     list = getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1 and mcl.id.campsegId='" + campsegId + "' and mcl.confirmFlag in(0,2,9) ");
/* 396 */     if (list.size() <= 0) {
/* 397 */       return "yes";
/*     */     }
/*     */ 
/* 400 */     list = getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1 and mcl.id.campsegId='" + campsegId + "' and mcl.confirmFlag =0");
/* 401 */     if (list.size() > 0) {
/* 402 */       return "notFinished";
/*     */     }
/* 404 */     return "";
/*     */   }
/*     */ 
/*     */   public String checkConfirmAllFinished(String campsegRootid)
/*     */   {
/* 410 */     List list = getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1 and mcl.campsegRootid='" + campsegRootid + "' and mcl.confirmFlag = 2");
/* 411 */     if (list.size() > 0) {
/* 412 */       return "notPassed";
/*     */     }
/*     */ 
/* 415 */     list = getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1 and mcl.campsegRootid='" + campsegRootid + "' and mcl.confirmFlag in(0,2,9) ");
/* 416 */     if (list.size() <= 0) {
/* 417 */       return "yes";
/*     */     }
/*     */ 
/* 420 */     list = getHibernateTemplate().find(" from MtlApproveConfirmList mcl where 1=1 and mcl.campsegRootid='" + campsegRootid + "' and mcl.confirmFlag =0");
/* 421 */     if (list.size() > 0) {
/* 422 */       return "notFinished";
/*     */     }
/* 424 */     return "";
/*     */   }
/*     */ 
/*     */   public String checkConfirmEnd(String campsegId, String userid, Integer resourceId)
/*     */     throws Exception
/*     */   {
/* 430 */     String sql = " from MtlApproveConfirmList mcl where 1=1 and mcl.id.campsegId='" + campsegId + "' and mcl.id.confirmUserid='" + userid + "'";
/* 431 */     if (resourceId != null) {
/* 432 */       sql = sql + " and mcl.id.resourceId=" + resourceId;
/*     */     }
/* 434 */     sql = sql + " and mcl.confirmFlag =0";
/* 435 */     List list = getHibernateTemplate().find(sql);
/* 436 */     if (list.size() > 0) {
/* 437 */       return "notFinished";
/*     */     }
/* 439 */     return "confirmed";
/*     */   }
/*     */ 
/*     */   public boolean checkConfirmFailed(String campsegId, Integer resourceId)
/*     */     throws Exception
/*     */   {
/* 446 */     String sql = " from MtlApproveConfirmList mcl where 1=1 and mcl.id.campsegId='" + campsegId + "'";
/*     */ 
/* 448 */     if (resourceId != null) {
/* 449 */       sql = sql + " and mcl.id.resourceId=" + resourceId;
/*     */     }
/* 451 */     sql = sql + " and mcl.confirmFlag =2";
/* 452 */     List list = getHibernateTemplate().find(sql);
/* 453 */     if (list.size() > 0) {
/* 454 */       return true;
/*     */     }
/* 456 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean checkConfirmFinished(String campsegId, Short resourceId, int confirmFlag)
/*     */     throws Exception
/*     */   {
/* 462 */     String sql = " from MtlApproveConfirmList mcl where 1=1 and mcl.id.campsegId='" + campsegId + "'";
/* 463 */     if (resourceId != null) {
/* 464 */       sql = sql + " and mcl.id.resourceId=" + resourceId;
/*     */     }
/* 466 */     sql = sql + " and mcl.confirmFlag !=" + confirmFlag;
/* 467 */     List list = getHibernateTemplate().find(sql);
/* 468 */     if (list.size() > 0) {
/* 469 */       return false;
/*     */     }
/* 471 */     return true;
/*     */   }
/*     */ 
/*     */   public void updateConfirmUserId(final String confirmUserid, final String newConfirmUserid, final int authFlag)
/*     */     throws Exception
/*     */   {
/* 477 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/* 480 */         Sqlca sqlca = null;
/*     */         try {
/* 482 */           sqlca = new Sqlca(session.connection());
/* 483 */           StringBuffer sql = new StringBuffer();
/* 484 */           sql.append("update ap_approve_confirm_list set confirm_userid='").append(newConfirmUserid).append("',auth_flag=").append(authFlag).append(" where confirm_userid='").append(confirmUserid).append("' and confirm_flag = 0");
/*     */ 
/* 488 */           MtlApproveConfirmListDaoImpl.log.debug(sql);
/* 489 */           sqlca.execute(sql.toString());
/*     */         } catch (Exception e) {
/*     */         }
/*     */         finally {
/* 493 */           if (sqlca != null) {
/* 494 */             sqlca.close();
/*     */           }
/*     */         }
/* 497 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void updateApprover(MtlApproveConfirmList approver) throws Exception {
/* 503 */     Sqlca sqlca = null;
/*     */     try {
/* 505 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 506 */       StringBuffer sql = new StringBuffer();
/*     */ 
/* 508 */       if ((approver.getAuthFlag() != null) && (approver.getAuthFlag().shortValue() == 1)) {
/* 509 */         sql.append("update ap_approve_confirm_list set confirm_userid='").append(approver.getId().getConfirmUserid()).append("',auth_flag=").append(approver.getAuthFlag()).append(" where campseg_id='").append(approver.getId().getCampsegId()).append("' and approve_flow_id='").append(approver.getId().getApproveFlowId()).append("' and approve_seq=").append(approver.getId().getApproveSeq()).append(" and approve_level=").append(approver.getId().getApproveLevel());
/*     */       }
/*     */       else
/*     */       {
/* 514 */         sql.append("update ap_approve_confirm_list set confirm_userid='").append(approver.getId().getConfirmUserid()).append("',auth_flag=").append(approver.getAuthFlag()).append(" where campseg_id='").append(approver.getId().getCampsegId()).append("' and approve_flow_id='").append(approver.getId().getApproveFlowId()).append("' and approve_seq=").append(approver.getId().getApproveSeq()).append(" and approve_level=").append(approver.getId().getApproveLevel()).append(" and auth_flag=1");
/*     */       }
/*     */ 
/* 520 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 522 */       log.error("", e);
/*     */     } finally {
/* 524 */       if (sqlca != null)
/* 525 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateByLevel(String authUserid, String consignorUserid, String campsegId, Short approveSeq, int authFlag) throws Exception
/*     */   {
/* 531 */     Sqlca sqlca = null;
/*     */     try {
/* 533 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 534 */       StringBuffer sql = new StringBuffer();
/*     */ 
/* 536 */       if (authFlag == 1) {
/* 537 */         sql.append("update ap_approve_confirm_list set confirm_userid='").append(consignorUserid).append("',auth_flag=").append(authFlag).append(" where confirm_userid='").append(authUserid).append("' and campseg_id='").append(campsegId).append("' and approve_seq>").append(approveSeq);
/*     */       }
/*     */       else {
/* 540 */         sql.append("update ap_approve_confirm_list set confirm_userid='").append(consignorUserid).append("',auth_flag=").append(authFlag).append(" where confirm_userid='").append(authUserid).append("' and campseg_id='").append(campsegId).append("' and approve_seq>").append(approveSeq).append(" and auth_flag=1");
/*     */       }
/*     */ 
/* 543 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 545 */       log.error("", e);
/*     */     } finally {
/* 547 */       if (sqlca != null)
/* 548 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<MtlApproveConfirmAppoint> getApproveConfirmAppointList() throws Exception
/*     */   {
/* 554 */     return getHibernateTemplate().find(" from MtlApproveConfirmAppoint order by orderSeq ");
/*     */   }
/*     */ 
/*     */   public void updateApprover(String campsegId, String userId, String delegrateUserId, String delegrateAdvise) throws Exception {
/* 558 */     Sqlca sqlca = null;
/*     */     try {
/* 560 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 561 */       String sql = "update ap_approve_confirm_list set confirm_userid= '{delegrateUserId}', confirm_advice='{delegrateAdvise}' where confirm_userid = '{userId}' and campseg_id = '{campsegId}'";
/* 562 */       String execSql = sql.replace("{delegrateUserId}", delegrateUserId).replace("{delegrateAdvise}", delegrateAdvise).replace("{userId}", userId).replace("{campsegId}", campsegId);
/*     */ 
/* 566 */       sqlca.execute(execSql);
/*     */ 
/* 568 */       sqlca.execute(sql);
/*     */     } catch (Exception e) {
/* 570 */       log.error("", e);
/*     */     } finally {
/* 572 */       if (sqlca != null)
/* 573 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlApproveConfirmListDaoImpl
 * JD-Core Version:    0.6.2
 */
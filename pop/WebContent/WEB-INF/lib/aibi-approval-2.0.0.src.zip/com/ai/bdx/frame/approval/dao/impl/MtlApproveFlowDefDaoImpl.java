package com.ai.bdx.frame.approval.dao.impl;


import java.io.Serializable;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao;
import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDef;

/**
 * Created on Apr 26, 2007 3:12:34 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlApproveFlowDefDaoImpl extends HibernateDaoSupport implements IMtlApproveFlowDefDao {

	public List getAllApproveFlowDef() throws Exception {
		String sql = "from MtlApproveFlowDef maf where 1=1 order by maf.approveFlowName";
		//Query query = this.getSession().createQuery(sql);
		//return query.list();
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	public List getAllApproveFlowDef(String userid) throws Exception {
		String sql = "from MtlApproveFlowDef maf where maf.createUserid='" + userid + "' or maf.approveFlowAccessToken=1 order by maf.approveFlowName";
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao#deleteApproveFlowDef(java.lang.String)
	 */
	public void deleteApproveFlowDef(String approveFlowId) throws Exception {
		String sql = "from MtlApproveFlowDef maf where maf.approveFlowId='" + approveFlowId + "'";
		List<?> list=this.getHibernateTemplate().find(sql);
		if(list!=null&&list.size()>0){
			this.getHibernateTemplate().deleteAll(list);
		}
		
		
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao#findApproveFlow(com.ai.bdx.frame.approval.model.MtlApproveFlowDef, java.lang.Integer, java.lang.Integer)
	 */
	public Map findApproveFlow(MtlApproveFlowDef searchCond, Integer curPage, Integer pageSize) throws Exception {
		String sql = "from MtlApproveFlowDef maf where 1=1 ";
		if (searchCond!=null&&searchCond.getApproveFlowName() != null && searchCond.getApproveFlowName().length() > 0)
			sql += " and maf.approveFlowName like '%" + searchCond.getApproveFlowName() + "%'";
		if (searchCond.getCreateUserid() != null && searchCond.getCreateUserid().length() > 0)
			sql += " and (maf.createUserid='" + searchCond.getCreateUserid() + "' or maf.approveFlowAccessToken=1)";
			sql += " order by maf.approveFlowName";
		//		Query query = this.getSession().createQuery(sql);
		//		int totalCnt = query.list().size();
		//log.debug(">>curpage: " + curpage.intValue() + ", pagesize: " + pagesize.intValue());
		//		query.setFirstResult((curPage.intValue()) * pageSize.intValue());
		//		query.setMaxResults((curPage.intValue() + 1) * pageSize.intValue());
		Map map = new HashMap();
		final String tmpSql = sql;
		final Integer tmpPage = curPage, tmpSize = pageSize;
		List list = getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);

				int totalCnt = query.list().size();
				query.setFirstResult((tmpPage.intValue()) * tmpSize.intValue());
				query.setMaxResults((tmpPage.intValue() + 1) * tmpSize.intValue());
				List tmpList = query.list();
				//				MtlApproveFlowDef flow;
				//				for (int i = 0; i < tmpList.size(); i++) {
				//					flow = (MtlApproveFlowDef)tmpList.get(i);
				//					flow.getApproveFlowLevels().iterator();
				//				}
				tmpList.add(Integer.valueOf(totalCnt));
				return tmpList;
			}
		});
		Integer totalCnt = (Integer) list.get(list.size() - 1);
		list.remove(list.size() - 1);
		map.put("total", totalCnt);
		map.put("result", list);
		return map;
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao#getApproveFlowDef(java.lang.String)
	 */
	public MtlApproveFlowDef getApproveFlowDef(String approveFlowId) throws Exception {
		return (MtlApproveFlowDef) this.getHibernateTemplate().get(MtlApproveFlowDef.class, approveFlowId);
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao#saveApproveFlowDef(com.ai.bdx.frame.approval.model.MtlApproveFlowDef)
	 */
	public Serializable saveApproveFlowDef(MtlApproveFlowDef def) throws Exception {
		return this.getHibernateTemplate().save(def);
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao#updateApproveFlowDef(com.ai.bdx.frame.approval.model.MtlApproveFlowDef)
	 */
	public void updateApproveFlowDef(MtlApproveFlowDef def) throws Exception {
		this.getHibernateTemplate().update(def);
	}

	public MtlApproveFlowDef getApproveFlowDefWithAllChilds(String approveFlowId) throws Exception {
		MtlApproveFlowDef obj = (MtlApproveFlowDef) this.getHibernateTemplate().get(MtlApproveFlowDef.class, approveFlowId);
		if (obj != null) {
			Iterator it = obj.getApproveFlowLevels().iterator();
			Iterator it2;
			MtlApproveLevelDef level;
			MtlApproveTriggerCondDef cond;
			while (it.hasNext()) {
				level = (MtlApproveLevelDef) it.next();
				it2 = level.getApproveFlowLevelConds().iterator();
				while (it2.hasNext()) {
					cond = (MtlApproveTriggerCondDef) it2.next();
				}
			}
		}
		return obj;
	}
	
	public List getFirstApproveUser(String deptId) throws Exception {
		// TODO Auto-generated method stub
		String sql = "from MtlApproveFlowDef where deptId = '"+deptId+"'";
		return this.getHibernateTemplate().find(sql);
	}
}

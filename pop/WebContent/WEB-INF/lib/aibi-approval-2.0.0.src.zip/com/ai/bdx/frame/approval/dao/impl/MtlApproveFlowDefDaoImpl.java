/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDef;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlApproveFlowDefDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlApproveFlowDefDao
/*     */ {
/*     */   public List getAllApproveFlowDef()
/*     */     throws Exception
/*     */   {
/*  36 */     String sql = "from MtlApproveFlowDef maf where 1=1 order by maf.approveFlowName";
/*     */ 
/*  39 */     final String tmpSql = sql;
/*  40 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  42 */         Query query = s.createQuery(tmpSql);
/*  43 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List getAllApproveFlowDef(String userid) throws Exception {
/*  49 */     String sql = "from MtlApproveFlowDef maf where maf.createUserid='" + userid + "' or maf.approveFlowAccessToken=1 order by maf.approveFlowName";
/*  50 */     final String tmpSql = sql;
/*  51 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  53 */         Query query = s.createQuery(tmpSql);
/*  54 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void deleteApproveFlowDef(String approveFlowId)
/*     */     throws Exception
/*     */   {
/*  63 */     String sql = "from MtlApproveFlowDef maf where maf.approveFlowId='" + approveFlowId + "'";
/*  64 */     List list = getHibernateTemplate().find(sql);
/*  65 */     if ((list != null) && (list.size() > 0))
/*  66 */       getHibernateTemplate().deleteAll(list);
/*     */   }
/*     */ 
/*     */   public Map findApproveFlow(MtlApproveFlowDef searchCond, Integer curPage, Integer pageSize)
/*     */     throws Exception
/*     */   {
/*  76 */     String sql = "from MtlApproveFlowDef maf where 1=1 ";
/*  77 */     if ((searchCond != null) && (searchCond.getApproveFlowName() != null) && (searchCond.getApproveFlowName().length() > 0))
/*  78 */       sql = sql + " and maf.approveFlowName like '%" + searchCond.getApproveFlowName() + "%'";
/*  79 */     if ((searchCond.getCreateUserid() != null) && (searchCond.getCreateUserid().length() > 0))
/*  80 */       sql = sql + " and (maf.createUserid='" + searchCond.getCreateUserid() + "' or maf.approveFlowAccessToken=1)";
/*  81 */     sql = sql + " order by maf.approveFlowName";
/*     */ 
/*  87 */     Map map = new HashMap();
/*  88 */     final String tmpSql = sql;
/*  89 */     final Integer tmpPage = curPage; final Integer tmpSize = pageSize;
/*  90 */     List list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  92 */         Query query = s.createQuery(tmpSql);
/*     */ 
/*  94 */         int totalCnt = query.list().size();
/*  95 */         query.setFirstResult(tmpPage.intValue() * tmpSize.intValue());
/*  96 */         query.setMaxResults((tmpPage.intValue() + 1) * tmpSize.intValue());
/*  97 */         List tmpList = query.list();
/*     */ 
/* 103 */         tmpList.add(Integer.valueOf(totalCnt));
/* 104 */         return tmpList;
/*     */       }
/*     */     });
/* 107 */     Integer totalCnt = (Integer)list.get(list.size() - 1);
/* 108 */     list.remove(list.size() - 1);
/* 109 */     map.put("total", totalCnt);
/* 110 */     map.put("result", list);
/* 111 */     return map;
/*     */   }
/*     */ 
/*     */   public MtlApproveFlowDef getApproveFlowDef(String approveFlowId)
/*     */     throws Exception
/*     */   {
/* 118 */     return (MtlApproveFlowDef)getHibernateTemplate().get(MtlApproveFlowDef.class, approveFlowId);
/*     */   }
/*     */ 
/*     */   public Serializable saveApproveFlowDef(MtlApproveFlowDef def)
/*     */     throws Exception
/*     */   {
/* 125 */     return getHibernateTemplate().save(def);
/*     */   }
/*     */ 
/*     */   public void updateApproveFlowDef(MtlApproveFlowDef def)
/*     */     throws Exception
/*     */   {
/* 132 */     getHibernateTemplate().update(def);
/*     */   }
/*     */ 
/*     */   public MtlApproveFlowDef getApproveFlowDefWithAllChilds(String approveFlowId) throws Exception {
/* 136 */     MtlApproveFlowDef obj = (MtlApproveFlowDef)getHibernateTemplate().get(MtlApproveFlowDef.class, approveFlowId);
/* 137 */     if (obj != null) {
/* 138 */       Iterator it = obj.getApproveFlowLevels().iterator();
/*     */ 
/* 142 */       while (it.hasNext()) {
/* 143 */         MtlApproveLevelDef level = (MtlApproveLevelDef)it.next();
/* 144 */         Iterator it2 = level.getApproveFlowLevelConds().iterator();
/*     */         MtlApproveTriggerCondDef cond;
/* 145 */         while (it2.hasNext()) {
/* 146 */           cond = (MtlApproveTriggerCondDef)it2.next();
/*     */         }
/*     */       }
/*     */     }
/* 150 */     return obj;
/*     */   }
/*     */ 
/*     */   public List getFirstApproveUser(String deptId) throws Exception
/*     */   {
/* 155 */     String sql = "from MtlApproveFlowDef where deptId = '" + deptId + "'";
/* 156 */     return getHibernateTemplate().find(sql);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlApproveFlowDefDaoImpl
 * JD-Core Version:    0.6.2
 */
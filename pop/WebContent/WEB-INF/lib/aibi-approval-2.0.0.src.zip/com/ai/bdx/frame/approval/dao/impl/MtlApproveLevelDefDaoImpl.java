package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.impl.SessionImpl;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao;
import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
import com.ai.bdx.frame.approval.model.MtlApproveLevelDefId;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;

/**
 * Created on Apr 27, 2007 4:31:39 PM
 *
 * <p>
 * Title:
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: asiainfo.,Ltd
 * </p>
 * 
 * @author weilin.wu wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlApproveLevelDefDaoImpl extends HibernateDaoSupport implements
		IMtlApproveLevelDefDao {
	public static Logger log = LogManager.getLogger();

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao#deleteApproveLevelDef
	 * (java.lang.String, java.lang.Integer)
	 */
	public void deleteApproveLevelDef(MtlApproveLevelDefId id) throws Exception {
		String sql = "from MtlApproveLevelDef mald where mald.id.approveLevel="
				+ id.getApproveLevel() + " and mald.id.approveFlowId='"
				+ id.getApproveFlowId() + "'";
		this.getHibernateTemplate().deleteAll(
				this.getHibernateTemplate().find(sql));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao#
	 * deleteApproveLevelDefByFlow(java.lang.String)
	 */
	public void deleteApproveLevelDefByFlow(String flowId) throws Exception {
		String sql = "from MtlApproveLevelDef mald where mald.id.approveFlowId='"
				+ flowId + "'";
		List l=this.getHibernateTemplate().find(sql);
		if(l!=null&&l.size()>0){
			this.getHibernateTemplate().deleteAll(l);
		}
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao#getApproveLevelDef
	 * (java.lang.String, java.lang.Integer)
	 */
	public MtlApproveLevelDef getApproveLevelDef(MtlApproveLevelDefId id)
			throws Exception {
		return (MtlApproveLevelDef) this.getHibernateTemplate().get(
				MtlApproveLevelDef.class, id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao#getApproveLevelDefByFlow
	 * (java.lang.String)
	 */
	public List getApproveLevelDefByFlow(String flowId) throws Exception {
		String sql = "from MtlApproveLevelDef mald where mald.id.approveFlowId='"
				+ flowId + "' order by mald.id.approveLevel";
		// Query query = this.getSession().createQuery(sql);
		// return query.list();
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao#saveApproveLevelDef
	 * (com.ai.bdx.frame.approval.model.MtlApproveLevelDef)
	 */
	public void saveApproveLevelDef(MtlApproveLevelDef def) throws Exception {
		// mod by caolifeng 20100611
		if (def.getAuthFlag() == null) {
			def.setAuthFlag(0);
		}
		this.getHibernateTemplate().save(def);
	}

	public void updateApproveLevelDef(String authUserid,
			String consignorUserid, int authFlag) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl) this.getSession()).connection());
			// String sql = null;
			StringBuffer sql = new StringBuffer();
			if (authFlag == 1) {
				sql.append("update ap_approve_level_def set approve_obj_id='")
						.append(consignorUserid).append("',auth_flag=")
						.append(authFlag).append(" where approve_obj_id='")
						.append(authUserid).append("' and approve_obj_type=")
						.append(MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER);
				// sql = "update ap_approve_level_def set approve_obj_id='" +
				// consignorUserid + "',auth_flag=" + authFlag +
				// " where approve_obj_id='" + authUserid +
				// "' and approve_obj_type=" +
				// MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER;
			} else {
				sql.append("update ap_approve_level_def set approve_obj_id='")
						.append(consignorUserid).append("',auth_flag=")
						.append(authFlag).append(" where approve_obj_id='")
						.append(authUserid).append("' and approve_obj_type=")
						.append(MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER)
						.append(" and auth_flag=1");
				// sql = "update ap_approve_level_def set approve_obj_id='" +
				// consignorUserid + "',auth_flag=" + authFlag +
				// " where approve_obj_id='" + authUserid +
				// "' and approve_obj_type=" +
				// MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER +
				// " and auth_flag=1";
			}
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}
}

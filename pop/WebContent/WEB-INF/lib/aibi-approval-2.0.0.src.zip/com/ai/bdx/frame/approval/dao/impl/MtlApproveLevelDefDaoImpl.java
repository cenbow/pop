/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveLevelDefId;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.impl.SessionImpl;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlApproveLevelDefDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlApproveLevelDefDao
/*     */ {
/*  42 */   public static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public void deleteApproveLevelDef(MtlApproveLevelDefId id)
/*     */     throws Exception
/*     */   {
/*  52 */     String sql = "from MtlApproveLevelDef mald where mald.id.approveLevel=" + id.getApproveLevel() + " and mald.id.approveFlowId='" + id.getApproveFlowId() + "'";
/*     */ 
/*  55 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ 
/*     */   public void deleteApproveLevelDefByFlow(String flowId)
/*     */     throws Exception
/*     */   {
/*  66 */     String sql = "from MtlApproveLevelDef mald where mald.id.approveFlowId='" + flowId + "'";
/*     */ 
/*  68 */     List l = getHibernateTemplate().find(sql);
/*  69 */     if ((l != null) && (l.size() > 0))
/*  70 */       getHibernateTemplate().deleteAll(l);
/*     */   }
/*     */ 
/*     */   public MtlApproveLevelDef getApproveLevelDef(MtlApproveLevelDefId id)
/*     */     throws Exception
/*     */   {
/*  84 */     return (MtlApproveLevelDef)getHibernateTemplate().get(MtlApproveLevelDef.class, id);
/*     */   }
/*     */ 
/*     */   public List getApproveLevelDefByFlow(String flowId)
/*     */     throws Exception
/*     */   {
/*  96 */     String sql = "from MtlApproveLevelDef mald where mald.id.approveFlowId='" + flowId + "' order by mald.id.approveLevel";
/*     */ 
/* 100 */     final String tmpSql = sql;
/* 101 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 104 */         Query query = s.createQuery(tmpSql);
/* 105 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void saveApproveLevelDef(MtlApproveLevelDef def)
/*     */     throws Exception
/*     */   {
/* 119 */     if (def.getAuthFlag() == null) {
/* 120 */       def.setAuthFlag(Integer.valueOf(0));
/*     */     }
/* 122 */     getHibernateTemplate().save(def);
/*     */   }
/*     */ 
/*     */   public void updateApproveLevelDef(String authUserid, String consignorUserid, int authFlag) throws Exception
/*     */   {
/* 127 */     Sqlca sqlca = null;
/*     */     try {
/* 129 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/*     */ 
/* 131 */       StringBuffer sql = new StringBuffer();
/* 132 */       if (authFlag == 1) {
/* 133 */         sql.append("update ap_approve_level_def set approve_obj_id='").append(consignorUserid).append("',auth_flag=").append(authFlag).append(" where approve_obj_id='").append(authUserid).append("' and approve_obj_type=").append(3);
/*     */       }
/*     */       else
/*     */       {
/* 144 */         sql.append("update ap_approve_level_def set approve_obj_id='").append(consignorUserid).append("',auth_flag=").append(authFlag).append(" where approve_obj_id='").append(authUserid).append("' and approve_obj_type=").append(3).append(" and auth_flag=1");
/*     */       }
/*     */ 
/* 157 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 159 */       log.error("", e);
/*     */     } finally {
/* 161 */       if (sqlca != null)
/* 162 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlApproveLevelDefDaoImpl
 * JD-Core Version:    0.6.2
 */
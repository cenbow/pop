/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveResourceTypeDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.form.MtlApproveResourceTypeForm;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveResourceType;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlApproveResourceTypeDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlApproveResourceTypeDao
/*     */ {
/*  33 */   public static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public List findAll()
/*     */     throws Exception
/*     */   {
/*  40 */     return getHibernateTemplate().find("from MtlApproveResourceType a order by a.resourceId desc");
/*     */   }
/*     */ 
/*     */   public List findByFlag(short resourceFlag) throws Exception {
/*  44 */     return getHibernateTemplate().find("from MtlApproveResourceType a where a.resourceFlag = " + resourceFlag + " order by a.resourceId");
/*     */   }
/*     */ 
/*     */   public List findFlag(Integer resourceId) throws Exception {
/*  48 */     StringBuffer sqlBuffer = new StringBuffer();
/*  49 */     sqlBuffer.append("select a.resourceFlag from MtlApproveResourceType a where a.resourceId= ").append(resourceId);
/*  50 */     return getHibernateTemplate().find(sqlBuffer.toString());
/*     */   }
/*     */ 
/*     */   public MtlApproveResourceType getRourceById(Integer resourceId)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  65 */       return (MtlApproveResourceType)getHibernateTemplate().get(MtlApproveResourceType.class, resourceId);
/*     */     } catch (Exception ex) {
/*  67 */       log.error("", ex);
/*  68 */     }return null;
/*     */   }
/*     */ 
/*     */   public MtlApproveResourceType getRourceByName(String resourceName) throws Exception
/*     */   {
/*     */     try {
/*  74 */       MtlApproveResourceType mtlApproveResourceType = null;
/*  75 */       String sql = "from  MtlApproveResourceType a where a.resourceName='" + resourceName + "'";
/*     */ 
/*  77 */       List list = getHibernateTemplate().find(sql);
/*  78 */       if (list.size() > 0);
/*  79 */       return (MtlApproveResourceType)list.get(0);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  83 */       log.error("", ex);
/*  84 */     }return null;
/*     */   }
/*     */ 
/*     */   public Map searchMtlApproveResourceType(MtlApproveResourceTypeForm resourceForm, final Integer curPage, final Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*  90 */     String sql = "from  MtlApproveResourceType a where 1=1 ";
/*  91 */     if ((resourceForm.getResourceId() != null) && 
/*  92 */       (!resourceForm.getResourceId().equals("-1"))) {
/*  93 */       sql = sql + " and a.resourceId=" + resourceForm.getResourceId();
/*     */     }
/*     */ 
/*  96 */     sql = sql + " order by a.resourceId";
/*  97 */     final String sql1 = sql;
/*  98 */     Map map = (Map)getHibernateTemplate().execute(new HibernateCallback() {
/*     */       public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/* 100 */         Query query = arg0.createQuery(sql1);
/* 101 */         Map map = new HashMap();
/* 102 */         int totalCnt = query.list().size();
/* 103 */         if (totalCnt < 1) {
/* 104 */           map.put("total", Integer.valueOf(0));
/* 105 */           map.put("result", new ArrayList());
/* 106 */           return map;
/*     */         }
/* 108 */         query.setFirstResult(pageSize.intValue() * curPage.intValue());
/* 109 */         query.setMaxResults(pageSize.intValue());
/* 110 */         List list = query.list();
/* 111 */         map.put("total", Integer.valueOf(totalCnt));
/* 112 */         map.put("result", list);
/*     */ 
/* 114 */         return map;
/*     */       }
/*     */     });
/* 118 */     return map;
/*     */   }
/*     */ 
/*     */   public void save(MtlApproveResourceType mtlApproveResourceType) throws MpmException
/*     */   {
/* 123 */     String sql = "from  MtlApproveResourceType a where a.resourceId=" + mtlApproveResourceType.getResourceId();
/* 124 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/* 125 */     getHibernateTemplate().save(mtlApproveResourceType);
/*     */   }
/*     */ 
/*     */   public void update(MtlApproveResourceType mtlApproveResourceType) throws MpmException
/*     */   {
/* 130 */     getHibernateTemplate().update(mtlApproveResourceType);
/*     */   }
/*     */ 
/*     */   public void delete(MtlApproveResourceTypeForm searchForm) throws MpmException
/*     */   {
/* 135 */     String sql = "from  MtlApproveResourceType a where a.resourceId=" + searchForm.getResourceId();
/* 136 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlApproveResourceTypeDaoImpl
 * JD-Core Version:    0.6.2
 */
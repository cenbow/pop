package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMtlApproveResourceTypeDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.MtlApproveResourceTypeForm;
import com.ai.bdx.frame.approval.model.MtlApproveResourceType;

/*
 * Created on 9:32:39 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlApproveResourceTypeDaoImpl extends HibernateDaoSupport implements IMtlApproveResourceTypeDao {
	public static Logger log = LogManager.getLogger();
	public MtlApproveResourceTypeDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List findAll() throws Exception {
		return this.getHibernateTemplate().find("from MtlApproveResourceType a order by a.resourceId desc");
	}

	public List findByFlag(short resourceFlag) throws Exception {
		return this.getHibernateTemplate().find("from MtlApproveResourceType a where a.resourceFlag = " + resourceFlag + " order by a.resourceId");
	}

	public List findFlag(Integer resourceId) throws Exception {
		StringBuffer sqlBuffer =new StringBuffer();
		sqlBuffer.append("select a.resourceFlag from MtlApproveResourceType a where a.resourceId= ").append( resourceId);
		return this.getHibernateTemplate().find(sqlBuffer.toString());
		//return this.getHibernateTemplate().find("select a.resourceFlag from MtlApproveResourceType a where a.resourceId= " + resourceId);
	}

	//	public MtlApproveResourceType getMtlApproveResourceType(Integer resourceId) throws Exception{
	//		MtlApproveResourceType mtlApproveResourceType=null;
	//		List list;
	//		list=this.getHibernateTemplate().find("from MtlApproveResourceType a where a.resourceId= "+resourceId);
	//		if(list.size()>0)
	//			mtlApproveResourceType = (MtlApproveResourceType)list.get(0);
	//		return mtlApproveResourceType;
	//	}

	public MtlApproveResourceType getRourceById(Integer resourceId) throws Exception {
		try {
			return (MtlApproveResourceType) this.getHibernateTemplate().get(MtlApproveResourceType.class, resourceId);
		} catch (Exception ex) {
log.error("",ex);
			return null;
		}
	}

	public MtlApproveResourceType getRourceByName(String resourceName) throws Exception {
		try {
			MtlApproveResourceType mtlApproveResourceType = null;
			String sql = "from  MtlApproveResourceType a where a.resourceName='" + resourceName + "'";
			//	final String sql1 = sql;
			List list = this.getHibernateTemplate().find(sql);
			if (list.size() > 0) {
				mtlApproveResourceType = (MtlApproveResourceType) list.get(0);
			}
			return mtlApproveResourceType;
		} catch (Exception ex) {
log.error("",ex);
			return null;
		}
	}

	public Map searchMtlApproveResourceType(MtlApproveResourceTypeForm resourceForm, final Integer curPage, final Integer pageSize) throws MpmException {
		// TODO 自动生成方法存根
		String sql = "from  MtlApproveResourceType a where 1=1 ";
		if (resourceForm.getResourceId() != null) {
			if (!resourceForm.getResourceId().equals("-1")) {
				sql += " and a.resourceId=" + resourceForm.getResourceId();
			}
		}
		sql += " order by a.resourceId";
		final String sql1 = sql;
		Map map = (Map) this.getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
				Query query = arg0.createQuery(sql1);
				Map map = new HashMap();
				int totalCnt = query.list().size();
				if (totalCnt < 1) {
					map.put("total", Integer.valueOf(0));
					map.put("result", new ArrayList());
					return map;
				}
				query.setFirstResult(pageSize.intValue() * curPage.intValue());
				query.setMaxResults(pageSize.intValue());
				List list = query.list();
				map.put("total", Integer.valueOf(totalCnt));
				map.put("result", list);

				return map;
			}
		});

		return map;
	}

	public void save(MtlApproveResourceType mtlApproveResourceType) throws MpmException {
		// TODO 自动生成方法存根
		String sql = "from  MtlApproveResourceType a where a.resourceId=" + mtlApproveResourceType.getResourceId();
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
		this.getHibernateTemplate().save(mtlApproveResourceType);
	}

	public void update(MtlApproveResourceType mtlApproveResourceType) throws MpmException {
		// TODO 自动生成方法存根
		this.getHibernateTemplate().update(mtlApproveResourceType);
	}

	public void delete(final MtlApproveResourceTypeForm searchForm) throws MpmException {
		// TODO 自动生成方法存根
		String sql = "from  MtlApproveResourceType a where a.resourceId=" + searchForm.getResourceId();
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
	}
}

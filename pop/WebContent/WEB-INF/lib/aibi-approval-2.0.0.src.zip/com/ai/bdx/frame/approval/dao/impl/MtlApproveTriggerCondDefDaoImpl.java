package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao;
import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDef;
import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDefId;

/**
 * Created on Apr 27, 2007 4:37:03 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlApproveTriggerCondDefDaoImpl extends HibernateDaoSupport implements IMtlApproveTriggerCondDefDao {

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao#deleteApproveTriggerCondDef(com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDefId)
	 */
	public void deleteApproveTriggerCondDef(MtlApproveTriggerCondDefId id) throws Exception {
		String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveLevel=" + id.getApproveLevel() + " and matcd.id.approveFlowId='" + id.getApproveFlowId() + "'" + " and matcd.id.condIndiId='" + id.getCondIndiId() + "'" + " and matcd.id.approveTriggerCondId='"
				+ id.getApproveTriggerCondId() + "'";
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao#deleteApproveTriggerCondDefByFlow(java.lang.String)
	 */
	public void deleteApproveTriggerCondDefByFlow(String flowId) throws Exception {
		String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveFlowId='" + flowId + "'";
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao#deleteApproveTriggerCondDefByFlowAndLevel(java.lang.String, java.lang.Integer)
	 */
	public void deleteApproveTriggerCondDefByFlowAndLevel(String flowId, Integer level) throws Exception {
		String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveLevel=" + level + " and matcd.id.approveFlowId='" + flowId + "'";
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao#getApproveTriggerCondDef(com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDefId)
	 */
	public MtlApproveTriggerCondDef getApproveTriggerCondDef(MtlApproveTriggerCondDefId id) throws Exception {
		return (MtlApproveTriggerCondDef) this.getHibernateTemplate().get(MtlApproveTriggerCondDef.class, id);
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao#getApproveTriggerCondDefByFlow(java.lang.String)
	 */
	public List getApproveTriggerCondDefByFlow(String flowId) throws Exception {
		String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveFlowId='" + flowId + "' order by matcd.id.approveLevel,matcd.id.approveTriggerCondId";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao#getApproveTriggerCondDefByFlowAndLevel(java.lang.String, java.lang.Integer)
	 */
	public List getApproveTriggerCondDefByFlowAndLevel(String flowId, Integer level) throws Exception {
		String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveLevel=" + level + " and matcd.id.approveFlowId='" + flowId + "'" + " order by matcd.id.approveLevel,matcd.id.approveTriggerCondId";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao#saveApproveTriggerCondDef(com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDef)
	 */
	public void saveApproveTriggerCondDef(MtlApproveTriggerCondDef def) throws Exception {
		this.getHibernateTemplate().save(def);
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao#updateApproveTriggerCondDef(com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDef)
	 */
	public void updateApproveTriggerCondDef(MtlApproveTriggerCondDef def) throws Exception {
		this.getHibernateTemplate().update(def);
	}

}

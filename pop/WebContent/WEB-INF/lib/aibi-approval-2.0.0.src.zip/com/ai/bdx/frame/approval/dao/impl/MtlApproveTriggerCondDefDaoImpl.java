/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondDefId;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlApproveTriggerCondDefDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlApproveTriggerCondDefDao
/*     */ {
/*     */   public void deleteApproveTriggerCondDef(MtlApproveTriggerCondDefId id)
/*     */     throws Exception
/*     */   {
/*  33 */     String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveLevel=" + id.getApproveLevel() + " and matcd.id.approveFlowId='" + id.getApproveFlowId() + "'" + " and matcd.id.condIndiId='" + id.getCondIndiId() + "'" + " and matcd.id.approveTriggerCondId='" + id.getApproveTriggerCondId() + "'";
/*     */ 
/*  35 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ 
/*     */   public void deleteApproveTriggerCondDefByFlow(String flowId)
/*     */     throws Exception
/*     */   {
/*  42 */     String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveFlowId='" + flowId + "'";
/*  43 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ 
/*     */   public void deleteApproveTriggerCondDefByFlowAndLevel(String flowId, Integer level)
/*     */     throws Exception
/*     */   {
/*  50 */     String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveLevel=" + level + " and matcd.id.approveFlowId='" + flowId + "'";
/*  51 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ 
/*     */   public MtlApproveTriggerCondDef getApproveTriggerCondDef(MtlApproveTriggerCondDefId id)
/*     */     throws Exception
/*     */   {
/*  58 */     return (MtlApproveTriggerCondDef)getHibernateTemplate().get(MtlApproveTriggerCondDef.class, id);
/*     */   }
/*     */ 
/*     */   public List getApproveTriggerCondDefByFlow(String flowId)
/*     */     throws Exception
/*     */   {
/*  65 */     String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveFlowId='" + flowId + "' order by matcd.id.approveLevel,matcd.id.approveTriggerCondId";
/*     */ 
/*  68 */     final String tmpSql = sql;
/*  69 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  71 */         Query query = s.createQuery(tmpSql);
/*  72 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List getApproveTriggerCondDefByFlowAndLevel(String flowId, Integer level)
/*     */     throws Exception
/*     */   {
/*  81 */     String sql = "from MtlApproveTriggerCondDef matcd where matcd.id.approveLevel=" + level + " and matcd.id.approveFlowId='" + flowId + "'" + " order by matcd.id.approveLevel,matcd.id.approveTriggerCondId";
/*     */ 
/*  84 */     final String tmpSql = sql;
/*  85 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  87 */         Query query = s.createQuery(tmpSql);
/*  88 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void saveApproveTriggerCondDef(MtlApproveTriggerCondDef def)
/*     */     throws Exception
/*     */   {
/*  97 */     getHibernateTemplate().save(def);
/*     */   }
/*     */ 
/*     */   public void updateApproveTriggerCondDef(MtlApproveTriggerCondDef def)
/*     */     throws Exception
/*     */   {
/* 104 */     getHibernateTemplate().update(def);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlApproveTriggerCondDefDaoImpl
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao;
/*    */ import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondIndi;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.Query;
/*    */ import org.hibernate.Session;
/*    */ import org.springframework.orm.hibernate3.HibernateCallback;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class MtlApproveTriggerCondIndiDaoImpl extends HibernateDaoSupport
/*    */   implements IMtlApproveTriggerCondIndiDao
/*    */ {
/*    */   public void deleteApproveTriggerCondIndi(String indiId)
/*    */     throws Exception
/*    */   {
/* 32 */     String sql = "from MtlApproveTriggerCondIndi m where m.condIndiId='" + indiId + "'";
/* 33 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*    */   }
/*    */ 
/*    */   public List getAllApproveTriggerCondIndi()
/*    */     throws Exception
/*    */   {
/* 40 */     String sql = "from MtlApproveTriggerCondIndi m order by m.condIndiName";
/*    */ 
/* 43 */     final String tmpSql = sql;
/* 44 */     return getHibernateTemplate().executeFind(new HibernateCallback() {
/*    */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 46 */         Query query = s.createQuery(tmpSql);
/* 47 */         return query.list();
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   public MtlApproveTriggerCondIndi getApproveTriggerCondIndi(String indiId)
/*    */     throws Exception
/*    */   {
/* 56 */     return (MtlApproveTriggerCondIndi)getHibernateTemplate().get(MtlApproveTriggerCondIndi.class, indiId);
/*    */   }
/*    */ 
/*    */   public void saveApproveTriggerCondIndi(MtlApproveTriggerCondIndi indi)
/*    */     throws Exception
/*    */   {
/* 63 */     getHibernateTemplate().save(indi);
/*    */   }
/*    */ 
/*    */   public void updateApproveTriggerCondIndi(MtlApproveTriggerCondIndi indi)
/*    */     throws Exception
/*    */   {
/* 70 */     getHibernateTemplate().update(indi);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlApproveTriggerCondIndiDaoImpl
 * JD-Core Version:    0.6.2
 */
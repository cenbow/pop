package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao;
import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondIndi;

/**
 * Created on Apr 28, 2007 5:17:03 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlApproveTriggerCondIndiDaoImpl extends HibernateDaoSupport implements IMtlApproveTriggerCondIndiDao {

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao#deleteApproveTriggerCondIndi(java.lang.String)
	 */
	public void deleteApproveTriggerCondIndi(String indiId) throws Exception {
		String sql = "from MtlApproveTriggerCondIndi m where m.condIndiId='" + indiId + "'";
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao#getAllApproveTriggerCondIndi()
	 */
	public List getAllApproveTriggerCondIndi() throws Exception {
		String sql = "from MtlApproveTriggerCondIndi m order by m.condIndiName";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao#getApproveTriggerCondIndi(java.lang.String)
	 */
	public MtlApproveTriggerCondIndi getApproveTriggerCondIndi(String indiId) throws Exception {
		return (MtlApproveTriggerCondIndi) this.getHibernateTemplate().get(MtlApproveTriggerCondIndi.class, indiId);
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao#saveApproveTriggerCondIndi(com.ai.bdx.frame.approval.model.MtlApproveTriggerCondIndi)
	 */
	public void saveApproveTriggerCondIndi(MtlApproveTriggerCondIndi indi) throws Exception {
		this.getHibernateTemplate().save(indi);
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao#updateApproveTriggerCondIndi(com.ai.bdx.frame.approval.model.MtlApproveTriggerCondIndi)
	 */
	public void updateApproveTriggerCondIndi(MtlApproveTriggerCondIndi indi) throws Exception {
		this.getHibernateTemplate().update(indi);
	}

}

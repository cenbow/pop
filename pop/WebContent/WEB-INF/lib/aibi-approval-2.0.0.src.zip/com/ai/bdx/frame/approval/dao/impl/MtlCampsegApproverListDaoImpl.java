package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.impl.SessionImpl;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao;
import com.ai.bdx.frame.approval.model.MtlCampsegApproverList;
import com.ai.bdx.frame.approval.model.MtlCampsegApproverListId;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;

/**
 * Created on May 17, 2007 1:23:10 PM
 *
 * <p>
 * Title:
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: asiainfo.,Ltd
 * </p>
 *
 * @author weilin.wu wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlCampsegApproverListDaoImpl extends HibernateDaoSupport
		implements IMtlCampsegApproverListDao {
	private static Logger log = LogManager.getLogger();

	public void updateCampsegApproverToken(String approveFlowId,
			String campsegId, String approveUserId, Short seq, Short token)
			throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl) this.getSession()).connection());
			StringBuffer sql = new StringBuffer();
			sql.append("update ap_campseg_approver_list set approve_token=")
					.append(token).append(",update_time=")
					.append(sqlca.getSql2DateTimeNow()).append(" where 1=1 ");
			// String sql = "update ap_campseg_approver_list set approve_token="
			// + token + ",update_time=" + sqlca.getSql2DateTimeNow() +
			// " where 1=1 ";
			if (approveFlowId != null && approveFlowId.length() > 0) {
				sql.append(" and approve_flow_id='").append(approveFlowId)
						.append("'");
				// sql += " and approve_flow_id='" + approveFlowId + "'";
			}
			if (campsegId != null && campsegId.length() > 0) {
				sql.append(" and campseg_id='").append(campsegId).append("'");
				// sql += " and campseg_id='" + campsegId + "'";
			}
			if (approveUserId != null && approveUserId.length() > 0) {
				sql.append(" and approve_userid='").append(approveUserId)
						.append("'");
				// sql += " and approve_userid='" + approveUserId + "'";
			}
			if (seq != null && seq.shortValue() > 0) {
				sql.append(" and APPROVE_SEQ=").append(seq);
				// sql += " and APPROVE_SEQ=" + seq;
			}
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	public void updateCampsegApprover(String campsegId, String oldApprover,
			String newApprover) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl) this.getSession()).connection());
			sqlca.setAutoCommit(false);
			StringBuffer sql = new StringBuffer();
			sql.append("update ap_campseg_approver_list set approve_userid='")
					.append(newApprover).append("',update_time=")
					.append(sqlca.getSql2DateTimeNow())
					.append(" where campseg_id='").append(campsegId)
					.append("' and approve_userid='").append(oldApprover)
					.append("'");
			// String sql =
			// "update ap_campseg_approver_list set approve_userid='" +
			// newApprover + "',update_time=" + sqlca.getSql2DateTimeNow() +
			// " where campseg_id='" + campsegId + "' and approve_userid='" +
			// oldApprover + "'";
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao#
	 * deleteCampsegApprover
	 * (com.ai.bdx.frame.approval.model.MtlCampsegApproverListId)
	 */
	public void deleteCampsegApprover(MtlCampsegApproverListId id)
			throws Exception {
		String sql = "from MtlCampsegApproverList mcal where mcal.id.campsegId='"
				+ id.getCampsegId()
				+ "'"
				+ " and mcal.id.approveFlowId='"
				+ id.getApproveFlowId()
				+ "'"
				+ " and mcal.id.approveSeq="
				+ id.getApproveSeq()
				+ " and mcal.id.approveLevel="
				+ id.getApproveLevel();
		this.getHibernateTemplate().deleteAll(
				this.getHibernateTemplate().find(sql));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao#
	 * deleteCampsegApproverByCampsegId(java.lang.String)
	 */
	public void deleteCampsegApproverByCampsegId(String campsegId)
			throws Exception {
		String sql = "from MtlCampsegApproverList mcal where mcal.id.campsegId='"
				+ campsegId + "'";
		this.getHibernateTemplate().deleteAll(
				this.getHibernateTemplate().find(sql));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao#findCampsegApprover
	 * (com.ai.bdx.frame.approval.model.MtlCampsegApproverList)
	 */
	public List findCampsegApprover(MtlCampsegApproverList approver)
			throws Exception {
		String sql = "from MtlCampsegApproverList mcal where 1=1 ";
		if (approver.getId() != null
				&& approver.getId().getApproveFlowId() != null) {
			sql += " and mcal.id.approveFlowId='"
					+ approver.getId().getApproveFlowId() + "'";
		}
		if (approver.getId() != null && approver.getId().getCampsegId() != null) {
			sql += " and mcal.id.campsegId='" + approver.getId().getCampsegId()
					+ "'";
		}

		if (approver.getApproveUserid() != null) {
			sql += " and mcal.approveUserid='" + approver.getApproveUserid()
					+ "'";
		}
		if (approver.getApproveToken() != null) {
			sql += " and mcal.approveToken=" + approver.getApproveToken();
		}
		if (approver.getId() != null
				&& approver.getId().getApproveLevel() != null) {
			sql += " and mcal.id.approveLevel="
					+ approver.getId().getApproveLevel();
		}
		if (approver.getId() != null
				&& approver.getId().getApproveSeq() != null) {
			sql += " and mcal.id.approveSeq="
					+ approver.getId().getApproveSeq();
		}
		sql += " order by mcal.id.approveSeq";

		final String tmpSql = sql;
		return this.getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	public List findCampsegApproverList(MtlCampsegApproverList approver)
			throws Exception {
		String sql = "from MtlCampsegApproverList mcal where 1=1 ";
		if (approver.getId() != null
				&& approver.getId().getApproveFlowId() != null) {
			sql += " and mcal.id.approveFlowId='"
					+ approver.getId().getApproveFlowId() + "'";
		}
		if (approver.getId() != null && approver.getId().getCampsegId() != null) {
			sql += " and mcal.id.campsegId='" + approver.getId().getCampsegId()
					+ "'";
		}

		if (approver.getApproveUserid() != null) {
			sql += " and mcal.approveUserid='" + approver.getApproveUserid()
					+ "'";
		}
		if (approver.getApproveToken() != null) {
			sql += " and mcal.approveToken=" + approver.getApproveToken();
		}
		if (approver.getId() != null
				&& approver.getId().getApproveLevel() != null) {
			sql += " and mcal.id.approveLevel="
					+ approver.getId().getApproveLevel();
		}

		final String tmpSql = sql;
		return this.getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	public MtlCampsegApproverList getFirstApprover(String campsegId) {
		String sql = "from MtlCampsegApproverList mcal where mcal.id.campsegId='"
				+ campsegId + "' order by mcal.id.approveSeq";

		final String tmpSql = sql;
		List list = this.getHibernateTemplate().executeFind(
				new HibernateCallback() {
					public Object doInHibernate(Session s)
							throws HibernateException, SQLException {
						Query query = s.createQuery(tmpSql);
						return query.list();
					}
				});

		if (list != null && !list.isEmpty()) {
			return (MtlCampsegApproverList) list.get(0);
		}

		return null;
	}

	// caihao add
	public List findCampsegApprover(String campsegId, String approveUserid)
			throws Exception {
		String sql = "from MtlCampsegApproverList mcal where 1=1";

		sql += " and mcal.id.campsegId='" + campsegId + "'";

		sql += " and mcal.approveUserid='" + approveUserid + "'";

		final String tmpSql = sql;
		return this.getHibernateTemplate().executeFind(new HibernateCallback() {
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(tmpSql);

				return query.list();
			}
		});

	}

	public int countCampsegApproverByFlowId(String flowId) throws Exception {
		String sql = "from MtlCampsegApproverList mcal where mcal.id.approveFlowId='"
				+ flowId + "'";
		final String tmpSql = sql;
		List list = this.getHibernateTemplate().executeFind(
				new HibernateCallback() {
					public Object doInHibernate(Session s)
							throws HibernateException, SQLException {
						Query query = s.createQuery(tmpSql);
						return query.list();
					}
				});

		return list.size();
	}
	
	
	public int countCampsegApproverByFlowId1(String flowId) throws Exception {
		String sql = "select * from ap_approve_list a where a.approve_flow_id='"+  flowId+ "'";
		List list = this.getSession().createSQLQuery(sql).list();
		return list.size();
	}
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao#getCampsegApprover
	 * (com.ai.bdx.frame.approval.model.MtlCampsegApproverListId)
	 */
	public MtlCampsegApproverList getCampsegApprover(MtlCampsegApproverListId id)
			throws Exception {
		return (MtlCampsegApproverList) this.getHibernateTemplate().get(
				MtlCampsegApproverList.class, id);
	}

	public MtlCampsegApproverList getCampsegApproverList(String campsegId,
			String userId, Short token) throws Exception {
		String sql = "from MtlCampsegApproverList mcal where mcal.id.campsegId='"
				+ campsegId
				+ "' and  mcal.approveUserid='"
				+ userId
				+ "' and mcal.approveToken=" + token;

		final String tmpSql = sql;
		List list = this.getHibernateTemplate().executeFind(
				new HibernateCallback() {
					public Object doInHibernate(Session s)
							throws HibernateException, SQLException {
						Query query = s.createQuery(tmpSql);
						return query.list();
					}
				});

		if (list != null && !list.isEmpty()) {
			return (MtlCampsegApproverList) list.get(0);
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao#saveCampsegApprover
	 * (com.ai.bdx.frame.approval.model.MtlCampsegApproverList)
	 */
	public void saveCampsegApprover(MtlCampsegApproverList approver)
			throws Exception {
		this.getHibernateTemplate().save(approver);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao#
	 * updateCampsegApprover
	 * (com.ai.bdx.frame.approval.model.MtlCampsegApproverList)
	 */
	public void updateCampsegApprover(MtlCampsegApproverList approver)
			throws Exception {
		this.getHibernateTemplate().update(approver);
	}

	public void updateApprover(MtlCampsegApproverList approver)
			throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl) this.getSession()).connection());
			StringBuffer sql = new StringBuffer();
			// String sql = null;
			if (approver.getAuthFlag() != null
					&& approver.getAuthFlag().shortValue() == 1) {
				sql.append(
						"update ap_campseg_approver_list set approve_userid='")
						.append(approver.getApproveUserid())
						.append("',auth_flag=").append(approver.getAuthFlag())
						.append(" where campseg_id='")
						.append(approver.getId().getCampsegId())
						.append("' and approve_flow_id='")
						.append(approver.getId().getApproveFlowId())
						.append("' and approve_seq=")
						.append(approver.getId().getApproveSeq())
						.append(" and approve_level=")
						.append(approver.getId().getApproveLevel());
				// sql = "update ap_campseg_approver_list set approve_userid='"
				// + approver.getApproveUserid() + "',auth_flag=" +
				// approver.getAuthFlag() + " where campseg_id='" +
				// approver.getId().getCampsegId() + "' and approve_flow_id='" +
				// approver.getId().getApproveFlowId()
				// + "' and approve_seq=" + approver.getId().getApproveSeq() +
				// " and approve_level=" + approver.getId().getApproveLevel();
			} else {
				sql.append(
						"update ap_campseg_approver_list set approve_userid='")
						.append(approver.getApproveUserid())
						.append("',auth_flag=").append(approver.getAuthFlag())
						.append(" where campseg_id='")
						.append(approver.getId().getCampsegId())
						.append("' and approve_flow_id='")
						.append(approver.getId().getApproveFlowId())
						.append("' and approve_seq=")
						.append(approver.getId().getApproveSeq())
						.append(" and approve_level=")
						.append(approver.getId().getApproveLevel())
						.append(" and auth_flag=1");
				// sql = "update ap_campseg_approver_list set approve_userid='"
				// + approver.getApproveUserid() + "',auth_flag=" +
				// approver.getAuthFlag() + " where campseg_id='" +
				// approver.getId().getCampsegId() + "' and approve_flow_id='" +
				// approver.getId().getApproveFlowId()
				// + "' and approve_seq=" + approver.getId().getApproveSeq() +
				// " and approve_level=" + approver.getId().getApproveLevel() +
				// " and auth_flag=1";
			}

			sqlca.execute(sql.toString());
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

	public void updateByLevel(String authUserid, String consignorUserid,
			String campsegId, Short approveSeq, int authFlag) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl) this.getSession()).connection());
			StringBuffer sql = new StringBuffer();
			// String sql = null;
			if (authFlag == 1) {
				sql.append(
						"update ap_campseg_approver_list set approve_userid='")
						.append(consignorUserid).append("',auth_flag=")
						.append(authFlag).append(" where approve_userid='")
						.append(authUserid).append("' and campseg_id='")
						.append(campsegId).append("' and approve_seq>")
						.append(approveSeq);
				// sql = "update ap_campseg_approver_list set approve_userid='"
				// + consignorUserid + "',auth_flag=" + authFlag +
				// " where approve_userid='" + authUserid + "' and campseg_id='"
				// + campsegId + "' and approve_seq>" + approveSeq;
			} else {
				sql.append(
						"update ap_campseg_approver_list set approve_userid='")
						.append(consignorUserid).append("',auth_flag=")
						.append(authFlag).append(" where approve_userid='")
						.append(authUserid).append("' and campseg_id='")
						.append(campsegId).append("' and approve_seq>")
						.append(approveSeq).append(" and auth_flag=1");
				// sql = "update ap_campseg_approver_list set approve_userid='"
				// + consignorUserid + "',auth_flag=" + authFlag +
				// " where approve_userid='" + authUserid + "' and campseg_id='"
				// + campsegId + "' and approve_seq>" + approveSeq +
				// " and auth_flag=1";
			}
			// log.debug("*************2sql="+sql);
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null) {
				sqlca.close();
			}
		}
	}

}

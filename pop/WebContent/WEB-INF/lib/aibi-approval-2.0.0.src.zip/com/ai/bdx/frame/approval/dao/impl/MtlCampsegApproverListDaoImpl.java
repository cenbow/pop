/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampsegApproverList;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampsegApproverListId;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.impl.SessionImpl;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlCampsegApproverListDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlCampsegApproverListDao
/*     */ {
/*  41 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public void updateCampsegApproverToken(String approveFlowId, String campsegId, String approveUserId, Short seq, Short token)
/*     */     throws Exception
/*     */   {
/*  46 */     Sqlca sqlca = null;
/*     */     try {
/*  48 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/*  49 */       StringBuffer sql = new StringBuffer();
/*  50 */       sql.append("update ap_campseg_approver_list set approve_token=").append(token).append(",update_time=").append(sqlca.getSql2DateTimeNow()).append(" where 1=1 ");
/*     */ 
/*  56 */       if ((approveFlowId != null) && (approveFlowId.length() > 0)) {
/*  57 */         sql.append(" and approve_flow_id='").append(approveFlowId).append("'");
/*     */       }
/*     */ 
/*  61 */       if ((campsegId != null) && (campsegId.length() > 0)) {
/*  62 */         sql.append(" and campseg_id='").append(campsegId).append("'");
/*     */       }
/*     */ 
/*  65 */       if ((approveUserId != null) && (approveUserId.length() > 0)) {
/*  66 */         sql.append(" and approve_userid='").append(approveUserId).append("'");
/*     */       }
/*     */ 
/*  70 */       if ((seq != null) && (seq.shortValue() > 0)) {
/*  71 */         sql.append(" and APPROVE_SEQ=").append(seq);
/*     */       }
/*     */ 
/*  74 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/*  76 */       throw e;
/*     */     } finally {
/*  78 */       if (sqlca != null)
/*  79 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateCampsegApprover(String campsegId, String oldApprover, String newApprover)
/*     */     throws Exception
/*     */   {
/*  86 */     Sqlca sqlca = null;
/*     */     try {
/*  88 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/*  89 */       sqlca.setAutoCommit(false);
/*  90 */       StringBuffer sql = new StringBuffer();
/*  91 */       sql.append("update ap_campseg_approver_list set approve_userid='").append(newApprover).append("',update_time=").append(sqlca.getSql2DateTimeNow()).append(" where campseg_id='").append(campsegId).append("' and approve_userid='").append(oldApprover).append("'");
/*     */ 
/* 102 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 104 */       throw e;
/*     */     } finally {
/* 106 */       if (sqlca != null)
/* 107 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteCampsegApprover(MtlCampsegApproverListId id)
/*     */     throws Exception
/*     */   {
/* 121 */     String sql = "from MtlCampsegApproverList mcal where mcal.id.campsegId='" + id.getCampsegId() + "'" + " and mcal.id.approveFlowId='" + id.getApproveFlowId() + "'" + " and mcal.id.approveSeq=" + id.getApproveSeq() + " and mcal.id.approveLevel=" + id.getApproveLevel();
/*     */ 
/* 131 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ 
/*     */   public void deleteCampsegApproverByCampsegId(String campsegId)
/*     */     throws Exception
/*     */   {
/* 143 */     String sql = "from MtlCampsegApproverList mcal where mcal.id.campsegId='" + campsegId + "'";
/*     */ 
/* 145 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ 
/*     */   public List findCampsegApprover(MtlCampsegApproverList approver)
/*     */     throws Exception
/*     */   {
/* 158 */     String sql = "from MtlCampsegApproverList mcal where 1=1 ";
/* 159 */     if ((approver.getId() != null) && (approver.getId().getApproveFlowId() != null))
/*     */     {
/* 161 */       sql = sql + " and mcal.id.approveFlowId='" + approver.getId().getApproveFlowId() + "'";
/*     */     }
/*     */ 
/* 164 */     if ((approver.getId() != null) && (approver.getId().getCampsegId() != null)) {
/* 165 */       sql = sql + " and mcal.id.campsegId='" + approver.getId().getCampsegId() + "'";
/*     */     }
/*     */ 
/* 169 */     if (approver.getApproveUserid() != null) {
/* 170 */       sql = sql + " and mcal.approveUserid='" + approver.getApproveUserid() + "'";
/*     */     }
/*     */ 
/* 173 */     if (approver.getApproveToken() != null) {
/* 174 */       sql = sql + " and mcal.approveToken=" + approver.getApproveToken();
/*     */     }
/* 176 */     if ((approver.getId() != null) && (approver.getId().getApproveLevel() != null))
/*     */     {
/* 178 */       sql = sql + " and mcal.id.approveLevel=" + approver.getId().getApproveLevel();
/*     */     }
/*     */ 
/* 181 */     if ((approver.getId() != null) && (approver.getId().getApproveSeq() != null))
/*     */     {
/* 183 */       sql = sql + " and mcal.id.approveSeq=" + approver.getId().getApproveSeq();
/*     */     }
/*     */ 
/* 186 */     sql = sql + " order by mcal.id.approveSeq";
/*     */ 
/* 188 */     final String tmpSql = sql;
/* 189 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 192 */         Query query = s.createQuery(tmpSql);
/* 193 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List findCampsegApproverList(MtlCampsegApproverList approver) throws Exception
/*     */   {
/* 200 */     String sql = "from MtlCampsegApproverList mcal where 1=1 ";
/* 201 */     if ((approver.getId() != null) && (approver.getId().getApproveFlowId() != null))
/*     */     {
/* 203 */       sql = sql + " and mcal.id.approveFlowId='" + approver.getId().getApproveFlowId() + "'";
/*     */     }
/*     */ 
/* 206 */     if ((approver.getId() != null) && (approver.getId().getCampsegId() != null)) {
/* 207 */       sql = sql + " and mcal.id.campsegId='" + approver.getId().getCampsegId() + "'";
/*     */     }
/*     */ 
/* 211 */     if (approver.getApproveUserid() != null) {
/* 212 */       sql = sql + " and mcal.approveUserid='" + approver.getApproveUserid() + "'";
/*     */     }
/*     */ 
/* 215 */     if (approver.getApproveToken() != null) {
/* 216 */       sql = sql + " and mcal.approveToken=" + approver.getApproveToken();
/*     */     }
/* 218 */     if ((approver.getId() != null) && (approver.getId().getApproveLevel() != null))
/*     */     {
/* 220 */       sql = sql + " and mcal.id.approveLevel=" + approver.getId().getApproveLevel();
/*     */     }
/*     */ 
/* 224 */     final String tmpSql = sql;
/* 225 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 228 */         Query query = s.createQuery(tmpSql);
/* 229 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public MtlCampsegApproverList getFirstApprover(String campsegId) {
/* 235 */     String sql = "from MtlCampsegApproverList mcal where mcal.id.campsegId='" + campsegId + "' order by mcal.id.approveSeq";
/*     */ 
/* 238 */     final String tmpSql = sql;
/* 239 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException
/*     */       {
/* 243 */         Query query = s.createQuery(tmpSql);
/* 244 */         return query.list();
/*     */       }
/*     */     });
/* 248 */     if ((list != null) && (!list.isEmpty())) {
/* 249 */       return (MtlCampsegApproverList)list.get(0);
/*     */     }
/*     */ 
/* 252 */     return null;
/*     */   }
/*     */ 
/*     */   public List findCampsegApprover(String campsegId, String approveUserid)
/*     */     throws Exception
/*     */   {
/* 258 */     String sql = "from MtlCampsegApproverList mcal where 1=1";
/*     */ 
/* 260 */     sql = sql + " and mcal.id.campsegId='" + campsegId + "'";
/*     */ 
/* 262 */     sql = sql + " and mcal.approveUserid='" + approveUserid + "'";
/*     */ 
/* 264 */     final String tmpSql = sql;
/* 265 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 268 */         Query query = s.createQuery(tmpSql);
/*     */ 
/* 270 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public int countCampsegApproverByFlowId(String flowId) throws Exception
/*     */   {
/* 277 */     String sql = "from MtlCampsegApproverList mcal where mcal.id.approveFlowId='" + flowId + "'";
/*     */ 
/* 279 */     final String tmpSql = sql;
/* 280 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException
/*     */       {
/* 284 */         Query query = s.createQuery(tmpSql);
/* 285 */         return query.list();
/*     */       }
/*     */     });
/* 289 */     return list.size();
/*     */   }
/*     */ 
/*     */   public int countCampsegApproverByFlowId1(String flowId) throws Exception
/*     */   {
/* 294 */     String sql = "select * from ap_approve_list a where a.approve_flow_id='" + flowId + "'";
/* 295 */     List list = getSession().createSQLQuery(sql).list();
/* 296 */     return list.size();
/*     */   }
/*     */ 
/*     */   public MtlCampsegApproverList getCampsegApprover(MtlCampsegApproverListId id)
/*     */     throws Exception
/*     */   {
/* 309 */     return (MtlCampsegApproverList)getHibernateTemplate().get(MtlCampsegApproverList.class, id);
/*     */   }
/*     */ 
/*     */   public MtlCampsegApproverList getCampsegApproverList(String campsegId, String userId, Short token)
/*     */     throws Exception
/*     */   {
/* 315 */     String sql = "from MtlCampsegApproverList mcal where mcal.id.campsegId='" + campsegId + "' and  mcal.approveUserid='" + userId + "' and mcal.approveToken=" + token;
/*     */ 
/* 321 */     final String tmpSql = sql;
/* 322 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException
/*     */       {
/* 326 */         Query query = s.createQuery(tmpSql);
/* 327 */         return query.list();
/*     */       }
/*     */     });
/* 331 */     if ((list != null) && (!list.isEmpty())) {
/* 332 */       return (MtlCampsegApproverList)list.get(0);
/*     */     }
/*     */ 
/* 335 */     return null;
/*     */   }
/*     */ 
/*     */   public void saveCampsegApprover(MtlCampsegApproverList approver)
/*     */     throws Exception
/*     */   {
/* 347 */     getHibernateTemplate().save(approver);
/*     */   }
/*     */ 
/*     */   public void updateCampsegApprover(MtlCampsegApproverList approver)
/*     */     throws Exception
/*     */   {
/* 359 */     getHibernateTemplate().update(approver);
/*     */   }
/*     */ 
/*     */   public void updateApprover(MtlCampsegApproverList approver) throws Exception
/*     */   {
/* 364 */     Sqlca sqlca = null;
/*     */     try {
/* 366 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 367 */       StringBuffer sql = new StringBuffer();
/*     */ 
/* 369 */       if ((approver.getAuthFlag() != null) && (approver.getAuthFlag().shortValue() == 1))
/*     */       {
/* 371 */         sql.append("update ap_campseg_approver_list set approve_userid='").append(approver.getApproveUserid()).append("',auth_flag=").append(approver.getAuthFlag()).append(" where campseg_id='").append(approver.getId().getCampsegId()).append("' and approve_flow_id='").append(approver.getId().getApproveFlowId()).append("' and approve_seq=").append(approver.getId().getApproveSeq()).append(" and approve_level=").append(approver.getId().getApproveLevel());
/*     */       }
/*     */       else
/*     */       {
/* 391 */         sql.append("update ap_campseg_approver_list set approve_userid='").append(approver.getApproveUserid()).append("',auth_flag=").append(approver.getAuthFlag()).append(" where campseg_id='").append(approver.getId().getCampsegId()).append("' and approve_flow_id='").append(approver.getId().getApproveFlowId()).append("' and approve_seq=").append(approver.getId().getApproveSeq()).append(" and approve_level=").append(approver.getId().getApproveLevel()).append(" and auth_flag=1");
/*     */       }
/*     */ 
/* 414 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 416 */       log.error("", e);
/*     */     } finally {
/* 418 */       if (sqlca != null)
/* 419 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateByLevel(String authUserid, String consignorUserid, String campsegId, Short approveSeq, int authFlag)
/*     */     throws Exception
/*     */   {
/* 426 */     Sqlca sqlca = null;
/*     */     try {
/* 428 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 429 */       StringBuffer sql = new StringBuffer();
/*     */ 
/* 431 */       if (authFlag == 1) {
/* 432 */         sql.append("update ap_campseg_approver_list set approve_userid='").append(consignorUserid).append("',auth_flag=").append(authFlag).append(" where approve_userid='").append(authUserid).append("' and campseg_id='").append(campsegId).append("' and approve_seq>").append(approveSeq);
/*     */       }
/*     */       else
/*     */       {
/* 444 */         sql.append("update ap_campseg_approver_list set approve_userid='").append(consignorUserid).append("',auth_flag=").append(authFlag).append(" where approve_userid='").append(authUserid).append("' and campseg_id='").append(campsegId).append("' and approve_seq>").append(approveSeq).append(" and auth_flag=1");
/*     */       }
/*     */ 
/* 458 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 460 */       log.error("", e);
/*     */     } finally {
/* 462 */       if (sqlca != null)
/* 463 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlCampsegApproverListDaoImpl
 * JD-Core Version:    0.6.2
 */
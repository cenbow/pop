/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlCampsegProgressDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampsegProgressId;
/*     */ import com.ai.bdx.frame.approval.util.StringFunc;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.impl.SessionImpl;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlCampsegProgressDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlCampsegProgressDao
/*     */ {
/*     */   public List findCampsegProgress(MtlCampsegProgress progress)
/*     */     throws Exception
/*     */   {
/*  40 */     String sql = "from MtlCampsegProgress mp where 1=1 ";
/*  41 */     if ((progress.getId().getCampsegId() != null) && (progress.getId().getCampsegId().length() > 0))
/*  42 */       sql = sql + " and mp.id.campsegId='" + progress.getId().getCampsegId() + "'";
/*  43 */     if ((progress.getId().getFlowId() != null) && (progress.getId().getFlowId().length() > 0))
/*  44 */       sql = sql + " and mp.id.flowId='" + progress.getId().getFlowId() + "'";
/*  45 */     if (progress.getId().getStepId() != null)
/*  46 */       sql = sql + " and mp.id.stepId=" + progress.getId().getStepId();
/*  47 */     if ((progress.getCampId() != null) && (progress.getCampId().length() > 0))
/*  48 */       sql = sql + " and mp.campId='" + progress.getCampId() + "'";
/*  49 */     sql = sql + " order by mp.id.stepId";
/*     */ 
/*  52 */     final String tmpSql = sql;
/*  53 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  56 */         Query query = s.createQuery(tmpSql);
/*  57 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public boolean findCampsegByProformResult(String proformResult) throws Exception
/*     */   {
/*  64 */     boolean flag = false;
/*     */     try {
/*  66 */       String sql = "from MtlCampsegProgress as a where a.proformResult='" + proformResult + "'";
/*  67 */       List result = getHibernateTemplate().find(sql);
/*  68 */       if ((result != null) && (result.size() > 0)) {
/*  69 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  79 */       throw e;
/*     */     }
/*  81 */     return flag;
/*     */   }
/*     */ 
/*     */   public MtlCampsegProgress getCampsegProgress(MtlCampsegProgressId id) throws Exception
/*     */   {
/*  86 */     MtlCampsegProgress obj = null;
/*  87 */     String sql = "from MtlCampsegProgress mp where mp.id.campsegId='" + id.getCampsegId() + "'" + " and mp.id.stepId=" + id.getStepId();
/*     */ 
/*  94 */     final String tmpSql = sql;
/*  95 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  98 */         Query query = s.createQuery(tmpSql);
/*  99 */         return query.list();
/*     */       }
/*     */     });
/* 102 */     if (list.size() > 0)
/*     */     {
/* 104 */       obj = (MtlCampsegProgress)list.get(0);
/* 105 */     }return obj;
/*     */   }
/*     */ 
/*     */   public MtlCampsegProgress getCampPropProgress(String campId, Short stepId, String flowId) throws Exception
/*     */   {
/* 110 */     MtlCampsegProgress obj = null;
/* 111 */     String sql = "from MtlCampsegProgress mp where mp.proformResult is not null and mp.performFlag=1 and mp.campId='" + campId + "'" + " and mp.id.stepId=" + stepId;
/*     */ 
/* 116 */     final String tmpSql = sql;
/* 117 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 120 */         Query query = s.createQuery(tmpSql);
/* 121 */         return query.list();
/*     */       }
/*     */     });
/* 124 */     if (list.size() > 0) {
/* 125 */       obj = (MtlCampsegProgress)list.get(0);
/*     */     }
/* 127 */     return obj;
/*     */   }
/*     */ 
/*     */   public MtlCampsegProgress getCampPropProgressByseg(String campsegId, Short stepId, String flowId) throws Exception
/*     */   {
/* 132 */     MtlCampsegProgress obj = null;
/* 133 */     String sql = "from MtlCampsegProgress mp where mp.proformResult is not null and mp.performFlag=1 and mp.id.campsegId='" + campsegId + "'" + " and mp.id.stepId=" + stepId;
/*     */ 
/* 138 */     final String tmpSql = sql;
/* 139 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 142 */         Query query = s.createQuery(tmpSql);
/* 143 */         return query.list();
/*     */       }
/*     */     });
/* 146 */     if (list.size() > 0) {
/* 147 */       obj = (MtlCampsegProgress)list.get(0);
/*     */     }
/* 149 */     return obj;
/*     */   }
/*     */ 
/*     */   public Short getCampsegProgressStatus(MtlCampsegProgressId id) throws Exception
/*     */   {
/* 154 */     StringBuffer sqlBuffer = new StringBuffer();
/* 155 */     sqlBuffer.append("select mp.performFlag from MtlCampsegProgress mp").append(" where mp.id.campsegId='").append(id.getCampsegId()).append("'").append(" and mp.id.flowId='").append(id.getFlowId()).append("'").append(" and mp.id.stepId=").append(id.getStepId());
/*     */ 
/* 157 */     List list = getHibernateTemplate().find(sqlBuffer.toString());
/* 158 */     if (list.size() > 0) {
/* 159 */       Object obj = list.get(0);
/* 160 */       return (Short)obj;
/*     */     }
/* 162 */     return Short.valueOf("0");
/*     */   }
/*     */ 
/*     */   public void saveCampsegProgress(MtlCampsegProgress progress) throws Exception
/*     */   {
/* 167 */     getHibernateTemplate().saveOrUpdate(progress);
/*     */   }
/*     */ 
/*     */   public void deleteCampsegProgress(MtlCampsegProgressId id)
/*     */     throws Exception
/*     */   {
/* 173 */     String sql = "from MtlCampsegProgress mp where mp.id.campsegId='" + id.getCampsegId() + "'" + " and mp.id.flowId='" + id.getFlowId() + "'" + " and mp.id.stepId=" + id.getStepId();
/* 174 */     getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */   }
/*     */ 
/*     */   public void deleteAllCampsegProgress(String campsegId)
/*     */   {
/* 179 */     String sql = "delete from MtlCampsegProgress where campseg_Id = ?";
/* 180 */     Query query = getSession().createQuery(sql);
/* 181 */     query.setString(0, campsegId);
/* 182 */     query.executeUpdate();
/*     */   }
/*     */ 
/*     */   public void updateCampsegProgress(MtlCampsegProgress progress)
/*     */     throws Exception
/*     */   {
/* 188 */     getHibernateTemplate().update(progress);
/*     */   }
/*     */ 
/*     */   public void updateCampsegProgressResult(String campsegId, String flowId, Short stepId, String result) throws Exception
/*     */   {
/* 193 */     Sqlca sqlca = null;
/*     */     try {
/* 195 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 196 */       sqlca.setAutoCommit(false);
/* 197 */       StringBuffer sqlBuffer = new StringBuffer();
/* 198 */       sqlBuffer.append("update mtl_campseg_progress set proform_result='").append(result).append("' where campseg_Id='").append(campsegId).append("' and flow_Id='").append(flowId).append("' and step_id=").append(stepId);
/*     */ 
/* 201 */       sqlca.execute(sqlBuffer.toString());
/*     */     } catch (Exception e) {
/* 203 */       throw e;
/*     */     } finally {
/* 205 */       if (sqlca != null)
/* 206 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateCampProgressFlag(String campId, String flowId, Short[] stepIds, Short flag) throws Exception
/*     */   {
/* 212 */     Sqlca sqlca = null;
/*     */     try {
/* 214 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 215 */       sqlca.setAutoCommit(false);
/* 216 */       StringBuffer sqlBuffer = new StringBuffer();
/*     */ 
/* 218 */       sqlBuffer.append("update mtl_campseg_progress set perform_flag=").append(flag).append(" where camp_Id='").append(campId).append("'");
/*     */ 
/* 220 */       if ((flowId != null) && (flowId.length() > 0))
/*     */       {
/* 222 */         sqlBuffer.append(" and flow_Id='").append(flowId).append("'");
/* 223 */       }if ((stepIds != null) && (stepIds.length > 0)) {
/* 224 */         String tmpStr = StringFunc.array_to_str(stepIds);
/*     */ 
/* 226 */         sqlBuffer.append(" and step_id in (").append(tmpStr).append(")");
/*     */       }
/* 228 */       sqlca.execute(sqlBuffer.toString());
/*     */     } catch (Exception e) {
/* 230 */       throw e;
/*     */     } finally {
/* 232 */       if (sqlca != null)
/* 233 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateCampPropProgressFlagAndResult(String campId, String flowId, Short flag, String result) throws Exception
/*     */   {
/* 239 */     Sqlca sqlca = null;
/*     */     try {
/* 241 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 242 */       sqlca.setAutoCommit(false);
/* 243 */       StringBuffer sql = new StringBuffer();
/* 244 */       sql.append("update mtl_campseg_progress set perform_flag=").append(flag).append(",proform_result='").append(result).append("'").append(" where camp_Id='").append(campId).append("' and flow_Id='").append(flowId).append("'").append(" and step_id=").append(10);
/*     */ 
/* 246 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 248 */       throw e;
/*     */     } finally {
/* 250 */       if (sqlca != null)
/* 251 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateCampsegProgressFlag(String campsegId, String flowId, Short[] stepIds, Short flag) throws Exception
/*     */   {
/* 257 */     Sqlca sqlca = null;
/*     */     try {
/* 259 */       String strStepIds = "";
/* 260 */       for (int i = 0; i < stepIds.length; i++) {
/* 261 */         strStepIds = strStepIds + stepIds[i] + ",";
/*     */       }
/* 263 */       if (strStepIds.length() > 0) {
/* 264 */         strStepIds = strStepIds.substring(0, strStepIds.length() - 1);
/*     */       }
/* 266 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 267 */       sqlca.setAutoCommit(false);
/* 268 */       StringBuffer sql = new StringBuffer();
/* 269 */       sql.append("update mtl_campseg_progress set perform_flag=").append(flag).append(" where campseg_Id='").append(campsegId).append("' and step_id in (").append(strStepIds).append(")");
/*     */ 
/* 271 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 273 */       throw e;
/*     */     } finally {
/* 275 */       if (sqlca != null)
/* 276 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateCampsegProgressBySegid(String campsegId, Short flag)
/*     */     throws Exception
/*     */   {
/* 285 */     Sqlca sqlca = null;
/*     */     try {
/* 287 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 288 */       StringBuffer sql = new StringBuffer();
/* 289 */       sql.append("update mtl_campseg_progress set perform_flag=").append(flag).append(" where step_id =").append(80).append(" and campseg_Id='").append(campsegId).append("'");
/*     */ 
/* 291 */       sqlca.execute(sql.toString());
/*     */     } catch (Exception e) {
/* 293 */       throw e;
/*     */     } finally {
/* 295 */       if (sqlca != null)
/* 296 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getCampsegProgressflow(String campsegId)
/*     */     throws Exception
/*     */   {
/* 303 */     String sql = "from MtlCampsegProgress mp where mp.id.campsegId='" + campsegId + "' order by mp.id.stepId";
/*     */ 
/* 306 */     final String tmpSql = sql;
/* 307 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 310 */         Query query = s.createQuery(tmpSql);
/* 311 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List getCampsegProgressflowstate(String campsegId) throws Exception
/*     */   {
/* 318 */     String sql = "from MtlCampsegProgress mp where mp.id.stepId = 100 and  mp.id.campsegId='" + campsegId + "'";
/*     */ 
/* 321 */     final String tmpSql = sql;
/* 322 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 325 */         Query query = s.createQuery(tmpSql);
/* 326 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public MtlCampsegProgress getCampPropProgressByCond(String campsegId, Short stepId, String flowId)
/*     */     throws Exception
/*     */   {
/* 337 */     MtlCampsegProgress obj = null;
/* 338 */     final StringBuffer sql = new StringBuffer();
/* 339 */     sql.append("from MtlCampsegProgress mp where 1=1 ").append(" and mp.id.campsegId='").append(campsegId).append("'").append(" and mp.id.flowId='").append(flowId).append("'").append(" and mp.id.stepId=").append(stepId);
/*     */ 
/* 342 */     List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 345 */         Query query = s.createQuery(sql.toString());
/* 346 */         return query.list();
/*     */       }
/*     */     });
/* 349 */     if (list.size() > 0) {
/* 350 */       obj = (MtlCampsegProgress)list.get(0);
/*     */     }
/* 352 */     return obj;
/*     */   }
/*     */ 
/*     */   public void saveOrUpdateCampsegProgress(MtlCampsegProgress progress)
/*     */     throws Exception
/*     */   {
/* 358 */     getHibernateTemplate().saveOrUpdate(progress);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlCampsegProgressDaoImpl
 * JD-Core Version:    0.6.2
 */
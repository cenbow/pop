package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.impl.SessionImpl;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMtlCampsegProgressDao;
import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
import com.ai.bdx.frame.approval.model.MtlCampsegProgressId;
import com.ai.bdx.frame.approval.util.StringFunc;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;

/*
 * Created on 5:38:43 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlCampsegProgressDaoImpl extends HibernateDaoSupport implements IMtlCampsegProgressDao {

	public MtlCampsegProgressDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public List findCampsegProgress(MtlCampsegProgress progress) throws Exception {
		String sql = "from MtlCampsegProgress mp where 1=1 ";
		if (progress.getId().getCampsegId() != null && progress.getId().getCampsegId().length() > 0)
			sql += " and mp.id.campsegId='" + progress.getId().getCampsegId() + "'";
		if (progress.getId().getFlowId() != null && progress.getId().getFlowId().length() > 0)
			sql += " and mp.id.flowId='" + progress.getId().getFlowId() + "'";
		if (progress.getId().getStepId() != null)
			sql += " and mp.id.stepId=" + progress.getId().getStepId();
		if (progress.getCampId() != null && progress.getCampId().length() > 0)
			sql += " and mp.campId='" + progress.getCampId() + "'";
		sql += " order by mp.id.stepId";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	@Override
	public boolean findCampsegByProformResult(String proformResult) throws Exception {
		boolean flag = false;
		try {
			String sql = "from MtlCampsegProgress as a where a.proformResult='" + proformResult + "'";
			List result = this.getHibernateTemplate().find(sql);
			if (result != null && result.size() > 0) {
				flag = true;
				return flag;
			}
			//			sql="from MtlCampsegProgressBak as a where a.proformResult='"+proformResult+"'";
			//			result = this.getHibernateTemplate().find(sql);
			//			if(result != null && result.size() >0){
			//				flag = true;
			//				return flag;
			//			}
		} catch (Exception e) {
			throw e;
		}
		return flag;
	}

	@Override
	public MtlCampsegProgress getCampsegProgress(MtlCampsegProgressId id) throws Exception {
		MtlCampsegProgress obj = null;
		String sql = "from MtlCampsegProgress mp where mp.id.campsegId='" + id.getCampsegId() + "'" +
		//						" and mp.id.flowId='" + id.getFlowId() + "'" +
				" and mp.id.stepId=" + id.getStepId();
		//			obj = (MtlCampsegProgress)this.getHibernateTemplate().get(MtlCampsegProgress.class,id);
		//		Query query = this.getSession().createQuery(sql);
		//		List list = query.list();

		final String tmpSql = sql;
		List list = getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
		if (list.size() > 0)

			obj = (MtlCampsegProgress) list.get(0);
		return obj;
	}

	@Override
	public MtlCampsegProgress getCampPropProgress(String campId, Short stepId, String flowId) throws Exception {
		MtlCampsegProgress obj = null;
		String sql = "from MtlCampsegProgress mp where mp.proformResult is not null and mp.performFlag=" + MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_SUCCESS + " and mp.campId='" + campId + "'" +
		//					" and mp.id.flowId='" + flowId + "'" +
				" and mp.id.stepId=" + stepId;
		//		Query query = this.getSession().createQuery(sql);
		//		List list = query.list();
		final String tmpSql = sql;
		List list = getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
		if (list.size() > 0)
			obj = (MtlCampsegProgress) list.get(0);

		return obj;
	}

	@Override
	public MtlCampsegProgress getCampPropProgressByseg(String campsegId, Short stepId, String flowId) throws Exception {
		MtlCampsegProgress obj = null;
		String sql = "from MtlCampsegProgress mp where mp.proformResult is not null and mp.performFlag=" + MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_SUCCESS + " and mp.id.campsegId='" + campsegId + "'" +
		//					" and mp.id.flowId='" + flowId + "'" +
				" and mp.id.stepId=" + stepId;
		//		Query query = this.getSession().createQuery(sql);
		//		List list = query.list();
		final String tmpSql = sql;
		List list = getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
		if (list.size() > 0)
			obj = (MtlCampsegProgress) list.get(0);

		return obj;
	}

	@Override
	public Short getCampsegProgressStatus(MtlCampsegProgressId id) throws Exception {
		StringBuffer sqlBuffer=new StringBuffer();
		sqlBuffer.append("select mp.performFlag from MtlCampsegProgress mp").append(" where mp.id.campsegId='").append(id.getCampsegId()).append("'").append(" and mp.id.flowId='").append(id.getFlowId()).append("'").append(" and mp.id.stepId=").append(id.getStepId());
		//List list = this.getHibernateTemplate().find("select mp.performFlag from MtlCampsegProgress mp" + " where mp.id.campsegId='" + id.getCampsegId() + "'" + " and mp.id.flowId='" + id.getFlowId() + "'" + " and mp.id.stepId=" + id.getStepId());
		List list = this.getHibernateTemplate().find(sqlBuffer.toString());
		if (list.size() > 0) {
			Object obj = list.get(0);
			return (Short) obj;
		} else
			return Short.valueOf("0");
	}

	@Override
	public void saveCampsegProgress(MtlCampsegProgress progress) throws Exception {
		this.getHibernateTemplate().saveOrUpdate(progress);
	}
	

	@Override
	public void deleteCampsegProgress(MtlCampsegProgressId id) throws Exception {
		String sql = "from MtlCampsegProgress mp where mp.id.campsegId='" + id.getCampsegId() + "'" + " and mp.id.flowId='" + id.getFlowId() + "'" + " and mp.id.stepId=" + id.getStepId();
		this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
	}
	
	@Override
	public void deleteAllCampsegProgress(String campsegId) {
		String sql = "delete from MtlCampsegProgress where campseg_Id = ?";
		Query query = this.getSession().createQuery(sql);
		query.setString(0, campsegId);
		query.executeUpdate();
	}

	@Override
	public void updateCampsegProgress(MtlCampsegProgress progress) throws Exception {
		//log.debug("progress-----------------------------" + progress.getId().getCampsegId());
		this.getHibernateTemplate().update(progress);
	}

	@Override
	public void updateCampsegProgressResult(String campsegId, String flowId, Short stepId, String result) throws Exception {
		Sqlca sqlca = null;
		try {			
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			sqlca.setAutoCommit(false);
			StringBuffer sqlBuffer=new StringBuffer();
			sqlBuffer.append("update mtl_campseg_progress set proform_result='").append(result).append("' where campseg_Id='")
			.append(campsegId).append("' and flow_Id='").append(flowId).append("' and step_id=").append(stepId);
			//String sql = "update mtl_campseg_progress set proform_result='" + result + "' where campseg_Id='" + campsegId + "' and flow_Id='" + flowId + "' and step_id=" + stepId;
			sqlca.execute(sqlBuffer.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null)
				sqlca.close();
		}
	}

	@Override
	public void updateCampProgressFlag(String campId, String flowId, Short[] stepIds, Short flag) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			sqlca.setAutoCommit(false);
			StringBuffer sqlBuffer=new StringBuffer();
			//String sql = "update mtl_campseg_progress set perform_flag=" + flag + " where camp_Id='" + campId + "'";
			sqlBuffer.append("update mtl_campseg_progress set perform_flag=").append(flag)
			.append(" where camp_Id='").append(campId).append( "'");
			if (flowId != null && flowId.length() > 0)
				//sql += " and flow_Id='" + flowId + "'";
				sqlBuffer.append(" and flow_Id='").append(flowId).append("'");
			if (stepIds != null && stepIds.length > 0) {
				String tmpStr = StringFunc.array_to_str(stepIds);
				//sql += " and step_id in (" + tmpStr + ")";
				sqlBuffer.append(" and step_id in (").append(tmpStr).append(")");
			}
			sqlca.execute(sqlBuffer.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null)
				sqlca.close();
		}
	}

	@Override
	public void updateCampPropProgressFlagAndResult(String campId, String flowId, Short flag, String result) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			sqlca.setAutoCommit(false);
			StringBuffer sql=new StringBuffer();
		 sql.append("update mtl_campseg_progress set perform_flag=").append(flag).append(",proform_result='").append(result).append( "'").append( " where camp_Id='").append(campId).append( "' and flow_Id='").append( flowId).append( "'").append(" and step_id=").append(MpmCONST.MPM_SYS_ACTSTEP_DEF_ACTIVE_TEMPLET);
//			String sql = "update mtl_campseg_progress set perform_flag=" + flag + ",proform_result='" + result + "'" + " where camp_Id='" + campId + "' and flow_Id='" + flowId + "'" + " and step_id=" + MpmCONST.MPM_SYS_ACTSTEP_DEF_ACTIVE_TEMPLET;
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null)
				sqlca.close();
		}
	}

	@Override
	public void updateCampsegProgressFlag(String campsegId, String flowId, Short[] stepIds, Short flag) throws Exception {
		Sqlca sqlca = null;
		try {
			String strStepIds = "";
			for (int i = 0; i < stepIds.length; i++) {
				strStepIds += stepIds[i] + ",";
			}
			if (strStepIds.length() > 0)
				strStepIds = strStepIds.substring(0, strStepIds.length() - 1);

			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			sqlca.setAutoCommit(false);
			StringBuffer sql=new StringBuffer();
			sql.append("update mtl_campseg_progress set perform_flag=").append(flag).append( " where campseg_Id='").append(campsegId).append("' and step_id in (").append(strStepIds).append(")");
			//String sql = "update mtl_campseg_progress set perform_flag=" + flag + " where campseg_Id='" + campsegId + "' and step_id in (" + strStepIds + ")";
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null)
				sqlca.close();
		}
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlCampsegProgressDao#updateCampsegProgressBySegid(java.lang.String, java.lang.Short)
	 */
	@Override
	public void updateCampsegProgressBySegid(String campsegId, Short flag) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			StringBuffer sql=new StringBuffer();
			 sql.append("update mtl_campseg_progress set perform_flag=").append(flag).append(" where step_id =").append( MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SEND).append(" and campseg_Id='").append( campsegId).append("'");
			//String sql = "update mtl_campseg_progress set perform_flag=" + flag + " where step_id =" + MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SEND + " and campseg_Id='" + campsegId + "'";
			sqlca.execute(sql.toString());
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null)
				sqlca.close();
		}

	}

	@Override
	public List getCampsegProgressflow(String campsegId) throws Exception {
		String sql = "from MtlCampsegProgress mp where mp.id.campsegId='" + campsegId + "' order by mp.id.stepId";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	@Override
	public List getCampsegProgressflowstate(String campsegId) throws Exception {
		String sql = "from MtlCampsegProgress mp where mp.id.stepId = 100 and  mp.id.campsegId='" + campsegId + "'";
		//		Query query = this.getSession().createQuery(sql);
		//		return query.list();
		final String tmpSql = sql;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				return query.list();
			}
		});
	}

	/*
	 * (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.dao.IMtlCampsegProgressDao#getCampPropProgressByCond(java.lang.String, java.lang.Short, java.lang.String)
	 */
	@Override
	public MtlCampsegProgress getCampPropProgressByCond(String campsegId, Short stepId, String flowId) throws Exception {
		MtlCampsegProgress obj = null;
		final StringBuffer sql=new StringBuffer();
	 sql.append("from MtlCampsegProgress mp where 1=1 ").append(" and mp.id.campsegId='").append(campsegId).append( "'").append(" and mp.id.flowId='").append(flowId).append( "'").append(" and mp.id.stepId=").append(stepId);
		//String sql = "from MtlCampsegProgress mp where 1=1 " + " and mp.id.campsegId='" + campsegId + "'" + " and mp.id.flowId='" + flowId + "'" + " and mp.id.stepId=" + stepId;
		//final String tmpSql = sql;
		List list = getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(sql.toString());
				return query.list();
			}
		});
		if (list.size() > 0)
			obj = (MtlCampsegProgress) list.get(0);

		return obj;
	}

	@Override
	public void saveOrUpdateCampsegProgress(MtlCampsegProgress progress)
			throws Exception {
		this.getHibernateTemplate().saveOrUpdate(progress);
	}

}

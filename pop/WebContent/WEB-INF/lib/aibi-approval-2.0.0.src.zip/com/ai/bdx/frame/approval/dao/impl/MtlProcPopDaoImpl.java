package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.dao.IMtlProcPopDao;
import com.ai.bdx.frame.approval.model.MtlProcPop;
import com.ai.bdx.frame.approval.model.MtlProcPopId;

/**
 * Data access object (DAO) for domain model class MtlProcPop.
 *
 * @see hibernate.MtlProcPop
 * @author MyEclipse Persistence Tools
 */

public class MtlProcPopDaoImpl extends HibernateDaoSupport implements
		IMtlProcPopDao {
	private static Logger log = LogManager.getLogger();

	// property constants

	@Override
	protected void initDao() {
		// do nothing
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hibernate.IMtlProcPopDao#save(hibernate.MtlProcPop)
	 */
	@Override
	public void save(MtlProcPop transientInstance) {
		log.debug("saving MtlProcPop instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hibernate.IMtlProcPopDao#delete(hibernate.MtlProcPop)
	 */
	@Override
	public void delete(MtlProcPop persistentInstance) {
		log.debug("deleting MtlProcPop instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	@Override
	public List findPopRecord(final Integer procId) {
		final String sql = "from MtlProcPop m where 1=1 and m.id.procId = "
				+ procId;
		// +" and m.id.startTime = :startTime";
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException,
					SQLException {
				Query query = s.createQuery(sql);
				// query.setParameter("startTime", pob.getId().getStartTime() ,
				// Hibernate.TIMESTAMP);
				return query.list();
			}
		});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hibernate.IMtlProcPopDao#findById(hibernate.MtlProcPopId)
	 */
	@Override
	public MtlProcPop findById(MtlProcPopId id) {
		log.debug("getting MtlProcPop instance with id: " + id);
		try {
			MtlProcPop instance = (MtlProcPop) getHibernateTemplate().get("com.ai.bdx.frame.approval.model.MtlProcPop", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hibernate.IMtlProcPopDao#findByExample(hibernate.MtlProcPop)
	 */
	@Override
	public List findByExample(MtlProcPop instance) {
		log.debug("finding MtlProcPop instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hibernate.IMtlProcPopDao#findByProperty(java.lang.String,
	 * java.lang.Object)
	 */
	@Override
	public List findByProperty(String propertyName, Object value) {
		log.debug("finding MtlProcPop instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from MtlProcPop as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hibernate.IMtlProcPopDao#findAll()
	 */
	@Override
	public List findAll() {
		log.debug("finding all MtlProcPop instances");
		try {
			String queryString = "from MtlProcPop";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hibernate.IMtlProcPopDao#merge(hibernate.MtlProcPop)
	 */
	@Override
	public MtlProcPop merge(MtlProcPop detachedInstance) {
		log.debug("merging MtlProcPop instance");
		try {
			MtlProcPop result = (MtlProcPop) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hibernate.IMtlProcPopDao#attachDirty(hibernate.MtlProcPop)
	 */
	@Override
	public void attachDirty(MtlProcPop instance) {
		log.debug("attaching dirty MtlProcPop instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see hibernate.IMtlProcPopDao#attachClean(hibernate.MtlProcPop)
	 */
	@Override
	public void attachClean(MtlProcPop instance) {
		log.debug("attaching clean MtlProcPop instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static IMtlProcPopDao getFromApplicationContext(
			ApplicationContext ctx) {
		return (IMtlProcPopDao) ctx.getBean("MtlProcPopDAO");
	}
}
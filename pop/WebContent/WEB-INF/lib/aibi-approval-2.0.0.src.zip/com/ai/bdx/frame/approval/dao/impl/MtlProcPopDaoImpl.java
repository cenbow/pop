/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlProcPopDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlProcPop;
/*     */ import com.ai.bdx.frame.approval.model.MtlProcPopId;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlProcPopDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlProcPopDao
/*     */ {
/*  29 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   protected void initDao()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void save(MtlProcPop transientInstance)
/*     */   {
/*  45 */     log.debug("saving MtlProcPop instance");
/*     */     try {
/*  47 */       getHibernateTemplate().save(transientInstance);
/*  48 */       log.debug("save successful");
/*     */     } catch (RuntimeException re) {
/*  50 */       log.error("save failed", re);
/*  51 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(MtlProcPop persistentInstance)
/*     */   {
/*  62 */     log.debug("deleting MtlProcPop instance");
/*     */     try {
/*  64 */       getHibernateTemplate().delete(persistentInstance);
/*  65 */       log.debug("delete successful");
/*     */     } catch (RuntimeException re) {
/*  67 */       log.error("delete failed", re);
/*  68 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findPopRecord(Integer procId)
/*     */   {
/*  74 */     final String sql = "from MtlProcPop m where 1=1 and m.id.procId = " + procId;
/*     */ 
/*  77 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException
/*     */       {
/*  81 */         Query query = s.createQuery(sql);
/*     */ 
/*  84 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public MtlProcPop findById(MtlProcPopId id)
/*     */   {
/*  96 */     log.debug("getting MtlProcPop instance with id: " + id);
/*     */     try {
/*  98 */       return (MtlProcPop)getHibernateTemplate().get("com.ai.bdx.frame.approval.model.MtlProcPop", id);
/*     */     }
/*     */     catch (RuntimeException re) {
/* 101 */       log.error("get failed", re);
/* 102 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findByExample(MtlProcPop instance)
/*     */   {
/* 113 */     log.debug("finding MtlProcPop instance by example");
/*     */     try {
/* 115 */       List results = getHibernateTemplate().findByExample(instance);
/* 116 */       log.debug("find by example successful, result size: " + results.size());
/*     */ 
/* 118 */       return results;
/*     */     } catch (RuntimeException re) {
/* 120 */       log.error("find by example failed", re);
/* 121 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findByProperty(String propertyName, Object value)
/*     */   {
/* 133 */     log.debug("finding MtlProcPop instance with property: " + propertyName + ", value: " + value);
/*     */     try
/*     */     {
/* 136 */       String queryString = "from MtlProcPop as model where model." + propertyName + "= ?";
/*     */ 
/* 138 */       return getHibernateTemplate().find(queryString, value);
/*     */     } catch (RuntimeException re) {
/* 140 */       log.error("find by property name failed", re);
/* 141 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List findAll()
/*     */   {
/* 152 */     log.debug("finding all MtlProcPop instances");
/*     */     try {
/* 154 */       String queryString = "from MtlProcPop";
/* 155 */       return getHibernateTemplate().find(queryString);
/*     */     } catch (RuntimeException re) {
/* 157 */       log.error("find all failed", re);
/* 158 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public MtlProcPop merge(MtlProcPop detachedInstance)
/*     */   {
/* 169 */     log.debug("merging MtlProcPop instance");
/*     */     try {
/* 171 */       MtlProcPop result = (MtlProcPop)getHibernateTemplate().merge(detachedInstance);
/*     */ 
/* 173 */       log.debug("merge successful");
/* 174 */       return result;
/*     */     } catch (RuntimeException re) {
/* 176 */       log.error("merge failed", re);
/* 177 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void attachDirty(MtlProcPop instance)
/*     */   {
/* 188 */     log.debug("attaching dirty MtlProcPop instance");
/*     */     try {
/* 190 */       getHibernateTemplate().saveOrUpdate(instance);
/* 191 */       log.debug("attach successful");
/*     */     } catch (RuntimeException re) {
/* 193 */       log.error("attach failed", re);
/* 194 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void attachClean(MtlProcPop instance)
/*     */   {
/* 205 */     log.debug("attaching clean MtlProcPop instance");
/*     */     try {
/* 207 */       getHibernateTemplate().lock(instance, LockMode.NONE);
/* 208 */       log.debug("attach successful");
/*     */     } catch (RuntimeException re) {
/* 210 */       log.error("attach failed", re);
/* 211 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static IMtlProcPopDao getFromApplicationContext(ApplicationContext ctx)
/*     */   {
/* 217 */     return (IMtlProcPopDao)ctx.getBean("MtlProcPopDAO");
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlProcPopDaoImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMtlResListDao;
import com.ai.bdx.frame.approval.model.MtlResList;

public class MtlResListDaoImpl extends HibernateDaoSupport implements
		IMtlResListDao {
	private static Logger log = LogManager.getLogger();

	/**
	 *
	 */
	public List getResObjList() {
		return this.getHibernateTemplate().find(" from MtlResList");
	}

	public List getResFlackObjList() {
		return this.getHibernateTemplate().find(
				" from MtlResList res " + "where res.resType = "
						+ MpmCONST.RESTYPE_FLACK + "  and " + "(res.resFlag="
						+ MpmCONST.RES_ENTITY_VALID + "  or res.resFlag="
						+ MpmCONST.RES_ENTITY_FOREVER_VALID + ")");
	}

	public List getResEntityObjList() {
		return this.getHibernateTemplate().find(
				" from MtlResList res " + "where res.resType = "
						+ MpmCONST.RESTYPE_ENTITY);
	}

	/**
	 * 保存一条记录
	 */
	public String save(MtlResList mtlResList) throws Exception {
		String result = "";
		try {
			result = (String) this.getHibernateTemplate().save(mtlResList);
		} catch (Exception e) {
			log.error("", e);
		}
		return result;
	}

	/**
	 * 修改一条记录
	 */
	public void update(MtlResList mtlResList) throws Exception {
		try {
			getHibernateTemplate().update(mtlResList);
		} catch (Exception e) {
			log.error("", e);
		}
		return;
	}

	/**
	 * 删除一条记录
	 */
	public void delete(String resCode) throws Exception {
		try {
			String sql = "";
			if (resCode.indexOf(",") <= 0) {
				sql = "from MtlResList as a where a.resCode='" + resCode + "'";
			} else {
				sql = "from MtlResList as a where a.resCode in " + resCode;
			}
			// getHibernateTemplate().delete(sql);
			final String delsql = sql;
			this.getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session arg0)
						throws HibernateException, SQLException {
					Query query = arg0.createQuery("delete " + delsql);
					query.executeUpdate();
					return null;
				}
			});
		} catch (Exception e) {
			log.error("", e);
		}
		return;
	}

	/**
	 * 取一条记录
	 * 
	 * @param resCode
	 * @return
	 * @throws Exception
	 */
	public MtlResList findByCode(String resCode, String resFlag)
			throws Exception {
		MtlResList result = new MtlResList();
		try {
			String sql = "from MtlResList as a where a.resCode='" + resCode
					+ "'";
			if (resFlag != null && !"".equals(resFlag)) {
				sql = sql + " and a.resFlag=" + resFlag;
			}
			List list = this.getHibernateTemplate().find(sql);
			if (list != null && list.size() > 0) {
				result = (MtlResList) list.get(0);
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return result;

	}

	public List findByCostCode(String costCode) throws Exception {
		List result = new ArrayList();
		try {
			String sql = " from MtlResList as a where 1=1 ";
			if (costCode != null && !"".equals(costCode)) {
				sql = sql + " and a.costCode=" + costCode;
			}
			sql = sql
					+ " and a.resCode<>'RES0000001' and a.resCode<>'RES0000002'";
			sql = sql + " order by a.resName";
			result = this.getHibernateTemplate().find(sql);
		} catch (Exception e) {
			log.error("", e);
		}
		return result;
	}

}

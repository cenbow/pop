/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlResListDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlResList;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlResListDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlResListDao
/*     */ {
/*  21 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public List getResObjList()
/*     */   {
/*  27 */     return getHibernateTemplate().find(" from MtlResList");
/*     */   }
/*     */ 
/*     */   public List getResFlackObjList() {
/*  31 */     return getHibernateTemplate().find(" from MtlResList res where res.resType = 40  and (res.resFlag=1  or res.resFlag=9)");
/*     */   }
/*     */ 
/*     */   public List getResEntityObjList()
/*     */   {
/*  39 */     return getHibernateTemplate().find(" from MtlResList res where res.resType = 10");
/*     */   }
/*     */ 
/*     */   public String save(MtlResList mtlResList)
/*     */     throws Exception
/*     */   {
/*  48 */     String result = "";
/*     */     try {
/*  50 */       result = (String)getHibernateTemplate().save(mtlResList);
/*     */     } catch (Exception e) {
/*  52 */       log.error("", e);
/*     */     }
/*  54 */     return result;
/*     */   }
/*     */ 
/*     */   public void update(MtlResList mtlResList)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  62 */       getHibernateTemplate().update(mtlResList);
/*     */     } catch (Exception e) {
/*  64 */       log.error("", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(String resCode)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  74 */       String sql = "";
/*  75 */       if (resCode.indexOf(",") <= 0)
/*  76 */         sql = "from MtlResList as a where a.resCode='" + resCode + "'";
/*     */       else {
/*  78 */         sql = "from MtlResList as a where a.resCode in " + resCode;
/*     */       }
/*     */ 
/*  81 */       final String delsql = sql;
/*  82 */       getHibernateTemplate().execute(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
/*  85 */           Query query = arg0.createQuery("delete " + delsql);
/*  86 */           query.executeUpdate();
/*  87 */           return null;
/*     */         } } );
/*     */     }
/*     */     catch (Exception e) {
/*  91 */       log.error("", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public MtlResList findByCode(String resCode, String resFlag)
/*     */     throws Exception
/*     */   {
/* 105 */     MtlResList result = new MtlResList();
/*     */     try {
/* 107 */       String sql = "from MtlResList as a where a.resCode='" + resCode + "'";
/*     */ 
/* 109 */       if ((resFlag != null) && (!"".equals(resFlag))) {
/* 110 */         sql = sql + " and a.resFlag=" + resFlag;
/*     */       }
/* 112 */       List list = getHibernateTemplate().find(sql);
/* 113 */       if ((list != null) && (list.size() > 0))
/* 114 */         result = (MtlResList)list.get(0);
/*     */     }
/*     */     catch (Exception e) {
/* 117 */       log.error("", e);
/*     */     }
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */   public List findByCostCode(String costCode) throws Exception
/*     */   {
/* 124 */     List result = new ArrayList();
/*     */     try {
/* 126 */       String sql = " from MtlResList as a where 1=1 ";
/* 127 */       if ((costCode != null) && (!"".equals(costCode))) {
/* 128 */         sql = sql + " and a.costCode=" + costCode;
/*     */       }
/* 130 */       sql = sql + " and a.resCode<>'RES0000001' and a.resCode<>'RES0000002'";
/*     */ 
/* 132 */       sql = sql + " order by a.resName";
/* 133 */       result = getHibernateTemplate().find(sql);
/*     */     } catch (Exception e) {
/* 135 */       log.error("", e);
/*     */     }
/* 137 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlResListDaoImpl
 * JD-Core Version:    0.6.2
 */
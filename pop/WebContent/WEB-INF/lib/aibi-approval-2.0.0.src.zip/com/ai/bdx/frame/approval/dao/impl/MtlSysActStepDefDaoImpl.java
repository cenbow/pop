package com.ai.bdx.frame.approval.dao.impl;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.impl.SessionImpl;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMtlSysActStepDefDao;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;

/*
 * Created on 3:46:43 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlSysActStepDefDaoImpl extends HibernateDaoSupport implements IMtlSysActStepDefDao {
	private static Logger log = LogManager.getLogger();
	public MtlSysActStepDefDaoImpl() {
		super();
	}

	public static final String CAMP_COLUMN = " CAMP_ID,START_DATE,END_DATE,CREATE_USERID,CAMP_NAME,CREATE_DATE,CAMP_REPLAY_STATUS,STATUS_CHG_TYPE,APPROVE_LEV,CAMP_TYPE,CAMP_DESC,CAMP_STRAGE_DESC,OBJECTIVE_DESC,FLOW_ID,CAMP_PRI_ID,CAMP_DRV_ID,CAMP_STATUS,DEPTID,CITY_ID ";

	public static final String CAMP_COLUMN_BAK = " CAMP_ID,START_DATE,END_DATE,CREATE_USERID,CAMP_NAME,CREATE_DATE,CAMP_REPLAY_STATUS,CAMP_PERFORM_TYPE,APPROVE_LEV,CAMP_TYPE,CAMP_DESC,CAMP_STRAGE_DESC,OBJECTIVE_DESC,FLOW_ID,CAMP_PRI_ID,CAMP_DRV_ID,CAMP_STATUS,DEPART_ID,CITY_ID ";

	public static final String CAMPSEG_COLUMN = " START_DATE,END_DATE,TARGER_USER_NUMS,CONTACTED_USER_NUMS,CONTACT_OKUSER_NUMS,RECEIVED_OKUSER_NUMS,CAMPSEG_STAT_ID,CAMPSEG_ID,CAMP_ID,APPROVE_FLAG,APPROVE_RESULT,APPROVE_RECEIVE_NUMS,CAMPSEG_NO,CAMPSEG_NAME,CREATE_TIME,CAMPSEG_DESC";

	//根据ID得到活动步骤信息。
	@Override
	/*public MtlSysActstepDef getSysActStepDef(Short stepId) throws Exception {
		MtlSysActstepDef obj = null;
		obj = (MtlSysActstepDef) this.getHibernateTemplate().get(MtlSysActstepDef.class, stepId);
		return obj;
	}
*/
	//得到所有的 活动步骤
	public List<?> getSysActStepAll() throws Exception {
		List<?> result = new ArrayList();
		try {
			result = this.getHibernateTemplate().find("from MtlSysActstepDef as a order by a.stepId");
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
		return result;
	}

	

	/**
	 * 取得某个活动拥有的步骤数组
	 */
	@Override
	public String getExistsStepArray(String flowId) throws Exception {
		StringBuffer str = new StringBuffer("");
		str.append("var sysExistsCount=0;\n sysExistsStepDef = new Array();\n");
		int count = 0;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "select t1.* from mtl_sys_actstep_def t1, ap_sys_actflow_def t2, mtl_sys_flowstep_def t3   where t2.flow_id=? and t2.flow_id=t3.flow_id   and t3.step_id=t1.step_id order by t1.step_id";
			sqlca.execute(sql,new String[]{flowId});
			while (sqlca.next()) {
				str.append("sysExistsStepDef[" + count + "] = new Array(\"" + sqlca.getString("step_id") + "\",\"" + sqlca.getString("step_name") + "\");\n");
				count++;
			}
			str.append("sysExistsCount=" + count + ";\n");
		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return str.toString();
	}

	/**
	 * 取某个活动流程在某个阶段下的所有步骤信息
	 */
	@Override
	public List<?> getSysActStepDefByFlowId(String flowId, Short stepPhase) throws Exception {
		HashMap<String,Object> map=new HashMap<String,Object>();
		String sql = "select t1 from MtlSysActstepDef t1, MtlSysFlowstepDef t2   where t2.id.flowId=:flowId and t2.id.stepId=t1.stepId";
		map.put("flowId", flowId);
		if (stepPhase != null){
			sql += " and t1.stepPhase=:stepPhase" ;
			map.put("stepPhase", stepPhase.intValue());
		}
		sql += " order by t1.stepId";
		final String tmpSql = sql;
		final HashMap<String,Object> paramMap=map;
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session s) throws HibernateException, SQLException {
				Query query = s.createQuery(tmpSql);
				for(String key:paramMap.keySet()){
					query.setParameter(key, paramMap.get(key));
				}
				return query.list();
			}
		});
	}

	/**
	 * 取所有需要手工改变状态的活动
	 */
	@Override
	public List<?> getHandChgStatusAct(String createUserid) throws Exception {
		List list = new ArrayList();
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "select a.camp_name camp_name,a.camp_id camp_id from mtl_camp_baseinfo a ,ap_sys_actflow_def b   where a.flow_id=b.flow_id and b.status_chg_type=? and a.camp_status=?";
			Object[] params=new Object[]{MpmCONST.COMPAIGN_STATUS_CHG_BY_HAND,MpmCONST.COMPAIGN_STATUS_NORMAL};
			if (createUserid != null && !"".equals(createUserid)) {
				sql = sql + " and a.create_userid=? ";
		        params=new Object[]{MpmCONST.COMPAIGN_STATUS_CHG_BY_HAND,MpmCONST.COMPAIGN_STATUS_NORMAL,createUserid};
			}
			sql = sql + " order by a.camp_name";
			sqlca.execute(sql,params);
			while (sqlca.next()) {
				list.add(new LabelValueBean(sqlca.getString("camp_name"), sqlca.getString("camp_id")));
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return list;
	}

	/**
	 * 得到需要手动变更活动的波次信息数组
	 */
	@Override
	public String getSegArray(String createUserid) throws Exception {
		StringBuffer str = new StringBuffer("");
		str.append("var segCount=0;\n segDefArray = new Array();\n");
		int count = 0;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "select c.campseg_id,c.camp_id,c.campseg_name from mtl_camp_baseinfo a ,ap_sys_actflow_def b ,mtl_camp_seginfo c  where a.flow_id=b.flow_id and b.status_chg_type=? and a.camp_id=c.camp_id";
			Object[] params=new Object[]{MpmCONST.COMPAIGN_STATUS_CHG_BY_HAND};
			if (createUserid != null && !"".equals(createUserid)) {
				sql = sql + " and a.create_userid=? ";
				params=new Object[]{MpmCONST.COMPAIGN_STATUS_CHG_BY_HAND,createUserid};
			}
			sql = sql + " order by c.campseg_id";
			sqlca.execute(sql,params);
			while (sqlca.next()) {
				str.append("segDefArray[" + count + "] = new Array(\"" + sqlca.getString("campseg_id") + "\",\"" + sqlca.getString("campseg_name") + "\",\"" + sqlca.getString("camp_id") + "\");\n");
				count++;
			}
			str.append("segCount=" + count + ";\n");

		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return str.toString();
	}

	/**
	 * 得到某个波次的步骤信息
	 */
	@Override
	public String getSegStepArray(String campseg_id) throws Exception {
		StringBuffer str = new StringBuffer("");
		str.append("var segStepCount=0;\n segStepDefArray = new Array();\n");
		int count = 0;
		Sqlca sqlca = null;
		String exeSuccess = Short.valueOf(MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_SUCCESS).toString();
		String yesOrNo = "0";
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "select a.step_id,c.step_name,a.perform_flag from mtl_campseg_progress a , mtl_camp_seginfo b ,mtl_sys_actstep_def c  where a.campseg_id=b.campseg_id and a.step_id=c.step_id and a.campseg_id=? order by a.step_id";
			sqlca.execute(sql,new String[]{campseg_id});
			while (sqlca.next()) {
				
				if (exeSuccess.equals(sqlca.getString("perform_flag"))){
					yesOrNo = "1";
				}
				else{
					yesOrNo = "0";
				}

				str.append("segStepDefArray[" + count + "] = new Array(\"" + sqlca.getString("step_id") + "\",\"" + sqlca.getString("step_name") + "\",\"" + yesOrNo + "\");\n");
				count++;
			}
			str.append("segStepCount=" + count + ";\n");

		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return str.toString();
	}

	//得到波次可变更的状态
	@Override
	public List getSegCanStatus(String campId, String campsegId, String campsegStatId) throws Exception {
		List result = new ArrayList();
		Sqlca sqlca = null;
		int flag = 0;
		String approveFlag = "";
		String campsegExeFlag = "";
		try {
			//判断某个波次是否需要审批
			List list = this.getHibernateTemplate().find("from MtlCampsegProgress as a where a.id.campsegId='" + campsegId + "' and a.id.stepId=" + MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_AUDIT);
			if (list != null && list.size() > 0) {
				approveFlag = "OK";
			}

			//判断某个波次所属活动是否有波次在进行
			List list3 = this.getHibernateTemplate().find("from MtlCampSeginfo as a where a.campId='" + campId + "' and a.campsegStatId=" + MpmCONST.MPM_CAMPSEG_STAT_ZXZT);
			if (list3 != null && list3.size() > 0) {
				campsegExeFlag = "OK";
			}

			//判断某个波次是否需要评估
			//List list1  = this.getHibernateTemplate().find("from MtlCampsegProgress as a where a.id.campsegId='"+campsegId+"' and a.id.stepId="+MpmCONST.MPM_ACTIVE_STEP_ID_EVALUATE);
			//List list2  = this.getHibernateTemplate().find("from MtlCampsegProgressBak as a where a.id.campsegId='"+campsegId+"' and a.id.stepId="+MpmCONST.MPM_ACTIVE_STEP_ID_EVALUATE);
			//if((list1 != null && list1.size() > 0) || (list2 !=null && list2.size() > 0)){
			//	 evaluateFlag = "OK";
			// }

			StringBuffer sql = new StringBuffer("");
			sql.append("select campseg_stat_id,campseg_stat_name from dim_campseg_stat where ");

			if (campsegStatId.equals(MpmCONST.MPM_CAMPSEG_STAT_CHZT)) {
				sql.append(" campseg_stat_id =" + MpmCONST.MPM_CAMPSEG_STAT_HDJX + " ");
				flag++;
			}

			if (campsegStatId.equals(MpmCONST.MPM_CAMPSEG_STAT_HDJX)) {
				sql.append(" campseg_stat_id = " + MpmCONST.MPM_CAMPSEG_STAT_CHZT + " ");
				if (approveFlag.length() > 0){
					sql.append(" or campseg_stat_id =" + MpmCONST.MPM_CAMPSEG_STAT_HDSP + " ");
				}
				else {
					sql.append(" or campseg_stat_id=" + MpmCONST.MPM_CAMPSEG_STAT_DDZX + " ");
					if (campsegExeFlag.length() <= 0) {
						sql.append(" or campseg_stat_id=" + MpmCONST.MPM_CAMPSEG_STAT_ZXZT + " ");
					}
				}
				flag++;
			}

			if (campsegStatId.equals(MpmCONST.MPM_CAMPSEG_STAT_SPYG)) {
				sql.append(" campseg_stat_id =" + MpmCONST.MPM_CAMPSEG_STAT_HDJX + " ");
				flag++;
			}

			if (campsegStatId.equals(MpmCONST.MPM_CAMPSEG_STAT_SPYZ)) {
				sql.append(" 1=2 ");
				flag++;
			}

			if (campsegStatId.equals(MpmCONST.MPM_CAMPSEG_STAT_HDSP)) {
				sql.append(" 1=2 ");
				//sql.append(" or campseg_stat_id="+MpmCONST.MPM_CAMPSEG_STAT_SPYG+" ");
				flag++;
			}

			if (campsegStatId.equals(MpmCONST.MPM_CAMPSEG_STAT_DDZX)) {
				sql.append(" campseg_stat_id =" + MpmCONST.MPM_CAMPSEG_STAT_ZXZT + " ");
				flag++;
			}

			if (campsegStatId.equals(MpmCONST.MPM_CAMPSEG_STAT_ZXZT)) {
				//if(evaluateFlag.length() >0 ){
				//    sql.append(" campseg_stat_id="+MpmCONST.MPM_CAMPSEG_STAT_PGZT+" ");
				//}else{
				sql.append(" campseg_stat_id =" + MpmCONST.MPM_CAMPSEG_STAT_HDWC + " ");
				//}
				flag++;
			}

			if (campsegStatId.equals(MpmCONST.MPM_CAMPSEG_STAT_PGZT)) {
				sql.append(" campseg_stat_id =" + MpmCONST.MPM_CAMPSEG_STAT_HDWC + " ");
				flag++;
			}

			if (flag == 0) {
				return result;
			}
			sql.append(" or campseg_stat_id=" + MpmCONST.MPM_CAMPSEG_STAT_HDZZ + " ");
			sql.append(" order by campseg_stat_id");

			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			sqlca.execute(sql.toString());
			while (sqlca.next()) {
				result.add(new LabelValueBean(sqlca.getString("campseg_stat_name"), sqlca.getString("campseg_stat_id")));
				//map.put(sqlca.getString("campseg_stat_id"),sqlca.getString("campseg_stat_name"));
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return result;
	}

	/**
	 * 更新营销活动状态
	 */
	@Override
	public boolean updateCampsegStatus(String campId, String campsegId, String campsegStatId) throws Exception {
		boolean flag = false;

		try {
			String sql = "";
			if (StringUtils.isNotEmpty(campId)) {
				List<String> campsegIdList = new ArrayList<String>();
				String seginfoQuery = "select campsegId from MtlCampSeginfo where campId = ? and campsegStatId != ?";
				List<String> tmpList = this.getHibernateTemplate().find(seginfoQuery, new Object[]{campId,Short.valueOf(MpmCONST.MPM_CAMPSEG_STAT_HDWC)});
				if(tmpList != null){
					campsegIdList.addAll(tmpList);
				}
				while( tmpList != null && tmpList.size()>0 ){
					seginfoQuery = "select campsegId from MtlCampSeginfo where campsegPid in( :ids ) and campsegStatId !=:campsegStatId ";
					Query campsegIdQuery = this.getSession().createQuery(seginfoQuery);
					campsegIdQuery.setParameter("campsegStatId",Short.valueOf(MpmCONST.MPM_CAMPSEG_STAT_HDWC));
					campsegIdQuery.setParameterList("ids", tmpList);
					tmpList = campsegIdQuery.list();
					campsegIdList.addAll(tmpList);
				}
				if (campsegId != null && campsegIdList.size()> 0){
					sql = "update MtlCampSeginfo set campsegStatId=:campsegStatId where campsegId in( :ids ) ";
					Query updateQuery = this.getSession().createQuery(sql);
					updateQuery.setParameter("campsegStatId", Short.valueOf(campsegStatId));
					updateQuery.setParameterList("ids", campsegIdList);
					updateQuery.executeUpdate();
				}
				flag = true;


			} else {

				List<String> campsegIdList = new ArrayList<String>();
				campsegIdList.add(campsegId);

				String seginfoQuery = "select campsegId from MtlCampSeginfo where campsegPid = ?";
				List<String> tmpList = this.getHibernateTemplate().find(seginfoQuery,campsegId);
				if( tmpList != null ) {
					campsegIdList.addAll(tmpList);
				}
				while( tmpList != null && tmpList.size()>0 ){
					seginfoQuery = "select campsegId from MtlCampSeginfo where campsegPid in( :ids )";
					Query campsegIdQuery = this.getSession().createQuery(seginfoQuery);
					campsegIdQuery.setParameterList("ids", tmpList);
					tmpList = campsegIdQuery.list();
					if(tmpList!=null) {
						campsegIdList.addAll(tmpList);
					}
				}

				if (campsegId != null && campsegIdList.size()> 0){
					sql = "update MtlCampSeginfo set campsegStatId=:campsegStatId where campsegId in( :ids ) ";
					Query updateQuery = this.getSession().createQuery(sql);
					updateQuery.setParameter("campsegStatId", Short.valueOf(campsegStatId));
					updateQuery.setParameterList("ids", campsegIdList);
					updateQuery.executeUpdate();
				}
				flag = true;
			}

		} catch (Exception e) {
			log.error("",e);
		}/* finally {
			if (sqlca != null)
				sqlca.closeAll();
			if (sqlca1 != null)
				sqlca1.closeAll();
		}*/
		return flag;
	}

	/**
	 * 更新营销活动资源确认状态
	 */
	@Override
	public boolean updateCampSegConfirmFlag(String campsegId, short campsegConfrimFlag) throws Exception {
		boolean flag = false;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "";
			if (campsegId != null && !"".equals(campsegId)){
				sql = "update mtl_camp_seginfo set confirm_flag=? where campseg_id=?";
			}
			if (sql.length() > 0){
				sqlca.execute(sql,new Object[]{campsegConfrimFlag,campsegId});
			}
			flag = true;

		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return flag;
	}

	/**
	 * 更新营销案资源确认状态
	 */
	@Override
	public boolean updateCampConfirmFlag(String campId, short campsegConfrimFlag) throws Exception {
		boolean flag = false;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "";
			if (campId != null && !"".equals(campId)){
				sql = "update mtl_camp_baseinfo set confirm_flag=? where camp_id=?";
			}
			if (sql.length() > 0){
				sqlca.execute(sql,new Object[]{campsegConfrimFlag,campId});
			}
			flag = true;

		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return flag;
	}

	/**
	 * 更新营销活动审批结果状态
	 */
	@Override
	public boolean updateCampsegApproveResult(String campsegId) throws Exception {
		boolean flag = false;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "";
			if (campsegId != null && !"".equals(campsegId)){
				sql = "update mtl_camp_seginfo set approve_result=?  where campseg_id=?";
			}

			if (sql.length() > 0){
				sqlca.execute(sql,new Object[]{MpmCONST.MPM_SEG_APPROVE_RESULT_WAITING,campsegId});
			}
			flag = true;
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return flag;
	}

	/**
	 * 更新营销案审批结果状态
	 */
	@Override
	public boolean updateCampApproveResult(String campId) throws Exception {
		boolean flag = false;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "";
			if (campId != null && !"".equals(campId)){
				sql = "update mtl_camp_baseinfo set approve_result=? where camp_id=?";
			}

			if (sql.length() > 0){
				sqlca.execute(sql,new Object[]{MpmCONST.MPM_SEG_APPROVE_RESULT_WAITING,campId});
			}
			flag = true;
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return flag;
	}

	/**
	 * 更新波次审批波次
	 */
	@Override
	public boolean updateCampsegApproveNums(String campsegId) throws Exception {
		boolean flag = false;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "";
			if (campsegId != null && !"".equals(campsegId)){
				sql = "update mtl_camp_seginfo set approve_receive_nums=(case when approve_receive_nums is null then  1 else approve_receive_nums+1 end) where campseg_id=?";
			}

			if (sql.length() > 0){
				sqlca.execute(sql,new String[]{campsegId});
			}
			flag = true;
		} catch (Exception e) {
log.error("",e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return flag;
	}

	/**
	 * 将活动状态改为终止或完成
	 */
	@Override
	public boolean updateCampStatus(String campsegId, String campStatus) throws Exception {
		boolean flag = false;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "update mtl_camp_baseinfo set camp_status=? where camp_id=?";
			sqlca.execute(sql,new String[]{campStatus,campsegId});
			flag = true;
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}
		return flag;
	}

	//删除活动波次信息
	@Override
	public boolean deleteCampseg(String campId, String campsegId) throws Exception {
		boolean flag = false;
		try {
			String sql = "from MtlCampSeginfo as a where 1=1";
			if (campId != null && !"".equals(campId)) {
				sql = sql + " and a.campId='" + campId + "'";
			}
			if (campsegId != null && !"".equals(campsegId)) {
				sql = sql + " and a.campsegId='" + campsegId + "'";
			}

			if (sql.charAt(sql.length() - 1) != '1') {
				this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
			}
			flag = true;
		} catch (Exception e) {
log.error("",e);
		}
		return flag;
	}

	//删除活动信息
	@Override
	public boolean deleteCamp(String campId) throws Exception {
		boolean flag = false;
		try {
			String sql = "from MtlCampBaseinfo as a where 1=1";
			if (campId != null && !"".equals(campId)) {
				sql = sql + " and a.campId='" + campId + "'";
			}

			if (sql.charAt(sql.length() - 1) != '1') {
				this.getHibernateTemplate().deleteAll(this.getHibernateTemplate().find(sql));
			}
			flag = true;
		} catch (Exception e) {
log.error("",e);
		}
		return flag;
	}

	//插入波次信息备份表
	@Override
	public boolean insertCampsegBak(String campId) throws Exception {
		boolean flag = false;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			//String sql = "insert into mtl_camp_seginfo_bak(" + CAMPSEG_COLUMN + ") select " + CAMPSEG_COLUMN + " from mtl_camp_seginfo where camp_id='" + campId + "'";
			String sql = "insert into mtl_camp_seginfo_bak(#CAMPSEG_COLUMN#) select #CAMPSEG_COLUMN# from mtl_camp_seginfo where camp_id=?";
			sql=sql.replace("#CAMPSEG_COLUMN#", CAMPSEG_COLUMN).replace("#CAMPSEG_COLUMN#", CAMPSEG_COLUMN);
			sqlca.execute(sql,new String[]{campId});
		} catch (Exception e) {
			log.error("",e);
		}
		return flag;
	}

	//插入活动信息备份表
	@Override
	public boolean insertCampBak(String campId) throws Exception {
		boolean flag = false;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			//String sql = "insert into mtl_camp_baseinfo_bak(" + CAMP_COLUMN_BAK + ") select " + CAMP_COLUMN + " from mtl_camp_baseinfo where camp_id='" + campId + "'";
			String sql = "insert into mtl_camp_baseinfo_bak(#CAMP_COLUMN_BAK#) select #CAMP_COLUMN# from mtl_camp_baseinfo where camp_id=?";
			sql=sql.replace("#CAMP_COLUMN_BAK#", CAMP_COLUMN_BAK).replace("#CAMP_COLUMN#", CAMP_COLUMN);
			sqlca.execute(sql,new String[]{campId});
		} catch (Exception e) {
			log.error("",e);
		}
		return flag;
	}

	/**
	 * 向波次状态变更历史表插入一条日志记录
	 */
/*	public MtlStatChangeHist saveSegHis(MtlStatChangeHist mtlStatChangeHist) throws Exception {
		try {
			this.getHibernateTemplate().save(mtlStatChangeHist);
		} catch (Exception e) {
			log.error("",e);
		}
		return mtlStatChangeHist;
	}*/

	/**
	 * 根据一个活动标识，取判断所有的波次状态，如果波次信息都为完成状态，则将活动状态也改成完成状态
	 * @return
	 * @throws Exception
	 */
	@Override
	public boolean getCampsegStatus(String campId) throws Exception {
		boolean flag = false;
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(((SessionImpl)this.getSession()).connection());
			String sql = "select campseg_stat_id from mtl_camp_seginfo a where a.camp_id=?";
			sqlca.execute(sql,new String[]{campId});
			while (sqlca.next()) {
				String str=sqlca.getString("campseg_stat_id");
				if (MpmCONST.MPM_CAMPSEG_STAT_HDWC.equals(str) || MpmCONST.MPM_CAMPSEG_STAT_HDZZ.equals(str)) {
					flag = true;
				} else {
					flag = false;
					break;
				}
			}
		} catch (Exception e) {
			log.error("",e);
		} finally {
			if (sqlca != null){
				sqlca.closeAll();
			}
		}

		return flag;
	}

	
	/**
	 * 取得所有活动步骤数组
	 */
	public String getSysActStepArray() throws Exception {
		StringBuffer str = new StringBuffer("");
	/*	str.append("var sysActStepCount=0;\n sysActStepDef = new Array();\n");
		int count = 0;
		try {
			List list = getHibernateTemplate().find("from MtlSysActstepDef as a order by a.stepId");
			Iterator i = list.iterator();
			while (i.hasNext()) {
				MtlSysActstepDef mtlSysActstepDef = (MtlSysActstepDef) i.next();
				str.append("sysActStepDef[" + count + "] = new Array(\"" + mtlSysActstepDef.getStepId() + "\",\"" + mtlSysActstepDef.getStepName() + "\");\n");
				count++;
			}
			str.append("sysActStepCount=" + count + ";\n");
		} catch (Exception ex) {
			log.error("",ex);
			throw ex;
		}*/
		return str.toString();

	}
}

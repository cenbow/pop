/*     */ package com.ai.bdx.frame.approval.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlSysActStepDefDao;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.impl.SessionImpl;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class MtlSysActStepDefDaoImpl extends HibernateDaoSupport
/*     */   implements IMtlSysActStepDefDao
/*     */ {
/*  36 */   private static Logger log = LogManager.getLogger();
/*     */   public static final String CAMP_COLUMN = " CAMP_ID,START_DATE,END_DATE,CREATE_USERID,CAMP_NAME,CREATE_DATE,CAMP_REPLAY_STATUS,STATUS_CHG_TYPE,APPROVE_LEV,CAMP_TYPE,CAMP_DESC,CAMP_STRAGE_DESC,OBJECTIVE_DESC,FLOW_ID,CAMP_PRI_ID,CAMP_DRV_ID,CAMP_STATUS,DEPTID,CITY_ID ";
/*     */   public static final String CAMP_COLUMN_BAK = " CAMP_ID,START_DATE,END_DATE,CREATE_USERID,CAMP_NAME,CREATE_DATE,CAMP_REPLAY_STATUS,CAMP_PERFORM_TYPE,APPROVE_LEV,CAMP_TYPE,CAMP_DESC,CAMP_STRAGE_DESC,OBJECTIVE_DESC,FLOW_ID,CAMP_PRI_ID,CAMP_DRV_ID,CAMP_STATUS,DEPART_ID,CITY_ID ";
/*     */   public static final String CAMPSEG_COLUMN = " START_DATE,END_DATE,TARGER_USER_NUMS,CONTACTED_USER_NUMS,CONTACT_OKUSER_NUMS,RECEIVED_OKUSER_NUMS,CAMPSEG_STAT_ID,CAMPSEG_ID,CAMP_ID,APPROVE_FLAG,APPROVE_RESULT,APPROVE_RECEIVE_NUMS,CAMPSEG_NO,CAMPSEG_NAME,CREATE_TIME,CAMPSEG_DESC";
/*     */ 
/*     */   public List<?> getSysActStepAll()
/*     */     throws Exception
/*     */   {
/*  57 */     List result = new ArrayList();
/*     */     try {
/*  59 */       result = getHibernateTemplate().find("from MtlSysActstepDef as a order by a.stepId");
/*     */     } catch (Exception e) {
/*  61 */       log.error(e.getMessage(), e);
/*     */     }
/*  63 */     return result;
/*     */   }
/*     */ 
/*     */   public String getExistsStepArray(String flowId)
/*     */     throws Exception
/*     */   {
/*  73 */     StringBuffer str = new StringBuffer("");
/*  74 */     str.append("var sysExistsCount=0;\n sysExistsStepDef = new Array();\n");
/*  75 */     int count = 0;
/*  76 */     Sqlca sqlca = null;
/*     */     try {
/*  78 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/*  79 */       String sql = "select t1.* from mtl_sys_actstep_def t1, ap_sys_actflow_def t2, mtl_sys_flowstep_def t3   where t2.flow_id=? and t2.flow_id=t3.flow_id   and t3.step_id=t1.step_id order by t1.step_id";
/*  80 */       sqlca.execute(sql, new String[] { flowId });
/*  81 */       while (sqlca.next()) {
/*  82 */         str.append("sysExistsStepDef[" + count + "] = new Array(\"" + sqlca.getString("step_id") + "\",\"" + sqlca.getString("step_name") + "\");\n");
/*  83 */         count++;
/*     */       }
/*  85 */       str.append("sysExistsCount=" + count + ";\n");
/*     */     } catch (Exception e) {
/*  87 */       throw e;
/*     */     } finally {
/*  89 */       if (sqlca != null) {
/*  90 */         sqlca.closeAll();
/*     */       }
/*     */     }
/*  93 */     return str.toString();
/*     */   }
/*     */ 
/*     */   public List<?> getSysActStepDefByFlowId(String flowId, Short stepPhase)
/*     */     throws Exception
/*     */   {
/* 101 */     HashMap map = new HashMap();
/* 102 */     String sql = "select t1 from MtlSysActstepDef t1, MtlSysFlowstepDef t2   where t2.id.flowId=:flowId and t2.id.stepId=t1.stepId";
/* 103 */     map.put("flowId", flowId);
/* 104 */     if (stepPhase != null) {
/* 105 */       sql = sql + " and t1.stepPhase=:stepPhase";
/* 106 */       map.put("stepPhase", Integer.valueOf(stepPhase.intValue()));
/*     */     }
/* 108 */     sql = sql + " order by t1.stepId";
/* 109 */     final String tmpSql = sql;
/* 110 */     final HashMap paramMap = map;
/* 111 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 114 */         Query query = s.createQuery(tmpSql);
/* 115 */         for (String key : paramMap.keySet()) {
/* 116 */           query.setParameter(key, paramMap.get(key));
/*     */         }
/* 118 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List<?> getHandChgStatusAct(String createUserid)
/*     */     throws Exception
/*     */   {
/* 128 */     List list = new ArrayList();
/* 129 */     Sqlca sqlca = null;
/*     */     try {
/* 131 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 132 */       String sql = "select a.camp_name camp_name,a.camp_id camp_id from mtl_camp_baseinfo a ,ap_sys_actflow_def b   where a.flow_id=b.flow_id and b.status_chg_type=? and a.camp_status=?";
/* 133 */       Object[] params = { Short.valueOf(0), Short.valueOf(1) };
/* 134 */       if ((createUserid != null) && (!"".equals(createUserid))) {
/* 135 */         sql = sql + " and a.create_userid=? ";
/* 136 */         params = new Object[] { Short.valueOf(0), Short.valueOf(1), createUserid };
/*     */       }
/* 138 */       sql = sql + " order by a.camp_name";
/* 139 */       sqlca.execute(sql, params);
/* 140 */       while (sqlca.next())
/* 141 */         list.add(new LabelValueBean(sqlca.getString("camp_name"), sqlca.getString("camp_id")));
/*     */     }
/*     */     catch (Exception e) {
/* 144 */       log.error(e.getMessage(), e);
/*     */     } finally {
/* 146 */       if (sqlca != null) {
/* 147 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 150 */     return list;
/*     */   }
/*     */ 
/*     */   public String getSegArray(String createUserid)
/*     */     throws Exception
/*     */   {
/* 158 */     StringBuffer str = new StringBuffer("");
/* 159 */     str.append("var segCount=0;\n segDefArray = new Array();\n");
/* 160 */     int count = 0;
/* 161 */     Sqlca sqlca = null;
/*     */     try {
/* 163 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 164 */       String sql = "select c.campseg_id,c.camp_id,c.campseg_name from mtl_camp_baseinfo a ,ap_sys_actflow_def b ,mtl_camp_seginfo c  where a.flow_id=b.flow_id and b.status_chg_type=? and a.camp_id=c.camp_id";
/* 165 */       Object[] params = { Short.valueOf(0) };
/* 166 */       if ((createUserid != null) && (!"".equals(createUserid))) {
/* 167 */         sql = sql + " and a.create_userid=? ";
/* 168 */         params = new Object[] { Short.valueOf(0), createUserid };
/*     */       }
/* 170 */       sql = sql + " order by c.campseg_id";
/* 171 */       sqlca.execute(sql, params);
/* 172 */       while (sqlca.next()) {
/* 173 */         str.append("segDefArray[" + count + "] = new Array(\"" + sqlca.getString("campseg_id") + "\",\"" + sqlca.getString("campseg_name") + "\",\"" + sqlca.getString("camp_id") + "\");\n");
/* 174 */         count++;
/*     */       }
/* 176 */       str.append("segCount=" + count + ";\n");
/*     */     }
/*     */     catch (Exception e) {
/* 179 */       log.error(e.getMessage(), e);
/*     */     } finally {
/* 181 */       if (sqlca != null) {
/* 182 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 185 */     return str.toString();
/*     */   }
/*     */ 
/*     */   public String getSegStepArray(String campseg_id)
/*     */     throws Exception
/*     */   {
/* 193 */     StringBuffer str = new StringBuffer("");
/* 194 */     str.append("var segStepCount=0;\n segStepDefArray = new Array();\n");
/* 195 */     int count = 0;
/* 196 */     Sqlca sqlca = null;
/* 197 */     String exeSuccess = Short.valueOf((short)1).toString();
/* 198 */     String yesOrNo = "0";
/*     */     try {
/* 200 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 201 */       String sql = "select a.step_id,c.step_name,a.perform_flag from mtl_campseg_progress a , mtl_camp_seginfo b ,mtl_sys_actstep_def c  where a.campseg_id=b.campseg_id and a.step_id=c.step_id and a.campseg_id=? order by a.step_id";
/* 202 */       sqlca.execute(sql, new String[] { campseg_id });
/* 203 */       while (sqlca.next())
/*     */       {
/* 205 */         if (exeSuccess.equals(sqlca.getString("perform_flag"))) {
/* 206 */           yesOrNo = "1";
/*     */         }
/*     */         else {
/* 209 */           yesOrNo = "0";
/*     */         }
/*     */ 
/* 212 */         str.append("segStepDefArray[" + count + "] = new Array(\"" + sqlca.getString("step_id") + "\",\"" + sqlca.getString("step_name") + "\",\"" + yesOrNo + "\");\n");
/* 213 */         count++;
/*     */       }
/* 215 */       str.append("segStepCount=" + count + ";\n");
/*     */     }
/*     */     catch (Exception e) {
/* 218 */       log.error(e.getMessage(), e);
/*     */     } finally {
/* 220 */       if (sqlca != null) {
/* 221 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 224 */     return str.toString();
/*     */   }
/*     */ 
/*     */   public List getSegCanStatus(String campId, String campsegId, String campsegStatId)
/*     */     throws Exception
/*     */   {
/* 230 */     List result = new ArrayList();
/* 231 */     Sqlca sqlca = null;
/* 232 */     int flag = 0;
/* 233 */     String approveFlag = "";
/* 234 */     String campsegExeFlag = "";
/*     */     try
/*     */     {
/* 237 */       List list = getHibernateTemplate().find("from MtlCampsegProgress as a where a.id.campsegId='" + campsegId + "' and a.id.stepId=" + 60);
/* 238 */       if ((list != null) && (list.size() > 0)) {
/* 239 */         approveFlag = "OK";
/*     */       }
/*     */ 
/* 243 */       List list3 = getHibernateTemplate().find("from MtlCampSeginfo as a where a.campId='" + campId + "' and a.campsegStatId=" + "50");
/* 244 */       if ((list3 != null) && (list3.size() > 0)) {
/* 245 */         campsegExeFlag = "OK";
/*     */       }
/*     */ 
/* 255 */       StringBuffer sql = new StringBuffer("");
/* 256 */       sql.append("select campseg_stat_id,campseg_stat_name from dim_campseg_stat where ");
/*     */ 
/* 258 */       if (campsegStatId.equals("20")) {
/* 259 */         sql.append(" campseg_stat_id =30 ");
/* 260 */         flag++;
/*     */       }
/*     */ 
/* 263 */       if (campsegStatId.equals("30")) {
/* 264 */         sql.append(" campseg_stat_id = 20 ");
/* 265 */         if (approveFlag.length() > 0) {
/* 266 */           sql.append(" or campseg_stat_id =40 ");
/*     */         }
/*     */         else {
/* 269 */           sql.append(" or campseg_stat_id=51 ");
/* 270 */           if (campsegExeFlag.length() <= 0) {
/* 271 */             sql.append(" or campseg_stat_id=50 ");
/*     */           }
/*     */         }
/* 274 */         flag++;
/*     */       }
/*     */ 
/* 277 */       if (campsegStatId.equals("41")) {
/* 278 */         sql.append(" campseg_stat_id =30 ");
/* 279 */         flag++;
/*     */       }
/*     */ 
/* 282 */       if (campsegStatId.equals("42")) {
/* 283 */         sql.append(" 1=2 ");
/* 284 */         flag++;
/*     */       }
/*     */ 
/* 287 */       if (campsegStatId.equals("40")) {
/* 288 */         sql.append(" 1=2 ");
/*     */ 
/* 290 */         flag++;
/*     */       }
/*     */ 
/* 293 */       if (campsegStatId.equals("51")) {
/* 294 */         sql.append(" campseg_stat_id =50 ");
/* 295 */         flag++;
/*     */       }
/*     */ 
/* 298 */       if (campsegStatId.equals("50"))
/*     */       {
/* 302 */         sql.append(" campseg_stat_id =90 ");
/*     */ 
/* 304 */         flag++;
/*     */       }
/*     */ 
/* 307 */       if (campsegStatId.equals("60")) {
/* 308 */         sql.append(" campseg_stat_id =90 ");
/* 309 */         flag++;
/*     */       }
/*     */ 
/* 312 */       if (flag == 0) {
/* 313 */         return result;
/*     */       }
/* 315 */       sql.append(" or campseg_stat_id=91 ");
/* 316 */       sql.append(" order by campseg_stat_id");
/*     */ 
/* 318 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 319 */       sqlca.execute(sql.toString());
/* 320 */       while (sqlca.next())
/* 321 */         result.add(new LabelValueBean(sqlca.getString("campseg_stat_name"), sqlca.getString("campseg_stat_id")));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 325 */       log.error(e.getMessage(), e);
/*     */     } finally {
/* 327 */       if (sqlca != null) {
/* 328 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 331 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean updateCampsegStatus(String campId, String campsegId, String campsegStatId)
/*     */     throws Exception
/*     */   {
/* 339 */     boolean flag = false;
/*     */     try
/*     */     {
/* 342 */       String sql = "";
/* 343 */       if (StringUtils.isNotEmpty(campId)) {
/* 344 */         List campsegIdList = new ArrayList();
/* 345 */         String seginfoQuery = "select campsegId from MtlCampSeginfo where campId = ? and campsegStatId != ?";
/* 346 */         List tmpList = getHibernateTemplate().find(seginfoQuery, new Object[] { campId, Short.valueOf("90") });
/* 347 */         if (tmpList != null) {
/* 348 */           campsegIdList.addAll(tmpList);
/*     */         }
/* 350 */         while ((tmpList != null) && (tmpList.size() > 0)) {
/* 351 */           seginfoQuery = "select campsegId from MtlCampSeginfo where campsegPid in( :ids ) and campsegStatId !=:campsegStatId ";
/* 352 */           Query campsegIdQuery = getSession().createQuery(seginfoQuery);
/* 353 */           campsegIdQuery.setParameter("campsegStatId", Short.valueOf("90"));
/* 354 */           campsegIdQuery.setParameterList("ids", tmpList);
/* 355 */           tmpList = campsegIdQuery.list();
/* 356 */           campsegIdList.addAll(tmpList);
/*     */         }
/* 358 */         if ((campsegId != null) && (campsegIdList.size() > 0)) {
/* 359 */           sql = "update MtlCampSeginfo set campsegStatId=:campsegStatId where campsegId in( :ids ) ";
/* 360 */           Query updateQuery = getSession().createQuery(sql);
/* 361 */           updateQuery.setParameter("campsegStatId", Short.valueOf(campsegStatId));
/* 362 */           updateQuery.setParameterList("ids", campsegIdList);
/* 363 */           updateQuery.executeUpdate();
/*     */         }
/* 365 */         flag = true;
/*     */       }
/*     */       else
/*     */       {
/* 370 */         List campsegIdList = new ArrayList();
/* 371 */         campsegIdList.add(campsegId);
/*     */ 
/* 373 */         String seginfoQuery = "select campsegId from MtlCampSeginfo where campsegPid = ?";
/* 374 */         List tmpList = getHibernateTemplate().find(seginfoQuery, campsegId);
/* 375 */         if (tmpList != null) {
/* 376 */           campsegIdList.addAll(tmpList);
/*     */         }
/* 378 */         while ((tmpList != null) && (tmpList.size() > 0)) {
/* 379 */           seginfoQuery = "select campsegId from MtlCampSeginfo where campsegPid in( :ids )";
/* 380 */           Query campsegIdQuery = getSession().createQuery(seginfoQuery);
/* 381 */           campsegIdQuery.setParameterList("ids", tmpList);
/* 382 */           tmpList = campsegIdQuery.list();
/* 383 */           if (tmpList != null) {
/* 384 */             campsegIdList.addAll(tmpList);
/*     */           }
/*     */         }
/*     */ 
/* 388 */         if ((campsegId != null) && (campsegIdList.size() > 0)) {
/* 389 */           sql = "update MtlCampSeginfo set campsegStatId=:campsegStatId where campsegId in( :ids ) ";
/* 390 */           Query updateQuery = getSession().createQuery(sql);
/* 391 */           updateQuery.setParameter("campsegStatId", Short.valueOf(campsegStatId));
/* 392 */           updateQuery.setParameterList("ids", campsegIdList);
/* 393 */           updateQuery.executeUpdate();
/*     */         }
/* 395 */         flag = true;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 399 */       log.error("", e);
/*     */     }
/*     */ 
/* 406 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateCampSegConfirmFlag(String campsegId, short campsegConfrimFlag)
/*     */     throws Exception
/*     */   {
/* 414 */     boolean flag = false;
/* 415 */     Sqlca sqlca = null;
/*     */     try {
/* 417 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 418 */       String sql = "";
/* 419 */       if ((campsegId != null) && (!"".equals(campsegId))) {
/* 420 */         sql = "update mtl_camp_seginfo set confirm_flag=? where campseg_id=?";
/*     */       }
/* 422 */       if (sql.length() > 0) {
/* 423 */         sqlca.execute(sql, new Object[] { Short.valueOf(campsegConfrimFlag), campsegId });
/*     */       }
/* 425 */       flag = true;
/*     */     }
/*     */     catch (Exception e) {
/* 428 */       log.error(e.getMessage(), e);
/*     */     } finally {
/* 430 */       if (sqlca != null) {
/* 431 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 434 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateCampConfirmFlag(String campId, short campsegConfrimFlag)
/*     */     throws Exception
/*     */   {
/* 442 */     boolean flag = false;
/* 443 */     Sqlca sqlca = null;
/*     */     try {
/* 445 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 446 */       String sql = "";
/* 447 */       if ((campId != null) && (!"".equals(campId))) {
/* 448 */         sql = "update mtl_camp_baseinfo set confirm_flag=? where camp_id=?";
/*     */       }
/* 450 */       if (sql.length() > 0) {
/* 451 */         sqlca.execute(sql, new Object[] { Short.valueOf(campsegConfrimFlag), campId });
/*     */       }
/* 453 */       flag = true;
/*     */     }
/*     */     catch (Exception e) {
/* 456 */       log.error(e.getMessage(), e);
/*     */     } finally {
/* 458 */       if (sqlca != null) {
/* 459 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 462 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateCampsegApproveResult(String campsegId)
/*     */     throws Exception
/*     */   {
/* 470 */     boolean flag = false;
/* 471 */     Sqlca sqlca = null;
/*     */     try {
/* 473 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 474 */       String sql = "";
/* 475 */       if ((campsegId != null) && (!"".equals(campsegId))) {
/* 476 */         sql = "update mtl_camp_seginfo set approve_result=?  where campseg_id=?";
/*     */       }
/*     */ 
/* 479 */       if (sql.length() > 0) {
/* 480 */         sqlca.execute(sql, new Object[] { Short.valueOf(0), campsegId });
/*     */       }
/* 482 */       flag = true;
/*     */     } catch (Exception e) {
/* 484 */       log.error(e.getMessage(), e);
/*     */     } finally {
/* 486 */       if (sqlca != null) {
/* 487 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 490 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateCampApproveResult(String campId)
/*     */     throws Exception
/*     */   {
/* 498 */     boolean flag = false;
/* 499 */     Sqlca sqlca = null;
/*     */     try {
/* 501 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 502 */       String sql = "";
/* 503 */       if ((campId != null) && (!"".equals(campId))) {
/* 504 */         sql = "update mtl_camp_baseinfo set approve_result=? where camp_id=?";
/*     */       }
/*     */ 
/* 507 */       if (sql.length() > 0) {
/* 508 */         sqlca.execute(sql, new Object[] { Short.valueOf(0), campId });
/*     */       }
/* 510 */       flag = true;
/*     */     } catch (Exception e) {
/* 512 */       log.error(e.getMessage(), e);
/*     */     } finally {
/* 514 */       if (sqlca != null) {
/* 515 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 518 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateCampsegApproveNums(String campsegId)
/*     */     throws Exception
/*     */   {
/* 526 */     boolean flag = false;
/* 527 */     Sqlca sqlca = null;
/*     */     try {
/* 529 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 530 */       String sql = "";
/* 531 */       if ((campsegId != null) && (!"".equals(campsegId))) {
/* 532 */         sql = "update mtl_camp_seginfo set approve_receive_nums=(case when approve_receive_nums is null then  1 else approve_receive_nums+1 end) where campseg_id=?";
/*     */       }
/*     */ 
/* 535 */       if (sql.length() > 0) {
/* 536 */         sqlca.execute(sql, new String[] { campsegId });
/*     */       }
/* 538 */       flag = true;
/*     */     } catch (Exception e) {
/* 540 */       log.error("", e);
/*     */     } finally {
/* 542 */       if (sqlca != null) {
/* 543 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 546 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateCampStatus(String campsegId, String campStatus)
/*     */     throws Exception
/*     */   {
/* 554 */     boolean flag = false;
/* 555 */     Sqlca sqlca = null;
/*     */     try {
/* 557 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 558 */       String sql = "update mtl_camp_baseinfo set camp_status=? where camp_id=?";
/* 559 */       sqlca.execute(sql, new String[] { campStatus, campsegId });
/* 560 */       flag = true;
/*     */     } catch (Exception e) {
/* 562 */       log.error(e.getMessage(), e);
/*     */     } finally {
/* 564 */       if (sqlca != null) {
/* 565 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 568 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean deleteCampseg(String campId, String campsegId)
/*     */     throws Exception
/*     */   {
/* 574 */     boolean flag = false;
/*     */     try {
/* 576 */       String sql = "from MtlCampSeginfo as a where 1=1";
/* 577 */       if ((campId != null) && (!"".equals(campId))) {
/* 578 */         sql = sql + " and a.campId='" + campId + "'";
/*     */       }
/* 580 */       if ((campsegId != null) && (!"".equals(campsegId))) {
/* 581 */         sql = sql + " and a.campsegId='" + campsegId + "'";
/*     */       }
/*     */ 
/* 584 */       if (sql.charAt(sql.length() - 1) != '1') {
/* 585 */         getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */       }
/* 587 */       flag = true;
/*     */     } catch (Exception e) {
/* 589 */       log.error("", e);
/*     */     }
/* 591 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean deleteCamp(String campId)
/*     */     throws Exception
/*     */   {
/* 597 */     boolean flag = false;
/*     */     try {
/* 599 */       String sql = "from MtlCampBaseinfo as a where 1=1";
/* 600 */       if ((campId != null) && (!"".equals(campId))) {
/* 601 */         sql = sql + " and a.campId='" + campId + "'";
/*     */       }
/*     */ 
/* 604 */       if (sql.charAt(sql.length() - 1) != '1') {
/* 605 */         getHibernateTemplate().deleteAll(getHibernateTemplate().find(sql));
/*     */       }
/* 607 */       flag = true;
/*     */     } catch (Exception e) {
/* 609 */       log.error("", e);
/*     */     }
/* 611 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean insertCampsegBak(String campId)
/*     */     throws Exception
/*     */   {
/* 617 */     boolean flag = false;
/* 618 */     Sqlca sqlca = null;
/*     */     try {
/* 620 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/*     */ 
/* 622 */       String sql = "insert into mtl_camp_seginfo_bak(#CAMPSEG_COLUMN#) select #CAMPSEG_COLUMN# from mtl_camp_seginfo where camp_id=?";
/* 623 */       sql = sql.replace("#CAMPSEG_COLUMN#", " START_DATE,END_DATE,TARGER_USER_NUMS,CONTACTED_USER_NUMS,CONTACT_OKUSER_NUMS,RECEIVED_OKUSER_NUMS,CAMPSEG_STAT_ID,CAMPSEG_ID,CAMP_ID,APPROVE_FLAG,APPROVE_RESULT,APPROVE_RECEIVE_NUMS,CAMPSEG_NO,CAMPSEG_NAME,CREATE_TIME,CAMPSEG_DESC").replace("#CAMPSEG_COLUMN#", " START_DATE,END_DATE,TARGER_USER_NUMS,CONTACTED_USER_NUMS,CONTACT_OKUSER_NUMS,RECEIVED_OKUSER_NUMS,CAMPSEG_STAT_ID,CAMPSEG_ID,CAMP_ID,APPROVE_FLAG,APPROVE_RESULT,APPROVE_RECEIVE_NUMS,CAMPSEG_NO,CAMPSEG_NAME,CREATE_TIME,CAMPSEG_DESC");
/* 624 */       sqlca.execute(sql, new String[] { campId });
/*     */     } catch (Exception e) {
/* 626 */       log.error("", e);
/*     */     }
/* 628 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean insertCampBak(String campId)
/*     */     throws Exception
/*     */   {
/* 634 */     boolean flag = false;
/* 635 */     Sqlca sqlca = null;
/*     */     try {
/* 637 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/*     */ 
/* 639 */       String sql = "insert into mtl_camp_baseinfo_bak(#CAMP_COLUMN_BAK#) select #CAMP_COLUMN# from mtl_camp_baseinfo where camp_id=?";
/* 640 */       sql = sql.replace("#CAMP_COLUMN_BAK#", " CAMP_ID,START_DATE,END_DATE,CREATE_USERID,CAMP_NAME,CREATE_DATE,CAMP_REPLAY_STATUS,CAMP_PERFORM_TYPE,APPROVE_LEV,CAMP_TYPE,CAMP_DESC,CAMP_STRAGE_DESC,OBJECTIVE_DESC,FLOW_ID,CAMP_PRI_ID,CAMP_DRV_ID,CAMP_STATUS,DEPART_ID,CITY_ID ").replace("#CAMP_COLUMN#", " CAMP_ID,START_DATE,END_DATE,CREATE_USERID,CAMP_NAME,CREATE_DATE,CAMP_REPLAY_STATUS,STATUS_CHG_TYPE,APPROVE_LEV,CAMP_TYPE,CAMP_DESC,CAMP_STRAGE_DESC,OBJECTIVE_DESC,FLOW_ID,CAMP_PRI_ID,CAMP_DRV_ID,CAMP_STATUS,DEPTID,CITY_ID ");
/* 641 */       sqlca.execute(sql, new String[] { campId });
/*     */     } catch (Exception e) {
/* 643 */       log.error("", e);
/*     */     }
/* 645 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean getCampsegStatus(String campId)
/*     */     throws Exception
/*     */   {
/* 667 */     boolean flag = false;
/* 668 */     Sqlca sqlca = null;
/*     */     try {
/* 670 */       sqlca = new Sqlca(((SessionImpl)getSession()).connection());
/* 671 */       String sql = "select campseg_stat_id from mtl_camp_seginfo a where a.camp_id=?";
/* 672 */       sqlca.execute(sql, new String[] { campId });
/* 673 */       while (sqlca.next()) {
/* 674 */         String str = sqlca.getString("campseg_stat_id");
/* 675 */         if (("90".equals(str)) || ("91".equals(str))) {
/* 676 */           flag = true;
/*     */         } else {
/* 678 */           flag = false;
/* 679 */           break;
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 683 */       log.error("", e);
/*     */     } finally {
/* 685 */       if (sqlca != null) {
/* 686 */         sqlca.closeAll();
/*     */       }
/*     */     }
/*     */ 
/* 690 */     return flag;
/*     */   }
/*     */ 
/*     */   public String getSysActStepArray()
/*     */     throws Exception
/*     */   {
/* 698 */     StringBuffer str = new StringBuffer("");
/*     */ 
/* 714 */     return str.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.dao.impl.MtlSysActStepDefDaoImpl
 * JD-Core Version:    0.6.2
 */
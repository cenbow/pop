/*    */ package com.ai.bdx.frame.approval.exception;
/*    */ 
/*    */ public class MpmException extends RuntimeException
/*    */ {
/*    */   public MpmException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MpmException(String message)
/*    */   {
/* 18 */     super(message);
/*    */   }
/*    */ 
/*    */   public MpmException(Throwable cause)
/*    */   {
/* 26 */     super(cause);
/*    */   }
/*    */ 
/*    */   public MpmException(String message, Throwable cause)
/*    */   {
/* 35 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.exception.MpmException
 * JD-Core Version:    0.6.2
 */
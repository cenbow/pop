package com.ai.bdx.frame.approval.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ExceptionHandler;
import org.apache.struts.config.ExceptionConfig;

import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

/*
 * Created on 11:09:43 AM
 *
 * <p>Title: </p>
 * <p>Description: 营销管理系统Action类抛出错误处理类</p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MpmExceptionHandler extends ExceptionHandler{
	private static Logger log = LogManager.getLogger();

	/**
	 *
	 */
	public MpmExceptionHandler() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public ActionForward execute(java.lang.Exception ex, ExceptionConfig ae, ActionMapping mapping, ActionForm formInstance, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException {

		if (ex instanceof MpmException)
		{
			request.setAttribute("errMsg", ex.getMessage());
			log.error("", ex);
		}
		else {
			request.setAttribute("errMsg", MpmLocaleUtil.getMessage("mcd.java.fswzcwqlxx"));
			log.error("", ex);
		}

		return mapping.findForward("mpmFailure");
	}
}

/*    */ package com.ai.bdx.frame.approval.exception;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.action.ActionForm;
/*    */ import org.apache.struts.action.ActionForward;
/*    */ import org.apache.struts.action.ActionMapping;
/*    */ import org.apache.struts.action.ExceptionHandler;
/*    */ import org.apache.struts.config.ExceptionConfig;
/*    */ 
/*    */ public class MpmExceptionHandler extends ExceptionHandler
/*    */ {
/* 24 */   private static Logger log = LogManager.getLogger();
/*    */ 
/*    */   public ActionForward execute(Exception ex, ExceptionConfig ae, ActionMapping mapping, ActionForm formInstance, HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException
/*    */   {
/* 37 */     if ((ex instanceof MpmException))
/*    */     {
/* 39 */       request.setAttribute("errMsg", ex.getMessage());
/* 40 */       log.error("", ex);
/*    */     }
/*    */     else {
/* 43 */       request.setAttribute("errMsg", MpmLocaleUtil.getMessage("mcd.java.fswzcwqlxx"));
/* 44 */       log.error("", ex);
/*    */     }
/*    */ 
/* 47 */     return mapping.findForward("mpmFailure");
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.exception.MpmExceptionHandler
 * JD-Core Version:    0.6.2
 */
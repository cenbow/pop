/*     */ package com.ai.bdx.frame.approval.filter;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.listener.SessionListener;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import com.asiainfo.biframe.utils.string.DES;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.httpclient.HostConfiguration;
/*     */ import org.apache.commons.httpclient.HttpClient;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.httpclient.methods.PostMethod;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class AutoLoginFilter
/*     */   implements Filter
/*     */ {
/*  42 */   private static Logger log = LogManager.getLogger();
/*  43 */   protected boolean autoLogin = false;
/*  44 */   private static String[] skips = null;
/*  45 */   private int sumSSO = 0;
/*     */   private IUserPrivilegeCommonService privilegeService;
/*     */   private String topMenuId;
/*     */ 
/*     */   public void init(FilterConfig arg0)
/*     */     throws ServletException
/*     */   {
/*  55 */     String value = arg0.getInitParameter("autoLogin");
/*  56 */     if ((value != null) && ((value.equalsIgnoreCase("yes")) || (value.equalsIgnoreCase("true")))) {
/*  57 */       this.autoLogin = true;
/*     */     }
/*  59 */     String skip = arg0.getInitParameter("skip");
/*  60 */     if (skip != null)
/*  61 */       skips = skip.split(";");
/*     */     try
/*     */     {
/*  64 */       this.privilegeService = ((IUserPrivilegeCommonService)SystemServiceLocator.getInstance().getService("userPrivilegeCommonService"));
/*     */ 
/*  66 */       this.topMenuId = Configure.getInstance().getProperty("TOP_MENU_ID");
/*     */     }
/*     */     catch (Exception e) {
/*  69 */       log.error("", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  76 */     HttpServletRequest hrequest = (HttpServletRequest)request;
/*     */ 
/*  78 */     HttpServletResponse hresponse = (HttpServletResponse)response;
/*     */ 
/*  81 */     if (needSkipUserLoginCheck(hrequest))
/*     */     {
/*  83 */       chain.doFilter(request, response);
/*  84 */       return;
/*     */     }
/*  86 */     String userId = "";
/*     */ 
/*  89 */     if (!this.autoLogin)
/*     */     {
/*  91 */       if ((hrequest.getSession(false) != null) && (hrequest.getSession().getAttribute("ASIA_SESSION_NAME") != null))
/*     */       {
/*     */         try
/*     */         {
/*  95 */           userId = ((SessionListener)hrequest.getSession().getAttribute("ASIA_SESSION_NAME")).getUserID();
/*     */         }
/*     */         catch (Exception e) {
/*  98 */           log.error("", e);
/*     */         }
/*     */       }
/*     */       else {
/* 102 */         String script = new StringBuilder().append("<script language='javascript'>alert('").append(MpmLocaleUtil.getMessage("mcd.java.zjdyhyyzsj")).append("');top.location.href='").append(hrequest.getContextPath()).append("/login/login.jsp'</script>").toString();
/*     */ 
/* 105 */         script = new String(script.getBytes("utf-8"), "iso8859-1");
/* 106 */         hresponse.getOutputStream().print(script);
/*     */       }
/*     */     }
/*     */     else {
/* 110 */       String url = new StringBuilder().append(hrequest.getRequestURL()).append(hrequest.getQueryString() == null ? "" : new StringBuilder().append("?").append(hrequest.getQueryString()).toString()).toString();
/*     */ 
/* 112 */       log.debug(url);
/* 113 */       if (url.contains("mpm.jsp")) {
/* 114 */         this.sumSSO += 1;
/*     */       }
/* 116 */       userId = hrequest.getParameter("userId");
/* 117 */       String uuid = hrequest.getParameter("uuid");
/* 118 */       String mainAccount = hrequest.getParameter("mainAccount");
/* 119 */       if ((uuid != null) && (!"".equals(uuid))) {
/* 120 */         if (this.sumSSO < 2) {
/* 121 */           HttpClient client = new HttpClient();
/* 122 */           client.getHostConfiguration().setHost(Configure.getInstance().getProperty("bi_sso_ip"), Integer.parseInt(Configure.getInstance().getProperty("bi_sso_port")));
/*     */ 
/* 124 */           PostMethod post = new PostMethod(Configure.getInstance().getProperty("bi_sso_verify_path"));
/* 125 */           NameValuePair uuidPair = new NameValuePair("uuid", uuid);
/* 126 */           post.setRequestBody(new NameValuePair[] { uuidPair });
/* 127 */           client.executeMethod(post);
/* 128 */           String responseStr = new String(post.getResponseBodyAsString().getBytes("GBK"));
/* 129 */           if ((responseStr != null) && (!"".equals(responseStr))) {
/* 130 */             userId = responseStr;
/*     */           }
/* 132 */           log.debug(new StringBuilder().append("get userid from sso:").append(userId).toString());
/* 133 */           post.releaseConnection();
/*     */         } else {
/* 135 */           this.sumSSO = 0;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 140 */       if ((userId == null) || (userId.length() == 0) || ("null".equals(userId)))
/*     */       {
/* 142 */         if ((hrequest.getSession(false) != null) && (hrequest.getSession().getAttribute("ASIA_SESSION_NAME") != null))
/*     */         {
/*     */           try {
/* 145 */             userId = ((SessionListener)hrequest.getSession().getAttribute("ASIA_SESSION_NAME")).getUserID();
/*     */           }
/*     */           catch (Exception e) {
/* 148 */             log.error("", e);
/*     */           }
/*     */         } else {
/* 151 */           String script = new StringBuilder().append("<script language='javascript'>alert('").append(MpmLocaleUtil.getMessage("mcd.java.zjdyhyyzsj")).append("');top.location.href='").append(hrequest.getContextPath()).append("/login/login.jsp'</script>").toString();
/*     */ 
/* 154 */           script = new String(script.getBytes("utf-8"), "iso8859-1");
/* 155 */           hresponse.getOutputStream().print(script);
/*     */         }
/*     */       }
/*     */       else {
/* 159 */         log.error(new StringBuilder().append("----------------------------------- remote ip:").append(request.getRemoteAddr()).toString());
/*     */         try {
/* 161 */           log.debug(new StringBuilder().append("before decrypt:").append(userId).toString());
/* 162 */           userId = DES.decrypt(userId);
/* 163 */           if (mainAccount != null) {
/* 164 */             mainAccount = DES.decrypt(mainAccount);
/*     */           }
/*     */ 
/* 167 */           if (hrequest.getSession(false) == null) {
/* 168 */             log.info(">>Session has been invalidated!...create a new session!");
/* 169 */             hrequest.getSession().setAttribute("ASIA_SESSION_NAME", SessionListener.login(hrequest, userId, mainAccount));
/*     */           }
/*     */           else {
/* 172 */             SessionListener mysession = (SessionListener)hrequest.getSession().getAttribute("ASIA_SESSION_NAME");
/*     */ 
/* 175 */             if (mysession == null) {
/* 176 */               log.info(new StringBuilder().append(">>New user [").append(userId).append("] from").append(hrequest.getRemoteAddr()).append(" login in...").toString());
/* 177 */               hrequest.getSession().setAttribute("ASIA_SESSION_NAME", SessionListener.login(hrequest, userId, mainAccount));
/*     */             }
/* 179 */             else if ((mysession != null) && 
/* 180 */               (!mysession.getUserID().equalsIgnoreCase(userId))) {
/* 181 */               log.info(new StringBuilder().append(">>Request has a session, but a new user [").append(userId).append("] from").append(hrequest.getRemoteAddr()).append(" login in...").toString());
/*     */ 
/* 183 */               hrequest.getSession().setAttribute("ASIA_SESSION_NAME", SessionListener.login(hrequest, userId, mainAccount));
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 189 */           e.printStackTrace();
/*     */         }
/*     */ 
/* 192 */         System.out.println(hrequest.getRequestURI());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 204 */     chain.doFilter(hrequest, hresponse);
/*     */   }
/*     */ 
/*     */   private boolean isVisitMenu(String userId, HttpServletRequest request)
/*     */   {
/* 210 */     List menuItemList = this.privilegeService.getSubAllMenuItem(userId, this.topMenuId);
/* 211 */     String requestUrl = request.getRequestURI();
/* 212 */     String contextPath = request.getContextPath();
/* 213 */     if (requestUrl.indexOf(".aido") < 0) {
/* 214 */       return true;
/*     */     }
/*     */ 
/* 217 */     if ((requestUrl.indexOf("homePageAction.aido") >= 0) || (requestUrl.indexOf("mmp-dwr") >= 0)) {
/* 218 */       return true;
/*     */     }
/* 220 */     String requstMenu = requestUrl.substring(requestUrl.indexOf(contextPath) + contextPath.length(), requestUrl.indexOf(".aido"));
/*     */ 
/* 223 */     if (requstMenu.indexOf("mcdCampSegWaveMaintain") >= 0)
/* 224 */       requstMenu = "mpmCampSegMaintain";
/* 225 */     else if (requstMenu.indexOf("mpmCampApproveDetail") >= 0)
/* 226 */       requstMenu = "mpmCampApproveList";
/* 227 */     else if (requstMenu.indexOf("mpmCampConfirmDetail") >= 0) {
/* 228 */       requstMenu = "mpmCampConfirmList";
/*     */     }
/* 230 */     boolean flag = true;
/* 231 */     for (IMenuItem menuItem : menuItemList) {
/* 232 */       if (menuItem.getUrl().indexOf(requstMenu) >= 0) {
/* 233 */         flag = true;
/* 234 */         break;
/*     */       }
/*     */     }
/* 237 */     return flag;
/*     */   }
/*     */ 
/*     */   private boolean needSkipUserLoginCheck(HttpServletRequest r) {
/* 241 */     boolean result = false;
/* 242 */     String uri = r.getRequestURI();
/*     */ 
/* 245 */     if ((uri.equals(r.getContextPath())) || (uri.equals(new StringBuilder().append(r.getContextPath()).append("/").toString()))) {
/* 246 */       return true;
/*     */     }
/*     */ 
/* 249 */     for (String s : skips) {
/* 250 */       if (uri.indexOf(s) > -1) {
/* 251 */         result = true;
/* 252 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 256 */     return result;
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 260 */     this.autoLogin = false;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.filter.AutoLoginFilter
 * JD-Core Version:    0.6.2
 */
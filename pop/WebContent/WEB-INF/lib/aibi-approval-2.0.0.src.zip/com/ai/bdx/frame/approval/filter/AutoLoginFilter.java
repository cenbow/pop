package com.ai.bdx.frame.approval.filter;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.listener.SessionListener;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IMenuItem;
import com.asiainfo.biframe.privilege.base.constants.UserManager;
import com.asiainfo.biframe.utils.config.Configure;
import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
import com.asiainfo.biframe.utils.string.DES;

/*
 * Created on 2005-10-28 16:19:57
 *
 * <p>Title: </p>
 * <p>Description: 处理从其他服务器转过来的模块请求服务，实现用户自动登录</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class AutoLoginFilter implements Filter {
	private static Logger log = LogManager.getLogger();
	protected boolean autoLogin = false;
	private static String skips[] = null;
	private int sumSSO = 0;
	private IUserPrivilegeCommonService privilegeService;
	private String topMenuId;

	public AutoLoginFilter() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init(FilterConfig arg0) throws ServletException {
		String value = arg0.getInitParameter("autoLogin");
		if (value != null && (value.equalsIgnoreCase("yes") || value.equalsIgnoreCase("true"))) {
			autoLogin = true;
		}
		String skip = arg0.getInitParameter("skip");
		if (skip != null) {
			skips = skip.split(";");
		}
		try {
			privilegeService = (IUserPrivilegeCommonService) SystemServiceLocator.getInstance().getService(
					MpmCONST.MPM_USER_PRIVILEGE_SERVICE);
			topMenuId = Configure.getInstance().getProperty("TOP_MENU_ID");

		} catch (Exception e) {
			log.error("", e);
		}
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
			ServletException {

		HttpServletRequest hrequest = (HttpServletRequest) request;
		//hrequest.setCharacterEncoding("GBK");
		HttpServletResponse hresponse = (HttpServletResponse) response;

		//		System.out.println("判断是否放过的路径???????");
		if (this.needSkipUserLoginCheck(hrequest)) {
			//			System.out.println("放过的路径");
			chain.doFilter(request, response);
			return;
		}
		String userId = "";
		//当autoLogin=false时,只做过滤校验用
		//		System.out.println("判断是否自动登陆???");
		if (!autoLogin) {
			//			System.out.println("是自动登陆。。。。。。。。。。。");
			if (hrequest.getSession(false) != null
					&& hrequest.getSession().getAttribute(UserManager.ASIA_SESSION_NAME) != null) {
				//				System.out.println("可以直接登陆");
				try {
					userId = ((SessionListener) hrequest.getSession().getAttribute(UserManager.ASIA_SESSION_NAME))
							.getUserID();
				} catch (Exception e) {
					log.error("", e);
				}
			} else {
				//				System.out.println("session超时了");
				String script = "<script language='javascript'>alert('"
						+ MpmLocaleUtil.getMessage("mcd.java.zjdyhyyzsj") + "');top.location.href='"
						+ hrequest.getContextPath() + "/login/login.jsp'</script>";
				script = new String(script.getBytes("utf-8"), "iso8859-1");
				hresponse.getOutputStream().print(script);
				return;
			}
		} else {
			String url = hrequest.getRequestURL()
					+ ((hrequest.getQueryString() == null) ? "" : ("?" + hrequest.getQueryString()));
			log.debug(url);
			if (url.contains("mpm.jsp")) {
				++sumSSO;
			}
			userId = hrequest.getParameter("userId");
			String uuid = hrequest.getParameter("uuid");
			String mainAccount = hrequest.getParameter("mainAccount");
			if (uuid != null && !"".equals(uuid)) {
				if (sumSSO < 2) {
					HttpClient client = new HttpClient();
					client.getHostConfiguration().setHost(Configure.getInstance().getProperty("bi_sso_ip"),
							Integer.parseInt(Configure.getInstance().getProperty("bi_sso_port")));
					PostMethod post = new PostMethod(Configure.getInstance().getProperty("bi_sso_verify_path"));
					NameValuePair uuidPair = new NameValuePair("uuid", uuid);
					post.setRequestBody(new NameValuePair[] { uuidPair });
					client.executeMethod(post);
					String responseStr = new String(post.getResponseBodyAsString().getBytes("GBK"));
					if (responseStr != null && !"".equals(responseStr)) {
						userId = responseStr;
					}
					log.debug("get userid from sso:" + userId);
					post.releaseConnection();
				} else {
					sumSSO = 0;
				}
			}

			//			System.out.println("再判断userID是不是空？？？？？");
			if (userId == null || userId.length() == 0 || "null".equals(userId)) {
				//				System.out.println("这种情况UserID为空了，表明是跟单点没关系的请求");
				if (hrequest.getSession(false) != null
						&& hrequest.getSession().getAttribute(UserManager.ASIA_SESSION_NAME) != null) {
					try {
						userId = ((SessionListener) hrequest.getSession().getAttribute(UserManager.ASIA_SESSION_NAME))
								.getUserID();
					} catch (Exception e) {
						log.error("", e);
					}
				} else {
					String script = "<script language='javascript'>alert('"
							+ MpmLocaleUtil.getMessage("mcd.java.zjdyhyyzsj") + "');top.location.href='"
							+ hrequest.getContextPath() + "/login/login.jsp'</script>";
					script = new String(script.getBytes("utf-8"), "iso8859-1");
					hresponse.getOutputStream().print(script);
					return;
				}
			} else {
				log.error("----------------------------------- remote ip:" + request.getRemoteAddr());
				try {
					log.debug("before decrypt:" + userId);
					userId = DES.decrypt(userId);
					if (mainAccount != null) {
						mainAccount = DES.decrypt(mainAccount);
					}

					if (hrequest.getSession(false) == null) {
						log.info(">>Session has been invalidated!...create a new session!");
						hrequest.getSession().setAttribute(UserManager.ASIA_SESSION_NAME,
								SessionListener.login(hrequest, userId, mainAccount));
					} else {
						SessionListener mysession = (SessionListener) hrequest.getSession().getAttribute(
								UserManager.ASIA_SESSION_NAME);
						//用户请求可能是从其他服务器转过来的，如果带了userId参数，并且有值，则构造一个登录SessionListener
						if (mysession == null) {
							log.info(">>New user [" + userId + "] from" + hrequest.getRemoteAddr() + " login in...");
							hrequest.getSession().setAttribute(UserManager.ASIA_SESSION_NAME,
									SessionListener.login(hrequest, userId, mainAccount));
						} else if (mysession != null) {
							if (!mysession.getUserID().equalsIgnoreCase(userId)) {
								log.info(">>Request has a session, but a new user [" + userId + "] from"
										+ hrequest.getRemoteAddr() + " login in...");
								hrequest.getSession().setAttribute(UserManager.ASIA_SESSION_NAME,
										SessionListener.login(hrequest, userId, mainAccount));
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				//			    System.out.println("所有请求进入这里。。。。。。。。。");
				System.out.println(hrequest.getRequestURI());
				//校验用户访问url权限
			}
		}
		/*if (!isVisitMenu(userId, hrequest)) {
			String script = "<script language='javascript'>alert('您没有权限访问该功能 !');top.location.href='"
					+ hrequest.getContextPath() + "/login/login.jsp'</script>";
			script = new String(script.getBytes("utf-8"), "iso8859-1");
			hresponse.setContentType("text/html; utf-8");
			hresponse.getOutputStream().print(script);
			return;
		}*/
		chain.doFilter(hrequest, hresponse);
		//		System.out.println("执行了跳转");
	}

	private boolean isVisitMenu(String userId, HttpServletRequest request) {

		List<IMenuItem> menuItemList = privilegeService.getSubAllMenuItem(userId, topMenuId);
		String requestUrl = request.getRequestURI();
		String contextPath = request.getContextPath();
		if (requestUrl.indexOf(".aido") < 0) {
			return true;
		}
		//首页直接返回
		if (requestUrl.indexOf("homePageAction.aido") >= 0 || requestUrl.indexOf("mmp-dwr") >= 0) {
			return true;
		}
		String requstMenu = requestUrl.substring(requestUrl.indexOf(contextPath) + contextPath.length(),
				requestUrl.indexOf(".aido"));
		//规则创建，查看是否配置有活动创建权限
		if (requstMenu.indexOf("mcdCampSegWaveMaintain") >= 0) {
			requstMenu = "mpmCampSegMaintain";
		} else if (requstMenu.indexOf("mpmCampApproveDetail") >= 0) {//营销案 / 营销活动 审批详细页面
			requstMenu = "mpmCampApproveList";
		} else if (requstMenu.indexOf("mpmCampConfirmDetail") >= 0) {
			requstMenu = "mpmCampConfirmList";
		}
		boolean flag = true;
		for (IMenuItem menuItem : menuItemList) {
			if (menuItem.getUrl().indexOf(requstMenu) >= 0) {
				flag = true;
				break;
			}
		}
		return flag;
	}

	private boolean needSkipUserLoginCheck(HttpServletRequest r) {
		boolean result = false;
		String uri = r.getRequestURI();

		//过滤掉直接输入根路径 或者 根路径 + / 这些
		if (uri.equals(r.getContextPath()) || uri.equals(r.getContextPath() + "/")) {
			return true;
		}

		for (String s : skips) {
			if (uri.indexOf(s) > -1) {
				result = true;
				break;
			}
		}

		return result;
	}

	public void destroy() {
		autoLogin = false;
	}

}

/*    */ package com.ai.bdx.frame.approval.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ 
/*    */ public class SetCharacterEncodingFilter
/*    */   implements Filter
/*    */ {
/*    */   protected String encoding;
/*    */   protected FilterConfig filterConfig;
/*    */   protected boolean ignore;
/*    */ 
/*    */   public SetCharacterEncodingFilter()
/*    */   {
/* 18 */     this.encoding = null;
/* 19 */     this.filterConfig = null;
/* 20 */     this.ignore = true;
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 24 */     this.encoding = null;
/* 25 */     this.filterConfig = null;
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
/*    */   {
/* 30 */     if ((!this.ignore) || (request.getCharacterEncoding() == null)) {
/* 31 */       String encoding = selectEncoding(request);
/* 32 */       if (encoding != null) {
/* 33 */         request.setCharacterEncoding(encoding);
/*    */       }
/*    */     }
/* 36 */     chain.doFilter(request, response);
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig filterConfig) throws ServletException {
/* 40 */     this.filterConfig = filterConfig;
/* 41 */     this.encoding = filterConfig.getInitParameter("encoding");
/* 42 */     String value = filterConfig.getInitParameter("ignore");
/* 43 */     if (value == null)
/* 44 */       this.ignore = true;
/* 45 */     else if (value.equalsIgnoreCase("true"))
/* 46 */       this.ignore = true;
/* 47 */     else if (value.equalsIgnoreCase("yes"))
/* 48 */       this.ignore = true;
/*    */     else
/* 50 */       this.ignore = false;
/*    */   }
/*    */ 
/*    */   protected String selectEncoding(ServletRequest request) {
/* 54 */     return this.encoding;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.filter.SetCharacterEncodingFilter
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class ThemeSetFilter
/*    */   implements Filter
/*    */ {
/* 15 */   private static Logger log = LogManager.getLogger();
/*    */ 
/*    */   public void init(FilterConfig arg0) throws ServletException {
/*    */   }
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 20 */     HttpServletRequest hrequest = (HttpServletRequest)request;
/* 21 */     String theme = hrequest.getParameter("theme");
/*    */ 
/* 23 */     if (null != theme)
/*    */     {
/* 25 */       hrequest.getSession().setAttribute("theme", theme);
/*    */     }
/* 27 */     chain.doFilter(request, response);
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.filter.ThemeSetFilter
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.form;

import java.util.Date;

public class ApproveFlowDefForm extends SysBaseForm {
	
	private static final long serialVersionUID = 1L;

	private String approveFlowId;

	private String createUserid;

	private String cityid;

	private String approveFlowName;

	private Date createTime;

	private short approveObjType;

	private Short approveFlowLevelCnt;

	private String approveFlowDefStr;

	private String confirmId;

	private short approveFlowAccessToken;

	private String firstApproveUser;
	private String flowType;
	private String approve_obj_type;//定义的流程类型
	/**
	 * @return approveFlowAccessToken
	 */
	public short getApproveFlowAccessToken() {
		return approveFlowAccessToken;
	}

	/**
	 * @param approveFlowAccessToken
	 *            ~o approveFlowAccessToken
	 */
	public void setApproveFlowAccessToken(short approveFlowAccessToken) {
		this.approveFlowAccessToken = approveFlowAccessToken;
	}

	/**
	 * 
	 */
	public ApproveFlowDefForm() {
		// TODO Auto-generated constructor stub
	}

	public String getApproveFlowId() {
		return approveFlowId;
	}

	public void setApproveFlowId(String approveFlowId) {
		this.approveFlowId = approveFlowId;
	}

	public String getConfirmId() {
		return confirmId;
	}

	public void setConfirmId(String confirmId) {
		this.confirmId = confirmId;
	}

	public String getApproveFlowName() {
		return approveFlowName;
	}

	public void setApproveFlowName(String approveFlowName) {
		this.approveFlowName = approveFlowName;
	}

	public String getCityid() {
		return cityid;
	}

	public void setCityid(String cityid) {
		this.cityid = cityid;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreateUserid() {
		return createUserid;
	}

	public void setCreateUserid(String createUserid) {
		this.createUserid = createUserid;
	}

	public short getApproveObjType() {
		return approveObjType;
	}

	public void setApproveObjType(short approveObjType) {
		this.approveObjType = approveObjType;
	}

	public Short getApproveFlowLevelCnt() {
		return approveFlowLevelCnt;
	}

	public void setApproveFlowLevelCnt(Short approveFlowLevelCnt) {
		this.approveFlowLevelCnt = approveFlowLevelCnt;
	}

	public String getApproveFlowDefStr() {
		return approveFlowDefStr;
	}

	public void setApproveFlowDefStr(String approveFlowDefStr) {
		this.approveFlowDefStr = approveFlowDefStr;
	}

	public String getFirstApproveUser() {
		return firstApproveUser;
	}

	public void setFirstApproveUser(String firstApproveUser) {
		this.firstApproveUser = firstApproveUser;
	}

	public String getFlowType() {
		return flowType;
	}

	public void setFlowType(String flowType) {
		this.flowType = flowType;
	}

	public String getApprove_obj_type() {
		return approve_obj_type;
	}

	public void setApprove_obj_type(String approve_obj_type) {
		this.approve_obj_type = approve_obj_type;
	}

	
	
}

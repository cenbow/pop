/*     */ package com.ai.bdx.frame.approval.form;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public class ApproveFlowDefForm extends SysBaseForm
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String approveFlowId;
/*     */   private String createUserid;
/*     */   private String cityid;
/*     */   private String approveFlowName;
/*     */   private Date createTime;
/*     */   private short approveObjType;
/*     */   private Short approveFlowLevelCnt;
/*     */   private String approveFlowDefStr;
/*     */   private String confirmId;
/*     */   private short approveFlowAccessToken;
/*     */   private String firstApproveUser;
/*     */   private String flowType;
/*     */   private String approve_obj_type;
/*     */ 
/*     */   public short getApproveFlowAccessToken()
/*     */   {
/*  36 */     return this.approveFlowAccessToken;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowAccessToken(short approveFlowAccessToken)
/*     */   {
/*  44 */     this.approveFlowAccessToken = approveFlowAccessToken;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowId()
/*     */   {
/*  55 */     return this.approveFlowId;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowId(String approveFlowId) {
/*  59 */     this.approveFlowId = approveFlowId;
/*     */   }
/*     */ 
/*     */   public String getConfirmId() {
/*  63 */     return this.confirmId;
/*     */   }
/*     */ 
/*     */   public void setConfirmId(String confirmId) {
/*  67 */     this.confirmId = confirmId;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowName() {
/*  71 */     return this.approveFlowName;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowName(String approveFlowName) {
/*  75 */     this.approveFlowName = approveFlowName;
/*     */   }
/*     */ 
/*     */   public String getCityid() {
/*  79 */     return this.cityid;
/*     */   }
/*     */ 
/*     */   public void setCityid(String cityid) {
/*  83 */     this.cityid = cityid;
/*     */   }
/*     */ 
/*     */   public Date getCreateTime() {
/*  87 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(Date createTime) {
/*  91 */     this.createTime = createTime;
/*     */   }
/*     */ 
/*     */   public String getCreateUserid() {
/*  95 */     return this.createUserid;
/*     */   }
/*     */ 
/*     */   public void setCreateUserid(String createUserid) {
/*  99 */     this.createUserid = createUserid;
/*     */   }
/*     */ 
/*     */   public short getApproveObjType() {
/* 103 */     return this.approveObjType;
/*     */   }
/*     */ 
/*     */   public void setApproveObjType(short approveObjType) {
/* 107 */     this.approveObjType = approveObjType;
/*     */   }
/*     */ 
/*     */   public Short getApproveFlowLevelCnt() {
/* 111 */     return this.approveFlowLevelCnt;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowLevelCnt(Short approveFlowLevelCnt) {
/* 115 */     this.approveFlowLevelCnt = approveFlowLevelCnt;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowDefStr() {
/* 119 */     return this.approveFlowDefStr;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowDefStr(String approveFlowDefStr) {
/* 123 */     this.approveFlowDefStr = approveFlowDefStr;
/*     */   }
/*     */ 
/*     */   public String getFirstApproveUser() {
/* 127 */     return this.firstApproveUser;
/*     */   }
/*     */ 
/*     */   public void setFirstApproveUser(String firstApproveUser) {
/* 131 */     this.firstApproveUser = firstApproveUser;
/*     */   }
/*     */ 
/*     */   public String getFlowType() {
/* 135 */     return this.flowType;
/*     */   }
/*     */ 
/*     */   public void setFlowType(String flowType) {
/* 139 */     this.flowType = flowType;
/*     */   }
/*     */ 
/*     */   public String getApprove_obj_type() {
/* 143 */     return this.approve_obj_type;
/*     */   }
/*     */ 
/*     */   public void setApprove_obj_type(String approve_obj_type) {
/* 147 */     this.approve_obj_type = approve_obj_type;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.ApproveFlowDefForm
 * JD-Core Version:    0.6.2
 */
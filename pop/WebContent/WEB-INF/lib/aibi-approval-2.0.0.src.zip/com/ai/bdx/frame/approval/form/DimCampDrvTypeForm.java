package com.ai.bdx.frame.approval.form;


public class DimCampDrvTypeForm extends SysBaseForm {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Short campDrvId;

	private Short parentId;

	private String flowId;

	private String planExecId;
	

	private String tableID;// 维表ID
	private String tableColVal;// 维表ID对表应值

	private String campDrvName;

	private String campDrvDesc;
	
	private Short accessControlFlag;
	
	private Short campDrvClass;
	
	private String toforward;
	
	private Integer dcpPageId;
	/** 该驱动类型是否禁用，0：正常不禁用； 1：禁用 */
	private Short drvDesabled;
	
	private Short campDrvAutoFlag; 
	
	public Short getCampDrvAutoFlag() {
		return campDrvAutoFlag;
	}

	public void setCampDrvAutoFlag(Short campDrvAutoFlag) {
		this.campDrvAutoFlag = campDrvAutoFlag;
	}

	public Short getCampDrvId() {
		return this.campDrvId;
	}

	public void setCampDrvId(Short campDrvId) {
		this.campDrvId = campDrvId;
	}

	public String getCampDrvName() {
		return this.campDrvName;
	}

	public void setCampDrvName(String campDrvName) {
		this.campDrvName = campDrvName;
	}

	public String getCampDrvDesc() {
		return this.campDrvDesc;
	}

	public void setCampDrvDesc(String campDrvDesc) {
		this.campDrvDesc = campDrvDesc;
	}

	public Short getParentId() {
		return parentId;
	}

	public void setParentId(Short parentId) {
		this.parentId = parentId;
	}

	/**
	 * @return flowId
	 */
	public String getFlowId() {
		return flowId;
	}

	/**
	 * @param flowId 要设置的 flowId
	 */
	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}

	/**
	 * @return planExecId
	 */
	public String getPlanExecId() {
		return planExecId;
	}

	/**
	 * @param planExecId 要设置的 planExecId
	 */
	public void setPlanExecId(String planExecId) {
		this.planExecId = planExecId;
	}

	public Short getAccessControlFlag() {
		return accessControlFlag;
	}

	public void setAccessControlFlag(Short accessControlFlag) {
		this.accessControlFlag = accessControlFlag;
	}
	
	public Short getCampDrvClass() {
		return campDrvClass;
	}

	public void setCampDrvClass(Short campDrvClass) {
		this.campDrvClass = campDrvClass;
	}

	public void setToforward(String toforward) {
		this.toforward = toforward;
	}
	
	public String getToforward() {
		// TODO Auto-generated method stub
		return this.toforward;
	}

	public Integer getDcpPageId() {
		return dcpPageId;
	}

	public void setDcpPageId(Integer dcpPageId) {
		this.dcpPageId = dcpPageId;
	}

	public Short getDrvDesabled() {
		return drvDesabled;
	}

	public void setDrvDesabled(Short drvDesabled) {
		this.drvDesabled = drvDesabled;
	}

	public String getTableID() {
		return tableID;
	}

	public void setTableID(String tableID) {
		this.tableID = tableID;
	}

	public String getTableColVal() {
		return tableColVal;
	}

	public void setTableColVal(String tableColVal) {
		this.tableColVal = tableColVal;
	}

	
}



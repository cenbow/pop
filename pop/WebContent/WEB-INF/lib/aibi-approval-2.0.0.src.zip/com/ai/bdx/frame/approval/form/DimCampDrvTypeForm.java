/*     */ package com.ai.bdx.frame.approval.form;
/*     */ 
/*     */ public class DimCampDrvTypeForm extends SysBaseForm
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Short campDrvId;
/*     */   private Short parentId;
/*     */   private String flowId;
/*     */   private String planExecId;
/*     */   private String tableID;
/*     */   private String tableColVal;
/*     */   private String campDrvName;
/*     */   private String campDrvDesc;
/*     */   private Short accessControlFlag;
/*     */   private Short campDrvClass;
/*     */   private String toforward;
/*     */   private Integer dcpPageId;
/*     */   private Short drvDesabled;
/*     */   private Short campDrvAutoFlag;
/*     */ 
/*     */   public Short getCampDrvAutoFlag()
/*     */   {
/*  40 */     return this.campDrvAutoFlag;
/*     */   }
/*     */ 
/*     */   public void setCampDrvAutoFlag(Short campDrvAutoFlag) {
/*  44 */     this.campDrvAutoFlag = campDrvAutoFlag;
/*     */   }
/*     */ 
/*     */   public Short getCampDrvId() {
/*  48 */     return this.campDrvId;
/*     */   }
/*     */ 
/*     */   public void setCampDrvId(Short campDrvId) {
/*  52 */     this.campDrvId = campDrvId;
/*     */   }
/*     */ 
/*     */   public String getCampDrvName() {
/*  56 */     return this.campDrvName;
/*     */   }
/*     */ 
/*     */   public void setCampDrvName(String campDrvName) {
/*  60 */     this.campDrvName = campDrvName;
/*     */   }
/*     */ 
/*     */   public String getCampDrvDesc() {
/*  64 */     return this.campDrvDesc;
/*     */   }
/*     */ 
/*     */   public void setCampDrvDesc(String campDrvDesc) {
/*  68 */     this.campDrvDesc = campDrvDesc;
/*     */   }
/*     */ 
/*     */   public Short getParentId() {
/*  72 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setParentId(Short parentId) {
/*  76 */     this.parentId = parentId;
/*     */   }
/*     */ 
/*     */   public String getFlowId()
/*     */   {
/*  83 */     return this.flowId;
/*     */   }
/*     */ 
/*     */   public void setFlowId(String flowId)
/*     */   {
/*  90 */     this.flowId = flowId;
/*     */   }
/*     */ 
/*     */   public String getPlanExecId()
/*     */   {
/*  97 */     return this.planExecId;
/*     */   }
/*     */ 
/*     */   public void setPlanExecId(String planExecId)
/*     */   {
/* 104 */     this.planExecId = planExecId;
/*     */   }
/*     */ 
/*     */   public Short getAccessControlFlag() {
/* 108 */     return this.accessControlFlag;
/*     */   }
/*     */ 
/*     */   public void setAccessControlFlag(Short accessControlFlag) {
/* 112 */     this.accessControlFlag = accessControlFlag;
/*     */   }
/*     */ 
/*     */   public Short getCampDrvClass() {
/* 116 */     return this.campDrvClass;
/*     */   }
/*     */ 
/*     */   public void setCampDrvClass(Short campDrvClass) {
/* 120 */     this.campDrvClass = campDrvClass;
/*     */   }
/*     */ 
/*     */   public void setToforward(String toforward) {
/* 124 */     this.toforward = toforward;
/*     */   }
/*     */ 
/*     */   public String getToforward()
/*     */   {
/* 129 */     return this.toforward;
/*     */   }
/*     */ 
/*     */   public Integer getDcpPageId() {
/* 133 */     return this.dcpPageId;
/*     */   }
/*     */ 
/*     */   public void setDcpPageId(Integer dcpPageId) {
/* 137 */     this.dcpPageId = dcpPageId;
/*     */   }
/*     */ 
/*     */   public Short getDrvDesabled() {
/* 141 */     return this.drvDesabled;
/*     */   }
/*     */ 
/*     */   public void setDrvDesabled(Short drvDesabled) {
/* 145 */     this.drvDesabled = drvDesabled;
/*     */   }
/*     */ 
/*     */   public String getTableID() {
/* 149 */     return this.tableID;
/*     */   }
/*     */ 
/*     */   public void setTableID(String tableID) {
/* 153 */     this.tableID = tableID;
/*     */   }
/*     */ 
/*     */   public String getTableColVal() {
/* 157 */     return this.tableColVal;
/*     */   }
/*     */ 
/*     */   public void setTableColVal(String tableColVal) {
/* 161 */     this.tableColVal = tableColVal;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.DimCampDrvTypeForm
 * JD-Core Version:    0.6.2
 */
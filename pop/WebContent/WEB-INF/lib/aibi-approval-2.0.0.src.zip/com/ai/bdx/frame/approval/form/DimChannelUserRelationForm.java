/*    */ package com.ai.bdx.frame.approval.form;
/*    */ 
/*    */ public class DimChannelUserRelationForm extends SysBaseForm
/*    */ {
/*    */   private Short channeltypeId;
/*    */   private String channelId;
/*    */   private String userId1;
/*    */   private Short confirmType;
/*    */   private int resourceId;
/*    */ 
/*    */   public String getChannelId()
/*    */   {
/* 18 */     return this.channelId;
/*    */   }
/*    */ 
/*    */   public void setChannelId(String channelId)
/*    */   {
/* 26 */     this.channelId = channelId;
/*    */   }
/*    */ 
/*    */   public Short getChanneltypeId()
/*    */   {
/* 33 */     return this.channeltypeId;
/*    */   }
/*    */ 
/*    */   public void setChanneltypeId(Short channeltypeId)
/*    */   {
/* 41 */     this.channeltypeId = channeltypeId;
/*    */   }
/*    */ 
/*    */   public Short getConfirmType()
/*    */   {
/* 48 */     return this.confirmType;
/*    */   }
/*    */ 
/*    */   public void setConfirmType(Short confirmType)
/*    */   {
/* 56 */     this.confirmType = confirmType;
/*    */   }
/*    */ 
/*    */   public int getResourceId()
/*    */   {
/* 63 */     return this.resourceId;
/*    */   }
/*    */ 
/*    */   public void setResourceId(int resourceId)
/*    */   {
/* 71 */     this.resourceId = resourceId;
/*    */   }
/*    */ 
/*    */   public String getUserId1() {
/* 75 */     return this.userId1;
/*    */   }
/*    */ 
/*    */   public void setUserId1(String userId1) {
/* 79 */     this.userId1 = userId1;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.DimChannelUserRelationForm
 * JD-Core Version:    0.6.2
 */
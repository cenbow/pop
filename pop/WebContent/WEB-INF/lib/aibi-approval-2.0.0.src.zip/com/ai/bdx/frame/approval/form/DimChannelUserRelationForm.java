package com.ai.bdx.frame.approval.form;

public class DimChannelUserRelationForm extends SysBaseForm {
	private Short channeltypeId;

	private String channelId;

	private String userId1;

	private Short confirmType;

	private int resourceId;

	/**
	 * @return channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * @param channelId
	 *            ~o channelId
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return channeltypeId
	 */
	public Short getChanneltypeId() {
		return channeltypeId;
	}

	/**
	 * @param channeltypeId
	 *            ~o channeltypeId
	 */
	public void setChanneltypeId(Short channeltypeId) {
		this.channeltypeId = channeltypeId;
	}

	/**
	 * @return confirmType
	 */
	public Short getConfirmType() {
		return confirmType;
	}

	/**
	 * @param confirmType
	 *            ~o confirmType
	 */
	public void setConfirmType(Short confirmType) {
		this.confirmType = confirmType;
	}

	/**
	 * @return resourceId
	 */
	public int getResourceId() {
		return resourceId;
	}

	/**
	 * @param resourceId
	 *            ~o resourceId
	 */
	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}

	public String getUserId1() {
		return userId1;
	}

	public void setUserId1(String userId1) {
		this.userId1 = userId1;
	}

	public DimChannelUserRelationForm() {

	}

}

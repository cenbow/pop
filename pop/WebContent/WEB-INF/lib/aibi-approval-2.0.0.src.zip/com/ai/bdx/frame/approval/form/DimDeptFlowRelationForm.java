/*     */ package com.ai.bdx.frame.approval.form;
/*     */ 
/*     */ public class DimDeptFlowRelationForm extends SysBaseForm
/*     */ {
/*     */   private String campDrvId;
/*     */   private String deptId;
/*     */   private String cityId;
/*     */   private String channelId;
/*     */   private String flow_type;
/*     */   private String approveFlowId;
/*     */   private String relationType;
/*     */   private Short approveType1;
/*     */   private Short campDrvId1;
/*     */   private String deptId1;
/*     */   private String cityId1;
/*     */   private Short channeltypeId1;
/*     */   private String channelId1;
/*     */   int rowsPerPage;
/*     */   int rowPerPage;
/*     */ 
/*     */   public Short getApproveType1()
/*     */   {
/*  24 */     return this.approveType1;
/*     */   }
/*     */ 
/*     */   public void setApproveType1(Short approveType1) {
/*  28 */     this.approveType1 = approveType1;
/*     */   }
/*     */ 
/*     */   public Short getCampDrvId1() {
/*  32 */     return this.campDrvId1;
/*     */   }
/*     */ 
/*     */   public void setCampDrvId1(Short campDrvId1) {
/*  36 */     this.campDrvId1 = campDrvId1;
/*     */   }
/*     */ 
/*     */   public String getDeptId1() {
/*  40 */     return this.deptId1;
/*     */   }
/*     */ 
/*     */   public void setDeptId1(String deptId1) {
/*  44 */     this.deptId1 = deptId1;
/*     */   }
/*     */ 
/*     */   public String getCityId1() {
/*  48 */     return this.cityId1;
/*     */   }
/*     */ 
/*     */   public void setCityId1(String cityId1) {
/*  52 */     this.cityId1 = cityId1;
/*     */   }
/*     */ 
/*     */   public Short getChanneltypeId1() {
/*  56 */     return this.channeltypeId1;
/*     */   }
/*     */ 
/*     */   public String getCampDrvId() {
/*  60 */     return this.campDrvId;
/*     */   }
/*     */ 
/*     */   public void setCampDrvId(String campDrvId) {
/*  64 */     this.campDrvId = campDrvId;
/*     */   }
/*     */ 
/*     */   public String getRelationType() {
/*  68 */     return this.relationType;
/*     */   }
/*     */ 
/*     */   public void setRelationType(String relationType) {
/*  72 */     this.relationType = relationType;
/*     */   }
/*     */ 
/*     */   public void setChanneltypeId1(Short channeltypeId1) {
/*  76 */     this.channeltypeId1 = channeltypeId1;
/*     */   }
/*     */ 
/*     */   public String getChannelId1() {
/*  80 */     return this.channelId1;
/*     */   }
/*     */ 
/*     */   public void setChannelId1(String channelId1) {
/*  84 */     this.channelId1 = channelId1;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowId()
/*     */   {
/*  93 */     return this.approveFlowId;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowId(String approveFlowId) {
/*  97 */     this.approveFlowId = approveFlowId;
/*     */   }
/*     */ 
/*     */   public String getDeptId() {
/* 101 */     return this.deptId;
/*     */   }
/*     */ 
/*     */   public void setDeptId(String deptId) {
/* 105 */     this.deptId = deptId;
/*     */   }
/*     */ 
/*     */   public String getCityId() {
/* 109 */     return this.cityId;
/*     */   }
/*     */ 
/*     */   public void setCityId(String cityId) {
/* 113 */     this.cityId = cityId;
/*     */   }
/*     */ 
/*     */   public String getChannelId()
/*     */   {
/* 119 */     return this.channelId;
/*     */   }
/*     */ 
/*     */   public void setChannelId(String channelId) {
/* 123 */     this.channelId = channelId;
/*     */   }
/*     */ 
/*     */   public int getRowsPerPage() {
/* 127 */     return this.rowsPerPage;
/*     */   }
/*     */ 
/*     */   public void setRowsPerPage(int rowsPerPage) {
/* 131 */     this.rowsPerPage = rowsPerPage;
/*     */   }
/*     */ 
/*     */   public int getRowPerPage() {
/* 135 */     return this.rowPerPage;
/*     */   }
/*     */ 
/*     */   public void setRowPerPage(int rowPerPage) {
/* 139 */     this.rowPerPage = rowPerPage;
/*     */   }
/*     */ 
/*     */   public String getFlow_type() {
/* 143 */     return this.flow_type;
/*     */   }
/*     */ 
/*     */   public void setFlow_type(String flow_type) {
/* 147 */     this.flow_type = flow_type;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.DimDeptFlowRelationForm
 * JD-Core Version:    0.6.2
 */
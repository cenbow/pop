package com.ai.bdx.frame.approval.form;

public class DimDeptFlowRelationForm extends SysBaseForm {

	// 主键
	private String campDrvId;
	private String deptId;
	private String cityId;
	private String channelId;
	private String flow_type;
	// 非主键
	private String approveFlowId;
	private String relationType;

	// 删除时使用的参数
	private Short approveType1;
	private Short campDrvId1;
	private String deptId1;
	private String cityId1;
	private Short channeltypeId1;
	private String channelId1;

	public Short getApproveType1() {
		return approveType1;
	}

	public void setApproveType1(Short approveType1) {
		this.approveType1 = approveType1;
	}

	public Short getCampDrvId1() {
		return campDrvId1;
	}

	public void setCampDrvId1(Short campDrvId1) {
		this.campDrvId1 = campDrvId1;
	}

	public String getDeptId1() {
		return deptId1;
	}

	public void setDeptId1(String deptId1) {
		this.deptId1 = deptId1;
	}

	public String getCityId1() {
		return cityId1;
	}

	public void setCityId1(String cityId1) {
		this.cityId1 = cityId1;
	}

	public Short getChanneltypeId1() {
		return channeltypeId1;
	}

	public String getCampDrvId() {
		return campDrvId;
	}

	public void setCampDrvId(String campDrvId) {
		this.campDrvId = campDrvId;
	}

	public String getRelationType() {
		return relationType;
	}

	public void setRelationType(String relationType) {
		this.relationType = relationType;
	}

	public void setChanneltypeId1(Short channeltypeId1) {
		this.channeltypeId1 = channeltypeId1;
	}

	public String getChannelId1() {
		return channelId1;
	}

	public void setChannelId1(String channelId1) {
		this.channelId1 = channelId1;
	}

	int rowsPerPage;
	int rowPerPage;

	

	public String getApproveFlowId() {
		return approveFlowId;
	}

	public void setApproveFlowId(String approveFlowId) {
		this.approveFlowId = approveFlowId;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public int getRowsPerPage() {
		return rowsPerPage;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}

	public int getRowPerPage() {
		return rowPerPage;
	}

	public void setRowPerPage(int rowPerPage) {
		this.rowPerPage = rowPerPage;
	}

	public String getFlow_type() {
		return flow_type;
	}

	public void setFlow_type(String flow_type) {
		this.flow_type = flow_type;
	}

}

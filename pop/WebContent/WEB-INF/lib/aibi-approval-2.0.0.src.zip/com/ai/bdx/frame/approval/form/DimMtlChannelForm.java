package com.ai.bdx.frame.approval.form;



public class DimMtlChannelForm extends SysBaseForm {
	private String channelId;

	private Short channeltypeId;

	private String channelName;

	/**
	 * @return channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * @param channelId ~o channelId
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return channelName
	 */
	public String getChannelName() {
		return channelName;
	}

	/**
	 * @param channelName ~o channelName
	 */
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	/**
	 * @return channeltypeId
	 */
	public Short getChanneltypeId() {
		return channeltypeId;
	}

	/**
	 * @param channeltypeId ~o channeltypeId
	 */
	public void setChanneltypeId(Short channeltypeId) {
		this.channeltypeId = channeltypeId;
	}

	public DimMtlChannelForm() {

	}
}

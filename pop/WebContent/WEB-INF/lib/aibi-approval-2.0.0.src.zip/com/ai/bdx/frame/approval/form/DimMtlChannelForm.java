/*    */ package com.ai.bdx.frame.approval.form;
/*    */ 
/*    */ public class DimMtlChannelForm extends SysBaseForm
/*    */ {
/*    */   private String channelId;
/*    */   private Short channeltypeId;
/*    */   private String channelName;
/*    */ 
/*    */   public String getChannelId()
/*    */   {
/* 16 */     return this.channelId;
/*    */   }
/*    */ 
/*    */   public void setChannelId(String channelId)
/*    */   {
/* 23 */     this.channelId = channelId;
/*    */   }
/*    */ 
/*    */   public String getChannelName()
/*    */   {
/* 30 */     return this.channelName;
/*    */   }
/*    */ 
/*    */   public void setChannelName(String channelName)
/*    */   {
/* 37 */     this.channelName = channelName;
/*    */   }
/*    */ 
/*    */   public Short getChanneltypeId()
/*    */   {
/* 44 */     return this.channeltypeId;
/*    */   }
/*    */ 
/*    */   public void setChanneltypeId(Short channeltypeId)
/*    */   {
/* 51 */     this.channeltypeId = channeltypeId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.DimMtlChannelForm
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.form;
/*    */ 
/*    */ public class DimMtlChanneltypeForm extends SysBaseForm
/*    */ {
/*    */   private Short channeltypeId;
/*    */   private String channeltypeName;
/*    */   private Short activeFlag;
/*    */ 
/*    */   public Short getActiveFlag()
/*    */   {
/* 14 */     return this.activeFlag;
/*    */   }
/*    */ 
/*    */   public void setActiveFlag(Short activeFlag)
/*    */   {
/* 22 */     this.activeFlag = activeFlag;
/*    */   }
/*    */ 
/*    */   public Short getChanneltypeId()
/*    */   {
/* 29 */     return this.channeltypeId;
/*    */   }
/*    */ 
/*    */   public void setChanneltypeId(Short channeltypeId)
/*    */   {
/* 37 */     this.channeltypeId = channeltypeId;
/*    */   }
/*    */ 
/*    */   public String getChanneltypeName()
/*    */   {
/* 44 */     return this.channeltypeName;
/*    */   }
/*    */ 
/*    */   public void setChanneltypeName(String channeltypeName)
/*    */   {
/* 52 */     this.channeltypeName = channeltypeName;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm
 * JD-Core Version:    0.6.2
 */
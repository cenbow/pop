package com.ai.bdx.frame.approval.form;


import java.util.Date;


/**
 * Created on May 30, 2007 11:05:38 AM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb
 * @version 1.0
 */
public class MpmApproveAuthForm extends SysBaseForm {
	private String authUserid;

	private String consignorUserid;

	private String consignorUsername;

	private Short authFlag;

	private Short authType = Short.valueOf("0");

	private String beginTime;

	private String endTime;

	private Date updateTime;

	private Short flag;

	public MpmApproveAuthForm() {
	}

	public String getAuthUserid() {
		return this.authUserid;
	}

	public void setAuthUserid(String authUserid) {
		this.authUserid = authUserid;
	}

	public String getConsignorUserid() {
		return this.consignorUserid;
	}

	public void setConsignorUserid(String consignorUserid) {
		this.consignorUserid = consignorUserid;
	}

	public String getConsignorUsername() {
		return this.consignorUsername;
	}

	public void setConsignorUsername(String consignorUsername) {
		this.consignorUsername = consignorUsername;
	}

	public Short getAuthFlag() {
		return this.authFlag;
	}

	public void setAuthFlag(Short authFlag) {
		this.authFlag = authFlag;
	}

	public String getBeginTime() {
		return this.beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return this.endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	public Short getAuthType() {
		return authType;
	}

	public void setAuthType(Short authType) {
		this.authType = authType;
	}

}

/*     */ package com.ai.bdx.frame.approval.form;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public class MpmApproveAuthForm extends SysBaseForm
/*     */ {
/*     */   private String authUserid;
/*     */   private String consignorUserid;
/*     */   private String consignorUsername;
/*     */   private Short authFlag;
/*  26 */   private Short authType = Short.valueOf("0");
/*     */   private String beginTime;
/*     */   private String endTime;
/*     */   private Date updateTime;
/*     */   private Short flag;
/*     */ 
/*     */   public String getAuthUserid()
/*     */   {
/*  40 */     return this.authUserid;
/*     */   }
/*     */ 
/*     */   public void setAuthUserid(String authUserid) {
/*  44 */     this.authUserid = authUserid;
/*     */   }
/*     */ 
/*     */   public String getConsignorUserid() {
/*  48 */     return this.consignorUserid;
/*     */   }
/*     */ 
/*     */   public void setConsignorUserid(String consignorUserid) {
/*  52 */     this.consignorUserid = consignorUserid;
/*     */   }
/*     */ 
/*     */   public String getConsignorUsername() {
/*  56 */     return this.consignorUsername;
/*     */   }
/*     */ 
/*     */   public void setConsignorUsername(String consignorUsername) {
/*  60 */     this.consignorUsername = consignorUsername;
/*     */   }
/*     */ 
/*     */   public Short getAuthFlag() {
/*  64 */     return this.authFlag;
/*     */   }
/*     */ 
/*     */   public void setAuthFlag(Short authFlag) {
/*  68 */     this.authFlag = authFlag;
/*     */   }
/*     */ 
/*     */   public String getBeginTime() {
/*  72 */     return this.beginTime;
/*     */   }
/*     */ 
/*     */   public void setBeginTime(String beginTime) {
/*  76 */     this.beginTime = beginTime;
/*     */   }
/*     */ 
/*     */   public String getEndTime() {
/*  80 */     return this.endTime;
/*     */   }
/*     */ 
/*     */   public void setEndTime(String endTime) {
/*  84 */     this.endTime = endTime;
/*     */   }
/*     */ 
/*     */   public Date getUpdateTime() {
/*  88 */     return this.updateTime;
/*     */   }
/*     */ 
/*     */   public void setUpdateTime(Date updateTime) {
/*  92 */     this.updateTime = updateTime;
/*     */   }
/*     */ 
/*     */   public Short getFlag() {
/*  96 */     return this.flag;
/*     */   }
/*     */ 
/*     */   public void setFlag(Short flag) {
/* 100 */     this.flag = flag;
/*     */   }
/*     */ 
/*     */   public Short getAuthType() {
/* 104 */     return this.authType;
/*     */   }
/*     */ 
/*     */   public void setAuthType(Short authType) {
/* 108 */     this.authType = authType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.MpmApproveAuthForm
 * JD-Core Version:    0.6.2
 */
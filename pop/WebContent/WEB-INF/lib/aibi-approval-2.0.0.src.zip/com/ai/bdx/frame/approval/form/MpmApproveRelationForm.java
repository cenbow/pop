/*     */ package com.ai.bdx.frame.approval.form;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public class MpmApproveRelationForm extends SysBaseForm
/*     */ {
/*     */   private String deptId;
/*     */   private String approveUserid;
/*     */   private Integer positionId;
/*     */   private Short approveLevel;
/*     */   private String approveCreateUserid;
/*     */   private Date createTime;
/*     */   private String approveUseridEmail;
/*     */   private String approveUseridMsisdn;
/*     */   private Integer approverDeptid;
/*     */   private Integer creatorDeptid;
/*     */   private String cityid;
/*     */   private String deptName;
/*     */   private String approveUsername;
/*     */   private String approveCreateUsername;
/*     */   private String toforward;
/*     */   private String changePk;
/*     */   private String changeApprove;
/*     */   private String beforeCreateUserid;
/*     */   private String beforeApproveUserid;
/*     */ 
/*     */   public void setBeforeCreateUserid(String beforeCreateUserid)
/*     */   {
/*  44 */     this.beforeCreateUserid = beforeCreateUserid;
/*     */   }
/*     */ 
/*     */   public String getBeforeCreateUserid() {
/*  48 */     return this.beforeCreateUserid;
/*     */   }
/*     */ 
/*     */   public void setBeforeApproveUserid(String beforeApproveUserid) {
/*  52 */     this.beforeApproveUserid = beforeApproveUserid;
/*     */   }
/*     */ 
/*     */   public String getBeforeApproveUserid() {
/*  56 */     return this.beforeApproveUserid;
/*     */   }
/*     */ 
/*     */   public void setChangePk(String changePk) {
/*  60 */     this.changePk = changePk;
/*     */   }
/*     */ 
/*     */   public String getChangePk() {
/*  64 */     return this.changePk;
/*     */   }
/*     */ 
/*     */   public void setChangeApprove(String changeApprove) {
/*  68 */     this.changeApprove = changeApprove;
/*     */   }
/*     */ 
/*     */   public String getChangeApprove() {
/*  72 */     return this.changeApprove;
/*     */   }
/*     */ 
/*     */   public void setToforward(String toforward) {
/*  76 */     this.toforward = toforward;
/*     */   }
/*     */ 
/*     */   public String getToforward() {
/*  80 */     return this.toforward;
/*     */   }
/*     */ 
/*     */   public void setDeptName(String createUsername) {
/*  84 */     this.deptName = createUsername;
/*     */   }
/*     */ 
/*     */   public String getDeptName() {
/*  88 */     return this.deptName;
/*     */   }
/*     */ 
/*     */   public void setApproveUsername(String approveUsername) {
/*  92 */     this.approveUsername = approveUsername;
/*     */   }
/*     */ 
/*     */   public String getApproveUsername() {
/*  96 */     return this.approveUsername;
/*     */   }
/*     */ 
/*     */   public void setApproveCreateUsername(String approveCreateUsername) {
/* 100 */     this.approveCreateUsername = approveCreateUsername;
/*     */   }
/*     */ 
/*     */   public String getApproveCreateUsername() {
/* 104 */     return this.approveCreateUsername;
/*     */   }
/*     */ 
/*     */   public String getDeptId()
/*     */   {
/* 118 */     return this.deptId;
/*     */   }
/*     */ 
/*     */   public void setDeptId(String createUserid)
/*     */   {
/* 126 */     this.deptId = createUserid;
/*     */   }
/*     */ 
/*     */   public String getApproveUserid()
/*     */   {
/* 134 */     return this.approveUserid;
/*     */   }
/*     */ 
/*     */   public void setApproveUserid(String approveUserid)
/*     */   {
/* 142 */     this.approveUserid = approveUserid;
/*     */   }
/*     */ 
/*     */   public Short getApproveLevel()
/*     */   {
/* 150 */     return this.approveLevel;
/*     */   }
/*     */ 
/*     */   public void setApproveLevel(Short approveLevel)
/*     */   {
/* 158 */     this.approveLevel = approveLevel;
/*     */   }
/*     */ 
/*     */   public String getApproveCreateUserid()
/*     */   {
/* 166 */     return this.approveCreateUserid;
/*     */   }
/*     */ 
/*     */   public void setApproveCreateUserid(String approveCreateUserid)
/*     */   {
/* 174 */     this.approveCreateUserid = approveCreateUserid;
/*     */   }
/*     */ 
/*     */   public Date getCreateTime()
/*     */   {
/* 182 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(Date createTime)
/*     */   {
/* 190 */     this.createTime = createTime;
/*     */   }
/*     */ 
/*     */   public Integer getPositionId()
/*     */   {
/* 198 */     return this.positionId;
/*     */   }
/*     */ 
/*     */   public void setPositionId(Integer positionId)
/*     */   {
/* 206 */     this.positionId = positionId;
/*     */   }
/*     */ 
/*     */   public String getApproveUseridEmail()
/*     */   {
/* 214 */     return this.approveUseridEmail;
/*     */   }
/*     */ 
/*     */   public void setApproveUseridEmail(String approveUseridEmail)
/*     */   {
/* 222 */     this.approveUseridEmail = approveUseridEmail;
/*     */   }
/*     */ 
/*     */   public String getApproveUseridMsisdn()
/*     */   {
/* 230 */     return this.approveUseridMsisdn;
/*     */   }
/*     */ 
/*     */   public void setApproveUseridMsisdn(String approveUseridMsisdn)
/*     */   {
/* 238 */     this.approveUseridMsisdn = approveUseridMsisdn;
/*     */   }
/*     */ 
/*     */   public Integer getApproverDeptid()
/*     */   {
/* 246 */     return this.approverDeptid;
/*     */   }
/*     */ 
/*     */   public void setApproverDeptid(Integer approverDeptid)
/*     */   {
/* 254 */     this.approverDeptid = approverDeptid;
/*     */   }
/*     */ 
/*     */   public Integer getCreatorDeptid()
/*     */   {
/* 262 */     return this.creatorDeptid;
/*     */   }
/*     */ 
/*     */   public void setCreatorDeptid(Integer creatorDeptid)
/*     */   {
/* 270 */     this.creatorDeptid = creatorDeptid;
/*     */   }
/*     */ 
/*     */   public void setCityid(String cityid) {
/* 274 */     this.cityid = cityid;
/*     */   }
/*     */ 
/*     */   public String getCityid() {
/* 278 */     return this.cityid;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.MpmApproveRelationForm
 * JD-Core Version:    0.6.2
 */
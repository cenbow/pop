package com.ai.bdx.frame.approval.form;

public class MpmApproveRelationForm extends SysBaseForm {

	private java.lang.String deptId;

	private java.lang.String approveUserid;

	private java.lang.Integer positionId;

	private java.lang.Short approveLevel;

	private java.lang.String approveCreateUserid;

	private java.util.Date createTime;

	private java.lang.String approveUseridEmail;

	private java.lang.String approveUseridMsisdn;

	private java.lang.Integer approverDeptid;

	private java.lang.Integer creatorDeptid;

	private String cityid;

	private String deptName;

	private String approveUsername;

	private String approveCreateUsername;

	private String toforward;

	private String changePk;

	private String changeApprove;

	private String beforeCreateUserid;

	private String beforeApproveUserid;

	public void setBeforeCreateUserid(String beforeCreateUserid) {
		this.beforeCreateUserid = beforeCreateUserid;
	}

	public String getBeforeCreateUserid() {
		return beforeCreateUserid;
	}

	public void setBeforeApproveUserid(String beforeApproveUserid) {
		this.beforeApproveUserid = beforeApproveUserid;
	}

	public String getBeforeApproveUserid() {
		return beforeApproveUserid;
	}

	public void setChangePk(String changePk) {
		this.changePk = changePk;
	}

	public String getChangePk() {
		return changePk;
	}

	public void setChangeApprove(String changeApprove) {
		this.changeApprove = changeApprove;
	}

	public String getChangeApprove() {
		return changeApprove;
	}

	public void setToforward(String toforward) {
		this.toforward = toforward;
	}

	public String getToforward() {
		return toforward;
	}

	public void setDeptName(String createUsername) {
		deptName = createUsername;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setApproveUsername(String approveUsername) {
		this.approveUsername = approveUsername;
	}

	public String getApproveUsername() {
		return approveUsername;
	}

	public void setApproveCreateUsername(String approveCreateUsername) {
		this.approveCreateUsername = approveCreateUsername;
	}

	public String getApproveCreateUsername() {
		return approveCreateUsername;
	}

	/**
	 * Simple constructor of MtlApproveRelationKey instances.
	 */
	public MpmApproveRelationForm() {
	}

	/**
	 * Returns the value of the createUserid property.
	 * @return java.lang.String
	 */
	public java.lang.String getDeptId() {
		return deptId;
	}

	/**
	 * Sets the value of the createUserid property.
	 * @param createUserid
	 */
	public void setDeptId(java.lang.String createUserid) {
		deptId = createUserid;
	}

	/**
	 * Returns the value of the approveUserid property.
	 * @return java.lang.String
	 */
	public java.lang.String getApproveUserid() {
		return approveUserid;
	}

	/**
	 * Sets the value of the approveUserid property.
	 * @param approveUserid
	 */
	public void setApproveUserid(java.lang.String approveUserid) {
		this.approveUserid = approveUserid;
	}

	/**
	 * Return the value of the APPROVE_LEVEL column.
	 * @return java.lang.Short
	 */
	public java.lang.Short getApproveLevel() {
		return approveLevel;
	}

	/**
	 * Set the value of the APPROVE_LEVEL column.
	 * @param approveLevel
	 */
	public void setApproveLevel(java.lang.Short approveLevel) {
		this.approveLevel = approveLevel;
	}

	/**
	 * Return the value of the APPROVE_CREATE_USERID column.
	 * @return java.lang.String
	 */
	public java.lang.String getApproveCreateUserid() {
		return approveCreateUserid;
	}

	/**
	 * Set the value of the APPROVE_CREATE_USERID column.
	 * @param approveCreateUserid
	 */
	public void setApproveCreateUserid(java.lang.String approveCreateUserid) {
		this.approveCreateUserid = approveCreateUserid;
	}

	/**
	 * Return the value of the CREATE_TIME column.
	 * @return java.util.Date
	 */
	public java.util.Date getCreateTime() {
		return createTime;
	}

	/**
	 * Set the value of the CREATE_TIME column.
	 * @param createTime
	 */
	public void setCreateTime(java.util.Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * Return the value of the POSITION_ID column.
	 * @return DimPositionCode
	 */
	public Integer getPositionId() {
		return positionId;
	}

	/**
	 * Set the value of the POSITION_ID column.
	 * @param dimPositionCode
	 */
	public void setPositionId(Integer positionId) {
		this.positionId = positionId;
	}

	/**
	 * Return the value of the APPROVE_USERID_EMAIL column.
	 * @return java.lang.String
	 */
	public java.lang.String getApproveUseridEmail() {
		return approveUseridEmail;
	}

	/**
	 * Set the value of the APPROVE_USERID_EMAIL column.
	 * @param approveUseridEmail
	 */
	public void setApproveUseridEmail(java.lang.String approveUseridEmail) {
		this.approveUseridEmail = approveUseridEmail;
	}

	/**
	 * Return the value of the APPROVE_USERID_MSISDN column.
	 * @return java.lang.String
	 */
	public java.lang.String getApproveUseridMsisdn() {
		return approveUseridMsisdn;
	}

	/**
	 * Set the value of the APPROVE_USERID_MSISDN column.
	 * @param approveUseridMsisdn
	 */
	public void setApproveUseridMsisdn(java.lang.String approveUseridMsisdn) {
		this.approveUseridMsisdn = approveUseridMsisdn;
	}

	/**
	 * Return the value of the APPROVER_DEPTID column.
	 * @return java.lang.Integer
	 */
	public java.lang.Integer getApproverDeptid() {
		return approverDeptid;
	}

	/**
	 * Set the value of the APPROVER_DEPTID column.
	 * @param approverDeptid
	 */
	public void setApproverDeptid(java.lang.Integer approverDeptid) {
		this.approverDeptid = approverDeptid;
	}

	/**
	 * Return the value of the CREATOR_DEPTID column.
	 * @return java.lang.Integer
	 */
	public java.lang.Integer getCreatorDeptid() {
		return creatorDeptid;
	}

	/**
	 * Set the value of the CREATOR_DEPTID column.
	 * @param creatorDeptid
	 */
	public void setCreatorDeptid(java.lang.Integer creatorDeptid) {
		this.creatorDeptid = creatorDeptid;
	}

	public void setCityid(String cityid) {
		this.cityid = cityid;
	}

	public String getCityid() {
		return cityid;
	}
}

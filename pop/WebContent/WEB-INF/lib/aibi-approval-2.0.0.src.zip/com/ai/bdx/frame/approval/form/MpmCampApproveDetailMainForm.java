package com.ai.bdx.frame.approval.form;

import org.apache.struts.upload.FormFile;

public class MpmCampApproveDetailMainForm extends MpmCampDesignBaseForm {

	private String campName = "";

	private short campDrvId = 0;

	private String attachmentUrls = "";

	private String campObjective = "";

	private String campStrategy = "";

	private int deptId = 0;

	private String campsegName = "";

	private short campsegNo = 0;

	private String startDate = "";

	private String endDate = "";

	private String cityId = "";

	private int targetUserNums = 0;

	private String approveAdv = "";

	private String createUserid = "";

	private String approveUserId = "";

	private int contactNums = 0;

	private String extendCustN;

	private String resourceName = "";

	private short campStatId;

	private short campStatus;

	private Double[] custNums;

	private String[] rptScore;

	private String changeEndDate = "";

	private String changeStartDate = "";

	private String[] channelCampContent = { "aaa", "aaa", "aaa", "aaa", "aaa", "aaa", "aaa", "aaa", "aaa", "aaa" };

	//活动开始日期
	private String campStartDate = "";

	//活动结束日期
	private String campEndDate = "";

	//活动描述
	private String campDesc = "";

	//活动优先级
	private String campPri = "";

	//驱动类型
	private String campDrv = "";

	//波次描述
	private String campsegDesc = "";

	//波次最大客户数
	int campsegMaxuser = 0;

	//波次期望对比用户数
	int campsegContrastUsers = 0;

	String publicizeId = "";

	// 是否是提审批意见页面
	private String adviceFlag;

	private String sponorUserId;

	private String campId;

	private String campsegId;

	private String flowId;

	private String filterRuleId;

	private String createdPhaseId;

	private String usersegId;

	private short approveResult;

	private short approveReceiveNums;
	
	private short seq;

	private String resourceId;

	private String confirmUserid;

	private String confirmId;

	private String usersegContent;

	private String modifiedFlag;

	private String modifiedFlag1;

	private Integer campsegMaxUsers;

	private FormFile[] files = new FormFile[] { this.file1, this.file2, this.file3, this.file4, this.file5 };

	private String[] fileDescs = new String[] { this.fileDesc1, this.fileDesc2, this.fileDesc3, this.fileDesc4, this.fileDesc5 };

	private String fileDesc1;

	private FormFile file1;

	private String fileDesc2;

	private FormFile file2;

	private String fileDesc3;

	private FormFile file3;

	private String fileDesc4;

	private FormFile file4;

	private String fileDesc5;

	private FormFile file5;

	private String delAttachIds;

	// caihao add
	private String approveFlag;

	private String approveFlowid;

	private Double guessTotalCost;

	private Double guessTotalCustNum;

	private String[] channelType;

	private String campCityName;

	private String channelTypeName;

	private String campCity;

	private Short campType;

	private String publicizeCombId;

	private short confirmFlag;
	
	private String channelSendTypeId;

	// YangQ add
	// for BeiJing BI
	// 2008-01-21
	//private String useCustGotoneNums;// 全球通客户数
	//private String useCustMzoneNums;// 动感地带客户数
	//private String useCustScpNums;// 神州行客户数
	private Short existVipCustFlag;// 是否包含VIP客户

	private String existVipCust;//是否包含VIP客户 是/否

	private String rptScoreN;//渠道评分结果

	// YangQ add end

	private String campTempletId = "";

	public int ruleType = 0;
	
	private String channelCampCont;
	
	private String userSrvDesc;
	
	private String channeltypeId;
	
	private String channelId;
	
	private String channeltypeAndId;
	//活动执行人员（辽宁需求）added by caosj 2009-06-04
	private String executeUser;
	
	//GDS需求
	private String serviceType;
	private String hodCcoFlag;
	private String subCampDrvId;
	
	
	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getHodCcoFlag() {
		return hodCcoFlag;
	}

	public void setHodCcoFlag(String hodCcoFlag) {
		this.hodCcoFlag = hodCcoFlag;
	}

	public String getSubCampDrvId() {
		return subCampDrvId;
	}

	public void setSubCampDrvId(String subCampDrvId) {
		this.subCampDrvId = subCampDrvId;
	}

	/**
	 * @return channelId
	 */
	
	public String getChannelId() {
		return channelId;
	}

	/**
	 * @param channelId 要设置的 channelId
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return channeltypeId
	 */
	public String getChanneltypeId() {
		return channeltypeId;
	}

	public String getUserSrvDesc() {
		return userSrvDesc;
	}

	public void setUserSrvDesc(String userSrvDesc) {
		this.userSrvDesc = userSrvDesc;
	}

	/**
	 * @param channeltypeId 要设置的 channeltypeId
	 */
	public void setChanneltypeId(String channeltypeId) {
		this.channeltypeId = channeltypeId;
	}

	public String getDelAttachIds() {
		return delAttachIds;
	}

	public String getExistVipCust() {
		return existVipCust;
	}

	public String getChannelSendTypeId() {
		return channelSendTypeId;
	}

	public void setChannelSendTypeId(String channelSendTypeId) {
		this.channelSendTypeId = channelSendTypeId;
	}

	public void setExistVipCust(String existVipCust) {
		this.existVipCust = existVipCust;
	}

	public void setDelAttachIds(String delAttachIds) {
		this.delAttachIds = delAttachIds;
	}

	public FormFile getFile1() {
		return file1;
	}

	public void setFile1(FormFile file1) {
		this.file1 = file1;
		this.files[0] = file1;
	}

	public FormFile getFile2() {
		return file2;
	}

	public void setFile2(FormFile file2) {
		this.file2 = file2;
		this.files[1] = file2;
	}

	public FormFile getFile3() {
		return file3;
	}

	public void setFile3(FormFile file3) {
		this.file3 = file3;
		this.files[2] = file3;
	}

	public FormFile getFile4() {
		return file4;
	}

	public void setFile4(FormFile file4) {
		this.file4 = file4;
		this.files[3] = file4;
	}

	public FormFile getFile5() {
		return file5;

	}

	public void setFile5(FormFile file5) {
		this.file5 = file5;
		this.files[4] = file5;
	}

	public String getFileDesc1() {
		return fileDesc1;
	}

	public void setFileDesc1(String fileDesc1) {
		this.fileDesc1 = fileDesc1;
		this.fileDescs[0] = fileDesc1;
	}

	public String getFileDesc2() {
		return fileDesc2;
	}

	public void setFileDesc2(String fileDesc2) {
		this.fileDesc2 = fileDesc2;
		this.fileDescs[1] = fileDesc2;
	}

	public String getFileDesc3() {
		return fileDesc3;
	}

	public void setFileDesc3(String fileDesc3) {
		this.fileDesc3 = fileDesc3;
		this.fileDescs[2] = fileDesc3;
	}

	public String getFileDesc4() {
		return fileDesc4;
	}

	public void setFileDesc4(String fileDesc4) {
		this.fileDesc4 = fileDesc4;
		this.fileDescs[3] = fileDesc4;
	}

	public String getFileDesc5() {
		return fileDesc5;
	}

	public void setFileDesc5(String fileDesc5) {
		this.fileDesc5 = fileDesc5;
		this.fileDescs[4] = fileDesc5;
	}

	public String[] getFileDescs() {
		return fileDescs;
	}

	public void setFileDescs(String[] fileDescs) {
		this.fileDescs = fileDescs;
	}

	public FormFile[] getFiles() {
		return files;
	}

	public void setFiles(FormFile[] files) {
		this.files = files;
	}

	public String getApproveAdv() {
		return approveAdv;
	}

	public void setApproveAdv(String approveAdv) {
		this.approveAdv = approveAdv;
	}

	public String getAttachmentUrls() {
		return attachmentUrls;
	}

	public void setAttachmentUrls(String attachmentUrls) {
		this.attachmentUrls = attachmentUrls;
	}

	public short getCampDrvId() {
		return campDrvId;
	}

	public void setCampDrvId(short campDrvId) {
		this.campDrvId = campDrvId;
	}

	public String getCampName() {
		return campName;
	}

	public void setCampName(String campName) {
		this.campName = campName;
	}

	public String getCampObjective() {
		return campObjective;
	}

	public void setCampObjective(String campObjective) {
		this.campObjective = campObjective;
	}

	public String getCampsegName() {
		return campsegName;
	}

	public void setCampsegName(String campsegName) {
		this.campsegName = campsegName;
	}

	public short getCampsegNo() {
		return campsegNo;
	}

	public void setCampsegNo(short campsegNo) {
		this.campsegNo = campsegNo;
	}

	public String getCampStrategy() {
		return campStrategy;
	}

	public void setCampStrategy(String campStrategy) {
		this.campStrategy = campStrategy;
	}

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public int getTargetUserNums() {
		return targetUserNums;
	}

	public void setTargetUserNums(int targetUserNums) {
		this.targetUserNums = targetUserNums;
	}

	public String getCampId() {
		return campId;
	}

	public void setCampId(String campId) {

		this.campId = campId;
	}

	public String getCampsegId() {

		return campsegId;
	}

	public void setCampsegId(String campsegId) {

		this.campsegId = campsegId;
	}

	public String getFlowId() {
		return flowId;
	}

	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}

	public String getCreateUserid() {
		return createUserid;
	}

	public void setCreateUserid(String createUserid) {
		this.createUserid = createUserid;
	}

	public String getCreatedPhaseId() {
		return createdPhaseId;
	}

	public void setCreatedPhaseId(String createdPhaseId) {
		this.createdPhaseId = createdPhaseId;
	}

	public String getFilterRuleId() {
		return filterRuleId;
	}

	public void setFilterRuleId(String filterRuleId) {
		this.filterRuleId = filterRuleId;
	}

	public String getApproveUserId() {
		return approveUserId;
	}

	public void setApproveUserId(String approveUserId) {
		this.approveUserId = approveUserId;
	}

	public String getUsersegId() {
		return usersegId;
	}

	public void setUsersegId(String usersegId) {
		this.usersegId = usersegId;
	}

	public short getApproveResult() {
		return approveResult;
	}

	public void setApproveResult(short approveResult) {
		this.approveResult = approveResult;
	}

	public short getApproveReceiveNums() {
		return approveReceiveNums;
	}

	public void setApproveReceiveNums(short approveReceiveNums) {
		this.approveReceiveNums = approveReceiveNums;
	}

	public String getCampEndDate() {
		return campEndDate;
	}

	public void setCampEndDate(String campEndDate) {
		this.campEndDate = campEndDate;
	}

	public String getCampStartDate() {
		return campStartDate;
	}

	public void setCampStartDate(String campStartDate) {
		this.campStartDate = campStartDate;
	}

	public String getCampDesc() {
		return campDesc;
	}

	public void setCampDesc(String campDesc) {
		this.campDesc = campDesc;
	}

	public String getCampDrv() {
		return campDrv;
	}

	public void setCampDrv(String campDrv) {
		this.campDrv = campDrv;
	}

	public String getCampPri() {
		return campPri;
	}

	public void setCampPri(String campPri) {
		this.campPri = campPri;
	}

	public int getCampsegContrastUsers() {
		return campsegContrastUsers;
	}

	public void setCampsegContrastUsers(int campsegContrastUsers) {
		this.campsegContrastUsers = campsegContrastUsers;
	}

	public String getCampsegDesc() {
		return campsegDesc;
	}

	public void setCampsegDesc(String campsegDesc) {
		this.campsegDesc = campsegDesc;
	}

	public int getCampsegMaxuser() {
		return campsegMaxuser;
	}

	public void setCampsegMaxuser(int campsegMaxuser) {
		this.campsegMaxuser = campsegMaxuser;
	}

	public int getContactNums() {
		return contactNums;
	}

	public void setContactNums(int contactNums) {
		this.contactNums = contactNums;
	}

	public String getPublicizeId() {
		return publicizeId;
	}

	public void setPublicizeId(String publicizeId) {
		this.publicizeId = publicizeId;
	}

	public String getAdviceFlag() {
		return adviceFlag;
	}

	public void setAdviceFlag(String adviceFlag) {
		this.adviceFlag = adviceFlag;
	}

	public String getSponorUserId() {
		return sponorUserId;
	}

	public void setSponorUserId(String sponorUserId) {
		this.sponorUserId = sponorUserId;
	}

	public String getConfirmId() {
		return this.confirmId;
	}

	public void setConfirmId(String confirmId) {
		this.confirmId = confirmId;
	}

	public String getConfirmUserid() {
		return this.confirmUserid;
	}

	public void setConfirmUserid(String confirmUserid) {
		this.confirmUserid = confirmUserid;
	}

	public String getResourceId() {
		return this.resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getUsersegContent() {
		return this.usersegContent;
	}

	public void setUsersegContent(String usersegContent) {
		this.usersegContent = usersegContent;
	}

	public String getModifiedFlag() {
		return this.modifiedFlag;
	}

	public void setModifiedFlag(String modifiedFlag) {
		this.modifiedFlag = modifiedFlag;
	}

	public String getModifiedFlag1() {
		return this.modifiedFlag1;
	}

	public void setModifiedFlag1(String modifiedFlag1) {
		this.modifiedFlag1 = modifiedFlag1;
	}

	public Integer getCampsegMaxUsers() {
		return campsegMaxUsers;
	}

	public void setCampsegMaxUsers(Integer campsegMaxUsers) {
		this.campsegMaxUsers = campsegMaxUsers;
	}

	public String getApproveFlag() {
		return approveFlag;
	}

	public void setApproveFlag(String approveFlag) {
		this.approveFlag = approveFlag;
	}

	public String getApproveFlowid() {
		return approveFlowid;
	}

	public void setApproveFlowid(String approveFlowid) {
		this.approveFlowid = approveFlowid;
	}

	public Double getGuessTotalCost() {
		return guessTotalCost;
	}

	public void setGuessTotalCost(Double guessTotalCost) {
		this.guessTotalCost = guessTotalCost;
	}

	public Double getGuessTotalCustNum() {
		return guessTotalCustNum;
	}

	public void setGuessTotalCustNum(Double guessTotalCustNum) {
		this.guessTotalCustNum = guessTotalCustNum;
	}

	public String[] getChannelType() {
		return channelType;
	}

	/**
	 * @param channelType
	 *            要设置的 channelType
	 */
	public void setChannelType(String[] channelType) {
		this.channelType = channelType;
	}

	public String getCampCityName() {
		return campCityName;
	}

	public void setCampCityName(String campCityName) {
		this.campCityName = campCityName;
	}

	public String getCampCity() {
		return campCity;
	}

	public void setCampCity(String campCity) {
		this.campCity = campCity;
	}

	public Short getCampType() {
		return campType;
	}

	public void setCampType(Short campType) {
		this.campType = campType;
	}

	public String getPublicizeCombId() {

		return publicizeCombId;
	}

	public void setPublicizeCombId(String publicizeCombId) {

		this.publicizeCombId = publicizeCombId;
	}

	/**
	 * @return channelTypeName
	 */
	public String getChannelTypeName() {
		return channelTypeName;
	}

	/**
	 * @param channelTypeName
	 *            要设置的 channelTypeName
	 */
	public void setChannelTypeName(String channelTypeName) {
		this.channelTypeName = channelTypeName;
	}

	public short getCampStatId() {
		return campStatId;
	}

	public void setCampStatId(short campStatId) {
		this.campStatId = campStatId;
	}

	public short getConfirmFlag() {
		return confirmFlag;
	}

	public void setConfirmFlag(short confirmFlag) {
		this.confirmFlag = confirmFlag;
	}

	public short getCampStatus() {
		return campStatus;
	}

	public void setCampStatus(short campStatus) {
		this.campStatus = campStatus;
	}

	public String getExtendCustN() {

		return extendCustN;
	}

	public String getChangeStartDate() {
		return changeStartDate;
	}

	public void setChangeStartDate(String changeStartDate) {
		this.changeStartDate = changeStartDate;
	}

	public String getChangeEndDate() {
		return changeEndDate;
	}

	public void setChangeEndDate(String changeEndDate) {
		this.changeEndDate = changeEndDate;
	}

	public Short getExistVipCustFlag() {
		return existVipCustFlag;
	}

	public void setExistVipCustFlag(Short existVipCustFlag) {
		this.existVipCustFlag = existVipCustFlag;
	}

	public void setExtendCustN(String extendCustN) {
		this.extendCustN = extendCustN;
	}

	public String[] getChannelCampContent() {
		return channelCampContent;
	}

	public void setChannelCampContent(String[] channelCampContent) {
		this.channelCampContent = channelCampContent;
	}

	public String getRptScoreN() {
		return rptScoreN;
	}

	public void setRptScoreN(String rptScoreN) {
		this.rptScoreN = rptScoreN;
	}

	public String getCampTempletId() {
		return campTempletId;
	}

	public void setCampTempletId(String campTempletId) {
		this.campTempletId = campTempletId;
	}

	public int getRuleType() {
		return ruleType;
	}

	public void setRuleType(int ruleType) {
		this.ruleType = ruleType;
	}

	public Double[] getCustNums() {
		return custNums;
	}

	public void setCustNums(Double[] custNums) {
		this.custNums = custNums;
	}

	public String[] getRptScore() {
		return rptScore;
	}

	public void setRptScore(String[] rptScore) {
		this.rptScore = rptScore;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	/**
	 * @return channelCampCont
	 */
	public String getChannelCampCont() {
		return channelCampCont;
	}

	/**
	 * @param channelCampCont 要设置的 channelCampCont
	 */
	public void setChannelCampCont(String channelCampCont) {
		this.channelCampCont = channelCampCont;
	}

	public String getChanneltypeAndId() {
		return this.channeltypeId + "_" + this.channelId;
	}

	public String getExecuteUser() {
		return executeUser;
	}

	public void setExecuteUser(String executeUser) {
		this.executeUser = executeUser;
	}

	public short getSeq() {
		return seq;
	}

	public void setSeq(short seq) {
		this.seq = seq;
	}

}

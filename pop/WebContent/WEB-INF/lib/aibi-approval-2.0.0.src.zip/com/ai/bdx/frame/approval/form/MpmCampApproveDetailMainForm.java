/*     */ package com.ai.bdx.frame.approval.form;
/*     */ 
/*     */ import org.apache.struts.upload.FormFile;
/*     */ 
/*     */ public class MpmCampApproveDetailMainForm extends MpmCampDesignBaseForm
/*     */ {
/*   7 */   private String campName = "";
/*     */ 
/*   9 */   private short campDrvId = 0;
/*     */ 
/*  11 */   private String attachmentUrls = "";
/*     */ 
/*  13 */   private String campObjective = "";
/*     */ 
/*  15 */   private String campStrategy = "";
/*     */ 
/*  17 */   private int deptId = 0;
/*     */ 
/*  19 */   private String campsegName = "";
/*     */ 
/*  21 */   private short campsegNo = 0;
/*     */ 
/*  23 */   private String startDate = "";
/*     */ 
/*  25 */   private String endDate = "";
/*     */ 
/*  27 */   private String cityId = "";
/*     */ 
/*  29 */   private int targetUserNums = 0;
/*     */ 
/*  31 */   private String approveAdv = "";
/*     */ 
/*  33 */   private String createUserid = "";
/*     */ 
/*  35 */   private String approveUserId = "";
/*     */ 
/*  37 */   private int contactNums = 0;
/*     */   private String extendCustN;
/*  41 */   private String resourceName = "";
/*     */   private short campStatId;
/*     */   private short campStatus;
/*     */   private Double[] custNums;
/*     */   private String[] rptScore;
/*  51 */   private String changeEndDate = "";
/*     */ 
/*  53 */   private String changeStartDate = "";
/*     */ 
/*  55 */   private String[] channelCampContent = { "aaa", "aaa", "aaa", "aaa", "aaa", "aaa", "aaa", "aaa", "aaa", "aaa" };
/*     */ 
/*  58 */   private String campStartDate = "";
/*     */ 
/*  61 */   private String campEndDate = "";
/*     */ 
/*  64 */   private String campDesc = "";
/*     */ 
/*  67 */   private String campPri = "";
/*     */ 
/*  70 */   private String campDrv = "";
/*     */ 
/*  73 */   private String campsegDesc = "";
/*     */ 
/*  76 */   int campsegMaxuser = 0;
/*     */ 
/*  79 */   int campsegContrastUsers = 0;
/*     */ 
/*  81 */   String publicizeId = "";
/*     */   private String adviceFlag;
/*     */   private String sponorUserId;
/*     */   private String campId;
/*     */   private String campsegId;
/*     */   private String flowId;
/*     */   private String filterRuleId;
/*     */   private String createdPhaseId;
/*     */   private String usersegId;
/*     */   private short approveResult;
/*     */   private short approveReceiveNums;
/*     */   private short seq;
/*     */   private String resourceId;
/*     */   private String confirmUserid;
/*     */   private String confirmId;
/*     */   private String usersegContent;
/*     */   private String modifiedFlag;
/*     */   private String modifiedFlag1;
/*     */   private Integer campsegMaxUsers;
/* 120 */   private FormFile[] files = { this.file1, this.file2, this.file3, this.file4, this.file5 };
/*     */ 
/* 122 */   private String[] fileDescs = { this.fileDesc1, this.fileDesc2, this.fileDesc3, this.fileDesc4, this.fileDesc5 };
/*     */   private String fileDesc1;
/*     */   private FormFile file1;
/*     */   private String fileDesc2;
/*     */   private FormFile file2;
/*     */   private String fileDesc3;
/*     */   private FormFile file3;
/*     */   private String fileDesc4;
/*     */   private FormFile file4;
/*     */   private String fileDesc5;
/*     */   private FormFile file5;
/*     */   private String delAttachIds;
/*     */   private String approveFlag;
/*     */   private String approveFlowid;
/*     */   private Double guessTotalCost;
/*     */   private Double guessTotalCustNum;
/*     */   private String[] channelType;
/*     */   private String campCityName;
/*     */   private String channelTypeName;
/*     */   private String campCity;
/*     */   private Short campType;
/*     */   private String publicizeCombId;
/*     */   private short confirmFlag;
/*     */   private String channelSendTypeId;
/*     */   private Short existVipCustFlag;
/*     */   private String existVipCust;
/*     */   private String rptScoreN;
/* 185 */   private String campTempletId = "";
/*     */ 
/* 187 */   public int ruleType = 0;
/*     */   private String channelCampCont;
/*     */   private String userSrvDesc;
/*     */   private String channeltypeId;
/*     */   private String channelId;
/*     */   private String channeltypeAndId;
/*     */   private String executeUser;
/*     */   private String serviceType;
/*     */   private String hodCcoFlag;
/*     */   private String subCampDrvId;
/*     */ 
/*     */   public String getServiceType()
/*     */   {
/* 208 */     return this.serviceType;
/*     */   }
/*     */ 
/*     */   public void setServiceType(String serviceType) {
/* 212 */     this.serviceType = serviceType;
/*     */   }
/*     */ 
/*     */   public String getHodCcoFlag() {
/* 216 */     return this.hodCcoFlag;
/*     */   }
/*     */ 
/*     */   public void setHodCcoFlag(String hodCcoFlag) {
/* 220 */     this.hodCcoFlag = hodCcoFlag;
/*     */   }
/*     */ 
/*     */   public String getSubCampDrvId() {
/* 224 */     return this.subCampDrvId;
/*     */   }
/*     */ 
/*     */   public void setSubCampDrvId(String subCampDrvId) {
/* 228 */     this.subCampDrvId = subCampDrvId;
/*     */   }
/*     */ 
/*     */   public String getChannelId()
/*     */   {
/* 236 */     return this.channelId;
/*     */   }
/*     */ 
/*     */   public void setChannelId(String channelId)
/*     */   {
/* 243 */     this.channelId = channelId;
/*     */   }
/*     */ 
/*     */   public String getChanneltypeId()
/*     */   {
/* 250 */     return this.channeltypeId;
/*     */   }
/*     */ 
/*     */   public String getUserSrvDesc() {
/* 254 */     return this.userSrvDesc;
/*     */   }
/*     */ 
/*     */   public void setUserSrvDesc(String userSrvDesc) {
/* 258 */     this.userSrvDesc = userSrvDesc;
/*     */   }
/*     */ 
/*     */   public void setChanneltypeId(String channeltypeId)
/*     */   {
/* 265 */     this.channeltypeId = channeltypeId;
/*     */   }
/*     */ 
/*     */   public String getDelAttachIds() {
/* 269 */     return this.delAttachIds;
/*     */   }
/*     */ 
/*     */   public String getExistVipCust() {
/* 273 */     return this.existVipCust;
/*     */   }
/*     */ 
/*     */   public String getChannelSendTypeId() {
/* 277 */     return this.channelSendTypeId;
/*     */   }
/*     */ 
/*     */   public void setChannelSendTypeId(String channelSendTypeId) {
/* 281 */     this.channelSendTypeId = channelSendTypeId;
/*     */   }
/*     */ 
/*     */   public void setExistVipCust(String existVipCust) {
/* 285 */     this.existVipCust = existVipCust;
/*     */   }
/*     */ 
/*     */   public void setDelAttachIds(String delAttachIds) {
/* 289 */     this.delAttachIds = delAttachIds;
/*     */   }
/*     */ 
/*     */   public FormFile getFile1() {
/* 293 */     return this.file1;
/*     */   }
/*     */ 
/*     */   public void setFile1(FormFile file1) {
/* 297 */     this.file1 = file1;
/* 298 */     this.files[0] = file1;
/*     */   }
/*     */ 
/*     */   public FormFile getFile2() {
/* 302 */     return this.file2;
/*     */   }
/*     */ 
/*     */   public void setFile2(FormFile file2) {
/* 306 */     this.file2 = file2;
/* 307 */     this.files[1] = file2;
/*     */   }
/*     */ 
/*     */   public FormFile getFile3() {
/* 311 */     return this.file3;
/*     */   }
/*     */ 
/*     */   public void setFile3(FormFile file3) {
/* 315 */     this.file3 = file3;
/* 316 */     this.files[2] = file3;
/*     */   }
/*     */ 
/*     */   public FormFile getFile4() {
/* 320 */     return this.file4;
/*     */   }
/*     */ 
/*     */   public void setFile4(FormFile file4) {
/* 324 */     this.file4 = file4;
/* 325 */     this.files[3] = file4;
/*     */   }
/*     */ 
/*     */   public FormFile getFile5() {
/* 329 */     return this.file5;
/*     */   }
/*     */ 
/*     */   public void setFile5(FormFile file5)
/*     */   {
/* 334 */     this.file5 = file5;
/* 335 */     this.files[4] = file5;
/*     */   }
/*     */ 
/*     */   public String getFileDesc1() {
/* 339 */     return this.fileDesc1;
/*     */   }
/*     */ 
/*     */   public void setFileDesc1(String fileDesc1) {
/* 343 */     this.fileDesc1 = fileDesc1;
/* 344 */     this.fileDescs[0] = fileDesc1;
/*     */   }
/*     */ 
/*     */   public String getFileDesc2() {
/* 348 */     return this.fileDesc2;
/*     */   }
/*     */ 
/*     */   public void setFileDesc2(String fileDesc2) {
/* 352 */     this.fileDesc2 = fileDesc2;
/* 353 */     this.fileDescs[1] = fileDesc2;
/*     */   }
/*     */ 
/*     */   public String getFileDesc3() {
/* 357 */     return this.fileDesc3;
/*     */   }
/*     */ 
/*     */   public void setFileDesc3(String fileDesc3) {
/* 361 */     this.fileDesc3 = fileDesc3;
/* 362 */     this.fileDescs[2] = fileDesc3;
/*     */   }
/*     */ 
/*     */   public String getFileDesc4() {
/* 366 */     return this.fileDesc4;
/*     */   }
/*     */ 
/*     */   public void setFileDesc4(String fileDesc4) {
/* 370 */     this.fileDesc4 = fileDesc4;
/* 371 */     this.fileDescs[3] = fileDesc4;
/*     */   }
/*     */ 
/*     */   public String getFileDesc5() {
/* 375 */     return this.fileDesc5;
/*     */   }
/*     */ 
/*     */   public void setFileDesc5(String fileDesc5) {
/* 379 */     this.fileDesc5 = fileDesc5;
/* 380 */     this.fileDescs[4] = fileDesc5;
/*     */   }
/*     */ 
/*     */   public String[] getFileDescs() {
/* 384 */     return this.fileDescs;
/*     */   }
/*     */ 
/*     */   public void setFileDescs(String[] fileDescs) {
/* 388 */     this.fileDescs = fileDescs;
/*     */   }
/*     */ 
/*     */   public FormFile[] getFiles() {
/* 392 */     return this.files;
/*     */   }
/*     */ 
/*     */   public void setFiles(FormFile[] files) {
/* 396 */     this.files = files;
/*     */   }
/*     */ 
/*     */   public String getApproveAdv() {
/* 400 */     return this.approveAdv;
/*     */   }
/*     */ 
/*     */   public void setApproveAdv(String approveAdv) {
/* 404 */     this.approveAdv = approveAdv;
/*     */   }
/*     */ 
/*     */   public String getAttachmentUrls() {
/* 408 */     return this.attachmentUrls;
/*     */   }
/*     */ 
/*     */   public void setAttachmentUrls(String attachmentUrls) {
/* 412 */     this.attachmentUrls = attachmentUrls;
/*     */   }
/*     */ 
/*     */   public short getCampDrvId() {
/* 416 */     return this.campDrvId;
/*     */   }
/*     */ 
/*     */   public void setCampDrvId(short campDrvId) {
/* 420 */     this.campDrvId = campDrvId;
/*     */   }
/*     */ 
/*     */   public String getCampName() {
/* 424 */     return this.campName;
/*     */   }
/*     */ 
/*     */   public void setCampName(String campName) {
/* 428 */     this.campName = campName;
/*     */   }
/*     */ 
/*     */   public String getCampObjective() {
/* 432 */     return this.campObjective;
/*     */   }
/*     */ 
/*     */   public void setCampObjective(String campObjective) {
/* 436 */     this.campObjective = campObjective;
/*     */   }
/*     */ 
/*     */   public String getCampsegName() {
/* 440 */     return this.campsegName;
/*     */   }
/*     */ 
/*     */   public void setCampsegName(String campsegName) {
/* 444 */     this.campsegName = campsegName;
/*     */   }
/*     */ 
/*     */   public short getCampsegNo() {
/* 448 */     return this.campsegNo;
/*     */   }
/*     */ 
/*     */   public void setCampsegNo(short campsegNo) {
/* 452 */     this.campsegNo = campsegNo;
/*     */   }
/*     */ 
/*     */   public String getCampStrategy() {
/* 456 */     return this.campStrategy;
/*     */   }
/*     */ 
/*     */   public void setCampStrategy(String campStrategy) {
/* 460 */     this.campStrategy = campStrategy;
/*     */   }
/*     */ 
/*     */   public String getCityId() {
/* 464 */     return this.cityId;
/*     */   }
/*     */ 
/*     */   public void setCityId(String cityId) {
/* 468 */     this.cityId = cityId;
/*     */   }
/*     */ 
/*     */   public int getDeptId() {
/* 472 */     return this.deptId;
/*     */   }
/*     */ 
/*     */   public void setDeptId(int deptId) {
/* 476 */     this.deptId = deptId;
/*     */   }
/*     */ 
/*     */   public String getEndDate() {
/* 480 */     return this.endDate;
/*     */   }
/*     */ 
/*     */   public void setEndDate(String endDate) {
/* 484 */     this.endDate = endDate;
/*     */   }
/*     */ 
/*     */   public String getStartDate() {
/* 488 */     return this.startDate;
/*     */   }
/*     */ 
/*     */   public void setStartDate(String startDate) {
/* 492 */     this.startDate = startDate;
/*     */   }
/*     */ 
/*     */   public int getTargetUserNums() {
/* 496 */     return this.targetUserNums;
/*     */   }
/*     */ 
/*     */   public void setTargetUserNums(int targetUserNums) {
/* 500 */     this.targetUserNums = targetUserNums;
/*     */   }
/*     */ 
/*     */   public String getCampId() {
/* 504 */     return this.campId;
/*     */   }
/*     */ 
/*     */   public void setCampId(String campId)
/*     */   {
/* 509 */     this.campId = campId;
/*     */   }
/*     */ 
/*     */   public String getCampsegId()
/*     */   {
/* 514 */     return this.campsegId;
/*     */   }
/*     */ 
/*     */   public void setCampsegId(String campsegId)
/*     */   {
/* 519 */     this.campsegId = campsegId;
/*     */   }
/*     */ 
/*     */   public String getFlowId() {
/* 523 */     return this.flowId;
/*     */   }
/*     */ 
/*     */   public void setFlowId(String flowId) {
/* 527 */     this.flowId = flowId;
/*     */   }
/*     */ 
/*     */   public String getCreateUserid() {
/* 531 */     return this.createUserid;
/*     */   }
/*     */ 
/*     */   public void setCreateUserid(String createUserid) {
/* 535 */     this.createUserid = createUserid;
/*     */   }
/*     */ 
/*     */   public String getCreatedPhaseId() {
/* 539 */     return this.createdPhaseId;
/*     */   }
/*     */ 
/*     */   public void setCreatedPhaseId(String createdPhaseId) {
/* 543 */     this.createdPhaseId = createdPhaseId;
/*     */   }
/*     */ 
/*     */   public String getFilterRuleId() {
/* 547 */     return this.filterRuleId;
/*     */   }
/*     */ 
/*     */   public void setFilterRuleId(String filterRuleId) {
/* 551 */     this.filterRuleId = filterRuleId;
/*     */   }
/*     */ 
/*     */   public String getApproveUserId() {
/* 555 */     return this.approveUserId;
/*     */   }
/*     */ 
/*     */   public void setApproveUserId(String approveUserId) {
/* 559 */     this.approveUserId = approveUserId;
/*     */   }
/*     */ 
/*     */   public String getUsersegId() {
/* 563 */     return this.usersegId;
/*     */   }
/*     */ 
/*     */   public void setUsersegId(String usersegId) {
/* 567 */     this.usersegId = usersegId;
/*     */   }
/*     */ 
/*     */   public short getApproveResult() {
/* 571 */     return this.approveResult;
/*     */   }
/*     */ 
/*     */   public void setApproveResult(short approveResult) {
/* 575 */     this.approveResult = approveResult;
/*     */   }
/*     */ 
/*     */   public short getApproveReceiveNums() {
/* 579 */     return this.approveReceiveNums;
/*     */   }
/*     */ 
/*     */   public void setApproveReceiveNums(short approveReceiveNums) {
/* 583 */     this.approveReceiveNums = approveReceiveNums;
/*     */   }
/*     */ 
/*     */   public String getCampEndDate() {
/* 587 */     return this.campEndDate;
/*     */   }
/*     */ 
/*     */   public void setCampEndDate(String campEndDate) {
/* 591 */     this.campEndDate = campEndDate;
/*     */   }
/*     */ 
/*     */   public String getCampStartDate() {
/* 595 */     return this.campStartDate;
/*     */   }
/*     */ 
/*     */   public void setCampStartDate(String campStartDate) {
/* 599 */     this.campStartDate = campStartDate;
/*     */   }
/*     */ 
/*     */   public String getCampDesc() {
/* 603 */     return this.campDesc;
/*     */   }
/*     */ 
/*     */   public void setCampDesc(String campDesc) {
/* 607 */     this.campDesc = campDesc;
/*     */   }
/*     */ 
/*     */   public String getCampDrv() {
/* 611 */     return this.campDrv;
/*     */   }
/*     */ 
/*     */   public void setCampDrv(String campDrv) {
/* 615 */     this.campDrv = campDrv;
/*     */   }
/*     */ 
/*     */   public String getCampPri() {
/* 619 */     return this.campPri;
/*     */   }
/*     */ 
/*     */   public void setCampPri(String campPri) {
/* 623 */     this.campPri = campPri;
/*     */   }
/*     */ 
/*     */   public int getCampsegContrastUsers() {
/* 627 */     return this.campsegContrastUsers;
/*     */   }
/*     */ 
/*     */   public void setCampsegContrastUsers(int campsegContrastUsers) {
/* 631 */     this.campsegContrastUsers = campsegContrastUsers;
/*     */   }
/*     */ 
/*     */   public String getCampsegDesc() {
/* 635 */     return this.campsegDesc;
/*     */   }
/*     */ 
/*     */   public void setCampsegDesc(String campsegDesc) {
/* 639 */     this.campsegDesc = campsegDesc;
/*     */   }
/*     */ 
/*     */   public int getCampsegMaxuser() {
/* 643 */     return this.campsegMaxuser;
/*     */   }
/*     */ 
/*     */   public void setCampsegMaxuser(int campsegMaxuser) {
/* 647 */     this.campsegMaxuser = campsegMaxuser;
/*     */   }
/*     */ 
/*     */   public int getContactNums() {
/* 651 */     return this.contactNums;
/*     */   }
/*     */ 
/*     */   public void setContactNums(int contactNums) {
/* 655 */     this.contactNums = contactNums;
/*     */   }
/*     */ 
/*     */   public String getPublicizeId() {
/* 659 */     return this.publicizeId;
/*     */   }
/*     */ 
/*     */   public void setPublicizeId(String publicizeId) {
/* 663 */     this.publicizeId = publicizeId;
/*     */   }
/*     */ 
/*     */   public String getAdviceFlag() {
/* 667 */     return this.adviceFlag;
/*     */   }
/*     */ 
/*     */   public void setAdviceFlag(String adviceFlag) {
/* 671 */     this.adviceFlag = adviceFlag;
/*     */   }
/*     */ 
/*     */   public String getSponorUserId() {
/* 675 */     return this.sponorUserId;
/*     */   }
/*     */ 
/*     */   public void setSponorUserId(String sponorUserId) {
/* 679 */     this.sponorUserId = sponorUserId;
/*     */   }
/*     */ 
/*     */   public String getConfirmId() {
/* 683 */     return this.confirmId;
/*     */   }
/*     */ 
/*     */   public void setConfirmId(String confirmId) {
/* 687 */     this.confirmId = confirmId;
/*     */   }
/*     */ 
/*     */   public String getConfirmUserid() {
/* 691 */     return this.confirmUserid;
/*     */   }
/*     */ 
/*     */   public void setConfirmUserid(String confirmUserid) {
/* 695 */     this.confirmUserid = confirmUserid;
/*     */   }
/*     */ 
/*     */   public String getResourceId() {
/* 699 */     return this.resourceId;
/*     */   }
/*     */ 
/*     */   public void setResourceId(String resourceId) {
/* 703 */     this.resourceId = resourceId;
/*     */   }
/*     */ 
/*     */   public String getUsersegContent() {
/* 707 */     return this.usersegContent;
/*     */   }
/*     */ 
/*     */   public void setUsersegContent(String usersegContent) {
/* 711 */     this.usersegContent = usersegContent;
/*     */   }
/*     */ 
/*     */   public String getModifiedFlag() {
/* 715 */     return this.modifiedFlag;
/*     */   }
/*     */ 
/*     */   public void setModifiedFlag(String modifiedFlag) {
/* 719 */     this.modifiedFlag = modifiedFlag;
/*     */   }
/*     */ 
/*     */   public String getModifiedFlag1() {
/* 723 */     return this.modifiedFlag1;
/*     */   }
/*     */ 
/*     */   public void setModifiedFlag1(String modifiedFlag1) {
/* 727 */     this.modifiedFlag1 = modifiedFlag1;
/*     */   }
/*     */ 
/*     */   public Integer getCampsegMaxUsers() {
/* 731 */     return this.campsegMaxUsers;
/*     */   }
/*     */ 
/*     */   public void setCampsegMaxUsers(Integer campsegMaxUsers) {
/* 735 */     this.campsegMaxUsers = campsegMaxUsers;
/*     */   }
/*     */ 
/*     */   public String getApproveFlag() {
/* 739 */     return this.approveFlag;
/*     */   }
/*     */ 
/*     */   public void setApproveFlag(String approveFlag) {
/* 743 */     this.approveFlag = approveFlag;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowid() {
/* 747 */     return this.approveFlowid;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowid(String approveFlowid) {
/* 751 */     this.approveFlowid = approveFlowid;
/*     */   }
/*     */ 
/*     */   public Double getGuessTotalCost() {
/* 755 */     return this.guessTotalCost;
/*     */   }
/*     */ 
/*     */   public void setGuessTotalCost(Double guessTotalCost) {
/* 759 */     this.guessTotalCost = guessTotalCost;
/*     */   }
/*     */ 
/*     */   public Double getGuessTotalCustNum() {
/* 763 */     return this.guessTotalCustNum;
/*     */   }
/*     */ 
/*     */   public void setGuessTotalCustNum(Double guessTotalCustNum) {
/* 767 */     this.guessTotalCustNum = guessTotalCustNum;
/*     */   }
/*     */ 
/*     */   public String[] getChannelType() {
/* 771 */     return this.channelType;
/*     */   }
/*     */ 
/*     */   public void setChannelType(String[] channelType)
/*     */   {
/* 779 */     this.channelType = channelType;
/*     */   }
/*     */ 
/*     */   public String getCampCityName() {
/* 783 */     return this.campCityName;
/*     */   }
/*     */ 
/*     */   public void setCampCityName(String campCityName) {
/* 787 */     this.campCityName = campCityName;
/*     */   }
/*     */ 
/*     */   public String getCampCity() {
/* 791 */     return this.campCity;
/*     */   }
/*     */ 
/*     */   public void setCampCity(String campCity) {
/* 795 */     this.campCity = campCity;
/*     */   }
/*     */ 
/*     */   public Short getCampType() {
/* 799 */     return this.campType;
/*     */   }
/*     */ 
/*     */   public void setCampType(Short campType) {
/* 803 */     this.campType = campType;
/*     */   }
/*     */ 
/*     */   public String getPublicizeCombId()
/*     */   {
/* 808 */     return this.publicizeCombId;
/*     */   }
/*     */ 
/*     */   public void setPublicizeCombId(String publicizeCombId)
/*     */   {
/* 813 */     this.publicizeCombId = publicizeCombId;
/*     */   }
/*     */ 
/*     */   public String getChannelTypeName()
/*     */   {
/* 820 */     return this.channelTypeName;
/*     */   }
/*     */ 
/*     */   public void setChannelTypeName(String channelTypeName)
/*     */   {
/* 828 */     this.channelTypeName = channelTypeName;
/*     */   }
/*     */ 
/*     */   public short getCampStatId() {
/* 832 */     return this.campStatId;
/*     */   }
/*     */ 
/*     */   public void setCampStatId(short campStatId) {
/* 836 */     this.campStatId = campStatId;
/*     */   }
/*     */ 
/*     */   public short getConfirmFlag() {
/* 840 */     return this.confirmFlag;
/*     */   }
/*     */ 
/*     */   public void setConfirmFlag(short confirmFlag) {
/* 844 */     this.confirmFlag = confirmFlag;
/*     */   }
/*     */ 
/*     */   public short getCampStatus() {
/* 848 */     return this.campStatus;
/*     */   }
/*     */ 
/*     */   public void setCampStatus(short campStatus) {
/* 852 */     this.campStatus = campStatus;
/*     */   }
/*     */ 
/*     */   public String getExtendCustN()
/*     */   {
/* 857 */     return this.extendCustN;
/*     */   }
/*     */ 
/*     */   public String getChangeStartDate() {
/* 861 */     return this.changeStartDate;
/*     */   }
/*     */ 
/*     */   public void setChangeStartDate(String changeStartDate) {
/* 865 */     this.changeStartDate = changeStartDate;
/*     */   }
/*     */ 
/*     */   public String getChangeEndDate() {
/* 869 */     return this.changeEndDate;
/*     */   }
/*     */ 
/*     */   public void setChangeEndDate(String changeEndDate) {
/* 873 */     this.changeEndDate = changeEndDate;
/*     */   }
/*     */ 
/*     */   public Short getExistVipCustFlag() {
/* 877 */     return this.existVipCustFlag;
/*     */   }
/*     */ 
/*     */   public void setExistVipCustFlag(Short existVipCustFlag) {
/* 881 */     this.existVipCustFlag = existVipCustFlag;
/*     */   }
/*     */ 
/*     */   public void setExtendCustN(String extendCustN) {
/* 885 */     this.extendCustN = extendCustN;
/*     */   }
/*     */ 
/*     */   public String[] getChannelCampContent() {
/* 889 */     return this.channelCampContent;
/*     */   }
/*     */ 
/*     */   public void setChannelCampContent(String[] channelCampContent) {
/* 893 */     this.channelCampContent = channelCampContent;
/*     */   }
/*     */ 
/*     */   public String getRptScoreN() {
/* 897 */     return this.rptScoreN;
/*     */   }
/*     */ 
/*     */   public void setRptScoreN(String rptScoreN) {
/* 901 */     this.rptScoreN = rptScoreN;
/*     */   }
/*     */ 
/*     */   public String getCampTempletId() {
/* 905 */     return this.campTempletId;
/*     */   }
/*     */ 
/*     */   public void setCampTempletId(String campTempletId) {
/* 909 */     this.campTempletId = campTempletId;
/*     */   }
/*     */ 
/*     */   public int getRuleType() {
/* 913 */     return this.ruleType;
/*     */   }
/*     */ 
/*     */   public void setRuleType(int ruleType) {
/* 917 */     this.ruleType = ruleType;
/*     */   }
/*     */ 
/*     */   public Double[] getCustNums() {
/* 921 */     return this.custNums;
/*     */   }
/*     */ 
/*     */   public void setCustNums(Double[] custNums) {
/* 925 */     this.custNums = custNums;
/*     */   }
/*     */ 
/*     */   public String[] getRptScore() {
/* 929 */     return this.rptScore;
/*     */   }
/*     */ 
/*     */   public void setRptScore(String[] rptScore) {
/* 933 */     this.rptScore = rptScore;
/*     */   }
/*     */ 
/*     */   public String getResourceName() {
/* 937 */     return this.resourceName;
/*     */   }
/*     */ 
/*     */   public void setResourceName(String resourceName) {
/* 941 */     this.resourceName = resourceName;
/*     */   }
/*     */ 
/*     */   public String getChannelCampCont()
/*     */   {
/* 948 */     return this.channelCampCont;
/*     */   }
/*     */ 
/*     */   public void setChannelCampCont(String channelCampCont)
/*     */   {
/* 955 */     this.channelCampCont = channelCampCont;
/*     */   }
/*     */ 
/*     */   public String getChanneltypeAndId() {
/* 959 */     return this.channeltypeId + "_" + this.channelId;
/*     */   }
/*     */ 
/*     */   public String getExecuteUser() {
/* 963 */     return this.executeUser;
/*     */   }
/*     */ 
/*     */   public void setExecuteUser(String executeUser) {
/* 967 */     this.executeUser = executeUser;
/*     */   }
/*     */ 
/*     */   public short getSeq() {
/* 971 */     return this.seq;
/*     */   }
/*     */ 
/*     */   public void setSeq(short seq) {
/* 975 */     this.seq = seq;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.MpmCampApproveDetailMainForm
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.form;

/*
 * Created on 5:21:24 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MpmCampChannelSearchForm extends SysBaseForm {
	private String campId;

	private String campsegId;

	private String channelId;

	private String channelMgrId;

	private String elchannelId;

	private String channelTypeId;

	private String channelMgrTypeId;

	private String channelElTypeId;

	private String channelName;

	private String contactType;

	public MpmCampChannelSearchForm() {
		super();
		contactType = "-1";
	}

	public String getCampId() {
		return campId;
	}

	public void setCampId(String campId) {
		this.campId = campId;
	}

	public String getCampsegId() {
		return campsegId;
	}

	public void setCampsegId(String campsegId) {
		this.campsegId = campsegId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public String getChannelTypeId() {
		return channelTypeId;
	}

	public void setChannelTypeId(String channelType) {
		this.channelTypeId = channelType;
	}

	public String getContactType() {
		return contactType;
	}

	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	public String getElchannelId() {
		return elchannelId;
	}

	public void setElchannelId(String elchannelId) {
		this.elchannelId = elchannelId;
	}

	public String getChannelElTypeId() {
		return channelElTypeId;
	}

	public void setChannelElTypeId(String channelElTypeId) {
		this.channelElTypeId = channelElTypeId;
	}

	public String getChannelMgrId() {
		return channelMgrId;
	}

	public void setChannelMgrId(String channelMgrId) {
		this.channelMgrId = channelMgrId;
	}

	public String getChannelMgrTypeId() {
		return channelMgrTypeId;
	}

	public void setChannelMgrTypeId(String channelMgrTypeId) {
		this.channelMgrTypeId = channelMgrTypeId;
	}

}

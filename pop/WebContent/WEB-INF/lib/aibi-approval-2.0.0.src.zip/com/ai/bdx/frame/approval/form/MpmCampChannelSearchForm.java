/*     */ package com.ai.bdx.frame.approval.form;
/*     */ 
/*     */ public class MpmCampChannelSearchForm extends SysBaseForm
/*     */ {
/*     */   private String campId;
/*     */   private String campsegId;
/*     */   private String channelId;
/*     */   private String channelMgrId;
/*     */   private String elchannelId;
/*     */   private String channelTypeId;
/*     */   private String channelMgrTypeId;
/*     */   private String channelElTypeId;
/*     */   private String channelName;
/*     */   private String contactType;
/*     */ 
/*     */   public MpmCampChannelSearchForm()
/*     */   {
/*  36 */     this.contactType = "-1";
/*     */   }
/*     */ 
/*     */   public String getCampId() {
/*  40 */     return this.campId;
/*     */   }
/*     */ 
/*     */   public void setCampId(String campId) {
/*  44 */     this.campId = campId;
/*     */   }
/*     */ 
/*     */   public String getCampsegId() {
/*  48 */     return this.campsegId;
/*     */   }
/*     */ 
/*     */   public void setCampsegId(String campsegId) {
/*  52 */     this.campsegId = campsegId;
/*     */   }
/*     */ 
/*     */   public String getChannelId() {
/*  56 */     return this.channelId;
/*     */   }
/*     */ 
/*     */   public void setChannelId(String channelId) {
/*  60 */     this.channelId = channelId;
/*     */   }
/*     */ 
/*     */   public String getChannelName() {
/*  64 */     return this.channelName;
/*     */   }
/*     */ 
/*     */   public void setChannelName(String channelName) {
/*  68 */     this.channelName = channelName;
/*     */   }
/*     */ 
/*     */   public String getChannelTypeId() {
/*  72 */     return this.channelTypeId;
/*     */   }
/*     */ 
/*     */   public void setChannelTypeId(String channelType) {
/*  76 */     this.channelTypeId = channelType;
/*     */   }
/*     */ 
/*     */   public String getContactType() {
/*  80 */     return this.contactType;
/*     */   }
/*     */ 
/*     */   public void setContactType(String contactType) {
/*  84 */     this.contactType = contactType;
/*     */   }
/*     */ 
/*     */   public String getElchannelId() {
/*  88 */     return this.elchannelId;
/*     */   }
/*     */ 
/*     */   public void setElchannelId(String elchannelId) {
/*  92 */     this.elchannelId = elchannelId;
/*     */   }
/*     */ 
/*     */   public String getChannelElTypeId() {
/*  96 */     return this.channelElTypeId;
/*     */   }
/*     */ 
/*     */   public void setChannelElTypeId(String channelElTypeId) {
/* 100 */     this.channelElTypeId = channelElTypeId;
/*     */   }
/*     */ 
/*     */   public String getChannelMgrId() {
/* 104 */     return this.channelMgrId;
/*     */   }
/*     */ 
/*     */   public void setChannelMgrId(String channelMgrId) {
/* 108 */     this.channelMgrId = channelMgrId;
/*     */   }
/*     */ 
/*     */   public String getChannelMgrTypeId() {
/* 112 */     return this.channelMgrTypeId;
/*     */   }
/*     */ 
/*     */   public void setChannelMgrTypeId(String channelMgrTypeId) {
/* 116 */     this.channelMgrTypeId = channelMgrTypeId;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.MpmCampChannelSearchForm
 * JD-Core Version:    0.6.2
 */
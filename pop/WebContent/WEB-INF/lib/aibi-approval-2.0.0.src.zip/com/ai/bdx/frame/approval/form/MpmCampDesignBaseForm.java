/*     */ package com.ai.bdx.frame.approval.form;
/*     */ 
/*     */ public class MpmCampDesignBaseForm extends SysBaseForm
/*     */ {
/*     */   protected String campId;
/*     */   protected String flowId;
/*     */   protected String campsegId;
/*     */   protected String campsegName;
/*     */   protected Short stepId;
/*     */   protected String canModify;
/*     */   protected String saveTempletToCurrCampseg;
/*     */   protected String stepPerformFlag;
/*     */   protected short campDrvId;
/*     */   protected Short campType;
/*     */   protected String toBeginDate;
/*     */   protected String toEndDate;
/*     */   protected String preStepId;
/*     */   protected String nextStepId;
/*     */   protected String custGroupId;
/*     */   protected Short custGroupType;
/*     */ 
/*     */   public String getCampId()
/*     */   {
/*  47 */     return this.campId;
/*     */   }
/*     */ 
/*     */   public void setCampId(String campId) {
/*  51 */     this.campId = campId;
/*     */   }
/*     */ 
/*     */   public String getCampsegId() {
/*  55 */     return this.campsegId;
/*     */   }
/*     */ 
/*     */   public void setCampsegId(String campsegId) {
/*  59 */     this.campsegId = campsegId;
/*     */   }
/*     */ 
/*     */   public Short getStepId() {
/*  63 */     return this.stepId;
/*     */   }
/*     */ 
/*     */   public void setStepId(Short stepId) {
/*  67 */     this.stepId = stepId;
/*     */   }
/*     */ 
/*     */   public String getFlowId() {
/*  71 */     return this.flowId;
/*     */   }
/*     */ 
/*     */   public void setFlowId(String flowId) {
/*  75 */     this.flowId = flowId;
/*     */   }
/*     */ 
/*     */   public String getCanModify() {
/*  79 */     return this.canModify;
/*     */   }
/*     */ 
/*     */   public void setCanModify(String canModify) {
/*  83 */     this.canModify = canModify;
/*     */   }
/*     */ 
/*     */   public String getCampsegName() {
/*  87 */     return this.campsegName;
/*     */   }
/*     */ 
/*     */   public void setCampsegName(String campsegName) {
/*  91 */     this.campsegName = campsegName;
/*     */   }
/*     */ 
/*     */   public String getToBeginDate() {
/*  95 */     return this.toBeginDate;
/*     */   }
/*     */ 
/*     */   public void setToBeginDate(String toBeginDate) {
/*  99 */     this.toBeginDate = toBeginDate;
/*     */   }
/*     */ 
/*     */   public String getToEndDate() {
/* 103 */     return this.toEndDate;
/*     */   }
/*     */ 
/*     */   public void setToEndDate(String toEndDate) {
/* 107 */     this.toEndDate = toEndDate;
/*     */   }
/*     */ 
/*     */   public String getSaveTempletToCurrCampseg() {
/* 111 */     return this.saveTempletToCurrCampseg;
/*     */   }
/*     */ 
/*     */   public void setSaveTempletToCurrCampseg(String saveTempletToCurrCampseg) {
/* 115 */     this.saveTempletToCurrCampseg = saveTempletToCurrCampseg;
/*     */   }
/*     */ 
/*     */   public String getStepPerformFlag() {
/* 119 */     return this.stepPerformFlag;
/*     */   }
/*     */ 
/*     */   public void setStepPerformFlag(String stepPerformFlag) {
/* 123 */     this.stepPerformFlag = stepPerformFlag;
/*     */   }
/*     */ 
/*     */   public short getCampDrvId() {
/* 127 */     return this.campDrvId;
/*     */   }
/*     */ 
/*     */   public void setCampDrvId(short campDrvId) {
/* 131 */     this.campDrvId = campDrvId;
/*     */   }
/*     */ 
/*     */   public Short getCampType() {
/* 135 */     return this.campType;
/*     */   }
/*     */ 
/*     */   public void setCampType(Short campType) {
/* 139 */     this.campType = campType;
/*     */   }
/*     */ 
/*     */   public String getNextStepId() {
/* 143 */     return this.nextStepId;
/*     */   }
/*     */ 
/*     */   public void setNextStepId(String nextStepId) {
/* 147 */     this.nextStepId = nextStepId;
/*     */   }
/*     */ 
/*     */   public String getPreStepId() {
/* 151 */     return this.preStepId;
/*     */   }
/*     */ 
/*     */   public void setPreStepId(String preStepId) {
/* 155 */     this.preStepId = preStepId;
/*     */   }
/*     */ 
/*     */   public String getCustGroupId() {
/* 159 */     return this.custGroupId;
/*     */   }
/*     */ 
/*     */   public void setCustGroupId(String custGroupId) {
/* 163 */     this.custGroupId = custGroupId;
/*     */   }
/*     */ 
/*     */   public Short getCustGroupType() {
/* 167 */     return this.custGroupType;
/*     */   }
/*     */ 
/*     */   public void setCustGroupType(Short custGroupType) {
/* 171 */     this.custGroupType = custGroupType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.MpmCampDesignBaseForm
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.approval.form;
/*     */ 
/*     */ public class MpmCampsegApproveForm extends MpmCampDesignBaseForm
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  10 */   private String createUserid = "";
/*     */   private String publicizeCombId;
/*  14 */   private String[] campsegIdList = new String[0];
/*     */   private short approveResult;
/*     */   private short approveReceiveNums;
/*     */   private short seq;
/*     */   private short campsegStatId;
/*     */   private String approveAdv;
/*     */   private String modifiedFlag;
/*     */   private String modifiedFlag1;
/*     */   private Short confirmFlag;
/*     */   private String showButton;
/*     */   private short campStatus;
/*     */   private String resourceName;
/*     */   private int extendCustNum;
/*  40 */   private Double[] custNum = { Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D), Double.valueOf(-1.0D) };
/*     */ 
/*  43 */   private int[] rptScore = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*     */ 
/*     */   public String getCreateUserid() {
/*  46 */     return this.createUserid;
/*     */   }
/*     */ 
/*     */   public void setCreateUserid(String createUserid) {
/*  50 */     this.createUserid = createUserid;
/*     */   }
/*     */ 
/*     */   public String getPublicizeCombId()
/*     */   {
/*  55 */     return this.publicizeCombId;
/*     */   }
/*     */ 
/*     */   public void setPublicizeCombId(String publicizeCombId)
/*     */   {
/*  60 */     this.publicizeCombId = publicizeCombId;
/*     */   }
/*     */ 
/*     */   public String[] getCampsegIdList()
/*     */   {
/*  65 */     return this.campsegIdList;
/*     */   }
/*     */ 
/*     */   public void setCampsegIdList(String[] campsegIdList) {
/*  69 */     this.campsegIdList = campsegIdList;
/*     */   }
/*     */ 
/*     */   public short getApproveReceiveNums()
/*     */   {
/*  74 */     return this.approveReceiveNums;
/*     */   }
/*     */ 
/*     */   public void setApproveReceiveNums(short approveReceiveNums) {
/*  78 */     this.approveReceiveNums = approveReceiveNums;
/*     */   }
/*     */ 
/*     */   public short getApproveResult() {
/*  82 */     return this.approveResult;
/*     */   }
/*     */ 
/*     */   public void setApproveResult(short approveResult) {
/*  86 */     this.approveResult = approveResult;
/*     */   }
/*     */ 
/*     */   public String getApproveAdv() {
/*  90 */     return this.approveAdv;
/*     */   }
/*     */ 
/*     */   public void setApproveAdv(String approveAdv) {
/*  94 */     this.approveAdv = approveAdv;
/*     */   }
/*     */ 
/*     */   public String getModifiedFlag1() {
/*  98 */     return this.modifiedFlag1;
/*     */   }
/*     */ 
/*     */   public void setModifiedFlag1(String modifiedFlag1) {
/* 102 */     this.modifiedFlag1 = modifiedFlag1;
/*     */   }
/*     */ 
/*     */   public String getModifiedFlag() {
/* 106 */     return this.modifiedFlag;
/*     */   }
/*     */ 
/*     */   public void setModifiedFlag(String modifiedFlag) {
/* 110 */     this.modifiedFlag = modifiedFlag;
/*     */   }
/*     */ 
/*     */   public Short getConfirmFlag() {
/* 114 */     return this.confirmFlag;
/*     */   }
/*     */ 
/*     */   public void setConfirmFlag(Short confirmFlag) {
/* 118 */     this.confirmFlag = confirmFlag;
/*     */   }
/*     */ 
/*     */   public short getCampsegStatId() {
/* 122 */     return this.campsegStatId;
/*     */   }
/*     */ 
/*     */   public void setCampsegStatId(short campsegStatId) {
/* 126 */     this.campsegStatId = campsegStatId;
/*     */   }
/*     */ 
/*     */   public String getShowButton() {
/* 130 */     return this.showButton;
/*     */   }
/*     */ 
/*     */   public void setShowButton(String showButton) {
/* 134 */     this.showButton = showButton;
/*     */   }
/*     */ 
/*     */   public short getCampStatus() {
/* 138 */     return this.campStatus;
/*     */   }
/*     */ 
/*     */   public void setCampStatus(short campStatus) {
/* 142 */     this.campStatus = campStatus;
/*     */   }
/*     */ 
/*     */   public int getExtendCustNum() {
/* 146 */     return this.extendCustNum;
/*     */   }
/*     */ 
/*     */   public void setExtendCustNum(int extendCustNum) {
/* 150 */     this.extendCustNum = extendCustNum;
/*     */   }
/*     */ 
/*     */   public Double[] getCustNum() {
/* 154 */     return this.custNum;
/*     */   }
/*     */ 
/*     */   public void setCustNum(Double[] custNum) {
/* 158 */     this.custNum = custNum;
/*     */   }
/*     */ 
/*     */   public int[] getRptScore() {
/* 162 */     return this.rptScore;
/*     */   }
/*     */ 
/*     */   public void setRptScore(int[] rptScore) {
/* 166 */     this.rptScore = rptScore;
/*     */   }
/*     */ 
/*     */   public String getResourceName() {
/* 170 */     return this.resourceName;
/*     */   }
/*     */ 
/*     */   public void setResourceName(String resourceName) {
/* 174 */     this.resourceName = resourceName;
/*     */   }
/*     */ 
/*     */   public short getSeq() {
/* 178 */     return this.seq;
/*     */   }
/*     */ 
/*     */   public void setSeq(short seq) {
/* 182 */     this.seq = seq;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.MpmCampsegApproveForm
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.form;


public class MpmCampsegApproveForm extends MpmCampDesignBaseForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String createUserid = "";

	private String publicizeCombId;

	private String[] campsegIdList = {};

	private short approveResult;

	private short approveReceiveNums;
	
	private short seq;

	private short campsegStatId;

	private String approveAdv;

	private String modifiedFlag;

	private String modifiedFlag1;

	private Short confirmFlag;

	private String showButton;

	private short campStatus;

	private String resourceName;

	private int extendCustNum;

	private Double[] custNum = { -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0,
			-1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, };

	private int[] rptScore = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, };

	public String getCreateUserid() {
		return createUserid;
	}

	public void setCreateUserid(String createUserid) {
		this.createUserid = createUserid;
	}

	public String getPublicizeCombId() {

		return publicizeCombId;
	}

	public void setPublicizeCombId(String publicizeCombId) {

		this.publicizeCombId = publicizeCombId;
	}

	public String[] getCampsegIdList() {

		return campsegIdList;
	}

	public void setCampsegIdList(String[] campsegIdList) {
		this.campsegIdList = campsegIdList;

	}

	public short getApproveReceiveNums() {
		return approveReceiveNums;
	}

	public void setApproveReceiveNums(short approveReceiveNums) {
		this.approveReceiveNums = approveReceiveNums;
	}

	public short getApproveResult() {
		return approveResult;
	}

	public void setApproveResult(short approveResult) {
		this.approveResult = approveResult;
	}

	public String getApproveAdv() {
		return approveAdv;
	}

	public void setApproveAdv(String approveAdv) {
		this.approveAdv = approveAdv;
	}

	public String getModifiedFlag1() {
		return modifiedFlag1;
	}

	public void setModifiedFlag1(String modifiedFlag1) {
		this.modifiedFlag1 = modifiedFlag1;
	}

	public String getModifiedFlag() {
		return modifiedFlag;
	}

	public void setModifiedFlag(String modifiedFlag) {
		this.modifiedFlag = modifiedFlag;
	}

	public Short getConfirmFlag() {
		return confirmFlag;
	}

	public void setConfirmFlag(Short confirmFlag) {
		this.confirmFlag = confirmFlag;
	}

	public short getCampsegStatId() {
		return campsegStatId;
	}

	public void setCampsegStatId(short campsegStatId) {
		this.campsegStatId = campsegStatId;
	}

	public String getShowButton() {
		return showButton;
	}

	public void setShowButton(String showButton) {
		this.showButton = showButton;
	}

	public short getCampStatus() {
		return campStatus;
	}

	public void setCampStatus(short campStatus) {
		this.campStatus = campStatus;
	}

	public int getExtendCustNum() {
		return extendCustNum;
	}

	public void setExtendCustNum(int extendCustNum) {
		this.extendCustNum = extendCustNum;
	}

	public Double[] getCustNum() {
		return custNum;
	}

	public void setCustNum(Double[] custNum) {
		this.custNum = custNum;
	}

	public int[] getRptScore() {
		return rptScore;
	}

	public void setRptScore(int[] rptScore) {
		this.rptScore = rptScore;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public short getSeq() {
		return seq;
	}

	public void setSeq(short seq) {
		this.seq = seq;
	}

}

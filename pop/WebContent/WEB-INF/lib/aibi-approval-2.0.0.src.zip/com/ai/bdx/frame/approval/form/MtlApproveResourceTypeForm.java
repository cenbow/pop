/*    */ package com.ai.bdx.frame.approval.form;
/*    */ 
/*    */ public class MtlApproveResourceTypeForm extends SysBaseForm
/*    */ {
/*    */   private String resourceId;
/*    */   private String resourceName;
/*    */   private String resourceDesc;
/*    */   private String resourceType;
/*    */   private String resName;
/*    */   private String resDesc;
/* 17 */   String action = "";
/*    */ 
/*    */   public String getResourceDesc() {
/* 20 */     return this.resourceDesc;
/*    */   }
/*    */ 
/*    */   public void setResourceDesc(String resourceDesc) {
/* 24 */     this.resourceDesc = resourceDesc;
/*    */   }
/*    */ 
/*    */   public String getResourceId() {
/* 28 */     return this.resourceId;
/*    */   }
/*    */ 
/*    */   public void setResourceId(String resourceId) {
/* 32 */     this.resourceId = resourceId;
/*    */   }
/*    */ 
/*    */   public String getResourceName() {
/* 36 */     return this.resourceName;
/*    */   }
/*    */ 
/*    */   public void setResourceName(String resourceName) {
/* 40 */     this.resourceName = resourceName;
/*    */   }
/*    */ 
/*    */   public String getResourceType() {
/* 44 */     return this.resourceType;
/*    */   }
/*    */ 
/*    */   public void setResourceType(String resourceType) {
/* 48 */     this.resourceType = resourceType;
/*    */   }
/*    */ 
/*    */   public String getResDesc() {
/* 52 */     return this.resDesc;
/*    */   }
/*    */ 
/*    */   public void setResDesc(String resDesc) {
/* 56 */     this.resDesc = resDesc;
/*    */   }
/*    */ 
/*    */   public String getResName() {
/* 60 */     return this.resName;
/*    */   }
/*    */ 
/*    */   public void setResName(String resName) {
/* 64 */     this.resName = resName;
/*    */   }
/*    */ 
/*    */   public String getAction() {
/* 68 */     return this.action;
/*    */   }
/*    */ 
/*    */   public void setAction(String action) {
/* 72 */     this.action = action;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.MtlApproveResourceTypeForm
 * JD-Core Version:    0.6.2
 */
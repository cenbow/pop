package com.ai.bdx.frame.approval.form;


import org.apache.struts.action.ActionForm;

public class SysBaseForm extends ActionForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SysBaseForm() {
	}

	public String getCmd() {
		return cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}

	protected String cmd;
}
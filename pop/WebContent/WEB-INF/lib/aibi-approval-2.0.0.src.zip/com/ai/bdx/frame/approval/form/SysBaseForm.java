/*    */ package com.ai.bdx.frame.approval.form;
/*    */ 
/*    */ import org.apache.struts.action.ActionForm;
/*    */ 
/*    */ public class SysBaseForm extends ActionForm
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected String cmd;
/*    */ 
/*    */   public String getCmd()
/*    */   {
/* 17 */     return this.cmd;
/*    */   }
/*    */ 
/*    */   public void setCmd(String cmd) {
/* 21 */     this.cmd = cmd;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.form.SysBaseForm
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.approval.jms.util;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class SimpleCache
/*     */ {
/*     */   private final Map<String, Object> objects;
/*     */   private final Map<String, Long> expire;
/*     */   private final long defaultExpire;
/*     */   private final ExecutorService threads;
/*  40 */   private String cacheType = "local";
/*     */ 
/*     */   public static SimpleCache getInstance()
/*     */   {
/*  25 */     return SimpleCacheHolder.instance;
/*     */   }
/*     */ 
/*     */   private SimpleCache()
/*     */   {
/*  46 */     this(100L);
/*     */   }
/*     */ 
/*     */   public SimpleCache(long defaultExpire)
/*     */   {
/*  55 */     this.objects = new ConcurrentHashMap();
/*  56 */     this.expire = new ConcurrentHashMap();
/*     */ 
/*  58 */     this.defaultExpire = defaultExpire;
/*     */ 
/*  60 */     this.threads = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 2);
/*     */ 
/*  62 */     Executors.newScheduledThreadPool(2).scheduleWithFixedDelay(removeExpired(), 2L, 5L, TimeUnit.SECONDS);
/*     */   }
/*     */ 
/*     */   private Runnable removeExpired()
/*     */   {
/*  71 */     return new Runnable()
/*     */     {
/*     */       public void run() {
/*  74 */         for (String name : SimpleCache.this.expire.keySet())
/*  75 */           if ((System.currentTimeMillis() > ((Long)SimpleCache.this.expire.get(name)).longValue()) && (((Long)SimpleCache.this.expire.get(name)).longValue() != -1L))
/*  76 */             SimpleCache.this.threads.execute(SimpleCache.this.createRemoveRunnable(name));
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private Runnable createRemoveRunnable(final String name)
/*     */   {
/*  91 */     return new Runnable()
/*     */     {
/*     */       public void run() {
/*  94 */         SimpleCache.this.objects.remove(name);
/*  95 */         SimpleCache.this.expire.remove(name);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public long getExpire()
/*     */   {
/* 106 */     return this.defaultExpire;
/*     */   }
/*     */ 
/*     */   public void put(String name, Object obj)
/*     */   {
/* 116 */     put(name, obj, this.defaultExpire);
/*     */   }
/*     */ 
/*     */   public void put(String name, Object obj, long expireTime)
/*     */   {
/* 127 */     this.objects.put(name, obj);
/* 128 */     this.expire.put(name, Long.valueOf(expireTime != -1L ? System.currentTimeMillis() + expireTime * 1000L : -1L));
/*     */   }
/*     */ 
/*     */   public Object get(String name)
/*     */   {
/* 141 */     Object obj = null;
/* 142 */     Long expireTime = (Long)this.expire.get(name);
/* 143 */     if (expireTime == null)
/* 144 */       return null;
/* 145 */     if ((System.currentTimeMillis() > expireTime.longValue()) && (expireTime.longValue() != -1L)) {
/* 146 */       this.threads.execute(createRemoveRunnable(name));
/* 147 */       return null;
/*     */     }
/* 149 */     obj = this.objects.get(name);
/* 150 */     return obj;
/*     */   }
/*     */ 
/*     */   public <R> R get(String name, Class<R> type)
/*     */   {
/* 163 */     return get(name);
/*     */   }
/*     */ 
/*     */   public void remove(String name) {
/* 167 */     this.objects.remove(name);
/* 168 */     this.expire.remove(name);
/*     */   }
/*     */ 
/*     */   static class SimpleCacheHolder
/*     */   {
/*  21 */     static SimpleCache instance = new SimpleCache(-1L);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.jms.util.SimpleCache
 * JD-Core Version:    0.6.2
 */
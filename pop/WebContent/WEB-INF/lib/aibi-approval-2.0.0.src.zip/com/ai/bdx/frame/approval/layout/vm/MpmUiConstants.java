package com.ai.bdx.frame.approval.layout.vm;

public class MpmUiConstants
{
  public static final String DCP_VALUE_VIEW_SPLIT = "|^|";
  public static final String DCP_VALUE_SPLIT = "|";
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.layout.vm.MpmUiConstants
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.layout.vm;

public class MpmUiConstants {
	public static final String DCP_VALUE_VIEW_SPLIT = "|^|";

	public static final String DCP_VALUE_SPLIT = "|";
}

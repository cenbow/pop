/*    */ package com.ai.bdx.frame.approval.listener;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.util.MpmConfigure;
/*    */ import com.ai.bdx.frame.approval.util.SpringContext;
/*    */ import com.ai.bdx.frame.approval.util.ThreadPool;
/*    */ import com.asiainfo.biframe.manager.context.ContextManager;
/*    */ import com.asiainfo.biframe.servlet.BISpringContextLoader;
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import java.io.File;
/*    */ import java.io.PrintStream;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.quartz.Scheduler;
/*    */ import org.springframework.web.context.ContextLoader;
/*    */ import org.springframework.web.context.ContextLoaderListener;
/*    */ 
/*    */ public class ApCommonListener extends ContextLoaderListener
/*    */ {
/* 23 */   private static Logger log = LogManager.getLogger();
/*    */ 
/* 33 */   private String configFilePath = "aibi_approval";
/* 34 */   private String webInfPath = "/WEB-INF/classes/config";
/*    */ 
/*    */   protected ContextLoader createContextLoader()
/*    */   {
/* 30 */     System.out.println(".....approval's createContextLoader done.....");
/* 31 */     return new BISpringContextLoader();
/*    */   }
/*    */ 
/*    */   public void contextInitialized(ServletContextEvent event)
/*    */   {
/*    */     try
/*    */     {
/* 38 */       ServletContext servletContext = event.getServletContext();
/*    */ 
/* 40 */       SpringContext.init(servletContext);
/* 41 */       String approvalFilePath = servletContext.getRealPath(this.webInfPath + File.separator + this.configFilePath + File.separator + "approval.properties");
/* 42 */       Configure.getInstance().addConfFileName("ASIAINFO_PROPERTIES", approvalFilePath);
/*    */ 
/* 45 */       String is_suite_privalege = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
/* 46 */       if ("false".equalsIgnoreCase(is_suite_privalege)) {
/* 47 */         String privilegeConfFilePath = servletContext.getRealPath("/WEB-INF/classes/config/aibi_privilegeService/privilege.properties");
/* 48 */         Configure.getInstance().addConfFileName("AIBI_PRIVILEGE_PROPERTIES", privilegeConfFilePath);
/*    */       }
/*    */ 
/* 52 */       String provinceConfFilePath = servletContext.getRealPath(this.webInfPath + File.separator + this.configFilePath + File.separator + "{PROVINCE}" + File.separator + "approval.properties");
/* 53 */       MpmConfigure.getInstance().setConfFileName(provinceConfFilePath);
/* 54 */       log.debug("approval component init done.....");
/*    */     } catch (Exception ce) {
/* 56 */       log.error("初始化数据异常：", ce);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent event)
/*    */   {
/*    */     try {
/* 63 */       super.contextDestroyed(event);
/* 64 */       ContextManager context = new ContextManager();
/* 65 */       context.finalizeComponents(event);
/* 66 */       ThreadPool.getInstance().shutdownNow();
/* 67 */       shutdownJob("download_quartzScheduler");
/* 68 */       shutdownJob("logService_schedulerFactory");
/* 69 */       shutdownJob("jobTriggerFactory");
/*    */     } catch (Exception e) {
/* 71 */       log.error("destroy resource error:", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private void shutdownJob(String jobName) {
/*    */     try {
/* 77 */       Scheduler job = (Scheduler)SpringContext.getBean(jobName, Scheduler.class);
/* 78 */       if ((job != null) && (job.isStarted())) {
/* 79 */         job.shutdown();
/* 80 */         Thread.sleep(1000L);
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.listener.ApCommonListener
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.listener;

import java.io.File;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.Scheduler;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.ContextLoaderListener;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.util.MpmConfigure;
import com.ai.bdx.frame.approval.util.SpringContext;
import com.ai.bdx.frame.approval.util.ThreadPool;
import com.asiainfo.biframe.manager.context.ContextManager;
import com.asiainfo.biframe.servlet.BISpringContextLoader;
import com.asiainfo.biframe.utils.config.Configure;

public class ApCommonListener extends ContextLoaderListener {
	private static Logger log = LogManager.getLogger();

	public ApCommonListener() {
	}

	@Override
	protected ContextLoader createContextLoader() {
		System.out.println(".....approval's createContextLoader done.....");
		return new BISpringContextLoader();
	}
    private String  configFilePath="aibi_approval";
    private String  webInfPath="/WEB-INF/classes/config";
	@Override
	public void contextInitialized(ServletContextEvent event) {
		try {
			ServletContext servletContext = event.getServletContext();
			//SpringContext初始化
			SpringContext.init(servletContext);
			String approvalFilePath = servletContext.getRealPath(webInfPath+File.separator+configFilePath+File.separator+"approval.properties");
			Configure.getInstance().addConfFileName(MpmCONST.MCD_PROPERTY_NAME, approvalFilePath);
			
			//是否是WEBOS权限
			String is_suite_privalege=Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
			if ("false".equalsIgnoreCase(is_suite_privalege)) {
				String privilegeConfFilePath = servletContext.getRealPath("/WEB-INF/classes/config/aibi_privilegeService/privilege.properties");
				Configure.getInstance().addConfFileName("AIBI_PRIVILEGE_PROPERTIES", privilegeConfFilePath);
			}
			
            //加载省份配置参数"/WEB-INF/classes/config/aibi_mpm/province/{PROVINCE}/mpm.properties"
		    String provinceConfFilePath = servletContext.getRealPath(webInfPath+File.separator+configFilePath+File.separator+"{PROVINCE}"+File.separator+"approval.properties");
			MpmConfigure.getInstance().setConfFileName(provinceConfFilePath);
			log.debug("approval component init done.....");
		} catch (Exception ce) {
			log.error("初始化数据异常：", ce);
		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent event) {
		try {
			super.contextDestroyed(event);
			ContextManager context = new ContextManager();
			context.finalizeComponents(event);
			ThreadPool.getInstance().shutdownNow();
			this.shutdownJob("download_quartzScheduler");
			this.shutdownJob("logService_schedulerFactory");
			this.shutdownJob("jobTriggerFactory");
		} catch (Exception e) {
			log.error("destroy resource error:", e);
		}
	}

	private void shutdownJob(String jobName) {
		try {
			Scheduler job = SpringContext.getBean(jobName, Scheduler.class);
			if (job != null && job.isStarted()) {
				job.shutdown();
				Thread.sleep(1000);
			}
		} catch (Exception e) {
		}
	}
}
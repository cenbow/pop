package com.ai.bdx.frame.approval.listener;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.asiainfo.biframe.manager.context.ContextManager;
import com.asiainfo.biframe.service.IActivator;

public class ApprovalActivatorImpl implements IActivator {
	private static Logger log = LogManager.getLogger();

	public void start(ContextManager context) throws Exception {
		try {
			/*log.debug(" begin ApprovalActivatorImpl");
			String confFilePath = context.getServletContextEvent().getServletContext()
					.getRealPath("/WEB-INF/classes/config/aibi_approval/approval.properties");
			Configure.getInstance().addConfFileName("AIBI_APPROVAL_PROPERTIES", confFilePath);
			log.debug(" end ApprovalActivatorImpl");*/
		} catch (Exception e) {
			log.error("加载审批组件数据异常：", e);
		}
	}

	public void stop(ContextManager context) throws Exception {
	}
}

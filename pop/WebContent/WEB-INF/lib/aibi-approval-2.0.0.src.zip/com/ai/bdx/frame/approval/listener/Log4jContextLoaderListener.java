/*    */ package com.ai.bdx.frame.approval.listener;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.exception.MpmException;
/*    */ import com.asiainfo.biframe.servlet.SystemCommonListener;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.util.Properties;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.logging.log4j.core.LoggerContext;
/*    */ 
/*    */ public class Log4jContextLoaderListener extends SystemCommonListener
/*    */ {
/* 19 */   private static Logger log = LogManager.getLogger();
/* 20 */   private String configFilePath = "aibi_approval";
/* 21 */   private String webInfPath = "/WEB-INF/classes/config";
/*    */ 
/*    */   public void contextInitialized(ServletContextEvent event) {
/*    */     try { ServletContext servletContext = event.getServletContext();
/*    */ 
/* 26 */       String log4jPath = servletContext.getRealPath(this.webInfPath + File.separator + this.configFilePath + File.separator + "log4j2.xml");
/*    */ 
/* 28 */       System.setProperty("log4j.configurationFile", log4jPath);
/* 29 */       System.setProperty("-DLog4jContextSelector", "org.apache.logging.log4j.core.async.AsyncLoggerContextSelector");
/* 30 */       System.setProperty("log4j.skipJansi", "true");
/* 31 */       LoggerContext context = (LoggerContext)LogManager.getContext(false);
/* 32 */       context.reconfigure();
/* 33 */       String confFilePath1 = servletContext.getRealPath(this.webInfPath + File.separator + this.configFilePath + File.separator + "approval.properties");
/* 34 */       loadProperties(confFilePath1);
/* 35 */       super.contextInitialized(event);
/*    */     } catch (Exception ce)
/*    */     {
/* 38 */       log.error("初始化数据异常：", ce);
/*    */     }
/*    */   }
/*    */ 
/*    */   private void loadProperties(String fileName) {
/*    */     try {
/* 44 */       Properties props = new Properties();
/* 45 */       File fileObj = new File(fileName);
/* 46 */       String absPathStr = fileObj.getAbsolutePath();
/* 47 */       log.debug("Load file:{}", new Object[] { absPathStr });
/* 48 */       if (!fileObj.exists()) {
/* 49 */         throw new Exception("parameter file not found:" + fileName + "\r\nAbsolute Path:" + absPathStr);
/*    */       }
/*    */ 
/* 52 */       FileInputStream fis = new FileInputStream(fileName);
/* 53 */       props.load(fis);
/* 54 */       fis.close();
/* 55 */       System.getProperties().putAll(props);
/*    */     }
/*    */     catch (Exception e) {
/* 58 */       throw new MpmException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.listener.Log4jContextLoaderListener
 * JD-Core Version:    0.6.2
 */
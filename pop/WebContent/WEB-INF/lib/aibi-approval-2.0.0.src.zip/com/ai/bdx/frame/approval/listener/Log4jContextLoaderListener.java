package com.ai.bdx.frame.approval.listener;


import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.asiainfo.biframe.servlet.SystemCommonListener;

public class Log4jContextLoaderListener extends SystemCommonListener {
	private static Logger log = LogManager.getLogger();
	 private String  configFilePath="aibi_approval";
	private String  webInfPath="/WEB-INF/classes/config";
	public void contextInitialized(ServletContextEvent event) {
		try {
			ServletContext servletContext = event.getServletContext();
			//log4j2初始化
			String log4jPath = servletContext.getRealPath(webInfPath+File.separator+configFilePath+File.separator+"log4j2.xml");
			//PropertyConfigurator.configure(log4jPath);
			System.setProperty("log4j.configurationFile", log4jPath);
			System.setProperty("-DLog4jContextSelector","org.apache.logging.log4j.core.async.AsyncLoggerContextSelector");//使用异步日志
			System.setProperty("log4j.skipJansi", "true");
			LoggerContext context = (LoggerContext) LogManager.getContext(false);
			context.reconfigure();
			String confFilePath1 = servletContext.getRealPath(webInfPath+File.separator+configFilePath+File.separator+"approval.properties");
			this.loadProperties(confFilePath1);
			super.contextInitialized(event);
			
		} catch (Exception ce) {
			log.error("初始化数据异常：", ce);
		}
	}

	private void loadProperties(String fileName) {
		try {
			Properties props = new Properties();
			File fileObj = new File(fileName);
			String absPathStr = fileObj.getAbsolutePath();
			log.debug("Load file:{}", absPathStr);
			if (!fileObj.exists()) {
				throw new Exception((new StringBuilder()).append("parameter file not found:").append(fileName)
						.append("\r\nAbsolute Path:").append(absPathStr).toString());
			} else {
				FileInputStream fis = new FileInputStream(fileName);
				props.load(fis);
				fis.close();
				System.getProperties().putAll(props);
			}
		} catch (Exception e) {
			throw new MpmException(e);
		}
	}
}

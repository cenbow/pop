/*     */ package com.ai.bdx.frame.approval.listener;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.base.constants.UserManager;
/*     */ import com.asiainfo.biframe.privilege.base.vo.PrivilegeUserSession;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.Serializable;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionBindingEvent;
/*     */ import javax.servlet.http.HttpSessionBindingListener;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class SessionListener
/*     */   implements HttpSessionBindingListener, Serializable
/*     */ {
/*  29 */   private static Logger log = LogManager.getLogger();
/*     */   private static final long serialVersionUID = -1334939621828913344L;
/*  31 */   private IUser m_User = null;
/*  32 */   private String m_strLoginOAUser = "";
/*  33 */   private String m_strSessionID = null;
/*  34 */   private String m_strClientIP = null;
/*  35 */   private String m_strServerAddress = "";
/*  36 */   private String m_browser_version = "";
/*     */   public static final String LOGOUTTYPE_ZHUDONG = "1";
/*     */   public static final String LOGOUTTYPE_BEIDONG = "2";
/*     */ 
/*     */   public static String getIpAddr(HttpServletRequest request)
/*     */   {
/*  47 */     String ip = request.getHeader("x-forwarded-for");
/*  48 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  49 */       ip = request.getHeader("Proxy-Client-IP");
/*     */     }
/*  51 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  52 */       ip = request.getHeader("WL-Proxy-Client-IP");
/*     */     }
/*  54 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  55 */       ip = request.getRemoteAddr();
/*     */     }
/*  57 */     String[] ips = null;
/*  58 */     if (StringUtil.isNotEmpty(ip)) {
/*  59 */       ips = ip.split(",");
/*  60 */       return ips[0];
/*     */     }
/*  62 */     return ip;
/*     */   }
/*     */ 
/*     */   public static SessionListener login(HttpServletRequest request, String strUserID, String strOaUser)
/*     */     throws Exception
/*     */   {
/*  75 */     SessionListener session = new SessionListener();
/*  76 */     session.m_strClientIP = getIpAddr(request);
/*     */ 
/*  78 */     session.m_strSessionID = request.getSession().getId();
/*  79 */     session.m_strLoginOAUser = strOaUser;
/*  80 */     session.m_browser_version = getBrowserVersion(request.getHeader("user-agent"));
/*  81 */     log.info("[SessionListener] login sessionid=====" + session.m_strSessionID);
/*     */     try {
/*  83 */       session.m_strServerAddress = UserManager.getHostAddress();
/*     */     } catch (Exception exceo) {
/*  85 */       session.m_strServerAddress = "127.0.0.1";
/*     */     }
/*     */ 
/*  88 */     Sqlca sqlca = null;
/*     */     try {
/*  90 */       IUserPrivilegeCommonService userService = (IUserPrivilegeCommonService)SystemServiceLocator.getInstance().getService("userPrivilegeCommonService");
/*     */ 
/*  92 */       session.m_User = userService.getUser(strUserID);
/*     */ 
/*  97 */       if (null != sqlca)
/*  98 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/*  94 */       excep.printStackTrace();
/*  95 */       throw excep;
/*     */     } finally {
/*  97 */       if (null != sqlca) {
/*  98 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 101 */     return session;
/*     */   }
/*     */ 
/*     */   public String getUserID() throws Exception {
/* 105 */     return this.m_User.getUserid();
/*     */   }
/*     */ 
/*     */   public IUser getUser() throws Exception {
/* 109 */     return this.m_User;
/*     */   }
/*     */ 
/*     */   public String getUserName() throws Exception {
/* 113 */     return this.m_User.getUsername();
/*     */   }
/*     */ 
/*     */   public String getUserRoles()
/*     */     throws Exception
/*     */   {
/* 122 */     return this.m_User.getGroupId();
/*     */   }
/*     */ 
/*     */   public void valueBound(HttpSessionBindingEvent event)
/*     */   {
/* 130 */     Sqlca sqlca = null;
/*     */     try {
/* 132 */       sqlca = new Sqlca(new ConnectionEx());
/* 133 */       sqlca.setAutoCommit(false);
/*     */ 
/* 149 */       String oaUserId = "";
/* 150 */       PrivilegeUserSession sessionUser = new PrivilegeUserSession();
/* 151 */       sessionUser.setUser(this.m_User);
/* 152 */       sessionUser.setClientIp(this.m_strClientIP);
/* 153 */       sessionUser.setSessionId(this.m_strSessionID);
/* 154 */       sessionUser.setOaUserId(this.m_strLoginOAUser);
/* 155 */       sessionUser.setGroupId(this.m_User.getGroupId() == null ? "" : this.m_User.getGroupId());
/* 156 */       IUserPrivilegeCommonService privilegeService = (IUserPrivilegeCommonService)SystemServiceLocator.getInstance().getService("userPrivilegeCommonService");
/*     */ 
/* 158 */       if (privilegeService.isAdminUser(this.m_User.getUserid()))
/* 159 */         sessionUser.setGroupId("1");
/*     */       else {
/* 161 */         sessionUser.setGroupId("0");
/*     */       }
/*     */ 
/* 164 */       event.getSession().setAttribute("biplatform_user", sessionUser);
/* 165 */       log.info("[SessionListener] --valueBound put PrivilegeUserSession into \"biplatform_user\"");
/*     */ 
/* 169 */       if (null != sqlca)
/* 170 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 167 */       e.printStackTrace();
/*     */ 
/* 169 */       if (null != sqlca)
/* 170 */         sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 169 */       if (null != sqlca)
/* 170 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void valueUnbound(HttpSessionBindingEvent event)
/*     */   {
/* 179 */     Sqlca sqlca = null;
/*     */     try {
/* 181 */       sqlca = new Sqlca(new ConnectionEx());
/* 182 */       sqlca.setAutoCommit(false);
/*     */ 
/* 198 */       if (null != sqlca)
/* 199 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 196 */       e.printStackTrace();
/*     */ 
/* 198 */       if (null != sqlca)
/* 199 */         sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 198 */       if (null != sqlca)
/* 199 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getBrowserVersion(String user_agent)
/*     */   {
/* 210 */     if (user_agent.indexOf("MSIE 6.0") > 0) {
/* 211 */       return "IE 6.0";
/*     */     }
/* 213 */     if (user_agent.indexOf("MSIE 8.0") > 0) {
/* 214 */       return "IE 8.0";
/*     */     }
/* 216 */     if (user_agent.indexOf("MSIE 7.0") > 0) {
/* 217 */       return "IE 7.0";
/*     */     }
/* 219 */     if (user_agent.indexOf("MSIE 5.5") > 0) {
/* 220 */       return "IE 5.5";
/*     */     }
/* 222 */     if (user_agent.indexOf("MSIE 5.01") > 0) {
/* 223 */       return "IE 5.01";
/*     */     }
/* 225 */     if (user_agent.indexOf("MSIE 5.0") > 0) {
/* 226 */       return "IE 5.0";
/*     */     }
/* 228 */     if (user_agent.indexOf("MSIE 4.0") > 0) {
/* 229 */       return "IE 4.0";
/*     */     }
/* 231 */     if (user_agent.indexOf("Firefox") > 0) {
/* 232 */       return "Firefox";
/*     */     }
/* 234 */     if (user_agent.indexOf("Netscape") > 0) {
/* 235 */       return "Netscape";
/*     */     }
/* 237 */     if (user_agent.indexOf("Opera") > 0) {
/* 238 */       return "Opera";
/*     */     }
/* 240 */     return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.other") + "";
/*     */   }
/*     */ 
/*     */   public String getM_strLoginOAUser() {
/* 244 */     return this.m_strLoginOAUser;
/*     */   }
/*     */ 
/*     */   public void setM_strLoginOAUser(String mStrLoginOAUser) {
/* 248 */     this.m_strLoginOAUser = mStrLoginOAUser;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.listener.SessionListener
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.model;

/**
 * DimChannelUserRelation entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class DimChannelUserRelation implements java.io.Serializable {

	// Fields

	private DimChannelUserRelationId id;

	private int resourceId;
	
	private Short channelNo;

	// Constructors

	public Short getChannelNo() {
		return channelNo;
	}

	public void setChannelNo(Short channelNo) {
		this.channelNo = channelNo;
	}

	/** default constructor */
	public DimChannelUserRelation() {
	}

	/** full constructor */
	public DimChannelUserRelation(DimChannelUserRelationId id) {
		this.id = id;
	}

	// Property accessors

	public DimChannelUserRelationId getId() {
		return this.id;
	}

	public void setId(DimChannelUserRelationId id) {
		this.id = id;
	}

	/**
	 * @return resourceId
	 */
	public int getResourceId() {
		return resourceId;
	}

	/**
	 * @param resourceId 要设置的 resourceId
	 */
	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}

	public String getChanneltypeAndId() {
		return this.id.getChanneltypeId() + "_" + this.id.getChannelId();
	}
}

/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DimChannelUserRelationId
/*    */   implements Serializable
/*    */ {
/*    */   private Short channeltypeId;
/*    */   private String channelId;
/*    */   private String userId;
/*    */   private Short confirmType;
/*    */ 
/*    */   public DimChannelUserRelationId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DimChannelUserRelationId(Short channeltypeId, String channelId, String userId, Short confirmType)
/*    */   {
/* 29 */     this.channeltypeId = channeltypeId;
/* 30 */     this.channelId = channelId;
/* 31 */     this.userId = userId;
/* 32 */     this.confirmType = confirmType;
/*    */   }
/*    */ 
/*    */   public Short getChanneltypeId()
/*    */   {
/* 38 */     return this.channeltypeId;
/*    */   }
/*    */ 
/*    */   public void setChanneltypeId(Short channeltypeId) {
/* 42 */     this.channeltypeId = channeltypeId;
/*    */   }
/*    */ 
/*    */   public String getChannelId() {
/* 46 */     return this.channelId;
/*    */   }
/*    */ 
/*    */   public void setChannelId(String channelId) {
/* 50 */     this.channelId = channelId;
/*    */   }
/*    */ 
/*    */   public String getUserId() {
/* 54 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public void setUserId(String userId) {
/* 58 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 62 */     if (this == other)
/* 63 */       return true;
/* 64 */     if (other == null)
/* 65 */       return false;
/* 66 */     if (!(other instanceof DimChannelUserRelationId))
/* 67 */       return false;
/* 68 */     DimChannelUserRelationId castOther = (DimChannelUserRelationId)other;
/*    */ 
/* 70 */     return ((getChanneltypeId() == castOther.getChanneltypeId()) || ((getChanneltypeId() != null) && (castOther.getChanneltypeId() != null) && (getChanneltypeId().equals(castOther.getChanneltypeId())))) && ((getChannelId() == castOther.getChannelId()) || ((getChannelId() != null) && (castOther.getChannelId() != null) && (getChannelId().equals(castOther.getChannelId())))) && ((getUserId() == castOther.getUserId()) || ((getUserId() != null) && (castOther.getUserId() != null) && (getUserId().equals(castOther.getUserId())) && ((getConfirmType() == castOther.getConfirmType()) || ((getConfirmType() != null) && (castOther.getConfirmType() != null) && (getConfirmType().equals(castOther.getConfirmType()))))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 77 */     int result = 17;
/*    */ 
/* 79 */     result = 37 * result + (getChanneltypeId() == null ? 0 : getChanneltypeId().hashCode());
/* 80 */     result = 37 * result + (getChannelId() == null ? 0 : getChannelId().hashCode());
/* 81 */     result = 37 * result + (getUserId() == null ? 0 : getUserId().hashCode());
/* 82 */     result = 37 * result + (getConfirmType() == null ? 0 : getConfirmType().hashCode());
/* 83 */     return result;
/*    */   }
/*    */ 
/*    */   public Short getConfirmType() {
/* 87 */     return this.confirmType;
/*    */   }
/*    */ 
/*    */   public void setConfirmType(Short confirmType) {
/* 91 */     this.confirmType = confirmType;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimChannelUserRelationId
 * JD-Core Version:    0.6.2
 */
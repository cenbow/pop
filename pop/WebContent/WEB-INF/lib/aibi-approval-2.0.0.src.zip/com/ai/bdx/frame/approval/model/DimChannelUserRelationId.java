package com.ai.bdx.frame.approval.model;

/**
 * DimChannelUserRelationId entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class DimChannelUserRelationId implements java.io.Serializable {

	// Fields

	private Short channeltypeId;

	private String channelId;

	private String userId;

	private Short confirmType;

	// Constructors

	/** default constructor */
	public DimChannelUserRelationId() {
	}

	/** full constructor */
	public DimChannelUserRelationId(Short channeltypeId, String channelId, String userId, Short confirmType) {
		this.channeltypeId = channeltypeId;
		this.channelId = channelId;
		this.userId = userId;
		this.confirmType = confirmType;
	}

	// Property accessors

	public Short getChanneltypeId() {
		return this.channeltypeId;
	}

	public void setChanneltypeId(Short channeltypeId) {
		this.channeltypeId = channeltypeId;
	}

	public String getChannelId() {
		return this.channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof DimChannelUserRelationId))
			return false;
		DimChannelUserRelationId castOther = (DimChannelUserRelationId) other;

		return ((this.getChanneltypeId() == castOther.getChanneltypeId()) || (this.getChanneltypeId() != null && castOther.getChanneltypeId() != null && this.getChanneltypeId().equals(castOther.getChanneltypeId())))
				&& ((this.getChannelId() == castOther.getChannelId()) || (this.getChannelId() != null && castOther.getChannelId() != null && this.getChannelId().equals(castOther.getChannelId())))
				&& ((this.getUserId() == castOther.getUserId()) || (this.getUserId() != null && castOther.getUserId() != null && this.getUserId().equals(castOther.getUserId()))
						&& ((this.getConfirmType() == castOther.getConfirmType()) || (this.getConfirmType() != null && castOther.getConfirmType() != null && this.getConfirmType().equals(castOther.getConfirmType()))));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getChanneltypeId() == null ? 0 : this.getChanneltypeId().hashCode());
		result = 37 * result + (getChannelId() == null ? 0 : this.getChannelId().hashCode());
		result = 37 * result + (getUserId() == null ? 0 : this.getUserId().hashCode());
		result = 37 * result + (getConfirmType() == null ? 0 : this.getConfirmType().hashCode());
		return result;
	}

	public Short getConfirmType() {
		return confirmType;
	}

	public void setConfirmType(Short confirmType) {
		this.confirmType = confirmType;
	}

}

/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DimColumnClass
/*    */   implements Serializable
/*    */ {
/*    */   private Short classId;
/*    */   private String className;
/*    */ 
/*    */   public DimColumnClass()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DimColumnClass(Short classId)
/*    */   {
/* 23 */     this.classId = classId;
/*    */   }
/*    */ 
/*    */   public DimColumnClass(Short classId, String campDrvName)
/*    */   {
/* 28 */     this.classId = classId;
/* 29 */     this.className = this.className;
/*    */   }
/*    */ 
/*    */   public Short getClassId()
/*    */   {
/* 35 */     return this.classId;
/*    */   }
/*    */ 
/*    */   public void setClassId(Short classId) {
/* 39 */     this.classId = classId;
/*    */   }
/*    */ 
/*    */   public String getClassName() {
/* 43 */     return this.className;
/*    */   }
/*    */ 
/*    */   public void setClassName(String className) {
/* 47 */     this.className = className;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimColumnClass
 * JD-Core Version:    0.6.2
 */
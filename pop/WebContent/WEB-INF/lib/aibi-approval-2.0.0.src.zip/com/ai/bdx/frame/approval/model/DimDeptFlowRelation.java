/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DimDeptFlowRelation
/*    */   implements Serializable
/*    */ {
/*    */   private DimDeptFlowRelationId id;
/*    */ 
/*    */   public DimDeptFlowRelation()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DimDeptFlowRelation(DimDeptFlowRelationId id)
/*    */   {
/* 22 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public DimDeptFlowRelationId getId()
/*    */   {
/* 30 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(DimDeptFlowRelationId id) {
/* 34 */     this.id = id;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimDeptFlowRelation
 * JD-Core Version:    0.6.2
 */
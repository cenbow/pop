package com.ai.bdx.frame.approval.model;



public class DimDeptFlowRelationId implements java.io.Serializable {

	private String cityId;
	private String deptId;
	private String campDrvId;
	private String relationType;
	private String approveFlowId;
	private String flow_type;

	// Constructors

	/** default constructor */
	public DimDeptFlowRelationId() {
	}

	/** full constructor */
	public DimDeptFlowRelationId(String cityId, String deptId, String campDrvId,
			String relationType, String approveFlowId, String flow_type) {
		this.cityId = cityId;
		this.deptId = deptId;
		this.campDrvId = campDrvId;
		this.relationType = relationType;
		this.approveFlowId = approveFlowId;
		this.flow_type = flow_type;
	}

	// Property accessors

	public String getCityId() {
		return this.cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public String getDeptId() {
		return this.deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getCampDrvId() {
		return this.campDrvId;
	}

	public void setCampDrvId(String campDrvId) {
		this.campDrvId = campDrvId;
	}

	public String getRelationType() {
		return relationType;
	}

	public void setRelationType(String relationType) {
		this.relationType = relationType;
	}

	public String getFlow_type() {
		return flow_type;
	}

	public void setFlow_type(String flow_type) {
		this.flow_type = flow_type;
	}

	public String getApproveFlowId() {
		return approveFlowId;
	}

	public void setApproveFlowId(String approveFlowId) {
		this.approveFlowId = approveFlowId;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof DimDeptFlowRelationId))
			return false;
		DimDeptFlowRelationId castOther = (DimDeptFlowRelationId) other;

		return ((this.getCityId() == castOther.getCityId()) || (this
				.getCityId() != null
				&& castOther.getCityId() != null && this.getCityId().equals(
				castOther.getCityId())))
				&& ((this.getDeptId() == castOther.getDeptId()) || (this
						.getDeptId() != null
						&& castOther.getDeptId() != null && this.getDeptId()
						.equals(castOther.getDeptId())))
				&& ((this.getCampDrvId() == castOther.getCampDrvId()) || (this
						.getCampDrvId() != null
						&& castOther.getCampDrvId() != null && this
						.getCampDrvId().equals(castOther.getCampDrvId())))
				&& ((this.getRelationType() == castOther.getRelationType()) || (this
						.getRelationType() != null
						&& castOther.getRelationType() != null && this
						.getRelationType()
						.equals(castOther.getRelationType())))
				&& ((this.getApproveFlowId() == castOther.getApproveFlowId()) || (this
						.getApproveFlowId() != null
						&& castOther.getApproveFlowId() != null && this
						.getApproveFlowId().equals(castOther.getApproveFlowId())))
				&& ((this.getFlow_type() == castOther.getFlow_type()) || (this
						.getFlow_type() != null
						&& castOther.getFlow_type() != null && this
						.getFlow_type().equals(castOther.getFlow_type())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getCityId() == null ? 0 : this.getCityId().hashCode());
		result = 37 * result
				+ (getDeptId() == null ? 0 : this.getDeptId().hashCode());
		result = 37 * result
				+ (getCampDrvId() == null ? 0 : this.getCampDrvId().hashCode());
		result = 37
				* result
				+ (getRelationType() == null ? 0 : this.getRelationType()
						.hashCode());
		result = 37 * result
				+ (getApproveFlowId() == null ? 0 : this.getApproveFlowId().hashCode());
		result = 37
				* result
				+ (getFlow_type() == null ? 0 : this.getFlow_type()
						.hashCode());
		return result;
	}

}

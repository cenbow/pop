/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class DimDeptFlowRelationId
/*     */   implements Serializable
/*     */ {
/*     */   private String cityId;
/*     */   private String deptId;
/*     */   private String campDrvId;
/*     */   private String relationType;
/*     */   private String approveFlowId;
/*     */   private String flow_type;
/*     */ 
/*     */   public DimDeptFlowRelationId()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DimDeptFlowRelationId(String cityId, String deptId, String campDrvId, String relationType, String approveFlowId, String flow_type)
/*     */   {
/*  23 */     this.cityId = cityId;
/*  24 */     this.deptId = deptId;
/*  25 */     this.campDrvId = campDrvId;
/*  26 */     this.relationType = relationType;
/*  27 */     this.approveFlowId = approveFlowId;
/*  28 */     this.flow_type = flow_type;
/*     */   }
/*     */ 
/*     */   public String getCityId()
/*     */   {
/*  34 */     return this.cityId;
/*     */   }
/*     */ 
/*     */   public void setCityId(String cityId) {
/*  38 */     this.cityId = cityId;
/*     */   }
/*     */ 
/*     */   public String getDeptId() {
/*  42 */     return this.deptId;
/*     */   }
/*     */ 
/*     */   public void setDeptId(String deptId) {
/*  46 */     this.deptId = deptId;
/*     */   }
/*     */ 
/*     */   public String getCampDrvId() {
/*  50 */     return this.campDrvId;
/*     */   }
/*     */ 
/*     */   public void setCampDrvId(String campDrvId) {
/*  54 */     this.campDrvId = campDrvId;
/*     */   }
/*     */ 
/*     */   public String getRelationType() {
/*  58 */     return this.relationType;
/*     */   }
/*     */ 
/*     */   public void setRelationType(String relationType) {
/*  62 */     this.relationType = relationType;
/*     */   }
/*     */ 
/*     */   public String getFlow_type() {
/*  66 */     return this.flow_type;
/*     */   }
/*     */ 
/*     */   public void setFlow_type(String flow_type) {
/*  70 */     this.flow_type = flow_type;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowId() {
/*  74 */     return this.approveFlowId;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowId(String approveFlowId) {
/*  78 */     this.approveFlowId = approveFlowId;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/*  82 */     if (this == other)
/*  83 */       return true;
/*  84 */     if (other == null)
/*  85 */       return false;
/*  86 */     if (!(other instanceof DimDeptFlowRelationId))
/*  87 */       return false;
/*  88 */     DimDeptFlowRelationId castOther = (DimDeptFlowRelationId)other;
/*     */ 
/*  90 */     return ((getCityId() == castOther.getCityId()) || ((getCityId() != null) && (castOther.getCityId() != null) && (getCityId().equals(castOther.getCityId())))) && ((getDeptId() == castOther.getDeptId()) || ((getDeptId() != null) && (castOther.getDeptId() != null) && (getDeptId().equals(castOther.getDeptId())))) && ((getCampDrvId() == castOther.getCampDrvId()) || ((getCampDrvId() != null) && (castOther.getCampDrvId() != null) && (getCampDrvId().equals(castOther.getCampDrvId())))) && ((getRelationType() == castOther.getRelationType()) || ((getRelationType() != null) && (castOther.getRelationType() != null) && (getRelationType().equals(castOther.getRelationType())))) && ((getApproveFlowId() == castOther.getApproveFlowId()) || ((getApproveFlowId() != null) && (castOther.getApproveFlowId() != null) && (getApproveFlowId().equals(castOther.getApproveFlowId())))) && ((getFlow_type() == castOther.getFlow_type()) || ((getFlow_type() != null) && (castOther.getFlow_type() != null) && (getFlow_type().equals(castOther.getFlow_type()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 118 */     int result = 17;
/*     */ 
/* 120 */     result = 37 * result + (getCityId() == null ? 0 : getCityId().hashCode());
/*     */ 
/* 122 */     result = 37 * result + (getDeptId() == null ? 0 : getDeptId().hashCode());
/*     */ 
/* 124 */     result = 37 * result + (getCampDrvId() == null ? 0 : getCampDrvId().hashCode());
/*     */ 
/* 126 */     result = 37 * result + (getRelationType() == null ? 0 : getRelationType().hashCode());
/*     */ 
/* 130 */     result = 37 * result + (getApproveFlowId() == null ? 0 : getApproveFlowId().hashCode());
/*     */ 
/* 132 */     result = 37 * result + (getFlow_type() == null ? 0 : getFlow_type().hashCode());
/*     */ 
/* 136 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimDeptFlowRelationId
 * JD-Core Version:    0.6.2
 */
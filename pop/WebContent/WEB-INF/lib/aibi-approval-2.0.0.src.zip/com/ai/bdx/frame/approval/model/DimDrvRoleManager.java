/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DimDrvRoleManager
/*    */   implements Serializable
/*    */ {
/*    */   private DimDrvRoleManagerId id;
/*    */   private Short accessToken;
/*    */   private Short roleFlag;
/*    */ 
/*    */   public DimDrvRoleManager()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DimDrvRoleManager(DimDrvRoleManagerId id)
/*    */   {
/* 24 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public DimDrvRoleManager(DimDrvRoleManagerId id, Short accessToken, Short roleFlag)
/*    */   {
/* 30 */     this.id = id;
/* 31 */     this.accessToken = accessToken;
/* 32 */     this.roleFlag = roleFlag;
/*    */   }
/*    */ 
/*    */   public DimDrvRoleManagerId getId()
/*    */   {
/* 38 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(DimDrvRoleManagerId id) {
/* 42 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public Short getAccessToken() {
/* 46 */     return this.accessToken;
/*    */   }
/*    */ 
/*    */   public void setAccessToken(Short accessToken) {
/* 50 */     this.accessToken = accessToken;
/*    */   }
/*    */ 
/*    */   public Short getRoleFlag() {
/* 54 */     return this.roleFlag;
/*    */   }
/*    */ 
/*    */   public void setRoleFlag(Short roleFlag) {
/* 58 */     this.roleFlag = roleFlag;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimDrvRoleManager
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DimDrvRoleManagerId
/*    */   implements Serializable
/*    */ {
/*    */   private Short campDrvId;
/*    */   private String roleId;
/*    */ 
/*    */   public DimDrvRoleManagerId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DimDrvRoleManagerId(Short campDrvId, String roleId)
/*    */   {
/* 22 */     this.campDrvId = campDrvId;
/* 23 */     this.roleId = roleId;
/*    */   }
/*    */ 
/*    */   public Short getCampDrvId()
/*    */   {
/* 29 */     return this.campDrvId;
/*    */   }
/*    */ 
/*    */   public void setCampDrvId(Short campDrvId) {
/* 33 */     this.campDrvId = campDrvId;
/*    */   }
/*    */ 
/*    */   public String getRoleId() {
/* 37 */     return this.roleId;
/*    */   }
/*    */ 
/*    */   public void setRoleId(String roleId) {
/* 41 */     this.roleId = roleId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 45 */     if (this == other)
/* 46 */       return true;
/* 47 */     if (other == null)
/* 48 */       return false;
/* 49 */     if (!(other instanceof DimDrvRoleManagerId))
/* 50 */       return false;
/* 51 */     DimDrvRoleManagerId castOther = (DimDrvRoleManagerId)other;
/*    */ 
/* 53 */     return ((getCampDrvId() == castOther.getCampDrvId()) || ((getCampDrvId() != null) && (castOther.getCampDrvId() != null) && (getCampDrvId().equals(castOther.getCampDrvId())))) && ((getRoleId() == castOther.getRoleId()) || ((getRoleId() != null) && (castOther.getRoleId() != null) && (getRoleId().equals(castOther.getRoleId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 62 */     int result = 17;
/*    */ 
/* 64 */     result = 37 * result + (getCampDrvId() == null ? 0 : getCampDrvId().hashCode());
/*    */ 
/* 66 */     result = 37 * result + (getRoleId() == null ? 0 : getRoleId().hashCode());
/*    */ 
/* 68 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimDrvRoleManagerId
 * JD-Core Version:    0.6.2
 */
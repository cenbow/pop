/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DimMtlChannel
/*    */   implements Serializable
/*    */ {
/*    */   private String channelId;
/*    */   private Short channeltypeId;
/*    */   private String channelName;
/*    */   private String campId;
/*    */   private String createUser;
/*    */ 
/*    */   public String getCampId()
/*    */   {
/* 26 */     return this.campId;
/*    */   }
/*    */ 
/*    */   public void setCampId(String campId) {
/* 30 */     this.campId = campId;
/*    */   }
/*    */ 
/*    */   public DimMtlChannel()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DimMtlChannel(String channelId, String channelName)
/*    */   {
/* 39 */     this.channelId = channelId;
/* 40 */     this.channelName = channelName;
/*    */   }
/*    */ 
/*    */   public DimMtlChannel(String channelId, Short channeltypeId, String channelName)
/*    */   {
/* 45 */     this.channelId = channelId;
/* 46 */     this.channeltypeId = channeltypeId;
/* 47 */     this.channelName = channelName;
/*    */   }
/*    */ 
/*    */   public String getChannelId()
/*    */   {
/* 53 */     return this.channelId;
/*    */   }
/*    */ 
/*    */   public void setChannelId(String channelId) {
/* 57 */     this.channelId = channelId;
/*    */   }
/*    */ 
/*    */   public Short getChanneltypeId() {
/* 61 */     return this.channeltypeId;
/*    */   }
/*    */ 
/*    */   public void setChanneltypeId(Short channeltypeId) {
/* 65 */     this.channeltypeId = channeltypeId;
/*    */   }
/*    */ 
/*    */   public String getChannelName() {
/* 69 */     return this.channelName;
/*    */   }
/*    */ 
/*    */   public void setChannelName(String channelName) {
/* 73 */     this.channelName = channelName;
/*    */   }
/*    */ 
/*    */   public String getCreateUser() {
/* 77 */     return this.createUser;
/*    */   }
/*    */ 
/*    */   public void setCreateUser(String createUser) {
/* 81 */     this.createUser = createUser;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimMtlChannel
 * JD-Core Version:    0.6.2
 */
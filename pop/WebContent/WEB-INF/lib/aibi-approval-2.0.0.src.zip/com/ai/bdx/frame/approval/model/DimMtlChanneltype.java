package com.ai.bdx.frame.approval.model;


/**
 * DimMtlChanneltype entity.
 *
 * @author MyEclipse Persistence Tools
 */

public class DimMtlChanneltype implements java.io.Serializable {

	// Fields

	private Short activeFlag;

	private Short channeltypeId;

	private String channeltypeName;

	private Integer contactType;

	private Integer autoSendOdd;

	private Integer initiativeType;
	
	private Integer displayOrder;
	// Constructors

	/** default constructor */
	public DimMtlChanneltype() {
	}

	/** minimal constructor */
	public DimMtlChanneltype(Short channeltypeId, String channeltypeName) {
		this.channeltypeId = channeltypeId;
		this.channeltypeName = channeltypeName;
	}

	/** full constructor */
	public DimMtlChanneltype(Short channeltypeId, String channeltypeName, Short activeFlag) {
		this.channeltypeId = channeltypeId;
		this.channeltypeName = channeltypeName;
		this.activeFlag = activeFlag;
	}

	// Property accessors

	public Short getActiveFlag() {
		return activeFlag;
	}

	public Integer getContactType() {
		return contactType;
	}

	public void setContactType(Integer contactType) {
		this.contactType = contactType;
	}

	public Short getChanneltypeId() {
		return channeltypeId;
	}

	public String getChanneltypeName() {
		return channeltypeName;
	}

	public void setActiveFlag(Short activeFlag) {
		this.activeFlag = activeFlag;
	}

	public void setChanneltypeId(Short channeltypeId) {
		this.channeltypeId = channeltypeId;
	}

	public void setChanneltypeName(String channeltypeName) {
		this.channeltypeName = channeltypeName;
	}

	public Integer getAutoSendOdd() {
		return autoSendOdd;
	}

	public void setAutoSendOdd(Integer autoSendOdd) {
		this.autoSendOdd = autoSendOdd;
	}

	public Integer getInitiativeType() {
		return initiativeType;
	}

	public void setInitiativeType(Integer initiativeType) {
		this.initiativeType = initiativeType;
	}

	public Integer getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}

}

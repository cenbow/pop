/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class DimMtlChanneltype
/*     */   implements Serializable
/*     */ {
/*     */   private Short activeFlag;
/*     */   private Short channeltypeId;
/*     */   private String channeltypeName;
/*     */   private Integer contactType;
/*     */   private Integer autoSendOdd;
/*     */   private Integer initiativeType;
/*     */   private Integer displayOrder;
/*     */ 
/*     */   public DimMtlChanneltype()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DimMtlChanneltype(Short channeltypeId, String channeltypeName)
/*     */   {
/*  35 */     this.channeltypeId = channeltypeId;
/*  36 */     this.channeltypeName = channeltypeName;
/*     */   }
/*     */ 
/*     */   public DimMtlChanneltype(Short channeltypeId, String channeltypeName, Short activeFlag)
/*     */   {
/*  41 */     this.channeltypeId = channeltypeId;
/*  42 */     this.channeltypeName = channeltypeName;
/*  43 */     this.activeFlag = activeFlag;
/*     */   }
/*     */ 
/*     */   public Short getActiveFlag()
/*     */   {
/*  49 */     return this.activeFlag;
/*     */   }
/*     */ 
/*     */   public Integer getContactType() {
/*  53 */     return this.contactType;
/*     */   }
/*     */ 
/*     */   public void setContactType(Integer contactType) {
/*  57 */     this.contactType = contactType;
/*     */   }
/*     */ 
/*     */   public Short getChanneltypeId() {
/*  61 */     return this.channeltypeId;
/*     */   }
/*     */ 
/*     */   public String getChanneltypeName() {
/*  65 */     return this.channeltypeName;
/*     */   }
/*     */ 
/*     */   public void setActiveFlag(Short activeFlag) {
/*  69 */     this.activeFlag = activeFlag;
/*     */   }
/*     */ 
/*     */   public void setChanneltypeId(Short channeltypeId) {
/*  73 */     this.channeltypeId = channeltypeId;
/*     */   }
/*     */ 
/*     */   public void setChanneltypeName(String channeltypeName) {
/*  77 */     this.channeltypeName = channeltypeName;
/*     */   }
/*     */ 
/*     */   public Integer getAutoSendOdd() {
/*  81 */     return this.autoSendOdd;
/*     */   }
/*     */ 
/*     */   public void setAutoSendOdd(Integer autoSendOdd) {
/*  85 */     this.autoSendOdd = autoSendOdd;
/*     */   }
/*     */ 
/*     */   public Integer getInitiativeType() {
/*  89 */     return this.initiativeType;
/*     */   }
/*     */ 
/*     */   public void setInitiativeType(Integer initiativeType) {
/*  93 */     this.initiativeType = initiativeType;
/*     */   }
/*     */ 
/*     */   public Integer getDisplayOrder() {
/*  97 */     return this.displayOrder;
/*     */   }
/*     */ 
/*     */   public void setDisplayOrder(Integer displayOrder) {
/* 101 */     this.displayOrder = displayOrder;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimMtlChanneltype
 * JD-Core Version:    0.6.2
 */
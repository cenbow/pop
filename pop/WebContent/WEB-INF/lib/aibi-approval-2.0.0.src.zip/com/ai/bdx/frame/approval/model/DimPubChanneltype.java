package com.ai.bdx.frame.approval.model;

import java.util.Date;

public class DimPubChanneltype implements java.io.Serializable {

	// Fields

	private Integer channeltypeId;

	private Date beginTime;

	private Date endTime;

	private Short activeFlag;

	private String channeltypeName;

	private String descTxt;

	// Constructors

	/** default constructor */
	public DimPubChanneltype() {
	}

	/** minimal constructor */
	public DimPubChanneltype(Integer channeltypeId, Date beginTime, Date endTime) {
		this.channeltypeId = channeltypeId;
		this.beginTime = beginTime;
		this.endTime = endTime;
	}

	/** full constructor */
	public DimPubChanneltype(Integer channeltypeId, Date beginTime,
			Date endTime, Short activeFlag, String channeltypeName,
			String descTxt) {
		this.channeltypeId = channeltypeId;
		this.beginTime = beginTime;
		this.endTime = endTime;
		this.activeFlag = activeFlag;
		this.channeltypeName = channeltypeName;
		this.descTxt = descTxt;
	}

	// Property accessors

	public Integer getChanneltypeId() {
		return this.channeltypeId;
	}

	public void setChanneltypeId(Integer channeltypeId) {
		this.channeltypeId = channeltypeId;
	}

	public Date getBeginTime() {
		return this.beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public Date getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Short getActiveFlag() {
		return this.activeFlag;
	}

	public void setActiveFlag(Short activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getChanneltypeName() {
		return this.channeltypeName;
	}

	public void setChanneltypeName(String channeltypeName) {
		this.channeltypeName = channeltypeName;
	}

	public String getDescTxt() {
		return this.descTxt;
	}

	public void setDescTxt(String descTxt) {
		this.descTxt = descTxt;
	}

}

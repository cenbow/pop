/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class DimPubChanneltype
/*    */   implements Serializable
/*    */ {
/*    */   private Integer channeltypeId;
/*    */   private Date beginTime;
/*    */   private Date endTime;
/*    */   private Short activeFlag;
/*    */   private String channeltypeName;
/*    */   private String descTxt;
/*    */ 
/*    */   public DimPubChanneltype()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DimPubChanneltype(Integer channeltypeId, Date beginTime, Date endTime)
/*    */   {
/* 29 */     this.channeltypeId = channeltypeId;
/* 30 */     this.beginTime = beginTime;
/* 31 */     this.endTime = endTime;
/*    */   }
/*    */ 
/*    */   public DimPubChanneltype(Integer channeltypeId, Date beginTime, Date endTime, Short activeFlag, String channeltypeName, String descTxt)
/*    */   {
/* 38 */     this.channeltypeId = channeltypeId;
/* 39 */     this.beginTime = beginTime;
/* 40 */     this.endTime = endTime;
/* 41 */     this.activeFlag = activeFlag;
/* 42 */     this.channeltypeName = channeltypeName;
/* 43 */     this.descTxt = descTxt;
/*    */   }
/*    */ 
/*    */   public Integer getChanneltypeId()
/*    */   {
/* 49 */     return this.channeltypeId;
/*    */   }
/*    */ 
/*    */   public void setChanneltypeId(Integer channeltypeId) {
/* 53 */     this.channeltypeId = channeltypeId;
/*    */   }
/*    */ 
/*    */   public Date getBeginTime() {
/* 57 */     return this.beginTime;
/*    */   }
/*    */ 
/*    */   public void setBeginTime(Date beginTime) {
/* 61 */     this.beginTime = beginTime;
/*    */   }
/*    */ 
/*    */   public Date getEndTime() {
/* 65 */     return this.endTime;
/*    */   }
/*    */ 
/*    */   public void setEndTime(Date endTime) {
/* 69 */     this.endTime = endTime;
/*    */   }
/*    */ 
/*    */   public Short getActiveFlag() {
/* 73 */     return this.activeFlag;
/*    */   }
/*    */ 
/*    */   public void setActiveFlag(Short activeFlag) {
/* 77 */     this.activeFlag = activeFlag;
/*    */   }
/*    */ 
/*    */   public String getChanneltypeName() {
/* 81 */     return this.channeltypeName;
/*    */   }
/*    */ 
/*    */   public void setChanneltypeName(String channeltypeName) {
/* 85 */     this.channeltypeName = channeltypeName;
/*    */   }
/*    */ 
/*    */   public String getDescTxt() {
/* 89 */     return this.descTxt;
/*    */   }
/*    */ 
/*    */   public void setDescTxt(String descTxt) {
/* 93 */     this.descTxt = descTxt;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimPubChanneltype
 * JD-Core Version:    0.6.2
 */
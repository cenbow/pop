/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DimResType
/*    */   implements Serializable
/*    */ {
/*    */   private Long resType;
/*    */   private String restypeName;
/*    */   private String restypeDesc;
/*    */ 
/*    */   public DimResType()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DimResType(Long resType)
/*    */   {
/* 26 */     this.resType = resType;
/*    */   }
/*    */ 
/*    */   public DimResType(Long resType, String restypeName, String restypeDesc)
/*    */   {
/* 31 */     this.resType = resType;
/* 32 */     this.restypeName = restypeName;
/* 33 */     this.restypeDesc = restypeDesc;
/*    */   }
/*    */ 
/*    */   public Long getResType()
/*    */   {
/* 39 */     return this.resType;
/*    */   }
/*    */ 
/*    */   public void setResType(Long resType) {
/* 43 */     this.resType = resType;
/*    */   }
/*    */ 
/*    */   public String getRestypeName() {
/* 47 */     return this.restypeName;
/*    */   }
/*    */ 
/*    */   public void setRestypeName(String restypeName) {
/* 51 */     this.restypeName = restypeName;
/*    */   }
/*    */ 
/*    */   public String getRestypeDesc() {
/* 55 */     return this.restypeDesc;
/*    */   }
/*    */ 
/*    */   public void setRestypeDesc(String restypeDesc) {
/* 59 */     this.restypeDesc = restypeDesc;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.DimResType
 * JD-Core Version:    0.6.2
 */
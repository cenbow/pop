package com.ai.bdx.frame.approval.model;

import java.io.Serializable;
import java.util.Map;

/**
 * Created on Mar 24, 2008 3:14:24 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MpmCustInfoWs implements Serializable {
	private String productNo;

	//key=用户属性字段英文名称；value=用户属性字段值
	private Map<String, String> userInfoMap;

	//String[][0]=用户属性字段英文名称；String[][1]=用户属性字段值
	private String[][] userInfoArray;

	public MpmCustInfoWs() {

	}

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

	public Map<String, String> getUserInfoMap() {
		return userInfoMap;
	}

	public void setUserInfoMap(Map<String, String> userInfoMap) {
		this.userInfoMap = userInfoMap;
	}

	public String[][] getUserInfoArray() {
		return userInfoArray;
	}

	public void setUserInfoArray(String[][] userInfoArray) {
		this.userInfoArray = userInfoArray;
	}

	public String getUserInfo(String key) {
		String res = "";
		if (this.userInfoMap != null) {
			res = this.userInfoMap.get(key);
		} else if (this.userInfoArray != null) {
			for (int i = 0; i < this.userInfoArray.length; i++) {
				if (this.userInfoArray[i][0].equalsIgnoreCase(key.toLowerCase())) {
					res = this.userInfoArray[i][1];
					break;
				}
			}
		}
		return res;
	}
}

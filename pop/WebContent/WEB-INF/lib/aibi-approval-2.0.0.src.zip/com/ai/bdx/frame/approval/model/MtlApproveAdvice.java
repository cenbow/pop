/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class MtlApproveAdvice
/*     */   implements Serializable
/*     */ {
/*     */   private MtlApproveAdviceId id;
/*     */   private String[] actorUserIds;
/*     */   private String sponsorDate;
/*     */   private Date actTime;
/*     */   private String actorAdvice;
/*     */   private Short actEndFlag;
/*     */ 
/*     */   public String toString()
/*     */   {
/*  26 */     StringBuffer sb = new StringBuffer();
/*  27 */     sb.append("id.getCampsegId():" + this.id.getCampsegId() + ",").append("id.getSponorUserId():" + this.id.getSponorUserId() + ",").append("id.getActorUserId():" + this.id.getActorUserId() + ",").append("id.getSponsorType():" + this.id.getSponsorType() + ",").append(this.sponsorDate + ",").append(this.actTime.toGMTString() + ",").append(this.actorAdvice + ",").append(this.actEndFlag + ",");
/*     */ 
/*  34 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public MtlApproveAdvice()
/*     */   {
/*  41 */     this.id = new MtlApproveAdviceId();
/*     */   }
/*     */ 
/*     */   public MtlApproveAdvice(MtlApproveAdviceId id, String sponsorDate, Date actTime, Short actEndFlag)
/*     */   {
/*  47 */     this.id = id;
/*  48 */     this.sponsorDate = sponsorDate;
/*  49 */     this.actTime = actTime;
/*  50 */     this.actEndFlag = actEndFlag;
/*     */   }
/*     */ 
/*     */   public MtlApproveAdvice(MtlApproveAdviceId id, String sponsorDate, Date actTime, String actorAdvice, Short actEndFlag)
/*     */   {
/*  56 */     this.id = id;
/*  57 */     this.sponsorDate = sponsorDate;
/*  58 */     this.actTime = actTime;
/*  59 */     this.actorAdvice = actorAdvice;
/*  60 */     this.actEndFlag = actEndFlag;
/*     */   }
/*     */ 
/*     */   public MtlApproveAdviceId getId()
/*     */   {
/*  66 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(MtlApproveAdviceId id) {
/*  70 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getSponsorDate() {
/*  74 */     return this.sponsorDate;
/*     */   }
/*     */ 
/*     */   public void setSponsorDate(String sponsorDate) {
/*  78 */     this.sponsorDate = sponsorDate;
/*     */   }
/*     */ 
/*     */   public Date getActTime() {
/*  82 */     return this.actTime;
/*     */   }
/*     */ 
/*     */   public void setActTime(Date actTime) {
/*  86 */     this.actTime = actTime;
/*     */   }
/*     */ 
/*     */   public String getActorAdvice() {
/*  90 */     return this.actorAdvice;
/*     */   }
/*     */ 
/*     */   public void setActorAdvice(String actorAdvice) {
/*  94 */     this.actorAdvice = actorAdvice;
/*     */   }
/*     */ 
/*     */   public Short getActEndFlag() {
/*  98 */     return this.actEndFlag;
/*     */   }
/*     */ 
/*     */   public void setActEndFlag(Short actEndFlag) {
/* 102 */     this.actEndFlag = actEndFlag;
/*     */   }
/*     */ 
/*     */   public String[] getActorUserIds() {
/* 106 */     return this.actorUserIds;
/*     */   }
/*     */ 
/*     */   public void setActorUserIds(String[] actorUserIds) {
/* 110 */     this.actorUserIds = actorUserIds;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveAdvice
 * JD-Core Version:    0.6.2
 */
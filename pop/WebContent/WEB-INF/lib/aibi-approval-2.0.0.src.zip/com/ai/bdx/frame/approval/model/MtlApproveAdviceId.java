/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class MtlApproveAdviceId
/*     */   implements Serializable
/*     */ {
/*     */   private String campsegId;
/*     */   private String sponorUserId;
/*     */   private String actorUserId;
/*     */   private Short sponsorType;
/*     */ 
/*     */   public MtlApproveAdviceId()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlApproveAdviceId(String campsegId, String sponorUserId, String actorUserId, Short sponsorType)
/*     */   {
/*  28 */     this.campsegId = campsegId;
/*  29 */     this.sponorUserId = sponorUserId;
/*  30 */     this.actorUserId = actorUserId;
/*  31 */     this.sponsorType = sponsorType;
/*     */   }
/*     */ 
/*     */   public String getCampsegId()
/*     */   {
/*  37 */     return this.campsegId;
/*     */   }
/*     */ 
/*     */   public void setCampsegId(String campsegId) {
/*  41 */     this.campsegId = campsegId;
/*     */   }
/*     */ 
/*     */   public String getSponorUserId() {
/*  45 */     return this.sponorUserId;
/*     */   }
/*     */ 
/*     */   public void setSponorUserId(String sponorUserId) {
/*  49 */     this.sponorUserId = sponorUserId;
/*     */   }
/*     */ 
/*     */   public String getActorUserId() {
/*  53 */     return this.actorUserId;
/*     */   }
/*     */ 
/*     */   public void setActorUserId(String actorUserId) {
/*  57 */     this.actorUserId = actorUserId;
/*     */   }
/*     */ 
/*     */   public Short getSponsorType() {
/*  61 */     return this.sponsorType;
/*     */   }
/*     */ 
/*     */   public void setSponsorType(Short sponsorType) {
/*  65 */     this.sponsorType = sponsorType;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/*  69 */     if (this == other)
/*  70 */       return true;
/*  71 */     if (other == null)
/*  72 */       return false;
/*  73 */     if (!(other instanceof MtlApproveAdviceId))
/*  74 */       return false;
/*  75 */     MtlApproveAdviceId castOther = (MtlApproveAdviceId)other;
/*     */ 
/*  77 */     return ((getCampsegId() == castOther.getCampsegId()) || ((getCampsegId() != null) && (castOther.getCampsegId() != null) && (getCampsegId().equals(castOther.getCampsegId())))) && ((getSponorUserId() == castOther.getSponorUserId()) || ((getSponorUserId() != null) && (castOther.getSponorUserId() != null) && (getSponorUserId().equals(castOther.getSponorUserId())))) && ((getActorUserId() == castOther.getActorUserId()) || ((getActorUserId() != null) && (castOther.getActorUserId() != null) && (getActorUserId().equals(castOther.getActorUserId())))) && ((getSponsorType() == castOther.getSponsorType()) || ((getSponsorType() != null) && (castOther.getSponsorType() != null) && (getSponsorType().equals(castOther.getSponsorType()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  95 */     int result = 17;
/*     */ 
/*  97 */     result = 37 * result + (getCampsegId() == null ? 0 : getCampsegId().hashCode());
/*     */ 
/*  99 */     result = 37 * result + (getSponorUserId() == null ? 0 : getSponorUserId().hashCode());
/*     */ 
/* 103 */     result = 37 * result + (getActorUserId() == null ? 0 : getActorUserId().hashCode());
/*     */ 
/* 107 */     result = 37 * result + (getSponsorType() == null ? 0 : getSponsorType().hashCode());
/*     */ 
/* 111 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveAdviceId
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.model;

import java.util.Date;

/**
 * MtlApproveAuth entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class MtlApproveAuth implements java.io.Serializable {

	// Fields

	private MtlApproveAuthId id;

	private String consignorUserid;

	private Short authFlag;

	private String beginTime;

	private String endTime;

	private Date updateTime;

	// Constructors

	/** default constructor */
	public MtlApproveAuth() {
		id = new MtlApproveAuthId();
	}

	/** minimal constructor */
	public MtlApproveAuth(MtlApproveAuthId id, String consignorUserid, Short authFlag, Date updateTime) {
		this.id = id;
		this.consignorUserid = consignorUserid;
		this.authFlag = authFlag;
		this.updateTime = updateTime;
	}

	/** full constructor */
	public MtlApproveAuth(MtlApproveAuthId id, String consignorUserid, Short authFlag, String beginTime, String endTime, Date updateTime) {
		this.id = id;
		this.consignorUserid = consignorUserid;
		this.authFlag = authFlag;
		this.beginTime = beginTime;
		this.endTime = endTime;
		this.updateTime = updateTime;
	}

	// Property accessors

	public MtlApproveAuthId getId() {
		return this.id;
	}

	public void setId(MtlApproveAuthId id) {
		this.id = id;
	}

	public String getConsignorUserid() {
		return this.consignorUserid;
	}

	public void setConsignorUserid(String consignorUserid) {
		this.consignorUserid = consignorUserid;
	}

	public Short getAuthFlag() {
		return this.authFlag;
	}

	public void setAuthFlag(Short authFlag) {
		this.authFlag = authFlag;
	}

	public String getBeginTime() {
		return this.beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return this.endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}

/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlApproveAuthId
/*    */   implements Serializable
/*    */ {
/*    */   private String authUserid;
/*    */   private Short authType;
/*    */ 
/*    */   public MtlApproveAuthId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MtlApproveAuthId(String authUserid, Short authType)
/*    */   {
/* 26 */     this.authUserid = authUserid;
/* 27 */     this.authType = authType;
/*    */   }
/*    */ 
/*    */   public String getAuthUserid()
/*    */   {
/* 33 */     return this.authUserid;
/*    */   }
/*    */ 
/*    */   public void setAuthUserid(String authUserid) {
/* 37 */     this.authUserid = authUserid;
/*    */   }
/*    */ 
/*    */   public Short getAuthType() {
/* 41 */     return this.authType;
/*    */   }
/*    */ 
/*    */   public void setAuthType(Short authType) {
/* 45 */     this.authType = authType;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 49 */     if (this == other)
/* 50 */       return true;
/* 51 */     if (other == null)
/* 52 */       return false;
/* 53 */     if (!(other instanceof MtlApproveAuthId))
/* 54 */       return false;
/* 55 */     MtlApproveAuthId castOther = (MtlApproveAuthId)other;
/*    */ 
/* 57 */     return ((getAuthUserid() == castOther.getAuthUserid()) || ((getAuthUserid() != null) && (castOther.getAuthUserid() != null) && (getAuthUserid().equals(castOther.getAuthUserid())))) && ((getAuthType() == castOther.getAuthType()) || ((getAuthType() != null) && (castOther.getAuthType() != null) && (getAuthType().equals(castOther.getAuthType()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 62 */     int result = 17;
/*    */ 
/* 64 */     result = 37 * result + (getAuthUserid() == null ? 0 : getAuthUserid().hashCode());
/* 65 */     result = 37 * result + (getAuthType() == null ? 0 : getAuthType().hashCode());
/* 66 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveAuthId
 * JD-Core Version:    0.6.2
 */
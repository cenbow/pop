package com.ai.bdx.frame.approval.model;


/**
 * MtlApproveAuthId entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class MtlApproveAuthId implements java.io.Serializable {

	// Fields

	private String authUserid;

	private Short authType;

	// Constructors

	/** default constructor */
	public MtlApproveAuthId() {
	}

	/** full constructor */
	public MtlApproveAuthId(String authUserid, Short authType) {
		this.authUserid = authUserid;
		this.authType = authType;
	}

	// Property accessors

	public String getAuthUserid() {
		return this.authUserid;
	}

	public void setAuthUserid(String authUserid) {
		this.authUserid = authUserid;
	}

	public Short getAuthType() {
		return this.authType;
	}

	public void setAuthType(Short authType) {
		this.authType = authType;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof MtlApproveAuthId))
			return false;
		MtlApproveAuthId castOther = (MtlApproveAuthId) other;

		return ((this.getAuthUserid() == castOther.getAuthUserid()) || (this.getAuthUserid() != null && castOther.getAuthUserid() != null && this.getAuthUserid().equals(castOther.getAuthUserid())))
				&& ((this.getAuthType() == castOther.getAuthType()) || (this.getAuthType() != null && castOther.getAuthType() != null && this.getAuthType().equals(castOther.getAuthType())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getAuthUserid() == null ? 0 : this.getAuthUserid().hashCode());
		result = 37 * result + (getAuthType() == null ? 0 : this.getAuthType().hashCode());
		return result;
	}

}

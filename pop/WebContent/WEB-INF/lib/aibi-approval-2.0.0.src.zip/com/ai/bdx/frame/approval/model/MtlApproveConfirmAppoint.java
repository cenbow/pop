/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlApproveConfirmAppoint
/*    */   implements Serializable
/*    */ {
/*    */   private String userId;
/*    */   private String userName;
/*    */   private Integer orderSeq;
/*    */ 
/*    */   public String getUserId()
/*    */   {
/* 13 */     return this.userId;
/*    */   }
/*    */   public void setUserId(String userId) {
/* 16 */     this.userId = userId;
/*    */   }
/*    */   public String getUserName() {
/* 19 */     return this.userName;
/*    */   }
/*    */   public void setUserName(String userName) {
/* 22 */     this.userName = userName;
/*    */   }
/*    */   public Integer getOrderSeq() {
/* 25 */     return this.orderSeq;
/*    */   }
/*    */   public void setOrderSeq(Integer orderSeq) {
/* 28 */     this.orderSeq = orderSeq;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveConfirmAppoint
 * JD-Core Version:    0.6.2
 */
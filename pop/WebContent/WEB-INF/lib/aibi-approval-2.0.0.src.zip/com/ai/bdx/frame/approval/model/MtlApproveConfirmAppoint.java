package com.ai.bdx.frame.approval.model;

import java.io.Serializable;

public class MtlApproveConfirmAppoint implements Serializable {
	
	private String userId;
	private String userName;
	private Integer orderSeq;
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getOrderSeq() {
		return orderSeq;
	}
	public void setOrderSeq(Integer orderSeq) {
		this.orderSeq = orderSeq;
	}
}

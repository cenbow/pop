package com.ai.bdx.frame.approval.model;

import java.io.Serializable;
import java.util.Date;

import com.asiainfo.biframe.utils.string.StringUtil;

/**
 * A class that represents a row in the 'IR_INDI_TYPE' table. 
 * This class may be customized as it is never re-generated 
 * after being created.
 */
public class MtlApproveConfirmList implements Serializable {
	private MtlApproveConfirmListId id;

	private java.lang.Short confirmFlag;

	private java.lang.String forecastDate;

	private java.lang.String remindDate;

	private java.lang.String confirmAdvice;

	private java.lang.String confirmExplain;
	
	private java.lang.String confirmUserid;

	private Short approveToken;

	private Short authFlag;
	

	private Date confirmTime = new Date();
	
	private String campsegRootid;

	/**
	 * Simple constructor of AbstractIrIndiType instances.
	 */
	public MtlApproveConfirmList() {
		id = new MtlApproveConfirmListId();
	}

	/**
	 * Constructor of AbstractIrIndiType instances given a simple primary key.
	 * @param idType
	 */
	public MtlApproveConfirmList(MtlApproveConfirmListId id) {
		this.setId(id);
	}

	public MtlApproveConfirmListId getId() {
		return this.id;
	}

	public void setId(MtlApproveConfirmListId id) {
		this.id = id;
	}

	public java.lang.Short getConfirmFlag() {
		return this.confirmFlag;
	}

	public void setConfirmFlag(java.lang.Short confirmFlag) {
		this.confirmFlag = confirmFlag;
	}

	public java.lang.String getConfirmAdvice() {
		if(StringUtil.isNotEmpty(confirmAdvice) && ! "null".equalsIgnoreCase(confirmAdvice)){
			return this.confirmAdvice;
		}else{
			return "";
		}
	}

	public void setConfirmAdvice(java.lang.String confirmAdvice) {
		this.confirmAdvice = confirmAdvice;
	}

	//    public java.lang.String getResourceName()
	//    {
	//        return this.resourceName;
	//    }
	//    public void setResourceName(java.lang.String resourceName)
	//    {
	//        this.resourceName = resourceName;
	//    }
	public java.lang.String getForecastDate() {
		return this.forecastDate;
	}

	public void setForecastDate(java.lang.String forecastDate) {
		this.forecastDate = forecastDate;
	}

	public java.lang.String getRemindDate() {
		return this.remindDate;
	}

	public void setRemindDate(java.lang.String remindDate) {
		this.remindDate = remindDate;
	}

	/**
	 * @return confirmTime
	 */
	public Date getConfirmTime() {
		return this.confirmTime;
	}

	/**
	 * @param confirmTime 要设置的 confirmTime
	 */
	public void setConfirmTime(Date confirmTime) {
		this.confirmTime = confirmTime;
	}

	/**
	 * @return confirmExplain
	 */
	public java.lang.String getConfirmExplain() {
		return confirmExplain;
	}

	/**
	 * @param confirmExplain 要设置的 confirmExplain
	 */
	public void setConfirmExplain(java.lang.String confirmExplain) {
		this.confirmExplain = confirmExplain;
	}

	public Short getApproveToken() {
		return approveToken;
	}

	public void setApproveToken(Short approveToken) {
		this.approveToken = approveToken;
	}

	/**
	 * @return authFlag
	 */
	public Short getAuthFlag() {
		return authFlag;
	}

	/**
	 * @param authFlag 要设置的 authFlag
	 */
	public void setAuthFlag(Short authFlag) {
		this.authFlag = authFlag;
	}

	public java.lang.String getConfirmUserid() {
		return confirmUserid;
	}

	public void setConfirmUserid(java.lang.String confirmUserid) {
		this.confirmUserid = confirmUserid;
	}

	public String getCampsegRootid() {
		return campsegRootid;
	}

	public void setCampsegRootid(String campsegRootid) {
		this.campsegRootid = campsegRootid;
	}	
}

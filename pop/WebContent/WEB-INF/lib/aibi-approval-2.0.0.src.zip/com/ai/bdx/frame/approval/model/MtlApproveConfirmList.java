/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class MtlApproveConfirmList
/*     */   implements Serializable
/*     */ {
/*     */   private MtlApproveConfirmListId id;
/*     */   private Short confirmFlag;
/*     */   private String forecastDate;
/*     */   private String remindDate;
/*     */   private String confirmAdvice;
/*     */   private String confirmExplain;
/*     */   private String confirmUserid;
/*     */   private Short approveToken;
/*     */   private Short authFlag;
/*  33 */   private Date confirmTime = new Date();
/*     */   private String campsegRootid;
/*     */ 
/*     */   public MtlApproveConfirmList()
/*     */   {
/*  41 */     this.id = new MtlApproveConfirmListId();
/*     */   }
/*     */ 
/*     */   public MtlApproveConfirmList(MtlApproveConfirmListId id)
/*     */   {
/*  49 */     setId(id);
/*     */   }
/*     */ 
/*     */   public MtlApproveConfirmListId getId() {
/*  53 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(MtlApproveConfirmListId id) {
/*  57 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public Short getConfirmFlag() {
/*  61 */     return this.confirmFlag;
/*     */   }
/*     */ 
/*     */   public void setConfirmFlag(Short confirmFlag) {
/*  65 */     this.confirmFlag = confirmFlag;
/*     */   }
/*     */ 
/*     */   public String getConfirmAdvice() {
/*  69 */     if ((StringUtil.isNotEmpty(this.confirmAdvice)) && (!"null".equalsIgnoreCase(this.confirmAdvice))) {
/*  70 */       return this.confirmAdvice;
/*     */     }
/*  72 */     return "";
/*     */   }
/*     */ 
/*     */   public void setConfirmAdvice(String confirmAdvice)
/*     */   {
/*  77 */     this.confirmAdvice = confirmAdvice;
/*     */   }
/*     */ 
/*     */   public String getForecastDate()
/*     */   {
/*  89 */     return this.forecastDate;
/*     */   }
/*     */ 
/*     */   public void setForecastDate(String forecastDate) {
/*  93 */     this.forecastDate = forecastDate;
/*     */   }
/*     */ 
/*     */   public String getRemindDate() {
/*  97 */     return this.remindDate;
/*     */   }
/*     */ 
/*     */   public void setRemindDate(String remindDate) {
/* 101 */     this.remindDate = remindDate;
/*     */   }
/*     */ 
/*     */   public Date getConfirmTime()
/*     */   {
/* 108 */     return this.confirmTime;
/*     */   }
/*     */ 
/*     */   public void setConfirmTime(Date confirmTime)
/*     */   {
/* 115 */     this.confirmTime = confirmTime;
/*     */   }
/*     */ 
/*     */   public String getConfirmExplain()
/*     */   {
/* 122 */     return this.confirmExplain;
/*     */   }
/*     */ 
/*     */   public void setConfirmExplain(String confirmExplain)
/*     */   {
/* 129 */     this.confirmExplain = confirmExplain;
/*     */   }
/*     */ 
/*     */   public Short getApproveToken() {
/* 133 */     return this.approveToken;
/*     */   }
/*     */ 
/*     */   public void setApproveToken(Short approveToken) {
/* 137 */     this.approveToken = approveToken;
/*     */   }
/*     */ 
/*     */   public Short getAuthFlag()
/*     */   {
/* 144 */     return this.authFlag;
/*     */   }
/*     */ 
/*     */   public void setAuthFlag(Short authFlag)
/*     */   {
/* 151 */     this.authFlag = authFlag;
/*     */   }
/*     */ 
/*     */   public String getConfirmUserid() {
/* 155 */     return this.confirmUserid;
/*     */   }
/*     */ 
/*     */   public void setConfirmUserid(String confirmUserid) {
/* 159 */     this.confirmUserid = confirmUserid;
/*     */   }
/*     */ 
/*     */   public String getCampsegRootid() {
/* 163 */     return this.campsegRootid;
/*     */   }
/*     */ 
/*     */   public void setCampsegRootid(String campsegRootid) {
/* 167 */     this.campsegRootid = campsegRootid;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveConfirmList
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.model;

import java.io.Serializable;

/**
 * A class that represents a row in the 'IR_INDI_TYPE' table. 
 * This class may be customized as it is never re-generated 
 * after being created.
 */
public class MtlApproveConfirmListId implements Serializable {
	private String campsegId;

	private java.lang.Integer resourceId;

	private java.lang.String confirmUserid;

	private java.lang.String confirmId;

	private String approveFlowId;

	private Short approveSeq;

	private Short approveLevel;
	
	private Short channelNo;
	
	public Short getChannelNo() {
		return channelNo;
	}

	public void setChannelNo(Short channelNo) {
		this.channelNo = channelNo;
	}

	/**
	 * Simple constructor of AbstractIrIndiType instances.
	 */
	public MtlApproveConfirmListId() {
	}

	/**
	 * Constructor of AbstractIrIndiType instances given a simple primary key.
	 * @param idType
	 */
	public MtlApproveConfirmListId(java.lang.String campsegId, java.lang.Integer resourceId, java.lang.String confirmUserid, String approveFlowId, Short approveLevel, Short approveSeq) {
		this.setCampsegId(campsegId);
		this.setResourceId(resourceId);
		this.setConfirmUserid(confirmUserid);
		this.setApproveFlowId(approveFlowId);
		this.setApproveLevel(approveLevel);
		this.setApproveSeq(approveSeq);
	}

	public java.lang.String getCampsegId() {
		return this.campsegId;
	}

	public void setCampsegId(java.lang.String campsegId) {
		this.campsegId = campsegId;
	}

	public java.lang.Integer getResourceId() {
		return this.resourceId;
	}

	public void setResourceId(java.lang.Integer resourceId) {
		this.resourceId = resourceId;
	}

	public java.lang.String getConfirmUserid() {
		return this.confirmUserid;
	}

	public void setConfirmUserid(java.lang.String confirmUserid) {
		this.confirmUserid = confirmUserid;
	}

	public java.lang.String getConfirmId() {
		return this.confirmId;
	}

	public void setConfirmId(java.lang.String confirmId) {
		this.confirmId = confirmId;
	}

	/**
	 * Implementation of the equals comparison on the basis of equality of the primary key values.
	 * @param rhs
	 * @return boolean
	 */
	public boolean equals(Object rhs) {
		if (rhs == null)
			return false;
		if (!(rhs instanceof MtlApproveConfirmListId))
			return false;
		MtlApproveConfirmListId that = (MtlApproveConfirmListId) rhs;
		if (this.getCampsegId() == null || that.getCampsegId() == null || this.getConfirmUserid() == null || that.getConfirmUserid() == null || this.getResourceId() == null || that.getResourceId() == null)
			return false;
		return (this.getCampsegId().equals(that.getCampsegId()) && this.getConfirmUserid().equals(that.getConfirmUserid()) && this.getResourceId().equals(that.getResourceId()));
	}

	public int hashCode() {
		int result = 17;
		result = 37 * result + (getCampsegId() == null ? 0 : this.getCampsegId().hashCode());
		result = 37 * result + (getResourceId() == null ? 0 : this.getResourceId().hashCode());
		result = 37 * result + (getConfirmUserid() == null ? 0 : this.getConfirmUserid().hashCode());
		return result;
	}

	public String getApproveFlowId() {
		return this.approveFlowId;
	}

	public void setApproveFlowId(String approveFlowId) {
		this.approveFlowId = approveFlowId;
	}

	public Short getApproveLevel() {
		return this.approveLevel;
	}

	public void setApproveLevel(Short approveLevel) {
		this.approveLevel = approveLevel;
	}

	public Short getApproveSeq() {
		return this.approveSeq;
	}

	public void setApproveSeq(Short approveSeq) {
		this.approveSeq = approveSeq;
	}


}

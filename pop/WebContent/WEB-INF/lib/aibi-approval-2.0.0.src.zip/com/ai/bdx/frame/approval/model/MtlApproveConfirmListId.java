/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class MtlApproveConfirmListId
/*     */   implements Serializable
/*     */ {
/*     */   private String campsegId;
/*     */   private Integer resourceId;
/*     */   private String confirmUserid;
/*     */   private String confirmId;
/*     */   private String approveFlowId;
/*     */   private Short approveSeq;
/*     */   private Short approveLevel;
/*     */   private Short channelNo;
/*     */ 
/*     */   public Short getChannelNo()
/*     */   {
/*  28 */     return this.channelNo;
/*     */   }
/*     */ 
/*     */   public void setChannelNo(Short channelNo) {
/*  32 */     this.channelNo = channelNo;
/*     */   }
/*     */ 
/*     */   public MtlApproveConfirmListId()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlApproveConfirmListId(String campsegId, Integer resourceId, String confirmUserid, String approveFlowId, Short approveLevel, Short approveSeq)
/*     */   {
/*  46 */     setCampsegId(campsegId);
/*  47 */     setResourceId(resourceId);
/*  48 */     setConfirmUserid(confirmUserid);
/*  49 */     setApproveFlowId(approveFlowId);
/*  50 */     setApproveLevel(approveLevel);
/*  51 */     setApproveSeq(approveSeq);
/*     */   }
/*     */ 
/*     */   public String getCampsegId() {
/*  55 */     return this.campsegId;
/*     */   }
/*     */ 
/*     */   public void setCampsegId(String campsegId) {
/*  59 */     this.campsegId = campsegId;
/*     */   }
/*     */ 
/*     */   public Integer getResourceId() {
/*  63 */     return this.resourceId;
/*     */   }
/*     */ 
/*     */   public void setResourceId(Integer resourceId) {
/*  67 */     this.resourceId = resourceId;
/*     */   }
/*     */ 
/*     */   public String getConfirmUserid() {
/*  71 */     return this.confirmUserid;
/*     */   }
/*     */ 
/*     */   public void setConfirmUserid(String confirmUserid) {
/*  75 */     this.confirmUserid = confirmUserid;
/*     */   }
/*     */ 
/*     */   public String getConfirmId() {
/*  79 */     return this.confirmId;
/*     */   }
/*     */ 
/*     */   public void setConfirmId(String confirmId) {
/*  83 */     this.confirmId = confirmId;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object rhs)
/*     */   {
/*  92 */     if (rhs == null)
/*  93 */       return false;
/*  94 */     if (!(rhs instanceof MtlApproveConfirmListId))
/*  95 */       return false;
/*  96 */     MtlApproveConfirmListId that = (MtlApproveConfirmListId)rhs;
/*  97 */     if ((getCampsegId() == null) || (that.getCampsegId() == null) || (getConfirmUserid() == null) || (that.getConfirmUserid() == null) || (getResourceId() == null) || (that.getResourceId() == null))
/*  98 */       return false;
/*  99 */     return (getCampsegId().equals(that.getCampsegId())) && (getConfirmUserid().equals(that.getConfirmUserid())) && (getResourceId().equals(that.getResourceId()));
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 103 */     int result = 17;
/* 104 */     result = 37 * result + (getCampsegId() == null ? 0 : getCampsegId().hashCode());
/* 105 */     result = 37 * result + (getResourceId() == null ? 0 : getResourceId().hashCode());
/* 106 */     result = 37 * result + (getConfirmUserid() == null ? 0 : getConfirmUserid().hashCode());
/* 107 */     return result;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowId() {
/* 111 */     return this.approveFlowId;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowId(String approveFlowId) {
/* 115 */     this.approveFlowId = approveFlowId;
/*     */   }
/*     */ 
/*     */   public Short getApproveLevel() {
/* 119 */     return this.approveLevel;
/*     */   }
/*     */ 
/*     */   public void setApproveLevel(Short approveLevel) {
/* 123 */     this.approveLevel = approveLevel;
/*     */   }
/*     */ 
/*     */   public Short getApproveSeq() {
/* 127 */     return this.approveSeq;
/*     */   }
/*     */ 
/*     */   public void setApproveSeq(Short approveSeq) {
/* 131 */     this.approveSeq = approveSeq;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveConfirmListId
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlApproveConsignor
/*    */   implements Serializable
/*    */ {
/*    */   private Integer authId;
/*    */   private String authUserid;
/*    */   private String consignorUserid;
/*    */ 
/*    */   public Integer getAuthId()
/*    */   {
/* 25 */     return this.authId;
/*    */   }
/*    */ 
/*    */   public void setAuthId(Integer authId) {
/* 29 */     this.authId = authId;
/*    */   }
/*    */ 
/*    */   public String getAuthUserid() {
/* 33 */     return this.authUserid;
/*    */   }
/*    */ 
/*    */   public void setAuthUserid(String authUserid) {
/* 37 */     this.authUserid = authUserid;
/*    */   }
/*    */ 
/*    */   public String getConsignorUserid() {
/* 41 */     return this.consignorUserid;
/*    */   }
/*    */ 
/*    */   public void setConsignorUserid(String consignorUserid) {
/* 45 */     this.consignorUserid = consignorUserid;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveConsignor
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MtlApproveFlowDef
/*     */   implements Serializable
/*     */ {
/*     */   private String approveFlowId;
/*     */   private String createUserid;
/*     */   private String cityid;
/*     */   private String approveFlowName;
/*     */   private String confirmId;
/*     */   private Date createTime;
/*     */   private Short approveFlowLevelCnt;
/*     */   private Set approveFlowLevels;
/*     */   private String approveFlowDefStr;
/*     */   private short approveFlowAccessToken;
/*     */   private String firstApproveUser;
/*     */   private String deptId;
/*     */   private String flowType;
/*     */ 
/*     */   public short getApproveFlowAccessToken()
/*     */   {
/*  44 */     return this.approveFlowAccessToken;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowAccessToken(short approveFlowAccessToken)
/*     */   {
/*  52 */     this.approveFlowAccessToken = approveFlowAccessToken;
/*     */   }
/*     */ 
/*     */   public MtlApproveFlowDef()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlApproveFlowDef(String approveFlowId, String createUserid, String approveFlowName)
/*     */   {
/*  62 */     this.approveFlowId = approveFlowId;
/*  63 */     this.createUserid = createUserid;
/*  64 */     this.approveFlowName = approveFlowName;
/*     */   }
/*     */ 
/*     */   public MtlApproveFlowDef(String approveFlowId, String createUserid, String cityid, String approveFlowName)
/*     */   {
/*  70 */     this.approveFlowId = approveFlowId;
/*  71 */     this.createUserid = createUserid;
/*  72 */     this.cityid = cityid;
/*  73 */     this.approveFlowName = approveFlowName;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowId()
/*     */   {
/*  79 */     return this.approveFlowId;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowId(String approveFlowId) {
/*  83 */     this.approveFlowId = approveFlowId;
/*     */   }
/*     */ 
/*     */   public String getCreateUserid() {
/*  87 */     return this.createUserid;
/*     */   }
/*     */ 
/*     */   public void setCreateUserid(String createUserid) {
/*  91 */     this.createUserid = createUserid;
/*     */   }
/*     */ 
/*     */   public String getConfirmId() {
/*  95 */     return this.confirmId;
/*     */   }
/*     */ 
/*     */   public void setConfirmId(String confirmId) {
/*  99 */     this.confirmId = confirmId;
/*     */   }
/*     */ 
/*     */   public String getCityid() {
/* 103 */     return this.cityid;
/*     */   }
/*     */ 
/*     */   public void setCityid(String cityid) {
/* 107 */     this.cityid = cityid;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowName() {
/* 111 */     return this.approveFlowName;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowName(String approveFlowName) {
/* 115 */     this.approveFlowName = approveFlowName;
/*     */   }
/*     */ 
/*     */   public Date getCreateTime() {
/* 119 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(Date createTime) {
/* 123 */     this.createTime = createTime;
/*     */   }
/*     */ 
/*     */   public Set getApproveFlowLevels() {
/* 127 */     return this.approveFlowLevels;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowLevels(Set approveFlowLevels) {
/* 131 */     this.approveFlowLevels = approveFlowLevels;
/*     */   }
/*     */ 
/*     */   public String getApproveFlowDefStr() {
/* 135 */     return this.approveFlowDefStr;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowDefStr(String approveFlowDefStr) {
/* 139 */     this.approveFlowDefStr = approveFlowDefStr;
/*     */   }
/*     */ 
/*     */   public Short getApproveFlowLevelCnt() {
/* 143 */     return this.approveFlowLevelCnt;
/*     */   }
/*     */ 
/*     */   public void setApproveFlowLevelCnt(Short approveFlowLevelCnt) {
/* 147 */     this.approveFlowLevelCnt = approveFlowLevelCnt;
/*     */   }
/*     */ 
/*     */   public String getFirstApproveUser() {
/* 151 */     return this.firstApproveUser;
/*     */   }
/*     */ 
/*     */   public void setFirstApproveUser(String firstApproveUser) {
/* 155 */     this.firstApproveUser = firstApproveUser;
/*     */   }
/*     */ 
/*     */   public String getDeptId() {
/* 159 */     return this.deptId;
/*     */   }
/*     */ 
/*     */   public void setDeptId(String deptId) {
/* 163 */     this.deptId = deptId;
/*     */   }
/*     */ 
/*     */   public String getFlowType() {
/* 167 */     return this.flowType;
/*     */   }
/*     */ 
/*     */   public void setFlowType(String flowType) {
/* 171 */     this.flowType = flowType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveFlowDef
 * JD-Core Version:    0.6.2
 */
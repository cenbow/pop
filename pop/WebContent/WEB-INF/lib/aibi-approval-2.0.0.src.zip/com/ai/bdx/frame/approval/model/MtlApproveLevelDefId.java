/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlApproveLevelDefId
/*    */   implements Serializable
/*    */ {
/*    */   private Integer approveLevel;
/*    */   private String approveFlowId;
/*    */   private Integer approveObjType;
/*    */   private String approveObjId;
/*    */ 
/*    */   public MtlApproveLevelDefId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MtlApproveLevelDefId(Integer approveLevel, String approveFlowId, Integer approveObjType, String approveObjId)
/*    */   {
/* 28 */     this.approveLevel = approveLevel;
/* 29 */     this.approveFlowId = approveFlowId;
/* 30 */     this.approveObjType = approveObjType;
/* 31 */     this.approveObjId = approveObjId;
/*    */   }
/*    */ 
/*    */   public Integer getApproveLevel()
/*    */   {
/* 37 */     return this.approveLevel;
/*    */   }
/*    */ 
/*    */   public void setApproveLevel(Integer approveLevel) {
/* 41 */     this.approveLevel = approveLevel;
/*    */   }
/*    */ 
/*    */   public String getApproveFlowId() {
/* 45 */     return this.approveFlowId;
/*    */   }
/*    */ 
/*    */   public Integer getApproveObjType()
/*    */   {
/* 51 */     return this.approveObjType;
/*    */   }
/*    */ 
/*    */   public void setApproveObjType(Integer approveObjType) {
/* 55 */     this.approveObjType = approveObjType;
/*    */   }
/*    */ 
/*    */   public String getApproveObjId() {
/* 59 */     return this.approveObjId;
/*    */   }
/*    */ 
/*    */   public void setApproveObjId(String approveObjId) {
/* 63 */     this.approveObjId = approveObjId;
/*    */   }
/*    */ 
/*    */   public void setApproveFlowId(String approveFlowId) {
/* 67 */     this.approveFlowId = approveFlowId;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 72 */     int result = 17;
/* 73 */     result = 37 * result + (getApproveLevel() == null ? 0 : getApproveLevel().hashCode());
/* 74 */     result = 37 * result + (getApproveFlowId() == null ? 0 : getApproveFlowId().hashCode());
/* 75 */     result = 37 * result + (getApproveObjType() == null ? 0 : getApproveObjType().hashCode());
/* 76 */     result = 37 * result + (getApproveObjId() == null ? 0 : getApproveObjId().hashCode());
/* 77 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveLevelDefId
 * JD-Core Version:    0.6.2
 */
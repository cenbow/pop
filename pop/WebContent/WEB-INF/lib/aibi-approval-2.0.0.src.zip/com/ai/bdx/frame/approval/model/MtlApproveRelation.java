/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class MtlApproveRelation
/*     */   implements Serializable
/*     */ {
/*  11 */   private MtlApproveRelationKey id = new MtlApproveRelationKey();
/*     */   private Integer positionId;
/*     */   private String approveCreateUserid;
/*     */   private Date createTime;
/*     */   private String approveUseridEmail;
/*     */   private String approveUseridMsisdn;
/*     */   private String cityid;
/*     */   private String beforeCreateUserid;
/*     */   private String beforeApproveUserid;
/*     */   private String userid;
/*     */ 
/*     */   public MtlApproveRelation()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlApproveRelation(MtlApproveRelationKey id)
/*     */   {
/*  47 */     setId(id);
/*     */   }
/*     */ 
/*     */   public MtlApproveRelationKey getId()
/*     */   {
/*  55 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(MtlApproveRelationKey id)
/*     */   {
/*  63 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getApproveCreateUserid()
/*     */   {
/*  71 */     return this.approveCreateUserid;
/*     */   }
/*     */ 
/*     */   public void setApproveCreateUserid(String approveCreateUserid)
/*     */   {
/*  79 */     this.approveCreateUserid = approveCreateUserid;
/*     */   }
/*     */ 
/*     */   public Date getCreateTime()
/*     */   {
/*  87 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(Date createTime)
/*     */   {
/*  95 */     this.createTime = createTime;
/*     */   }
/*     */ 
/*     */   public Integer getPositionId()
/*     */   {
/* 103 */     return this.positionId;
/*     */   }
/*     */ 
/*     */   public void setPositionId(Integer positionId)
/*     */   {
/* 111 */     this.positionId = positionId;
/*     */   }
/*     */ 
/*     */   public String getApproveUseridEmail()
/*     */   {
/* 119 */     return this.approveUseridEmail;
/*     */   }
/*     */ 
/*     */   public void setApproveUseridEmail(String approveUseridEmail)
/*     */   {
/* 127 */     this.approveUseridEmail = approveUseridEmail;
/*     */   }
/*     */ 
/*     */   public String getApproveUseridMsisdn()
/*     */   {
/* 135 */     return this.approveUseridMsisdn;
/*     */   }
/*     */ 
/*     */   public void setApproveUseridMsisdn(String approveUseridMsisdn)
/*     */   {
/* 143 */     this.approveUseridMsisdn = approveUseridMsisdn;
/*     */   }
/*     */ 
/*     */   public void setCityid(String cityid) {
/* 147 */     this.cityid = cityid;
/*     */   }
/*     */ 
/*     */   public String getCityid() {
/* 151 */     return this.cityid;
/*     */   }
/*     */ 
/*     */   public void setBeforeCreateUserid(String beforeCreateUserid) {
/* 155 */     this.beforeCreateUserid = beforeCreateUserid;
/*     */   }
/*     */ 
/*     */   public String getBeforeCreateUserid() {
/* 159 */     return this.beforeCreateUserid;
/*     */   }
/*     */ 
/*     */   public void setBeforeApproveUserid(String beforeApproveUserid) {
/* 163 */     this.beforeApproveUserid = beforeApproveUserid;
/*     */   }
/*     */ 
/*     */   public String getBeforeApproveUserid() {
/* 167 */     return this.beforeApproveUserid;
/*     */   }
/*     */ 
/*     */   public void setUserid(String userid) {
/* 171 */     this.userid = userid;
/*     */   }
/*     */ 
/*     */   public String getUserid() {
/* 175 */     return this.userid;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveRelation
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlApproveRelationKey
/*    */   implements Serializable
/*    */ {
/*    */   private Integer deptId;
/*    */   private String approveUserid;
/*    */ 
/*    */   public Integer getDeptId()
/*    */   {
/* 20 */     return this.deptId;
/*    */   }
/*    */ 
/*    */   public void setDeptId(Integer deptId) {
/* 24 */     this.deptId = deptId;
/*    */   }
/*    */ 
/*    */   public String getApproveUserid() {
/* 28 */     return this.approveUserid;
/*    */   }
/*    */ 
/*    */   public void setApproveUserid(String approveUserid) {
/* 32 */     this.approveUserid = approveUserid;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object rhs)
/*    */   {
/* 41 */     if (rhs == null)
/* 42 */       return false;
/* 43 */     if (!(rhs instanceof MtlApproveRelationKey))
/* 44 */       return false;
/* 45 */     MtlApproveRelationKey that = (MtlApproveRelationKey)rhs;
/* 46 */     if ((getDeptId() == null) || (that.getDeptId() == null)) {
/* 47 */       return false;
/*    */     }
/* 49 */     if (!getDeptId().equals(that.getDeptId())) {
/* 50 */       return false;
/*    */     }
/* 52 */     if ((getApproveUserid() == null) || (that.getApproveUserid() == null)) {
/* 53 */       return false;
/*    */     }
/* 55 */     if (!getApproveUserid().equals(that.getApproveUserid())) {
/* 56 */       return false;
/*    */     }
/* 58 */     return true;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 62 */     int result = 17;
/*    */ 
/* 64 */     result = 37 * result + (getDeptId() == null ? 0 : getDeptId().hashCode());
/* 65 */     result = 37 * result + (getApproveUserid() == null ? 0 : getApproveUserid().hashCode());
/* 66 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveRelationKey
 * JD-Core Version:    0.6.2
 */
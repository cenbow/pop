/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlApproveResourceType
/*    */   implements Serializable
/*    */ {
/*    */   private Integer resourceId;
/*    */   private String resourceName;
/*    */   private String resourceDesc;
/*    */   private Short resourceFlag;
/*    */ 
/*    */   public Integer getResourceId()
/*    */   {
/* 19 */     return this.resourceId;
/*    */   }
/*    */ 
/*    */   public void setResourceId(Integer resourceId) {
/* 23 */     this.resourceId = resourceId;
/*    */   }
/*    */ 
/*    */   public String getResourceName() {
/* 27 */     return this.resourceName;
/*    */   }
/*    */ 
/*    */   public void setResourceName(String resourceName) {
/* 31 */     this.resourceName = resourceName;
/*    */   }
/*    */ 
/*    */   public String getResourceDesc() {
/* 35 */     return this.resourceDesc;
/*    */   }
/*    */ 
/*    */   public void setResourceDesc(String resourceDesc) {
/* 39 */     this.resourceDesc = resourceDesc;
/*    */   }
/*    */ 
/*    */   public Short getResourceFlag() {
/* 43 */     return this.resourceFlag;
/*    */   }
/*    */ 
/*    */   public void setResourceFlag(Short resourceFlag) {
/* 47 */     this.resourceFlag = resourceFlag;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveResourceType
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.model;

import java.io.Serializable;


public class MtlApproveResourceType implements Serializable {
	private java.lang.Integer resourceId;

	private java.lang.String resourceName;

	private java.lang.String resourceDesc;

	private java.lang.Short resourceFlag;

	public MtlApproveResourceType() {
	}

	public java.lang.Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(java.lang.Integer resourceId) {
		this.resourceId = resourceId;
	}

	public java.lang.String getResourceName() {
		return this.resourceName;
	}

	public void setResourceName(java.lang.String resourceName) {
		this.resourceName = resourceName;
	}

	public java.lang.String getResourceDesc() {
		return this.resourceDesc;
	}

	public void setResourceDesc(java.lang.String resourceDesc) {
		this.resourceDesc = resourceDesc;
	}

	public java.lang.Short getResourceFlag() {
		return resourceFlag;
	}

	public void setResourceFlag(java.lang.Short resourceFlag) {
		this.resourceFlag = resourceFlag;
	}

}

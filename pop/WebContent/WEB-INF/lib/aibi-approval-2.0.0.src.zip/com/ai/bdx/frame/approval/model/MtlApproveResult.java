/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class MtlApproveResult
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private MtlApproveResultId id;
/*    */   private String approveAdv;
/*    */   private Date approveTime;
/*    */   private Short approveResult;
/*    */   private Short approveLevel;
/*    */ 
/*    */   public MtlApproveResult()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MtlApproveResult(MtlApproveResultId id, Date approveTime)
/*    */   {
/* 37 */     this.id = id;
/* 38 */     this.approveTime = approveTime;
/*    */   }
/*    */ 
/*    */   public MtlApproveResult(MtlApproveResultId id, String approveAdv, Date approveTime, Short approveResult, Short approveLevel)
/*    */   {
/* 43 */     this.id = id;
/* 44 */     this.approveAdv = approveAdv;
/* 45 */     this.approveTime = approveTime;
/* 46 */     this.approveResult = approveResult;
/* 47 */     this.approveLevel = approveLevel;
/*    */   }
/*    */ 
/*    */   public MtlApproveResultId getId()
/*    */   {
/* 53 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(MtlApproveResultId id) {
/* 57 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getApproveAdv() {
/* 61 */     return this.approveAdv;
/*    */   }
/*    */ 
/*    */   public void setApproveAdv(String approveAdv) {
/* 65 */     this.approveAdv = approveAdv;
/*    */   }
/*    */ 
/*    */   public Date getApproveTime() {
/* 69 */     return this.approveTime;
/*    */   }
/*    */ 
/*    */   public void setApproveTime(Date approveTime) {
/* 73 */     this.approveTime = approveTime;
/*    */   }
/*    */ 
/*    */   public Short getApproveResult() {
/* 77 */     return this.approveResult;
/*    */   }
/*    */ 
/*    */   public void setApproveResult(Short approveResult) {
/* 81 */     this.approveResult = approveResult;
/*    */   }
/*    */ 
/*    */   public Short getApproveLevel() {
/* 85 */     return this.approveLevel;
/*    */   }
/*    */ 
/*    */   public void setApproveLevel(Short approveLevel) {
/* 89 */     this.approveLevel = approveLevel;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlApproveResult
 * JD-Core Version:    0.6.2
 */
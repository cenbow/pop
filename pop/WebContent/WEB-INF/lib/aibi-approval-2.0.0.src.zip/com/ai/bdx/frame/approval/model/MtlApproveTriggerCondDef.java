package com.ai.bdx.frame.approval.model;


public class MtlApproveTriggerCondDef implements java.io.Serializable {

	// Fields    

	private MtlApproveTriggerCondDefId id;

	private String condOperator;

	private String condIndiValue;

	private Integer approveObjType;

	private String approveObjId;

	private Integer approveTriggerCondPri;

	private String approveObjName;

	// Constructors

	/** default constructor */
	public MtlApproveTriggerCondDef() {
	}

	/** full constructor */
	public MtlApproveTriggerCondDef(MtlApproveTriggerCondDefId id, String condOperator, String condIndiValue, Integer approveObjType, String approveObjId, Integer approveTriggerCondPri) {
		this.id = id;
		this.condOperator = condOperator;
		this.condIndiValue = condIndiValue;
		this.approveObjType = approveObjType;
		this.approveObjId = approveObjId;
		this.approveTriggerCondPri = approveTriggerCondPri;
	}

	// Property accessors

	public MtlApproveTriggerCondDefId getId() {
		return this.id;
	}

	public void setId(MtlApproveTriggerCondDefId id) {
		this.id = id;
	}

	public String getCondOperator() {
		return this.condOperator;
	}

	public void setCondOperator(String condOperator) {
		this.condOperator = condOperator;
	}

	public String getCondIndiValue() {
		return this.condIndiValue;
	}

	public void setCondIndiValue(String condIndiValue) {
		this.condIndiValue = condIndiValue;
	}

	public Integer getApproveObjType() {
		return this.approveObjType;
	}

	public void setApproveObjType(Integer approveObjType) {
		this.approveObjType = approveObjType;
	}

	public String getApproveObjId() {
		return this.approveObjId;
	}

	public void setApproveObjId(String approveObjId) {
		this.approveObjId = approveObjId;
	}

	public Integer getApproveTriggerCondPri() {
		return this.approveTriggerCondPri;
	}

	public void setApproveTriggerCondPri(Integer approveTriggerCondPri) {
		this.approveTriggerCondPri = approveTriggerCondPri;
	}

	public String getApproveObjName() {
		return approveObjName;
	}

	public void setApproveObjName(String approveObjName) {
		this.approveObjName = approveObjName;
	}

}

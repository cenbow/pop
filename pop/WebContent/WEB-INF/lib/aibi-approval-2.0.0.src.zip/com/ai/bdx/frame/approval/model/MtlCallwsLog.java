/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class MtlCallwsLog
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String callwsId;
/*     */   private Short callwsType;
/*     */   private String campsegId;
/*     */   private Short channeltypeId;
/*     */   private String channelId;
/*     */   private Date callwsBeginDate;
/*     */   private Date callwsEndDate;
/*     */   private Short callwsStatus;
/*     */   private String callwsDesc;
/*     */ 
/*     */   public MtlCallwsLog()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlCallwsLog(String callwsId)
/*     */   {
/*  42 */     this.callwsId = callwsId;
/*     */   }
/*     */ 
/*     */   public String getCallwsId() {
/*  46 */     return this.callwsId;
/*     */   }
/*     */ 
/*     */   public void setCallwsId(String callwsId) {
/*  50 */     this.callwsId = callwsId;
/*     */   }
/*     */ 
/*     */   public Short getCallwsType() {
/*  54 */     return this.callwsType;
/*     */   }
/*     */ 
/*     */   public void setCallwsType(Short callwsType) {
/*  58 */     this.callwsType = callwsType;
/*     */   }
/*     */ 
/*     */   public String getCampsegId() {
/*  62 */     return this.campsegId;
/*     */   }
/*     */ 
/*     */   public void setCampsegId(String campsegId) {
/*  66 */     this.campsegId = campsegId;
/*     */   }
/*     */ 
/*     */   public Short getChanneltypeId() {
/*  70 */     return this.channeltypeId;
/*     */   }
/*     */ 
/*     */   public void setChanneltypeId(Short channeltypeId) {
/*  74 */     this.channeltypeId = channeltypeId;
/*     */   }
/*     */ 
/*     */   public String getChannelId() {
/*  78 */     return this.channelId;
/*     */   }
/*     */ 
/*     */   public void setChannelId(String channelId) {
/*  82 */     this.channelId = channelId;
/*     */   }
/*     */ 
/*     */   public Short getCallwsStatus() {
/*  86 */     return this.callwsStatus;
/*     */   }
/*     */ 
/*     */   public void setCallwsStatus(Short callwsStatus) {
/*  90 */     this.callwsStatus = callwsStatus;
/*     */   }
/*     */ 
/*     */   public String getCallwsDesc() {
/*  94 */     return this.callwsDesc;
/*     */   }
/*     */ 
/*     */   public void setCallwsDesc(String callwsDesc) {
/*  98 */     this.callwsDesc = callwsDesc;
/*     */   }
/*     */ 
/*     */   public Date getCallwsBeginDate() {
/* 102 */     return this.callwsBeginDate;
/*     */   }
/*     */ 
/*     */   public void setCallwsBeginDate(Date callwsBeginDate) {
/* 106 */     this.callwsBeginDate = callwsBeginDate;
/*     */   }
/*     */ 
/*     */   public Date getCallwsEndDate() {
/* 110 */     return this.callwsEndDate;
/*     */   }
/*     */ 
/*     */   public void setCallwsEndDate(Date callwsEndDate) {
/* 114 */     this.callwsEndDate = callwsEndDate;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCallwsLog
 * JD-Core Version:    0.6.2
 */
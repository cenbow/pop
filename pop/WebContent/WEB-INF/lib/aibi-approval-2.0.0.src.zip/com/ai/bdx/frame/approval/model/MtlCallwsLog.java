package com.ai.bdx.frame.approval.model;

import java.util.Date;


public class MtlCallwsLog implements java.io.Serializable {

	// Fields    

	
	 /** 
	  * serialVersionUID:TODO 
	  */
	private static final long serialVersionUID = 1L;

	private String callwsId;

	private Short callwsType;

	private String campsegId;
	
	private Short channeltypeId;
	
	private String channelId;
	
	private Date callwsBeginDate;

	private Date callwsEndDate;
	
	private Short callwsStatus;
	
	private String callwsDesc;

	// Constructors

	/** default constructor */
	public MtlCallwsLog() {
	}

	/** minimal constructor */
	public MtlCallwsLog(String callwsId) {
		this.callwsId = callwsId;
	}

	public String getCallwsId() {
		return callwsId;
	}

	public void setCallwsId(String callwsId) {
		this.callwsId = callwsId;
	}

	public Short getCallwsType() {
		return callwsType;
	}

	public void setCallwsType(Short callwsType) {
		this.callwsType = callwsType;
	}

	public String getCampsegId() {
		return campsegId;
	}

	public void setCampsegId(String campsegId) {
		this.campsegId = campsegId;
	}

	public Short getChanneltypeId() {
		return channeltypeId;
	}

	public void setChanneltypeId(Short channeltypeId) {
		this.channeltypeId = channeltypeId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public Short getCallwsStatus() {
		return callwsStatus;
	}

	public void setCallwsStatus(Short callwsStatus) {
		this.callwsStatus = callwsStatus;
	}

	public String getCallwsDesc() {
		return callwsDesc;
	}

	public void setCallwsDesc(String callwsDesc) {
		this.callwsDesc = callwsDesc;
	}

	public Date getCallwsBeginDate() {
		return callwsBeginDate;
	}

	public void setCallwsBeginDate(Date callwsBeginDate) {
		this.callwsBeginDate = callwsBeginDate;
	}

	public Date getCallwsEndDate() {
		return callwsEndDate;
	}

	public void setCallwsEndDate(Date callwsEndDate) {
		this.callwsEndDate = callwsEndDate;
	}

   

}

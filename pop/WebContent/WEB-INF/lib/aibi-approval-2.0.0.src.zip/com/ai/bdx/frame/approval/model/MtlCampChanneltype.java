/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class MtlCampChanneltype
/*     */   implements Serializable
/*     */ {
/*     */   private MtlCampChanneltypeId id;
/*     */   private String startDate;
/*     */   private String endDate;
/*     */   private String useDesc;
/*     */   private Double custNums;
/*     */   private int confirmFlag;
/*     */   private Double custGotoneNums;
/*     */   private Double custMzoneNums;
/*     */   private Double custScpNums;
/*     */   private Integer callSuccessRate;
/*     */   private Integer questionFinishRate;
/*     */   private Short wishCallCounts;
/*     */   private Integer questionDuration;
/*     */   private Integer campsegSuccessNums;
/*     */   private String channeltypeAndId;
/*     */   private Short channelNo;
/*     */   private String channelName;
/*     */   private String channelTypeName;
/*     */ 
/*     */   public String getChannelName()
/*     */   {
/*  51 */     return this.channelName;
/*     */   }
/*     */ 
/*     */   public void setChannelName(String channelName) {
/*  55 */     this.channelName = channelName;
/*     */   }
/*     */ 
/*     */   public String getChannelTypeName() {
/*  59 */     return this.channelTypeName;
/*     */   }
/*     */ 
/*     */   public void setChannelTypeName(String channelTypeName) {
/*  63 */     this.channelTypeName = channelTypeName;
/*     */   }
/*     */ 
/*     */   public Short getChannelNo() {
/*  67 */     return this.channelNo;
/*     */   }
/*     */ 
/*     */   public void setChannelNo(Short channelNo) {
/*  71 */     this.channelNo = channelNo;
/*     */   }
/*     */ 
/*     */   public Double getCustGotoneNums() {
/*  75 */     return this.custGotoneNums;
/*     */   }
/*     */ 
/*     */   public void setCustGotoneNums(Double custGotoneNums) {
/*  79 */     this.custGotoneNums = custGotoneNums;
/*     */   }
/*     */ 
/*     */   public Double getCustMzoneNums() {
/*  83 */     return this.custMzoneNums;
/*     */   }
/*     */ 
/*     */   public void setCustMzoneNums(Double custMzoneNums) {
/*  87 */     this.custMzoneNums = custMzoneNums;
/*     */   }
/*     */ 
/*     */   public Double getCustScpNums() {
/*  91 */     return this.custScpNums;
/*     */   }
/*     */ 
/*     */   public void setCustScpNums(Double custScpNums) {
/*  95 */     this.custScpNums = custScpNums;
/*     */   }
/*     */ 
/*     */   public MtlCampChanneltype()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlCampChanneltype(MtlCampChanneltypeId id)
/*     */   {
/* 104 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public MtlCampChanneltypeId getId()
/*     */   {
/* 110 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(MtlCampChanneltypeId id) {
/* 114 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getStartDate() {
/* 118 */     return this.startDate;
/*     */   }
/*     */ 
/*     */   public void setStartDate(String startDate) {
/* 122 */     this.startDate = startDate;
/*     */   }
/*     */ 
/*     */   public String getEndDate() {
/* 126 */     return this.endDate;
/*     */   }
/*     */ 
/*     */   public void setEndDate(String endDate) {
/* 130 */     this.endDate = endDate;
/*     */   }
/*     */ 
/*     */   public String getUseDesc() {
/* 134 */     return this.useDesc;
/*     */   }
/*     */ 
/*     */   public void setUseDesc(String useDesc) {
/* 138 */     this.useDesc = useDesc;
/*     */   }
/*     */ 
/*     */   public Double getCustNums() {
/* 142 */     return this.custNums;
/*     */   }
/*     */ 
/*     */   public void setCustNums(Double custNums) {
/* 146 */     this.custNums = custNums;
/*     */   }
/*     */ 
/*     */   public String getChanneltypeAndId() {
/* 150 */     return this.id.getChanneltypeId() + "_" + this.id.getChannelId();
/*     */   }
/*     */ 
/*     */   public void setChanneltypeAndId(String channeltypeAndId) {
/* 154 */     this.channeltypeAndId = channeltypeAndId;
/*     */   }
/*     */ 
/*     */   public Integer getCallSuccessRate() {
/* 158 */     return this.callSuccessRate;
/*     */   }
/*     */ 
/*     */   public void setCallSuccessRate(Integer callSuccessRate) {
/* 162 */     this.callSuccessRate = callSuccessRate;
/*     */   }
/*     */ 
/*     */   public Integer getQuestionFinishRate() {
/* 166 */     return this.questionFinishRate;
/*     */   }
/*     */ 
/*     */   public void setQuestionFinishRate(Integer questionFinishRate) {
/* 170 */     this.questionFinishRate = questionFinishRate;
/*     */   }
/*     */ 
/*     */   public Short getWishCallCounts() {
/* 174 */     return this.wishCallCounts;
/*     */   }
/*     */ 
/*     */   public void setWishCallCounts(Short wishCallCounts) {
/* 178 */     this.wishCallCounts = wishCallCounts;
/*     */   }
/*     */ 
/*     */   public Integer getQuestionDuration() {
/* 182 */     return this.questionDuration;
/*     */   }
/*     */ 
/*     */   public void setQuestionDuration(Integer questionDuration) {
/* 186 */     this.questionDuration = questionDuration;
/*     */   }
/*     */ 
/*     */   public Integer getCampsegSuccessNums() {
/* 190 */     return this.campsegSuccessNums;
/*     */   }
/*     */ 
/*     */   public void setCampsegSuccessNums(Integer campsegSuccessNums) {
/* 194 */     this.campsegSuccessNums = campsegSuccessNums;
/*     */   }
/*     */ 
/*     */   public int getConfirmFlag()
/*     */   {
/* 201 */     return this.confirmFlag;
/*     */   }
/*     */ 
/*     */   public void setConfirmFlag(int confirmFlag)
/*     */   {
/* 208 */     this.confirmFlag = confirmFlag;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCampChanneltype
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlCampChanneltypeId
/*    */   implements Serializable
/*    */ {
/*    */   private String campId;
/*    */   private Short channeltypeId;
/*    */   private String channelId;
/*    */ 
/*    */   public MtlCampChanneltypeId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MtlCampChanneltypeId(String campId, Short channeltypeId, String channelId)
/*    */   {
/* 26 */     this.campId = campId;
/* 27 */     this.channeltypeId = channeltypeId;
/* 28 */     this.channelId = channelId;
/*    */   }
/*    */ 
/*    */   public String getCampId()
/*    */   {
/* 34 */     return this.campId;
/*    */   }
/*    */ 
/*    */   public void setCampId(String campId) {
/* 38 */     this.campId = campId;
/*    */   }
/*    */ 
/*    */   public Short getChanneltypeId() {
/* 42 */     return this.channeltypeId;
/*    */   }
/*    */ 
/*    */   public void setChanneltypeId(Short channeltypeId) {
/* 46 */     this.channeltypeId = channeltypeId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 50 */     if (this == other)
/* 51 */       return true;
/* 52 */     if (other == null)
/* 53 */       return false;
/* 54 */     if (!(other instanceof MtlCampChanneltypeId))
/* 55 */       return false;
/* 56 */     MtlCampChanneltypeId castOther = (MtlCampChanneltypeId)other;
/*    */ 
/* 58 */     return ((getCampId() == castOther.getCampId()) || ((getCampId() != null) && (castOther.getCampId() != null) && (getCampId().equals(castOther.getCampId())))) && ((getChannelId() == castOther.getChannelId()) || ((getChannelId() != null) && (castOther.getChannelId() != null) && (getChannelId().equals(castOther.getChannelId())))) && ((getChanneltypeId() == castOther.getChanneltypeId()) || ((getChanneltypeId() != null) && (castOther.getChanneltypeId() != null) && (getChanneltypeId().equals(castOther.getChanneltypeId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 64 */     int result = 17;
/*    */ 
/* 66 */     result = 37 * result + (getCampId() == null ? 0 : getCampId().hashCode());
/* 67 */     result = 37 * result + (getChannelId() == null ? 0 : getChannelId().hashCode());
/* 68 */     result = 37 * result + (getChanneltypeId() == null ? 0 : getChanneltypeId().hashCode());
/* 69 */     return result;
/*    */   }
/*    */ 
/*    */   public String getChannelId() {
/* 73 */     return this.channelId;
/*    */   }
/*    */ 
/*    */   public void setChannelId(String channelId) {
/* 77 */     this.channelId = channelId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCampChanneltypeId
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.util.MpmUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MtlCampDataSource
/*     */   implements Serializable
/*     */ {
/*     */   private String sourceName;
/*     */   private String sourceCname;
/*     */   private String sourceDesc;
/*     */   private String sourceType;
/*     */   private Date createTime;
/*     */   private String sourceStatus;
/*  28 */   private boolean flag = true;
/*     */   private Short cycleType;
/*     */   private Set columns;
/*     */ 
/*     */   public Short getCycleType()
/*     */   {
/*  33 */     return this.cycleType;
/*     */   }
/*     */ 
/*     */   public void setCycleType(Short cycleType) {
/*  37 */     this.cycleType = cycleType;
/*     */   }
/*     */ 
/*     */   public boolean isFlag() {
/*  41 */     return this.flag;
/*     */   }
/*     */ 
/*     */   public void setFlag(boolean flag) {
/*  45 */     this.flag = flag;
/*     */   }
/*     */ 
/*     */   public MtlCampDataSource()
/*     */   {
/*  54 */     this.flag = true;
/*     */   }
/*     */ 
/*     */   public MtlCampDataSource(String sourceName)
/*     */   {
/*  59 */     this.sourceName = sourceName;
/*     */   }
/*     */ 
/*     */   public MtlCampDataSource(String sourceName, String sourceCname, String sourceDesc, String sourceType, Date createTime, String sourceStatus)
/*     */   {
/*  64 */     this.sourceName = sourceName;
/*  65 */     this.sourceCname = sourceCname;
/*  66 */     this.sourceDesc = sourceDesc;
/*  67 */     this.sourceType = sourceType;
/*  68 */     this.createTime = createTime;
/*  69 */     this.sourceStatus = sourceStatus;
/*     */   }
/*     */ 
/*     */   public String getSourceName()
/*     */   {
/*  76 */     return this.sourceName;
/*     */   }
/*     */ 
/*     */   public void setSourceName(String sourceName) {
/*  80 */     this.sourceName = sourceName;
/*     */   }
/*     */ 
/*     */   public String getSourceCname() {
/*  84 */     if (this.flag) {
/*  85 */       return MpmUtil.GBToUnicode(this.sourceCname);
/*     */     }
/*  87 */     return MpmUtil.unicodeToGB(this.sourceCname);
/*     */   }
/*     */ 
/*     */   public void setSourceCname(String sourceCname)
/*     */   {
/*  92 */     this.sourceCname = sourceCname;
/*     */   }
/*     */ 
/*     */   public String getSourceDesc() {
/*  96 */     return this.sourceDesc;
/*     */   }
/*     */ 
/*     */   public void setSourceDesc(String sourceDesc) {
/* 100 */     this.sourceDesc = sourceDesc;
/*     */   }
/*     */ 
/*     */   public String getSourceType() {
/* 104 */     return this.sourceType;
/*     */   }
/*     */ 
/*     */   public void setSourceType(String sourceType) {
/* 108 */     this.sourceType = sourceType;
/*     */   }
/*     */ 
/*     */   public Date getCreateTime() {
/* 112 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(Date createTime) {
/* 116 */     this.createTime = createTime;
/*     */   }
/*     */ 
/*     */   public String getSourceStatus() {
/* 120 */     return this.sourceStatus;
/*     */   }
/*     */ 
/*     */   public void setSourceStatus(String sourceStatus) {
/* 124 */     this.sourceStatus = sourceStatus;
/*     */   }
/*     */ 
/*     */   public Set getColumns() {
/* 128 */     return this.columns;
/*     */   }
/*     */ 
/*     */   public void setColumns(Set columns) {
/* 132 */     this.columns = columns;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCampDataSource
 * JD-Core Version:    0.6.2
 */
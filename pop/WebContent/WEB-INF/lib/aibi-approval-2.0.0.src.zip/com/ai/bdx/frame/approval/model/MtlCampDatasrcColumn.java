/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.util.MpmCache;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class MtlCampDatasrcColumn
/*     */   implements Serializable
/*     */ {
/*  14 */   private MtlCampDatasrcColumnId id = new MtlCampDatasrcColumnId();
/*     */   private String columnCname;
/*     */   private String columnClass;
/*     */   private String columnFlag;
/*     */   private String columnDesc;
/*     */   private String columnCtype;
/*     */   private String columnCclass;
/*     */   private String columnCflag;
/*     */   private String columnDatatype;
/*     */   private String beforeColumnName;
/*     */   private Short columnStatus;
/*     */   private Short columnCStatus;
/*     */ 
/*     */   public MtlCampDatasrcColumn()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlCampDatasrcColumn(MtlCampDatasrcColumnId id)
/*     */   {
/*  47 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public MtlCampDatasrcColumn(MtlCampDatasrcColumnId id, String columnCname, String columnClass, String columnFlag, String columnDesc)
/*     */   {
/*  52 */     this.id = id;
/*  53 */     this.columnCname = columnCname;
/*  54 */     this.columnClass = columnClass;
/*  55 */     this.columnFlag = columnFlag;
/*  56 */     this.columnDesc = columnDesc;
/*     */   }
/*     */ 
/*     */   public MtlCampDatasrcColumnId getId()
/*     */   {
/*  62 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(MtlCampDatasrcColumnId id) {
/*  66 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getColumnCname() {
/*  70 */     return this.columnCname;
/*     */   }
/*     */ 
/*     */   public void setColumnCname(String columnCname) {
/*  74 */     this.columnCname = columnCname;
/*     */   }
/*     */ 
/*     */   public String getColumnClass() {
/*  78 */     return this.columnClass;
/*     */   }
/*     */ 
/*     */   public void setColumnClass(String columnClass) {
/*  82 */     this.columnClass = columnClass;
/*     */   }
/*     */ 
/*     */   public String getColumnFlag() {
/*  86 */     return this.columnFlag;
/*     */   }
/*     */ 
/*     */   public void setColumnFlag(String columnFlag) {
/*  90 */     this.columnFlag = columnFlag;
/*     */   }
/*     */ 
/*     */   public String getColumnDesc() {
/*  94 */     return this.columnDesc;
/*     */   }
/*     */ 
/*     */   public void setColumnDesc(String columnDesc) {
/*  98 */     this.columnDesc = columnDesc;
/*     */   }
/*     */ 
/*     */   public String getColumnDatatype() {
/* 102 */     return this.columnDatatype;
/*     */   }
/*     */ 
/*     */   public void setColumnDatatype(String columnDatatype) {
/* 106 */     this.columnDatatype = columnDatatype;
/*     */   }
/*     */ 
/*     */   public void setBeforeColumnName(String beforeColumnName) {
/* 110 */     this.beforeColumnName = beforeColumnName;
/*     */   }
/*     */ 
/*     */   public String getBeforeColumnName() {
/* 114 */     return this.beforeColumnName;
/*     */   }
/*     */ 
/*     */   public String getColumnCtype() {
/* 118 */     String columntype = this.id.getColumnType();
/* 119 */     return MpmCache.getInstance().getNameByTypeAndKey("mpm_ds_column_type", columntype);
/*     */   }
/*     */ 
/*     */   public String getColumnCclass() {
/* 123 */     return MpmCache.getInstance().getNameByTypeAndKey("baseTableColumnType", this.columnClass);
/*     */   }
/*     */ 
/*     */   public String getColumnCflag() {
/* 127 */     return MpmCache.getInstance().getNameByTypeAndKey("source_table_column_flag", this.columnFlag);
/*     */   }
/*     */ 
/*     */   public Short getColumnStatus() {
/* 131 */     return this.columnStatus;
/*     */   }
/*     */ 
/*     */   public void setColumnStatus(Short columnStatus) {
/* 135 */     this.columnStatus = columnStatus;
/*     */   }
/*     */ 
/*     */   public String getColumnCStatus() {
/* 139 */     if (this.columnStatus == null)
/* 140 */       return "";
/* 141 */     return MpmCache.getInstance().getNameByTypeAndKey("column_status", this.columnStatus.toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class MtlCampsegApproverList
/*    */   implements Serializable
/*    */ {
/*    */   private MtlCampsegApproverListId id;
/*    */   private String approveUserid;
/*    */   private Short approveToken;
/* 19 */   private Date updateTime = new Date();
/*    */   private Short authFlag;
/*    */ 
/*    */   public MtlCampsegApproverList()
/*    */   {
/* 27 */     this.id = new MtlCampsegApproverListId();
/*    */   }
/*    */ 
/*    */   public MtlCampsegApproverList(MtlCampsegApproverListId id, String approveUserid, Short approveToken)
/*    */   {
/* 32 */     this.id = id;
/* 33 */     this.approveUserid = approveUserid;
/* 34 */     this.approveToken = approveToken;
/*    */   }
/*    */ 
/*    */   public MtlCampsegApproverListId getId()
/*    */   {
/* 40 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(MtlCampsegApproverListId id) {
/* 44 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getApproveUserid() {
/* 48 */     return this.approveUserid;
/*    */   }
/*    */ 
/*    */   public void setApproveUserid(String approveUserid) {
/* 52 */     this.approveUserid = approveUserid;
/*    */   }
/*    */ 
/*    */   public Short getApproveToken() {
/* 56 */     return this.approveToken;
/*    */   }
/*    */ 
/*    */   public void setApproveToken(Short approveToken) {
/* 60 */     this.approveToken = approveToken;
/*    */   }
/*    */ 
/*    */   public Date getUpdateTime() {
/* 64 */     return this.updateTime;
/*    */   }
/*    */ 
/*    */   public void setUpdateTime(Date updateTime) {
/* 68 */     this.updateTime = updateTime;
/*    */   }
/*    */ 
/*    */   public Short getAuthFlag() {
/* 72 */     return this.authFlag;
/*    */   }
/*    */ 
/*    */   public void setAuthFlag(Short authFlag) {
/* 76 */     this.authFlag = authFlag;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCampsegApproverList
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlCampsegApproverListId
/*    */   implements Serializable
/*    */ {
/*    */   private String campsegId;
/*    */   private String approveFlowId;
/*    */   private Short approveSeq;
/*    */   private Short approveLevel;
/*    */ 
/*    */   public MtlCampsegApproverListId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MtlCampsegApproverListId(String campsegId, String approveFlowId, Short approveSeq, Short approveLevel)
/*    */   {
/* 28 */     this.campsegId = campsegId;
/* 29 */     this.approveFlowId = approveFlowId;
/* 30 */     this.approveSeq = approveSeq;
/* 31 */     this.approveLevel = approveLevel;
/*    */   }
/*    */ 
/*    */   public String getCampsegId()
/*    */   {
/* 37 */     return this.campsegId;
/*    */   }
/*    */ 
/*    */   public void setCampsegId(String campsegId) {
/* 41 */     this.campsegId = campsegId;
/*    */   }
/*    */ 
/*    */   public String getApproveFlowId() {
/* 45 */     return this.approveFlowId;
/*    */   }
/*    */ 
/*    */   public void setApproveFlowId(String approveFlowId) {
/* 49 */     this.approveFlowId = approveFlowId;
/*    */   }
/*    */ 
/*    */   public Short getApproveSeq() {
/* 53 */     return this.approveSeq;
/*    */   }
/*    */ 
/*    */   public void setApproveSeq(Short approveSeq) {
/* 57 */     this.approveSeq = approveSeq;
/*    */   }
/*    */ 
/*    */   public Short getApproveLevel() {
/* 61 */     return this.approveLevel;
/*    */   }
/*    */ 
/*    */   public void setApproveLevel(Short approveLevel) {
/* 65 */     this.approveLevel = approveLevel;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 69 */     if (this == other)
/* 70 */       return true;
/* 71 */     if (other == null)
/* 72 */       return false;
/* 73 */     if (!(other instanceof MtlCampsegApproverListId))
/* 74 */       return false;
/* 75 */     MtlCampsegApproverListId castOther = (MtlCampsegApproverListId)other;
/*    */ 
/* 77 */     return ((getCampsegId() == castOther.getCampsegId()) || ((getCampsegId() != null) && (castOther.getCampsegId() != null) && (getCampsegId().equals(castOther.getCampsegId())))) && ((getApproveFlowId() == castOther.getApproveFlowId()) || ((getApproveFlowId() != null) && (castOther.getApproveFlowId() != null) && (getApproveFlowId().equals(castOther.getApproveFlowId())))) && ((getApproveSeq() == castOther.getApproveSeq()) || ((getApproveSeq() != null) && (castOther.getApproveSeq() != null) && (getApproveSeq().equals(castOther.getApproveSeq())))) && ((getApproveLevel() == castOther.getApproveLevel()) || ((getApproveLevel() != null) && (castOther.getApproveLevel() != null) && (getApproveLevel().equals(castOther.getApproveLevel()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 84 */     int result = 17;
/*    */ 
/* 86 */     result = 37 * result + (getCampsegId() == null ? 0 : getCampsegId().hashCode());
/* 87 */     result = 37 * result + (getApproveFlowId() == null ? 0 : getApproveFlowId().hashCode());
/* 88 */     result = 37 * result + (getApproveSeq() == null ? 0 : getApproveSeq().hashCode());
/* 89 */     result = 37 * result + (getApproveLevel() == null ? 0 : getApproveLevel().hashCode());
/* 90 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCampsegApproverListId
 * JD-Core Version:    0.6.2
 */
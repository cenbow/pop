/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class MtlCampsegProgress
/*    */   implements Serializable
/*    */ {
/*    */   private MtlCampsegProgressId id;
/*    */   private Date performTime;
/*    */   private String performUserid;
/*    */   private Short performFlag;
/*    */   private String proformResult;
/*    */   private String campId;
/*    */ 
/*    */   public MtlCampsegProgress()
/*    */   {
/* 29 */     this.id = new MtlCampsegProgressId();
/*    */   }
/*    */ 
/*    */   public MtlCampsegProgress(MtlCampsegProgressId id, Date performTime)
/*    */   {
/* 34 */     this.id = id;
/* 35 */     this.performTime = performTime;
/*    */   }
/*    */ 
/*    */   public MtlCampsegProgress(MtlCampsegProgressId id, Date performTime, String performUserid, Short performFlag, String proformResult, String campId)
/*    */   {
/* 40 */     this.id = id;
/* 41 */     this.performTime = performTime;
/* 42 */     this.performUserid = performUserid;
/* 43 */     this.performFlag = performFlag;
/* 44 */     this.proformResult = proformResult;
/* 45 */     this.campId = campId;
/*    */   }
/*    */ 
/*    */   public MtlCampsegProgressId getId()
/*    */   {
/* 51 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(MtlCampsegProgressId id) {
/* 55 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public Date getPerformTime() {
/* 59 */     return this.performTime;
/*    */   }
/*    */ 
/*    */   public void setPerformTime(Date performTime) {
/* 63 */     this.performTime = performTime;
/*    */   }
/*    */ 
/*    */   public String getPerformUserid() {
/* 67 */     return this.performUserid;
/*    */   }
/*    */ 
/*    */   public void setPerformUserid(String performUserid) {
/* 71 */     this.performUserid = performUserid;
/*    */   }
/*    */ 
/*    */   public Short getPerformFlag() {
/* 75 */     return this.performFlag;
/*    */   }
/*    */ 
/*    */   public void setPerformFlag(Short performFlag) {
/* 79 */     this.performFlag = performFlag;
/*    */   }
/*    */ 
/*    */   public String getProformResult() {
/* 83 */     return this.proformResult;
/*    */   }
/*    */ 
/*    */   public void setProformResult(String proformResult) {
/* 87 */     this.proformResult = proformResult;
/*    */   }
/*    */ 
/*    */   public String getCampId() {
/* 91 */     return this.campId;
/*    */   }
/*    */ 
/*    */   public void setCampId(String campId) {
/* 95 */     this.campId = campId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCampsegProgress
 * JD-Core Version:    0.6.2
 */
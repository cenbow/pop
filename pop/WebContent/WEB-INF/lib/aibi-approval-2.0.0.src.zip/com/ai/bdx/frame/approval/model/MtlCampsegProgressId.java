/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlCampsegProgressId
/*    */   implements Serializable
/*    */ {
/*    */   private String campsegId;
/*    */   private Short stepId;
/*    */   private String flowId;
/*    */ 
/*    */   public MtlCampsegProgressId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MtlCampsegProgressId(String id1, Short id2, String id3)
/*    */   {
/* 24 */     this.campsegId = id1;
/* 25 */     this.stepId = id2;
/* 26 */     this.flowId = id3;
/*    */   }
/*    */ 
/*    */   public String getCampsegId()
/*    */   {
/* 32 */     return this.campsegId;
/*    */   }
/*    */ 
/*    */   public void setCampsegId(String campsegId) {
/* 36 */     this.campsegId = campsegId;
/*    */   }
/*    */ 
/*    */   public Short getStepId() {
/* 40 */     return this.stepId;
/*    */   }
/*    */ 
/*    */   public void setStepId(Short stepId) {
/* 44 */     this.stepId = stepId;
/*    */   }
/*    */ 
/*    */   public String getFlowId() {
/* 48 */     return this.flowId;
/*    */   }
/*    */ 
/*    */   public void setFlowId(String flowId) {
/* 52 */     this.flowId = flowId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 56 */     if (this == other)
/* 57 */       return true;
/* 58 */     if (other == null)
/* 59 */       return false;
/* 60 */     if (!(other instanceof MtlCampsegProgressId))
/* 61 */       return false;
/* 62 */     MtlCampsegProgressId castOther = (MtlCampsegProgressId)other;
/*    */ 
/* 64 */     return ((getCampsegId() == castOther.getCampsegId()) || ((getCampsegId() != null) && (castOther.getCampsegId() != null) && (getCampsegId().equals(castOther.getCampsegId())))) && ((getStepId() == castOther.getStepId()) || ((getStepId() != null) && (castOther.getStepId() != null) && (getStepId().equals(castOther.getStepId())))) && ((getFlowId() == castOther.getFlowId()) || ((getFlowId() != null) && (castOther.getFlowId() != null) && (getFlowId().equals(castOther.getFlowId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 70 */     int result = 17;
/*    */ 
/* 72 */     result = 37 * result + (getCampsegId() == null ? 0 : getCampsegId().hashCode());
/* 73 */     result = 37 * result + (getStepId() == null ? 0 : getStepId().hashCode());
/* 74 */     result = 37 * result + (getFlowId() == null ? 0 : getFlowId().hashCode());
/* 75 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCampsegProgressId
 * JD-Core Version:    0.6.2
 */
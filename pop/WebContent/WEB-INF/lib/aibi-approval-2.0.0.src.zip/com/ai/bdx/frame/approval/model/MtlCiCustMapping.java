/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlCiCustMapping
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String ciCustId;
/*    */   private String mtlCustId;
/*    */   private String ciTempleteId;
/*    */ 
/*    */   public String getCiCustId()
/*    */   {
/* 15 */     return this.ciCustId;
/*    */   }
/*    */   public String getCiTempleteId() {
/* 18 */     return this.ciTempleteId;
/*    */   }
/*    */   public String getMtlCustId() {
/* 21 */     return this.mtlCustId;
/*    */   }
/*    */   public void setCiCustId(String ciCustId) {
/* 24 */     this.ciCustId = ciCustId;
/*    */   }
/*    */   public void setCiTempleteId(String ciTempleteId) {
/* 27 */     this.ciTempleteId = ciTempleteId;
/*    */   }
/*    */   public void setMtlCustId(String mtlCustId) {
/* 30 */     this.mtlCustId = mtlCustId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlCiCustMapping
 * JD-Core Version:    0.6.2
 */
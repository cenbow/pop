package com.ai.bdx.frame.approval.model;


public class MtlConfirmExtendInfo implements java.io.Serializable {
	private MtlConfirmExtendInfoId id;

	private Double custNums;

	private Short rptScore;

	private String channelCampContent;

	private String startDate;

	private String endDate;
	
	private Short channelNo;

	public Short getChannelNo() {
		return channelNo;
	}

	public void setChannelNo(Short channelNo) {
		this.channelNo = channelNo;
	}

	public MtlConfirmExtendInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MtlConfirmExtendInfo(MtlConfirmExtendInfoId id, Double custNums, String channelCampContent, String startDate, String endDate) {
		super();
		this.id = id;
		this.custNums = custNums;
		this.channelCampContent = channelCampContent;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public String getChannelCampContent() {
		return channelCampContent;
	}

	public void setChannelCampContent(String channelCampContent) {
		this.channelCampContent = channelCampContent;
	}

	public Double getCustNums() {
		return custNums;
	}

	public void setCustNums(Double custNums) {
		this.custNums = custNums;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public MtlConfirmExtendInfoId getId() {
		return id;
	}

	public void setId(MtlConfirmExtendInfoId id) {
		this.id = id;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((channelCampContent == null) ? 0 : channelCampContent.hashCode());
		result = PRIME * result + ((custNums == null) ? 0 : custNums.hashCode());
		result = PRIME * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = PRIME * result + ((id == null) ? 0 : id.hashCode());
		result = PRIME * result + ((startDate == null) ? 0 : startDate.hashCode());
		result = PRIME * result + ((rptScore == null) ? 0 : rptScore.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final MtlConfirmExtendInfo other = (MtlConfirmExtendInfo) obj;
		if (channelCampContent == null) {
			if (other.channelCampContent != null)
				return false;
		} else if (!channelCampContent.equals(other.channelCampContent))
			return false;
		if (custNums == null) {
			if (other.custNums != null)
				return false;
		} else if (!custNums.equals(other.custNums))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (rptScore == null) {
			if (other.rptScore != null)
				return false;
		} else if (!rptScore.equals(other.rptScore))
			return false;
		return true;
	}

	public Short getRptScore() {
		return rptScore;
	}

	public void setRptScore(Short rptScore) {
		this.rptScore = rptScore;
	}

}

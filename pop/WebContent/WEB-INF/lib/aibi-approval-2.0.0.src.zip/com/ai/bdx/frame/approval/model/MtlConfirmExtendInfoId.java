/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class MtlConfirmExtendInfoId
/*     */   implements Serializable
/*     */ {
/*     */   private String campsegId;
/*     */   private Integer resourceId;
/*     */   private Short usersegId;
/*     */   private String confirmUserid;
/*     */   private Short approveSeq;
/*     */ 
/*     */   public MtlConfirmExtendInfoId()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlConfirmExtendInfoId(String campsegId, Integer resourceId, Short usersegId, String confirmUserid)
/*     */   {
/*  23 */     this.campsegId = campsegId;
/*  24 */     this.resourceId = resourceId;
/*  25 */     this.usersegId = usersegId;
/*  26 */     this.confirmUserid = confirmUserid;
/*     */   }
/*     */ 
/*     */   public String getCampsegId() {
/*  30 */     return this.campsegId;
/*     */   }
/*     */ 
/*     */   public void setCampsegId(String campsegId) {
/*  34 */     this.campsegId = campsegId;
/*     */   }
/*     */ 
/*     */   public String getConfirmUserid() {
/*  38 */     return this.confirmUserid;
/*     */   }
/*     */ 
/*     */   public void setConfirmUserid(String confirmUserid) {
/*  42 */     this.confirmUserid = confirmUserid;
/*     */   }
/*     */ 
/*     */   public Integer getResourceId() {
/*  46 */     return this.resourceId;
/*     */   }
/*     */ 
/*     */   public void setResourceId(Integer resourceId) {
/*  50 */     this.resourceId = resourceId;
/*     */   }
/*     */ 
/*     */   public Short getUsersegId() {
/*  54 */     return this.usersegId;
/*     */   }
/*     */ 
/*     */   public void setUsersegId(Short usersegId) {
/*  58 */     this.usersegId = usersegId;
/*     */   }
/*     */ 
/*     */   public Short getApproveSeq() {
/*  62 */     return this.approveSeq;
/*     */   }
/*     */ 
/*     */   public void setApproveSeq(Short approveSeq) {
/*  66 */     this.approveSeq = approveSeq;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/*  70 */     int prime = 31;
/*  71 */     int result = 1;
/*  72 */     result = 31 * result + (this.campsegId == null ? 0 : this.campsegId.hashCode());
/*  73 */     result = 31 * result + (this.confirmUserid == null ? 0 : this.confirmUserid.hashCode());
/*  74 */     result = 31 * result + (this.resourceId == null ? 0 : this.resourceId.hashCode());
/*  75 */     result = 31 * result + (this.usersegId == null ? 0 : this.usersegId.hashCode());
/*  76 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/*  80 */     if (this == obj)
/*  81 */       return true;
/*  82 */     if (obj == null)
/*  83 */       return false;
/*  84 */     if (getClass() != obj.getClass())
/*  85 */       return false;
/*  86 */     MtlConfirmExtendInfoId other = (MtlConfirmExtendInfoId)obj;
/*  87 */     if (this.campsegId == null) {
/*  88 */       if (other.campsegId != null)
/*  89 */         return false;
/*  90 */     } else if (!this.campsegId.equals(other.campsegId))
/*  91 */       return false;
/*  92 */     if (this.confirmUserid == null) {
/*  93 */       if (other.confirmUserid != null)
/*  94 */         return false;
/*  95 */     } else if (!this.confirmUserid.equals(other.confirmUserid))
/*  96 */       return false;
/*  97 */     if (this.resourceId == null) {
/*  98 */       if (other.resourceId != null)
/*  99 */         return false;
/* 100 */     } else if (!this.resourceId.equals(other.resourceId))
/* 101 */       return false;
/* 102 */     if (this.usersegId == null) {
/* 103 */       if (other.usersegId != null)
/* 104 */         return false;
/* 105 */     } else if (!this.usersegId.equals(other.usersegId))
/* 106 */       return false;
/* 107 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlConfirmExtendInfoId
 * JD-Core Version:    0.6.2
 */
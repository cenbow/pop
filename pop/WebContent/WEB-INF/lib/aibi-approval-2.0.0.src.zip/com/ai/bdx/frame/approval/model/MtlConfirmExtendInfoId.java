package com.ai.bdx.frame.approval.model;

public class MtlConfirmExtendInfoId implements java.io.Serializable {

	private String campsegId;

	private Integer resourceId;

	private Short usersegId;

	private String confirmUserid;
	
	private Short approveSeq;
	

	public MtlConfirmExtendInfoId() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MtlConfirmExtendInfoId(String campsegId, Integer resourceId, Short usersegId, String confirmUserid) {
		super();
		this.campsegId = campsegId;
		this.resourceId = resourceId;
		this.usersegId = usersegId;
		this.confirmUserid = confirmUserid;
	}

	public String getCampsegId() {
		return campsegId;
	}

	public void setCampsegId(String campsegId) {
		this.campsegId = campsegId;
	}

	public String getConfirmUserid() {
		return confirmUserid;
	}

	public void setConfirmUserid(String confirmUserid) {
		this.confirmUserid = confirmUserid;
	}

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public Short getUsersegId() {
		return usersegId;
	}

	public void setUsersegId(Short usersegId) {
		this.usersegId = usersegId;
	}

	public Short getApproveSeq() {
		return approveSeq;
	}

	public void setApproveSeq(Short approveSeq) {
		this.approveSeq = approveSeq;
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((campsegId == null) ? 0 : campsegId.hashCode());
		result = prime * result + ((confirmUserid == null) ? 0 : confirmUserid.hashCode());
		result = prime * result + ((resourceId == null) ? 0 : resourceId.hashCode());
		result = prime * result + ((usersegId == null) ? 0 : usersegId.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final MtlConfirmExtendInfoId other = (MtlConfirmExtendInfoId) obj;
		if (campsegId == null) {
			if (other.campsegId != null)
				return false;
		} else if (!campsegId.equals(other.campsegId))
			return false;
		if (confirmUserid == null) {
			if (other.confirmUserid != null)
				return false;
		} else if (!confirmUserid.equals(other.confirmUserid))
			return false;
		if (resourceId == null) {
			if (other.resourceId != null)
				return false;
		} else if (!resourceId.equals(other.resourceId))
			return false;
		if (usersegId == null) {
			if (other.usersegId != null)
				return false;
		} else if (!usersegId.equals(other.usersegId))
			return false;
		return true;
	}

}

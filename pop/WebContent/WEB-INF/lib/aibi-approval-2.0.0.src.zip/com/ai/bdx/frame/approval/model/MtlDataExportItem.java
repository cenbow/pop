/*
 * Created Tue Jun 13 13:44:19 CST 2006 by MyEclipse Hibernate Tool.
 */
package com.ai.bdx.frame.approval.model;

import java.io.Serializable;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.util.MpmCache;

/**
 * A class that represents a row in the 'MTL_DATA_EXPORT_ITEM' table. 
 * This class may be customized as it is never re-generated 
 * after being created.
 */
public class MtlDataExportItem implements Serializable {

	private MtlDataExportItemKey id = new MtlDataExportItemKey();

	private java.lang.Short columnType;

	private java.lang.Integer columnDest;

	private java.lang.Short dimcolumnDescFlag;

	private String columnCtype;

	private String dimcolumnCflag;

	private String columnCname;

	public MtlDataExportItem() {
	}

	public void setColumnCname(String columnCname) {
		this.columnCname = columnCname;
	}

	public String getColumnCname() {
		return this.columnCname;
	}

	public MtlDataExportItem(MtlDataExportItemKey id) {
		this.setId(id);
	}

	public MtlDataExportItemKey getId() {
		return this.id;
	}

	public void setId(MtlDataExportItemKey id) {
		this.id = id;
	}

	public Short getColumnType() {
		return this.columnType;
	}

	public void setColumnType(Short columnType) {
		this.columnType = columnType;
	}

	public java.lang.Integer getColumnDest() {
		return this.columnDest;
	}

	public void setColumnDest(java.lang.Integer columnDest) {
		this.columnDest = columnDest;
	}

	public java.lang.Short getDimcolumnDescFlag() {
		return this.dimcolumnDescFlag;
	}

	public void setDimcolumnDescFlag(java.lang.Short dimcolumnDescFlag) {
		this.dimcolumnDescFlag = dimcolumnDescFlag;
	}

	public String getColumnCtype() {
		String columntype = getColumnType().toString();
		return MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_DS_COLUMN_TYPE, columntype);
	}

	public String getDimcolumnCflag() {
		return MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_DATA_EXPORT_ITEM, dimcolumnDescFlag.toString());
	}
}

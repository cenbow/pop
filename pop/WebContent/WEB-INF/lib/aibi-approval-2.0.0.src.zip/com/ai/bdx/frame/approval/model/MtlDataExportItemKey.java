/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlDataExportItemKey
/*    */   implements Serializable
/*    */ {
/*    */   private Short campDrvId;
/*    */   private String columnName;
/*    */   private String sourceName;
/*    */ 
/*    */   public Short getCampDrvId()
/*    */   {
/* 29 */     return this.campDrvId;
/*    */   }
/*    */ 
/*    */   public void setCampDrvId(Short campDrvId) {
/* 33 */     this.campDrvId = campDrvId;
/*    */   }
/*    */ 
/*    */   public String getColumnName() {
/* 37 */     return this.columnName;
/*    */   }
/*    */ 
/*    */   public void setColumnName(String columnName) {
/* 41 */     this.columnName = columnName;
/*    */   }
/*    */ 
/*    */   public String getSourceName() {
/* 45 */     return this.sourceName;
/*    */   }
/*    */ 
/*    */   public void setSourceName(String sourceName) {
/* 49 */     this.sourceName = sourceName;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 53 */     if (this == other)
/* 54 */       return true;
/* 55 */     if (other == null)
/* 56 */       return false;
/* 57 */     if (!(other instanceof MtlDataExportItemKey))
/* 58 */       return false;
/* 59 */     MtlDataExportItemKey castOther = (MtlDataExportItemKey)other;
/*    */ 
/* 61 */     return ((getColumnName() == castOther.getColumnName()) || ((getColumnName() != null) && (castOther.getColumnName() != null) && (getColumnName().equals(castOther.getColumnName())))) && ((getSourceName() == castOther.getSourceName()) || ((getSourceName() != null) && (castOther.getSourceName() != null) && (getSourceName().equals(castOther.getSourceName())))) && ((getCampDrvId() == castOther.getCampDrvId()) || ((getCampDrvId() != null) && (castOther.getCampDrvId() != null) && (getCampDrvId().equals(castOther.getCampDrvId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 67 */     int result = 17;
/*    */ 
/* 69 */     result = 37 * result + (getColumnName() == null ? 0 : getColumnName().hashCode());
/* 70 */     result = 37 * result + (getSourceName() == null ? 0 : getSourceName().hashCode());
/* 71 */     result = 37 * result + (getCampDrvId() == null ? 0 : getCampDrvId().hashCode());
/* 72 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlDataExportItemKey
 * JD-Core Version:    0.6.2
 */
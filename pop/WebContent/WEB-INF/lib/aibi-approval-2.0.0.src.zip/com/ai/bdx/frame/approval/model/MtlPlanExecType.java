/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlPlanExecType
/*    */   implements Serializable
/*    */ {
/*    */   private String planExecId;
/*    */   private String planExecName;
/*    */   private Short planExecType;
/*    */   private Short planExecPeriod;
/*    */   private String planExecColumn;
/*    */ 
/*    */   public MtlPlanExecType()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MtlPlanExecType(Short planExecType, String planExecColumn)
/*    */   {
/* 29 */     this.planExecType = planExecType;
/* 30 */     this.planExecColumn = planExecColumn;
/*    */   }
/*    */ 
/*    */   public MtlPlanExecType(String planExecName, Short planExecType, Short planExecPeriod, String planExecColumn)
/*    */   {
/* 35 */     this.planExecName = planExecName;
/* 36 */     this.planExecType = planExecType;
/* 37 */     this.planExecPeriod = planExecPeriod;
/* 38 */     this.planExecColumn = planExecColumn;
/*    */   }
/*    */ 
/*    */   public String getPlanExecId()
/*    */   {
/* 44 */     return this.planExecId;
/*    */   }
/*    */ 
/*    */   public void setPlanExecId(String planExecId) {
/* 48 */     this.planExecId = planExecId;
/*    */   }
/*    */ 
/*    */   public String getPlanExecName() {
/* 52 */     return this.planExecName;
/*    */   }
/*    */ 
/*    */   public void setPlanExecName(String planExecName) {
/* 56 */     this.planExecName = planExecName;
/*    */   }
/*    */ 
/*    */   public Short getPlanExecType() {
/* 60 */     return this.planExecType;
/*    */   }
/*    */ 
/*    */   public void setPlanExecType(Short planExecType) {
/* 64 */     this.planExecType = planExecType;
/*    */   }
/*    */ 
/*    */   public Short getPlanExecPeriod() {
/* 68 */     return this.planExecPeriod;
/*    */   }
/*    */ 
/*    */   public void setPlanExecPeriod(Short planExecPeriod) {
/* 72 */     this.planExecPeriod = planExecPeriod;
/*    */   }
/*    */ 
/*    */   public String getPlanExecColumn() {
/* 76 */     return this.planExecColumn;
/*    */   }
/*    */ 
/*    */   public void setPlanExecColumn(String planExecColumn) {
/* 80 */     this.planExecColumn = planExecColumn;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlPlanExecType
 * JD-Core Version:    0.6.2
 */
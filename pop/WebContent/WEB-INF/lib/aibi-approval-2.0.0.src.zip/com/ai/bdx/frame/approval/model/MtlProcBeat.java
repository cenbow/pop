/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlProcBeat
/*    */   implements Serializable
/*    */ {
/*    */   private MtlProcBeatId id;
/*    */ 
/*    */   public MtlProcBeat()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MtlProcBeat(MtlProcBeatId id)
/*    */   {
/* 21 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public MtlProcBeatId getId()
/*    */   {
/* 27 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(MtlProcBeatId id) {
/* 31 */     this.id = id;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlProcBeat
 * JD-Core Version:    0.6.2
 */
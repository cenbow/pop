/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class MtlResList
/*     */   implements Serializable
/*     */ {
/*     */   private String resCode;
/*     */   private String resName;
/*     */   private String resDesc;
/*     */   private Short resFlag;
/*     */   private Long costCode;
/*     */   private Long resType;
/*     */   private Double resPrice;
/*     */ 
/*     */   public MtlResList()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlResList(String resCode)
/*     */   {
/*  33 */     this.resCode = resCode;
/*     */   }
/*     */ 
/*     */   public MtlResList(String resCode, String resName, String resDesc, Short resFlag, Long costCode, Long resType)
/*     */   {
/*  38 */     this.resCode = resCode;
/*  39 */     this.resName = resName;
/*  40 */     this.resDesc = resDesc;
/*  41 */     this.resFlag = resFlag;
/*  42 */     this.costCode = costCode;
/*  43 */     this.resType = resType;
/*     */   }
/*     */ 
/*     */   public String getResCode()
/*     */   {
/*  49 */     return this.resCode;
/*     */   }
/*     */ 
/*     */   public void setResCode(String resCode) {
/*  53 */     this.resCode = resCode;
/*     */   }
/*     */ 
/*     */   public String getResName() {
/*  57 */     return this.resName;
/*     */   }
/*     */ 
/*     */   public void setResName(String resName) {
/*  61 */     this.resName = resName;
/*     */   }
/*     */ 
/*     */   public String getResDesc() {
/*  65 */     return this.resDesc;
/*     */   }
/*     */ 
/*     */   public void setResDesc(String resDesc) {
/*  69 */     this.resDesc = resDesc;
/*     */   }
/*     */ 
/*     */   public Short getResFlag() {
/*  73 */     return this.resFlag;
/*     */   }
/*     */ 
/*     */   public void setResFlag(Short resFlag) {
/*  77 */     this.resFlag = resFlag;
/*     */   }
/*     */ 
/*     */   public Long getCostCode() {
/*  81 */     return this.costCode;
/*     */   }
/*     */ 
/*     */   public void setCostCode(Long costCode) {
/*  85 */     this.costCode = costCode;
/*     */   }
/*     */ 
/*     */   public Long getResType() {
/*  89 */     return this.resType;
/*     */   }
/*     */ 
/*     */   public void setResType(Long resType) {
/*  93 */     this.resType = resType;
/*     */   }
/*     */ 
/*     */   public Double getResPrice() {
/*  97 */     return this.resPrice;
/*     */   }
/*     */ 
/*     */   public void setResPrice(Double resPrice) {
/* 101 */     this.resPrice = resPrice;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlResList
 * JD-Core Version:    0.6.2
 */
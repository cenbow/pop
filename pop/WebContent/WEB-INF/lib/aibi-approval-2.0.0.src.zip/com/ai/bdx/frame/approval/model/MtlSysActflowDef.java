/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.util.MpmCache;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class MtlSysActflowDef
/*     */   implements Serializable
/*     */ {
/*     */   private String flowId;
/*     */   private String flowName;
/*     */   private String flowDesc;
/*     */   private String createUserid;
/*     */   private Date createTime;
/*     */   private Short warnFlag;
/*     */   private Integer statusChgType;
/*     */   private String warnFlagStr;
/*     */   private String statusChgTypeStr;
/*     */   private Short campType;
/*     */ 
/*     */   public MtlSysActflowDef()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlSysActflowDef(String flowId)
/*     */   {
/*  45 */     this.flowId = flowId;
/*     */   }
/*     */ 
/*     */   public MtlSysActflowDef(String flowId, String flowName, String flowDesc, String approveFlowId, String createUserid, Date createTime, Short warnFlag, Integer statusChgType)
/*     */   {
/*  50 */     this.flowId = flowId;
/*  51 */     this.flowName = flowName;
/*  52 */     this.flowDesc = flowDesc;
/*  53 */     this.createUserid = createUserid;
/*  54 */     this.createTime = createTime;
/*  55 */     this.warnFlag = warnFlag;
/*  56 */     this.statusChgType = statusChgType;
/*     */   }
/*     */ 
/*     */   public String getFlowId()
/*     */   {
/*  62 */     return this.flowId;
/*     */   }
/*     */ 
/*     */   public void setFlowId(String flowId) {
/*  66 */     this.flowId = flowId;
/*     */   }
/*     */ 
/*     */   public String getFlowName() {
/*  70 */     return this.flowName;
/*     */   }
/*     */ 
/*     */   public void setFlowName(String flowName) {
/*  74 */     this.flowName = flowName;
/*     */   }
/*     */ 
/*     */   public String getFlowDesc() {
/*  78 */     return this.flowDesc;
/*     */   }
/*     */ 
/*     */   public void setFlowDesc(String flowDesc) {
/*  82 */     this.flowDesc = flowDesc;
/*     */   }
/*     */ 
/*     */   public String getCreateUserid() {
/*  86 */     return this.createUserid;
/*     */   }
/*     */ 
/*     */   public void setCreateUserid(String createUserid) {
/*  90 */     this.createUserid = createUserid;
/*     */   }
/*     */ 
/*     */   public Date getCreateTime() {
/*  94 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(Date createTime) {
/*  98 */     this.createTime = createTime;
/*     */   }
/*     */ 
/*     */   public Short getWarnFlag() {
/* 102 */     return this.warnFlag;
/*     */   }
/*     */ 
/*     */   public void setWarnFlag(Short warnFlag) {
/* 106 */     this.warnFlag = warnFlag;
/*     */   }
/*     */ 
/*     */   public Integer getStatusChgType() {
/* 110 */     return this.statusChgType;
/*     */   }
/*     */ 
/*     */   public void setStatusChgType(Integer statusChgType) {
/* 114 */     this.statusChgType = statusChgType;
/*     */   }
/*     */ 
/*     */   public String getWarnFlagStr()
/*     */   {
/* 124 */     String result = "";
/* 125 */     result = MpmCache.getInstance().getNameByTypeAndKey("mpm_warn_flag_define", this.warnFlag.toString());
/* 126 */     return result;
/*     */   }
/*     */ 
/*     */   public String getStatusChgTypeStr() {
/* 130 */     String result = "";
/* 131 */     result = MpmCache.getInstance().getNameByTypeAndKey("statusChgType", this.statusChgType.toString());
/* 132 */     return result;
/*     */   }
/*     */ 
/*     */   public Short getCampType() {
/* 136 */     return this.campType;
/*     */   }
/*     */ 
/*     */   public void setCampType(Short campType) {
/* 140 */     this.campType = campType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlSysActflowDef
 * JD-Core Version:    0.6.2
 */
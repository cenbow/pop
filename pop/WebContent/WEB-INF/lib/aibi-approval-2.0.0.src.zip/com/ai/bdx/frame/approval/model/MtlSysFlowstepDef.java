/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlSysFlowstepDef
/*    */   implements Serializable
/*    */ {
/*    */   private MtlSysFlowstepDefId id;
/*    */ 
/*    */   public MtlSysFlowstepDef()
/*    */   {
/* 15 */     this.id = new MtlSysFlowstepDefId();
/*    */   }
/*    */ 
/*    */   public MtlSysFlowstepDef(MtlSysFlowstepDefId id)
/*    */   {
/* 20 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public MtlSysFlowstepDefId getId()
/*    */   {
/* 26 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(MtlSysFlowstepDefId id) {
/* 30 */     this.id = id;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlSysFlowstepDef
 * JD-Core Version:    0.6.2
 */
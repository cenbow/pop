/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlSysFlowstepDefId
/*    */   implements Serializable
/*    */ {
/*    */   private String flowId;
/*    */   private String stepId;
/*    */ 
/*    */   public String getFlowId()
/*    */   {
/* 24 */     return this.flowId;
/*    */   }
/*    */ 
/*    */   public void setFlowId(String flowId) {
/* 28 */     this.flowId = flowId;
/*    */   }
/*    */ 
/*    */   public String getStepId() {
/* 32 */     return this.stepId;
/*    */   }
/*    */ 
/*    */   public void setStepId(String stepId) {
/* 36 */     this.stepId = stepId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 40 */     if (this == other)
/* 41 */       return true;
/* 42 */     if (other == null)
/* 43 */       return false;
/* 44 */     if (!(other instanceof MtlSysFlowstepDefId))
/* 45 */       return false;
/* 46 */     MtlSysFlowstepDefId castOther = (MtlSysFlowstepDefId)other;
/*    */ 
/* 48 */     return ((getFlowId() == castOther.getFlowId()) || ((getFlowId() != null) && (castOther.getFlowId() != null) && (getFlowId().equals(castOther.getFlowId())))) && ((getStepId() == castOther.getStepId()) || ((getStepId() != null) && (castOther.getStepId() != null) && (getStepId().equals(castOther.getStepId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 57 */     int result = 17;
/*    */ 
/* 59 */     result = 37 * result + (getFlowId() == null ? 0 : getFlowId().hashCode());
/*    */ 
/* 61 */     result = 37 * result + (getStepId() == null ? 0 : getStepId().hashCode());
/*    */ 
/* 63 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlSysFlowstepDefId
 * JD-Core Version:    0.6.2
 */
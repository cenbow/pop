/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class MtlTargetuserFile
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String targetuserFileId;
/*     */   private String targetuserFileName;
/*     */   private String targetuserFileDesc;
/*     */   private String targetuserFileUrl;
/*     */   private Short fileLoadType;
/*     */   private String loadUserid;
/*     */   private Date loadTime;
/*     */   private String loadTabname;
/*     */   private Integer successLoadCnt;
/*     */   private Integer totalNeedLoadCnt;
/*     */   private Date loadEndTime;
/*     */   private String[] targetuserFileUrls;
/*     */   private String[] columnCname;
/*     */ 
/*     */   public MtlTargetuserFile()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlTargetuserFile(String targetuserFileId, Date loadTime)
/*     */   {
/*  53 */     this.targetuserFileId = targetuserFileId;
/*  54 */     this.loadTime = loadTime;
/*     */   }
/*     */ 
/*     */   public MtlTargetuserFile(String targetuserFileId, String targetuserFileName, String targetuserFileDesc, String targetuserFileUrl, Short fileLoadType, String loadUserid, Date loadTime, String loadTabname)
/*     */   {
/*  59 */     this.targetuserFileId = targetuserFileId;
/*  60 */     this.targetuserFileName = targetuserFileName;
/*  61 */     this.targetuserFileDesc = targetuserFileDesc;
/*  62 */     this.targetuserFileUrl = targetuserFileUrl;
/*  63 */     this.fileLoadType = fileLoadType;
/*  64 */     this.loadUserid = loadUserid;
/*  65 */     this.loadTime = loadTime;
/*  66 */     this.loadTabname = loadTabname;
/*     */   }
/*     */ 
/*     */   public String getTargetuserFileId()
/*     */   {
/*  72 */     return this.targetuserFileId;
/*     */   }
/*     */ 
/*     */   public void setTargetuserFileId(String targetuserFileId) {
/*  76 */     this.targetuserFileId = targetuserFileId;
/*     */   }
/*     */ 
/*     */   public String getTargetuserFileName() {
/*  80 */     return this.targetuserFileName;
/*     */   }
/*     */ 
/*     */   public void setTargetuserFileName(String targetuserFileName) {
/*  84 */     this.targetuserFileName = targetuserFileName;
/*     */   }
/*     */ 
/*     */   public String getTargetuserFileDesc() {
/*  88 */     return this.targetuserFileDesc;
/*     */   }
/*     */ 
/*     */   public void setTargetuserFileDesc(String targetuserFileDesc) {
/*  92 */     this.targetuserFileDesc = targetuserFileDesc;
/*     */   }
/*     */ 
/*     */   public String getTargetuserFileUrl() {
/*  96 */     return this.targetuserFileUrl;
/*     */   }
/*     */ 
/*     */   public void setTargetuserFileUrl(String targetuserFileUrl) {
/* 100 */     this.targetuserFileUrl = targetuserFileUrl;
/*     */   }
/*     */ 
/*     */   public Short getFileLoadType() {
/* 104 */     return this.fileLoadType;
/*     */   }
/*     */ 
/*     */   public void setFileLoadType(Short fileLoadType) {
/* 108 */     this.fileLoadType = fileLoadType;
/*     */   }
/*     */ 
/*     */   public String getLoadUserid() {
/* 112 */     return this.loadUserid;
/*     */   }
/*     */ 
/*     */   public void setLoadUserid(String loadUserid) {
/* 116 */     this.loadUserid = loadUserid;
/*     */   }
/*     */ 
/*     */   public Date getLoadTime() {
/* 120 */     return this.loadTime;
/*     */   }
/*     */ 
/*     */   public void setLoadTime(Date loadTime) {
/* 124 */     this.loadTime = loadTime;
/*     */   }
/*     */ 
/*     */   public String getLoadTabname() {
/* 128 */     return this.loadTabname;
/*     */   }
/*     */ 
/*     */   public void setLoadTabname(String loadTabname) {
/* 132 */     this.loadTabname = loadTabname;
/*     */   }
/*     */ 
/*     */   public Integer getSuccessLoadCnt() {
/* 136 */     return this.successLoadCnt;
/*     */   }
/*     */ 
/*     */   public void setSuccessLoadCnt(Integer successLoadCnt) {
/* 140 */     this.successLoadCnt = successLoadCnt;
/*     */   }
/*     */ 
/*     */   public Date getLoadEndTime() {
/* 144 */     return this.loadEndTime;
/*     */   }
/*     */ 
/*     */   public void setLoadEndTime(Date loadEndTime) {
/* 148 */     this.loadEndTime = loadEndTime;
/*     */   }
/*     */ 
/*     */   public Integer getTotalNeedLoadCnt() {
/* 152 */     return this.totalNeedLoadCnt;
/*     */   }
/*     */ 
/*     */   public void setTotalNeedLoadCnt(Integer totalNeedLoadCnt) {
/* 156 */     this.totalNeedLoadCnt = totalNeedLoadCnt;
/*     */   }
/*     */ 
/*     */   public String[] getTargetuserFileUrls() {
/* 160 */     return this.targetuserFileUrls;
/*     */   }
/*     */ 
/*     */   public void setTargetuserFileUrls(String[] targetuserFileUrls) {
/* 164 */     this.targetuserFileUrls = targetuserFileUrls;
/*     */   }
/*     */ 
/*     */   public void setColumnCname(String[] columnCname) {
/* 168 */     this.columnCname = columnCname;
/*     */   }
/*     */ 
/*     */   public String[] getColumnCname() {
/* 172 */     return this.columnCname;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlTargetuserFile
 * JD-Core Version:    0.6.2
 */
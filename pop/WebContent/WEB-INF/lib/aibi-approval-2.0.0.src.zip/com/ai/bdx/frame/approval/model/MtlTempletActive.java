/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MtlTempletActive
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String activeTempletId;
/*     */   private String atempletName;
/*     */   private String createUserid;
/*     */   private Date createTime;
/*     */   private String atempletDesc;
/*     */   private Short atempletType;
/*     */   private Set fields;
/*     */ 
/*     */   public MtlTempletActive()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MtlTempletActive(String activeTempletId)
/*     */   {
/*  39 */     this.activeTempletId = activeTempletId;
/*     */   }
/*     */ 
/*     */   public MtlTempletActive(String activeTempletId, String atempletName, String createUserid, Date createTime, String atempletDesc, Short atempletType)
/*     */   {
/*  44 */     this.activeTempletId = activeTempletId;
/*  45 */     this.atempletName = atempletName;
/*  46 */     this.createUserid = createUserid;
/*  47 */     this.createTime = createTime;
/*  48 */     this.atempletDesc = atempletDesc;
/*  49 */     this.atempletType = atempletType;
/*     */   }
/*     */ 
/*     */   public String getActiveTempletId()
/*     */   {
/*  55 */     return this.activeTempletId;
/*     */   }
/*     */ 
/*     */   public void setActiveTempletId(String activeTempletId) {
/*  59 */     this.activeTempletId = activeTempletId;
/*     */   }
/*     */ 
/*     */   public String getAtempletName() {
/*  63 */     return this.atempletName;
/*     */   }
/*     */ 
/*     */   public void setAtempletName(String atempletName) {
/*  67 */     this.atempletName = atempletName;
/*     */   }
/*     */ 
/*     */   public String getCreateUserid() {
/*  71 */     return this.createUserid;
/*     */   }
/*     */ 
/*     */   public void setCreateUserid(String createUserid) {
/*  75 */     this.createUserid = createUserid;
/*     */   }
/*     */ 
/*     */   public Date getCreateTime() {
/*  79 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(Date createTime) {
/*  83 */     this.createTime = createTime;
/*     */   }
/*     */ 
/*     */   public String getAtempletDesc() {
/*  87 */     return this.atempletDesc;
/*     */   }
/*     */ 
/*     */   public void setAtempletDesc(String atempletDesc) {
/*  91 */     this.atempletDesc = atempletDesc;
/*     */   }
/*     */ 
/*     */   public Short getAtempletType() {
/*  95 */     return this.atempletType;
/*     */   }
/*     */ 
/*     */   public void setAtempletType(Short atempletType) {
/*  99 */     this.atempletType = atempletType;
/*     */   }
/*     */ 
/*     */   public Set getFields() {
/* 103 */     return this.fields;
/*     */   }
/*     */ 
/*     */   public void setFields(Set fields) {
/* 107 */     this.fields = fields;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlTempletActive
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.model;

import java.util.Date;
import java.util.Set;


public class MtlTempletActive implements java.io.Serializable {

	// Fields    

	
	 /** 
	  * serialVersionUID:TODO 
	  */
	private static final long serialVersionUID = 1L;

	private String activeTempletId;

	private String atempletName;

	private String createUserid;

	private Date createTime;

	private String atempletDesc;

	private Short atempletType;

	private Set fields;

	// Constructors

	/** default constructor */
	public MtlTempletActive() {
	}

	/** minimal constructor */
	public MtlTempletActive(String activeTempletId) {
		this.activeTempletId = activeTempletId;
	}

	/** full constructor */
	public MtlTempletActive(String activeTempletId, String atempletName, String createUserid, Date createTime, String atempletDesc, Short atempletType) {
		this.activeTempletId = activeTempletId;
		this.atempletName = atempletName;
		this.createUserid = createUserid;
		this.createTime = createTime;
		this.atempletDesc = atempletDesc;
		this.atempletType = atempletType;
	}

	// Property accessors

	public String getActiveTempletId() {
		return this.activeTempletId;
	}

	public void setActiveTempletId(String activeTempletId) {
		this.activeTempletId = activeTempletId;
	}

	public String getAtempletName() {
		return this.atempletName;
	}

	public void setAtempletName(String atempletName) {
		this.atempletName = atempletName;
	}

	public String getCreateUserid() {
		return this.createUserid;
	}

	public void setCreateUserid(String createUserid) {
		this.createUserid = createUserid;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getAtempletDesc() {
		return this.atempletDesc;
	}

	public void setAtempletDesc(String atempletDesc) {
		this.atempletDesc = atempletDesc;
	}

	public Short getAtempletType() {
		return this.atempletType;
	}

	public void setAtempletType(Short atempletType) {
		this.atempletType = atempletType;
	}

	public Set getFields() {
		return fields;
	}

	public void setFields(Set fields) {
		this.fields = fields;
	}

}

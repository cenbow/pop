/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.util.MpmCache;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlTempletActiveField
/*    */   implements Serializable
/*    */ {
/* 14 */   private MtlTempletActiveFieldId id = new MtlTempletActiveFieldId();
/*    */   private String columnCname;
/*    */   private Short columnFlag;
/*    */   private String columnCtype;
/*    */   private String identityStr;
/*    */ 
/*    */   public MtlTempletActiveField()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MtlTempletActiveField(MtlTempletActiveFieldId id)
/*    */   {
/* 32 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public MtlTempletActiveField(MtlTempletActiveFieldId id, String columnCname)
/*    */   {
/* 37 */     this.id = id;
/* 38 */     this.columnCname = columnCname;
/*    */   }
/*    */ 
/*    */   public MtlTempletActiveFieldId getId()
/*    */   {
/* 44 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(MtlTempletActiveFieldId id) {
/* 48 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getColumnCname() {
/* 52 */     return this.columnCname;
/*    */   }
/*    */ 
/*    */   public void setColumnCname(String columnCname) {
/* 56 */     this.columnCname = columnCname;
/*    */   }
/*    */ 
/*    */   public String getIdentityStr() {
/* 60 */     StringBuffer sb = new StringBuffer();
/* 61 */     sb.append(this.id.getColumnName() + "|" + this.id.getSourceName() + "|" + this.id.getColumnType() + "|" + this.columnFlag + "|" + this.columnCname);
/* 62 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public void setIdentityStr(String identityStr) {
/* 66 */     this.identityStr = identityStr;
/*    */   }
/*    */ 
/*    */   public String getColumnCtype() {
/* 70 */     Short columntype = this.id.getColumnType();
/* 71 */     return MpmCache.getInstance().getNameByTypeAndKey("mpm_ds_column_type", columntype.toString());
/*    */   }
/*    */ 
/*    */   public Short getColumnFlag() {
/* 75 */     return this.columnFlag;
/*    */   }
/*    */ 
/*    */   public void setColumnFlag(Short columnFlag) {
/* 79 */     this.columnFlag = columnFlag;
/*    */   }
/*    */ 
/*    */   public void setCcolumnCtype(String columnCtype) {
/* 83 */     this.columnCtype = columnCtype;
/*    */   }
/*    */ 
/*    */   public void setColumnCtype(String columnCtype)
/*    */   {
/* 91 */     this.columnCtype = columnCtype;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlTempletActiveField
 * JD-Core Version:    0.6.2
 */
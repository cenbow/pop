/*    */ package com.ai.bdx.frame.approval.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MtlTempletActiveFieldId
/*    */   implements Serializable
/*    */ {
/*    */   private String columnName;
/*    */   private String sourceName;
/*    */   private Short columnType;
/*    */   private String activeTempletId;
/*    */ 
/*    */   public String getColumnName()
/*    */   {
/* 28 */     return this.columnName;
/*    */   }
/*    */ 
/*    */   public void setColumnName(String columnName) {
/* 32 */     this.columnName = columnName;
/*    */   }
/*    */ 
/*    */   public String getSourceName() {
/* 36 */     return this.sourceName;
/*    */   }
/*    */ 
/*    */   public void setSourceName(String sourceName) {
/* 40 */     this.sourceName = sourceName;
/*    */   }
/*    */ 
/*    */   public Short getColumnType() {
/* 44 */     return this.columnType;
/*    */   }
/*    */ 
/*    */   public void setColumnType(Short columnType) {
/* 48 */     this.columnType = columnType;
/*    */   }
/*    */ 
/*    */   public String getActiveTempletId() {
/* 52 */     return this.activeTempletId;
/*    */   }
/*    */ 
/*    */   public void setActiveTempletId(String activeTempletId) {
/* 56 */     this.activeTempletId = activeTempletId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 60 */     if (this == other)
/* 61 */       return true;
/* 62 */     if (other == null)
/* 63 */       return false;
/* 64 */     if (!(other instanceof MtlTempletActiveFieldId))
/* 65 */       return false;
/* 66 */     MtlTempletActiveFieldId castOther = (MtlTempletActiveFieldId)other;
/*    */ 
/* 68 */     return ((getColumnName() == castOther.getColumnName()) || ((getColumnName() != null) && (castOther.getColumnName() != null) && (getColumnName().equals(castOther.getColumnName())))) && ((getSourceName() == castOther.getSourceName()) || ((getSourceName() != null) && (castOther.getSourceName() != null) && (getSourceName().equals(castOther.getSourceName())))) && ((getColumnType() == castOther.getColumnType()) || ((getColumnType() != null) && (castOther.getColumnType() != null) && (getColumnType().equals(castOther.getColumnType())))) && ((getActiveTempletId() == castOther.getActiveTempletId()) || ((getActiveTempletId() != null) && (castOther.getActiveTempletId() != null) && (getActiveTempletId().equals(castOther.getActiveTempletId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 75 */     int result = 17;
/*    */ 
/* 77 */     result = 37 * result + (getColumnName() == null ? 0 : getColumnName().hashCode());
/* 78 */     result = 37 * result + (getSourceName() == null ? 0 : getSourceName().hashCode());
/* 79 */     result = 37 * result + (getColumnType() == null ? 0 : getColumnType().hashCode());
/* 80 */     result = 37 * result + (getActiveTempletId() == null ? 0 : getActiveTempletId().hashCode());
/* 81 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.MtlTempletActiveFieldId
 * JD-Core Version:    0.6.2
 */
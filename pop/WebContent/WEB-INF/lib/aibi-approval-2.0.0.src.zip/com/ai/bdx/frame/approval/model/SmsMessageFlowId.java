/*     */ package com.ai.bdx.frame.approval.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class SmsMessageFlowId
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1224527501514448259L;
/*     */   private String productNo;
/*     */   private String msg;
/*     */   private Short flag;
/*     */   private String sendtype;
/*     */   private long id;
/*     */   private String taskId;
/*     */   private String channelId;
/*     */   private int status;
/*     */   private int sendCount;
/*     */   private Timestamp createTime;
/*     */   private Timestamp updateTime;
/*     */ 
/*     */   public String getMsg()
/*     */   {
/*  44 */     return this.msg;
/*     */   }
/*     */ 
/*     */   public void setMsg(String msg) {
/*  48 */     this.msg = msg;
/*     */   }
/*     */ 
/*     */   public String getProductNo() {
/*  52 */     return this.productNo;
/*     */   }
/*     */ 
/*     */   public void setProductNo(String productNo) {
/*  56 */     this.productNo = productNo;
/*     */   }
/*     */ 
/*     */   public Short getFlag() {
/*  60 */     return this.flag;
/*     */   }
/*     */ 
/*     */   public void setFlag(Short flag) {
/*  64 */     this.flag = flag;
/*     */   }
/*     */ 
/*     */   public String getSendtype() {
/*  68 */     return this.sendtype;
/*     */   }
/*     */ 
/*     */   public void setSendtype(String sendtype) {
/*  72 */     this.sendtype = sendtype;
/*     */   }
/*     */ 
/*     */   public long getId() {
/*  76 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(long id) {
/*  80 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/*  84 */     return this.taskId;
/*     */   }
/*     */ 
/*     */   public void setTaskId(String taskId) {
/*  88 */     this.taskId = taskId;
/*     */   }
/*     */ 
/*     */   public String getChannelId() {
/*  92 */     return this.channelId;
/*     */   }
/*     */ 
/*     */   public void setChannelId(String channelId) {
/*  96 */     this.channelId = channelId;
/*     */   }
/*     */ 
/*     */   public int getStatus() {
/* 100 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(int status) {
/* 104 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public int getSendCount() {
/* 108 */     return this.sendCount;
/*     */   }
/*     */ 
/*     */   public void setSendCount(int sendCount) {
/* 112 */     this.sendCount = sendCount;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateTime() {
/* 116 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(Timestamp createTime) {
/* 120 */     this.createTime = createTime;
/*     */   }
/*     */ 
/*     */   public Timestamp getUpdateTime() {
/* 124 */     return this.updateTime;
/*     */   }
/*     */ 
/*     */   public void setUpdateTime(Timestamp updateTime) {
/* 128 */     this.updateTime = updateTime;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.model.SmsMessageFlowId
 * JD-Core Version:    0.6.2
 */
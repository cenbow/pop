package com.ai.bdx.frame.approval.model;

import java.sql.Timestamp;


/**
 * (名称可与数据库字段名不一致)
 * SmsMessageFlowId entity.
 *
 * @author MyEclipse Persistence Tools
 */

public class SmsMessageFlowId implements java.io.Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1224527501514448259L;
	/*
	 * 比不可少字段
	 */
	private String productNo; //电话号码
	private String msg; //消息
	/*
	 * 不同省份短信表其他字段
	 */
	private Short flag;
	private String sendtype;

	private long id;
	private String taskId;
	private String channelId;
	private int status;
	private int sendCount;
	private Timestamp createTime;
	private Timestamp updateTime;

	// Constructors
	/** default constructor */
	public SmsMessageFlowId() {
	}

	// Property accessors
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	public String getSendtype() {
		return sendtype;
	}

	public void setSendtype(String sendtype) {
		this.sendtype = sendtype;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getSendCount() {
		return sendCount;
	}

	public void setSendCount(int sendCount) {
		this.sendCount = sendCount;
	}

	public Timestamp getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}

	public Timestamp getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}
}
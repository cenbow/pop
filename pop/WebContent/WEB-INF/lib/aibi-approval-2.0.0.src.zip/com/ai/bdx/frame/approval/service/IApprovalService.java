package com.ai.bdx.frame.approval.service;

import java.util.List;
import java.util.TreeMap;

import com.ai.bdx.frame.approval.bean.ApApproveList;
import com.ai.bdx.frame.approval.bean.ApproveTriggerCondDef;

/**
 * 审批确认过程查询获取方法
 * @author Administrator
 *
 */
public interface IApprovalService {

	/**
	 * 根据流程配置中ap_dept_flow_relation配置关系查询审批流程ID
	 * @param userId 用户ID
	 * @param drvTypeID 驱动类型分类ID
	 * @param drvID 驱动类型ID
	 * @param approvalType 审批类型 1 审批流程 2 确认流程
	 * @return 流程ID
	 */
	public String getApprovalFlowIDByDeptFlowRelation(String userId, String drvTypeID, String drvID, String approvalType)
			throws Exception;

	/**
	 * 判断是否有确认流程
	 * @param userId 用户ID
	 * @param drvTypeID  驱动类型分类ID
	 * @param drvID  驱动类型ID
	 * @return true 有 fasle  没有
	 * @throws Exception 
	 */
	public boolean isHasConfirmFlow(String userId, String drvTypeID, String drvID) throws Exception;

	/**
	 * 判断是有审批流程
	 * @param userId
	 * @param drvTypeID
	 * @param drvID
	 * @return true 有 fasle 没有
	 * @throws Exception 
	 */
	public boolean isHasApprovalFlow(String userId, String drvTypeID, String drvID) throws Exception;

	/**
	 * 
	 * deleteApproverList:根据条件删除原有审批确认列表
	 * @param approvalFlowId
	 * @param approvalId
	 * @param approve_userid
	 * @param approvalType
	 * @return 
	 * @return int
	 * @throws Exception 
	 */
	public int deleteApproverList(String approvalFlowId, String approvalId, String approve_userid, String approvalType)
			throws Exception;

	/**
	 * 
	 * saveApproverList:保存审批确认列表
	 * @param approvalFlowId
	 * @param approvalId
	 * @param status
	 * @param approveUserId
	 * @param drvTypeID
	 * @param drvID
	 * @param approvalType
	 * @throws Exception 
	 */
	public void saveApproverList(String approvalFlowId, String approvalId, Integer status, String approveUserId,
			String drvTypeID, String drvID, String approvalType) throws Exception;

	/**
	 * 
	 * processApprove: 
	 * @return void
	 */
	public void processOaApprove(String serverIp, String serverPort, String approvalFlowId, String approvalId,
			Integer status, String needApprovalUserid, String drvTypeID, String drvID) throws Exception;

	/**
	 * 
	 * processApproveTriggerCondDef:处理审批触发条件定义，返回根据条件定义需要把审批额外提交的审批人编号
	 * @param cond
	 * @param approvalId
	 * @param needApproveUserid
	 * @return
	 * @throws Exception 
	 * @return String
	 */
	public String processApproveTriggerCondDef(ApproveTriggerCondDef cond, String approvalId, String needApproveUserid)
			throws Exception;

	/**
	 * 更新审批确认持有令牌
	 * @param approvalId
	 * @param approvalType
	 * @param approvalFlag 审批结果0 - 待审批 确认  	1 - 通过 	2 - 不通过 	9 - 终止
	 * @return String  1 ：同级审批人还有未审批的 2：同级审批人全部审批过 3：当前流程结束
	 * @throws Exception
	 */
	public String updateApprovalToken(String approvalId, String approvalType, String approvalFlag, String userId)
			throws Exception;

	/**
	 * 审批确认不通过
	 * @param approvalId
	 * @param needApprovalUserid
	 * @param drvTypeID
	 * @param drvID
	 * @param advice
	 * @return
	 * @throws Exception
	 */
	public int updateApprovalNotPass(String approvalId, String approvalType, String needApprovalUserid,
			String drvTypeID, String drvID, String advice) throws Exception;

	/**
	 *获取审批进程
	 * @param approvalId 审批对象ID
	 * @param approvalType 审批确认类型  1=ApprovalCONST.FLOW_TYPE_APPROVL  审批  2=ApprovalCONST.FLOW_TYPE_CONFIRM 确认
	 * @return
	 * @throws Exception
	 */
	public List<ApApproveList> getApprovalProcess(String approvalId, String approvalType) throws Exception;

	/**
	 * 获取某对象所有审批进程
	 * @param approvalId 审批对象ID
	 * @return
	 * @throws Exception
	 */
	public List<ApApproveList> getApprovalProcess(String approvalId) throws Exception;

	/**
	 * 
	 * getApprovalProcessDesc:获取某对象所有审批确认进程，带描述
	 * @param approvalId  审批确认对象ID
	 * @param approvalType 可为null null空查询是查询包括审批确认流程 1 查询审批流程，2查询确认流程
	 * @return
	 * @throws Exception 
	 * @return List<ApApproveList>
	 */
	public List<ApApproveList> getApprovalProcessDesc(String approvalId, String approvalType) throws Exception;

	/**
	 * 
	 * getApprovalTypeProcess:根据用户审批确认对象id查询该对象需要走的流程过程
	 * @param approvalId 要审批确认对象ID
	 * @return 没有审批确认过程，其他有审批确认过程
	 * @throws Exception 
	 * @return TreeMap<String,String>
	 */
	public TreeMap<String, String> getApprovalTypeProcess(String approvalId) throws Exception;

	/**
	 * 根据驱动分类和实际值查询流程模式
	 * @param drvTypeID
	 * @param drvID
	* @throws Exception 
	 */
	public String getApproveDrvType(String drvTypeID, String drvID) throws Exception;

	/**
	 * 
	 * updateFirstApproveOrConfirmUserToken:更新确认令牌持有
	 * @param approvalId
	 * @param approvlType
	 * @throws Exception 
	 * @return void
	 */
	public void updateFirstApproveOrConfirmUserToken(String approvalId, String approvlType) throws Exception;

	/**
	 * 让第一确认持有令牌
	 * @param approvalId
	 * @return
	 */
	//public int updateFirstConfirmUserToken(String approvalId);
	/**
	 * 更新审批确认意见
	 * @param approvalId
	 * @param app_flow_id
	 * @param approvalSeq
	 * @param approve_level
	 * @param approve_userId
	 * @param approvalType
	 * @param approve_advice
	 * @return
	 * @throws Exception 
	 */
	public int updateConfirmAdvice(String approvalId, String app_flow_id, Integer approvalSeq, Integer approve_level,
			String approve_userId, String approvalType, String approve_advice) throws Exception;

	/**
	 * 转其他审批确认人
	 * @param approvalId
	 * @param app_flow_id
	 * @param approvalSeq
	 * @param approve_level
	 * @param approve_userId
	 * @param approvalType
	 * @param approve_advice
	 */
	public void tranOtherApproveUser(String approvalId, String app_flow_id, Integer approvalSeq, Integer approve_level,
			String approve_userId, String approvalType, String approve_advice);

	/**
	 * 整理审批确认过程，该方法初始化审批确认流程前先删除原有的
	 * @param approvalId 要审批的策略id 活动id等
	 * @param status 要审批的策略或活动等当前所处状态
	 * @param needApprovalUserid 当前用户
	 * @param drvTypeID  驱动类型分类
	 * @param drvID 驱动类型
	 * @throws Exception
	 */
	public void doApproval(String approvalId, Integer status, String needApprovalUserid, String drvTypeID, String drvID)
			throws Exception;

	/**
	 * 整理审批确认过程
	 * @param approvalId
	 * @param status
	 * @param needApprovalUserid
	 * @param drvTypeID
	 * @param drvID
	 * @throws Exception
	 */
	public void doInitApproval(String approvalId, Integer status, String needApprovalUserid, String drvTypeID,
			String drvID) throws Exception;

	/**
	 * 根据用户查询改用户下需要的对象ID
	 * @param userId 用户ID
	 * @param approvalType 1 审批 2 确认
	 * @return List<审批确认对象ID>
	 * @throws Exception
	 */
	public List getApprovalIdByUser(String userId, String approvalType) throws Exception;

	/**
	 * 根据当前审批节点查询下下级所有节点
	 * @param ap
	 * @return
	 * @throws Exception 
	 */
	public List<ApApproveList> getNextApprovalProcess(ApApproveList ap) throws Exception;

	/**
	 * 
	 * saveTranOtherUser:审批转发到其他人
	 * @param approvalId 要转发的对象ID
	 * @param tranUserID 转发到的用户ID
	 * @return int
	 */
	public int saveTranOtherUser(String approvalId, String tranUserID) throws Exception;

	/**
	 * 
	 * getCurrentApproversByApprovalID:根据审批对象ID查询所有当前审批人
	 * @param approvalID
	 * @return
	 * @throws Exception 
	 * @return List<String>
	 */
	public List<String> getCurrentApproversByApprovalID(String approvalID) throws Exception;
}
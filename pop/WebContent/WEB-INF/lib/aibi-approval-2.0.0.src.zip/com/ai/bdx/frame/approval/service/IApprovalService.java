package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.bean.ApApproveList;
import com.ai.bdx.frame.approval.bean.ApproveTriggerCondDef;
import java.util.List;
import java.util.TreeMap;

public abstract interface IApprovalService
{
  public abstract String getApprovalFlowIDByDeptFlowRelation(String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract boolean isHasConfirmFlow(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract boolean isHasApprovalFlow(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract int deleteApproverList(String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract void saveApproverList(String paramString1, String paramString2, Integer paramInteger, String paramString3, String paramString4, String paramString5, String paramString6)
    throws Exception;

  public abstract void processOaApprove(String paramString1, String paramString2, String paramString3, String paramString4, Integer paramInteger, String paramString5, String paramString6, String paramString7)
    throws Exception;

  public abstract String processApproveTriggerCondDef(ApproveTriggerCondDef paramApproveTriggerCondDef, String paramString1, String paramString2)
    throws Exception;

  public abstract String updateApprovalToken(String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract int updateApprovalNotPass(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws Exception;

  public abstract List<ApApproveList> getApprovalProcess(String paramString1, String paramString2)
    throws Exception;

  public abstract List<ApApproveList> getApprovalProcess(String paramString)
    throws Exception;

  public abstract List<ApApproveList> getApprovalProcessDesc(String paramString1, String paramString2)
    throws Exception;

  public abstract TreeMap<String, String> getApprovalTypeProcess(String paramString)
    throws Exception;

  public abstract String getApproveDrvType(String paramString1, String paramString2)
    throws Exception;

  public abstract void updateFirstApproveOrConfirmUserToken(String paramString1, String paramString2)
    throws Exception;

  public abstract int updateConfirmAdvice(String paramString1, String paramString2, Integer paramInteger1, Integer paramInteger2, String paramString3, String paramString4, String paramString5)
    throws Exception;

  public abstract void tranOtherApproveUser(String paramString1, String paramString2, Integer paramInteger1, Integer paramInteger2, String paramString3, String paramString4, String paramString5);

  public abstract void doApproval(String paramString1, Integer paramInteger, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract void doInitApproval(String paramString1, Integer paramInteger, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract List getApprovalIdByUser(String paramString1, String paramString2)
    throws Exception;

  public abstract List<ApApproveList> getNextApprovalProcess(ApApproveList paramApApproveList)
    throws Exception;

  public abstract int saveTranOtherUser(String paramString1, String paramString2)
    throws Exception;

  public abstract List<String> getCurrentApproversByApprovalID(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IApprovalService
 * JD-Core Version:    0.6.2
 */
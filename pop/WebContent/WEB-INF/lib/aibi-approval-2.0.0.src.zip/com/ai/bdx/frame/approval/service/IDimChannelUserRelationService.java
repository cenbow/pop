package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimChannelUserRelationForm;
import com.ai.bdx.frame.approval.model.DimChannelUserRelation;
import java.util.List;
import java.util.Map;

public abstract interface IDimChannelUserRelationService
{
  public abstract Map searchChannelUserRelation(DimChannelUserRelationForm paramDimChannelUserRelationForm, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void delete(DimChannelUserRelationForm paramDimChannelUserRelationForm)
    throws MpmException;

  public abstract void save(DimChannelUserRelation paramDimChannelUserRelation)
    throws MpmException;

  public abstract DimChannelUserRelation getChannelUserRelation(int paramInt, Short paramShort)
    throws MpmException;

  public abstract DimChannelUserRelation getChannelUserRelation(Short paramShort, String paramString, int paramInt)
    throws MpmException;

  public abstract List getAllChanneltype()
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IDimChannelUserRelationService
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service;


import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimChannelUserRelationForm;
import com.ai.bdx.frame.approval.model.DimChannelUserRelation;

/**
 * 
 * Created on 2008-3-7
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author qixf
 * @version 1.0
 */
public interface IDimChannelUserRelationService {

	/**
	 * 查询资源渠道确认人对应信息
	 * @param searchForm
	 * @return
	 * @throws MpmException
	 */
	public Map searchChannelUserRelation(DimChannelUserRelationForm searchForm, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 保存资源渠道确认人对应信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void delete(DimChannelUserRelationForm searchForm) throws MpmException;

	/**
	 * 删除资源渠道确认人对应信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void save(DimChannelUserRelation dimChannelUserRelation) throws MpmException;

	/**
	 * 取资源渠道确认人对应信息
	 * @param rid
	 * @param cType
	 * @return
	 * @throws MpmException
	 */
	public DimChannelUserRelation getChannelUserRelation(int rid, Short cType) throws MpmException;

	/**
	 * 取资源渠道确认人对应信息
	 * @param channelType
	 * @param channelId
	 * @param confirmType
	 * @return
	 * @throws MpmException
	 */
	public DimChannelUserRelation getChannelUserRelation(Short channelType, String channelId, int confirmType) throws MpmException;

	/**
	 * 取所有资源渠道确认人对应信息
	 * @param rid
	 * @param cType
	 * @return
	 * @throws MpmException
	 */
	public List getAllChanneltype() throws MpmException;
}

package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimDeptFlowRelationForm;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelationId;
import java.util.List;
import java.util.Map;

public abstract interface IDimDeptFlowRelationService
{
  public abstract Map searchDeptFlowRelation(DimDeptFlowRelationForm paramDimDeptFlowRelationForm, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void save(DimDeptFlowRelation paramDimDeptFlowRelation)
    throws MpmException;

  public abstract void modify(DimDeptFlowRelationForm paramDimDeptFlowRelationForm)
    throws MpmException;

  public abstract void delete(DimDeptFlowRelationId paramDimDeptFlowRelationId)
    throws MpmException;

  public abstract DimDeptFlowRelation getDeptFlowRelation(int paramInt, Short paramShort)
    throws MpmException;

  public abstract DimDeptFlowRelation getDeptFlowRelation(Short paramShort, String paramString, int paramInt)
    throws MpmException;

  public abstract List getAllDeptFlowRelation()
    throws MpmException;

  public abstract Map findDeptFlowActions(DimDeptFlowRelation paramDimDeptFlowRelation, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract boolean isObjectExist(DimDeptFlowRelationId paramDimDeptFlowRelationId)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IDimDeptFlowRelationService
 * JD-Core Version:    0.6.2
 */
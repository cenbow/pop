package com.ai.bdx.frame.approval.service;


import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimDeptFlowRelationForm;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelationId;

public interface IDimDeptFlowRelationService{
	
	/**
	 * 查询审批权限配置对应信息
	 * @param searchForm
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 */
	public Map searchDeptFlowRelation(DimDeptFlowRelationForm searchForm, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 保存审批权限配置对应信息
	 * @param dimDeptFlowRelation
	 * @throws MpmException
	 */
	public void save(DimDeptFlowRelation dimDeptFlowRelation) throws MpmException;
	
	/**
	 * 修改审批权限配置对应信息
	 * @param modifyForm
	 * @throws MpmException
	 */
	public void modify(DimDeptFlowRelationForm modifyForm) throws MpmException;
	
	/**
	 * 删除审批权限配置对应信息
	 * @param deleteForm
	 * @throws MpmException
	 */
	public void delete(DimDeptFlowRelationId dimDeptFlowRelationId) throws MpmException;
	
	/**
	 * 取审批权限配置对应信息
	 * @param rid
	 * @param cType
	 * @return
	 * @throws MpmException
	 */
	public DimDeptFlowRelation getDeptFlowRelation(int rid, Short cType) throws MpmException;

	/**
	 * 取审批权限配置对应信息
	 * @param deptflow
	 * @param channelId
	 * @param confirmType
	 * @return
	 * @throws MpmException
	 */
	public DimDeptFlowRelation getDeptFlowRelation(Short channelType, String channelId, int confirmType) throws MpmException;

	/**
	 * 取所有审批权限配置对应信息
	 * @param rid
	 * @param cType
	 * @return
	 * @throws MpmException
	 */
	public List getAllDeptFlowRelation() throws MpmException;
	/**
	 * 查询审批权限配置对应信息
	 * @param searchForm
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 */
	public Map findDeptFlowActions(DimDeptFlowRelation dimDeptFlowRelation, Integer curPage, Integer pageSize) throws MpmException;
	/**
	 * 判断审批权限配置对应信息是否已经存在
	 * @param dimDeptFlowRelation
	 * @return
	 * @throws MpmException
	 */
	public boolean isObjectExist(DimDeptFlowRelationId dimDeptFlowRelationId) throws MpmException;
}

package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChannelForm;
import com.ai.bdx.frame.approval.model.DimMtlChannel;
import java.util.List;
import java.util.Map;
import org.apache.struts.util.LabelValueBean;

public abstract interface IDimMtlChannelService
{
  public abstract Map searchMtlChannel(DimMtlChannelForm paramDimMtlChannelForm, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void delete(DimMtlChannelForm paramDimMtlChannelForm)
    throws MpmException;

  public abstract void save(DimMtlChannel paramDimMtlChannel)
    throws MpmException;

  public abstract DimMtlChannel getMtlChannel(String paramString)
    throws MpmException;

  public abstract List getAllMmsContentByType(String paramString)
    throws Exception;

  public abstract List getAllMmsType()
    throws Exception;

  public abstract List<LabelValueBean> getBsChannelsByType(String paramString)
    throws Exception;

  public abstract List findWebSiteInfo(String paramString1, String paramString2, int paramInt1, int paramInt2);

  public abstract void saveCampsegIdWebSiteInfoIdClassIdRel(String paramString1, String paramString2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IDimMtlChannelService
 * JD-Core Version:    0.6.2
 */
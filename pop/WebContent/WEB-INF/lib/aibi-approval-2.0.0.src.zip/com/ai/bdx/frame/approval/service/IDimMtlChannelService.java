package com.ai.bdx.frame.approval.service;


import java.util.List;
import java.util.Map;
import org.apache.struts.util.LabelValueBean;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChannelForm;

import com.ai.bdx.frame.approval.model.DimMtlChannel;


public interface IDimMtlChannelService {

	/**
	 * 查询渠道信息定义信息
	 * @param searchForm
	 * @return
	 * @throws MpmException
	 */
	public Map searchMtlChannel(DimMtlChannelForm searchForm, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 保存渠道信息定义信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void delete(DimMtlChannelForm searchForm) throws MpmException;

	/**
	 * 删除渠道信息定义信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void save(DimMtlChannel dimMtlChannel) throws MpmException;

	/**
	 * 取渠道信息定义信息
	 * @param rid
	 * @param cType
	 * @return
	 * @throws MpmException
	 */
	public DimMtlChannel getMtlChannel(String channelId) throws MpmException;
	
	/**
	 * 得到短信的所有发送方式
	 * @return
	 * @throws MpmException
	 */
	//public List<DimChannelSendType> getAllSmsSendType() throws MpmException;
	
	/**
	 * 取得所有的彩信分类；
	 * @param typeId
	 * @return
	 * @throws Exception
	 */
	public List getAllMmsContentByType(String typeId) throws Exception ;
	
	/**
	 * 取得某种彩信种类的所有彩信；
	 * @return
	 * @throws Exception
	 */
	public List getAllMmsType() throws Exception ;
	
	/**
	 * 由渠道类型得到该类型的所有渠道；
	 * @param channelType
	 * @return
	 * @throws Exception
	 */
	public List<LabelValueBean> getBsChannelsByType(String channelType) throws Exception;
	
	/**
	 * 获取渠道附加信息
	 * @param channelType
	 * @return
	 */
	//public List<DimMtlChannelExtend> getChannelExtendInfo(String channelType);
	
	/**
	 * 获取网站分类
	 * @param channelType
	 * @return
	 */
	//public List<DimUrlRule> getWebClasses();

	/**
	 * 获取查询关键字对应的内容站点信息等
	 * @param classId 网站分类
	 * @param searchKeyWords 搜索关键字
	 * @param pageNo 当前页（第一页的标识是1，不是0）
	 * @param countPerPage（每页显示多少行数据）
	 * @return
	 */
	public List findWebSiteInfo(String classId, String searchKeyWords, int pageNo, int countPerPage);

	/**
	 * 保存活动与关键字对应的信息关联
	 * @param campsegId 活动规则Id
	 * @param webSiteInfoIdClassIdRel 关键字对应的站点信息Id和网站分类Id的关联信息(json字符串)
	 */
	public void saveCampsegIdWebSiteInfoIdClassIdRel(String campsegId, String webSiteInfoIdClassIdRel);
}

package com.ai.bdx.frame.approval.service;

import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm;
import com.ai.bdx.frame.approval.model.DimMtlChanneltype;

/**
 * 
 * Created on 2008-3-7
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author qixf
 * @version 1.0
 */
public interface IDimMtlChanneltypeService {

	/**
	 * 查询渠道类型定义信息
	 * @param searchForm
	 * @return
	 * @throws MpmException
	 */
	public Map searchMtlChanneltype(DimMtlChanneltypeForm searchForm, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 保存渠道类型定义信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void delete(DimMtlChanneltypeForm searchForm) throws MpmException;

	/**
	 * 删除渠道类型定义信息
	 * @param dimChannelUserRelation
	 * @throws MpmException
	 */
	public void save(DimMtlChanneltype dimMtlChanneltype) throws MpmException;

	/**
	 * 取渠道类型定义信息
	 * @param rid
	 * @param cType
	 * @return
	 * @throws MpmException
	 */
	public DimMtlChanneltype getMtlChanneltype(Short channeltype) throws MpmException;
	
	/**
	 * 通过渠道类型取得渠道派单方式
	 * @param channelTypeId
	 * @return autoSendOdd
	 * @throws MpmException
	 */
	public Integer getSendOddTypeByChannelType(Integer ChannelTypeId)  throws MpmException;
	/**
	 * 获取所有渠道类型
	 * @param channelTypeId
	 * @return autoSendOdd
	 * @throws MpmException
	 */
	public List getMtlChannelTypeList() throws Exception ;
	/**
	 * 根据系统标示获取所有渠道类型
	 * @param SysId
	 * @return autoSendOdd
	 * @throws MpmException
	 */
	public List getAllChannelTypeForSys(String SysId) throws MpmException;
}

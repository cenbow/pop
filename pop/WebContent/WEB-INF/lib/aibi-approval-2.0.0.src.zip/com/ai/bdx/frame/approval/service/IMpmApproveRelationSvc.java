package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveRelation;
import java.util.List;
import java.util.Map;

public abstract interface IMpmApproveRelationSvc
{
  public abstract Map findApproveAll(MtlApproveRelation paramMtlApproveRelation, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract boolean deleteApprove(MtlApproveRelation paramMtlApproveRelation)
    throws MpmException;

  public abstract boolean saveApprove(MtlApproveRelation paramMtlApproveRelation)
    throws MpmException;

  public abstract boolean updateByHiberite(MtlApproveRelation paramMtlApproveRelation)
    throws MpmException;

  public abstract boolean updateByJdbc(MtlApproveRelation paramMtlApproveRelation)
    throws MpmException;

  public abstract String getCompanyUserTree(String paramString)
    throws MpmException;

  public abstract MtlApproveRelation getApproveRelationById(String paramString1, String paramString2)
    throws MpmException;

  public abstract List getApproveRelationByCond(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract int getUserMaxApproveLevel(String paramString)
    throws MpmException;

  public abstract String getCompanyUserSubTree(String paramString1, String paramString2)
    throws MpmException;

  public abstract String getDeptName(String paramString)
    throws MpmException;

  public abstract String getCompanyTreeHtmlCache(String paramString1, String paramString2)
    throws MpmException;

  public abstract boolean ApproveRelationExist(String paramString)
    throws MpmException;

  public abstract String getCompanyUserTreeAsyn(String paramString)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMpmApproveRelationSvc
 * JD-Core Version:    0.6.2
 */
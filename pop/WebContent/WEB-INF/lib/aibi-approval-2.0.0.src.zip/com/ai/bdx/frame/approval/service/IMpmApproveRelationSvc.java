package com.ai.bdx.frame.approval.service;


import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveRelation;

public interface IMpmApproveRelationSvc {

	/**
	 * 根据条件返回审批关系记录（分页使用）
	 * @param svc
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 */
	public Map findApproveAll(MtlApproveRelation svc, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 删除一条记录
	 * @param mtlApproveRelation
	 * @return
	 * @throws MpmException
	 */
	public boolean deleteApprove(MtlApproveRelation mtlApproveRelation) throws MpmException;

	/**
	 * 保存一条记录
	 * @param mtlApproveRelation
	 * @return
	 * @throws MpmException
	 */
	public boolean saveApprove(MtlApproveRelation mtlApproveRelation) throws MpmException;

	/**
	 * 通过hiberate修改审批关系记录
	 * @param mtlApproveRelation
	 * @return
	 * @throws MpmException
	 */
	public boolean updateByHiberite(MtlApproveRelation mtlApproveRelation) throws MpmException;

	/**
	 * 通过jdbc修改审批关系记录
	 * @param mtlApproveRelation
	 * @return
	 * @throws MpmException
	 */
	public boolean updateByJdbc(MtlApproveRelation mtlApproveRelation) throws MpmException;

	/**
	 * 得到公司部门用户树
	 * @return
	 * @throws MpmException
	 */
	public String getCompanyUserTree(String operatorId) throws MpmException;

	/**
	 * 返回职位代码所有记录
	 * @return
	 * @throws MpmException
	 */
	//public List getPositionAll() throws MpmException;

	/**
	 *通过主键返回一条记录
	 * @param createUserid
	 * @param approveUserid
	 * @return
	 * @throws MpmException
	 */
	public MtlApproveRelation getApproveRelationById(String createUserid, String approveUserid) throws MpmException;

	/**
	 * 通过条件组合查询记录
	 * @param createId
	 * @param approveId
	 * @param approveLevel
	 * @return
	 * @throws MpmException
	 */
	public List getApproveRelationByCond(String createId, String approveId, String approveLevel) throws MpmException;

	/**
	 * 取在用户上定义的最高审批级别
	 * @param userId
	 * @return
	 * @throws MpmException
	 */
	public int getUserMaxApproveLevel(String userId) throws MpmException;
	
	/**mads2
	 * 取用户有权限访问的公司按层树型分的组织结构信息（目前公司组织结构还没有权限控制）
	 * @param deptid
	 * @return
	 * @throws MpmException
	 */
	public String getCompanyUserSubTree(String operatorId,String parentId) throws MpmException;
	/**
	 * 根据部门标识得到部门名称
	 * @param deptid
	 * @return
	 * @throws MpmException
	 */

	public String getDeptName(String deptid) throws MpmException;

	/**
	 * 取用户有权限访问的公司组织结构树型html信息（目前公司组织结构还没有权限控制）
	 * @param userId
	 * @param userGroupId
	 * @return
	 * @throws MpmException
	 */
	public String getCompanyTreeHtmlCache(String userId, String userGroupId) throws MpmException;

	/**
	 * 判断是否已经为部门添加审批关系
	 * @param deptId
	 * @return
	 * @throws MpmException
	 */
	public boolean ApproveRelationExist(String deptId) throws MpmException;
	
	/**
	 * 异步获取公司部门用户树
	 * @param nodeId
	 * @return
	 * @throws MpmException
	 */
	public String getCompanyUserTreeAsyn(String nodeId) throws MpmException;
}

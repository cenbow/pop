package com.ai.bdx.frame.approval.service;

import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;

public interface IMpmCampChannelDispatchSearchService {
    /**
     * 根据不同的渠道类型获得不同的渠道下拉框
     * @param channelTypeId
     * @param selectName
     * @return
     * @throws MpmException
     */
    public String getChannelSelectListCache(String channelTypeId, String channelId, String selectName) throws MpmException;

    /**
	 * 根据不同的渠道类型获得不同的渠道下拉框(不从缓存中取)
	 * @param channelTypeId
	 * @param selectName
	 * @param random 随机数
	 * @return
	 * @throws MpmException
	 */
	//public String getChannelSelectListNoCache(String channelTypeId, String channelId, String selectName, double random) throws MpmException;
    
	/**
	 * 获取营销案所引用的渠道信息
	 * @param campId
	 * @param channelTypeId
	 * @param channelId
	 * @param selectName
	 * @return
	 * @throws MpmException
	 */
	//public String getCampChannelListCache(String campId, String channelTypeId, String channelId,String selectName) throws MpmException;
	/**
	 * 根据营销案获得对应的渠道类型(只有Option)
	 * @param campId
	 * @param channelTypeId
	 * @param channelId
	 * @param selectName
	 * @return
	 * @throws MpmException
	 */
	//public String getChannelSelectTypeOption(String campId) throws MpmException;
	/**
	 * 根据营销案获得对应的渠道类型
	 * @param campId
	 * @param channelTypeId
	 * @param selectName
	 * @return
	 * @throws MpmException
	 */
	//public String getChannelSelectTypeCache(String campId, String channelTypeId, String selectName)throws MpmException;
	/**
	 * 根据营销案获得对应的渠道类型(只有Option)
	 * @param campId
	 * @param channelTypeId
	 * @param selectName
	 * @return
	 * @throws MpmException
	 */
	//public String getCampChannelListOption(String campId, String channelTypeId,String systemId) throws MpmException;
	/**
	 * 获得派单记录
	 * @param channelTypeId
	 * @param channelId
	 * @param currpage
	 * @param pagesize
	 * @return
	 * @throws MpmException
	 */
	//public Map getFileDownByChannel(String campId, String campsegId, String channelTypeId, String channelId, String userId, final Integer currpage, final Integer pagesize) throws MpmException;
}

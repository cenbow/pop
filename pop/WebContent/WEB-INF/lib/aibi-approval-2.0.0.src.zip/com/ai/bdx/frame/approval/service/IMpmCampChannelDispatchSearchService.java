package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;

public abstract interface IMpmCampChannelDispatchSearchService
{
  public abstract String getChannelSelectListCache(String paramString1, String paramString2, String paramString3)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMpmCampChannelDispatchSearchService
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCampDataSource;
import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
import java.util.List;
import java.util.Map;

public abstract interface IMpmCampDataSourceSvc
{
  public abstract boolean saveDatasource(MtlCampDataSource paramMtlCampDataSource)
    throws MpmException;

  public abstract List findAllDatasource()
    throws MpmException;

  public abstract MtlCampDataSource findByTabname(String paramString)
    throws MpmException;

  public abstract boolean deleteByTabname(String paramString)
    throws MpmException;

  public abstract boolean updateTable(MtlCampDataSource paramMtlCampDataSource)
    throws MpmException;

  public abstract boolean saveDatasrcColumn(MtlCampDatasrcColumn paramMtlCampDatasrcColumn)
    throws MpmException;

  public abstract Map findColumnByTabname(String paramString1, String paramString2, String paramString3, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract boolean deleteColumnByStr(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract List getColumnInfoList(MtlCampDatasrcColumn paramMtlCampDatasrcColumn)
    throws MpmException;

  public abstract boolean updateColumnByHiberate(MtlCampDatasrcColumn paramMtlCampDatasrcColumn)
    throws MpmException;

  public abstract boolean updateColumnByJdbc(MtlCampDatasrcColumn paramMtlCampDatasrcColumn)
    throws MpmException;

  public abstract MtlCampDatasrcColumn getCampDatasrcColumn(String paramString1, String paramString2)
    throws MpmException;

  public abstract List getColumnClass()
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMpmCampDataSourceSvc
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.model.MtlTempletActive;

public interface IMpmCampDesignService {
	public String saveColumns(MtlTempletActive templet,String[] tablecols);
}

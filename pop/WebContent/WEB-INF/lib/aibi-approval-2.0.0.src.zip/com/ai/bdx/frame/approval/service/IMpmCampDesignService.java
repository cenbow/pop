package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.model.MtlTempletActive;

public abstract interface IMpmCampDesignService
{
  public abstract String saveColumns(MtlTempletActive paramMtlTempletActive, String[] paramArrayOfString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMpmCampDesignService
 * JD-Core Version:    0.6.2
 */
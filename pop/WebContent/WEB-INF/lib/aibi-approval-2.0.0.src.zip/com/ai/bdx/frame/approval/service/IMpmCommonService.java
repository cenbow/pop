package com.ai.bdx.frame.approval.service;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.DimCampDrvType;
import com.ai.bdx.frame.approval.model.DimDrvRoleManager;
import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
import com.ai.bdx.frame.approval.model.MtlPlanExecType;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;

public interface IMpmCommonService {

	public boolean isFlowRelationExist(String relationType, String campDrvId, String cityId, String deptId,
			String approveFlowId, String flow_type);

	public boolean isDrvExist(String tableID, String tableColVal, String flowId, String campDrvId);

	/**
	 * @return
	 */
	public Map getCampChannelTypeMap() throws MpmException;

	/**
	* 根据部门获取部门审批人列表
	* @param parentTypeId
	* @param channelType
	* @return
	*/
	public List<MtlApproveFlowDef> getApproveUserList(String deptId) throws Exception;

	public Map getMtlCampRuleTypeMap() throws MpmException;

	public Map getCampChannelIdMap(int channeltypeId) throws Exception;

	public String getAllChannelIds() throws Exception;

	/**
	 * 取所有定义的渠道类型
	 * @return
	 * @throws MpmException
	 */
	public List getAllMtlChanneltype() throws MpmException;

	/**
	 * 获取最新的活动类型ID
	 * @return
	 * @throws MpmException
	 */
	public Short getMaxCampDrvId() throws MpmException;

	/**
	 *
	 * @param dcdt
	 * @throws MpmException
	 */
	public void saveCampDrvType(DimCampDrvType dcdt) throws MpmException;

	/**
	 *  通过类型标识获取的驱动类�?
	 * @param drvTypeId
	 * @return
	 * @throws Exception
	 */
	public DimCampDrvType getDrvType(Short drvTypeId) throws Exception;

	/**
	 * 得到所有的执行类型信息
	 * @param mpet
	 * @return
	 * @throws MpmException
	 */
	public List getPlanExecTypeMap(MtlPlanExecType mpet) throws MpmException;

	/**
	 * 得到所有活动的流程信息
	 * @param dab
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 */
	public Map findCampDrvList(DimCampDrvType dab, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 取所有活动驱动类型信息（List形式�?
	 * @return 带活动驱动类型信息的DimCampDrvType List
	 * @throws MpmException
	 */
	public List getAllCampDrvType() throws MpmException;

	/**
	 * 判断某个类型资源的中文名称是否存在（如：活动、活动波次等�?
	 * @param name 资源中文�?
	 * @param name 资源唯一标示编号
	 * @param nameType 资源类型（指明是活动还是活动波次，或是其他类型资源，在MmpCONST中定义）
	 * @param nameNeedTrans 资源中文名是否需要转码（资源名可能是直接从jsp页面传递到service类中，所以可能需要转码成GB2312�?
	 * @return
	 */
	public boolean isNameExist(String name, String id, String nameType, boolean nameNeedTrans);

	/**
	 * 取可以进行活动波次指标分析的活动信息
	 * @param userId String
	 * @return list List (LabelValueBean对象集合)
	 */
	public List getCampCanAnalyseList(String userId) throws Exception;

	/**
	 * 取可以进行活动波次指标分析的活动波次信息
	 * @param userId String
	 * @return list List (LabelValueBean对象集合)
	 */
	public String getCampSegCanAnalyseArray(String userId);

	/**
	 * 依据活动ID获得品牌下拉框Html
	 * @param campId String
	 * @param selectName String select控件�?
	 * @return String
	 */
	public String getBrandHtmlByCampIdCache(String campId, String selectName) throws MpmException;

	/**
	 * 取用户有权限访问的活动信息
	 * @param userId TODO
	 * @return 带有活动编号、名称信息的LabelValueBean List
	 */
	public List getCampList(String userId) throws Exception;

	/**
	 *  取用户有权限访问的非纯宣传活动信息
	 * @param userId
	 * @return 带有活动编号、名称信息的LabelValueBean List
	 * @throws Exception
	 */
	public List getInitiativeCampList(String userId) throws MpmException;

	/**
	 * 取用户有权限访问的活动信息
	 * @param userId
	 * @return 带有活动信息的MtlCampBaseInfo List
	 * @throws Exception
	 */
	public List getCampListAll(String userId) throws Exception;

	/**
	 *
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List getCampListAllbyfile(String userId) throws Exception;

	/**
	 *
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List getCampListAlloddact(String userId) throws Exception;

	/**
	 *
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public String getCampSegArrayoddact(String userId) throws Exception;

	/**
	 *
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List getCampListAlloddCall(String userId) throws Exception;

	/**
	 *
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public String getCampSegArrayoddCall(String userId) throws Exception;

	/**
	 *
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List getCampSegListbyoddact(String userId) throws Exception;

	/**
	 *
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List getCampSegListbyfile(String userId) throws Exception;

	/**
	 *
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List getCampSegArrayoddactbyfile(String userId) throws Exception;

	/**
	 * 活动某个活动下的所有活动波次信息列息
	 * @param campid
	 * @return 带有波次编号、名称信息的LabelValueBean List
	 * @throws MpmException
	 */
	public List getCampsegListByCampId(String campid) throws MpmException;

	/**
	 * 取用户有权限访问的所有波次信息列息
	 * @param userId TODO
	 * @return 带有波次编号、名称信息的LabelValueBean List
	 */
	public List getCampSegList(String userId) throws Exception;

	/**
	 * 取用户有权限访问的所有波次信息列息
	 * @param userId TODO
	 * @return 带有波次编号、名称信息的LabelValueBean List
	 */
	public List getCampSegListForHD(String userId) throws Exception;

	/**
	 * 取用户有权限访问的活动和活动波次Select联动Html代码
	 * @param userId TODO
	 * @return Select联动Html代码
	 * @throws Exception
	 */
	public String getCampSegArray(String userId) throws Exception;

	/**
	 * 取所有活动驱动类型信息（Map形式�?
	 * @return Map(key = campDrvId; value=campDrvName)
	 * @throws MpmException
	 */
	public Map getCampDrvTypeMap() throws MpmException;

	/**
	 * 得到所有未禁用的驱动类型列表；
	 * @return
	 * @throws MpmException
	 */
	public List getAllCampDrvTypesEnable() throws MpmException;

	/**
	 * 通过角色取所有活动驱动类型信息（List形式�?
	 * @return 带活动驱动类型信息的DimCampDrvType List
	 * @throws MpmException
	 */
	public DimDrvRoleManager getAllCampDrvTypeByRoleId(Short campDrvId, String roleId, Short roleFlag)
			throws MpmException;

	/**
	 * 判断用户是否拥有该活动类型的权限
	 * @param campDrvId
	 * @param userId
	 * @param groupId
	 * @return
	 * @throws MpmException
	 */
	public boolean getUserDrvAuth(Short campDrvId, String userId, String groupId) throws MpmException;

	/**
	 * 取所有活动优先级信息
	 * @return Map(key = campPriId; value=campPriName)
	 * @throws MpmException
	 */
	public Map getCampPriMap() throws MpmException;

	/**获取品牌
	 *
	 * @return Map(key = brandId; value=brandName)
	 * @throws MpmException
	 */
	public Map getDimPubBrandMap() throws MpmException;

	/**
	 * 取所有资费套餐的信息
	 * @return
	 * @throws MpmException
	 */
	public List getAllStcPlan() throws MpmException;

	/**
	 * 通过类型获取资费列表
	 * @param typeId
	 * @return
	 * @throws MpmException
	 */
	//public List<MtlStcPlan> getPlansByType(String typeId) throws MpmException;

	/**
	 * 通过父节点，获取推荐业务类型列表
	 * @param parentTypeId
	 * @return
	 * @throws MpmException
	 */
	//public List<DimPlanType> getPlanTypesByParentId(String parentTypeId) throws MpmException;

	public MtlCampsegProgress getCampsegProgress(String campsegId, String flowId, Short stepId) throws MpmException;

	/**
	 * 判断活动波次当前步骤地前续步骤是否已经完�?
	 * @param campsegId
	 * @param flowId
	 * @param stepId
	 * @param campType TODO
	 * @return
	 * @throws MpmException
	 */
	public boolean hasPreStepFinished(String campsegId, String flowId, Short stepId, Short campType)
			throws MpmException;

	/**
	 * 判断活动的波次是否完�?
	 * @param campId
	 * @return
	 */
	public boolean isCampsegExist(String campId);

	/**
	 * 获取替换符集合
	 * @return
	 */
	public String getReplaceLabelList();

	/**
	 * 约束审批关系定义
	 * @param s1
	 * @param s2
	 * @param flag
	 * @return
	 */
	public boolean isApproveExist(String s1, String s2, boolean flag);

	/**
	 * 判断审批对应的上级和下级审批关系是否存在
	 * @param createUserid
	 * @param approveUserid
	 * @param flag
	 * @return
	 */
	public boolean isNextOrPreApproveExist(String createUserid, String approveUserid, boolean flag);

	/**
	 * 判断活动定义人员是否正在审批状�?
	 * @param createUserid
	 * @return
	 */
	public boolean isCampsegApproveExist(String createUserid);

	/**
	 * 维度字段约束
	 * @param columnName
	 * @param sourceName
	 * @param flag
	 * @return
	 */
	public int isDimColumnExist(String columnName, String sourceName, boolean flag);

	/**
	 * 获得步骤状�?
	 * @param campsegId
	 * @param flowId
	 * @param stepId
	 * @return
	 * @throws MpmException
	 */
	public short getCampsegProgressStatus(String campsegId, String flowId, Short stepId) throws MpmException;

	/**
	 * 判断有无审批关系定义
	 * @param createUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isFirstUserApprove(String createUserId) throws Exception;

	/**
	 * 返回大客户经理下来框
	 * @return
	 * @throws MpmException
	 */
	public List getVipManagerSelectListCache() throws MpmException;

	/**
	 * 返回策反经理下拉�?
	 * @return
	 * @throws MpmException
	 */
	public List getComVipManagerSelectListCache() throws MpmException;

	/**
	 * 根基驱动类型 决定是下拉框是获取大客户经理还是策反客户经理
	 * @param campType
	 * @return
	 * @throws MpmException
	 */
	public List getVipOrCompManagerSelectListCache(Short campType) throws MpmException;

	/**
	 * 返回大客户经理联动下拉框
	 * @return
	 * @throws MpmException
	 */
	public String getVipManagerArrayCache() throws MpmException;

	/**
	 * 获得传统渠道联动下拉�?
	 * @return
	 * @throws MpmException
	 */
	public String getTraditionChannelArrayCache() throws MpmException;

	/**
	 * 获得传统渠道下拉�?
	 * @param channelTypeId
	 * @return
	 * @throws MpmException
	 */
	public List getTraditionChannleSelectListCache(String channelTypeId) throws MpmException;

	/**
	 * 获得所有渠道类型下拉框
	 * @return
	 * @throws MpmException
	 */
	public List getChannelTypeListCache() throws MpmException;

	/**
	 * 获得传统渠道类型下拉�?
	 * @return
	 * @throws MpmException
	 */
	public List getTraditionChannelTypeSelectListCache() throws MpmException;

	/**
	 * 取在某个流程定义中，某个步骤地前续、后续步骤编�?
	 * @param flowId
	 * @param currStepId
	 * @return String[2]（String[0]=前续步骤编号/null；String[1]=后续步骤编号/null。如果没有前续或后续步骤，则编号值为null�?
	 * @throws MpmException
	 */
	public String[] getPreAndNextStepIdCache(String flowId, String currStepId) throws MpmException;

	/**
	 * 取在某个流程定义中，某个步骤的后续步骤编�?
	 * @param flowId
	 * @param currStepId
	 * @return 如果没有后续步骤，返�?'
	 * @throws MpmException
	 */
	public String getNextStepIdCache(String flowId, String currStepId) throws MpmException;

	/**
	 * 取在某个流程定义中，某个步骤的前续步骤编�?
	 * @param flowId
	 * @param currStepId
	 * @return 如果没有前续步骤，返�?'
	 * @throws MpmException
	 */
	public String getPreStepIdCache(String flowId, String currStepId) throws MpmException;

	/**
	 * 取系统当前最新的用户数据月份
	 * @return
	 * @throws MpmException
	 */
	public String getLastUserDataMonthCache(String mainTable) throws MpmException;

	/**
	 * 取系统中最�?年的客户数据月份列表
	 * @return List(element=LabelValueBean)
	 * @throws MpmException
	 */
	public List getUserBaseDataMonthListCache(String mainTable) throws MpmException;

	/**
	 * 更新活动波次某个步骤地处理结果标�?
	 * @param campsegId
	 * @param stepId
	 * @param flag
	 * @throws MpmException
	 */
	public void updateCampsegProgressFlag(String campsegId, String stepId, String flag) throws MpmException;

	/**
	 * 判断活动波次的“目标客户定位”步骤中是否设置了“目标客户筛选条件�?
	 * （如果活动波次没有“目标客户定位”步骤，则返回false�?
	 * @param campsegId
	 * @return
	 * @throws MpmException
	 */
	public boolean isCampsegSelectSeted(String campsegId) throws MpmException;

	/**
	 * 取数据源表字段的描述信息
	 * @param sourceName
	 * @param columnName
	 * @return
	 * @throws MpmException
	 */
	public String getDataSrcColumnDescCache(String sourceName, String columnName) throws MpmException;

	/**
	 * 判断某个部门/分公司是否已经设置了审批�?
	 * @param deptId
	 * @return
	 * @throws MpmException
	 */
	public boolean isDeptHasSetApprover(String deptId) throws MpmException;

	/**
	 * 判断某个审批人在活动波次的审批人中是否已经存�?
	 * @param campsegId
	 * @param currUserId 当前审批�?
	 * @param approverUserId 将要转发的审批人
	 * @return (0-不存在；1-存在在活动波次的审批人列表中�?-存在在审批转发日志中)
	 * @throws MpmException
	 */
	public int isApproverExistInCampseg(String campsegId, String currUserId, String approverUserId) throws MpmException;

	/**
	 * 判断客户群定义是否能删除
	 * @param custGroupId
	 * @return
	 * @throws MpmExcepiton
	 */
	public boolean isCustGroupCanDelete(String custGroupId, String currUserId, String groupId) throws MpmException;

	/**
	 * 判断客户群定义是否能删除
	 * @param custGroupId
	 * @return
	 * @throws MpmExcepiton
	 */
	public boolean isCustGroupCanDivide(String custGroupId, String currUserId, String groupId) throws MpmException;

	/**
	 * 判断客户群是否可以变更状�?
	 * @param custGroupId
	 * @param currUserId
	 * @param groupId
	 * @return (0 - 可以变更�? - 当前用户不是客户群创建者或管理员，不能变更�? - 客户群还有步骤未完成，不能变更；3 - 客户群已被营销活动引用，不能变�?
	 * @throws MpmException
	 */
	public int isCustGroupCanChgStatus(String custGroupId, String currUserId, String groupId) throws MpmException;

	/**
	 * 判断宣传设计是否能删�?
	 * @param custGroupId
	 * @return
	 * @throws MpmException
	 */
	public boolean isPublicizeCombCanDelete(String combId, String currUserId, String groupId) throws MpmException;

	/**
	 * 判断活动是否能够进行提交确认和报批的各种状�?
	 * @param campId
	 * @param campsegId
	 * @param flowId
	 * @param flag
	 * @return
	 */
	public boolean isCanConfirmOrApprove(String campId, String campsegId, String flowId, String flag);

	/**
	 * 根据营销案取对应的渠道类�?
	 *
	 * @param campId
	 * @return
	 * @throws MpmException
	 */
	public Map getCampChannelTypeMap(String campId) throws MpmException;

	public List getAllMtlChanneltype(DimMtlChanneltype type) throws MpmException;

	public String getApproveFlowidByChannelTypeAndId(String type, String cid) throws MpmException;

	public List getInterfaceTable() throws MpmException;

	/**
	 * 获取执行完成状态的活动数组
	 * @return
	 * @throws Exception
	 */
	public String getCampSegArrayExec(String campsegStatId) throws Exception;

	/**
	 * 获取有执行完成营销活动的营销�?
	 * @return
	 * @throws Exception
	 */
	public List getCampListbyExec() throws Exception;

	/**
	 * 通过类型获取不同级别的驱动类�?0 获取第一�?�?0 获取第二�?
	 * @param type
	 * @throws Exception
	 */
	public List getCampDrvTypeListByType(String type) throws Exception;

	/**
	 * 获取需要进行网站派单的营销�?
	 * @param cityId
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List getCampListAlloddWeb(String userId) throws Exception;

	/**
	 * 获取需要网站派单的营销活动JS数组
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public String getCampSegArrayoddWeb(String userId) throws Exception;

	/**
	 * 取营销场景模板
	 * @param campDrvId
	 * @return
	 * @throws MpmException
	 */
	public List getScenesBycampDrvId(String campDrvId) throws MpmException;

	/**
	 * 取默认的审批流程
	 * @param userid
	 * @param campDrvId
	 * @param channeltypeId
	 * @param approveType
	 * @return
	 * @throws MpmException
	 */
	public String getApproveFlowid(String userid, String campDrvId, String channeltypeId, String channelId,
			String approveType) throws MpmException;

	/**
	 * 取默认的审批流程
	 * @param userid
	 * @param campDrvId
	 * @param channeltypeId
	 * @param approveType
	 * @return
	 * @throws MpmException
	 */
	public String getApproveFlowid(String userid, String campDrvId, String approveType) throws MpmException;

	/**
	 * 取陕西默认的审批流程
	 * @param userid
	 * @param campDrvId
	 * @param channeltypeId
	 * @param approveType
	 * @return
	 * @throws MpmException
	 */
	public String getApproveFlowid(String userid, String approveType) throws MpmException;

	/**
	 * 取营销场景元素Map
	 * @param ScenesId 场景ID
	 * @return
	 * @throws MpmException
	 */
	public Map getScenesElementsMap(String scenesId) throws MpmException;

	public String excludeBlackList(String srcTable, String avoidCustTypes);

	/**
	 *
	 * @return
	 * @throws MpmException
	 */
	public Map getDimCustTypeMap() throws MpmException;

	/**
	 * 获取免打扰类�?
	 * @param dab
	 * @return
	 * @throws MpmException
	 */
	//public List getDimAvoidBotherMap(DimAvoidBother dab) throws MpmException;

	public IUserPrivilegeCommonService getUserPolicyService();

	/**
	 * 按渠道类型查找活�?
	 * @param channeltypeId
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List findCampsegByChannelTypeId(String channeltypeId, String userId) throws Exception;

	/**
	 *
	 * @param campsegStatId
	 * @return
	 * @throws Exception
	 */
	public List getCampSegListExec(String campsegStatId) throws Exception;

	/**
	 * 获取数据源月�?
	 * @param custGroupId
	 * @return
	 * @throws MpmException
	 */
	public String getCustDataMonth(String custGroupId) throws MpmException;

	public String testFmtMess(String fmtMess) throws MpmException;

	/**
	 * 判断合作伙伴是否能删�?
	 * @param partnerId
	 * @return
	 * @throws MpmExcepiton
	 */
	public boolean isPartnerCanDelete(String partnerId, String currUserId, String groupId) throws MpmException;

	/**
	 * 判断执行计划是否能删�?
	 * @param planId
	 * @return
	 * @throws MpmExcepiton
	 */
	public boolean isPlanCanDelete(String planId, String currUserId, String groupId) throws MpmException;

	/**
	 * 保存活动营销目标成本
	 * @param campsegId
	 * @param objCode[]
	 * @param objCost[]
	 * @throws MpmException
	 */
	public void saveObjCosts(String campsegId, String objCode[], String objCost[]) throws MpmException;

	/**
	 * 取所有活动目标成本�?
	 * @param campsegId
	 * @return
	 * @throws MpmException
	 */
	public List getObjCostList(String campsegId) throws MpmException;

	public String getCustGroupByCampSeg(String campSegId) throws Exception;

	public String getCalendarDate(String userId) throws Exception;

	public List getStcPlans(String planIds) throws MpmException;

	public List<LabelValueBean> getBsMmsContent() throws Exception;

	/*public List<DimPubBrand> getLevel1Brand() throws Exception;

	public List<DimPubBrand> getLevel2Brand(String brandId) throws Exception;

	public List<MtlStcPlan> getMtlStcPlanList(String cityId, String brandId) throws Exception;
	*/
	/**
	 * 由资费ID得到对应资费名，批量处理；
	 * @param planIdStr "a,b"格式；
	 * @return  "planName1,planName2"
	 * @throws Exception
	 */
	public String getMtlStcPlanName(String planIdStr) throws Exception;

	/**
	 * 由资费ID得到对应资费
	 * @throws Exception
	 */
	//public MtlStcPlan getMtlStcPlanById(String planId) throws Exception;

	public TreeMap getBrandTreeMap();

	/**
	 * 通过客户群id查找客户群类型id
	 * @return
	 * @throws MpmException
	 */
	public int getCustGroupTypeById(String custid);

	/**
	 * 获取品牌维表中的所有品牌字符串（json格式）
	 * @return
	 * @throws MpmException
	 */
	public String getAllBrandString() throws Exception;

	/**
	 * 删除附件;
	 * @param attaId
	 * @return
	 * @throws Exception
	 */
	public String deleteAttachmentById(String attaId) throws Exception;

	/**
	 * 根据活动驱动类型Id获取名称
	 * @param attaId
	 * @return
	 * @throws Exception
	 */
	public String getDrvTypeName(Short drvTypeId) throws Exception;

	/**
	 * 根据场景ID获取场景对象
	 * @param scenesId
	 * @return
	 */
	//	public MtlScenesTemplet getScenesTemplet(String scenesId);

	/**
	 *
	 * @param codeType 4-业务平台编码  6-信息格式编码  8-信息类型编码
	 * @return
	 */
	//public List<SiProductDic> getSiProductDicList(short codeType);

	/**
	 * 根据业务平台编码获取业务分类
	 * @param svcPlat
	 * @return
	 */
	//public List<DimSvcCategory> getSvcCategoryList(String svcPlat);

	/**
	 * 获取VGOP产品信息列表
	 * @param infoFormat  信息格式
	 * @param infoType   信息类型
	 * @param svcCategory  业务分类
	 * @return
	 */
	//public List<SiProductBaseInfo> getProductList(String infoFormat,String infoType, String svcCategory);

	/**
	 * 获取指标单位名称；
	 * @param unitId
	 * @return
	 */
	public String getIrUnitName(String unitId);

	/**
	 * 检查指定渠道的回复内容是否已经在执行的活动中存在
	 * @param feed
	 * @param channelType
	 * @return
	 * @throws Exception
	 */
	public boolean isReplayExist(String feed, String channelType) throws Exception;

	public List<LabelValueBean> getAllApproveDrvDimTable() throws Exception;

	public List<LabelValueBean> getListApproveDrvDimTableCon(String id) throws Exception;

	public String getAllApproveDrvDimTableConByid(String id) throws Exception;

	public Map<String, Map<String, String>> getMapApproveDrvDimTableCon() throws Exception;
	/**
	 * 根据渠道类型获取推荐业务目录
	 * @param parentTypeId
	 * @param channelType
	 * @return
	 */
	//public  List<DimPlanType> getPlanTypesByChannelType(String parentTypeId, String channelType);

}

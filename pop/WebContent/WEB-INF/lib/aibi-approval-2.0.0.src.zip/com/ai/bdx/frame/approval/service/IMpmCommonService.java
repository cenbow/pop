package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.DimCampDrvType;
import com.ai.bdx.frame.approval.model.DimDrvRoleManager;
import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
import com.ai.bdx.frame.approval.model.MtlPlanExecType;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.apache.struts.util.LabelValueBean;

public abstract interface IMpmCommonService
{
  public abstract boolean isFlowRelationExist(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6);

  public abstract boolean isDrvExist(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract Map getCampChannelTypeMap()
    throws MpmException;

  public abstract List<MtlApproveFlowDef> getApproveUserList(String paramString)
    throws Exception;

  public abstract Map getMtlCampRuleTypeMap()
    throws MpmException;

  public abstract Map getCampChannelIdMap(int paramInt)
    throws Exception;

  public abstract String getAllChannelIds()
    throws Exception;

  public abstract List getAllMtlChanneltype()
    throws MpmException;

  public abstract Short getMaxCampDrvId()
    throws MpmException;

  public abstract void saveCampDrvType(DimCampDrvType paramDimCampDrvType)
    throws MpmException;

  public abstract DimCampDrvType getDrvType(Short paramShort)
    throws Exception;

  public abstract List getPlanExecTypeMap(MtlPlanExecType paramMtlPlanExecType)
    throws MpmException;

  public abstract Map findCampDrvList(DimCampDrvType paramDimCampDrvType, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract List getAllCampDrvType()
    throws MpmException;

  public abstract boolean isNameExist(String paramString1, String paramString2, String paramString3, boolean paramBoolean);

  public abstract List getCampCanAnalyseList(String paramString)
    throws Exception;

  public abstract String getCampSegCanAnalyseArray(String paramString);

  public abstract String getBrandHtmlByCampIdCache(String paramString1, String paramString2)
    throws MpmException;

  public abstract List getCampList(String paramString)
    throws Exception;

  public abstract List getInitiativeCampList(String paramString)
    throws MpmException;

  public abstract List getCampListAll(String paramString)
    throws Exception;

  public abstract List getCampListAllbyfile(String paramString)
    throws Exception;

  public abstract List getCampListAlloddact(String paramString)
    throws Exception;

  public abstract String getCampSegArrayoddact(String paramString)
    throws Exception;

  public abstract List getCampListAlloddCall(String paramString)
    throws Exception;

  public abstract String getCampSegArrayoddCall(String paramString)
    throws Exception;

  public abstract List getCampSegListbyoddact(String paramString)
    throws Exception;

  public abstract List getCampSegListbyfile(String paramString)
    throws Exception;

  public abstract List getCampSegArrayoddactbyfile(String paramString)
    throws Exception;

  public abstract List getCampsegListByCampId(String paramString)
    throws MpmException;

  public abstract List getCampSegList(String paramString)
    throws Exception;

  public abstract List getCampSegListForHD(String paramString)
    throws Exception;

  public abstract String getCampSegArray(String paramString)
    throws Exception;

  public abstract Map getCampDrvTypeMap()
    throws MpmException;

  public abstract List getAllCampDrvTypesEnable()
    throws MpmException;

  public abstract DimDrvRoleManager getAllCampDrvTypeByRoleId(Short paramShort1, String paramString, Short paramShort2)
    throws MpmException;

  public abstract boolean getUserDrvAuth(Short paramShort, String paramString1, String paramString2)
    throws MpmException;

  public abstract Map getCampPriMap()
    throws MpmException;

  public abstract Map getDimPubBrandMap()
    throws MpmException;

  public abstract List getAllStcPlan()
    throws MpmException;

  public abstract MtlCampsegProgress getCampsegProgress(String paramString1, String paramString2, Short paramShort)
    throws MpmException;

  public abstract boolean hasPreStepFinished(String paramString1, String paramString2, Short paramShort1, Short paramShort2)
    throws MpmException;

  public abstract boolean isCampsegExist(String paramString);

  public abstract String getReplaceLabelList();

  public abstract boolean isApproveExist(String paramString1, String paramString2, boolean paramBoolean);

  public abstract boolean isNextOrPreApproveExist(String paramString1, String paramString2, boolean paramBoolean);

  public abstract boolean isCampsegApproveExist(String paramString);

  public abstract int isDimColumnExist(String paramString1, String paramString2, boolean paramBoolean);

  public abstract short getCampsegProgressStatus(String paramString1, String paramString2, Short paramShort)
    throws MpmException;

  public abstract boolean isFirstUserApprove(String paramString)
    throws Exception;

  public abstract List getVipManagerSelectListCache()
    throws MpmException;

  public abstract List getComVipManagerSelectListCache()
    throws MpmException;

  public abstract List getVipOrCompManagerSelectListCache(Short paramShort)
    throws MpmException;

  public abstract String getVipManagerArrayCache()
    throws MpmException;

  public abstract String getTraditionChannelArrayCache()
    throws MpmException;

  public abstract List getTraditionChannleSelectListCache(String paramString)
    throws MpmException;

  public abstract List getChannelTypeListCache()
    throws MpmException;

  public abstract List getTraditionChannelTypeSelectListCache()
    throws MpmException;

  public abstract String[] getPreAndNextStepIdCache(String paramString1, String paramString2)
    throws MpmException;

  public abstract String getNextStepIdCache(String paramString1, String paramString2)
    throws MpmException;

  public abstract String getPreStepIdCache(String paramString1, String paramString2)
    throws MpmException;

  public abstract String getLastUserDataMonthCache(String paramString)
    throws MpmException;

  public abstract List getUserBaseDataMonthListCache(String paramString)
    throws MpmException;

  public abstract void updateCampsegProgressFlag(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract boolean isCampsegSelectSeted(String paramString)
    throws MpmException;

  public abstract String getDataSrcColumnDescCache(String paramString1, String paramString2)
    throws MpmException;

  public abstract boolean isDeptHasSetApprover(String paramString)
    throws MpmException;

  public abstract int isApproverExistInCampseg(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract boolean isCustGroupCanDelete(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract boolean isCustGroupCanDivide(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract int isCustGroupCanChgStatus(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract boolean isPublicizeCombCanDelete(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract boolean isCanConfirmOrApprove(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract Map getCampChannelTypeMap(String paramString)
    throws MpmException;

  public abstract List getAllMtlChanneltype(DimMtlChanneltype paramDimMtlChanneltype)
    throws MpmException;

  public abstract String getApproveFlowidByChannelTypeAndId(String paramString1, String paramString2)
    throws MpmException;

  public abstract List getInterfaceTable()
    throws MpmException;

  public abstract String getCampSegArrayExec(String paramString)
    throws Exception;

  public abstract List getCampListbyExec()
    throws Exception;

  public abstract List getCampDrvTypeListByType(String paramString)
    throws Exception;

  public abstract List getCampListAlloddWeb(String paramString)
    throws Exception;

  public abstract String getCampSegArrayoddWeb(String paramString)
    throws Exception;

  public abstract List getScenesBycampDrvId(String paramString)
    throws MpmException;

  public abstract String getApproveFlowid(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws MpmException;

  public abstract String getApproveFlowid(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract String getApproveFlowid(String paramString1, String paramString2)
    throws MpmException;

  public abstract Map getScenesElementsMap(String paramString)
    throws MpmException;

  public abstract String excludeBlackList(String paramString1, String paramString2);

  public abstract Map getDimCustTypeMap()
    throws MpmException;

  public abstract IUserPrivilegeCommonService getUserPolicyService();

  public abstract List findCampsegByChannelTypeId(String paramString1, String paramString2)
    throws Exception;

  public abstract List getCampSegListExec(String paramString)
    throws Exception;

  public abstract String getCustDataMonth(String paramString)
    throws MpmException;

  public abstract String testFmtMess(String paramString)
    throws MpmException;

  public abstract boolean isPartnerCanDelete(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract boolean isPlanCanDelete(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract void saveObjCosts(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2)
    throws MpmException;

  public abstract List getObjCostList(String paramString)
    throws MpmException;

  public abstract String getCustGroupByCampSeg(String paramString)
    throws Exception;

  public abstract String getCalendarDate(String paramString)
    throws Exception;

  public abstract List getStcPlans(String paramString)
    throws MpmException;

  public abstract List<LabelValueBean> getBsMmsContent()
    throws Exception;

  public abstract String getMtlStcPlanName(String paramString)
    throws Exception;

  public abstract TreeMap getBrandTreeMap();

  public abstract int getCustGroupTypeById(String paramString);

  public abstract String getAllBrandString()
    throws Exception;

  public abstract String deleteAttachmentById(String paramString)
    throws Exception;

  public abstract String getDrvTypeName(Short paramShort)
    throws Exception;

  public abstract String getIrUnitName(String paramString);

  public abstract boolean isReplayExist(String paramString1, String paramString2)
    throws Exception;

  public abstract List<LabelValueBean> getAllApproveDrvDimTable()
    throws Exception;

  public abstract List<LabelValueBean> getListApproveDrvDimTableCon(String paramString)
    throws Exception;

  public abstract String getAllApproveDrvDimTableConByid(String paramString)
    throws Exception;

  public abstract Map<String, Map<String, String>> getMapApproveDrvDimTableCon()
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMpmCommonService
 * JD-Core Version:    0.6.2
 */
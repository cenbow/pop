package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCostList;
import com.ai.bdx.frame.approval.model.MtlResList;
import java.util.List;
import java.util.Map;

public abstract interface IMpmResListSvc
{
  public abstract Map findAllRes(MtlResList paramMtlResList, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract String saveResList(MtlResList paramMtlResList)
    throws MpmException;

  public abstract boolean updateResList(MtlResList paramMtlResList)
    throws MpmException;

  public abstract boolean deleteResList(String paramString)
    throws MpmException;

  public abstract List getCostList()
    throws MpmException;

  public abstract List getResTypeList()
    throws MpmException;

  public abstract MtlResList findResListByCode(String paramString1, String paramString2)
    throws MpmException;

  public abstract List findAllCostList()
    throws Exception;

  public abstract List getAllSubCostList(String paramString)
    throws Exception;

  public abstract Map findAllCost(MtlCostList paramMtlCostList, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract MtlCostList saveCostList(MtlCostList paramMtlCostList)
    throws MpmException;

  public abstract boolean updateCostList(MtlCostList paramMtlCostList)
    throws MpmException;

  public abstract boolean deleteCostList(String paramString)
    throws MpmException;

  public abstract MtlCostList findCostListByCode(String paramString)
    throws MpmException;

  public abstract List findResListByCostCode(String paramString)
    throws MpmException;

  public abstract Map findCostListMap()
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMpmResListSvc
 * JD-Core Version:    0.6.2
 */
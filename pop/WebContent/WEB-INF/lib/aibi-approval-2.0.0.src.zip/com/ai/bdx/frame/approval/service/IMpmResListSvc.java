package com.ai.bdx.frame.approval.service;


import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCostList;
import com.ai.bdx.frame.approval.model.MtlResList;

public interface IMpmResListSvc {

	public Map findAllRes(MtlResList svc, Integer curPage, Integer pageSize) throws MpmException;

	public String saveResList(MtlResList mtlResList) throws MpmException;

	public boolean updateResList(MtlResList mtlResList) throws MpmException;

	public boolean deleteResList(String resCode) throws MpmException;

	public List getCostList() throws MpmException;

	public List getResTypeList() throws MpmException;

	public MtlResList findResListByCode(String resCode, String resFlag) throws MpmException;
	
	/**
	 * 得到所有的成本类型；
	 * @return
	 * @throws Exception
	 */
	public List findAllCostList() throws Exception;
	
	/**
	 * 得到成本类型列表；
	 * 1. 传入的是一个总类；返回除这个类型之外的所有类型；
	 * 2. 传入的不是总类，返回本身；
	 * @param costCode  成本类型id；
	 * @return
	 * @throws Exception
	 */
	public List getAllSubCostList(String costCode) throws Exception;

	public Map findAllCost(MtlCostList svc, Integer curPage, Integer pageSize) throws MpmException;

	public MtlCostList saveCostList(MtlCostList mtlCostList) throws MpmException;

	public boolean updateCostList(MtlCostList mtlCostList) throws MpmException;

	public boolean deleteCostList(String costCode) throws MpmException;

	public MtlCostList findCostListByCode(String costCode) throws MpmException;

	public List findResListByCostCode(String costCode) throws MpmException;

	//public List findResourceCostByResCode(String resCode) throws MpmException;

	public Map findCostListMap() throws MpmException;
}

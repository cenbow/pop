package com.ai.bdx.frame.approval.service;

import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCallwsLog;

/**
 * 营销管理－数据源管理
 * @author yuantian 2006-6-1
 * @version 1.0
 */
public interface IMpmSendOddDataSourceSvc {

	/**
	 * 
	 * @return
	 * @throws MpmException
	 */
	public List findAllDatasource() throws MpmException;

	/**
	 * 根据波次得到模版文件列表
	 */
	public List getObjsByCampseg(String campsegId) throws MpmException;

	/**
	 * 宣传信息
	 */
	public Map getObjsCodeByCampsegId(String campsegId) throws MpmException;

	/**
	 * 
	 * @param campExportFiledef
	 * @return
	 * @throws MpmException
	 */

	/**
	 * 
	 * @param campsegId
	 * @return
	 * @throws MpmException
	 */

	/**
	 * 
	 * @param campsegId
	 * @param usersegid
	 * @return
	 * @throws MpmException
	 */
	public Map getCampsegidDimResType(String campsegId, int usersegid) throws MpmException;

	/**
	 * 
	 * @param usersegId
	 * @param campsegId
	 * @return
	 * @throws MpmException
	 */
	public Map getCampsegidChannelPlan(String usersegId, String campsegId) throws MpmException;

	/**
	 * 
	 * @param fileId
	 * @return
	 * @throws MpmException
	 */
	public List getFilterfileInfo(String[] fileId) throws MpmException;

	/**
	 * 
	 * @param sectionresult
	 * @param campseg_id
	 * @return
	 * @throws MpmException
	 */
	public Map getSubsectionResult(int sectionresult, String campseg_id) throws MpmException;

	/**
	 * 通过渠道标识＆渠道类型得到渠道的名称
	 * @param channelid
	 * @param channeltype
	 * @return
	 * @throws MpmException
	 */
	public Map getChannelName(String channelid, String channeltype) throws MpmException;

	/**
	 * 
	 * @param campsegId
	 * @return
	 * @throws Exception
	 */
	public Map getTempletExportData(String campsegId) throws Exception;

	/**
	 * 得到用户清单文件
	 * @param campsegId
	 * @param strsql
	 * @param userid
	 * @param exportflag
	 * @param filepath
	 * @throws Exception
	 */
	public boolean getuseritem(String campsegId, String strsql, String userid, String exportflag, String filepath)
			throws Exception;

	/**
	 * 
	 * @param campId
	 * @param campsegId
	 * @param userId
	 * @param currpage
	 * @param pagesize
	 * @return
	 * @throws Exception
	 */
	public Map getTempletExportDataFile(String campId, String campsegId, String userId, Integer currpage,
			Integer pagesize) throws Exception;

	/**
	 * 按驱动类型导出文件
	 * @param campsegid
	 * @param userid
	 * @throws Exception
	 */
	public boolean exportBossItem(String campsegid, String userid) throws Exception;

	/**
	 * 
	 * @param campsegId
	 * @return
	 * @throws Exception
	 */
	public Map getMtlTempletSelectResult(String campsegId) throws Exception;



	/**
	 * 
	 * @param campsegId
	 * @param channelid
	 * @return
	 * @throws Exception
	 */
	public int getCampsegidChannelid(String campsegId, String channelid) throws Exception;

	/**
	 * 通过datafileId删除记录
	 * @param mtlDatafileContentItem
	 * @throws MpmException
	 */
	//public void deleteById(MtlDatafileContentItem mtlDatafileContentItem) throws MpmException ;    
	/**
	 * 建立反馈表
	 * @param campsegId
	 * @throws MpmException
	 */
	public void createTableByTemplet(String campsegId) throws MpmException;




	/**
	 * 
	 * @param exportCondId
	 * @param exportItem
	 * @throws MpmException
	 */
	public void saveCampsegExportContent(String exportCondId, String[] exportItem) throws MpmException;

	/**
	 * 
	 * @param exportCondId
	 * @param stepIdArray
	 * @throws MpmException
	 */
	public void saveCampsegExportColumn(String exportCondId, String[] stepIdArray) throws MpmException;

	/**
	 * 
	 * @param campId
	 * @param campsegId
	 * @param userId
	 * @param flag
	 * @param currpage
	 * @param pagesize
	 * @return
	 * @throws Exception
	 */
	public Map getExportCond(String campId, String campsegId, String userId, Short flag, Integer currpage,
			Integer pagesize) throws Exception;

	/**
	 * 
	 * @param exportCondId
	 * @return
	 * @throws Exception
	 */
	public List getExportFile(String exportCondId) throws Exception;

	/**
	 * 等待后台派单处理
	 * @param exportCondId
	 * @return
	 * @throws Exception
	 */
	public boolean waitForExportCall(String campsegId) throws Exception;

	/**
	 * 调用接口，传送外呼类营销活动信息
	 * @param exportCondId
	 * @return
	 * @throws Exception
	 */
	public boolean updateCampsegInfo(String exportCondId, String campsegId, String[] usersegId,
			String[] useTestcallUserNums, String[] useCallCleanZero) throws Exception;

	/**
	 * 修改分组的试呼量等信息
	 * @param usersegId
	 * @param useTestcallUserNums
	 * @param useCallMaxCounts
	 * @param useCallCleanZero
	 * @throws Exception
	 */
	public boolean updateUsersegInfo(String campsegId, String[] usersegId, String[] useTestcallUserNums,
			String[] useCallCleanZero) throws Exception;

	/**
	 * 调用接口，传送网站类营销活动信息
	 * @param exportCondId
	 * @param campsegId
	 * @param custNum
	 * @param custGotoneNum
	 * @param custMzoneNum
	 * @param custScpNum
	 * @return
	 * @throws Exception
	 */
	public boolean updateCampsegInfoForWeb(String exportCondId, String campsegId, String custNum, String custGotoneNum,
			String custMzoneNum, String custScpNum) throws Exception;


	public boolean updateCampsegInfoToUnite(String exportCondId, String campsegId, String custNum,
			String custGotoneNum, String custMzoneNum, String custScpNum) throws Exception;

	public String saveMtlCallwsLog(MtlCallwsLog mtlCallwsLog) throws Exception;

	/**
	 * 可配置化统一派单
	 * @param map
	 * @param channelType
	 * @return
	 * @throws Exception
	 */
	public boolean commonSendInfo(Map<String, String> map, String channelType) throws Exception;

	
}
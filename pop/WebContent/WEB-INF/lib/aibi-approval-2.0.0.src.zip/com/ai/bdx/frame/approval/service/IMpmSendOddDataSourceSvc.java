package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCallwsLog;
import java.util.List;
import java.util.Map;

public abstract interface IMpmSendOddDataSourceSvc
{
  public abstract List findAllDatasource()
    throws MpmException;

  public abstract List getObjsByCampseg(String paramString)
    throws MpmException;

  public abstract Map getObjsCodeByCampsegId(String paramString)
    throws MpmException;

  public abstract Map getCampsegidDimResType(String paramString, int paramInt)
    throws MpmException;

  public abstract Map getCampsegidChannelPlan(String paramString1, String paramString2)
    throws MpmException;

  public abstract List getFilterfileInfo(String[] paramArrayOfString)
    throws MpmException;

  public abstract Map getSubsectionResult(int paramInt, String paramString)
    throws MpmException;

  public abstract Map getChannelName(String paramString1, String paramString2)
    throws MpmException;

  public abstract Map getTempletExportData(String paramString)
    throws Exception;

  public abstract boolean getuseritem(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws Exception;

  public abstract Map getTempletExportDataFile(String paramString1, String paramString2, String paramString3, Integer paramInteger1, Integer paramInteger2)
    throws Exception;

  public abstract boolean exportBossItem(String paramString1, String paramString2)
    throws Exception;

  public abstract Map getMtlTempletSelectResult(String paramString)
    throws Exception;

  public abstract int getCampsegidChannelid(String paramString1, String paramString2)
    throws Exception;

  public abstract void createTableByTemplet(String paramString)
    throws MpmException;

  public abstract void saveCampsegExportContent(String paramString, String[] paramArrayOfString)
    throws MpmException;

  public abstract void saveCampsegExportColumn(String paramString, String[] paramArrayOfString)
    throws MpmException;

  public abstract Map getExportCond(String paramString1, String paramString2, String paramString3, Short paramShort, Integer paramInteger1, Integer paramInteger2)
    throws Exception;

  public abstract List getExportFile(String paramString)
    throws Exception;

  public abstract boolean waitForExportCall(String paramString)
    throws Exception;

  public abstract boolean updateCampsegInfo(String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3)
    throws Exception;

  public abstract boolean updateUsersegInfo(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3)
    throws Exception;

  public abstract boolean updateCampsegInfoForWeb(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws Exception;

  public abstract boolean updateCampsegInfoToUnite(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws Exception;

  public abstract String saveMtlCallwsLog(MtlCallwsLog paramMtlCallwsLog)
    throws Exception;

  public abstract boolean commonSendInfo(Map<String, String> paramMap, String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMpmSendOddDataSourceSvc
 * JD-Core Version:    0.6.2
 */
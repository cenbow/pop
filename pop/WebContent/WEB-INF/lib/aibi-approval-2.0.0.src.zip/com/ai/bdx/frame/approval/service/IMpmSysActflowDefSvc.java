package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
import com.ai.bdx.frame.approval.model.MtlSysFlowstepDef;
import java.util.List;
import java.util.Map;

public abstract interface IMpmSysActflowDefSvc
{
  public abstract Map findAllActflow(MtlSysActflowDef paramMtlSysActflowDef, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract MtlSysActflowDef findActflowById(String paramString)
    throws MpmException;

  public abstract String saveActflow(MtlSysActflowDef paramMtlSysActflowDef, String[] paramArrayOfString)
    throws MpmException;

  public abstract boolean updateActflow(MtlSysActflowDef paramMtlSysActflowDef)
    throws MpmException;

  public abstract List getActflowStepById(String paramString)
    throws MpmException;

  public abstract boolean deleteSysActflow(String paramString)
    throws MpmException;

  public abstract String getSysActStepArray()
    throws MpmException;

  public abstract String getExistsStepArray(String paramString)
    throws MpmException;

  public abstract boolean saveFlowStep(MtlSysFlowstepDef paramMtlSysFlowstepDef)
    throws MpmException;

  public abstract boolean deleteStepById(String paramString)
    throws MpmException;

  public abstract List getSysActStepList()
    throws MpmException;

  public abstract List getAllSysActFlowDefList()
    throws MpmException;

  public abstract List getCampSysActFlowDefList()
    throws MpmException;

  /** @deprecated */
  public abstract List getSysActFlowDefListByLevel(int paramInt)
    throws MpmException;

  public abstract boolean getActFlowDefByApproveflowid(String paramString)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMpmSysActflowDefSvc
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service;


import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
import com.ai.bdx.frame.approval.model.MtlSysFlowstepDef;

public interface IMpmSysActflowDefSvc {

	public Map findAllActflow(MtlSysActflowDef svc, Integer curPage, Integer pageSize) throws MpmException;

	public MtlSysActflowDef findActflowById(String flowId) throws MpmException;

	public String saveActflow(MtlSysActflowDef mtlSysActflowDef, String[] stepId) throws MpmException;

	public boolean updateActflow(MtlSysActflowDef mtlSysActflowDef) throws MpmException;

	public List getActflowStepById(String flowId) throws MpmException;

	public boolean deleteSysActflow(String flowId) throws MpmException;

	public String getSysActStepArray() throws MpmException;

	public String getExistsStepArray(String flowId) throws MpmException;

	public boolean saveFlowStep(MtlSysFlowstepDef mtlSysFlowstepDef) throws MpmException;

	public boolean deleteStepById(String flowId) throws MpmException;

	public List getSysActStepList() throws MpmException;

	/**
	 * 取所有活动流程Select格式信息
	 * @return 包含(ValueBean)的活动流程信息
	 * @throws MpmException
	 */
	public List getAllSysActFlowDefList() throws MpmException;

	/**
	 * 取营销案活动内置流程Select格式信息
	 * @return 包含(ValueBean)的活动流程信息
	 * @throws MpmException
	 */
	public List getCampSysActFlowDefList() throws MpmException;

	/**
	 * 取小于等于某个审批级别的活动流程Select格式信息
	 * @param approveLevel
	 * @return 包含(ValueBean)的活动流程信息
	 * @throws MpmException
	 * @deprecated 不再使用 wuwl 2007-6-21
	 */
	public List getSysActFlowDefListByLevel(int approveLevel) throws MpmException;

	/**
	 * 查看审批流程是否被使用。
	 * @param approveFlowId
	 * @return
	 * @throws MpmException
	 */
	public boolean getActFlowDefByApproveflowid(String approveFlowId) throws MpmException;
}


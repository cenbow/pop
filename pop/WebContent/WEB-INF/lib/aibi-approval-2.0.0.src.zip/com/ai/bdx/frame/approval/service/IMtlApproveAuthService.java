package com.ai.bdx.frame.approval.service;

import java.util.List;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveAuth;
import com.ai.bdx.frame.approval.model.MtlApproveAuthId;

/**
 * Created on May 30, 2007 11:18:47 AM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb
 * @version 1.0
 */
public interface IMtlApproveAuthService {
	/**
	 * 得到委派信息
	 * @param authUserid
	 * @return
	 * @throws MpmException
	 */
	public MtlApproveAuth getAuthInfo(MtlApproveAuthId id) throws MpmException;

	/**
	 * 得到委派授权信息
	 * @param authUserid
	 * @return
	 * @throws MpmException
	 */
	public List getAuthRelation(String authUserid) throws MpmException;

	/**
	 * 审批权委派
	 * @param auth
	 * @return
	 * @throws MpmException
	 */
	public boolean saveAuth(MtlApproveAuth auth) throws MpmException;

	/**
	 * 确认权委派
	 * @param auth
	 * @return
	 * @throws MpmException
	 */
	public boolean saveConfirmAuth(MtlApproveAuth auth) throws MpmException;

	/**
	 * 回收审批权
	 * @param auth
	 * @return
	 * @throws MpmException
	 */
	public boolean deleteAuth(MtlApproveAuth auth) throws MpmException;

	/**
	 * 回收确认权
	 * @param auth
	 * @return
	 * @throws MpmException
	 */
	public boolean deleteConfirmAuth(MtlApproveAuth auth) throws MpmException;
}

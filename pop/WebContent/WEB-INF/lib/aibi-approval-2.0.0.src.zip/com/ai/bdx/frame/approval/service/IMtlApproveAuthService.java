package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveAuth;
import com.ai.bdx.frame.approval.model.MtlApproveAuthId;
import java.util.List;

public abstract interface IMtlApproveAuthService
{
  public abstract MtlApproveAuth getAuthInfo(MtlApproveAuthId paramMtlApproveAuthId)
    throws MpmException;

  public abstract List getAuthRelation(String paramString)
    throws MpmException;

  public abstract boolean saveAuth(MtlApproveAuth paramMtlApproveAuth)
    throws MpmException;

  public abstract boolean saveConfirmAuth(MtlApproveAuth paramMtlApproveAuth)
    throws MpmException;

  public abstract boolean deleteAuth(MtlApproveAuth paramMtlApproveAuth)
    throws MpmException;

  public abstract boolean deleteConfirmAuth(MtlApproveAuth paramMtlApproveAuth)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMtlApproveAuthService
 * JD-Core Version:    0.6.2
 */
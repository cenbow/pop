package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
import java.util.List;
import java.util.Map;

public abstract interface IMtlApproveFlowDefService
{
  public abstract MtlApproveFlowDef getApproveFlowDef(String paramString)
    throws MpmException;

  public abstract MtlApproveFlowDef getApproveFlowDefWithAllChilds(String paramString)
    throws MpmException;

  public abstract List getAllApproveFlowDefAsLabelValueBean(String paramString)
    throws MpmException;

  public abstract List getAllApproveFlowDefAsLabelValueBean()
    throws MpmException;

  public abstract List getAllApproveFlowDef()
    throws MpmException;

  public abstract List getAllApproveFlowDef(String paramString)
    throws MpmException;

  public abstract Map findApproveFlow(MtlApproveFlowDef paramMtlApproveFlowDef, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void deleteApproveFlowDef(String paramString)
    throws MpmException;

  public abstract void saveApproveFlowDef(MtlApproveFlowDef paramMtlApproveFlowDef, String paramString)
    throws MpmException;

  public abstract void updateApproveFlowDef(MtlApproveFlowDef paramMtlApproveFlowDef)
    throws MpmException;

  public abstract List getApproveLevelDefByFlow(String paramString)
    throws MpmException;

  public abstract List getApproveTriggerCondDefByFlow(String paramString)
    throws MpmException;

  public abstract List getApproveTriggerCondDefByFlowAndLevel(String paramString, Integer paramInteger)
    throws MpmException;

  public abstract String getApproveObjNameByTypeAndIdCache(Integer paramInteger, String paramString)
    throws MpmException;

  public abstract List getAllApproveTriggerCondIndi()
    throws MpmException;

  public abstract String getApproveTriggerCondIndiNameCache(String paramString)
    throws MpmException;

  public abstract boolean isApproveFlowCanDelete(String paramString)
    throws MpmException;

  public abstract boolean isApproveFlowCanDelete1(String paramString)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService
 * JD-Core Version:    0.6.2
 */
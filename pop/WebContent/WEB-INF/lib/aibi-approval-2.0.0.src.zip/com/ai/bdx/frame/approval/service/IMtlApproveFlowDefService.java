package com.ai.bdx.frame.approval.service;


import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;

/**
 * Created on Apr 26, 2007 2:45:18 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlApproveFlowDefService {

	/**
	 * 根据审批流程编码取流程定义信息
	 * @param approveFlowId
	 * @return
	 * @throws MpmException
	 */
	public MtlApproveFlowDef getApproveFlowDef(String approveFlowId) throws MpmException;

	/**
	 * 根据审批流程编码取流程定义信息(包括每个审批级别的定义、每个审批级别的触发条件定义信息)
	 * @param approveFlowId
	 * @return
	 * @throws MpmException
	 */
	public MtlApproveFlowDef getApproveFlowDefWithAllChilds(String approveFlowId) throws MpmException;

	/**
	 * 取所有审批流程定义信息
	 * @return list(每个element是一个LabelValueBean)
	 * @throws MpmException
	 */
	public List getAllApproveFlowDefAsLabelValueBean(String userid) throws MpmException;

	public List getAllApproveFlowDefAsLabelValueBean() throws MpmException;

	/**
	 * 取所有审批流程定义信息
	 * @return list(每个element是一个MtlApproveFlowDef)
	 * @throws MpmException
	 */
	public List getAllApproveFlowDef() throws MpmException;

	public List getAllApproveFlowDef(String userid) throws MpmException;

	/**
	 * 根据查询条件分页取审批流程定义信息
	 * @param searchCond
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 */
	public Map findApproveFlow(MtlApproveFlowDef searchCond, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 删除审批流程定义信息
	 * @param approveFlowId
	 * @throws MpmException
	 */
	public void deleteApproveFlowDef(String approveFlowId) throws MpmException;

	/**
	 * 保存审批流程定义信息
	 * @param def
	 * @throws MpmException
	 */
	public void saveApproveFlowDef(MtlApproveFlowDef def,String objId) throws MpmException;

	/**
	 * 删除审批流程定义信息
	 * @param def
	 * @throws MpmException
	 */
	public void updateApproveFlowDef(MtlApproveFlowDef def) throws MpmException;

	/**
	 * 取审批流程中定义的所有审批级别信息
	 * @param flowId
	 * @return
	 * @throws MpmException
	 */
	public List getApproveLevelDefByFlow(String flowId) throws MpmException;

	/**
	 * 取审批流程中定义的所有审批触发条件信息
	 * @param flowId
	 * @return
	 * @throws MpmException
	 */
	public List getApproveTriggerCondDefByFlow(String flowId) throws MpmException;

	/**
	 * 取审批流程中某个审批级别下定义的审批触发条件信息
	 * @param flowId
	 * @param level
	 * @return
	 * @throws MpmExceptin
	 */
	public List getApproveTriggerCondDefByFlowAndLevel(String flowId, Integer level) throws MpmException;

	/**
	 * 根据审批人类型及审批人ID取审批人名称
	 * @param objType
	 * @param objId
	 * @return 名称（可能是""、部门名称、人名、数字）
	 * @throws MpmException
	 */
	public String getApproveObjNameByTypeAndIdCache(Integer objType, String objId) throws MpmException;

	/**
	 * 取所有触发条件指标定义信息
	 * @return
	 * @throws MpmException
	 */
	public List getAllApproveTriggerCondIndi() throws MpmException;

	/**
	 * 根据指标编号取触发条件指标定义的名称
	 * @param indiId
	 * @return
	 * @throws MpmException
	 */
	public String getApproveTriggerCondIndiNameCache(String indiId) throws MpmException;

	/**
	 * 判断审批流程是否可以审批
	 * @param flowId
	 * @return
	 * @throws MpmException
	 */
	public boolean isApproveFlowCanDelete(String flowId) throws MpmException;
	public boolean isApproveFlowCanDelete1(String flowId) throws MpmException;
}
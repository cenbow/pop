package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.MtlApproveResourceTypeForm;
import com.ai.bdx.frame.approval.model.MtlApproveResourceType;
import java.util.Map;

public abstract interface IMtlApproveResourceTypeService
{
  public abstract void save(MtlApproveResourceType paramMtlApproveResourceType)
    throws MpmException;

  public abstract Map searchMtlApproveResourceType(MtlApproveResourceTypeForm paramMtlApproveResourceTypeForm, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract void delete(MtlApproveResourceTypeForm paramMtlApproveResourceTypeForm)
    throws MpmException;

  public abstract MtlApproveResourceType getMtlApproveResourceType(String paramString)
    throws MpmException;

  public abstract void update(MtlApproveResourceType paramMtlApproveResourceType)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMtlApproveResourceTypeService
 * JD-Core Version:    0.6.2
 */
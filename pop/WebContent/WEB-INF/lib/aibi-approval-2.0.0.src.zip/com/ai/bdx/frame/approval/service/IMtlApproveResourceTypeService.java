package com.ai.bdx.frame.approval.service;


import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.MtlApproveResourceTypeForm;
import com.ai.bdx.frame.approval.model.MtlApproveResourceType;

public interface IMtlApproveResourceTypeService {

	/**
	 * @param 保存确认资源类型信息
	 * @throws MpmException
	 */
	public void save(MtlApproveResourceType mtlApproveResourceType) throws MpmException;

	/**
	 * @param 分页查询资源类型
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 */
	public Map searchMtlApproveResourceType(MtlApproveResourceTypeForm searchForm, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * @param 删除确认资源类型信息
	 * @throws MpmException
	 */
	public void delete(MtlApproveResourceTypeForm searchForm) throws MpmException;

	/**
	 * @param 取得确认资源类型信息
	 * @return
	 * @throws MpmException
	 */
	public MtlApproveResourceType getMtlApproveResourceType(String resourceId) throws MpmException;

	public void update(MtlApproveResourceType mtlApproveResourceType) throws MpmException;

}

package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import java.util.List;

public abstract interface IMtlConfirmService
{
  public abstract List findAllRourceType()
    throws MpmException;

  public abstract int getMaxResourceId()
    throws MpmException;

  public abstract List findRourceTypeByFlag(short paramShort)
    throws MpmException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMtlConfirmService
 * JD-Core Version:    0.6.2
 */
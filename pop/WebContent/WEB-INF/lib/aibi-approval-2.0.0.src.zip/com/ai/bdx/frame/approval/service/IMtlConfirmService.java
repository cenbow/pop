package com.ai.bdx.frame.approval.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.MpmCampApproveDetailMainForm;
import com.ai.bdx.frame.approval.form.MpmCampsegApproveForm;
import com.ai.bdx.frame.approval.model.DimChannelUserRelation;
import com.ai.bdx.frame.approval.model.MtlApproveConfirmAppoint;
import com.ai.bdx.frame.approval.model.MtlApproveConfirmList;
import com.ai.bdx.frame.approval.model.MtlApproveContentSend;
import com.ai.bdx.frame.approval.model.MtlApproveResourceType;
import com.ai.bdx.frame.approval.model.MtlCampChanneltype;
import com.ai.bdx.frame.approval.model.MtlConfirmExtendInfo;
import com.ai.bdx.frame.approval.model.MtlConfirmExtendInfoId;

/**
 * Created on 5:29:41 PM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb
 * @version 1.0
 */
public interface IMtlConfirmService {
	/**
	 * 查询所有的资源类型信息
	 * @return
	 * @throws MpmException
	 */
	public List findAllRourceType() throws MpmException;
	
	
	/**取得确认资源最大id
	 * @return
	 * @throws MpmException
	 */
	public int getMaxResourceId() throws MpmException;

	
	/**
	 * 查询渠道类型的资源信息
	 * @param resourceFlag
	 * @return
	 * @throws MpmException
	 */
	public List findRourceTypeByFlag(short resourceFlag) throws MpmException;
	
	
	
	
	/*
	

	*//**
	 * 根据资源标识查询
	 * @param resourceId
	 * @return
	 * @throws MpmException
	 *//*
	public MtlApproveResourceType findRourceTypeById(Integer resourceId) throws MpmException;

	*//**
	 * 根据条件查询资源确认人员信息
	 * @param searchCond
	 * @return
	 * @throws MpmException
	 *//*
	public List findConfirmList(MtlApproveConfirmList searchCond) throws MpmException;

	*//**
	 * 根据条件查询资源确认人员信息
	 * @param campsegId
	 * @param confirmId
	 * @param resourceId
	 * @param confirmUserid
	 * @return
	 * @throws MpmException
	 *//*
	public List findConfirmListById(String campsegId, String confirmId, String resourceId, String confirmUserid, String approveFlowId, Short approveSeq, Short approveLevel) throws MpmException;

	*//**
	 * 根据条件查询当前资源确认人员信息
	 * @param campsegId
	 * @param confirmFlag
	 * @param resourceId
	 * @param confirmUserid
	 * @param approveFlowId
	 * @param approveSeq
	 * @param approveLevel
	 * @return
	 * @throws MpmException
	 *//*
	public List findCurrentConfirmListById(String campsegId, String confirmFlag, String resourceId, String confirmUserid, String approveFlowId, Short approveSeq, Short approveLevel) throws MpmException;
	
	*//**
	 * 更新资源确认信息
	 * @param svc
	 * @throws MpmException
	 *//*
	public void updateConfirmList(MtlApproveConfirmList svc) throws MpmException;

	*//**
	 * 更新资源确认信息
	 * @param svc
	 * @throws MpmException
	 *//*
	public void saveConfirmList(MtlApproveConfirmList svc) throws MpmException;

	*//**
	 * 保存资源确认信息
	 * @param campsegId
	 * @param resourceIdArr
	 * @param confirmUseridArr
	 * @param forecastDateArr
	 * @param remindDateArr
	 * @throws MpmException
	 *//*
	public void saveCampsegConfirmList(String campsegId, String resourceIdArr, String confirmUseridArr, String forecastDateArr, String remindDateArr, String confirmExplainArr, String needApproveUserid) throws MpmException;

	*//**
	 * @param 判断某一活动/营销案的所有资源确认情况
	 * caihao 08/03
	 * @return
	 * @throws MpmException
	 *//*
	public String checkConfirmEnd(String campsegId) throws MpmException;

	*//**
	 * @param 查询确认列表
	 * @return
	 * @throws MpmException
	 *//*
	public List findByCond(MtlApproveConfirmList searchCond) throws MpmException;

	*//**
	 * @param 营销活动确认发送短信邮件通知
	 * @param aForm
	 * @param userId
	 * @throws MpmException
	 *//*
	public void saveConfirmSendContent(HttpServletRequest request, MpmCampApproveDetailMainForm aForm, String userId) throws MpmException;

	*//**
	 * @param  保存确认通知内容
	 * @throws MpmException
	 *//*
	public void saveApproveContentSend(MtlApproveContentSend obj) throws MpmException;

	*//**
	 * @param 批量营销活动确认的短信邮件提醒功能
	 * @param aForm
	 * @param userId
	 * @throws MpmException
	 *//*
	public void saveBatchConfirmSendContent(HttpServletRequest request, MpmCampsegApproveForm aForm, String userId, String startDate, String endDate) throws MpmException;

	
	*//**
	 * @param 营销案确认发送短信邮件通知
	 * @param aForm
	 * @param userId
	 * @throws MpmException
	 *//*
	public void saveCampConfirmSendContent(HttpServletRequest request, MpmCampApproveDetailMainForm aForm, String userId, String custNums, String rptScore, String resName) throws MpmException;

	*//**
	 * @param 批量营销案确认的短信邮件提醒功能
	 * @param aForm
	 * @param userId
	 * @throws MpmException
	 *//*
	public void saveBatchCampConfirmSendContent(HttpServletRequest request, MpmCampsegApproveForm aForm, String userId, Double custNums, int rptScore, String resourceName) throws MpmException;

	*//**
	 * @param 判断确认资源类型
	 * @return
	 * @throws MpmException
	 *//*
	public String checkResourceType(Integer resourceId) throws MpmException;

	*//**
	 * @param 查询渠道确认人关系表
	 * @param userId
	 * @param confirmType
	 * @return
	 * @throws MpmException
	 *//*
	public DimChannelUserRelation getChannelTypeId(Integer resourceId, String userId, String confirmType) throws MpmException;

	*//**
	 * @param 查询营销案渠道类型定义表
	 * @param campId
	 * @param channelId
	 * @return
	 * @throws MpmException
	 *//*
	public MtlCampChanneltype getChanneltype(Short channeltypeId, String campId, String channelId) throws MpmException;

	*//**
	 * @param 取营销确认额外信息
	 * @param resourceId
	 * @param confirmUserid
	 * @param usersegId
	 * @return
	 * @throws MpmException
	 *//*
	public List getConfirmExtendInfo(String campsegId, Integer resourceId, String confirmUserid, Short usersegId, Short approveSeq) throws MpmException;

	*//**
	 * @param  更新确认额外信息表目标客户数
	 * @param resourceId
	 * @param confirmUserid
	 * @param usersegId
	 * @param custNums
	 * @throws MpmException
	 *//*
	public void updateConfirmExtendInfoCustNums(String campsegId, Integer resourceId, String confirmUserid, Short usersegId, Short approveSeq, Double custNums) throws MpmException;

	*//**
	 * @param 更新确认额外信息表评分结果
	 * @param resourceId
	 * @param confirmUserid
	 * @param usersegId
	 * @param rptScore
	 * @throws MpmException
	 *//*
	public void updateConfirmExtendInfoRptScore(String campsegId, Integer resourceId, String confirmUserid, Short usersegId, Short approveSeq, Integer rptScore) throws MpmException;

	*//**
	 * @param 保存确认后客户数到额外信息表
	 * @throws MpmException
	 *//*
	public void saveConfirmExtendInfoCustNums(MtlConfirmExtendInfo mcei) throws MpmException;

	*//**
	 * @param 根据campId取得渠道信息
	 * @return
	 * @throws MpmException
	 *//*
	public List getChanneltypeByCampid(String campId) throws MpmException;

	*//**
	 * 取营销确认额外信息
	 * @param id
	 * @return
	 * @throws Exception
	 *//*

	public MtlConfirmExtendInfo getConfirmExtendInfo(MtlConfirmExtendInfoId id) throws MpmException;

	*//**
	 * @param  取营销确认额外信息
	 * @param resourceId
	 * @param confirmUserid
	 * @param usersegId
	 * @return
	 * @throws MpmException
	 *//*
	public List getMtlConfirmExtendInfo(String campsegId, Integer resourceId, String confirmUserid, Short usersegId, Short approveSeq) throws MpmException;

	*//**
	 * @param 更新确认额外信息表中的确认后日期
	 * @param resourceId
	 * @param confirmUserid
	 * @param usersegId
	 * @param startDate
	 * @param endDate
	 * @throws MpmException
	 *//*
	public void updateConfirmExtendInfoDate(String campsegId, Integer resourceId, String confirmUserid, Short usersegId, Short approveSeq, String startDate, String endDate) throws MpmException;

	*//**
	 * @param 更新确认额外信息表中的确认后分组营销用语
	 * @param resourceId
	 * @param confirmUserid
	 * @param usersegId
	 * @param content
	 * @throws MpmException
	 *//*
	public void updateConfirmExtendInfoContent(String campsegId, Integer resourceId, String confirmUserid, Short usersegId, Short approveSeq, String content) throws MpmException;

	*//**
	 * @param 取得资源类型
	 * @return
	 * @throws MpmException
	 *//*
	public MtlApproveResourceType getResourceType(Integer resourceId) throws MpmException;

	*//**
	 * @param 查找需要确认的营销案
	 * @return
	 * @throws MpmException
	 *//*
	public List findAllNeedConfirmCamp(String approveUserids) throws MpmException;

	*//**
	 * @param 查找已经确认的营销案
	 * @return
	 * @throws MpmException
	 *//*
	public List findAllConfirmedCamp(String approveUserids) throws MpmException;

	*//**
	 * @param 更新活动定义表中的confirm_flag
	 * @param confirmFlag
	 * @throws MpmException
	 *//*
	public void updateCampsegConfirmFlag(String campsegId, Short confirmFlag) throws MpmException;

	*//**
	 * @param 查找已经确认的营销活动
	 * @return
	 * @throws MpmException
	 *//*
	public List findAllConfirmed(String approveUserids) throws MpmException;

	*//**
	 * @param 查找需要确认的营销活动
	 * @return
	 * @throws MpmException
	 *//*
	public List findAllNeedConfirm(String approveUserids) throws MpmException;

	*//**
	 * @param 所有营销活动确认完毕后，判断是否更改活动状态以及更改营销活动确认状态
	 * @param campsegId
	 * @param userId
	 * @param port
	 *//*
	public void doAllConfirmFinished(String campId, String campsegId, String userId, String port);

	
	
	*//**
	 * @param 根据名称取得资源类型信息
	 * @return
	 * @throws MpmException
	 *//*
	public MtlApproveResourceType getResourceTypeByName(String resourceName) throws MpmException;

	*//**
	 * @param 判断某人是否确认完某一活动的全部资源
	 * @param userid
	 * @return
	 * @throws MpmException
	 *//*
	public String checkUserConfirmEnd(String campsegId, String userid, Integer resourceId) throws MpmException;

	*//**
	 * @param approveFlowId
	 * @param campsegId
	 * @return
	 * @throws MpmException
	 *//*
	public String getFirstApproveUser(String approveFlowId, String campsegId, Integer resourceId) throws MpmException;

	*//**
	 * @param approveFlowId
	 * @param campsegId
	 * @param approveUserId
	 * @param token
	 * @throws MpmException
	 *//*
	public void updateCampsegApproverToken(String approveFlowId, String campsegId, String approveUserId, Short seq, Short token, Integer resourceId) throws MpmException;

	*//**
	 * @param approveFlowId
	 * @param campsegId
	 * @param currApproverUserId
	 * @return
	 * @throws MpmException
	 *//*
	public boolean isLastApproveUser(String approveFlowId, String campsegId, String currApproverUserId, Integer resourceId, Short seq) throws MpmException;

	*//**
	 * @param approveFlowId
	 * @param campsegId
	 * @param currApproveUserId
	 * @return
	 * @throws MpmException
	 *//*
	public String[] getNextApproveUser(String approveFlowId, String campsegId, String currApproveUserId, Integer resourceId, Short seq) throws MpmException;

	*//**
	 * @param campsegId
	 * @param resourceId
	 * @return
	 * @throws MpmException
	 *//*
	public boolean checkConfirmFailed(String campsegId, Integer resourceId) throws MpmException;

	*//**
	 * @param 自动提交确认保存确认列表
	 * @param campsegId
	 * @param needApproveUserid
	 * @throws MpmException
	 *//*
	public void saveCampsegConfirmListAuto(DimChannelUserRelation dimChannelUserRelation, String campsegId, String needApproveUserid) throws MpmException;
	
	*//**
	 * 
	 * getCampApproveFlowIDForBj:针对北京提出的需求改造,针对外呼渠道，非分公司策划人需要两级审批，分公司策划人只需要一级审批添加判断逻辑，这个部分也可给其他省份应用，只需要在省份配置文件里配置MCD_APPROVE_CONFIRM_ID，GSD_COMMPANY_DEPTID即可
	 * @param channelID
	 * @return String
	 * @throws Exception 
	 *//*
	public String getCampApproveFlowIDForBj(String channelID,String campId) throws Exception;
	*//**
	 * @param 自动提交确认保存确认列表新，保存基本活动活动信息Id
	 * @param campsegId
	 * @param needApproveUserid
	 * @throws MpmException
	 *//*
	public void saveCampsegConfirmListAutoNew(DimChannelUserRelation dimChannelUserRelation, String campsegId, String needApproveUserid, String campsegRootid) throws MpmException;
	

	*//**
	 * 
	 * @param channeltypeId
	 * @param campId
	 * @param channelNo
	 * @return
	 * @throws MpmException
	 *//*
	public MtlCampChanneltype getChanneltypeByNo(Short channeltypeId, String campId, String channelNo) throws MpmException;
	
	*//**
	 * 查看某活动的某项资源是否确认完成
	 * @param campsegId
	 * @param resourceId
	 * @param confirmFlag
	 * @return
	 * @throws MpmException
	 *//*
	public boolean checkConfirmFinished(String campsegId,Short resourceId,int confirmFlag) throws MpmException;
	
	*//**
	 * 根据条件查找需要审批的记录
	 * @param approver
	 * @return
	 * @throws MpmException
	 *//*
	public List findUserConfirmList(MtlApproveConfirmList approver) throws MpmException ;
	
	*//**
	 * 查讯日历显示的待确认的营销案
	 * @param approver
	 * @return
	 * @throws MpmException
	 * @throws Exception 
	 *//*
	public String findConfirmCampForCalendar(String approveUserids) throws MpmException, Exception ;
	*//**
	 * 查讯日历显示的待确认的营销活动
	 * @param approver
	 * @return
	 * @throws MpmException
	 * @throws Exception 
	 * @throws Exception 
	 *//*
	public String findConfirmCampsegForCalendar(String approveUserids) throws MpmException, Exception;
	
	*//**
	 * 更新营销确认状态
	 * @param campsegId 营销ID
	 * @param resourceId 资源ID
	 * @param confirmFlag 更新后的确认状态
	 * @throws Exception
	 *//*
	public void updateCampsegConfirmFlag(String campsegId, Integer resourceId, String confirmFlag) throws Exception;
	
	*//**
	 * 删除活动已有的确认信息
	 * @param campsegId 营销ID
	 * @throws Exception
	 *//*
	public void deleteCampsegConfirmList(String campsegId) throws MpmException;
	
	*//**
	 * 取得确认流程第一个序列；
	 * @param campsegId
	 * @param flowId
	 * @param resourceId
	 * @return
	 * @throws MpmException
	 *//*
	public Short getFirstApproveSeq(String campsegId, String flowId, Integer resourceId) throws MpmException;
	
	*//**
	 * 得到确认人信息；
	 * @param campsegId
	 * @param flowId
	 * @param userId
	 * @param resourceId
	 * @return
	 * @throws MpmException
	 *//*
	public MtlApproveConfirmList getApproveConfirmList(String campsegId, String flowId, String userId, Integer resourceId) throws MpmException;
	
	*//**
	 * 得到当前确认人信息；
	 * @param campsegId
	 * @param flowId
	 * @param userId
	 * @param resourceId
	 * @return
	 * @throws MpmException
	 *//*
	public MtlApproveConfirmList getApproveCurrentConfirmList(String campsegId, String flowId, String userId, Integer resourceId) throws MpmException;
	
	*//**
	 * 校验活动是否全部确认通过
	 * @param campsegRootid
	 * @return
	 *//*
	public String checkConfirmAllFinished(String campsegRootid);
	
	*//**
	 * 获取活动下需要该用户确认的子活动
	 * @param campsegId
	 * @param userId
	 * @return
	 *//*
	public List<MtlApproveConfirmList> findByCampsegIdUserId(String campsegId,String userId);

	*//**
	 * 云南-拿到请示的短信模板
	 * @param i
	 * @return
	 *//*
	public String getCampSegConsultText(int i,String campSegId) throws MpmException;
	*//**
	 * 发送请示短信
	 * *//*
	public boolean saveAndSubmitConsutltText(String campsegId,String consutltText);
	*//**
	 * 得到历史请示短信
	 * *//*
	public String getConsutltHisText(String campsegId);
	
	*//**
	 * 得到历史请示短信(最后一条)
	 * *//*
	public String getConsutltHisTextLast(String campsegId);
	
	*//**
	 * 获取确认委派人列表
	 * @return
	 *//*
	public List<MtlApproveConfirmAppoint> getApproveConfirmAppointList();
	
	*//**
	 * 营销活动确认委派
	 * @param campsegId 营销活动id
	 * @param userId 用户id
	 * @param delegrateUserId 确认用户id
	 * @param delegrateAdvise 委派建议
	 *//*
	public void confirmDelegrate(String campsegId, String userId, String delegrateUserId, String delegrateAdvise) throws Exception;
	
	*//**
	 * @param 执行状态更改时发短信邮件通知功能
	 * @param aForm
	 * @param userId
	 * @param message
	 * @throws MpmException
	 *//*
	//public void saveSendOddContent(HttpServletRequest request, MpmSendOddForm aForm, String userId, String message) throws MpmException;
	*//**
	 * @param 查询用户已经确认过的营销活动
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 *//*
	//public Map findConfirmedCampsegInfo(MtlCampSeginfo segInfo, final Integer curPage, final Integer pageSize) throws MpmException;

	*//**
	 * @param 查询用户已经确认过的营销案
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 *//*
	//public Map findConfirmedCampInfo(MtlCampBaseinfo campInfo, final Integer curPage, final Integer pageSize) throws MpmException;

	*//**
	 * @param 取得营销活动信息
	 * @return
	 * @throws MpmException
	 *//*
	//public MtlCampSeginfo findCampsegInfo(String campsegId) throws MpmException;

	*//**
	 * @param 取得营销案信息
	 * @return
	 * @throws MpmException
	 *//*
	//public MtlCampBaseinfo findCampBaseInfo(String campId) throws MpmException;

*/}

package com.ai.bdx.frame.approval.service;

import java.util.List;
import java.util.Map;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
import com.ai.bdx.frame.approval.model.MtlCiCustMapping;
import com.ai.bdx.frame.approval.model.MtlCustGroup;
import com.ai.bdx.frame.approval.model.MtlTargetuserFile;

/**
 * Created on Oct 22, 2007 10:54:03 AM
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public interface IMtlCustGroupService {

	/**
	 * 按分页方式查询客户群信息
	 * @return
	 * @throws MpmException
	 */
	public Map findMtlCustGroup(MtlCustGroup custGroup, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 查询客户群清单中的用户信息
	 * @param tabName 客户群清单物理表名
	 * @param sqlWhere 查询条件
	 * @param columnList 查询字段列表
	 * @param curPage 当前页
	 * @param pageSize 每页记录数
	 * @return
	 * @throws MpmException
	 */
	public Map findCustGroupUser(String tabName, String sqlWhere, List columnList, Integer curPage, Integer pageSize) throws MpmException;

	/**
	 * 查询客户群信息
	 * @param custGroup
	 * @return List(element=MtlCustGroup)
	 * @throws MpmException
	 */
	public List findMtlCustGroup(MtlCustGroup custGroup) throws MpmException;

	/**
	 * 查询用户上载的目标客户文件的载入情况
	 * @param userFile
	 * @return List(element=MtlTargetuserFile)
	 * @throws MpmException
	 */
	public List findMtlTargetUserFile(MtlTargetuserFile userFile) throws MpmException;

	/**
	 * 获取目标客户文件上载的日志记录
	 * @param fileId
	 * @return
	 * @throws MpmException
	 */
	public MtlTargetuserFile getTargetuserFile(String fileId) throws MpmException;

	/**
	 * 取客户群信息
	 * @param custGroupId
	 * @return
	 * @throws Exception
	 */
	public MtlCustGroup getCustGroup(String custGroupId) throws MpmException;

	/**
	 * 保存客户群信息
	 * @param custGroup
	 * @throws Exception
	 */
	public String saveCustGroup(MtlCustGroup custGroup) throws MpmException;

	/**
	 * 更新客户群信息
	 * @param custGroup
	 * @throws Exception
	 */
	public void updateCustGroup(MtlCustGroup custGroup) throws MpmException;

	/**
	 * 更新给定map中表字段名的值
	 * @param columnAndValueMap
	 * @throws MpmException
	 */
	public void updateCustGroup(Map columnAndValueMap, String custGroupId) throws MpmException;

	/**
	 * 删除客户群信息
	 * @param custGroupId
	 * @param custGroupType
	 * @throws MpmException
	 */
	public void deleteMtlCustGroup(String custGroupId, Short custGroupType) throws MpmException;

	/**
	 * 更新客户群步骤状态及处理结果
	 * @param custGroupId
	 * @param flowId
	 * @param stepId
	 * @param flag
	 * @param result
	 * @throws MpmException
	 */
	public void updatePorgressFlagAndResult(String custGroupId, String flowId, Short stepId, String flag, String result) throws MpmException;

	/**
	 * 取客户群各个步骤的处理结果信息
	 * @param flowId
	 * @return
	 * @throws MpmException
	 */
	public List getCustGroupProgress(String flowId, String custGroupId) throws MpmException;

	/**
	 * 判断客户群信息是否可以修改
	 * @param custGroupId
	 * @param custGroupType
	 * @return
	 * @throws MpmException
	 */
	public boolean isCustGroupCanModify(String custGroupId, Short custGroupType, String currUserId, String groupId) throws MpmException;

	/**
	 * 判断客户群信息是否可以删除
	 * @param custGroupId
	 * @param custGroupType
	 * @param currUserId
	 * @param groupId
	 * @return
	 * @throws MpmException
	 */
	public boolean isCustGroupCanDelete(String custGroupId, Short custGroupType, String currUserId, String groupId) throws MpmException;
	/**
	 * 判断客户群信息是否可以细化
	 * @param custGroupId
	 * @param custGroupType
	 * @param currUserId
	 * @param groupId
	 * @return
	 * @throws MpmException
	 */
	public boolean isCustGroupCanDivide(String custGroupId, Short custGroupType, String currUserId, String groupId) throws MpmException;

	
	
	/**
	 * 判断客户群是否可以变更状态
	 * @param custGroupId
	 * @param custGroupType
	 * @param currUserId
	 * @param groupId
	 * @return (0 - 可以变更；1 - 当前用户不是客户群创建者或管理员，不能变更；2 - 客户群还有步骤未完成，不能变更；3 - 客户群已被营销活动引用，不能变更)
	 * @throws MpmException
	 */
	public int isCustGroupCanChgStatus(String custGroupId, Short custGroupType, String currUserId, String groupId) throws MpmException;

	public List getSegCustGroup(String campsegId) throws MpmException;

	/**
	 * 复制客户群信息
	 * @param sourceCustGroupId
	 * @param newCustGroupName
	 * @throws MpmException
	 */
	public void saveCustGroupCopy(String sourceCustGroupId, String newCustGroupName, String creatorUserId) throws MpmException;

	/**
	 * 取得活动客户属性值
	 * @param campsegId
	 * @param productNo
	 * @return
	 * @throws Exception
	 */
	public Map getMtlDuserXXXX(String campsegId, String productNo, String[] fieldArr) throws Exception;

	/**
	 * 获取全部执行反馈结果信息
	 * @return
	 * @throws Exception
	 */
	public List getFeedbackStatus(String feedbackStatusId, Short flagId,Short channeltypeId,String channelId) throws Exception;

	/**
	 * 根据标识获取执行反馈信息
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public List getFeedbackStatusById(String id) throws Exception;

	/**
	 * 外部系统传入营销活动编号、客户手机号码，
	 *  查询单个用户号码的历史营销活动信息
	 * @param productNo 客户号码
	 * @param promotionId 营销活动编号
	 * @return 历史营销活动信息类
	 */
	public List findCustCampsegHistory(String productNo, String promotionId) throws Exception;

	/**
	 * 获取步骤信息
	 * @param custGroupId
	 * @param flowId
	 * @param stepId
	 * @return
	 * @throws MpmException
	 */
	public MtlCampsegProgress getCampsegProgress(String custGroupId, String flowId, Short stepId) throws MpmException;
	
	public String saveMtlCiCustMapping(MtlCiCustMapping mtlCiCust) throws Exception ;
	
	public String getMtlCustIdByCiId(String ciCustId) throws Exception;
}

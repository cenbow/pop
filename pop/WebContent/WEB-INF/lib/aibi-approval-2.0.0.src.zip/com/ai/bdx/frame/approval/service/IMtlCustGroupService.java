package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
import com.ai.bdx.frame.approval.model.MtlCiCustMapping;
import com.ai.bdx.frame.approval.model.MtlCustGroup;
import com.ai.bdx.frame.approval.model.MtlTargetuserFile;
import java.util.List;
import java.util.Map;

public abstract interface IMtlCustGroupService
{
  public abstract Map findMtlCustGroup(MtlCustGroup paramMtlCustGroup, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract Map findCustGroupUser(String paramString1, String paramString2, List paramList, Integer paramInteger1, Integer paramInteger2)
    throws MpmException;

  public abstract List findMtlCustGroup(MtlCustGroup paramMtlCustGroup)
    throws MpmException;

  public abstract List findMtlTargetUserFile(MtlTargetuserFile paramMtlTargetuserFile)
    throws MpmException;

  public abstract MtlTargetuserFile getTargetuserFile(String paramString)
    throws MpmException;

  public abstract MtlCustGroup getCustGroup(String paramString)
    throws MpmException;

  public abstract String saveCustGroup(MtlCustGroup paramMtlCustGroup)
    throws MpmException;

  public abstract void updateCustGroup(MtlCustGroup paramMtlCustGroup)
    throws MpmException;

  public abstract void updateCustGroup(Map paramMap, String paramString)
    throws MpmException;

  public abstract void deleteMtlCustGroup(String paramString, Short paramShort)
    throws MpmException;

  public abstract void updatePorgressFlagAndResult(String paramString1, String paramString2, Short paramShort, String paramString3, String paramString4)
    throws MpmException;

  public abstract List getCustGroupProgress(String paramString1, String paramString2)
    throws MpmException;

  public abstract boolean isCustGroupCanModify(String paramString1, Short paramShort, String paramString2, String paramString3)
    throws MpmException;

  public abstract boolean isCustGroupCanDelete(String paramString1, Short paramShort, String paramString2, String paramString3)
    throws MpmException;

  public abstract boolean isCustGroupCanDivide(String paramString1, Short paramShort, String paramString2, String paramString3)
    throws MpmException;

  public abstract int isCustGroupCanChgStatus(String paramString1, Short paramShort, String paramString2, String paramString3)
    throws MpmException;

  public abstract List getSegCustGroup(String paramString)
    throws MpmException;

  public abstract void saveCustGroupCopy(String paramString1, String paramString2, String paramString3)
    throws MpmException;

  public abstract Map getMtlDuserXXXX(String paramString1, String paramString2, String[] paramArrayOfString)
    throws Exception;

  public abstract List getFeedbackStatus(String paramString1, Short paramShort1, Short paramShort2, String paramString2)
    throws Exception;

  public abstract List getFeedbackStatusById(String paramString)
    throws Exception;

  public abstract List findCustCampsegHistory(String paramString1, String paramString2)
    throws Exception;

  public abstract MtlCampsegProgress getCampsegProgress(String paramString1, String paramString2, Short paramShort)
    throws MpmException;

  public abstract String saveMtlCiCustMapping(MtlCiCustMapping paramMtlCiCustMapping)
    throws Exception;

  public abstract String getMtlCustIdByCiId(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.IMtlCustGroupService
 * JD-Core Version:    0.6.2
 */
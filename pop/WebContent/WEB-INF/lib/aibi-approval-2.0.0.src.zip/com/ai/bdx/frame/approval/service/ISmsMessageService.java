package com.ai.bdx.frame.approval.service;

import java.util.List;

import com.ai.bdx.frame.approval.model.SmsMessageFlowId;

/**
 * 短息发送Service
 * @author guoyj
 *
 */
public interface ISmsMessageService {

	/**
	 * 单条消息查表
	 * @param smsMessage
	 * @throws Exception
	 */
	public void saveSMSFlow(SmsMessageFlowId smsMessage) throws Exception;

	/**
	 * 批处理查表
	 * @param msgList
	 * @throws Exception
	 */
	public void saveSMSFlowBatch(List<SmsMessageFlowId> msgList) throws Exception;

	public List getCustNumber() throws Exception;


}

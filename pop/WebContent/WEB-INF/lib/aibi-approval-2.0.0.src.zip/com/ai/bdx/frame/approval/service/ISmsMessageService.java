package com.ai.bdx.frame.approval.service;

import com.ai.bdx.frame.approval.model.SmsMessageFlowId;
import java.util.List;

public abstract interface ISmsMessageService
{
  public abstract void saveSMSFlow(SmsMessageFlowId paramSmsMessageFlowId)
    throws Exception;

  public abstract void saveSMSFlowBatch(List<SmsMessageFlowId> paramList)
    throws Exception;

  public abstract List getCustNumber()
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.ISmsMessageService
 * JD-Core Version:    0.6.2
 */
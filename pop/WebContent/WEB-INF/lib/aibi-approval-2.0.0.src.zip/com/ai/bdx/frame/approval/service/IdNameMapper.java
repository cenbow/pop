package com.ai.bdx.frame.approval.service;

@SuppressWarnings("all")
public interface IdNameMapper extends com.asiainfo.biframe.service.IdNameMapper{
	
}

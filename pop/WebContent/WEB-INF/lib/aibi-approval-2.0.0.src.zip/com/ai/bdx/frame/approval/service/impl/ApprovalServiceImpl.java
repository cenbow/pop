package com.ai.bdx.frame.approval.service.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.bean.ApApproveList;
import com.ai.bdx.frame.approval.bean.ApproveLevelDef;
import com.ai.bdx.frame.approval.bean.ApproveRelation;
import com.ai.bdx.frame.approval.bean.ApproveTriggerCondDef;
import com.ai.bdx.frame.approval.dao.ApprovalDao;
import com.ai.bdx.frame.approval.service.IApprovalService;
import com.ai.bdx.frame.approval.util.ApprovalCONST;
import com.ai.bdx.frame.approval.util.NumberUtil;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.IUserCompany;
import com.asiainfo.biframe.utils.config.Configure;
import com.asiainfo.biframe.utils.string.StringUtil;

public class ApprovalServiceImpl implements IApprovalService {
	private static Logger log = LogManager.getLogger();
	private ApprovalDao approvalDao;
	private IUserPrivilegeCommonService userPrivilegeService;

	public ApprovalDao getApprovalDao() {
		return approvalDao;
	}

	public void setApprovalDao(ApprovalDao approvalDao) {
		this.approvalDao = approvalDao;
	}

	public IUserPrivilegeCommonService getUserPrivilegeService() {
		return userPrivilegeService;
	}

	public void setUserPrivilegeService(IUserPrivilegeCommonService userPrivilegeCommonService) {
		this.userPrivilegeService = userPrivilegeCommonService;
	}

	/**
	 * 
	 * getApprovalFlowIDByFirstApprovalUser:根据第一审批人获取审批流程
	 * 
	 * @param firstUserId
	 * @param approvalType
	 * @return
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#getApprovalFlowIDByFirstApprovalUser(java.lang.String,
	 *      java.lang.String)
	 */
	public String getApprovalFlowIDByFirstApprovalUser(String firstUserId, String approvalType) {

		return null;
	}

	/**
	 * 
	 * getApprovalFlowIDByDeptFlowRelation:根据配置关系获取审批流程
	 * 
	 * @param userId
	 * @param drvTypeID
	 * @param drvID
	 * @param approvalType
	 * @return
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#getApprovalFlowIDByDeptFlowRelation(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 */
	public String getApprovalFlowIDByDeptFlowRelation(String userId, String drvTypeID, String drvID, String approvalType)
			throws Exception {

		String result = "";
		String defaultFlowName = Configure.getInstance().getProperty("DEFAULT_APPROVALFLOW_NAME") == null ? "default1"
				: Configure.getInstance().getProperty("DEFAULT_APPROVALFLOW_NAME");
		log.debug("get default config default approval flow name is {}", defaultFlowName);
		if (StringUtil.isNotEmpty(userId) && StringUtil.isNotEmpty(drvTypeID) && StringUtil.isNotEmpty(drvID)
				&& StringUtil.isNotEmpty(approvalType)) {
			IUser user = userPrivilegeService.getUser(userId);

			// 先按照用户信息查流程,没有的情况下再查询范围较大的
			StringBuffer sql = new StringBuffer();
			sql.append("select approve_flow_id from ap_dept_flow_relation where city_id in('").append(user.getCityid())
					.append("') and dept_id in('").append(user.getDepartmentid()).append("') ");
			sql.append("  and relation_type=:relation_type");
			sql.append("  and camp_drv_id=:camp_drv_id");
			sql.append("  and appr_flow_tpye=:appr_flow_tpye ");
			sql.append("  order by city_id,dept_id desc");
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("relation_type", drvTypeID);
			params.put("camp_drv_id", drvID);
			params.put("appr_flow_tpye", approvalType);
			List<?> list = approvalDao.getObjectsBySQL(sql.toString(), params);
			if (list != null && list.size() > 0) {// 当根据用户信息找到流程ID直接返回
				return (String) list.get(0);
			} else {// 当找不到时，全省或者默认设置，即比当前用户范围大的审批流程
				StringBuffer sql1 = new StringBuffer();
				sql1.append("select approve_flow_id from ap_dept_flow_relation where city_id in('-1') and dept_id in('-1') ");
				sql1.append("  and relation_type=:relation_type");
				sql1.append("  and camp_drv_id=:camp_drv_id");
				sql1.append("  and appr_flow_tpye=:appr_flow_tpye ");
				sql1.append("  order by city_id,dept_id desc");
				Map<String, Object> params1 = new HashMap<String, Object>();
				params1.put("relation_type", drvTypeID);
				params1.put("camp_drv_id", drvID);
				params1.put("appr_flow_tpye", approvalType);
				List<?> g_list = approvalDao.getObjectsBySQL(sql1.toString(), params1);
				if (g_list != null && g_list.size() > 0) {
					return (String) g_list.get(0);
				}
			}
		} else {
			result = "";
		}
		// 如果有查到审批流程，走默认的审批流程
		if (StringUtil.isEmpty(result)) {
			String sql = "select approve_flow_id from ap_approve_flow_def where approve_flow_name=:approve_flow_name";
			Map<String, Object> defaultParams = new HashMap<String, Object>();
			defaultParams.put("approve_flow_name", defaultFlowName);
			List<?> list = approvalDao.getObjectsBySQL(sql.toString(), defaultParams);
			if (list != null && list.size() > 0) {
				return (String) list.get(0);
			}
		}
		return result;
	}

	/**
	 * 
	 * isHasConfirmFlow:判断是有确认过程
	 * 
	 * @param userId
	 * @param drvTypeID
	 * @param drvID
	 * @return
	 * @throws Exception 
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#isHasConfirmFlow(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public boolean isHasConfirmFlow(String userId, String drvTypeID, String drvID) throws Exception {
		return this.isHasApprovalOrConfirmFlow(userId, drvTypeID, drvID, ApprovalCONST.FLOW_TYPE_CONFIRM);
	}

	/**
	 * 
	 * isHasApprovalFlow:判断是有审批过程
	 * 
	 * @param userId
	 * @param drvTypeID
	 * @param drvID
	 * @return
	 * @throws Exception 
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#isHasApprovalFlow(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public boolean isHasApprovalFlow(String userId, String drvTypeID, String drvID) throws Exception {

		return this.isHasApprovalOrConfirmFlow(userId, drvTypeID, drvID, ApprovalCONST.FLOW_TYPE_APPROVL);
	}

	public boolean isHasApprovalOrConfirmFlow(String userId, String drvTypeID, String drvID, String approvalType)
			throws Exception {
		boolean flag = false;
		if (StringUtil.isNotEmpty(userId) && StringUtil.isNotEmpty(drvTypeID) && StringUtil.isNotEmpty(drvID)
				&& StringUtil.isNotEmpty(approvalType)) {
			IUser user = userPrivilegeService.getUser(userId);
			StringBuffer sql = new StringBuffer();
			sql.append("select approve_flow_id from ap_dept_flow_relation where city_id in('").append(user.getCityid())
					.append("','-1') and dept_id in('").append(user.getDepartmentid()).append("','-1') ");
			sql.append("  and relation_type=:relation_type");
			sql.append("  and camp_drv_id=:camp_drv_id");
			sql.append("  and appr_flow_tpye=:appr_flow_tpye ");
			sql.append("  order by city_id,dept_id desc");
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("relation_type", drvTypeID);
			params.put("camp_drv_id", drvID);
			params.put("appr_flow_tpye", approvalType);

			List<?> list = approvalDao.getObjectsBySQL(sql.toString(), params);
			if (list != null && list.size() > 0) {
				flag = true;
			}
		}
		return flag;
	}

	/**
	 * 
	 * processOaApprove:通过OA审批
	 * 
	 * @param serverIp
	 * @param serverPort
	 * @param approvalFlowId
	 * @param approvalId
	 * @param status
	 * @param needApprovalUserid
	 * @param drvTypeID
	 * @param drvID
	 * @throws Exception
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#processOaApprove(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String)
	 */
	public void processOaApprove(String serverIp, String serverPort, String approvalFlowId, String approvalId,
			Integer status, String needApprovalUserid, String drvTypeID, String drvID) throws Exception {
		// TODO Auto-generated method stub
		throw new Exception("通过OA审批确认需要根据需求现场开发，目前流程暂未开通！");
	}

	/**
	 * 
	 * deleteApproverList:根据条件删除原有审批确认列表
	 * 
	 * @param approvalFlowId
	 * @param approvalId
	 * @param approve_userid
	 * @param approvalType
	 * @return
	 * @throws Exception 
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#deleteApproverList(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 */
	public int deleteApproverList(String approvalFlowId, String approvalId, String approve_userid, String approvalType)
			throws Exception {
		StringBuffer b = new StringBuffer();
		Map<String, Object> params = new HashMap<String, Object>();
		b.append(" delete from ap_approve_list where 1=1 and approval_id=:approval_id ");
		// b.append(" delete from ap_approve_list where 1=1 and approval_id=:approval_id and approve_type=:approve_type ");
		params.put("approval_id", approvalId);
		// params.put("approve_type", approvalType);

		if (StringUtil.isNotEmpty(approvalFlowId)) {
			b.append(" and approve_flow_id=:approve_flow_id");
			params.put("approve_flow_id", approvalFlowId);
		}
		if (StringUtil.isNotEmpty(approve_userid)) {
			b.append(" and approve_userid=:approve_userid");
			params.put("approve_userid", approve_userid);
		}
		if (StringUtil.isNotEmpty(approvalType)) {
			b.append(" and approve_type=:approve_type");
			params.put("approve_type", approvalType);
		}
		return approvalDao.executeBySQL(b.toString(), params);
	}

	/**
	 * 
	 * saveApproverListHis:备份原来审批历史
	 * @param approvalFlowId
	 * @param approvalId
	 * @param approve_userid
	 * @param approvalType
	 * @return 
	 * @return int
	 * @throws Exception 
	 */
	public int saveApproverListHis(String approvalFlowId, String approvalId, String approve_userid, String approvalType)
			throws Exception {
		StringBuffer b = new StringBuffer();
		Map<String, Object> params = new HashMap<String, Object>();
		b.append(" insert into ap_approve_list_his select * from ap_approve_list where 1=1 and approval_id=:approval_id ");
		// b.append(" delete from ap_approve_list where 1=1 and approval_id=:approval_id and approve_type=:approve_type ");
		params.put("approval_id", approvalId);
		// params.put("approve_type", approvalType);

		if (StringUtil.isNotEmpty(approvalFlowId)) {
			b.append(" and approve_flow_id=:approve_flow_id");
			params.put("approve_flow_id", approvalFlowId);
		}
		if (StringUtil.isNotEmpty(approve_userid)) {
			b.append(" and approve_userid=:approve_userid");
			params.put("approve_userid", approve_userid);
		}
		if (StringUtil.isNotEmpty(approvalType)) {
			b.append(" and approve_type=:approve_type");
			params.put("approve_type", approvalType);
		}
		return approvalDao.executeBySQL(b.toString(), params);
	}

	/**
	 * 
	 * saveApproverList:保存审批确认列表
	 * 
	 * @param approvalFlowId
	 * @param approvalId
	 * @param status
	 * @param approveUserId
	 * @param drvTypeID
	 * @param drvID
	 * @param approvalType
	 * @throws Exception 
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#saveApproverList(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 */
	public void saveApproverList(String approvalFlowId, String approvalId, Integer status, String needApproveUserid,
			String drvTypeID, String drvID, String approvalType) throws Exception {
		String approveUserId = null;
		ApproveLevelDef levelDef;
		ApApproveList campSegApprover;
		ApproveTriggerCondDef triggerCond;
		try {
			List<ApproveLevelDef> ApproveLevelDefList = approvalDao.getApprovalListByFlowId(approvalFlowId);
			if (ApproveLevelDefList != null && ApproveLevelDefList.size() > 0) {
				Iterator<ApproveLevelDef> levelIt = ApproveLevelDefList.iterator();
				Integer approveSeq = 1;
				Set<String> approverUserIdSet; // 本阶段审批人的id set，过滤触发条件产生的同一审批人。
				while (levelIt.hasNext()) {
					approveUserId = null;
					levelDef = levelIt.next();
					Integer approveObjType = levelDef.getApprove_obj_type().intValue();
					String deptId = null;
					int deptTopN;
					approverUserIdSet = new HashSet<String>();
					if (approveObjType == ApprovalCONST.MPM_APPROVE_OBJ_TYPE_SELF_DEPT) {
						IUser user = userPrivilegeService.getUser(needApproveUserid);
						if (user == null) {
							throw new Exception("找不到【" + needApproveUserid + "】用户对象！");
						}
						deptId = String.valueOf(user.getDepartmentid());
					} else if (approveObjType == ApprovalCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_DEPT) {
						deptId = levelDef.getApprove_obj_id().trim();
					} else if (approveObjType == ApprovalCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER) {
						approveUserId = levelDef.getApprove_obj_id().trim();
					} else if (approveObjType == ApprovalCONST.MPM_APPROVE_OBJ_TYPE_TOPN_DEPT) {
						deptTopN = Integer.parseInt(levelDef.getApprove_obj_id().trim());
						IUser user = userPrivilegeService.getUser(needApproveUserid);
						if (user == null) {
							throw new Exception("找不到【" + needApproveUserid + "】用户对象！");
						}
						deptId = String.valueOf(user.getDepartmentid());
						// 取当前分公司/部门的上N级分公司/部门编号
						deptId = getDeptTopNDeptId(deptId, deptTopN);
					}
					// 取审批部门对应设定的审批人
					if (approveUserId == null && deptId != null) {
						ApproveRelation relation = approvalDao.findByUserDeptId(deptId, null);
						if (relation != null) {
							approveUserId = relation.getApprove_userid();
						}
					}

					if (StringUtil.isEmpty(approveUserId)) {
						log.error("审批第【{}】级找不到审批人，略过……", levelDef.getApprove_level());
						continue;
					}

					campSegApprover = new ApApproveList();

					campSegApprover.setApproval_id(approvalId);
					campSegApprover.setApprove_flow_id(approvalFlowId);
					campSegApprover.setApprove_seq(approveSeq);
					campSegApprover.setApprove_level(levelDef.getApprove_level());
					campSegApprover.setApprove_userid(approveUserId);
					campSegApprover.setApprove_token(ApprovalCONST.APPROVE_TOKEN_NOT_HOLD);// 默认是不持有令牌
					campSegApprover.setApprove_type(approvalType);
					campSegApprover.setUpdate_time(new java.util.Date());
					campSegApprover.setCreate_time(new java.util.Date());
					campSegApprover.setApprove_flag(ApprovalCONST.APPROVE_FLAG_FALSE);
					campSegApprover.setAuth_flag(0);
					approvalDao.saveApApproveList(campSegApprover);

					approverUserIdSet.add(approveUserId); // 保存审批list后，将对应审批人加入set；

					approveSeq++;

					// 开始 取审批级别中定义的触发条件对应的审批人
					/*
					 * List triggerCondList =
					 * approvalDao.getApproveTriggerCondDefByFlowAndLevel
					 * (approvalFlowId,levelDef.getApprove_level()); Iterator it =
					 * triggerCondList.iterator(); //
					 * approve_level,approve_flow_id,approve_trigger_cond_id
					 * ,cond_indi_id, //
					 * cond_operator,cond_indi_value,approve_obj_type
					 * ,approve_obj_id,approve_trigger_cond_pri while (it.hasNext())
					 * { approveUserId = null; triggerCond = (ApproveTriggerCondDef)
					 * it.next(); approveUserId =
					 * processApproveTriggerCondDef(triggerCond, approvalId,
					 * needApproveUserid); if (StringUtil.isEmpty(approveUserId)) {
					 * log.error("审批第【{}】级的第【{}】个触发条件找不到审批人，略过……",
					 * levelDef.getApprove_level(),
					 * triggerCond.getApprove_trigger_cond_id()); continue; } if
					 * (approverUserIdSet.contains(approveUserId)) {
					 * log.debug("the user:" + approveUserId +
					 * " has been already on this approval level. "); continue; }
					 * 
					 * campSegApprover = new ApApproveList();
					 * 
					 * campSegApprover.setApprove_flow_id(approvalFlowId);
					 * campSegApprover.setApprove_level(levelDef
					 * .getApprove_level());
					 * campSegApprover.setApproval_id(approvalId);
					 * campSegApprover.setApprove_seq(approveSeq);
					 * campSegApprover.setApprove_userid(approveUserId);
					 * campSegApprover
					 * .setApprove_token(ApprovalCONST.MPM_APPROVE_TOKEN_NOT_HOLD);
					 * campSegApprover.setApprove_type(approvalType);
					 * 
					 * approvalDao.saveApApproveList(campSegApprover);
					 * //保存审批list后，将对应审批人加入set approverUserIdSet.add(approveUserId);
					 * // 结束 取审批级别中定义的触发条件对应的审批人 approveSeq++; }
					 */
				}
			} else {
				log.error("根据流程ID没有查询到审批确认级别信息:approvalFlowId={}", approvalFlowId);
			}
		} catch (Exception e) {
			log.error("保存审批确认需要的审批人列表信息异常{}", e);
			throw new Exception(" 保存审批确认需要的审批人列表信息失败！");
		}

	}

	/**
	 * 取当前分公司/部门的上N级分公司/部门编号
	 *
	 * @param currDeptId
	 * @return
	 * @throws Exception
	 */
	public String getDeptTopNDeptId(String currDeptId, int topN) throws Exception {
		IUserCompany dept = null;
		int index = 0;
		String deptId = null;
		do {
			dept = userPrivilegeService.getUserCompanyById(currDeptId);
			if (dept != null && index < topN) {
				currDeptId = String.valueOf(dept.getParentid());
				index++;
			} else {
				deptId = currDeptId;
				break;
			}
		} while (dept != null && index <= topN);
		return deptId;
	}

	/**
	 * 
	 * processApproveTriggerCondDef:审批流程触发条件，目前是空实现，后根据实际情况修改
	 * 
	 * @param cond
	 * @param approvalId
	 * @param needApproveUserid
	 * @return
	 * @throws Exception
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#processApproveTriggerCondDef(com.ai.bdx.pop.bean.ApproveTriggerCondDef,
	 *      java.lang.String, java.lang.String)
	 */
	public String processApproveTriggerCondDef(ApproveTriggerCondDef cond, String approvalId, String needApproveUserid)
			throws Exception {

		String approveUserId = null;
		try {/*
				* 
				* double totalCost = 0; String condId = cond.getCond_indi_id(); if
				* (ApprovalCONST.CUSTGROUP_NUM_COND_ID.equals(condId)) { //
				* 客户群数目判断流转； campsegService = (IMpmCampSegInfoService)
				* SystemServiceLocator
				* .getInstance().getService(MpmCONST.CAMPAIGN_SEG_INFO_SERVICE);
				* List<MtlCampsegCiCustgroup> group =
				* campsegService.getCiCustGroupListByCampSeg(campsegId); if (group
				* != null) { for (int i = 0; i < group.size(); i++) {
				* MtlCampsegCiCustgroup tmp = group.get(i); int tmpNum =
				* tmp.getCustgroupNumber() == null ? 0 : tmp.getCustgroupNumber();
				* totalCost += tmpNum; } } } else if
				* (MpmCONST.NEED_HOD_APPROVE.equals(condId) ||
				* MpmCONST.NEED_CCO_APPROVE.equals(condId)) { // HOD CCO
				* IMpmCampBaseInfoService campBaseService =
				* (IMpmCampBaseInfoService) SystemServiceLocator
				* .getInstance().getService( MpmCONST.CAMPAIGN_BASE_INFO_SERVICE);
				* MtlCampBaseinfo mcbi = campBaseService
				* .getCampaignBaseInfo(campsegId); totalCost =
				* mcbi.getHodCcoFlag(); } else { // 成本判断流转； totalCost =
				* getObjCostValue(campsegId,
				* Integer.parseInt(cond.getId().getCondIndiId())); }
				*/

			// 得到该触发条件用到的成本类型；
			// List costList =
			// mpmResListSvc.getAllSubCostList(cond.getId().getCondIndiId());
			// //累计用到的成本对应的成本值；
			// for(Iterator it = costList.iterator(); it.hasNext(); ) {
			// MtlCostList cost = (MtlCostList) it.next();
			// int costCode = cost.getCostCode().intValue();
			// totalCost += getObjCostValue(campsegId, costCode);
			// }

			/*
			 * Map costMap =
			 * this.mpmCampsegCostService.getCampsegCostList(campsegId);
			 * costMap.remove("resTypeAndNameMapper"); Iterator costIt =
			 * costMap.values().iterator(); String[] costArr; List
			 * resTypeCostList; double tmpDou; Iterator countIt; //计算累计成本 while
			 * (costIt.hasNext()) { resTypeCostList = (List) costIt.next();
			 * //每种成本类型的成本累计 countIt = resTypeCostList.iterator(); while
			 * (countIt.hasNext()) { costArr = (String[]) countIt.next(); tmpDou
			 * = Double.parseDouble(costArr[4]); totalCost += tmpDou; } }
			 */

			/*
			 * double condValue = Double.parseDouble(cond.getCondIndiValue());
			 * String condOperator = cond.getCondOperator(); //
			 * log.debug("******1="
			 * +totalCost+",2="+condOperator+",3="+condValue); boolean match =
			 * MpmUtil.matchApproveTriggerCondValue(totalCost, condOperator,
			 * condValue); if (match) { short approveObjType =
			 * cond.getApproveObjType().shortValue(); String deptId = null; int
			 * deptTopN; if (approveObjType ==
			 * MpmCONST.MPM_APPROVE_OBJ_TYPE_SELF_DEPT) { IUser user =
			 * mpmUserPrivilegeService .getUser(needApproveUserid); if (user ==
			 * null) { throw new MpmException(
			 * MpmLocaleUtil.getMessage("mcd.java.zbd") + needApproveUserid +
			 * MpmLocaleUtil .getMessage("mcd.java.yhdx")); } deptId =
			 * String.valueOf(user.getDepartmentid()); } else if (approveObjType
			 * == MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_DEPT) { deptId =
			 * cond.getApproveObjId().trim(); } else if (approveObjType ==
			 * MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER) { approveUserId =
			 * cond.getApproveObjId().trim(); } else if (approveObjType ==
			 * MpmCONST.MPM_APPROVE_OBJ_TYPE_TOPN_DEPT) { deptTopN =
			 * Integer.parseInt(cond.getApproveObjId().trim()); IUser user =
			 * mpmUserPrivilegeService .getUser(needApproveUserid); if (user ==
			 * null) { throw new MpmException(
			 * MpmLocaleUtil.getMessage("mcd.java.zbd") + needApproveUserid +
			 * MpmLocaleUtil .getMessage("mcd.java.yhdx")); } deptId =
			 * String.valueOf(user.getDepartmentid()); // 取当前分公司/部门的上N级分公司/部门编号
			 * deptId = MpmUtil.getDeptTopNDeptId(deptId, deptTopN); } //
			 * 取审批部门对应设定的审批人 if (approveUserId == null && deptId != null) {
			 * MtlApproveRelation relation = mpmApproveRelationDao
			 * .findByUserid(deptId, null); if (relation != null) {
			 * approveUserId = relation.getId().getApproveUserid(); } } }
			 */
		} catch (Exception e) {
			log.error("", e);
			throw new Exception("审批确认触发条件处理失败！");
		}
		return approveUserId;
	}

	/**
	 * 
	 * updateApprovalToken:
	 * @param approvalId
	 * @param approvalType
	 * @param approvalFlag
	 * @param userId
	 * @return
	 * @throws Exception 
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#updateApprovalToken(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public String updateApprovalToken(String approvalId, String approvalType, String approvalFlag, String userId)
			throws Exception {
		// 把当前id的所有持有令牌重置
		List<?> apList = getApprovalProcess(approvalId, approvalType);
		Integer currentApprovalSeq = null;
		String app_flow_id = null;
		Integer approve_level = null;
		String approve_userId = null;
		ApApproveList currentApproval = null;
		//处理当前审批人信息
		if (apList != null && apList.size() > 0) {
			for (int i = 0; i < apList.size(); i++) {
				ApApproveList ap = (ApApproveList) apList.get(i);
				//处理当前审批人,审批人是当前登录用户，且持有令牌
				if (ap != null && ap.getApprove_userid().equals(userId)
						&& ap.getApprove_token().equals(ApprovalCONST.APPROVE_TOKEN_HOLD)) {
					currentApproval = ap;
					// 更新持有令牌,把当前令牌修改无效
					currentApprovalSeq = ap.getApprove_seq();
					app_flow_id = ap.getApprove_flow_id();
					approve_level = ap.getApprove_level();
					approve_userId = ap.getApprove_userid();
					int rtv1 = approvalDao.updateApprovalFlag(approvalId, approvalType, approvalFlag,
							currentApprovalSeq, app_flow_id, approve_level, approve_userId);// 修改审批确认标示

					int rtv = approvalDao.updateApprovalToken(approvalId, approvalType,
							ApprovalCONST.APPROVE_TOKEN_NOT_HOLD, currentApprovalSeq, app_flow_id, approve_level,
							approve_userId);// 把当前审批令牌置为无效

					log.debug("把当前持有审批令牌的人员所持令牌失效,approvalId={},approvalType={},approvalSeq={},approve_level={}",
							approvalId, approvalType, ap.getApprove_seq(), ap.getApprove_level());
				}
			}
		}
		//判断当前审批人同级是否还有审批人，如果有继续等待同级审批人审批，如果没有则把审批令牌传递到下级审批人
		List<?> list = approvalDao.getSampleLevelApproverByCurrentApproval(currentApproval);
		if (list.size() > 0) {//同级别还有未审批过的审批人信息
			log.error("等待同级审批人完成审批：approvalId={},level={}", currentApproval.getApproval_id(),
					currentApproval.getApprove_level());
			return ApprovalCONST.APPROVE_LEVEL_HAS;
		} else {//同级别已经没有未审批过的审批人信息， 把令牌传递到下级所有审批人
			return updateNextApprovalToken(approvalId, approvalType, ApprovalCONST.APPROVE_TOKEN_HOLD, currentApproval);
		}
	}

	/**
	 * 把持有令牌传递给下一批审批确认人
	 * 
	 * @param approvalId
	 * @param approvalType
	 * @param approvalToken
	 * @param approvalSeq
	 * @return String 1 ：同级审批人还有未审批的 2：同级审批人全部审批过,把令牌传递下级审批 3：当前流程结束即不存在下级审批人了
	 * @throws Exception
	 */
	public String updateNextApprovalToken(String approvalId, String approvalType, Integer approvalToken,
			ApApproveList currentApproval) throws Exception {
		String flag = ApprovalCONST.APPROVE_LEVEL_OVER;
		List<ApApproveList> nextApprovals = approvalDao.getNextApprovalProcess(currentApproval);// 寻找下个级别的审批人
		if (nextApprovals != null && nextApprovals.size() > 0) {// 当找到下级审批人，把令牌传递下级审批人
			//让下级所有审批人持有审批令牌
			for (int i = 0; i < nextApprovals.size(); i++) {
				ApApproveList nextApproval = nextApprovals.get(i);
				int rtv = approvalDao.updateApprovalToken(approvalId, approvalType, approvalToken,
						nextApproval.getApprove_seq(), nextApproval.getApprove_flow_id(),
						nextApproval.getApprove_level(), nextApproval.getApprove_userid());
				log.info(
						"更新持有令牌，参数：approvalId={},approvalType={},approvalToken={},approve_seq={},approve_flow_id={},approve_level={},approve_userid={}",
						approvalId, approvalType, approvalToken, nextApproval.getApprove_seq(),
						nextApproval.getApprove_flow_id(), nextApproval.getApprove_level(),
						nextApproval.getApprove_userid());
			}
			/*if (rtv <= 0) {// 当没找到下级审批确认人，继续向下找，直至结束
				this.updateNextApprovalToken(approvalId, approvalType,approvalToken, nextApproval);
			}*/
			flag = ApprovalCONST.APPROVE_LEVEL_NEXTHAS;
		} else {//没找到下级审批人
			flag = ApprovalCONST.APPROVE_LEVEL_OVER;
		}
		return flag;
	}

	/**
	 * 把审批状态修改为初始状态
	 * 
	 * @param approvalId
	 * @param status
	 * @param needApprovalUserid
	 * @param drvTypeID
	 * @param drvID
	 * @throws Exception
	 */
	public int updateApprovalNotPass(String approvalId, String approvalType, String needApprovalUserid,
			String drvTypeID, String drvID, String advice) throws Exception {
		if (StringUtil.isNotEmpty(approvalId)) {
			// 更新意见原因等
			List<ApApproveList> list = this.getCurrentApprovalProcess(approvalId, approvalType,
					ApprovalCONST.APPROVE_TOKEN_HOLD.toString());
			if (list != null && list.size() > 0) {
				Iterator<ApApproveList> it = list.iterator();
				while (it.hasNext()) {
					ApApproveList ap = it.next();
					if (ap.getApprove_userid().equals(needApprovalUserid)) {
						this.updateConfirmAdvice(ap.getApproval_id(), ap.getApprove_flow_id(), ap.getApprove_seq(),
								ap.getApprove_level(), ap.getApprove_userid(), ap.getApprove_type(), advice);
					}
				}
			}
			// 把持有令牌的标示全部置为无效
			StringBuffer sql = new StringBuffer(
					"update ap_approve_list a set a.approve_token=:approve_token where a.approval_id=:approval_id");
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("approve_token", ApprovalCONST.APPROVE_TOKEN_NOT_HOLD);
			params.put("approval_id", approvalId);
			int rtv = approvalDao.executeBySQL(sql.toString(), params);

			// 判断流程模式，根据流程模式把审批令牌赋值给流程中第一个人
			String flowModelID = getApproveDrvType(drvTypeID, drvID);
			if (ApprovalCONST.FLOW_MODEL_ONE.equals(flowModelID)) {// 基本信息
				// 更新策略成待派单状态
			} else if (ApprovalCONST.FLOW_MODEL_TWO.equals(flowModelID)
					|| ApprovalCONST.FLOW_MODEL_FOUR.equals(flowModelID)) {// 基本信息审批   基本信息 审批 确认
				updateFirstApproveOrConfirmUserToken(approvalId, ApprovalCONST.FLOW_TYPE_APPROVL);
			} else if (ApprovalCONST.FLOW_MODEL_THREE.equals(flowModelID)) {// 基本信息 确认
				updateFirstApproveOrConfirmUserToken(approvalId, ApprovalCONST.FLOW_TYPE_CONFIRM);
			} else {
				log.error("策略{}没有在驱动类型配置中配置对应配置流程模式", approvalId);
			}
			return rtv;
		}
		return 0;
	}

	public List<ApApproveList> getApprovalProcess(String approvalId, String approvalType) throws Exception {
		return approvalDao.getApprovalProcess(approvalId, approvalType, null);
	}

	public List<ApApproveList> getCurrentApprovalProcess(String approvalId, String approvalType, String approvalToken)
			throws Exception {
		return approvalDao.getApprovalProcess(approvalId, approvalType, approvalToken);
	}

	public List<ApApproveList> getApprovalProcessDesc(String approvalId, String approvalType) throws Exception {

		List<ApApproveList> list = approvalDao.getApprovalProcess(approvalId, approvalType, null);
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				ApApproveList a = list.get(i);
				a.setApprove_flag_desc(ApprovalCONST.getApproveFlagDesc(a.getApprove_type(), a.getApprove_flag()));
				a.setApprove_level_desc("第" + NumberUtil.numberToZH(a.getApprove_level(), false) + "级"
						+ ApprovalCONST.getFlowTypeDesc(a.getApprove_type()));
				a.setApprove_type_desc(ApprovalCONST.getFlowTypeDesc(a.getApprove_type()));
				IUser user = userPrivilegeService.getUser(a.getApprove_userid());
				a.setApprove_user(user.getUsername());
			}
		}
		return list;
	}

	public List<ApApproveList> getApprovalProcess(String approvalId) throws Exception {
		return approvalDao.getApprovalProcess(approvalId, null, null);
	}

	@Override
	public String getApproveDrvType(String drvTypeID, String drvID) throws Exception {
		return approvalDao.getApproveDrvType(drvTypeID, drvID);
	}

	/**
	 * 
	 * updateFirstApproveOrConfirmUserToken:
	 * @param approvalId
	 * @param approvlType
	 * @throws Exception 
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#updateFirstApproveOrConfirmUserToken(java.lang.String, java.lang.String)
	 */
	public void updateFirstApproveOrConfirmUserToken(String approvalId, String approvlType) throws Exception {
		// 查询出第一个(批)审批人
		List<ApApproveList> aps = approvalDao.getFirstApprovalOrConfimUser(approvalId, approvlType);
		if (aps != null && aps.size() > 0) {
			for (int i = 0; i < aps.size(); i++) {
				ApApproveList ap = aps.get(i);
				String sql = "update ap_approve_list a set a.approve_token=:approve_token  where a.approval_id=:approval_id"
						+ " and a.approve_flow_id=:approve_flow_id and  a.approve_seq=:approve_seq and a.approve_level=:approve_level and"
						+ " a.approve_type=:approve_type and a.approve_userid=:approve_userid";
				Map<String, Object> p = new HashMap<String, Object>();
				p.put("approve_token", ApprovalCONST.APPROVE_TOKEN_HOLD);
				p.put("approval_id", ap.getApproval_id());
				p.put("approve_flow_id", ap.getApprove_flow_id());
				p.put("approve_seq", ap.getApprove_seq());
				p.put("approve_level", ap.getApprove_level());
				p.put("approve_type", ap.getApprove_type());
				p.put("approve_userid", ap.getApprove_userid());
				int rtv = approvalDao.executeBySQL(sql, p);
			}

		}
	}

	@Override
	/*
	 * public int updateFirstConfirmUserToken(String approvalId) { //查询出第一确认人
	 * ApApproveList
	 * ap=approvalDao.getFirstApprovalOrConfimUser(approvalId,ApprovalCONST
	 * .FLOW_TYPE_CONFIRM); String sql=
	 * "update ap_approve_list a set a.approve_token=:approve_token  where a.approval_id=:approval_id"
	 * +
	 * " and a.approve_flow_id=:approve_flow_id and  a.approve_seq=:approve_seq and a.approve_level=:approve_level and"
	 * + " a.approve_type=:approve_type and a.approve_userid=:approve_userid";
	 * Map<String,Object> p=new HashMap<String,Object>(); p.put("approve_token",
	 * ApprovalCONST.APPROVE_TOKEN_HOLD); p.put("approval_id",
	 * ap.getApproval_id()); p.put("approve_flow_id", ap.getApprove_flow_id());
	 * p.put("approve_seq", ap.getApprove_seq()); p.put("approve_level",
	 * ap.getApprove_level()); p.put("approve_type", ap.getApprove_type());
	 * p.put("approve_userid", ap.getApprove_userid());
	 * 
	 * int rtv=approvalDao.executeBySQL(sql, p); return rtv; }
	 */
	public int updateConfirmAdvice(String approvalId, String app_flow_id, Integer approvalSeq, Integer approve_level,
			String approve_userId, String approvalType, String approve_advice) throws Exception {
		String sql = "update ap_approve_list a set a.approve_advice=:approve_advice  where a.approval_id=:approval_id"
				+ " and a.approve_flow_id=:approve_flow_id and  a.approve_seq=:approve_seq and a.approve_level=:approve_level and"
				+ " a.approve_type=:approve_type and a.approve_userid=:approve_userid";
		Map<String, Object> p = new HashMap<String, Object>();
		p.put("approve_advice", approve_advice);
		p.put("approval_id", approvalId);
		p.put("approve_flow_id", app_flow_id);
		p.put("approve_seq", approvalSeq);
		p.put("approve_level", approve_level);
		p.put("approve_type", approvalType);
		p.put("approve_userid", approve_userId);
		int rtv = approvalDao.executeBySQL(sql, p);
		return 0;
	}

	public void tranOtherApproveUser(String approvalId, String app_flow_id, Integer approvalSeq, Integer approve_level,
			String approve_userId, String approvalType, String approve_advice) {
		// TODO Auto-generated method stub

	}

	public void doInitApproval(String approvalId, Integer status, String needApprovalUserid, String drvTypeID,
			String drvID) throws Exception {
		String approvalFlowId = null;
		// 判断流程模式，根据流程模式把审批令牌赋值给流程中第一个人
		String flowModelID = getApproveDrvType(drvTypeID, drvID);
		if (ApprovalCONST.FLOW_MODEL_ONE.equals(flowModelID)) {// 基本信息
			// 更新策略成待派单状态
		} else if (ApprovalCONST.FLOW_MODEL_TWO.equals(flowModelID)) {// 基本信息审批
			// 添加审批过程
			approvalFlowId = null;
			approvalFlowId = getApprovalFlowIDByDeptFlowRelation(needApprovalUserid, drvTypeID, drvID,
					ApprovalCONST.FLOW_TYPE_APPROVL);
			if (StringUtil.isNotEmpty(approvalFlowId)) {
				if (approvalFlowId.equals(ApprovalCONST.APPROVE_FLOW_ID_BY_OA)) {// 通过OA审批活动
					processOaApprove(null, null, approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID,
							drvID);
				} else {// 通过营销管理系统内部的审批流程来审批活动
					saveApproverList(approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID,
							ApprovalCONST.FLOW_TYPE_APPROVL);
				}
			} else {
				log.error("策略{}流程模式是基本信息审批但没有配置对应的审批流程", approvalId);
				//add by jinl 20150513 抛出异常信息 防止页面空指针异常
				throw new Exception("流程模式是基本信息审批但没有配置对应的审批流程");
			}
			updateFirstApproveOrConfirmUserToken(approvalId, ApprovalCONST.FLOW_TYPE_APPROVL);
		} else if (ApprovalCONST.FLOW_MODEL_THREE.equals(flowModelID)) {// 基本信息
																		// 确认
			// 添加确认过程
			approvalFlowId = null;
			approvalFlowId = getApprovalFlowIDByDeptFlowRelation(needApprovalUserid, drvTypeID, drvID,
					ApprovalCONST.FLOW_TYPE_CONFIRM);
			if (StringUtil.isNotEmpty(approvalFlowId)) {
				if (approvalFlowId.equals(ApprovalCONST.APPROVE_FLOW_ID_BY_OA)) {// 通过OA确认活动
					processOaApprove(null, null, approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID,
							drvID);
				} else {// 通过营销管理系统内部的审批流程来确认活动
					saveApproverList(approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID,
							ApprovalCONST.FLOW_TYPE_CONFIRM);
				}
			} else {
				log.error("策略{}，流程模式是基本信息 确认,但没有配置对应的确认流程", approvalId);
				//add by jinl 20150513 抛出异常信息 防止页面空指针异常
				throw new Exception("流程模式是基本信息 确认,但没有配置对应的确认流程");
			}
			updateFirstApproveOrConfirmUserToken(approvalId, ApprovalCONST.FLOW_TYPE_CONFIRM);
		} else if (ApprovalCONST.FLOW_MODEL_FOUR.equals(flowModelID)) {// 基本信息
																		// 审批 确认
			approvalFlowId = null;
			// 添加审批过程
			approvalFlowId = getApprovalFlowIDByDeptFlowRelation(needApprovalUserid, drvTypeID, drvID,
					ApprovalCONST.FLOW_TYPE_APPROVL);
			if (StringUtil.isNotEmpty(approvalFlowId)) {
				if (approvalFlowId.equals(ApprovalCONST.APPROVE_FLOW_ID_BY_OA)) {// 通过OA审批活动
					processOaApprove(null, null, approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID,
							drvID);
				} else {// 通过营销管理系统内部的审批流程来审批活动
					saveApproverList(approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID,
							ApprovalCONST.FLOW_TYPE_APPROVL);
				}
			} else {
				log.error("策略{}流程模式是基本信息 审批 确认,但没有配置对应的审批流程", approvalId);
				//add by jinl 20150513 抛出异常信息 防止页面空指针异常
				throw new Exception("流程模式是基本信息 审批 确认,但没有配置对应的审批流程");
			}

			// 添加确认过程
			approvalFlowId = null;
			approvalFlowId = getApprovalFlowIDByDeptFlowRelation(needApprovalUserid, drvTypeID, drvID,
					ApprovalCONST.FLOW_TYPE_CONFIRM);
			if (StringUtil.isNotEmpty(approvalFlowId)) {
				if (approvalFlowId.equals(ApprovalCONST.APPROVE_FLOW_ID_BY_OA)) {// 通过OA确认活动
					processOaApprove(null, null, approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID,
							drvID);
				} else {// 通过营销管理系统内部的审批流程来确认活动
					saveApproverList(approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID,
							ApprovalCONST.FLOW_TYPE_CONFIRM);
				}
			} else {
				log.error("策略{}流程模式是基本信息 审批 确认,但没有配置对应的确认流程", approvalId);
				//add by jinl 20150513 抛出异常信息 防止页面空指针异常
				throw new Exception("流程模式是基本信息 审批 确认,但没有配置对应的确认流程");
			}
			updateFirstApproveOrConfirmUserToken(approvalId, ApprovalCONST.FLOW_TYPE_APPROVL);
		} else {
			log.error("策略{}没有在驱动类型配置中配置对应配置流程模式", approvalId);
		}

	}

	/**
	*
	*/
	public void doApproval(String approvalId, Integer status, String needApprovalUserid, String drvTypeID, String drvID)
			throws Exception {
		//先备份原来审批过程
		int rtv1 = saveApproverListHis(null, approvalId, null, null);
		// 先删除,把传入id相关的原来所有审批确认过程，全部删除掉
		int rtv = deleteApproverList(null, approvalId, null, null);
		log.debug("删除{}审批确认过程，删除{}条记录", approvalId, rtv);
		this.doInitApproval(approvalId, status, needApprovalUserid, drvTypeID, drvID);
	}

	public List<?> getApprovalIdByUser(String userId, String approvalType) throws Exception {
		String sql = "select a.approval_id from ap_approve_list a  where  a.approve_token =:approve_token and a.approve_userid=:approve_userid";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("approve_token", ApprovalCONST.APPROVE_TOKEN_HOLD);
		params.put("approve_userid", userId);
		if (StringUtil.isNotEmpty(approvalType)) {
			sql += " and a.approve_type=:approve_type";
			params.put("approve_type", approvalType);
		}
		return approvalDao.getObjectsBySQL(sql.toString(), params);
	}

	public List<ApApproveList> getNextApprovalProcess(ApApproveList ap) throws Exception {
		return approvalDao.getNextApprovalProcess(ap);
	}

	/**
	 * 
	 * tranOtherUser:审批转发到其他人
	 * 
	 * @param approvalId
	 *            要转发的对象ID
	 * @param tranUserID
	 *            转发到的用户ID
	 * @return
	 * @throws Exception
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#saveTranOtherUser(java.lang.String,
	 *      java.lang.String)
	 */
	public int saveTranOtherUser(String approvalId, String tranUserID) throws Exception {
		// 步骤描述：
		// 找到当前审批人，并把当前审批之后的所有审批人序号加+1
		// 设置新转发进来的审批人，然后把审批人和审批序号设置成当前审批人和序号+1
		String approveUserId = tranUserID;
		if (StringUtil.isNotEmpty(tranUserID) && StringUtil.isNotEmpty(approvalId)) {
			// IUser user = userPrivilegeService.getUser(approveUserId);
			// String deptId = String.valueOf(user.getDepartmentid());
			// 找到当前审批人
			List<ApApproveList> apList = this.getCurrentApprovalProcess(approvalId, ApprovalCONST.FLOW_TYPE_APPROVL,
					ApprovalCONST.APPROVE_TOKEN_HOLD.toString());
			if (apList != null && apList.size() > 0) {
				ApApproveList a = apList.get(0);
				// 当前审批人之后的审批序号+1
				String sql = "update ap_approve_list  a set a.approve_seq=a.approve_seq+1 where a.approval_id=:approval_id and a.approve_flow_id=:approve_flow_id and a.approve_type=:approve_type and a.approve_seq>:approve_seq";
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("approval_id", a.getApproval_id());
				params.put("approve_flow_id", a.getApprove_flow_id());
				params.put("approve_type", a.getApprove_type());
				params.put("approve_seq", a.getApprove_seq());
				approvalDao.executeBySQL(sql, params);
				// 插入转发的审批人
				ApApproveList campSegApprover = new ApApproveList();
				campSegApprover.setApproval_id(approvalId);
				campSegApprover.setApprove_flow_id(a.getApprove_flow_id());
				campSegApprover.setApprove_seq(a.getApprove_seq() + 1);
				campSegApprover.setApprove_level(a.getApprove_level());
				campSegApprover.setApprove_userid(approveUserId);
				campSegApprover.setApprove_token(ApprovalCONST.APPROVE_TOKEN_NOT_HOLD);// 默认是不持有令牌
				campSegApprover.setApprove_type(a.getApprove_type());
				campSegApprover.setUpdate_time(new java.util.Date());
				campSegApprover.setApprove_flag(ApprovalCONST.APPROVE_FLAG_FALSE);
				campSegApprover.setAuth_flag(1);// 0 是默认流程 1是转发审批用户
				int rtv = approvalDao.saveApApproveList(campSegApprover);
			}
		}

		return 0;
	}

	/**
	 * 
	 * getApprovalTypeProcess:
	 * 
	 * @param approvalId
	 * @return null没有审批确认过程，其他有审批确认过程List<Map<>>
	 * @throws Exception
	 * @see com.ai.bdx.IApprovalService.service.ApprovalService#getApprovalTypeProcess(java.lang.String)
	 */
	public TreeMap<String, String> getApprovalTypeProcess(String approvalId) throws Exception {
		if (StringUtil.isNotEmpty(approvalId)) {
			String sql = "select distinct a.approve_type from ap_approve_list a where a.approval_id=:approval_id order by a.approve_type";
			HashMap<String, Object> p = new HashMap<String, Object>();
			p.put("approval_id", approvalId);
			List<?> list = approvalDao.getObjectsBySQL(sql, p);
			if (list != null && list.size() > 0) {
				TreeMap<String, String> ret = new TreeMap<String, String>();
				for (Object str : list) {
					ret.put(str.toString(), ApprovalCONST.getFlowTypeDesc(str.toString()));
				}
				return ret;
			} else {
				return null;
			}
		}
		return null;
	}

	public List<String> getCurrentApproversByApprovalID(String approvalID) throws Exception {
		return approvalDao.getCurrentApproversByApprovalID(approvalID);
	}

}

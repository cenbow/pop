/*      */ package com.ai.bdx.frame.approval.service.impl;
/*      */ 
/*      */ import com.ai.bdx.frame.approval.bean.ApApproveList;
/*      */ import com.ai.bdx.frame.approval.bean.ApproveLevelDef;
/*      */ import com.ai.bdx.frame.approval.bean.ApproveRelation;
/*      */ import com.ai.bdx.frame.approval.bean.ApproveTriggerCondDef;
/*      */ import com.ai.bdx.frame.approval.dao.ApprovalDao;
/*      */ import com.ai.bdx.frame.approval.service.IApprovalService;
/*      */ import com.ai.bdx.frame.approval.util.ApprovalCONST;
/*      */ import com.ai.bdx.frame.approval.util.NumberUtil;
/*      */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*      */ import com.asiainfo.biframe.privilege.IUser;
/*      */ import com.asiainfo.biframe.privilege.IUserCompany;
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import org.apache.logging.log4j.LogManager;
/*      */ import org.apache.logging.log4j.Logger;
/*      */ 
/*      */ public class ApprovalServiceImpl
/*      */   implements IApprovalService
/*      */ {
/*   29 */   private static Logger log = LogManager.getLogger();
/*      */   private ApprovalDao approvalDao;
/*      */   private IUserPrivilegeCommonService userPrivilegeService;
/*      */ 
/*      */   public ApprovalDao getApprovalDao()
/*      */   {
/*   34 */     return this.approvalDao;
/*      */   }
/*      */ 
/*      */   public void setApprovalDao(ApprovalDao approvalDao) {
/*   38 */     this.approvalDao = approvalDao;
/*      */   }
/*      */ 
/*      */   public IUserPrivilegeCommonService getUserPrivilegeService() {
/*   42 */     return this.userPrivilegeService;
/*      */   }
/*      */ 
/*      */   public void setUserPrivilegeService(IUserPrivilegeCommonService userPrivilegeCommonService) {
/*   46 */     this.userPrivilegeService = userPrivilegeCommonService;
/*      */   }
/*      */ 
/*      */   public String getApprovalFlowIDByFirstApprovalUser(String firstUserId, String approvalType)
/*      */   {
/*   61 */     return null;
/*      */   }
/*      */ 
/*      */   public String getApprovalFlowIDByDeptFlowRelation(String userId, String drvTypeID, String drvID, String approvalType)
/*      */     throws Exception
/*      */   {
/*   79 */     String result = "";
/*   80 */     String defaultFlowName = Configure.getInstance().getProperty("DEFAULT_APPROVALFLOW_NAME") == null ? "default1" : Configure.getInstance().getProperty("DEFAULT_APPROVALFLOW_NAME");
/*      */ 
/*   82 */     log.debug("get default config default approval flow name is {}", new Object[] { defaultFlowName });
/*   83 */     if ((StringUtil.isNotEmpty(userId)) && (StringUtil.isNotEmpty(drvTypeID)) && (StringUtil.isNotEmpty(drvID)) && (StringUtil.isNotEmpty(approvalType)))
/*      */     {
/*   85 */       IUser user = this.userPrivilegeService.getUser(userId);
/*      */ 
/*   88 */       StringBuffer sql = new StringBuffer();
/*   89 */       sql.append("select approve_flow_id from ap_dept_flow_relation where city_id in('").append(user.getCityid()).append("') and dept_id in('").append(user.getDepartmentid()).append("') ");
/*      */ 
/*   91 */       sql.append("  and relation_type=:relation_type");
/*   92 */       sql.append("  and camp_drv_id=:camp_drv_id");
/*   93 */       sql.append("  and appr_flow_tpye=:appr_flow_tpye ");
/*   94 */       sql.append("  order by city_id,dept_id desc");
/*   95 */       Map params = new HashMap();
/*   96 */       params.put("relation_type", drvTypeID);
/*   97 */       params.put("camp_drv_id", drvID);
/*   98 */       params.put("appr_flow_tpye", approvalType);
/*   99 */       List list = this.approvalDao.getObjectsBySQL(sql.toString(), params);
/*  100 */       if ((list != null) && (list.size() > 0)) {
/*  101 */         return (String)list.get(0);
/*      */       }
/*  103 */       StringBuffer sql1 = new StringBuffer();
/*  104 */       sql1.append("select approve_flow_id from ap_dept_flow_relation where city_id in('-1') and dept_id in('-1') ");
/*  105 */       sql1.append("  and relation_type=:relation_type");
/*  106 */       sql1.append("  and camp_drv_id=:camp_drv_id");
/*  107 */       sql1.append("  and appr_flow_tpye=:appr_flow_tpye ");
/*  108 */       sql1.append("  order by city_id,dept_id desc");
/*  109 */       Map params1 = new HashMap();
/*  110 */       params1.put("relation_type", drvTypeID);
/*  111 */       params1.put("camp_drv_id", drvID);
/*  112 */       params1.put("appr_flow_tpye", approvalType);
/*  113 */       List g_list = this.approvalDao.getObjectsBySQL(sql1.toString(), params1);
/*  114 */       if ((g_list != null) && (g_list.size() > 0))
/*  115 */         return (String)g_list.get(0);
/*      */     }
/*      */     else
/*      */     {
/*  119 */       result = "";
/*      */     }
/*      */ 
/*  122 */     if (StringUtil.isEmpty(result)) {
/*  123 */       String sql = "select approve_flow_id from ap_approve_flow_def where approve_flow_name=:approve_flow_name";
/*  124 */       Map defaultParams = new HashMap();
/*  125 */       defaultParams.put("approve_flow_name", defaultFlowName);
/*  126 */       List list = this.approvalDao.getObjectsBySQL(sql.toString(), defaultParams);
/*  127 */       if ((list != null) && (list.size() > 0)) {
/*  128 */         return (String)list.get(0);
/*      */       }
/*      */     }
/*  131 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean isHasConfirmFlow(String userId, String drvTypeID, String drvID)
/*      */     throws Exception
/*      */   {
/*  147 */     return isHasApprovalOrConfirmFlow(userId, drvTypeID, drvID, "2");
/*      */   }
/*      */ 
/*      */   public boolean isHasApprovalFlow(String userId, String drvTypeID, String drvID)
/*      */     throws Exception
/*      */   {
/*  164 */     return isHasApprovalOrConfirmFlow(userId, drvTypeID, drvID, "1");
/*      */   }
/*      */ 
/*      */   public boolean isHasApprovalOrConfirmFlow(String userId, String drvTypeID, String drvID, String approvalType) throws Exception
/*      */   {
/*  169 */     boolean flag = false;
/*  170 */     if ((StringUtil.isNotEmpty(userId)) && (StringUtil.isNotEmpty(drvTypeID)) && (StringUtil.isNotEmpty(drvID)) && (StringUtil.isNotEmpty(approvalType)))
/*      */     {
/*  172 */       IUser user = this.userPrivilegeService.getUser(userId);
/*  173 */       StringBuffer sql = new StringBuffer();
/*  174 */       sql.append("select approve_flow_id from ap_dept_flow_relation where city_id in('").append(user.getCityid()).append("','-1') and dept_id in('").append(user.getDepartmentid()).append("','-1') ");
/*      */ 
/*  176 */       sql.append("  and relation_type=:relation_type");
/*  177 */       sql.append("  and camp_drv_id=:camp_drv_id");
/*  178 */       sql.append("  and appr_flow_tpye=:appr_flow_tpye ");
/*  179 */       sql.append("  order by city_id,dept_id desc");
/*  180 */       Map params = new HashMap();
/*  181 */       params.put("relation_type", drvTypeID);
/*  182 */       params.put("camp_drv_id", drvID);
/*  183 */       params.put("appr_flow_tpye", approvalType);
/*      */ 
/*  185 */       List list = this.approvalDao.getObjectsBySQL(sql.toString(), params);
/*  186 */       if ((list != null) && (list.size() > 0)) {
/*  187 */         flag = true;
/*      */       }
/*      */     }
/*  190 */     return flag;
/*      */   }
/*      */ 
/*      */   public void processOaApprove(String serverIp, String serverPort, String approvalFlowId, String approvalId, Integer status, String needApprovalUserid, String drvTypeID, String drvID)
/*      */     throws Exception
/*      */   {
/*  214 */     throw new Exception("通过OA审批确认需要根据需求现场开发，目前流程暂未开通！");
/*      */   }
/*      */ 
/*      */   public int deleteApproverList(String approvalFlowId, String approvalId, String approve_userid, String approvalType)
/*      */     throws Exception
/*      */   {
/*  232 */     StringBuffer b = new StringBuffer();
/*  233 */     Map params = new HashMap();
/*  234 */     b.append(" delete from ap_approve_list where 1=1 and approval_id=:approval_id ");
/*      */ 
/*  236 */     params.put("approval_id", approvalId);
/*      */ 
/*  239 */     if (StringUtil.isNotEmpty(approvalFlowId)) {
/*  240 */       b.append(" and approve_flow_id=:approve_flow_id");
/*  241 */       params.put("approve_flow_id", approvalFlowId);
/*      */     }
/*  243 */     if (StringUtil.isNotEmpty(approve_userid)) {
/*  244 */       b.append(" and approve_userid=:approve_userid");
/*  245 */       params.put("approve_userid", approve_userid);
/*      */     }
/*  247 */     if (StringUtil.isNotEmpty(approvalType)) {
/*  248 */       b.append(" and approve_type=:approve_type");
/*  249 */       params.put("approve_type", approvalType);
/*      */     }
/*  251 */     return this.approvalDao.executeBySQL(b.toString(), params);
/*      */   }
/*      */ 
/*      */   public int saveApproverListHis(String approvalFlowId, String approvalId, String approve_userid, String approvalType)
/*      */     throws Exception
/*      */   {
/*  267 */     StringBuffer b = new StringBuffer();
/*  268 */     Map params = new HashMap();
/*  269 */     b.append(" insert into ap_approve_list_his select * from ap_approve_list where 1=1 and approval_id=:approval_id ");
/*      */ 
/*  271 */     params.put("approval_id", approvalId);
/*      */ 
/*  274 */     if (StringUtil.isNotEmpty(approvalFlowId)) {
/*  275 */       b.append(" and approve_flow_id=:approve_flow_id");
/*  276 */       params.put("approve_flow_id", approvalFlowId);
/*      */     }
/*  278 */     if (StringUtil.isNotEmpty(approve_userid)) {
/*  279 */       b.append(" and approve_userid=:approve_userid");
/*  280 */       params.put("approve_userid", approve_userid);
/*      */     }
/*  282 */     if (StringUtil.isNotEmpty(approvalType)) {
/*  283 */       b.append(" and approve_type=:approve_type");
/*  284 */       params.put("approve_type", approvalType);
/*      */     }
/*  286 */     return this.approvalDao.executeBySQL(b.toString(), params);
/*      */   }
/*      */ 
/*      */   public void saveApproverList(String approvalFlowId, String approvalId, Integer status, String needApproveUserid, String drvTypeID, String drvID, String approvalType)
/*      */     throws Exception
/*      */   {
/*  307 */     String approveUserId = null;
/*      */     try
/*      */     {
/*  312 */       List ApproveLevelDefList = this.approvalDao.getApprovalListByFlowId(approvalFlowId);
/*  313 */       if ((ApproveLevelDefList != null) && (ApproveLevelDefList.size() > 0)) {
/*  314 */         Iterator levelIt = ApproveLevelDefList.iterator();
/*  315 */         Integer approveSeq = Integer.valueOf(1);
/*      */         ApproveRelation relation;
/*  317 */         while (levelIt.hasNext()) {
/*  318 */           approveUserId = null;
/*  319 */           ApproveLevelDef levelDef = (ApproveLevelDef)levelIt.next();
/*  320 */           Integer approveObjType = Integer.valueOf(levelDef.getApprove_obj_type().intValue());
/*  321 */           String deptId = null;
/*      */ 
/*  323 */           Set approverUserIdSet = new HashSet();
/*  324 */           if (approveObjType.intValue() == 1) {
/*  325 */             IUser user = this.userPrivilegeService.getUser(needApproveUserid);
/*  326 */             if (user == null) {
/*  327 */               throw new Exception("找不到【" + needApproveUserid + "】用户对象！");
/*      */             }
/*  329 */             deptId = String.valueOf(user.getDepartmentid());
/*  330 */           } else if (approveObjType.intValue() == 2) {
/*  331 */             deptId = levelDef.getApprove_obj_id().trim();
/*  332 */           } else if (approveObjType.intValue() == 3) {
/*  333 */             approveUserId = levelDef.getApprove_obj_id().trim();
/*  334 */           } else if (approveObjType.intValue() == 4) {
/*  335 */             int deptTopN = Integer.parseInt(levelDef.getApprove_obj_id().trim());
/*  336 */             IUser user = this.userPrivilegeService.getUser(needApproveUserid);
/*  337 */             if (user == null) {
/*  338 */               throw new Exception("找不到【" + needApproveUserid + "】用户对象！");
/*      */             }
/*  340 */             deptId = String.valueOf(user.getDepartmentid());
/*      */ 
/*  342 */             deptId = getDeptTopNDeptId(deptId, deptTopN);
/*      */           }
/*      */ 
/*  345 */           if ((approveUserId == null) && (deptId != null)) {
/*  346 */             relation = this.approvalDao.findByUserDeptId(deptId, null);
/*  347 */             if (relation != null) {
/*  348 */               approveUserId = relation.getApprove_userid();
/*      */             }
/*      */           }
/*      */ 
/*  352 */           if (StringUtil.isEmpty(approveUserId)) {
/*  353 */             log.error("审批第【{}】级找不到审批人，略过……", new Object[] { levelDef.getApprove_level() });
/*      */           }
/*      */           else
/*      */           {
/*  357 */             ApApproveList campSegApprover = new ApApproveList();
/*      */ 
/*  359 */             campSegApprover.setApproval_id(approvalId);
/*  360 */             campSegApprover.setApprove_flow_id(approvalFlowId);
/*  361 */             campSegApprover.setApprove_seq(approveSeq);
/*  362 */             campSegApprover.setApprove_level(levelDef.getApprove_level());
/*  363 */             campSegApprover.setApprove_userid(approveUserId);
/*  364 */             campSegApprover.setApprove_token(ApprovalCONST.APPROVE_TOKEN_NOT_HOLD);
/*  365 */             campSegApprover.setApprove_type(approvalType);
/*  366 */             campSegApprover.setUpdate_time(new Date());
/*  367 */             campSegApprover.setCreate_time(new Date());
/*  368 */             campSegApprover.setApprove_flag("0");
/*  369 */             campSegApprover.setAuth_flag(Integer.valueOf(0));
/*  370 */             this.approvalDao.saveApApproveList(campSegApprover);
/*      */ 
/*  372 */             approverUserIdSet.add(approveUserId);
/*      */ 
/*  374 */             relation = approveSeq; Integer localInteger1 = approveSeq = Integer.valueOf(approveSeq.intValue() + 1);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  415 */         log.error("根据流程ID没有查询到审批确认级别信息:approvalFlowId={}", new Object[] { approvalFlowId });
/*      */       }
/*      */     } catch (Exception e) {
/*  418 */       log.error("保存审批确认需要的审批人列表信息异常{}", e);
/*  419 */       throw new Exception(" 保存审批确认需要的审批人列表信息失败！");
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getDeptTopNDeptId(String currDeptId, int topN)
/*      */     throws Exception
/*      */   {
/*  432 */     IUserCompany dept = null;
/*  433 */     int index = 0;
/*  434 */     String deptId = null;
/*      */     do {
/*  436 */       dept = this.userPrivilegeService.getUserCompanyById(currDeptId);
/*  437 */       if ((dept != null) && (index < topN)) {
/*  438 */         currDeptId = String.valueOf(dept.getParentid());
/*  439 */         index++;
/*      */       } else {
/*  441 */         deptId = currDeptId;
/*  442 */         break;
/*      */       }
/*      */     }
/*  444 */     while ((dept != null) && (index <= topN));
/*  445 */     return deptId;
/*      */   }
/*      */ 
/*      */   public String processApproveTriggerCondDef(ApproveTriggerCondDef cond, String approvalId, String needApproveUserid)
/*      */     throws Exception
/*      */   {
/*  463 */     String approveUserId = null;
/*      */ 
/*  547 */     return approveUserId;
/*      */   }
/*      */ 
/*      */   public String updateApprovalToken(String approvalId, String approvalType, String approvalFlag, String userId)
/*      */     throws Exception
/*      */   {
/*  564 */     List apList = getApprovalProcess(approvalId, approvalType);
/*  565 */     Integer currentApprovalSeq = null;
/*  566 */     String app_flow_id = null;
/*  567 */     Integer approve_level = null;
/*  568 */     String approve_userId = null;
/*  569 */     ApApproveList currentApproval = null;
/*      */ 
/*  571 */     if ((apList != null) && (apList.size() > 0)) {
/*  572 */       for (int i = 0; i < apList.size(); i++) {
/*  573 */         ApApproveList ap = (ApApproveList)apList.get(i);
/*      */ 
/*  575 */         if ((ap != null) && (ap.getApprove_userid().equals(userId)) && (ap.getApprove_token().equals(ApprovalCONST.APPROVE_TOKEN_HOLD)))
/*      */         {
/*  577 */           currentApproval = ap;
/*      */ 
/*  579 */           currentApprovalSeq = ap.getApprove_seq();
/*  580 */           app_flow_id = ap.getApprove_flow_id();
/*  581 */           approve_level = ap.getApprove_level();
/*  582 */           approve_userId = ap.getApprove_userid();
/*  583 */           int rtv1 = this.approvalDao.updateApprovalFlag(approvalId, approvalType, approvalFlag, currentApprovalSeq, app_flow_id, approve_level, approve_userId);
/*      */ 
/*  586 */           int rtv = this.approvalDao.updateApprovalToken(approvalId, approvalType, ApprovalCONST.APPROVE_TOKEN_NOT_HOLD, currentApprovalSeq, app_flow_id, approve_level, approve_userId);
/*      */ 
/*  590 */           log.debug("把当前持有审批令牌的人员所持令牌失效,approvalId={},approvalType={},approvalSeq={},approve_level={}", new Object[] { approvalId, approvalType, ap.getApprove_seq(), ap.getApprove_level() });
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  596 */     List list = this.approvalDao.getSampleLevelApproverByCurrentApproval(currentApproval);
/*  597 */     if (list.size() > 0) {
/*  598 */       log.error("等待同级审批人完成审批：approvalId={},level={}", new Object[] { currentApproval.getApproval_id(), currentApproval.getApprove_level() });
/*      */ 
/*  600 */       return "1";
/*      */     }
/*  602 */     return updateNextApprovalToken(approvalId, approvalType, ApprovalCONST.APPROVE_TOKEN_HOLD, currentApproval);
/*      */   }
/*      */ 
/*      */   public String updateNextApprovalToken(String approvalId, String approvalType, Integer approvalToken, ApApproveList currentApproval)
/*      */     throws Exception
/*      */   {
/*  618 */     String flag = "3";
/*  619 */     List nextApprovals = this.approvalDao.getNextApprovalProcess(currentApproval);
/*  620 */     if ((nextApprovals != null) && (nextApprovals.size() > 0))
/*      */     {
/*  622 */       for (int i = 0; i < nextApprovals.size(); i++) {
/*  623 */         ApApproveList nextApproval = (ApApproveList)nextApprovals.get(i);
/*  624 */         int rtv = this.approvalDao.updateApprovalToken(approvalId, approvalType, approvalToken, nextApproval.getApprove_seq(), nextApproval.getApprove_flow_id(), nextApproval.getApprove_level(), nextApproval.getApprove_userid());
/*      */ 
/*  627 */         log.info("更新持有令牌，参数：approvalId={},approvalType={},approvalToken={},approve_seq={},approve_flow_id={},approve_level={},approve_userid={}", new Object[] { approvalId, approvalType, approvalToken, nextApproval.getApprove_seq(), nextApproval.getApprove_flow_id(), nextApproval.getApprove_level(), nextApproval.getApprove_userid() });
/*      */       }
/*      */ 
/*  636 */       flag = "2";
/*      */     } else {
/*  638 */       flag = "3";
/*      */     }
/*  640 */     return flag;
/*      */   }
/*      */ 
/*      */   public int updateApprovalNotPass(String approvalId, String approvalType, String needApprovalUserid, String drvTypeID, String drvID, String advice)
/*      */     throws Exception
/*      */   {
/*  655 */     if (StringUtil.isNotEmpty(approvalId))
/*      */     {
/*  657 */       List list = getCurrentApprovalProcess(approvalId, approvalType, ApprovalCONST.APPROVE_TOKEN_HOLD.toString());
/*      */ 
/*  659 */       if ((list != null) && (list.size() > 0)) {
/*  660 */         Iterator it = list.iterator();
/*  661 */         while (it.hasNext()) {
/*  662 */           ApApproveList ap = (ApApproveList)it.next();
/*  663 */           if (ap.getApprove_userid().equals(needApprovalUserid)) {
/*  664 */             updateConfirmAdvice(ap.getApproval_id(), ap.getApprove_flow_id(), ap.getApprove_seq(), ap.getApprove_level(), ap.getApprove_userid(), ap.getApprove_type(), advice);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  670 */       StringBuffer sql = new StringBuffer("update ap_approve_list a set a.approve_token=:approve_token where a.approval_id=:approval_id");
/*      */ 
/*  672 */       Map params = new HashMap();
/*  673 */       params.put("approve_token", ApprovalCONST.APPROVE_TOKEN_NOT_HOLD);
/*  674 */       params.put("approval_id", approvalId);
/*  675 */       int rtv = this.approvalDao.executeBySQL(sql.toString(), params);
/*      */ 
/*  678 */       String flowModelID = getApproveDrvType(drvTypeID, drvID);
/*  679 */       if (!"flow_0001".equals(flowModelID))
/*      */       {
/*  681 */         if (("flow_0002".equals(flowModelID)) || ("flow_0004".equals(flowModelID)))
/*      */         {
/*  683 */           updateFirstApproveOrConfirmUserToken(approvalId, "1");
/*  684 */         } else if ("flow_0003".equals(flowModelID))
/*  685 */           updateFirstApproveOrConfirmUserToken(approvalId, "2");
/*      */         else
/*  687 */           log.error("策略{}没有在驱动类型配置中配置对应配置流程模式", new Object[] { approvalId });
/*      */       }
/*  689 */       return rtv;
/*      */     }
/*  691 */     return 0;
/*      */   }
/*      */ 
/*      */   public List<ApApproveList> getApprovalProcess(String approvalId, String approvalType) throws Exception {
/*  695 */     return this.approvalDao.getApprovalProcess(approvalId, approvalType, null);
/*      */   }
/*      */ 
/*      */   public List<ApApproveList> getCurrentApprovalProcess(String approvalId, String approvalType, String approvalToken) throws Exception
/*      */   {
/*  700 */     return this.approvalDao.getApprovalProcess(approvalId, approvalType, approvalToken);
/*      */   }
/*      */ 
/*      */   public List<ApApproveList> getApprovalProcessDesc(String approvalId, String approvalType) throws Exception
/*      */   {
/*  705 */     List list = this.approvalDao.getApprovalProcess(approvalId, approvalType, null);
/*  706 */     if ((list != null) && (list.size() > 0)) {
/*  707 */       for (int i = 0; i < list.size(); i++) {
/*  708 */         ApApproveList a = (ApApproveList)list.get(i);
/*  709 */         a.setApprove_flag_desc(ApprovalCONST.getApproveFlagDesc(a.getApprove_type(), a.getApprove_flag()));
/*  710 */         a.setApprove_level_desc("第" + NumberUtil.numberToZH(a.getApprove_level().intValue(), false) + "级" + ApprovalCONST.getFlowTypeDesc(a.getApprove_type()));
/*      */ 
/*  712 */         a.setApprove_type_desc(ApprovalCONST.getFlowTypeDesc(a.getApprove_type()));
/*  713 */         IUser user = this.userPrivilegeService.getUser(a.getApprove_userid());
/*  714 */         a.setApprove_user(user.getUsername());
/*      */       }
/*      */     }
/*  717 */     return list;
/*      */   }
/*      */ 
/*      */   public List<ApApproveList> getApprovalProcess(String approvalId) throws Exception {
/*  721 */     return this.approvalDao.getApprovalProcess(approvalId, null, null);
/*      */   }
/*      */ 
/*      */   public String getApproveDrvType(String drvTypeID, String drvID) throws Exception
/*      */   {
/*  726 */     return this.approvalDao.getApproveDrvType(drvTypeID, drvID);
/*      */   }
/*      */ 
/*      */   public void updateFirstApproveOrConfirmUserToken(String approvalId, String approvlType)
/*      */     throws Exception
/*      */   {
/*  739 */     List aps = this.approvalDao.getFirstApprovalOrConfimUser(approvalId, approvlType);
/*  740 */     if ((aps != null) && (aps.size() > 0))
/*      */     {
/*      */       int rtv;
/*  741 */       for (int i = 0; i < aps.size(); i++) {
/*  742 */         ApApproveList ap = (ApApproveList)aps.get(i);
/*  743 */         String sql = "update ap_approve_list a set a.approve_token=:approve_token  where a.approval_id=:approval_id and a.approve_flow_id=:approve_flow_id and  a.approve_seq=:approve_seq and a.approve_level=:approve_level and a.approve_type=:approve_type and a.approve_userid=:approve_userid";
/*      */ 
/*  746 */         Map p = new HashMap();
/*  747 */         p.put("approve_token", ApprovalCONST.APPROVE_TOKEN_HOLD);
/*  748 */         p.put("approval_id", ap.getApproval_id());
/*  749 */         p.put("approve_flow_id", ap.getApprove_flow_id());
/*  750 */         p.put("approve_seq", ap.getApprove_seq());
/*  751 */         p.put("approve_level", ap.getApprove_level());
/*  752 */         p.put("approve_type", ap.getApprove_type());
/*  753 */         p.put("approve_userid", ap.getApprove_userid());
/*  754 */         rtv = this.approvalDao.executeBySQL(sql, p);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public int updateConfirmAdvice(String approvalId, String app_flow_id, Integer approvalSeq, Integer approve_level, String approve_userId, String approvalType, String approve_advice)
/*      */     throws Exception
/*      */   {
/*  781 */     String sql = "update ap_approve_list a set a.approve_advice=:approve_advice  where a.approval_id=:approval_id and a.approve_flow_id=:approve_flow_id and  a.approve_seq=:approve_seq and a.approve_level=:approve_level and a.approve_type=:approve_type and a.approve_userid=:approve_userid";
/*      */ 
/*  784 */     Map p = new HashMap();
/*  785 */     p.put("approve_advice", approve_advice);
/*  786 */     p.put("approval_id", approvalId);
/*  787 */     p.put("approve_flow_id", app_flow_id);
/*  788 */     p.put("approve_seq", approvalSeq);
/*  789 */     p.put("approve_level", approve_level);
/*  790 */     p.put("approve_type", approvalType);
/*  791 */     p.put("approve_userid", approve_userId);
/*  792 */     int rtv = this.approvalDao.executeBySQL(sql, p);
/*  793 */     return 0;
/*      */   }
/*      */ 
/*      */   public void tranOtherApproveUser(String approvalId, String app_flow_id, Integer approvalSeq, Integer approve_level, String approve_userId, String approvalType, String approve_advice)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void doInitApproval(String approvalId, Integer status, String needApprovalUserid, String drvTypeID, String drvID)
/*      */     throws Exception
/*      */   {
/*  804 */     String approvalFlowId = null;
/*      */ 
/*  806 */     String flowModelID = getApproveDrvType(drvTypeID, drvID);
/*  807 */     if (!"flow_0001".equals(flowModelID))
/*      */     {
/*  809 */       if ("flow_0002".equals(flowModelID))
/*      */       {
/*  811 */         approvalFlowId = null;
/*  812 */         approvalFlowId = getApprovalFlowIDByDeptFlowRelation(needApprovalUserid, drvTypeID, drvID, "1");
/*      */ 
/*  814 */         if (StringUtil.isNotEmpty(approvalFlowId)) {
/*  815 */           if (approvalFlowId.equals("-1")) {
/*  816 */             processOaApprove(null, null, approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID);
/*      */           }
/*      */           else
/*  819 */             saveApproverList(approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID, "1");
/*      */         }
/*      */         else
/*      */         {
/*  823 */           log.error("策略{}流程模式是基本信息审批但没有配置对应的审批流程", new Object[] { approvalId });
/*      */ 
/*  825 */           throw new Exception("流程模式是基本信息审批但没有配置对应的审批流程");
/*      */         }
/*  827 */         updateFirstApproveOrConfirmUserToken(approvalId, "1");
/*  828 */       } else if ("flow_0003".equals(flowModelID))
/*      */       {
/*  831 */         approvalFlowId = null;
/*  832 */         approvalFlowId = getApprovalFlowIDByDeptFlowRelation(needApprovalUserid, drvTypeID, drvID, "2");
/*      */ 
/*  834 */         if (StringUtil.isNotEmpty(approvalFlowId)) {
/*  835 */           if (approvalFlowId.equals("-1")) {
/*  836 */             processOaApprove(null, null, approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID);
/*      */           }
/*      */           else
/*  839 */             saveApproverList(approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID, "2");
/*      */         }
/*      */         else
/*      */         {
/*  843 */           log.error("策略{}，流程模式是基本信息 确认,但没有配置对应的确认流程", new Object[] { approvalId });
/*      */ 
/*  845 */           throw new Exception("流程模式是基本信息 确认,但没有配置对应的确认流程");
/*      */         }
/*  847 */         updateFirstApproveOrConfirmUserToken(approvalId, "2");
/*  848 */       } else if ("flow_0004".equals(flowModelID))
/*      */       {
/*  850 */         approvalFlowId = null;
/*      */ 
/*  852 */         approvalFlowId = getApprovalFlowIDByDeptFlowRelation(needApprovalUserid, drvTypeID, drvID, "1");
/*      */ 
/*  854 */         if (StringUtil.isNotEmpty(approvalFlowId)) {
/*  855 */           if (approvalFlowId.equals("-1")) {
/*  856 */             processOaApprove(null, null, approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID);
/*      */           }
/*      */           else
/*  859 */             saveApproverList(approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID, "1");
/*      */         }
/*      */         else
/*      */         {
/*  863 */           log.error("策略{}流程模式是基本信息 审批 确认,但没有配置对应的审批流程", new Object[] { approvalId });
/*      */ 
/*  865 */           throw new Exception("流程模式是基本信息 审批 确认,但没有配置对应的审批流程");
/*      */         }
/*      */ 
/*  869 */         approvalFlowId = null;
/*  870 */         approvalFlowId = getApprovalFlowIDByDeptFlowRelation(needApprovalUserid, drvTypeID, drvID, "2");
/*      */ 
/*  872 */         if (StringUtil.isNotEmpty(approvalFlowId)) {
/*  873 */           if (approvalFlowId.equals("-1")) {
/*  874 */             processOaApprove(null, null, approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID);
/*      */           }
/*      */           else
/*  877 */             saveApproverList(approvalFlowId, approvalId, status, needApprovalUserid, drvTypeID, drvID, "2");
/*      */         }
/*      */         else
/*      */         {
/*  881 */           log.error("策略{}流程模式是基本信息 审批 确认,但没有配置对应的确认流程", new Object[] { approvalId });
/*      */ 
/*  883 */           throw new Exception("流程模式是基本信息 审批 确认,但没有配置对应的确认流程");
/*      */         }
/*  885 */         updateFirstApproveOrConfirmUserToken(approvalId, "1");
/*      */       } else {
/*  887 */         log.error("策略{}没有在驱动类型配置中配置对应配置流程模式", new Object[] { approvalId });
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void doApproval(String approvalId, Integer status, String needApprovalUserid, String drvTypeID, String drvID)
/*      */     throws Exception
/*      */   {
/*  898 */     int rtv1 = saveApproverListHis(null, approvalId, null, null);
/*      */ 
/*  900 */     int rtv = deleteApproverList(null, approvalId, null, null);
/*  901 */     log.debug("删除{}审批确认过程，删除{}条记录", new Object[] { approvalId, Integer.valueOf(rtv) });
/*  902 */     doInitApproval(approvalId, status, needApprovalUserid, drvTypeID, drvID);
/*      */   }
/*      */ 
/*      */   public List<?> getApprovalIdByUser(String userId, String approvalType) throws Exception {
/*  906 */     String sql = "select a.approval_id from ap_approve_list a  where  a.approve_token =:approve_token and a.approve_userid=:approve_userid";
/*  907 */     Map params = new HashMap();
/*  908 */     params.put("approve_token", ApprovalCONST.APPROVE_TOKEN_HOLD);
/*  909 */     params.put("approve_userid", userId);
/*  910 */     if (StringUtil.isNotEmpty(approvalType)) {
/*  911 */       sql = sql + " and a.approve_type=:approve_type";
/*  912 */       params.put("approve_type", approvalType);
/*      */     }
/*  914 */     return this.approvalDao.getObjectsBySQL(sql.toString(), params);
/*      */   }
/*      */ 
/*      */   public List<ApApproveList> getNextApprovalProcess(ApApproveList ap) throws Exception {
/*  918 */     return this.approvalDao.getNextApprovalProcess(ap);
/*      */   }
/*      */ 
/*      */   public int saveTranOtherUser(String approvalId, String tranUserID)
/*      */     throws Exception
/*      */   {
/*  938 */     String approveUserId = tranUserID;
/*      */     int rtv;
/*  939 */     if ((StringUtil.isNotEmpty(tranUserID)) && (StringUtil.isNotEmpty(approvalId)))
/*      */     {
/*  943 */       List apList = getCurrentApprovalProcess(approvalId, "1", ApprovalCONST.APPROVE_TOKEN_HOLD.toString());
/*      */ 
/*  945 */       if ((apList != null) && (apList.size() > 0)) {
/*  946 */         ApApproveList a = (ApApproveList)apList.get(0);
/*      */ 
/*  948 */         String sql = "update ap_approve_list  a set a.approve_seq=a.approve_seq+1 where a.approval_id=:approval_id and a.approve_flow_id=:approve_flow_id and a.approve_type=:approve_type and a.approve_seq>:approve_seq";
/*  949 */         Map params = new HashMap();
/*  950 */         params.put("approval_id", a.getApproval_id());
/*  951 */         params.put("approve_flow_id", a.getApprove_flow_id());
/*  952 */         params.put("approve_type", a.getApprove_type());
/*  953 */         params.put("approve_seq", a.getApprove_seq());
/*  954 */         this.approvalDao.executeBySQL(sql, params);
/*      */ 
/*  956 */         ApApproveList campSegApprover = new ApApproveList();
/*  957 */         campSegApprover.setApproval_id(approvalId);
/*  958 */         campSegApprover.setApprove_flow_id(a.getApprove_flow_id());
/*  959 */         campSegApprover.setApprove_seq(Integer.valueOf(a.getApprove_seq().intValue() + 1));
/*  960 */         campSegApprover.setApprove_level(a.getApprove_level());
/*  961 */         campSegApprover.setApprove_userid(approveUserId);
/*  962 */         campSegApprover.setApprove_token(ApprovalCONST.APPROVE_TOKEN_NOT_HOLD);
/*  963 */         campSegApprover.setApprove_type(a.getApprove_type());
/*  964 */         campSegApprover.setUpdate_time(new Date());
/*  965 */         campSegApprover.setApprove_flag("0");
/*  966 */         campSegApprover.setAuth_flag(Integer.valueOf(1));
/*  967 */         rtv = this.approvalDao.saveApApproveList(campSegApprover);
/*      */       }
/*      */     }
/*      */ 
/*  971 */     return 0;
/*      */   }
/*      */ 
/*      */   public TreeMap<String, String> getApprovalTypeProcess(String approvalId)
/*      */     throws Exception
/*      */   {
/*  984 */     if (StringUtil.isNotEmpty(approvalId)) {
/*  985 */       String sql = "select distinct a.approve_type from ap_approve_list a where a.approval_id=:approval_id order by a.approve_type";
/*  986 */       HashMap p = new HashMap();
/*  987 */       p.put("approval_id", approvalId);
/*  988 */       List list = this.approvalDao.getObjectsBySQL(sql, p);
/*  989 */       if ((list != null) && (list.size() > 0)) {
/*  990 */         TreeMap ret = new TreeMap();
/*  991 */         for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object str = i$.next();
/*  992 */           ret.put(str.toString(), ApprovalCONST.getFlowTypeDesc(str.toString()));
/*      */         }
/*  994 */         return ret;
/*      */       }
/*  996 */       return null;
/*      */     }
/*      */ 
/*  999 */     return null;
/*      */   }
/*      */ 
/*      */   public List<String> getCurrentApproversByApprovalID(String approvalID) throws Exception {
/* 1003 */     return this.approvalDao.getCurrentApproversByApprovalID(approvalID);
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.ApprovalServiceImpl
 * JD-Core Version:    0.6.2
 */
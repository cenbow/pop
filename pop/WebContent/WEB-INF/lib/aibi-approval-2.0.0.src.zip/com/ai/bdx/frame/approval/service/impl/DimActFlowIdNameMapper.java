package com.ai.bdx.frame.approval.service.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.approval.dao.IMpmSysActflowDefDao;
import com.ai.bdx.frame.approval.model.MtlSysActflowDef;

/*
 * Created on 6:32:07 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author chenlc
 * @version 1.0
 */
public class DimActFlowIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IMpmSysActflowDefDao dao;

	List itemList;

	public DimActFlowIdNameMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(
				DimActFlowIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = "--";
		try {
			MtlSysActflowDef obj = dao.getSysActFlowDef(id.toString());
			if (obj != null && obj.getFlowName() != null) {
				name = obj.getFlowName();
			}
			super.putSimpleCacheMap(DimActFlowIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("", e);
		}
		return name;
	}

	public List getAll() {
		try {
			if (itemList == null) {

				Iterator it = dao.findAll().iterator();
				MtlSysActflowDef obj;
				while (it.hasNext()) {
					obj = (MtlSysActflowDef) it.next();
					itemList.add(new LabelValueBean(obj.getFlowName(), obj
							.getFlowId()));
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return itemList;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public IMpmSysActflowDefDao getDao() {
		return dao;
	}

	public void setDao(IMpmSysActflowDefDao dao) {
		this.dao = dao;
	}

}

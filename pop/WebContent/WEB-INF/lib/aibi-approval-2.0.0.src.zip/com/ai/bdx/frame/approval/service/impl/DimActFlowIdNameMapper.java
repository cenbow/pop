/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IMpmSysActflowDefDao;
/*    */ import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class DimActFlowIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 24 */   private static Logger log = LogManager.getLogger();
/*    */   private IMpmSysActflowDefDao dao;
/*    */   List itemList;
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 35 */     Object value = super.getSimpleCacheMapValue(DimActFlowIdNameMapper.class, id);
/*    */ 
/* 37 */     if (value != null) {
/* 38 */       return value.toString();
/*    */     }
/* 40 */     String name = "--";
/*    */     try {
/* 42 */       MtlSysActflowDef obj = this.dao.getSysActFlowDef(id.toString());
/* 43 */       if ((obj != null) && (obj.getFlowName() != null)) {
/* 44 */         name = obj.getFlowName();
/*    */       }
/* 46 */       super.putSimpleCacheMap(DimActFlowIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 48 */       log.error("", e);
/*    */     }
/* 50 */     return name;
/*    */   }
/*    */ 
/*    */   public List getAll() {
/*    */     try {
/* 55 */       if (this.itemList == null)
/*    */       {
/* 57 */         Iterator it = this.dao.findAll().iterator();
/*    */ 
/* 59 */         while (it.hasNext()) {
/* 60 */           MtlSysActflowDef obj = (MtlSysActflowDef)it.next();
/* 61 */           this.itemList.add(new LabelValueBean(obj.getFlowName(), obj.getFlowId()));
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 66 */       log.error("", e);
/*    */     }
/* 68 */     return this.itemList;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 73 */     return null;
/*    */   }
/*    */ 
/*    */   public IMpmSysActflowDefDao getDao() {
/* 77 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IMpmSysActflowDefDao dao) {
/* 81 */     this.dao = dao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimActFlowIdNameMapper
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service.impl;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao;
import com.ai.bdx.frame.approval.model.DimMtlChanneltype;

public class DimCampChannelTypeIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IDimMtlChanneltypeDao dao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.asiainfo.service.IdNameMapper#getAll()
	 */
	public List getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.asiainfo.service.IdNameMapper#getNameById(java.lang.Object)
	 */
	public String getNameById(Object arg0) {
		String res = "";
		if (arg0 == null) {
			return res;
		}
		Object value = super.getSimpleCacheMapValue(
				DimCampChannelTypeIdNameMapper.class, arg0);
		if (value != null) {
			return value.toString();
		}

		try {
			DimMtlChanneltype type = dao.getMtlChanneltype(Short.valueOf(arg0
					.toString()));
			if (type != null) {
				res = type.getChanneltypeName();
			}
			super.putSimpleCacheMap(DimCampChannelTypeIdNameMapper.class, arg0,
					res);
		} catch (Exception e) {
			log.error("", e);
		}
		return res;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.asiainfo.service.IdNameMapper#getNameListByCondition(java.util.List)
	 */
	public List getNameListByCondition(List arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public IDimMtlChanneltypeDao getDao() {
		return dao;
	}

	public void setDao(IDimMtlChanneltypeDao dao) {
		this.dao = dao;
	}

}

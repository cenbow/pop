/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao;
/*    */ import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class DimCampChannelTypeIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 10 */   private static Logger log = LogManager.getLogger();
/*    */   private IDimMtlChanneltypeDao dao;
/*    */ 
/*    */   public List getAll()
/*    */   {
/* 20 */     return null;
/*    */   }
/*    */ 
/*    */   public String getNameById(Object arg0)
/*    */   {
/* 29 */     String res = "";
/* 30 */     if (arg0 == null) {
/* 31 */       return res;
/*    */     }
/* 33 */     Object value = super.getSimpleCacheMapValue(DimCampChannelTypeIdNameMapper.class, arg0);
/*    */ 
/* 35 */     if (value != null) {
/* 36 */       return value.toString();
/*    */     }
/*    */     try
/*    */     {
/* 40 */       DimMtlChanneltype type = this.dao.getMtlChanneltype(Short.valueOf(arg0.toString()));
/*    */ 
/* 42 */       if (type != null) {
/* 43 */         res = type.getChanneltypeName();
/*    */       }
/* 45 */       super.putSimpleCacheMap(DimCampChannelTypeIdNameMapper.class, arg0, res);
/*    */     }
/*    */     catch (Exception e) {
/* 48 */       log.error("", e);
/*    */     }
/* 50 */     return res;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List arg0)
/*    */   {
/* 61 */     return null;
/*    */   }
/*    */ 
/*    */   public IDimMtlChanneltypeDao getDao() {
/* 65 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IDimMtlChanneltypeDao dao) {
/* 69 */     this.dao = dao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimCampChannelTypeIdNameMapper
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao;
/*    */ import com.ai.bdx.frame.approval.model.DimCampDrvType;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class DimCampDrvTypeIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 24 */   private static Logger log = LogManager.getLogger();
/*    */   private IDimCampDrvTypeDao dao;
/*    */   List itemList;
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 35 */     Object value = super.getSimpleCacheMapValue(DimCampDrvTypeIdNameMapper.class, id);
/*    */ 
/* 37 */     if (value != null) {
/* 38 */       return value.toString();
/*    */     }
/* 40 */     String name = "--";
/*    */     try {
/* 42 */       DimCampDrvType obj = this.dao.getDrvType(Short.valueOf(id.toString()));
/* 43 */       if ((obj != null) && (obj.getCampDrvName() != null)) {
/* 44 */         name = obj.getCampDrvName();
/*    */       }
/* 46 */       super.putSimpleCacheMap(DimCampDrvTypeIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 48 */       log.error("", e);
/*    */     }
/* 50 */     return name;
/*    */   }
/*    */ 
/*    */   public List getAll() {
/*    */     try {
/* 55 */       if (this.itemList == null)
/*    */       {
/* 57 */         Iterator it = this.dao.getAllDrvType().iterator();
/*    */ 
/* 59 */         while (it.hasNext()) {
/* 60 */           DimCampDrvType obj = (DimCampDrvType)it.next();
/* 61 */           this.itemList.add(new LabelValueBean(obj.getCampDrvName(), obj.getCampDrvId().toString()));
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 66 */       log.error("", e);
/*    */     }
/* 68 */     return this.itemList;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 73 */     return null;
/*    */   }
/*    */ 
/*    */   public IDimCampDrvTypeDao getDao() {
/* 77 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IDimCampDrvTypeDao dao) {
/* 81 */     this.dao = dao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimCampDrvTypeIdNameMapper
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao;
import com.ai.bdx.frame.approval.model.DimCampDrvType;

/*
 * Created on 6:18:03 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class DimCampDrvTypeIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IDimCampDrvTypeDao dao;

	List itemList;

	public DimCampDrvTypeIdNameMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(
				DimCampDrvTypeIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = "--";
		try {
			DimCampDrvType obj = dao.getDrvType(Short.valueOf(id.toString()));
			if (obj != null && obj.getCampDrvName() != null) {
				name = obj.getCampDrvName();
			}
			super.putSimpleCacheMap(DimCampDrvTypeIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("", e);
		}
		return name;
	}

	public List getAll() {
		try {
			if (itemList == null) {

				Iterator it = dao.getAllDrvType().iterator();
				DimCampDrvType obj;
				while (it.hasNext()) {
					obj = (DimCampDrvType) it.next();
					itemList.add(new LabelValueBean(obj.getCampDrvName(), obj
							.getCampDrvId().toString()));
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return itemList;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public IDimCampDrvTypeDao getDao() {
		return dao;
	}

	public void setDao(IDimCampDrvTypeDao dao) {
		this.dao = dao;
	}

}

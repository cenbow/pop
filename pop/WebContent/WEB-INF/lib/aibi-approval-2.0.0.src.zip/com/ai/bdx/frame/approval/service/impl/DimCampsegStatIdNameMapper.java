/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimCampsegStatDao;
/*    */ import com.ai.bdx.frame.approval.model.DimCampsegStat;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class DimCampsegStatIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 11 */   private static Logger log = LogManager.getLogger();
/*    */   private IDimCampsegStatDao dao;
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 19 */     Object value = super.getSimpleCacheMapValue(DimCampsegStatIdNameMapper.class, id);
/*    */ 
/* 21 */     if (value != null) {
/* 22 */       return value.toString();
/*    */     }
/* 24 */     String name = "--";
/*    */     try {
/* 26 */       DimCampsegStat obj = this.dao.getCampsegStat(Short.valueOf(id.toString()));
/*    */ 
/* 28 */       if (obj != null) {
/* 29 */         name = obj.getCampsegStatName();
/*    */       }
/* 31 */       super.putSimpleCacheMap(DimCampsegStatIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 33 */       log.error(e.getMessage(), e);
/*    */     }
/* 35 */     return name;
/*    */   }
/*    */ 
/*    */   public List getAll()
/*    */   {
/* 49 */     List result = null;
/*    */     try {
/* 51 */       result = this.dao.getAllCampsegStat();
/*    */     } catch (Exception e) {
/* 53 */       log.error(e.getMessage(), e);
/*    */     }
/* 55 */     return result;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids) {
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */   public IDimCampsegStatDao getDao() {
/* 63 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IDimCampsegStatDao dao) {
/* 67 */     this.dao = dao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimCampsegStatIdNameMapper
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service.impl;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.dao.IDimCampsegStatDao;
import com.ai.bdx.frame.approval.model.DimCampsegStat;

public class DimCampsegStatIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IDimCampsegStatDao dao;

	public DimCampsegStatIdNameMapper() {
		super();
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(
				DimCampsegStatIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = "--";
		try {
			DimCampsegStat obj = dao
					.getCampsegStat(Short.valueOf(id.toString()));
			if (obj != null) {
				name = obj.getCampsegStatName();
			}
			super.putSimpleCacheMap(DimCampsegStatIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return name;
	}

	public List getAll() {
		/*
		 * List<LabelValueBean> itemList = null; try { itemList = new
		 * ArrayList<LabelValueBean>(); Iterator it =
		 * dao.getAllCampsegStat().iterator(); //by chengxc 修改为取得用户可见的状态列表；
		 * //Iterator it = this.dao.getAllCampsegStatVisible().iterator();
		 * DimCampsegStat obj; while (it.hasNext()) { obj = (DimCampsegStat)
		 * it.next(); itemList.add(new LabelValueBean(obj.getCampsegStatName(),
		 * obj.getCampsegStatId().toString())); } } catch (Exception e) {
		 * log.error(e.getMessage(),e); } return itemList;
		 */
		List result = null;
		try {
			result = dao.getAllCampsegStat();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return result;
	}

	public List getNameListByCondition(List ids) {
		return null;
	}

	public IDimCampsegStatDao getDao() {
		return dao;
	}

	public void setDao(IDimCampsegStatDao dao) {
		this.dao = dao;
	}

}

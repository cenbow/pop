/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
/*     */ import com.ai.bdx.frame.approval.dao.IDimPubChannelDao;
/*     */ import com.ai.bdx.frame.approval.model.DimMtlChannel;
/*     */ import com.ai.bdx.frame.approval.util.MpmHtmlHelper;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class DimChannelIdNameMapper extends IdNameMapperImpl
/*     */ {
/*  15 */   private static Logger log = LogManager.getLogger();
/*     */   private IDimPubChannelDao channelDao;
/*     */   private IDimMtlChannelDao dimMtlChannelDao;
/*     */   List itemList;
/*     */ 
/*     */   public String getNameById(Object id)
/*     */   {
/*  28 */     Object value = super.getSimpleCacheMapValue(DimChannelIdNameMapper.class, id);
/*     */ 
/*  30 */     if (value != null) {
/*  31 */       return value.toString();
/*     */     }
/*  33 */     String name = "";
/*  34 */     String VipOrComp = Configure.getInstance().getProperty("MPM_VIP_OR_COMP_MANAGER");
/*     */ 
/*  36 */     String tmpId = id == null ? "" : id.toString();
/*  37 */     if (tmpId.indexOf("'") >= 0) {
/*  38 */       tmpId = MpmHtmlHelper.removeComma(tmpId);
/*     */     }
/*  40 */     int pos = tmpId.indexOf("_");
/*  41 */     String channeltypeId = tmpId.substring(0, pos);
/*  42 */     String channelId = tmpId.substring(pos + 1).trim();
/*     */     try
/*     */     {
/*  46 */       if ((channelId.equals("'-1'")) || (channelId.equals("-1"))) {
/*  47 */         name = MpmLocaleUtil.getMessage("mcd.java.qbqd");
/*  48 */       } else if (channelId.indexOf(",") >= 0) {
/*  49 */         if (channelId.indexOf("'") < 0) {
/*  50 */           channelId = MpmHtmlHelper.addComma(channelId);
/*     */         }
/*  52 */         DimMtlChannel obj = new DimMtlChannel();
/*  53 */         obj.setChannelId(channelId);
/*  54 */         Iterator it = this.dimMtlChannelDao.findMtlChannel(obj).iterator();
/*  55 */         name = "";
/*  56 */         while (it.hasNext()) {
/*  57 */           obj = (DimMtlChannel)it.next();
/*  58 */           name = name + obj.getChannelName() + ",";
/*     */         }
/*  60 */         if (name.length() > 0)
/*  61 */           name = name.substring(0, name.length() - 1);
/*     */       }
/*     */       else {
/*  64 */         DimMtlChannel obj = this.dimMtlChannelDao.getMtlChannel(channelId.toString());
/*     */ 
/*  66 */         if (obj != null) {
/*  67 */           name = obj.getChannelName();
/*     */         }
/*     */       }
/*  70 */       super.putSimpleCacheMap(DimChannelIdNameMapper.class, id, name);
/*     */     } catch (Exception e) {
/*  72 */       log.error("", e);
/*     */     }
/*  74 */     return name;
/*     */   }
/*     */ 
/*     */   public List getAll()
/*     */   {
/*  83 */     return this.itemList;
/*     */   }
/*     */ 
/*     */   public List getNameListByCondition(List ids)
/*     */   {
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */   public IDimPubChannelDao getChannelDao() {
/*  92 */     return this.channelDao;
/*     */   }
/*     */ 
/*     */   public void setChannelDao(IDimPubChannelDao channelDao) {
/*  96 */     this.channelDao = channelDao;
/*     */   }
/*     */ 
/*     */   public IDimMtlChannelDao getDimMtlChannelDao() {
/* 100 */     return this.dimMtlChannelDao;
/*     */   }
/*     */ 
/*     */   public void setDimMtlChannelDao(IDimMtlChannelDao dimMtlChannelDao) {
/* 104 */     this.dimMtlChannelDao = dimMtlChannelDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimChannelIdNameMapper
 * JD-Core Version:    0.6.2
 */
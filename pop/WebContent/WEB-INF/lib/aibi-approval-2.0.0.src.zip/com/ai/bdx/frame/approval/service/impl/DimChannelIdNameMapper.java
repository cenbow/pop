package com.ai.bdx.frame.approval.service.impl;

import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
import com.ai.bdx.frame.approval.dao.IDimPubChannelDao;
import com.ai.bdx.frame.approval.model.DimMtlChannel;
import com.ai.bdx.frame.approval.util.MpmHtmlHelper;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
import com.asiainfo.biframe.utils.config.Configure;

public class DimChannelIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IDimPubChannelDao channelDao;

	private IDimMtlChannelDao dimMtlChannelDao;

	List itemList;

	public DimChannelIdNameMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(
				DimChannelIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = "";
		String VipOrComp = Configure.getInstance().getProperty(
				"MPM_VIP_OR_COMP_MANAGER");
		String tmpId = (id == null) ? "" : id.toString();
		if (tmpId.indexOf("'") >= 0) {
			tmpId = MpmHtmlHelper.removeComma(tmpId);
		}
		int pos = tmpId.indexOf("_");
		String channeltypeId = tmpId.substring(0, pos);
		String channelId = tmpId.substring(pos + 1).trim();
		try {
			// 大客户经理

			if (channelId.equals("'-1'") || channelId.equals("-1")) {
				name = MpmLocaleUtil.getMessage("mcd.java.qbqd");
			} else if (channelId.indexOf(",") >= 0) {
				if (channelId.indexOf("'") < 0) {
					channelId = MpmHtmlHelper.addComma(channelId);
				}
				DimMtlChannel obj = new DimMtlChannel();
				obj.setChannelId(channelId);
				Iterator it = dimMtlChannelDao.findMtlChannel(obj).iterator();
				name = "";
				while (it.hasNext()) {
					obj = (DimMtlChannel) it.next();
					name += obj.getChannelName() + ",";
				}
				if (name.length() > 0) {
					name = name.substring(0, name.length() - 1);
				}
			} else {
				DimMtlChannel obj = dimMtlChannelDao.getMtlChannel(channelId
						.toString());
				if (obj != null) {
					name = obj.getChannelName();
				}
			}
			super.putSimpleCacheMap(DimChannelIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("", e);
		}
		return name;
	}

	public List getAll() {
		try {

		} catch (Exception e) {
			log.error("", e);
		}
		return itemList;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public IDimPubChannelDao getChannelDao() {
		return channelDao;
	}

	public void setChannelDao(IDimPubChannelDao channelDao) {
		this.channelDao = channelDao;
	}

	public IDimMtlChannelDao getDimMtlChannelDao() {
		return dimMtlChannelDao;
	}

	public void setDimMtlChannelDao(IDimMtlChannelDao dimMtlChannelDao) {
		this.dimMtlChannelDao = dimMtlChannelDao;
	}

}

/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.form.DimChannelUserRelationForm;
/*     */ import com.ai.bdx.frame.approval.model.DimChannelUserRelation;
/*     */ import com.ai.bdx.frame.approval.service.IDimChannelUserRelationService;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class DimChannelUserRelationServiceImpl
/*     */   implements IDimChannelUserRelationService
/*     */ {
/*  27 */   private static Logger log = LogManager.getLogger();
/*     */   private IDimChannelUserRelationDao dimChannelUserRelationDao;
/*     */ 
/*     */   public void save(DimChannelUserRelation dimChannelUserRelation)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  42 */       this.dimChannelUserRelationDao.save(dimChannelUserRelation);
/*     */     } catch (Exception e) {
/*  44 */       log.error("", e);
/*  45 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bczyqdqrrd"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map searchChannelUserRelation(DimChannelUserRelationForm searchForm, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  55 */       return this.dimChannelUserRelationDao.searchChannelUserRelation(searchForm, curPage, pageSize);
/*     */     } catch (Exception e) {
/*  57 */       log.error("", e);
/*  58 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxzyqdqrrd"));
/*     */   }
/*     */ 
/*     */   public DimChannelUserRelation getChannelUserRelation(int rid, Short cType)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  68 */       return this.dimChannelUserRelationDao.getChannelTypeId(Integer.valueOf(rid + ""), null, cType);
/*     */     } catch (Exception e) {
/*  70 */       log.error("", e);
/*  71 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qzyqdqrrdy"));
/*     */   }
/*     */ 
/*     */   public DimChannelUserRelation getChannelUserRelation(Short channelType, String channelId, int confirmType)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  81 */       return this.dimChannelUserRelationDao.getChannelTypeId(channelType, channelId, confirmType);
/*     */     } catch (Exception e) {
/*  83 */       log.error("", e);
/*  84 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qzyqdqrrdy"));
/*     */   }
/*     */ 
/*     */   public void delete(DimChannelUserRelationForm searchForm)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  94 */       this.dimChannelUserRelationDao.delete(searchForm);
/*     */     } catch (Exception e) {
/*  96 */       log.error("", e);
/*  97 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.sczyqdqrrd"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getAllChanneltype()
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 107 */       return this.dimChannelUserRelationDao.getAllChannelType();
/*     */     } catch (Exception e) {
/* 109 */       log.error("", e);
/* 110 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsyzyqdqrr"));
/*     */   }
/*     */ 
/*     */   public IDimChannelUserRelationDao getDimChannelUserRelationDao()
/*     */   {
/* 118 */     return this.dimChannelUserRelationDao;
/*     */   }
/*     */ 
/*     */   public void setDimChannelUserRelationDao(IDimChannelUserRelationDao dimChannelUserRelationDao)
/*     */   {
/* 125 */     this.dimChannelUserRelationDao = dimChannelUserRelationDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimChannelUserRelationServiceImpl
 * JD-Core Version:    0.6.2
 */
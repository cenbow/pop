package com.ai.bdx.frame.approval.service.impl;


import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimChannelUserRelationForm;
import com.ai.bdx.frame.approval.model.DimChannelUserRelation;
import com.ai.bdx.frame.approval.service.IDimChannelUserRelationService;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

/**
 *
 * Created on 2008-3-7
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author qixf
 * @version 1.0
 */
public class DimChannelUserRelationServiceImpl implements IDimChannelUserRelationService {
	private static Logger log = LogManager.getLogger();

	private IDimChannelUserRelationDao dimChannelUserRelationDao;

	public DimChannelUserRelationServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#save(com.ai.bdx.frame.approval.model.DimChannelUserRelation)
	 */
	public void save(DimChannelUserRelation dimChannelUserRelation) throws MpmException {
		// TODO 自动生成方法存根
		try {
			dimChannelUserRelationDao.save(dimChannelUserRelation);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bczyqdqrrd"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#searchChannelUserRelation(com.ai.bdx.frame.approval.form.DimChannelUserRelationForm)
	 */
	public Map searchChannelUserRelation(DimChannelUserRelationForm searchForm, Integer curPage, Integer pageSize) throws MpmException {
		// TODO 自动生成方法存根
		try {
			return dimChannelUserRelationDao.searchChannelUserRelation(searchForm, curPage, pageSize);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxzyqdqrrd"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#getChannelUserRelation(int, java.lang.Short)
	 */
	public DimChannelUserRelation getChannelUserRelation(int rid, Short cType) throws MpmException {
		// TODO 自动生成方法存根
		try {
			return dimChannelUserRelationDao.getChannelTypeId(Integer.valueOf(rid + ""), null, cType);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qzyqdqrrdy"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#getChannelUserRelation(java.lang.Short, java.lang.String, int)
	 */
	public DimChannelUserRelation getChannelUserRelation(Short channelType, String channelId, int confirmType) throws MpmException {
		// TODO 自动生成方法存根
		try {
			return dimChannelUserRelationDao.getChannelTypeId(channelType, channelId, confirmType);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qzyqdqrrdy"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#delete(com.ai.bdx.frame.approval.form.DimChannelUserRelationForm)
	 */
	public void delete(DimChannelUserRelationForm searchForm) throws MpmException {
		// TODO 自动生成方法存根
		try {
			dimChannelUserRelationDao.delete(searchForm);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.sczyqdqrrd"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#getAllChanneltype()
	 */
	public List getAllChanneltype() throws MpmException {
		// TODO 自动生成方法存根
		try {
			return dimChannelUserRelationDao.getAllChannelType();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsyzyqdqrr"));
		}
	}

	/**
	 * @return dimChannelUserRelationDao
	 */
	public IDimChannelUserRelationDao getDimChannelUserRelationDao() {
		return dimChannelUserRelationDao;
	}

	/**
	 * @param dimChannelUserRelationDao 要设置的 dimChannelUserRelationDao
	 */
	public void setDimChannelUserRelationDao(IDimChannelUserRelationDao dimChannelUserRelationDao) {
		this.dimChannelUserRelationDao = dimChannelUserRelationDao;
	}
}

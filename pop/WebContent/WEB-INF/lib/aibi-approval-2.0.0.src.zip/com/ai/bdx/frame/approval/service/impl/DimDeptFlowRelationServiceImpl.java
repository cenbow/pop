/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimDeptFlowRelationDAO;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.form.DimDeptFlowRelationForm;
/*     */ import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;
/*     */ import com.ai.bdx.frame.approval.model.DimDeptFlowRelationId;
/*     */ import com.ai.bdx.frame.approval.service.IDimDeptFlowRelationService;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.builder.ToStringBuilder;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class DimDeptFlowRelationServiceImpl
/*     */   implements IDimDeptFlowRelationService
/*     */ {
/*  31 */   private static Logger log = LogManager.getLogger();
/*     */   private IDimDeptFlowRelationDAO dimDeptFlowRelationDao;
/*     */ 
/*     */   public IDimDeptFlowRelationDAO getDimDeptFlowRelationDao()
/*     */   {
/*  36 */     return this.dimDeptFlowRelationDao;
/*     */   }
/*     */ 
/*     */   public void setDimDeptFlowRelationDao(IDimDeptFlowRelationDAO dimDeptFlowRelationDao)
/*     */   {
/*  41 */     this.dimDeptFlowRelationDao = dimDeptFlowRelationDao;
/*     */   }
/*     */ 
/*     */   public void delete(DimDeptFlowRelationId dimDeptFlowRelationId)
/*     */     throws MpmException
/*     */   {
/*  58 */     DimDeptFlowRelation rel = this.dimDeptFlowRelationDao.findById(dimDeptFlowRelationId);
/*  59 */     if (rel == null) {
/*  60 */       throw new RuntimeException(String.format("对象【%s】没找到，无法删除", new Object[] { ToStringBuilder.reflectionToString(dimDeptFlowRelationId) }));
/*     */     }
/*  62 */     this.dimDeptFlowRelationDao.delete(rel);
/*     */   }
/*     */ 
/*     */   public List getAllDeptFlowRelation()
/*     */     throws MpmException
/*     */   {
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   public DimDeptFlowRelation getDeptFlowRelation(int rid, Short cType)
/*     */     throws MpmException
/*     */   {
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */   public void modify(DimDeptFlowRelationForm modifyForm)
/*     */     throws MpmException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void save(DimDeptFlowRelation dimDeptFlowRelation)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  90 */       this.dimDeptFlowRelationDao.save(dimDeptFlowRelation);
/*     */     } catch (Exception e) {
/*  92 */       log.error("", e);
/*  93 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bczyqdqrrd"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isObjectExist(DimDeptFlowRelationId dimDeptFlowRelationId) throws MpmException {
/*     */     try { if (this.dimDeptFlowRelationDao.findById(dimDeptFlowRelationId) != null) {
/*  99 */         return true;
/*     */       }
/* 101 */       return false;
/*     */     } catch (Exception e)
/*     */     {
/* 104 */       log.error("", e);
/* 105 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bczyqdqrrd"));
/*     */   }
/*     */ 
/*     */   public Map searchDeptFlowRelation(DimDeptFlowRelationForm searchForm, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   public Map findDeptFlowActions(DimDeptFlowRelation dimDeptFlowRelation, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 125 */       return this.dimDeptFlowRelationDao.findDeptFlowAction(dimDeptFlowRelation, curPage, pageSize);
/*     */     }
/*     */     catch (Exception e) {
/* 128 */       log.error("", e);
/* 129 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.yxacxsb"));
/*     */   }
/*     */ 
/*     */   public IDimDeptFlowRelationDAO getDeptFlowRelationDAO()
/*     */   {
/* 136 */     return this.dimDeptFlowRelationDao;
/*     */   }
/*     */ 
/*     */   public void setDeptFlowRelationDAO(IDimDeptFlowRelationDAO dimDeptFlowRelationDao) {
/* 140 */     this.dimDeptFlowRelationDao = dimDeptFlowRelationDao;
/*     */   }
/*     */ 
/*     */   public DimDeptFlowRelation getDeptFlowRelation(Short channelType, String channelId, int confirmType)
/*     */     throws MpmException
/*     */   {
/* 146 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimDeptFlowRelationServiceImpl
 * JD-Core Version:    0.6.2
 */
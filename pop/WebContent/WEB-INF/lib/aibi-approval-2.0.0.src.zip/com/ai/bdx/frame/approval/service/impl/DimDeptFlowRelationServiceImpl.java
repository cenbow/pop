package com.ai.bdx.frame.approval.service.impl;


import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.dao.IDimDeptFlowRelationDAO;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimDeptFlowRelationForm;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelation;
import com.ai.bdx.frame.approval.model.DimDeptFlowRelationId;
import com.ai.bdx.frame.approval.service.IDimDeptFlowRelationService;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

/**
 *
 * Created on 2010
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author mads
 * @version 1.0
 */
public class DimDeptFlowRelationServiceImpl implements IDimDeptFlowRelationService {
	private static Logger log = LogManager.getLogger();

	private IDimDeptFlowRelationDAO dimDeptFlowRelationDao;

	public IDimDeptFlowRelationDAO getDimDeptFlowRelationDao() {
		return dimDeptFlowRelationDao;
	}

	public void setDimDeptFlowRelationDao(
			IDimDeptFlowRelationDAO dimDeptFlowRelationDao) {
		this.dimDeptFlowRelationDao = dimDeptFlowRelationDao;
	}

	public DimDeptFlowRelationServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void delete(DimDeptFlowRelationId dimDeptFlowRelationId) throws MpmException {
//		// TODO Auto-generated method stub
//		DimDeptFlowRelationId ddfr=new DimDeptFlowRelationId();
//		ddfr.setCampDrvId(baseForm.getCampDrvId());
//		ddfr.setCityId(baseForm.getCityId());
//		ddfr.setDeptId(baseForm.getDeptId());
//		ddfr.setRelationType(baseForm.getRelationType());
//		ddfr.setFlow_type(baseForm.getFlow_type());
//		ddfr.setApproveFlowId(baseForm.getApproveFlowId());
		DimDeptFlowRelation rel = dimDeptFlowRelationDao.findById(dimDeptFlowRelationId);
		if (rel == null) {
			throw new RuntimeException(String.format("对象【%s】没找到，无法删除", ToStringBuilder.reflectionToString(dimDeptFlowRelationId)));
		}
		dimDeptFlowRelationDao.delete(rel);

	}

	public List getAllDeptFlowRelation() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	public DimDeptFlowRelation getDeptFlowRelation(int rid, Short cType)
			throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}


	public void modify(DimDeptFlowRelationForm modifyForm) throws MpmException {
		// TODO Auto-generated method stub

	}

	/*
	 * @see com.ai.bdx.frame.approval.service.IDimDeptFlowRelationService#save(com.ai.bdx.frame.approval.model.DimDeptFlowRelation)
	 */
	public void save(DimDeptFlowRelation dimDeptFlowRelation)
			throws MpmException {
		// TODO Auto-generated method stub
		try {
			dimDeptFlowRelationDao.save(dimDeptFlowRelation);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bczyqdqrrd"));
		}
	}
	public boolean isObjectExist(DimDeptFlowRelationId dimDeptFlowRelationId) throws MpmException {
		try {
			if(dimDeptFlowRelationDao.findById(dimDeptFlowRelationId)!=null){
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bczyqdqrrd"));
		}
	}

	public Map searchDeptFlowRelation(DimDeptFlowRelationForm searchForm,
			Integer curPage, Integer pageSize) throws MpmException {
		// TODO Auto-generated method stub


		return null;
	}

	/*
	 *
	 * @see com.ai.bdx.frame.approval.service.IMpmCampBaseInfoService#findMpmCampActions(com.ai.bdx.frame.approval.model.MtlCampBaseinfo, java.lang.Integer, java.lang.Integer)
	 */
	public Map findDeptFlowActions(DimDeptFlowRelation dimDeptFlowRelation, Integer curPage, Integer pageSize) throws MpmException {
		try {
	/*		DimDeptFlowRelation dimDeptFlow = new DimDeptFlowRelation();
			dimDeptFlow = dimDeptFlowRelation;*/
			Map map = dimDeptFlowRelationDao.findDeptFlowAction(dimDeptFlowRelation, curPage, pageSize);
			return map;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.yxacxsb"));
		}
	}



	public IDimDeptFlowRelationDAO getDeptFlowRelationDAO() {
		return dimDeptFlowRelationDao;
	}

	public void setDeptFlowRelationDAO(IDimDeptFlowRelationDAO dimDeptFlowRelationDao) {
		this.dimDeptFlowRelationDao = dimDeptFlowRelationDao;
	}

	public DimDeptFlowRelation getDeptFlowRelation(Short channelType,
			String channelId, int confirmType) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}



}

package com.ai.bdx.frame.approval.service.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IUserCompany;

public class DimDeptIdNameMapper extends IdNameMapperImpl {

	private static Logger log = LogManager.getLogger();
	// private IUserDeptDao dao;
	private IUserPrivilegeCommonService mpmUserPrivilegeService;

	List itemList;

	public DimDeptIdNameMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(DimDeptIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = "--";
		try {
			IUserCompany uc = mpmUserPrivilegeService.getUserCompanyById(id.toString());
			if (uc != null) {
				name = uc.getTitle();
			}
			super.putSimpleCacheMap(DimDeptIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("", e);
		}
		return name;
	}

	public List getAll() {
		try {
			if (itemList == null) {

				Iterator<IUserCompany> it = mpmUserPrivilegeService.getAllUserCompany().iterator();
				IUserCompany uc = null;
				while (it.hasNext()) {
					uc = it.next();
					itemList.add(new LabelValueBean(uc.getTitle(), uc.getDeptid().toString()));
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return itemList;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public IUserPrivilegeCommonService getMpmUserPrivilegeService() {
		return mpmUserPrivilegeService;
	}

	public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
		this.mpmUserPrivilegeService = mpmUserPrivilegeService;
	}

}

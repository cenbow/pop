/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*    */ import com.asiainfo.biframe.privilege.IUserCompany;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class DimDeptIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 15 */   private static Logger log = LogManager.getLogger();
/*    */   private IUserPrivilegeCommonService mpmUserPrivilegeService;
/*    */   List itemList;
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 27 */     Object value = super.getSimpleCacheMapValue(DimDeptIdNameMapper.class, id);
/* 28 */     if (value != null) {
/* 29 */       return value.toString();
/*    */     }
/* 31 */     String name = "--";
/*    */     try {
/* 33 */       IUserCompany uc = this.mpmUserPrivilegeService.getUserCompanyById(id.toString());
/* 34 */       if (uc != null) {
/* 35 */         name = uc.getTitle();
/*    */       }
/* 37 */       super.putSimpleCacheMap(DimDeptIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 39 */       log.error("", e);
/*    */     }
/* 41 */     return name;
/*    */   }
/*    */ 
/*    */   public List getAll() {
/*    */     try {
/* 46 */       if (this.itemList == null)
/*    */       {
/* 48 */         Iterator it = this.mpmUserPrivilegeService.getAllUserCompany().iterator();
/* 49 */         IUserCompany uc = null;
/* 50 */         while (it.hasNext()) {
/* 51 */           uc = (IUserCompany)it.next();
/* 52 */           this.itemList.add(new LabelValueBean(uc.getTitle(), uc.getDeptid().toString()));
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 56 */       log.error("", e);
/*    */     }
/* 58 */     return this.itemList;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 63 */     return null;
/*    */   }
/*    */ 
/*    */   public IUserPrivilegeCommonService getMpmUserPrivilegeService() {
/* 67 */     return this.mpmUserPrivilegeService;
/*    */   }
/*    */ 
/*    */   public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
/* 71 */     this.mpmUserPrivilegeService = mpmUserPrivilegeService;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimDeptIdNameMapper
 * JD-Core Version:    0.6.2
 */
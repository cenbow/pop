package com.ai.bdx.frame.approval.service.impl;


import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChannelForm;
import com.ai.bdx.frame.approval.model.DimMtlChannel;
import com.ai.bdx.frame.approval.service.IDimMtlChannelService;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

/**
 *
 * Created on 2008-3-7
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author qixf
 * @version 1.0
 */
public class DimMtlChannelServiceImpl implements IDimMtlChannelService {
	private static Logger log = LogManager.getLogger();

	private IDimMtlChannelDao dimMtlChannelDao;



	public DimMtlChannelServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}



	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#save(com.ai.bdx.frame.approval.model.DimChannelUserRelation)
	 */
	public void save(DimMtlChannel dimMtlChannel) throws MpmException {
		// TODO 自动生成方法存根
		try {
			dimMtlChannelDao.save(dimMtlChannel);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcqdxxdyxx"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#searchChannelUserRelation(com.ai.bdx.frame.approval.form.DimChannelUserRelationForm)
	 */
	public Map searchMtlChannel(DimMtlChannelForm searchForm, Integer curPage, Integer pageSize) throws MpmException {
		// TODO 自动生成方法存根
		try {
			
			return  dimMtlChannelDao.searchMtlChannel(searchForm, curPage, pageSize);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqdxxdyxx"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#getChannelUserRelation(int, java.lang.Short)
	 */
	public DimMtlChannel getMtlChannel(String ChannelId) throws MpmException {
		// TODO 自动生成方法存根
		try {
			return dimMtlChannelDao.getMtlChannel(ChannelId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdxxdyxxs"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#delete(com.ai.bdx.frame.approval.form.DimChannelUserRelationForm)
	 */
	public void delete(DimMtlChannelForm searchForm) throws MpmException {
		// TODO 自动生成方法存根
		try {
			dimMtlChannelDao.delete(searchForm);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scqdxxdyxx"));
		}
	}

	/*public List<DimChannelSendType> getAllSmsSendType() throws MpmException {
		List<DimChannelSendType> list = new ArrayList<DimChannelSendType>();
		try {
			list = channelSendTypeDao.getAllSmsSendType(MpmCONST.CHANNEL_TYPE_SMS);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.dqdxfsfssb"));
		}

		return list;
	}*/

	/**
	 * @return dimMtlChannelDao
	 */
	public IDimMtlChannelDao getDimMtlChannelDao() {
		return dimMtlChannelDao;
	}

	/**
	 * @param dimMtlChannelDao 要设置的 dimMtlChannelDao
	 */
	public void setDimMtlChannelDao(IDimMtlChannelDao dimMtlChannelDao) {
		this.dimMtlChannelDao = dimMtlChannelDao;
	}



	@Override
	public List getAllMmsContentByType(String typeId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public List getAllMmsType() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public List<LabelValueBean> getBsChannelsByType(String channelType)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public List findWebSiteInfo(String classId, String searchKeyWords,
			int pageNo, int countPerPage) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void saveCampsegIdWebSiteInfoIdClassIdRel(String campsegId,
			String webSiteInfoIdClassIdRel) {
		// TODO Auto-generated method stub
		
	}

	/*public List getAllMmsContentByType(String typeId) throws Exception {
		List list =  dimMtlChannelDao.getAllMmsContentByType(typeId);
		List result = new ArrayList();

		if(list != null && !list.isEmpty()) {
			String name = dimMtlChannelDao.getTypeName(typeId);
			TreeNode root = new TreeNode();
			root.setId(typeId);
			root.setText(name);
			root.setPid("-2");
			result.add(root);

			for(Iterator it = list.iterator(); it.hasNext(); ) {
				BsMmsContent content = (BsMmsContent) it.next();
				if(content != null) {
					TreeNode node = new TreeNode();
					node.setId(content.getId());
					node.setText(content.getName());
					node.setPid(typeId);
					node.setLeaf(true);
					result.add(node);
				}
			}
		}

		return result;
	}*/

	/*public List getAllMmsType() throws Exception {
		List list =  dimMtlChannelDao.getAllMmsType();

		List result = new ArrayList();
		if(list != null) {
			for(Iterator it = list.iterator(); it.hasNext(); ) {
				BsMmsType type = (BsMmsType) it.next();
				if(type != null) {
					TreeNode node = new TreeNode();
					node.setId(type.getId());
					node.setText(type.getName());
					node.setPid(type.getParentId());
					node.setHref("mpmCampSegMaintain.aido?cmd=getMms&typeId=" + type.getId());
					result.add(node);
				}
			}
		}

		return result;
	}

	public List<LabelValueBean> getBsChannelsByType(String channelType) throws Exception {
		List list = dimMtlChannelDao.getBsChannelsByType(channelType);
		List<LabelValueBean> result = new ArrayList<LabelValueBean>();
		if(list != null) {
			for(Iterator it = list.iterator(); it.hasNext(); ) {
				BsChannel bs = (BsChannel) it.next();
				if(bs != null) {
					LabelValueBean label = new LabelValueBean();
					label.setLabel(bs.getName());
					label.setValue(bs.getId());
					result.add(label);
				}
			}
		}

		return result;
	}
*/
	/*public List<DimMtlChannelExtend> getChannelExtendInfo(String channelType) {
		try {
			return channelExtendDao.queryChannelExtendByChannelType(channelType);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("",e);
			return null;
		}
	}*/
	
	/**
	 * 获取网站分类大类
	 * @return
	 */
	/*public List<DimUrlRule> getWebClasses() {
		try {
			return channelExtendDao.getWebClasses();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("",e);
			return null;
		}
	}*/

	/**
	 * 获取查询关键字对应的内容站点信息等
	 * @param classId 网站分类
	 * @param searchKeyWords 搜索关键字
	 * @param pageNo 当前页（第一页的标识是1，不是0）
	 * @param countPerPage（每页显示多少行数据）
	 * @return list 如果查询到数据，则list包含两个内容：数据行数、存放数据的list；没有查到数据，则只含有一个数据行数
	 */
	/*public List findWebSiteInfo(String classId, String searchKeyWords, int pageNo, int countPerPage) {
		try {
			return channelExtendDao.findWebSiteInfo(classId, searchKeyWords, pageNo, countPerPage);
		} catch (Exception e) {
			log.error("",e);
			return null;
		}
	}*/
	
	/**
	 * 保存活动规则与关键字对应内容的站点信息等关联
	 * @param campsegId 活动规则Id
	 * @param webSiteInfoIdClassIdRel 关键字对应的站点信息Id和网站分类Id的关联信息(json字符串)
	 */
	/*public void saveCampsegIdWebSiteInfoIdClassIdRel(String campsegId, String webSiteInfoIdClassIdRel) {
		List<MtlCampsegSiteCategoryRel> list = new ArrayList<MtlCampsegSiteCategoryRel>();
		try {
			JSONArray result = JSONArray.fromObject(webSiteInfoIdClassIdRel);
			JSONObject jsonObject = null;
			String siteCategoryId = null;
			String classId = null;
			MtlCampsegSiteCategoryRel mtlCampsegSiteCategoryRel = null;
			for (int i = 0; i < result.size(); i++) {
				jsonObject = result.getJSONObject(i);
				siteCategoryId = jsonObject.get("siteCategoryId").toString();
				classId = jsonObject.get("classId").toString();
				mtlCampsegSiteCategoryRel = new MtlCampsegSiteCategoryRel(campsegId, siteCategoryId, classId);
				list.add(mtlCampsegSiteCategoryRel);
			}
			channelExtendDao.saveCampsegIdWebSiteInfoIdClassIdRel(campsegId, list);
		} catch (Exception e) {
			log.error("保存活动规则、网站分类和关键字对应内容站点关联失败!",e);
		}
	}*/
	
	/**
	 * 获取与活动规则相关的内容站点和网站分类信息
	 * @param campsegId
	 * @return
	 */
	/*public List<MtlCampsegSiteCategoryRel> getSiteCateGoryIdClassIdRel(String campsegId) {
		try {
			return channelExtendDao.getSiteCateGoryIdClassIdRel(campsegId);
		} catch (Exception e) {
			log.error("",e);
			return null;
		}
	}*/

}

/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.form.DimMtlChannelForm;
/*     */ import com.ai.bdx.frame.approval.model.DimMtlChannel;
/*     */ import com.ai.bdx.frame.approval.service.IDimMtlChannelService;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ 
/*     */ public class DimMtlChannelServiceImpl
/*     */   implements IDimMtlChannelService
/*     */ {
/*  28 */   private static Logger log = LogManager.getLogger();
/*     */   private IDimMtlChannelDao dimMtlChannelDao;
/*     */ 
/*     */   public void save(DimMtlChannel dimMtlChannel)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  47 */       this.dimMtlChannelDao.save(dimMtlChannel);
/*     */     } catch (Exception e) {
/*  49 */       log.error("", e);
/*  50 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcqdxxdyxx"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map searchMtlChannel(DimMtlChannelForm searchForm, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  61 */       return this.dimMtlChannelDao.searchMtlChannel(searchForm, curPage, pageSize);
/*     */     } catch (Exception e) {
/*  63 */       log.error("", e);
/*  64 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqdxxdyxx"));
/*     */   }
/*     */ 
/*     */   public DimMtlChannel getMtlChannel(String ChannelId)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  74 */       return this.dimMtlChannelDao.getMtlChannel(ChannelId);
/*     */     } catch (Exception e) {
/*  76 */       log.error("", e);
/*  77 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdxxdyxxs"));
/*     */   }
/*     */ 
/*     */   public void delete(DimMtlChannelForm searchForm)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  87 */       this.dimMtlChannelDao.delete(searchForm);
/*     */     } catch (Exception e) {
/*  89 */       log.error("", e);
/*  90 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scqdxxdyxx"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public IDimMtlChannelDao getDimMtlChannelDao()
/*     */   {
/* 110 */     return this.dimMtlChannelDao;
/*     */   }
/*     */ 
/*     */   public void setDimMtlChannelDao(IDimMtlChannelDao dimMtlChannelDao)
/*     */   {
/* 117 */     this.dimMtlChannelDao = dimMtlChannelDao;
/*     */   }
/*     */ 
/*     */   public List getAllMmsContentByType(String typeId)
/*     */     throws Exception
/*     */   {
/* 125 */     return null;
/*     */   }
/*     */ 
/*     */   public List getAllMmsType()
/*     */     throws Exception
/*     */   {
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   public List<LabelValueBean> getBsChannelsByType(String channelType)
/*     */     throws Exception
/*     */   {
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */   public List findWebSiteInfo(String classId, String searchKeyWords, int pageNo, int countPerPage)
/*     */   {
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */   public void saveCampsegIdWebSiteInfoIdClassIdRel(String campsegId, String webSiteInfoIdClassIdRel)
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimMtlChannelServiceImpl
 * JD-Core Version:    0.6.2
 */
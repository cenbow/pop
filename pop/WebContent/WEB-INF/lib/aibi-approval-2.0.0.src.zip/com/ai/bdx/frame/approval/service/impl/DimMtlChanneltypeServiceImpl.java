/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm;
/*     */ import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
/*     */ import com.ai.bdx.frame.approval.service.IDimMtlChanneltypeService;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ 
/*     */ public class DimMtlChanneltypeServiceImpl
/*     */   implements IDimMtlChanneltypeService
/*     */ {
/*  31 */   private static Logger log = LogManager.getLogger();
/*     */   private IDimMtlChanneltypeDao dimMtlChanneltypeDao;
/*     */ 
/*     */   public void save(DimMtlChanneltype dimMtlChanneltype)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  46 */       this.dimMtlChanneltypeDao.save(dimMtlChanneltype);
/*     */     } catch (Exception e) {
/*  48 */       log.error("", e);
/*  49 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcqdlxdyxx1"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map searchMtlChanneltype(DimMtlChanneltypeForm searchForm, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  59 */       return this.dimMtlChanneltypeDao.searchMtlChanneltype(searchForm, curPage, pageSize);
/*     */     } catch (Exception e) {
/*  61 */       log.error("", e);
/*  62 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqdlxdyxx"));
/*     */   }
/*     */ 
/*     */   public DimMtlChanneltype getMtlChanneltype(Short Channeltype)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  72 */       return this.dimMtlChanneltypeDao.getMtlChanneltype(Channeltype);
/*     */     } catch (Exception e) {
/*  74 */       log.error("", e);
/*  75 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdlxdyxxs"));
/*     */   }
/*     */ 
/*     */   public void delete(DimMtlChanneltypeForm searchForm)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  85 */       this.dimMtlChanneltypeDao.delete(searchForm);
/*     */     } catch (Exception e) {
/*  87 */       log.error("", e);
/*  88 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scqdlxdyxx1"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public IDimMtlChanneltypeDao getDimMtlChanneltypeDao()
/*     */   {
/*  96 */     return this.dimMtlChanneltypeDao;
/*     */   }
/*     */ 
/*     */   public void setDimMtlChanneltypeDao(IDimMtlChanneltypeDao dimMtlChanneltypeDao)
/*     */   {
/* 103 */     this.dimMtlChanneltypeDao = dimMtlChanneltypeDao;
/*     */   }
/*     */ 
/*     */   public Integer getSendOddTypeByChannelType(Integer ChannelTypeId)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 111 */       return this.dimMtlChanneltypeDao.getSendOddTypeByChannelType(ChannelTypeId);
/*     */     } catch (Exception e) {
/* 113 */       log.error("", e);
/* 114 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scqdlxdyxx1"));
/*     */   }
/*     */ 
/*     */   public List getMtlChannelTypeList()
/*     */     throws Exception
/*     */   {
/* 121 */     List list = this.dimMtlChanneltypeDao.getAllChannelType(null);
/* 122 */     Iterator _li = list.iterator();
/* 123 */     list = new ArrayList();
/* 124 */     while (_li.hasNext()) {
/* 125 */       DimMtlChanneltype dimMtlChanneltype = (DimMtlChanneltype)_li.next();
/* 126 */       list.add(new LabelValueBean(dimMtlChanneltype.getChanneltypeName(), dimMtlChanneltype.getChanneltypeId() + ""));
/*     */     }
/* 128 */     return list;
/*     */   }
/*     */ 
/*     */   public List getAllChannelTypeForSys(String SysId) throws MpmException {
/* 132 */     List list = this.dimMtlChanneltypeDao.getAllChannelTypeForSys(SysId);
/* 133 */     Iterator _li = list.iterator();
/* 134 */     list = new ArrayList();
/* 135 */     while (_li.hasNext()) {
/* 136 */       DimMtlChanneltype dimMtlChanneltype = (DimMtlChanneltype)_li.next();
/* 137 */       list.add(new LabelValueBean(dimMtlChanneltype.getChanneltypeName(), dimMtlChanneltype.getChanneltypeId() + ""));
/*     */     }
/* 139 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimMtlChanneltypeServiceImpl
 * JD-Core Version:    0.6.2
 */
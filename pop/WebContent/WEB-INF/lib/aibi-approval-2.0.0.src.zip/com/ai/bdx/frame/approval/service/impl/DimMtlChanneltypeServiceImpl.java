package com.ai.bdx.frame.approval.service.impl;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.DimMtlChanneltypeForm;
import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
import com.ai.bdx.frame.approval.service.IDimMtlChanneltypeService;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

/**
 *
 * Created on 2008-3-7
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author qixf
 * @version 1.0
 */
public class DimMtlChanneltypeServiceImpl implements IDimMtlChanneltypeService {
	private static Logger log = LogManager.getLogger();

	private IDimMtlChanneltypeDao dimMtlChanneltypeDao;

	public DimMtlChanneltypeServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#save(com.ai.bdx.frame.approval.model.DimChannelUserRelation)
	 */
	public void save(DimMtlChanneltype dimMtlChanneltype) throws MpmException {
		// TODO 自动生成方法存根
		try {
			dimMtlChanneltypeDao.save(dimMtlChanneltype);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcqdlxdyxx1"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#searchChannelUserRelation(com.ai.bdx.frame.approval.form.DimChannelUserRelationForm)
	 */
	public Map searchMtlChanneltype(DimMtlChanneltypeForm searchForm, Integer curPage, Integer pageSize) throws MpmException {
		// TODO 自动生成方法存根
		try {
			return dimMtlChanneltypeDao.searchMtlChanneltype(searchForm, curPage, pageSize);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqdlxdyxx"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#getChannelUserRelation(int, java.lang.Short)
	 */
	public DimMtlChanneltype getMtlChanneltype(Short Channeltype) throws MpmException {
		// TODO 自动生成方法存根
		try {
			return dimMtlChanneltypeDao.getMtlChanneltype(Channeltype);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdlxdyxxs"));
		}
	}

	/* （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IDimChannelUserRelationService#delete(com.ai.bdx.frame.approval.form.DimChannelUserRelationForm)
	 */
	public void delete(DimMtlChanneltypeForm searchForm) throws MpmException {
		// TODO 自动生成方法存根
		try {
			dimMtlChanneltypeDao.delete(searchForm);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scqdlxdyxx1"));
		}
	}

	/**
	 * @return dimMtlChanneltypeDao
	 */
	public IDimMtlChanneltypeDao getDimMtlChanneltypeDao() {
		return dimMtlChanneltypeDao;
	}

	/**
	 * @param dimMtlChanneltypeDao 要设置的 dimMtlChanneltypeDao
	 */
	public void setDimMtlChanneltypeDao(IDimMtlChanneltypeDao dimMtlChanneltypeDao) {
		this.dimMtlChanneltypeDao = dimMtlChanneltypeDao;
	}

	public Integer getSendOddTypeByChannelType(Integer ChannelTypeId)
			throws MpmException {
		// TODO Auto-generated method stub

		try {
			return dimMtlChanneltypeDao.getSendOddTypeByChannelType(ChannelTypeId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scqdlxdyxx1"));
		}
	}

	
	
	public List getMtlChannelTypeList() throws Exception {
		List list = dimMtlChanneltypeDao.getAllChannelType(null);
		Iterator _li = list.iterator();
		list = new ArrayList();
		while (_li.hasNext()) {
			DimMtlChanneltype dimMtlChanneltype = (DimMtlChanneltype) _li.next();
			list.add(new LabelValueBean(dimMtlChanneltype.getChanneltypeName(), dimMtlChanneltype.getChanneltypeId()+""));
		}
		return list;
	}
	
	public List getAllChannelTypeForSys(String SysId) throws MpmException {
		List list = dimMtlChanneltypeDao.getAllChannelTypeForSys(SysId);
		Iterator _li = list.iterator();
		list = new ArrayList();
		while (_li.hasNext()) {
			DimMtlChanneltype dimMtlChanneltype = (DimMtlChanneltype) _li.next();
			list.add(new LabelValueBean(dimMtlChanneltype.getChanneltypeName(), dimMtlChanneltype.getChanneltypeId()+""));
		}
		return list;
	}
}

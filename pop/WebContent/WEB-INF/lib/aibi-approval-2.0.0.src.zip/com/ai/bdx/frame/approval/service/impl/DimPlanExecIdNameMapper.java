/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao;
/*    */ import com.ai.bdx.frame.approval.model.MtlPlanExecType;
/*    */ import com.asiainfo.biframe.utils.string.StringUtil;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class DimPlanExecIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 13 */   private static Logger log = LogManager.getLogger();
/*    */   private IDimCampDrvTypeDao dao;
/*    */   List itemList;
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 24 */     Object value = super.getSimpleCacheMapValue(DimPlanExecIdNameMapper.class, id);
/*    */ 
/* 26 */     if (value != null) {
/* 27 */       return value.toString();
/*    */     }
/* 29 */     String name = "--";
/* 30 */     if (StringUtil.isEmpty(id))
/* 31 */       return name;
/*    */     try
/*    */     {
/* 34 */       MtlPlanExecType obj = this.dao.getPlanExecById(id.toString());
/* 35 */       if ((obj != null) && (obj.getPlanExecName() != null)) {
/* 36 */         name = obj.getPlanExecName();
/*    */       }
/* 38 */       super.putSimpleCacheMap(DimPlanExecIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 40 */       log.error("", e);
/*    */     }
/* 42 */     return name;
/*    */   }
/*    */ 
/*    */   public List getAll() {
/*    */     try {
/* 47 */       if (this.itemList == null)
/*    */       {
/* 49 */         Iterator it = this.dao.findPlanExecAll().iterator();
/*    */ 
/* 51 */         while (it.hasNext()) {
/* 52 */           MtlPlanExecType obj = (MtlPlanExecType)it.next();
/* 53 */           this.itemList.add(new LabelValueBean(obj.getPlanExecName(), obj.getPlanExecId()));
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 58 */       log.error("", e);
/*    */     }
/* 60 */     return this.itemList;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */   public IDimCampDrvTypeDao getDao() {
/* 69 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IDimCampDrvTypeDao dao) {
/* 73 */     this.dao = dao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimPlanExecIdNameMapper
 * JD-Core Version:    0.6.2
 */
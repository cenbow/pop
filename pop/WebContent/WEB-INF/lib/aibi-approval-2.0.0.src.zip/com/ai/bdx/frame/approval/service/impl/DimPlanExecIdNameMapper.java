package com.ai.bdx.frame.approval.service.impl;

import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao;
import com.ai.bdx.frame.approval.model.MtlPlanExecType;
import com.asiainfo.biframe.utils.string.StringUtil;

public class DimPlanExecIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IDimCampDrvTypeDao dao;

	List itemList;

	public DimPlanExecIdNameMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(
				DimPlanExecIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = "--";
		if (StringUtil.isEmpty(id)) {
			return name;
		}
		try {
			MtlPlanExecType obj = dao.getPlanExecById(id.toString());
			if (obj != null && obj.getPlanExecName() != null) {
				name = obj.getPlanExecName();
			}
			super.putSimpleCacheMap(DimPlanExecIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("", e);
		}
		return name;
	}

	public List getAll() {
		try {
			if (itemList == null) {

				Iterator it = dao.findPlanExecAll().iterator();
				MtlPlanExecType obj;
				while (it.hasNext()) {
					obj = (MtlPlanExecType) it.next();
					itemList.add(new LabelValueBean(obj.getPlanExecName(), obj
							.getPlanExecId()));
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return itemList;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public IDimCampDrvTypeDao getDao() {
		return dao;
	}

	public void setDao(IDimCampDrvTypeDao dao) {
		this.dao = dao;
	}

}

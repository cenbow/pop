package com.ai.bdx.frame.approval.service.impl;

import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import com.ai.bdx.frame.approval.dao.IDimPubChannelDao;
import com.ai.bdx.frame.approval.model.DimPubChannel;

public class DimPubChannelIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IDimPubChannelDao dao;

	List itemList;

	public DimPubChannelIdNameMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(
				DimPubChannelIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = id.toString();
		try {
			DimPubChannel obj = dao.getPubChannel(id.toString());
			if (obj != null) {
				name = obj.getChannelName();
			}
			super.putSimpleCacheMap(DimPubChannelIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("", e);
		}
		return name;
	}

	public List getAll() {
		try {
			if (itemList == null) {

				Iterator it = dao.getObjList().iterator();
				DimPubChannel obj;
				while (it.hasNext()) {
					obj = (DimPubChannel) it.next();
					itemList.add(new LabelValueBean(obj.getChannelName(), obj
							.getChannelId().toString()));
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return itemList;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public IDimPubChannelDao getDao() {
		return dao;
	}

	public void setDao(IDimPubChannelDao dao) {
		this.dao = dao;
	}

}

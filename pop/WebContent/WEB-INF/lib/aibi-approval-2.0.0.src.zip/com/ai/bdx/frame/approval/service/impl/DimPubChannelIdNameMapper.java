/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimPubChannelDao;
/*    */ import com.ai.bdx.frame.approval.model.DimPubChannel;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class DimPubChannelIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 12 */   private static Logger log = LogManager.getLogger();
/*    */   private IDimPubChannelDao dao;
/*    */   List itemList;
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 23 */     Object value = super.getSimpleCacheMapValue(DimPubChannelIdNameMapper.class, id);
/*    */ 
/* 25 */     if (value != null) {
/* 26 */       return value.toString();
/*    */     }
/* 28 */     String name = id.toString();
/*    */     try {
/* 30 */       DimPubChannel obj = this.dao.getPubChannel(id.toString());
/* 31 */       if (obj != null) {
/* 32 */         name = obj.getChannelName();
/*    */       }
/* 34 */       super.putSimpleCacheMap(DimPubChannelIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 36 */       log.error("", e);
/*    */     }
/* 38 */     return name;
/*    */   }
/*    */ 
/*    */   public List getAll() {
/*    */     try {
/* 43 */       if (this.itemList == null)
/*    */       {
/* 45 */         Iterator it = this.dao.getObjList().iterator();
/*    */ 
/* 47 */         while (it.hasNext()) {
/* 48 */           DimPubChannel obj = (DimPubChannel)it.next();
/* 49 */           this.itemList.add(new LabelValueBean(obj.getChannelName(), obj.getChannelId().toString()));
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 54 */       log.error("", e);
/*    */     }
/* 56 */     return this.itemList;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 61 */     return null;
/*    */   }
/*    */ 
/*    */   public IDimPubChannelDao getDao() {
/* 65 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IDimPubChannelDao dao) {
/* 69 */     this.dao = dao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimPubChannelIdNameMapper
 * JD-Core Version:    0.6.2
 */
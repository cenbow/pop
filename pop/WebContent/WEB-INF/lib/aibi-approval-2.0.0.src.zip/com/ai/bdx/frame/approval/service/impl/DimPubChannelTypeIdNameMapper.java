package com.ai.bdx.frame.approval.service.impl;


import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IDimPubChannelTypeDao;
import com.ai.bdx.frame.approval.model.DimPubChanneltype;
import com.ai.bdx.frame.approval.util.MpmCache;

/*
 * Created on 7:51:30 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class DimPubChannelTypeIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IDimPubChannelTypeDao dao;

	List itemList;

	public DimPubChannelTypeIdNameMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(DimPubChannelTypeIdNameMapper.class, id);
		if(value !=null){
			return value.toString();
		}
		String name = "";
		try {
			//有些渠道类型是定义在常量文件里,需要到常量缓存里寻找
			name = MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.CHANNEL_TYPE, id.toString());

			//如果在常量缓存里寻找不到，则查询数据库
			if (name == null || name.length() < 2) {
				DimPubChanneltype obj = dao.getChanneltype(Integer.valueOf(id.toString()));
				if (obj != null) {
					name = obj.getChanneltypeName();
				}
			}
			super.putSimpleCacheMap(DimPubChannelTypeIdNameMapper.class, id,name);
		} catch (Exception e) {
log.error("",e);
		}
		return name;
	}

	public List getAll() {
		try {
			if (itemList == null) {

				Iterator it = dao.getAllChannelType().iterator();
				DimPubChanneltype obj;
				while (it.hasNext()) {
					obj = (DimPubChanneltype) it.next();
					itemList.add(new LabelValueBean(obj.getChanneltypeName(), obj.getChanneltypeId().toString()));
				}
			}
		} catch (Exception e) {
log.error("",e);
		}
		return itemList;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public IDimPubChannelTypeDao getDao() {
		return dao;
	}

	public void setDao(IDimPubChannelTypeDao dao) {
		this.dao = dao;
	}

}

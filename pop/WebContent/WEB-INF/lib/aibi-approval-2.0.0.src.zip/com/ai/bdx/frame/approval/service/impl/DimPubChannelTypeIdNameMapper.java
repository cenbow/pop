/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimPubChannelTypeDao;
/*    */ import com.ai.bdx.frame.approval.model.DimPubChanneltype;
/*    */ import com.ai.bdx.frame.approval.util.MpmCache;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class DimPubChannelTypeIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 25 */   private static Logger log = LogManager.getLogger();
/*    */   private IDimPubChannelTypeDao dao;
/*    */   List itemList;
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 36 */     Object value = super.getSimpleCacheMapValue(DimPubChannelTypeIdNameMapper.class, id);
/* 37 */     if (value != null) {
/* 38 */       return value.toString();
/*    */     }
/* 40 */     String name = "";
/*    */     try
/*    */     {
/* 43 */       name = MpmCache.getInstance().getNameByTypeAndKey("channel_type", id.toString());
/*    */ 
/* 46 */       if ((name == null) || (name.length() < 2)) {
/* 47 */         DimPubChanneltype obj = this.dao.getChanneltype(Integer.valueOf(id.toString()));
/* 48 */         if (obj != null) {
/* 49 */           name = obj.getChanneltypeName();
/*    */         }
/*    */       }
/* 52 */       super.putSimpleCacheMap(DimPubChannelTypeIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 54 */       log.error("", e);
/*    */     }
/* 56 */     return name;
/*    */   }
/*    */ 
/*    */   public List getAll() {
/*    */     try {
/* 61 */       if (this.itemList == null)
/*    */       {
/* 63 */         Iterator it = this.dao.getAllChannelType().iterator();
/*    */ 
/* 65 */         while (it.hasNext()) {
/* 66 */           DimPubChanneltype obj = (DimPubChanneltype)it.next();
/* 67 */           this.itemList.add(new LabelValueBean(obj.getChanneltypeName(), obj.getChanneltypeId().toString()));
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 71 */       log.error("", e);
/*    */     }
/* 73 */     return this.itemList;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 78 */     return null;
/*    */   }
/*    */ 
/*    */   public IDimPubChannelTypeDao getDao() {
/* 82 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IDimPubChannelTypeDao dao) {
/* 86 */     this.dao = dao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimPubChannelTypeIdNameMapper
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.ICity;
import com.asiainfo.biframe.utils.config.Configure;
import com.asiainfo.biframe.utils.string.StringUtil;

/*
 * Created on 5:33:53 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
@SuppressWarnings("deprecation")
public class DimPubCityIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IUserPrivilegeCommonService mpmUserPrivilegeService;

	public IUserPrivilegeCommonService getMpmUserPrivilegeService() {
		return mpmUserPrivilegeService;
	}

	public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
		this.mpmUserPrivilegeService = mpmUserPrivilegeService;
	}

	public DimPubCityIdNameMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(DimPubCityIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = id.toString();
		try {
			ICity city = mpmUserPrivilegeService.getCityById(id.toString());
			if (city != null) {
				String PROVINCE = Configure.getInstance().getProperty("PROVINCE");
				String pid = "beijing".equalsIgnoreCase(PROVINCE) && "999".equals(id) ? "-1" : city.getParentId();
				if (StringUtil.isNotEmpty(pid) && !"-1".equals(pid) && !pid.equals(id)) {
					name = this.getNameById(pid) + " - " + city.getCityName();
				} else {
					name = city.getCityName();
				}
			}
			super.putSimpleCacheMap(DimPubCityIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("getNameById error:", e);
		}
		return name;
	}

	public List<?> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}
}

/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*    */ import com.asiainfo.biframe.privilege.ICity;
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import com.asiainfo.biframe.utils.string.StringUtil;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class DimPubCityIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 25 */   private static Logger log = LogManager.getLogger();
/*    */   private IUserPrivilegeCommonService mpmUserPrivilegeService;
/*    */ 
/*    */   public IUserPrivilegeCommonService getMpmUserPrivilegeService()
/*    */   {
/* 29 */     return this.mpmUserPrivilegeService;
/*    */   }
/*    */ 
/*    */   public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
/* 33 */     this.mpmUserPrivilegeService = mpmUserPrivilegeService;
/*    */   }
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 42 */     Object value = super.getSimpleCacheMapValue(DimPubCityIdNameMapper.class, id);
/* 43 */     if (value != null) {
/* 44 */       return value.toString();
/*    */     }
/* 46 */     String name = id.toString();
/*    */     try {
/* 48 */       ICity city = this.mpmUserPrivilegeService.getCityById(id.toString());
/* 49 */       if (city != null) {
/* 50 */         String PROVINCE = Configure.getInstance().getProperty("PROVINCE");
/* 51 */         String pid = ("beijing".equalsIgnoreCase(PROVINCE)) && ("999".equals(id)) ? "-1" : city.getParentId();
/* 52 */         if ((StringUtil.isNotEmpty(pid)) && (!"-1".equals(pid)) && (!pid.equals(id)))
/* 53 */           name = getNameById(pid) + " - " + city.getCityName();
/*    */         else {
/* 55 */           name = city.getCityName();
/*    */         }
/*    */       }
/* 58 */       super.putSimpleCacheMap(DimPubCityIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 60 */       log.error("getNameById error:", e);
/*    */     }
/* 62 */     return name;
/*    */   }
/*    */ 
/*    */   public List<?> getAll()
/*    */   {
/* 67 */     return null;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 72 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimPubCityIdNameMapper
 * JD-Core Version:    0.6.2
 */
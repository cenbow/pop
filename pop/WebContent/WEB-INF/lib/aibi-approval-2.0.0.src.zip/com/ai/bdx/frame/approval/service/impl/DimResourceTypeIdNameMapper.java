package com.ai.bdx.frame.approval.service.impl;

import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import com.ai.bdx.frame.approval.dao.IMtlApproveResourceTypeDao;
import com.ai.bdx.frame.approval.model.MtlApproveResourceType;

/*
 * Created on 6:32:07 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author chenlc
 * @version 1.0
 */
public class DimResourceTypeIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IMtlApproveResourceTypeDao dao;

	List itemList;

	public DimResourceTypeIdNameMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(
				DimResourceTypeIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = "";
		try {
			MtlApproveResourceType obj = dao.getRourceById(Integer.valueOf(id
					.toString()));
			if (obj != null) {
				name = obj.getResourceName();
			}
			super.putSimpleCacheMap(DimResourceTypeIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("", e);
		}
		return name;
	}

	public List getAll() {
		try {
			if (itemList == null) {

				Iterator it = dao.findAll().iterator();
				MtlApproveResourceType obj;
				while (it.hasNext()) {
					obj = (MtlApproveResourceType) it.next();
					itemList.add(new LabelValueBean(obj.getResourceName(), obj
							.getResourceId().toString()));
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return itemList;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public IMtlApproveResourceTypeDao getDao() {
		return dao;
	}

	public void setDao(IMtlApproveResourceTypeDao dao) {
		this.dao = dao;
	}

}

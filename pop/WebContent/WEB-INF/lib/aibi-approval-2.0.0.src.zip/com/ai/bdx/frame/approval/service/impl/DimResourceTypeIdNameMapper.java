/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IMtlApproveResourceTypeDao;
/*    */ import com.ai.bdx.frame.approval.model.MtlApproveResourceType;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class DimResourceTypeIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 22 */   private static Logger log = LogManager.getLogger();
/*    */   private IMtlApproveResourceTypeDao dao;
/*    */   List itemList;
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 33 */     Object value = super.getSimpleCacheMapValue(DimResourceTypeIdNameMapper.class, id);
/*    */ 
/* 35 */     if (value != null) {
/* 36 */       return value.toString();
/*    */     }
/* 38 */     String name = "";
/*    */     try {
/* 40 */       MtlApproveResourceType obj = this.dao.getRourceById(Integer.valueOf(id.toString()));
/*    */ 
/* 42 */       if (obj != null) {
/* 43 */         name = obj.getResourceName();
/*    */       }
/* 45 */       super.putSimpleCacheMap(DimResourceTypeIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 47 */       log.error("", e);
/*    */     }
/* 49 */     return name;
/*    */   }
/*    */ 
/*    */   public List getAll() {
/*    */     try {
/* 54 */       if (this.itemList == null)
/*    */       {
/* 56 */         Iterator it = this.dao.findAll().iterator();
/*    */ 
/* 58 */         while (it.hasNext()) {
/* 59 */           MtlApproveResourceType obj = (MtlApproveResourceType)it.next();
/* 60 */           this.itemList.add(new LabelValueBean(obj.getResourceName(), obj.getResourceId().toString()));
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 65 */       log.error("", e);
/*    */     }
/* 67 */     return this.itemList;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 72 */     return null;
/*    */   }
/*    */ 
/*    */   public IMtlApproveResourceTypeDao getDao() {
/* 76 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IMtlApproveResourceTypeDao dao) {
/* 80 */     this.dao = dao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimResourceTypeIdNameMapper
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IUser;

public class DimUserIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();

	IUserPrivilegeCommonService mpmUserPrivilegeService;

	List itemList;

	public DimUserIdNameMapper() {
		super();
	}

	public IUserPrivilegeCommonService getMpmUserPrivilegeService() {
		return mpmUserPrivilegeService;
	}

	public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
		this.mpmUserPrivilegeService = mpmUserPrivilegeService;
	}

	public String getNameById(Object id) {
		Object value = super.getSimpleCacheMapValue(DimUserIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}
		String name = "";
		try {
			IUser obj = mpmUserPrivilegeService.getUser(id.toString());
			if (obj != null) {
				name = obj.getUsername();
			}
			super.putSimpleCacheMap(DimUserIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("", e);
		}
		return name;
	}

	public List getAll() {
		try {
			if (itemList == null) {
				Iterator it = mpmUserPrivilegeService.getAllUser().iterator();
				IUser obj;
				while (it.hasNext()) {
					obj = (IUser) it.next();
					itemList.add(new LabelValueBean(obj.getUsername(), obj.getUserid().toString()));
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return itemList;
	}

	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}
}

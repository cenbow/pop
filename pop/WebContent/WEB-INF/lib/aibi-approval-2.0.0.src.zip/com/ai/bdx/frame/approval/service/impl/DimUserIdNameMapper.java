/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*    */ import com.asiainfo.biframe.privilege.IUser;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class DimUserIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 14 */   private static Logger log = LogManager.getLogger();
/*    */   IUserPrivilegeCommonService mpmUserPrivilegeService;
/*    */   List itemList;
/*    */ 
/*    */   public IUserPrivilegeCommonService getMpmUserPrivilegeService()
/*    */   {
/* 25 */     return this.mpmUserPrivilegeService;
/*    */   }
/*    */ 
/*    */   public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
/* 29 */     this.mpmUserPrivilegeService = mpmUserPrivilegeService;
/*    */   }
/*    */ 
/*    */   public String getNameById(Object id) {
/* 33 */     Object value = super.getSimpleCacheMapValue(DimUserIdNameMapper.class, id);
/* 34 */     if (value != null) {
/* 35 */       return value.toString();
/*    */     }
/* 37 */     String name = "";
/*    */     try {
/* 39 */       IUser obj = this.mpmUserPrivilegeService.getUser(id.toString());
/* 40 */       if (obj != null) {
/* 41 */         name = obj.getUsername();
/*    */       }
/* 43 */       super.putSimpleCacheMap(DimUserIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 45 */       log.error("", e);
/*    */     }
/* 47 */     return name;
/*    */   }
/*    */ 
/*    */   public List getAll() {
/*    */     try {
/* 52 */       if (this.itemList == null) {
/* 53 */         Iterator it = this.mpmUserPrivilegeService.getAllUser().iterator();
/*    */ 
/* 55 */         while (it.hasNext()) {
/* 56 */           IUser obj = (IUser)it.next();
/* 57 */           this.itemList.add(new LabelValueBean(obj.getUsername(), obj.getUserid().toString()));
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 61 */       log.error("", e);
/*    */     }
/* 63 */     return this.itemList;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 68 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.DimUserIdNameMapper
 * JD-Core Version:    0.6.2
 */
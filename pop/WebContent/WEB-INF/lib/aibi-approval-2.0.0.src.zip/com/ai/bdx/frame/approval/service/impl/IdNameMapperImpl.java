package com.ai.bdx.frame.approval.service.impl;

import com.ai.bdx.frame.approval.jms.util.JmsConstant;
import com.ai.bdx.frame.approval.jms.util.SimpleCache;
import com.asiainfo.biframe.service.IdNameMapper;

public abstract class IdNameMapperImpl implements IdNameMapper {

	public Object getSimpleCacheMapValue(Class clazz, Object id) {
		return SimpleCache.getInstance().get(clazz.getCanonicalName() + id);
	}

	public void putSimpleCacheMap(Class clazz, Object id, Object value) {
		SimpleCache.getInstance().put(clazz.getCanonicalName() + id, value,
				JmsConstant.CACHE_TIME);

	}

}

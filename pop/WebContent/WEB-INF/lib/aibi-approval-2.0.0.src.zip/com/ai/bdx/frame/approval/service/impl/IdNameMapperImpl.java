/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.jms.util.SimpleCache;
/*    */ import com.asiainfo.biframe.service.IdNameMapper;
/*    */ 
/*    */ public abstract class IdNameMapperImpl
/*    */   implements IdNameMapper
/*    */ {
/*    */   public Object getSimpleCacheMapValue(Class clazz, Object id)
/*    */   {
/* 10 */     return SimpleCache.getInstance().get(clazz.getCanonicalName() + id);
/*    */   }
/*    */ 
/*    */   public void putSimpleCacheMap(Class clazz, Object id, Object value) {
/* 14 */     SimpleCache.getInstance().put(clazz.getCanonicalName() + id, value, 36000L);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.IdNameMapperImpl
 * JD-Core Version:    0.6.2
 */
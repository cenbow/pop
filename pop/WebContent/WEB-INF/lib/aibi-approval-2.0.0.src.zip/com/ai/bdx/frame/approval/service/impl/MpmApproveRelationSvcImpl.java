/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMpmApproveRelationDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveRelation;
/*     */ import com.ai.bdx.frame.approval.service.IMpmApproveRelationSvc;
/*     */ import com.ai.bdx.frame.approval.util.MpmHtmlHelper;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class MpmApproveRelationSvcImpl
/*     */   implements IMpmApproveRelationSvc
/*     */ {
/*  23 */   private static Logger log = LogManager.getLogger();
/*     */   private IMpmApproveRelationDao mpmApproveRelationDao;
/*     */   private IMpmForPageDao mpmForPageDao;
/*     */   private IUserPrivilegeCommonService mpmUserPrivilegeService;
/*     */   private IMpmCommonJdbcDao mpmCommonJdbcDao;
/*     */ 
/*     */   public void setMpmApproveRelationDao(IMpmApproveRelationDao mpmApproveRelationDao)
/*     */   {
/*  34 */     this.mpmApproveRelationDao = mpmApproveRelationDao;
/*     */   }
/*     */ 
/*     */   public IMpmApproveRelationDao getMpmApproveRelationDao() {
/*  38 */     return this.mpmApproveRelationDao;
/*     */   }
/*     */ 
/*     */   public void setMpmForPageDao(IMpmForPageDao mpmForPageDao) {
/*  42 */     this.mpmForPageDao = mpmForPageDao;
/*     */   }
/*     */ 
/*     */   public IMpmForPageDao getMpmForPageDao() {
/*  46 */     return this.mpmForPageDao;
/*     */   }
/*     */ 
/*     */   public IMpmCommonJdbcDao getMpmCommonJdbcDao() {
/*  50 */     return this.mpmCommonJdbcDao;
/*     */   }
/*     */ 
/*     */   public void setMpmCommonJdbcDao(IMpmCommonJdbcDao mpmCommonJdbcDao) {
/*  54 */     this.mpmCommonJdbcDao = mpmCommonJdbcDao;
/*     */   }
/*     */ 
/*     */   public Map findApproveAll(MtlApproveRelation svc, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  69 */       return this.mpmForPageDao.findApproveRelationAll(svc, curPage, pageSize);
/*     */     } catch (Exception e) {
/*  71 */       log.error("", e);
/*  72 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqspxxsb"));
/*     */   }
/*     */ 
/*     */   public boolean deleteApprove(MtlApproveRelation mtlApproveRelation)
/*     */     throws MpmException
/*     */   {
/*  78 */     boolean flag = false;
/*     */     try {
/*  80 */       this.mpmApproveRelationDao.deleteByUserid(mtlApproveRelation);
/*  81 */       flag = true;
/*     */     } catch (Exception e) {
/*  83 */       log.error("", e);
/*  84 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scspgxsb"));
/*     */     }
/*  86 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean saveApprove(MtlApproveRelation mtlApproveRelation) throws MpmException {
/*  90 */     boolean flag = true;
/*     */     try {
/*  92 */       this.mpmApproveRelationDao.save(mtlApproveRelation);
/*  93 */       flag = true;
/*     */     } catch (Exception e) {
/*  95 */       log.error("", e);
/*  96 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcspgxsb"));
/*     */     }
/*  98 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean ApproveRelationExist(String deptId) throws MpmException {
/*     */     try {
/* 103 */       List approveRelations = this.mpmApproveRelationDao.getApproveRelationByDeptId(deptId);
/* 104 */       if ((null != approveRelations) && (approveRelations.size() > 0)) {
/* 105 */         return true;
/*     */       }
/* 107 */       return false;
/*     */     }
/*     */     catch (Exception e) {
/* 110 */       log.error("", e);
/* 111 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgtjzhcxxx"));
/*     */   }
/*     */ 
/*     */   public boolean updateByHiberite(MtlApproveRelation mtlApproveRelation) throws MpmException
/*     */   {
/* 116 */     boolean flag = false;
/*     */     try {
/* 118 */       this.mpmApproveRelationDao.update(mtlApproveRelation);
/* 119 */       flag = true;
/*     */     } catch (Exception e) {
/* 121 */       log.error("", e);
/* 122 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tghiberate"));
/*     */     }
/* 124 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateByJdbc(MtlApproveRelation mtlApproveRelation) throws MpmException {
/* 128 */     boolean flag = false;
/*     */     try {
/* 130 */       this.mpmApproveRelationDao.updateByJdbc(mtlApproveRelation);
/* 131 */       flag = true;
/*     */     } catch (Exception e) {
/* 133 */       log.error("", e);
/* 134 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgjdbcxgjl"));
/*     */     }
/* 136 */     return flag;
/*     */   }
/*     */ 
/*     */   public String getCompanyUserSubTree(String operatorId, String parentId) throws MpmException
/*     */   {
/* 141 */     Sqlca sqlca = null;
/*     */     try {
/* 143 */       String userCityPolicys = null;
/*     */ 
/* 145 */       if (operatorId != null) {
/* 146 */         userCityPolicys = this.mpmUserPrivilegeService.getUserCityPolicyCache(operatorId);
/*     */       }
/* 148 */       sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 150 */       return MpmHtmlHelper.getCompanySubTree(sqlca, parentId, userCityPolicys);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 154 */       log.error("", e);
/* 155 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddgsygssb"));
/*     */     } finally {
/* 157 */       if (sqlca != null)
/* 158 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getCompanyUserTree(String operatorId) throws MpmException
/*     */   {
/* 164 */     Sqlca sqlca = null;
/*     */     try {
/* 166 */       String userCityPolicys = null;
/*     */ 
/* 168 */       if (operatorId != null) {
/* 169 */         userCityPolicys = this.mpmUserPrivilegeService.getUserCityPolicyCache(operatorId);
/*     */       }
/* 171 */       sqlca = new Sqlca(new ConnectionEx());
/* 172 */       String strFormat = "<a onclick=\"onSelecCompanyUser('[ID]','[S]')\" style=\"cursor:hand\">[S]</a>";
/*     */ 
/* 174 */       return MpmHtmlHelper.getCompanyTree(sqlca, "", strFormat, true, true, userCityPolicys);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 178 */       log.error("", e);
/* 179 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddgsygssb"));
/*     */     } finally {
/* 181 */       if (sqlca != null)
/* 182 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getCompanyUserTreeAsyn(String nodeId) throws MpmException
/*     */   {
/* 188 */     Sqlca sqlca = null;
/*     */     try {
/* 190 */       sqlca = new Sqlca(new ConnectionEx());
/* 191 */       return MpmHtmlHelper.getCompanyTreeAsyn(sqlca, nodeId);
/*     */     }
/*     */     catch (Exception e) {
/* 194 */       log.error("", e);
/* 195 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddgsygssb"));
/*     */     } finally {
/* 197 */       if (sqlca != null)
/* 198 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public MtlApproveRelation getApproveRelationById(String createUserid, String approveUserid) throws MpmException
/*     */   {
/*     */     try {
/* 205 */       return this.mpmApproveRelationDao.findByUserid(createUserid, approveUserid);
/*     */     } catch (Exception e) {
/* 207 */       log.error("", e);
/* 208 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddspgxxxsb"));
/*     */   }
/*     */ 
/*     */   public List getApproveRelationByCond(String createId, String approveId, String approveLevel) throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 215 */       return this.mpmApproveRelationDao.findByCondtion(createId, approveId, approveLevel);
/*     */     } catch (Exception e) {
/* 217 */       log.error("", e);
/* 218 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgtjzhcxxx"));
/*     */   }
/*     */ 
/*     */   public int getUserMaxApproveLevel(String userId) throws MpmException
/*     */   {
/*     */     try {
/* 224 */       return this.mpmApproveRelationDao.getUserMaxApproveLevel(userId);
/*     */     } catch (Exception e) {
/* 226 */       log.error("", e);
/* 227 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qdyzyh") + userId + MpmLocaleUtil.getMessage("mcd.java.szgspjbsb"));
/*     */   }
/*     */ 
/*     */   public String getDeptName(String deptid)
/*     */     throws MpmException
/*     */   {
/* 233 */     String result = "";
/*     */     try
/*     */     {
/* 236 */       IUserCompany uc = this.mpmUserPrivilegeService.getUserCompanyById(deptid);
/* 237 */       result = uc.getTitle();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 242 */       log.error("", e);
/* 243 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qyhdbmmcsb"));
/*     */     }
/* 245 */     return result;
/*     */   }
/*     */ 
/*     */   public String getCompanyTreeHtmlCache(String userId, String userGroupId) throws MpmException {
/*     */     try {
/* 250 */       return this.mpmCommonJdbcDao.getCompanyTreeHtml();
/*     */     } catch (Exception e) {
/* 252 */       log.error("", e);
/* 253 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qgszzjgxxs"));
/*     */   }
/*     */ 
/*     */   public IUserPrivilegeCommonService getMpmUserPrivilegeService()
/*     */   {
/* 258 */     return this.mpmUserPrivilegeService;
/*     */   }
/*     */ 
/*     */   public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
/* 262 */     this.mpmUserPrivilegeService = mpmUserPrivilegeService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MpmApproveRelationSvcImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.dao.IMpmApproveRelationDao;
import com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao;
import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveRelation;
import com.ai.bdx.frame.approval.service.IMpmApproveRelationSvc;
import com.ai.bdx.frame.approval.util.MpmHtmlHelper;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IUserCompany;
import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;

public class MpmApproveRelationSvcImpl implements IMpmApproveRelationSvc {
	private static Logger log = LogManager.getLogger();

	private IMpmApproveRelationDao mpmApproveRelationDao;

	private IMpmForPageDao mpmForPageDao;

	private IUserPrivilegeCommonService mpmUserPrivilegeService;

	private IMpmCommonJdbcDao mpmCommonJdbcDao;

	public void setMpmApproveRelationDao(IMpmApproveRelationDao mpmApproveRelationDao) {
		this.mpmApproveRelationDao = mpmApproveRelationDao;
	}

	public IMpmApproveRelationDao getMpmApproveRelationDao() {
		return mpmApproveRelationDao;
	}

	public void setMpmForPageDao(IMpmForPageDao mpmForPageDao) {
		this.mpmForPageDao = mpmForPageDao;
	}

	public IMpmForPageDao getMpmForPageDao() {
		return mpmForPageDao;
	}

	public IMpmCommonJdbcDao getMpmCommonJdbcDao() {
		return mpmCommonJdbcDao;
	}

	public void setMpmCommonJdbcDao(IMpmCommonJdbcDao mpmCommonJdbcDao) {
		this.mpmCommonJdbcDao = mpmCommonJdbcDao;
	}

	/**
	 *
	 * @param curPage
	 * @param pageSize
	 * @return
	 * @throws MpmException
	 */
	public Map findApproveAll(MtlApproveRelation svc, Integer curPage, Integer pageSize) throws MpmException {
		try {
			//判断操作源的用户权限 removed by wwl 2007-7-4 去掉地市权限控制
			//			String  userCityPolicys = userPolicyService.getUserCityPolicyCache(svc.getUserid());
			//			svc.setCityid(userCityPolicys);
			return mpmForPageDao.findApproveRelationAll(svc, curPage, pageSize);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqspxxsb"));
		}

	}

	public boolean deleteApprove(MtlApproveRelation mtlApproveRelation) throws MpmException {
		boolean flag = false;
		try {
			mpmApproveRelationDao.deleteByUserid(mtlApproveRelation);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scspgxsb"));
		}
		return flag;
	}

	public boolean saveApprove(MtlApproveRelation mtlApproveRelation) throws MpmException {
		boolean flag = true;
		try {
			mpmApproveRelationDao.save(mtlApproveRelation);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcspgxsb"));
		}
		return flag;
	}

	public boolean ApproveRelationExist(String deptId) throws MpmException {
		try {
			List approveRelations = mpmApproveRelationDao.getApproveRelationByDeptId(deptId);
			if (null != approveRelations && approveRelations.size() > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgtjzhcxxx"));
		}
	}

	public boolean updateByHiberite(MtlApproveRelation mtlApproveRelation) throws MpmException {
		boolean flag = false;
		try {
			mpmApproveRelationDao.update(mtlApproveRelation);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tghiberate"));
		}
		return flag;
	}

	public boolean updateByJdbc(MtlApproveRelation mtlApproveRelation) throws MpmException {
		boolean flag = false;
		try {
			mpmApproveRelationDao.updateByJdbc(mtlApproveRelation);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgjdbcxgjl"));
		}
		return flag;
	}

	//mads2
	public String getCompanyUserSubTree(String operatorId, String parentId) throws MpmException {
		Sqlca sqlca = null;
		try {
			String userCityPolicys = null;
			//判断操作源的用户权限
			if (operatorId != null) {
				userCityPolicys = mpmUserPrivilegeService.getUserCityPolicyCache(operatorId);
			}
			sqlca = new Sqlca(new ConnectionEx());

			return MpmHtmlHelper.getCompanySubTree(sqlca, parentId, userCityPolicys);
			//log.debug("*************="+userCityPolicys);
			//return userDeptDao.getUserDeptTree(userCityPolicys);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddgsygssb"));
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
	}

	public String getCompanyUserTree(String operatorId) throws MpmException {
		Sqlca sqlca = null;
		try {
			String userCityPolicys = null;
			//判断操作源的用户权限
			if (operatorId != null) {
				userCityPolicys = mpmUserPrivilegeService.getUserCityPolicyCache(operatorId);
			}
			sqlca = new Sqlca(new ConnectionEx());
			String strFormat = "<a onclick=\"onSelecCompanyUser('[ID]','[S]')\" style=\"cursor:hand\">[S]</a>";

			return MpmHtmlHelper.getCompanyTree(sqlca, "", strFormat, true, true, userCityPolicys);
			//log.debug("*************="+userCityPolicys);
			//return userDeptDao.getUserDeptTree(userCityPolicys);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddgsygssb"));
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
	}

	public String getCompanyUserTreeAsyn(String nodeId) throws MpmException {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(new ConnectionEx());
			return MpmHtmlHelper.getCompanyTreeAsyn(sqlca, nodeId);

		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddgsygssb"));
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
	}

	public MtlApproveRelation getApproveRelationById(String createUserid, String approveUserid) throws MpmException {
		try {
			return mpmApproveRelationDao.findByUserid(createUserid, approveUserid);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddspgxxxsb"));
		}

	}

	public List getApproveRelationByCond(String createId, String approveId, String approveLevel) throws MpmException {
		try {
			return mpmApproveRelationDao.findByCondtion(createId, approveId, approveLevel);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgtjzhcxxx"));
		}
	}

	public int getUserMaxApproveLevel(String userId) throws MpmException {
		try {
			return mpmApproveRelationDao.getUserMaxApproveLevel(userId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qdyzyh") + userId
					+ MpmLocaleUtil.getMessage("mcd.java.szgspjbsb"));
		}
	}

	public String getDeptName(String deptid) throws MpmException {
		String result = "";

		try {
			IUserCompany uc = mpmUserPrivilegeService.getUserCompanyById(deptid);
			result = uc.getTitle();

			//			DeptMap deptmap = userDeptDao.getDeptById(deptid);
			//			result = deptmap.getDeptName();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qyhdbmmcsb"));
		}
		return result;
	}

	public String getCompanyTreeHtmlCache(String userId, String userGroupId) throws MpmException {
		try {
			return mpmCommonJdbcDao.getCompanyTreeHtml();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qgszzjgxxs"));
		}
	}

	public IUserPrivilegeCommonService getMpmUserPrivilegeService() {
		return mpmUserPrivilegeService;
	}

	public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
		this.mpmUserPrivilegeService = mpmUserPrivilegeService;
	}

}

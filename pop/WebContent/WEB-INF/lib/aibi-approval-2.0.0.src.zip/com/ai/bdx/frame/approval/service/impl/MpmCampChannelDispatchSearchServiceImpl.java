package com.ai.bdx.frame.approval.service.impl;

import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.DimMtlChannel;
import com.ai.bdx.frame.approval.service.IDimMtlChannelService;
import com.ai.bdx.frame.approval.service.IMpmCampChannelDispatchSearchService;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

public class MpmCampChannelDispatchSearchServiceImpl implements
		IMpmCampChannelDispatchSearchService {
	private static Logger log = LogManager.getLogger();

	private IDimMtlChannelDao dimMtlChannelDao;
	private IDimMtlChannelService dimMtlChannelService;

	public IDimMtlChannelDao getDimMtlChannelDao() {
		return dimMtlChannelDao;
	}

	public void setDimMtlChannelDao(IDimMtlChannelDao dimMtlChannelDao) {
		this.dimMtlChannelDao = dimMtlChannelDao;
	}

	public IDimMtlChannelService getDimMtlChannelService() {
		return dimMtlChannelService;
	}

	public void setDimMtlChannelService(
			IDimMtlChannelService dimMtlChannelService) {
		this.dimMtlChannelService = dimMtlChannelService;
	}

	public String getChannelSelectListCache(String channelTypeId,
			String channelId, String selectName) throws MpmException {
		StringBuffer sb = new StringBuffer();
		List list = null;
		sb.append("<select style='width:9em' name='" + selectName
				+ "' onchange='changeChannelid()'>");
		try {
			if (channelTypeId.equals("-1")) {
				sb.append("<option value='-1'");
				if (channelId.equals("-1")) {
					sb.append(" selected ");
				}
				sb.append(">" + MpmLocaleUtil.getMessage("mcd.java.jtqdoption")
						+ "</option>");
			} else {
				DimMtlChannel channel = new DimMtlChannel();
				channel.setChanneltypeId(Short.valueOf(channelTypeId));
				if (!channelId.equals("-1")) {
					channel.setChannelId(channelId);
				}
				Iterator it = null;
				it = dimMtlChannelDao.findMtlChannel(channel).iterator();
				// if (!it.hasNext()) {
				sb.append("<option value='-1'");
				if (channelId.equals("-1")) {
					sb.append(" selected ");
				}
				sb.append(">" + MpmLocaleUtil.getMessage("mcd.java.qbqdoption")
						+ "</option>");
				// }
				while (it.hasNext()) {

					channel = (DimMtlChannel) it.next();
					sb.append("<option value='" + channel.getChannelId() + "'");
					sb.append(">" + channel.getChannelName() + "</option>");
				}
			}
			sb.append("</select>");
			return sb.toString();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException("");
		}
	}

}

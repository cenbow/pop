/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
/*    */ import com.ai.bdx.frame.approval.exception.MpmException;
/*    */ import com.ai.bdx.frame.approval.model.DimMtlChannel;
/*    */ import com.ai.bdx.frame.approval.service.IDimMtlChannelService;
/*    */ import com.ai.bdx.frame.approval.service.IMpmCampChannelDispatchSearchService;
/*    */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class MpmCampChannelDispatchSearchServiceImpl
/*    */   implements IMpmCampChannelDispatchSearchService
/*    */ {
/* 16 */   private static Logger log = LogManager.getLogger();
/*    */   private IDimMtlChannelDao dimMtlChannelDao;
/*    */   private IDimMtlChannelService dimMtlChannelService;
/*    */ 
/*    */   public IDimMtlChannelDao getDimMtlChannelDao()
/*    */   {
/* 22 */     return this.dimMtlChannelDao;
/*    */   }
/*    */ 
/*    */   public void setDimMtlChannelDao(IDimMtlChannelDao dimMtlChannelDao) {
/* 26 */     this.dimMtlChannelDao = dimMtlChannelDao;
/*    */   }
/*    */ 
/*    */   public IDimMtlChannelService getDimMtlChannelService() {
/* 30 */     return this.dimMtlChannelService;
/*    */   }
/*    */ 
/*    */   public void setDimMtlChannelService(IDimMtlChannelService dimMtlChannelService)
/*    */   {
/* 35 */     this.dimMtlChannelService = dimMtlChannelService;
/*    */   }
/*    */ 
/*    */   public String getChannelSelectListCache(String channelTypeId, String channelId, String selectName) throws MpmException
/*    */   {
/* 40 */     StringBuffer sb = new StringBuffer();
/* 41 */     List list = null;
/* 42 */     sb.append("<select style='width:9em' name='" + selectName + "' onchange='changeChannelid()'>");
/*    */     try
/*    */     {
/* 45 */       if (channelTypeId.equals("-1")) {
/* 46 */         sb.append("<option value='-1'");
/* 47 */         if (channelId.equals("-1")) {
/* 48 */           sb.append(" selected ");
/*    */         }
/* 50 */         sb.append(">" + MpmLocaleUtil.getMessage("mcd.java.jtqdoption") + "</option>");
/*    */       }
/*    */       else {
/* 53 */         DimMtlChannel channel = new DimMtlChannel();
/* 54 */         channel.setChanneltypeId(Short.valueOf(channelTypeId));
/* 55 */         if (!channelId.equals("-1")) {
/* 56 */           channel.setChannelId(channelId);
/*    */         }
/* 58 */         Iterator it = null;
/* 59 */         it = this.dimMtlChannelDao.findMtlChannel(channel).iterator();
/*    */ 
/* 61 */         sb.append("<option value='-1'");
/* 62 */         if (channelId.equals("-1")) {
/* 63 */           sb.append(" selected ");
/*    */         }
/* 65 */         sb.append(">" + MpmLocaleUtil.getMessage("mcd.java.qbqdoption") + "</option>");
/*    */ 
/* 68 */         while (it.hasNext())
/*    */         {
/* 70 */           channel = (DimMtlChannel)it.next();
/* 71 */           sb.append("<option value='" + channel.getChannelId() + "'");
/* 72 */           sb.append(">" + channel.getChannelName() + "</option>");
/*    */         }
/*    */       }
/* 75 */       sb.append("</select>");
/* 76 */       return sb.toString();
/*    */     } catch (Exception e) {
/* 78 */       log.error("", e);
/* 79 */     }throw new MpmException("");
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MpmCampChannelDispatchSearchServiceImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.approval.dao.IMpmCampDataSourceDao;
import com.ai.bdx.frame.approval.dao.IMpmCampDatasrcColumnDao;
import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.DimColumnClass;
import com.ai.bdx.frame.approval.model.MtlCampDataSource;
import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
import com.ai.bdx.frame.approval.service.IMpmCampDataSourceSvc;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

/**
 * 营销管理－数据源管理
 * 
 * @author zhoulb 2006-5-16
 * @version 1.0
 */
public class MpmCampDataSourceSvcImpl implements IMpmCampDataSourceSvc {
	private static Logger log = LogManager.getLogger();

	IMpmCampDataSourceDao campDatasourceDao;

	IMpmCampDatasrcColumnDao campDatasrcColumnDao;

	IMpmForPageDao mpmForPageDao;

	public IMpmCampDataSourceDao getCampDatasourceDao() {
		return campDatasourceDao;
	}

	public void setCampDatasourceDao(IMpmCampDataSourceDao campDatasourceDao) {
		this.campDatasourceDao = campDatasourceDao;
	}

	public IMpmCampDatasrcColumnDao getCampDatasrcColumnDao() {
		return campDatasrcColumnDao;
	}

	public void setCampDatasrcColumnDao(
			IMpmCampDatasrcColumnDao campDatasrcColumnDao) {
		this.campDatasrcColumnDao = campDatasrcColumnDao;
	}

	public void setMpmForPageDao(IMpmForPageDao mpmForPageDao) {
		this.mpmForPageDao = mpmForPageDao;
	}

	public IMpmForPageDao getMpmForPageDao() {
		return mpmForPageDao;
	}

	public boolean saveDatasource(MtlCampDataSource mtlCampDataSource)
			throws MpmException {
		boolean flag = false;
		try {
			campDatasourceDao.insert(mtlCampDataSource);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.crytsjybjl"));
		}
		return flag;
	}

	public List findAllDatasource() throws MpmException {
		List list = new ArrayList();
		try {
			list = campDatasourceDao.findAll();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.cxsydsjybj"));
		}
		return list;
	}

	public MtlCampDataSource findByTabname(String tabname) throws MpmException {
		MtlCampDataSource info = null;
		try {
			info = campDatasourceDao.findByTabname(tabname);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.tgbmcxsjyb"));
		}
		return info;
	}

	public boolean deleteByTabname(String tabname) throws MpmException {
		boolean flag = false;
		try {
			campDatasrcColumnDao.deleteByStr(tabname, "", "");
			campDatasourceDao.deleteByTabname(tabname);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.tgbmscsjyb"));
		}
		return flag;
	}

	public boolean updateTable(MtlCampDataSource mtlCampDataSource)
			throws MpmException {
		boolean flag = false;
		try {
			campDatasourceDao.updateByTabname(mtlCampDataSource);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.xgsjybxxsb"));
		}
		return flag;
	}

	// ///////////////以下为操作字段信息表的操作函数//////////////////

	public boolean saveDatasrcColumn(MtlCampDatasrcColumn mtlCampDatasrcColumn)
			throws MpmException {
		boolean flag = false;
		try {
			campDatasrcColumnDao.insertDatasrcColumn(mtlCampDatasrcColumn);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.bcsjybzdxx"));
		}
		return flag;
	}

	public Map findColumnByTabname(String tablename, String columnName,
			String columnCname, Integer curPage, Integer pageSize)
			throws MpmException {
		try {
			Map map = mpmForPageDao.findDataSourceByTabname(tablename,
					columnName, columnCname, curPage, pageSize);
			return map;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.tgbmcxzdxx"));
		}
	}

	public boolean deleteColumnByStr(String tableName, String columnName,
			String columnPk) throws MpmException {
		boolean flag = false;
		try {
			campDatasrcColumnDao.deleteByStr(tableName, columnName, columnPk);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.sczdxxsb"));
		}
		return flag;
	}

	public boolean updateColumnByHiberate(
			MtlCampDatasrcColumn mtlCampDatasrcColumn) throws MpmException {
		boolean flag = false;
		try {
			campDatasrcColumnDao.updateByHiberate(mtlCampDatasrcColumn);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.xgzdxxsb"));
		}
		return flag;
	}

	public boolean updateColumnByJdbc(MtlCampDatasrcColumn mtlCampDatasrcColumn)
			throws MpmException {
		boolean flag = false;
		try {
			campDatasrcColumnDao.updateByJdbc(mtlCampDatasrcColumn);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.xgzdxxsb"));
		}
		return flag;
	}

	public List getColumnInfoList(MtlCampDatasrcColumn svc) throws MpmException {
		try {
			return campDatasrcColumnDao.findByCondtion(svc);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.tjzhhqzdxx"));
		}
	}

	public MtlCampDatasrcColumn getCampDatasrcColumn(String sourceName,
			String columnName) throws MpmException {
		try {
			return campDatasrcColumnDao.getCampDatasrcColumn(sourceName,
					columnName);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.qsjyzdxxsb"));
		}
	}

	public List getColumnClass() throws MpmException {
		List result = new ArrayList();
		try {
			Iterator it = campDatasrcColumnDao.getAllClass().iterator();
			DimColumnClass dcc;
			while (it != null && it.hasNext()) {
				dcc = (DimColumnClass) it.next();
				result.add(new LabelValueBean(dcc.getClassName(), dcc
						.getClassId().toString()));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.hqzdflsb"));
		}
		return result;
	}

}

/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMpmCampDataSourceDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMpmCampDatasrcColumnDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.model.DimColumnClass;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampDataSource;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
/*     */ import com.ai.bdx.frame.approval.service.IMpmCampDataSourceSvc;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ 
/*     */ public class MpmCampDataSourceSvcImpl
/*     */   implements IMpmCampDataSourceSvc
/*     */ {
/*  29 */   private static Logger log = LogManager.getLogger();
/*     */   IMpmCampDataSourceDao campDatasourceDao;
/*     */   IMpmCampDatasrcColumnDao campDatasrcColumnDao;
/*     */   IMpmForPageDao mpmForPageDao;
/*     */ 
/*     */   public IMpmCampDataSourceDao getCampDatasourceDao()
/*     */   {
/*  38 */     return this.campDatasourceDao;
/*     */   }
/*     */ 
/*     */   public void setCampDatasourceDao(IMpmCampDataSourceDao campDatasourceDao) {
/*  42 */     this.campDatasourceDao = campDatasourceDao;
/*     */   }
/*     */ 
/*     */   public IMpmCampDatasrcColumnDao getCampDatasrcColumnDao() {
/*  46 */     return this.campDatasrcColumnDao;
/*     */   }
/*     */ 
/*     */   public void setCampDatasrcColumnDao(IMpmCampDatasrcColumnDao campDatasrcColumnDao)
/*     */   {
/*  51 */     this.campDatasrcColumnDao = campDatasrcColumnDao;
/*     */   }
/*     */ 
/*     */   public void setMpmForPageDao(IMpmForPageDao mpmForPageDao) {
/*  55 */     this.mpmForPageDao = mpmForPageDao;
/*     */   }
/*     */ 
/*     */   public IMpmForPageDao getMpmForPageDao() {
/*  59 */     return this.mpmForPageDao;
/*     */   }
/*     */ 
/*     */   public boolean saveDatasource(MtlCampDataSource mtlCampDataSource) throws MpmException
/*     */   {
/*  64 */     boolean flag = false;
/*     */     try {
/*  66 */       this.campDatasourceDao.insert(mtlCampDataSource);
/*  67 */       flag = true;
/*     */     } catch (Exception e) {
/*  69 */       log.error("", e);
/*  70 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.crytsjybjl"));
/*     */     }
/*     */ 
/*  73 */     return flag;
/*     */   }
/*     */ 
/*     */   public List findAllDatasource() throws MpmException {
/*  77 */     List list = new ArrayList();
/*     */     try {
/*  79 */       list = this.campDatasourceDao.findAll();
/*     */     } catch (Exception e) {
/*  81 */       log.error("", e);
/*  82 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxsydsjybj"));
/*     */     }
/*     */ 
/*  85 */     return list;
/*     */   }
/*     */ 
/*     */   public MtlCampDataSource findByTabname(String tabname) throws MpmException {
/*  89 */     MtlCampDataSource info = null;
/*     */     try {
/*  91 */       info = this.campDatasourceDao.findByTabname(tabname);
/*     */     } catch (Exception e) {
/*  93 */       log.error("", e);
/*  94 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgbmcxsjyb"));
/*     */     }
/*     */ 
/*  97 */     return info;
/*     */   }
/*     */ 
/*     */   public boolean deleteByTabname(String tabname) throws MpmException {
/* 101 */     boolean flag = false;
/*     */     try {
/* 103 */       this.campDatasrcColumnDao.deleteByStr(tabname, "", "");
/* 104 */       this.campDatasourceDao.deleteByTabname(tabname);
/* 105 */       flag = true;
/*     */     } catch (Exception e) {
/* 107 */       log.error("", e);
/* 108 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgbmscsjyb"));
/*     */     }
/*     */ 
/* 111 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateTable(MtlCampDataSource mtlCampDataSource) throws MpmException
/*     */   {
/* 116 */     boolean flag = false;
/*     */     try {
/* 118 */       this.campDatasourceDao.updateByTabname(mtlCampDataSource);
/* 119 */       flag = true;
/*     */     } catch (Exception e) {
/* 121 */       log.error("", e);
/* 122 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.xgsjybxxsb"));
/*     */     }
/*     */ 
/* 125 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean saveDatasrcColumn(MtlCampDatasrcColumn mtlCampDatasrcColumn)
/*     */     throws MpmException
/*     */   {
/* 132 */     boolean flag = false;
/*     */     try {
/* 134 */       this.campDatasrcColumnDao.insertDatasrcColumn(mtlCampDatasrcColumn);
/* 135 */       flag = true;
/*     */     } catch (Exception e) {
/* 137 */       log.error("", e);
/* 138 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcsjybzdxx"));
/*     */     }
/*     */ 
/* 141 */     return flag;
/*     */   }
/*     */ 
/*     */   public Map findColumnByTabname(String tablename, String columnName, String columnCname, Integer curPage, Integer pageSize) throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 148 */       return this.mpmForPageDao.findDataSourceByTabname(tablename, columnName, columnCname, curPage, pageSize);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 152 */       log.error("", e);
/* 153 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgbmcxzdxx"));
/*     */   }
/*     */ 
/*     */   public boolean deleteColumnByStr(String tableName, String columnName, String columnPk)
/*     */     throws MpmException
/*     */   {
/* 160 */     boolean flag = false;
/*     */     try {
/* 162 */       this.campDatasrcColumnDao.deleteByStr(tableName, columnName, columnPk);
/* 163 */       flag = true;
/*     */     } catch (Exception e) {
/* 165 */       log.error("", e);
/* 166 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.sczdxxsb"));
/*     */     }
/*     */ 
/* 169 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateColumnByHiberate(MtlCampDatasrcColumn mtlCampDatasrcColumn) throws MpmException
/*     */   {
/* 174 */     boolean flag = false;
/*     */     try {
/* 176 */       this.campDatasrcColumnDao.updateByHiberate(mtlCampDatasrcColumn);
/* 177 */       flag = true;
/*     */     } catch (Exception e) {
/* 179 */       log.error("", e);
/* 180 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.xgzdxxsb"));
/*     */     }
/*     */ 
/* 183 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean updateColumnByJdbc(MtlCampDatasrcColumn mtlCampDatasrcColumn) throws MpmException
/*     */   {
/* 188 */     boolean flag = false;
/*     */     try {
/* 190 */       this.campDatasrcColumnDao.updateByJdbc(mtlCampDatasrcColumn);
/* 191 */       flag = true;
/*     */     } catch (Exception e) {
/* 193 */       log.error("", e);
/* 194 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.xgzdxxsb"));
/*     */     }
/*     */ 
/* 197 */     return flag;
/*     */   }
/*     */ 
/*     */   public List getColumnInfoList(MtlCampDatasrcColumn svc) throws MpmException {
/*     */     try {
/* 202 */       return this.campDatasrcColumnDao.findByCondtion(svc);
/*     */     } catch (Exception e) {
/* 204 */       log.error("", e);
/* 205 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tjzhhqzdxx"));
/*     */   }
/*     */ 
/*     */   public MtlCampDatasrcColumn getCampDatasrcColumn(String sourceName, String columnName)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 213 */       return this.campDatasrcColumnDao.getCampDatasrcColumn(sourceName, columnName);
/*     */     }
/*     */     catch (Exception e) {
/* 216 */       log.error("", e);
/* 217 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsjyzdxxsb"));
/*     */   }
/*     */ 
/*     */   public List getColumnClass()
/*     */     throws MpmException
/*     */   {
/* 223 */     List result = new ArrayList();
/*     */     try {
/* 225 */       Iterator it = this.campDatasrcColumnDao.getAllClass().iterator();
/*     */ 
/* 227 */       while ((it != null) && (it.hasNext())) {
/* 228 */         DimColumnClass dcc = (DimColumnClass)it.next();
/* 229 */         result.add(new LabelValueBean(dcc.getClassName(), dcc.getClassId().toString()));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 233 */       log.error("", e);
/* 234 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqzdflsb"));
/*     */     }
/*     */ 
/* 237 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MpmCampDataSourceSvcImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service.impl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.time.FastDateFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.approval.bean.MtlSeginfoObj;
import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao;
import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
import com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao;
import com.ai.bdx.frame.approval.dao.IDimPubChannelDao;
import com.ai.bdx.frame.approval.dao.IDimPubChannelTypeDao;
import com.ai.bdx.frame.approval.dao.IMpmApproveRelationDao;
import com.ai.bdx.frame.approval.dao.IMpmCampDataSourceDao;
import com.ai.bdx.frame.approval.dao.IMpmCampDatasrcColumnDao;
import com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao;
import com.ai.bdx.frame.approval.dao.IMpmSysActflowDefDao;
import com.ai.bdx.frame.approval.dao.IMpmSysFlowstepDefDao;
import com.ai.bdx.frame.approval.dao.IMtlApproveAdviceDao;
import com.ai.bdx.frame.approval.dao.IMtlApproveConfirmListDao;
import com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao;
import com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao;
import com.ai.bdx.frame.approval.dao.IMtlCampsegProgressDao;
import com.ai.bdx.frame.approval.dao.IMtlSysActStepDefDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.DimCampDrvType;
import com.ai.bdx.frame.approval.model.DimDrvRoleManager;
import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
import com.ai.bdx.frame.approval.model.DimPubChannel;
import com.ai.bdx.frame.approval.model.DimPubChanneltype;
import com.ai.bdx.frame.approval.model.MtlApproveAdvice;
import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
import com.ai.bdx.frame.approval.model.MtlCampDataSource;
import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
import com.ai.bdx.frame.approval.model.MtlCampsegApproverList;
import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
import com.ai.bdx.frame.approval.model.MtlCampsegProgressId;
import com.ai.bdx.frame.approval.model.MtlPlanExecType;
import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
import com.ai.bdx.frame.approval.model.MtlSysFlowstepDef;
import com.ai.bdx.frame.approval.service.IMpmCommonService;
import com.ai.bdx.frame.approval.util.MpmCache;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
import com.ai.bdx.frame.approval.util.MpmUtil;
import com.ai.bdx.frame.approval.util.StringFunc;
import com.ai.bdx.frame.privilegeServiceExt.bean.TreeNode;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.ICity;
import com.asiainfo.biframe.privilege.base.util.OperString;
import com.asiainfo.biframe.utils.config.Configure;
import com.asiainfo.biframe.utils.database.jdbc.AiomniConnectionFactory;
import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
import com.asiainfo.biframe.utils.date.DateUtil;
import com.asiainfo.biframe.utils.string.StringUtil;

public class MpmCommonServiceImpl implements IMpmCommonService {

	private static Logger log = LogManager.getLogger();

	private IMpmCommonJdbcDao commonJdbcDao;
	private IDimCampDrvTypeDao campDevTypeDao;
	private IUserPrivilegeCommonService userPolicyService;
	private IDimPubChannelTypeDao channelTypeDao;
	private IDimPubChannelDao channelDao;
	private IMtlSysActStepDefDao sysActStepDefDao;
	private IMpmApproveRelationDao mpmApproveRelationDao;
	private IMpmSysActflowDefDao actFlowDefDao;
	private IMpmSysFlowstepDefDao flowstepDefDao;
	private IMtlCampsegProgressDao campsegProgressDao;
	private IMpmCampDatasrcColumnDao mpmCampDatasrcColumnDao;
	private IMpmCampDataSourceDao campDatasourceDao;
	private IMpmCampDatasrcColumnDao campDatasrcColumnDao;
	private IMtlCampsegApproverListDao mtlCampsegApproverListDao;
	private IMtlApproveAdviceDao mtlApproveAdviceDao;
	private IMtlApproveConfirmListDao approveConfirmListDao;

	private IDimMtlChanneltypeDao dimMtlChanneltypeDao;
	private IDimMtlChannelDao dimMtlChannelDao;

	private IMtlApproveFlowDefDao mtlApproveFlowDefDao;
	private IMtlCampsegProgressDao progressDao;

	public IMtlCampsegProgressDao getProgressDao() {
		return progressDao;
	}

	public void setProgressDao(IMtlCampsegProgressDao progressDao) {
		this.progressDao = progressDao;
	}

	public IDimCampDrvTypeDao getCampDevTypeDao() {
		return campDevTypeDao;
	}

	public void setCampDevTypeDao(IDimCampDrvTypeDao campDevTypeDao) {
		this.campDevTypeDao = campDevTypeDao;
	}

	public IUserPrivilegeCommonService getUserPolicyService() {
		return userPolicyService;
	}

	public void setUserPolicyService(IUserPrivilegeCommonService userPolicyService) {
		this.userPolicyService = userPolicyService;
	}

	public IDimPubChannelTypeDao getChannelTypeDao() {
		return channelTypeDao;
	}

	public void setChannelTypeDao(IDimPubChannelTypeDao channelTypeDao) {
		this.channelTypeDao = channelTypeDao;
	}

	public IDimPubChannelDao getChannelDao() {
		return channelDao;
	}

	public void setChannelDao(IDimPubChannelDao channelDao) {
		this.channelDao = channelDao;
	}

	public IMpmApproveRelationDao getMpmApproveRelationDao() {
		return mpmApproveRelationDao;
	}

	public void setMpmApproveRelationDao(IMpmApproveRelationDao mpmApproveRelationDao) {
		this.mpmApproveRelationDao = mpmApproveRelationDao;
	}

	public IMpmSysActflowDefDao getActFlowDefDao() {
		return actFlowDefDao;
	}

	public void setActFlowDefDao(IMpmSysActflowDefDao actFlowDefDao) {
		this.actFlowDefDao = actFlowDefDao;
	}

	public IMpmSysFlowstepDefDao getFlowstepDefDao() {
		return flowstepDefDao;
	}

	public void setFlowstepDefDao(IMpmSysFlowstepDefDao flowstepDefDao) {
		this.flowstepDefDao = flowstepDefDao;
	}

	public IMtlApproveFlowDefDao getMtlApproveFlowDefDao() {
		return mtlApproveFlowDefDao;
	}

	public void setMtlApproveFlowDefDao(IMtlApproveFlowDefDao mtlApproveFlowDefDao) {
		this.mtlApproveFlowDefDao = mtlApproveFlowDefDao;
	}

	private final String CREATE_TABLE_SQL = "create table ? (product_no varchar(12) not null)";
	private final String ALTER_TABLE_PK_SQL = "alter table ? add primary key(product_no)";
	private final String UPDATE_LOAD_TYPE = "update mtl_filter_file set file_load_type=?1 where filter_file_id='?2'";
	private final String UPDATE_TAB_NAME = "update mtl_filter_file set load_tabname='?1' where filter_file_id='?2'";
	private final String DELETE_REPEAT_RECORD = "delete from (select PRODUCT_NO,row_number() over(partition by PRODUCT_NO) as row_seq from ?) t where t.row_seq>1";
	private final String DELETE_REPEAT_RECORD_ORACLE = "delete from ? a  where a.rowid>(select min(b.rowid) from ? b where b.PRODUCT_NO=a.PRODUCT_NO)";
	private final String ALTER_TABLE_PK_SQL3 = "alter table ? add primary key(product_no)";
	private final String UPDATE_LOAD_TYPE3 = "update MTL_targetuser_file set file_load_type=?1 where targetuser_file_id='?2'";
	private final String UPDATE_LOAD_TYPE2 = "update MTL_targetuser_file set file_load_type=?1,TARGETUSER_FILE_DESC='?3' where targetuser_file_id='?2'";
	private final String UPDATE_TAB_NAME3 = "update MTL_targetuser_file set load_tabname='?1',total_need_load_cnt=?2,success_load_cnt=?3,load_end_time=?5 where targetuser_file_id='?4'";
	private static String INSERT_DATASOURCE_SQL3 = "insert into MTL_camp_data_source (source_name,source_cname,source_type,create_time,source_status) "
			+ " values ('?1','?2',6,?3,1)";
	private static String INSERT_DATASOURCE_COLUMN_SQL3 = "insert into MTL_camp_datasrc_column (column_name,source_name,column_type,column_cname,column_class,column_flag,column_serno,column_datatype,column_status,column_desc) "
			+ " values ('?1','?2',?3,'?4',?8,0,?5,'?6',1,'?7')";
	private static String INSERT_Templet_Active_SQL = "insert into MTL_templet_active (active_templet_id,atemplet_name,create_userid,create_time,atemplet_desc,atemplet_type) "
			+ " values ('?1','?2','?3',?4,'?5',?6)";
	private static String INSERT_Cust_Group_SQL = "insert into MTL_cust_group (cust_group_id,cust_group_name,create_user_id,city_id,create_date,cust_group_type,cust_group_num,active_templet_id,cust_group_access_token,cust_group_status) "
			+ " values ('?1','?2','?3','?4','?5',?6,?7,'?8',?9," + MpmCONST.MPM_CUST_GROUP_STATUS_VALID + ")";
	private static String INSERT_Templet_Select_SQL = "insert into MTL_templet_select (active_templet_id,select_templet_id,seltemplet_name,select_sql,select_sql_cn,create_userid,create_time,seltemplet_type,seltemplet_desc,result_order_bysql,result_cnorder_bysql) "
			+ " values ('?1','?2','?3','?4','?5','?6',?7,?8,'?90','?91','?92')";
	private static String INSERT_Datasrc_Column_SQL = "insert into MTL_camp_datasrc_column (source_name,column_name,column_type,column_cname,column_class,column_flag,column_desc,column_serno,column_datatype,column_status) "
			+ "	values ('?1','?2',?3,'?4',?5,?6,'?7',?8,'?90',?91)";

	private final String CREATE_TABLE_SQL3 = "create table ? (product_no varchar(12) not null,col1 varchar(500),col2 varchar(500),col3 varchar(500),col4 varchar(500),col5 varchar(500),file_idx_flag smallint)";

	private final String TAB_NAME_PRE3 = "mtl_suser_";
	private final String TAB_NAME_PRE = "mtl_extelim_";

	public Map getCampChannelTypeMap() throws MpmException {
		Map map = new TreeMap();
		try {
			Iterator it = commonJdbcDao.getCampChannelTypeMap().iterator();
			while (it.hasNext()) {
				Map cm = (Map) it.next();
				map.put(cm.get("CHANNELTYPE_ID").toString(), cm.get("CHANNELTYPE_NAME"));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdlxcw"));
		}
		return map;
	}

	public List<MtlApproveFlowDef> getApproveUserList(String deptId) throws Exception {
		// TODO Auto-generated method stub
		List<MtlApproveFlowDef> list = new ArrayList();
		try {
			list = mtlApproveFlowDefDao.getFirstApproveUser(deptId);
			if (list.isEmpty()) {
				MtlApproveFlowDef mafd = new MtlApproveFlowDef();
				mafd.setFirstApproveUser("ADMIN");
				list.add(mafd);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public Map getMtlCampRuleTypeMap() throws MpmException {
		Map map = new TreeMap();
		try {
			Iterator it = commonJdbcDao.getMtlCampRuleTypeMap().iterator();
			while (it.hasNext()) {
				Map cm = (Map) it.next();
				map.put(cm.get("RULE_TYPE_ID").toString(), cm.get("RULE_TYPE_NAME"));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdlxcw"));
		}
		return map;
	}

	public Map getCampChannelIdMap(int channeltypeId) throws Exception {
		// TODO 自动生成方法存根
		Map map = new TreeMap();
		if (channeltypeId == 904) {
			map.put("-1", MpmLocaleUtil.getMessage("mcd.java.qbcfkhjl"));
		}
		// 以下可能需要为其他渠道添加所有类型选项

		try {
			Iterator it = commonJdbcDao.getCampChannelIdMap(channeltypeId).iterator();
			while (it.hasNext()) {
				Map cm = (Map) it.next();
				map.put(cm.get("CHANNEL_ID"), cm.get("CHANNEL_NAME"));
			}

		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdlxcw"));
		}
		return map;
	}

	public String getAllChannelIds() throws Exception {
		// TODO 自动生成方法存根
		String channelIds = ",";
		try {
			Iterator it = commonJdbcDao.getAllChannel().iterator();
			while (it.hasNext()) {
				Map cm = (Map) it.next();
				channelIds += (String) cm.get("CHANNEL_ID") + ",";
			}

		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqbqdxxdyc"));
		}
		return channelIds;
	}

	public List getAllMtlChanneltype() throws MpmException {
		try {
			return dimMtlChanneltypeDao.findMtlChanneltype(null);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqdlxdysb"));
		}
	}

	public Short getMaxCampDrvId() throws MpmException {
		try {
			return campDevTypeDao.getMaxCampDrvId();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qkhmdrlxcw"));
		}
	}

	public void saveCampDrvType(DimCampDrvType dcdt) throws MpmException {
		try {
			campDevTypeDao.save(dcdt);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qkhmdrlxcw"));
		}
	}

	public DimCampDrvType getDrvType(Short drvTypeId) throws Exception {
		DimCampDrvType obj = null;
		try {
			obj = campDevTypeDao.getDrvType(drvTypeId);
		} catch (Exception e) {
			log.error("", e);
		}
		return obj;
	}

	public List getPlanExecTypeMap(MtlPlanExecType mpet) throws MpmException {
		List map = new ArrayList();
		try {
			map = campDevTypeDao.getPlanExecTypeMap(mpet);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qkhmdrlxcw"));
		}
		return map;
	}

	public List getAllCampDrvType() throws MpmException {
		try {
			return campDevTypeDao.getAllDrvType();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdqdlxcw"));
		}
	}

	public boolean isNameExist(String name, String id, String nameType, boolean nameNeedTrans) {
		boolean res = true;
		try {
			if (nameNeedTrans) {
				name = OperString.ISO2GBK(name);
			}
			String nameColumn = "";
			String idColumn = "";
			String tableName = nameType;
			int flag = 0;
			if (nameType.equalsIgnoreCase("AP_APPROVE_DRV_TYPE")) {
				nameColumn = "CAMP_DRV_NAME";
				idColumn = "CAMP_DRV_ID";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_CAMP)) {
				nameColumn = "camp_name";
				idColumn = "camp_id";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_CAMP_SEG)) {
				nameColumn = "campseg_name";
				idColumn = "campseg_id";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_ACTIVE_TEMPLET)) {
				nameColumn = "atemplet_name";
				idColumn = "active_templet_id";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_SELECT_TEMPLET)) {
				nameColumn = "seltemplet_name";
				idColumn = "select_templet_id";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_FILTER_TEMPLET)) {
				nameColumn = "ftemplet_name";
				idColumn = "filter_templet_id";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_FILTER_COMB)) {
				nameColumn = "filter_rule_name";
				idColumn = "filter_rule_id";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_SUB_TEMPLET)) {
				nameColumn = "stemplet_name";
				idColumn = "subsection_templet_id";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_SUB_COMB)) {
				nameColumn = "rule_name";
				idColumn = "subsection_rule_id";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_ACTIVE_FLOW)) {
				nameColumn = "flow_name";
				idColumn = "flow_id";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_COST_LIST)) {
				nameColumn = "cost_code";
				flag = 1;
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_IDINDI)) {
				nameColumn = "id_indi";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_RES_LIST)) {
				nameColumn = "res_name";
				idColumn = "res_code";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_DATASOURCE)) {
				nameColumn = "source_name";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_DATASRC_COLUMN) && id.length() > 0) {
				nameColumn = "column_name";
				idColumn = "source_name";
				flag = 2;
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_DATASRC_COLUMN) && id.length() == 0) {
				nameColumn = "column_cname";
			} else if (nameType.equals(MpmCONST.MPM_RES_NAME_TYPE_FILTER_FILE)) {
				nameColumn = "filter_file_name";
				idColumn = "filter_file_id";
			} else if (nameType.equals(MpmCONST.MPM_DIM_COLUMN_FEATURE)) {
				nameColumn = "column_name";
			} else if (nameType.equals(MpmCONST.MPM_SMS_MMS_CODE_DEF)) {
				nameColumn = "content_code";
				idColumn = "campseg_id";
			} else if (nameType.equals(MpmCONST.MPM_TARGETUSER_FILE)) {
				nameColumn = "targetuser_file_name";
			} else if (nameType.equals(MpmCONST.MPM_APPROVE_CONFIRM_TEMPLET)) {
				nameColumn = "confirm_name";
				idColumn = "confirm_id";
			} else if (nameType.equals(MpmCONST.MPM_APPROVE_FLOW_DEF)) {
				nameColumn = "approve_flow_name";
				idColumn = "approve_flow_id";
			} else if (nameType.equals(MpmCONST.MPM_CUST_GROUP)) {
				nameColumn = "cust_group_name";
				idColumn = "cust_group_id";
			} else if (nameType.equals(MpmCONST.MTL_PUBLICIZE_COMB)) {
				nameColumn = "publicize_comb_name";
				idColumn = "publicize_comb_id";
			} else if (nameType.equalsIgnoreCase("MTL_SCENES_TEMPLET")) {
				nameColumn = "scenes_name";
				idColumn = "scenes_id";
			} else if (nameType.equalsIgnoreCase("mtl_premodel_cfg")) {
				nameColumn = "mname";
				idColumn = "cid";
			} else if (nameType.equalsIgnoreCase("event_tag_define")) {
				nameColumn = "tag_name";
				idColumn = "tag_id";
			}

			if (flag == 0) {
				res = commonJdbcDao.isNameExist(name, id, idColumn, nameColumn, tableName);
			} else {
				if (flag == 1) {
					res = commonJdbcDao.isNameExistForInt(name, id, idColumn, nameColumn, tableName);
				} else {
					if (flag == 2) {
						res = commonJdbcDao.isNameExistForDataColumn(name, id, idColumn, nameColumn, tableName);
					}
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return res;
	}

	/**
	 *
	 */
	public Map getCampDrvTypeMap() throws MpmException {
		Map map = new TreeMap();
		try {
			Iterator it = campDevTypeDao.getAllDrvType().iterator();
			DimCampDrvType obj;
			while (it.hasNext()) {
				obj = (DimCampDrvType) it.next();
				map.put(obj.getCampDrvId(), obj.getCampDrvName());
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdqdlxcw"));
		}
		return map;
	}

	public List getAllCampDrvTypesEnable() throws MpmException {
		try {
			Object[] objs = campDevTypeDao.getAllDrvTypesEnabled();
			List result = (List) objs[0];
			List filter = (List) objs[1];

			Iterator<Short> filterIt;

			for (Iterator<DimCampDrvType> it = result.iterator(); it.hasNext();) {
				DimCampDrvType drv = it.next();

				for (filterIt = filter.iterator(); filterIt.hasNext();) {
					Short filterId = filterIt.next();
					if (filterId != null && drv.getParentId() != null
							&& drv.getParentId().shortValue() == filterId.shortValue()) {
						it.remove();
					}
				}
			}

			filter = null;

			return result;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdqdlxcw"));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.service.IMpmCommonService#getAllCampDrvTypeByRoleId
	 * ( java.lang.Short, java.lang.String, java.lang.Short)
	 */
	public DimDrvRoleManager getAllCampDrvTypeByRoleId(Short campDrvId, String roleId, Short roleFlag)
			throws MpmException {
		DimDrvRoleManager ddrm = null;
		try {
			ddrm = campDevTypeDao.getAllCampDrvTypeByRoleId(campDrvId, roleId, roleFlag);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgjsqhdqdl"));
		}
		return ddrm;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.service.IMpmCommonService#getUserDrvAuth(java.
	 * lang.Short , java.lang.String, java.lang.String)
	 */
	public boolean getUserDrvAuth(Short campDrvId, String userId, String groupId) throws MpmException {
		boolean flag = false;
		try {
			flag = campDevTypeDao.getUserDrvAuth(campDrvId, userId, groupId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgjsqhdqdl"));
		}
		return flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.service.IMpmCommonService#getScenesBycampDrvId
	 * (java. lang.String)
	 */
	public List getScenesBycampDrvId(String campDrvId) throws MpmException {
		try {
			return campDevTypeDao.getScenesBycampDrvId(campDrvId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qyxcjmbcw"));
		}
	}

	public MtlCampsegProgress getCampsegProgress(String campsegId, String flowId, Short stepId) throws MpmException {
		try {
			MtlCampsegProgressId key = new MtlCampsegProgressId();
			key.setCampsegId(campsegId);
			key.setFlowId(flowId);
			key.setStepId(stepId);
			return progressDao.getCampsegProgress(key);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qyxhdbcjdc") + e);
		}
	}

	public short getCampsegProgressStatus(String campsegId, String flowId, Short stepId) throws MpmException {
		try {
			MtlCampsegProgressId key = new MtlCampsegProgressId();
			key.setCampsegId(campsegId);
			key.setFlowId(flowId);
			key.setStepId(stepId);
			Short status = progressDao.getCampsegProgressStatus(key);
			// log.debug(">>>>>>>>>>>>状�?"+status);
			if (status != null) {
				return status.shortValue();
			} else {
				throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ghdbcjdbcz"));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qyxhdbcjdc") + e);
		}
	}

	public boolean hasPreStepFinished(String campsegId, String flowId, Short stepId, Short campType)
			throws MpmException {
		try {

			// removed by wwl 2007-11-1
			// //取步骤依赖的前续步骤
			// MtlSysActstepDef step =
			// this.sysActStepDefDao.getSysActStepDef(stepId);
			// Short preStepId = step.getPreStepId();
			// //如果没有前续步骤，直接返�?
			// if (preStepId == null || preStepId.shortValue() ==
			// MpmCONST.MPM_CAMP_STEP_NO_PRESTEP)
			// return true;
			// //如果步骤的依赖步骤需要特殊处�?
			// else if (preStepId.shortValue() ==
			// MpmCONST.MPM_CAMP_STEP_SPECIAL_PRESTEP) {
			// //取流程中包含的所有步�?
			// Iterator it =
			// sysActStepDefDao.getSysActStepDefByFlowId(flowId,new
			// Short(MpmCONST.MPM_CAMP_STEP_PHASE_DEFINE)).iterator();
			// MtlSysActstepDef stpDef;
			// List stepIds = new ArrayList();
			// while (it.hasNext()) {
			// stpDef = (MtlSysActstepDef)it.next();
			// stepIds.add(stpDef.getStepId());
			// }
			//
			// //如果是目标群运算步骤-25，如果定义了20步骤，则前续步骤�?0；如果没有定�?5步骤，则前续步骤�?0
			// if (stepId.shortValue() ==
			// MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_AGGREGATE) {
			// if (stepIds.contains(new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SELECT)))
			// preStepId =
			// Short.valueOf(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SELECT);
			// else if (stepIds.contains(new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_ACTIVE_TEMPLET)))
			// preStepId = new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_ACTIVE_TEMPLET);
			// }
			// //如果是剔除条件设置步�?30，如果定义了25步骤，则前续步骤�?5；如果没有定�?5步骤，则前续步骤�?0
			// else if (stepId.shortValue() ==
			// MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_FILTER) {
			// if (stepIds.contains(new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_AGGREGATE)))
			// preStepId = new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_AGGREGATE);
			// else if (stepIds.contains(new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SELECT)))
			// preStepId =
			// Short.valueOf(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SELECT);
			// }
			// //如果是目标客户圈定步�?40，如果在流程中定义了30步骤，则本步骤的前续步骤�?0；如果定义了25步骤，则前续步骤�?5�?
			// //如果没有定义30�?5步骤，则本步骤的前续步骤�?0
			// else if (stepId.shortValue() ==
			// MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_CONFIRM) {
			// if (stepIds.contains(new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_FILTER)))
			// preStepId =
			// Short.valueOf(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_FILTER);
			// else if (stepIds.contains(new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_AGGREGATE)))
			// preStepId = new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_AGGREGATE);
			// else if (stepIds.contains(new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SELECT)))
			// preStepId =
			// Short.valueOf(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SELECT);
			// }
			// //如果是营销规则步骤-70，如果在流程中定义了60步骤，则本步骤的前续步骤�?0；如果在流程中定义了40步骤，则前续步骤�?0；如果是纯宣传的营销活动，则没有前续步骤�?
			// else if (stepId.shortValue() ==
			// MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SALE_RULE) {
			// //取活动类�?
			// if (campType == null)
			// campType = Short.valueOf(this.getCampTypeByFlowId(flowId));
			// //如果是纯宣传类型的活动，不需要前续步�?
			// if (campType.shortValue() == MpmCONST.MPM_CAMP_TYPE_PASSVITY)
			// return true;
			//
			// if (stepIds.contains(new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_GROUPINGRUN)))
			// preStepId = new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_GROUPINGRUN);
			// else if (stepIds.contains(new
			// Short(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_CONFIRM)))
			// preStepId =
			// Short.valueOf(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_CONFIRM);
			// }
			// }

			// added by wwl 2007-11-1 取流程中当前步骤的前续、后续步骤编�?
			String[] stepIds = this.getPreAndNextStepIdCache(flowId, stepId.toString());
			if (StringUtil.isEmpty(stepIds[0])) {
				return true;
			} else {
				// 取前续步骤在活动波次下的执行情况
				MtlCampsegProgress progress = progressDao.getCampsegProgress(new MtlCampsegProgressId(campsegId, Short
						.valueOf(stepIds[0]), flowId));
				if (progress == null
						|| progress.getPerformFlag().shortValue() != MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_SUCCESS) {
					return false;
				}
				return true;
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.pdhdbcbzdq"));
		}
	}

	public boolean isCampsegExist(String campId) {
		boolean res = false;
		try {
			res = sysActStepDefDao.getCampsegStatus(campId);
		} catch (Exception e) {
			log.error("", e);
		}
		return res;
	}

	public boolean isApproveExist(String s1, String s2, boolean flag) {
		boolean res = false;
		try {
			List list = null;
			if (flag) {
				list = mpmApproveRelationDao.findByCondtion(s1, s2, "");
				if (list != null && list.size() > 0) {
					res = true;
				}
			} else {
				list = mpmApproveRelationDao.findByCondtion(s1, "", s2);
				if (list != null && list.size() > 0) {
					res = true;
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return res;
	}

	public boolean isNextOrPreApproveExist(String createUserid, String approveLevel, boolean flag) {
		boolean res = false;
		try {
			if (flag) {
				res = mpmApproveRelationDao.isNextApproveExist(createUserid, approveLevel);
			} else {
				res = mpmApproveRelationDao.isPreApproveExist(createUserid, approveLevel);
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return res;
	}

	public int isDimColumnExist(String columnName, String sourceName, boolean flag) {
		int res = 0;
		try {
			res = commonJdbcDao.isDimColumnExists(columnName, sourceName);
		} catch (Exception e) {
			log.error("", e);
		}
		return res;
	}

	public boolean isFirstUserApprove(String createUserId) throws Exception {
		boolean res = false;
		try {
			res = mpmApproveRelationDao.isFirstUserApprove(createUserId);
		} catch (Exception e) {

		}
		return res;
	}

	public IMtlSysActStepDefDao getSysActStepDefDao() {
		return sysActStepDefDao;
	}

	public void setSysActStepDefDao(IMtlSysActStepDefDao sysActStepDefDao) {
		this.sysActStepDefDao = sysActStepDefDao;
	}

	public IMpmCommonJdbcDao getCommonJdbcDao() {
		return commonJdbcDao;
	}

	public void setCommonJdbcDao(IMpmCommonJdbcDao commonJdbcDao) {
		this.commonJdbcDao = commonJdbcDao;
	}

	/**
	 * 根基驱动类型 决定是获取大客户经理还是策反客户经理
	 *
	 * @param campType
	 * @return
	 * @throws MpmException
	 */
	public List getVipOrCompManagerSelectListCache(Short campType) throws MpmException {
		List list = null;
		try {
			String VipOrComp = Configure.getInstance().getProperty("MPM_VIP_OR_COMP_MANAGER");
			// 有策反大客户经理且驱动类型为竞争对手策反
			// if (VipOrComp.equals("1") && campType.shortValue() ==
			// MpmCONST.MPM_DRV_COMPAGIN_CF)
			// list = this.getComVipManagerSelectListCache();
			// else
			list = this.getVipManagerSelectListCache();
		} catch (Exception e) {

		}
		return list;
	}

	/**
	 * 获得传统渠道类型下拉�?
	 */
	public List getTraditionChannelTypeSelectListCache() throws MpmException {
		List list = null;
		try {
			list = channelTypeDao.getObjList();
			Iterator i = list.iterator();
			list = new ArrayList();
			while (i.hasNext()) {
				DimPubChanneltype obj = (DimPubChanneltype) i.next();
				list.add(new LabelValueBean(obj.getChanneltypeName(), obj.getChanneltypeId().toString()));
			}
		} catch (Exception e) {
			log.error(e);
			throw new MpmException(e);
		}
		return list;
	}

	/**
	 * 获得渠道类型下拉�?传统渠道,电子渠道和客户经�? 渠道评估�?
	 */
	public List getChannelTypeListCache() throws MpmException {
		List list = null;
		List resultList = new ArrayList();
		try {
			// 电子渠道和客户经�?
			Map map = MpmCache.getInstance().getMapByType(MpmCONST.CHANNEL_TYPE + "");
			Iterator it = map.entrySet().iterator();

			while (it.hasNext()) {
				Map.Entry entry = (Map.Entry) it.next();
				resultList.add(new LabelValueBean((String) entry.getValue(), (String) entry.getKey()));
			}

			// 传统渠道
			list = channelTypeDao.getAllChannelType();
			Iterator i = list.iterator();

			while (i.hasNext()) {
				DimPubChanneltype obj = (DimPubChanneltype) i.next();
				resultList.add(new LabelValueBean(obj.getChanneltypeName(), obj.getChanneltypeId().toString()));
			}
		} catch (Exception e) {
			log.error(e);
			throw new MpmException(e);
		}

		return resultList;
	}

	/**
	 * 获得渠道下拉�?
	 */
	public List getTraditionChannleSelectListCache(String channelTypeId) throws MpmException {
		List list = null;
		try {
			list = channelDao.getObjListByChannleType(channelTypeId);
			Iterator i = list.iterator();
			list = new ArrayList();
			while (i.hasNext()) {
				DimPubChannel obj = (DimPubChannel) i.next();
				list.add(new LabelValueBean(obj.getChannelName(), obj.getChanneltypeId() + "-" + obj.getChannelId()));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(e);
		}
		return list;
	}

	/**
	 * 获得渠道联动�?
	 */
	public String getTraditionChannelArrayCache() throws MpmException {
		List list = null;
		StringBuffer str = new StringBuffer();
		str.append("var channelcount=0;channel = new Array();");
		int count = 0;
		try {
			list = channelDao.getObjList();
			Iterator i = list.iterator();
			while (i.hasNext()) {
				DimPubChannel obj = (DimPubChannel) i.next();
				str.append("channel[" + count + "] = new Array(\"" + obj.getChannelName() + "\",\""
						+ obj.getChanneltypeId() + "\",\"" + obj.getChannelId() + "\");");
				count++;
			}
			str.append("channelcount=" + count);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(e);
		}
		return str.toString();
	}

	public short getCampTypeByFlowId(String flowId) throws MpmException {
		short flowType = 1;
		try {
			MtlSysActflowDef flowDef = actFlowDefDao.findById(flowId);
			flowType = flowDef.getCampType().shortValue();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hdhdqdlxcc"));
		}
		return flowType;
	}

	public String[] getPreAndNextStepIdCache(String flowId, String currStepId) throws MpmException {
		String[] resArr = new String[2];
		try {
			List stepList = flowstepDefDao.getSysFlowstepDefByFlowId(flowId);
			MtlSysFlowstepDef preFlowstepDef = null;
			MtlSysFlowstepDef nextFlowstepDef = null;
			MtlSysFlowstepDef currFlowstepDef = null;
			for (int i = 0; i < stepList.size(); i++) {
				currFlowstepDef = (MtlSysFlowstepDef) stepList.get(i);
				if (currFlowstepDef.getId().getStepId().equals(currStepId)) {
					// 没有前一个步�?
					if (preFlowstepDef == null) {
						resArr[0] = null;
						// 有前一个步�?
					} else {
						resArr[0] = preFlowstepDef.getId().getStepId();
					}

					// 有后一个步�?
					if (i <= (stepList.size() - 2)) {
						nextFlowstepDef = (MtlSysFlowstepDef) stepList.get(i + 1);
						resArr[1] = nextFlowstepDef.getId().getStepId();
					}
					// 没有后一个步�?
					else {
						resArr[1] = null;
					}
					break;
				}
				preFlowstepDef = currFlowstepDef;
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hdbzdqxhxb"));
		}
		return resArr;
	}

	public String getNextStepIdCache(String flowId, String currStepId) throws MpmException {
		String[] stepIdArr = this.getPreAndNextStepIdCache(flowId, currStepId);
		if (stepIdArr[1] == null) {
			return "";
		} else {
			return stepIdArr[1];
		}
	}

	public String getPreStepIdCache(String flowId, String currStepId) throws MpmException {
		String[] stepIdArr = this.getPreAndNextStepIdCache(flowId, currStepId);
		if (stepIdArr[0] == null) {
			return "";
		} else {
			return stepIdArr[0];
		}
	}

	public String getLastUserDataMonthCache(String mainTable) throws MpmException {
		String lastUserBaseDataMonth = MpmLocaleUtil.getMessage("mcd.java.xtzmyjgyld");
		try {
			String currMonth = DateUtil.getCurrentMonth();
			String userBaseTables[] = new String[12];
			String preMonth;
			// 判断�?年的时间中是否存在某个最新月份的客户数据�?
			for (int i = 0; i < 4; i++) {
				preMonth = DateUtil.date2String(DateUtil.getOffsetDate(currMonth + "01", 0 - i, "month"),
						DateUtil.YYYY_MM_DD).substring(0, 7);
				;
				preMonth = preMonth.substring(0, 4) + preMonth.substring(5, 7);
				userBaseTables[i] = mainTable + "_" + preMonth;
			}

			lastUserBaseDataMonth = commonJdbcDao.getFirstExistTable(userBaseTables);

			if (lastUserBaseDataMonth != null && lastUserBaseDataMonth.length() > 0) {
				lastUserBaseDataMonth = StringFunc.replace2(lastUserBaseDataMonth, mainTable + "_", "");
				lastUserBaseDataMonth = lastUserBaseDataMonth.substring(0, 4) + "-"
						+ lastUserBaseDataMonth.substring(4, 6);
			}
		} catch (Exception e) {
			log.error("", e);
			// throw new MpmException("取系统当前最新的用户数据月份失败�?);
		}
		return lastUserBaseDataMonth;
	}

	public List getUserBaseDataMonthListCache(String mainTable) throws MpmException {
		List list = new ArrayList();
		try {
			String currMonth = DateUtil.getCurrentMonth();
			String userBaseTables[] = new String[12];
			String preMonth;
			// 判断�?年的时间中是否存在某个最新月份的客户数据�?
			for (int i = 1; i <= 4; i++) {
				preMonth = DateUtil.date2String(DateUtil.getOffsetDate(currMonth + "01", 0 - i, "month"),
						DateUtil.YYYY_MM_DD).substring(0, 7);
				preMonth = preMonth.substring(0, 4) + preMonth.substring(5, 7);
				userBaseTables[i - 1] = mainTable + "_" + preMonth;
			}

			Iterator it = commonJdbcDao.getExistTables(userBaseTables).iterator();
			String tableName;
			while (it.hasNext()) {
				tableName = (String) it.next();
				tableName = StringFunc.replace2(tableName, mainTable + "_", "");
				tableName = tableName.substring(0, 4) + "-" + tableName.substring(4, 6);
				list.add(new LabelValueBean(tableName, tableName));
			}

		} catch (Exception e) {
			log.error("", e);
			// throw new MpmException("取系统当前最新的用户数据月份失败�?);
		}
		return list;
	}

	public void updateCampsegProgressFlag(String campsegId, String stepId, String flag) throws MpmException {
		try {
			campsegProgressDao.updateCampsegProgressFlag(campsegId, null, new Short[] { Short.valueOf(stepId) },
					Short.valueOf(flag));
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.gxhdbcbzcl"));
		}
	}

	public boolean isCampsegSelectSeted(String campsegId) throws MpmException {
		boolean res = false;
		try {
			MtlCampsegProgressId id = new MtlCampsegProgressId();
			id.setCampsegId(campsegId);
			id.setStepId(Short.valueOf(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SELECT));

			MtlCampsegProgress progress = campsegProgressDao.getCampsegProgress(id);
			if (progress != null && progress.getProformResult() != null && progress.getProformResult().length() > 1) {
				res = true;
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.pdhdbcdmbk"));
		}
		return res;
	}

	public String getDataSrcColumnDescCache(String sourceName, String columnName) throws MpmException {
		String res = "";
		try {
			MtlCampDatasrcColumn obj = mpmCampDatasrcColumnDao.getCampDatasrcColumn(sourceName, columnName);
			if (obj != null) {
				res = obj.getColumnDesc();
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.pdhdbcdmbk"));
		}
		return (res == null ? "" : res);
	}

	public boolean isDeptHasSetApprover(String deptId) throws MpmException {
		boolean res = false;
		try {
			List list = mpmApproveRelationDao.findByCondtion(deptId, null, null);
			res = (list.size() > 0) ? true : false;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qgszzjgxxs"));
		}
		return res;
	}

	public int isApproverExistInCampseg(String campsegId, String currUserId, String approverUserId) throws MpmException {
		int res = 0;
		try {
			// 判断approverUserId是否已经存在在campsegId的审批人列表�?
			MtlCampsegApproverList approverList = new MtlCampsegApproverList();
			approverList.getId().setCampsegId(campsegId);
			approverList.setApproveUserid(approverUserId);
			List list = mtlCampsegApproverListDao.findCampsegApprover(approverList);
			res = (list.size() > 0) ? 1 : 0;
			if (res > 0) {
				return res;
			}

			// 判断是否存在approverUserId转发给curruserId的审批日�?
			MtlApproveAdvice advice = new MtlApproveAdvice();
			advice.getId().setCampsegId(campsegId);
			advice.getId().setSponorUserId(approverUserId);
			advice.getId().setActorUserId(currUserId);
			advice.getId().setSponsorType(Short.valueOf(MpmCONST.MPM_APPROVE_SPONSOR_TYPE_REDIRECT));
			list = mtlApproveAdviceDao.findApproveAdvice(advice);
			res = (list.size() > 0) ? 2 : 0;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsprzhdbcd"));
		}
		return res;
	}

	public List getAllMtlChanneltype(DimMtlChanneltype type) throws MpmException {
		try {
			return dimMtlChanneltypeDao.findMtlChanneltype(type);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqdlxdysb"));
		}
	}

	/*
	 * （非 Javadoc�?
	 * 
	 * @seecom.ai.bdx.frame.approval.service.IMpmCommonService#
	 * getApproveFlowidByChannelTypeAndId (java.lang.String, java.lang.String)
	 */
	public String getApproveFlowidByChannelTypeAndId(String type, String cid) throws MpmException {
		// TODO 自动生成方法存根
		return commonJdbcDao.getApproveFlowidByChannelTypeAndId(type, cid);
	}

	/*
	 * （非 Javadoc�?
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.service.IMpmCommonService#getApproveFlowid(java
	 * .lang .String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public String getApproveFlowid(String userid, String campDrvId, String channeltypeId, String channelId,
			String approveType) throws MpmException {
		// TODO 自动生成方法存根
		return commonJdbcDao.getApproveFlowid(userid, campDrvId, channeltypeId, channelId, approveType);
	}

	public String getApproveFlowid(String userid, String campDrvId, String approveType) throws MpmException {
		return commonJdbcDao.getApproveFlowid(userid, campDrvId, approveType);
	}

	public String getApproveFlowid(String userid, String approveType) throws MpmException {

		// TODO 自动生成方法存根
		return commonJdbcDao.getApproveFlowid(userid, approveType);
	}

	/*
	 * （非 Javadoc�?
	 * 
	 * @see com.ai.bdx.frame.approval.service.IMpmCommonService#
	 * LoadCampsegSmsFeedbackFile (java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	public short LoadCampsegSmsFeedbackFile(String campsegId, String feedbackType, String fileName) {
		// TODO 自动生成方法存根
		Connection cn = null;
		Statement sm = null;
		PreparedStatement pstm = null;
		String tmpName = "MTL_sms_dm_" + campsegId + "_" + MpmUtil.convertLongMillsToYYYYMMDDHHMMSS(-1);
		String tabName = "MTL_sms_dm_" + campsegId;
		String CREATE_TABLE_SMS_SQL = "create table ? (product_no	varchar(12)	not null,content_code	varchar(10) ,send_time	timestamp not null,reply_time	timestamp not null,channel_id	varchar(32) not null,channeltype_id	smallint not null,reply_handle_result smallint not null) ";
		String DEL_SMS_REP_SQL = "delete from ?1 a where    exists ( select * from ?2   b  where a.product_no = b.product_no)";
		String INSERT_SMS_SQL = "insert into ?1 (product_no,content_code,send_time,reply_time,channel_id,channeltype_id,reply_handle_result) select product_no,content_code,send_time,reply_time,channel_id,channeltype_id,reply_handle_result from (select a.* ,row_number() over(partition by product_no order by product_no)	as rank_no from ?2 a) b where b.rank_no = 1";
		int totalNeedLoadCnt = 0;
		int successLoadCnt = 0;
		try {
			log.debug("Thread:" + Thread.currentThread().getName() + " start");

			String strDataSourceName = Configure.getInstance().getProperty("JDBC_MPM");
			if (StringUtil.isEmpty(strDataSourceName)) {
				throw new Exception(MpmLocaleUtil.getMessage("mcd.java.JDBCljpzJD"));
			}
			try {
				cn = AiomniConnectionFactory.getInstance(strDataSourceName).getConnection();
			} catch (Exception e) {
				log.error("", e);
			}

			cn.setAutoCommit(false);

			// 创建存放目标客户文件数据的表
			sm = cn.createStatement();
			String createSql = StringFunc.replace2(CREATE_TABLE_SMS_SQL, "?", tmpName);
			// log.debug("createSql="+createSql);
			createSql = MpmUtil.getCreateTableSql(createSql);
			// log.debug("createSql="+createSql);
			// sqlca.execute(createSql);
			sm.executeUpdate(createSql);
			// int value = sm.executeUpdate(createSql);
			// log.debug("sm.executeUpdate(createSql) =" + value);

			String filename = fileName;
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			String tmpLine, tmpSql;
			String productNo, contentCode, channelId;
			Date sendTime, replyTime;
			short channeltypeId, replyHandleResult;
			int cnt = 0;
			int index = -1;
			int firstpoint;
			// DateFormat df = DateFormat.getDateInstance();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			StringBuilder sb = new StringBuilder("insert into ");
			sb.append(tmpName)
					.append("(product_no,content_code,send_time,reply_time,channel_id,channeltype_id,reply_handle_result) values(?,?,?,?,?,?,?)");
			pstm = cn.prepareStatement(sb.toString());
			// pstm =
			// cn.prepareStatement("insert into "+tabName+" values(?,?,?,?,?,?,?)");
			while ((tmpLine = reader.readLine()) != null) {
				log.debug(">>LoadCampsegSmsFeedbackFile reader.readLine() " + tmpLine);
				totalNeedLoadCnt++;
				try {
					index = tmpLine.indexOf(",");
					// log.debug("the first word index =" + index);
					if (index < 0) {
						log.error("lack of column 1");
						continue;
					}

					productNo = tmpLine.substring(0, index);
					if (StringUtil.isEmpty(productNo)) {
						log.error("productNo is null ");
						continue;
					}
					// log.debug("productNo=" + productNo);

					firstpoint = index + 1;
					index = tmpLine.indexOf(",", index + 1);
					if (index < 0) {
						log.error("lack of column 2");
						continue;
					}

					contentCode = tmpLine.substring(firstpoint, index);
					/*
					 * if(contentCode == null || contentCode.length() == 0){
					 * log.error("contentCode is null"); continue; }
					 */// log.debug("contentCode=" + contentCode);
					firstpoint = index + 1;
					index = tmpLine.indexOf(",", index + 1);
					if (index < 0) {
						log.error("lack of column 3");
						continue;
					}

					// sendTime = (new
					// SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(smsFeedback.getReplyTime())
					sendTime = df.parse(tmpLine.substring(firstpoint, index).trim());
					// log.debug("sendTime=" + sendTime);
					// sendTime =
					// (SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(sendTime);
					// sendTime = new Date(tmpLine.substring(firstpoint,
					// index-1));
					// java.util.Date.parse(arg0);
					if (sendTime == null) {
						log.error("sendTime is null");
						continue;
					}

					firstpoint = index + 1;
					index = tmpLine.indexOf(",", index + 1);
					if (index < 0) {
						log.error("lack of column 4");
						continue;
					}

					replyTime = df.parse(tmpLine.substring(firstpoint, index).trim());
					if (replyTime == null) {
						log.error("replyTime is null");
						continue;
					}
					// log.debug("replyTime=" + replyTime);

					firstpoint = index + 1;
					index = tmpLine.indexOf(",", index + 1);
					if (index < 0) {
						log.error("lack of column 5");
						continue;
					}

					channelId = tmpLine.substring(firstpoint, index);
					if (StringUtil.isEmpty(channelId)) {
						log.error("channelId is null");
						continue;
					}
					// log.debug("channelId=" + channelId);

					firstpoint = index + 1;
					index = tmpLine.indexOf(",", index + 1);
					if (index < 0) {
						log.error("lack of column 6");
						continue;
					}

					if (tmpLine.substring(firstpoint, index).trim() == null) {
						log.error("channeltypeId is null");
						continue;
					}
					channeltypeId = Short.parseShort(tmpLine.substring(firstpoint, index).trim());
					// log.debug("channeltypeId=" + channeltypeId);

					firstpoint = index + 1;
					index = tmpLine.indexOf(",", index + 1);
					log.debug("the last index is:" + index);
					if (index < 0) {
						log.error("lack of column 7");
						continue;
					}

					if (tmpLine.substring(firstpoint, index - 1).trim() == null) {
						log.error("replyHandleResult is null");
						continue;
					}
					replyHandleResult = Short.parseShort(tmpLine.substring(firstpoint, index).trim());

					// 处理多列问题
					index = tmpLine.indexOf(",", index + 1);
					log.debug("the index is:" + index);
					if (index > 0) {
						log.error("column nums is error,nums > 7");
						continue;
					}
					// log.debug("replyHandleResult=" + replyHandleResult);
					// 多列是否需要处�??

					pstm.setString(1, productNo.trim());
					pstm.setString(2, contentCode.trim());
					pstm.setString(3, df.format(sendTime));
					pstm.setString(4, df.format(replyTime));
					// pstm.setDate(3, sendTime);
					// pstm.setDate(4, replyTime);
					pstm.setString(5, channelId.trim());
					pstm.setShort(6, channeltypeId);
					pstm.setShort(7, replyHandleResult);

				} catch (Exception e) {
					log.error("row " + totalNeedLoadCnt + " is error:", e);
					continue;
				}

				pstm.addBatch();
				cnt++;
				if (cnt > 1000) {
					pstm.executeBatch();
					cnt = 0;
					cn.commit();
				}
				successLoadCnt++;
			}
			// log.debug("file read over");
			// log.debug("test 001 ");
			if (cnt > 0) {
				pstm.executeBatch();
			}
			// log.debug("test 002 ");
			cn.commit();
			// log.debug("test 003 ");

			String deleteSql = StringFunc.replace2(DEL_SMS_REP_SQL, "?1", tmpName);
			deleteSql = StringFunc.replace2(deleteSql, "?2", tabName);
			log.debug("deleteSql=" + deleteSql);
			sm.executeUpdate(deleteSql);
			// log.debug("test 004 ");

			String insertSql = StringFunc.replace2(INSERT_SMS_SQL, "?1", tabName);
			insertSql = StringFunc.replace2(insertSql, "?2", tmpName);
			log.debug("insertSql=" + insertSql);
			// createSql = MpmUtil.getCreateTableSql(createSql);
			// sqlca.execute(createSql);
			int insertNums = sm.executeUpdate(insertSql);
			// log.debug("sm.executeUpdate(insertSql) =" + insertNums);
			// sm.executeUpdate(insertSql);
			// log.debug("test 005 ");
			cn.commit();

			sm.close();
			pstm.close();

			log.debug(MpmLocaleUtil.getMessage("mcd.java.zjls") + totalNeedLoadCnt
					+ MpmLocaleUtil.getMessage("mcd.java.zzdlsb") + successLoadCnt
					+ MpmLocaleUtil.getMessage("mcd.java.tjlsjcgzz") + insertNums
					+ MpmLocaleUtil.getMessage("mcd.java.tjl"));
			String msg = "";
			short flag = MpmCONST.MPM_FILTER_FILE_LOAD_TYPE_SUCCESS;
			if (successLoadCnt == 0) {
				msg = MpmLocaleUtil.getMessage("mcd.java.zzcgltjlqj1");
				flag = MpmCONST.MPM_FILTER_FILE_LOAD_TYPE_FAILURE;
				return 0;
			}

			return 1;
		} catch (Exception e) {
			log.error("", e);
			try {
				if (cn != null) {
					cn.rollback();
				}
				return 0;
			} catch (Exception e3) {
				log.error(">>rollback error: ", e3);
			}
		} finally {
			try {
				if (sm != null) {
					sm.close();
				}
				if (pstm != null) {
					pstm.close();
				}
				if (cn != null) {
					cn.close();
				}
			} catch (Exception e) {
			}
			// log.debug(">>LoadCampsegSmsFeedbackFile end at " + Thread.));
			log.debug(">>LoadCampsegSmsFeedbackFile end at "
					+ MpmUtil.convertLongMillsToStrTime(System.currentTimeMillis()));
			log.debug("Thread:" + Thread.currentThread().getName() + " finished");
		}
		return 0;
	}

	/**
	 * 更新剔除文件装载处理时的状�?
	 *
	 * @param filterFileId
	 * @param loadType
	 * @throws Exception
	 */
	private void updateFilterFileLoadType(String filterFileId, Short loadType, Connection cn) throws Exception {
		Statement sm = null;
		try {
			sm = cn.createStatement();
			String updateSql = StringFunc.replace2(UPDATE_LOAD_TYPE, "?1", loadType + "");
			updateSql = StringFunc.replace2(updateSql, "?2", filterFileId);
			log.debug(">>\n" + updateSql);
			sm.execute(updateSql);
			cn.commit();
		} catch (Exception e) {
			if (sm != null) {
				sm.close();
				sm = null;
			}
			throw e;
		} finally {
			if (sm != null) {
				sm.close();
				sm = null;
			}
		}
	}

	/**
	 * 更新剔除文件装载成功后保存的表名
	 *
	 * @param filterFileId
	 * @param tabName
	 * @throws Exception
	 */
	private void updateFilterFileTabName(String filterFileId, String tabName, Connection cn) throws Exception {
		Statement sm = null;
		try {
			sm = cn.createStatement();
			String updateSql = StringFunc.replace2(UPDATE_TAB_NAME, "?1", tabName);
			updateSql = StringFunc.replace2(updateSql, "?2", filterFileId);
			log.debug(">>\n" + updateSql);
			sm.execute(updateSql);
			cn.commit();
		} catch (Exception e) {
			if (sm != null) {
				sm.close();
				sm = null;
			}
			throw e;
		} finally {
			if (sm != null) {
				sm.close();
				sm = null;
			}
		}
	}

	/**
	 * 更新文件装载处理时的状�?
	 *
	 * @param filterFileId
	 * @param loadType
	 * @throws Exception
	 */
	private void updateFileLoadType(String filterFileId, Short loadType, String errMsg, Connection cn) throws Exception {
		Statement sm = null;
		try {
			sm = cn.createStatement();
			String sql = UPDATE_LOAD_TYPE3;
			if (errMsg != null && errMsg.length() > 0) {
				sql = UPDATE_LOAD_TYPE2;
			}
			String updateSql = StringFunc.replace2(sql, "?1", loadType + "");
			updateSql = StringFunc.replace2(updateSql, "?2", filterFileId);
			updateSql = StringFunc.replace2(updateSql, "?3", errMsg);
			log.debug(">>\n" + updateSql);
			sm.execute(updateSql);
			cn.commit();
			sm.close();
			sm = null;
		} catch (Exception e) {
			if (sm != null) {
				sm.close();
				sm = null;
			}
			throw e;
		} finally {
			if (sm != null) {
				sm.close();
				sm = null;
			}
		}
	}

	/**
	 * 更新文件装载成功后保存的表名
	 *
	 * @param filterFileId
	 * @param tabName
	 * @throws Exception
	 */
	private void updateFileTabName(String filterFileId, String tabName, int totalNeedLoadCnt, int successLoadCnt,
			Connection cn) throws Exception {
		Statement sm = null;
		try {
			sm = cn.createStatement();
			String updateSql = StringFunc.replace2(UPDATE_TAB_NAME3, "?1", tabName);
			updateSql = StringFunc.replace2(updateSql, "?2", String.valueOf(totalNeedLoadCnt));
			updateSql = StringFunc.replace2(updateSql, "?3", String.valueOf(successLoadCnt));
			updateSql = StringFunc.replace2(updateSql, "?4", filterFileId);
			FastDateFormat dFormat = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
			String strDBType = MpmUtil.getDBType();
			if (strDBType != null && strDBType.equalsIgnoreCase("ORACLE")) {
				updateSql = StringFunc.replace2(updateSql, "?5", "to_date('" + dFormat.format(new Date())
						+ "','yyyy-mm-dd hh24:MI:ss')");
			} else {
				updateSql = StringFunc.replace2(updateSql, "?5", "'" + dFormat.format(new Date()) + "'");
			}
			log.debug(">>\n" + updateSql);
			sm.execute(updateSql);
			cn.commit();
		} catch (Exception e) {
			if (sm != null) {
				sm.close();
				sm = null;
			}
			throw e;
		} finally {
			if (sm != null) {
				sm.close();
				sm = null;
			}
		}
	}

	/**
	 * 外部系统传入数据源字段属性定义表中字段客户群编号、字段中文名称、字段数据类型分类�?字段中文名称、字段分类、字段标识、字段说明，保存到营销互动平台
	 *
	 * @param custGroupId
	 *            客户群编�?
	 * @param columnName
	 *            字段名称
	 * @param columnType
	 *            字段数据类型分类
	 * @param columnCname
	 *            字段中文名称
	 * @param columnClass
	 *            字段分类
	 * @param columnFlag
	 *            字段标识
	 * @param columnDesc
	 *            字段说明
	 * @param columnSerNo
	 *            字段序号 没有定义�?
	 * @param columnDatatype
	 *            字段数据类型
	 * @param columnStatus
	 *            字段状�?0 - 可用�? - 失效)
	 * @return 是否保存成功(0 - 失败�? - 成功)
	 */
	/*
	 * public void insertDatasrcColumnInfo(String custGroupId, String
	 * columnName, String columnType, String columnCname, String columnClass,
	 * String columnFlag, String columnDesc, String columnSerNo, String
	 * columnDatatype, Short columnStatus) throws Exception { Sqlca sqlca =
	 * null; try { sqlca = new Sqlca(new ConnectionEx("JDBC_MPM"));
	 * sqlca.setAutoCommit(false);
	 * 
	 * //加入数据源字段属性定义表数据 String sourceName = "mtl_cuser_" + custGroupId; String
	 * updateSql = StringFunc.replace2(INSERT_Datasrc_Column_SQL, "?1",
	 * sourceName); updateSql = StringFunc.replace2(updateSql, "?2",
	 * columnName); updateSql = StringFunc.replace2(updateSql, "?3",
	 * columnType); updateSql = StringFunc.replace2(updateSql, "?4",
	 * columnCname); updateSql = StringFunc.replace2(updateSql, "?5",
	 * columnClass); updateSql = StringFunc.replace2(updateSql, "?6",
	 * columnFlag); updateSql = StringFunc.replace2(updateSql, "?7",
	 * columnDesc); updateSql = StringFunc.replace2(updateSql, "?8",
	 * columnSerNo);
	 * 
	 * //因做替换�?10替换时会先替换掉?1,故导致替换错误，故从9开始后面用不重复�?updateSql =
	 * StringFunc.replace2(updateSql, "?90", columnDatatype); updateSql =
	 * StringFunc.replace2(updateSql, "?91", String.valueOf(columnStatus));
	 * 
	 * log.debug(">>\n" + updateSql); sqlca.execute(updateSql); sqlca.commit();
	 * } catch (Exception e) { if (sqlca != null) sqlca.rollback(); throw e; }
	 * finally { if (sqlca != null) sqlca.closeAll(); } }
	 */
	/**
	 * 往MTL_camp_data_source插入表信息，往MTL_camp_datasrc_column插入表字段信�?
	 *
	 * @param sourceName
	 * @param sourceCName
	 * @throws Exception
	 */
	private void insertDataSourceInfo(String sourceName, String sourceCName, String[] columnCname, Connection cn)
			throws Exception {
		Statement sm = null;
		try {
			sm = cn.createStatement();
			String updateSql = StringFunc.replace2(INSERT_DATASOURCE_SQL3, "?1", sourceName);
			updateSql = StringFunc.replace2(updateSql, "?2", sourceCName);
			updateSql = StringFunc.replace2(updateSql, "?3", this.getSqlNow());
			log.debug(">>\n" + updateSql);
			sm.execute(updateSql);
			// 加入手机号码
			updateSql = StringFunc.replace2(INSERT_DATASOURCE_COLUMN_SQL3, "?1", "product_no");
			updateSql = StringFunc.replace2(updateSql, "?2", sourceName);
			updateSql = StringFunc.replace2(updateSql, "?3", String.valueOf(MpmCONST.MPM_DS_COLUMN_TYPE_STRING));
			updateSql = StringFunc.replace2(updateSql, "?4", MpmLocaleUtil.getMessage("mcd.java.sjhm"));
			updateSql = StringFunc.replace2(updateSql, "?5", "1");
			updateSql = StringFunc.replace2(updateSql, "?6", "varchar(12) not null");
			updateSql = StringFunc.replace2(updateSql, "?7", MpmLocaleUtil.getMessage("mcd.java.khsjhm"));
			updateSql = StringFunc.replace2(updateSql, "?8", "2");
			log.debug(">>\n" + updateSql);
			sm.execute(updateSql);
			// 加入文件标识
			updateSql = StringFunc.replace2(INSERT_DATASOURCE_COLUMN_SQL3, "?1", "file_idx_flag");
			updateSql = StringFunc.replace2(updateSql, "?2", sourceName);
			updateSql = StringFunc.replace2(updateSql, "?3", String.valueOf(MpmCONST.MPM_DS_COLUMN_TYPE_NUMBER));
			updateSql = StringFunc.replace2(updateSql, "?4", MpmLocaleUtil.getMessage("mcd.java.sybs"));
			updateSql = StringFunc.replace2(updateSql, "?5", "2");
			updateSql = StringFunc.replace2(updateSql, "?6", "smallint not null");
			updateSql = StringFunc.replace2(updateSql, "?7", MpmLocaleUtil.getMessage("mcd.java.wjxlbs"));
			updateSql = StringFunc.replace2(updateSql, "?8", "1");
			log.debug(">>\n" + updateSql);
			sm.execute(updateSql);

			// 加入外部导入扩展属�?
			for (int i = 1; i <= 5; i++) {
				updateSql = StringFunc.replace2(INSERT_DATASOURCE_COLUMN_SQL3, "?1", "col" + i);
				updateSql = StringFunc.replace2(updateSql, "?2", sourceName);
				updateSql = StringFunc.replace2(updateSql, "?3", String.valueOf(MpmCONST.MPM_DS_COLUMN_TYPE_STRING));

				// 如果扩展属性名为空，则不记录这条记�?
				if (columnCname == null || columnCname.length == 0 || columnCname[i - 1] == null
						|| columnCname[i - 1].length() == 0) {
					continue;
				}

				if (columnCname == null || columnCname.length == 0 || columnCname[i - 1] == null
						|| columnCname[i - 1].length() == 0) {
					updateSql = StringFunc.replace2(updateSql, "?4", MpmLocaleUtil.getMessage("mcd.java.kzsx") + i);
				} else {
					updateSql = StringFunc.replace2(updateSql, "?4", columnCname[i - 1]);
				}
				updateSql = StringFunc.replace2(updateSql, "?5", String.valueOf(i + 2));
				updateSql = StringFunc.replace2(updateSql, "?6", "varchar(500)");
				updateSql = StringFunc.replace2(updateSql, "?7", MpmLocaleUtil.getMessage("mcd.java.kzsx"));
				updateSql = StringFunc.replace2(updateSql, "?8", "1");
				log.debug(">>\n" + updateSql);
				sm.execute(updateSql);
			}
			cn.commit();
		} catch (Exception e) {
			if (sm != null) {
				sm.close();
				sm = null;
			}
			throw e;
		} finally {
			if (sm != null) {
				sm.close();
				sm = null;
			}
		}
	}

	public String getSqlNow() throws Exception {
		String strType = Configure.getInstance().getProperty("MPM_DBTYPE");
		if (strType == null) {
			return "sysdate";
		}
		String strRet = "";
		if (strType.equalsIgnoreCase("MYSQL")) {
			strRet = "now()";
		} else if (strType.equalsIgnoreCase("ORACLE")) {
			strRet = "sysdate";
		} else if (strType.equalsIgnoreCase("ACCESS")) {
			strRet = "date()+time()";
		} else if (strType.equalsIgnoreCase("SQLSERVER")) {
			strRet = "getdate()";
		} else if (strType.equalsIgnoreCase("DB2")) {
			strRet = "current timestamp";
		} else if (strType.equalsIgnoreCase("TERA")) {
			strRet = "cast((date (format 'yyyy-mm-dd' )) as char(10)) ||' '|| time";
		} else if (strType.equalsIgnoreCase("SYSBASE")) {
			strRet = "getdate()";
		} else {
			throw new Exception(MpmLocaleUtil.getMessage("mcd.java.bnqddqrqdh"));
		}
		return strRet;
	}

	/**
	 * 外部系统传入数据库链路，营销互动平台把通过数据库链路把数据加载到客户群清单表中
	 *
	 * @param custGroupId
	 *            客户群编�?
	 * @param dbName
	 *            外部系统客户群对应的数据库名�?
	 * @param schema
	 *            外部系统客户群对应的模式名称
	 * @param sourceName
	 *            外部系统客户群清单表�?
	 * @param columnName
	 *            外部系统客户群清单号码字段名�?
	 * @return 是否保存成功(0 - 失败�? - 成功)
	 */
	public void insertCustGroupDataByDBLink(String custGroupId, String dbName, String schema, String sourceName,
			String columnName) throws Exception {
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(new ConnectionEx("JDBC_MPM"));
			sqlca.setAutoCommit(false);
			String updateSql = null;
			String querySQL = null;

			// 取得建客户群表需要的列字段及列类�?
			querySQL = "select lower(a.column_name) as column_name, column_datatype from MTL_templet_active_field a, MTL_camp_datasrc_column b "
					+ "where a.active_templet_id =(select active_templet_id from mtl_cust_group where cust_group_id = ?) "
					+ "and a.source_name = b.source_name and a.column_name = b.column_name "
					+ "order by b.column_serno,lower(a.column_name)";
			log.debug(">>\n" + querySQL);
			sqlca.execute(querySQL, new String[] { custGroupId });
			String tableColumnList = null;
			String columnList = null;
			boolean isSpecialTemplet = false;
			while (sqlca.next()) {
				if (tableColumnList == null) {
					columnList = sqlca.getString("column_name");
					tableColumnList = columnList + " " + sqlca.getString("column_datatype");
				} else {
					columnList = columnList + "," + sqlca.getString("column_name");
					tableColumnList = tableColumnList + "," + columnList + " " + sqlca.getString("column_datatype");
				}
			}

			String tableName = "mtl_cuser_" + custGroupId;
			updateSql = "create table " + tableName + "(" + tableColumnList + ")";
			log.debug(">>\n" + updateSql);
			sqlca.execute(updateSql);

			if (schema != null && schema.length() != 0) {
				// updateSql = "insert into " + tableName + " (" + columnList +
				// ") " + " select " + columnName + " from "+ schema + "." +
				// sourceName;
				updateSql = new StringBuffer("insert into ").append(tableName).append(" (").append(columnList)
						.append(") ").append(" select ").append(columnName).append(" from ").append(schema).append(".")
						.append(sourceName).toString();
			} else {
				// updateSql = "insert into " + tableName + " (" + columnList +
				// ") " + " select " + columnName + " from "+ sourceName;
				updateSql = new StringBuffer("insert into ").append(tableName).append(" (").append(columnList)
						.append(") ").append(" select ").append(columnName).append(" from ").append(sourceName)
						.toString();
			}
			// updateSql = "insert into " + tableName + " (" + columnList +") "
			// + " select " + columnList + " from " + schema + "." + sourceName;
			if (dbName != null && dbName.length() != 0) {
				updateSql = updateSql + "@" + dbName;
			}
			log.debug(">>\n" + updateSql);
			sqlca.execute(updateSql);

			sqlca.commit();
		} catch (Exception e) {
			if (sqlca != null) {
				sqlca.rollback();
			}
			throw e;
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
	}

	/**
	 * 解压缩zip数据文件，并传回解压缩后数据文件名称
	 *
	 * @param filepath
	 *            文件路径名称
	 * @param zipFileName
	 *            zip数据文件
	 * @return 解压缩后数据文件名称
	 */
	public String unzip(String filepath, String zipFileName) throws Exception {
		try {
			String zipFile = filepath + File.separator + zipFileName;
			final int BUFFER = 2048;
			BufferedOutputStream dest = null;
			FileInputStream fis = new FileInputStream(zipFile);
			ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
			ZipEntry entry;

			// zip文件只包括一个文件，只取一�?
			if ((entry = zis.getNextEntry()) != null) { // 存放压缩文件名或路径�?
				int count;
				byte data[] = new byte[BUFFER];
				// write the files to the disk
				String outFile = filepath + File.separator + entry.getName();
				// log.debug(outFile);
				FileOutputStream fos = new FileOutputStream(outFile);
				dest = new BufferedOutputStream(fos, BUFFER);

				// 写文�?
				while ((count = zis.read(data, 0, BUFFER)) != -1) {
					dest.write(data, 0, count);
				}
				dest.flush();
				dest.close();
			}
			zis.close();
			return entry.getName();
		} catch (Exception e) {
			log.debug(">>\n" + e);
			throw e;
		}
	}

	public List getCampDrvTypeListByType(String type) throws Exception {
		List result = new ArrayList();
		try {
			result = campDevTypeDao.getCampDrvTypeListByType(type);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqqdlxcw"));
		}
		return result;
	}

	public String getDrvTypeName(Short drvTypeId) throws Exception {
		DimCampDrvType obj = null;
		try {
			obj = campDevTypeDao.getDrvType(drvTypeId);
		} catch (Exception e) {
			log.error("", e);
		}
		return obj.getCampDrvName();
	}

	public Connection getConnectionForWAS(String strDataSourceName) {
		DataSource ds = null;
		Connection cn = null;
		try {
			// websphere�?-在北京WEBSPHERE下测试，
			String jndi = strDataSourceName.substring(new String("java:comp/env/").length());
			Context ctx = new InitialContext();
			if (ctx == null) {
				throw new Exception("Boom - No Context");
			}

			if (jndi != null) {
				String strDbJndi = jndi;
				if (strDbJndi.startsWith("java:comp/env/")) {
					strDbJndi = strDbJndi.substring(14);
				}
				ds = (DataSource) ctx.lookup(strDbJndi);
				cn = ds.getConnection();
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return cn;
	}

	public void saveObjCosts(String campsegId, String objCode[], String objCost[]) throws MpmException {
		// TODO Auto-generated method stub
		Map map = new TreeMap();
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(new ConnectionEx("JDBC_MPM"));
			sqlca.execute("delete from MTL_SEGINFO_OBJ where campseg_id=?", new String[] { campsegId });
			if (objCode != null && objCode.length > 0) {
				for (int i = 1; i < objCode.length; i++) {
					sqlca.execute("insert into MTL_SEGINFO_OBJ(campseg_id,obj_id,obj_value) values(?,?,?)",
							new Object[] { campsegId, objCode[i], objCost[i] });
				}
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bchdcbmbcw"));
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
	}

	public List getObjCostList(String campsegId) throws MpmException {
		// TODO Auto-generated method stub
		List list = new ArrayList();
		Sqlca sqlca = null;
		try {
			sqlca = new Sqlca(new ConnectionEx("JDBC_MPM"));
			sqlca.execute("select a.cost_code as obj_id,a.cost_name as obj_name,obj_value from AP_COST_LIST a,mtl_seginfo_obj b where a.cost_code=b.obj_id and b.campseg_id='"
					+ campsegId + "'");
			while (sqlca.next()) {
				MtlSeginfoObj mtlSeginfoObj = new MtlSeginfoObj();
				mtlSeginfoObj.setCampsegId(campsegId);
				mtlSeginfoObj.setObjCode(sqlca.getInt("obj_id") + "");
				mtlSeginfoObj.setObjName(sqlca.getString("obj_name"));
				mtlSeginfoObj.setObjCost(String.valueOf(sqlca.getDouble("obj_value")));
				list.add(mtlSeginfoObj);
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdcbmbcw"));
		} finally {
			if (sqlca != null) {
				sqlca.closeAll();
			}
		}
		return list;
	}

	/*
	 * （非 Javadoc�?
	 * 
	 * @see
	 * com.ai.bdx.frame.approval.service.IMpmCommonService#excludeBlackList(java
	 * .lang .String, java.lang.String)
	 */
	public String excludeBlackList(String srcTable, String avoidCustTypes) {
		// TODO 自动生成方法存根
		return commonJdbcDao.excludeBlackList(srcTable, avoidCustTypes);
	}

	public IMtlCampsegProgressDao getCampsegProgressDao() {
		return campsegProgressDao;
	}

	public void setCampsegProgressDao(IMtlCampsegProgressDao campsegProgressDao) {
		this.campsegProgressDao = campsegProgressDao;
	}

	public IMpmCampDatasrcColumnDao getMpmCampDatasrcColumnDao() {
		return mpmCampDatasrcColumnDao;
	}

	public void setMpmCampDatasrcColumnDao(IMpmCampDatasrcColumnDao mpmCampDatasrcColumnDao) {
		this.mpmCampDatasrcColumnDao = mpmCampDatasrcColumnDao;
	}

	public IMpmCampDatasrcColumnDao getCampDatasrcColumnDao() {
		return campDatasrcColumnDao;
	}

	public void setCampDatasrcColumnDao(IMpmCampDatasrcColumnDao campDatasrcColumnDao) {
		this.campDatasrcColumnDao = campDatasrcColumnDao;
	}

	public IMtlCampsegApproverListDao getMtlCampsegApproverListDao() {
		return mtlCampsegApproverListDao;
	}

	public void setMtlCampsegApproverListDao(IMtlCampsegApproverListDao mtlCampsegApproverListDao) {
		this.mtlCampsegApproverListDao = mtlCampsegApproverListDao;
	}

	public IMtlApproveAdviceDao getMtlApproveAdviceDao() {
		return mtlApproveAdviceDao;
	}

	public void setMtlApproveAdviceDao(IMtlApproveAdviceDao mtlApproveAdviceDao) {
		this.mtlApproveAdviceDao = mtlApproveAdviceDao;
	}

	/**
	 * @return approveConfirmListDao
	 */
	public IMtlApproveConfirmListDao getApproveConfirmListDao() {
		return approveConfirmListDao;
	}

	/**
	 * @param approveConfirmListDao
	 *            要设置的 approveConfirmListDao
	 */
	public void setApproveConfirmListDao(IMtlApproveConfirmListDao approveConfirmListDao) {
		this.approveConfirmListDao = approveConfirmListDao;
	}

	public IDimMtlChanneltypeDao getDimMtlChanneltypeDao() {
		return dimMtlChanneltypeDao;
	}

	public void setDimMtlChanneltypeDao(IDimMtlChanneltypeDao dimMtlChanneltypeDao) {
		this.dimMtlChanneltypeDao = dimMtlChanneltypeDao;
	}

	public IDimMtlChannelDao getDimMtlChannelDao() {
		return dimMtlChannelDao;
	}

	public void setDimMtlChannelDao(IDimMtlChannelDao dimMtlChannelDao) {
		this.dimMtlChannelDao = dimMtlChannelDao;
	}

	public IMpmCampDataSourceDao getCampDatasourceDao() {
		return campDatasourceDao;
	}

	public void setCampDatasourceDao(IMpmCampDataSourceDao campDatasourceDao) {
		this.campDatasourceDao = campDatasourceDao;
	}

	public String testFmtMess(String fmtMess) throws MpmException {
		String returnMess = "OK";
		boolean matched = false;
		// 2.校验括号中的字符串是否符合要求（“[表名.字段名称]”）
		try {
			String regex = "\\[(([\\S&[^\\p{Cntrl}]&[^\\.]&&[^\\[]]+?)\\.([\\S&[^\\p{Cntrl}]&[^\\.]&&[^\\[]]+?))\\]";
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(fmtMess);
			int lastMatch = 0;
			StringBuilder sb = new StringBuilder();
			for (int counter = 0; m.find(); counter++, matched = true) {
				String tabName = m.group(2);
				String colName = m.group(3);
				// 3.校验表名是否存在
				MtlCampDataSource mcds = campDatasourceDao.findByTabCname(tabName);
				if (mcds == null) {
					returnMess = MpmLocaleUtil.getMessage("mcd.java.2") + tabName
							+ MpmLocaleUtil.getMessage("mcd.java.bczqzxsr");
					return returnMess;

				}
				// 4.校验字段名称是否存在
				MtlCampDatasrcColumn mcdc = campDatasrcColumnDao.findByColCname(colName);
				if (mcdc == null) {
					returnMess = MpmLocaleUtil.getMessage("mcd.java.2") + colName
							+ MpmLocaleUtil.getMessage("mcd.java.zdbczqzxsr");
					return returnMess;
				}
			}
			if (!matched) {
				returnMess = MpmLocaleUtil.getMessage("mcd.java.cgshxxzmyp");
				return returnMess;
			}
		} catch (MpmException e) {
			log.error("", e);
		}
		return returnMess;
	}

	@Override
	public Map findCampDrvList(DimCampDrvType dab, Integer curPage, Integer pageSize) throws MpmException {
		Map map = new TreeMap();
		try {
			map = campDevTypeDao.findCampDrvList(dab, curPage, pageSize);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qkhmdrlxcw"));
		}
		return map;
	}

	@Override
	public List getCampCanAnalyseList(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCampSegCanAnalyseArray(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBrandHtmlByCampIdCache(String campId, String selectName) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampList(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getInitiativeCampList(String userId) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampListAll(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampListAllbyfile(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampListAlloddact(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCampSegArrayoddact(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampListAlloddCall(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCampSegArrayoddCall(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampSegListbyoddact(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampSegListbyfile(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampSegArrayoddactbyfile(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampsegListByCampId(String campid) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampSegList(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampSegListForHD(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCampSegArray(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map getCampPriMap() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map getDimPubBrandMap() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getAllStcPlan() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getReplaceLabelList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isCampsegApproveExist(String createUserid) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List getVipManagerSelectListCache() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getComVipManagerSelectListCache() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVipManagerArrayCache() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isPublicizeCombCanDelete(String combId, String currUserId, String groupId) throws MpmException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCanConfirmOrApprove(String campId, String campsegId, String flowId, String flag) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Map getCampChannelTypeMap(String campId) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getInterfaceTable() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCampSegArrayExec(String campsegStatId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampListbyExec() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampListAlloddWeb(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCampSegArrayoddWeb(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map getScenesElementsMap(String scenesId) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map getDimCustTypeMap() throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findCampsegByChannelTypeId(String channeltypeId, String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getCampSegListExec(String campsegStatId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustDataMonth(String custGroupId) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isPartnerCanDelete(String partnerId, String currUserId, String groupId) throws MpmException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isPlanCanDelete(String planId, String currUserId, String groupId) throws MpmException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getCustGroupByCampSeg(String campSegId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCalendarDate(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getStcPlans(String planIds) throws MpmException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<LabelValueBean> getBsMmsContent() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getMtlStcPlanName(String planIdStr) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TreeMap getBrandTreeMap() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAllBrandString() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteAttachmentById(String attaId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIrUnitName(String unitId) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean isReplayExist(String feed, String channelType) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCustGroupCanDelete(String custGroupId, String currUserId, String groupId) throws MpmException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCustGroupCanDivide(String custGroupId, String currUserId, String groupId) throws MpmException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int isCustGroupCanChgStatus(String custGroupId, String currUserId, String groupId) throws MpmException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCustGroupTypeById(String custid) {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<LabelValueBean> getAllApproveDrvDimTable() throws Exception {
		ConnectionEx conn = null;
		Sqlca sqlca = null;
		String sql = "select id,var_table_desc from ap_approve_drv_dimtable order by id asc";
		List<LabelValueBean> list = new ArrayList<LabelValueBean>();
		try {
			conn = new ConnectionEx("JDBC_APP");
			sqlca = new Sqlca(conn);
			sqlca.execute(sql);
			while (sqlca.next()) {
				String id = sqlca.getString("id");
				String table = sqlca.getString("var_table_desc");
				list.add(new LabelValueBean(table, id));
			}
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null)
				sqlca.close();
			try {
				if (!conn.isClosed()) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public List<LabelValueBean> getListApproveDrvDimTableCon(String tid) throws Exception {

		ConnectionEx conn = null;
		Sqlca sqlca = null;
		String sql = "select id,var_table_code,var_table_id_coloum,var_table_val_coloum,var_jndi from ap_approve_drv_dimtable where id=?";
		String[] tableList = null;
		try {
			conn = new ConnectionEx("JDBC_APP");
			sqlca = new Sqlca(conn);
			sqlca.execute(sql, new String[] { tid });
			while (sqlca.next()) {
				String id = sqlca.getString("id");
				String table_code = sqlca.getString("var_table_code");
				String table_id_coloum = sqlca.getString("var_table_id_coloum");
				String table_val_coloum = sqlca.getString("var_table_val_coloum");
				String jndi = sqlca.getString("var_jndi");
				tableList = new String[] { id, table_code, table_id_coloum, table_val_coloum, jndi };
			}
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null)
				sqlca.close();
			try {
				if (!conn.isClosed()) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		List<LabelValueBean> cList = new ArrayList<LabelValueBean>();
		if (tableList != null) {
			//取所有内容表
			ConnectionEx con = null;
			Sqlca sqlca1 = null;
			String id = tableList[0];
			String sqlCon = new StringBuffer("select ").append(tableList[2]).append(" as id,").append(tableList[3])
					.append(" as val from ").append(tableList[1]).append(" order by ").append(tableList[2])
					.append(" asc").toString();

			try {
				con = new ConnectionEx(tableList[4]);
				sqlca1 = new Sqlca(con);
				sqlca1.execute(sqlCon);
				while (sqlca1.next()) {
					String c_id = sqlca1.getString("id");
					String c_val = sqlca1.getString("val");
					cList.add(new LabelValueBean(c_val, c_id));
				}
			} catch (Exception e) {
				log.error("", e);
			} finally {
				if (sqlca1 != null)
					sqlca1.close();
				try {
					if (!con.isClosed()) {
						con.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}
		return cList;
	}

	public Map<String, Map<String, String>> getMapApproveDrvDimTableCon() throws Exception {

		ConnectionEx conn = null;
		Sqlca sqlca = null;
		String sql = "select id,var_table_code,var_table_id_coloum,var_table_val_coloum,var_jndi from ap_approve_drv_dimtable";
		List<String[]> tableList = new ArrayList<String[]>();
		try {
			conn = new ConnectionEx("JDBC_APP");
			sqlca = new Sqlca(conn);
			sqlca.execute(sql);
			while (sqlca.next()) {
				String id = sqlca.getString("id");
				String table_code = sqlca.getString("var_table_code");
				String table_id_coloum = sqlca.getString("var_table_id_coloum");
				String table_val_coloum = sqlca.getString("var_table_val_coloum");
				String jndi = sqlca.getString("var_jndi");
				tableList.add(new String[] { id, table_code, table_id_coloum, table_val_coloum, jndi });
			}
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null)
				sqlca.close();
			try {
				if (!conn.isClosed()) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Map<String, Map<String, String>> retMap = new HashMap<String, Map<String, String>>();
		if (tableList != null) {
			for (String[] arrs : tableList) {
				//取所有内容表
				ConnectionEx con = null;
				Sqlca sqlca1 = null;
				String id = arrs[0];
				String sqlCon = new StringBuffer("select ").append(arrs[2]).append(" as id,").append(arrs[3])
						.append(" as val from ").append(arrs[1]).append(" order by ").append(arrs[2]).append(" asc")
						.toString();
				Map<String, String> map = new HashMap<String, String>();
				try {
					con = new ConnectionEx(arrs[4]);
					sqlca1 = new Sqlca(con);
					sqlca1.execute(sqlCon);
					while (sqlca1.next()) {
						String c_id = sqlca1.getString("id");
						String c_val = sqlca1.getString("val");
						map.put(c_id, c_val);
					}
					retMap.put(id, map);
				} catch (Exception e) {
					log.error("", e);
				} finally {
					if (sqlca1 != null)
						sqlca1.close();
					try {
						if (!con.isClosed()) {
							con.close();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}

		}
		return retMap;
	}

	public String getAllApproveDrvDimTableConByid(String tid) throws Exception {
		JSONArray ja = new JSONArray();
		if (StringUtil.isNotEmpty(tid)) {
			ConnectionEx conn = null;
			Sqlca sqlca = null;
			String sql = "select id,var_table_code,var_table_id_coloum,var_table_val_coloum,var_jndi from ap_approve_drv_dimtable where id=?";
			List<String[]> tableList = new ArrayList<String[]>();
			try {
				conn = new ConnectionEx("JDBC_APP");
				sqlca = new Sqlca(conn);
				sqlca.execute(sql, new String[] { tid });
				while (sqlca.next()) {
					String id = sqlca.getString("id");
					String table_code = sqlca.getString("var_table_code");
					String table_id_coloum = sqlca.getString("var_table_id_coloum");
					String table_val_coloum = sqlca.getString("var_table_val_coloum");
					String jndi = sqlca.getString("var_jndi");
					tableList.add(new String[] { id, table_code, table_id_coloum, table_val_coloum, jndi });
				}
			} catch (Exception e) {
				log.error("", e);
			} finally {
				if (sqlca != null)
					sqlca.close();
				try {
					if (!conn.isClosed()) {
						conn.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			//取所有内容表
			if (tableList.size() > 0) {
				for (String[] arrs : tableList) {
					ConnectionEx con = null;
					Sqlca sqlca1 = null;
					String id = arrs[0];
					String sqlCon = new StringBuffer("select ").append(arrs[2]).append(" as id,").append(arrs[3])
							.append(" as val from ").append(arrs[1]).append(" order by ").append(arrs[2])
							.append(" asc").toString();
					try {
						con = new ConnectionEx(arrs[4]);
						sqlca1 = new Sqlca(con);
						sqlca1.execute(sqlCon);
						while (sqlca1.next()) {
							JSONObject json = new JSONObject();
							String c_id = sqlca1.getString("id");
							String c_val = sqlca1.getString("val");
							json.put("code", c_id);
							json.put("val", c_val);
							ja.add(json.toString());
							json.clear();
						}
					} catch (Exception e) {
						log.error("", e);
					} finally {
						if (sqlca1 != null)
							sqlca1.close();
						try {
							if (!con.isClosed()) {
								con.close();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}

		}
		return ja.toString();
	}

	@Override
	public boolean isFlowRelationExist(String relationType, String campDrvId, String cityId, String deptId,
			String approveFlowId, String flow_type) {
		ConnectionEx conn = null;
		Sqlca sqlca = null;
		boolean flag = false;
		try {
			String sql = "select count(1)  as count from ap_dept_flow_relation where CITY_ID=? and DEPT_ID=? and CAMP_DRV_ID=? and RELATION_TYPE=? and APPR_FLOW_TPYE=?";
			conn = new ConnectionEx("JDBC_APP");
			sqlca = new Sqlca(conn);
			sqlca.execute(sql, new String[] { cityId, deptId, campDrvId, relationType, flow_type });
			int count = 0;
			while (sqlca.next()) {
				count = sqlca.getInt("count");
			}
			if (count > 0) {
				flag = true;
			}
		} catch (Exception e) {
			log.error("", e);
		} finally {
			if (sqlca != null)
				sqlca.close();
			try {
				if (!conn.isClosed()) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return flag;
	}

	@Override
	public boolean isDrvExist(String tableID, String tableColVal, String flowId, String campDrvId) {
		ConnectionEx conn = null;
		Sqlca sqlca = null;
		boolean flag = false;
		if (StringUtil.isEmpty(campDrvId) && StringUtil.isNotEmpty(tableID) && StringUtil.isNotEmpty(tableColVal)) {
			try {

				conn = new ConnectionEx("JDBC_APP");
				sqlca = new Sqlca(conn);
				/*String sql="select count(1)  as count from ap_approve_drv_type where CAMP_DRV_ID=?";
				sqlca.execute(sql,new String[]{campDrvId});
				int count=0;
				while (sqlca.next()) {
					count = sqlca.getInt("count");
				}*/

				int count1 = 0;
				String sql1 = "select count(1)  as count1 from ap_approve_drv_type where table_id=?  and table_col_val=?";
				sqlca.execute(sql1, new String[] { tableID, tableColVal });
				while (sqlca.next()) {
					count1 = sqlca.getInt("count1");
				}
				if (count1 > 0) {
					flag = true;
				}

			} catch (Exception e) {
				log.error("", e);
			} finally {
				if (sqlca != null)
					sqlca.close();
				try {
					if (!conn.isClosed()) {
						conn.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		return flag;
	}

}

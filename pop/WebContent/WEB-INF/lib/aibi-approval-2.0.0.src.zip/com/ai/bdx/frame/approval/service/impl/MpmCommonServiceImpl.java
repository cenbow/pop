/*      */ package com.ai.bdx.frame.approval.service.impl;
/*      */ 
/*      */ import com.ai.bdx.frame.approval.bean.MtlSeginfoObj;
/*      */ import com.ai.bdx.frame.approval.dao.IDimCampDrvTypeDao;
/*      */ import com.ai.bdx.frame.approval.dao.IDimMtlChannelDao;
/*      */ import com.ai.bdx.frame.approval.dao.IDimMtlChanneltypeDao;
/*      */ import com.ai.bdx.frame.approval.dao.IDimPubChannelDao;
/*      */ import com.ai.bdx.frame.approval.dao.IDimPubChannelTypeDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMpmApproveRelationDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMpmCampDataSourceDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMpmCampDatasrcColumnDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMpmCommonJdbcDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMpmSysActflowDefDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMpmSysFlowstepDefDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMtlApproveAdviceDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMtlApproveConfirmListDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMtlCampsegProgressDao;
/*      */ import com.ai.bdx.frame.approval.dao.IMtlSysActStepDefDao;
/*      */ import com.ai.bdx.frame.approval.exception.MpmException;
/*      */ import com.ai.bdx.frame.approval.model.DimCampDrvType;
/*      */ import com.ai.bdx.frame.approval.model.DimDrvRoleManager;
/*      */ import com.ai.bdx.frame.approval.model.DimMtlChanneltype;
/*      */ import com.ai.bdx.frame.approval.model.DimPubChannel;
/*      */ import com.ai.bdx.frame.approval.model.DimPubChanneltype;
/*      */ import com.ai.bdx.frame.approval.model.MtlApproveAdvice;
/*      */ import com.ai.bdx.frame.approval.model.MtlApproveAdviceId;
/*      */ import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
/*      */ import com.ai.bdx.frame.approval.model.MtlCampDataSource;
/*      */ import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
/*      */ import com.ai.bdx.frame.approval.model.MtlCampsegApproverList;
/*      */ import com.ai.bdx.frame.approval.model.MtlCampsegApproverListId;
/*      */ import com.ai.bdx.frame.approval.model.MtlCampsegProgress;
/*      */ import com.ai.bdx.frame.approval.model.MtlCampsegProgressId;
/*      */ import com.ai.bdx.frame.approval.model.MtlPlanExecType;
/*      */ import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
/*      */ import com.ai.bdx.frame.approval.model.MtlSysFlowstepDef;
/*      */ import com.ai.bdx.frame.approval.model.MtlSysFlowstepDefId;
/*      */ import com.ai.bdx.frame.approval.service.IMpmCommonService;
/*      */ import com.ai.bdx.frame.approval.util.MpmCache;
/*      */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*      */ import com.ai.bdx.frame.approval.util.MpmUtil;
/*      */ import com.ai.bdx.frame.approval.util.StringFunc;
/*      */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*      */ import com.asiainfo.biframe.privilege.base.util.OperString;
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.AiomniConnectionFactory;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.date.DateUtil;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FileReader;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Statement;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipInputStream;
/*      */ import javax.naming.Context;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.sql.DataSource;
/*      */ import net.sf.json.JSONArray;
/*      */ import net.sf.json.JSONObject;
/*      */ import org.apache.commons.lang.time.FastDateFormat;
/*      */ import org.apache.logging.log4j.LogManager;
/*      */ import org.apache.logging.log4j.Logger;
/*      */ import org.apache.struts.util.LabelValueBean;
/*      */ 
/*      */ public class MpmCommonServiceImpl
/*      */   implements IMpmCommonService
/*      */ {
/*   92 */   private static Logger log = LogManager.getLogger();
/*      */   private IMpmCommonJdbcDao commonJdbcDao;
/*      */   private IDimCampDrvTypeDao campDevTypeDao;
/*      */   private IUserPrivilegeCommonService userPolicyService;
/*      */   private IDimPubChannelTypeDao channelTypeDao;
/*      */   private IDimPubChannelDao channelDao;
/*      */   private IMtlSysActStepDefDao sysActStepDefDao;
/*      */   private IMpmApproveRelationDao mpmApproveRelationDao;
/*      */   private IMpmSysActflowDefDao actFlowDefDao;
/*      */   private IMpmSysFlowstepDefDao flowstepDefDao;
/*      */   private IMtlCampsegProgressDao campsegProgressDao;
/*      */   private IMpmCampDatasrcColumnDao mpmCampDatasrcColumnDao;
/*      */   private IMpmCampDataSourceDao campDatasourceDao;
/*      */   private IMpmCampDatasrcColumnDao campDatasrcColumnDao;
/*      */   private IMtlCampsegApproverListDao mtlCampsegApproverListDao;
/*      */   private IMtlApproveAdviceDao mtlApproveAdviceDao;
/*      */   private IMtlApproveConfirmListDao approveConfirmListDao;
/*      */   private IDimMtlChanneltypeDao dimMtlChanneltypeDao;
/*      */   private IDimMtlChannelDao dimMtlChannelDao;
/*      */   private IMtlApproveFlowDefDao mtlApproveFlowDefDao;
/*      */   private IMtlCampsegProgressDao progressDao;
/*  189 */   private final String CREATE_TABLE_SQL = "create table ? (product_no varchar(12) not null)";
/*  190 */   private final String ALTER_TABLE_PK_SQL = "alter table ? add primary key(product_no)";
/*  191 */   private final String UPDATE_LOAD_TYPE = "update mtl_filter_file set file_load_type=?1 where filter_file_id='?2'";
/*  192 */   private final String UPDATE_TAB_NAME = "update mtl_filter_file set load_tabname='?1' where filter_file_id='?2'";
/*  193 */   private final String DELETE_REPEAT_RECORD = "delete from (select PRODUCT_NO,row_number() over(partition by PRODUCT_NO) as row_seq from ?) t where t.row_seq>1";
/*  194 */   private final String DELETE_REPEAT_RECORD_ORACLE = "delete from ? a  where a.rowid>(select min(b.rowid) from ? b where b.PRODUCT_NO=a.PRODUCT_NO)";
/*  195 */   private final String ALTER_TABLE_PK_SQL3 = "alter table ? add primary key(product_no)";
/*  196 */   private final String UPDATE_LOAD_TYPE3 = "update MTL_targetuser_file set file_load_type=?1 where targetuser_file_id='?2'";
/*  197 */   private final String UPDATE_LOAD_TYPE2 = "update MTL_targetuser_file set file_load_type=?1,TARGETUSER_FILE_DESC='?3' where targetuser_file_id='?2'";
/*  198 */   private final String UPDATE_TAB_NAME3 = "update MTL_targetuser_file set load_tabname='?1',total_need_load_cnt=?2,success_load_cnt=?3,load_end_time=?5 where targetuser_file_id='?4'";
/*  199 */   private static String INSERT_DATASOURCE_SQL3 = "insert into MTL_camp_data_source (source_name,source_cname,source_type,create_time,source_status)  values ('?1','?2',6,?3,1)";
/*      */ 
/*  201 */   private static String INSERT_DATASOURCE_COLUMN_SQL3 = "insert into MTL_camp_datasrc_column (column_name,source_name,column_type,column_cname,column_class,column_flag,column_serno,column_datatype,column_status,column_desc)  values ('?1','?2',?3,'?4',?8,0,?5,'?6',1,'?7')";
/*      */ 
/*  203 */   private static String INSERT_Templet_Active_SQL = "insert into MTL_templet_active (active_templet_id,atemplet_name,create_userid,create_time,atemplet_desc,atemplet_type)  values ('?1','?2','?3',?4,'?5',?6)";
/*      */ 
/*  205 */   private static String INSERT_Cust_Group_SQL = "insert into MTL_cust_group (cust_group_id,cust_group_name,create_user_id,city_id,create_date,cust_group_type,cust_group_num,active_templet_id,cust_group_access_token,cust_group_status)  values ('?1','?2','?3','?4','?5',?6,?7,'?8',?9,1)";
/*      */ 
/*  207 */   private static String INSERT_Templet_Select_SQL = "insert into MTL_templet_select (active_templet_id,select_templet_id,seltemplet_name,select_sql,select_sql_cn,create_userid,create_time,seltemplet_type,seltemplet_desc,result_order_bysql,result_cnorder_bysql)  values ('?1','?2','?3','?4','?5','?6',?7,?8,'?90','?91','?92')";
/*      */ 
/*  209 */   private static String INSERT_Datasrc_Column_SQL = "insert into MTL_camp_datasrc_column (source_name,column_name,column_type,column_cname,column_class,column_flag,column_desc,column_serno,column_datatype,column_status) \tvalues ('?1','?2',?3,'?4',?5,?6,'?7',?8,'?90',?91)";
/*      */ 
/*  212 */   private final String CREATE_TABLE_SQL3 = "create table ? (product_no varchar(12) not null,col1 varchar(500),col2 varchar(500),col3 varchar(500),col4 varchar(500),col5 varchar(500),file_idx_flag smallint)";
/*      */ 
/*  214 */   private final String TAB_NAME_PRE3 = "mtl_suser_";
/*  215 */   private final String TAB_NAME_PRE = "mtl_extelim_";
/*      */ 
/*      */   public IMtlCampsegProgressDao getProgressDao()
/*      */   {
/*  118 */     return this.progressDao;
/*      */   }
/*      */ 
/*      */   public void setProgressDao(IMtlCampsegProgressDao progressDao) {
/*  122 */     this.progressDao = progressDao;
/*      */   }
/*      */ 
/*      */   public IDimCampDrvTypeDao getCampDevTypeDao() {
/*  126 */     return this.campDevTypeDao;
/*      */   }
/*      */ 
/*      */   public void setCampDevTypeDao(IDimCampDrvTypeDao campDevTypeDao) {
/*  130 */     this.campDevTypeDao = campDevTypeDao;
/*      */   }
/*      */ 
/*      */   public IUserPrivilegeCommonService getUserPolicyService() {
/*  134 */     return this.userPolicyService;
/*      */   }
/*      */ 
/*      */   public void setUserPolicyService(IUserPrivilegeCommonService userPolicyService) {
/*  138 */     this.userPolicyService = userPolicyService;
/*      */   }
/*      */ 
/*      */   public IDimPubChannelTypeDao getChannelTypeDao() {
/*  142 */     return this.channelTypeDao;
/*      */   }
/*      */ 
/*      */   public void setChannelTypeDao(IDimPubChannelTypeDao channelTypeDao) {
/*  146 */     this.channelTypeDao = channelTypeDao;
/*      */   }
/*      */ 
/*      */   public IDimPubChannelDao getChannelDao() {
/*  150 */     return this.channelDao;
/*      */   }
/*      */ 
/*      */   public void setChannelDao(IDimPubChannelDao channelDao) {
/*  154 */     this.channelDao = channelDao;
/*      */   }
/*      */ 
/*      */   public IMpmApproveRelationDao getMpmApproveRelationDao() {
/*  158 */     return this.mpmApproveRelationDao;
/*      */   }
/*      */ 
/*      */   public void setMpmApproveRelationDao(IMpmApproveRelationDao mpmApproveRelationDao) {
/*  162 */     this.mpmApproveRelationDao = mpmApproveRelationDao;
/*      */   }
/*      */ 
/*      */   public IMpmSysActflowDefDao getActFlowDefDao() {
/*  166 */     return this.actFlowDefDao;
/*      */   }
/*      */ 
/*      */   public void setActFlowDefDao(IMpmSysActflowDefDao actFlowDefDao) {
/*  170 */     this.actFlowDefDao = actFlowDefDao;
/*      */   }
/*      */ 
/*      */   public IMpmSysFlowstepDefDao getFlowstepDefDao() {
/*  174 */     return this.flowstepDefDao;
/*      */   }
/*      */ 
/*      */   public void setFlowstepDefDao(IMpmSysFlowstepDefDao flowstepDefDao) {
/*  178 */     this.flowstepDefDao = flowstepDefDao;
/*      */   }
/*      */ 
/*      */   public IMtlApproveFlowDefDao getMtlApproveFlowDefDao() {
/*  182 */     return this.mtlApproveFlowDefDao;
/*      */   }
/*      */ 
/*      */   public void setMtlApproveFlowDefDao(IMtlApproveFlowDefDao mtlApproveFlowDefDao) {
/*  186 */     this.mtlApproveFlowDefDao = mtlApproveFlowDefDao;
/*      */   }
/*      */ 
/*      */   public Map getCampChannelTypeMap()
/*      */     throws MpmException
/*      */   {
/*  218 */     Map map = new TreeMap();
/*      */     try {
/*  220 */       Iterator it = this.commonJdbcDao.getCampChannelTypeMap().iterator();
/*  221 */       while (it.hasNext()) {
/*  222 */         Map cm = (Map)it.next();
/*  223 */         map.put(cm.get("CHANNELTYPE_ID").toString(), cm.get("CHANNELTYPE_NAME"));
/*      */       }
/*      */     } catch (Exception e) {
/*  226 */       log.error("", e);
/*  227 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdlxcw"));
/*      */     }
/*  229 */     return map;
/*      */   }
/*      */ 
/*      */   public List<MtlApproveFlowDef> getApproveUserList(String deptId) throws Exception
/*      */   {
/*  234 */     List list = new ArrayList();
/*      */     try {
/*  236 */       list = this.mtlApproveFlowDefDao.getFirstApproveUser(deptId);
/*  237 */       if (list.isEmpty()) {
/*  238 */         MtlApproveFlowDef mafd = new MtlApproveFlowDef();
/*  239 */         mafd.setFirstApproveUser("ADMIN");
/*  240 */         list.add(mafd);
/*      */       }
/*      */     } catch (Exception e) {
/*  243 */       e.printStackTrace();
/*      */     }
/*      */ 
/*  246 */     return list;
/*      */   }
/*      */ 
/*      */   public Map getMtlCampRuleTypeMap() throws MpmException {
/*  250 */     Map map = new TreeMap();
/*      */     try {
/*  252 */       Iterator it = this.commonJdbcDao.getMtlCampRuleTypeMap().iterator();
/*  253 */       while (it.hasNext()) {
/*  254 */         Map cm = (Map)it.next();
/*  255 */         map.put(cm.get("RULE_TYPE_ID").toString(), cm.get("RULE_TYPE_NAME"));
/*      */       }
/*      */     } catch (Exception e) {
/*  258 */       log.error("", e);
/*  259 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdlxcw"));
/*      */     }
/*  261 */     return map;
/*      */   }
/*      */ 
/*      */   public Map getCampChannelIdMap(int channeltypeId) throws Exception
/*      */   {
/*  266 */     Map map = new TreeMap();
/*  267 */     if (channeltypeId == 904) {
/*  268 */       map.put("-1", MpmLocaleUtil.getMessage("mcd.java.qbcfkhjl"));
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  273 */       Iterator it = this.commonJdbcDao.getCampChannelIdMap(channeltypeId).iterator();
/*  274 */       while (it.hasNext()) {
/*  275 */         Map cm = (Map)it.next();
/*  276 */         map.put(cm.get("CHANNEL_ID"), cm.get("CHANNEL_NAME"));
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  280 */       log.error("", e);
/*  281 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqdlxcw"));
/*      */     }
/*  283 */     return map;
/*      */   }
/*      */ 
/*      */   public String getAllChannelIds() throws Exception
/*      */   {
/*  288 */     String channelIds = ",";
/*      */     try {
/*  290 */       Iterator it = this.commonJdbcDao.getAllChannel().iterator();
/*  291 */       while (it.hasNext()) {
/*  292 */         Map cm = (Map)it.next();
/*  293 */         channelIds = new StringBuilder().append(channelIds).append((String)cm.get("CHANNEL_ID")).append(",").toString();
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  297 */       log.error("", e);
/*  298 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qqbqdxxdyc"));
/*      */     }
/*  300 */     return channelIds;
/*      */   }
/*      */ 
/*      */   public List getAllMtlChanneltype() throws MpmException {
/*      */     try {
/*  305 */       return this.dimMtlChanneltypeDao.findMtlChanneltype(null);
/*      */     } catch (Exception e) {
/*  307 */       log.error("", e);
/*  308 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqdlxdysb"));
/*      */   }
/*      */ 
/*      */   public Short getMaxCampDrvId() throws MpmException
/*      */   {
/*      */     try {
/*  314 */       return this.campDevTypeDao.getMaxCampDrvId();
/*      */     } catch (Exception e) {
/*  316 */       log.error("", e);
/*  317 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qkhmdrlxcw"));
/*      */   }
/*      */ 
/*      */   public void saveCampDrvType(DimCampDrvType dcdt) throws MpmException
/*      */   {
/*      */     try {
/*  323 */       this.campDevTypeDao.save(dcdt);
/*      */     } catch (Exception e) {
/*  325 */       log.error("", e);
/*  326 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qkhmdrlxcw"));
/*      */     }
/*      */   }
/*      */ 
/*      */   public DimCampDrvType getDrvType(Short drvTypeId) throws Exception {
/*  331 */     DimCampDrvType obj = null;
/*      */     try {
/*  333 */       obj = this.campDevTypeDao.getDrvType(drvTypeId);
/*      */     } catch (Exception e) {
/*  335 */       log.error("", e);
/*      */     }
/*  337 */     return obj;
/*      */   }
/*      */ 
/*      */   public List getPlanExecTypeMap(MtlPlanExecType mpet) throws MpmException {
/*  341 */     List map = new ArrayList();
/*      */     try {
/*  343 */       map = this.campDevTypeDao.getPlanExecTypeMap(mpet);
/*      */     } catch (Exception e) {
/*  345 */       log.error("", e);
/*  346 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qkhmdrlxcw"));
/*      */     }
/*  348 */     return map;
/*      */   }
/*      */ 
/*      */   public List getAllCampDrvType() throws MpmException {
/*      */     try {
/*  353 */       return this.campDevTypeDao.getAllDrvType();
/*      */     } catch (Exception e) {
/*  355 */       log.error("", e);
/*  356 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdqdlxcw"));
/*      */   }
/*      */ 
/*      */   public boolean isNameExist(String name, String id, String nameType, boolean nameNeedTrans)
/*      */   {
/*  361 */     boolean res = true;
/*      */     try {
/*  363 */       if (nameNeedTrans) {
/*  364 */         name = OperString.ISO2GBK(name);
/*      */       }
/*  366 */       String nameColumn = "";
/*  367 */       String idColumn = "";
/*  368 */       String tableName = nameType;
/*  369 */       int flag = 0;
/*  370 */       if (nameType.equalsIgnoreCase("AP_APPROVE_DRV_TYPE")) {
/*  371 */         nameColumn = "CAMP_DRV_NAME";
/*  372 */         idColumn = "CAMP_DRV_ID";
/*  373 */       } else if (nameType.equals("mtl_camp_baseinfo")) {
/*  374 */         nameColumn = "camp_name";
/*  375 */         idColumn = "camp_id";
/*  376 */       } else if (nameType.equals("mtl_camp_seginfo")) {
/*  377 */         nameColumn = "campseg_name";
/*  378 */         idColumn = "campseg_id";
/*  379 */       } else if (nameType.equals("mtl_templet_active")) {
/*  380 */         nameColumn = "atemplet_name";
/*  381 */         idColumn = "active_templet_id";
/*  382 */       } else if (nameType.equals("mtl_templet_select")) {
/*  383 */         nameColumn = "seltemplet_name";
/*  384 */         idColumn = "select_templet_id";
/*  385 */       } else if (nameType.equals("mtl_templet_filter")) {
/*  386 */         nameColumn = "ftemplet_name";
/*  387 */         idColumn = "filter_templet_id";
/*  388 */       } else if (nameType.equals("mtl_filter_rule_combination")) {
/*  389 */         nameColumn = "filter_rule_name";
/*  390 */         idColumn = "filter_rule_id";
/*  391 */       } else if (nameType.equals("mtl_templet_subsection")) {
/*  392 */         nameColumn = "stemplet_name";
/*  393 */         idColumn = "subsection_templet_id";
/*  394 */       } else if (nameType.equals("mtl_subsection_rule_comb")) {
/*  395 */         nameColumn = "rule_name";
/*  396 */         idColumn = "subsection_rule_id";
/*  397 */       } else if (nameType.equals("mtl_sys_actflow_def")) {
/*  398 */         nameColumn = "flow_name";
/*  399 */         idColumn = "flow_id";
/*  400 */       } else if (nameType.equals("ap_cost_list")) {
/*  401 */         nameColumn = "cost_code";
/*  402 */         flag = 1;
/*  403 */       } else if (nameType.equals("mtl_ir_indi_define")) {
/*  404 */         nameColumn = "id_indi";
/*  405 */       } else if (nameType.equals("mtl_res_list")) {
/*  406 */         nameColumn = "res_name";
/*  407 */         idColumn = "res_code";
/*  408 */       } else if (nameType.equals("mtl_camp_data_source")) {
/*  409 */         nameColumn = "source_name";
/*  410 */       } else if ((nameType.equals("mtl_camp_datasrc_column")) && (id.length() > 0)) {
/*  411 */         nameColumn = "column_name";
/*  412 */         idColumn = "source_name";
/*  413 */         flag = 2;
/*  414 */       } else if ((nameType.equals("mtl_camp_datasrc_column")) && (id.length() == 0)) {
/*  415 */         nameColumn = "column_cname";
/*  416 */       } else if (nameType.equals("mtl_filter_file")) {
/*  417 */         nameColumn = "filter_file_name";
/*  418 */         idColumn = "filter_file_id";
/*  419 */       } else if (nameType.equals("mtl_dim_column_feature")) {
/*  420 */         nameColumn = "column_name";
/*  421 */       } else if (nameType.equals("mtl_sms_mms_code_def")) {
/*  422 */         nameColumn = "content_code";
/*  423 */         idColumn = "campseg_id";
/*  424 */       } else if (nameType.equals("mtl_targetuser_file")) {
/*  425 */         nameColumn = "targetuser_file_name";
/*  426 */       } else if (nameType.equals("mtl_approve_confirm_templet")) {
/*  427 */         nameColumn = "confirm_name";
/*  428 */         idColumn = "confirm_id";
/*  429 */       } else if (nameType.equals("ap_approve_flow_def")) {
/*  430 */         nameColumn = "approve_flow_name";
/*  431 */         idColumn = "approve_flow_id";
/*  432 */       } else if (nameType.equals("mtl_cust_group")) {
/*  433 */         nameColumn = "cust_group_name";
/*  434 */         idColumn = "cust_group_id";
/*  435 */       } else if (nameType.equals("mtl_publicize_comb")) {
/*  436 */         nameColumn = "publicize_comb_name";
/*  437 */         idColumn = "publicize_comb_id";
/*  438 */       } else if (nameType.equalsIgnoreCase("MTL_SCENES_TEMPLET")) {
/*  439 */         nameColumn = "scenes_name";
/*  440 */         idColumn = "scenes_id";
/*  441 */       } else if (nameType.equalsIgnoreCase("mtl_premodel_cfg")) {
/*  442 */         nameColumn = "mname";
/*  443 */         idColumn = "cid";
/*  444 */       } else if (nameType.equalsIgnoreCase("event_tag_define")) {
/*  445 */         nameColumn = "tag_name";
/*  446 */         idColumn = "tag_id";
/*      */       }
/*      */ 
/*  449 */       if (flag == 0) {
/*  450 */         res = this.commonJdbcDao.isNameExist(name, id, idColumn, nameColumn, tableName);
/*      */       }
/*  452 */       else if (flag == 1) {
/*  453 */         res = this.commonJdbcDao.isNameExistForInt(name, id, idColumn, nameColumn, tableName);
/*      */       }
/*  455 */       else if (flag == 2) {
/*  456 */         res = this.commonJdbcDao.isNameExistForDataColumn(name, id, idColumn, nameColumn, tableName);
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  461 */       log.error("", e);
/*      */     }
/*  463 */     return res;
/*      */   }
/*      */ 
/*      */   public Map getCampDrvTypeMap()
/*      */     throws MpmException
/*      */   {
/*  470 */     Map map = new TreeMap();
/*      */     try {
/*  472 */       Iterator it = this.campDevTypeDao.getAllDrvType().iterator();
/*      */ 
/*  474 */       while (it.hasNext()) {
/*  475 */         DimCampDrvType obj = (DimCampDrvType)it.next();
/*  476 */         map.put(obj.getCampDrvId(), obj.getCampDrvName());
/*      */       }
/*      */     } catch (Exception e) {
/*  479 */       log.error("", e);
/*  480 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdqdlxcw"));
/*      */     }
/*  482 */     return map;
/*      */   }
/*      */ 
/*      */   public List getAllCampDrvTypesEnable() throws MpmException {
/*      */     try {
/*  487 */       Object[] objs = this.campDevTypeDao.getAllDrvTypesEnabled();
/*  488 */       List result = (List)objs[0];
/*  489 */       List filter = (List)objs[1];
/*      */ 
/*  493 */       for (Iterator it = result.iterator(); it.hasNext(); ) {
/*  494 */         drv = (DimCampDrvType)it.next();
/*      */ 
/*  496 */         for (filterIt = filter.iterator(); filterIt.hasNext(); ) {
/*  497 */           Short filterId = (Short)filterIt.next();
/*  498 */           if ((filterId != null) && (drv.getParentId() != null) && (drv.getParentId().shortValue() == filterId.shortValue()))
/*      */           {
/*  500 */             it.remove();
/*      */           }
/*      */         }
/*      */       }
/*      */       DimCampDrvType drv;
/*      */       Iterator filterIt;
/*  505 */       filter = null;
/*      */ 
/*  507 */       return result;
/*      */     } catch (Exception e) {
/*  509 */       log.error("", e);
/*  510 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdqdlxcw"));
/*      */   }
/*      */ 
/*      */   public DimDrvRoleManager getAllCampDrvTypeByRoleId(Short campDrvId, String roleId, Short roleFlag)
/*      */     throws MpmException
/*      */   {
/*  523 */     DimDrvRoleManager ddrm = null;
/*      */     try {
/*  525 */       ddrm = this.campDevTypeDao.getAllCampDrvTypeByRoleId(campDrvId, roleId, roleFlag);
/*      */     } catch (Exception e) {
/*  527 */       log.error("", e);
/*  528 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgjsqhdqdl"));
/*      */     }
/*  530 */     return ddrm;
/*      */   }
/*      */ 
/*      */   public boolean getUserDrvAuth(Short campDrvId, String userId, String groupId)
/*      */     throws MpmException
/*      */   {
/*  541 */     boolean flag = false;
/*      */     try {
/*  543 */       flag = this.campDevTypeDao.getUserDrvAuth(campDrvId, userId, groupId);
/*      */     } catch (Exception e) {
/*  545 */       log.error("", e);
/*  546 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgjsqhdqdl"));
/*      */     }
/*  548 */     return flag;
/*      */   }
/*      */ 
/*      */   public List getScenesBycampDrvId(String campDrvId)
/*      */     throws MpmException
/*      */   {
/*      */     try
/*      */     {
/*  560 */       return this.campDevTypeDao.getScenesBycampDrvId(campDrvId);
/*      */     } catch (Exception e) {
/*  562 */       log.error("", e);
/*  563 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qyxcjmbcw"));
/*      */   }
/*      */ 
/*      */   public MtlCampsegProgress getCampsegProgress(String campsegId, String flowId, Short stepId) throws MpmException
/*      */   {
/*      */     try {
/*  569 */       MtlCampsegProgressId key = new MtlCampsegProgressId();
/*  570 */       key.setCampsegId(campsegId);
/*  571 */       key.setFlowId(flowId);
/*  572 */       key.setStepId(stepId);
/*  573 */       return this.progressDao.getCampsegProgress(key);
/*      */     } catch (Exception e) {
/*  575 */       log.error("", e);
/*  576 */       throw new MpmException(new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.qyxhdbcjdc")).append(e).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public short getCampsegProgressStatus(String campsegId, String flowId, Short stepId) throws MpmException {
/*      */     try {
/*  582 */       MtlCampsegProgressId key = new MtlCampsegProgressId();
/*  583 */       key.setCampsegId(campsegId);
/*  584 */       key.setFlowId(flowId);
/*  585 */       key.setStepId(stepId);
/*  586 */       Short status = this.progressDao.getCampsegProgressStatus(key);
/*      */ 
/*  588 */       if (status != null) {
/*  589 */         return status.shortValue();
/*      */       }
/*  591 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ghdbcjdbcz"));
/*      */     }
/*      */     catch (Exception e) {
/*  594 */       log.error("", e);
/*  595 */       throw new MpmException(new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.qyxhdbcjdc")).append(e).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean hasPreStepFinished(String campsegId, String flowId, Short stepId, Short campType)
/*      */     throws MpmException
/*      */   {
/*      */     try
/*      */     {
/*  689 */       String[] stepIds = getPreAndNextStepIdCache(flowId, stepId.toString());
/*  690 */       if (StringUtil.isEmpty(stepIds[0])) {
/*  691 */         return true;
/*      */       }
/*      */ 
/*  694 */       MtlCampsegProgress progress = this.progressDao.getCampsegProgress(new MtlCampsegProgressId(campsegId, Short.valueOf(stepIds[0]), flowId));
/*      */ 
/*  696 */       if ((progress == null) || (progress.getPerformFlag().shortValue() != 1))
/*      */       {
/*  698 */         return false;
/*      */       }
/*  700 */       return true;
/*      */     }
/*      */     catch (Exception e) {
/*  703 */       log.error("", e);
/*  704 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.pdhdbcbzdq"));
/*      */   }
/*      */ 
/*      */   public boolean isCampsegExist(String campId)
/*      */   {
/*  709 */     boolean res = false;
/*      */     try {
/*  711 */       res = this.sysActStepDefDao.getCampsegStatus(campId);
/*      */     } catch (Exception e) {
/*  713 */       log.error("", e);
/*      */     }
/*  715 */     return res;
/*      */   }
/*      */ 
/*      */   public boolean isApproveExist(String s1, String s2, boolean flag) {
/*  719 */     boolean res = false;
/*      */     try {
/*  721 */       List list = null;
/*  722 */       if (flag) {
/*  723 */         list = this.mpmApproveRelationDao.findByCondtion(s1, s2, "");
/*  724 */         if ((list != null) && (list.size() > 0))
/*  725 */           res = true;
/*      */       }
/*      */       else {
/*  728 */         list = this.mpmApproveRelationDao.findByCondtion(s1, "", s2);
/*  729 */         if ((list != null) && (list.size() > 0))
/*  730 */           res = true;
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  734 */       log.error("", e);
/*      */     }
/*  736 */     return res;
/*      */   }
/*      */ 
/*      */   public boolean isNextOrPreApproveExist(String createUserid, String approveLevel, boolean flag) {
/*  740 */     boolean res = false;
/*      */     try {
/*  742 */       if (flag)
/*  743 */         res = this.mpmApproveRelationDao.isNextApproveExist(createUserid, approveLevel);
/*      */       else
/*  745 */         res = this.mpmApproveRelationDao.isPreApproveExist(createUserid, approveLevel);
/*      */     }
/*      */     catch (Exception e) {
/*  748 */       log.error("", e);
/*      */     }
/*  750 */     return res;
/*      */   }
/*      */ 
/*      */   public int isDimColumnExist(String columnName, String sourceName, boolean flag) {
/*  754 */     int res = 0;
/*      */     try {
/*  756 */       res = this.commonJdbcDao.isDimColumnExists(columnName, sourceName);
/*      */     } catch (Exception e) {
/*  758 */       log.error("", e);
/*      */     }
/*  760 */     return res;
/*      */   }
/*      */ 
/*      */   public boolean isFirstUserApprove(String createUserId) throws Exception {
/*  764 */     boolean res = false;
/*      */     try {
/*  766 */       res = this.mpmApproveRelationDao.isFirstUserApprove(createUserId);
/*      */     }
/*      */     catch (Exception e) {
/*      */     }
/*  770 */     return res;
/*      */   }
/*      */ 
/*      */   public IMtlSysActStepDefDao getSysActStepDefDao() {
/*  774 */     return this.sysActStepDefDao;
/*      */   }
/*      */ 
/*      */   public void setSysActStepDefDao(IMtlSysActStepDefDao sysActStepDefDao) {
/*  778 */     this.sysActStepDefDao = sysActStepDefDao;
/*      */   }
/*      */ 
/*      */   public IMpmCommonJdbcDao getCommonJdbcDao() {
/*  782 */     return this.commonJdbcDao;
/*      */   }
/*      */ 
/*      */   public void setCommonJdbcDao(IMpmCommonJdbcDao commonJdbcDao) {
/*  786 */     this.commonJdbcDao = commonJdbcDao;
/*      */   }
/*      */ 
/*      */   public List getVipOrCompManagerSelectListCache(Short campType)
/*      */     throws MpmException
/*      */   {
/*  797 */     List list = null;
/*      */     try {
/*  799 */       String VipOrComp = Configure.getInstance().getProperty("MPM_VIP_OR_COMP_MANAGER");
/*      */ 
/*  805 */       list = getVipManagerSelectListCache();
/*      */     }
/*      */     catch (Exception e) {
/*      */     }
/*  809 */     return list;
/*      */   }
/*      */ 
/*      */   public List getTraditionChannelTypeSelectListCache()
/*      */     throws MpmException
/*      */   {
/*  816 */     List list = null;
/*      */     try {
/*  818 */       list = this.channelTypeDao.getObjList();
/*  819 */       Iterator i = list.iterator();
/*  820 */       list = new ArrayList();
/*  821 */       while (i.hasNext()) {
/*  822 */         DimPubChanneltype obj = (DimPubChanneltype)i.next();
/*  823 */         list.add(new LabelValueBean(obj.getChanneltypeName(), obj.getChanneltypeId().toString()));
/*      */       }
/*      */     } catch (Exception e) {
/*  826 */       log.error(e);
/*  827 */       throw new MpmException(e);
/*      */     }
/*  829 */     return list;
/*      */   }
/*      */ 
/*      */   public List getChannelTypeListCache()
/*      */     throws MpmException
/*      */   {
/*  836 */     List list = null;
/*  837 */     List resultList = new ArrayList();
/*      */     try
/*      */     {
/*  840 */       Map map = MpmCache.getInstance().getMapByType("channel_type");
/*  841 */       Iterator it = map.entrySet().iterator();
/*      */ 
/*  843 */       while (it.hasNext()) {
/*  844 */         Map.Entry entry = (Map.Entry)it.next();
/*  845 */         resultList.add(new LabelValueBean((String)entry.getValue(), (String)entry.getKey()));
/*      */       }
/*      */ 
/*  849 */       list = this.channelTypeDao.getAllChannelType();
/*  850 */       Iterator i = list.iterator();
/*      */ 
/*  852 */       while (i.hasNext()) {
/*  853 */         DimPubChanneltype obj = (DimPubChanneltype)i.next();
/*  854 */         resultList.add(new LabelValueBean(obj.getChanneltypeName(), obj.getChanneltypeId().toString()));
/*      */       }
/*      */     } catch (Exception e) {
/*  857 */       log.error(e);
/*  858 */       throw new MpmException(e);
/*      */     }
/*      */ 
/*  861 */     return resultList;
/*      */   }
/*      */ 
/*      */   public List getTraditionChannleSelectListCache(String channelTypeId)
/*      */     throws MpmException
/*      */   {
/*  868 */     List list = null;
/*      */     try {
/*  870 */       list = this.channelDao.getObjListByChannleType(channelTypeId);
/*  871 */       Iterator i = list.iterator();
/*  872 */       list = new ArrayList();
/*  873 */       while (i.hasNext()) {
/*  874 */         DimPubChannel obj = (DimPubChannel)i.next();
/*  875 */         list.add(new LabelValueBean(obj.getChannelName(), new StringBuilder().append(obj.getChanneltypeId()).append("-").append(obj.getChannelId()).toString()));
/*      */       }
/*      */     } catch (Exception e) {
/*  878 */       log.error("", e);
/*  879 */       throw new MpmException(e);
/*      */     }
/*  881 */     return list;
/*      */   }
/*      */ 
/*      */   public String getTraditionChannelArrayCache()
/*      */     throws MpmException
/*      */   {
/*  888 */     List list = null;
/*  889 */     StringBuffer str = new StringBuffer();
/*  890 */     str.append("var channelcount=0;channel = new Array();");
/*  891 */     int count = 0;
/*      */     try {
/*  893 */       list = this.channelDao.getObjList();
/*  894 */       Iterator i = list.iterator();
/*  895 */       while (i.hasNext()) {
/*  896 */         DimPubChannel obj = (DimPubChannel)i.next();
/*  897 */         str.append(new StringBuilder().append("channel[").append(count).append("] = new Array(\"").append(obj.getChannelName()).append("\",\"").append(obj.getChanneltypeId()).append("\",\"").append(obj.getChannelId()).append("\");").toString());
/*      */ 
/*  899 */         count++;
/*      */       }
/*  901 */       str.append(new StringBuilder().append("channelcount=").append(count).toString());
/*      */     } catch (Exception e) {
/*  903 */       log.error("", e);
/*  904 */       throw new MpmException(e);
/*      */     }
/*  906 */     return str.toString();
/*      */   }
/*      */ 
/*      */   public short getCampTypeByFlowId(String flowId) throws MpmException {
/*  910 */     short flowType = 1;
/*      */     try {
/*  912 */       MtlSysActflowDef flowDef = this.actFlowDefDao.findById(flowId);
/*  913 */       flowType = flowDef.getCampType().shortValue();
/*      */     } catch (Exception e) {
/*  915 */       log.error("", e);
/*  916 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hdhdqdlxcc"));
/*      */     }
/*  918 */     return flowType;
/*      */   }
/*      */ 
/*      */   public String[] getPreAndNextStepIdCache(String flowId, String currStepId) throws MpmException {
/*  922 */     String[] resArr = new String[2];
/*      */     try {
/*  924 */       List stepList = this.flowstepDefDao.getSysFlowstepDefByFlowId(flowId);
/*  925 */       MtlSysFlowstepDef preFlowstepDef = null;
/*  926 */       MtlSysFlowstepDef nextFlowstepDef = null;
/*  927 */       MtlSysFlowstepDef currFlowstepDef = null;
/*  928 */       for (int i = 0; i < stepList.size(); i++) {
/*  929 */         currFlowstepDef = (MtlSysFlowstepDef)stepList.get(i);
/*  930 */         if (currFlowstepDef.getId().getStepId().equals(currStepId))
/*      */         {
/*  932 */           if (preFlowstepDef == null) {
/*  933 */             resArr[0] = null;
/*      */           }
/*      */           else {
/*  936 */             resArr[0] = preFlowstepDef.getId().getStepId();
/*      */           }
/*      */ 
/*  940 */           if (i <= stepList.size() - 2) {
/*  941 */             nextFlowstepDef = (MtlSysFlowstepDef)stepList.get(i + 1);
/*  942 */             resArr[1] = nextFlowstepDef.getId().getStepId(); break;
/*      */           }
/*      */ 
/*  946 */           resArr[1] = null;
/*      */ 
/*  948 */           break;
/*      */         }
/*  950 */         preFlowstepDef = currFlowstepDef;
/*      */       }
/*      */     } catch (Exception e) {
/*  953 */       log.error("", e);
/*  954 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hdbzdqxhxb"));
/*      */     }
/*  956 */     return resArr;
/*      */   }
/*      */ 
/*      */   public String getNextStepIdCache(String flowId, String currStepId) throws MpmException {
/*  960 */     String[] stepIdArr = getPreAndNextStepIdCache(flowId, currStepId);
/*  961 */     if (stepIdArr[1] == null) {
/*  962 */       return "";
/*      */     }
/*  964 */     return stepIdArr[1];
/*      */   }
/*      */ 
/*      */   public String getPreStepIdCache(String flowId, String currStepId) throws MpmException
/*      */   {
/*  969 */     String[] stepIdArr = getPreAndNextStepIdCache(flowId, currStepId);
/*  970 */     if (stepIdArr[0] == null) {
/*  971 */       return "";
/*      */     }
/*  973 */     return stepIdArr[0];
/*      */   }
/*      */ 
/*      */   public String getLastUserDataMonthCache(String mainTable) throws MpmException
/*      */   {
/*  978 */     String lastUserBaseDataMonth = MpmLocaleUtil.getMessage("mcd.java.xtzmyjgyld");
/*      */     try {
/*  980 */       String currMonth = DateUtil.getCurrentMonth();
/*  981 */       String[] userBaseTables = new String[12];
/*      */ 
/*  984 */       for (int i = 0; i < 4; i++) {
/*  985 */         String preMonth = DateUtil.date2String(DateUtil.getOffsetDate(new StringBuilder().append(currMonth).append("01").toString(), 0 - i, "month"), "yyyy-MM-dd").substring(0, 7);
/*      */ 
/*  988 */         preMonth = new StringBuilder().append(preMonth.substring(0, 4)).append(preMonth.substring(5, 7)).toString();
/*  989 */         userBaseTables[i] = new StringBuilder().append(mainTable).append("_").append(preMonth).toString();
/*      */       }
/*      */ 
/*  992 */       lastUserBaseDataMonth = this.commonJdbcDao.getFirstExistTable(userBaseTables);
/*      */ 
/*  994 */       if ((lastUserBaseDataMonth != null) && (lastUserBaseDataMonth.length() > 0)) {
/*  995 */         lastUserBaseDataMonth = StringFunc.replace2(lastUserBaseDataMonth, new StringBuilder().append(mainTable).append("_").toString(), "");
/*  996 */         lastUserBaseDataMonth = new StringBuilder().append(lastUserBaseDataMonth.substring(0, 4)).append("-").append(lastUserBaseDataMonth.substring(4, 6)).toString();
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1000 */       log.error("", e);
/*      */     }
/*      */ 
/* 1003 */     return lastUserBaseDataMonth;
/*      */   }
/*      */ 
/*      */   public List getUserBaseDataMonthListCache(String mainTable) throws MpmException {
/* 1007 */     List list = new ArrayList();
/*      */     try {
/* 1009 */       String currMonth = DateUtil.getCurrentMonth();
/* 1010 */       String[] userBaseTables = new String[12];
/*      */ 
/* 1013 */       for (int i = 1; i <= 4; i++) {
/* 1014 */         String preMonth = DateUtil.date2String(DateUtil.getOffsetDate(new StringBuilder().append(currMonth).append("01").toString(), 0 - i, "month"), "yyyy-MM-dd").substring(0, 7);
/*      */ 
/* 1016 */         preMonth = new StringBuilder().append(preMonth.substring(0, 4)).append(preMonth.substring(5, 7)).toString();
/* 1017 */         userBaseTables[(i - 1)] = new StringBuilder().append(mainTable).append("_").append(preMonth).toString();
/*      */       }
/*      */ 
/* 1020 */       Iterator it = this.commonJdbcDao.getExistTables(userBaseTables).iterator();
/*      */ 
/* 1022 */       while (it.hasNext()) {
/* 1023 */         String tableName = (String)it.next();
/* 1024 */         tableName = StringFunc.replace2(tableName, new StringBuilder().append(mainTable).append("_").toString(), "");
/* 1025 */         tableName = new StringBuilder().append(tableName.substring(0, 4)).append("-").append(tableName.substring(4, 6)).toString();
/* 1026 */         list.add(new LabelValueBean(tableName, tableName));
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1030 */       log.error("", e);
/*      */     }
/*      */ 
/* 1033 */     return list;
/*      */   }
/*      */ 
/*      */   public void updateCampsegProgressFlag(String campsegId, String stepId, String flag) throws MpmException {
/*      */     try {
/* 1038 */       this.campsegProgressDao.updateCampsegProgressFlag(campsegId, null, new Short[] { Short.valueOf(stepId) }, Short.valueOf(flag));
/*      */     }
/*      */     catch (Exception e) {
/* 1041 */       log.error("", e);
/* 1042 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.gxhdbcbzcl"));
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isCampsegSelectSeted(String campsegId) throws MpmException {
/* 1047 */     boolean res = false;
/*      */     try {
/* 1049 */       MtlCampsegProgressId id = new MtlCampsegProgressId();
/* 1050 */       id.setCampsegId(campsegId);
/* 1051 */       id.setStepId(Short.valueOf((short)20));
/*      */ 
/* 1053 */       MtlCampsegProgress progress = this.campsegProgressDao.getCampsegProgress(id);
/* 1054 */       if ((progress != null) && (progress.getProformResult() != null) && (progress.getProformResult().length() > 1))
/* 1055 */         res = true;
/*      */     }
/*      */     catch (Exception e) {
/* 1058 */       log.error("", e);
/* 1059 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.pdhdbcdmbk"));
/*      */     }
/* 1061 */     return res;
/*      */   }
/*      */ 
/*      */   public String getDataSrcColumnDescCache(String sourceName, String columnName) throws MpmException {
/* 1065 */     String res = "";
/*      */     try {
/* 1067 */       MtlCampDatasrcColumn obj = this.mpmCampDatasrcColumnDao.getCampDatasrcColumn(sourceName, columnName);
/* 1068 */       if (obj != null)
/* 1069 */         res = obj.getColumnDesc();
/*      */     }
/*      */     catch (Exception e) {
/* 1072 */       log.error("", e);
/* 1073 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.pdhdbcdmbk"));
/*      */     }
/* 1075 */     return res == null ? "" : res;
/*      */   }
/*      */ 
/*      */   public boolean isDeptHasSetApprover(String deptId) throws MpmException {
/* 1079 */     boolean res = false;
/*      */     try {
/* 1081 */       List list = this.mpmApproveRelationDao.findByCondtion(deptId, null, null);
/* 1082 */       res = list.size() > 0;
/*      */     } catch (Exception e) {
/* 1084 */       log.error("", e);
/* 1085 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qgszzjgxxs"));
/*      */     }
/* 1087 */     return res;
/*      */   }
/*      */ 
/*      */   public int isApproverExistInCampseg(String campsegId, String currUserId, String approverUserId) throws MpmException {
/* 1091 */     int res = 0;
/*      */     try
/*      */     {
/* 1094 */       MtlCampsegApproverList approverList = new MtlCampsegApproverList();
/* 1095 */       approverList.getId().setCampsegId(campsegId);
/* 1096 */       approverList.setApproveUserid(approverUserId);
/* 1097 */       List list = this.mtlCampsegApproverListDao.findCampsegApprover(approverList);
/* 1098 */       res = list.size() > 0 ? 1 : 0;
/* 1099 */       if (res > 0) {
/* 1100 */         return res;
/*      */       }
/*      */ 
/* 1104 */       MtlApproveAdvice advice = new MtlApproveAdvice();
/* 1105 */       advice.getId().setCampsegId(campsegId);
/* 1106 */       advice.getId().setSponorUserId(approverUserId);
/* 1107 */       advice.getId().setActorUserId(currUserId);
/* 1108 */       advice.getId().setSponsorType(Short.valueOf((short)2));
/* 1109 */       list = this.mtlApproveAdviceDao.findApproveAdvice(advice);
/* 1110 */       res = list.size() > 0 ? 2 : 0;
/*      */     } catch (Exception e) {
/* 1112 */       log.error("", e);
/* 1113 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsprzhdbcd"));
/*      */     }
/* 1115 */     return res;
/*      */   }
/*      */ 
/*      */   public List getAllMtlChanneltype(DimMtlChanneltype type) throws MpmException {
/*      */     try {
/* 1120 */       return this.dimMtlChanneltypeDao.findMtlChanneltype(type);
/*      */     } catch (Exception e) {
/* 1122 */       log.error("", e);
/* 1123 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqdlxdysb"));
/*      */   }
/*      */ 
/*      */   public String getApproveFlowidByChannelTypeAndId(String type, String cid)
/*      */     throws MpmException
/*      */   {
/* 1135 */     return this.commonJdbcDao.getApproveFlowidByChannelTypeAndId(type, cid);
/*      */   }
/*      */ 
/*      */   public String getApproveFlowid(String userid, String campDrvId, String channeltypeId, String channelId, String approveType)
/*      */     throws MpmException
/*      */   {
/* 1148 */     return this.commonJdbcDao.getApproveFlowid(userid, campDrvId, channeltypeId, channelId, approveType);
/*      */   }
/*      */ 
/*      */   public String getApproveFlowid(String userid, String campDrvId, String approveType) throws MpmException {
/* 1152 */     return this.commonJdbcDao.getApproveFlowid(userid, campDrvId, approveType);
/*      */   }
/*      */ 
/*      */   public String getApproveFlowid(String userid, String approveType)
/*      */     throws MpmException
/*      */   {
/* 1158 */     return this.commonJdbcDao.getApproveFlowid(userid, approveType);
/*      */   }
/*      */ 
/*      */   public short LoadCampsegSmsFeedbackFile(String campsegId, String feedbackType, String fileName)
/*      */   {
/* 1170 */     Connection cn = null;
/* 1171 */     Statement sm = null;
/* 1172 */     PreparedStatement pstm = null;
/* 1173 */     String tmpName = new StringBuilder().append("MTL_sms_dm_").append(campsegId).append("_").append(MpmUtil.convertLongMillsToYYYYMMDDHHMMSS(-1L)).toString();
/* 1174 */     String tabName = new StringBuilder().append("MTL_sms_dm_").append(campsegId).toString();
/* 1175 */     String CREATE_TABLE_SMS_SQL = "create table ? (product_no\tvarchar(12)\tnot null,content_code\tvarchar(10) ,send_time\ttimestamp not null,reply_time\ttimestamp not null,channel_id\tvarchar(32) not null,channeltype_id\tsmallint not null,reply_handle_result smallint not null) ";
/* 1176 */     String DEL_SMS_REP_SQL = "delete from ?1 a where    exists ( select * from ?2   b  where a.product_no = b.product_no)";
/* 1177 */     String INSERT_SMS_SQL = "insert into ?1 (product_no,content_code,send_time,reply_time,channel_id,channeltype_id,reply_handle_result) select product_no,content_code,send_time,reply_time,channel_id,channeltype_id,reply_handle_result from (select a.* ,row_number() over(partition by product_no order by product_no)\tas rank_no from ?2 a) b where b.rank_no = 1";
/* 1178 */     int totalNeedLoadCnt = 0;
/* 1179 */     int successLoadCnt = 0;
/*      */     try {
/* 1181 */       log.debug(new StringBuilder().append("Thread:").append(Thread.currentThread().getName()).append(" start").toString());
/*      */ 
/* 1183 */       String strDataSourceName = Configure.getInstance().getProperty("JDBC_MPM");
/* 1184 */       if (StringUtil.isEmpty(strDataSourceName))
/* 1185 */         throw new Exception(MpmLocaleUtil.getMessage("mcd.java.JDBCljpzJD"));
/*      */       try
/*      */       {
/* 1188 */         cn = AiomniConnectionFactory.getInstance(strDataSourceName).getConnection();
/*      */       } catch (Exception e) {
/* 1190 */         log.error("", e);
/*      */       }
/*      */ 
/* 1193 */       cn.setAutoCommit(false);
/*      */ 
/* 1196 */       sm = cn.createStatement();
/* 1197 */       createSql = StringFunc.replace2(CREATE_TABLE_SMS_SQL, "?", tmpName);
/*      */ 
/* 1199 */       createSql = MpmUtil.getCreateTableSql(createSql);
/*      */ 
/* 1202 */       sm.executeUpdate(createSql);
/*      */ 
/* 1206 */       String filename = fileName;
/* 1207 */       BufferedReader reader = new BufferedReader(new FileReader(filename));
/*      */ 
/* 1212 */       int cnt = 0;
/* 1213 */       int index = -1;
/*      */ 
/* 1216 */       DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1217 */       StringBuilder sb = new StringBuilder("insert into ");
/* 1218 */       sb.append(tmpName).append("(product_no,content_code,send_time,reply_time,channel_id,channeltype_id,reply_handle_result) values(?,?,?,?,?,?,?)");
/*      */ 
/* 1220 */       pstm = cn.prepareStatement(sb.toString());
/*      */       String tmpLine;
/* 1223 */       while ((tmpLine = reader.readLine()) != null) {
/* 1224 */         log.debug(new StringBuilder().append(">>LoadCampsegSmsFeedbackFile reader.readLine() ").append(tmpLine).toString());
/* 1225 */         totalNeedLoadCnt++;
/*      */         try {
/* 1227 */           index = tmpLine.indexOf(",");
/*      */ 
/* 1229 */           if (index < 0) {
/* 1230 */             log.error("lack of column 1");
/* 1231 */             continue;
/*      */           }
/*      */ 
/* 1234 */           String productNo = tmpLine.substring(0, index);
/* 1235 */           if (StringUtil.isEmpty(productNo)) {
/* 1236 */             log.error("productNo is null ");
/* 1237 */             continue;
/*      */           }
/*      */ 
/* 1241 */           int firstpoint = index + 1;
/* 1242 */           index = tmpLine.indexOf(",", index + 1);
/* 1243 */           if (index < 0) {
/* 1244 */             log.error("lack of column 2");
/* 1245 */             continue;
/*      */           }
/*      */ 
/* 1248 */           String contentCode = tmpLine.substring(firstpoint, index);
/*      */ 
/* 1253 */           firstpoint = index + 1;
/* 1254 */           index = tmpLine.indexOf(",", index + 1);
/* 1255 */           if (index < 0) {
/* 1256 */             log.error("lack of column 3");
/* 1257 */             continue;
/*      */           }
/*      */ 
/* 1262 */           Date sendTime = df.parse(tmpLine.substring(firstpoint, index).trim());
/*      */ 
/* 1269 */           if (sendTime == null) {
/* 1270 */             log.error("sendTime is null");
/* 1271 */             continue;
/*      */           }
/*      */ 
/* 1274 */           firstpoint = index + 1;
/* 1275 */           index = tmpLine.indexOf(",", index + 1);
/* 1276 */           if (index < 0) {
/* 1277 */             log.error("lack of column 4");
/* 1278 */             continue;
/*      */           }
/*      */ 
/* 1281 */           Date replyTime = df.parse(tmpLine.substring(firstpoint, index).trim());
/* 1282 */           if (replyTime == null) {
/* 1283 */             log.error("replyTime is null");
/* 1284 */             continue;
/*      */           }
/*      */ 
/* 1288 */           firstpoint = index + 1;
/* 1289 */           index = tmpLine.indexOf(",", index + 1);
/* 1290 */           if (index < 0) {
/* 1291 */             log.error("lack of column 5");
/* 1292 */             continue;
/*      */           }
/*      */ 
/* 1295 */           String channelId = tmpLine.substring(firstpoint, index);
/* 1296 */           if (StringUtil.isEmpty(channelId)) {
/* 1297 */             log.error("channelId is null");
/* 1298 */             continue;
/*      */           }
/*      */ 
/* 1302 */           firstpoint = index + 1;
/* 1303 */           index = tmpLine.indexOf(",", index + 1);
/* 1304 */           if (index < 0) {
/* 1305 */             log.error("lack of column 6");
/* 1306 */             continue;
/*      */           }
/*      */ 
/* 1309 */           if (tmpLine.substring(firstpoint, index).trim() == null) {
/* 1310 */             log.error("channeltypeId is null");
/* 1311 */             continue;
/*      */           }
/* 1313 */           short channeltypeId = Short.parseShort(tmpLine.substring(firstpoint, index).trim());
/*      */ 
/* 1316 */           firstpoint = index + 1;
/* 1317 */           index = tmpLine.indexOf(",", index + 1);
/* 1318 */           log.debug(new StringBuilder().append("the last index is:").append(index).toString());
/* 1319 */           if (index < 0) {
/* 1320 */             log.error("lack of column 7");
/* 1321 */             continue;
/*      */           }
/*      */ 
/* 1324 */           if (tmpLine.substring(firstpoint, index - 1).trim() == null) {
/* 1325 */             log.error("replyHandleResult is null");
/* 1326 */             continue;
/*      */           }
/* 1328 */           short replyHandleResult = Short.parseShort(tmpLine.substring(firstpoint, index).trim());
/*      */ 
/* 1331 */           index = tmpLine.indexOf(",", index + 1);
/* 1332 */           log.debug(new StringBuilder().append("the index is:").append(index).toString());
/* 1333 */           if (index > 0) {
/* 1334 */             log.error("column nums is error,nums > 7");
/* 1335 */             continue;
/*      */           }
/*      */ 
/* 1340 */           pstm.setString(1, productNo.trim());
/* 1341 */           pstm.setString(2, contentCode.trim());
/* 1342 */           pstm.setString(3, df.format(sendTime));
/* 1343 */           pstm.setString(4, df.format(replyTime));
/*      */ 
/* 1346 */           pstm.setString(5, channelId.trim());
/* 1347 */           pstm.setShort(6, channeltypeId);
/* 1348 */           pstm.setShort(7, replyHandleResult);
/*      */         }
/*      */         catch (Exception e) {
/* 1351 */           log.error(new StringBuilder().append("row ").append(totalNeedLoadCnt).append(" is error:").toString(), e);
/* 1352 */         }continue;
/*      */ 
/* 1355 */         pstm.addBatch();
/* 1356 */         cnt++;
/* 1357 */         if (cnt > 1000) {
/* 1358 */           pstm.executeBatch();
/* 1359 */           cnt = 0;
/* 1360 */           cn.commit();
/*      */         }
/* 1362 */         successLoadCnt++;
/*      */       }
/*      */ 
/* 1366 */       if (cnt > 0) {
/* 1367 */         pstm.executeBatch();
/*      */       }
/*      */ 
/* 1370 */       cn.commit();
/*      */ 
/* 1373 */       String deleteSql = StringFunc.replace2(DEL_SMS_REP_SQL, "?1", tmpName);
/* 1374 */       deleteSql = StringFunc.replace2(deleteSql, "?2", tabName);
/* 1375 */       log.debug(new StringBuilder().append("deleteSql=").append(deleteSql).toString());
/* 1376 */       sm.executeUpdate(deleteSql);
/*      */ 
/* 1379 */       String insertSql = StringFunc.replace2(INSERT_SMS_SQL, "?1", tabName);
/* 1380 */       insertSql = StringFunc.replace2(insertSql, "?2", tmpName);
/* 1381 */       log.debug(new StringBuilder().append("insertSql=").append(insertSql).toString());
/*      */ 
/* 1384 */       int insertNums = sm.executeUpdate(insertSql);
/*      */ 
/* 1388 */       cn.commit();
/*      */ 
/* 1390 */       sm.close();
/* 1391 */       pstm.close();
/*      */ 
/* 1393 */       log.debug(new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.zjls")).append(totalNeedLoadCnt).append(MpmLocaleUtil.getMessage("mcd.java.zzdlsb")).append(successLoadCnt).append(MpmLocaleUtil.getMessage("mcd.java.tjlsjcgzz")).append(insertNums).append(MpmLocaleUtil.getMessage("mcd.java.tjl")).toString());
/*      */ 
/* 1397 */       String msg = "";
/* 1398 */       short flag = 1;
/*      */       short s1;
/* 1399 */       if (successLoadCnt == 0) {
/* 1400 */         msg = MpmLocaleUtil.getMessage("mcd.java.zzcgltjlqj1");
/* 1401 */         flag = 2;
/* 1402 */         return 0;
/*      */       }
/*      */ 
/* 1405 */       return 1;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       String createSql;
/* 1407 */       log.error("", e);
/*      */       try {
/* 1409 */         if (cn != null) {
/* 1410 */           cn.rollback();
/*      */         }
/* 1412 */         return 0;
/*      */       } catch (Exception e3) {
/* 1414 */         log.error(">>rollback error: ", e3);
/*      */       }
/*      */     } finally {
/*      */       try {
/* 1418 */         if (sm != null) {
/* 1419 */           sm.close();
/*      */         }
/* 1421 */         if (pstm != null) {
/* 1422 */           pstm.close();
/*      */         }
/* 1424 */         if (cn != null)
/* 1425 */           cn.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/* 1430 */       log.debug(new StringBuilder().append(">>LoadCampsegSmsFeedbackFile end at ").append(MpmUtil.convertLongMillsToStrTime(System.currentTimeMillis())).toString());
/*      */ 
/* 1432 */       log.debug(new StringBuilder().append("Thread:").append(Thread.currentThread().getName()).append(" finished").toString());
/*      */     }
/* 1434 */     return 0;
/*      */   }
/*      */ 
/*      */   private void updateFilterFileLoadType(String filterFileId, Short loadType, Connection cn)
/*      */     throws Exception
/*      */   {
/* 1445 */     Statement sm = null;
/*      */     try {
/* 1447 */       sm = cn.createStatement();
/* 1448 */       String updateSql = StringFunc.replace2("update mtl_filter_file set file_load_type=?1 where filter_file_id='?2'", "?1", new StringBuilder().append(loadType).append("").toString());
/* 1449 */       updateSql = StringFunc.replace2(updateSql, "?2", filterFileId);
/* 1450 */       log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1451 */       sm.execute(updateSql);
/* 1452 */       cn.commit();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1458 */       throw e;
/*      */     } finally {
/* 1460 */       if (sm != null) {
/* 1461 */         sm.close();
/* 1462 */         sm = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updateFilterFileTabName(String filterFileId, String tabName, Connection cn)
/*      */     throws Exception
/*      */   {
/* 1475 */     Statement sm = null;
/*      */     try {
/* 1477 */       sm = cn.createStatement();
/* 1478 */       String updateSql = StringFunc.replace2("update mtl_filter_file set load_tabname='?1' where filter_file_id='?2'", "?1", tabName);
/* 1479 */       updateSql = StringFunc.replace2(updateSql, "?2", filterFileId);
/* 1480 */       log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1481 */       sm.execute(updateSql);
/* 1482 */       cn.commit();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1488 */       throw e;
/*      */     } finally {
/* 1490 */       if (sm != null) {
/* 1491 */         sm.close();
/* 1492 */         sm = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updateFileLoadType(String filterFileId, Short loadType, String errMsg, Connection cn)
/*      */     throws Exception
/*      */   {
/* 1505 */     Statement sm = null;
/*      */     try {
/* 1507 */       sm = cn.createStatement();
/* 1508 */       String sql = "update MTL_targetuser_file set file_load_type=?1 where targetuser_file_id='?2'";
/* 1509 */       if ((errMsg != null) && (errMsg.length() > 0)) {
/* 1510 */         sql = "update MTL_targetuser_file set file_load_type=?1,TARGETUSER_FILE_DESC='?3' where targetuser_file_id='?2'";
/*      */       }
/* 1512 */       String updateSql = StringFunc.replace2(sql, "?1", new StringBuilder().append(loadType).append("").toString());
/* 1513 */       updateSql = StringFunc.replace2(updateSql, "?2", filterFileId);
/* 1514 */       updateSql = StringFunc.replace2(updateSql, "?3", errMsg);
/* 1515 */       log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1516 */       sm.execute(updateSql);
/* 1517 */       cn.commit();
/* 1518 */       sm.close();
/* 1519 */       sm = null;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1525 */       throw e;
/*      */     } finally {
/* 1527 */       if (sm != null) {
/* 1528 */         sm.close();
/* 1529 */         sm = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updateFileTabName(String filterFileId, String tabName, int totalNeedLoadCnt, int successLoadCnt, Connection cn)
/*      */     throws Exception
/*      */   {
/* 1543 */     Statement sm = null;
/*      */     try {
/* 1545 */       sm = cn.createStatement();
/* 1546 */       String updateSql = StringFunc.replace2("update MTL_targetuser_file set load_tabname='?1',total_need_load_cnt=?2,success_load_cnt=?3,load_end_time=?5 where targetuser_file_id='?4'", "?1", tabName);
/* 1547 */       updateSql = StringFunc.replace2(updateSql, "?2", String.valueOf(totalNeedLoadCnt));
/* 1548 */       updateSql = StringFunc.replace2(updateSql, "?3", String.valueOf(successLoadCnt));
/* 1549 */       updateSql = StringFunc.replace2(updateSql, "?4", filterFileId);
/* 1550 */       FastDateFormat dFormat = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
/* 1551 */       String strDBType = MpmUtil.getDBType();
/* 1552 */       if ((strDBType != null) && (strDBType.equalsIgnoreCase("ORACLE"))) {
/* 1553 */         updateSql = StringFunc.replace2(updateSql, "?5", new StringBuilder().append("to_date('").append(dFormat.format(new Date())).append("','yyyy-mm-dd hh24:MI:ss')").toString());
/*      */       }
/*      */       else {
/* 1556 */         updateSql = StringFunc.replace2(updateSql, "?5", new StringBuilder().append("'").append(dFormat.format(new Date())).append("'").toString());
/*      */       }
/* 1558 */       log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1559 */       sm.execute(updateSql);
/* 1560 */       cn.commit();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1566 */       throw e;
/*      */     } finally {
/* 1568 */       if (sm != null) {
/* 1569 */         sm.close();
/* 1570 */         sm = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void insertDataSourceInfo(String sourceName, String sourceCName, String[] columnCname, Connection cn)
/*      */     throws Exception
/*      */   {
/* 1636 */     Statement sm = null;
/*      */     try {
/* 1638 */       sm = cn.createStatement();
/* 1639 */       String updateSql = StringFunc.replace2(INSERT_DATASOURCE_SQL3, "?1", sourceName);
/* 1640 */       updateSql = StringFunc.replace2(updateSql, "?2", sourceCName);
/* 1641 */       updateSql = StringFunc.replace2(updateSql, "?3", getSqlNow());
/* 1642 */       log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1643 */       sm.execute(updateSql);
/*      */ 
/* 1645 */       updateSql = StringFunc.replace2(INSERT_DATASOURCE_COLUMN_SQL3, "?1", "product_no");
/* 1646 */       updateSql = StringFunc.replace2(updateSql, "?2", sourceName);
/* 1647 */       updateSql = StringFunc.replace2(updateSql, "?3", String.valueOf(2));
/* 1648 */       updateSql = StringFunc.replace2(updateSql, "?4", MpmLocaleUtil.getMessage("mcd.java.sjhm"));
/* 1649 */       updateSql = StringFunc.replace2(updateSql, "?5", "1");
/* 1650 */       updateSql = StringFunc.replace2(updateSql, "?6", "varchar(12) not null");
/* 1651 */       updateSql = StringFunc.replace2(updateSql, "?7", MpmLocaleUtil.getMessage("mcd.java.khsjhm"));
/* 1652 */       updateSql = StringFunc.replace2(updateSql, "?8", "2");
/* 1653 */       log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1654 */       sm.execute(updateSql);
/*      */ 
/* 1656 */       updateSql = StringFunc.replace2(INSERT_DATASOURCE_COLUMN_SQL3, "?1", "file_idx_flag");
/* 1657 */       updateSql = StringFunc.replace2(updateSql, "?2", sourceName);
/* 1658 */       updateSql = StringFunc.replace2(updateSql, "?3", String.valueOf(1));
/* 1659 */       updateSql = StringFunc.replace2(updateSql, "?4", MpmLocaleUtil.getMessage("mcd.java.sybs"));
/* 1660 */       updateSql = StringFunc.replace2(updateSql, "?5", "2");
/* 1661 */       updateSql = StringFunc.replace2(updateSql, "?6", "smallint not null");
/* 1662 */       updateSql = StringFunc.replace2(updateSql, "?7", MpmLocaleUtil.getMessage("mcd.java.wjxlbs"));
/* 1663 */       updateSql = StringFunc.replace2(updateSql, "?8", "1");
/* 1664 */       log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1665 */       sm.execute(updateSql);
/*      */ 
/* 1668 */       for (int i = 1; i <= 5; i++) {
/* 1669 */         updateSql = StringFunc.replace2(INSERT_DATASOURCE_COLUMN_SQL3, "?1", new StringBuilder().append("col").append(i).toString());
/* 1670 */         updateSql = StringFunc.replace2(updateSql, "?2", sourceName);
/* 1671 */         updateSql = StringFunc.replace2(updateSql, "?3", String.valueOf(2));
/*      */ 
/* 1674 */         if ((columnCname != null) && (columnCname.length != 0) && (columnCname[(i - 1)] != null) && (columnCname[(i - 1)].length() != 0))
/*      */         {
/* 1679 */           if ((columnCname == null) || (columnCname.length == 0) || (columnCname[(i - 1)] == null) || (columnCname[(i - 1)].length() == 0))
/*      */           {
/* 1681 */             updateSql = StringFunc.replace2(updateSql, "?4", new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.kzsx")).append(i).toString());
/*      */           }
/* 1683 */           else updateSql = StringFunc.replace2(updateSql, "?4", columnCname[(i - 1)]);
/*      */ 
/* 1685 */           updateSql = StringFunc.replace2(updateSql, "?5", String.valueOf(i + 2));
/* 1686 */           updateSql = StringFunc.replace2(updateSql, "?6", "varchar(500)");
/* 1687 */           updateSql = StringFunc.replace2(updateSql, "?7", MpmLocaleUtil.getMessage("mcd.java.kzsx"));
/* 1688 */           updateSql = StringFunc.replace2(updateSql, "?8", "1");
/* 1689 */           log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1690 */           sm.execute(updateSql);
/*      */         }
/*      */       }
/* 1692 */       cn.commit();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1698 */       throw e;
/*      */     } finally {
/* 1700 */       if (sm != null) {
/* 1701 */         sm.close();
/* 1702 */         sm = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getSqlNow() throws Exception {
/* 1708 */     String strType = Configure.getInstance().getProperty("MPM_DBTYPE");
/* 1709 */     if (strType == null) {
/* 1710 */       return "sysdate";
/*      */     }
/* 1712 */     String strRet = "";
/* 1713 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1714 */       strRet = "now()";
/* 1715 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1716 */       strRet = "sysdate";
/* 1717 */     else if (strType.equalsIgnoreCase("ACCESS"))
/* 1718 */       strRet = "date()+time()";
/* 1719 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 1720 */       strRet = "getdate()";
/* 1721 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1722 */       strRet = "current timestamp";
/* 1723 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1724 */       strRet = "cast((date (format 'yyyy-mm-dd' )) as char(10)) ||' '|| time";
/* 1725 */     else if (strType.equalsIgnoreCase("SYSBASE"))
/* 1726 */       strRet = "getdate()";
/*      */     else {
/* 1728 */       throw new Exception(MpmLocaleUtil.getMessage("mcd.java.bnqddqrqdh"));
/*      */     }
/* 1730 */     return strRet;
/*      */   }
/*      */ 
/*      */   public void insertCustGroupDataByDBLink(String custGroupId, String dbName, String schema, String sourceName, String columnName)
/*      */     throws Exception
/*      */   {
/* 1750 */     Sqlca sqlca = null;
/*      */     try {
/* 1752 */       sqlca = new Sqlca(new ConnectionEx("JDBC_MPM"));
/* 1753 */       sqlca.setAutoCommit(false);
/* 1754 */       String updateSql = null;
/* 1755 */       String querySQL = null;
/*      */ 
/* 1758 */       querySQL = "select lower(a.column_name) as column_name, column_datatype from MTL_templet_active_field a, MTL_camp_datasrc_column b where a.active_templet_id =(select active_templet_id from mtl_cust_group where cust_group_id = ?) and a.source_name = b.source_name and a.column_name = b.column_name order by b.column_serno,lower(a.column_name)";
/*      */ 
/* 1762 */       log.debug(new StringBuilder().append(">>\n").append(querySQL).toString());
/* 1763 */       sqlca.execute(querySQL, new String[] { custGroupId });
/* 1764 */       String tableColumnList = null;
/* 1765 */       String columnList = null;
/* 1766 */       boolean isSpecialTemplet = false;
/* 1767 */       while (sqlca.next()) {
/* 1768 */         if (tableColumnList == null) {
/* 1769 */           columnList = sqlca.getString("column_name");
/* 1770 */           tableColumnList = new StringBuilder().append(columnList).append(" ").append(sqlca.getString("column_datatype")).toString();
/*      */         } else {
/* 1772 */           columnList = new StringBuilder().append(columnList).append(",").append(sqlca.getString("column_name")).toString();
/* 1773 */           tableColumnList = new StringBuilder().append(tableColumnList).append(",").append(columnList).append(" ").append(sqlca.getString("column_datatype")).toString();
/*      */         }
/*      */       }
/*      */ 
/* 1777 */       String tableName = new StringBuilder().append("mtl_cuser_").append(custGroupId).toString();
/* 1778 */       updateSql = new StringBuilder().append("create table ").append(tableName).append("(").append(tableColumnList).append(")").toString();
/* 1779 */       log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1780 */       sqlca.execute(updateSql);
/*      */ 
/* 1782 */       if ((schema != null) && (schema.length() != 0))
/*      */       {
/* 1786 */         updateSql = new StringBuffer("insert into ").append(tableName).append(" (").append(columnList).append(") ").append(" select ").append(columnName).append(" from ").append(schema).append(".").append(sourceName).toString();
/*      */       }
/*      */       else
/*      */       {
/* 1792 */         updateSql = new StringBuffer("insert into ").append(tableName).append(" (").append(columnList).append(") ").append(" select ").append(columnName).append(" from ").append(sourceName).toString();
/*      */       }
/*      */ 
/* 1798 */       if ((dbName != null) && (dbName.length() != 0)) {
/* 1799 */         updateSql = new StringBuilder().append(updateSql).append("@").append(dbName).toString();
/*      */       }
/* 1801 */       log.debug(new StringBuilder().append(">>\n").append(updateSql).toString());
/* 1802 */       sqlca.execute(updateSql);
/*      */ 
/* 1804 */       sqlca.commit();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1809 */       throw e;
/*      */     } finally {
/* 1811 */       if (sqlca != null)
/* 1812 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String unzip(String filepath, String zipFileName)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1828 */       String zipFile = new StringBuilder().append(filepath).append(File.separator).append(zipFileName).toString();
/* 1829 */       int BUFFER = 2048;
/* 1830 */       BufferedOutputStream dest = null;
/* 1831 */       FileInputStream fis = new FileInputStream(zipFile);
/* 1832 */       ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
/*      */       ZipEntry entry;
/* 1836 */       if ((entry = zis.getNextEntry()) != null)
/*      */       {
/* 1838 */         byte[] data = new byte[2048];
/*      */ 
/* 1840 */         String outFile = new StringBuilder().append(filepath).append(File.separator).append(entry.getName()).toString();
/*      */ 
/* 1842 */         FileOutputStream fos = new FileOutputStream(outFile);
/* 1843 */         dest = new BufferedOutputStream(fos, 2048);
/*      */         int count;
/* 1846 */         while ((count = zis.read(data, 0, 2048)) != -1) {
/* 1847 */           dest.write(data, 0, count);
/*      */         }
/* 1849 */         dest.flush();
/* 1850 */         dest.close();
/*      */       }
/* 1852 */       zis.close();
/* 1853 */       return entry.getName();
/*      */     } catch (Exception e) {
/* 1855 */       log.debug(new StringBuilder().append(">>\n").append(e).toString());
/* 1856 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   public List getCampDrvTypeListByType(String type) throws Exception {
/* 1861 */     List result = new ArrayList();
/*      */     try {
/* 1863 */       result = this.campDevTypeDao.getCampDrvTypeListByType(type);
/*      */     } catch (Exception e) {
/* 1865 */       log.error("", e);
/* 1866 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqqdlxcw"));
/*      */     }
/* 1868 */     return result;
/*      */   }
/*      */ 
/*      */   public String getDrvTypeName(Short drvTypeId) throws Exception {
/* 1872 */     DimCampDrvType obj = null;
/*      */     try {
/* 1874 */       obj = this.campDevTypeDao.getDrvType(drvTypeId);
/*      */     } catch (Exception e) {
/* 1876 */       log.error("", e);
/*      */     }
/* 1878 */     return obj.getCampDrvName();
/*      */   }
/*      */ 
/*      */   public Connection getConnectionForWAS(String strDataSourceName) {
/* 1882 */     DataSource ds = null;
/* 1883 */     Connection cn = null;
/*      */     try
/*      */     {
/* 1886 */       String jndi = strDataSourceName.substring(new String("java:comp/env/").length());
/* 1887 */       Context ctx = new InitialContext();
/* 1888 */       if (ctx == null) {
/* 1889 */         throw new Exception("Boom - No Context");
/*      */       }
/*      */ 
/* 1892 */       if (jndi != null) {
/* 1893 */         String strDbJndi = jndi;
/* 1894 */         if (strDbJndi.startsWith("java:comp/env/")) {
/* 1895 */           strDbJndi = strDbJndi.substring(14);
/*      */         }
/* 1897 */         ds = (DataSource)ctx.lookup(strDbJndi);
/* 1898 */         cn = ds.getConnection();
/*      */       }
/*      */     } catch (Exception e) {
/* 1901 */       log.error("", e);
/*      */     }
/* 1903 */     return cn;
/*      */   }
/*      */ 
/*      */   public void saveObjCosts(String campsegId, String[] objCode, String[] objCost) throws MpmException
/*      */   {
/* 1908 */     Map map = new TreeMap();
/* 1909 */     Sqlca sqlca = null;
/*      */     try {
/* 1911 */       sqlca = new Sqlca(new ConnectionEx("JDBC_MPM"));
/* 1912 */       sqlca.execute("delete from MTL_SEGINFO_OBJ where campseg_id=?", new String[] { campsegId });
/* 1913 */       if ((objCode != null) && (objCode.length > 0)) {
/* 1914 */         for (int i = 1; i < objCode.length; i++)
/* 1915 */           sqlca.execute("insert into MTL_SEGINFO_OBJ(campseg_id,obj_id,obj_value) values(?,?,?)", new Object[] { campsegId, objCode[i], objCost[i] });
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1920 */       log.error("", e);
/* 1921 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bchdcbmbcw"));
/*      */     } finally {
/* 1923 */       if (sqlca != null)
/* 1924 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public List getObjCostList(String campsegId)
/*      */     throws MpmException
/*      */   {
/* 1931 */     List list = new ArrayList();
/* 1932 */     Sqlca sqlca = null;
/*      */     try {
/* 1934 */       sqlca = new Sqlca(new ConnectionEx("JDBC_MPM"));
/* 1935 */       sqlca.execute(new StringBuilder().append("select a.cost_code as obj_id,a.cost_name as obj_name,obj_value from AP_COST_LIST a,mtl_seginfo_obj b where a.cost_code=b.obj_id and b.campseg_id='").append(campsegId).append("'").toString());
/*      */ 
/* 1937 */       while (sqlca.next()) {
/* 1938 */         MtlSeginfoObj mtlSeginfoObj = new MtlSeginfoObj();
/* 1939 */         mtlSeginfoObj.setCampsegId(campsegId);
/* 1940 */         mtlSeginfoObj.setObjCode(new StringBuilder().append(sqlca.getInt("obj_id")).append("").toString());
/* 1941 */         mtlSeginfoObj.setObjName(sqlca.getString("obj_name"));
/* 1942 */         mtlSeginfoObj.setObjCost(String.valueOf(sqlca.getDouble("obj_value")));
/* 1943 */         list.add(mtlSeginfoObj);
/*      */       }
/*      */     } catch (Exception e) {
/* 1946 */       log.error("", e);
/* 1947 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdcbmbcw"));
/*      */     } finally {
/* 1949 */       if (sqlca != null) {
/* 1950 */         sqlca.closeAll();
/*      */       }
/*      */     }
/* 1953 */     return list;
/*      */   }
/*      */ 
/*      */   public String excludeBlackList(String srcTable, String avoidCustTypes)
/*      */   {
/* 1965 */     return this.commonJdbcDao.excludeBlackList(srcTable, avoidCustTypes);
/*      */   }
/*      */ 
/*      */   public IMtlCampsegProgressDao getCampsegProgressDao() {
/* 1969 */     return this.campsegProgressDao;
/*      */   }
/*      */ 
/*      */   public void setCampsegProgressDao(IMtlCampsegProgressDao campsegProgressDao) {
/* 1973 */     this.campsegProgressDao = campsegProgressDao;
/*      */   }
/*      */ 
/*      */   public IMpmCampDatasrcColumnDao getMpmCampDatasrcColumnDao() {
/* 1977 */     return this.mpmCampDatasrcColumnDao;
/*      */   }
/*      */ 
/*      */   public void setMpmCampDatasrcColumnDao(IMpmCampDatasrcColumnDao mpmCampDatasrcColumnDao) {
/* 1981 */     this.mpmCampDatasrcColumnDao = mpmCampDatasrcColumnDao;
/*      */   }
/*      */ 
/*      */   public IMpmCampDatasrcColumnDao getCampDatasrcColumnDao() {
/* 1985 */     return this.campDatasrcColumnDao;
/*      */   }
/*      */ 
/*      */   public void setCampDatasrcColumnDao(IMpmCampDatasrcColumnDao campDatasrcColumnDao) {
/* 1989 */     this.campDatasrcColumnDao = campDatasrcColumnDao;
/*      */   }
/*      */ 
/*      */   public IMtlCampsegApproverListDao getMtlCampsegApproverListDao() {
/* 1993 */     return this.mtlCampsegApproverListDao;
/*      */   }
/*      */ 
/*      */   public void setMtlCampsegApproverListDao(IMtlCampsegApproverListDao mtlCampsegApproverListDao) {
/* 1997 */     this.mtlCampsegApproverListDao = mtlCampsegApproverListDao;
/*      */   }
/*      */ 
/*      */   public IMtlApproveAdviceDao getMtlApproveAdviceDao() {
/* 2001 */     return this.mtlApproveAdviceDao;
/*      */   }
/*      */ 
/*      */   public void setMtlApproveAdviceDao(IMtlApproveAdviceDao mtlApproveAdviceDao) {
/* 2005 */     this.mtlApproveAdviceDao = mtlApproveAdviceDao;
/*      */   }
/*      */ 
/*      */   public IMtlApproveConfirmListDao getApproveConfirmListDao()
/*      */   {
/* 2012 */     return this.approveConfirmListDao;
/*      */   }
/*      */ 
/*      */   public void setApproveConfirmListDao(IMtlApproveConfirmListDao approveConfirmListDao)
/*      */   {
/* 2020 */     this.approveConfirmListDao = approveConfirmListDao;
/*      */   }
/*      */ 
/*      */   public IDimMtlChanneltypeDao getDimMtlChanneltypeDao() {
/* 2024 */     return this.dimMtlChanneltypeDao;
/*      */   }
/*      */ 
/*      */   public void setDimMtlChanneltypeDao(IDimMtlChanneltypeDao dimMtlChanneltypeDao) {
/* 2028 */     this.dimMtlChanneltypeDao = dimMtlChanneltypeDao;
/*      */   }
/*      */ 
/*      */   public IDimMtlChannelDao getDimMtlChannelDao() {
/* 2032 */     return this.dimMtlChannelDao;
/*      */   }
/*      */ 
/*      */   public void setDimMtlChannelDao(IDimMtlChannelDao dimMtlChannelDao) {
/* 2036 */     this.dimMtlChannelDao = dimMtlChannelDao;
/*      */   }
/*      */ 
/*      */   public IMpmCampDataSourceDao getCampDatasourceDao() {
/* 2040 */     return this.campDatasourceDao;
/*      */   }
/*      */ 
/*      */   public void setCampDatasourceDao(IMpmCampDataSourceDao campDatasourceDao) {
/* 2044 */     this.campDatasourceDao = campDatasourceDao;
/*      */   }
/*      */ 
/*      */   public String testFmtMess(String fmtMess) throws MpmException {
/* 2048 */     String returnMess = "OK";
/* 2049 */     boolean matched = false;
/*      */     try
/*      */     {
/* 2052 */       String regex = "\\[(([\\S&[^\\p{Cntrl}]&[^\\.]&&[^\\[]]+?)\\.([\\S&[^\\p{Cntrl}]&[^\\.]&&[^\\[]]+?))\\]";
/* 2053 */       Pattern p = Pattern.compile(regex);
/* 2054 */       Matcher m = p.matcher(fmtMess);
/* 2055 */       int lastMatch = 0;
/* 2056 */       StringBuilder sb = new StringBuilder();
/* 2057 */       for (int counter = 0; m.find(); matched = true) {
/* 2058 */         String tabName = m.group(2);
/* 2059 */         String colName = m.group(3);
/*      */ 
/* 2061 */         MtlCampDataSource mcds = this.campDatasourceDao.findByTabCname(tabName);
/* 2062 */         if (mcds == null) {
/* 2063 */           return new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.2")).append(tabName).append(MpmLocaleUtil.getMessage("mcd.java.bczqzxsr")).toString();
/*      */         }
/*      */ 
/* 2069 */         MtlCampDatasrcColumn mcdc = this.campDatasrcColumnDao.findByColCname(colName);
/* 2070 */         if (mcdc == null)
/* 2071 */           return new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.2")).append(colName).append(MpmLocaleUtil.getMessage("mcd.java.zdbczqzxsr")).toString();
/* 2057 */         counter++;
/*      */       }
/*      */ 
/* 2076 */       if (!matched)
/* 2077 */         return MpmLocaleUtil.getMessage("mcd.java.cgshxxzmyp");
/*      */     }
/*      */     catch (MpmException e)
/*      */     {
/* 2081 */       log.error("", e);
/*      */     }
/* 2083 */     return returnMess;
/*      */   }
/*      */ 
/*      */   public Map findCampDrvList(DimCampDrvType dab, Integer curPage, Integer pageSize) throws MpmException
/*      */   {
/* 2088 */     Map map = new TreeMap();
/*      */     try {
/* 2090 */       map = this.campDevTypeDao.findCampDrvList(dab, curPage, pageSize);
/*      */     } catch (Exception e) {
/* 2092 */       log.error("", e);
/* 2093 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qkhmdrlxcw"));
/*      */     }
/* 2095 */     return map;
/*      */   }
/*      */ 
/*      */   public List getCampCanAnalyseList(String userId)
/*      */     throws Exception
/*      */   {
/* 2101 */     return null;
/*      */   }
/*      */ 
/*      */   public String getCampSegCanAnalyseArray(String userId)
/*      */   {
/* 2107 */     return null;
/*      */   }
/*      */ 
/*      */   public String getBrandHtmlByCampIdCache(String campId, String selectName)
/*      */     throws MpmException
/*      */   {
/* 2113 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampList(String userId)
/*      */     throws Exception
/*      */   {
/* 2119 */     return null;
/*      */   }
/*      */ 
/*      */   public List getInitiativeCampList(String userId)
/*      */     throws MpmException
/*      */   {
/* 2125 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampListAll(String userId)
/*      */     throws Exception
/*      */   {
/* 2131 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampListAllbyfile(String userId)
/*      */     throws Exception
/*      */   {
/* 2137 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampListAlloddact(String userId)
/*      */     throws Exception
/*      */   {
/* 2143 */     return null;
/*      */   }
/*      */ 
/*      */   public String getCampSegArrayoddact(String userId)
/*      */     throws Exception
/*      */   {
/* 2149 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampListAlloddCall(String userId)
/*      */     throws Exception
/*      */   {
/* 2155 */     return null;
/*      */   }
/*      */ 
/*      */   public String getCampSegArrayoddCall(String userId)
/*      */     throws Exception
/*      */   {
/* 2161 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampSegListbyoddact(String userId)
/*      */     throws Exception
/*      */   {
/* 2167 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampSegListbyfile(String userId)
/*      */     throws Exception
/*      */   {
/* 2173 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampSegArrayoddactbyfile(String userId)
/*      */     throws Exception
/*      */   {
/* 2179 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampsegListByCampId(String campid)
/*      */     throws MpmException
/*      */   {
/* 2185 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampSegList(String userId)
/*      */     throws Exception
/*      */   {
/* 2191 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampSegListForHD(String userId)
/*      */     throws Exception
/*      */   {
/* 2197 */     return null;
/*      */   }
/*      */ 
/*      */   public String getCampSegArray(String userId)
/*      */     throws Exception
/*      */   {
/* 2203 */     return null;
/*      */   }
/*      */ 
/*      */   public Map getCampPriMap()
/*      */     throws MpmException
/*      */   {
/* 2209 */     return null;
/*      */   }
/*      */ 
/*      */   public Map getDimPubBrandMap()
/*      */     throws MpmException
/*      */   {
/* 2215 */     return null;
/*      */   }
/*      */ 
/*      */   public List getAllStcPlan()
/*      */     throws MpmException
/*      */   {
/* 2221 */     return null;
/*      */   }
/*      */ 
/*      */   public String getReplaceLabelList()
/*      */   {
/* 2227 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isCampsegApproveExist(String createUserid)
/*      */   {
/* 2233 */     return false;
/*      */   }
/*      */ 
/*      */   public List getVipManagerSelectListCache()
/*      */     throws MpmException
/*      */   {
/* 2239 */     return null;
/*      */   }
/*      */ 
/*      */   public List getComVipManagerSelectListCache()
/*      */     throws MpmException
/*      */   {
/* 2245 */     return null;
/*      */   }
/*      */ 
/*      */   public String getVipManagerArrayCache()
/*      */     throws MpmException
/*      */   {
/* 2251 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isPublicizeCombCanDelete(String combId, String currUserId, String groupId)
/*      */     throws MpmException
/*      */   {
/* 2257 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isCanConfirmOrApprove(String campId, String campsegId, String flowId, String flag)
/*      */   {
/* 2263 */     return false;
/*      */   }
/*      */ 
/*      */   public Map getCampChannelTypeMap(String campId)
/*      */     throws MpmException
/*      */   {
/* 2269 */     return null;
/*      */   }
/*      */ 
/*      */   public List getInterfaceTable()
/*      */     throws MpmException
/*      */   {
/* 2275 */     return null;
/*      */   }
/*      */ 
/*      */   public String getCampSegArrayExec(String campsegStatId)
/*      */     throws Exception
/*      */   {
/* 2281 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampListbyExec()
/*      */     throws Exception
/*      */   {
/* 2287 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampListAlloddWeb(String userId)
/*      */     throws Exception
/*      */   {
/* 2293 */     return null;
/*      */   }
/*      */ 
/*      */   public String getCampSegArrayoddWeb(String userId)
/*      */     throws Exception
/*      */   {
/* 2299 */     return null;
/*      */   }
/*      */ 
/*      */   public Map getScenesElementsMap(String scenesId)
/*      */     throws MpmException
/*      */   {
/* 2305 */     return null;
/*      */   }
/*      */ 
/*      */   public Map getDimCustTypeMap()
/*      */     throws MpmException
/*      */   {
/* 2311 */     return null;
/*      */   }
/*      */ 
/*      */   public List findCampsegByChannelTypeId(String channeltypeId, String userId)
/*      */     throws Exception
/*      */   {
/* 2317 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCampSegListExec(String campsegStatId)
/*      */     throws Exception
/*      */   {
/* 2323 */     return null;
/*      */   }
/*      */ 
/*      */   public String getCustDataMonth(String custGroupId)
/*      */     throws MpmException
/*      */   {
/* 2329 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isPartnerCanDelete(String partnerId, String currUserId, String groupId)
/*      */     throws MpmException
/*      */   {
/* 2335 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isPlanCanDelete(String planId, String currUserId, String groupId)
/*      */     throws MpmException
/*      */   {
/* 2341 */     return false;
/*      */   }
/*      */ 
/*      */   public String getCustGroupByCampSeg(String campSegId)
/*      */     throws Exception
/*      */   {
/* 2347 */     return null;
/*      */   }
/*      */ 
/*      */   public String getCalendarDate(String userId)
/*      */     throws Exception
/*      */   {
/* 2353 */     return null;
/*      */   }
/*      */ 
/*      */   public List getStcPlans(String planIds)
/*      */     throws MpmException
/*      */   {
/* 2359 */     return null;
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getBsMmsContent()
/*      */     throws Exception
/*      */   {
/* 2365 */     return null;
/*      */   }
/*      */ 
/*      */   public String getMtlStcPlanName(String planIdStr)
/*      */     throws Exception
/*      */   {
/* 2371 */     return null;
/*      */   }
/*      */ 
/*      */   public TreeMap getBrandTreeMap()
/*      */   {
/* 2377 */     return null;
/*      */   }
/*      */ 
/*      */   public String getAllBrandString()
/*      */     throws Exception
/*      */   {
/* 2383 */     return null;
/*      */   }
/*      */ 
/*      */   public String deleteAttachmentById(String attaId)
/*      */     throws Exception
/*      */   {
/* 2389 */     return null;
/*      */   }
/*      */ 
/*      */   public String getIrUnitName(String unitId)
/*      */   {
/* 2395 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isReplayExist(String feed, String channelType)
/*      */     throws Exception
/*      */   {
/* 2402 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isCustGroupCanDelete(String custGroupId, String currUserId, String groupId)
/*      */     throws MpmException
/*      */   {
/* 2408 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isCustGroupCanDivide(String custGroupId, String currUserId, String groupId)
/*      */     throws MpmException
/*      */   {
/* 2414 */     return false;
/*      */   }
/*      */ 
/*      */   public int isCustGroupCanChgStatus(String custGroupId, String currUserId, String groupId)
/*      */     throws MpmException
/*      */   {
/* 2420 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getCustGroupTypeById(String custid)
/*      */   {
/* 2426 */     return 0;
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getAllApproveDrvDimTable() throws Exception {
/* 2430 */     ConnectionEx conn = null;
/* 2431 */     Sqlca sqlca = null;
/* 2432 */     String sql = "select id,var_table_desc from ap_approve_drv_dimtable order by id asc";
/* 2433 */     List list = new ArrayList();
/*      */     try {
/* 2435 */       conn = new ConnectionEx("JDBC_APP");
/* 2436 */       sqlca = new Sqlca(conn);
/* 2437 */       sqlca.execute(sql);
/* 2438 */       while (sqlca.next()) {
/* 2439 */         String id = sqlca.getString("id");
/* 2440 */         String table = sqlca.getString("var_table_desc");
/* 2441 */         list.add(new LabelValueBean(table, id));
/*      */       }
/*      */     } catch (Exception e) {
/* 2444 */       log.error("", e);
/*      */     } finally {
/* 2446 */       if (sqlca != null)
/* 2447 */         sqlca.close();
/*      */       try {
/* 2449 */         if (!conn.isClosed())
/* 2450 */           conn.close();
/*      */       }
/*      */       catch (Exception e) {
/* 2453 */         e.printStackTrace();
/*      */       }
/*      */     }
/* 2456 */     return list;
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getListApproveDrvDimTableCon(String tid) throws Exception
/*      */   {
/* 2461 */     ConnectionEx conn = null;
/* 2462 */     Sqlca sqlca = null;
/* 2463 */     String sql = "select id,var_table_code,var_table_id_coloum,var_table_val_coloum,var_jndi from ap_approve_drv_dimtable where id=?";
/* 2464 */     String[] tableList = null;
/*      */     try {
/* 2466 */       conn = new ConnectionEx("JDBC_APP");
/* 2467 */       sqlca = new Sqlca(conn);
/* 2468 */       sqlca.execute(sql, new String[] { tid });
/* 2469 */       while (sqlca.next()) {
/* 2470 */         String id = sqlca.getString("id");
/* 2471 */         String table_code = sqlca.getString("var_table_code");
/* 2472 */         String table_id_coloum = sqlca.getString("var_table_id_coloum");
/* 2473 */         String table_val_coloum = sqlca.getString("var_table_val_coloum");
/* 2474 */         String jndi = sqlca.getString("var_jndi");
/* 2475 */         tableList = new String[] { id, table_code, table_id_coloum, table_val_coloum, jndi };
/*      */       }
/*      */     } catch (Exception e) {
/* 2478 */       log.error("", e);
/*      */     } finally {
/* 2480 */       if (sqlca != null)
/* 2481 */         sqlca.close();
/*      */       try {
/* 2483 */         if (!conn.isClosed())
/* 2484 */           conn.close();
/*      */       }
/*      */       catch (Exception e) {
/* 2487 */         e.printStackTrace();
/*      */       }
/*      */     }
/* 2490 */     List cList = new ArrayList();
/* 2491 */     if (tableList != null)
/*      */     {
/* 2493 */       ConnectionEx con = null;
/* 2494 */       Sqlca sqlca1 = null;
/* 2495 */       String id = tableList[0];
/* 2496 */       String sqlCon = new StringBuffer("select ").append(tableList[2]).append(" as id,").append(tableList[3]).append(" as val from ").append(tableList[1]).append(" order by ").append(tableList[2]).append(" asc").toString();
/*      */       try
/*      */       {
/* 2501 */         con = new ConnectionEx(tableList[4]);
/* 2502 */         sqlca1 = new Sqlca(con);
/* 2503 */         sqlca1.execute(sqlCon);
/* 2504 */         while (sqlca1.next()) {
/* 2505 */           String c_id = sqlca1.getString("id");
/* 2506 */           String c_val = sqlca1.getString("val");
/* 2507 */           cList.add(new LabelValueBean(c_val, c_id));
/*      */         }
/*      */       } catch (Exception e) {
/* 2510 */         log.error("", e);
/*      */       } finally {
/* 2512 */         if (sqlca1 != null)
/* 2513 */           sqlca1.close();
/*      */         try {
/* 2515 */           if (!con.isClosed())
/* 2516 */             con.close();
/*      */         }
/*      */         catch (Exception e) {
/* 2519 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2524 */     return cList;
/*      */   }
/*      */ 
/*      */   public Map<String, Map<String, String>> getMapApproveDrvDimTableCon() throws Exception
/*      */   {
/* 2529 */     ConnectionEx conn = null;
/* 2530 */     Sqlca sqlca = null;
/* 2531 */     String sql = "select id,var_table_code,var_table_id_coloum,var_table_val_coloum,var_jndi from ap_approve_drv_dimtable";
/* 2532 */     List tableList = new ArrayList();
/*      */     try {
/* 2534 */       conn = new ConnectionEx("JDBC_APP");
/* 2535 */       sqlca = new Sqlca(conn);
/* 2536 */       sqlca.execute(sql);
/* 2537 */       while (sqlca.next()) {
/* 2538 */         String id = sqlca.getString("id");
/* 2539 */         String table_code = sqlca.getString("var_table_code");
/* 2540 */         String table_id_coloum = sqlca.getString("var_table_id_coloum");
/* 2541 */         String table_val_coloum = sqlca.getString("var_table_val_coloum");
/* 2542 */         String jndi = sqlca.getString("var_jndi");
/* 2543 */         tableList.add(new String[] { id, table_code, table_id_coloum, table_val_coloum, jndi });
/*      */       }
/*      */     } catch (Exception e) {
/* 2546 */       log.error("", e);
/*      */     } finally {
/* 2548 */       if (sqlca != null)
/* 2549 */         sqlca.close();
/*      */       try {
/* 2551 */         if (!conn.isClosed())
/* 2552 */           conn.close();
/*      */       }
/*      */       catch (Exception e) {
/* 2555 */         e.printStackTrace();
/*      */       }
/*      */     }
/* 2558 */     Map retMap = new HashMap();
/* 2559 */     if (tableList != null) {
/* 2560 */       for (String[] arrs : tableList)
/*      */       {
/* 2562 */         ConnectionEx con = null;
/* 2563 */         Sqlca sqlca1 = null;
/* 2564 */         String id = arrs[0];
/* 2565 */         String sqlCon = new StringBuffer("select ").append(arrs[2]).append(" as id,").append(arrs[3]).append(" as val from ").append(arrs[1]).append(" order by ").append(arrs[2]).append(" asc").toString();
/*      */ 
/* 2568 */         Map map = new HashMap();
/*      */         try {
/* 2570 */           con = new ConnectionEx(arrs[4]);
/* 2571 */           sqlca1 = new Sqlca(con);
/* 2572 */           sqlca1.execute(sqlCon);
/* 2573 */           while (sqlca1.next()) {
/* 2574 */             String c_id = sqlca1.getString("id");
/* 2575 */             String c_val = sqlca1.getString("val");
/* 2576 */             map.put(c_id, c_val);
/*      */           }
/* 2578 */           retMap.put(id, map);
/*      */         } catch (Exception e) {
/* 2580 */           log.error("", e);
/*      */         } finally {
/* 2582 */           if (sqlca1 != null)
/* 2583 */             sqlca1.close();
/*      */           try {
/* 2585 */             if (!con.isClosed())
/* 2586 */               con.close();
/*      */           }
/*      */           catch (Exception e) {
/* 2589 */             e.printStackTrace();
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2596 */     return retMap;
/*      */   }
/*      */ 
/*      */   public String getAllApproveDrvDimTableConByid(String tid) throws Exception {
/* 2600 */     JSONArray ja = new JSONArray();
/* 2601 */     if (StringUtil.isNotEmpty(tid)) {
/* 2602 */       ConnectionEx conn = null;
/* 2603 */       Sqlca sqlca = null;
/* 2604 */       String sql = "select id,var_table_code,var_table_id_coloum,var_table_val_coloum,var_jndi from ap_approve_drv_dimtable where id=?";
/* 2605 */       List tableList = new ArrayList();
/*      */       try {
/* 2607 */         conn = new ConnectionEx("JDBC_APP");
/* 2608 */         sqlca = new Sqlca(conn);
/* 2609 */         sqlca.execute(sql, new String[] { tid });
/* 2610 */         while (sqlca.next()) {
/* 2611 */           String id = sqlca.getString("id");
/* 2612 */           String table_code = sqlca.getString("var_table_code");
/* 2613 */           String table_id_coloum = sqlca.getString("var_table_id_coloum");
/* 2614 */           String table_val_coloum = sqlca.getString("var_table_val_coloum");
/* 2615 */           String jndi = sqlca.getString("var_jndi");
/* 2616 */           tableList.add(new String[] { id, table_code, table_id_coloum, table_val_coloum, jndi });
/*      */         }
/*      */       } catch (Exception e) {
/* 2619 */         log.error("", e);
/*      */       } finally {
/* 2621 */         if (sqlca != null)
/* 2622 */           sqlca.close();
/*      */         try {
/* 2624 */           if (!conn.isClosed())
/* 2625 */             conn.close();
/*      */         }
/*      */         catch (Exception e) {
/* 2628 */           e.printStackTrace();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2633 */       if (tableList.size() > 0) {
/* 2634 */         for (String[] arrs : tableList) {
/* 2635 */           ConnectionEx con = null;
/* 2636 */           Sqlca sqlca1 = null;
/* 2637 */           String id = arrs[0];
/* 2638 */           String sqlCon = new StringBuffer("select ").append(arrs[2]).append(" as id,").append(arrs[3]).append(" as val from ").append(arrs[1]).append(" order by ").append(arrs[2]).append(" asc").toString();
/*      */           try
/*      */           {
/* 2642 */             con = new ConnectionEx(arrs[4]);
/* 2643 */             sqlca1 = new Sqlca(con);
/* 2644 */             sqlca1.execute(sqlCon);
/* 2645 */             while (sqlca1.next()) {
/* 2646 */               JSONObject json = new JSONObject();
/* 2647 */               String c_id = sqlca1.getString("id");
/* 2648 */               String c_val = sqlca1.getString("val");
/* 2649 */               json.put("code", c_id);
/* 2650 */               json.put("val", c_val);
/* 2651 */               ja.add(json.toString());
/* 2652 */               json.clear();
/*      */             }
/*      */           } catch (Exception e) {
/* 2655 */             log.error("", e);
/*      */           } finally {
/* 2657 */             if (sqlca1 != null)
/* 2658 */               sqlca1.close();
/*      */             try {
/* 2660 */               if (!con.isClosed())
/* 2661 */                 con.close();
/*      */             }
/*      */             catch (Exception e) {
/* 2664 */               e.printStackTrace();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2671 */     return ja.toString();
/*      */   }
/*      */ 
/*      */   public boolean isFlowRelationExist(String relationType, String campDrvId, String cityId, String deptId, String approveFlowId, String flow_type)
/*      */   {
/* 2677 */     ConnectionEx conn = null;
/* 2678 */     Sqlca sqlca = null;
/* 2679 */     boolean flag = false;
/*      */     try {
/* 2681 */       String sql = "select count(1)  as count from ap_dept_flow_relation where CITY_ID=? and DEPT_ID=? and CAMP_DRV_ID=? and RELATION_TYPE=? and APPR_FLOW_TPYE=?";
/* 2682 */       conn = new ConnectionEx("JDBC_APP");
/* 2683 */       sqlca = new Sqlca(conn);
/* 2684 */       sqlca.execute(sql, new String[] { cityId, deptId, campDrvId, relationType, flow_type });
/* 2685 */       int count = 0;
/* 2686 */       while (sqlca.next()) {
/* 2687 */         count = sqlca.getInt("count");
/*      */       }
/* 2689 */       if (count > 0)
/* 2690 */         flag = true;
/*      */     }
/*      */     catch (Exception e) {
/* 2693 */       log.error("", e);
/*      */     } finally {
/* 2695 */       if (sqlca != null)
/* 2696 */         sqlca.close();
/*      */       try {
/* 2698 */         if (!conn.isClosed())
/* 2699 */           conn.close();
/*      */       }
/*      */       catch (Exception e) {
/* 2702 */         e.printStackTrace();
/*      */       }
/*      */     }
/* 2705 */     return flag;
/*      */   }
/*      */ 
/*      */   public boolean isDrvExist(String tableID, String tableColVal, String flowId, String campDrvId)
/*      */   {
/* 2710 */     ConnectionEx conn = null;
/* 2711 */     Sqlca sqlca = null;
/* 2712 */     boolean flag = false;
/* 2713 */     if ((StringUtil.isEmpty(campDrvId)) && (StringUtil.isNotEmpty(tableID)) && (StringUtil.isNotEmpty(tableColVal))) {
/*      */       try
/*      */       {
/* 2716 */         conn = new ConnectionEx("JDBC_APP");
/* 2717 */         sqlca = new Sqlca(conn);
/*      */ 
/* 2725 */         int count1 = 0;
/* 2726 */         String sql1 = "select count(1)  as count1 from ap_approve_drv_type where table_id=?  and table_col_val=?";
/* 2727 */         sqlca.execute(sql1, new String[] { tableID, tableColVal });
/* 2728 */         while (sqlca.next()) {
/* 2729 */           count1 = sqlca.getInt("count1");
/*      */         }
/* 2731 */         if (count1 > 0)
/* 2732 */           flag = true;
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 2736 */         log.error("", e);
/*      */       } finally {
/* 2738 */         if (sqlca != null)
/* 2739 */           sqlca.close();
/*      */         try {
/* 2741 */           if (!conn.isClosed())
/* 2742 */             conn.close();
/*      */         }
/*      */         catch (Exception e) {
/* 2745 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2750 */     return flag;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MpmCommonServiceImpl
 * JD-Core Version:    0.6.2
 */
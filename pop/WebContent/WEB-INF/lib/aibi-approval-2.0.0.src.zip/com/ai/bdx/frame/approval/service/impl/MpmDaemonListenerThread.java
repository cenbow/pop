/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlProcBeatDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlProcPopDao;
/*     */ import com.ai.bdx.frame.approval.model.MtlProcBeat;
/*     */ import com.ai.bdx.frame.approval.model.MtlProcBeatId;
/*     */ import com.ai.bdx.frame.approval.util.MpmUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class MpmDaemonListenerThread extends Thread
/*     */ {
/*  19 */   private static Logger log = LogManager.getLogger();
/*  20 */   int processId = MpmUtil.getPid();
/*     */   IMtlProcPopDao mtlProcPopDao;
/*     */   IMtlProcBeatDao mtlProcBeatDao;
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     while (true)
/*     */     {
/*  25 */       List mtlProcBeatList = getMtlProcBeatDao().findByProcId(Integer.valueOf(this.processId));
/*     */ 
/*  27 */       if (mtlProcBeatList.size() > 0) {
/*  28 */         MtlProcBeat mtlProcBeat = (MtlProcBeat)mtlProcBeatList.get(0);
/*  29 */         getMtlProcBeatDao().updateBeatTime(mtlProcBeat);
/*     */       } else {
/*  31 */         MtlProcBeatId mpbi = new MtlProcBeatId();
/*  32 */         mpbi.setProcId(Integer.valueOf(this.processId));
/*  33 */         mpbi.setProgramName("mcd");
/*  34 */         Calendar cal = Calendar.getInstance();
/*     */ 
/*  36 */         Timestamp timestamp = new Timestamp(cal.getTimeInMillis());
/*  37 */         mpbi.setBeatTime(timestamp);
/*  38 */         mpbi.setStartTime(timestamp);
/*  39 */         mpbi.setStatus(Short.valueOf((short)1));
/*  40 */         MtlProcBeat mtlProcBeat = new MtlProcBeat(mpbi);
/*  41 */         getMtlProcBeatDao().save(mtlProcBeat);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/*  77 */         sleep(10000L);
/*     */       }
/*     */       catch (InterruptedException e) {
/*  80 */         log.error("", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public IMtlProcPopDao getMtlProcPopDao()
/*     */   {
/*  89 */     if (this.mtlProcPopDao == null) {
/*     */       try {
/*  91 */         this.mtlProcPopDao = ((IMtlProcPopDao)SystemServiceLocator.getInstance().getService("mtlProcPopDao"));
/*     */       }
/*     */       catch (Exception e) {
/*  94 */         log.error("", e);
/*     */       }
/*     */     }
/*  97 */     return this.mtlProcPopDao;
/*     */   }
/*     */ 
/*     */   public void setMtlProcPopDao(IMtlProcPopDao mtlProcPopDao) {
/* 101 */     this.mtlProcPopDao = mtlProcPopDao;
/*     */   }
/*     */ 
/*     */   public IMtlProcBeatDao getMtlProcBeatDao() {
/* 105 */     if (this.mtlProcBeatDao == null) {
/*     */       try {
/* 107 */         this.mtlProcBeatDao = ((IMtlProcBeatDao)SystemServiceLocator.getInstance().getService("mtlProcBeatDao"));
/*     */       }
/*     */       catch (Exception e) {
/* 110 */         log.error("", e);
/*     */       }
/*     */     }
/* 113 */     return this.mtlProcBeatDao;
/*     */   }
/*     */ 
/*     */   public void setMtlProcBeatDao(IMtlProcBeatDao mtlProcBeatDao) {
/* 117 */     this.mtlProcBeatDao = mtlProcBeatDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MpmDaemonListenerThread
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.service.impl;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMtlProcBeatDao;
import com.ai.bdx.frame.approval.dao.IMtlProcPopDao;
import com.ai.bdx.frame.approval.model.MtlProcBeat;
import com.ai.bdx.frame.approval.model.MtlProcBeatId;
import com.ai.bdx.frame.approval.util.MpmUtil;
import com.asiainfo.biframe.utils.spring.SystemServiceLocator;

public class MpmDaemonListenerThread extends Thread {
	private static Logger log = LogManager.getLogger();
	int processId = MpmUtil.getPid();

	@Override
	public void run() {
		while (true) {
			List mtlProcBeatList = getMtlProcBeatDao().findByProcId(processId);
			MtlProcBeat mtlProcBeat;
			if (mtlProcBeatList.size() > 0) {
				mtlProcBeat = (MtlProcBeat) mtlProcBeatList.get(0);
				getMtlProcBeatDao().updateBeatTime(mtlProcBeat);
			} else {
				MtlProcBeatId mpbi = new MtlProcBeatId();
				mpbi.setProcId(processId);
				mpbi.setProgramName("mcd");
				Calendar cal = Calendar.getInstance();
				// 从配置文件中读取扫描的时间间隔
				Timestamp timestamp = new Timestamp(cal.getTimeInMillis());
				mpbi.setBeatTime(timestamp);
				mpbi.setStartTime(timestamp);
				mpbi.setStatus(Short.valueOf((short) 1));
				mtlProcBeat = new MtlProcBeat(mpbi);
				getMtlProcBeatDao().save(mtlProcBeat);
			}

			// List mtlProcBeatList = getMtlProcBeatDao().findBeatRecord();
			// Iterator<MtlProcBeat> it = mtlProcBeatList.iterator();
			// while (it.hasNext()) {
			// MtlProcBeat mpb = it.next();
			// // MtlProcPop mpp=new MpmDaemonListenerThread()
			// List mppList = null;
			// mppList = getMtlProcPopDao().findPopRecord(
			// mpb.getId().getProcId());
			// if (mppList == null || mppList.size() < 1) {
			// // 发送短信
			// log.debug("发送短信：后台服务已关闭，进程名："
			// + mpb.getId().getProgramName() + ",进程号："
			// + mpb.getId().getProcId());
			//
			// MtlProcPopId mppi = new MtlProcPopId();
			// mppi.setProcId(mpb.getId().getProcId());
			// mppi.setStartTime(mpb.getId().getStartTime());
			//
			// Calendar cal = Calendar.getInstance();
			// // 从配置文件中读取扫描的时间间隔
			// Timestamp timestamp = new Timestamp(cal.getTimeInMillis());
			// mppi.setPopTime(timestamp);
			// MtlProcPop mpp = new MtlProcPop(mppi);
			// getMtlProcPopDao().save(mpp);
			// } else {
			// // log.debug("已经发送过短信");
			//
			// }
			// }
			try {
				// int interval = Integer.parseInt(Configure.getInstance()
				// .getProperty("DEAMON_LISTENER_INTERVAL"));
				// this.sleep(interval * 60 * 1000);
				this.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				log.error("", e);
			}
		}
	}

	IMtlProcPopDao mtlProcPopDao;
	IMtlProcBeatDao mtlProcBeatDao;

	public IMtlProcPopDao getMtlProcPopDao() {
		if (mtlProcPopDao == null) {
			try {
				mtlProcPopDao = (IMtlProcPopDao) SystemServiceLocator
						.getInstance().getService(MpmCONST.MTL_PROC_POP_DAO);
			} catch (Exception e) {
				log.error("", e);
			}
		}
		return mtlProcPopDao;
	}

	public void setMtlProcPopDao(IMtlProcPopDao mtlProcPopDao) {
		this.mtlProcPopDao = mtlProcPopDao;
	}

	public IMtlProcBeatDao getMtlProcBeatDao() {
		if (mtlProcBeatDao == null) {
			try {
				mtlProcBeatDao = (IMtlProcBeatDao) SystemServiceLocator
						.getInstance().getService(MpmCONST.MTL_PROC_BEAT_DAO);
			} catch (Exception e) {
				log.error("", e);
			}
		}
		return mtlProcBeatDao;
	}

	public void setMtlProcBeatDao(IMtlProcBeatDao mtlProcBeatDao) {
		this.mtlProcBeatDao = mtlProcBeatDao;
	}
}

package com.ai.bdx.frame.approval.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.dao.IDimResTypeDao;
import com.ai.bdx.frame.approval.dao.IMpmCostListDao;
import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
import com.ai.bdx.frame.approval.dao.IMtlResListDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlCostList;
import com.ai.bdx.frame.approval.model.MtlResList;
import com.ai.bdx.frame.approval.service.IMpmResListSvc;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

public class MpmResListSvcImpl implements IMpmResListSvc {
	private static Logger log = LogManager.getLogger();

	IMtlResListDao mtlResListDao;

	IDimResTypeDao dimResTypeDao;

	IMpmCostListDao mpmCostListDao;

	IMpmForPageDao mpmForPageDao;


	public void setMtlResListDao(IMtlResListDao mtlResListDao) {
		this.mtlResListDao = mtlResListDao;
	}

	public IMtlResListDao getMtlResListDao() {
		return mtlResListDao;
	}

	public void setDimResTypeDao(IDimResTypeDao dimResTypeDao) {
		this.dimResTypeDao = dimResTypeDao;
	}

	public IDimResTypeDao getDimResTypeDao() {
		return dimResTypeDao;
	}

	public void setMpmCostListDao(IMpmCostListDao mpmCostListDao) {
		this.mpmCostListDao = mpmCostListDao;
	}

	public IMpmCostListDao getMpmCostListDao() {
		return mpmCostListDao;
	}

	public void setMpmForPageDao(IMpmForPageDao mpmForPageDao) {
		this.mpmForPageDao = mpmForPageDao;
	}

	public IMpmForPageDao getMpmForPageDao() {
		return mpmForPageDao;
	}

	
	/**
	 * 取所有的实体信息
	 */
	public Map findAllRes(MtlResList svc, Integer curPage, Integer pageSize)
			throws MpmException {
		try {
			return mpmForPageDao.findResAll(svc, curPage, pageSize);
		} catch (Exception e) {
			log.debug("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.qsydstxxsb"));
		}
	}

	/**
	 * 获取实体的一条信息
	 * 
	 * @param resCode
	 * @return
	 * @throws MpmException
	 */
	public MtlResList findResListByCode(String resCode, String resFlag)
			throws MpmException {
		MtlResList result = new MtlResList();
		try {
			result = mtlResListDao.findByCode(resCode, resFlag);
		} catch (Exception e) {
			log.debug("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.hqytstxxsb"));
		}
		return result;
	}

	public List findResListByCostCode(String costCode) throws MpmException {
		try {
			return mtlResListDao.findByCostCode(costCode);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.tgcblxhqst"));
		}
	}

	/*public List findResourceCostByResCode(String resCode) throws MpmException {
		try {
			return mtlResourceCostPlanDao.findByResCode(resCode);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException("");
		}
	}*/

	/**
	 * 保存一条实体信息
	 * 
	 * @param mtlResList
	 * @return
	 * @throws MpmException
	 */
	public String saveResList(MtlResList mtlResList) throws MpmException {
		String result = "";
		try {
			result = mtlResListDao.save(mtlResList);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.bcstxxsb"));
		}
		return result;
	}

	/**
	 * 更新一条实体信息
	 * 
	 * @param mtlResList
	 * @return
	 * @throws MpmException
	 */
	public boolean updateResList(MtlResList mtlResList) throws MpmException {
		boolean flag = false;
		try {
			mtlResListDao.update(mtlResList);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.xgstxxsb"));
		}
		return flag;
	}

	/**
	 * 删除一条实体信息
	 * 
	 * @param mtlResList
	 * @return
	 * @throws MpmException
	 */
	public boolean deleteResList(String resCode) throws MpmException {
		boolean flag = false;
		try {
			mtlResListDao.delete(resCode);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.scstxxsb"));
		}
		return flag;
	}

	/**
	 * 获取成本类型
	 * 
	 * @return
	 * @throws MpmException
	 */
	public List getCostList() throws MpmException {
		List result = new ArrayList();
		try {
			result = mpmCostListDao.findAll();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.ddcblxsb"));
		}
		return result;
	}

	/**
	 * 获取实体类型信息
	 * 
	 * @return
	 * @throws MpmException
	 */
	public List getResTypeList() throws MpmException {
		List result = new ArrayList();
		try {
			result = dimResTypeDao.findAll();
		} catch (Exception e) {
			log.error("", e);
		}
		return result;
	}

	/**
	 * 获取成本类型的分页信息
	 */
	public Map findAllCost(MtlCostList svc, Integer curPage, Integer pageSize)
			throws MpmException {
		try {
			return mpmForPageDao.findCostAll(svc, curPage, pageSize);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.hqcblxxxsb"));
		}
	}

	/**
	 * 插入一条成本类型信息
	 * 
	 * @param mtlCostList
	 * @return
	 * @throws MpmException
	 */
	public MtlCostList saveCostList(MtlCostList mtlCostList)
			throws MpmException {
		MtlCostList result = new MtlCostList();
		try {
			result = mpmCostListDao.save(mtlCostList);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.bccbxxsb"));
		}
		return result;
	}

	/**
	 * 修改一条成本类型信息
	 * 
	 * @param mtlCostList
	 * @return
	 * @throws MpmException
	 */
	public boolean updateCostList(MtlCostList mtlCostList) throws MpmException {
		boolean flag = false;
		try {
			mpmCostListDao.update(mtlCostList);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.xgcbxxsb"));
		}
		return flag;
	}

	/**
	 * 插入一条成本类型信息
	 * 
	 * @param mtlCostList
	 * @return
	 * @throws MpmException
	 */
	public boolean deleteCostList(String costCode) throws MpmException {
		boolean flag = false;
		try {
			mpmCostListDao.delete(costCode);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.sccbxxsb"));
		}
		return flag;
	}

	/**
	 * 获取成本的一条信息
	 * 
	 * @param resCode
	 * @return
	 * @throws MpmException
	 */
	public MtlCostList findCostListByCode(String costCode) throws MpmException {
		MtlCostList result = new MtlCostList();
		try {
			result = mpmCostListDao.findByCode(costCode);
		} catch (Exception e) {
			log.debug("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.hqytstxxsb"));
		}
		return result;
	}

	public List findAllCostList() throws Exception {

		return mpmCostListDao.findAll();
	}

	public List getAllSubCostList(String costCode) throws Exception {
		List result = new ArrayList();
		if (costCode != null && !"".equals(costCode)) {
			MtlCostList cost = mpmCostListDao.findByCode(costCode);
			if (cost != null) {
				int costType = cost.getCostType().intValue();
				if (0 == costType) { // 传入的是一个总类；返回除这个类型之外的所有类型；
					result = mpmCostListDao.findAll();
					for (Iterator it = result.iterator(); it.hasNext();) {
						cost = (MtlCostList) it.next();
						if (cost.getCostType().intValue() == 0) {
							it.remove();
						}
					}
				} else { // 传入的不是总类，返回本身；
					result.add(cost);
				}
			}
		}

		return result;
	}

	/**
	 *
	 * @return
	 * @throws MpmException
	 */
	public Map findCostListMap() throws MpmException {
		try {
			Iterator it = mpmCostListDao.findAll().iterator();
			Map map = new TreeMap();
			while (it.hasNext()) {
				MtlCostList mcl = (MtlCostList) it.next();
				map.put(mcl.getCostCode(), mcl.getCostName());
			}
			return map;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.hqcblxsb"));
		}
	}

}

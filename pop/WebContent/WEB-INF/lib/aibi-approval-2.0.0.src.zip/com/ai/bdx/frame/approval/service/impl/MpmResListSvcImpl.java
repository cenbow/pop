/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimResTypeDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMpmCostListDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlResListDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.model.MtlCostList;
/*     */ import com.ai.bdx.frame.approval.model.MtlResList;
/*     */ import com.ai.bdx.frame.approval.service.IMpmResListSvc;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class MpmResListSvcImpl
/*     */   implements IMpmResListSvc
/*     */ {
/*  23 */   private static Logger log = LogManager.getLogger();
/*     */   IMtlResListDao mtlResListDao;
/*     */   IDimResTypeDao dimResTypeDao;
/*     */   IMpmCostListDao mpmCostListDao;
/*     */   IMpmForPageDao mpmForPageDao;
/*     */ 
/*     */   public void setMtlResListDao(IMtlResListDao mtlResListDao)
/*     */   {
/*  35 */     this.mtlResListDao = mtlResListDao;
/*     */   }
/*     */ 
/*     */   public IMtlResListDao getMtlResListDao() {
/*  39 */     return this.mtlResListDao;
/*     */   }
/*     */ 
/*     */   public void setDimResTypeDao(IDimResTypeDao dimResTypeDao) {
/*  43 */     this.dimResTypeDao = dimResTypeDao;
/*     */   }
/*     */ 
/*     */   public IDimResTypeDao getDimResTypeDao() {
/*  47 */     return this.dimResTypeDao;
/*     */   }
/*     */ 
/*     */   public void setMpmCostListDao(IMpmCostListDao mpmCostListDao) {
/*  51 */     this.mpmCostListDao = mpmCostListDao;
/*     */   }
/*     */ 
/*     */   public IMpmCostListDao getMpmCostListDao() {
/*  55 */     return this.mpmCostListDao;
/*     */   }
/*     */ 
/*     */   public void setMpmForPageDao(IMpmForPageDao mpmForPageDao) {
/*  59 */     this.mpmForPageDao = mpmForPageDao;
/*     */   }
/*     */ 
/*     */   public IMpmForPageDao getMpmForPageDao() {
/*  63 */     return this.mpmForPageDao;
/*     */   }
/*     */ 
/*     */   public Map findAllRes(MtlResList svc, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  73 */       return this.mpmForPageDao.findResAll(svc, curPage, pageSize);
/*     */     } catch (Exception e) {
/*  75 */       log.debug("", e);
/*  76 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsydstxxsb"));
/*     */   }
/*     */ 
/*     */   public MtlResList findResListByCode(String resCode, String resFlag)
/*     */     throws MpmException
/*     */   {
/*  90 */     MtlResList result = new MtlResList();
/*     */     try {
/*  92 */       result = this.mtlResListDao.findByCode(resCode, resFlag);
/*     */     } catch (Exception e) {
/*  94 */       log.debug("", e);
/*  95 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqytstxxsb"));
/*     */     }
/*     */ 
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */   public List findResListByCostCode(String costCode) throws MpmException {
/*     */     try {
/* 103 */       return this.mtlResListDao.findByCostCode(costCode);
/*     */     } catch (Exception e) {
/* 105 */       log.error("", e);
/* 106 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.tgcblxhqst"));
/*     */   }
/*     */ 
/*     */   public String saveResList(MtlResList mtlResList)
/*     */     throws MpmException
/*     */   {
/* 128 */     String result = "";
/*     */     try {
/* 130 */       result = this.mtlResListDao.save(mtlResList);
/*     */     } catch (Exception e) {
/* 132 */       log.error("", e);
/* 133 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcstxxsb"));
/*     */     }
/*     */ 
/* 136 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean updateResList(MtlResList mtlResList)
/*     */     throws MpmException
/*     */   {
/* 147 */     boolean flag = false;
/*     */     try {
/* 149 */       this.mtlResListDao.update(mtlResList);
/* 150 */       flag = true;
/*     */     } catch (Exception e) {
/* 152 */       log.error("", e);
/* 153 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.xgstxxsb"));
/*     */     }
/*     */ 
/* 156 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean deleteResList(String resCode)
/*     */     throws MpmException
/*     */   {
/* 167 */     boolean flag = false;
/*     */     try {
/* 169 */       this.mtlResListDao.delete(resCode);
/* 170 */       flag = true;
/*     */     } catch (Exception e) {
/* 172 */       log.error("", e);
/* 173 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scstxxsb"));
/*     */     }
/*     */ 
/* 176 */     return flag;
/*     */   }
/*     */ 
/*     */   public List getCostList()
/*     */     throws MpmException
/*     */   {
/* 186 */     List result = new ArrayList();
/*     */     try {
/* 188 */       result = this.mpmCostListDao.findAll();
/*     */     } catch (Exception e) {
/* 190 */       log.error("", e);
/* 191 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddcblxsb"));
/*     */     }
/*     */ 
/* 194 */     return result;
/*     */   }
/*     */ 
/*     */   public List getResTypeList()
/*     */     throws MpmException
/*     */   {
/* 204 */     List result = new ArrayList();
/*     */     try {
/* 206 */       result = this.dimResTypeDao.findAll();
/*     */     } catch (Exception e) {
/* 208 */       log.error("", e);
/*     */     }
/* 210 */     return result;
/*     */   }
/*     */ 
/*     */   public Map findAllCost(MtlCostList svc, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 219 */       return this.mpmForPageDao.findCostAll(svc, curPage, pageSize);
/*     */     } catch (Exception e) {
/* 221 */       log.error("", e);
/* 222 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqcblxxxsb"));
/*     */   }
/*     */ 
/*     */   public MtlCostList saveCostList(MtlCostList mtlCostList)
/*     */     throws MpmException
/*     */   {
/* 236 */     MtlCostList result = new MtlCostList();
/*     */     try {
/* 238 */       result = this.mpmCostListDao.save(mtlCostList);
/*     */     } catch (Exception e) {
/* 240 */       log.error("", e);
/* 241 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bccbxxsb"));
/*     */     }
/*     */ 
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean updateCostList(MtlCostList mtlCostList)
/*     */     throws MpmException
/*     */   {
/* 255 */     boolean flag = false;
/*     */     try {
/* 257 */       this.mpmCostListDao.update(mtlCostList);
/* 258 */       flag = true;
/*     */     } catch (Exception e) {
/* 260 */       log.error("", e);
/* 261 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.xgcbxxsb"));
/*     */     }
/*     */ 
/* 264 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean deleteCostList(String costCode)
/*     */     throws MpmException
/*     */   {
/* 275 */     boolean flag = false;
/*     */     try {
/* 277 */       this.mpmCostListDao.delete(costCode);
/* 278 */       flag = true;
/*     */     } catch (Exception e) {
/* 280 */       log.error("", e);
/* 281 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.sccbxxsb"));
/*     */     }
/*     */ 
/* 284 */     return flag;
/*     */   }
/*     */ 
/*     */   public MtlCostList findCostListByCode(String costCode)
/*     */     throws MpmException
/*     */   {
/* 295 */     MtlCostList result = new MtlCostList();
/*     */     try {
/* 297 */       result = this.mpmCostListDao.findByCode(costCode);
/*     */     } catch (Exception e) {
/* 299 */       log.debug("", e);
/* 300 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqytstxxsb"));
/*     */     }
/*     */ 
/* 303 */     return result;
/*     */   }
/*     */ 
/*     */   public List findAllCostList() throws Exception
/*     */   {
/* 308 */     return this.mpmCostListDao.findAll();
/*     */   }
/*     */ 
/*     */   public List getAllSubCostList(String costCode) throws Exception {
/* 312 */     List result = new ArrayList();
/* 313 */     if ((costCode != null) && (!"".equals(costCode))) {
/* 314 */       MtlCostList cost = this.mpmCostListDao.findByCode(costCode);
/* 315 */       if (cost != null) {
/* 316 */         int costType = cost.getCostType().intValue();
/*     */         Iterator it;
/* 317 */         if (0 == costType) {
/* 318 */           result = this.mpmCostListDao.findAll();
/* 319 */           for (it = result.iterator(); it.hasNext(); ) {
/* 320 */             cost = (MtlCostList)it.next();
/* 321 */             if (cost.getCostType().intValue() == 0)
/* 322 */               it.remove();
/*     */           }
/*     */         }
/*     */         else {
/* 326 */           result.add(cost);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 331 */     return result;
/*     */   }
/*     */ 
/*     */   public Map findCostListMap()
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 341 */       Iterator it = this.mpmCostListDao.findAll().iterator();
/* 342 */       Map map = new TreeMap();
/* 343 */       while (it.hasNext()) {
/* 344 */         MtlCostList mcl = (MtlCostList)it.next();
/* 345 */         map.put(mcl.getCostCode(), mcl.getCostName());
/*     */       }
/* 347 */       return map;
/*     */     } catch (Exception e) {
/* 349 */       log.error("", e);
/* 350 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.hqcblxsb"));
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MpmResListSvcImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMpmSysActflowDefDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMpmSysFlowstepDefDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlSysActStepDefDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlSysFlowstepDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlSysFlowstepDefId;
/*     */ import com.ai.bdx.frame.approval.service.IMpmSysActflowDefSvc;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ 
/*     */ public class MpmSysActflowDefSvcImpl
/*     */   implements IMpmSysActflowDefSvc
/*     */ {
/*  24 */   private static Logger log = LogManager.getLogger();
/*     */   IMpmSysActflowDefDao sysActFlowDefDao;
/*     */   IMpmSysFlowstepDefDao sysFlowstepDefDao;
/*     */   IMtlSysActStepDefDao sysActStepDefDao;
/*     */   IMpmForPageDao mpmForPageDao;
/*     */ 
/*     */   public void setSysActFlowDefDao(IMpmSysActflowDefDao sysActFlowDefDao)
/*     */   {
/*  35 */     this.sysActFlowDefDao = sysActFlowDefDao;
/*     */   }
/*     */ 
/*     */   public IMpmSysActflowDefDao getSysActFlowDefDao() {
/*  39 */     return this.sysActFlowDefDao;
/*     */   }
/*     */ 
/*     */   public void setSysFlowstepDefDao(IMpmSysFlowstepDefDao sysFlowstepDefDao) {
/*  43 */     this.sysFlowstepDefDao = sysFlowstepDefDao;
/*     */   }
/*     */ 
/*     */   public IMpmSysFlowstepDefDao getSysFlowstepDefDao() {
/*  47 */     return this.sysFlowstepDefDao;
/*     */   }
/*     */ 
/*     */   public void setSysActStepDefDao(IMtlSysActStepDefDao sysActStepDefDao) {
/*  51 */     this.sysActStepDefDao = sysActStepDefDao;
/*     */   }
/*     */ 
/*     */   public IMtlSysActStepDefDao getSysActStepDefDao() {
/*  55 */     return this.sysActStepDefDao;
/*     */   }
/*     */ 
/*     */   public void setMpmForPageDao(IMpmForPageDao mpmForPageDao) {
/*  59 */     this.mpmForPageDao = mpmForPageDao;
/*     */   }
/*     */ 
/*     */   public IMpmForPageDao getMpmForPageDao() {
/*  63 */     return this.mpmForPageDao;
/*     */   }
/*     */ 
/*     */   public Map findAllActflow(MtlSysActflowDef svc, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  72 */       return this.mpmForPageDao.findActStepflowAll(svc, curPage, pageSize);
/*     */     } catch (Exception e) {
/*  74 */       log.error("", e);
/*  75 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsyhdlcxxs"));
/*     */   }
/*     */ 
/*     */   public MtlSysActflowDef findActflowById(String flowId)
/*     */     throws MpmException
/*     */   {
/*  84 */     MtlSysActflowDef mtlSysActflowDef = new MtlSysActflowDef();
/*     */     try {
/*  86 */       mtlSysActflowDef = this.sysActFlowDefDao.findById(flowId);
/*     */     } catch (Exception e) {
/*  88 */       log.error("", e);
/*  89 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qythdlcxxs"));
/*     */     }
/*  91 */     return mtlSysActflowDef;
/*     */   }
/*     */ 
/*     */   public String saveActflow(MtlSysActflowDef mtlSysActflowDef, String[] stepId)
/*     */     throws MpmException
/*     */   {
/* 100 */     String flowId = new String("");
/*     */     try {
/* 102 */       if (StringUtil.isEmpty(mtlSysActflowDef.getFlowId())) {
/* 103 */         flowId = this.sysActFlowDefDao.save(mtlSysActflowDef);
/*     */       } else {
/* 105 */         if ((stepId != null) && (stepId.length > 0)) {
/* 106 */           deleteStepById(mtlSysActflowDef.getFlowId());
/*     */         }
/* 108 */         this.sysActFlowDefDao.update(mtlSysActflowDef);
/* 109 */         flowId = mtlSysActflowDef.getFlowId();
/*     */       }
/*     */ 
/* 112 */       MtlSysFlowstepDef svc = null;
/* 113 */       if ((stepId != null) && (stepId.length > 0))
/* 114 */         for (int j = 0; j < stepId.length; j++) {
/* 115 */           svc = new MtlSysFlowstepDef();
/* 116 */           svc.getId().setFlowId(flowId);
/* 117 */           svc.getId().setStepId(stepId[j]);
/* 118 */           saveFlowStep(svc);
/*     */         }
/*     */     }
/*     */     catch (Exception e) {
/* 122 */       log.error("", e);
/* 123 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.crhdlcxxsb"));
/*     */     }
/* 125 */     return flowId;
/*     */   }
/*     */ 
/*     */   public boolean updateActflow(MtlSysActflowDef mtlSysActflowDef)
/*     */     throws MpmException
/*     */   {
/* 134 */     boolean flag = false;
/*     */     try {
/* 136 */       this.sysActFlowDefDao.update(mtlSysActflowDef);
/* 137 */       flag = true;
/*     */     } catch (Exception e) {
/* 139 */       log.error("", e);
/* 140 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.crhdlcxxsb"));
/*     */     }
/* 142 */     return flag;
/*     */   }
/*     */ 
/*     */   public List getActflowStepById(String flowId)
/*     */     throws MpmException
/*     */   {
/* 149 */     List list = new ArrayList();
/*     */     try {
/* 151 */       list = this.sysActStepDefDao.getSysActStepDefByFlowId(flowId, null);
/*     */     } catch (Exception e) {
/* 153 */       log.error("", e);
/* 154 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcbzxxs"));
/*     */     }
/* 156 */     return list;
/*     */   }
/*     */ 
/*     */   public boolean deleteSysActflow(String flowId)
/*     */     throws MpmException
/*     */   {
/* 166 */     boolean flag = false;
/*     */     try
/*     */     {
/* 169 */       this.sysFlowstepDefDao.deleteById(flowId);
/*     */ 
/* 171 */       this.sysActFlowDefDao.deleteById(flowId);
/* 172 */       flag = true;
/*     */     } catch (Exception e) {
/* 174 */       log.error("", e);
/* 175 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.schdlcxxsb"));
/*     */     }
/* 177 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean deleteStepById(String flowId) throws MpmException {
/* 181 */     boolean flag = false;
/*     */     try {
/* 183 */       this.sysFlowstepDefDao.deleteById(flowId);
/*     */     } catch (Exception e) {
/* 185 */       log.error("", e);
/* 186 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.schdlcdbz"));
/*     */     }
/* 188 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean saveFlowStep(MtlSysFlowstepDef mtlSysFlowstepDef)
/*     */     throws MpmException
/*     */   {
/* 195 */     boolean flag = true;
/*     */     try {
/* 197 */       this.sysFlowstepDefDao.saveOrUpdate(mtlSysFlowstepDef);
/* 198 */       flag = true;
/*     */     } catch (Exception e) {
/* 200 */       log.error("", e);
/* 201 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.crhdlcbzsb"));
/*     */     }
/* 203 */     return flag;
/*     */   }
/*     */ 
/*     */   public String getSysActStepArray()
/*     */     throws MpmException
/*     */   {
/* 210 */     String str = "";
/*     */     try {
/* 212 */       str = this.sysActStepDefDao.getSysActStepArray();
/*     */     } catch (Exception e) {
/* 214 */       log.error("", e);
/* 215 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcbzszs"));
/*     */     }
/* 217 */     return str;
/*     */   }
/*     */ 
/*     */   public List getSysActStepList()
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 225 */       return this.sysActStepDefDao.getSysActStepAll();
/*     */     } catch (Exception e) {
/* 227 */       log.error("", e);
/* 228 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddbzlbsb"));
/*     */   }
/*     */ 
/*     */   public String getExistsStepArray(String flowId)
/*     */     throws MpmException
/*     */   {
/* 236 */     String str = new String("");
/*     */     try {
/* 238 */       str = this.sysActStepDefDao.getExistsStepArray(flowId);
/*     */     } catch (Exception e) {
/* 240 */       log.error("", e);
/* 241 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qmghdlcyjy"));
/*     */     }
/* 243 */     return str;
/*     */   }
/*     */ 
/*     */   public List getAllSysActFlowDefList() throws MpmException {
/* 247 */     List list = new ArrayList();
/*     */     try {
/* 249 */       Iterator it = this.sysActFlowDefDao.getAllSysActFlow().iterator();
/*     */ 
/* 251 */       while (it.hasNext()) {
/* 252 */         MtlSysActflowDef obj = (MtlSysActflowDef)it.next();
/* 253 */         list.add(new LabelValueBean(obj.getFlowName(), obj.getFlowId().toString()));
/*     */       }
/*     */     } catch (Exception e) {
/* 256 */       log.error("", e);
/* 257 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcxxsb"));
/*     */     }
/* 259 */     return list;
/*     */   }
/*     */ 
/*     */   public List getCampSysActFlowDefList() throws MpmException {
/* 263 */     List list = new ArrayList();
/*     */     try {
/* 265 */       Iterator it = this.sysActFlowDefDao.getCampSysActFlow().iterator();
/*     */ 
/* 267 */       while (it.hasNext()) {
/* 268 */         MtlSysActflowDef obj = (MtlSysActflowDef)it.next();
/* 269 */         list.add(new LabelValueBean(obj.getFlowName(), obj.getFlowId().toString()));
/*     */       }
/*     */     } catch (Exception e) {
/* 272 */       log.error("", e);
/* 273 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcxxsb"));
/*     */     }
/* 275 */     return list;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public List getSysActFlowDefListByLevel(int approveLevel)
/*     */     throws MpmException
/*     */   {
/* 284 */     List list = new ArrayList();
/*     */ 
/* 297 */     return list;
/*     */   }
/*     */ 
/*     */   public boolean getActFlowDefByApproveflowid(String approveFlowId)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 308 */       return this.sysActFlowDefDao.getActFlowByApproveflowid(approveFlowId);
/*     */     } catch (Exception e) {
/* 310 */       log.error("", e);
/* 311 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcxxsb"));
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MpmSysActflowDefSvcImpl
 * JD-Core Version:    0.6.2
 */
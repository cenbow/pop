package com.ai.bdx.frame.approval.service.impl;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.approval.dao.IMpmForPageDao;
import com.ai.bdx.frame.approval.dao.IMpmSysActflowDefDao;
import com.ai.bdx.frame.approval.dao.IMpmSysFlowstepDefDao;
import com.ai.bdx.frame.approval.dao.IMtlSysActStepDefDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlSysActflowDef;
import com.ai.bdx.frame.approval.model.MtlSysFlowstepDef;
import com.ai.bdx.frame.approval.service.IMpmSysActflowDefSvc;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
import com.asiainfo.biframe.utils.string.StringUtil;

public class MpmSysActflowDefSvcImpl implements IMpmSysActflowDefSvc {
	private static Logger log = LogManager.getLogger();

	IMpmSysActflowDefDao sysActFlowDefDao;

	IMpmSysFlowstepDefDao sysFlowstepDefDao;

	IMtlSysActStepDefDao sysActStepDefDao;

	IMpmForPageDao mpmForPageDao;

	public void setSysActFlowDefDao(IMpmSysActflowDefDao sysActFlowDefDao) {
		this.sysActFlowDefDao = sysActFlowDefDao;
	}

	public IMpmSysActflowDefDao getSysActFlowDefDao() {
		return sysActFlowDefDao;
	}

	public void setSysFlowstepDefDao(IMpmSysFlowstepDefDao sysFlowstepDefDao) {
		this.sysFlowstepDefDao = sysFlowstepDefDao;
	}

	public IMpmSysFlowstepDefDao getSysFlowstepDefDao() {
		return sysFlowstepDefDao;
	}

	public void setSysActStepDefDao(IMtlSysActStepDefDao sysActStepDefDao) {
		this.sysActStepDefDao = sysActStepDefDao;
	}

	public IMtlSysActStepDefDao getSysActStepDefDao() {
		return sysActStepDefDao;
	}

	public void setMpmForPageDao(IMpmForPageDao mpmForPageDao) {
		this.mpmForPageDao = mpmForPageDao;
	}

	public IMpmForPageDao getMpmForPageDao() {
		return mpmForPageDao;
	}

	/**
	 * 返回所有的活动流程信息
	 * @return List
	 */
	public Map findAllActflow(MtlSysActflowDef svc, Integer curPage, Integer pageSize) throws MpmException {
		try {
			return mpmForPageDao.findActStepflowAll(svc, curPage, pageSize);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsyhdlcxxs"));
		}
	}

	/**
	 * 根据flowId返回一条活动流程信息
	 * @return List
	 */
	public MtlSysActflowDef findActflowById(String flowId) throws MpmException {
		MtlSysActflowDef mtlSysActflowDef = new MtlSysActflowDef();
		try {
			mtlSysActflowDef = sysActFlowDefDao.findById(flowId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qythdlcxxs"));
		}
		return mtlSysActflowDef;
	}

	/**
	 * 插入一条活动流程信息
	 * @param mtlSysActflowDef
	 * @return
	 */
	public String saveActflow(MtlSysActflowDef mtlSysActflowDef, String[] stepId) throws MpmException {
		String flowId = new String("");
		try {
			if (StringUtil.isEmpty(mtlSysActflowDef.getFlowId())) {
				flowId = sysActFlowDefDao.save(mtlSysActflowDef);
			} else {
				if (stepId != null && stepId.length > 0) {
					deleteStepById(mtlSysActflowDef.getFlowId());
				}
				sysActFlowDefDao.update(mtlSysActflowDef);
				flowId = mtlSysActflowDef.getFlowId();
			}

			MtlSysFlowstepDef svc = null;
			if (stepId != null && stepId.length > 0) {
				for (int j = 0; j < stepId.length; j++) {
					svc = new MtlSysFlowstepDef();
					svc.getId().setFlowId(flowId);
					svc.getId().setStepId(stepId[j]);
					saveFlowStep(svc);
				}
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.crhdlcxxsb"));
		}
		return flowId;
	}

	/**
	 * 修改一条活动流程信息
	 * @param mtlSysActflowDef
	 * @return
	 */
	public boolean updateActflow(MtlSysActflowDef mtlSysActflowDef) throws MpmException {
		boolean flag = false;
		try {
			sysActFlowDefDao.update(mtlSysActflowDef);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.crhdlcxxsb"));
		}
		return flag;
	}

	/**
	 * 通过FLOW_ID得到该活动流程的步骤
	 */
	public List getActflowStepById(String flowId) throws MpmException {
		List list = new ArrayList();
		try {
			list = sysActStepDefDao.getSysActStepDefByFlowId(flowId, null);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcbzxxs"));
		}
		return list;
	}

	/**
	 * 删除活动流程记录
	 * @param flowId
	 * @return
	 * @throws MpmException
	 */
	public boolean deleteSysActflow(String flowId) throws MpmException {
		boolean flag = false;
		try {
			//首先删除步骤信息
			sysFlowstepDefDao.deleteById(flowId);
			//删除活动流程信息
			sysActFlowDefDao.deleteById(flowId);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.schdlcxxsb"));
		}
		return flag;
	}

	public boolean deleteStepById(String flowId) throws MpmException {
		boolean flag = false;
		try {
			sysFlowstepDefDao.deleteById(flowId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.schdlcdbz"));
		}
		return flag;
	}

	/**
	 * 为活动流程插入一个步骤
	 */
	public boolean saveFlowStep(MtlSysFlowstepDef mtlSysFlowstepDef) throws MpmException {
		boolean flag = true;
		try {
			sysFlowstepDefDao.saveOrUpdate(mtlSysFlowstepDef);
			flag = true;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.crhdlcbzsb"));
		}
		return flag;
	}

	/**
	 * 取活动流程的步骤集合
	 */
	public String getSysActStepArray() throws MpmException {
		String str = "";
		try {
			str = sysActStepDefDao.getSysActStepArray();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcbzszs"));
		}
		return str;
	}

	/**
	 * 得到所有步骤信息的list
	 */
	public List getSysActStepList() throws MpmException {
		try {
			return sysActStepDefDao.getSysActStepAll();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddbzlbsb"));
		}
	}

	/**
	 * 取活动流程已经存在的步骤
	 */
	public String getExistsStepArray(String flowId) throws MpmException {
		String str = new String("");
		try {
			str = sysActStepDefDao.getExistsStepArray(flowId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qmghdlcyjy"));
		}
		return str;
	}

	public List getAllSysActFlowDefList() throws MpmException {
		List list = new ArrayList();
		try {
			Iterator it = sysActFlowDefDao.getAllSysActFlow().iterator();
			MtlSysActflowDef obj;
			while (it.hasNext()) {
				obj = (MtlSysActflowDef) it.next();
				list.add(new LabelValueBean(obj.getFlowName(), obj.getFlowId().toString()));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcxxsb"));
		}
		return list;
	}

	public List getCampSysActFlowDefList() throws MpmException {
		List list = new ArrayList();
		try {
			Iterator it = sysActFlowDefDao.getCampSysActFlow().iterator();
			MtlSysActflowDef obj;
			while (it.hasNext()) {
				obj = (MtlSysActflowDef) it.next();
				list.add(new LabelValueBean(obj.getFlowName(), obj.getFlowId().toString()));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcxxsb"));
		}
		return list;
	}

	/**
	 * @deprecated 不再使用
	 *
	 */
	@Deprecated
	public List getSysActFlowDefListByLevel(int approveLevel) throws MpmException {
		List list = new ArrayList();
		try {
			//			Iterator it = this.sysActFlowDefDao.getSysActFlowDefMapByLevel(approveLevel).iterator();
			//			MtlSysActflowDef obj;
			//			while(it.hasNext()) {
			//				obj = (MtlSysActflowDef)it.next();
			//				list.add(new LabelValueBean(obj.getFlowName(),obj.getFlowId().toString()));
			//			}
			//			throw new MpmException("取活动流程信息失败！");
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcxxsb"));
		}
		return list;
	}

	/**
	 *
	 * @param approveFlowId
	 * @return
	 * @throws MpmException
	 */
	public boolean getActFlowDefByApproveflowid(String approveFlowId) throws MpmException {
		try {
			return sysActFlowDefDao.getActFlowByApproveflowid(approveFlowId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qhdlcxxsb"));
		}
	}

}

package com.ai.bdx.frame.approval.service.impl;


import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao;
import com.ai.bdx.frame.approval.dao.IMpmApproveRelationDao;
import com.ai.bdx.frame.approval.dao.IMtlApproveAuthDao;
import com.ai.bdx.frame.approval.dao.IMtlApproveConfirmListDao;
import com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao;
import com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveAuth;
import com.ai.bdx.frame.approval.model.MtlApproveAuthId;
import com.ai.bdx.frame.approval.model.MtlApproveConfirmList;
import com.ai.bdx.frame.approval.model.MtlCampsegApproverList;
import com.ai.bdx.frame.approval.service.IMtlApproveAuthService;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

/**
 * Created on May 30, 2007 11:32:08 AM
 *
 * <p>Title: 审批和确认委派action类</p>
 * <p>Description: 审批和确认委派</p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author zhoulb
 * @version 1.0
 */
public class MtlApproveAuthServiceImpl implements IMtlApproveAuthService {
	private static Logger log = LogManager.getLogger();

	private IMtlApproveAuthDao mtlApproveAuthDao;

	private IMtlCampsegApproverListDao mtlCampsegApproverListDao;

	private IMpmApproveRelationDao mpmApproveRelationDao;

	private IMtlApproveLevelDefDao mtlApproveLevelDefDao;

	private IMtlApproveConfirmListDao mtlApproveConfirmListDao;

	private IDimChannelUserRelationDao dimChannelUserRelationDao;

	/*
	 * （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveAuthService#getAuthInfo(com.ai.bdx.frame.approval.model.MtlApproveAuthId)
	 */
	public MtlApproveAuth getAuthInfo(MtlApproveAuthId id) throws MpmException {
		try {
			return mtlApproveAuthDao.getById(id);
		} catch (Exception me) {
			log.error("", me);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddwpxxsb"));
		}
	}

	/*
	 * （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveAuthService#getAuthRelation(java.lang.String)
	 */
	public List getAuthRelation(String authUserid) throws MpmException {
		try {
			return mtlApproveAuthDao.getAuthRelation(authUserid);
		} catch (Exception me) {
			log.error("", me);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddwpksqxxs"));
		}
	}

	/*
	 * （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveAuthService#saveConfirmAuth(com.ai.bdx.frame.approval.model.MtlApproveAuth)
	 */
	public boolean saveConfirmAuth(MtlApproveAuth auth) throws MpmException {
		boolean flag = false;
		try {
			//首先清除回收
			MtlApproveAuth auth1 = mtlApproveAuthDao.getById(auth.getId());
			if (auth1 != null && auth1.getConsignorUserid() != null && auth1.getConsignorUserid().length() > 0) {
				deleteConfirmAuth(auth1);
			}

			//部门审批关系
			mpmApproveRelationDao.updateApproveUserid(auth.getConsignorUserid(), auth.getId().getAuthUserid(), 1);
			//审批流程
			mtlApproveLevelDefDao.updateApproveLevelDef(auth.getId().getAuthUserid(), auth.getConsignorUserid(), 1);
			//当前审批列表
			//获取活动当前是否有人持有令牌，如果没有持有，说明该活动已经审批通过
			MtlApproveConfirmList model = new MtlApproveConfirmList();
			model.setApproveToken(Short.valueOf(MpmCONST.MPM_APPROVE_TOKEN_HOLD));
			List list = mtlApproveConfirmListDao.findCampsegApprover(model);
			for (int i = 0; list != null && list.size() > 0 && i < list.size(); i++) {
				model = (MtlApproveConfirmList) list.get(i);
				if (model.getId().getConfirmUserid() != null && model.getId().getConfirmUserid().equals(auth.getId().getAuthUserid())) {
					model.getId().setConfirmUserid(auth.getConsignorUserid());
					model.setAuthFlag(Short.valueOf(String.valueOf(1)));
					mtlApproveConfirmListDao.updateApprover(model);
				} else {
					mtlApproveConfirmListDao.updateByLevel(auth.getId().getAuthUserid(), auth.getConsignorUserid(), model.getId().getCampsegId(), model.getId().getApproveSeq(), 1);
				}
			}
			//审批委派信息表
			auth.setAuthFlag(Short.valueOf("1"));
			Calendar cld = Calendar.getInstance();
			auth.setUpdateTime(cld.getTime());
			//this.mtlApproveAuthDao.delete(auth);
			mtlApproveAuthDao.save(auth);
			flag = true;
		} catch (Exception me) {
			log.error("", me);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.wpqrqsb"));
		}
		return flag;
	}

	/*
	 * （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveAuthService#saveAuth(com.ai.bdx.frame.approval.model.MtlApproveAuth)
	 */
	public boolean saveAuth(MtlApproveAuth auth) throws MpmException {
		boolean flag = false;
		try {
			//首先清除回收
			MtlApproveAuth auth1 = mtlApproveAuthDao.getById(auth.getId());
			if (auth1 != null && auth1.getConsignorUserid() != null && auth1.getConsignorUserid().length() > 0) {
				deleteAuth(auth1);
			}
			//部门审批关系
			mpmApproveRelationDao.updateApproveUserid(auth.getConsignorUserid(), auth.getId().getAuthUserid(), 1);
			//审批流程
			mtlApproveLevelDefDao.updateApproveLevelDef(auth.getId().getAuthUserid(), auth.getConsignorUserid(), 1);
			//当前审批列表
			//获取活动当前是否有人持有令牌，如果没有持有，说明该活动已经审批通过
			MtlCampsegApproverList model = new MtlCampsegApproverList();
			model.setApproveToken(Short.valueOf(MpmCONST.MPM_APPROVE_TOKEN_HOLD));
			List list = mtlCampsegApproverListDao.findCampsegApprover(model);
			for (int i = 0; list != null && list.size() > 0 && i < list.size(); i++) {
				model = (MtlCampsegApproverList) list.get(i);
				if (model.getApproveUserid() != null && model.getApproveUserid().equals(auth.getId().getAuthUserid())) {
					model.setApproveUserid(auth.getConsignorUserid());
					model.setAuthFlag(Short.valueOf(String.valueOf(1)));
					mtlCampsegApproverListDao.updateApprover(model);
					//发短信通知当前正处于审批状态的邮件？？？
				} else {
					mtlCampsegApproverListDao.updateByLevel(auth.getId().getAuthUserid(), auth.getConsignorUserid(), model.getId().getCampsegId(), model.getId().getApproveSeq(), 1);
				}
			}
			//
			//审批委派信息表
			auth.setAuthFlag(Short.valueOf("1"));
			Calendar cld = Calendar.getInstance();
			auth.setUpdateTime(cld.getTime());
			//this.mtlApproveAuthDao.delete(auth);
			mtlApproveAuthDao.save(auth);
			flag = true;
		} catch (Exception me) {
			log.error("", me);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.wpspqsb"));
		}
		return flag;
	}

	/*
	 * （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveAuthService#deleteConfirmAuth(com.ai.bdx.frame.approval.model.MtlApproveAuth)
	 */
	public boolean deleteConfirmAuth(MtlApproveAuth auth) throws MpmException {
		boolean flag = false;
		try {
			//部门审批关系
			mpmApproveRelationDao.updateApproveUserid(auth.getId().getAuthUserid(), auth.getConsignorUserid(), 0);
			//审批流程
			mtlApproveLevelDefDao.updateApproveLevelDef(auth.getConsignorUserid(), auth.getId().getAuthUserid(), 0);
			//当前审批列表
			//获取活动确认当前是否有人持有令牌，如果没有持有，说明该活动已经确认通过
			MtlApproveConfirmList model = new MtlApproveConfirmList();
			model.setApproveToken(Short.valueOf(MpmCONST.MPM_APPROVE_TOKEN_HOLD));
			List list = mtlApproveConfirmListDao.findCampsegApprover(model);
			for (int i = 0; list != null && list.size() > 0 && i < list.size(); i++) {
				model = (MtlApproveConfirmList) list.get(i);
				if (model.getId().getConfirmUserid() != null && model.getId().getConfirmUserid().equals(auth.getConsignorUserid())) {
					model.getId().setConfirmUserid(auth.getId().getAuthUserid());
					model.setAuthFlag(Short.valueOf(String.valueOf(0)));
					mtlApproveConfirmListDao.updateApprover(model);
				} else {
					mtlApproveConfirmListDao.updateByLevel(auth.getConsignorUserid(), auth.getId().getAuthUserid(), model.getId().getCampsegId(), model.getId().getApproveSeq(), 0);
				}
			}
			//审批委派信息表
			auth.setAuthFlag(Short.valueOf("1"));
			Calendar cld = Calendar.getInstance();
			auth.setUpdateTime(cld.getTime());
			mtlApproveAuthDao.delete(auth);
			flag = true;
		} catch (Exception me) {
			log.error("", me);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.spqhssb"));
		}
		return flag;
	}

	/*
	 * （非 Javadoc）
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveAuthService#deleteAuth(com.ai.bdx.frame.approval.model.MtlApproveAuth)
	 */
	public boolean deleteAuth(MtlApproveAuth auth) throws MpmException {
		boolean flag = false;
		try {
			//部门审批关系
			mpmApproveRelationDao.updateApproveUserid(auth.getId().getAuthUserid(), auth.getConsignorUserid(), 0);
			//审批流程
			mtlApproveLevelDefDao.updateApproveLevelDef(auth.getConsignorUserid(), auth.getId().getAuthUserid(), 0);
			//当前审批列表
			//获取活动当前是否有人持有令牌，如果没有持有，说明该活动已经审批通过
			MtlCampsegApproverList model = new MtlCampsegApproverList();
			model.setApproveToken(Short.valueOf(MpmCONST.MPM_APPROVE_TOKEN_HOLD));
			List list = mtlCampsegApproverListDao.findCampsegApprover(model);
			for (int i = 0; list != null && list.size() > 0 && i < list.size(); i++) {
				model = (MtlCampsegApproverList) list.get(i);
				if (model.getApproveUserid() != null && model.getApproveUserid().equals(auth.getConsignorUserid())) {
					model.setApproveUserid(auth.getId().getAuthUserid());
					model.setAuthFlag(Short.valueOf(String.valueOf(0)));
					mtlCampsegApproverListDao.updateApprover(model);
				} else {
					mtlCampsegApproverListDao.updateByLevel(auth.getConsignorUserid(), auth.getId().getAuthUserid(), model.getId().getCampsegId(), model.getId().getApproveSeq(), 0);
				}
			}
			//审批委派信息表
			auth.setAuthFlag(Short.valueOf("1"));
			Calendar cld = Calendar.getInstance();
			auth.setUpdateTime(cld.getTime());
			mtlApproveAuthDao.delete(auth);
			flag = true;
		} catch (Exception me) {
			log.error("", me);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.spqhssb"));
		}
		return flag;
	}

	public void setMtlApproveAuthDao(IMtlApproveAuthDao mtlApproveAuthDao) {
		this.mtlApproveAuthDao = mtlApproveAuthDao;
	}

	public IMtlApproveAuthDao getMtlApproveAuthDao() {
		return mtlApproveAuthDao;
	}

	public void setMtlCampsegApproverListDao(IMtlCampsegApproverListDao mtlCampsegApproverListDao) {
		this.mtlCampsegApproverListDao = mtlCampsegApproverListDao;
	}

	public IMtlCampsegApproverListDao getMtlCampsegApproverListDao() {
		return mtlCampsegApproverListDao;
	}

	public void setMpmApproveRelationDao(IMpmApproveRelationDao mpmApproveRelationDao) {
		this.mpmApproveRelationDao = mpmApproveRelationDao;
	}

	public IMpmApproveRelationDao getMpmApproveRelationDao() {
		return mpmApproveRelationDao;
	}

	public void setMtlApproveLevelDefDao(IMtlApproveLevelDefDao mtlApproveLevelDefDao) {
		this.mtlApproveLevelDefDao = mtlApproveLevelDefDao;
	}

	public IMtlApproveLevelDefDao getMtlApproveLevelDefDao() {
		return mtlApproveLevelDefDao;
	}

	public IMtlApproveConfirmListDao getMtlApproveConfirmListDao() {
		return mtlApproveConfirmListDao;
	}

	public void setMtlApproveConfirmListDao(IMtlApproveConfirmListDao mtlApproveConfirmListDao) {
		this.mtlApproveConfirmListDao = mtlApproveConfirmListDao;
	}

	public IDimChannelUserRelationDao getDimChannelUserRelationDao() {
		return dimChannelUserRelationDao;
	}

	public void setDimChannelUserRelationDao(IDimChannelUserRelationDao dimChannelUserRelationDao) {
		this.dimChannelUserRelationDao = dimChannelUserRelationDao;
	}
}

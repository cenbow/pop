/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMpmApproveRelationDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveAuthDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveConfirmListDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveAuth;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveAuthId;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveConfirmList;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveConfirmListId;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampsegApproverList;
/*     */ import com.ai.bdx.frame.approval.model.MtlCampsegApproverListId;
/*     */ import com.ai.bdx.frame.approval.service.IMtlApproveAuthService;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import java.util.Calendar;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class MtlApproveAuthServiceImpl
/*     */   implements IMtlApproveAuthService
/*     */ {
/*  36 */   private static Logger log = LogManager.getLogger();
/*     */   private IMtlApproveAuthDao mtlApproveAuthDao;
/*     */   private IMtlCampsegApproverListDao mtlCampsegApproverListDao;
/*     */   private IMpmApproveRelationDao mpmApproveRelationDao;
/*     */   private IMtlApproveLevelDefDao mtlApproveLevelDefDao;
/*     */   private IMtlApproveConfirmListDao mtlApproveConfirmListDao;
/*     */   private IDimChannelUserRelationDao dimChannelUserRelationDao;
/*     */ 
/*     */   public MtlApproveAuth getAuthInfo(MtlApproveAuthId id)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  56 */       return this.mtlApproveAuthDao.getById(id);
/*     */     } catch (Exception me) {
/*  58 */       log.error("", me);
/*  59 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddwpxxsb"));
/*     */   }
/*     */ 
/*     */   public List getAuthRelation(String authUserid)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  69 */       return this.mtlApproveAuthDao.getAuthRelation(authUserid);
/*     */     } catch (Exception me) {
/*  71 */       log.error("", me);
/*  72 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.ddwpksqxxs"));
/*     */   }
/*     */ 
/*     */   public boolean saveConfirmAuth(MtlApproveAuth auth)
/*     */     throws MpmException
/*     */   {
/*  81 */     boolean flag = false;
/*     */     try
/*     */     {
/*  84 */       MtlApproveAuth auth1 = this.mtlApproveAuthDao.getById(auth.getId());
/*  85 */       if ((auth1 != null) && (auth1.getConsignorUserid() != null) && (auth1.getConsignorUserid().length() > 0)) {
/*  86 */         deleteConfirmAuth(auth1);
/*     */       }
/*     */ 
/*  90 */       this.mpmApproveRelationDao.updateApproveUserid(auth.getConsignorUserid(), auth.getId().getAuthUserid(), 1);
/*     */ 
/*  92 */       this.mtlApproveLevelDefDao.updateApproveLevelDef(auth.getId().getAuthUserid(), auth.getConsignorUserid(), 1);
/*     */ 
/*  95 */       MtlApproveConfirmList model = new MtlApproveConfirmList();
/*  96 */       model.setApproveToken(Short.valueOf((short)1));
/*  97 */       List list = this.mtlApproveConfirmListDao.findCampsegApprover(model);
/*  98 */       for (int i = 0; (list != null) && (list.size() > 0) && (i < list.size()); i++) {
/*  99 */         model = (MtlApproveConfirmList)list.get(i);
/* 100 */         if ((model.getId().getConfirmUserid() != null) && (model.getId().getConfirmUserid().equals(auth.getId().getAuthUserid()))) {
/* 101 */           model.getId().setConfirmUserid(auth.getConsignorUserid());
/* 102 */           model.setAuthFlag(Short.valueOf(String.valueOf(1)));
/* 103 */           this.mtlApproveConfirmListDao.updateApprover(model);
/*     */         } else {
/* 105 */           this.mtlApproveConfirmListDao.updateByLevel(auth.getId().getAuthUserid(), auth.getConsignorUserid(), model.getId().getCampsegId(), model.getId().getApproveSeq(), 1);
/*     */         }
/*     */       }
/*     */ 
/* 109 */       auth.setAuthFlag(Short.valueOf("1"));
/* 110 */       Calendar cld = Calendar.getInstance();
/* 111 */       auth.setUpdateTime(cld.getTime());
/*     */ 
/* 113 */       this.mtlApproveAuthDao.save(auth);
/* 114 */       flag = true;
/*     */     } catch (Exception me) {
/* 116 */       log.error("", me);
/* 117 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.wpqrqsb"));
/*     */     }
/* 119 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean saveAuth(MtlApproveAuth auth)
/*     */     throws MpmException
/*     */   {
/* 127 */     boolean flag = false;
/*     */     try
/*     */     {
/* 130 */       MtlApproveAuth auth1 = this.mtlApproveAuthDao.getById(auth.getId());
/* 131 */       if ((auth1 != null) && (auth1.getConsignorUserid() != null) && (auth1.getConsignorUserid().length() > 0)) {
/* 132 */         deleteAuth(auth1);
/*     */       }
/*     */ 
/* 135 */       this.mpmApproveRelationDao.updateApproveUserid(auth.getConsignorUserid(), auth.getId().getAuthUserid(), 1);
/*     */ 
/* 137 */       this.mtlApproveLevelDefDao.updateApproveLevelDef(auth.getId().getAuthUserid(), auth.getConsignorUserid(), 1);
/*     */ 
/* 140 */       MtlCampsegApproverList model = new MtlCampsegApproverList();
/* 141 */       model.setApproveToken(Short.valueOf((short)1));
/* 142 */       List list = this.mtlCampsegApproverListDao.findCampsegApprover(model);
/* 143 */       for (int i = 0; (list != null) && (list.size() > 0) && (i < list.size()); i++) {
/* 144 */         model = (MtlCampsegApproverList)list.get(i);
/* 145 */         if ((model.getApproveUserid() != null) && (model.getApproveUserid().equals(auth.getId().getAuthUserid()))) {
/* 146 */           model.setApproveUserid(auth.getConsignorUserid());
/* 147 */           model.setAuthFlag(Short.valueOf(String.valueOf(1)));
/* 148 */           this.mtlCampsegApproverListDao.updateApprover(model);
/*     */         }
/*     */         else {
/* 151 */           this.mtlCampsegApproverListDao.updateByLevel(auth.getId().getAuthUserid(), auth.getConsignorUserid(), model.getId().getCampsegId(), model.getId().getApproveSeq(), 1);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 156 */       auth.setAuthFlag(Short.valueOf("1"));
/* 157 */       Calendar cld = Calendar.getInstance();
/* 158 */       auth.setUpdateTime(cld.getTime());
/*     */ 
/* 160 */       this.mtlApproveAuthDao.save(auth);
/* 161 */       flag = true;
/*     */     } catch (Exception me) {
/* 163 */       log.error("", me);
/* 164 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.wpspqsb"));
/*     */     }
/* 166 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean deleteConfirmAuth(MtlApproveAuth auth)
/*     */     throws MpmException
/*     */   {
/* 174 */     boolean flag = false;
/*     */     try
/*     */     {
/* 177 */       this.mpmApproveRelationDao.updateApproveUserid(auth.getId().getAuthUserid(), auth.getConsignorUserid(), 0);
/*     */ 
/* 179 */       this.mtlApproveLevelDefDao.updateApproveLevelDef(auth.getConsignorUserid(), auth.getId().getAuthUserid(), 0);
/*     */ 
/* 182 */       MtlApproveConfirmList model = new MtlApproveConfirmList();
/* 183 */       model.setApproveToken(Short.valueOf((short)1));
/* 184 */       List list = this.mtlApproveConfirmListDao.findCampsegApprover(model);
/* 185 */       for (int i = 0; (list != null) && (list.size() > 0) && (i < list.size()); i++) {
/* 186 */         model = (MtlApproveConfirmList)list.get(i);
/* 187 */         if ((model.getId().getConfirmUserid() != null) && (model.getId().getConfirmUserid().equals(auth.getConsignorUserid()))) {
/* 188 */           model.getId().setConfirmUserid(auth.getId().getAuthUserid());
/* 189 */           model.setAuthFlag(Short.valueOf(String.valueOf(0)));
/* 190 */           this.mtlApproveConfirmListDao.updateApprover(model);
/*     */         } else {
/* 192 */           this.mtlApproveConfirmListDao.updateByLevel(auth.getConsignorUserid(), auth.getId().getAuthUserid(), model.getId().getCampsegId(), model.getId().getApproveSeq(), 0);
/*     */         }
/*     */       }
/*     */ 
/* 196 */       auth.setAuthFlag(Short.valueOf("1"));
/* 197 */       Calendar cld = Calendar.getInstance();
/* 198 */       auth.setUpdateTime(cld.getTime());
/* 199 */       this.mtlApproveAuthDao.delete(auth);
/* 200 */       flag = true;
/*     */     } catch (Exception me) {
/* 202 */       log.error("", me);
/* 203 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.spqhssb"));
/*     */     }
/* 205 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean deleteAuth(MtlApproveAuth auth)
/*     */     throws MpmException
/*     */   {
/* 213 */     boolean flag = false;
/*     */     try
/*     */     {
/* 216 */       this.mpmApproveRelationDao.updateApproveUserid(auth.getId().getAuthUserid(), auth.getConsignorUserid(), 0);
/*     */ 
/* 218 */       this.mtlApproveLevelDefDao.updateApproveLevelDef(auth.getConsignorUserid(), auth.getId().getAuthUserid(), 0);
/*     */ 
/* 221 */       MtlCampsegApproverList model = new MtlCampsegApproverList();
/* 222 */       model.setApproveToken(Short.valueOf((short)1));
/* 223 */       List list = this.mtlCampsegApproverListDao.findCampsegApprover(model);
/* 224 */       for (int i = 0; (list != null) && (list.size() > 0) && (i < list.size()); i++) {
/* 225 */         model = (MtlCampsegApproverList)list.get(i);
/* 226 */         if ((model.getApproveUserid() != null) && (model.getApproveUserid().equals(auth.getConsignorUserid()))) {
/* 227 */           model.setApproveUserid(auth.getId().getAuthUserid());
/* 228 */           model.setAuthFlag(Short.valueOf(String.valueOf(0)));
/* 229 */           this.mtlCampsegApproverListDao.updateApprover(model);
/*     */         } else {
/* 231 */           this.mtlCampsegApproverListDao.updateByLevel(auth.getConsignorUserid(), auth.getId().getAuthUserid(), model.getId().getCampsegId(), model.getId().getApproveSeq(), 0);
/*     */         }
/*     */       }
/*     */ 
/* 235 */       auth.setAuthFlag(Short.valueOf("1"));
/* 236 */       Calendar cld = Calendar.getInstance();
/* 237 */       auth.setUpdateTime(cld.getTime());
/* 238 */       this.mtlApproveAuthDao.delete(auth);
/* 239 */       flag = true;
/*     */     } catch (Exception me) {
/* 241 */       log.error("", me);
/* 242 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.spqhssb"));
/*     */     }
/* 244 */     return flag;
/*     */   }
/*     */ 
/*     */   public void setMtlApproveAuthDao(IMtlApproveAuthDao mtlApproveAuthDao) {
/* 248 */     this.mtlApproveAuthDao = mtlApproveAuthDao;
/*     */   }
/*     */ 
/*     */   public IMtlApproveAuthDao getMtlApproveAuthDao() {
/* 252 */     return this.mtlApproveAuthDao;
/*     */   }
/*     */ 
/*     */   public void setMtlCampsegApproverListDao(IMtlCampsegApproverListDao mtlCampsegApproverListDao) {
/* 256 */     this.mtlCampsegApproverListDao = mtlCampsegApproverListDao;
/*     */   }
/*     */ 
/*     */   public IMtlCampsegApproverListDao getMtlCampsegApproverListDao() {
/* 260 */     return this.mtlCampsegApproverListDao;
/*     */   }
/*     */ 
/*     */   public void setMpmApproveRelationDao(IMpmApproveRelationDao mpmApproveRelationDao) {
/* 264 */     this.mpmApproveRelationDao = mpmApproveRelationDao;
/*     */   }
/*     */ 
/*     */   public IMpmApproveRelationDao getMpmApproveRelationDao() {
/* 268 */     return this.mpmApproveRelationDao;
/*     */   }
/*     */ 
/*     */   public void setMtlApproveLevelDefDao(IMtlApproveLevelDefDao mtlApproveLevelDefDao) {
/* 272 */     this.mtlApproveLevelDefDao = mtlApproveLevelDefDao;
/*     */   }
/*     */ 
/*     */   public IMtlApproveLevelDefDao getMtlApproveLevelDefDao() {
/* 276 */     return this.mtlApproveLevelDefDao;
/*     */   }
/*     */ 
/*     */   public IMtlApproveConfirmListDao getMtlApproveConfirmListDao() {
/* 280 */     return this.mtlApproveConfirmListDao;
/*     */   }
/*     */ 
/*     */   public void setMtlApproveConfirmListDao(IMtlApproveConfirmListDao mtlApproveConfirmListDao) {
/* 284 */     this.mtlApproveConfirmListDao = mtlApproveConfirmListDao;
/*     */   }
/*     */ 
/*     */   public IDimChannelUserRelationDao getDimChannelUserRelationDao() {
/* 288 */     return this.dimChannelUserRelationDao;
/*     */   }
/*     */ 
/*     */   public void setDimChannelUserRelationDao(IDimChannelUserRelationDao dimChannelUserRelationDao) {
/* 292 */     this.dimChannelUserRelationDao = dimChannelUserRelationDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MtlApproveAuthServiceImpl
 * JD-Core Version:    0.6.2
 */
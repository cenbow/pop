/*     */ package com.ai.bdx.frame.approval.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao;
/*     */ import com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao;
/*     */ import com.ai.bdx.frame.approval.exception.MpmException;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveLevelDefId;
/*     */ import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondIndi;
/*     */ import com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService;
/*     */ import com.ai.bdx.frame.approval.util.MpmConfigure;
/*     */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ 
/*     */ public class MtlApproveFlowDefServiceImpl
/*     */   implements IMtlApproveFlowDefService
/*     */ {
/*  43 */   private static Logger log = LogManager.getLogger("MtlApproveFlowDefServiceImpl.class");
/*     */   private IMtlApproveFlowDefDao mtlApproveFlowDefDao;
/*     */   private IMtlApproveLevelDefDao mtlApproveLevelDefDao;
/*     */   private IMtlApproveTriggerCondDefDao mtlApproveTriggerCondDefDao;
/*     */   private IMtlApproveTriggerCondIndiDao mtlApproveTriggerCondIndiDao;
/*     */   private IMtlCampsegApproverListDao mtlCampsegApproverListDao;
/*     */   private IUserPrivilegeCommonService mpmUserPrivilegeService;
/*     */ 
/*     */   public void deleteApproveFlowDef(String approveFlowId)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/*  62 */       this.mtlApproveTriggerCondDefDao.deleteApproveTriggerCondDefByFlow(approveFlowId);
/*  63 */       this.mtlApproveLevelDefDao.deleteApproveLevelDefByFlow(approveFlowId);
/*  64 */       this.mtlApproveFlowDefDao.deleteApproveFlowDef(approveFlowId);
/*     */     } catch (Exception e) {
/*  66 */       log.error("", e);
/*  67 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scsplcdyxx1"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getAllApproveFlowDefAsLabelValueBean() throws MpmException
/*     */   {
/*  73 */     List list = new ArrayList();
/*     */     try
/*     */     {
/*  76 */       list.add(new LabelValueBean(MpmLocaleUtil.getMessage("mcd.java.tgOAxtsp"), "-1"));
/*     */ 
/*  79 */       Iterator it = getAllApproveFlowDef().iterator();
/*     */ 
/*  81 */       while (it.hasNext()) {
/*  82 */         MtlApproveFlowDef def = (MtlApproveFlowDef)it.next();
/*  83 */         list.add(new LabelValueBean(def.getApproveFlowName(), def.getApproveFlowId()));
/*     */       }
/*     */     } catch (Exception e) {
/*  86 */       log.error("", e);
/*  87 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsysplcdyx"));
/*     */     }
/*  89 */     return list;
/*     */   }
/*     */ 
/*     */   public List getAllApproveFlowDef() throws MpmException {
/*     */     try {
/*  94 */       return this.mtlApproveFlowDefDao.getAllApproveFlowDef();
/*     */     } catch (Exception e) {
/*  96 */       log.error("", e);
/*  97 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsysplcdyx"));
/*     */   }
/*     */ 
/*     */   public List getAllApproveFlowDefAsLabelValueBean(String userid) throws MpmException
/*     */   {
/* 102 */     List list = new ArrayList();
/*     */     try
/*     */     {
/* 105 */       if ("1".equals(MpmConfigure.getInstance().getProperty("IF_CAMP_FLOW_TO_OA"))) {
/* 106 */         list.add(new LabelValueBean(MpmLocaleUtil.getMessage("mcd.java.tgOAxtsp"), "-1"));
/*     */       }
/*     */ 
/* 109 */       Iterator it = getAllApproveFlowDef(userid).iterator();
/*     */ 
/* 111 */       while (it.hasNext()) {
/* 112 */         MtlApproveFlowDef def = (MtlApproveFlowDef)it.next();
/* 113 */         list.add(new LabelValueBean(def.getApproveFlowName(), def.getApproveFlowId()));
/*     */       }
/*     */     } catch (Exception e) {
/* 116 */       log.error("", e);
/* 117 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsysplcdyx"));
/*     */     }
/* 119 */     return list;
/*     */   }
/*     */ 
/*     */   public List getAllApproveFlowDef(String userid) throws MpmException {
/*     */     try {
/* 124 */       return this.mtlApproveFlowDefDao.getAllApproveFlowDef(userid);
/*     */     } catch (Exception e) {
/* 126 */       log.error("", e);
/* 127 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsysplcdyx"));
/*     */   }
/*     */ 
/*     */   public Map findApproveFlow(MtlApproveFlowDef searchCond, Integer curPage, Integer pageSize)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 136 */       return this.mtlApproveFlowDefDao.findApproveFlow(searchCond, curPage, pageSize);
/*     */     } catch (Exception e) {
/* 138 */       log.error("", e);
/* 139 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxsplcdyxx"));
/*     */   }
/*     */ 
/*     */   public MtlApproveFlowDef getApproveFlowDef(String approveFlowId)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 148 */       return this.mtlApproveFlowDefDao.getApproveFlowDef(approveFlowId);
/*     */     } catch (Exception e) {
/* 150 */       log.error("", e);
/* 151 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplcdyxxs"));
/*     */   }
/*     */ 
/*     */   public void saveApproveFlowDef(MtlApproveFlowDef def, String objId)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 161 */       Calendar cal = Calendar.getInstance();
/* 162 */       def.setCreateTime(cal.getTime());
/* 163 */       String approveFlowId = def.getApproveFlowId();
/* 164 */       if (StringUtil.isEmpty(approveFlowId)) {
/* 165 */         approveFlowId = (String)this.mtlApproveFlowDefDao.saveApproveFlowDef(def);
/*     */       } else {
/* 167 */         this.mtlApproveFlowDefDao.updateApproveFlowDef(def);
/*     */ 
/* 169 */         this.mtlApproveLevelDefDao.deleteApproveLevelDefByFlow(approveFlowId);
/*     */       }
/*     */ 
/* 172 */       String approveFlowDefStr = def.getApproveFlowDefStr();
/*     */ 
/* 180 */       if (StringUtil.isNotEmpty(approveFlowDefStr)) {
/* 181 */         String[] approveLevel = approveFlowDefStr.split(";");
/* 182 */         if ((approveLevel != null) && (approveLevel.length > 0)) {
/* 183 */           for (String levelApprover : approveLevel)
/*     */             try {
/* 185 */               String[] levelApprovers = levelApprover.split(",");
/* 186 */               String levelCnt = levelApprovers[0].substring(levelApprovers[0].lastIndexOf("=") + 1, levelApprovers[0].length());
/*     */ 
/* 188 */               String levelApproveObjType = levelApprovers[1].substring(levelApprovers[1].lastIndexOf("=") + 1, levelApprovers[1].length());
/*     */ 
/* 190 */               String levelApproveObjId = levelApprovers[2].substring(levelApprovers[2].lastIndexOf("=") + 1, levelApprovers[2].length());
/*     */ 
/* 192 */               String levelApproveObjName = levelApprovers[3].substring(levelApprovers[3].lastIndexOf("=") + 1, levelApprovers[3].length());
/*     */ 
/* 195 */               MtlApproveLevelDef levelDef = new MtlApproveLevelDef();
/* 196 */               MtlApproveLevelDefId levelId = new MtlApproveLevelDefId();
/* 197 */               levelId.setApproveFlowId(approveFlowId);
/* 198 */               levelId.setApproveLevel(Integer.valueOf(levelCnt));
/* 199 */               levelId.setApproveObjType(Integer.valueOf(levelApproveObjType));
/* 200 */               levelId.setApproveObjId(levelApproveObjId);
/* 201 */               levelDef.setId(levelId);
/* 202 */               if (StringUtil.isEmpty(levelDef.getId().getApproveObjId())) {
/* 203 */                 if ((objId != null) && (!objId.equals("")))
/* 204 */                   levelDef.getId().setApproveObjId(objId);
/*     */                 else {
/* 206 */                   levelDef.getId().setApproveObjId("0");
/*     */                 }
/*     */               }
/*     */ 
/* 210 */               if (Short.parseShort(levelApproveObjType) == 4) {
/* 211 */                 levelDef.getId().setApproveObjId(levelApproveObjName);
/*     */               }
/* 213 */               this.mtlApproveLevelDefDao.saveApproveLevelDef(levelDef);
/*     */             } catch (Exception e) {
/* 215 */               log.error("保存审批级别出错{},异常信息:{}", new Object[] { approveFlowId, e });
/*     */             }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 222 */       log.error("", e);
/* 223 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcsplcdyxx1"));
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getValueFromDefStr(String key, String defStr)
/*     */     throws Exception
/*     */   {
/* 334 */     if ((StringUtil.isEmpty(defStr)) || (defStr.indexOf(key) < 0)) {
/* 335 */       return null;
/*     */     }
/*     */ 
/* 338 */     String res = "";
/* 339 */     if (!key.endsWith("=")) {
/* 340 */       key = key + "=";
/*     */     }
/* 342 */     int pos = defStr.indexOf(key);
/* 343 */     defStr = defStr.substring(pos + key.length());
/* 344 */     pos = defStr.indexOf(",");
/* 345 */     res = defStr.substring(0, pos);
/* 346 */     return res;
/*     */   }
/*     */ 
/*     */   public void updateApproveFlowDef(MtlApproveFlowDef def)
/*     */     throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 354 */       this.mtlApproveFlowDefDao.updateApproveFlowDef(def);
/*     */     } catch (Exception e) {
/* 356 */       log.error("", e);
/* 357 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.gxsplcdyxx"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public MtlApproveFlowDef getApproveFlowDefWithAllChilds(String approveFlowId) throws MpmException {
/*     */     try {
/* 363 */       return this.mtlApproveFlowDefDao.getApproveFlowDefWithAllChilds(approveFlowId);
/*     */     } catch (Exception e) {
/* 365 */       log.error("", e);
/* 366 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplcspjbs"));
/*     */   }
/*     */ 
/*     */   public List getApproveLevelDefByFlow(String flowId) throws MpmException
/*     */   {
/*     */     try {
/* 372 */       return this.mtlApproveLevelDefDao.getApproveLevelDefByFlow(flowId);
/*     */     } catch (Exception e) {
/* 374 */       log.error("", e);
/* 375 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplczdyds"));
/*     */   }
/*     */ 
/*     */   public List getApproveTriggerCondDefByFlow(String flowId) throws MpmException
/*     */   {
/*     */     try {
/* 381 */       return this.mtlApproveTriggerCondDefDao.getApproveTriggerCondDefByFlow(flowId);
/*     */     } catch (Exception e) {
/* 383 */       log.error("", e);
/* 384 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplczdyds1"));
/*     */   }
/*     */ 
/*     */   public List getApproveTriggerCondDefByFlowAndLevel(String flowId, Integer level) throws MpmException
/*     */   {
/*     */     try {
/* 390 */       return this.mtlApproveTriggerCondDefDao.getApproveTriggerCondDefByFlowAndLevel(flowId, level);
/*     */     } catch (Exception e) {
/* 392 */       log.error("", e);
/* 393 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplczmgsp"));
/*     */   }
/*     */ 
/*     */   public String getApproveObjNameByTypeAndIdCache(Integer objType, String objId) throws MpmException
/*     */   {
/* 398 */     String res = objId;
/*     */     try {
/* 400 */       short type = objType.shortValue();
/* 401 */       if (type == 1) {
/* 402 */         res = "";
/* 403 */       } else if (type == 2) {
/* 404 */         IUserCompany dept = this.mpmUserPrivilegeService.getUserCompanyById(objId);
/* 405 */         if (dept != null)
/* 406 */           res = dept.getTitle();
/*     */       }
/* 408 */       else if (type == 3) {
/* 409 */         IUser user = this.mpmUserPrivilegeService.getUser(objId);
/* 410 */         if (user != null)
/* 411 */           res = user.getUsername();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 415 */       log.error("", e);
/* 416 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplczmgsp"));
/*     */     }
/* 418 */     return res == null ? "" : res;
/*     */   }
/*     */ 
/*     */   public List getAllApproveTriggerCondIndi() throws MpmException {
/*     */     try {
/* 423 */       return this.mtlApproveTriggerCondIndiDao.getAllApproveTriggerCondIndi();
/*     */     } catch (Exception e) {
/* 425 */       log.error("", e);
/* 426 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qspcftjzbx"));
/*     */   }
/*     */ 
/*     */   public String getApproveTriggerCondIndiNameCache(String indiId) throws MpmException
/*     */   {
/* 431 */     String res = indiId;
/*     */     try {
/* 433 */       MtlApproveTriggerCondIndi indi = this.mtlApproveTriggerCondIndiDao.getApproveTriggerCondIndi(indiId);
/* 434 */       if (indi != null)
/* 435 */         res = indi.getCondIndiName();
/*     */     }
/*     */     catch (Exception e) {
/* 438 */       log.error("", e);
/* 439 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qspcftjzbx"));
/*     */     }
/* 441 */     return res;
/*     */   }
/*     */ 
/*     */   public boolean isApproveFlowCanDelete(String flowId) throws MpmException {
/*     */     try {
/* 446 */       int cnt = this.mtlCampsegApproverListDao.countCampsegApproverByFlowId(flowId);
/* 447 */       return cnt <= 0;
/*     */     }
/*     */     catch (Exception e) {
/* 450 */       log.error("", e);
/* 451 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qspcftjzbx"));
/*     */   }
/*     */ 
/*     */   public boolean isApproveFlowCanDelete1(String flowId) throws MpmException
/*     */   {
/*     */     try
/*     */     {
/* 458 */       int cnt = this.mtlCampsegApproverListDao.countCampsegApproverByFlowId1(flowId);
/* 459 */       return cnt <= 0;
/*     */     }
/*     */     catch (Exception e) {
/* 462 */       log.error("", e);
/* 463 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qspcftjzbx"));
/*     */   }
/*     */ 
/*     */   public IMtlApproveFlowDefDao getMtlApproveFlowDefDao()
/*     */   {
/* 469 */     return this.mtlApproveFlowDefDao;
/*     */   }
/*     */ 
/*     */   public void setMtlApproveFlowDefDao(IMtlApproveFlowDefDao mtlApproveFlowDefDao) {
/* 473 */     this.mtlApproveFlowDefDao = mtlApproveFlowDefDao;
/*     */   }
/*     */ 
/*     */   public IMtlApproveLevelDefDao getMtlApproveLevelDefDao() {
/* 477 */     return this.mtlApproveLevelDefDao;
/*     */   }
/*     */ 
/*     */   public void setMtlApproveLevelDefDao(IMtlApproveLevelDefDao mtlApproveLevelDefDao) {
/* 481 */     this.mtlApproveLevelDefDao = mtlApproveLevelDefDao;
/*     */   }
/*     */ 
/*     */   public IMtlApproveTriggerCondDefDao getMtlApproveTriggerCondDefDao() {
/* 485 */     return this.mtlApproveTriggerCondDefDao;
/*     */   }
/*     */ 
/*     */   public void setMtlApproveTriggerCondDefDao(IMtlApproveTriggerCondDefDao mtlApproveTriggerCondDefDao) {
/* 489 */     this.mtlApproveTriggerCondDefDao = mtlApproveTriggerCondDefDao;
/*     */   }
/*     */ 
/*     */   public IMtlApproveTriggerCondIndiDao getMtlApproveTriggerCondIndiDao() {
/* 493 */     return this.mtlApproveTriggerCondIndiDao;
/*     */   }
/*     */ 
/*     */   public void setMtlApproveTriggerCondIndiDao(IMtlApproveTriggerCondIndiDao mtlApproveTriggerCondIndiDao) {
/* 497 */     this.mtlApproveTriggerCondIndiDao = mtlApproveTriggerCondIndiDao;
/*     */   }
/*     */ 
/*     */   public IMtlCampsegApproverListDao getMtlCampsegApproverListDao() {
/* 501 */     return this.mtlCampsegApproverListDao;
/*     */   }
/*     */ 
/*     */   public void setMtlCampsegApproverListDao(IMtlCampsegApproverListDao mtlCampsegApproverListDao) {
/* 505 */     this.mtlCampsegApproverListDao = mtlCampsegApproverListDao;
/*     */   }
/*     */ 
/*     */   public IUserPrivilegeCommonService getMpmUserPrivilegeService() {
/* 509 */     return this.mpmUserPrivilegeService;
/*     */   }
/*     */ 
/*     */   public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
/* 513 */     this.mpmUserPrivilegeService = mpmUserPrivilegeService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MtlApproveFlowDefServiceImpl
 * JD-Core Version:    0.6.2
 */
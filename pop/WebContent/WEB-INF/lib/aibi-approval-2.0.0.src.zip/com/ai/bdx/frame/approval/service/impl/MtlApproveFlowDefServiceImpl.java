package com.ai.bdx.frame.approval.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao;
import com.ai.bdx.frame.approval.dao.IMtlApproveLevelDefDao;
import com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondDefDao;
import com.ai.bdx.frame.approval.dao.IMtlApproveTriggerCondIndiDao;
import com.ai.bdx.frame.approval.dao.IMtlCampsegApproverListDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
import com.ai.bdx.frame.approval.model.MtlApproveLevelDef;
import com.ai.bdx.frame.approval.model.MtlApproveLevelDefId;
import com.ai.bdx.frame.approval.model.MtlApproveTriggerCondIndi;
import com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService;
import com.ai.bdx.frame.approval.util.MpmConfigure;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.IUserCompany;
import com.asiainfo.biframe.utils.string.StringUtil;

/**
 * Created on Apr 26, 2007 3:05:41 PM
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MtlApproveFlowDefServiceImpl implements IMtlApproveFlowDefService {
	private static Logger log = LogManager.getLogger("MtlApproveFlowDefServiceImpl.class");

	private IMtlApproveFlowDefDao mtlApproveFlowDefDao;

	private IMtlApproveLevelDefDao mtlApproveLevelDefDao;

	private IMtlApproveTriggerCondDefDao mtlApproveTriggerCondDefDao;

	private IMtlApproveTriggerCondIndiDao mtlApproveTriggerCondIndiDao;

	private IMtlCampsegApproverListDao mtlCampsegApproverListDao;

	private IUserPrivilegeCommonService mpmUserPrivilegeService;

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService#deleteApproveFlowDef(java.lang.String)
	 */
	public void deleteApproveFlowDef(String approveFlowId) throws MpmException {
		try {
			mtlApproveTriggerCondDefDao.deleteApproveTriggerCondDefByFlow(approveFlowId);
			mtlApproveLevelDefDao.deleteApproveLevelDefByFlow(approveFlowId);
			mtlApproveFlowDefDao.deleteApproveFlowDef(approveFlowId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scsplcdyxx1"));
		}

	}

	public List getAllApproveFlowDefAsLabelValueBean() throws MpmException {
		List list = new ArrayList();
		try {
			//list.add(new LabelValueBean("不需要审批",MpmCONST.MPM_APPROVE_FLOW_ID_NO_APPROVE));
			list.add(new LabelValueBean(MpmLocaleUtil.getMessage("mcd.java.tgOAxtsp"),
					MpmCONST.MPM_APPROVE_FLOW_ID_BY_OA));

			Iterator it = this.getAllApproveFlowDef().iterator();
			MtlApproveFlowDef def;
			while (it.hasNext()) {
				def = (MtlApproveFlowDef) it.next();
				list.add(new LabelValueBean(def.getApproveFlowName(), def.getApproveFlowId()));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsysplcdyx"));
		}
		return list;
	}

	public List getAllApproveFlowDef() throws MpmException {
		try {
			return mtlApproveFlowDefDao.getAllApproveFlowDef();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsysplcdyx"));
		}
	}

	public List getAllApproveFlowDefAsLabelValueBean(String userid) throws MpmException {
		List list = new ArrayList();
		try {
			//list.add(new LabelValueBean("不需要审批",MpmCONST.MPM_APPROVE_FLOW_ID_NO_APPROVE));
			if ("1".equals(MpmConfigure.getInstance().getProperty("IF_CAMP_FLOW_TO_OA"))) {
				list.add(new LabelValueBean(MpmLocaleUtil.getMessage("mcd.java.tgOAxtsp"),
						MpmCONST.MPM_APPROVE_FLOW_ID_BY_OA));
			}
			Iterator it = this.getAllApproveFlowDef(userid).iterator();
			MtlApproveFlowDef def;
			while (it.hasNext()) {
				def = (MtlApproveFlowDef) it.next();
				list.add(new LabelValueBean(def.getApproveFlowName(), def.getApproveFlowId()));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsysplcdyx"));
		}
		return list;
	}

	public List getAllApproveFlowDef(String userid) throws MpmException {
		try {
			return mtlApproveFlowDefDao.getAllApproveFlowDef(userid);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsysplcdyx"));
		}
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService#findApproveFlow(com.ai.bdx.frame.approval.model.MtlApproveFlowDef, java.lang.Integer, java.lang.Integer)
	 */
	public Map findApproveFlow(MtlApproveFlowDef searchCond, Integer curPage, Integer pageSize) throws MpmException {
		try {
			return mtlApproveFlowDefDao.findApproveFlow(searchCond, curPage, pageSize);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxsplcdyxx"));
		}
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService#getApproveFlowDef(java.lang.String)
	 */
	public MtlApproveFlowDef getApproveFlowDef(String approveFlowId) throws MpmException {
		try {
			return mtlApproveFlowDefDao.getApproveFlowDef(approveFlowId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplcdyxxs"));
		}
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService#saveApproveFlowDef(com.ai.bdx.frame.approval.model.MtlApproveFlowDef)
	 */
	//这个是新写方法，原来方法在下个注释掉的方法，
	public void saveApproveFlowDef(MtlApproveFlowDef def, String objId) throws MpmException {
		try {
			Calendar cal = Calendar.getInstance();
			def.setCreateTime(cal.getTime());
			String approveFlowId = def.getApproveFlowId();
			if (StringUtil.isEmpty(approveFlowId)) {
				approveFlowId = (String) mtlApproveFlowDefDao.saveApproveFlowDef(def);
			} else {
				mtlApproveFlowDefDao.updateApproveFlowDef(def);
				//mtlApproveTriggerCondDefDao.deleteApproveTriggerCondDefByFlow(approveFlowId);
				mtlApproveLevelDefDao.deleteApproveLevelDefByFlow(approveFlowId);
			}

			String approveFlowDefStr = def.getApproveFlowDefStr();

			String levelCnt;
			String levelApproveObjType;
			String levelApproveObjId;
			String levelApproveObjName;
			MtlApproveLevelDef levelDef;
			MtlApproveLevelDefId levelId;
			if (StringUtil.isNotEmpty(approveFlowDefStr)) {
				String[] approveLevel = approveFlowDefStr.split(";");//每个审批人
				if (approveLevel != null && approveLevel.length > 0) {
					for (String levelApprover : approveLevel) {
						try {
							String[] levelApprovers = levelApprover.split(",");
							levelCnt = levelApprovers[0].substring(levelApprovers[0].lastIndexOf("=") + 1,
									levelApprovers[0].length());
							levelApproveObjType = levelApprovers[1].substring(levelApprovers[1].lastIndexOf("=") + 1,
									levelApprovers[1].length());
							levelApproveObjId = levelApprovers[2].substring(levelApprovers[2].lastIndexOf("=") + 1,
									levelApprovers[2].length());
							levelApproveObjName = levelApprovers[3].substring(levelApprovers[3].lastIndexOf("=") + 1,
									levelApprovers[3].length());

							levelDef = new MtlApproveLevelDef();
							levelId = new MtlApproveLevelDefId();
							levelId.setApproveFlowId(approveFlowId);
							levelId.setApproveLevel(Integer.valueOf(levelCnt));
							levelId.setApproveObjType(Integer.valueOf(levelApproveObjType));
							levelId.setApproveObjId(levelApproveObjId);
							levelDef.setId(levelId);
							if (StringUtil.isEmpty(levelDef.getId().getApproveObjId())) {
								if (objId != null && !objId.equals("")) {
									levelDef.getId().setApproveObjId(objId);
								} else {
									levelDef.getId().setApproveObjId("0");
								}

							}
							if (Short.parseShort(levelApproveObjType) == MpmCONST.MPM_APPROVE_OBJ_TYPE_TOPN_DEPT) {
								levelDef.getId().setApproveObjId(levelApproveObjName);
							}
							mtlApproveLevelDefDao.saveApproveLevelDef(levelDef);
						} catch (Exception e) {
							log.error("保存审批级别出错{},异常信息:{}", approveFlowId, e);
							continue;
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcsplcdyxx1"));
		}
	}

	/*public void saveApproveFlowDef(MtlApproveFlowDef def,String objId) throws MpmException {
		try {
			Calendar cal = Calendar.getInstance();
			def.setCreateTime(cal.getTime());
			String approveFlowId = def.getApproveFlowId();
			if (StringUtil.isEmpty(approveFlowId)) {
				approveFlowId = (String) mtlApproveFlowDefDao.saveApproveFlowDef(def);
			} else {
				mtlApproveFlowDefDao.updateApproveFlowDef(def);
				mtlApproveTriggerCondDefDao.deleteApproveTriggerCondDefByFlow(approveFlowId);
				mtlApproveLevelDefDao.deleteApproveLevelDefByFlow(approveFlowId);
			}

			String approveFlowDefStr = def.getApproveFlowDefStr();
			int levelCnt, levelCondCnt, levelIndex, condIndex;
			String levelApproveObjType, levelApproveObjId, levelApproveObjName, tmpStr;
			String condIndiId, condIndiOperator, condIndiVal, condApproveObjType, condApproveObjId, condApproveObjName;
			MtlApproveLevelDef level;
			MtlApproveLevelDefId levelId;
			MtlApproveTriggerCondDef cond;
			MtlApproveTriggerCondDefId condId;
			levelCnt = def.getApproveFlowLevelCnt().intValue();

			levelIndex = 1;
			for (int i = 0; i < levelCnt; i++) {
				//取审批级别配置数据
				log.debug("approveFlowDefStr:" + approveFlowDefStr);
				levelApproveObjType = getValueFromDefStr("level" + i + "ObjType", approveFlowDefStr);
				if (StringUtil.isEmpty(levelApproveObjType)) {
					continue;
				}
				log.debug("__________levelApproveObjType:" + levelApproveObjType);
				levelApproveObjId = getValueFromDefStr("level" + i + "ObjId", approveFlowDefStr);
				log.debug("__________levelApproveObjId:" + levelApproveObjId);
				levelApproveObjName = getValueFromDefStr("level" + i + "ObjName", approveFlowDefStr);
				log.debug("__________levelApproveObjName:" + levelApproveObjName);
				//保存审批级别信息
				level = new MtlApproveLevelDef();
				levelId = new MtlApproveLevelDefId();
				levelId.setApproveFlowId(approveFlowId);
				levelId.setApproveLevel(Integer.valueOf(levelIndex));
				level.setId(levelId);
				level.setApproveObjType(Integer.valueOf(levelApproveObjType));
				level.setApproveObjId(levelApproveObjId);
				if(StringUtil.isEmpty(level.getApproveObjId())){
					if(objId!=null&&!objId.equals("")){
						level.setApproveObjId(objId);
					}else{
						level.setApproveObjId("0");
					}

				}
				if (Short.parseShort(levelApproveObjType) == MpmCONST.MPM_APPROVE_OBJ_TYPE_TOPN_DEPT) {
					level.setApproveObjId(levelApproveObjName);
				}

				mtlApproveLevelDefDao.saveApproveLevelDef(level);

				tmpStr = getValueFromDefStr("level" + i + "condCnt", approveFlowDefStr);
				levelCondCnt = 0;
				if (tmpStr != null && tmpStr.length() > 0) {
					levelCondCnt = Integer.parseInt(tmpStr);
				}
				condIndex = 1;
				for (int j = 0; j < levelCondCnt; j++) {
					//取审批触发条件配置数据
					condIndiId = getValueFromDefStr("level" + i + "cond" + j + "IndiId", approveFlowDefStr);
					if (StringUtil.isEmpty(condIndiId)) {
						continue;
					}
					condIndiOperator = getValueFromDefStr("level" + i + "cond" + j + "IndiOperator", approveFlowDefStr);
					condIndiVal = getValueFromDefStr("level" + i + "cond" + j + "IndiVal", approveFlowDefStr);
					condApproveObjType = getValueFromDefStr("level" + i + "cond" + j + "ObjType", approveFlowDefStr);
					condApproveObjId = getValueFromDefStr("level" + i + "cond" + j + "ObjId", approveFlowDefStr);
					condApproveObjName = getValueFromDefStr("level" + i + "cond" + j + "ObjName", approveFlowDefStr);

					//保存审批触发条件数据
					cond = new MtlApproveTriggerCondDef();
					condId = new MtlApproveTriggerCondDefId();
					condId.setApproveFlowId(approveFlowId);
					condId.setApproveLevel(Integer.valueOf(levelIndex));
					condId.setCondIndiId(condIndiId);
					condId.setApproveTriggerCondId(Integer.valueOf(condIndex));
					cond.setId(condId);
					cond.setApproveObjType(Integer.valueOf(condApproveObjType));
					cond.setApproveObjId(condApproveObjId);
					cond.setCondIndiValue(condIndiVal);
					cond.setCondOperator(condIndiOperator);
					cond.setApproveTriggerCondPri(Integer.valueOf(condIndex));
					if (Short.parseShort(condApproveObjType) == MpmCONST.MPM_APPROVE_OBJ_TYPE_TOPN_DEPT) {
						cond.setApproveObjId(condApproveObjName);
					}
					mtlApproveTriggerCondDefDao.saveApproveTriggerCondDef(cond);

					condIndex++;
				}

				levelIndex++;
			}

		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcsplcdyxx1"));
		}
	}*/

	private String getValueFromDefStr(String key, String defStr) throws Exception {
		if (StringUtil.isEmpty(defStr) || defStr.indexOf(key) < 0) {
			return null;
		}

		String res = "";
		if (!key.endsWith("=")) {
			key += "=";
		}
		int pos = defStr.indexOf(key);
		defStr = defStr.substring(pos + key.length());
		pos = defStr.indexOf(",");
		res = defStr.substring(0, pos);
		return res;
	}

	/* (non-Javadoc)
	 * @see com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService#updateApproveFlowDef(com.ai.bdx.frame.approval.model.MtlApproveFlowDef)
	 */
	public void updateApproveFlowDef(MtlApproveFlowDef def) throws MpmException {
		try {
			mtlApproveFlowDefDao.updateApproveFlowDef(def);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.gxsplcdyxx"));
		}
	}

	public MtlApproveFlowDef getApproveFlowDefWithAllChilds(String approveFlowId) throws MpmException {
		try {
			return mtlApproveFlowDefDao.getApproveFlowDefWithAllChilds(approveFlowId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplcspjbs"));
		}
	}

	public List getApproveLevelDefByFlow(String flowId) throws MpmException {
		try {
			return mtlApproveLevelDefDao.getApproveLevelDefByFlow(flowId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplczdyds"));
		}
	}

	public List getApproveTriggerCondDefByFlow(String flowId) throws MpmException {
		try {
			return mtlApproveTriggerCondDefDao.getApproveTriggerCondDefByFlow(flowId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplczdyds1"));
		}
	}

	public List getApproveTriggerCondDefByFlowAndLevel(String flowId, Integer level) throws MpmException {
		try {
			return mtlApproveTriggerCondDefDao.getApproveTriggerCondDefByFlowAndLevel(flowId, level);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplczmgsp"));
		}
	}

	public String getApproveObjNameByTypeAndIdCache(Integer objType, String objId) throws MpmException {
		String res = objId;
		try {
			short type = objType.shortValue();
			if (type == MpmCONST.MPM_APPROVE_OBJ_TYPE_SELF_DEPT) {
				res = "";
			} else if (type == MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_DEPT) {
				IUserCompany dept = mpmUserPrivilegeService.getUserCompanyById(objId);
				if (dept != null) {
					res = dept.getTitle();//.getName();
				}
			} else if (type == MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER) {
				IUser user = mpmUserPrivilegeService.getUser(objId);
				if (user != null) {
					res = user.getUsername();
				}
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qsplczmgsp"));
		}
		return (res == null) ? "" : res;
	}

	public List getAllApproveTriggerCondIndi() throws MpmException {
		try {
			return mtlApproveTriggerCondIndiDao.getAllApproveTriggerCondIndi();
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qspcftjzbx"));
		}
	}

	public String getApproveTriggerCondIndiNameCache(String indiId) throws MpmException {
		String res = indiId;
		try {
			MtlApproveTriggerCondIndi indi = mtlApproveTriggerCondIndiDao.getApproveTriggerCondIndi(indiId);
			if (indi != null) {
				res = indi.getCondIndiName();
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qspcftjzbx"));
		}
		return res;
	}

	public boolean isApproveFlowCanDelete(String flowId) throws MpmException {
		try {
			int cnt = mtlCampsegApproverListDao.countCampsegApproverByFlowId(flowId);
			boolean res = (cnt > 0) ? false : true;
			return res;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qspcftjzbx"));
		}

	}

	public boolean isApproveFlowCanDelete1(String flowId) throws MpmException {
		try {
			int cnt = mtlCampsegApproverListDao.countCampsegApproverByFlowId1(flowId);
			boolean res = (cnt > 0) ? false : true;
			return res;
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qspcftjzbx"));
		}

	}

	public IMtlApproveFlowDefDao getMtlApproveFlowDefDao() {
		return mtlApproveFlowDefDao;
	}

	public void setMtlApproveFlowDefDao(IMtlApproveFlowDefDao mtlApproveFlowDefDao) {
		this.mtlApproveFlowDefDao = mtlApproveFlowDefDao;
	}

	public IMtlApproveLevelDefDao getMtlApproveLevelDefDao() {
		return mtlApproveLevelDefDao;
	}

	public void setMtlApproveLevelDefDao(IMtlApproveLevelDefDao mtlApproveLevelDefDao) {
		this.mtlApproveLevelDefDao = mtlApproveLevelDefDao;
	}

	public IMtlApproveTriggerCondDefDao getMtlApproveTriggerCondDefDao() {
		return mtlApproveTriggerCondDefDao;
	}

	public void setMtlApproveTriggerCondDefDao(IMtlApproveTriggerCondDefDao mtlApproveTriggerCondDefDao) {
		this.mtlApproveTriggerCondDefDao = mtlApproveTriggerCondDefDao;
	}

	public IMtlApproveTriggerCondIndiDao getMtlApproveTriggerCondIndiDao() {
		return mtlApproveTriggerCondIndiDao;
	}

	public void setMtlApproveTriggerCondIndiDao(IMtlApproveTriggerCondIndiDao mtlApproveTriggerCondIndiDao) {
		this.mtlApproveTriggerCondIndiDao = mtlApproveTriggerCondIndiDao;
	}

	public IMtlCampsegApproverListDao getMtlCampsegApproverListDao() {
		return mtlCampsegApproverListDao;
	}

	public void setMtlCampsegApproverListDao(IMtlCampsegApproverListDao mtlCampsegApproverListDao) {
		this.mtlCampsegApproverListDao = mtlCampsegApproverListDao;
	}

	public IUserPrivilegeCommonService getMpmUserPrivilegeService() {
		return mpmUserPrivilegeService;
	}

	public void setMpmUserPrivilegeService(IUserPrivilegeCommonService mpmUserPrivilegeService) {
		this.mpmUserPrivilegeService = mpmUserPrivilegeService;
	}

}

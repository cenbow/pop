/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao;
/*    */ import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
/*    */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class MtlApproveFlowIdNameMapper extends IdNameMapperImpl
/*    */ {
/* 12 */   private static Logger log = LogManager.getLogger();
/*    */   private IMtlApproveFlowDefDao dao;
/*    */ 
/*    */   public List getAll()
/*    */   {
/* 29 */     return null;
/*    */   }
/*    */ 
/*    */   public String getNameById(Object id)
/*    */   {
/* 38 */     if (id == null) {
/* 39 */       return "";
/*    */     }
/* 41 */     Object value = super.getSimpleCacheMapValue(MtlApproveFlowIdNameMapper.class, id);
/*    */ 
/* 43 */     if (value != null) {
/* 44 */       return value.toString();
/*    */     }
/*    */ 
/* 47 */     String name = id.toString();
/*    */     try
/*    */     {
/* 50 */       if (name.equals("-1")) {
/* 51 */         name = MpmLocaleUtil.getMessage("mcd.java.tgOAxtsp");
/* 52 */       } else if (name.equals("0")) {
/* 53 */         name = MpmLocaleUtil.getMessage("mcd.java.bxysp");
/*    */       } else {
/* 55 */         MtlApproveFlowDef def = this.dao.getApproveFlowDef(id.toString());
/* 56 */         if (def != null) {
/* 57 */           name = def.getApproveFlowName();
/*    */         }
/*    */       }
/* 60 */       super.putSimpleCacheMap(MtlApproveFlowIdNameMapper.class, id, name);
/*    */     } catch (Exception e) {
/* 62 */       log.error("", e);
/*    */     }
/* 64 */     return name;
/*    */   }
/*    */ 
/*    */   public List getNameListByCondition(List ids)
/*    */   {
/* 75 */     return null;
/*    */   }
/*    */ 
/*    */   public IMtlApproveFlowDefDao getDao() {
/* 79 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(IMtlApproveFlowDefDao dao) {
/* 83 */     this.dao = dao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MtlApproveFlowIdNameMapper
 * JD-Core Version:    0.6.2
 */
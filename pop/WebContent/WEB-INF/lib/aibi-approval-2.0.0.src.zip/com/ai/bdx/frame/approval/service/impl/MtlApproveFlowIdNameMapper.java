package com.ai.bdx.frame.approval.service.impl;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.dao.IMtlApproveFlowDefDao;
import com.ai.bdx.frame.approval.model.MtlApproveFlowDef;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

public class MtlApproveFlowIdNameMapper extends IdNameMapperImpl {
	private static Logger log = LogManager.getLogger();
	private IMtlApproveFlowDefDao dao;

	/**
	 *
	 */
	public MtlApproveFlowIdNameMapper() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.asiainfo.service.IdNameMapper#getAll()
	 */
	public List getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.asiainfo.service.IdNameMapper#getNameById(java.lang.Object)
	 */
	public String getNameById(Object id) {
		if (id == null) {
			return "";
		}
		Object value = super.getSimpleCacheMapValue(
				MtlApproveFlowIdNameMapper.class, id);
		if (value != null) {
			return value.toString();
		}

		String name = id.toString();

		try {
			if (name.equals(MpmCONST.MPM_APPROVE_FLOW_ID_BY_OA)) {
				name = MpmLocaleUtil.getMessage("mcd.java.tgOAxtsp");
			} else if (name.equals(MpmCONST.MPM_APPROVE_FLOW_ID_NO_APPROVE)) {
				name = MpmLocaleUtil.getMessage("mcd.java.bxysp");
			} else {
				MtlApproveFlowDef def = dao.getApproveFlowDef(id.toString());
				if (def != null) {
					name = def.getApproveFlowName();
				}
			}
			super.putSimpleCacheMap(MtlApproveFlowIdNameMapper.class, id, name);
		} catch (Exception e) {
			log.error("", e);
		}
		return name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.asiainfo.service.IdNameMapper#getNameListByCondition(java.util.List)
	 */
	public List getNameListByCondition(List ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public IMtlApproveFlowDefDao getDao() {
		return dao;
	}

	public void setDao(IMtlApproveFlowDefDao dao) {
		this.dao = dao;
	}

}

package com.ai.bdx.frame.approval.service.impl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.dao.IMtlApproveResourceTypeDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.form.MtlApproveResourceTypeForm;
import com.ai.bdx.frame.approval.model.MtlApproveResourceType;
import com.ai.bdx.frame.approval.service.IMtlApproveResourceTypeService;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

/**
 *
 * Created on 2008-3-7
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author qixf
 * @version 1.0
 */
public class MtlApproveResourceTypeServiceImpl implements IMtlApproveResourceTypeService {
	private static Logger log = LogManager.getLogger();

	private IMtlApproveResourceTypeDao mtlApproveResourceTypeDao;

	public MtlApproveResourceTypeServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void save(MtlApproveResourceType mtlApproveResourceType) throws MpmException {
		// TODO 自动生成方法存根
		try {
			mtlApproveResourceTypeDao.save(mtlApproveResourceType);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcqrzylxbs"));
		}
	}

	public void update(MtlApproveResourceType mtlApproveResourceType) throws MpmException {
		// TODO 自动生成方法存根
		try {
			mtlApproveResourceTypeDao.update(mtlApproveResourceType);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.gxqrzylxbs"));
		}
	}

	public Map searchMtlApproveResourceType(MtlApproveResourceTypeForm searchForm, Integer curPage, Integer pageSize) throws MpmException {
		// TODO 自动生成方法存根
		try {
			return mtlApproveResourceTypeDao.searchMtlApproveResourceType(searchForm, curPage, pageSize);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqrzylxbx"));
		}
	}

	public MtlApproveResourceType getMtlApproveResourceType(String resourceId) throws MpmException {
		// TODO 自动生成方法存根
		try {
			return mtlApproveResourceTypeDao.getRourceById(Integer.valueOf(resourceId));
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qzyqdqrrdy"));
		}
	}

	public void delete(MtlApproveResourceTypeForm searchForm) throws MpmException {
		// TODO 自动生成方法存根
		try {
			mtlApproveResourceTypeDao.delete(searchForm);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scqrzylxbx"));
		}
	}

	public IMtlApproveResourceTypeDao getMtlApproveResourceTypeDao() {
		return mtlApproveResourceTypeDao;
	}

	public void setMtlApproveResourceTypeDao(IMtlApproveResourceTypeDao mtlApproveResourceTypeDao) {
		this.mtlApproveResourceTypeDao = mtlApproveResourceTypeDao;
	}

}

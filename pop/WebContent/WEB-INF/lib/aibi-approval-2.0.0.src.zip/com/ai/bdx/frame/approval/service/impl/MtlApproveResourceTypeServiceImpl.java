/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IMtlApproveResourceTypeDao;
/*    */ import com.ai.bdx.frame.approval.exception.MpmException;
/*    */ import com.ai.bdx.frame.approval.form.MtlApproveResourceTypeForm;
/*    */ import com.ai.bdx.frame.approval.model.MtlApproveResourceType;
/*    */ import com.ai.bdx.frame.approval.service.IMtlApproveResourceTypeService;
/*    */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*    */ import java.util.Map;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class MtlApproveResourceTypeServiceImpl
/*    */   implements IMtlApproveResourceTypeService
/*    */ {
/* 27 */   private static Logger log = LogManager.getLogger();
/*    */   private IMtlApproveResourceTypeDao mtlApproveResourceTypeDao;
/*    */ 
/*    */   public void save(MtlApproveResourceType mtlApproveResourceType)
/*    */     throws MpmException
/*    */   {
/*    */     try
/*    */     {
/* 39 */       this.mtlApproveResourceTypeDao.save(mtlApproveResourceType);
/*    */     } catch (Exception e) {
/* 41 */       log.error("", e);
/* 42 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bcqrzylxbs"));
/*    */     }
/*    */   }
/*    */ 
/*    */   public void update(MtlApproveResourceType mtlApproveResourceType) throws MpmException
/*    */   {
/*    */     try {
/* 49 */       this.mtlApproveResourceTypeDao.update(mtlApproveResourceType);
/*    */     } catch (Exception e) {
/* 51 */       log.error("", e);
/* 52 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.gxqrzylxbs"));
/*    */     }
/*    */   }
/*    */ 
/*    */   public Map searchMtlApproveResourceType(MtlApproveResourceTypeForm searchForm, Integer curPage, Integer pageSize) throws MpmException
/*    */   {
/*    */     try {
/* 59 */       return this.mtlApproveResourceTypeDao.searchMtlApproveResourceType(searchForm, curPage, pageSize);
/*    */     } catch (Exception e) {
/* 61 */       log.error("", e);
/* 62 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqrzylxbx"));
/*    */   }
/*    */ 
/*    */   public MtlApproveResourceType getMtlApproveResourceType(String resourceId) throws MpmException
/*    */   {
/*    */     try
/*    */     {
/* 69 */       return this.mtlApproveResourceTypeDao.getRourceById(Integer.valueOf(resourceId));
/*    */     } catch (Exception e) {
/* 71 */       log.error("", e);
/* 72 */     }throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.qzyqdqrrdy"));
/*    */   }
/*    */ 
/*    */   public void delete(MtlApproveResourceTypeForm searchForm) throws MpmException
/*    */   {
/*    */     try
/*    */     {
/* 79 */       this.mtlApproveResourceTypeDao.delete(searchForm);
/*    */     } catch (Exception e) {
/* 81 */       log.error("", e);
/* 82 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.scqrzylxbx"));
/*    */     }
/*    */   }
/*    */ 
/*    */   public IMtlApproveResourceTypeDao getMtlApproveResourceTypeDao() {
/* 87 */     return this.mtlApproveResourceTypeDao;
/*    */   }
/*    */ 
/*    */   public void setMtlApproveResourceTypeDao(IMtlApproveResourceTypeDao mtlApproveResourceTypeDao) {
/* 91 */     this.mtlApproveResourceTypeDao = mtlApproveResourceTypeDao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MtlApproveResourceTypeServiceImpl
 * JD-Core Version:    0.6.2
 */
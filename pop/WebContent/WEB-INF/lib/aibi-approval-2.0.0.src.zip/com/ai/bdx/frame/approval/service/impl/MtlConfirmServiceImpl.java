/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.IMtlApproveResourceTypeDao;
/*    */ import com.ai.bdx.frame.approval.exception.MpmException;
/*    */ import com.ai.bdx.frame.approval.model.MtlApproveResourceType;
/*    */ import com.ai.bdx.frame.approval.service.IMtlConfirmService;
/*    */ import com.ai.bdx.frame.approval.util.MpmLocaleUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class MtlConfirmServiceImpl
/*    */   implements IMtlConfirmService
/*    */ {
/* 19 */   private static Logger log = LogManager.getLogger("MtlConfirmServiceImpl.class");
/*    */   private IMtlApproveResourceTypeDao approveResourceDao;
/*    */ 
/*    */   public IMtlApproveResourceTypeDao getApproveResourceDao()
/*    */   {
/* 23 */     return this.approveResourceDao;
/*    */   }
/*    */ 
/*    */   public void setApproveResourceDao(IMtlApproveResourceTypeDao approveResourceDao) {
/* 27 */     this.approveResourceDao = approveResourceDao;
/*    */   }
/*    */ 
/*    */   public List findAllRourceType() throws MpmException {
/* 31 */     List result = new ArrayList();
/* 32 */     MtlApproveResourceType mrt = null;
/*    */     try {
/* 34 */       Iterator it = this.approveResourceDao.findAll().iterator();
/* 35 */       while ((it != null) && (it.hasNext())) {
/* 36 */         mrt = (MtlApproveResourceType)it.next();
/* 37 */         result.add(new LabelValueBean(mrt.getResourceName(), mrt.getResourceId().toString()));
/*    */       }
/*    */     } catch (Exception e) {
/* 40 */       log.error("", e);
/* 41 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqrzysb"));
/*    */     }
/* 43 */     return result;
/*    */   }
/*    */ 
/*    */   public int getMaxResourceId() throws MpmException {
/* 47 */     List list = new ArrayList();
/* 48 */     MtlApproveResourceType mart = null;
/* 49 */     int maxId = 1;
/*    */     try {
/* 51 */       list = this.approveResourceDao.findAll();
/* 52 */       if ((list != null) && (list.size() > 0)) {
/* 53 */         mart = (MtlApproveResourceType)list.get(0);
/* 54 */         maxId = mart.getResourceId().intValue();
/*    */       }
/*    */     } catch (Exception e) {
/* 57 */       log.error("", e);
/* 58 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqrzysb"));
/*    */     }
/* 60 */     return maxId;
/*    */   }
/*    */ 
/*    */   public List findRourceTypeByFlag(short resourceFlag) throws MpmException {
/* 64 */     List result = new ArrayList();
/* 65 */     MtlApproveResourceType mrt = null;
/*    */     try {
/* 67 */       Iterator it = this.approveResourceDao.findByFlag(resourceFlag).iterator();
/* 68 */       while ((it != null) && (it.hasNext())) {
/* 69 */         mrt = (MtlApproveResourceType)it.next();
/* 70 */         result.add(new LabelValueBean(mrt.getResourceName(), mrt.getResourceId().toString()));
/*    */       }
/*    */     } catch (Exception e) {
/* 73 */       log.error("", e);
/* 74 */       throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqrzysb"));
/*    */     }
/* 76 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.MtlConfirmServiceImpl
 * JD-Core Version:    0.6.2
 */
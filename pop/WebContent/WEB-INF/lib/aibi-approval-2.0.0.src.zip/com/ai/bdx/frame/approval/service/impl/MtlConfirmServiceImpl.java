package com.ai.bdx.frame.approval.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.ai.bdx.frame.approval.dao.IMtlApproveResourceTypeDao;
import com.ai.bdx.frame.approval.exception.MpmException;
import com.ai.bdx.frame.approval.model.MtlApproveResourceType;
import com.ai.bdx.frame.approval.service.IMtlConfirmService;
import com.ai.bdx.frame.approval.util.MpmLocaleUtil;

public class MtlConfirmServiceImpl implements IMtlConfirmService {

	private static Logger log = LogManager.getLogger("MtlConfirmServiceImpl.class");
	private IMtlApproveResourceTypeDao approveResourceDao;

	public IMtlApproveResourceTypeDao getApproveResourceDao() {
		return approveResourceDao;
	}

	public void setApproveResourceDao(IMtlApproveResourceTypeDao approveResourceDao) {
		this.approveResourceDao = approveResourceDao;
	}

	public List findAllRourceType() throws MpmException {
		List result = new ArrayList();
		MtlApproveResourceType mrt = null;
		try {
			Iterator it = approveResourceDao.findAll().iterator();
			while (it != null && it.hasNext()) {
				mrt = (MtlApproveResourceType) it.next();
				result.add(new LabelValueBean(mrt.getResourceName(), mrt.getResourceId().toString()));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqrzysb"));
		}
		return result;
	}

	public int getMaxResourceId() throws MpmException {
		List list = new ArrayList();
		MtlApproveResourceType mart = null;
		int maxId = 1;
		try {
			list = approveResourceDao.findAll();
			if (list != null && list.size() > 0) {
				mart = (MtlApproveResourceType) list.get(0);
				maxId = mart.getResourceId().intValue();
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqrzysb"));
		}
		return maxId;
	}

	public List findRourceTypeByFlag(short resourceFlag) throws MpmException {
		List result = new ArrayList();
		MtlApproveResourceType mrt = null;
		try {
			Iterator it = approveResourceDao.findByFlag(resourceFlag).iterator();
			while (it != null && it.hasNext()) {
				mrt = (MtlApproveResourceType) it.next();
				result.add(new LabelValueBean(mrt.getResourceName(), mrt.getResourceId().toString()));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.cxqrzysb"));
		}
		return result;
	}
	/*
	




	
	private IMtlApproveConfirmListDao approveConfirmListDao;
	private IMtlCampsegProgressDao progressDao;
	private IMtlApproveFlowDefDao approveFlowDefDao;
	private IDimChannelUserRelationDao channelUserDao;
	private IMtlApproveLevelDefDao mtlApproveLevelDefDao;
	private IMpmApproveRelationDao relationDao;
	private IMpmUserPrivilegeService mpmUserPrivilegeService;
	private ISmsMessageService smsMessageService;

	private IMtlApproveContentSendDao sendDao;
	private IMtlCampChanneltypeDao channeltypeDao;
	private IMtlConfirmExtendInfoDao confirmExtendInfoDao;
	// 活动渠道Dao
	private IMtlChannelDefDao mtlChannelDefDao;

	public IMpmCampSegInfoDao getCampSegInfoDao() {
		return campSegInfoDao;
	}

	public void setCampSegInfoDao(IMpmCampSegInfoDao campSegInfoDao) {
		this.campSegInfoDao = campSegInfoDao;
	}

	public IMtlCampExecTimeDao getMtlCampExecTimeDao() {
		return mtlCampExecTimeDao;
	}

	public void setMtlCampExecTimeDao(IMtlCampExecTimeDao mtlCampExecTimeDao) {
		this.mtlCampExecTimeDao = mtlCampExecTimeDao;
	}

	public IMtlCampsegCiCustDao getMtlCampsegCiCustDao() {
		return mtlCampsegCiCustDao;
	}

	public void setMtlCampsegCiCustDao(IMtlCampsegCiCustDao mtlCampsegCiCustDao) {
		this.mtlCampsegCiCustDao = mtlCampsegCiCustDao;
	}

	public IMtlChannelDefDao getMtlChannelDefDao() {
		return mtlChannelDefDao;
	}

	public void setMtlChannelDefDao(IMtlChannelDefDao mtlChannelDefDao) {
		this.mtlChannelDefDao = mtlChannelDefDao;
	}

	public ILocMtlRequrestTempleteDao getMtlRequrestTempleteDao() {
		return mtlRequrestTempleteDao;
	}

	public void setMtlRequrestTempleteDao(
			ILocMtlRequrestTempleteDao mtlRequrestTempleteDao) {
		this.mtlRequrestTempleteDao = mtlRequrestTempleteDao;
	}

	public ILocMtlRequestPhoneListDAO getLocMtlRequestPhoneListDAO() {
		return locMtlRequestPhoneListDAO;
	}

	public void setLocMtlRequestPhoneListDAO(
			ILocMtlRequestPhoneListDAO locMtlRequestPhoneListDAO) {
		this.locMtlRequestPhoneListDAO = locMtlRequestPhoneListDAO;
	}

	public ISmsMessageService getSmsMessageService() {
		return smsMessageService;
	}

	public void setSmsMessageService(ISmsMessageService smsMessageService) {
		this.smsMessageService = smsMessageService;
	}

	public ILocMtlRequestContentDao getLocMtlRequestContentDao() {
		return locMtlRequestContentDao;
	}

	public void setLocMtlRequestContentDao(
			ILocMtlRequestContentDao locMtlRequestContentDao) {
		this.locMtlRequestContentDao = locMtlRequestContentDao;
	}

	public MtlConfirmExtendInfo getConfirmExtendInfo(MtlConfirmExtendInfoId id)
			throws MpmException {
		try {
			return confirmExtendInfoDao.getConfirmExtendInfo(id);
		} catch (Exception e) {
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.qqrewxxsb"));
		}
	}

	public List getMtlConfirmExtendInfo(String campsegId, Integer resourceId,
			String confirmUserid, Short usersegId, Short approveSeq)
			throws MpmException {
		try {
			return confirmExtendInfoDao.getMtlConfirmExtendInfo(campsegId,
					resourceId, confirmUserid, approveSeq, usersegId);
		} catch (Exception e) {
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.qqrewxxsb"));
		}
	}

	
	
	

	public MtlApproveResourceType findRourceTypeById(Integer resourceId)
			throws MpmException {
		try {
			return approveResourceDao.getRourceById(resourceId);
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.cxqrzysb"));
		}
	}

	// public void saveCampsegConfirmListOld(String campsegId,String
	// resourceIdArr,String confirmUseridArr,String forecastDateArr,String
	// remindDateArr,String confirmExplainArr) throws MpmException {
	// try{
	// //log.debug("1=["+resourceIdArr+"]2=["+confirmUseridArr+"]3=["+forecastDateArr+"]4=["+remindDateArr+"]");
	// //先删除已有信息
	// //approveConfirmListDao.deleteByCampsegid(campsegId);
	// //保存资源确认信息
	// String [] resourceId = resourceIdArr.split(",");
	// String [] confirmUserid = confirmUseridArr.split(",");
	// String [] forecastDate = forecastDateArr.split(",");
	// String [] remindDate = remindDateArr.split(",");
	// String [] confirmExplain = confirmExplainArr.split(",");
	// // log.debug("**************************");
	// // log.debug("**************************");
	// // log.debug("resourceId: length:"+resourceId);
	// // for(int i=0;i<resourceId.length;i++){
	// // log.debug("resId "+i+" :"+resourceId[i]);
	// // }
	// // log.debug("**************************");
	// // log.debug("**************************");
	// MtlApproveConfirmList macl;
	// MtlApproveConfirmListId macli;
	// for(int i=0 ;resourceId != null && confirmUserid != null && i<
	// resourceId.length && i <confirmUserid.length; i++ ){
	// if(resourceId[i] != null && resourceId[i].length() >0 && confirmUserid[i]
	// != null && confirmUserid[i].length() >0){
	// macl = new MtlApproveConfirmList();
	// macli = new MtlApproveConfirmListId();
	// macli.setCampsegId(campsegId);
	// macli.setResourceId(Integer.valueOf(resourceId[i]));
	// macli.setConfirmUserid(confirmUserid[i]);
	// macl.setId(macli);
	// macl.setConfirmFlag(Short.valueOf("0"));
	// if(forecastDate != null && forecastDate.length > i){
	// if(forecastDate[i] != null && forecastDate[i].length() >0)
	// macl.setForecastDate(forecastDate[i]);
	// else
	// macl.setForecastDate("");
	// }else
	// macl.setForecastDate("");
	//
	// if(remindDate != null && remindDate.length > i){
	// if(remindDate[i] != null && remindDate[i].length() >0)
	// macl.setRemindDate(remindDate[i]);
	// else
	// macl.setRemindDate("");
	// }else
	// macl.setRemindDate("");
	//
	// if(confirmExplain != null && confirmExplain.length > i){
	// if(confirmExplain[i] != null && confirmExplain[i].length() >0)
	// macl.setConfirmExplain(confirmExplain[i]);
	// else
	// macl.setConfirmExplain("");
	// }else
	// macl.setConfirmExplain("");
	// try{
	// approveConfirmListDao.save(macl);
	// log.error("",e);}
	// }
	// }
	// }catch (Exception e) {
	// log.error("",e);
	// throw new MpmException("保存确认资源人列表信息失败");
	// }
	// }
	// caihao 08-07-09 add 根据确认流程, 将每一个审批人保存到列表中
	public void saveCampsegConfirmList(String campsegId, String resourceIdArr,
			String confirmUseridArr, String forecastDateArr,
			String remindDateArr, String confirmExplainArr,
			String needApproveUserid) throws MpmException {
		try {
			String[] resourceId = resourceIdArr.split(",");
			String[] flowId = confirmUseridArr.split(",");
			String[] forecastDate = forecastDateArr.split(",");
			String[] remindDate = remindDateArr.split(",");
			String[] confirmExplain = confirmExplainArr.split(",");
			String confirmFlowid = null;
			MtlApproveConfirmList macl;
			MtlApproveConfirmListId macli;
			for (int i = 0; resourceId != null && flowId != null
					&& i < resourceId.length && i < flowId.length; i++) {
				if (resourceId[i] != null && resourceId[i].length() > 0
						&& flowId[i] != null && flowId[i].length() > 0) {
					List list = this.findConfirmListById(campsegId, null,
							resourceId[i], null, null, null, null);
					if (list != null && list.size() > 0) {
						for (int j = 0; j < list.size(); j++) {
							MtlApproveConfirmList svc = (MtlApproveConfirmList) list
									.get(j);
							approveConfirmListDao.delete(svc);
						}
					}

					confirmFlowid = flowId[i];
					String approveUserId;
					// 取审批流程中每一个审批级别定义的审批人
					MtlApproveLevelDef levelDef;
					Iterator levelIt = mtlApproveLevelDefDao
							.getApproveLevelDefByFlow(confirmFlowid).iterator();
					short approveSeq = 1;
					while (levelIt.hasNext()) {
						approveUserId = null;
						levelDef = (MtlApproveLevelDef) levelIt.next();
						short approveObjType = levelDef.getApproveObjType()
								.shortValue();
						String deptId = null;
						int deptTopN;
						if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_SELF_DEPT) {
							IUser user = mpmUserPrivilegeService
									.getUser(needApproveUserid);
							if (user == null) {
								throw new MpmException(
										MpmLocaleUtil
												.getMessage("mcd.java.zbd")
												+ needApproveUserid
												+ MpmLocaleUtil
														.getMessage("mcd.java.yhdx"));
							}
							deptId = String.valueOf(user.getDepartmentid());
						} else if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_DEPT) {
							deptId = levelDef.getApproveObjId().trim();
						} else if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER) {
							approveUserId = levelDef.getApproveObjId().trim();
						} else if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_TOPN_DEPT) {
							deptTopN = Integer.parseInt(levelDef
									.getApproveObjId().trim());
							IUser user = mpmUserPrivilegeService
									.getUser(needApproveUserid);
							if (user == null) {
								throw new MpmException(
										MpmLocaleUtil
												.getMessage("mcd.java.zbd")
												+ needApproveUserid
												+ MpmLocaleUtil
														.getMessage("mcd.java.yhdx"));
							}
							deptId = String.valueOf(user.getDepartmentid());
							// 取当前分公司/部门的上N级分公司/部门编号
							deptId = MpmUtil
									.getDeptTopNDeptId(deptId, deptTopN);
						}
						// 取审批部门对应设定的审批人
						if (approveUserId == null && deptId != null) {
							MtlApproveRelation relation = relationDao
									.findByUserid(deptId, null);
							if (relation != null) {
								approveUserId = relation.getId()
										.getApproveUserid();
							}
						}

						if (StringUtil.isEmpty(approveUserId)) {
							log.error(MpmLocaleUtil.getMessage("mcd.java.spd")
									+ levelDef.getId().getApproveLevel()
									+ MpmLocaleUtil
											.getMessage("mcd.java.jzbdsprlg"));
							continue;
						}
						approveSeq++;
						macl = new MtlApproveConfirmList();
						macli = new MtlApproveConfirmListId();
						macli.setCampsegId(campsegId);
						macli.setResourceId(Integer.valueOf(resourceId[i]));
						macli.setConfirmUserid(approveUserId);
						macli.setApproveLevel(Short.valueOf(levelDef.getId()
								.getApproveLevel().shortValue()));
						macli.setApproveSeq(Short.valueOf(approveSeq));
						macli.setApproveFlowId(confirmFlowid);
						macl.setId(macli);
						macl.setConfirmFlag(Short.valueOf("0"));
						macl.setApproveToken(Short
								.valueOf(MpmCONST.MPM_APPROVE_TOKEN_NOT_HOLD));
						if (forecastDate != null && forecastDate.length > i) {
							if (forecastDate[i] != null
									&& forecastDate[i].length() > 0) {
								macl.setForecastDate(forecastDate[i]);
							} else {
								macl.setForecastDate("");
							}
						} else {
							macl.setForecastDate("");
						}

						if (remindDate != null && remindDate.length > i) {
							if (remindDate[i] != null
									&& remindDate[i].length() > 0) {
								macl.setRemindDate(remindDate[i]);
							} else {
								macl.setRemindDate("");
							}
						} else {
							macl.setRemindDate("");
						}

						if (confirmExplain != null && confirmExplain.length > i) {
							if (confirmExplain[i] != null
									&& confirmExplain[i].length() > 0) {
								macl.setConfirmExplain(confirmExplain[i]);
							} else {
								macl.setConfirmExplain("");
							}
						} else {
							macl.setConfirmExplain("");
						}
						try {
							approveConfirmListDao.save(macl);
						} catch (Exception ex) {
							log.error("", ex);
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("", e);
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.bcqrzyrlbx"));
		}
	}

	*//**
		* 
		* getCampApproveFlowIDForBj:针对北京提出的需求改造,针对外呼渠道，非分公司策划人需要两级审批，
		* 分公司策划人只需要一级审批添加判断逻辑
		* ，这个部分也可给其他省份应用，只需要在省份配置文件里配置MCD_APPROVE_CONFIRM_ID，GSD_COMMPANY_DEPTID即可
		* 
		* @param channelID
		* @return String
		* @throws Exception
		*/
	/*
	public String getCampApproveFlowIDForBj(String channelID, String campId)
		throws Exception {
	// 开始 针对北京提出的需求改造 add by sang at 20150303
	// 针对外呼渠道，非分公司策划人需要两级审批，分公司策划人只需要一级审批添加判断逻辑，这个部分也可给其他省份应用，只需要在省份配置文件里配置MCD_APPROVE_CONFIRM_ID，GSD_COMMPANY_DEPTID即可
	String confirmFlowid = null;
	// String
	// channelID=dimChannelUserRelation.getId().getChannelId();//获取渠道ID
	String gsdCommpanyDeptID = MpmConfigure.getInstance().getProperty(
			"GSD_COMMPANY_DEPTID");// 配置分公司ID
	String mcdApproveConfirmID = MpmConfigure.getInstance().getProperty(
			"MCD_APPROVE_CONFIRM_ID");// 配置特殊流程ID
	String province = Configure.getInstance().getProperty("PROVINCE");// 获取省份
	if ("beijing".equalsIgnoreCase(province)
			&& MpmCONST.CHANNEL_ID_CALL_OUT.equals(channelID)
			&& StringUtil.isNotEmpty(gsdCommpanyDeptID)
			&& StringUtil.isNotEmpty(mcdApproveConfirmID)) {// 判断是外呼渠道
		// 获取营销案信息
		IMpmHandChgStatusSvc service = (IMpmHandChgStatusSvc) SystemServiceLocator
				.getInstance().getService(
						MpmCONST.HAND_CHGSTATUS_SERVICE_BEAN_ID);
		MtlCampBaseinfo mcbInfo = service.getBaseInfo(campId);
		if (mcbInfo != null) {
			String deptID = MpmUtil.getSecondDeptId(mcbInfo.getDeptId());// 营销案策划人所属部门ID
			String[] gsdCommpanyDeptIDArrs = gsdCommpanyDeptID.split(",");
			log.debug(
					"配置特殊流程：审批关系的渠道id：{},策划案部门 DeptID:{},分公司部门id:{},特殊流程ID:{}",
					channelID, deptID, gsdCommpanyDeptID,
					mcdApproveConfirmID);
			if (isContains(gsdCommpanyDeptIDArrs, deptID) == false) {
				log.debug("审批变更审批流程ID,原id={},新ID={}", confirmFlowid,
						mcdApproveConfirmID);
				confirmFlowid = mcdApproveConfirmID;

			}
		}

	}
	// 结束 针对北京提出的需求改造 add by sang at 20150303
	return confirmFlowid;
	}

	// caihao 2008-07-31 add 根据确认流程, 将每一个审批人保存到列表中, 自动提交确认用
	public void saveCampsegConfirmListAuto(
		DimChannelUserRelation dimChannelUserRelation, String campsegId,
		String needApproveUserid) throws MpmException {
	try {
		String confirmFlowid = null;
		MtlApproveConfirmList macl;
		MtlApproveConfirmListId macli;
		confirmFlowid = dimChannelUserRelation.getId().getUserId();
		Integer resourceId = dimChannelUserRelation.getResourceId();
		String approveUserId;
		// 取审批流程中每一个审批级别定义的审批人
		MtlApproveLevelDef levelDef;
		Iterator levelIt = mtlApproveLevelDefDao.getApproveLevelDefByFlow(
				confirmFlowid).iterator();
		short approveSeq = 1;
		while (levelIt.hasNext()) {
			approveUserId = null;
			levelDef = (MtlApproveLevelDef) levelIt.next();
			short approveObjType = levelDef.getApproveObjType()
					.shortValue();
			String deptId = null;
			int deptTopN;
			if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_SELF_DEPT) {
				IUser user = mpmUserPrivilegeService
						.getUser(needApproveUserid);
				if (user == null) {
					throw new MpmException(
							MpmLocaleUtil.getMessage("mcd.java.zbd")
									+ needApproveUserid
									+ MpmLocaleUtil
											.getMessage("mcd.java.yhdx"));
				}
				deptId = String.valueOf(user.getDepartmentid());
			} else if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_DEPT) {
				deptId = levelDef.getApproveObjId().trim();
			} else if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER) {
				approveUserId = levelDef.getApproveObjId().trim();
			} else if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_TOPN_DEPT) {
				deptTopN = Integer.parseInt(levelDef.getApproveObjId()
						.trim());
				IUser user = mpmUserPrivilegeService
						.getUser(needApproveUserid);
				if (user == null) {
					throw new MpmException(
							MpmLocaleUtil.getMessage("mcd.java.zbd")
									+ needApproveUserid
									+ MpmLocaleUtil
											.getMessage("mcd.java.yhdx"));
				}
				deptId = String.valueOf(user.getDepartmentid());
				// 取当前分公司/部门的上N级分公司/部门编号
				deptId = MpmUtil.getDeptTopNDeptId(deptId, deptTopN);
			}
			// 取审批部门对应设定的审批人
			if (approveUserId == null && deptId != null) {
				MtlApproveRelation relation = relationDao.findByUserid(
						deptId, null);
				if (relation != null) {
					approveUserId = relation.getId().getApproveUserid();
				}
			}

			if (StringUtil.isEmpty(approveUserId)) {
				log.error(MpmLocaleUtil.getMessage("mcd.java.spd")
						+ levelDef.getId().getApproveLevel()
						+ MpmLocaleUtil.getMessage("mcd.java.jzbdsprlg"));
				continue;
			}

			macl = new MtlApproveConfirmList();
			macli = new MtlApproveConfirmListId();
			macli.setCampsegId(campsegId);
			macli.setResourceId(resourceId);
			macli.setConfirmUserid(approveUserId);
			macli.setApproveLevel(Short.valueOf(levelDef.getId()
					.getApproveLevel().shortValue()));
			macli.setApproveSeq(Short.valueOf(approveSeq));
			macli.setApproveFlowId(confirmFlowid);
			macli.setChannelNo(dimChannelUserRelation.getChannelNo());
			macl.setId(macli);
			macl.setConfirmFlag(Short.valueOf("0"));
			macl.setApproveToken(Short
					.valueOf(MpmCONST.MPM_APPROVE_TOKEN_NOT_HOLD));
			macl.setForecastDate("");
			macl.setRemindDate("");
			macl.setConfirmExplain("");
			try {
				approveConfirmListDao.save(macl);
			} catch (Exception ex) {
				log.error("", ex);
			}
			approveSeq++;
		}

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.bcqrzyrlbx"));
	}
	}

	// 包含返回true，不包含返回false
	private boolean isContains(String[] arrs, String str) {
	boolean flag = false;// 默认不包含
	if (arrs != null && arrs.length > 0) {
		for (String a : arrs) {
			if (a.trim().equals(str.trim())) {
				flag = true;
				break;
			}
		}
	}
	return flag;
	}

	public void saveCampsegConfirmListAutoNew(
		DimChannelUserRelation dimChannelUserRelation, String campsegId,
		String needApproveUserid, String campsegRootid) throws MpmException {
	try {
		String confirmFlowid = null;
		MtlApproveConfirmList macl;
		MtlApproveConfirmListId macli;
		confirmFlowid = dimChannelUserRelation.getId().getUserId();
		Integer resourceId = dimChannelUserRelation.getResourceId();
		String approveUserId;
		// 取审批流程中每一个审批级别定义的审批人
		MtlApproveLevelDef levelDef;
		Iterator levelIt = mtlApproveLevelDefDao.getApproveLevelDefByFlow(
				confirmFlowid).iterator();
		short approveSeq = 1;
		while (levelIt.hasNext()) {
			approveUserId = null;
			levelDef = (MtlApproveLevelDef) levelIt.next();
			short approveObjType = levelDef.getApproveObjType()
					.shortValue();
			String deptId = null;
			int deptTopN;
			if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_SELF_DEPT) {
				IUser user = mpmUserPrivilegeService
						.getUser(needApproveUserid);
				if (user == null) {
					throw new MpmException(
							MpmLocaleUtil.getMessage("mcd.java.zbd")
									+ needApproveUserid
									+ MpmLocaleUtil
											.getMessage("mcd.java.yhdx"));
				}
				deptId = String.valueOf(user.getDepartmentid());
			} else if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_DEPT) {
				deptId = levelDef.getApproveObjId().trim();
			} else if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER) {
				approveUserId = levelDef.getApproveObjId().trim();
			} else if (approveObjType == MpmCONST.MPM_APPROVE_OBJ_TYPE_TOPN_DEPT) {
				deptTopN = Integer.parseInt(levelDef.getApproveObjId()
						.trim());
				IUser user = mpmUserPrivilegeService
						.getUser(needApproveUserid);
				if (user == null) {
					throw new MpmException(
							MpmLocaleUtil.getMessage("mcd.java.zbd")
									+ needApproveUserid
									+ MpmLocaleUtil
											.getMessage("mcd.java.yhdx"));
				}
				deptId = String.valueOf(user.getDepartmentid());
				// 取当前分公司/部门的上N级分公司/部门编号
				deptId = MpmUtil.getDeptTopNDeptId(deptId, deptTopN);
			}
			// 取审批部门对应设定的审批人
			if (approveUserId == null && deptId != null) {
				MtlApproveRelation relation = relationDao.findByUserid(
						deptId, null);
				if (relation != null) {
					approveUserId = relation.getId().getApproveUserid();
				}
			}

			if (StringUtil.isEmpty(approveUserId)) {
				log.error(MpmLocaleUtil.getMessage("mcd.java.spd")
						+ levelDef.getId().getApproveLevel()
						+ MpmLocaleUtil.getMessage("mcd.java.jzbdsprlg"));
				continue;
			}

			macl = new MtlApproveConfirmList();
			macli = new MtlApproveConfirmListId();
			macli.setCampsegId(campsegId);
			macli.setResourceId(resourceId);
			macli.setConfirmUserid(approveUserId);
			macli.setApproveLevel(Short.valueOf(levelDef.getId()
					.getApproveLevel().shortValue()));
			macli.setApproveSeq(Short.valueOf(approveSeq));
			macli.setApproveFlowId(confirmFlowid);
			macli.setChannelNo(dimChannelUserRelation.getChannelNo());
			macl.setId(macli);
			macl.setCampsegRootid(campsegRootid);
			macl.setConfirmFlag(Short.valueOf("0"));
			macl.setApproveToken(Short
					.valueOf(MpmCONST.MPM_APPROVE_TOKEN_NOT_HOLD));
			macl.setForecastDate("");
			macl.setRemindDate("");
			macl.setConfirmExplain("");
			try {
				approveConfirmListDao.save(macl);
			} catch (Exception ex) {
				log.error("", ex);
			}
			approveSeq++;
		}

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.bcqrzyrlbx"));
	}
	}

	// caihao add 08-7-22
	public String getFirstApproveUser(String approveFlowId, String campsegId,
		Integer resourceId) throws MpmException {
	String approveUserId = null;
	try {
		MtlApproveConfirmList cond = new MtlApproveConfirmList();
		cond.getId().setApproveFlowId(approveFlowId);
		cond.getId().setCampsegId(campsegId);
		cond.getId().setResourceId(resourceId);
		List approverList = approveConfirmListDao.findCampsegApprover(cond);
		MtlApproveConfirmList obj;
		if (approverList.size() > 0) {
			obj = (MtlApproveConfirmList) approverList.get(0);
			approveUserId = obj.getId().getConfirmUserid();
		}
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qhdddygspr") + e);
	}
	return approveUserId;
	}

	public boolean checkConfirmFailed(String campsegId, Integer resourceId)
		throws MpmException {
	try {
		return approveConfirmListDao.checkConfirmFailed(campsegId,
				resourceId);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.pdmyqdsfcz") + e);
	}
	}

	public void updateCampsegApproverToken(String approveFlowId,
		String campsegId, String approveUserId, Short seq, Short token,
		Integer resourceId) throws MpmException {
	try {
		approveConfirmListDao.updateCampsegConfirmToken(approveFlowId,
				campsegId, approveUserId, seq, token, resourceId);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.gxhdsprlpx"));
	}
	}

	public boolean isLastApproveUser(String approveFlowId, String campsegId,
		String currApproverUserId, Integer resourceId, Short seq)
		throws MpmException {
	boolean isLast = false;
	try {
		MtlApproveConfirmList cond = new MtlApproveConfirmList();
		cond.getId().setApproveFlowId(approveFlowId);
		cond.getId().setCampsegId(campsegId);
		cond.getId().setResourceId(resourceId);
		List approverList = approveConfirmListDao.findCampsegApprover(cond);
		MtlApproveConfirmList obj;
		if (approverList.size() > 0) {
			obj = (MtlApproveConfirmList) approverList.get(approverList
					.size() - 1);
			if (obj.getId().getConfirmUserid().equals(currApproverUserId)
					&& obj.getId().getApproveSeq().shortValue() == seq
							.shortValue()) {
				isLast = true;
			}
		}

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.pdyhsfwzhy") + e);
	}
	return isLast;
	}

	public List findUserConfirmList(MtlApproveConfirmList approver)
		throws MpmException {
	List result = new ArrayList();
	try {
		result = approveConfirmListDao.findCampsegApprover(approver);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.pdyhsfwzhy") + e);
	}
	return result;
	}

	public String[] getNextApproveUser(String approveFlowId, String campsegId,
		String currApproveUserId, Integer resourceId, Short seq)
		throws MpmException {
	String approveUserId = null;
	String nextSeq = null;
	try {
		MtlApproveConfirmList cond = new MtlApproveConfirmList();
		cond.getId().setApproveFlowId(approveFlowId);
		cond.getId().setCampsegId(campsegId);
		cond.getId().setResourceId(resourceId);
		Iterator approverIt = approveConfirmListDao.findCampsegApprover(
				cond).iterator();
		MtlApproveConfirmList obj;
		boolean isFound = false, isFoundNext = false;
		while (approverIt.hasNext()) {
			obj = (MtlApproveConfirmList) approverIt.next();
			if (isFound) {
				approveUserId = obj.getId().getConfirmUserid();
				nextSeq = obj.getId().getApproveSeq().shortValue() + "";
				isFoundNext = true;
				break;
			}
			if (obj.getId().getConfirmUserid().equals(currApproveUserId)
					&& obj.getId().getApproveSeq().shortValue() == seq
							.shortValue()) {
				isFound = true;
			}
		}

		if (!isFoundNext) {
			approveUserId = "-1";
			nextSeq = "-1";
		}
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qhddxygsps") + e);
	}
	return new String[] { approveUserId, nextSeq };
	}

	public List findConfirmList(MtlApproveConfirmList searchCond)
		throws MpmException {
	try {
		return approveConfirmListDao.findByCond(searchCond);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.cxqrzyrlbx"));
	}
	}

	public void deleteConfirmList(MtlApproveConfirmList searchCond)
		throws MpmException {
	try {
		approveConfirmListDao.delete(searchCond);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.cxqrzyrlbx"));
	}
	}

	public List findConfirmListById(String campsegId, String confirmFlag,
		String resourceId, String confirmUserid, String approveFlowId,
		Short approveSeq, Short approveLevel) throws MpmException {
	try {
		return approveConfirmListDao.findById(campsegId, confirmFlag,
				resourceId, confirmUserid, approveFlowId, approveSeq,
				approveLevel);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.cxqrzyrlbx"));
	}
	}

	public List findCurrentConfirmListById(String campsegId,
		String confirmFlag, String resourceId, String confirmUserid,
		String approveFlowId, Short approveSeq, Short approveLevel)
		throws MpmException {
	try {
		return approveConfirmListDao.findCurrentById(campsegId,
				confirmFlag, resourceId, confirmUserid, approveFlowId,
				approveSeq, approveLevel);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.cxqrzyrlbx"));
	}
	}

	public void updateConfirmList(MtlApproveConfirmList svc)
		throws MpmException {
	try {
		if (svc.getConfirmAdvice() == null) {
			svc.setConfirmAdvice("");
		}
		approveConfirmListDao.update(svc);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.gxqrzyrlbx"));
	}
	}

	public void saveConfirmList(MtlApproveConfirmList svc) throws MpmException {
	try {
		if (svc.getConfirmAdvice() == null) {
			svc.setConfirmAdvice("");
		}
		approveConfirmListDao.save(svc);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.xzqrzyrlbx"));
	}
	}

	// caihao add 08/1/14
	public String checkResourceType(Integer resourceId) throws MpmException {
	try {
		String resourceType = null;
		short flag = 5;
		List list = approveResourceDao.findFlag(resourceId);
		if (list != null && list.size() > 0) {
			Short f = (Short) list.get(0);
			flag = f.shortValue();
			if (flag == 0) {
				resourceType = "channel";
			} else {
				resourceType = "resource";
			}
		}

		return resourceType;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.pdqdhzysb"));
	}
	}

	public MtlApproveResourceType getResourceType(Integer resourceId)
		throws MpmException {
	try {
		MtlApproveResourceType mart = null;
		mart = approveResourceDao.getRourceById(resourceId);

		return mart;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qdzylxsb"));
	}
	}

	// caihao add
	public MtlApproveResourceType getResourceTypeByName(String resourceName)
		throws MpmException {
	try {
		MtlApproveResourceType mart = null;
		mart = approveResourceDao.getRourceByName(resourceName);

		return mart;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qdzylxsb"));
	}
	}

	public MtlCampChanneltype getChanneltype(Short channeltypeId,
		String campId, String channelId) throws MpmException {
	try {
		MtlCampChanneltype mcct = null;

		List list = channeltypeDao.getChanneltype(channeltypeId, campId,
				channelId);

		if (list != null && list.size() > 0) {

			mcct = (MtlCampChanneltype) list.get(0);
		}
		return mcct;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qdqdxxsbge"));
	}
	}

	public MtlCampChanneltype getChanneltypeByNo(Short channeltypeId,
		String campId, String channelNo) throws MpmException {
	try {
		MtlCampChanneltype mcct = null;

		List list = channeltypeDao.getChanneltypeByNo(channeltypeId,
				campId, channelNo);

		if (list != null && list.size() > 0) {

			mcct = (MtlCampChanneltype) list.get(0);
		}
		return mcct;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qdqdxxsbge"));
	}
	}

	public List getChanneltypeByCampid(String campId) throws MpmException {
	try {
		MtlCampChanneltype mcct = new MtlCampChanneltype();

		List list = channeltypeDao.getChanneltypeByCampid(campId);
		return list;
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qdqdxxsbge1"));
	}
	}

	public List getConfirmExtendInfo(String campsegId, Integer resourceId,
		String confirmUserid, Short usersegId, Short approveSeq)
		throws MpmException {
	try {
		// MtlConfirmExtendInfo mcei = new MtlConfirmExtendInfo();
		List list = confirmExtendInfoDao.getMtlConfirmExtendInfo(campsegId,
				resourceId, confirmUserid, usersegId, approveSeq);
		return list;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qdqrewxxsb"));
	}
	}

	public void updateConfirmExtendInfoCustNums(String campsegId,
		Integer resourceId, String confirmUserid, Short usersegId,
		Short approveSeq, Double custNums) throws MpmException {
	try {
		// MtlConfirmExtendInfo mcei = new MtlConfirmExtendInfo();
		confirmExtendInfoDao.updateConfirmExtendinfoCustNums(campsegId,
				resourceId, confirmUserid, usersegId, approveSeq, custNums);
		// return list;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.gxqrewxxsb"));
	}
	}

	public void updateConfirmExtendInfoRptScore(String campsegId,
		Integer resourceId, String confirmUserid, Short usersegId,
		Short approveSeq, Integer rptScore) throws MpmException {
	try {
		// MtlConfirmExtendInfo mcei = new MtlConfirmExtendInfo();
		confirmExtendInfoDao.updateConfirmExtendinfoRptScore(campsegId,
				resourceId, confirmUserid, usersegId, approveSeq, rptScore);
		// return list;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.gxqrewxxsb"));
	}
	}

	public void updateConfirmExtendInfoDate(String campsegId,
		Integer resourceId, String confirmUserid, Short usersegId,
		Short approveSeq, String startDate, String endDate)
		throws MpmException {
	try {
		// MtlConfirmExtendInfo mcei = new MtlConfirmExtendInfo();
		confirmExtendInfoDao.updateStratEndDate(campsegId, resourceId,
				confirmUserid, usersegId, approveSeq, startDate, endDate);
		// return list;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.gxqrewxxsb"));
	}
	}

	public void updateConfirmExtendInfoContent(String campsegId,
		Integer resourceId, String confirmUserid, Short usersegId,
		Short approveSeq, String content) throws MpmException {
	try {
		// MtlConfirmExtendInfo mcei = new MtlConfirmExtendInfo();
		confirmExtendInfoDao.updateChannelCampContent(campsegId,
				resourceId, confirmUserid, usersegId, approveSeq, content);
		// return list;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.gxqrewxxsb"));
	}
	}

	public void saveConfirmExtendInfoCustNums(MtlConfirmExtendInfo mcei)
		throws MpmException {
	try {
		// MtlConfirmExtendInfo mcei = new MtlConfirmExtendInfo();
		confirmExtendInfoDao.saveConfirmExtendInfo(mcei);
		// return list;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.bcqrewxxsb"));
	}
	}

	// caihao add
	public DimChannelUserRelation getChannelTypeId(Integer resourceId,
		String userId, String confirmType) throws MpmException {
	try {
		DimChannelUserRelation dimChannelUserRelation;
		dimChannelUserRelation = channelUserDao.getChannelTypeId(
				resourceId, userId, Short.valueOf(confirmType));
		return dimChannelUserRelation;

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qdqduserRe"));
	}
	}

	// caihao add 02/11/2007
	public String checkConfirmEnd(String campsegId) throws MpmException {
	try {
		return approveConfirmListDao.checkConfirmEnd(campsegId);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.pdmyhdsyxq"));
	}
	}

	public boolean checkConfirmFinished(String campsegId, Short resourceId,
		int confirmFlag) throws MpmException {
	try {
		return approveConfirmListDao.checkConfirmFinished(campsegId,
				resourceId, confirmFlag);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.pdmyhddmxz"));
	}
	}

	public String checkConfirmAllFinished(String campsegRootid) {
	try {
		return approveConfirmListDao.checkConfirmAllFinished(campsegRootid);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.pdmyhddmxz"));
	}
	}

	public String checkUserConfirmEnd(String campsegId, String userid,
		Integer resourceId) throws MpmException {
	try {
		return approveConfirmListDao.checkConfirmEnd(campsegId, userid,
				resourceId);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.pdmrsfqrwm"));
	}
	}

	// caihao add 查询确认列表，批量确认用
	public List findByCond(MtlApproveConfirmList searchCond)
		throws MpmException {
	try {
		return approveConfirmListDao.findByCond(searchCond);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.pdmyhdsyxq"));
	}
	}

	
	* public MtlCampSeginfo findCampsegInfo(String campsegId) throws
	* MpmException { MtlCampSeginfo obj = null; try {
	* 
	* obj = campsegDao.getCampSegInfo(campsegId); } catch (Exception e) {
	* log.error("", e); throw new
	* MpmException(MpmLocaleUtil.getMessage("mcd.java.hdhd") + campsegId +
	* MpmLocaleUtil.getMessage("mcd.java.xxcc") + e); } return obj; }
	

	
	* public MtlCampBaseinfo findCampBaseInfo(String campId) throws
	* MpmException { MtlCampBaseinfo obj = null; try {
	* 
	* obj = campbaseDao.getCampaignBaseInfo(campId); } catch (Exception e) {
	* log.error("", e); throw new
	* MpmException(MpmLocaleUtil.getMessage("mcd.java.hd") + campId +
	* MpmLocaleUtil.getMessage("mcd.java.xxcc") + e); } return obj; }
	

	// caihao add 保存确认通知内容
	public void saveApproveContentSend(MtlApproveContentSend obj)
		throws MpmException {

	try {

		if (StringUtil.isEmpty(obj.getSendAddress())) {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.tzdzsjhyjd"));

			return;
		}
		String ser = (String) sendDao.saveObj(obj);

		if (ser == null) {
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.bctznrcc"));
		}

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.bctznrcc") + e);
	}
	}

	// caihao add 2008/1/07 活动确认后短信邮件提醒功能
	public void saveConfirmSendContent(HttpServletRequest request,
		MpmCampApproveDetailMainForm aForm, String userId)
		throws MpmException {

	try {
		IMpmSendForUnitouchService mpmSendForUnitouchService = (IMpmSendForUnitouchService) SystemServiceLocator
				.getInstance().getService("mpmSendForUnitouchService");

		short confirmFlag = aForm.getApproveResult();
		String createUserid = aForm.getCreateUserid();
		String campsegId = aForm.getCampsegId();
		String changeStartDate = aForm.getChangeStartDate();
		String changeEndDate = aForm.getChangeEndDate();
		String advice = aForm.getApproveAdv();
		String resourceName = aForm.getResourceName();
		if (advice.equals("")) {
			advice = MpmLocaleUtil.getMessage("mcd.java.w");
		}
		// 发送给策划者的邮件内容
		String emailSendToCreateUser = "";

		MtlCampSeginfo campseg = this.findCampsegInfo(campsegId);

		if (campseg == null) {
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.zbdhddxx"));
		}
		String campsegName = campseg.getCampsegName();

		// MtlCampBaseinfo campbase =
		// campDao.getCampaignBaseInfo(campsegId);
		// 取得策划人的手机号码，邮件地址，姓名
		String createUsermsisdn = "";
		String createUserEmail = "";
		String createUserName = "";
		// log.debug("2="+createUserid);
		IUser user = mpmUserPrivilegeService.getUser(createUserid);
		// log.debug("3="+createUserid);
		if (user != null) {
			createUsermsisdn = user.getMobilePhone();
			createUserEmail = user.getEmail();
			createUserName = user.getUsername();
		} else {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.xtzbczchyh")
					+ createUserid + "]");
		}
		if (StringUtil.isEmpty(createUsermsisdn)) {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh")
					+ createUserid
					+ MpmLocaleUtil.getMessage("mcd.java.mysdsjhmwf"));
		}
		if (StringUtil.isEmpty(createUserEmail)) {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh")
					+ createUserid
					+ MpmLocaleUtil.getMessage("mcd.java.mysdyjdzwf"));
		}

		// 取得确认人的用户姓名
		String currentAuditUserName = "";
		IUser auditUser = mpmUserPrivilegeService.getUser(userId);
		if (auditUser != null) {
			currentAuditUserName = auditUser.getUsername();
		} else {
			currentAuditUserName = userId;
		}

		MtlApproveContentSend sendObj = new MtlApproveContentSend();
		// MtlApproveContentSendId sendKey = new MtlApproveContentSendId();
		sendObj.setApproveReceiveNums(Short.valueOf("0"));
		sendObj.setServerIp(UserManager.getHostAddress());
		sendObj.setServerPort(String.valueOf(request.getServerPort()));

		sendObj.setApproveUserid(userId);
		sendObj.setCampId(aForm.getCampId());
		sendObj.setCampsegId(campsegId);
		sendObj.setContentType(Short.valueOf(MpmCONST.APPROVE_SENDTYPE_SMS));
		sendObj.setCreateUserid(createUserid);
		// sendObj.setId(sendKey);
		sendObj.setCreateTime(new Date());
		sendObj.setSendFlag(Integer.valueOf(0));
		sendObj.setSentTimes(Short.valueOf("0"));

		String allContentDescTmp = ""; // 短信内容在原有所有内容基础上删除advice；
		if (confirmFlag == MpmCONST.MPM_CONFIRM_FLAG_YES) {
			allContentDescTmp = MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdhd")
					+ campsegName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resourceName
					+ MpmLocaleUtil.getMessage("mcd.java.yjtg")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrqrhkssj")
					+ changeStartDate
					+ MpmLocaleUtil.getMessage("mcd.java.qrhjssj")
					+ changeEndDate
					+ MpmLocaleUtil.getMessage("mcd.java.qryj")
					+ advice
					+ MpmLocaleUtil.getMessage("mcd.java.3");
			sendObj.setContentDesc(MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdhd")
					+ campsegName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resourceName
					+ MpmLocaleUtil.getMessage("mcd.java.yjtg")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrqrhkssj")
					+ changeStartDate
					+ MpmLocaleUtil.getMessage("mcd.java.qrhjssj")
					+ changeEndDate
					+ MpmLocaleUtil.getMessage("mcd.java.3"));
		}
		// else if(approveResult ==
		// MpmCONST.MPM_SEG_APPROVE_RESULT_NOTPASSED)
		// sendObj.setContentDesc("您提交审批的活动[" + campsegName + "]没通过[" +
		// currentAuditUserName + "]的审批，需要整改，请登陆系统查阅详细信息！");
		else if (confirmFlag == MpmCONST.MPM_CONFIRM_FLAG_CANNOT) {
			allContentDescTmp = MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdhd")
					+ campsegName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resourceName
					+ MpmLocaleUtil.getMessage("mcd.java.mytg")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrhghdybz")
					+ advice
					+ MpmLocaleUtil.getMessage("mcd.java.3")
					+ MpmLocaleUtil.getMessage("mcd.java.qdlxtcyxxx");
			sendObj.setContentDesc(MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdhd")
					+ campsegName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resourceName
					+ MpmLocaleUtil.getMessage("mcd.java.mytg")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrhghdybz1")
					+ MpmLocaleUtil.getMessage("mcd.java.qdlxtcyxxx"));
		}
		sendObj.setSendAddress(createUsermsisdn);

		// mpmSendForUnitouchService.sendSMSOnTime(sendObj);
		sendObj.setContentDesc(allContentDescTmp); // 重新设置email内容，加上advice；

		emailSendToCreateUser = sendObj.getContentDesc();

		// 发送邮件通知给策划人 added by wwl 2006-8-19
		if (createUserEmail != null && createUserEmail.length() > 1) {
			MtlApproveContentSend sendEmailObj = new MtlApproveContentSend();
			BeanUtils.copyProperties(sendEmailObj, sendObj);
			sendEmailObj.setSendAddress(createUserEmail);
			sendEmailObj.setApproveUserid(userId);
			sendEmailObj.setContentType(Short
					.valueOf(MpmCONST.APPROVE_SENDTYPE_EMAIL));
			emailSendToCreateUser = MpmHtmlHelper
					.genApproveEmailToCreateUser(createUserName,
							emailSendToCreateUser);
			sendEmailObj.setContentDesc(emailSendToCreateUser);
			sendEmailObj.setContentDesc2("");
			sendEmailObj.setContentId(null);
			// mpmSendForUnitouchService.sendEmailOnTime(sendEmailObj.getSendAddress(),
			// sendEmailObj.getContentDesc()+sendEmailObj.getContentDesc2());

		}

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bccc")
				+ e);

	}
	}

	// 营销案确认发送短信邮件通知
	public void saveCampConfirmSendContent(HttpServletRequest request,
		MpmCampApproveDetailMainForm aForm, String userId, String custNums,
		String rptScore, String resName) throws MpmException {

	try {
		IMpmSendForUnitouchService mpmSendForUnitouchService = (IMpmSendForUnitouchService) SystemServiceLocator
				.getInstance().getService("mpmSendForUnitouchService");

		short confirmFlag = aForm.getApproveResult();
		String createUserid = aForm.getCreateUserid();
		String campId = aForm.getCampId();
		String advice = aForm.getApproveAdv();
		if (StringUtil.isEmpty(advice)) {
			advice = MpmLocaleUtil.getMessage("mcd.java.w");
		}

		// 发送给策划者的邮件内容
		String emailSendToCreateUser = "";

		MtlCampBaseinfo camp = this.findCampBaseInfo(campId);

		if (camp == null) {
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.zbdhddxx"));
		}
		String campName = camp.getCampName();

		// MtlCampBaseinfo campbase =
		// campDao.getCampaignBaseInfo(campsegId);
		// 取得策划人的手机号码，邮件地址，姓名
		String createUsermsisdn = "";
		String createUserEmail = "";
		String createUserName = "";
		IUser user = mpmUserPrivilegeService.getUser(createUserid);

		if (user != null) {
			createUsermsisdn = user.getMobilePhone();
			createUserEmail = user.getEmail();
			createUserName = user.getUsername();

		} else {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.xtzbczchyh")
					+ createUserid + "]");
		}
		if (StringUtil.isEmpty(createUsermsisdn)) {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh")
					+ createUserid
					+ MpmLocaleUtil.getMessage("mcd.java.mysdsjhmwf"));
		}
		if (StringUtil.isEmpty(createUserEmail)) {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh")
					+ createUserid
					+ MpmLocaleUtil.getMessage("mcd.java.mysdyjdzwf"));
		}

		// 取得确认人的用户姓名
		String currentAuditUserName = "";
		IUser auditUser = mpmUserPrivilegeService.getUser(userId);
		if (auditUser != null) {
			currentAuditUserName = auditUser.getUsername();
		} else {
			currentAuditUserName = userId;
		}

		MtlApproveContentSend sendObj = new MtlApproveContentSend();
		// MtlApproveContentSendId sendKey = new MtlApproveContentSendId();
		sendObj.setApproveReceiveNums(Short.valueOf("0"));
		sendObj.setServerIp(UserManager.getHostAddress());
		sendObj.setServerPort(String.valueOf(request.getServerPort()));

		sendObj.setApproveUserid(userId);
		sendObj.setCampId(aForm.getCampId());
		// sendObj.setCampsegId(campsegId);
		sendObj.setContentType(Short.valueOf(MpmCONST.APPROVE_SENDTYPE_SMS));
		sendObj.setCreateUserid(createUserid);

		sendObj.setCreateTime(new Date());
		sendObj.setSendFlag(Integer.valueOf(0));
		sendObj.setSentTimes(Short.valueOf("0"));

		if (confirmFlag == MpmCONST.MPM_CONFIRM_FLAG_YES) {
			sendObj.setContentDesc(MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdyxa")
					+ campName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resName
					+ MpmLocaleUtil.getMessage("mcd.java.yjtg")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrqrhdmbk")
					+ custNums
					+ MpmLocaleUtil.getMessage("mcd.java.wrpfjg")
					+ rptScore
					+ MpmLocaleUtil.getMessage("mcd.java.qryj")
					+ advice);
		}
		// else if(approveResult ==
		// MpmCONST.MPM_SEG_APPROVE_RESULT_NOTPASSED)
		// sendObj.setContentDesc("您提交审批的活动[" + campsegName + "]没通过[" +
		// currentAuditUserName + "]的审批，需要整改，请登陆系统查阅详细信息！");
		else if (confirmFlag == MpmCONST.MPM_CONFIRM_FLAG_CANNOT) {
			sendObj.setContentDesc(MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdyxa")
					+ campName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resName
					+ MpmLocaleUtil.getMessage("mcd.java.mytg")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrhghdybz")
					+ advice
					+ MpmLocaleUtil.getMessage("mcd.java.qdlxtcyxxx1"));
		}
		sendObj.setSendAddress(createUsermsisdn);
		// mpmSendForUnitouchService.sendSMSOnTime(sendObj);

		emailSendToCreateUser = sendObj.getContentDesc();

		// 发送邮件通知给策划人 added by wwl 2006-8-19
		if (createUserEmail != null && createUserEmail.length() > 1) {
			MtlApproveContentSend sendEmailObj = new MtlApproveContentSend();
			BeanUtils.copyProperties(sendEmailObj, sendObj);
			sendEmailObj.setSendAddress(createUserEmail);
			sendEmailObj.setApproveUserid(userId);
			sendEmailObj.setContentType(Short
					.valueOf(MpmCONST.APPROVE_SENDTYPE_EMAIL));
			emailSendToCreateUser = MpmHtmlHelper
					.genApproveEmailToCreateUser(createUserName,
							emailSendToCreateUser);
			sendEmailObj.setContentDesc(emailSendToCreateUser);
			sendEmailObj.setContentDesc2("");
			sendEmailObj.setContentId(null);
			// mpmSendForUnitouchService.sendEmailOnTime(sendEmailObj.getSendAddress(),
			// sendEmailObj.getContentDesc()+sendEmailObj.getContentDesc2());

		}

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bccc")
				+ e);

	}
	}

	// caihao add 用于批量活动确认的短信邮件提醒功能
	public void saveBatchConfirmSendContent(HttpServletRequest request,
		MpmCampsegApproveForm aForm, String userId, String startDate,
		String endDate) throws MpmException {

	try {
		IMpmSendForUnitouchService mpmSendForUnitouchService = (IMpmSendForUnitouchService) SystemServiceLocator
				.getInstance().getService("mpmSendForUnitouchService");

		short confirmFlag = aForm.getConfirmFlag().shortValue();
		String createUserid = aForm.getCreateUserid();
		String campsegId = aForm.getCampsegId();
		String resourceName = aForm.getResourceName();

		// 发送给策划者的邮件内容
		String emailSendToCreateUser = "";

		MtlCampSeginfo campseg = this.findCampsegInfo(campsegId);

		if (campseg == null) {
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.zbdhddxx"));
		}
		String campsegName = campseg.getCampsegName();

		// MtlCampBaseinfo campbase =
		// campDao.getCampaignBaseInfo(campsegId);
		// 取得策划人的手机号码，邮件地址，姓名
		String createUsermsisdn = "";
		String createUserEmail = "";
		String createUserName = "";
		// log.debug("2="+createUserid);
		IUser user = mpmUserPrivilegeService.getUser(createUserid);
		// log.debug("3="+createUserid);
		if (user != null) {
			createUsermsisdn = user.getMobilePhone();
			createUserEmail = user.getEmail();
			createUserName = user.getUsername();
		} else {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.xtzbczchyh")
					+ createUserid + "]");
		}
		if (StringUtil.isEmpty(createUsermsisdn)) {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh")
					+ createUserid
					+ MpmLocaleUtil.getMessage("mcd.java.mysdsjhmwf"));
		}
		if (StringUtil.isEmpty(createUserEmail)) {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh")
					+ createUserid
					+ MpmLocaleUtil.getMessage("mcd.java.mysdyjdzwf"));
		}

		// 取得确认人的用户姓名
		String currentAuditUserName = "";
		IUser auditUser = mpmUserPrivilegeService.getUser(userId);
		if (auditUser != null) {
			currentAuditUserName = auditUser.getUsername();
		} else {
			currentAuditUserName = userId;
		}
		MtlApproveContentSend sendObj = new MtlApproveContentSend();
		// MtlApproveContentSendId sendKey = new MtlApproveContentSendId();
		sendObj.setApproveReceiveNums(Short.valueOf("0"));
		sendObj.setServerIp(UserManager.getHostAddress());
		sendObj.setServerPort(String.valueOf(request.getServerPort()));
		// 填写审批通知内容表 如果是最后一级审批通知策划人
		sendObj.setApproveUserid(userId);
		sendObj.setCampId(aForm.getCampId());
		sendObj.setCampsegId(campsegId);
		sendObj.setContentType(Short.valueOf(MpmCONST.APPROVE_SENDTYPE_SMS));
		sendObj.setCreateUserid(createUserid);
		// sendObj.setId(sendKey);
		sendObj.setCreateTime(new Date());
		sendObj.setSendFlag(Integer.valueOf(0));
		sendObj.setSentTimes(Short.valueOf("0"));

		if (confirmFlag == MpmCONST.MPM_CONFIRM_FLAG_YES) {
			sendObj.setContentDesc(MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdhd")
					+ campsegName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resourceName
					+ MpmLocaleUtil.getMessage("mcd.java.yjtg")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrqrhkssj")
					+ startDate
					+ MpmLocaleUtil.getMessage("mcd.java.qrhjssj")
					+ endDate + MpmLocaleUtil.getMessage("mcd.java.qryjw"));
		}
		// else if(approveResult ==
		// MpmCONST.MPM_SEG_APPROVE_RESULT_NOTPASSED)
		// sendObj.setContentDesc("您提交审批的活动[" + campsegName + "]没通过[" +
		// currentAuditUserName + "]的审批，需要整改，请登陆系统查阅详细信息！");
		else if (confirmFlag == MpmCONST.MPM_CONFIRM_FLAG_CANNOT) {
			sendObj.setContentDesc(MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdhd")
					+ campsegName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resourceName
					+ MpmLocaleUtil.getMessage("mcd.java.mytg1")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrhghdybz1")
					+ MpmLocaleUtil.getMessage("mcd.java.qdlxtcyxxx"));
		}
		sendObj.setSendAddress(createUsermsisdn);

		// mpmSendForUnitouchService.sendSMSOnTime(sendObj);

		emailSendToCreateUser = sendObj.getContentDesc();

		// 发送邮件通知给策划人 added by wwl 2006-8-19
		if (createUserEmail != null && createUserEmail.length() > 1) {
			MtlApproveContentSend sendEmailObj = new MtlApproveContentSend();
			BeanUtils.copyProperties(sendEmailObj, sendObj);
			sendEmailObj.setSendAddress(createUserEmail);
			sendEmailObj.setApproveUserid(userId);
			sendEmailObj.setContentType(Short
					.valueOf(MpmCONST.APPROVE_SENDTYPE_EMAIL));
			emailSendToCreateUser = MpmHtmlHelper
					.genApproveEmailToCreateUser(createUserName,
							emailSendToCreateUser);
			sendEmailObj.setContentDesc(emailSendToCreateUser);
			sendEmailObj.setContentDesc2("");
			sendEmailObj.setContentId(null);

			// mpmSendForUnitouchService.sendEmailOnTime(sendEmailObj.getSendAddress(),
			// sendEmailObj.getContentDesc()+sendEmailObj.getContentDesc2());
		}

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bccc")
				+ e);

	}
	}

	// caihao add 用于批量营销案确认的短信邮件提醒功能
	public void saveBatchCampConfirmSendContent(HttpServletRequest request,
		MpmCampsegApproveForm aForm, String userId, Double custNums,
		int rptScore, String resourceName) throws MpmException {

	try {
		IMpmSendForUnitouchService mpmSendForUnitouchService = (IMpmSendForUnitouchService) SystemServiceLocator
				.getInstance().getService("mpmSendForUnitouchService");

		short confirmFlag = aForm.getConfirmFlag().shortValue();
		String createUserid = aForm.getCreateUserid();
		String campsegId = aForm.getCampsegId();
		// String advice = aForm.getApproveAdv();
		// if(advice==null||advice.equals("")) advice="无";
		// 发送给策划者的邮件内容
		String emailSendToCreateUser = "";

		MtlCampBaseinfo campseg = this.findCampBaseInfo(campsegId);

		if (campseg == null) {
			throw new MpmException(
					MpmLocaleUtil.getMessage("mcd.java.zbdyxadxx"));
		}
		String campsegName = campseg.getCampName();

		// MtlCampBaseinfo campbase =
		// campDao.getCampaignBaseInfo(campsegId);
		// 取得策划人的手机号码，邮件地址，姓名
		String createUsermsisdn = "";
		String createUserEmail = "";
		String createUserName = "";
		// log.debug("2="+createUserid);
		IUser user = mpmUserPrivilegeService.getUser(createUserid);
		// log.debug("3="+createUserid);
		if (user != null) {
			createUsermsisdn = user.getMobilePhone();
			createUserEmail = user.getEmail();
			createUserName = user.getUsername();
		} else {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.xtzbczchyh")
					+ createUserid + "]");
		}
		if (StringUtil.isEmpty(createUsermsisdn)) {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh")
					+ createUserid
					+ MpmLocaleUtil.getMessage("mcd.java.mysdsjhmwf"));
		}
		if (StringUtil.isEmpty(createUserEmail)) {
			log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh")
					+ createUserid
					+ MpmLocaleUtil.getMessage("mcd.java.mysdyjdzwf"));
		}

		// 取得确认人的用户姓名
		String currentAuditUserName = "";
		IUser auditUser = mpmUserPrivilegeService.getUser(userId);
		if (auditUser != null) {
			currentAuditUserName = auditUser.getUsername();
		} else {
			currentAuditUserName = userId;
		}

		MtlApproveContentSend sendObj = new MtlApproveContentSend();
		// MtlApproveContentSendId sendKey = new MtlApproveContentSendId();
		sendObj.setApproveReceiveNums(Short.valueOf("0"));
		sendObj.setServerIp(UserManager.getHostAddress());
		sendObj.setServerPort(String.valueOf(request.getServerPort()));
		// 填写审批通知内容表 如果是最后一级审批通知策划人
		sendObj.setApproveUserid(userId);
		sendObj.setCampId(campsegId);
		// sendObj.setCampsegId(campsegId);
		sendObj.setContentType(Short.valueOf(MpmCONST.APPROVE_SENDTYPE_SMS));
		sendObj.setCreateUserid(createUserid);
		// sendObj.setId(sendKey);
		sendObj.setCreateTime(new Date());
		sendObj.setSendFlag(Integer.valueOf(0));
		sendObj.setSentTimes(Short.valueOf("0"));

		if (confirmFlag == MpmCONST.MPM_CONFIRM_FLAG_YES) {
			// sendObj.setContentDesc("您提交确认的营销案[" + campsegName + "]已经通过["
			// + currentAuditUserName + "]的确认");
			sendObj.setContentDesc(MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdyxa")
					+ campsegName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resourceName
					+ MpmLocaleUtil.getMessage("mcd.java.yjtg")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrqrhdmbk1")
					+ custNums
					+ MpmLocaleUtil.getMessage("mcd.java.wrpfjg")
					+ rptScore + MpmLocaleUtil.getMessage("mcd.java.qryjw"));
		}
		// else if(approveResult ==
		// MpmCONST.MPM_SEG_APPROVE_RESULT_NOTPASSED)
		// sendObj.setContentDesc("您提交审批的活动[" + campsegName + "]没通过[" +
		// currentAuditUserName + "]的审批，需要整改，请登陆系统查阅详细信息！");
		else if (confirmFlag == MpmCONST.MPM_CONFIRM_FLAG_CANNOT) {
			sendObj.setContentDesc(MpmLocaleUtil
					.getMessage("mcd.java.ntjqrdyxa")
					+ campsegName
					+ MpmLocaleUtil.getMessage("mcd.java.dzy")
					+ resourceName
					+ MpmLocaleUtil.getMessage("mcd.java.mytg")
					+ currentAuditUserName
					+ MpmLocaleUtil.getMessage("mcd.java.dqrhgyxayb"));
		}
		sendObj.setSendAddress(createUsermsisdn);

		// mpmSendForUnitouchService.sendSMSOnTime(sendObj);

		emailSendToCreateUser = sendObj.getContentDesc();

		// 发送邮件通知给策划人 added by wwl 2006-8-19
		if (createUserEmail != null && createUserEmail.length() > 1) {
			MtlApproveContentSend sendEmailObj = new MtlApproveContentSend();
			BeanUtils.copyProperties(sendEmailObj, sendObj);
			sendEmailObj.setSendAddress(createUserEmail);
			sendEmailObj.setApproveUserid(userId);
			sendEmailObj.setContentType(Short
					.valueOf(MpmCONST.APPROVE_SENDTYPE_EMAIL));
			emailSendToCreateUser = MpmHtmlHelper
					.genApproveEmailToCreateUser(createUserName,
							emailSendToCreateUser);
			sendEmailObj.setContentDesc(emailSendToCreateUser);
			sendEmailObj.setContentDesc2("");
			sendEmailObj.setContentId(null);

			// mpmSendForUnitouchService.sendEmailOnTime(sendEmailObj.getSendAddress(),
			// sendEmailObj.getContentDesc()+sendEmailObj.getContentDesc2());

		}

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(MpmLocaleUtil.getMessage("mcd.java.bccc")
				+ e);

	}
	}

	// caihao add 执行状态更改时发短信邮件通知功能
	
	* public void saveSendOddContent(HttpServletRequest request, MpmSendOddForm
	* aForm, String userId, String message) throws MpmException {
	* 
	* try { IMpmSendForUnitouchService mpmSendForUnitouchService =
	* (IMpmSendForUnitouchService
	* )SystemServiceLocator.getInstance().getService(
	* "mpmSendForUnitouchService");
	* 
	* String createUserid = aForm.getCreateUserid(); String campsegId =
	* aForm.getCampsegId();
	* 
	* // 发送给策划者的邮件内容 String emailSendToCreateUser = "";
	* 
	* MtlCampSeginfo campseg = this.findCampsegInfo(campsegId);
	* 
	* if (campseg == null){ throw new
	* MpmException(MpmLocaleUtil.getMessage("mcd.java.zbdhddxx")); } String
	* campsegName = campseg.getCampsegName();
	* 
	* // MtlCampBaseinfo campbase = campDao.getCampaignBaseInfo(campsegId);
	* //取得策划人的手机号码，邮件地址，姓名 String createUsermsisdn = ""; String createUserEmail
	* = ""; String createUserName = ""; //log.debug("2="+createUserid); IUser
	* user = mpmUserPrivilegeService.getUser(createUserid);
	* //log.debug("3="+createUserid); if (user != null) { createUsermsisdn =
	* user.getMobilePhone(); createUserEmail = user.getEmail(); createUserName
	* = user.getUsername(); } else{
	* log.debug(MpmLocaleUtil.getMessage("mcd.java.xtzbczchyh") + createUserid
	* + "]"); } if (StringUtil.isEmpty(createUsermsisdn)){
	* log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh") + createUserid +
	* MpmLocaleUtil.getMessage("mcd.java.mysdsjhmwf")); } if
	* (StringUtil.isEmpty(createUserEmail)){
	* log.debug(MpmLocaleUtil.getMessage("mcd.java.chyh") + createUserid +
	* MpmLocaleUtil.getMessage("mcd.java.mysdyjdzwf")); }
	* 
	* //取得确认人的用户姓名 String currentAuditUserName = ""; IUser auditUser =
	* mpmUserPrivilegeService.getUser(userId); if (auditUser != null){
	* currentAuditUserName = auditUser.getUsername(); } else{
	* currentAuditUserName = userId; }
	* 
	* MtlApproveContentSend sendObj = new MtlApproveContentSend(); //
	* MtlApproveContentSendId sendKey = new MtlApproveContentSendId();
	* sendObj.setApproveReceiveNums(Short.valueOf("0"));
	* sendObj.setServerIp(UserManager.getHostAddress());
	* sendObj.setServerPort(String.valueOf(request.getServerPort()));
	* 
	* sendObj.setApproveUserid(userId); sendObj.setCampId(aForm.getCampId());
	* sendObj.setCampsegId(campsegId);
	* sendObj.setContentType(Short.valueOf(MpmCONST.APPROVE_SENDTYPE_SMS));
	* sendObj.setCreateUserid(createUserid); // sendObj.setId(sendKey);
	* sendObj.setCreateTime(new Date());
	* sendObj.setSendFlag(Integer.valueOf(0));
	* sendObj.setSentTimes(Short.valueOf("0"));
	* 
	* // if(confirmFlag == MpmCONST.MPM_CONFIRM_FLAG_YES)
	* sendObj.setContentDesc(MpmLocaleUtil.getMessage("mcd.java.ntjqrdhd") +
	* campsegName + MpmLocaleUtil.getMessage("mcd.java.yjy") +
	* currentAuditUserName + "]" + message); // else if(approveResult ==
	* MpmCONST.MPM_SEG_APPROVE_RESULT_NOTPASSED) //
	* sendObj.setContentDesc("您提交审批的活动[" + campsegName + "]没通过[" +
	* currentAuditUserName + "]的审批，需要整改，请登陆系统查阅详细信息！"); // else if(confirmFlag
	* == MpmCONST.MPM_CONFIRM_FLAG_CANNOT) //
	* sendObj.setContentDesc("您提交确认的活动[" + campsegName + "]没有通过[" +
	* currentAuditUserName + "]的确认或该活动已被终止，请登陆系统查阅详细信息！");
	* sendObj.setSendAddress(createUsermsisdn); //
	* mpmSendForUnitouchService.sendSMSOnTime(sendObj);
	* 
	* emailSendToCreateUser = sendObj.getContentDesc();
	* 
	* //发送邮件通知给策划人 added by wwl 2006-8-19 if (createUserEmail != null &&
	* createUserEmail.length() > 1) { MtlApproveContentSend sendEmailObj = new
	* MtlApproveContentSend(); BeanUtils.copyProperties(sendEmailObj, sendObj);
	* sendEmailObj.setSendAddress(createUserEmail);
	* sendEmailObj.setApproveUserid(userId);
	* sendEmailObj.setContentType(Short.valueOf
	* (MpmCONST.APPROVE_SENDTYPE_EMAIL)); emailSendToCreateUser =
	* MpmHtmlHelper.genApproveEmailToCreateUser(createUserName,
	* emailSendToCreateUser);
	* sendEmailObj.setContentDesc(emailSendToCreateUser);
	* sendEmailObj.setContentDesc2(""); sendEmailObj.setContentId(null); //
	* mpmSendForUnitouchService.sendEmailOnTime(sendEmailObj.getSendAddress(),
	* sendEmailObj.getContentDesc()+sendEmailObj.getContentDesc2());
	* 
	* }
	* 
	* } catch (Exception e) { log.error("", e); throw new
	* MpmException(MpmLocaleUtil.getMessage("mcd.java.bccc") + e);
	* 
	* } }
	
	
	* public Map findConfirmedCampsegInfo(MtlCampSeginfo segInfo, final Integer
	* curPage, final Integer pageSize) throws MpmException { try { return
	* campsegDao.findConfirmedCampsegInfo(segInfo, curPage, pageSize); } catch
	* (Exception e) { log.error("", e); throw new
	* MpmException(MpmLocaleUtil.getMessage("mcd.java.cxyhyjqrgd")); } }
	

	
	* public Map findConfirmedCampInfo(MtlCampBaseinfo campInfo, final Integer
	* curPage, final Integer pageSize) throws MpmException { try { return
	* campbaseDao.findConfirmedCampInfo(campInfo, curPage, pageSize); } catch
	* (Exception e) { log.error("", e); throw new
	* MpmException(MpmLocaleUtil.getMessage("mcd.java.cxyhyjqrgd1")); } }
	

	// caihao add 查找需要确认的营销活动
	public List findAllNeedConfirm(String approveUserids) throws MpmException {
	List list = new ArrayList();
	List list_campbaseinfo = null;
	List list_appconfirmlist = null;
	try {
		MtlApproveConfirmList approverList = new MtlApproveConfirmList();
		list_appconfirmlist = approveConfirmListDao
				.findByUserFlag(approveUserids);
		if (list_appconfirmlist == null) {
			return null;
		}
		Iterator it = list_appconfirmlist.iterator();
		String campsegIdsNeedConfirm = "";
		while (it.hasNext()) {
			approverList = (MtlApproveConfirmList) it.next();
			campsegIdsNeedConfirm += "'"
					+ approverList.getId().getCampsegId() + "',";
		}
		if (campsegIdsNeedConfirm.length() > 0) {
			campsegIdsNeedConfirm = campsegIdsNeedConfirm.substring(0,
					campsegIdsNeedConfirm.length() - 1);
		}
		// modified end

		list_campbaseinfo = campsegDao
				.findAllCampsegNeedConfirm(campsegIdsNeedConfirm);

		list.add(list_campbaseinfo);
		list.add(list_appconfirmlist);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.hdxyqrzyhd") + e);
	}

	return list;
	}

	// caihao add 查找需要确认的营销案
	public List findAllNeedConfirmCamp(String approveUserids)
		throws MpmException {
	List list = new ArrayList();
	List list_campbaseinfo = null;
	List list_appconfirmlist = null;
	try {
		MtlApproveConfirmList approverList = new MtlApproveConfirmList();
		list_appconfirmlist = approveConfirmListDao
				.findByUserFlag(approveUserids);
		if (list_appconfirmlist == null) {
			return null;
		}
		Iterator it = list_appconfirmlist.iterator();
		String campsegIdsNeedConfirm = "";
		while (it.hasNext()) {
			approverList = (MtlApproveConfirmList) it.next();
			campsegIdsNeedConfirm += "'"
					+ approverList.getId().getCampsegId() + "',";
		}
		if (campsegIdsNeedConfirm.length() > 0) {
			campsegIdsNeedConfirm = campsegIdsNeedConfirm.substring(0,
					campsegIdsNeedConfirm.length() - 1);
		}
		// modified end
		list_campbaseinfo = campbaseDao.findAllCampNeedApprove(
				campsegIdsNeedConfirm, null);
		list.add(list_campbaseinfo);
		list.add(list_appconfirmlist);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.hdxyqrzyhd") + e);
	}

	return list;
	}

	// caihao add 查找已经确认的营销活动
	public List findAllConfirmed(String approveUserids) throws MpmException {
	List arrayList = new ArrayList();
	List list = null;// campbaseinfo
	List list1 = null;// Object
	try {
		MtlApproveConfirmList approverList = new MtlApproveConfirmList();

		list1 = approveConfirmListDao
				.findConfirmedByUserFlag(approveUserids);

		String campsegIdsNeedApprove = "";
		for (int i = 0; i < list1.size(); i++) {
			Object[] obj = (Object[]) list1.get(i);

			campsegIdsNeedApprove += "'" + (String) obj[0] + "',";
		}
		if (campsegIdsNeedApprove.length() > 0) {
			campsegIdsNeedApprove = campsegIdsNeedApprove.substring(0,
					campsegIdsNeedApprove.length() - 1);
		}
		// modified end

		// list = this.campDao
		// .findAllCampsegNeedApprove(campsegIdsNeedApprove);
		list = campsegDao.findAllCampsegNeedConfirm(campsegIdsNeedApprove);

		arrayList.add(list);
		arrayList.add(list1);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.hdxyqrzyhd") + e);
	}

	return arrayList;
	}

	// caihao add 查找已经确认的营销案
	public List findAllConfirmedCamp(String approveUserids, String subject)
		throws MpmException {
	List arrayList = new ArrayList();
	List list = null;// campbaseinfo
	List list1 = null;// Object
	try {
		MtlApproveConfirmList approverList = new MtlApproveConfirmList();

		list1 = approveConfirmListDao
				.findConfirmedByUserFlag(approveUserids);

		String campsegIdsNeedApprove = "";
		for (int i = 0; i < list1.size(); i++) {
			Object[] obj = (Object[]) list1.get(i);

			campsegIdsNeedApprove += "'" + (String) obj[0] + "',";
		}
		if (campsegIdsNeedApprove.length() > 0) {
			campsegIdsNeedApprove = campsegIdsNeedApprove.substring(0,
					campsegIdsNeedApprove.length() - 1);
		}
		// modified end

		// list = this.campDao
		// .findAllCampsegNeedApprove(campsegIdsNeedApprove);
		list = campbaseDao.findAllCampNeedApprove(campsegIdsNeedApprove,
				subject);

		arrayList.add(list);
		arrayList.add(list1);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.hdxyqrzyhd") + e);
	}

	return arrayList;
	}

	// caihao add 所有营销活动确认完毕后，判断是否更改活动状态以及更改营销活动确认状态
	public void doAllConfirmFinished(String campId, String campsegId,
		String userId, String port) {
	try {
		MtlCampSeginfo mcs = campsegDao.getCampSegInfo(campsegId);
		IMpmCampsegApproveService aService = (IMpmCampsegApproveService) SystemServiceLocator
				.getInstance().getService(
						MpmCONST.CAMPSEG_APPROVE_SERVICE_BEAN_ID);
		short confirmFlag = MpmCONST.MPM_CONFIRM_FLAG_YES;
		int appflag = mcs.getApproveResult().intValue();

		if (appflag != MpmCONST.MPM_SEG_APPROVE_NEEDLESS) {// 活动有内部审批步骤
			IMpmHandChgStatusSvc service = (IMpmHandChgStatusSvc) SystemServiceLocator
					.getInstance().getService(
							MpmCONST.HAND_CHGSTATUS_SERVICE_BEAN_ID);
			MtlCampSeginfo obj = campsegDao.getCampSegInfo(campsegId);
			// 如果审批已通过则修改活动状态为执行
			Short flag = obj.getApproveResult();
			if (flag.intValue() == MpmCONST.MPM_SEG_APPROVE_RESULT_PASSED) {
				// 修改mtl_camp_seginfo的 campseg_stat_id字段
				service.updateCampSeg(campsegId,
						MpmCONST.MPM_CAMPSEG_STAT_ZXZT);
			}

		} else {// 活动没有内部审批步骤
			String campseg_stat = MpmCONST.MPM_CAMPSEG_STAT_ZXZT;
			// campsegDao.updateCampsegStatus("", campsegId,
			// Short.valueOf(campseg_stat));
			campsegDao.updateAllCampsegStatus("", campsegId,
					MpmCONST.MPM_CAMPSEG_STAT_ZXZT);
		}
		campsegDao.updateCampsegConfirmFlag(campsegId, confirmFlag);
		// 修改活动步骤状态
		progressDao
				.updateCampsegProgressFlag(
						campsegId,
						null,
						new Short[] { Short
								.valueOf(MpmCONST.MPM_SYS_ACTSTEP_DEF_CHANNEL_AUDIT) },
						Short.valueOf("1"));
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.qrwchgghdz") + e);
	}
	}

	public void updateCampsegConfirmFlag(String campsegId, Short confirmFlag)
		throws MpmException {

	try {
		campsegDao.updateCampsegConfirmFlag(campsegId,
				confirmFlag.shortValue());

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.gxspjgcc") + e);
	}
	}

	// caolifeng add
	public String findConfirmCampForCalendar(String approveUserids)
		throws Exception {
	// campConfirm:[{campId:'xxxxxxx',name:'xxxxxx',updateDate:'2010-7-22',extendCustNums:'xx',extendRptScore:'xxx'}],
	FastDateFormat sdf = FastDateFormat.getInstance("yyyy-MM-dd");
	StringBuffer sb = new StringBuffer();
	sb.append("campConfirm:[");
	IMtlConfirmService confirmservice = (IMtlConfirmService) SystemServiceLocator
			.getInstance().getService(MpmCONST.MTL_CONFIRM_SERVICE);
	try {
		MtlApproveConfirmList approverList = new MtlApproveConfirmList();
		List approveConfirmCampList = approveConfirmListDao
				.findByUserFlag(approveUserids);
		Iterator it = approveConfirmCampList.iterator();
		String if_show_score = MpmConfigure.getInstance()
				.getProperty("IF_SHOW_SCORE").toLowerCase();
		while (it.hasNext()) {
			approverList = (MtlApproveConfirmList) it.next();
			String campsegIdsNeedConfirm = "'"
					+ approverList.getId().getCampsegId() + "'";
			// 下面方法需要改为根据id查对象
			List list = campbaseDao.findAllCampNeedApprove(
					campsegIdsNeedConfirm, null);

			if (list != null && list.size() > 0) {
				Object[] objs = (Object[]) list.get(0);
				sb.append("{campId:'" + objs[0] + "',");
				sb.append("name:'" + objs[1] + "',");
				Integer resourceId = approverList.getId().getResourceId();
				String flag = confirmservice.checkResourceType(resourceId);
				if (flag.equals("channel")) {
					List list1 = confirmservice.getConfirmExtendInfo(
							approverList.getId().getCampsegId(),
							resourceId, null, null, null);
					if (list1 != null && list1.size() > 0) {
						MtlConfirmExtendInfo mcei = (MtlConfirmExtendInfo) list1
								.get(0);
						sb.append("extendCustNums:'"
								+ mcei.getCustNums().toString() + "',");
						if ("1".equals(if_show_score)) {
							if (mcei.getRptScore() != null
									&& mcei.getRptScore().toString()
											.length() > 0) {
								sb.append("extendRptScore:'"
										+ mcei.getRptScore().toString()
										+ "',");
							} else {
								sb.append("extendRptScore:'0',");
							}
						} else {
							sb.append("extendRptScore:'0',");
						}
					} else {
						sb.append("extendCustNums:'0',");
						sb.append("extendRptScore:'0',");
					}
				}
				sb.append("updateDate:'"
						+ sdf.format(approverList.getConfirmTime()) + "'}");
				sb.append(",");
			}
		}

	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.hdxyqrzyhd") + e);
	}
	if (',' == sb.charAt(sb.length() - 1)) {
		sb = sb.deleteCharAt(sb.length() - 1);
	}
	sb.append("]");
	return sb.toString();
	}

	public void updateCampsegConfirmFlag(String campsegId, Integer resourceId,
		String confirmFlag) throws Exception {

	try {
		approveConfirmListDao.updateCampsegConfirmFlag(campsegId,
				resourceId, confirmFlag);
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.gxspjgcc") + e);
	}
	}

	// caolifeng add
	public String findConfirmCampsegForCalendar(String approveUserids)
		throws Exception {
	StringBuffer sb = new StringBuffer();
	FastDateFormat sdf = FastDateFormat.getInstance("yyyy-MM-dd");
	sb.append("campsegConfirm:[");
	IMpmCampSegInfoService segservice = (IMpmCampSegInfoService) SystemServiceLocator
			.getInstance().getService(MpmCONST.CAMPAIGN_SEG_INFO_SERVICE);
	IMtlConfirmService confirmservice = (IMtlConfirmService) SystemServiceLocator
			.getInstance().getService(MpmCONST.MTL_CONFIRM_SERVICE);
	IMpmCampBaseInfoService baseService = (IMpmCampBaseInfoService) SystemServiceLocator
			.getInstance().getService(MpmCONST.CAMPAIGN_BASE_INFO_SERVICE);
	try {
		MtlApproveConfirmList approverList = new MtlApproveConfirmList();
		List list_appconfirmlist = approveConfirmListDao
				.findByUserFlag(approveUserids);
		// Iterator it = list_appconfirmlist.iterator();
		// String campsegIdsNeedConfirm = "";
		// while (it.hasNext()) {
		// approverList = (MtlApproveConfirmList) it.next();
		// campsegIdsNeedConfirm += "'" +
		// approverList.getId().getCampsegId() + "',";
		// }
		// if (campsegIdsNeedConfirm.length() > 0)
		// campsegIdsNeedConfirm = campsegIdsNeedConfirm.substring(0,
		// campsegIdsNeedConfirm.length() - 1);
		// //modified end
		//
		// list_campbaseinfo =
		// this.campsegDao.findAllCampsegNeedConfirm(campsegIdsNeedConfirm);
		//
		// list.add(list_campbaseinfo);
		// list.add(list_appconfirmlist);
		Iterator it = list_appconfirmlist.iterator();
		while (it.hasNext()) {

			approverList = (MtlApproveConfirmList) it.next();
			String campsegId = approverList.getId().getCampsegId();
			MtlCampSeginfo seginfo = segservice.getCampSegInfo(campsegId);
			// MtlCampBaseinfo mcb=
			// baseService.getCampaignBaseInfo(campsegId);
			if (seginfo != null) {
				sb.append("{name:'" + seginfo.getCampsegName() + "',");
				// campId campsegId flowId createUserid publicizeCombid
				// channeltypeId
				// channelId resourceId
				String campId = seginfo.getCampId();
				sb.append("campId:'" + campId + "',");
				sb.append("campsegId:'" + campsegId + "',");
				sb.append("flowId:'" + seginfo.getApproveFlowid() + "',");
				sb.append("createUserid:'" + seginfo.getCreateUserid()
						+ "',");
				// 如何获取？
				sb.append("publicizeCombid:'"
						+ seginfo.getPublicizeCombId() + "',");

				Integer resourceId = approverList.getId().getResourceId();
				sb.append("resourceId:'" + resourceId + "',");
				String flag = confirmservice.checkResourceType(resourceId);
				if (flag.equals("channel")) {
					DimChannelUserRelation dcur = confirmservice
							.getChannelTypeId(resourceId, null, "1");
					if (dcur != null && dcur.getId() != null) {
						Short channeltypeId = dcur.getId()
								.getChanneltypeId();
						sb.append("channeltypeId:'"
								+ channeltypeId.toString() + "',");
						MtlCampChanneltype mcct = confirmservice
								.getChanneltypeByNo(channeltypeId, campId,
										String.valueOf(approverList.getId()
												.getChannelNo()));
						if (mcct != null) {
							String channelId = mcct.getId().getChannelId();
							sb.append("channelId:'" + channelId + "',");
						}
					}
				}
				sb.append("updateDate:'"
						+ sdf.format(approverList.getConfirmTime()) + "'}");
				sb.append(",");
			}
		}
	} catch (Exception e) {
		log.error("", e);
		throw new MpmException(
				MpmLocaleUtil.getMessage("mcd.java.hdxyqrzyhd") + e);
	}
	if (',' == sb.charAt(sb.length() - 1)) {
		sb = sb.deleteCharAt(sb.length() - 1);
	}
	sb.append("]");
	return sb.toString();
	}

	public com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao getChannelUserDao() {
	return channelUserDao;
	}

	public void setChannelUserDao(
		com.ai.bdx.frame.approval.dao.IDimChannelUserRelationDao channelUserDao) {
	this.channelUserDao = channelUserDao;
	}

	public IMtlCampChanneltypeDao getChanneltypeDao() {
	return channeltypeDao;
	}

	public void setChanneltypeDao(IMtlCampChanneltypeDao channeltypeDao) {
	this.channeltypeDao = channeltypeDao;
	}

	public IMtlConfirmExtendInfoDao getConfirmExtendInfoDao() {
	return confirmExtendInfoDao;
	}

	public void setConfirmExtendInfoDao(
		IMtlConfirmExtendInfoDao confirmExtendInfoDao) {
	this.confirmExtendInfoDao = confirmExtendInfoDao;
	}



	public IMtlApproveConfirmListDao getApproveConfirmListDao() {
	return approveConfirmListDao;
	}

	public void setApproveConfirmListDao(
		IMtlApproveConfirmListDao approveConfirmListDao) {
	this.approveConfirmListDao = approveConfirmListDao;
	}

	public IMtlApproveFlowDefDao getApproveFlowDefDao() {
	return approveFlowDefDao;
	}

	public void setApproveFlowDefDao(IMtlApproveFlowDefDao approveFlowDefDao) {
	this.approveFlowDefDao = approveFlowDefDao;
	}

	public IMtlApproveContentSendDao getSendDao() {
	return sendDao;
	}

	public void setSendDao(IMtlApproveContentSendDao sendDao) {
	this.sendDao = sendDao;
	}

	public IMpmCampSegInfoDao getCampsegDao() {
	return campsegDao;
	}

	public void setCampsegDao(IMpmCampSegInfoDao campsegDao) {
	this.campsegDao = campsegDao;
	}

	public IMpmCampBaseInfoDao getCampbaseDao() {
	return campbaseDao;
	}

	public void setCampbaseDao(IMpmCampBaseInfoDao campbaseDao) {
	this.campbaseDao = campbaseDao;
	}

	public IMtlApproveLevelDefDao getMtlApproveLevelDefDao() {
	return mtlApproveLevelDefDao;
	}

	public void setMtlApproveLevelDefDao(
		IMtlApproveLevelDefDao mtlApproveLevelDefDao) {
	this.mtlApproveLevelDefDao = mtlApproveLevelDefDao;
	}

	public IMpmApproveRelationDao getRelationDao() {
	return relationDao;
	}

	public void setRelationDao(IMpmApproveRelationDao relationDao) {
	this.relationDao = relationDao;
	}

	public IMpmUserPrivilegeService getMpmUserPrivilegeService() {
	return mpmUserPrivilegeService;
	}

	public void setMpmUserPrivilegeService(
		IMpmUserPrivilegeService mpmUserPrivilegeService) {
	this.mpmUserPrivilegeService = mpmUserPrivilegeService;
	}

	*//**
		* @return progressDao
		*/
	/*
	public IMtlCampsegProgressDao getProgressDao() {
	return progressDao;
	}

	*//**
		* @param progressDao
		*            要设置的 progressDao
		*/
	/*
	public void setProgressDao(IMtlCampsegProgressDao progressDao) {
	this.progressDao = progressDao;
	}

	public List findAllConfirmedCamp(String approveUserids) throws MpmException {
	// TODO Auto-generated method stub
	return null;
	}

	public void deleteCampsegConfirmList(String campsegId) throws MpmException {
	try {
		approveConfirmListDao.deleteByCampsegid(campsegId);
	} catch (Exception e) {
		log.error("", e);
	}
	}

	public Short getFirstApproveSeq(String campsegId, String flowId,
		Integer resourceId) throws MpmException {
	Short seq = Short.valueOf((short) -1);
	MtlApproveConfirmList approver = approveConfirmListDao
			.getFirstApprover(campsegId, flowId, resourceId);
	if (approver != null) {
		seq = approver.getId().getApproveSeq();
	}

	return seq;
	}

	public MtlApproveConfirmList getApproveConfirmList(String campsegId,
		String flowId, String userId, Integer resourceId)
		throws MpmException {
	return approveConfirmListDao.getApproveConfirmList(campsegId, flowId,
			userId, resourceId,
			Short.valueOf(MpmCONST.MPM_APPROVE_TOKEN_NOT_HOLD));
	}

	public MtlApproveConfirmList getApproveCurrentConfirmList(String campsegId,
		String flowId, String userId, Integer resourceId)
		throws MpmException {
	return approveConfirmListDao.getApproveConfirmList(campsegId, flowId,
			userId, resourceId,
			Short.valueOf(MpmCONST.MPM_APPROVE_TOKEN_HOLD));
	}

	public List<MtlApproveConfirmList> findByCampsegIdUserId(String campsegId,
		String userId) {
	try {
		return approveConfirmListDao.findByCampsegIdUserId(campsegId,
				userId);
	} catch (Exception e) {
		log.error("", e);
		return null;
	}
	}

	*//**
		* 发送请示短信
		* */
	/*
	@Override
	public boolean saveAndSubmitConsutltText(String campsegId,
	String consutltText) {
	boolean flag = true;
	try {
	// 1.插入历史表LOC_MTL_REQUEST_CONTENT
	LocMtlRequestContent locMtlRequestContent = new LocMtlRequestContent();
	locMtlRequestContent.setCampsegId(campsegId);
	locMtlRequestContent.setContent(consutltText);
	locMtlRequestContentDao
			.saveLocMtlRequestContent(locMtlRequestContent);
	// 2.插入短信接口表
	if ("0".equals(MpmConfigure.getInstance()
			.getProperty("REMIND_TYPE"))) { // 默认方式
		// 插入表
		log.warn("插入短信表BS_SMS_PUSH_R..");
		List<SmsMessageFlowId> msgList = new ArrayList<SmsMessageFlowId>();
		// 获取手机号码
		List<LocMtlRequestPhoneList> list = locMtlRequestPhoneListDAO
				.findAll();
		for (LocMtlRequestPhoneList proNo : list) {
			SmsMessageFlowId messageId = new SmsMessageFlowId();
			messageId.setMsg(consutltText);// 短信内容
			messageId.setProductNo(proNo.getProductNo());
			msgList.add(messageId);
		}
		smsMessageService.saveSMSFlowBatch(msgList);
	}

	} catch (Exception e) {
	log.error("", e);
	flag = false;
	}
	return flag;
	}

	*//**
		* 得到历史请示短信
		* */
	/*
	@Override
	public String getConsutltHisText(String campsegId) {
	String consutltHisText = "";
	try {
	StringBuffer str = new StringBuffer();
	List<LocMtlRequestContent> list = locMtlRequestContentDao
			.getLocMtlRequestContentList(campsegId);
	int i = 1;
	for (LocMtlRequestContent locMtlRequestContent : list) {
		str.append("NO." + i + ":" + locMtlRequestContent.getContent()
				+ ";");
		str.append("</br>");
		i++;
	}
	consutltHisText = str.toString();
	} catch (Exception e) {
	log.error("", e);
	}
	return consutltHisText;
	}

	@Override
	public String getConsutltHisTextLast(String campsegId) {
	String consutltHisText = "";
	try {
	StringBuffer str = new StringBuffer();
	List<LocMtlRequestContent> list = locMtlRequestContentDao
			.getLocMtlRequestContentList(campsegId);
	int i = 1;
	for (LocMtlRequestContent locMtlRequestContent : list) {
		if (i == list.size()) {
			str.append("NO." + i + ":"
					+ locMtlRequestContent.getContent() + ";");
		}
		i++;
	}
	consutltHisText = str.toString();
	} catch (Exception e) {
	log.error("", e);
	}
	return consutltHisText;
	}

	*//**
		* 云南-活动确认前短信请示功能 支持变量有：(变量在程序里实现)，展示模板内容时，如果模板里出现了不支持的变更，跳过，用空格代替。
		* ${send_time:发送时间}, ${channel_camp_content:营销用语}，
		* ${target_customers_name:客户群名称}， ${targer_user_nums:目标客户群数目},
		* ${city_name:活动策划人分公司}
		* 
		* */
	/*
	@Override
	public String getCampSegConsultText(int i, String campsegId)
	throws MpmException {
	String lastSendContent = "";
	try {
	MtlCampSeginfo campsegInfo = campSegInfoDao
			.getCampSegInfo(campsegId);
	String strResult = mtlRequrestTempleteDao.getCampSegConsultText(i);
	MtlCampsegCiCustgroup mtlCampsegCiCustgroup = mtlCampsegCiCustDao
			.findByCampsegId(campsegId);
	lastSendContent = strResult;
	// 获取营销用语变量
	String[] campContentVars = NbsJmsPublishUtil
			.parseReplaceCharacter(strResult);
	if (ArrayUtils.isNotEmpty(campContentVars)) {
		for (int j = 0; j < campContentVars.length; j++) {
			if ("send_time".equals(campContentVars[j])) {
				String time;
				StringBuffer timeAll = new StringBuffer();
				List<MtlCampExecTime> timeList = mtlCampExecTimeDao
						.getMtlCampExecTimeListByCode(campsegId);
				for (int a = 0; a < timeList.size(); a++) {
					time = timeList.get(a).getExecTime().toString();
					SimpleDateFormat sdf = new SimpleDateFormat(
							"yyyy-MM-dd");
					Date d = sdf.parse(time.toString());
					timeAll.append(sdf.format(d) + " "
							+ campsegInfo.getTimeRange());
					if (a != timeList.size() - 1) {
						timeAll.append("|");
					}
				}
				if (StringUtils.isNotEmpty(timeAll.toString())) {
					lastSendContent = lastSendContent.replaceFirst(
							"\\$\\{send_time\\}", timeAll.toString());

				}
			} else if ("channel_camp_content"
					.equals(campContentVars[j])) {
				List<MtlChannelDef> savedChannelList = mtlChannelDefDao
						.findMtlChannelDef(campsegId);
				MtlChannelDef savedChannelDef = null;
				if (CollectionUtils.isNotEmpty(savedChannelList)) {
					savedChannelDef = savedChannelList.get(0);
				}
				if (savedChannelDef != null) {
					String channelCampContent = savedChannelDef
							.getChannelCampContent();
					lastSendContent = lastSendContent.replaceFirst(
							"\\$\\{channel_camp_content\\}",
							channelCampContent);
				}

			} else if ("target_customers_name"
					.equals(campContentVars[j])) {
				String custgroupName = mtlCampsegCiCustgroup
						.getCustgroupName();
				if (StringUtils.isNotEmpty(custgroupName)) {
					lastSendContent = lastSendContent.replaceFirst(
							"\\$\\{target_customers_name\\}",
							custgroupName);
				}
			} else if ("targer_user_nums".equals(campContentVars[j])) {
				String custgroupNum = mtlCampsegCiCustgroup
						.getCustgroupNumber().toString();
				if (StringUtils.isNotEmpty(custgroupNum)) {
					lastSendContent = lastSendContent.replaceFirst(
							"\\$\\{targer_user_nums\\}", custgroupNum);
				}
			} else if ("city_name".equals(campContentVars[j])) {
				IUser user = mpmUserPrivilegeService
						.getUser(campsegInfo.getCreateUserid());
				String cityName = mpmUserPrivilegeService
						.getUserActualCity(user.getCityid())
						.getCityName();
				if (StringUtils.isNotEmpty(cityName)) {
					lastSendContent = lastSendContent.replaceFirst(
							"\\$\\{city_name\\}", cityName);
				}
			} else {
				lastSendContent = lastSendContent.replaceFirst(
						campContentVars[j], " ");
			}
		}
	}

	} catch (Exception e) {
	log.error("获取指示短信内容发生异常：", e);
	throw new MpmException("获取指示短信内容发生异常（campsegId=" + campsegId + "）",
			e);
	}
	return lastSendContent;
	}

	public List<MtlApproveConfirmAppoint> getApproveConfirmAppointList() {
	try {
	return approveConfirmListDao.getApproveConfirmAppointList();
	} catch (Exception e) {
	log.error("", e);
	return null;
	}
	}

	public void confirmDelegrate(String campsegId, String userId,
	String delegrateUserId, String delegrateAdvise) throws Exception {
	approveConfirmListDao.updateApprover(campsegId, userId,
		delegrateUserId, delegrateAdvise);
	;
	}

	*/
}

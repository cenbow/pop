package com.ai.bdx.frame.approval.service.impl;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.ai.bdx.frame.approval.dao.ISmsMessageFlowDao;
import com.ai.bdx.frame.approval.model.SmsMessageFlowId;
import com.ai.bdx.frame.approval.service.ISmsMessageService;
import com.ai.bdx.frame.approval.util.MpmConfigure;
import com.ai.bdx.frame.approval.util.MpmUtil;

public class SmsMessageServiceImpl implements ISmsMessageService {

	private ISmsMessageFlowDao smsMessageDao;

	public ISmsMessageFlowDao getSmsMessageDao() {
		return smsMessageDao;
	}

	public void setSmsMessageDao(ISmsMessageFlowDao smsMessageDao) {
		this.smsMessageDao = smsMessageDao;
	}

	@Override
	public void saveSMSFlow(SmsMessageFlowId smsMessage) throws Exception {
		setBean(smsMessage);
		smsMessageDao.saveSMSFlow(smsMessage);
	}

	@Override
	public void saveSMSFlowBatch(List<SmsMessageFlowId> msgList) throws Exception {
		for(int i=0;i<msgList.size();i++){
			setBean(msgList.get(i));
		}
		smsMessageDao.saveSMSFlowBatch(msgList);
	}

	@Override
	public List getCustNumber() throws Exception {
		return smsMessageDao.getCustNumber();
	}

	/**
	 * ID生成器
	 * @param phoneNo
	 * @return
	 */
	private synchronized long nextId(String phoneNo){
		Calendar calendar = Calendar.getInstance();
		Date now = calendar.getTime();
		return  now.getTime() + calendar.get(Calendar.MILLISECOND)
				+ Long.valueOf(phoneNo.substring(phoneNo.length()-4))
				+ Long.valueOf(MpmUtil.genFixLenNumStr(6));
	}

	/**
	 * 设置默认属性
	 * @param smsMessage
	 */
	private void setBean(SmsMessageFlowId smsMessage){
		smsMessage.setFlag(Short.valueOf("0"));
		smsMessage.setSendtype("IMCD");

		smsMessage.setId(nextId(smsMessage.getProductNo()));
		smsMessage.setTaskId(MpmConfigure.getInstance().getProperty("BS_TASK_ID"));
		smsMessage.setChannelId("SMS1");
		smsMessage.setStatus(0);
		smsMessage.setSendCount(0);
		Date now = new Date();
		smsMessage.setCreateTime(new Timestamp(now.getTime()));
		smsMessage.setUpdateTime(new Timestamp(now.getTime()));
	}
}

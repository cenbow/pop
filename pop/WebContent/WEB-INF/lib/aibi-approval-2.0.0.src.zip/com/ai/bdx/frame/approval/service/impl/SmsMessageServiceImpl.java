/*    */ package com.ai.bdx.frame.approval.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.dao.ISmsMessageFlowDao;
/*    */ import com.ai.bdx.frame.approval.model.SmsMessageFlowId;
/*    */ import com.ai.bdx.frame.approval.service.ISmsMessageService;
/*    */ import com.ai.bdx.frame.approval.util.MpmConfigure;
/*    */ import com.ai.bdx.frame.approval.util.MpmUtil;
/*    */ import java.sql.Timestamp;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SmsMessageServiceImpl
/*    */   implements ISmsMessageService
/*    */ {
/*    */   private ISmsMessageFlowDao smsMessageDao;
/*    */ 
/*    */   public ISmsMessageFlowDao getSmsMessageDao()
/*    */   {
/* 19 */     return this.smsMessageDao;
/*    */   }
/*    */ 
/*    */   public void setSmsMessageDao(ISmsMessageFlowDao smsMessageDao) {
/* 23 */     this.smsMessageDao = smsMessageDao;
/*    */   }
/*    */ 
/*    */   public void saveSMSFlow(SmsMessageFlowId smsMessage) throws Exception
/*    */   {
/* 28 */     setBean(smsMessage);
/* 29 */     this.smsMessageDao.saveSMSFlow(smsMessage);
/*    */   }
/*    */ 
/*    */   public void saveSMSFlowBatch(List<SmsMessageFlowId> msgList) throws Exception
/*    */   {
/* 34 */     for (int i = 0; i < msgList.size(); i++) {
/* 35 */       setBean((SmsMessageFlowId)msgList.get(i));
/*    */     }
/* 37 */     this.smsMessageDao.saveSMSFlowBatch(msgList);
/*    */   }
/*    */ 
/*    */   public List getCustNumber() throws Exception
/*    */   {
/* 42 */     return this.smsMessageDao.getCustNumber();
/*    */   }
/*    */ 
/*    */   private synchronized long nextId(String phoneNo)
/*    */   {
/* 51 */     Calendar calendar = Calendar.getInstance();
/* 52 */     Date now = calendar.getTime();
/* 53 */     return now.getTime() + calendar.get(14) + Long.valueOf(phoneNo.substring(phoneNo.length() - 4)).longValue() + Long.valueOf(MpmUtil.genFixLenNumStr(6)).longValue();
/*    */   }
/*    */ 
/*    */   private void setBean(SmsMessageFlowId smsMessage)
/*    */   {
/* 63 */     smsMessage.setFlag(Short.valueOf("0"));
/* 64 */     smsMessage.setSendtype("IMCD");
/*    */ 
/* 66 */     smsMessage.setId(nextId(smsMessage.getProductNo()));
/* 67 */     smsMessage.setTaskId(MpmConfigure.getInstance().getProperty("BS_TASK_ID"));
/* 68 */     smsMessage.setChannelId("SMS1");
/* 69 */     smsMessage.setStatus(0);
/* 70 */     smsMessage.setSendCount(0);
/* 71 */     Date now = new Date();
/* 72 */     smsMessage.setCreateTime(new Timestamp(now.getTime()));
/* 73 */     smsMessage.setUpdateTime(new Timestamp(now.getTime()));
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.service.impl.SmsMessageServiceImpl
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class ApprovalCONST
/*    */ {
/*    */   public static final String FLOW_TYPE_CONFIRM = "2";
/*    */   public static final String FLOW_TYPE_APPROVL = "1";
/* 11 */   public static final Integer APPROVE_TOKEN_NOT_HOLD = Integer.valueOf(0);
/*    */ 
/* 13 */   public static final Integer APPROVE_TOKEN_HOLD = Integer.valueOf(1);
/*    */ 
/* 16 */   private static HashMap<String, String> flowTypeMap = new HashMap();
/* 17 */   private static HashMap<String, String> approveFlagMap = new HashMap();
/*    */   public static final String APPROVE_FLAG_FALSE = "0";
/*    */   public static final String APPROVE_FLAG_TRUE = "1";
/*    */   public static final String APPROVE_FLOW_ID_BY_OA = "-1";
/*    */   public static final String APPROVE_SERVICE = "approvalServcie";
/*    */   public static final String APPROVE_LEVEL_HAS = "1";
/*    */   public static final String APPROVE_LEVEL_NEXTHAS = "2";
/*    */   public static final String APPROVE_LEVEL_OVER = "3";
/*    */   public static final short MPM_APPROVE_OBJ_TYPE_SELF_DEPT = 1;
/*    */   public static final short MPM_APPROVE_OBJ_TYPE_APPOINT_DEPT = 2;
/*    */   public static final short MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER = 3;
/*    */   public static final short MPM_APPROVE_OBJ_TYPE_TOPN_DEPT = 4;
/*    */   public static final String APPROVDRVDIMTABLE_CHANGJING = "1";
/*    */   public static final String APPROVDRVDIMTABLE_YEWU = "2";
/*    */   public static final String FLOW_MODEL_ONE = "flow_0001";
/*    */   public static final String FLOW_MODEL_TWO = "flow_0002";
/*    */   public static final String FLOW_MODEL_THREE = "flow_0003";
/*    */   public static final String FLOW_MODEL_FOUR = "flow_0004";
/*    */   public static final String APPROVE_FLAG_ZERO = "0";
/*    */   public static final String APPROVE_FLAG_ONE = "1";
/*    */   public static final String APPROVE_FLAG_TWO = "2";
/*    */   public static final String APPROVE_FLAG_NINE = "9";
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 20 */     System.out.print(getFlowTypeDesc("1"));
/*    */   }
/*    */ 
/*    */   public static String getApproveFlagDesc(String flowType, String approveFlag)
/*    */   {
/* 26 */     initMap();
/* 27 */     return ((String)approveFlagMap.get(approveFlag)).replace("{#}", (CharSequence)flowTypeMap.get(flowType));
/*    */   }
/*    */   public static String getFlowTypeDesc(String flowType) {
/* 30 */     initMap();
/* 31 */     return (String)flowTypeMap.get(flowType);
/*    */   }
/*    */ 
/*    */   private static void initMap()
/*    */   {
/* 76 */     flowTypeMap.put("2", "确认");
/* 77 */     flowTypeMap.put("1", "审批");
/*    */ 
/* 79 */     approveFlagMap.put("0", "待{#}");
/* 80 */     approveFlagMap.put("1", "{#}通过");
/* 81 */     approveFlagMap.put("2", "{#}不通过");
/* 82 */     approveFlagMap.put("9", "{#}终止");
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.ApprovalCONST
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.util;

import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.asiainfo.biframe.privilege.IMenuItem;
public class DataMock {

	private static final Logger log = LogManager.getLogger();

	public List<IMenuItem> getMenueData() {
		class MenuItemVo implements IMenuItem {
			Integer menuItemId;
			String url;
			String title;

			public MenuItemVo(int menuItemId, String title, String url) {
				this.menuItemId = menuItemId;
				this.url = url;
				this.title = title;
			}

			public Integer getAccessToken() {
				return null;
			}

			public String getApplicationId() {
				return null;
			}

			public Integer getMenuItemId() {
				return menuItemId;
			}

			public String getMenuItemTitle() {
				return title;
			}

			public Integer getMenuType() {
				return null;
			}

			public Integer getParentId() {
				return null;
			}

			public String getResId() {
				return null;
			}

			public Integer getResourceType() {
				return null;
			}

			public String getUrl() {
				return url;
			}

			public String getUrlPort() {
				return null;
			}

			public String getUrlTarget() {
				return null;
			}

			public String getOperationType() {
				return null;
			}

			public Integer getSortNum() {
				return null;
			}

			public boolean isFolderOrNot() {
				return false;
			}

			public String getPic1() {
				return null;
			}

			public String getPic2() {
				return null;
			}
		}
		List<IMenuItem> list = new ArrayList<IMenuItem>();
		list.add(new MenuItemVo(90055826, MpmLocaleUtil
				.getMessage("mcd.java.khqgl"), "/mpm/custGroup.jsp"));
		list.add(new MenuItemVo(90055827, MpmLocaleUtil
				.getMessage("mcd.java.yxach"), "/mpm/camp.jsp"));
		list.add(new MenuItemVo(90055828, MpmLocaleUtil
				.getMessage("mcd.java.yxhdch"), "/mpm/campSeg.jsp"));
		list.add(new MenuItemVo(90055829, MpmLocaleUtil
				.getMessage("mcd.java.yxsp"), "/mpm/approve.jsp"));
		list.add(new MenuItemVo(90055835, MpmLocaleUtil
				.getMessage("mcd.java.yxqr"), "/mpm/confirm.jsp"));
		list.add(new MenuItemVo(90055839, MpmLocaleUtil
				.getMessage("mcd.java.pdzx"), "/mpm/sendodd.jsp"));
		list.add(new MenuItemVo(90055840, MpmLocaleUtil
				.getMessage("mcd.java.yxcx"), "/mpm/query.jsp"));
		list.add(new MenuItemVo(90055854, MpmLocaleUtil
				.getMessage("mcd.java.yxgl"), "/mpm/manage.jsp"));
		list.add(new MenuItemVo(90055877, MpmLocaleUtil
				.getMessage("mcd.java.yxpg"), "/mpm/evaluate.jsp"));
		log.debug("_______________" + list.size());
		return list;
	}

	public List<IMenuItem> getAllMenu(String menuId) {
		List<IMenuItem> list = new ArrayList<IMenuItem>();

		if (menuId.equals("91")) {
			return getMenueData();
		}
		if (menuId.equals("")) {

		}

		return list;
	}

}

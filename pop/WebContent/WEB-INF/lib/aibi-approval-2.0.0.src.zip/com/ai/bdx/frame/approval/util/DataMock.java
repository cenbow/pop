/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class DataMock
/*     */ {
/*  11 */   private static final Logger log = LogManager.getLogger();
/*     */ 
/*     */   public List<IMenuItem> getMenueData()
/*     */   {
/*  89 */     List list = new ArrayList();
/*  90 */     list.add(new IMenuItem()
/*     */     {
/*     */       Integer menuItemId;
/*     */       String url;
/*     */       String title;
/*     */ 
/*     */       public Integer getAccessToken()
/*     */       {
/*  26 */         return null;
/*     */       }
/*     */ 
/*     */       public String getApplicationId() {
/*  30 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getMenuItemId() {
/*  34 */         return this.menuItemId;
/*     */       }
/*     */ 
/*     */       public String getMenuItemTitle() {
/*  38 */         return this.title;
/*     */       }
/*     */ 
/*     */       public Integer getMenuType() {
/*  42 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getParentId() {
/*  46 */         return null;
/*     */       }
/*     */ 
/*     */       public String getResId() {
/*  50 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getResourceType() {
/*  54 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrl() {
/*  58 */         return this.url;
/*     */       }
/*     */ 
/*     */       public String getUrlPort() {
/*  62 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrlTarget() {
/*  66 */         return null;
/*     */       }
/*     */ 
/*     */       public String getOperationType() {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getSortNum() {
/*  74 */         return null;
/*     */       }
/*     */ 
/*     */       public boolean isFolderOrNot() {
/*  78 */         return false;
/*     */       }
/*     */ 
/*     */       public String getPic1() {
/*  82 */         return null;
/*     */       }
/*     */ 
/*     */       public String getPic2() {
/*  86 */         return null;
/*     */       }
/*     */     });
/*  92 */     list.add(new IMenuItem()
/*     */     {
/*     */       Integer menuItemId;
/*     */       String url;
/*     */       String title;
/*     */ 
/*     */       public Integer getAccessToken()
/*     */       {
/*  26 */         return null;
/*     */       }
/*     */ 
/*     */       public String getApplicationId() {
/*  30 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getMenuItemId() {
/*  34 */         return this.menuItemId;
/*     */       }
/*     */ 
/*     */       public String getMenuItemTitle() {
/*  38 */         return this.title;
/*     */       }
/*     */ 
/*     */       public Integer getMenuType() {
/*  42 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getParentId() {
/*  46 */         return null;
/*     */       }
/*     */ 
/*     */       public String getResId() {
/*  50 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getResourceType() {
/*  54 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrl() {
/*  58 */         return this.url;
/*     */       }
/*     */ 
/*     */       public String getUrlPort() {
/*  62 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrlTarget() {
/*  66 */         return null;
/*     */       }
/*     */ 
/*     */       public String getOperationType() {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getSortNum() {
/*  74 */         return null;
/*     */       }
/*     */ 
/*     */       public boolean isFolderOrNot() {
/*  78 */         return false;
/*     */       }
/*     */ 
/*     */       public String getPic1() {
/*  82 */         return null;
/*     */       }
/*     */ 
/*     */       public String getPic2() {
/*  86 */         return null;
/*     */       }
/*     */     });
/*  94 */     list.add(new IMenuItem()
/*     */     {
/*     */       Integer menuItemId;
/*     */       String url;
/*     */       String title;
/*     */ 
/*     */       public Integer getAccessToken()
/*     */       {
/*  26 */         return null;
/*     */       }
/*     */ 
/*     */       public String getApplicationId() {
/*  30 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getMenuItemId() {
/*  34 */         return this.menuItemId;
/*     */       }
/*     */ 
/*     */       public String getMenuItemTitle() {
/*  38 */         return this.title;
/*     */       }
/*     */ 
/*     */       public Integer getMenuType() {
/*  42 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getParentId() {
/*  46 */         return null;
/*     */       }
/*     */ 
/*     */       public String getResId() {
/*  50 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getResourceType() {
/*  54 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrl() {
/*  58 */         return this.url;
/*     */       }
/*     */ 
/*     */       public String getUrlPort() {
/*  62 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrlTarget() {
/*  66 */         return null;
/*     */       }
/*     */ 
/*     */       public String getOperationType() {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getSortNum() {
/*  74 */         return null;
/*     */       }
/*     */ 
/*     */       public boolean isFolderOrNot() {
/*  78 */         return false;
/*     */       }
/*     */ 
/*     */       public String getPic1() {
/*  82 */         return null;
/*     */       }
/*     */ 
/*     */       public String getPic2() {
/*  86 */         return null;
/*     */       }
/*     */     });
/*  96 */     list.add(new IMenuItem()
/*     */     {
/*     */       Integer menuItemId;
/*     */       String url;
/*     */       String title;
/*     */ 
/*     */       public Integer getAccessToken()
/*     */       {
/*  26 */         return null;
/*     */       }
/*     */ 
/*     */       public String getApplicationId() {
/*  30 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getMenuItemId() {
/*  34 */         return this.menuItemId;
/*     */       }
/*     */ 
/*     */       public String getMenuItemTitle() {
/*  38 */         return this.title;
/*     */       }
/*     */ 
/*     */       public Integer getMenuType() {
/*  42 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getParentId() {
/*  46 */         return null;
/*     */       }
/*     */ 
/*     */       public String getResId() {
/*  50 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getResourceType() {
/*  54 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrl() {
/*  58 */         return this.url;
/*     */       }
/*     */ 
/*     */       public String getUrlPort() {
/*  62 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrlTarget() {
/*  66 */         return null;
/*     */       }
/*     */ 
/*     */       public String getOperationType() {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getSortNum() {
/*  74 */         return null;
/*     */       }
/*     */ 
/*     */       public boolean isFolderOrNot() {
/*  78 */         return false;
/*     */       }
/*     */ 
/*     */       public String getPic1() {
/*  82 */         return null;
/*     */       }
/*     */ 
/*     */       public String getPic2() {
/*  86 */         return null;
/*     */       }
/*     */     });
/*  98 */     list.add(new IMenuItem()
/*     */     {
/*     */       Integer menuItemId;
/*     */       String url;
/*     */       String title;
/*     */ 
/*     */       public Integer getAccessToken()
/*     */       {
/*  26 */         return null;
/*     */       }
/*     */ 
/*     */       public String getApplicationId() {
/*  30 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getMenuItemId() {
/*  34 */         return this.menuItemId;
/*     */       }
/*     */ 
/*     */       public String getMenuItemTitle() {
/*  38 */         return this.title;
/*     */       }
/*     */ 
/*     */       public Integer getMenuType() {
/*  42 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getParentId() {
/*  46 */         return null;
/*     */       }
/*     */ 
/*     */       public String getResId() {
/*  50 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getResourceType() {
/*  54 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrl() {
/*  58 */         return this.url;
/*     */       }
/*     */ 
/*     */       public String getUrlPort() {
/*  62 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrlTarget() {
/*  66 */         return null;
/*     */       }
/*     */ 
/*     */       public String getOperationType() {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getSortNum() {
/*  74 */         return null;
/*     */       }
/*     */ 
/*     */       public boolean isFolderOrNot() {
/*  78 */         return false;
/*     */       }
/*     */ 
/*     */       public String getPic1() {
/*  82 */         return null;
/*     */       }
/*     */ 
/*     */       public String getPic2() {
/*  86 */         return null;
/*     */       }
/*     */     });
/* 100 */     list.add(new IMenuItem()
/*     */     {
/*     */       Integer menuItemId;
/*     */       String url;
/*     */       String title;
/*     */ 
/*     */       public Integer getAccessToken()
/*     */       {
/*  26 */         return null;
/*     */       }
/*     */ 
/*     */       public String getApplicationId() {
/*  30 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getMenuItemId() {
/*  34 */         return this.menuItemId;
/*     */       }
/*     */ 
/*     */       public String getMenuItemTitle() {
/*  38 */         return this.title;
/*     */       }
/*     */ 
/*     */       public Integer getMenuType() {
/*  42 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getParentId() {
/*  46 */         return null;
/*     */       }
/*     */ 
/*     */       public String getResId() {
/*  50 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getResourceType() {
/*  54 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrl() {
/*  58 */         return this.url;
/*     */       }
/*     */ 
/*     */       public String getUrlPort() {
/*  62 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrlTarget() {
/*  66 */         return null;
/*     */       }
/*     */ 
/*     */       public String getOperationType() {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getSortNum() {
/*  74 */         return null;
/*     */       }
/*     */ 
/*     */       public boolean isFolderOrNot() {
/*  78 */         return false;
/*     */       }
/*     */ 
/*     */       public String getPic1() {
/*  82 */         return null;
/*     */       }
/*     */ 
/*     */       public String getPic2() {
/*  86 */         return null;
/*     */       }
/*     */     });
/* 102 */     list.add(new IMenuItem()
/*     */     {
/*     */       Integer menuItemId;
/*     */       String url;
/*     */       String title;
/*     */ 
/*     */       public Integer getAccessToken()
/*     */       {
/*  26 */         return null;
/*     */       }
/*     */ 
/*     */       public String getApplicationId() {
/*  30 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getMenuItemId() {
/*  34 */         return this.menuItemId;
/*     */       }
/*     */ 
/*     */       public String getMenuItemTitle() {
/*  38 */         return this.title;
/*     */       }
/*     */ 
/*     */       public Integer getMenuType() {
/*  42 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getParentId() {
/*  46 */         return null;
/*     */       }
/*     */ 
/*     */       public String getResId() {
/*  50 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getResourceType() {
/*  54 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrl() {
/*  58 */         return this.url;
/*     */       }
/*     */ 
/*     */       public String getUrlPort() {
/*  62 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrlTarget() {
/*  66 */         return null;
/*     */       }
/*     */ 
/*     */       public String getOperationType() {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getSortNum() {
/*  74 */         return null;
/*     */       }
/*     */ 
/*     */       public boolean isFolderOrNot() {
/*  78 */         return false;
/*     */       }
/*     */ 
/*     */       public String getPic1() {
/*  82 */         return null;
/*     */       }
/*     */ 
/*     */       public String getPic2() {
/*  86 */         return null;
/*     */       }
/*     */     });
/* 104 */     list.add(new IMenuItem()
/*     */     {
/*     */       Integer menuItemId;
/*     */       String url;
/*     */       String title;
/*     */ 
/*     */       public Integer getAccessToken()
/*     */       {
/*  26 */         return null;
/*     */       }
/*     */ 
/*     */       public String getApplicationId() {
/*  30 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getMenuItemId() {
/*  34 */         return this.menuItemId;
/*     */       }
/*     */ 
/*     */       public String getMenuItemTitle() {
/*  38 */         return this.title;
/*     */       }
/*     */ 
/*     */       public Integer getMenuType() {
/*  42 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getParentId() {
/*  46 */         return null;
/*     */       }
/*     */ 
/*     */       public String getResId() {
/*  50 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getResourceType() {
/*  54 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrl() {
/*  58 */         return this.url;
/*     */       }
/*     */ 
/*     */       public String getUrlPort() {
/*  62 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrlTarget() {
/*  66 */         return null;
/*     */       }
/*     */ 
/*     */       public String getOperationType() {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getSortNum() {
/*  74 */         return null;
/*     */       }
/*     */ 
/*     */       public boolean isFolderOrNot() {
/*  78 */         return false;
/*     */       }
/*     */ 
/*     */       public String getPic1() {
/*  82 */         return null;
/*     */       }
/*     */ 
/*     */       public String getPic2() {
/*  86 */         return null;
/*     */       }
/*     */     });
/* 106 */     list.add(new IMenuItem()
/*     */     {
/*     */       Integer menuItemId;
/*     */       String url;
/*     */       String title;
/*     */ 
/*     */       public Integer getAccessToken()
/*     */       {
/*  26 */         return null;
/*     */       }
/*     */ 
/*     */       public String getApplicationId() {
/*  30 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getMenuItemId() {
/*  34 */         return this.menuItemId;
/*     */       }
/*     */ 
/*     */       public String getMenuItemTitle() {
/*  38 */         return this.title;
/*     */       }
/*     */ 
/*     */       public Integer getMenuType() {
/*  42 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getParentId() {
/*  46 */         return null;
/*     */       }
/*     */ 
/*     */       public String getResId() {
/*  50 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getResourceType() {
/*  54 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrl() {
/*  58 */         return this.url;
/*     */       }
/*     */ 
/*     */       public String getUrlPort() {
/*  62 */         return null;
/*     */       }
/*     */ 
/*     */       public String getUrlTarget() {
/*  66 */         return null;
/*     */       }
/*     */ 
/*     */       public String getOperationType() {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       public Integer getSortNum() {
/*  74 */         return null;
/*     */       }
/*     */ 
/*     */       public boolean isFolderOrNot() {
/*  78 */         return false;
/*     */       }
/*     */ 
/*     */       public String getPic1() {
/*  82 */         return null;
/*     */       }
/*     */ 
/*     */       public String getPic2() {
/*  86 */         return null;
/*     */       }
/*     */     });
/* 108 */     log.debug("_______________" + list.size());
/* 109 */     return list;
/*     */   }
/*     */ 
/*     */   public List<IMenuItem> getAllMenu(String menuId) {
/* 113 */     List list = new ArrayList();
/*     */ 
/* 115 */     if (menuId.equals("91")) {
/* 116 */       return getMenueData();
/*     */     }
/* 118 */     if (menuId.equals(""));
/* 122 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.DataMock
 * JD-Core Version:    0.6.2
 */
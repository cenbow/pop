/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.string.StringUtil;
/*    */ import java.text.DateFormat;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import org.apache.commons.beanutils.Converter;
/*    */ import org.apache.commons.lang.time.FastDateFormat;
/*    */ 
/*    */ public class DateConvert
/*    */   implements Converter
/*    */ {
/* 18 */   private static String dateFormatStr = "yyyy-MM-dd";
/* 19 */   private static FastDateFormat dateTimeFormat = FastDateFormat.getInstance(dateFormatStr);
/*    */ 
/* 21 */   private static String dateLongFormatStr = dateFormatStr + " HH:mm:ss";
/* 22 */   private static FastDateFormat dateTimeLongFormat = FastDateFormat.getInstance(dateLongFormatStr);
/*    */ 
/*    */   public Object convert(Class arg0, Object arg1) {
/* 25 */     if (arg1 == null) {
/* 26 */       return null;
/*    */     }
/* 28 */     String className = arg1.getClass().getName();
/*    */ 
/* 30 */     if ("java.sql.Timestamp".equalsIgnoreCase(className)) {
/*    */       try {
/* 32 */         DateFormat df = new SimpleDateFormat(dateFormatStr + " HH:mm:ss");
/* 33 */         return df.parse(dateTimeLongFormat.format(arg1));
/*    */       } catch (Exception e) {
/*    */         try {
/* 36 */           DateFormat df = new SimpleDateFormat(dateFormatStr);
/* 37 */           return df.parse(dateTimeFormat.format(arg1));
/*    */         } catch (ParseException ex) {
/* 39 */           e.printStackTrace();
/* 40 */           return null;
/*    */         }
/*    */       }
/*    */     }
/* 44 */     String p = arg1 != null ? dateTimeLongFormat.format(arg1) : "";
/* 45 */     if (StringUtil.isEmpty(p))
/* 46 */       return null;
/*    */     try
/*    */     {
/* 49 */       DateFormat df = new SimpleDateFormat(dateFormatStr + " HH:mm:ss");
/* 50 */       return df.parse(p.trim());
/*    */     } catch (Exception e) {
/*    */       try {
/* 53 */         DateFormat df = new SimpleDateFormat(dateFormatStr);
/* 54 */         return df.parse(p.trim());
/*    */       } catch (ParseException ex) {
/* 56 */         e.printStackTrace(); } 
/* 57 */     }return null;
/*    */   }
/*    */ 
/*    */   public static String formatDateTime(Object obj)
/*    */   {
/* 64 */     if (obj != null) {
/* 65 */       return dateTimeFormat.format(obj);
/*    */     }
/* 67 */     return "";
/*    */   }
/*    */ 
/*    */   public static String formatLongDateTime(Object obj)
/*    */   {
/* 72 */     if (obj != null) {
/* 73 */       return dateTimeLongFormat.format(obj);
/*    */     }
/* 75 */     return "";
/*    */   }
/*    */ 
/*    */   public static java.sql.Date utilDate2sqlDate(java.util.Date srcDate)
/*    */   {
/* 80 */     return srcDate != null ? new java.sql.Date(srcDate.getTime()) : null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.DateConvert
 * JD-Core Version:    0.6.2
 */
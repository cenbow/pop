package com.ai.bdx.frame.approval.util;

import java.util.Map;

import jodd.util.StringUtil;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.service.IMpmCommonService;
import com.asiainfo.biframe.utils.spring.SystemServiceLocator;

public class DrvTypeUtil {

	
	private static Map<String,Map<String,String>> drvDimTableConMap;
	
	//Map<String,Map<String,String>> drvDimTableConMap=commonService.getMapApproveDrvDimTableCon();
	
	
	public static void init() throws Exception{
		IMpmCommonService commonService = (IMpmCommonService) SystemServiceLocator.getInstance().getService(MpmCONST.COMMON_SERVICE_BEAN_ID);
		Map<String,Map<String,String>> conMap=commonService.getMapApproveDrvDimTableCon();
		setDrvDimTableConMap(conMap);
	}

	public static Map<String, Map<String, String>> getDrvDimTableConMap() {
		return drvDimTableConMap;
	}

	public static void setDrvDimTableConMap(
			Map<String, Map<String, String>> drvDimTableConMap) {
		DrvTypeUtil.drvDimTableConMap = drvDimTableConMap;
	}

	
	public static String getVal(String tableID,String var_id){
		Map<String,Map<String,String>> map=getDrvDimTableConMap();
		String str="";
		if(StringUtil.isNotBlank(tableID)&&StringUtil.isNotBlank(var_id)){
			Map<String,String> cMap=map.get(tableID);
			if(cMap!=null){
				str=cMap.get(var_id);
			}else{
				str="--";
			}
		}else{
			str="--";
		}
		return str;
	}
}

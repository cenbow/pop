/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import com.ai.bdx.frame.approval.service.IMpmCommonService;
/*    */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*    */ import java.util.Map;
/*    */ import jodd.util.StringUtil;
/*    */ 
/*    */ public class DrvTypeUtil
/*    */ {
/*    */   private static Map<String, Map<String, String>> drvDimTableConMap;
/*    */ 
/*    */   public static void init()
/*    */     throws Exception
/*    */   {
/* 20 */     IMpmCommonService commonService = (IMpmCommonService)SystemServiceLocator.getInstance().getService("commonService");
/* 21 */     Map conMap = commonService.getMapApproveDrvDimTableCon();
/* 22 */     setDrvDimTableConMap(conMap);
/*    */   }
/*    */ 
/*    */   public static Map<String, Map<String, String>> getDrvDimTableConMap() {
/* 26 */     return drvDimTableConMap;
/*    */   }
/*    */ 
/*    */   public static void setDrvDimTableConMap(Map<String, Map<String, String>> drvDimTableConMap)
/*    */   {
/* 31 */     drvDimTableConMap = drvDimTableConMap;
/*    */   }
/*    */ 
/*    */   public static String getVal(String tableID, String var_id)
/*    */   {
/* 36 */     Map map = getDrvDimTableConMap();
/* 37 */     String str = "";
/* 38 */     if ((StringUtil.isNotBlank(tableID)) && (StringUtil.isNotBlank(var_id))) {
/* 39 */       Map cMap = (Map)map.get(tableID);
/* 40 */       if (cMap != null)
/* 41 */         str = (String)cMap.get(var_id);
/*    */       else
/* 43 */         str = "--";
/*    */     }
/*    */     else {
/* 46 */       str = "--";
/*    */     }
/* 48 */     return str;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.DrvTypeUtil
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ public class EncryptByte
/*    */ {
/*    */   public static String decrypt(String ssoToken)
/*    */   {
/*    */     try
/*    */     {
/* 27 */       String name = new String();
/* 28 */       StringTokenizer st = new StringTokenizer(ssoToken, "%");
/* 29 */       while (st.hasMoreElements()) {
/* 30 */         int asc = Integer.parseInt((String)st.nextElement()) - 27;
/* 31 */         name = name + (char)asc;
/*    */       }
/*    */ 
/* 34 */       return name;
/*    */     }
/*    */     catch (Exception e) {
/* 37 */       e.printStackTrace();
/* 38 */     }return null;
/*    */   }
/*    */ 
/*    */   public static String encrypt(String ssoToken)
/*    */   {
/*    */     try
/*    */     {
/* 51 */       byte[] _ssoToken = ssoToken.getBytes("ISO-8859-1");
/* 52 */       String name = new String();
/*    */ 
/* 54 */       for (int i = 0; i < _ssoToken.length; i++) {
/* 55 */         int asc = _ssoToken[i];
/* 56 */         _ssoToken[i] = ((byte)(asc + 27));
/* 57 */         name = name + (asc + 27) + "%";
/*    */       }
/*    */ 
/* 62 */       return name;
/*    */     }
/*    */     catch (Exception e) {
/* 65 */       e.printStackTrace();
/* 66 */     }return null;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 71 */     System.out.println(encrypt("13909290115"));
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.EncryptByte
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.sql.Timestamp;
/*    */ import org.apache.commons.beanutils.BeanUtils;
/*    */ import org.apache.commons.beanutils.ConvertUtils;
/*    */ 
/*    */ public class ExtBeanUtils extends BeanUtils
/*    */ {
/*    */   public static void copyProperties(Object dest, Object orig)
/*    */   {
/*    */     try
/*    */     {
/* 23 */       BeanUtils.copyProperties(dest, orig);
/*    */     } catch (IllegalAccessException ex) {
/* 25 */       ex.printStackTrace();
/*    */     } catch (InvocationTargetException ex) {
/* 27 */       ex.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 16 */     ConvertUtils.register(new DateConvert(), java.util.Date.class);
/* 17 */     ConvertUtils.register(new DateConvert(), java.sql.Date.class);
/* 18 */     ConvertUtils.register(new DateConvert(), Timestamp.class);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.ExtBeanUtils
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.util;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.time.FastDateFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ai.bdx.frame.approval.bean.LogInfoBean;
import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.utils.config.Configure;
import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
import com.asiainfo.biframe.utils.string.StringUtil;

public class LogUtil {
	private static Logger log = LogManager.getLogger();

	/**
	 * 该方法用于保存操作日志的记录到经分的操作表
	 * 
	 * @param hrequest
	 * @param desc
	 * @param userId
	 *
	 */

	public static void logOperate(HttpServletRequest hrequest, LogInfoBean lib) {

		String url = hrequest.getRequestURI();
		String query = hrequest.getQueryString();
		if (query != null && !"".equals(query)) {
			if (query.indexOf("&") > -1) {
				query = query.substring(0, query.indexOf("&"));
			}
			url = url.substring(hrequest.getContextPath().length()) + "?" + query;
		}
		log.debug("query url: " + url);

		FastDateFormat df = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
		String currentTime = df.format(new Date());// new Date()为获取当前系统时间
		try {
			IUserPrivilegeCommonService mpmUserPrivilegeService = (IUserPrivilegeCommonService) SystemServiceLocator
					.getInstance().getService(MpmCONST.MPM_USER_PRIVILEGE_SERVICE);
			IUser user = mpmUserPrivilegeService.getUser(lib.getUserId());
			// uol.setLogId(MpmUtil.convertLongMillsToYYYYMMDDHHMMSS(-1L));
			// uol.setSessionId(hrequest.getSession().getId());
			// uol.setOperatorId(lib.getUserId());
			// uol.setOperatorName(user.getUsername());
			// uol.setHostAddress(UserManager.getHostAddress());
			// uol.setClientAddress(getIpAddr(hrequest));
			// uol.setOperaterType(Integer.valueOf(lib.getOperaterType()));
			// uol.setResourceType(Integer.valueOf(lib.getResourceType()));
			// uol.setResourceId(lib.getResourceId());
			// uol.setResourceName(lib.getResourceName());
			// uol.setMsg(lib.getOperationDesc());

			String logFlag = Configure.getInstance().getProperty("LOG_FLAG");
			if ("true".equalsIgnoreCase(logFlag)) {

				log.debug("日志输出开始=======");
				log.debug(lib.getUserId());
				log.debug(lib.getOperaterType());
				log.debug(lib.getResourceId());
				log.debug(lib.getResourceName());
				log.debug(lib.getResourceType());
				log.debug(lib.getOperationDesc());
				log.debug("日志输出结束=======");

				// ILogService logService = new LogService();
				// logService.log(hrequest.getSession().getId(),
				// lib.getUserId(), user.getUsername(), lib.getOperaterType(),
				// lib.getResourceId(), lib.getResourceName(),
				// lib.getResourceType(), null, lib.getOperationDesc(), "",
				// null, null);
			}
		} catch (Exception e) {
			log.error("保存操作日志出错!", e);
		}

		// 保存操作记录：
		// logService.logIt(oper);
	}

	/**
	 * 获取请求IP地址
	 * 
	 * @param request
	 * @return
	 */
	public static String getIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (StringUtil.isEmpty(ip) || ("unknown".equalsIgnoreCase(ip))) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (StringUtil.isEmpty(ip) || ("unknown".equalsIgnoreCase(ip))) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (StringUtil.isEmpty(ip) || ("unknown".equalsIgnoreCase(ip))) {
			ip = request.getRemoteAddr();
		}
		String[] ips = null;
		if (StringUtil.isNotEmpty(ip)) {
			ips = ip.split(",");
			return ips[0];
		}
		return ip;
	}

	public String getSql2TimeStamp(String strDateStr, String strH, String strM, String strS) throws Exception {
		if (StringUtil.isEmpty(strDateStr)) {
			return null;
		}
		if (strDateStr.indexOf("0000-00-00") >= 0) {
			return "null";
		}
		String strType = Configure.getInstance().getProperty("MPM_DBTYPE");
		String strRet = "";
		if (strType.equalsIgnoreCase("MYSQL")) {
			strRet = (new StringBuilder()).append("'").append(strDateStr).append(" ").append(strH).append(":")
					.append(strM).append(":").append(strS).append("'").toString();
		} else if (strType.equalsIgnoreCase("DB2")) {
			strRet = (new StringBuilder()).append("timestamp('").append(strDateStr).append(" ").append(strH)
					.append(":").append(strM).append(":").append(strS).append("')").toString();
		} else if (strType.equalsIgnoreCase("ORACLE") || strType.equalsIgnoreCase("POSTGRESQL")) {
			strRet = (new StringBuilder()).append("to_date('").append(strDateStr).append(" ").append(strH).append(":")
					.append(strM).append(":").append(strS).append("','YYYY-mm-dd hh24:mi:ss')").toString();
		} else if (strType.equalsIgnoreCase("ACESS")) {
			strRet = (new StringBuilder()).append("'").append(strDateStr).append("'").toString();
		} else if (strType.equalsIgnoreCase("SQLSERVER")) {
			strRet = (new StringBuilder()).append("CONVERT(Datetime,'").append(strDateStr).append(" ").append(strH)
					.append(":").append(strM).append(":").append(strS).append("',20)").toString();
		} else if (strType.equalsIgnoreCase("TERA")) {
			strRet = (new StringBuilder()).append(strDateStr).append(" (FORMAT 'YYYY-MM-DD')").toString();
		} else if (strType.equalsIgnoreCase("SYBASE")) {
			strRet = (new StringBuilder()).append("cast('").append(strDateStr).append(" ").append(strH).append(":")
					.append(strM).append(":").append(strS).append("' as Datetime)").toString();
		} else {
			throw new Exception("can't get the current date of the function definition");
		}
		return strRet;
	}

}

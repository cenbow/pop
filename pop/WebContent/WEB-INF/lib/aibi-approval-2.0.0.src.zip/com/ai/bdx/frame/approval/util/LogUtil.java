/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.bean.LogInfoBean;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.Date;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang.time.FastDateFormat;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class LogUtil
/*     */ {
/*  20 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public static void logOperate(HttpServletRequest hrequest, LogInfoBean lib)
/*     */   {
/*  33 */     String url = hrequest.getRequestURI();
/*  34 */     String query = hrequest.getQueryString();
/*  35 */     if ((query != null) && (!"".equals(query))) {
/*  36 */       if (query.indexOf("&") > -1) {
/*  37 */         query = query.substring(0, query.indexOf("&"));
/*     */       }
/*  39 */       url = url.substring(hrequest.getContextPath().length()) + "?" + query;
/*     */     }
/*  41 */     log.debug("query url: " + url);
/*     */ 
/*  43 */     FastDateFormat df = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
/*  44 */     String currentTime = df.format(new Date());
/*     */     try {
/*  46 */       IUserPrivilegeCommonService mpmUserPrivilegeService = (IUserPrivilegeCommonService)SystemServiceLocator.getInstance().getService("userPrivilegeCommonService");
/*     */ 
/*  48 */       IUser user = mpmUserPrivilegeService.getUser(lib.getUserId());
/*     */ 
/*  61 */       String logFlag = Configure.getInstance().getProperty("LOG_FLAG");
/*  62 */       if ("true".equalsIgnoreCase(logFlag))
/*     */       {
/*  64 */         log.debug("日志输出开始=======");
/*  65 */         log.debug(lib.getUserId());
/*  66 */         log.debug(lib.getOperaterType());
/*  67 */         log.debug(lib.getResourceId());
/*  68 */         log.debug(lib.getResourceName());
/*  69 */         log.debug(lib.getResourceType());
/*  70 */         log.debug(lib.getOperationDesc());
/*  71 */         log.debug("日志输出结束=======");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  81 */       log.error("保存操作日志出错!", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getIpAddr(HttpServletRequest request)
/*     */   {
/*  95 */     String ip = request.getHeader("x-forwarded-for");
/*  96 */     if ((StringUtil.isEmpty(ip)) || ("unknown".equalsIgnoreCase(ip))) {
/*  97 */       ip = request.getHeader("Proxy-Client-IP");
/*     */     }
/*  99 */     if ((StringUtil.isEmpty(ip)) || ("unknown".equalsIgnoreCase(ip))) {
/* 100 */       ip = request.getHeader("WL-Proxy-Client-IP");
/*     */     }
/* 102 */     if ((StringUtil.isEmpty(ip)) || ("unknown".equalsIgnoreCase(ip))) {
/* 103 */       ip = request.getRemoteAddr();
/*     */     }
/* 105 */     String[] ips = null;
/* 106 */     if (StringUtil.isNotEmpty(ip)) {
/* 107 */       ips = ip.split(",");
/* 108 */       return ips[0];
/*     */     }
/* 110 */     return ip;
/*     */   }
/*     */ 
/*     */   public String getSql2TimeStamp(String strDateStr, String strH, String strM, String strS) throws Exception {
/* 114 */     if (StringUtil.isEmpty(strDateStr)) {
/* 115 */       return null;
/*     */     }
/* 117 */     if (strDateStr.indexOf("0000-00-00") >= 0) {
/* 118 */       return "null";
/*     */     }
/* 120 */     String strType = Configure.getInstance().getProperty("MPM_DBTYPE");
/* 121 */     String strRet = "";
/* 122 */     if (strType.equalsIgnoreCase("MYSQL")) {
/* 123 */       strRet = "'" + strDateStr + " " + strH + ":" + strM + ":" + strS + "'";
/*     */     }
/* 125 */     else if (strType.equalsIgnoreCase("DB2")) {
/* 126 */       strRet = "timestamp('" + strDateStr + " " + strH + ":" + strM + ":" + strS + "')";
/*     */     }
/* 128 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("POSTGRESQL"))) {
/* 129 */       strRet = "to_date('" + strDateStr + " " + strH + ":" + strM + ":" + strS + "','YYYY-mm-dd hh24:mi:ss')";
/*     */     }
/* 131 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 132 */       strRet = "'" + strDateStr + "'";
/* 133 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/* 134 */       strRet = "CONVERT(Datetime,'" + strDateStr + " " + strH + ":" + strM + ":" + strS + "',20)";
/*     */     }
/* 136 */     else if (strType.equalsIgnoreCase("TERA"))
/* 137 */       strRet = strDateStr + " (FORMAT 'YYYY-MM-DD')";
/* 138 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 139 */       strRet = "cast('" + strDateStr + " " + strH + ":" + strM + ":" + strS + "' as Datetime)";
/*     */     }
/*     */     else {
/* 142 */       throw new Exception("can't get the current date of the function definition");
/*     */     }
/* 144 */     return strRet;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.LogUtil
 * JD-Core Version:    0.6.2
 */
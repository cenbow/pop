package com.ai.bdx.frame.approval.util;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;

import com.asiainfo.biframe.utils.string.StringUtil;

public class Menu {

	/**
	 * 内部存储树型结构，一个Hashmap 关键字是父亲ID，其数据是一个Vector，Vector的?类型是MenuItem\
	 * 
	 * @seealso MenuItem
	 */
	private final Hashtable m_hashAllItems = new Hashtable(); //
	/**
	 * 本参数在显示树型结构的时候尤其重要，标记每一层需要的图片的名?
	 * ?而言，在层数?的数组元素的值是0的情况下显示正常图片，为1的情况下显示空白图片，注意不是空白?
	 */
	private final int m_NenuMask[] = new int[128]; // ?E可以支持树的高度?28
	// 根结点内部标识，对于显示无意?
	private static String ROOT_ID = "MR";
	// 是否在根层显示树型的图片
	private boolean m_bShowPicAtTheRoot = true;
	// 图片的根目录
	private String m_strPicRoot = "/images/menu/";
	// 默认的显示的图片
	private final String m_strPicFolderOpened = "img-folder-open.gif";
	private final String m_strPicFolderClosed = "img-folder.gif";
	private final String m_strPicPage = "img-page.gif";
	private final String m_strPicHead = "indes_03.gif";
	private final String m_strPicSearch = "sousuo.gif";
	private boolean m_bShowAll = false;
	private boolean m_bGetScript = true;
	private boolean m_bAutoDelete = true;

	// added by wwl 2004-11-17 展开?树型结构菜单的scripts列表
	private ArrayList expendAllScripts;

	public void setShowAll(boolean b) {
		m_bShowAll = b;
	}

	public String getPicHead() {
		return m_strPicRoot + m_strPicHead;
	}

	public String getPicSearch() {
		return m_strPicRoot + m_strPicSearch;
	}

	/**
	 * 构?函数
	 * 
	 * @param strRoot
	 *            图形的根目录
	 * @param bShow
	 *            是否在根层显示菜单图?
	 */
	public Menu(String strRoot, boolean ShowPicAtTheRoot) {
		if (null != strRoot && strRoot.length() > 0) {
			m_strPicRoot = strRoot;
		}
		m_bShowPicAtTheRoot = ShowPicAtTheRoot;
	}

	public Menu(String strRoot, boolean ShowPicAtTheRoot, boolean bGetScript,
			boolean bAutoDelete) {
		if (null != strRoot && strRoot.length() > 0) {
			m_strPicRoot = strRoot;
		}
		m_bShowPicAtTheRoot = ShowPicAtTheRoot;
		m_bGetScript = bGetScript;
		m_bAutoDelete = bAutoDelete;
	}

	public String getRootID() {
		return ROOT_ID;
	}

	public void setRootID(String str) {
		ROOT_ID = str;
	}

	/**
	 * 增加?树节?
	 * 
	 * @param ParentID
	 *            父亲ID
	 * @param strID
	 *            本节点在树中唯一的ID
	 * @param strTitle
	 *            本节点显示的标题
	 * @param strUrl
	 *            本节点连接的 URL
	 * @param strTargetFrame
	 *            打开的连接所在的 Frame
	 * @param strTip
	 *            提示信息
	 * @param strImgOpened
	 *            打开节点的图?
	 * @param imgCloseed
	 *            关闭节点的图?
	 * @return 菜单项目ID
	 */
	public String addItem(String ParentID, String strID, String strTitle,
			String strUrl, String strTargetFrame, String strTip,
			String strImgOpened, String imgCloseed) {
		MenuItem item = new MenuItem(ParentID, strID, strTitle, strUrl,
				strTargetFrame, strTip, strImgOpened, imgCloseed);
		// 取得parent??Vector
		Vector vect = (Vector) m_hashAllItems.get(ParentID);
		if (null == vect) {
			vect = new Vector();
		}
		vect.addElement(item);
		m_hashAllItems.remove(ParentID);
		m_hashAllItems.put(ParentID, vect);
		return strID;
	}

	/**
	 * 清P?的菜单项?
	 */
	public void clearAll() {
		m_hashAllItems.clear();
	}

	/**
	 * 增加?新的菜单项目
	 * 
	 * @param ParentID
	 *            父亲 ID
	 * @param strID
	 *            自己的ID
	 * @param strTitle
	 *            显示标题
	 * @param strUrl
	 *            连接字符?
	 * @param strTargetFrame
	 *            目标框架
	 * @param strTip
	 *            显示的提示内?
	 * @return 菜单ID
	 */
	public String addItem(String ParentID, String strID, String strTitle,
			String strUrl, String strTargetFrame, String strTip) {
		return addItem(ParentID, strID, strTitle, strUrl, strTargetFrame,
				strTip, "", "");
	}

	/**
	 * 增加?新的菜单项目
	 * 
	 * @param ParentID
	 *            父亲ID
	 * @param strID
	 *            自己的ID
	 * @param strTitle
	 *            菜单显示的标?
	 * @param strUrl
	 *            目标连接
	 * @param strTargetFrame
	 *            目标框架
	 * @return 菜单ID
	 */
	public String addItem(String ParentID, String strID, String strTitle,
			String strUrl, String strTargetFrame) {
		return addItem(ParentID, strID, strTitle, strUrl, strTargetFrame,
				strTitle, "", "");
	}

	public String addItem(String ParentID, String strID, String strTitle) {
		return addItem(ParentID, strID, strTitle, "", "", "", "", "");
	}

	/**
	 * 设置菜单图形的根目录
	 * 
	 * @param strDir
	 *            图形根目?
	 */
	public void setPicRoot(String strDir) {
		m_strPicRoot = strDir;
	}

	/**
	 * 取得菜单图形的根目录
	 * 
	 * @return 图形根目?
	 */
	public String getPicRoot() {
		return m_strPicRoot;
	}

	/**
	 * ?某个特定的菜单项目是否包含子?
	 * 
	 * @param strID
	 *            菜单 ID
	 * @return 是否包含子项
	 */
	public boolean hasChildren(String strID) {
		return m_hashAllItems.get(strID) != null;
	}

	/**
	 * 在根节点下增加一个菜单项
	 * 
	 * @param strID
	 *            菜单ID
	 * @param strTitle
	 *            标题
	 * @param strUrl
	 *            连接
	 * @param strTargetFrame
	 *            目标框架
	 * @param strTip
	 *            提示
	 * @param strImgOpened
	 *            菜单打开的时候的图形
	 * @param imgCloseed
	 *            菜单关闭的图?
	 * @return 菜单 ID
	 */
	public String addRootItem(String strID, String strTitle, String strUrl,
			String strTargetFrame, String strTip, String strImgOpened,
			String imgCloseed) {
		return addItem(ROOT_ID, strID, strTitle, strUrl, strTargetFrame,
				strTip, strImgOpened, imgCloseed);
	}

	protected String getRootBegin() {
		String strRet = "<table border='0' cellpadding='0' cellspacing='0' "
				+ "style='border-collapse: collapse' width='100%' "
				+ "id='TABLE_" + ROOT_ID + "'>\r\n";
		return strRet;
	}

	protected String getRootEnd() {
		return "</table>\r\n";
	}

	/**
	 * 取得菜单项目的前面显示的图形列表
	 * 
	 * @param nDeep
	 *            层次
	 * @param bLastOne
	 *            是否是父亲节点的??
	 * @return 图形显示列表
	 */
	protected String getPagePrevTreePic(int nDeep, boolean bLastOne) {
		String strRet = "";
		if (m_bShowPicAtTheRoot) {
			if (m_NenuMask[0] == 0) // 如果第一个图片（根层）需要展?
			{
				if (bLastOne && nDeep == 0) {
					strRet += "<img src='" + m_strPicRoot
							+ "img-branch-end.gif' ALIGN=TEXTTOP >";
				} else if (nDeep == 0) {
					strRet += "<img src='" + m_strPicRoot
							+ "img-branch-cont.gif' ALIGN=TEXTTOP >";
				} else {
					strRet += "<img src='" + m_strPicRoot
							+ "img-vert-line.gif' ALIGN=TEXTTOP >";
				}
			} else {
				strRet += "<img src='" + m_strPicRoot
						+ "img-blank.gif' ALIGN=TEXTTOP >";
			}
		}
		for (int i = 0; i < nDeep; i++) {
			// strRet +=i;
			if (i == nDeep - 1) // ??
			{
				if (!bLastOne) {
					strRet += "<img src='" + m_strPicRoot
							+ "img-branch-cont.gif' ALIGN=TEXTTOP >";
				} else {
					strRet += "<img src='" + m_strPicRoot
							+ "img-branch-end.gif' ALIGN=TEXTTOP >";
				}
			} else if (m_NenuMask[i + 1] == 0) {
				strRet += "<img src='" + m_strPicRoot
						+ "img-vert-line.gif' ALIGN=TEXTTOP >";
			} else {
				strRet += "<img src='" + m_strPicRoot
						+ "img-blank.gif' ALIGN=TEXTTOP >";
			}
		} // end for
		return strRet;
	}

	protected String getFolderPrevTreePic(int nDeep, boolean bLastOne,
			String strTableName, String strBShow, String strMyImgID,
			String strTreeImgID) {
		String strRet = "";
		String strFolderClickFunction = " name='" + strTreeImgID
				+ "' onClick='TREE_Fun_ShowTable(" + strMyImgID + ")' \r\n"
				+ " ShowFlag=" + strBShow;
		// added by wwl 2004-11-17
		String tmpStr = "TREE_Fun_ShowTable(" + strMyImgID + ");";
		if (!expendAllScripts.contains(tmpStr)) {
			expendAllScripts.add(tmpStr);
		}
		// added end
		String strStyle = "style='cursor:hand' ";
		if (!m_bShowPicAtTheRoot) {
			strStyle = " style='display:none' ";
		}
		if (nDeep == 0) {
			if (bLastOne) {
				strRet += "<img " + strStyle + strFolderClickFunction
						+ " src='" + m_strPicRoot
						+ "img-plus-end.gif' ALIGN=TEXTTOP >";
			} else {
				strRet += "<img " + strStyle + strFolderClickFunction
						+ " src='" + m_strPicRoot
						+ "img-plus-cont.gif' ALIGN=TEXTTOP >";
			}
		} else if (m_NenuMask[0] == 0) {
			if (bLastOne && nDeep == 0) {
				strRet += "<img " + strStyle + "src='" + m_strPicRoot
						+ "img-branch-end.gif' ALIGN=TEXTTOP >";
			} else {
				strRet += "<img " + strStyle + "src='" + m_strPicRoot
						+ "img-vert-line.gif' ALIGN=TEXTTOP >";
			}
		} else {
			strRet += "<img " + strStyle + "src='" + m_strPicRoot
					+ "img-blank.gif' ALIGN=TEXTTOP >";
		}
		for (int i = 0; i < nDeep; i++) {
			// strRet +=i;
			if (i == nDeep - 1) // ??
			{
				if (!bLastOne) {
					strRet += "<img " + strFolderClickFunction + " src='"
							+ m_strPicRoot
							+ "img-plus-cont.gif' ALIGN=TEXTTOP >";
				} else {
					strRet += "<img " + strFolderClickFunction + " src='"
							+ m_strPicRoot
							+ "img-plus-end.gif' ALIGN=TEXTTOP >";
				}
			} else if (m_NenuMask[i + 1] == 0) {
				strRet += "<img src='" + m_strPicRoot
						+ "img-vert-line.gif' ALIGN=TEXTTOP >";
			} else {
				strRet += "<img src='" + m_strPicRoot
						+ "img-blank.gif' ALIGN=TEXTTOP >";
			}
		} // end for
		return strRet;
	}

	/**
	 * 取得生成菜单文件夹的?部分
	 * 
	 * @param item
	 *            菜单项目
	 * @param bOpen
	 *            是否是打??
	 * @param nDeep
	 *            当前菜单?的层
	 * @param bLastOne
	 *            是否是父级菜单中的最后一?
	 * @return 菜单脚本
	 */
	protected String getFolderBegin(MenuItem item, boolean bOpen, int nDeep,
			boolean bLastOne) {
		String strTableName = ROOT_ID + "TAB_" + item.getID();
		String strImgID = ROOT_ID + "IMG_" + item.getID();
		String strImgTreeID = ROOT_ID + "TIMG_" + item.getID();
		String strImgOpened = item.getImgOpened();
		String strImgClosed = item.getImgClosed();
		if (strImgOpened.trim().length() < 1
				&& strImgClosed.trim().length() < 1) {
			strImgOpened = m_strPicFolderOpened;
			strImgClosed = m_strPicFolderClosed;
		} else if (strImgOpened.trim().length() < 1) {
			strImgOpened = strImgClosed;
		} else if (strImgClosed.trim().length() < 1) {
			strImgClosed = strImgOpened;
		}
		strImgClosed = m_strPicRoot + strImgClosed;
		strImgOpened = m_strPicRoot + strImgOpened;

		String strImg = strImgClosed;
		String strBShow = "0";
		String strShowStyle = "display:none";
		if (bOpen) {
			strImg = strImgOpened;
			strBShow = "1";
			strShowStyle = "";
		}
		String strLastMask = "0";
		if (bLastOne) {
			strLastMask = "1";
		}
		String strRet = "";
		strRet += "<tr><td nowrap>\r\n";
		strRet += getFolderPrevTreePic(nDeep, bLastOne, strTableName, strBShow,
				strImgID, strImgTreeID);
		// 显示点击的图?
		strRet += "<img name='" + strImgID + "' src='" + strImg + "' MIO='"
				+ strImgOpened + "' MIC='" + strImgClosed + "' IMG_TID='"
				+ strImgTreeID + "' IMG_MYID='" + strImgID + "' LASTM="
				+ strLastMask + " MYTABLE='" + strTableName
				+ "' onClick='TREE_Fun_ShowTable(this)' \r\n" + " ShowFlag="
				+ strBShow + " style='cursor:hand'  ALIGN=TEXTTOP >";
		// 显示文本
		if (item.getUrl().trim().length() < 1) {
			if (item.getTitle().toLowerCase().indexOf("</a>") < 0) {
				strRet += "<font size='2' style='cursor:hand' onClick='TREE_Fun_ShowTable("
						+ strImgID + ")'>" + item.getTitle() + "</font>\r\n";
				// added by wwl 2004-11-17
				String tmpStr = "TREE_Fun_ShowTable(" + strImgID + ");";
				if (!expendAllScripts.contains(tmpStr)) {
					expendAllScripts.add(tmpStr);
					// added end
				}
			} else {
				strRet += "<font size='2'>" + item.getTitle() + "</font>\r\n";

			}
		} else {
			String strTarget = "";
			if (item.getTargetFrame() != null
					&& item.getTargetFrame().trim().length() > 0) {
				strTarget = " target='" + item.getTargetFrame() + "'";
			}
			String strTip = item.getTip();
			if (StringUtil.isEmpty(strTip)) {
				strTip = item.getTitle();
			}
			strRet += "<font size='2'><a title='" + strTip
					+ "' class='CSS_TREE_FOLDER' " + strTarget + " href=\""
					+ item.getUrl() + "\">" + item.getTitle()
					+ "</a></font>\r\n";
		}
		// 增加表格
		strRet += "<table border='0' cellpadding='0' cellspacing='0' "
				+ "style='border-collapse:collapse;" + strShowStyle
				+ "' width='100%' " + "id='" + strTableName + "'>\r\n";
		return strRet;

	}

	/**
	 * 取得菜单文件夹的结束脚本
	 * 
	 * @param item
	 *            菜单项目
	 * @return 结束脚本
	 */
	protected String getFolderEnd(MenuItem item) {
		return "</td></tr>\r\n" + "</table>\r\n";
	}

	/**
	 * 取得菜单项的显示脚本
	 * 
	 * @param item
	 *            菜单项目
	 * @param nDeep
	 *            层次
	 * @param bLastOne
	 *            是否是父级菜单的??
	 * @return 菜单显示脚本
	 */
	protected String getPage(MenuItem item, int nDeep, boolean bLastOne) {
		String strRet = "";
		strRet += "<tr><td nowrap> \r\n";
		String strImgOpened = item.getImgOpened();
		String strImgClosed = item.getImgClosed();
		if (strImgOpened.trim().length() < 1) {
			strImgOpened = m_strPicPage;
		}
		if (strImgClosed.trim().length() < 1) {
			strImgClosed = m_strPicPage;
		}
		strImgClosed = m_strPicRoot + strImgClosed;
		strImgOpened = m_strPicRoot + strImgOpened;
		strRet += getPagePrevTreePic(nDeep, bLastOne);
		// 显示点击的图?
		strRet += "<img src='" + strImgOpened + "'"
				+ " style='cursor:hand' width='16' ALIGN='TEXTTOP' >";
		// 显示文本
		// 显示文本
		if (item.getUrl().trim().length() < 1) {
			strRet += "<font size='2'>" + item.getTitle() + "</font>\r\n";
		} else {
			String strTarget = "";
			if (item.getTargetFrame() != null
					&& item.getTargetFrame().trim().length() > 0) {
				strTarget = " target='" + item.getTargetFrame() + "'";
			}
			String strTip = item.getTip();
			if (StringUtil.isEmpty(strTip)) {
				strTip = item.getTitle();
			}
			strRet += "<font size='2'><a class='CSS_TREE_PAGE' title='"
					+ strTip + "' " + strTarget + " href=\"" + item.getUrl()
					+ "\">" + item.getTitle() + "</a></font>\r\n";
		}
		strRet += "</td></tr>\r\n";
		return strRet;
	}

	/**
	 * 取得树型结构菜单
	 * 
	 * @return 菜单脚本
	 */
	public String getTreeHtml() {
		for (int i = 0; i < m_NenuMask.length; i++) {
			m_NenuMask[i] = 0;
		}
		String strRet = "";
		expendAllScripts = new ArrayList();

		strRet += "<table border='0' cellpadding='0' cellspacing='0' "
				+ "style='border-collapse: collapse' width='100%'  "
				+ "id='MCTABR_" + ROOT_ID + "'>\r\n";
		;
		String strPID = ROOT_ID;
		while (true && m_bAutoDelete) {
			// 取得下面?
			Vector vect = (Vector) m_hashAllItems.get(strPID);
			if (null == vect || vect.size() == 1) {
				MenuItem item = (MenuItem) vect.elementAt(0);
				strPID = item.getID();
				continue;
			} else {
				break;
			}
		}
		strRet += getTreeHtmlSub(strPID, 0);
		strRet += "</table>";
		if (m_bGetScript) {
			strRet += getTreeScript();
		}
		return strRet;
	}

	/**
	 * 第归过程，取得脚?
	 * 
	 * @param strPID
	 *            父亲ID
	 * @param nDeep
	 *            层次
	 * @return 当前层次的脚?
	 */
	protected String getTreeHtmlSub(String strPID, int nDeep) {
		String strRet = "";
		Vector vect = (Vector) m_hashAllItems.get(strPID);
		if (null == vect) {
			return "";
		}
		for (int i = 0; i < vect.size(); i++) {
			boolean bLastOne = i == vect.size() - 1;
			MenuItem item = (MenuItem) vect.elementAt(i);
			if (hasChildren(item.getID())) {
				strRet += getFolderBegin(item, m_bShowAll, nDeep, bLastOne);
				if (bLastOne) {
					m_NenuMask[nDeep] = 1;
				}
				strRet += getTreeHtmlSub(item.getID(), nDeep + 1);
				strRet += getFolderEnd(item);
				m_NenuMask[nDeep + 1] = 0;
			} else {
				strRet += getPage(item, nDeep, bLastOne);
			}
		}
		return strRet;
	}

	/**
	 * 取得菜单支持显示的脚?
	 * 
	 * @return 菜单脚本
	 */
	protected String getTreeScript() {
		String str = "<script language=\"JavaScript\">\r\n"
				+ "function TREE_Fun_ShowTable(img)\r\n" + "{\r\n"
				+ "    if(null == img)\r\n" + "        return;\r\n"
				+ "    if(img.ShowFlag ==0)//显示表格，修改两个图片\r\n" + "    {\r\n"
				+ "		img.ShowFlag =1;\r\n"
				+ "        strSrc = img.MYTABLE+\".style.display=''\";\r\n"
				+ "        eval(strSrc);\r\n" + "        //显示数节点的图片\r\n"
				+ "        strSrc = img.IMG_MYID+\".src='\"+img.MIO+\"'\";\r\n"
				+ "        eval(strSrc);\r\n" + "        //显示自己的图\r\n"
				+ "        if(img.LASTM ==\"0\")\r\n"
				+ "            strSrc = img.IMG_TID+\".src='"
				+ m_strPicRoot
				+ "img-minus-cont.gif'\";\r\n"
				+ "        else    \r\n"
				+ "            strSrc = img.IMG_TID+\".src='"
				+ m_strPicRoot
				+ "img-minus-end.gif'\";\r\n"
				+ "        eval(strSrc);\r\n"
				+ "    }\r\n"
				+ "    else\r\n"
				+ "    {\r\n"
				+ "		img.ShowFlag =0;\r\n"
				+ "        strSrc = img.MYTABLE+\".style.display='none'\";\r\n"
				+ "        eval(strSrc);\r\n"
				+ "        \r\n"
				+ "        strSrc = img.IMG_MYID+\".src='\"+img.MIC+\"'\";\r\n"
				+ "        eval(strSrc);\r\n"
				+ "        if(img.LASTM ==\"0\")\r\n"
				+ "            strSrc = img.IMG_TID+\".src='"
				+ m_strPicRoot
				+ "img-plus-cont.gif'\";\r\n"
				+ "        else\r\n"
				+ "            strSrc = img.IMG_TID+\".src='"
				+ m_strPicRoot
				+ "img-plus-end.gif'\";  \r\n"
				+ "        eval(strSrc);\r\n"
				+ "    }\r\n"
				+ "}\r\n"
				+ "function expendAll() {\r\n"
				+ this.genExpendAllScripts() + "}\r\n" + "</script>\r\n";
		return str;
	}

	/**
	 * added by wwl 2004-11-17
	 * 
	 * @return
	 */
	private String genExpendAllScripts() {
		StringBuffer sb = new StringBuffer();
		int len = expendAllScripts.size();
		for (int i = 0; i < len; i++) {
			sb.append("	" + expendAllScripts.get(i) + "\r\n");
		}
		return sb.toString();
	}

	public static void main(String[] argv) {
		// com.asiainfo.biframe.privilege.menu.Menu m = new
		// com.asiainfo.biframe.privilege.menu.Menu();
		// m.addRootItem("1","root1","url","","tip","img1","img2");
		// m.addItem("1","2","title","url","","tip","img1","img2");
		// m.addItem("2","3","title","url","","tip","img1","img2");
		// m.addItem("3","4","title","url","","tip","img1","img2");
		// m.addItem("4","5","title","url","","tip","img1","img2");
		// m.addItem("5","6","title","url","","tip","img1","img2");
		// m.addItem("6","7","title","url","","tip","img1","img2");
		// m.addItem("7","8","title","url","","tip","img1","img2");
		// m.addItem("2","9","title","url","","tip","img1","img2");
		// //m.addItem("9","1","title","url","","tip","img1","img2");
		// log.debug(m.getHtml());

	}

	// ************************ 以下added by wwl 2004-11-16
	// begin**************************//
	// 把报表类型之间的树型结构显示?select>?
	/**
	 * 取得菜单项目的前面显示的图形列表
	 * 
	 * @param nDeep
	 *            层次
	 * @param bLastOne
	 *            是否是父亲节点的??
	 * @return 图形显示列表
	 */
	protected String getSelectPagePrevTreePic(int nDeep, boolean bLastOne) {
		String strRet = "";
		if (m_bShowPicAtTheRoot) {
			if (m_NenuMask[0] == 0) // 如果第一个图片（根层）需要展?
			{
				// TODO if(bLastOne && nDeep == 0) //如果是根的最后一个节?
				// strRet += "?;
				// else if(nDeep == 0)
				// strRet += "?;
				// else
				// strRet += "?;
			} else {
				strRet += "";
			}
		}
		for (int i = 0; i < nDeep; i++) {
			if (i == nDeep - 1) // ??
			{
				// TODO if(!bLastOne)
				// strRet += "?;
				// else
				// strRet += "?;
			} else if (m_NenuMask[i + 1] == 0) {
				// TODO strRet += "?;
			} else {
				strRet += "";
			}
		} // end for
		return strRet;
	}

	protected String getSelectFolderPrevTreePic(int nDeep, boolean bLastOne) {
		String strRet = "";

		if (nDeep == 0) {
			// TODO if(bLastOne)
			// strRet += "?;
			// else
			// strRet += "?;
		} else if (m_NenuMask[0] == 0) {
			// TODO if(bLastOne && nDeep == 0)
			// strRet += "?;
			// else
			// strRet += "?;
		} else {
			strRet += "";
		}
		for (int i = 0; i < nDeep; i++) {
			if (i == nDeep - 1) // ??
			{
				// TODO if(!bLastOne)
				// {
				// strRet += "?;
				// }
				// else
				// {
				// strRet += "?;
				// }
			} else if (m_NenuMask[i + 1] == 0) {
				// TODO strRet += "?;
			} else {
				strRet += "";
			}
		} // end for
		return strRet;
	}

	/**
	 * 取得生成菜单文件夹的?部分
	 * 
	 * @param item
	 *            菜单项目
	 * @param bOpen
	 *            是否是打??
	 * @param nDeep
	 *            当前菜单?的层
	 * @param bLastOne
	 *            是否是父级菜单中的最后一?
	 * @return 菜单脚本
	 */
	protected String getSelectFolderBegin(MenuItem item, boolean bOpen,
			int nDeep, boolean bLastOne, String selectedValue,
			Hashtable treeTable) {

		String strRet = "";
		strRet += getSelectFolderPrevTreePic(nDeep, bLastOne);
		String res = "<option value='" + item.getID() + "'";
		if ((selectedValue != null) && (selectedValue.equals(item.getID()))) {
			res += " selected";
		}
		res += ">";

		strRet += item.getTitle();
		res += strRet + "</option>\n";
		treeTable.put(item.getID(), strRet);

		return res;

	}

	/**
	 * 取得菜单项的显示脚本
	 * 
	 * @param item
	 *            菜单项目
	 * @param nDeep
	 *            层次
	 * @param bLastOne
	 *            是否是父级菜单的??
	 * @return 菜单显示脚本
	 */
	protected String getSelectPage(MenuItem item, int nDeep, boolean bLastOne,
			String selectedValue, Hashtable treeTable) {
		String strRet = "";
		strRet += getSelectPagePrevTreePic(nDeep, bLastOne);
		String res = "<option value='" + item.getID() + "'";
		if ((selectedValue != null) && (selectedValue.equals(item.getID()))) {
			res += " selected";
		}
		res += ">";

		strRet += item.getTitle();
		res += strRet + "</option>\n";
		treeTable.put(item.getID(), strRet);
		return res;
	}

	/**
	 * 取得树型结构菜单
	 * 
	 * @return 菜单脚本
	 */
	public String genSelectTreeHtml(String selName, String selOption,
			String selectedValue, Hashtable treeTable) {
		for (int i = 0; i < m_NenuMask.length; i++) {
			m_NenuMask[i] = 0;
		}
		String strRet = "";

		strRet += "<select name='" + selName + "' " + selOption + ">\n";
		String strPID = ROOT_ID;
		while (true && m_bAutoDelete) {
			// 取得下面?
			Vector vect = (Vector) m_hashAllItems.get(strPID);
			if (null == vect || vect.size() == 1) {
				MenuItem item = (MenuItem) vect.elementAt(0);
				strPID = item.getID();
				continue;
			} else {
				break;
			}
		}
		strRet += getSelectTreeHtmlSub(strPID, 0, selectedValue, treeTable);
		// strRet += "</table>";
		strRet += "</select>\n";
		return strRet;
	}

	/**
	 * 第归过程，取得脚?
	 * 
	 * @param strPID
	 *            父亲ID
	 * @param nDeep
	 *            层次
	 * @return 当前层次的脚?
	 */
	protected String getSelectTreeHtmlSub(String strPID, int nDeep,
			String selectedValue, Hashtable treeTable) {
		String strRet = "";
		Vector vect = (Vector) m_hashAllItems.get(strPID);
		if (null == vect) {
			return "";
		}
		for (int i = 0; i < vect.size(); i++) {
			boolean bLastOne = i == vect.size() - 1;
			MenuItem item = (MenuItem) vect.elementAt(i);
			if (hasChildren(item.getID())) {
				strRet += getSelectFolderBegin(item, m_bShowAll, nDeep,
						bLastOne, selectedValue, treeTable);
				if (bLastOne) {
					m_NenuMask[nDeep] = 1;
				}
				strRet += getSelectTreeHtmlSub(item.getID(), nDeep + 1,
						selectedValue, treeTable);
				// strRet += getFolderEnd(item);
				m_NenuMask[nDeep + 1] = 0;
			} else {
				strRet += getSelectPage(item, nDeep, bLastOne, selectedValue,
						treeTable);
			}
		}
		return strRet;
	}
	// ************************ 以下added by wwl 2004-11-16
	// end**************************//

}
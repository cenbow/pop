/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Menu
/*     */ {
/*  16 */   private final Hashtable m_hashAllItems = new Hashtable();
/*     */ 
/*  21 */   private final int[] m_NenuMask = new int[''];
/*     */ 
/*  23 */   private static String ROOT_ID = "MR";
/*     */ 
/*  25 */   private boolean m_bShowPicAtTheRoot = true;
/*     */ 
/*  27 */   private String m_strPicRoot = "/images/menu/";
/*     */ 
/*  29 */   private final String m_strPicFolderOpened = "img-folder-open.gif";
/*  30 */   private final String m_strPicFolderClosed = "img-folder.gif";
/*  31 */   private final String m_strPicPage = "img-page.gif";
/*  32 */   private final String m_strPicHead = "indes_03.gif";
/*  33 */   private final String m_strPicSearch = "sousuo.gif";
/*  34 */   private boolean m_bShowAll = false;
/*  35 */   private boolean m_bGetScript = true;
/*  36 */   private boolean m_bAutoDelete = true;
/*     */   private ArrayList expendAllScripts;
/*     */ 
/*     */   public void setShowAll(boolean b)
/*     */   {
/*  42 */     this.m_bShowAll = b;
/*     */   }
/*     */ 
/*     */   public String getPicHead() {
/*  46 */     return this.m_strPicRoot + "indes_03.gif";
/*     */   }
/*     */ 
/*     */   public String getPicSearch() {
/*  50 */     return this.m_strPicRoot + "sousuo.gif";
/*     */   }
/*     */ 
/*     */   public Menu(String strRoot, boolean ShowPicAtTheRoot)
/*     */   {
/*  62 */     if ((null != strRoot) && (strRoot.length() > 0)) {
/*  63 */       this.m_strPicRoot = strRoot;
/*     */     }
/*  65 */     this.m_bShowPicAtTheRoot = ShowPicAtTheRoot;
/*     */   }
/*     */ 
/*     */   public Menu(String strRoot, boolean ShowPicAtTheRoot, boolean bGetScript, boolean bAutoDelete)
/*     */   {
/*  70 */     if ((null != strRoot) && (strRoot.length() > 0)) {
/*  71 */       this.m_strPicRoot = strRoot;
/*     */     }
/*  73 */     this.m_bShowPicAtTheRoot = ShowPicAtTheRoot;
/*  74 */     this.m_bGetScript = bGetScript;
/*  75 */     this.m_bAutoDelete = bAutoDelete;
/*     */   }
/*     */ 
/*     */   public String getRootID() {
/*  79 */     return ROOT_ID;
/*     */   }
/*     */ 
/*     */   public void setRootID(String str) {
/*  83 */     ROOT_ID = str;
/*     */   }
/*     */ 
/*     */   public String addItem(String ParentID, String strID, String strTitle, String strUrl, String strTargetFrame, String strTip, String strImgOpened, String imgCloseed)
/*     */   {
/* 110 */     MenuItem item = new MenuItem(ParentID, strID, strTitle, strUrl, strTargetFrame, strTip, strImgOpened, imgCloseed);
/*     */ 
/* 113 */     Vector vect = (Vector)this.m_hashAllItems.get(ParentID);
/* 114 */     if (null == vect) {
/* 115 */       vect = new Vector();
/*     */     }
/* 117 */     vect.addElement(item);
/* 118 */     this.m_hashAllItems.remove(ParentID);
/* 119 */     this.m_hashAllItems.put(ParentID, vect);
/* 120 */     return strID;
/*     */   }
/*     */ 
/*     */   public void clearAll()
/*     */   {
/* 127 */     this.m_hashAllItems.clear();
/*     */   }
/*     */ 
/*     */   public String addItem(String ParentID, String strID, String strTitle, String strUrl, String strTargetFrame, String strTip)
/*     */   {
/* 149 */     return addItem(ParentID, strID, strTitle, strUrl, strTargetFrame, strTip, "", "");
/*     */   }
/*     */ 
/*     */   public String addItem(String ParentID, String strID, String strTitle, String strUrl, String strTargetFrame)
/*     */   {
/* 170 */     return addItem(ParentID, strID, strTitle, strUrl, strTargetFrame, strTitle, "", "");
/*     */   }
/*     */ 
/*     */   public String addItem(String ParentID, String strID, String strTitle)
/*     */   {
/* 175 */     return addItem(ParentID, strID, strTitle, "", "", "", "", "");
/*     */   }
/*     */ 
/*     */   public void setPicRoot(String strDir)
/*     */   {
/* 185 */     this.m_strPicRoot = strDir;
/*     */   }
/*     */ 
/*     */   public String getPicRoot()
/*     */   {
/* 194 */     return this.m_strPicRoot;
/*     */   }
/*     */ 
/*     */   public boolean hasChildren(String strID)
/*     */   {
/* 205 */     return this.m_hashAllItems.get(strID) != null;
/*     */   }
/*     */ 
/*     */   public String addRootItem(String strID, String strTitle, String strUrl, String strTargetFrame, String strTip, String strImgOpened, String imgCloseed)
/*     */   {
/* 230 */     return addItem(ROOT_ID, strID, strTitle, strUrl, strTargetFrame, strTip, strImgOpened, imgCloseed);
/*     */   }
/*     */ 
/*     */   protected String getRootBegin()
/*     */   {
/* 235 */     String strRet = "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='100%' id='TABLE_" + ROOT_ID + "'>\r\n";
/*     */ 
/* 238 */     return strRet;
/*     */   }
/*     */ 
/*     */   protected String getRootEnd() {
/* 242 */     return "</table>\r\n";
/*     */   }
/*     */ 
/*     */   protected String getPagePrevTreePic(int nDeep, boolean bLastOne)
/*     */   {
/* 255 */     String strRet = "";
/* 256 */     if (this.m_bShowPicAtTheRoot) {
/* 257 */       if (this.m_NenuMask[0] == 0)
/*     */       {
/* 259 */         if ((bLastOne) && (nDeep == 0)) {
/* 260 */           strRet = strRet + "<img src='" + this.m_strPicRoot + "img-branch-end.gif' ALIGN=TEXTTOP >";
/*     */         }
/* 262 */         else if (nDeep == 0) {
/* 263 */           strRet = strRet + "<img src='" + this.m_strPicRoot + "img-branch-cont.gif' ALIGN=TEXTTOP >";
/*     */         }
/*     */         else {
/* 266 */           strRet = strRet + "<img src='" + this.m_strPicRoot + "img-vert-line.gif' ALIGN=TEXTTOP >";
/*     */         }
/*     */       }
/*     */       else {
/* 270 */         strRet = strRet + "<img src='" + this.m_strPicRoot + "img-blank.gif' ALIGN=TEXTTOP >";
/*     */       }
/*     */     }
/*     */ 
/* 274 */     for (int i = 0; i < nDeep; i++)
/*     */     {
/* 276 */       if (i == nDeep - 1)
/*     */       {
/* 278 */         if (!bLastOne) {
/* 279 */           strRet = strRet + "<img src='" + this.m_strPicRoot + "img-branch-cont.gif' ALIGN=TEXTTOP >";
/*     */         }
/*     */         else {
/* 282 */           strRet = strRet + "<img src='" + this.m_strPicRoot + "img-branch-end.gif' ALIGN=TEXTTOP >";
/*     */         }
/*     */       }
/* 285 */       else if (this.m_NenuMask[(i + 1)] == 0) {
/* 286 */         strRet = strRet + "<img src='" + this.m_strPicRoot + "img-vert-line.gif' ALIGN=TEXTTOP >";
/*     */       }
/*     */       else {
/* 289 */         strRet = strRet + "<img src='" + this.m_strPicRoot + "img-blank.gif' ALIGN=TEXTTOP >";
/*     */       }
/*     */     }
/*     */ 
/* 293 */     return strRet;
/*     */   }
/*     */ 
/*     */   protected String getFolderPrevTreePic(int nDeep, boolean bLastOne, String strTableName, String strBShow, String strMyImgID, String strTreeImgID)
/*     */   {
/* 299 */     String strRet = "";
/* 300 */     String strFolderClickFunction = " name='" + strTreeImgID + "' onClick='TREE_Fun_ShowTable(" + strMyImgID + ")' \r\n" + " ShowFlag=" + strBShow;
/*     */ 
/* 304 */     String tmpStr = "TREE_Fun_ShowTable(" + strMyImgID + ");";
/* 305 */     if (!this.expendAllScripts.contains(tmpStr)) {
/* 306 */       this.expendAllScripts.add(tmpStr);
/*     */     }
/*     */ 
/* 309 */     String strStyle = "style='cursor:hand' ";
/* 310 */     if (!this.m_bShowPicAtTheRoot) {
/* 311 */       strStyle = " style='display:none' ";
/*     */     }
/* 313 */     if (nDeep == 0) {
/* 314 */       if (bLastOne) {
/* 315 */         strRet = strRet + "<img " + strStyle + strFolderClickFunction + " src='" + this.m_strPicRoot + "img-plus-end.gif' ALIGN=TEXTTOP >";
/*     */       }
/*     */       else
/*     */       {
/* 319 */         strRet = strRet + "<img " + strStyle + strFolderClickFunction + " src='" + this.m_strPicRoot + "img-plus-cont.gif' ALIGN=TEXTTOP >";
/*     */       }
/*     */ 
/*     */     }
/* 323 */     else if (this.m_NenuMask[0] == 0) {
/* 324 */       if ((bLastOne) && (nDeep == 0)) {
/* 325 */         strRet = strRet + "<img " + strStyle + "src='" + this.m_strPicRoot + "img-branch-end.gif' ALIGN=TEXTTOP >";
/*     */       }
/*     */       else {
/* 328 */         strRet = strRet + "<img " + strStyle + "src='" + this.m_strPicRoot + "img-vert-line.gif' ALIGN=TEXTTOP >";
/*     */       }
/*     */     }
/*     */     else {
/* 332 */       strRet = strRet + "<img " + strStyle + "src='" + this.m_strPicRoot + "img-blank.gif' ALIGN=TEXTTOP >";
/*     */     }
/*     */ 
/* 335 */     for (int i = 0; i < nDeep; i++)
/*     */     {
/* 337 */       if (i == nDeep - 1)
/*     */       {
/* 339 */         if (!bLastOne) {
/* 340 */           strRet = strRet + "<img " + strFolderClickFunction + " src='" + this.m_strPicRoot + "img-plus-cont.gif' ALIGN=TEXTTOP >";
/*     */         }
/*     */         else
/*     */         {
/* 344 */           strRet = strRet + "<img " + strFolderClickFunction + " src='" + this.m_strPicRoot + "img-plus-end.gif' ALIGN=TEXTTOP >";
/*     */         }
/*     */ 
/*     */       }
/* 348 */       else if (this.m_NenuMask[(i + 1)] == 0) {
/* 349 */         strRet = strRet + "<img src='" + this.m_strPicRoot + "img-vert-line.gif' ALIGN=TEXTTOP >";
/*     */       }
/*     */       else {
/* 352 */         strRet = strRet + "<img src='" + this.m_strPicRoot + "img-blank.gif' ALIGN=TEXTTOP >";
/*     */       }
/*     */     }
/*     */ 
/* 356 */     return strRet;
/*     */   }
/*     */ 
/*     */   protected String getFolderBegin(MenuItem item, boolean bOpen, int nDeep, boolean bLastOne)
/*     */   {
/* 374 */     String strTableName = ROOT_ID + "TAB_" + item.getID();
/* 375 */     String strImgID = ROOT_ID + "IMG_" + item.getID();
/* 376 */     String strImgTreeID = ROOT_ID + "TIMG_" + item.getID();
/* 377 */     String strImgOpened = item.getImgOpened();
/* 378 */     String strImgClosed = item.getImgClosed();
/* 379 */     if ((strImgOpened.trim().length() < 1) && (strImgClosed.trim().length() < 1))
/*     */     {
/* 381 */       strImgOpened = "img-folder-open.gif";
/* 382 */       strImgClosed = "img-folder.gif";
/* 383 */     } else if (strImgOpened.trim().length() < 1) {
/* 384 */       strImgOpened = strImgClosed;
/* 385 */     } else if (strImgClosed.trim().length() < 1) {
/* 386 */       strImgClosed = strImgOpened;
/*     */     }
/* 388 */     strImgClosed = this.m_strPicRoot + strImgClosed;
/* 389 */     strImgOpened = this.m_strPicRoot + strImgOpened;
/*     */ 
/* 391 */     String strImg = strImgClosed;
/* 392 */     String strBShow = "0";
/* 393 */     String strShowStyle = "display:none";
/* 394 */     if (bOpen) {
/* 395 */       strImg = strImgOpened;
/* 396 */       strBShow = "1";
/* 397 */       strShowStyle = "";
/*     */     }
/* 399 */     String strLastMask = "0";
/* 400 */     if (bLastOne) {
/* 401 */       strLastMask = "1";
/*     */     }
/* 403 */     String strRet = "";
/* 404 */     strRet = strRet + "<tr><td nowrap>\r\n";
/* 405 */     strRet = strRet + getFolderPrevTreePic(nDeep, bLastOne, strTableName, strBShow, strImgID, strImgTreeID);
/*     */ 
/* 408 */     strRet = strRet + "<img name='" + strImgID + "' src='" + strImg + "' MIO='" + strImgOpened + "' MIC='" + strImgClosed + "' IMG_TID='" + strImgTreeID + "' IMG_MYID='" + strImgID + "' LASTM=" + strLastMask + " MYTABLE='" + strTableName + "' onClick='TREE_Fun_ShowTable(this)' \r\n" + " ShowFlag=" + strBShow + " style='cursor:hand'  ALIGN=TEXTTOP >";
/*     */ 
/* 415 */     if (item.getUrl().trim().length() < 1) {
/* 416 */       if (item.getTitle().toLowerCase().indexOf("</a>") < 0) {
/* 417 */         strRet = strRet + "<font size='2' style='cursor:hand' onClick='TREE_Fun_ShowTable(" + strImgID + ")'>" + item.getTitle() + "</font>\r\n";
/*     */ 
/* 420 */         String tmpStr = "TREE_Fun_ShowTable(" + strImgID + ");";
/* 421 */         if (!this.expendAllScripts.contains(tmpStr))
/* 422 */           this.expendAllScripts.add(tmpStr);
/*     */       }
/*     */       else
/*     */       {
/* 426 */         strRet = strRet + "<font size='2'>" + item.getTitle() + "</font>\r\n";
/*     */       }
/*     */     }
/*     */     else {
/* 430 */       String strTarget = "";
/* 431 */       if ((item.getTargetFrame() != null) && (item.getTargetFrame().trim().length() > 0))
/*     */       {
/* 433 */         strTarget = " target='" + item.getTargetFrame() + "'";
/*     */       }
/* 435 */       String strTip = item.getTip();
/* 436 */       if (StringUtil.isEmpty(strTip)) {
/* 437 */         strTip = item.getTitle();
/*     */       }
/* 439 */       strRet = strRet + "<font size='2'><a title='" + strTip + "' class='CSS_TREE_FOLDER' " + strTarget + " href=\"" + item.getUrl() + "\">" + item.getTitle() + "</a></font>\r\n";
/*     */     }
/*     */ 
/* 445 */     strRet = strRet + "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse:collapse;" + strShowStyle + "' width='100%' " + "id='" + strTableName + "'>\r\n";
/*     */ 
/* 448 */     return strRet;
/*     */   }
/*     */ 
/*     */   protected String getFolderEnd(MenuItem item)
/*     */   {
/* 460 */     return "</td></tr>\r\n</table>\r\n";
/*     */   }
/*     */ 
/*     */   protected String getPage(MenuItem item, int nDeep, boolean bLastOne)
/*     */   {
/* 475 */     String strRet = "";
/* 476 */     strRet = strRet + "<tr><td nowrap> \r\n";
/* 477 */     String strImgOpened = item.getImgOpened();
/* 478 */     String strImgClosed = item.getImgClosed();
/* 479 */     if (strImgOpened.trim().length() < 1) {
/* 480 */       strImgOpened = "img-page.gif";
/*     */     }
/* 482 */     if (strImgClosed.trim().length() < 1) {
/* 483 */       strImgClosed = "img-page.gif";
/*     */     }
/* 485 */     strImgClosed = this.m_strPicRoot + strImgClosed;
/* 486 */     strImgOpened = this.m_strPicRoot + strImgOpened;
/* 487 */     strRet = strRet + getPagePrevTreePic(nDeep, bLastOne);
/*     */ 
/* 489 */     strRet = strRet + "<img src='" + strImgOpened + "'" + " style='cursor:hand' width='16' ALIGN='TEXTTOP' >";
/*     */ 
/* 493 */     if (item.getUrl().trim().length() < 1) {
/* 494 */       strRet = strRet + "<font size='2'>" + item.getTitle() + "</font>\r\n";
/*     */     } else {
/* 496 */       String strTarget = "";
/* 497 */       if ((item.getTargetFrame() != null) && (item.getTargetFrame().trim().length() > 0))
/*     */       {
/* 499 */         strTarget = " target='" + item.getTargetFrame() + "'";
/*     */       }
/* 501 */       String strTip = item.getTip();
/* 502 */       if (StringUtil.isEmpty(strTip)) {
/* 503 */         strTip = item.getTitle();
/*     */       }
/* 505 */       strRet = strRet + "<font size='2'><a class='CSS_TREE_PAGE' title='" + strTip + "' " + strTarget + " href=\"" + item.getUrl() + "\">" + item.getTitle() + "</a></font>\r\n";
/*     */     }
/*     */ 
/* 509 */     strRet = strRet + "</td></tr>\r\n";
/* 510 */     return strRet;
/*     */   }
/*     */ 
/*     */   public String getTreeHtml()
/*     */   {
/* 519 */     for (int i = 0; i < this.m_NenuMask.length; i++) {
/* 520 */       this.m_NenuMask[i] = 0;
/*     */     }
/* 522 */     String strRet = "";
/* 523 */     this.expendAllScripts = new ArrayList();
/*     */ 
/* 525 */     strRet = strRet + "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='100%'  id='MCTABR_" + ROOT_ID + "'>\r\n";
/*     */ 
/* 529 */     String strPID = ROOT_ID;
/* 530 */     while (this.m_bAutoDelete)
/*     */     {
/* 532 */       Vector vect = (Vector)this.m_hashAllItems.get(strPID);
/* 533 */       if ((null != vect) && (vect.size() != 1)) break;
/* 534 */       MenuItem item = (MenuItem)vect.elementAt(0);
/* 535 */       strPID = item.getID();
/*     */     }
/*     */ 
/* 541 */     strRet = strRet + getTreeHtmlSub(strPID, 0);
/* 542 */     strRet = strRet + "</table>";
/* 543 */     if (this.m_bGetScript) {
/* 544 */       strRet = strRet + getTreeScript();
/*     */     }
/* 546 */     return strRet;
/*     */   }
/*     */ 
/*     */   protected String getTreeHtmlSub(String strPID, int nDeep)
/*     */   {
/* 559 */     String strRet = "";
/* 560 */     Vector vect = (Vector)this.m_hashAllItems.get(strPID);
/* 561 */     if (null == vect) {
/* 562 */       return "";
/*     */     }
/* 564 */     for (int i = 0; i < vect.size(); i++) {
/* 565 */       boolean bLastOne = i == vect.size() - 1;
/* 566 */       MenuItem item = (MenuItem)vect.elementAt(i);
/* 567 */       if (hasChildren(item.getID())) {
/* 568 */         strRet = strRet + getFolderBegin(item, this.m_bShowAll, nDeep, bLastOne);
/* 569 */         if (bLastOne) {
/* 570 */           this.m_NenuMask[nDeep] = 1;
/*     */         }
/* 572 */         strRet = strRet + getTreeHtmlSub(item.getID(), nDeep + 1);
/* 573 */         strRet = strRet + getFolderEnd(item);
/* 574 */         this.m_NenuMask[(nDeep + 1)] = 0;
/*     */       } else {
/* 576 */         strRet = strRet + getPage(item, nDeep, bLastOne);
/*     */       }
/*     */     }
/* 579 */     return strRet;
/*     */   }
/*     */ 
/*     */   protected String getTreeScript()
/*     */   {
/* 588 */     String str = "<script language=\"JavaScript\">\r\nfunction TREE_Fun_ShowTable(img)\r\n{\r\n    if(null == img)\r\n        return;\r\n    if(img.ShowFlag ==0)//显示表格，修改两个图片\r\n    {\r\n\t\timg.ShowFlag =1;\r\n        strSrc = img.MYTABLE+\".style.display=''\";\r\n        eval(strSrc);\r\n        //显示数节点的图片\r\n        strSrc = img.IMG_MYID+\".src='\"+img.MIO+\"'\";\r\n        eval(strSrc);\r\n        //显示自己的图\r\n        if(img.LASTM ==\"0\")\r\n            strSrc = img.IMG_TID+\".src='" + this.m_strPicRoot + "img-minus-cont.gif'\";\r\n" + "        else    \r\n" + "            strSrc = img.IMG_TID+\".src='" + this.m_strPicRoot + "img-minus-end.gif'\";\r\n" + "        eval(strSrc);\r\n" + "    }\r\n" + "    else\r\n" + "    {\r\n" + "\t\timg.ShowFlag =0;\r\n" + "        strSrc = img.MYTABLE+\".style.display='none'\";\r\n" + "        eval(strSrc);\r\n" + "        \r\n" + "        strSrc = img.IMG_MYID+\".src='\"+img.MIC+\"'\";\r\n" + "        eval(strSrc);\r\n" + "        if(img.LASTM ==\"0\")\r\n" + "            strSrc = img.IMG_TID+\".src='" + this.m_strPicRoot + "img-plus-cont.gif'\";\r\n" + "        else\r\n" + "            strSrc = img.IMG_TID+\".src='" + this.m_strPicRoot + "img-plus-end.gif'\";  \r\n" + "        eval(strSrc);\r\n" + "    }\r\n" + "}\r\n" + "function expendAll() {\r\n" + genExpendAllScripts() + "}\r\n" + "</script>\r\n";
/*     */ 
/* 628 */     return str;
/*     */   }
/*     */ 
/*     */   private String genExpendAllScripts()
/*     */   {
/* 637 */     StringBuffer sb = new StringBuffer();
/* 638 */     int len = this.expendAllScripts.size();
/* 639 */     for (int i = 0; i < len; i++) {
/* 640 */       sb.append("\t" + this.expendAllScripts.get(i) + "\r\n");
/*     */     }
/* 642 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected String getSelectPagePrevTreePic(int nDeep, boolean bLastOne)
/*     */   {
/* 675 */     String strRet = "";
/* 676 */     if ((this.m_bShowPicAtTheRoot) && 
/* 677 */       (this.m_NenuMask[0] != 0))
/*     */     {
/* 686 */       strRet = strRet + "";
/*     */     }
/*     */ 
/* 689 */     for (int i = 0; i < nDeep; i++)
/* 690 */       if (i != nDeep - 1)
/*     */       {
/* 696 */         if (this.m_NenuMask[(i + 1)] != 0)
/*     */         {
/* 699 */           strRet = strRet + "";
/*     */         }
/*     */       }
/* 702 */     return strRet;
/*     */   }
/*     */ 
/*     */   protected String getSelectFolderPrevTreePic(int nDeep, boolean bLastOne) {
/* 706 */     String strRet = "";
/*     */ 
/* 708 */     if (nDeep != 0)
/*     */     {
/* 713 */       if (this.m_NenuMask[0] != 0)
/*     */       {
/* 719 */         strRet = strRet + "";
/*     */       }
/*     */     }
/* 721 */     for (int i = 0; i < nDeep; i++)
/* 722 */       if (i != nDeep - 1)
/*     */       {
/* 732 */         if (this.m_NenuMask[(i + 1)] != 0)
/*     */         {
/* 735 */           strRet = strRet + "";
/*     */         }
/*     */       }
/* 738 */     return strRet;
/*     */   }
/*     */ 
/*     */   protected String getSelectFolderBegin(MenuItem item, boolean bOpen, int nDeep, boolean bLastOne, String selectedValue, Hashtable treeTable)
/*     */   {
/* 758 */     String strRet = "";
/* 759 */     strRet = strRet + getSelectFolderPrevTreePic(nDeep, bLastOne);
/* 760 */     String res = "<option value='" + item.getID() + "'";
/* 761 */     if ((selectedValue != null) && (selectedValue.equals(item.getID()))) {
/* 762 */       res = res + " selected";
/*     */     }
/* 764 */     res = res + ">";
/*     */ 
/* 766 */     strRet = strRet + item.getTitle();
/* 767 */     res = res + strRet + "</option>\n";
/* 768 */     treeTable.put(item.getID(), strRet);
/*     */ 
/* 770 */     return res;
/*     */   }
/*     */ 
/*     */   protected String getSelectPage(MenuItem item, int nDeep, boolean bLastOne, String selectedValue, Hashtable treeTable)
/*     */   {
/* 787 */     String strRet = "";
/* 788 */     strRet = strRet + getSelectPagePrevTreePic(nDeep, bLastOne);
/* 789 */     String res = "<option value='" + item.getID() + "'";
/* 790 */     if ((selectedValue != null) && (selectedValue.equals(item.getID()))) {
/* 791 */       res = res + " selected";
/*     */     }
/* 793 */     res = res + ">";
/*     */ 
/* 795 */     strRet = strRet + item.getTitle();
/* 796 */     res = res + strRet + "</option>\n";
/* 797 */     treeTable.put(item.getID(), strRet);
/* 798 */     return res;
/*     */   }
/*     */ 
/*     */   public String genSelectTreeHtml(String selName, String selOption, String selectedValue, Hashtable treeTable)
/*     */   {
/* 808 */     for (int i = 0; i < this.m_NenuMask.length; i++) {
/* 809 */       this.m_NenuMask[i] = 0;
/*     */     }
/* 811 */     String strRet = "";
/*     */ 
/* 813 */     strRet = strRet + "<select name='" + selName + "' " + selOption + ">\n";
/* 814 */     String strPID = ROOT_ID;
/* 815 */     while (this.m_bAutoDelete)
/*     */     {
/* 817 */       Vector vect = (Vector)this.m_hashAllItems.get(strPID);
/* 818 */       if ((null != vect) && (vect.size() != 1)) break;
/* 819 */       MenuItem item = (MenuItem)vect.elementAt(0);
/* 820 */       strPID = item.getID();
/*     */     }
/*     */ 
/* 826 */     strRet = strRet + getSelectTreeHtmlSub(strPID, 0, selectedValue, treeTable);
/*     */ 
/* 828 */     strRet = strRet + "</select>\n";
/* 829 */     return strRet;
/*     */   }
/*     */ 
/*     */   protected String getSelectTreeHtmlSub(String strPID, int nDeep, String selectedValue, Hashtable treeTable)
/*     */   {
/* 843 */     String strRet = "";
/* 844 */     Vector vect = (Vector)this.m_hashAllItems.get(strPID);
/* 845 */     if (null == vect) {
/* 846 */       return "";
/*     */     }
/* 848 */     for (int i = 0; i < vect.size(); i++) {
/* 849 */       boolean bLastOne = i == vect.size() - 1;
/* 850 */       MenuItem item = (MenuItem)vect.elementAt(i);
/* 851 */       if (hasChildren(item.getID())) {
/* 852 */         strRet = strRet + getSelectFolderBegin(item, this.m_bShowAll, nDeep, bLastOne, selectedValue, treeTable);
/*     */ 
/* 854 */         if (bLastOne) {
/* 855 */           this.m_NenuMask[nDeep] = 1;
/*     */         }
/* 857 */         strRet = strRet + getSelectTreeHtmlSub(item.getID(), nDeep + 1, selectedValue, treeTable);
/*     */ 
/* 860 */         this.m_NenuMask[(nDeep + 1)] = 0;
/*     */       } else {
/* 862 */         strRet = strRet + getSelectPage(item, nDeep, bLastOne, selectedValue, treeTable);
/*     */       }
/*     */     }
/*     */ 
/* 866 */     return strRet;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.Menu
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.approval.util;

/**
 * 暂时使用；
 * 
 * @author Administrator
 *
 */
public class MenuItem {
	private String m_strID = ""; //
	private String m_strTitle = ""; //
	private String m_strTip = ""; //
	private String m_strImgOpened = ""; //
	private String m_strImgCloseed = ""; //
	private String m_strUrl = ""; //
	private String m_strParentID = ""; //
	private String m_strTargetFrame = ""; //
	private int m_nOrder = 0;

	public MenuItem(String ParentID, String strID, String strTitle,
			String strUrl, String strTargetFrame, String strTip,
			String strImgOpened, String imgCloseed) {
		m_strID = strID;
		m_strTitle = strTitle;
		m_strTip = strTip;
		m_strUrl = strUrl;
		m_strParentID = ParentID;
		m_strImgOpened = strImgOpened;
		m_strImgCloseed = imgCloseed;
		m_strTargetFrame = strTargetFrame;
	}

	public MenuItem(String ParentID, String strID, String strTitle,
			String strUrl, String strTargetFrame, String strTip) {
		m_strID = strID;
		m_strTitle = strTitle;
		m_strTip = strTip;
		m_strUrl = strUrl;
		m_strParentID = ParentID;
		m_strTargetFrame = strTargetFrame;
	}

	public MenuItem(String ParentID, String strID, String strTitle,
			String strUrl, String strTargetFrame) {
		m_strID = strID;
		m_strTitle = strTitle;
		m_strUrl = strUrl;
		m_strParentID = ParentID;
		m_strTargetFrame = strTargetFrame;
	}

	public String getTargetFrame() {
		return m_strTargetFrame;
	}

	public String getID() {
		return m_strID;
	}

	public String getTitle() {
		return m_strTitle;
	}

	public String getTip() {
		return m_strTip;
	}

	public String getImgOpened() {
		return m_strImgOpened;
	}

	public String getImgClosed() {
		return m_strImgCloseed;
	}

	public String getUrl() {
		return m_strUrl;
	}

	public void setOrder(int n) {
		m_nOrder = n;
	}

	public int getOrder() {
		return m_nOrder;
	}
}

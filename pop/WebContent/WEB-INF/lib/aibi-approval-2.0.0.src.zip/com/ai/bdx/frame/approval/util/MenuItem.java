/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ public class MenuItem
/*    */ {
/* 10 */   private String m_strID = "";
/* 11 */   private String m_strTitle = "";
/* 12 */   private String m_strTip = "";
/* 13 */   private String m_strImgOpened = "";
/* 14 */   private String m_strImgCloseed = "";
/* 15 */   private String m_strUrl = "";
/* 16 */   private String m_strParentID = "";
/* 17 */   private String m_strTargetFrame = "";
/* 18 */   private int m_nOrder = 0;
/*    */ 
/*    */   public MenuItem(String ParentID, String strID, String strTitle, String strUrl, String strTargetFrame, String strTip, String strImgOpened, String imgCloseed)
/*    */   {
/* 23 */     this.m_strID = strID;
/* 24 */     this.m_strTitle = strTitle;
/* 25 */     this.m_strTip = strTip;
/* 26 */     this.m_strUrl = strUrl;
/* 27 */     this.m_strParentID = ParentID;
/* 28 */     this.m_strImgOpened = strImgOpened;
/* 29 */     this.m_strImgCloseed = imgCloseed;
/* 30 */     this.m_strTargetFrame = strTargetFrame;
/*    */   }
/*    */ 
/*    */   public MenuItem(String ParentID, String strID, String strTitle, String strUrl, String strTargetFrame, String strTip)
/*    */   {
/* 35 */     this.m_strID = strID;
/* 36 */     this.m_strTitle = strTitle;
/* 37 */     this.m_strTip = strTip;
/* 38 */     this.m_strUrl = strUrl;
/* 39 */     this.m_strParentID = ParentID;
/* 40 */     this.m_strTargetFrame = strTargetFrame;
/*    */   }
/*    */ 
/*    */   public MenuItem(String ParentID, String strID, String strTitle, String strUrl, String strTargetFrame)
/*    */   {
/* 45 */     this.m_strID = strID;
/* 46 */     this.m_strTitle = strTitle;
/* 47 */     this.m_strUrl = strUrl;
/* 48 */     this.m_strParentID = ParentID;
/* 49 */     this.m_strTargetFrame = strTargetFrame;
/*    */   }
/*    */ 
/*    */   public String getTargetFrame() {
/* 53 */     return this.m_strTargetFrame;
/*    */   }
/*    */ 
/*    */   public String getID() {
/* 57 */     return this.m_strID;
/*    */   }
/*    */ 
/*    */   public String getTitle() {
/* 61 */     return this.m_strTitle;
/*    */   }
/*    */ 
/*    */   public String getTip() {
/* 65 */     return this.m_strTip;
/*    */   }
/*    */ 
/*    */   public String getImgOpened() {
/* 69 */     return this.m_strImgOpened;
/*    */   }
/*    */ 
/*    */   public String getImgClosed() {
/* 73 */     return this.m_strImgCloseed;
/*    */   }
/*    */ 
/*    */   public String getUrl() {
/* 77 */     return this.m_strUrl;
/*    */   }
/*    */ 
/*    */   public void setOrder(int n) {
/* 81 */     this.m_nOrder = n;
/*    */   }
/*    */ 
/*    */   public int getOrder() {
/* 85 */     return this.m_nOrder;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.MenuItem
 * JD-Core Version:    0.6.2
 */
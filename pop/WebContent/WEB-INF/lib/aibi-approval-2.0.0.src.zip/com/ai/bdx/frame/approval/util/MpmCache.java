package com.ai.bdx.frame.approval.util;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.jms.util.SimpleCache;
import com.asiainfo.biframe.manager.cache.CacheManager;
import com.asiainfo.biframe.service.IdNameMapper;

/**
 * Created on 2005-6-8
 *
 * <p>Title: </p>
 * <p>Description: 经分互动系统中各种基础信息缓存管理类</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */

public class MpmCache {
	private static final Logger log = LogManager.getLogger();

	private final ConcurrentMap<String, MpmCacheItem> cacheContainer;
	private String mpmContextPath;

	public static byte[] lock = new byte[0];
	private static final ReentrantLock userChannelInitLock = new ReentrantLock();

	/** 保证单例 */
	static class MpmCacheHolder {
		static MpmCache instance = new MpmCache();
	}

	public static MpmCache getInstance() {
		return MpmCacheHolder.instance;
	}

	/**
	 *
	 */
	private MpmCache() {
		super();
		cacheContainer = new ConcurrentHashMap<String, MpmCacheItem>();
		init();
	}

	/* (non-Javadoc)
	 * @see com.asiainfo.common.cache.CacheBase#init()
	 */
	protected boolean init() {
		
		//客户群访问标识
		TreeMap<String,Object> custGroupAccessMap = new TreeMap<String,Object>();
		custGroupAccessMap.put(MpmCONST.MPM_CUST_GROUP_ACCESS_TOKEN_COMMON + "",MpmLocaleUtil.getMessage("mcd.java.gy"));
		custGroupAccessMap.put(MpmCONST.MPM_CUST_GROUP_ACCESS_TOKEN_PRIVATE + "",MpmLocaleUtil.getMessage("mcd.java.sy"));
		MpmCacheItem custGroupAccessCache = new MpmCacheItem();
		custGroupAccessCache.setContainer(custGroupAccessMap);
		cacheContainer.put(MpmCONST.MPM_CUST_GROUP_ACCESS_TOKEN, custGroupAccessCache);

		//审批流程类型定义字典
		TreeMap<String,Object> flowtype = new TreeMap<String,Object>();
		flowtype.put(MpmCONST.FOLW_TYPE_QR + "","确认流程");
		flowtype.put(MpmCONST.FOLW_TYPE_SP + "","审批流程");

		MpmCacheItem flowtypeCache = new MpmCacheItem();
		flowtypeCache.setContainer(flowtype);
		cacheContainer.put(MpmCONST.FOLW_TYPE, flowtypeCache);

		
		
/*******************以上是确认用到的**********************************/		
		
		//活动场景类型动态KEY信息
		TreeMap<String,Object> sceneTypeMap = new TreeMap<String,Object>();
		sceneTypeMap.put(MpmCONST.REALTIME_DRV_TYPE, MpmCONST.SCENE_TYPE_REALTIME);
		sceneTypeMap.put(MpmCONST.NORMAL_DRV_TYPE, MpmCONST.SCENE_TYPE_NORMAL);
		MpmCacheItem sceneTypeCache = new MpmCacheItem();
		sceneTypeCache.setContainer(sceneTypeMap);
		cacheContainer.put(MpmCONST.SCENE_TYPE, sceneTypeCache);

		//活动状态信息
		TreeMap<String,Object> statusMap = new TreeMap<String,Object>();
		statusMap.put(MpmCONST.COMPAIGN_STATUS_NORMAL + "", MpmLocaleUtil.getMessage("mcd.java.zc"));
		statusMap.put(MpmCONST.COMPAIGN_STATUS_COMPLETED + "", MpmLocaleUtil.getMessage("mcd.java.wc1"));
		statusMap.put(MpmCONST.COMPAIGN_STATUS_TERMINALED + "", MpmLocaleUtil.getMessage("mcd.java.zz"));
		MpmCacheItem statusCache = new MpmCacheItem();
		statusCache.setContainer(statusMap);
		cacheContainer.put(MpmCONST.COMPAIGN_STATUS, statusCache);

		//活动状态变更方式
		TreeMap<String,Object> statusChgTypeMap = new TreeMap<String,Object>();
		statusChgTypeMap.put(MpmCONST.COMPAIGN_STATUS_CHG_BY_HAND + "", MpmLocaleUtil.getMessage("mcd.java.sd1"));
		statusChgTypeMap.put(MpmCONST.COMPAIGN_STATUS_CHG_AUTO + "", MpmLocaleUtil.getMessage("mcd.java.zd"));
		MpmCacheItem statusChgTypeCache = new MpmCacheItem();
		statusChgTypeCache.setContainer(statusChgTypeMap);
		cacheContainer.put(MpmCONST.COMPAIGN_STATUS_CHG_TYPE, statusChgTypeCache);

		//活动波次类型
		TreeMap<String,Object> replayStatusMap = new TreeMap<String,Object>();
		replayStatusMap.put(MpmCONST.COMPAIGN_REPLAY_STATUS_ONCE + "", MpmLocaleUtil.getMessage("mcd.java.dbc"));
		replayStatusMap.put(MpmCONST.COMPAIGN_REPLAY_STATUS_MULTI + "", MpmLocaleUtil.getMessage("mcd.java.dbc1"));
		MpmCacheItem replayStatusCache = new MpmCacheItem();
		replayStatusCache.setContainer(replayStatusMap);
		cacheContainer.put(MpmCONST.COMPAIGN_REPLAY_STATUS, replayStatusCache);

		//活动波次是否需要审批信息
		TreeMap<String,Object> segApproveMap = new TreeMap<String,Object>();
		segApproveMap.put(MpmCONST.MPM_SEG_APPROVE_FLAG_NOTNEED + "", MpmLocaleUtil.getMessage("mcd.java.bxysp"));
		segApproveMap.put(MpmCONST.MPM_SEG_APPROVE_FLAG_NEED + "", MpmLocaleUtil.getMessage("mcd.java.xysp"));
		MpmCacheItem segApproveCache = new MpmCacheItem();
		segApproveCache.setContainer(segApproveMap);
		cacheContainer.put(MpmCONST.MPM_SEG_APPROVE_FLAG, segApproveCache);

		//活动波次审批结果信息
		TreeMap<String,Object> segApproveResultMap = new TreeMap<String,Object>();
		segApproveResultMap.put(MpmCONST.MPM_SEG_APPROVE_RESULT_READY + "", MpmLocaleUtil.getMessage("mcd.java.wtjsp"));//营销案审批结果标志-营销案就绪未提交审批(mtl_camp_baseinfo中approve_result字段的含义)
		segApproveResultMap.put(MpmCONST.MPM_SEG_APPROVE_NEEDLESS + "", MpmLocaleUtil.getMessage("mcd.java.bxytjsp"));
		segApproveResultMap
				.put(MpmCONST.MPM_SEG_APPROVE_RESULT_WAITING + "", MpmLocaleUtil.getMessage("mcd.java.ddsp"));
		segApproveResultMap.put(MpmCONST.MPM_SEG_APPROVE_RESULT_PASSED + "", MpmLocaleUtil.getMessage("mcd.java.sptg"));
		segApproveResultMap.put(MpmCONST.MPM_SEG_APPROVE_RESULT_NOTPASSED + "",
				MpmLocaleUtil.getMessage("mcd.java.spwtg"));
		segApproveResultMap.put(MpmCONST.MPM_SEG_APPROVE_RESULT_TERMINALED + "",
				MpmLocaleUtil.getMessage("mcd.java.yqzz"));
		MpmCacheItem segApproveResultCache = new MpmCacheItem();
		segApproveResultCache.setContainer(segApproveResultMap);
		cacheContainer.put(MpmCONST.MPM_SEG_APPROVE_RESULT, segApproveResultCache);

		//活动波次步骤执行结果标志
		TreeMap<String,Object> performFlagMap = new TreeMap<String,Object>();
		performFlagMap.put(MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_UNDO + "", MpmLocaleUtil.getMessage("mcd.java.wzx"));
		performFlagMap.put(MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_SUCCESS + "",
				MpmLocaleUtil.getMessage("mcd.java.zxcg"));
		performFlagMap.put(MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_FAILURE + "",
				MpmLocaleUtil.getMessage("mcd.java.zxsb"));
		performFlagMap.put(MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_TERMINALED + "",
				MpmLocaleUtil.getMessage("mcd.java.bzz"));
		performFlagMap.put(MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_RUNING + "",
				MpmLocaleUtil.getMessage("mcd.java.ddzx"));
		performFlagMap.put(MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG_READYRUN + "",
				MpmLocaleUtil.getMessage("mcd.java.yxz"));
		MpmCacheItem performFlagCache = new MpmCacheItem();
		performFlagCache.setContainer(performFlagMap);
		cacheContainer.put(MpmCONST.MPM_CAMPSEG_STEP_PERFORM_FLAG, performFlagCache);

		//文件装载结果标志
		TreeMap<String,Object> loadTypeMap = new TreeMap<String,Object>();
		loadTypeMap.put(MpmCONST.MPM_FILTER_FILE_LOAD_TYPE_UNDO + "", MpmLocaleUtil.getMessage("mcd.java.wjhmyrk"));
		loadTypeMap
				.put(MpmCONST.MPM_FILTER_FILE_LOAD_TYPE_RUNNING + "", MpmLocaleUtil.getMessage("mcd.java.wjsjrkjxz"));
		loadTypeMap.put(MpmCONST.MPM_FILTER_FILE_LOAD_TYPE_SUCCESS + "", MpmLocaleUtil.getMessage("mcd.java.wjsjrkcg"));
		loadTypeMap.put(MpmCONST.MPM_FILTER_FILE_LOAD_TYPE_FAILURE + "", MpmLocaleUtil.getMessage("mcd.java.wjsjrksb"));
		MpmCacheItem loadTypeCache = new MpmCacheItem();
		loadTypeCache.setContainer(loadTypeMap);
		cacheContainer.put(MpmCONST.MPM_FILTER_FILE_LOAD_TYPE, loadTypeCache);

		TreeMap<String,Object> indiResourceMap = new TreeMap<String,Object>();
		indiResourceMap.put(MpmCONST.MPM_CAMP_INDI_RESOURCE_FROM_SYS + "", MpmLocaleUtil.getMessage("mcd.java.zbk"));
		indiResourceMap.put(MpmCONST.MPM_CAMP_INDI_RESOURCE_FROM_SELF + "", MpmLocaleUtil.getMessage("mcd.java.zdy"));
		MpmCacheItem indiResourceCache = new MpmCacheItem();
		indiResourceCache.setContainer(indiResourceMap);
		cacheContainer.put(MpmCONST.MPM_CAMP_INDI_RESOURCE, indiResourceCache);

		//基础信息表字段类型
		/*TreeMap<String,Object> baseTableColumnTypeMap = new TreeMap<String,Object>();
		try {
			IMpmCampDataSourceSvc campDatasourceSvc = (IMpmCampDataSourceSvc) SystemServiceLocator.getInstance()
					.getService(MpmCONST.CAMP_DATASOURCE_SERVICE_BEAN_ID);
			List typeMap = campDatasourceSvc.getColumnClass();
			for (int i = 0; typeMap != null && i < typeMap.size(); i++) {
				LabelValueBean lvb = (LabelValueBean) typeMap.get(i);
				baseTableColumnTypeMap.put(lvb.getValue() + "", lvb.getLabel());
			}
		} catch (Exception e) {
			log.error("", e);
		}
		MpmCacheItem baseTableColumnTypeCache = new MpmCacheItem();
		baseTableColumnTypeCache.setContainer(baseTableColumnTypeMap);
		cacheContainer.put(MpmCONST.BASE_TABLE_COLUMN_TYPE, baseTableColumnTypeCache);*/

		//基础表类型定义
		TreeMap<String,Object> sourceTableTypeMap = new TreeMap<String,Object>();
		sourceTableTypeMap.put(MpmCONST.SOURCE_TABLE_TYPE_BASE + "", MpmLocaleUtil.getMessage("mcd.java.jcxxb"));
		sourceTableTypeMap.put(MpmCONST.SOURCE_TABLE_TYPE_EXTEND + "", MpmLocaleUtil.getMessage("mcd.java.kzxxb"));
		sourceTableTypeMap.put(MpmCONST.SOURCE_TABLE_TYPE_INTFACE + "", MpmLocaleUtil.getMessage("mcd.java.hdjksjb"));
		sourceTableTypeMap.put(MpmCONST.SOURCE_TABLE_TYPE_COMPAIGN + "", MpmLocaleUtil.getMessage("mcd.java.hdkb"));
		sourceTableTypeMap.put(MpmCONST.SOURCE_TABLE_TYPE_ELIMINATE + "", MpmLocaleUtil.getMessage("mcd.java.tcsjb"));
		MpmCacheItem sourceTableTypeCache = new MpmCacheItem();
		sourceTableTypeCache.setContainer(sourceTableTypeMap);
		cacheContainer.put(MpmCONST.SOURCE_TABLE_TYPE, sourceTableTypeCache);

		TreeMap<String,Object> addsourceTableTypeMap = new TreeMap<String,Object>();
		addsourceTableTypeMap.put(MpmCONST.ADD_SOURCE_TABLE_TYPE_INTFACE + "",
				MpmLocaleUtil.getMessage("mcd.java.kzjkb"));
		addsourceTableTypeMap.put(MpmCONST.ADD_SOURCE_TABLE_TYPE_ELIMINATE + "",
				MpmLocaleUtil.getMessage("mcd.java.hmd"));
		MpmCacheItem addsourceTableTypeCache = new MpmCacheItem();
		addsourceTableTypeCache.setContainer(addsourceTableTypeMap);
		cacheContainer.put(MpmCONST.ADD_SOURCE_TABLE_TYPE, addsourceTableTypeCache);

		//字段类型定义
		TreeMap<String,Object> sourceColumnFlagMap = new TreeMap<String,Object>();
		sourceColumnFlagMap.put(MpmCONST.COMPAIGN_COLUMN_FLAG_NOTHING + "",
				MpmLocaleUtil.getMessage("mcd.java.fzbwdzd"));
		sourceColumnFlagMap.put(MpmCONST.COMPAIGN_COLUMN_FLAG_INDI + "", MpmLocaleUtil.getMessage("mcd.java.zb"));
		sourceColumnFlagMap.put(MpmCONST.COMPAIGN_COLUMN_FLAG_DEMENSION + "", MpmLocaleUtil.getMessage("mcd.java.wd"));
		MpmCacheItem sourceColumnFlagCache = new MpmCacheItem();
		sourceColumnFlagCache.setContainer(sourceColumnFlagMap);
		cacheContainer.put(MpmCONST.SOURCE_TABLE_COLUMN_FLAG, sourceColumnFlagCache);

		//字段标识定义
		TreeMap<String,Object> sourceColumnTypeMap = new TreeMap<String,Object>();
		sourceColumnTypeMap.put(MpmCONST.MPM_DS_COLUMN_TYPE_NUMBER + "", MpmLocaleUtil.getMessage("mcd.java.szx1"));
		sourceColumnTypeMap.put(MpmCONST.MPM_DS_COLUMN_TYPE_STRING + "", MpmLocaleUtil.getMessage("mcd.java.zfx"));
		sourceColumnTypeMap.put(MpmCONST.MPM_DS_COLUMN_TYPE_DATE + "", MpmLocaleUtil.getMessage("mcd.java.rqx"));
		sourceColumnTypeMap.put(MpmCONST.MPM_DS_COLUMN_TYPE_BLOB + "", MpmLocaleUtil.getMessage("mcd.java.BLOBx"));
		MpmCacheItem sourceColumnTypeCache = new MpmCacheItem();
		sourceColumnTypeCache.setContainer(sourceColumnTypeMap);
		cacheContainer.put(MpmCONST.MPM_DS_COLUMN_TYPE, sourceColumnTypeCache);

		//数据原表的状态定义
		TreeMap<String,Object> sourceTableStatusMap = new TreeMap<String,Object>();
		sourceTableStatusMap.put(MpmCONST.SOURCE_TABLE_STATUS_VALID + "", MpmLocaleUtil.getMessage("mcd.java.yx1"));
		sourceTableStatusMap.put(MpmCONST.SOURCE_TABLE_STATUS_INVALID + "", MpmLocaleUtil.getMessage("mcd.java.wx"));
		sourceTableStatusMap.put(MpmCONST.SOURCE_TABLE_STATUS_USED + "", MpmLocaleUtil.getMessage("mcd.java.zy"));
		sourceTableStatusMap.put(MpmCONST.SOURCE_TABLE_STATUS_PAUSE + "", MpmLocaleUtil.getMessage("mcd.java.zt1"));
		MpmCacheItem sourceTableStatusCache = new MpmCacheItem();
		sourceTableStatusCache.setContainer(sourceTableStatusMap);
		cacheContainer.put(MpmCONST.SOURCE_TABLE_STATUS, sourceTableStatusCache);

		//审批级别定义
		TreeMap<String,Object> approveDefineMap = new TreeMap<String,Object>();
		approveDefineMap.put(MpmCONST.MPM_APPROVE_LEVEL_YIJ + "", MpmLocaleUtil.getMessage("mcd.java.dyjsp"));
		approveDefineMap.put(MpmCONST.MPM_APPROVE_LEVEL_ERJ + "", MpmLocaleUtil.getMessage("mcd.java.dejsp"));
		approveDefineMap.put(MpmCONST.MPM_APPROVE_LEVEL_SANJ + "", MpmLocaleUtil.getMessage("mcd.java.dsjsp"));
		approveDefineMap.put(MpmCONST.MPM_APPROVE_LEVEL_SIJ + "", MpmLocaleUtil.getMessage("mcd.java.dsjsp1"));
		approveDefineMap.put(MpmCONST.MPM_APPROVE_LEVEL_WUJ + "", MpmLocaleUtil.getMessage("mcd.java.dwjsp"));
		approveDefineMap.put(MpmCONST.MPM_APPROVE_LEVEL_LIUJ + "", MpmLocaleUtil.getMessage("mcd.java.dljsp"));
		approveDefineMap.put(MpmCONST.MPM_APPROVE_LEVEL_QIJ + "", MpmLocaleUtil.getMessage("mcd.java.dqjsp"));
		MpmCacheItem approveDefineCache = new MpmCacheItem();
		approveDefineCache.setContainer(approveDefineMap);
		cacheContainer.put(MpmCONST.MPM_APPROVE_LEVEL_DEFINE_NO, approveDefineCache);

		TreeMap<String,Object> approveLevelMap = new TreeMap<String,Object>();
		approveLevelMap.put(MpmCONST.MPM_APPROVE_LEVEL_NOTHINE + "", MpmLocaleUtil.getMessage("mcd.java.bxysp"));
		approveLevelMap.put(MpmCONST.MPM_APPROVE_LEVEL_YIJ + "", MpmLocaleUtil.getMessage("mcd.java.yjsp"));
		approveLevelMap.put(MpmCONST.MPM_APPROVE_LEVEL_ERJ + "", MpmLocaleUtil.getMessage("mcd.java.ejsp"));
		approveLevelMap.put(MpmCONST.MPM_APPROVE_LEVEL_SANJ + "", MpmLocaleUtil.getMessage("mcd.java.sjsp"));
		approveLevelMap.put(MpmCONST.MPM_APPROVE_LEVEL_SIJ + "", MpmLocaleUtil.getMessage("mcd.java.sjsp1"));
		approveLevelMap.put(MpmCONST.MPM_APPROVE_LEVEL_WUJ + "", MpmLocaleUtil.getMessage("mcd.java.wjsp"));
		approveLevelMap.put(MpmCONST.MPM_APPROVE_LEVEL_LIUJ + "", MpmLocaleUtil.getMessage("mcd.java.ljsp"));
		approveLevelMap.put(MpmCONST.MPM_APPROVE_LEVEL_QIJ + "", MpmLocaleUtil.getMessage("mcd.java.qjsp"));
		MpmCacheItem approveLevelCache = new MpmCacheItem();
		approveLevelCache.setContainer(approveLevelMap);
		cacheContainer.put(MpmCONST.MPM_APPROVE_LEVEL_DEFINE, approveDefineCache);

		//告警标志定义
		TreeMap<String,Object> warnFlagMap = new TreeMap<String,Object>();
		warnFlagMap.put(MpmCONST.MPM_WARN_FLAG_GB + "", MpmLocaleUtil.getMessage("mcd.java.gbgjjz"));
		warnFlagMap.put(MpmCONST.MPM_WARN_FLAG_QY + "", MpmLocaleUtil.getMessage("mcd.java.qygjjz"));
		MpmCacheItem warnFlagCache = new MpmCacheItem();
		warnFlagCache.setContainer(warnFlagMap);
		cacheContainer.put(MpmCONST.MPM_WARN_FLAG_DEFINE, warnFlagCache);

		//外部资源url类型
		TreeMap<String,Object> extEvaluationUrlMap = new TreeMap<String,Object>();
		extEvaluationUrlMap.put(MpmCONST.MPM_EXT_EVALUATION_URL_CAMP + "",
				MpmLocaleUtil.getMessage("mcd.java.yxapgURL"));
		extEvaluationUrlMap.put(MpmCONST.MPM_EXT_EVALUATION_URL_SEG + "",
				MpmLocaleUtil.getMessage("mcd.java.yxhdpgURL"));
		MpmCacheItem extEvaluationUrlCache = new MpmCacheItem();
		extEvaluationUrlCache.setContainer(extEvaluationUrlMap);
		cacheContainer.put(MpmCONST.MPM_EXT_EVALUATION_URL, extEvaluationUrlCache);

		//成本类型定义
		TreeMap<String,Object> costTypeMap = new TreeMap<String,Object>();
		costTypeMap.put(MpmCONST.MPM_COST_TYPE_SHICHANG + "", MpmLocaleUtil.getMessage("mcd.java.sclcb"));
		costTypeMap.put(MpmCONST.MPM_COST_TYPE_CAIWU + "", MpmLocaleUtil.getMessage("mcd.java.cwlcb"));
		MpmCacheItem costTypeCache = new MpmCacheItem();
		costTypeCache.setContainer(costTypeMap);
		cacheContainer.put(MpmCONST.MPM_COST_TYPE_DEFINE, costTypeCache);

		TreeMap<String,Object> ruleApplyTypeMap = new TreeMap<String,Object>();
		ruleApplyTypeMap.put(MpmCONST.MPM_FILTER_RULE_APPLY_TYPE_NOTIN + "",
				MpmLocaleUtil.getMessage("mcd.java.notinms"));
		ruleApplyTypeMap.put(MpmCONST.MPM_FILTER_RULE_APPLY_TYPE_IN + "", MpmLocaleUtil.getMessage("mcd.java.inms"));
		MpmCacheItem ruleApplyTypeCache = new MpmCacheItem();
		ruleApplyTypeCache.setContainer(ruleApplyTypeMap);
		cacheContainer.put(MpmCONST.MPM_FILTER_RULE_APPLY_TYPE, ruleApplyTypeCache);

		//活动执行模式
		TreeMap execModeMap = new TreeMap();
		execModeMap.put(MpmCONST.COMPAIGN_EXEC_MODE_BYHAND + "", MpmLocaleUtil.getMessage("mcd.java.sd1"));
		execModeMap.put(MpmCONST.COMPAIGN_EXEC_MODE_AUTO + "", MpmLocaleUtil.getMessage("mcd.java.zd"));
		MpmCacheItem execModeCache = new MpmCacheItem();
		execModeCache.setContainer(execModeMap);
		cacheContainer.put(MpmCONST.COMPAIGN_EXEC_MODE, execModeCache);

		//活动波次状态编码
		TreeMap<String,Object> campsegStatMap = new TreeMap<String,Object>();
		//campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_HOLD + "","保留");
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_CHZT + "", MpmLocaleUtil.getMessage("mcd.java.chzt"));
		//		//campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_HDJX + "", "活动就绪");
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_HDSP + "", MpmLocaleUtil.getMessage("mcd.java.hdsp"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_SPYG + "", MpmLocaleUtil.getMessage("mcd.java.spyqzg"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_SPYZ + "", MpmLocaleUtil.getMessage("mcd.java.spyqzz"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_SPTG + "", MpmLocaleUtil.getMessage("mcd.java.sptg"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_ZXZT + "", MpmLocaleUtil.getMessage("mcd.java.ddpd"));
		//		//campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_DDZX + "", "等待派单");
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_DDPD + "", MpmLocaleUtil.getMessage("mcd.java.ddhtpd"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_ZZPD + "", MpmLocaleUtil.getMessage("mcd.java.pdz"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_DDSB + "", MpmLocaleUtil.getMessage("mcd.java.pdsb"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_DDCG + "", MpmLocaleUtil.getMessage("mcd.java.pdcg"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_PAUSE + "", MpmLocaleUtil.getMessage("mcd.java.pdzt"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_LOADING + "", MpmLocaleUtil.getMessage("mcd.java.zxqdpdz"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_LOADFAILURE + "", MpmLocaleUtil.getMessage("mcd.java.zxqdpdsb"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_LOADSUCCESS + "", MpmLocaleUtil.getMessage("mcd.java.zxqdpdcg"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_PGZT + "", MpmLocaleUtil.getMessage("mcd.java.pgzt"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_HDWC + "", MpmLocaleUtil.getMessage("mcd.java.hdwc"));
		//		campsegStatMap.put(MpmCONST.MPM_CAMPSEG_STAT_HDZZ + "", MpmLocaleUtil.getMessage("mcd.java.hdzz"));
		//		MpmCacheItem campsegStatCache = new MpmCacheItem();
		//		campsegStatCache.setContainer(campsegStatMap);

		/*try {
			IdNameMapper mpmCampsegStatService = (IdNameMapper) SystemServiceLocator.getInstance().getService("dimCampsegStat");
			List statList = mpmCampsegStatService.getAll();
			if (CollectionUtils.isNotEmpty(statList)) {
				for (int i = 0, size = statList.size(); i < size; i++) {
					DimCampsegStat bean = (DimCampsegStat) statList.get(i);
					campsegStatMap.put(bean.getCampsegStatId().toString(), bean.getCampsegStatName());
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}*/

		MpmCacheItem campsegStatCache = new MpmCacheItem();
		campsegStatCache.setContainer(campsegStatMap);
		cacheContainer.put(MpmCONST.MPM_CAMPSEG_STAT_DEFINE, campsegStatCache);

		//活动资源确认状态
		TreeMap<String,Object> campsegConfirmFlagMap = new TreeMap<String,Object>();
		campsegConfirmFlagMap.put(MpmCONST.MPM_CONFIRM_NEEDLESS + "", MpmLocaleUtil.getMessage("mcd.java.bxyqr"));
		campsegConfirmFlagMap.put(MpmCONST.MPM_CONFIRM_FLAG_NO + "", MpmLocaleUtil.getMessage("mcd.java.wtjqr"));
		campsegConfirmFlagMap.put(MpmCONST.MPM_CONFIRM_FLAG_WAITING + "", MpmLocaleUtil.getMessage("mcd.java.ddqr"));
		campsegConfirmFlagMap.put(MpmCONST.MPM_CONFIRM_FLAG_YES + "", MpmLocaleUtil.getMessage("mcd.java.qrwb"));
		campsegConfirmFlagMap.put(MpmCONST.MPM_CONFIRM_FLAG_CANNOT + "", MpmLocaleUtil.getMessage("mcd.java.qrwtg"));
		campsegConfirmFlagMap
				.put(MpmCONST.MPM_CONFIRM_FLAG_TERMINATE + "", MpmLocaleUtil.getMessage("mcd.java.qryxzz"));
		MpmCacheItem campsegConfirmFlagCache = new MpmCacheItem();
		campsegConfirmFlagCache.setContainer(campsegConfirmFlagMap);
		cacheContainer.put(MpmCONST.MPM_CONFIRM_FLAG, campsegConfirmFlagCache);

		//活动步骤定义
		TreeMap<String,Object> campsegStepMap = new TreeMap<String,Object>();
		campsegStepMap.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMPSEG + "", MpmLocaleUtil.getMessage("mcd.java.hdxxdy"));
		campsegStepMap
				.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_IMPORT_CUST + "", MpmLocaleUtil.getMessage("mcd.java.drmbkhwj"));
		campsegStepMap.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_CUST_GROUP_DEF_SELECT + "",
				MpmLocaleUtil.getMessage("mcd.java.khqmbxz"));
		campsegStepMap.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_ACTIVE_TEMPLET + "",
				MpmLocaleUtil.getMessage("mcd.java.khsxsz"));
		campsegStepMap.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SELECT + "", MpmLocaleUtil.getMessage("mcd.java.khdwsz"));
		campsegStepMap.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_CUST_GROUP_DEF_FEEDBACK + "",
				MpmLocaleUtil.getMessage("mcd.java.yxxgxz"));
		campsegStepMap.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_REALTIME + "", MpmLocaleUtil.getMessage("mcd.java.ssyxsz"));
		campsegStepMap
				.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_AGGREGATE + "", MpmLocaleUtil.getMessage("mcd.java.khqys"));
		campsegStepMap.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_FILTER + "", MpmLocaleUtil.getMessage("mcd.java.tctjsz"));
		campsegStepMap.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_AUDIT + "", MpmLocaleUtil.getMessage("mcd.java.hdnbsp"));
		campsegStepMap
				.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_CHANNEL_AUDIT + "", MpmLocaleUtil.getMessage("mcd.java.hdqdsp"));
		campsegStepMap.put(MpmCONST.MPM_SYS_ACTSTEP_DEF_CAMP_SEND + "", MpmLocaleUtil.getMessage("mcd.java.pdzx"));
		MpmCacheItem campsegStepCache = new MpmCacheItem();
		campsegStepCache.setContainer(campsegStepMap);
		cacheContainer.put(MpmCONST.MPM_ACTIVE_STEP_ID, campsegStepCache);

		//维表字段中文处理
		TreeMap dataExportItemMap = new TreeMap();
		dataExportItemMap.put(MpmCONST.MPM_DATA_EXPORT_ITEM_NO + "", MpmLocaleUtil.getMessage("mcd.java.zdcdm"));
		dataExportItemMap.put(MpmCONST.MPM_DATA_EXPORT_ITEM_OK + "", MpmLocaleUtil.getMessage("mcd.java.dcdmhzwms"));
		dataExportItemMap.put(MpmCONST.MPM_DATA_EXPORT_ITEM_ONLY + "", MpmLocaleUtil.getMessage("mcd.java.zdczwms"));
		MpmCacheItem dataExportItemCache = new MpmCacheItem();
		dataExportItemCache.setContainer(dataExportItemMap);
		cacheContainer.put(MpmCONST.MPM_DATA_EXPORT_ITEM, dataExportItemCache);

		//模板种类
		TreeMap<String,Object> templetClassMap = new TreeMap<String,Object>();
		templetClassMap.put(MpmCONST.MPM_TEMPLET_CLASS_ACT + "", MpmLocaleUtil.getMessage("mcd.java.khsxmb"));
		templetClassMap.put(MpmCONST.MPM_TEMPLET_CLASS_SELECT + "", MpmLocaleUtil.getMessage("mcd.java.khsxmb1"));
		templetClassMap.put(MpmCONST.MPM_TEMPLET_CLASS_FILTER + "", MpmLocaleUtil.getMessage("mcd.java.khtcmb"));
		templetClassMap.put(MpmCONST.MPM_TEMPLET_CLASS_SUBSECTION + "", MpmLocaleUtil.getMessage("mcd.java.khfzmb"));
		MpmCacheItem templetClassCache = new MpmCacheItem();
		templetClassCache.setContainer(templetClassMap);
		cacheContainer.put(MpmCONST.MPM_TEMPLET_CLASS_INFO, templetClassCache);

		//模板类型
		TreeMap<String,Object> ResFlagMap = new TreeMap<String,Object>();
		ResFlagMap.put(MpmCONST.MPM_RES_FLAG_VALID + "", MpmLocaleUtil.getMessage("mcd.java.yx1"));
		ResFlagMap.put(MpmCONST.MPM_RES_FLAG_PAUSE + "", MpmLocaleUtil.getMessage("mcd.java.zt1"));
		ResFlagMap.put(MpmCONST.MPM_RES_FLAG_INVALID + "", MpmLocaleUtil.getMessage("mcd.java.wx"));
		MpmCacheItem ResFlagCache = new MpmCacheItem();
		ResFlagCache.setContainer(ResFlagMap);
		cacheContainer.put(MpmCONST.MPM_RES_FLAG_STATUS, ResFlagCache);

		//模板类型
		TreeMap<String,Object> templetTypeMap = new TreeMap<String,Object>();
		templetTypeMap.put(MpmCONST.MPM_TEMPLET_TYPE_PUBLIC + "", MpmLocaleUtil.getMessage("mcd.java.gymb"));
		templetTypeMap.put(MpmCONST.MPM_TEMPLET_TYPE_PRIVATE + "", MpmLocaleUtil.getMessage("mcd.java.symb"));
		templetTypeMap.put(MpmCONST.MPM_TEMPLET_TYPE_SPECIAL + "", MpmLocaleUtil.getMessage("mcd.java.zymb"));
		templetTypeMap.put(MpmCONST.MPM_TEMPLET_TYPE_OTHER + "", MpmLocaleUtil.getMessage("mcd.java.wz"));
		MpmCacheItem templetTypeCache = new MpmCacheItem();
		templetTypeCache.setContainer(templetTypeMap);
		cacheContainer.put(MpmCONST.MPM_TEMPLET_TYPE_INFO, templetTypeCache);

		//步骤阶段
		TreeMap<String,Object> stepPhaseMap = new TreeMap<String,Object>();
		stepPhaseMap.put(MpmCONST.MPM_CAMP_STEP_PHASE_DEFINE + "", MpmLocaleUtil.getMessage("mcd.java.chjd"));
		stepPhaseMap.put(MpmCONST.MPM_CAMP_STEP_PHASE_AUDIT + "", MpmLocaleUtil.getMessage("mcd.java.spjd"));
		stepPhaseMap.put(MpmCONST.MPM_CAMP_STEP_PHASE_RUN + "", MpmLocaleUtil.getMessage("mcd.java.zxjd"));
		stepPhaseMap.put(MpmCONST.MPM_CAMP_STEP_PHASE_ANALYSE + "", MpmLocaleUtil.getMessage("mcd.java.pgjd"));
		MpmCacheItem stepPhaseCache = new MpmCacheItem();
		stepPhaseCache.setContainer(stepPhaseMap);
		cacheContainer.put(MpmCONST.MPM_CAMP_STEP_PHASE, stepPhaseCache);

		//add by happyl78
		//字段细分
		TreeMap<String,Object> fieldMap = new TreeMap<String,Object>();
		fieldMap.put(MpmCONST.VIPMANAGERID, MpmLocaleUtil.getMessage("mcd.java.dkhjl"));
		MpmCacheItem fieldCache = new MpmCacheItem();
		fieldCache.setContainer(fieldMap);
		cacheContainer.put(MpmCONST.USER_SUBSECTION_FIELD, fieldCache);

		//      反馈数据日期
		TreeMap<String,Object> contactType = new TreeMap<String,Object>();
		contactType.put(MpmCONST.CONTACTTYPE_ELECTRONIC_CHANNEL + "", MpmLocaleUtil.getMessage("mcd.java.dzqd"));
		contactType.put(MpmCONST.CONTACTTYPE_MANAGER_CHANNEL + "", MpmLocaleUtil.getMessage("mcd.java.khjl"));
		contactType.put(MpmCONST.CONTACTTYPE_TRADITION_CHANNEL + "", MpmLocaleUtil.getMessage("mcd.java.ctqd"));
		MpmCacheItem contactTypeCache = new MpmCacheItem();
		contactTypeCache.setContainer(contactType);
		cacheContainer.put(MpmCONST.CONTACTTYPE_MODE, contactTypeCache);

		//反馈数据日期
		TreeMap<String,Object> feedbackDateMap = new TreeMap<String,Object>();
		feedbackDateMap.put(MpmCONST.FEEDBACKDATE_NO, MpmLocaleUtil.getMessage("mcd.java.bxytgfksj"));
		feedbackDateMap.put(MpmCONST.FEEDBACKDATE_EVERYDAY, MpmLocaleUtil.getMessage("mcd.java.mttgycfksj"));
		feedbackDateMap.put(MpmCONST.FEEDBACKDATE_EVERYMONTH, MpmLocaleUtil.getMessage("mcd.java.mytgycfksj"));
		feedbackDateMap.put(MpmCONST.FEEDBACKDATE_EVERYQUARTER, MpmLocaleUtil.getMessage("mcd.java.mjdtgycfks"));
		feedbackDateMap.put(MpmCONST.FEEDBACKDATE_EVERYWEEK, MpmLocaleUtil.getMessage("mcd.java.mztgycfksj"));
		feedbackDateMap.put(MpmCONST.FEEDBACKDATE_APPOINTDATE, MpmLocaleUtil.getMessage("mcd.java.azzdsjfksj"));
		MpmCacheItem feedbackDateCache = new MpmCacheItem();
		feedbackDateCache.setContainer(feedbackDateMap);
		cacheContainer.put(MpmCONST.FEEDBACK_MODE, feedbackDateCache);

		//客户细分规则类型 add by chenlc
		TreeMap<String,Object> userSubSectionMap = new TreeMap<String,Object>();
		userSubSectionMap.put(MpmCONST.USER_SUBSECTION_TEMPLET + "", MpmLocaleUtil.getMessage("mcd.java.mbfz"));
		userSubSectionMap.put(MpmCONST.USER_SUBSECTION_VIP + "", MpmLocaleUtil.getMessage("mcd.java.dkhjlfz"));
		userSubSectionMap.put(MpmCONST.USER_SUBSECTION_DEFAUL + "", MpmLocaleUtil.getMessage("mcd.java.syfz"));
		MpmCacheItem userSubSectionCache = new MpmCacheItem();
		userSubSectionCache.setContainer(userSubSectionMap);
		cacheContainer.put(MpmCONST.USER_SUBSECTION_TYPE, userSubSectionCache);

		//是否是对比用户
		TreeMap<String,Object> userHandleFlagMap = new TreeMap<String,Object>();
		userHandleFlagMap.put(MpmCONST.MPM_USER_HANDLE_YES + "", MpmLocaleUtil.getMessage("mcd.java.s"));
		userHandleFlagMap.put(MpmCONST.MPM_USER_HANDLE_NO + "", MpmLocaleUtil.getMessage("mcd.java.f"));
		MpmCacheItem userHandleFlagCache = new MpmCacheItem();
		userHandleFlagCache.setContainer(userHandleFlagMap);
		cacheContainer.put(MpmCONST.MPM_USER_HANDLE_FLAG, userHandleFlagCache);

		//电子渠道类型
		TreeMap<String,Object> elChannelMap = new TreeMap<String,Object>();
		elChannelMap.put(MpmCONST.SMS, MpmLocaleUtil.getMessage("mcd.java.dx"));
		elChannelMap.put(MpmCONST.MMS, MpmLocaleUtil.getMessage("mcd.java.cx"));
		elChannelMap.put(MpmCONST.WAP, "WAP");
		MpmCacheItem elChannelCache = new MpmCacheItem();
		elChannelCache.setContainer(elChannelMap);
		cacheContainer.put(MpmCONST.ELCHANNEL_MODE, elChannelCache);

		//渠道类型(电子渠道和大客户经理) added by chenlc
		TreeMap<String,Object> channelTypeMap = new TreeMap<String,Object>();
		channelTypeMap.put(MpmCONST.CHANNEL_TYPE_VIPMANAGER, MpmLocaleUtil.getMessage("mcd.java.dkhjl"));
		channelTypeMap.put(MpmCONST.CHANNEL_TYPE_COMPMANAGER, MpmLocaleUtil.getMessage("mcd.java.cfkhjl"));
		channelTypeMap.put(MpmCONST.CHANNEL_TYPE_SMS, MpmLocaleUtil.getMessage("mcd.java.dx"));
		channelTypeMap.put(MpmCONST.CHANNEL_TYPE_MMS, MpmLocaleUtil.getMessage("mcd.java.cx"));
		channelTypeMap.put(MpmCONST.CHANNEL_TYPE_WAP, "WAP PUSH");
		MpmCacheItem channelTypeCache = new MpmCacheItem();
		channelTypeCache.setContainer(channelTypeMap);
		cacheContainer.put(MpmCONST.CHANNEL_TYPE, channelTypeCache);

		TreeMap<String,Object> managerChannelMap = new TreeMap<String,Object>();
		managerChannelMap.put(MpmCONST.CHANNEL_TYPE_VIPMANAGER, MpmLocaleUtil.getMessage("mcd.java.dkhjl"));
		managerChannelMap.put(MpmCONST.CHANNEL_TYPE_COMPMANAGER, MpmLocaleUtil.getMessage("mcd.java.cfkhjl"));
		MpmCacheItem managerChannelCache = new MpmCacheItem();
		managerChannelCache.setContainer(managerChannelMap);
		cacheContainer.put(MpmCONST.CHANNEL_MANAGER_TYPE, managerChannelCache);

		TreeMap<String,Object> eleChannelMap = new TreeMap<String,Object>();
		eleChannelMap.put(MpmCONST.CHANNEL_TYPE_SMS, MpmLocaleUtil.getMessage("mcd.java.dx"));
		eleChannelMap.put(MpmCONST.CHANNEL_TYPE_MMS, MpmLocaleUtil.getMessage("mcd.java.cx"));
		eleChannelMap.put(MpmCONST.CHANNEL_TYPE_WAP, "WAP PUSH");
		MpmCacheItem eleChannelCache = new MpmCacheItem();
		eleChannelCache.setContainer(eleChannelMap);
		cacheContainer.put(MpmCONST.CHANNEL_ELE_TYPE, eleChannelCache);

		TreeMap<String,Object> campTypeMap = new TreeMap<String,Object>();
		campTypeMap.put(MpmCONST.MPM_CAMP_TYPE_INITIATIVE + "", MpmLocaleUtil.getMessage("mcd.java.fcxc"));
		campTypeMap.put(MpmCONST.MPM_CAMP_TYPE_PASSVITY + "", MpmLocaleUtil.getMessage("mcd.java.cxc"));
		campTypeMap.put(MpmCONST.MPM_CAMP_TYPE_REALTIME + "", MpmLocaleUtil.getMessage("mcd.java.ssyx"));
		MpmCacheItem campTypeCache = new MpmCacheItem();
		campTypeCache.setContainer(campTypeMap);
		cacheContainer.put(MpmCONST.MPM_CAMP_TYPE, campTypeCache);

		TreeMap<String,Object> disModeMap = new TreeMap<String,Object>();
		disModeMap.put(MpmCONST.MPM_ANALYSE_DIS_MODE_TREND + "", MpmLocaleUtil.getMessage("mcd.java.qxt"));
		disModeMap.put(MpmCONST.MPM_ANALYSE_DIS_MODE_BAR + "", MpmLocaleUtil.getMessage("mcd.java.zxt"));
		disModeMap.put(MpmCONST.MPM_ANALYSE_DIS_MODE_PIE + "", MpmLocaleUtil.getMessage("mcd.java.bt"));
		MpmCacheItem disModeCache = new MpmCacheItem();
		disModeCache.setContainer(disModeMap);
		cacheContainer.put(MpmCONST.MPM_ANALYSE_DIS_MODE, disModeCache);

		TreeMap<String,Object> orderFieldMap = new TreeMap<String,Object>();
		orderFieldMap.put(MpmCONST.MPM_ORDER_FIELD_VAL1, MpmLocaleUtil.getMessage("mcd.java.jckhs"));
		orderFieldMap.put(MpmCONST.MPM_ORDER_FIELD_VAL2, MpmLocaleUtil.getMessage("mcd.java.jccgkhs"));
		orderFieldMap.put(MpmCONST.MPM_ORDER_FIELD_VAL2_RATE, MpmLocaleUtil.getMessage("mcd.java.jccgzb"));
		orderFieldMap.put(MpmCONST.MPM_ORDER_FIELD_VAL3, MpmLocaleUtil.getMessage("mcd.java.jshdkhs"));
		orderFieldMap.put(MpmCONST.MPM_ORDER_FIELD_VAL3_RATE, MpmLocaleUtil.getMessage("mcd.java.jshdzb"));
		orderFieldMap.put(MpmCONST.MPM_ORDER_FIELD_VAL4, MpmLocaleUtil.getMessage("mcd.java.mjshdkhs"));
		orderFieldMap.put(MpmCONST.MPM_ORDER_FIELD_VAL4_RATE, MpmLocaleUtil.getMessage("mcd.java.mjshdzb"));
		orderFieldMap.put(MpmCONST.MPM_ORDER_FIELD_TASK_RATE, MpmLocaleUtil.getMessage("mcd.java.wcrwzb"));
		MpmCacheItem orderFieldCache = new MpmCacheItem();
		orderFieldCache.setContainer(orderFieldMap);
		cacheContainer.put(MpmCONST.MPM_ORDER_FIELD, orderFieldCache);

		//数据源字段有效/无效
		TreeMap<String,Object> columnStatusMap = new TreeMap<String,Object>();
		columnStatusMap.put(MpmCONST.MPM_DATASRC_COLUMN_STATUS_VALID + "", MpmLocaleUtil.getMessage("mcd.java.yx1"));
		columnStatusMap.put(MpmCONST.MPM_DATASRC_COLUMN_STATUS_UNVALID + "", MpmLocaleUtil.getMessage("mcd.java.wx"));
		MpmCacheItem columnStatusCache = new MpmCacheItem();
		columnStatusCache.setContainer(columnStatusMap);
		cacheContainer.put(MpmCONST.MPM_DATASRC_COLUMN_STATUS, columnStatusCache);

		//审批人类型
		TreeMap<String,Object> approveObjTypeMap = new TreeMap<String,Object>();
		approveObjTypeMap.put(MpmCONST.MPM_APPROVE_OBJ_TYPE_SELF_DEPT + "", MpmLocaleUtil.getMessage("mcd.java.ssbm"));
		approveObjTypeMap.put(MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_DEPT + "",MpmLocaleUtil.getMessage("mcd.java.zdbm"));
		approveObjTypeMap.put(MpmCONST.MPM_APPROVE_OBJ_TYPE_APPOINT_APPROVER + "",MpmLocaleUtil.getMessage("mcd.java.zdspr"));
		//approveObjTypeMap.put(MpmCONST.MPM_APPROVE_OBJ_TYPE_TOPN_DEPT + "", MpmLocaleUtil.getMessage("mcd.java.sNjbm"));
		MpmCacheItem approveObjTypeCache = new MpmCacheItem();
		approveObjTypeCache.setContainer(approveObjTypeMap);
		cacheContainer.put(MpmCONST.MPM_APPROVE_OBJ_TYPE, approveObjTypeCache);

		//流程类型
		TreeMap<String,Object> approveFlowTypeMap = new TreeMap<String,Object>();
		approveFlowTypeMap.put(MpmCONST.APPROVE_APPROVAL_FLOW_TYPE_PT,"普通");//普通流程
		approveFlowTypeMap.put(MpmCONST.APPROVE_APPROVAL_FLOW_TYPE_HQ,"会签");//全都需要审批的会签流程
		MpmCacheItem approveFlowTypeCache = new MpmCacheItem();
		approveFlowTypeCache.setContainer(approveFlowTypeMap);
		cacheContainer.put(MpmCONST.APPROVEFLOWTYPE, approveFlowTypeCache);
		
		//客户群类型
		TreeMap<String,Object> custGroupTypeMap = new TreeMap<String,Object>();
		custGroupTypeMap.put(MpmCONST.MPM_CUST_GROUP_TYPE_DEFINE + "", MpmLocaleUtil.getMessage("mcd.java.zdySQLtj"));
		custGroupTypeMap.put(MpmCONST.MPM_CUST_GROUP_TYPE_LIST_FROM_DEFINE + "",
				MpmLocaleUtil.getMessage("mcd.java.zdySQLcjqd"));
		custGroupTypeMap.put(MpmCONST.MPM_CUST_GROUP_TYPE_LIST_FROM_FILE + "",
				MpmLocaleUtil.getMessage("mcd.java.wjdrcjqd"));
		custGroupTypeMap.put(MpmCONST.MPM_CUST_GROUP_TYPE_LIST_FROM_OPERATE + "",
				MpmLocaleUtil.getMessage("mcd.java.khqyscjqd"));
		custGroupTypeMap.put(MpmCONST.MPM_CUST_GROUP_TYPE_LIST_FROM_EXECFEEDBACK + "",
				MpmLocaleUtil.getMessage("mcd.java.hdxgcjqd"));
		MpmCacheItem custGroupTypeCache = new MpmCacheItem();
		custGroupTypeCache.setContainer(custGroupTypeMap);
		cacheContainer.put(MpmCONST.MPM_CUST_GROUP_TYPE, custGroupTypeCache);

		
		//客户群评估标志 added by caolifeng 20100621
		TreeMap<String,Object> custGroupEvaluateMap = new TreeMap<String,Object>();
		custGroupEvaluateMap.put(MpmCONST.MPM_CUST_GROUP_EVALUATE_FLAG_NO + "",
				MpmLocaleUtil.getMessage("mcd.java.bpg"));
		custGroupEvaluateMap.put(MpmCONST.MPM_CUST_GROUP_EVALUATE_FLAG_YES + "",
				MpmLocaleUtil.getMessage("mcd.java.pg"));
		MpmCacheItem custGroupEvaluateCache = new MpmCacheItem();
		custGroupEvaluateCache.setContainer(custGroupEvaluateMap);
		cacheContainer.put(MpmCONST.MPM_CUST_GROUP_EVALUATE_FLAG, custGroupEvaluateCache);

		//客户群状态
		TreeMap<String,Object> custGroupStatusMap = new TreeMap<String,Object>();
		custGroupStatusMap.put(MpmCONST.MPM_CUST_GROUP_STATUS_UNVALID_MODIFING + "",
				MpmLocaleUtil.getMessage("mcd.java.chz"));
		custGroupStatusMap.put(MpmCONST.MPM_CUST_GROUP_STATUS_VALID + "", MpmLocaleUtil.getMessage("mcd.java.ky"));
		custGroupStatusMap.put(MpmCONST.MPM_CUST_GROUP_STATUS_UNVALID_WAITING + "",
				MpmLocaleUtil.getMessage("mcd.java.ddsc"));
		custGroupStatusMap.put(MpmCONST.MPM_CUST_GROUP_STATUS_UNVALID_RUNNING + "",
				MpmLocaleUtil.getMessage("mcd.java.zzsc"));
		custGroupStatusMap.put(MpmCONST.MPM_CUST_GROUP_STATUS_UNVALID_FAILURE + "",
				MpmLocaleUtil.getMessage("mcd.java.scsb1"));
		MpmCacheItem custGroupStatusCache = new MpmCacheItem();
		custGroupStatusCache.setContainer(custGroupStatusMap);
		cacheContainer.put(MpmCONST.MPM_CUST_GROUP_STATUS, custGroupStatusCache);

		//接口表数据周期类型
		TreeMap<String,Object> dataSourceCycleTypeMap = new TreeMap<String,Object>();
		dataSourceCycleTypeMap.put(MpmCONST.DATA_SOURCE_CYCLE_TYPE_MONTH + "",
				MpmLocaleUtil.getMessage("mcd.java.myyz"));
		dataSourceCycleTypeMap.put(MpmCONST.DATA_SOURCE_CYCLE_TYPE_DAY + "", MpmLocaleUtil.getMessage("mcd.java.mryz"));
		dataSourceCycleTypeMap.put(MpmCONST.DATA_SOURCE_CYCLE_TYPE_NO + "", MpmLocaleUtil.getMessage("mcd.java.wlsb"));
		MpmCacheItem dataSourceCycleTypeCache = new MpmCacheItem();
		dataSourceCycleTypeCache.setContainer(dataSourceCycleTypeMap);
		cacheContainer.put(MpmCONST.DATA_SOURCE_CYCLE_TYPE, dataSourceCycleTypeCache);

		//免打扰类型
		TreeMap<String,Object> dimAvoidBotherMap = new TreeMap<String,Object>();
		dimAvoidBotherMap.put(MpmCONST.DIM_AVOID_BOTHER_TYPE_CLASS_CUST + "",
				MpmLocaleUtil.getMessage("mcd.java.khmdr"));
		dimAvoidBotherMap.put(MpmCONST.DIM_AVOID_BOTHER_TYPE_CLASS_CHANELL + "",
				MpmLocaleUtil.getMessage("mcd.java.qdmdr"));
		MpmCacheItem dimAvoidBotherCache = new MpmCacheItem();
		dimAvoidBotherCache.setContainer(dimAvoidBotherMap);
		cacheContainer.put(MpmCONST.DIM_AVOID_BOTHER_TYPE_CLASS, dimAvoidBotherCache);

		//其他系统返回状态说明
		TreeMap<String,Object> retrunMap = new TreeMap<String,Object>();
		//web接口返回
		retrunMap.put(MpmCONST.CHANNEL_TYPE_WEB + "-" + "1", MpmLocaleUtil.getMessage("mcd.java.drcg"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_WEB + "-" + "2", MpmLocaleUtil.getMessage("mcd.java.drsb"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_WEB + "-" + "3", MpmLocaleUtil.getMessage("mcd.java.hdsx"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_WEB + "-" + "4", MpmLocaleUtil.getMessage("mcd.java.hdwc"));
		//外呼、呼入接口返回
		retrunMap.put(MpmCONST.CHANNEL_TYPE_CALL + "-" + "3", MpmLocaleUtil.getMessage("mcd.java.drzcsh"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_CALL + "-" + "6", MpmLocaleUtil.getMessage("mcd.java.shcg"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_CALL + "-" + "7", MpmLocaleUtil.getMessage("mcd.java.drzczs"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_CALL + "-" + "8", MpmLocaleUtil.getMessage("mcd.java.shwcsb"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_CALL + "-" + "9", MpmLocaleUtil.getMessage("mcd.java.drsbsh"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_CALL + "-" + "10", MpmLocaleUtil.getMessage("mcd.java.drsbzs"));
		//营业厅接口返回
		retrunMap.put(MpmCONST.CHANNEL_TYPE_HALL + "-" + "3", MpmLocaleUtil.getMessage("mcd.java.drzcsh"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_HALL + "-" + "6", MpmLocaleUtil.getMessage("mcd.java.shcg"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_HALL + "-" + "7", MpmLocaleUtil.getMessage("mcd.java.drzczs"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_HALL + "-" + "8", MpmLocaleUtil.getMessage("mcd.java.shwcsb"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_HALL + "-" + "9", MpmLocaleUtil.getMessage("mcd.java.drsbsh"));
		retrunMap.put(MpmCONST.CHANNEL_TYPE_HALL + "-" + "10", MpmLocaleUtil.getMessage("mcd.java.drsbzs"));
		MpmCacheItem retrunCache = new MpmCacheItem();
		retrunCache.setContainer(retrunMap);
		cacheContainer.put(MpmCONST.MPM_INTERFACE_RETURN_CODE, retrunCache);

		//把营销管理中的缓存放置到系统缓存管理器中
		Map bigMap = CacheManager.getInstance().getAllCache();
		bigMap.putAll(cacheContainer);

		return true;
	}

	/**
	 * 通过数据字典名及key活动字典定义的值
	 * @param dicName 数据字典名（application-mpm-configure.xml中mapper类的bean名）
	 * @param key 数据字典ID
	 * @return
	 */
	public String getNameByKeyFromDic(String dicName, Object key) {
		synchronized (lock) {
			String name = "";
			if (key == null) {
				return name;
			}
			String tmpKey = key.toString();
			String mapValue = SimpleCache.getInstance().get(dicName + "_getNameByKeyFromDic_" + key, String.class);
			if (mapValue != null) {
				return mapValue;
			}

			IdNameMapper mapper = null;
			try {
				mapper = SpringContext.getBean(dicName, IdNameMapper.class);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("", e);
			}
			if (mapper != null) {
				name = mapper.getNameById(tmpKey);
			} else {
				name = SystemCacheManager.getInstance().getNameById(dicName, tmpKey);
			}

			//缓存一小时
			SimpleCache.getInstance().put(dicName + "_getNameByKeyFromDic_" + key, name, 60 * 60);

			return name;
		}
	}

	/**
	 * 通过类型及key获得某个字典定义的值
	 * @param type 数据字典类型,定义在MpmCONST中
	 * @param key 数据字典ID,定义在MpmCONST中
	 * @return
	 */
	public String getNameByTypeAndKey(Object type, Object key) {
		String res = "--";
		if (cacheContainer.containsKey(type)) {
			TreeMap tmpMap = (TreeMap) cacheContainer.get(type).getContainer();
			if (tmpMap.containsKey(key)) {
				res = (String) tmpMap.get(key);
			}
		}
		return res;
	}

	/**
	 *
	 * @param type
	 * @return
	 */
	public Map getMapByType(Object type) {
		TreeMap retMap = new TreeMap();
		if (cacheContainer.containsKey(type)) {
			retMap = (TreeMap) cacheContainer.get(type).getContainer();
		}
		return (Map) retMap.clone();
	}

	/* (non-Javadoc)
	 * @see com.asiainfo.common.cache.CacheBase#refreshByKey(java.lang.Object)
	 */
	public boolean refreshByKey(Object key) {
		// TODO Auto-generated method stub
		return false;
	}

	public String getMpmContextPath() {
		return mpmContextPath;
	}

	public void setMpmContextPath(String mpmContextPath) {
		this.mpmContextPath = mpmContextPath;
	}

	/**
	 * 获取渠道当天派单文件序列号
	 * @param channelType
	 * @return
	 * @throws Exception 
	 */
	public synchronized String getSendOddSerialNum(String channelType) {

		Integer serialNum = (Integer) SimpleCache.getInstance().get("DAY_SERIAL_NUM" + channelType);
		if (serialNum == null) {
			try {
				JdbcTemplate jt = SpringContext.getBean("jdbcTemplate", JdbcTemplate.class);
				String querySql = "select max(day_serial_num)  from mcd_sendodd_file_log where channel_type = ? and   send_date > ?";
				Calendar c = Calendar.getInstance();
				c.set(Calendar.HOUR_OF_DAY, 0);
				c.set(Calendar.MINUTE, 0);
				c.set(Calendar.SECOND, 0);
				serialNum = jt.queryForInt(querySql, new Object[] { channelType, c.getTime() });
			} catch (Exception e) {
				log.error("", e);
			}
		}

		Calendar c = Calendar.getInstance();
		c.set(Calendar.HOUR_OF_DAY, 23);
		c.set(Calendar.MINUTE, 59);
		c.set(Calendar.SECOND, 59);
		long expireTime = c.getTimeInMillis() - System.currentTimeMillis();
		SimpleCache.getInstance().put("DAY_SERIAL_NUM" + channelType, serialNum + 1, expireTime);

		return String.format("%04d", serialNum + 1);
	}

	public synchronized Date getSendOddLastRunTime(Date currentDate) {
		Date date = (Date) SimpleCache.getInstance().get("CEP_SENDODD_LAST_RUN_TIME");
		if (date == null) {
			try {
				JdbcTemplate jt = SpringContext.getBean("jdbcTemplate", JdbcTemplate.class);
				String querySql = "select max(end_time) from mcd_sendodd_file_log where send_date > ?";
				Calendar c = Calendar.getInstance();
				c.set(Calendar.HOUR_OF_DAY, 0);
				c.set(Calendar.MINUTE, 0);
				c.set(Calendar.SECOND, 0);
				date = (Date) jt.queryForObject(querySql, new Object[] { c.getTime() }, Date.class);
				if (date == null) {
					date = c.getTime();
				}
			} catch (Exception e) {
				log.error("", e);
			}
		}
		SimpleCache.getInstance().put("CEP_SENDODD_LAST_RUN_TIME", currentDate);
		return date;
	}
}

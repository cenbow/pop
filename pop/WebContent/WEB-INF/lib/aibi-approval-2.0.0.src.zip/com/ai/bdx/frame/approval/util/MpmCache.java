/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import com.ai.bdx.frame.approval.jms.util.SimpleCache;
/*     */ import com.asiainfo.biframe.manager.cache.CacheManager;
/*     */ import com.asiainfo.biframe.service.IdNameMapper;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ 
/*     */ public class MpmCache
/*     */ {
/*  32 */   private static final Logger log = LogManager.getLogger();
/*     */   private final ConcurrentMap<String, MpmCacheItem> cacheContainer;
/*     */   private String mpmContextPath;
/*  37 */   public static byte[] lock = new byte[0];
/*  38 */   private static final ReentrantLock userChannelInitLock = new ReentrantLock();
/*     */ 
/*     */   public static MpmCache getInstance()
/*     */   {
/*  46 */     return MpmCacheHolder.instance;
/*     */   }
/*     */ 
/*     */   private MpmCache()
/*     */   {
/*  54 */     this.cacheContainer = new ConcurrentHashMap();
/*  55 */     init();
/*     */   }
/*     */ 
/*     */   protected boolean init()
/*     */   {
/*  64 */     TreeMap custGroupAccessMap = new TreeMap();
/*  65 */     custGroupAccessMap.put("1", MpmLocaleUtil.getMessage("mcd.java.gy"));
/*  66 */     custGroupAccessMap.put("0", MpmLocaleUtil.getMessage("mcd.java.sy"));
/*  67 */     MpmCacheItem custGroupAccessCache = new MpmCacheItem();
/*  68 */     custGroupAccessCache.setContainer(custGroupAccessMap);
/*  69 */     this.cacheContainer.put("custGroupAccessToken", custGroupAccessCache);
/*     */ 
/*  72 */     TreeMap flowtype = new TreeMap();
/*  73 */     flowtype.put("2", "确认流程");
/*  74 */     flowtype.put("1", "审批流程");
/*     */ 
/*  76 */     MpmCacheItem flowtypeCache = new MpmCacheItem();
/*  77 */     flowtypeCache.setContainer(flowtype);
/*  78 */     this.cacheContainer.put("dingyiliuchengleixing", flowtypeCache);
/*     */ 
/*  85 */     TreeMap sceneTypeMap = new TreeMap();
/*  86 */     sceneTypeMap.put("-8", "scene_type11");
/*  87 */     sceneTypeMap.put("-12", "scene_type12");
/*  88 */     MpmCacheItem sceneTypeCache = new MpmCacheItem();
/*  89 */     sceneTypeCache.setContainer(sceneTypeMap);
/*  90 */     this.cacheContainer.put("scene_type", sceneTypeCache);
/*     */ 
/*  93 */     TreeMap statusMap = new TreeMap();
/*  94 */     statusMap.put("1", MpmLocaleUtil.getMessage("mcd.java.zc"));
/*  95 */     statusMap.put("2", MpmLocaleUtil.getMessage("mcd.java.wc1"));
/*  96 */     statusMap.put("3", MpmLocaleUtil.getMessage("mcd.java.zz"));
/*  97 */     MpmCacheItem statusCache = new MpmCacheItem();
/*  98 */     statusCache.setContainer(statusMap);
/*  99 */     this.cacheContainer.put("campStatus", statusCache);
/*     */ 
/* 102 */     TreeMap statusChgTypeMap = new TreeMap();
/* 103 */     statusChgTypeMap.put("0", MpmLocaleUtil.getMessage("mcd.java.sd1"));
/* 104 */     statusChgTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.zd"));
/* 105 */     MpmCacheItem statusChgTypeCache = new MpmCacheItem();
/* 106 */     statusChgTypeCache.setContainer(statusChgTypeMap);
/* 107 */     this.cacheContainer.put("statusChgType", statusChgTypeCache);
/*     */ 
/* 110 */     TreeMap replayStatusMap = new TreeMap();
/* 111 */     replayStatusMap.put("0", MpmLocaleUtil.getMessage("mcd.java.dbc"));
/* 112 */     replayStatusMap.put("1", MpmLocaleUtil.getMessage("mcd.java.dbc1"));
/* 113 */     MpmCacheItem replayStatusCache = new MpmCacheItem();
/* 114 */     replayStatusCache.setContainer(replayStatusMap);
/* 115 */     this.cacheContainer.put("replayStatus", replayStatusCache);
/*     */ 
/* 118 */     TreeMap segApproveMap = new TreeMap();
/* 119 */     segApproveMap.put("0", MpmLocaleUtil.getMessage("mcd.java.bxysp"));
/* 120 */     segApproveMap.put("1", MpmLocaleUtil.getMessage("mcd.java.xysp"));
/* 121 */     MpmCacheItem segApproveCache = new MpmCacheItem();
/* 122 */     segApproveCache.setContainer(segApproveMap);
/* 123 */     this.cacheContainer.put("segApproveFlag", segApproveCache);
/*     */ 
/* 126 */     TreeMap segApproveResultMap = new TreeMap();
/* 127 */     segApproveResultMap.put("-1", MpmLocaleUtil.getMessage("mcd.java.wtjsp"));
/* 128 */     segApproveResultMap.put("-2", MpmLocaleUtil.getMessage("mcd.java.bxytjsp"));
/* 129 */     segApproveResultMap.put("0", MpmLocaleUtil.getMessage("mcd.java.ddsp"));
/*     */ 
/* 131 */     segApproveResultMap.put("1", MpmLocaleUtil.getMessage("mcd.java.sptg"));
/* 132 */     segApproveResultMap.put("2", MpmLocaleUtil.getMessage("mcd.java.spwtg"));
/*     */ 
/* 134 */     segApproveResultMap.put("9", MpmLocaleUtil.getMessage("mcd.java.yqzz"));
/*     */ 
/* 136 */     MpmCacheItem segApproveResultCache = new MpmCacheItem();
/* 137 */     segApproveResultCache.setContainer(segApproveResultMap);
/* 138 */     this.cacheContainer.put("segApproveResult", segApproveResultCache);
/*     */ 
/* 141 */     TreeMap performFlagMap = new TreeMap();
/* 142 */     performFlagMap.put("0", MpmLocaleUtil.getMessage("mcd.java.wzx"));
/* 143 */     performFlagMap.put("1", MpmLocaleUtil.getMessage("mcd.java.zxcg"));
/*     */ 
/* 145 */     performFlagMap.put("2", MpmLocaleUtil.getMessage("mcd.java.zxsb"));
/*     */ 
/* 147 */     performFlagMap.put("3", MpmLocaleUtil.getMessage("mcd.java.bzz"));
/*     */ 
/* 149 */     performFlagMap.put("4", MpmLocaleUtil.getMessage("mcd.java.ddzx"));
/*     */ 
/* 151 */     performFlagMap.put("5", MpmLocaleUtil.getMessage("mcd.java.yxz"));
/*     */ 
/* 153 */     MpmCacheItem performFlagCache = new MpmCacheItem();
/* 154 */     performFlagCache.setContainer(performFlagMap);
/* 155 */     this.cacheContainer.put("campseg_step_perform_flag", performFlagCache);
/*     */ 
/* 158 */     TreeMap loadTypeMap = new TreeMap();
/* 159 */     loadTypeMap.put("0", MpmLocaleUtil.getMessage("mcd.java.wjhmyrk"));
/* 160 */     loadTypeMap.put("3", MpmLocaleUtil.getMessage("mcd.java.wjsjrkjxz"));
/*     */ 
/* 162 */     loadTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.wjsjrkcg"));
/* 163 */     loadTypeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.wjsjrksb"));
/* 164 */     MpmCacheItem loadTypeCache = new MpmCacheItem();
/* 165 */     loadTypeCache.setContainer(loadTypeMap);
/* 166 */     this.cacheContainer.put("fileLoadType", loadTypeCache);
/*     */ 
/* 168 */     TreeMap indiResourceMap = new TreeMap();
/* 169 */     indiResourceMap.put("0", MpmLocaleUtil.getMessage("mcd.java.zbk"));
/* 170 */     indiResourceMap.put("1", MpmLocaleUtil.getMessage("mcd.java.zdy"));
/* 171 */     MpmCacheItem indiResourceCache = new MpmCacheItem();
/* 172 */     indiResourceCache.setContainer(indiResourceMap);
/* 173 */     this.cacheContainer.put("campIndiResource", indiResourceCache);
/*     */ 
/* 193 */     TreeMap sourceTableTypeMap = new TreeMap();
/* 194 */     sourceTableTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.jcxxb"));
/* 195 */     sourceTableTypeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.kzxxb"));
/* 196 */     sourceTableTypeMap.put("3", MpmLocaleUtil.getMessage("mcd.java.hdjksjb"));
/* 197 */     sourceTableTypeMap.put("4", MpmLocaleUtil.getMessage("mcd.java.hdkb"));
/* 198 */     sourceTableTypeMap.put("5", MpmLocaleUtil.getMessage("mcd.java.tcsjb"));
/* 199 */     MpmCacheItem sourceTableTypeCache = new MpmCacheItem();
/* 200 */     sourceTableTypeCache.setContainer(sourceTableTypeMap);
/* 201 */     this.cacheContainer.put("sourceTableType", sourceTableTypeCache);
/*     */ 
/* 203 */     TreeMap addsourceTableTypeMap = new TreeMap();
/* 204 */     addsourceTableTypeMap.put("3", MpmLocaleUtil.getMessage("mcd.java.kzjkb"));
/*     */ 
/* 206 */     addsourceTableTypeMap.put("5", MpmLocaleUtil.getMessage("mcd.java.hmd"));
/*     */ 
/* 208 */     MpmCacheItem addsourceTableTypeCache = new MpmCacheItem();
/* 209 */     addsourceTableTypeCache.setContainer(addsourceTableTypeMap);
/* 210 */     this.cacheContainer.put("add_source_table_type", addsourceTableTypeCache);
/*     */ 
/* 213 */     TreeMap sourceColumnFlagMap = new TreeMap();
/* 214 */     sourceColumnFlagMap.put("0", MpmLocaleUtil.getMessage("mcd.java.fzbwdzd"));
/*     */ 
/* 216 */     sourceColumnFlagMap.put("2", MpmLocaleUtil.getMessage("mcd.java.zb"));
/* 217 */     sourceColumnFlagMap.put("1", MpmLocaleUtil.getMessage("mcd.java.wd"));
/* 218 */     MpmCacheItem sourceColumnFlagCache = new MpmCacheItem();
/* 219 */     sourceColumnFlagCache.setContainer(sourceColumnFlagMap);
/* 220 */     this.cacheContainer.put("source_table_column_flag", sourceColumnFlagCache);
/*     */ 
/* 223 */     TreeMap sourceColumnTypeMap = new TreeMap();
/* 224 */     sourceColumnTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.szx1"));
/* 225 */     sourceColumnTypeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.zfx"));
/* 226 */     sourceColumnTypeMap.put("3", MpmLocaleUtil.getMessage("mcd.java.rqx"));
/* 227 */     sourceColumnTypeMap.put("4", MpmLocaleUtil.getMessage("mcd.java.BLOBx"));
/* 228 */     MpmCacheItem sourceColumnTypeCache = new MpmCacheItem();
/* 229 */     sourceColumnTypeCache.setContainer(sourceColumnTypeMap);
/* 230 */     this.cacheContainer.put("mpm_ds_column_type", sourceColumnTypeCache);
/*     */ 
/* 233 */     TreeMap sourceTableStatusMap = new TreeMap();
/* 234 */     sourceTableStatusMap.put("1", MpmLocaleUtil.getMessage("mcd.java.yx1"));
/* 235 */     sourceTableStatusMap.put("2", MpmLocaleUtil.getMessage("mcd.java.wx"));
/* 236 */     sourceTableStatusMap.put("3", MpmLocaleUtil.getMessage("mcd.java.zy"));
/* 237 */     sourceTableStatusMap.put("4", MpmLocaleUtil.getMessage("mcd.java.zt1"));
/* 238 */     MpmCacheItem sourceTableStatusCache = new MpmCacheItem();
/* 239 */     sourceTableStatusCache.setContainer(sourceTableStatusMap);
/* 240 */     this.cacheContainer.put("sourceTableStatus", sourceTableStatusCache);
/*     */ 
/* 243 */     TreeMap approveDefineMap = new TreeMap();
/* 244 */     approveDefineMap.put("1", MpmLocaleUtil.getMessage("mcd.java.dyjsp"));
/* 245 */     approveDefineMap.put("2", MpmLocaleUtil.getMessage("mcd.java.dejsp"));
/* 246 */     approveDefineMap.put("3", MpmLocaleUtil.getMessage("mcd.java.dsjsp"));
/* 247 */     approveDefineMap.put("4", MpmLocaleUtil.getMessage("mcd.java.dsjsp1"));
/* 248 */     approveDefineMap.put("5", MpmLocaleUtil.getMessage("mcd.java.dwjsp"));
/* 249 */     approveDefineMap.put("6", MpmLocaleUtil.getMessage("mcd.java.dljsp"));
/* 250 */     approveDefineMap.put("7", MpmLocaleUtil.getMessage("mcd.java.dqjsp"));
/* 251 */     MpmCacheItem approveDefineCache = new MpmCacheItem();
/* 252 */     approveDefineCache.setContainer(approveDefineMap);
/* 253 */     this.cacheContainer.put("mpm_approve_level_define_no", approveDefineCache);
/*     */ 
/* 255 */     TreeMap approveLevelMap = new TreeMap();
/* 256 */     approveLevelMap.put("0", MpmLocaleUtil.getMessage("mcd.java.bxysp"));
/* 257 */     approveLevelMap.put("1", MpmLocaleUtil.getMessage("mcd.java.yjsp"));
/* 258 */     approveLevelMap.put("2", MpmLocaleUtil.getMessage("mcd.java.ejsp"));
/* 259 */     approveLevelMap.put("3", MpmLocaleUtil.getMessage("mcd.java.sjsp"));
/* 260 */     approveLevelMap.put("4", MpmLocaleUtil.getMessage("mcd.java.sjsp1"));
/* 261 */     approveLevelMap.put("5", MpmLocaleUtil.getMessage("mcd.java.wjsp"));
/* 262 */     approveLevelMap.put("6", MpmLocaleUtil.getMessage("mcd.java.ljsp"));
/* 263 */     approveLevelMap.put("7", MpmLocaleUtil.getMessage("mcd.java.qjsp"));
/* 264 */     MpmCacheItem approveLevelCache = new MpmCacheItem();
/* 265 */     approveLevelCache.setContainer(approveLevelMap);
/* 266 */     this.cacheContainer.put("mpm_approve_level_define", approveDefineCache);
/*     */ 
/* 269 */     TreeMap warnFlagMap = new TreeMap();
/* 270 */     warnFlagMap.put("0", MpmLocaleUtil.getMessage("mcd.java.gbgjjz"));
/* 271 */     warnFlagMap.put("1", MpmLocaleUtil.getMessage("mcd.java.qygjjz"));
/* 272 */     MpmCacheItem warnFlagCache = new MpmCacheItem();
/* 273 */     warnFlagCache.setContainer(warnFlagMap);
/* 274 */     this.cacheContainer.put("mpm_warn_flag_define", warnFlagCache);
/*     */ 
/* 277 */     TreeMap extEvaluationUrlMap = new TreeMap();
/* 278 */     extEvaluationUrlMap.put("1", MpmLocaleUtil.getMessage("mcd.java.yxapgURL"));
/*     */ 
/* 280 */     extEvaluationUrlMap.put("2", MpmLocaleUtil.getMessage("mcd.java.yxhdpgURL"));
/*     */ 
/* 282 */     MpmCacheItem extEvaluationUrlCache = new MpmCacheItem();
/* 283 */     extEvaluationUrlCache.setContainer(extEvaluationUrlMap);
/* 284 */     this.cacheContainer.put("mpm_ext_evaluation_url", extEvaluationUrlCache);
/*     */ 
/* 287 */     TreeMap costTypeMap = new TreeMap();
/* 288 */     costTypeMap.put("100", MpmLocaleUtil.getMessage("mcd.java.sclcb"));
/* 289 */     costTypeMap.put("200", MpmLocaleUtil.getMessage("mcd.java.cwlcb"));
/* 290 */     MpmCacheItem costTypeCache = new MpmCacheItem();
/* 291 */     costTypeCache.setContainer(costTypeMap);
/* 292 */     this.cacheContainer.put("mpm_cost_type_define", costTypeCache);
/*     */ 
/* 294 */     TreeMap ruleApplyTypeMap = new TreeMap();
/* 295 */     ruleApplyTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.notinms"));
/*     */ 
/* 297 */     ruleApplyTypeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.inms"));
/* 298 */     MpmCacheItem ruleApplyTypeCache = new MpmCacheItem();
/* 299 */     ruleApplyTypeCache.setContainer(ruleApplyTypeMap);
/* 300 */     this.cacheContainer.put("filterRuleApplyTYpe", ruleApplyTypeCache);
/*     */ 
/* 303 */     TreeMap execModeMap = new TreeMap();
/* 304 */     execModeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.sd1"));
/* 305 */     execModeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.zd"));
/* 306 */     MpmCacheItem execModeCache = new MpmCacheItem();
/* 307 */     execModeCache.setContainer(execModeMap);
/* 308 */     this.cacheContainer.put("execMode", execModeCache);
/*     */ 
/* 311 */     TreeMap campsegStatMap = new TreeMap();
/*     */ 
/* 348 */     MpmCacheItem campsegStatCache = new MpmCacheItem();
/* 349 */     campsegStatCache.setContainer(campsegStatMap);
/* 350 */     this.cacheContainer.put("mpm_campseg_stat_define", campsegStatCache);
/*     */ 
/* 353 */     TreeMap campsegConfirmFlagMap = new TreeMap();
/* 354 */     campsegConfirmFlagMap.put("-2", MpmLocaleUtil.getMessage("mcd.java.bxyqr"));
/* 355 */     campsegConfirmFlagMap.put("0", MpmLocaleUtil.getMessage("mcd.java.wtjqr"));
/* 356 */     campsegConfirmFlagMap.put("3", MpmLocaleUtil.getMessage("mcd.java.ddqr"));
/* 357 */     campsegConfirmFlagMap.put("1", MpmLocaleUtil.getMessage("mcd.java.qrwb"));
/* 358 */     campsegConfirmFlagMap.put("2", MpmLocaleUtil.getMessage("mcd.java.qrwtg"));
/* 359 */     campsegConfirmFlagMap.put("9", MpmLocaleUtil.getMessage("mcd.java.qryxzz"));
/*     */ 
/* 361 */     MpmCacheItem campsegConfirmFlagCache = new MpmCacheItem();
/* 362 */     campsegConfirmFlagCache.setContainer(campsegConfirmFlagMap);
/* 363 */     this.cacheContainer.put("mpm_confirm_flag", campsegConfirmFlagCache);
/*     */ 
/* 366 */     TreeMap campsegStepMap = new TreeMap();
/* 367 */     campsegStepMap.put("40", MpmLocaleUtil.getMessage("mcd.java.hdxxdy"));
/* 368 */     campsegStepMap.put("5", MpmLocaleUtil.getMessage("mcd.java.drmbkhwj"));
/*     */ 
/* 370 */     campsegStepMap.put("6", MpmLocaleUtil.getMessage("mcd.java.khqmbxz"));
/*     */ 
/* 372 */     campsegStepMap.put("10", MpmLocaleUtil.getMessage("mcd.java.khsxsz"));
/*     */ 
/* 374 */     campsegStepMap.put("20", MpmLocaleUtil.getMessage("mcd.java.khdwsz"));
/* 375 */     campsegStepMap.put("7", MpmLocaleUtil.getMessage("mcd.java.yxxgxz"));
/*     */ 
/* 377 */     campsegStepMap.put("50", MpmLocaleUtil.getMessage("mcd.java.ssyxsz"));
/* 378 */     campsegStepMap.put("25", MpmLocaleUtil.getMessage("mcd.java.khqys"));
/*     */ 
/* 380 */     campsegStepMap.put("30", MpmLocaleUtil.getMessage("mcd.java.tctjsz"));
/* 381 */     campsegStepMap.put("60", MpmLocaleUtil.getMessage("mcd.java.hdnbsp"));
/* 382 */     campsegStepMap.put("70", MpmLocaleUtil.getMessage("mcd.java.hdqdsp"));
/*     */ 
/* 384 */     campsegStepMap.put("80", MpmLocaleUtil.getMessage("mcd.java.pdzx"));
/* 385 */     MpmCacheItem campsegStepCache = new MpmCacheItem();
/* 386 */     campsegStepCache.setContainer(campsegStepMap);
/* 387 */     this.cacheContainer.put("mpm_active_step_id", campsegStepCache);
/*     */ 
/* 390 */     TreeMap dataExportItemMap = new TreeMap();
/* 391 */     dataExportItemMap.put("0", MpmLocaleUtil.getMessage("mcd.java.zdcdm"));
/* 392 */     dataExportItemMap.put("1", MpmLocaleUtil.getMessage("mcd.java.dcdmhzwms"));
/* 393 */     dataExportItemMap.put("3", MpmLocaleUtil.getMessage("mcd.java.zdczwms"));
/* 394 */     MpmCacheItem dataExportItemCache = new MpmCacheItem();
/* 395 */     dataExportItemCache.setContainer(dataExportItemMap);
/* 396 */     this.cacheContainer.put("mpm_data_export_item", dataExportItemCache);
/*     */ 
/* 399 */     TreeMap templetClassMap = new TreeMap();
/* 400 */     templetClassMap.put("0", MpmLocaleUtil.getMessage("mcd.java.khsxmb"));
/* 401 */     templetClassMap.put("1", MpmLocaleUtil.getMessage("mcd.java.khsxmb1"));
/* 402 */     templetClassMap.put("2", MpmLocaleUtil.getMessage("mcd.java.khtcmb"));
/* 403 */     templetClassMap.put("3", MpmLocaleUtil.getMessage("mcd.java.khfzmb"));
/* 404 */     MpmCacheItem templetClassCache = new MpmCacheItem();
/* 405 */     templetClassCache.setContainer(templetClassMap);
/* 406 */     this.cacheContainer.put("mpm_templet_class_info", templetClassCache);
/*     */ 
/* 409 */     TreeMap ResFlagMap = new TreeMap();
/* 410 */     ResFlagMap.put("1", MpmLocaleUtil.getMessage("mcd.java.yx1"));
/* 411 */     ResFlagMap.put("2", MpmLocaleUtil.getMessage("mcd.java.zt1"));
/* 412 */     ResFlagMap.put("3", MpmLocaleUtil.getMessage("mcd.java.wx"));
/* 413 */     MpmCacheItem ResFlagCache = new MpmCacheItem();
/* 414 */     ResFlagCache.setContainer(ResFlagMap);
/* 415 */     this.cacheContainer.put("mpm_res_flag_status", ResFlagCache);
/*     */ 
/* 418 */     TreeMap templetTypeMap = new TreeMap();
/* 419 */     templetTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.gymb"));
/* 420 */     templetTypeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.symb"));
/* 421 */     templetTypeMap.put("3", MpmLocaleUtil.getMessage("mcd.java.zymb"));
/* 422 */     templetTypeMap.put("4", MpmLocaleUtil.getMessage("mcd.java.wz"));
/* 423 */     MpmCacheItem templetTypeCache = new MpmCacheItem();
/* 424 */     templetTypeCache.setContainer(templetTypeMap);
/* 425 */     this.cacheContainer.put("mpm_templet_type_info", templetTypeCache);
/*     */ 
/* 428 */     TreeMap stepPhaseMap = new TreeMap();
/* 429 */     stepPhaseMap.put("1", MpmLocaleUtil.getMessage("mcd.java.chjd"));
/* 430 */     stepPhaseMap.put("2", MpmLocaleUtil.getMessage("mcd.java.spjd"));
/* 431 */     stepPhaseMap.put("3", MpmLocaleUtil.getMessage("mcd.java.zxjd"));
/* 432 */     stepPhaseMap.put("4", MpmLocaleUtil.getMessage("mcd.java.pgjd"));
/* 433 */     MpmCacheItem stepPhaseCache = new MpmCacheItem();
/* 434 */     stepPhaseCache.setContainer(stepPhaseMap);
/* 435 */     this.cacheContainer.put("mpm_camp_step_phase", stepPhaseCache);
/*     */ 
/* 439 */     TreeMap fieldMap = new TreeMap();
/* 440 */     fieldMap.put("vip_manager_id", MpmLocaleUtil.getMessage("mcd.java.dkhjl"));
/* 441 */     MpmCacheItem fieldCache = new MpmCacheItem();
/* 442 */     fieldCache.setContainer(fieldMap);
/* 443 */     this.cacheContainer.put("field", fieldCache);
/*     */ 
/* 446 */     TreeMap contactType = new TreeMap();
/* 447 */     contactType.put("3", MpmLocaleUtil.getMessage("mcd.java.dzqd"));
/* 448 */     contactType.put("1", MpmLocaleUtil.getMessage("mcd.java.khjl"));
/* 449 */     contactType.put("2", MpmLocaleUtil.getMessage("mcd.java.ctqd"));
/* 450 */     MpmCacheItem contactTypeCache = new MpmCacheItem();
/* 451 */     contactTypeCache.setContainer(contactType);
/* 452 */     this.cacheContainer.put("contactType", contactTypeCache);
/*     */ 
/* 455 */     TreeMap feedbackDateMap = new TreeMap();
/* 456 */     feedbackDateMap.put("0", MpmLocaleUtil.getMessage("mcd.java.bxytgfksj"));
/* 457 */     feedbackDateMap.put("1", MpmLocaleUtil.getMessage("mcd.java.mttgycfksj"));
/* 458 */     feedbackDateMap.put("3", MpmLocaleUtil.getMessage("mcd.java.mytgycfksj"));
/* 459 */     feedbackDateMap.put("4", MpmLocaleUtil.getMessage("mcd.java.mjdtgycfks"));
/* 460 */     feedbackDateMap.put("2", MpmLocaleUtil.getMessage("mcd.java.mztgycfksj"));
/* 461 */     feedbackDateMap.put("5", MpmLocaleUtil.getMessage("mcd.java.azzdsjfksj"));
/* 462 */     MpmCacheItem feedbackDateCache = new MpmCacheItem();
/* 463 */     feedbackDateCache.setContainer(feedbackDateMap);
/* 464 */     this.cacheContainer.put("feedbackDate", feedbackDateCache);
/*     */ 
/* 467 */     TreeMap userSubSectionMap = new TreeMap();
/* 468 */     userSubSectionMap.put("2", MpmLocaleUtil.getMessage("mcd.java.mbfz"));
/* 469 */     userSubSectionMap.put("1", MpmLocaleUtil.getMessage("mcd.java.dkhjlfz"));
/* 470 */     userSubSectionMap.put("0", MpmLocaleUtil.getMessage("mcd.java.syfz"));
/* 471 */     MpmCacheItem userSubSectionCache = new MpmCacheItem();
/* 472 */     userSubSectionCache.setContainer(userSubSectionMap);
/* 473 */     this.cacheContainer.put("user_subselection_type", userSubSectionCache);
/*     */ 
/* 476 */     TreeMap userHandleFlagMap = new TreeMap();
/* 477 */     userHandleFlagMap.put("1", MpmLocaleUtil.getMessage("mcd.java.s"));
/* 478 */     userHandleFlagMap.put("0", MpmLocaleUtil.getMessage("mcd.java.f"));
/* 479 */     MpmCacheItem userHandleFlagCache = new MpmCacheItem();
/* 480 */     userHandleFlagCache.setContainer(userHandleFlagMap);
/* 481 */     this.cacheContainer.put("user_handle_flag", userHandleFlagCache);
/*     */ 
/* 484 */     TreeMap elChannelMap = new TreeMap();
/* 485 */     elChannelMap.put("sms", MpmLocaleUtil.getMessage("mcd.java.dx"));
/* 486 */     elChannelMap.put("mms", MpmLocaleUtil.getMessage("mcd.java.cx"));
/* 487 */     elChannelMap.put("wap", "WAP");
/* 488 */     MpmCacheItem elChannelCache = new MpmCacheItem();
/* 489 */     elChannelCache.setContainer(elChannelMap);
/* 490 */     this.cacheContainer.put("elchannel", elChannelCache);
/*     */ 
/* 493 */     TreeMap channelTypeMap = new TreeMap();
/* 494 */     channelTypeMap.put("900", MpmLocaleUtil.getMessage("mcd.java.dkhjl"));
/* 495 */     channelTypeMap.put("904", MpmLocaleUtil.getMessage("mcd.java.cfkhjl"));
/* 496 */     channelTypeMap.put("901", MpmLocaleUtil.getMessage("mcd.java.dx"));
/* 497 */     channelTypeMap.put("902", MpmLocaleUtil.getMessage("mcd.java.cx"));
/* 498 */     channelTypeMap.put("903", "WAP PUSH");
/* 499 */     MpmCacheItem channelTypeCache = new MpmCacheItem();
/* 500 */     channelTypeCache.setContainer(channelTypeMap);
/* 501 */     this.cacheContainer.put("channel_type", channelTypeCache);
/*     */ 
/* 503 */     TreeMap managerChannelMap = new TreeMap();
/* 504 */     managerChannelMap.put("900", MpmLocaleUtil.getMessage("mcd.java.dkhjl"));
/* 505 */     managerChannelMap.put("904", MpmLocaleUtil.getMessage("mcd.java.cfkhjl"));
/* 506 */     MpmCacheItem managerChannelCache = new MpmCacheItem();
/* 507 */     managerChannelCache.setContainer(managerChannelMap);
/* 508 */     this.cacheContainer.put("channel_manager_type", managerChannelCache);
/*     */ 
/* 510 */     TreeMap eleChannelMap = new TreeMap();
/* 511 */     eleChannelMap.put("901", MpmLocaleUtil.getMessage("mcd.java.dx"));
/* 512 */     eleChannelMap.put("902", MpmLocaleUtil.getMessage("mcd.java.cx"));
/* 513 */     eleChannelMap.put("903", "WAP PUSH");
/* 514 */     MpmCacheItem eleChannelCache = new MpmCacheItem();
/* 515 */     eleChannelCache.setContainer(eleChannelMap);
/* 516 */     this.cacheContainer.put("channel_ele_type", eleChannelCache);
/*     */ 
/* 518 */     TreeMap campTypeMap = new TreeMap();
/* 519 */     campTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.fcxc"));
/* 520 */     campTypeMap.put("0", MpmLocaleUtil.getMessage("mcd.java.cxc"));
/* 521 */     campTypeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.ssyx"));
/* 522 */     MpmCacheItem campTypeCache = new MpmCacheItem();
/* 523 */     campTypeCache.setContainer(campTypeMap);
/* 524 */     this.cacheContainer.put("campType", campTypeCache);
/*     */ 
/* 526 */     TreeMap disModeMap = new TreeMap();
/* 527 */     disModeMap.put("trend", MpmLocaleUtil.getMessage("mcd.java.qxt"));
/* 528 */     disModeMap.put("bar", MpmLocaleUtil.getMessage("mcd.java.zxt"));
/* 529 */     disModeMap.put("pie", MpmLocaleUtil.getMessage("mcd.java.bt"));
/* 530 */     MpmCacheItem disModeCache = new MpmCacheItem();
/* 531 */     disModeCache.setContainer(disModeMap);
/* 532 */     this.cacheContainer.put("MPM_ANALYSE_DIS_MODE", disModeCache);
/*     */ 
/* 534 */     TreeMap orderFieldMap = new TreeMap();
/* 535 */     orderFieldMap.put(" tval1 ", MpmLocaleUtil.getMessage("mcd.java.jckhs"));
/* 536 */     orderFieldMap.put(" tval2 ", MpmLocaleUtil.getMessage("mcd.java.jccgkhs"));
/* 537 */     orderFieldMap.put(" val2_rate ", MpmLocaleUtil.getMessage("mcd.java.jccgzb"));
/* 538 */     orderFieldMap.put(" tval3 ", MpmLocaleUtil.getMessage("mcd.java.jshdkhs"));
/* 539 */     orderFieldMap.put(" val3_rate ", MpmLocaleUtil.getMessage("mcd.java.jshdzb"));
/* 540 */     orderFieldMap.put(" tval4 ", MpmLocaleUtil.getMessage("mcd.java.mjshdkhs"));
/* 541 */     orderFieldMap.put(" val4_rate ", MpmLocaleUtil.getMessage("mcd.java.mjshdzb"));
/* 542 */     orderFieldMap.put(" task_rate ", MpmLocaleUtil.getMessage("mcd.java.wcrwzb"));
/* 543 */     MpmCacheItem orderFieldCache = new MpmCacheItem();
/* 544 */     orderFieldCache.setContainer(orderFieldMap);
/* 545 */     this.cacheContainer.put("mpm_order_field", orderFieldCache);
/*     */ 
/* 548 */     TreeMap columnStatusMap = new TreeMap();
/* 549 */     columnStatusMap.put("1", MpmLocaleUtil.getMessage("mcd.java.yx1"));
/* 550 */     columnStatusMap.put("2", MpmLocaleUtil.getMessage("mcd.java.wx"));
/* 551 */     MpmCacheItem columnStatusCache = new MpmCacheItem();
/* 552 */     columnStatusCache.setContainer(columnStatusMap);
/* 553 */     this.cacheContainer.put("column_status", columnStatusCache);
/*     */ 
/* 556 */     TreeMap approveObjTypeMap = new TreeMap();
/* 557 */     approveObjTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.ssbm"));
/* 558 */     approveObjTypeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.zdbm"));
/* 559 */     approveObjTypeMap.put("3", MpmLocaleUtil.getMessage("mcd.java.zdspr"));
/*     */ 
/* 561 */     MpmCacheItem approveObjTypeCache = new MpmCacheItem();
/* 562 */     approveObjTypeCache.setContainer(approveObjTypeMap);
/* 563 */     this.cacheContainer.put("approve_obj_type", approveObjTypeCache);
/*     */ 
/* 566 */     TreeMap approveFlowTypeMap = new TreeMap();
/* 567 */     approveFlowTypeMap.put("1", "普通");
/* 568 */     approveFlowTypeMap.put("2", "会签");
/* 569 */     MpmCacheItem approveFlowTypeCache = new MpmCacheItem();
/* 570 */     approveFlowTypeCache.setContainer(approveFlowTypeMap);
/* 571 */     this.cacheContainer.put("approveFlowType", approveFlowTypeCache);
/*     */ 
/* 574 */     TreeMap custGroupTypeMap = new TreeMap();
/* 575 */     custGroupTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.zdySQLtj"));
/* 576 */     custGroupTypeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.zdySQLcjqd"));
/*     */ 
/* 578 */     custGroupTypeMap.put("3", MpmLocaleUtil.getMessage("mcd.java.wjdrcjqd"));
/*     */ 
/* 580 */     custGroupTypeMap.put("4", MpmLocaleUtil.getMessage("mcd.java.khqyscjqd"));
/*     */ 
/* 582 */     custGroupTypeMap.put("5", MpmLocaleUtil.getMessage("mcd.java.hdxgcjqd"));
/*     */ 
/* 584 */     MpmCacheItem custGroupTypeCache = new MpmCacheItem();
/* 585 */     custGroupTypeCache.setContainer(custGroupTypeMap);
/* 586 */     this.cacheContainer.put("custGroupType", custGroupTypeCache);
/*     */ 
/* 590 */     TreeMap custGroupEvaluateMap = new TreeMap();
/* 591 */     custGroupEvaluateMap.put("0", MpmLocaleUtil.getMessage("mcd.java.bpg"));
/*     */ 
/* 593 */     custGroupEvaluateMap.put("1", MpmLocaleUtil.getMessage("mcd.java.pg"));
/*     */ 
/* 595 */     MpmCacheItem custGroupEvaluateCache = new MpmCacheItem();
/* 596 */     custGroupEvaluateCache.setContainer(custGroupEvaluateMap);
/* 597 */     this.cacheContainer.put("evaluateFlag", custGroupEvaluateCache);
/*     */ 
/* 600 */     TreeMap custGroupStatusMap = new TreeMap();
/* 601 */     custGroupStatusMap.put("0", MpmLocaleUtil.getMessage("mcd.java.chz"));
/*     */ 
/* 603 */     custGroupStatusMap.put("1", MpmLocaleUtil.getMessage("mcd.java.ky"));
/* 604 */     custGroupStatusMap.put("2", MpmLocaleUtil.getMessage("mcd.java.ddsc"));
/*     */ 
/* 606 */     custGroupStatusMap.put("4", MpmLocaleUtil.getMessage("mcd.java.zzsc"));
/*     */ 
/* 608 */     custGroupStatusMap.put("3", MpmLocaleUtil.getMessage("mcd.java.scsb1"));
/*     */ 
/* 610 */     MpmCacheItem custGroupStatusCache = new MpmCacheItem();
/* 611 */     custGroupStatusCache.setContainer(custGroupStatusMap);
/* 612 */     this.cacheContainer.put("cust_group_status", custGroupStatusCache);
/*     */ 
/* 615 */     TreeMap dataSourceCycleTypeMap = new TreeMap();
/* 616 */     dataSourceCycleTypeMap.put("1", MpmLocaleUtil.getMessage("mcd.java.myyz"));
/*     */ 
/* 618 */     dataSourceCycleTypeMap.put("2", MpmLocaleUtil.getMessage("mcd.java.mryz"));
/* 619 */     dataSourceCycleTypeMap.put("3", MpmLocaleUtil.getMessage("mcd.java.wlsb"));
/* 620 */     MpmCacheItem dataSourceCycleTypeCache = new MpmCacheItem();
/* 621 */     dataSourceCycleTypeCache.setContainer(dataSourceCycleTypeMap);
/* 622 */     this.cacheContainer.put("source_cycle_type", dataSourceCycleTypeCache);
/*     */ 
/* 625 */     TreeMap dimAvoidBotherMap = new TreeMap();
/* 626 */     dimAvoidBotherMap.put("1", MpmLocaleUtil.getMessage("mcd.java.khmdr"));
/*     */ 
/* 628 */     dimAvoidBotherMap.put("0", MpmLocaleUtil.getMessage("mcd.java.qdmdr"));
/*     */ 
/* 630 */     MpmCacheItem dimAvoidBotherCache = new MpmCacheItem();
/* 631 */     dimAvoidBotherCache.setContainer(dimAvoidBotherMap);
/* 632 */     this.cacheContainer.put("dim_avoid_bother_type_class", dimAvoidBotherCache);
/*     */ 
/* 635 */     TreeMap retrunMap = new TreeMap();
/*     */ 
/* 637 */     retrunMap.put("907-1", MpmLocaleUtil.getMessage("mcd.java.drcg"));
/* 638 */     retrunMap.put("907-2", MpmLocaleUtil.getMessage("mcd.java.drsb"));
/* 639 */     retrunMap.put("907-3", MpmLocaleUtil.getMessage("mcd.java.hdsx"));
/* 640 */     retrunMap.put("907-4", MpmLocaleUtil.getMessage("mcd.java.hdwc"));
/*     */ 
/* 642 */     retrunMap.put("905-3", MpmLocaleUtil.getMessage("mcd.java.drzcsh"));
/* 643 */     retrunMap.put("905-6", MpmLocaleUtil.getMessage("mcd.java.shcg"));
/* 644 */     retrunMap.put("905-7", MpmLocaleUtil.getMessage("mcd.java.drzczs"));
/* 645 */     retrunMap.put("905-8", MpmLocaleUtil.getMessage("mcd.java.shwcsb"));
/* 646 */     retrunMap.put("905-9", MpmLocaleUtil.getMessage("mcd.java.drsbsh"));
/* 647 */     retrunMap.put("905-10", MpmLocaleUtil.getMessage("mcd.java.drsbzs"));
/*     */ 
/* 649 */     retrunMap.put("906-3", MpmLocaleUtil.getMessage("mcd.java.drzcsh"));
/* 650 */     retrunMap.put("906-6", MpmLocaleUtil.getMessage("mcd.java.shcg"));
/* 651 */     retrunMap.put("906-7", MpmLocaleUtil.getMessage("mcd.java.drzczs"));
/* 652 */     retrunMap.put("906-8", MpmLocaleUtil.getMessage("mcd.java.shwcsb"));
/* 653 */     retrunMap.put("906-9", MpmLocaleUtil.getMessage("mcd.java.drsbsh"));
/* 654 */     retrunMap.put("906-10", MpmLocaleUtil.getMessage("mcd.java.drsbzs"));
/* 655 */     MpmCacheItem retrunCache = new MpmCacheItem();
/* 656 */     retrunCache.setContainer(retrunMap);
/* 657 */     this.cacheContainer.put("mpm_interface_return_code", retrunCache);
/*     */ 
/* 660 */     Map bigMap = CacheManager.getInstance().getAllCache();
/* 661 */     bigMap.putAll(this.cacheContainer);
/*     */ 
/* 663 */     return true;
/*     */   }
/*     */ 
/*     */   public String getNameByKeyFromDic(String dicName, Object key)
/*     */   {
/* 673 */     synchronized (lock) {
/* 674 */       String name = "";
/* 675 */       if (key == null) {
/* 676 */         return name;
/*     */       }
/* 678 */       String tmpKey = key.toString();
/* 679 */       String mapValue = (String)SimpleCache.getInstance().get(dicName + "_getNameByKeyFromDic_" + key, String.class);
/* 680 */       if (mapValue != null) {
/* 681 */         return mapValue;
/*     */       }
/*     */ 
/* 684 */       IdNameMapper mapper = null;
/*     */       try {
/* 686 */         mapper = (IdNameMapper)SpringContext.getBean(dicName, IdNameMapper.class);
/*     */       }
/*     */       catch (Exception e) {
/* 689 */         log.error("", e);
/*     */       }
/* 691 */       if (mapper != null)
/* 692 */         name = mapper.getNameById(tmpKey);
/*     */       else {
/* 694 */         name = SystemCacheManager.getInstance().getNameById(dicName, tmpKey);
/*     */       }
/*     */ 
/* 698 */       SimpleCache.getInstance().put(dicName + "_getNameByKeyFromDic_" + key, name, 3600L);
/*     */ 
/* 700 */       return name;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getNameByTypeAndKey(Object type, Object key)
/*     */   {
/* 711 */     String res = "--";
/* 712 */     if (this.cacheContainer.containsKey(type)) {
/* 713 */       TreeMap tmpMap = (TreeMap)((MpmCacheItem)this.cacheContainer.get(type)).getContainer();
/* 714 */       if (tmpMap.containsKey(key)) {
/* 715 */         res = (String)tmpMap.get(key);
/*     */       }
/*     */     }
/* 718 */     return res;
/*     */   }
/*     */ 
/*     */   public Map getMapByType(Object type)
/*     */   {
/* 727 */     TreeMap retMap = new TreeMap();
/* 728 */     if (this.cacheContainer.containsKey(type)) {
/* 729 */       retMap = (TreeMap)((MpmCacheItem)this.cacheContainer.get(type)).getContainer();
/*     */     }
/* 731 */     return (Map)retMap.clone();
/*     */   }
/*     */ 
/*     */   public boolean refreshByKey(Object key)
/*     */   {
/* 739 */     return false;
/*     */   }
/*     */ 
/*     */   public String getMpmContextPath() {
/* 743 */     return this.mpmContextPath;
/*     */   }
/*     */ 
/*     */   public void setMpmContextPath(String mpmContextPath) {
/* 747 */     this.mpmContextPath = mpmContextPath;
/*     */   }
/*     */ 
/*     */   public synchronized String getSendOddSerialNum(String channelType)
/*     */   {
/* 758 */     Integer serialNum = (Integer)SimpleCache.getInstance().get("DAY_SERIAL_NUM" + channelType);
/* 759 */     if (serialNum == null) {
/*     */       try {
/* 761 */         JdbcTemplate jt = (JdbcTemplate)SpringContext.getBean("jdbcTemplate", JdbcTemplate.class);
/* 762 */         String querySql = "select max(day_serial_num)  from mcd_sendodd_file_log where channel_type = ? and   send_date > ?";
/* 763 */         Calendar c = Calendar.getInstance();
/* 764 */         c.set(11, 0);
/* 765 */         c.set(12, 0);
/* 766 */         c.set(13, 0);
/* 767 */         serialNum = Integer.valueOf(jt.queryForInt(querySql, new Object[] { channelType, c.getTime() }));
/*     */       } catch (Exception e) {
/* 769 */         log.error("", e);
/*     */       }
/*     */     }
/*     */ 
/* 773 */     Calendar c = Calendar.getInstance();
/* 774 */     c.set(11, 23);
/* 775 */     c.set(12, 59);
/* 776 */     c.set(13, 59);
/* 777 */     long expireTime = c.getTimeInMillis() - System.currentTimeMillis();
/* 778 */     SimpleCache.getInstance().put("DAY_SERIAL_NUM" + channelType, Integer.valueOf(serialNum.intValue() + 1), expireTime);
/*     */ 
/* 780 */     return String.format("%04d", new Object[] { Integer.valueOf(serialNum.intValue() + 1) });
/*     */   }
/*     */ 
/*     */   public synchronized Date getSendOddLastRunTime(Date currentDate) {
/* 784 */     Date date = (Date)SimpleCache.getInstance().get("CEP_SENDODD_LAST_RUN_TIME");
/* 785 */     if (date == null) {
/*     */       try {
/* 787 */         JdbcTemplate jt = (JdbcTemplate)SpringContext.getBean("jdbcTemplate", JdbcTemplate.class);
/* 788 */         String querySql = "select max(end_time) from mcd_sendodd_file_log where send_date > ?";
/* 789 */         Calendar c = Calendar.getInstance();
/* 790 */         c.set(11, 0);
/* 791 */         c.set(12, 0);
/* 792 */         c.set(13, 0);
/* 793 */         date = (Date)jt.queryForObject(querySql, new Object[] { c.getTime() }, Date.class);
/* 794 */         if (date == null)
/* 795 */           date = c.getTime();
/*     */       }
/*     */       catch (Exception e) {
/* 798 */         log.error("", e);
/*     */       }
/*     */     }
/* 801 */     SimpleCache.getInstance().put("CEP_SENDODD_LAST_RUN_TIME", currentDate);
/* 802 */     return date;
/*     */   }
/*     */ 
/*     */   static class MpmCacheHolder
/*     */   {
/*  42 */     static MpmCache instance = new MpmCache(null);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.MpmCache
 * JD-Core Version:    0.6.2
 */
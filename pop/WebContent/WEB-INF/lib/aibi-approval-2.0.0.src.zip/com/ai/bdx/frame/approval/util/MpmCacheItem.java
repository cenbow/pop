/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import com.asiainfo.biframe.common.cache.CacheBase;
/*    */ import java.util.Map;
/*    */ import java.util.TreeMap;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class MpmCacheItem extends CacheBase
/*    */ {
/* 18 */   private static Logger log = LogManager.getLogger();
/*    */   protected TreeMap mpmItemContainer;
/*    */ 
/*    */   public MpmCacheItem()
/*    */   {
/* 22 */     this.mpmItemContainer = new TreeMap();
/*    */   }
/*    */ 
/*    */   public String getNameByKey(Object key)
/*    */   {
/* 27 */     Object object = getObjectByKey(key);
/*    */ 
/* 29 */     return null == object ? "" : (String)object;
/*    */   }
/*    */ 
/*    */   public Object getObjectByKey(Object key)
/*    */   {
/* 35 */     if (key == null) {
/* 36 */       return null;
/*    */     }
/*    */ 
/* 39 */     if (this.mpmItemContainer.containsKey(key)) {
/* 40 */       return this.mpmItemContainer.get(key);
/*    */     }
/* 42 */     refreshByKey(key);
/* 43 */     if (this.mpmItemContainer.containsKey(key)) {
/* 44 */       return this.mpmItemContainer.get(key);
/*    */     }
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   public Map getContainer()
/*    */   {
/* 52 */     return this.mpmItemContainer;
/*    */   }
/*    */ 
/*    */   public void setContainer(TreeMap mpmItemContainer) {
/* 56 */     this.mpmItemContainer = mpmItemContainer;
/*    */   }
/*    */ 
/*    */   public boolean refreshByKey(Object obj)
/*    */   {
/* 61 */     log.debug("not use the refresh!");
/* 62 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean refreshAll()
/*    */   {
/* 68 */     return super.refreshAll();
/*    */   }
/*    */ 
/*    */   protected boolean init()
/*    */   {
/* 74 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.MpmCacheItem
 * JD-Core Version:    0.6.2
 */
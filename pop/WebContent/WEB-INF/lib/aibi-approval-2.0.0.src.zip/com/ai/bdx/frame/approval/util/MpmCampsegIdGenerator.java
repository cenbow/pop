/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.id.IdentifierGenerator;
/*    */ 
/*    */ public class MpmCampsegIdGenerator
/*    */   implements IdentifierGenerator
/*    */ {
/* 22 */   private static final Logger log = LogManager.getLogger();
/*    */ 
/*    */   public Serializable generate(SessionImplementor arg0, Object arg1)
/*    */     throws HibernateException
/*    */   {
/* 29 */     return MpmUtil.generateCampsegAndTaskNo();
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 33 */     MpmCampsegIdGenerator id = new MpmCampsegIdGenerator();
/*    */     try {
/* 35 */       log.debug(id.generate(null, null));
/*    */     } catch (Exception e) {
/* 37 */       log.error("", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.MpmCampsegIdGenerator
 * JD-Core Version:    0.6.2
 */
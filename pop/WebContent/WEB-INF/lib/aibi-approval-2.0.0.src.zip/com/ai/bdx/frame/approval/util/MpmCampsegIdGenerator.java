package com.ai.bdx.frame.approval.util;

import java.io.Serializable;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

/**
 * Created on 12:06:30 PM
 *
 * <p>Title: </p>
 * <p>Description: 活动波次编码生成器</p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MpmCampsegIdGenerator implements IdentifierGenerator {
	private static final Logger log = LogManager.getLogger();

	public MpmCampsegIdGenerator() {
		super();
	}

	public Serializable generate(SessionImplementor arg0, Object arg1) throws HibernateException {
		return MpmUtil.generateCampsegAndTaskNo();
	}

	public static void main(String[] args) {
		MpmCampsegIdGenerator id = new MpmCampsegIdGenerator();
		try {
			log.debug(id.generate(null, null));
		} catch (Exception e) {
			log.error("", e);
		}
	}
}

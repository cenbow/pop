/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class MpmConfigure
/*     */ {
/* 137 */   private static final Logger log = LogManager.getLogger();
/* 138 */   private static MpmConfigure configure = new MpmConfigure();
/*     */   private static final String DEFAULT_CONFIG_TYPE = "MPM_PROPERTIES";
/* 140 */   private static Map<String, Object> modifiedTimeMap = new HashMap();
/* 141 */   private static Map<String, Object> fileMap = new HashMap();
/* 142 */   private static Map<String, Object> fileNameMap = new HashMap();
/* 143 */   private static Map<String, Object> configMap = new HashMap();
/*     */ 
/*     */   public static MpmConfigure getInstance()
/*     */   {
/*  24 */     return configure;
/*     */   }
/*     */ 
/*     */   public void setConfFileName(String file) throws Exception
/*     */   {
/*  29 */     String province = Configure.getInstance().getProperty("PROVINCE");
/*  30 */     log.info("province------------------" + province);
/*  31 */     initProperties("MPM_PROPERTIES", file, province);
/*     */   }
/*     */ 
/*     */   public String getProperty(String strKey) {
/*     */     try {
/*  36 */       return getProperty("MPM_PROPERTIES", strKey);
/*     */     } catch (Exception e) {
/*  38 */       log.error("", e);
/*     */     }
/*  40 */     return null;
/*     */   }
/*     */ 
/*     */   public String getProperty(String configType, String strKey) throws Exception {
/*  44 */     String province = Configure.getInstance().getProperty("PROVINCE");
/*  45 */     if ((StringUtil.isEmpty(province)) || ("demo".equalsIgnoreCase(province))) {
/*  46 */       province = "default";
/*     */     }
/*  48 */     if (StringUtil.isEmpty(configType))
/*  49 */       throw new Exception("----Configure--err-------:configType is null");
/*     */     try
/*     */     {
/*  52 */       if (configMap.get(configType) == null) {
/*  53 */         throw new Exception("----Configure--err-------:configType[" + configType + "]is not initialized");
/*     */       }
/*  55 */       File defaultFileObj = new File((String)fileMap.get(configType + "_default"));
/*  56 */       File provinceFileObj = new File((String)fileMap.get(configType + "_" + province));
/*  57 */       if ((defaultFileObj.lastModified() > ((Long)modifiedTimeMap.get(configType + "_default")).longValue()) || (provinceFileObj.lastModified() > ((Long)modifiedTimeMap.get(configType + "_" + province)).longValue()))
/*     */       {
/*  60 */         initProperties(configType, (String)fileNameMap.get(configType), province);
/*     */       }
/*  62 */       Properties properties = (Properties)configMap.get(configType);
/*  63 */       return StringUtil.obj2Str(properties.getProperty(strKey));
/*     */     } catch (Exception excep) {
/*  65 */       log.error("", excep);
/*     */     }
/*  67 */     return "";
/*     */   }
/*     */ 
/*     */   private synchronized boolean initProperties(String configType, String file, String province) throws Exception {
/*  71 */     if (StringUtil.isEmpty(configType)) {
/*  72 */       throw new Exception("----Configure--err-------:configType is null");
/*     */     }
/*  74 */     if (StringUtil.isEmpty(file)) {
/*  75 */       throw new Exception("----Configure--err-------:fileName is null");
/*     */     }
/*     */ 
/*  78 */     Properties properties = new Properties();
/*  79 */     String defaultFile = file.replace("{PROVINCE}", province);
/*  80 */     File defaultFileObj = new File(defaultFile);
/*  81 */     String defaultPath = defaultFileObj.getAbsolutePath();
/*  82 */     if (!defaultFileObj.exists()) {
/*  83 */       throw new Exception("Parameter file not found:\r\nAbsolute Path:" + defaultPath);
/*     */     }
/*  85 */     log.debug("Load default properties fileName:\r\n Absolute Path:" + defaultPath);
/*  86 */     FileInputStream fis = new FileInputStream(defaultFile);
/*  87 */     properties.load(fis);
/*  88 */     File privincePathObj = null;
/*  89 */     String provincePath = "";
/*  90 */     if (StringUtil.isNotEmpty(province)) {
/*  91 */       String provinceFile = file.replace("{PROVINCE}", province.toLowerCase());
/*  92 */       privincePathObj = new File(provinceFile);
/*  93 */       if (privincePathObj.exists()) {
/*  94 */         provincePath = privincePathObj.getAbsolutePath();
/*  95 */         log.debug("Load province properties fileName:\r\n Absolute Path:" + provincePath);
/*  96 */         FileInputStream fisp = new FileInputStream(provinceFile);
/*  97 */         Properties propsProvince = new Properties();
/*  98 */         propsProvince.load(fisp);
/*  99 */         fisp.close();
/* 100 */         Set entries = propsProvince.entrySet();
/* 101 */         if (entries != null) {
/* 102 */           Iterator iterator = entries.iterator();
/* 103 */           while (iterator.hasNext()) {
/* 104 */             Map.Entry entry = (Map.Entry)iterator.next();
/* 105 */             Object key = entry.getKey();
/* 106 */             Object value = entry.getValue();
/* 107 */             if (!properties.containsKey(key.toString())) {
/* 108 */               properties.put(key, value);
/*     */             } else {
/* 110 */               properties.remove(key);
/* 111 */               properties.put(key, value);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 117 */     fis.close();
/*     */ 
/* 119 */     modifiedTimeMap.put(configType + "_default", Long.valueOf(defaultFileObj.lastModified()));
/* 120 */     modifiedTimeMap.put(configType + "_" + province, Long.valueOf(privincePathObj.lastModified()));
/* 121 */     fileMap.put(configType + "_" + province, provincePath);
/* 122 */     fileMap.put(configType + "_default", defaultPath);
/* 123 */     fileNameMap.put(configType, file);
/* 124 */     configMap.put(configType, properties);
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */   public String getAbsPath()
/*     */   {
/* 130 */     return getAbsPath("MPM_PROPERTIES_default");
/*     */   }
/*     */ 
/*     */   public String getAbsPath(String configType) {
/* 134 */     return (String)fileMap.get(configType + "_default");
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.MpmConfigure
 * JD-Core Version:    0.6.2
 */
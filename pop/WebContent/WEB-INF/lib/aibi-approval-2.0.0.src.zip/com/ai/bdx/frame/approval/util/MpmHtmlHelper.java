package com.ai.bdx.frame.approval.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import com.ai.bdx.frame.approval.constants.MpmCONST;
import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
import com.ai.bdx.frame.approval.model.MtlCostList;
import com.ai.bdx.frame.approval.model.MtlTempletActiveField;
import com.ai.bdx.frame.approval.service.IMpmResListSvc;
import com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService;
import com.asiainfo.biframe.privilege.sysmanage.util.SysManageConstants;
import com.asiainfo.biframe.service.IdNameMapper;
import com.asiainfo.biframe.utils.config.Configure;
import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
import com.asiainfo.biframe.utils.string.StringUtil;

/**
 * Created on 9:49:35 PM
 *
 * <p>Title: 营销管理平台共用页面显示和处理类</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: asiainfo.,Ltd</p>
 * @author weilin.wu  wuwl2@asiainfo.com
 * @version 1.0
 */
public class MpmHtmlHelper {
	private static Logger log = LogManager.getLogger();

	public MpmHtmlHelper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static String getMpmStoreFilePath() {
		String mpmPath = Configure.getInstance().getProperty("SYS_COMMON_UPLOAD_PATH");
		if (!mpmPath.endsWith(File.separator)) {
			mpmPath += File.separator;
		}
		mpmPath += MpmCONST.MPM_STORE_SUB_PATH;
		File pathFile = new File(mpmPath);
		if (!pathFile.exists()) {
			pathFile.mkdirs();
		}
		return mpmPath;
	}

	/**
	 * 上载活动用户过滤文件
	 * @param fFile
	 * @return
	 */
	/*public static String uploadCampFilterFile(FormFile fFile) {
		String mpmPath = getMpmStoreFilePath();

		String fileName = fFile.getFileName();
		//后缀的位置
		int nFileExtPos = fileName.lastIndexOf(".");
		//后缀名
		String fileExt = fileName.substring(nFileExtPos + 1);

		//不带后缀的文件名
		String pureFileName = nFileExtPos < 0 ? fileName : fileName.substring(0, nFileExtPos);
		//去除空格
		pureFileName = pureFileName.replaceAll(" ", "");
		//保存文件名，为避免重复，增加用户名和日期
		String saveFileName = (pureFileName.length() > 15 ? pureFileName.substring(0, 15) : pureFileName) +
		//				"_" + dFormatS.format(new Date());
				"_" + System.currentTimeMillis();
		if (saveFileName.length() > 40) {
			saveFileName = saveFileName.substring(saveFileName.length() - 40);
		}
		//加上扩展名
		saveFileName += "." + fileExt;

		return MpmHtmlHelper.uploadFile(fFile, mpmPath, saveFileName, false, false);
	}*/

	/**
	 * 上载用户目标客户文件
	 * @param fFile
	 * @return 返回上载后每个目标客户文件的路径数组
	 */
	/*public static String[] uploadTargetUserFile(FormFile[] fFiles) {
		String res[] = new String[fFiles.length];
		for (int i = 0; i < fFiles.length; i++) {
			if (fFiles[i] != null && fFiles[i].getFileName() != null && fFiles[i].getFileName().length() > 0) {
				res[i] = MpmHtmlHelper.uploadCampFilterFile(fFiles[i]);
			}
		}
		return res;
	}*/

	/**
	 * 上载活动或活动波次的附件文件
	 * @param fFiles
	 * @param descs
	 * @param userId
	 * @param type
	 * @param campCampsegId
	 * @return
	 */
	/*public static List uploadCampsegFile(FormFile[] fFiles, String[] descs, String userId, short type,
			String campCampsegId, short contType) {
		String mpmPath = getMpmStoreFilePath();

		List attachList = new ArrayList();
		//		Date currentTime = new Date();
		FastDateFormat dFormatS = FastDateFormat.getInstance("yyyyMMddHHmmss");

		for (int i = 0; i < fFiles.length; i++) {
			FormFile tmpFile = fFiles[i];
			if (null != tmpFile) {
				String fileName = tmpFile.getFileName();
				if (StringUtil.isEmpty(fileName)) {
					continue;
				}
				//后缀的位置
				int nFileExtPos = fileName.lastIndexOf(".");
				//后缀名
				String fileExt = fileName.substring(nFileExtPos + 1);

				//不带后缀的文件名
				String pureFileName = nFileExtPos < 0 ? fileName : fileName.substring(0, nFileExtPos);
				//去除空格
				pureFileName = pureFileName.replaceAll(" ", "");
				//change 保存文件名，为避免重复，增加用户名和日期
				String saveFileName = (pureFileName.length() > 15 ? pureFileName.substring(0, 15) : pureFileName) + "_"
						+ userId + "_" + dFormatS.format(new Date());
				if (saveFileName.length() > 40) {
					saveFileName = saveFileName.substring(saveFileName.length() - 40);
				}
				//加上扩展名
				saveFileName += "." + fileExt;
				String fileUrl = MpmHtmlHelper.uploadFile(tmpFile, mpmPath, saveFileName, false, true);
				//log.debug("上传信息："+remsg);

				MtlAttachmentInfo itemAttach = new MtlAttachmentInfo();
				String desc = descs[i];
				if (StringUtil.isEmpty(desc)) {
					desc = fileName;
				}
				itemAttach.setAttachmentName(desc);
				itemAttach.setAttachmentUrl(fileUrl);
				itemAttach.setCampCampsegId(campCampsegId);
				itemAttach.setAttachmentType(Short.valueOf(type));
				itemAttach.setAttachmentContentType(Short.valueOf(contType));
				itemAttach.setAttachmentUserid(userId);

				attachList.add(itemAttach);
			}
		}
		return attachList;
	}
*/
	/**
	 * 上载活动或活动波次的附件文件
	 * @param fFiles
	 * @param descs
	 * @param userId
	 * @param type
	 * @param campCampsegId
	 * @return
	 */
	/*public static String[] uploadCampsegFile(List fFiles, List descs, String userId) {
		String mpmPath = getMpmStoreFilePath();

		if (CollectionUtils.isEmpty(fFiles)) {
			return null;
		}
		//add by fuyu 获取数据库类型
		String dbType = Configure.getInstance().getProperty("MPM_DBTYPE");

		String[] files = new String[2];

		List attachList = new ArrayList();
		//		Date currentTime = new Date();
		FastDateFormat dFormatS = FastDateFormat.getInstance("yyyyMMddHHmmss");

		for (int i = 0; i < fFiles.size(); i++) {
			FormFile tmpFile = (FormFile) fFiles.get(i);
			if (null != tmpFile) {
				String fileName = tmpFile.getFileName();
				if (StringUtil.isEmpty(fileName)) {
					continue;
				}
				//后缀的位置
				int nFileExtPos = fileName.lastIndexOf(".");
				//后缀名
				String fileExt = fileName.substring(nFileExtPos + 1);

				//不带后缀的文件名
				String pureFileName = nFileExtPos < 0 ? fileName : fileName.substring(0, nFileExtPos);
				//去除空格
				pureFileName = pureFileName.replaceAll(" ", "");
				//change 保存文件名，为避免重复，增加用户名和日期
				String saveFileName = (pureFileName.length() > 15 ? pureFileName.substring(0, 15) : pureFileName) + "_"
						+ userId + "_" + dFormatS.format(new Date());
				if (saveFileName.length() > 40) {
					saveFileName = saveFileName.substring(saveFileName.length() - 40);
				}
				//加上扩展名
				saveFileName += "." + fileExt;
				String fileUrl = MpmHtmlHelper.uploadFile(tmpFile, mpmPath, saveFileName, false, false);
				//log.debug("上传信息："+remsg);

				MtlAttachmentInfo itemAttach = new MtlAttachmentInfo();
				String desc = (String) descs.get(i);
				if (StringUtil.isEmpty(desc)) {
					desc = fileName;
				}

				//add by fuyu 处理mysql数据库保存文件路径的问题
				if ("mysql".equalsIgnoreCase(dbType)) {
					String[] tempSqlArray = fileUrl.replaceAll("\\\\", "/").split("/");
					String tempFileUrl = "";
					for (int j = 0; j < tempSqlArray.length; j++) {
						if (j == tempSqlArray.length - 1) {
							tempFileUrl = tempFileUrl + tempSqlArray[j];
						} else {
							tempFileUrl = tempFileUrl + tempSqlArray[j] + File.separator + File.separator;
						}
					}
					fileUrl = tempFileUrl;
				}

				if (i == 0) {
					files[0] = desc;
					files[1] = fileUrl;
				} else {
					files[0] += MpmUiConstants.DCP_VALUE_SPLIT + desc;
					files[1] += MpmUiConstants.DCP_VALUE_SPLIT + fileUrl;
				}
			}
		}
		return files;
	}
*/
	/**
	 * 上载分公司上报文件
	 * @param fFiles
	 * @param descs
	 * @param userId
	 * @param type
	 * @param campCampsegId
	 * @return
	 */
	/*public static List uploadCompanyFile(FormFile[] fFiles, String[] descs, String userId, short type,
			String campCampsegId, short contType) {
		String mpmPath = getMpmStoreFilePath();
		List attachList = new ArrayList();
		FastDateFormat dFormatS = FastDateFormat.getInstance("yyyyMMddHHmmss");
		for (int i = 0; i < fFiles.length; i++) {
			FormFile tmpFile = fFiles[i];
			if (null != tmpFile) {
				String fileName = tmpFile.getFileName();
				if (StringUtil.isEmpty(fileName)) {
					continue;
				}
				//后缀的位置
				int nFileExtPos = fileName.lastIndexOf(".");
				//后缀名
				String fileExt = fileName.substring(nFileExtPos + 1);

				//不带后缀的文件名
				String pureFileName = nFileExtPos < 0 ? fileName : fileName.substring(0, nFileExtPos);
				//去除空格
				pureFileName = pureFileName.replaceAll(" ", "");
				//分公司上报是规范文件命名
				if (type == MpmCONST.MPM_ATTACH_TYPE_UPLOAD) {
					boolean flag = false;
					//log.debug("***************************length="+pureFileName.length()+",,="+fileExt);
					if (!fileExt.trim().equals("xls")) {
						flag = true;
					}
					if (pureFileName.length() != 11) {
						flag = true;
					}
					if (pureFileName.toUpperCase().indexOf("CY-") < 0 && pureFileName.toUpperCase().indexOf("HD-") < 0
							&& pureFileName.toUpperCase().indexOf("ZX-") < 0
							&& pureFileName.toUpperCase().indexOf("NQ-") < 0
							&& pureFileName.toUpperCase().indexOf("XQ-") < 0
							&& pureFileName.toUpperCase().indexOf("FS-") < 0
							&& pureFileName.toUpperCase().indexOf("TZ-") < 0
							&& pureFileName.toUpperCase().indexOf("SY-") < 0
							&& pureFileName.toUpperCase().indexOf("DX-") < 0
							&& pureFileName.toUpperCase().indexOf("CP-") < 0
							&& pureFileName.toUpperCase().indexOf("PG-") < 0
							&& pureFileName.toUpperCase().indexOf("HR-") < 0
							&& pureFileName.toUpperCase().indexOf("MY-") < 0
							&& pureFileName.toUpperCase().indexOf("YQ-") < 0) {
						flag = true;
					}
					try {
						String dateF = pureFileName.substring(3);
						DateFormat sdf = new SimpleDateFormat("yyyyMMdd");
						sdf.parse(dateF);
					} catch (Exception e) {
						flag = true;
					}
					//保存上报文件名称不符合要求的文件信息
					if (flag) {
						MtlAttachmentInfo itemAttach = new MtlAttachmentInfo();
						String desc = null;//= descs[i];
						if (StringUtil.isEmpty(desc)) {
							desc = fileName;
						}
						itemAttach.setCampCampsegId("111111111111111");
						itemAttach.setAttachmentName(desc);
						itemAttach.setAttachmentUrl(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj"));
						itemAttach.setAttachmentType(Short.valueOf(type));
						itemAttach.setAttachmentContentType(Short.valueOf(MpmCONST.MPM_ATTACH_CONT_TYPE_UPLOADERR));
						itemAttach.setAttachmentUserid(userId);
						attachList.add(itemAttach);
						continue;
					}
				}
				//change 保存文件名，为避免重复，增加用户名和日期
				String saveFileName = (pureFileName.length() > 15 ? pureFileName.substring(0, 15) : pureFileName) + "_"
						+ userId + "_" + dFormatS.format(new Date());
				if (saveFileName.length() > 40) {
					saveFileName = saveFileName.substring(saveFileName.length() - 40);
				}
				//加上扩展名
				saveFileName += "." + fileExt;
				String fileUrl = MpmHtmlHelper.uploadFile(tmpFile, mpmPath, saveFileName, false, true);

				if (type == MpmCONST.MPM_ATTACH_TYPE_UPLOAD) {
					String[] flagResult = subCompanyUpload(fileUrl);
					if (flagResult == null) {
						return null;
					}

					boolean flag = "true".equals(flagResult[0]);
					String errStr = flagResult[1];

					//保存上报excel文件内容有问题的文件信息
					if (flag) {
						MtlAttachmentInfo itemAttach = new MtlAttachmentInfo();
						String desc = null;//= descs[i];
						if (StringUtil.isEmpty(desc)) {
							desc = fileName;
						}
						itemAttach.setCampCampsegId("111111111111111");
						itemAttach.setAttachmentName(desc);
						itemAttach.setAttachmentUrl(errStr);
						itemAttach.setAttachmentType(Short.valueOf(type));
						itemAttach.setAttachmentContentType(Short.valueOf(MpmCONST.MPM_ATTACH_CONT_TYPE_UPLOADERR));
						itemAttach.setAttachmentUserid(userId);
						attachList.add(itemAttach);
						continue;
					}
				}
				MtlAttachmentInfo itemAttach = new MtlAttachmentInfo();
				String desc = null;//= descs[i];
				if (StringUtil.isEmpty(desc)) {
					desc = fileName;
				}
				if (type == MpmCONST.MPM_ATTACH_TYPE_UPLOAD) {
					itemAttach.setCampCampsegId(pureFileName.substring(3));
				} else {
					itemAttach.setCampCampsegId(campCampsegId);
				}
				itemAttach.setAttachmentName(desc);
				itemAttach.setAttachmentUrl(fileUrl);
				itemAttach.setAttachmentType(Short.valueOf(type));
				itemAttach.setAttachmentContentType(Short.valueOf(contType));
				itemAttach.setAttachmentUserid(userId);
				attachList.add(itemAttach);
			}
		}
		return attachList;
	}*/

	private static String[] subCompanyUpload(String fileUrl) {
		HSSFWorkbook wbread = null;
		HSSFSheet rSheet = null;
		HSSFRow rRow = null;
		POIFSFileSystem fsInr = null;
		FileInputStream fisr = null;
		boolean flag = false;
		String errStr = "";
		try {
			fisr = new FileInputStream(fileUrl);
			if (fisr == null) {
				log.debug(MpmLocaleUtil.getMessage("mcd.java.gjwj") + fileUrl
						+ MpmLocaleUtil.getMessage("mcd.java.hqFileInpu"));
				return null;
			}
			fsInr = new POIFSFileSystem(fisr);
			if (fsInr == null) {
				log.debug(MpmLocaleUtil.getMessage("mcd.java.gjwj") + fileUrl
						+ MpmLocaleUtil.getMessage("mcd.java.hqPOIFSFil"));
				return null;
			}
			wbread = new HSSFWorkbook(fsInr);
			fisr.close();
			rSheet = wbread.getSheetAt(0);
			for (int a = 2; a >= 2; a++) {
				rRow = rSheet.getRow(a);
				if (rRow == null && a == 2) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj1");
					break;
				}
				if (rRow == null) {
					break;
				}

				if (rRow.getCell((short) 2) == null && a == 2) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj1");
					break;
				}

				if (rRow.getCell((short) 2) == null) {
					break;
				}

				try {
					if (rRow.getCell((short) 0) != null) {
						rRow.getCell((short) 0).getStringCellValue();
					}
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj2") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwzfx");
					break;
				}

				try {
					if (rRow.getCell((short) 1) != null) {
						rRow.getCell((short) 1).getStringCellValue();
					}
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj3") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwzfx");
					break;
				}
				try {
					if ((rRow.getCell((short) 2).getStringCellValue() == null || rRow.getCell((short) 2)
							.getStringCellValue().trim().length() <= 0)
							&& a == 2) {
						MpmHtmlHelper.deleteFile(fileUrl);
						flag = true;
						errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj1");
						break;
					}
					if ((rRow.getCell((short) 2).getStringCellValue() == null || rRow.getCell((short) 2)
							.getStringCellValue().trim().length() <= 0)) {
						break;
					}
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj4") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwzfx");
					break;
				}

				try {
					rRow.getCell((short) 3).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj5") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 4).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj6") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 5).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj7") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 6).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj8") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 7).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj9") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 8).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj10") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 9).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj11") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 10).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj12") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 11).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj13") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 12).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj14") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 13).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj15") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 14).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj16") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 15).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj17") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 16).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj18") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 17).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj19") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 18).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj20") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 19).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj21") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 20).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj22") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 21).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj23") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 22).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj24") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 23).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj25") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
				try {
					rRow.getCell((short) 24).getNumericCellValue();
				} catch (Exception e) {
					MpmHtmlHelper.deleteFile(fileUrl);
					flag = true;
					errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj26") + (a + 1)
							+ MpmLocaleUtil.getMessage("mcd.java.sjbwszx");
					break;
				}
			}
		} catch (Exception e) {
			log.error("", e);
		}

		String[] result = new String[2];
		result[0] = flag ? "true" : "false";
		result[1] = errStr;

		return result;
	}

	/**
	 * 保存上载的文件到服务器端
	 * modified by wwl 2007-10-15
	 * @param uploadFile
	 * @param storePath
	 * @param destFileName
	 * @param bCleanFolder
	 * @param needUseFtp 是否使用FTP（活动、波次、审批等的附件可能需要使用FTP，活动剔除用户清单、目标客户清单等不需要使用FTP）
	 * @return 返回上载成功后文件保存的完整路径
	 */
/*	public static String uploadFile(FormFile uploadFile, String storePath, String destFileName, boolean bCleanFolder,
			boolean needUseFtp) {
		String remsg = "";
		ApacheFtpUtil ftp = null;
		try {
			if (StringUtil.isEmpty(storePath)) {
				remsg = MpmLocaleUtil.getMessage("mcd.java.myzdscljqy");
				return remsg;
			}

			java.io.File rootFolder = new java.io.File(storePath);
			//上载目录不存在，创建
			if (!rootFolder.exists()) {
				rootFolder.mkdirs();
			}
			//上载目录存在，清除目录下的所有文件
			else if (bCleanFolder) {
				java.io.File[] tmpFiles = rootFolder.listFiles();
				for (int i = 0; i < tmpFiles.length; i++) {
					tmpFiles[i].delete();
				}
			}

			//获得上传到的文件路径和名称
			String uploadName = storePath + File.separator + destFileName;

			InputStream stream = uploadFile.getInputStream();
			OutputStream bos = new FileOutputStream(uploadName);
			int bytesRead = 0;
			byte[] buffer = new byte[8192];
			while ((bytesRead = stream.read(buffer, 0, 8192)) != -1) {
				bos.write(buffer, 0, bytesRead);
			}
			bos.close();
			remsg = uploadName;

			if (needUseFtp) {
				//added by wwl 2007-5-25 支持把上传文件存储到FTP服务器上
				String isUseFtpStore = Configure.getInstance().getProperty("MPM_USE_FTP_STORE");
				if (isUseFtpStore != null && isUseFtpStore.equals("1")) {
					String ftpServer = Configure.getInstance().getProperty("MPM_FTP_SERVER_IP");
					int ftpServerPort = Integer.parseInt(Configure.getInstance().getProperty("MPM_FTP_SERVER_PORT"));
					String ftpStorePath = Configure.getInstance().getProperty("MPM_FTP_SERVER_STORE_PATH");
					String ftpUserName = Configure.getInstance().getProperty("MPM_FTP_USERNAME");
					String ftpUserPwd = Configure.getInstance().getProperty("MPM_FTP_USERPWD");
					String ftpUserPwdEncrypt = Configure.getInstance().getProperty("MPM_FTP_USERPWD_ENCRYPT");
					if (ftpUserPwdEncrypt != null && ftpUserPwdEncrypt.equals("1")) {
						ftpUserPwd = DES.decrypt(ftpUserPwd);
					}
					ftp = ApacheFtpUtil.getInstance(ftpServer, ftpServerPort, ftpUserName, ftpUserPwd, null);
					if (ftpStorePath != null && ftpStorePath.length() != 0) {
						ftp.changeDir(ftpStorePath);
					}
					ftp.upload(uploadName, destFileName);
				}
			}
			//added end

		}// end of try
		catch (Exception e) {
			log.error("", e);
			remsg = "";
		} finally {
			if (ftp != null) {
				ftp.closeFtpConnection();
			}
		}
		return remsg;
	}
*/
	public static String deleteFile(String fileName) {
		String remsg = "";
		try {
			java.io.File delFile = new java.io.File(fileName);
			if (delFile.exists()) {
				delFile.delete();
			}

			remsg = MpmLocaleUtil.getMessage("mcd.java.wjsccg");
		}// end of try
		catch (Exception e) {
			log.error("", e);
			remsg = MpmLocaleUtil.getMessage("mcd.java.wjscsb");
		}
		return remsg;
	}

	/**
	 * 构造基础信息表字段类型与字段之间的联动html代码
	 * @return
	 */
	public static String genBaseTableColumnTypeAndColumnLinkHtml(Set columnList) throws Exception {
		StringBuffer sb = new StringBuffer();
		sb.append("var baseColumnCount=0;\n").append("var subBaseColumn = new Array();\n");
		if (columnList == null) {
			return sb.toString();
		}
		Iterator it = columnList.iterator();
		MtlCampDatasrcColumn column;
		int index = 0;
		String columnKey;
		String desc;
		while (it.hasNext()) {
			column = (MtlCampDatasrcColumn) it.next();
			//无效的字段不在列表中显示出来 added by wwl 2007-4-17
			if (column.getColumnStatus() != null && column.getColumnStatus().shortValue() == 2) {
				continue;
			}
			desc = column.getColumnCname();
			columnKey = column.getId().getColumnName() + "|" + column.getId().getSourceName() + "|"
					+ column.getId().getColumnType() + "|" + column.getColumnFlag() + "|"
					+ ((desc == null) ? "" : desc);
			sb.append("subBaseColumn[" + index + "] = new Array(\"" + desc + "\",\"" + column.getColumnClass()
					+ "\",\"" + columnKey + "\");\n");
			index++;
		}
		sb.append("baseColumnCount=" + (index++) + ";\n");
		return sb.toString();
	}

	/**
	 *
	 */
	public static String addColumnTypeToBaseTable(String baseHtml) throws Exception {
		StringBuffer sb = new StringBuffer(baseHtml);
		try {
			int markup1 = baseHtml.lastIndexOf("=");
			int markup2 = baseHtml.lastIndexOf(";");
			String baseCount = baseHtml.substring(markup1 + 1, markup2);
			int index = Integer.parseInt(baseCount.trim());
			sb.append("subBaseColumn[" + index + "] = new Array(\"" + MpmLocaleUtil.getMessage("mcd.java.cjsj")
					+ "\",\"" + MpmCONST.BASE_TABLE_COLUMN_TYPE_USER + "\",\"" + "create_time|mtl_duser_xxxxx|"
					+ MpmCONST.MPM_DS_COLUMN_TYPE_DATE + MpmLocaleUtil.getMessage("mcd.java.||cjsj") + "\");\n");
			index++;
			sb.append("subBaseColumn[" + index + "] = new Array(\"" + MpmLocaleUtil.getMessage("mcd.java.yhgsfp")
					+ "\",\"" + MpmCONST.BASE_TABLE_COLUMN_TYPE_USER + "\",\"" + "ser_segno|mtl_duser_xxxxx|"
					+ MpmCONST.MPM_DS_COLUMN_TYPE_NUMBER + MpmLocaleUtil.getMessage("mcd.java.||yhgsfp") + "\");\n");
			index++;
			sb.append("baseColumnCount=" + index + ";\n");
		} catch (Exception e) {
			log.error("", e);
		}
		return sb.toString();
	}

	/**
	 * 构造活动接口表与字段之间的联动html代码
	 * @param columnList
	 * @return
	 */
	public static String genInterfaceTableAndColumnLinkHtml(Set columnList) throws Exception {
		StringBuffer sb = new StringBuffer();
		sb.append("var interfaceColumnCount=0;\n").append("var subInterfaceColumn = new Array();\n");
		if (columnList == null) {
			return sb.toString();
		}
		Iterator it = columnList.iterator();
		MtlCampDatasrcColumn column;
		int index = 0;
		String columnKey;
		String desc;
		while (it.hasNext()) {
			column = (MtlCampDatasrcColumn) it.next();
			//无效的字段不在列表中显示出来 added by wwl 2007-4-17
			if (column.getColumnStatus() != null && column.getColumnStatus().shortValue() == 2) {
				continue;
			}
			desc = column.getColumnCname();
			columnKey = column.getId().getColumnName() + "|" + column.getId().getSourceName() + "|"
					+ column.getId().getColumnType() + "|" + column.getColumnFlag() + "|"
					+ ((desc == null) ? "" : desc);
			sb.append("subInterfaceColumn[" + index + "] = new Array(\"" + desc + "\",\""
					+ column.getId().getSourceName() + "\",\"" + columnKey + "\");\n");
			index++;
		}
		sb.append("interfaceColumnCount=" + (index++) + ";\n");
		return sb.toString();
	}

/*	public static String genTempletClassLinkHtml(Map templetMap, DimUserIdNameMapper service) throws Exception {
		StringBuffer sb = new StringBuffer();
		sb.append("var templetClassArrayLen=0;\n").append("var templetClassArray = new Array();\n");
		if (templetMap == null) {
			return sb.toString();
		}
		int index = 0;
		List list = new ArrayList();
		MtlTempletActive active;
		MtlTempletSelect select;
		MtlTempletFilter filter;
		MtlTempletSubsection subsection;
		String templetType;
		String createTimeStr;
		FastDateFormat sd = FastDateFormat.getInstance("yyyy-MM-dd hh:mm:ss");
		//	    String createUserName = "";
		if (templetMap.containsKey(MpmCONST.MPM_TEMPLET_CLASS_ACT + "")) {
			list = (ArrayList) templetMap.get(MpmCONST.MPM_TEMPLET_CLASS_ACT + "");
			for (int j = 0; j < list.size(); j++) {
				active = (MtlTempletActive) list.get(j);
				templetType = MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_TEMPLET_TYPE_INFO,
						String.valueOf(active.getAtempletType()));
				createTimeStr = sd.format(active.getCreateTime());
				sb.append("templetClassArray[" + index + "] = new Array(\"" + active.getAtempletName() + "\",\""
						+ active.getActiveTempletId() + "\",\"" + MpmCONST.MPM_TEMPLET_CLASS_ACT + "" + "\",\""
						+ active.getCreateUserid() + "\",\"" + createTimeStr + "\",\"" + templetType + "\",\""
						+ active.getAtempletType() + "\");\n");
				index++;
			}
		}

		if (templetMap.containsKey(MpmCONST.MPM_TEMPLET_CLASS_SELECT + "")) {
			list = (ArrayList) templetMap.get(MpmCONST.MPM_TEMPLET_CLASS_SELECT + "");
			for (int j = 0; j < list.size(); j++) {
				select = (MtlTempletSelect) list.get(j);
				templetType = MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_TEMPLET_TYPE_INFO,
						String.valueOf(select.getSeltempletType()));
				createTimeStr = sd.format(select.getCreateTime());
				sb.append("templetClassArray[" + index + "] = new Array(\"" + select.getSeltempletName() + "\",\""
						+ select.getSelectTempletId() + "\",\"" + MpmCONST.MPM_TEMPLET_CLASS_SELECT + "" + "\",\""
						+ select.getCreateUserid() + "\",\"" + createTimeStr + "\",\"" + templetType + "\",\""
						+ select.getSeltempletType() + "\");\n");
				index++;
			}
		}

		if (templetMap.containsKey(MpmCONST.MPM_TEMPLET_CLASS_FILTER + "")) {
			list = (ArrayList) templetMap.get(MpmCONST.MPM_TEMPLET_CLASS_FILTER + "");
			for (int j = 0; j < list.size(); j++) {
				filter = (MtlTempletFilter) list.get(j);
				templetType = MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_TEMPLET_TYPE_INFO,
						String.valueOf(filter.getFtempletType()));
				createTimeStr = sd.format(filter.getCreateTime());
				sb.append("templetClassArray[" + index + "] = new Array(\"" + filter.getFtempletName() + "\",\""
						+ filter.getFilterTempletId() + "\",\"" + MpmCONST.MPM_TEMPLET_CLASS_FILTER + "" + "\",\""
						+ filter.getCreateUserid() + "\",\"" + createTimeStr + "\",\"" + templetType + "\",\""
						+ filter.getFtempletType() + "\");\n");
				index++;
			}
		}

		if (templetMap.containsKey(MpmCONST.MPM_TEMPLET_CLASS_SUBSECTION + "")) {
			list = (ArrayList) templetMap.get(MpmCONST.MPM_TEMPLET_CLASS_SUBSECTION + "");
			for (int j = 0; j < list.size(); j++) {
				subsection = (MtlTempletSubsection) list.get(j);
				templetType = MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_TEMPLET_TYPE_INFO,
						String.valueOf(subsection.getStempletType()));
				createTimeStr = sd.format(subsection.getCreateTime());
				sb.append("templetClassArray[" + index + "] = new Array(\"" + subsection.getStempletName() + "\",\""
						+ subsection.getSubsectionTempletId() + "\",\"" + MpmCONST.MPM_TEMPLET_CLASS_SUBSECTION + ""
						+ "\",\"" + subsection.getCreateUserid() + "\",\"" + createTimeStr + "\",\"" + templetType
						+ "\",\"" + subsection.getStempletType() + "\");\n");
				index++;
			}
		}

		if (index == 0) {
			return sb.toString();
		}
		sb.append("templetClassArrayLen=" + (index++) + ";\n");
		return sb.toString();
	}*/

	/**
	 * 构造活动接口表与字段之间的联动html代码
	 * @param columnList
	 * @return
	 */
	public static String genActTempletAndColumnLinkHtml(Set columnList) throws Exception {
		StringBuffer sb = new StringBuffer();
		sb.append("var actTempletColumnCount=0;\n").append("var actTempletColumn = new Array();\n");
		if (columnList == null) {
			return sb.toString();
		}
		Iterator it = columnList.iterator();
		MtlTempletActiveField column;
		int index = 0;
		String columnKey;
		String desc;
		while (it.hasNext()) {
			column = (MtlTempletActiveField) it.next();
			desc = column.getColumnCname();
			columnKey = column.getId().getColumnName() + "|" + column.getId().getSourceName() + "|"
					+ column.getId().getColumnType() + "|" + column.getColumnFlag() + "|"
					+ ((desc == null) ? "" : desc);
			sb.append("actTempletColumn[" + index + "] = new Array(\"" + desc + "\",\""
					+ column.getId().getSourceName() + "\",\"" + columnKey + "\",\""
					+ column.getId().getActiveTempletId() + "\",\"" + column.getId().getColumnType() + "\");\n");
			index++;
		}
		sb.append("actTempletColumnCount=" + (index++) + ";\n");
		return sb.toString();
	}

	/**
	 * 构造字段数据类型转换的JS函数Html代码
	 * @return
	 */
	public static String genColumnTypeTransferJSHtml() {
		StringBuffer sb = new StringBuffer();
		sb.append("function columnTypeTrans(columnType) {\n")
				.append(" 	var res = \"" + MpmLocaleUtil.getMessage("mcd.java.wzlx") + "\";\n")
				.append(" 	if (columnType == " + MpmCONST.MPM_DS_COLUMN_TYPE_NUMBER + ")\n")
				.append(" 		res = \"" + MpmLocaleUtil.getMessage("mcd.java.szx1") + "\";\n")
				.append(" 	else if (columnType == " + MpmCONST.MPM_DS_COLUMN_TYPE_STRING + ")\n")
				.append(" 		res = \"" + MpmLocaleUtil.getMessage("mcd.java.zfx") + "\";\n")
				.append(" 	else if (columnType == " + MpmCONST.MPM_DS_COLUMN_TYPE_DATE + ")\n")
				.append(" 		res = \"" + MpmLocaleUtil.getMessage("mcd.java.rqx") + "\";\n").append(" 	return res;\n")
				.append("}\n");
		return sb.toString();
	}

	/**
	 * 构造活动波次跟随活动编码变动的Html代码
	 * @param campsegList
	 * @return
	 */
	/*public static String genCampCampsegLinkHtml(List campsegList) {
		StringBuffer str = new StringBuffer();
		str.append("var campsegcount=0;\nseg = new Array();\n");
		int count = 0;
		try {
			Iterator i = campsegList.iterator();
			while (i.hasNext()) {
				MtlCampSeginfo seg = (MtlCampSeginfo) i.next();
				str.append("seg[" + count + "] = new Array(\"" + seg.getCampsegName() + "\",\"" + seg.getCampId()
						+ "\",\"" + seg.getCampsegId() + "\");\n");
				count++;
			}
			str.append("campsegcount=" + count + ";\n");
		} catch (Exception e) {
			log.error("", e);
		}
		return str.toString();
	}*/

	/**
	 * 构造发送给活动波次策划人的Html格式审批通知邮件
	 * @param emailContent
	 * @return
	 */
	public static String genApproveEmailToCreateUser(String userName, String emailContent) {
		StringBuffer sb = new StringBuffer();
		sb.append("<html><head><meta http-equiv=\"Content-Language\" content=\"zh-cn\"></meta>")
				.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"></meta>")
				.append("<title>" + MpmLocaleUtil.getMessage("mcd.java.titleyxyxg") + "</title>")
				.append("</head><body>")
				.append("<p style=\"FONT-SIZE: 9pt\">" + userName + MpmLocaleUtil.getMessage("mcd.java.nhp") + "</p>")
				.append("<p style=\"FONT-SIZE: 9pt\">&nbsp;&nbsp;&nbsp;&nbsp;").append(emailContent)
				.append("</p></body></html>");
		return sb.toString();
	}

	/**
	 * 构造发送给下一个审批人员的Html格式邮件内容
	 * @param camp
	 * @param campseg
	 * @param request
	 * @param sendObj
	 * @param flowId
	 * @param userName
	 * @param nextApproveUserId
	 * @return
	 */
	/*public static String genApproveEmailSendToNext(MtlCampBaseinfo camp, MtlCampSeginfo campseg,
			MtlApproveContentSend sendObj, String flowId, String userName, String nextApproveUserId) {
		StringBuffer sb = new StringBuffer();
		StringBuffer sb2 = new StringBuffer();
		sb2.append("<table style=\"BORDER-COLLAPSE: collapse\" borderColor='#537ee7' border='1' width='100%' align='center' cellSpacing='0' cellPadding='0' style=\"FONT-SIZE: 9pt\">");
		if (campseg == null) {
			sb2.append(
					"<tr height='23'><td bgcolor='#dcebfc' colspan='4'><b>"
							+ MpmLocaleUtil.getMessage("mcd.java.yxaxx") + "</b></td></tr>")
					.append("<tr height='21'><td width='15%' align='right'>"
							+ MpmLocaleUtil.getMessage("mcd.java.yxamc") + "</td><td colspan='3'>" + camp.getCampName()
							+ "</td></tr>")
					.append("<tr height='21'><td align='right'>" + MpmLocaleUtil.getMessage("mcd.java.qsrq")
							+ "</td><td>" + MpmUtil.parseOutDate(camp.getStartDate()) + "</td><td align='right'>"
							+ MpmLocaleUtil.getMessage("mcd.java.jzrq") + "</td><td>"
							+ MpmUtil.parseOutDate(camp.getEndDate()) + "</td></tr>")
					.append("<tr height='21'><td align='right'>" + MpmLocaleUtil.getMessage("mcd.java.yxams")
							+ "</td><td colspan='3'>" + camp.getCampDesc() + "</td></tr>");
		}
		if (campseg != null) {
			sb2.append(
					"<tr height='23'><td bgcolor='#dcebfc' colspan='4'><b>"
							+ MpmLocaleUtil.getMessage("mcd.java.yxhdxx") + "</b></td></tr>")
					.append("<tr height='21'><td align='right'>" + MpmLocaleUtil.getMessage("mcd.java.yxhdmc1")
							+ "</td><td>" + campseg.getCampsegName() + "</td><td align='right'>"
							+ MpmLocaleUtil.getMessage("mcd.java.yxhdxh") + "</td><td>&nbsp;" + campseg.getCampsegNo()
							+ "</td></tr>")
					.append("<tr height='21'><td align='right'>" + MpmLocaleUtil.getMessage("mcd.java.qsrq")
							+ "</td><td>" + MpmUtil.parseOutDate(campseg.getStartDate()) + "</td><td align='right'>"
							+ MpmLocaleUtil.getMessage("mcd.java.jzrq") + "</td><td>"
							+ MpmUtil.parseOutDate(campseg.getEndDate()) + "</td></tr>")
					.append("<tr height='21'><td align='right'>" + MpmLocaleUtil.getMessage("mcd.java.yxhdms")
							+ "</td><td colspan='3'>" + campseg.getCampsegDesc() + "</td></tr>");
		}
		sb2.append("</table>");
		if (campseg != null) {//营销活动确认或者审批
			if (sendObj.getConfirmId() != null && sendObj.getConfirmId().trim().length() > 0
					&& sendObj.getResourceId() != null) {
				String[] str = sendObj.getResourceStr().split(",");
				String resourceId = str[0];
				String strViewUrl = "http://" + sendObj.getServerIp() + ":" + sendObj.getServerPort()
						+ MpmCache.getInstance().getMpmContextPath()
						+ "/mpm/mpmCampsegConfirmDetail.aido?cmd=campsegConfirmDetial&campId=" + sendObj.getCampId()
						+ "&campsegId=" + sendObj.getCampsegId() + "&flowId=" + flowId + "&createUserid="
						+ campseg.getCreateUserid() + "&showButton=email" + "&resourceId=" + resourceId
						+ "&confirmUserid=" + nextApproveUserId;
				sb2.append("<table width='100%' style=\"FONT-SIZE: 9pt\"><tr height='40'>" + "<td><a href='"
						+ strViewUrl + "' target='_blank'>" + MpmLocaleUtil.getMessage("mcd.java.ckzyqrcyxh")
						+ "</a></td>" + "</tr></table>");
				sb.append("<html><head><meta http-equiv=\"Content-Language\" content=\"zh-cn\"></meta>")
						.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"></meta>")
						.append(MpmLocaleUtil.getMessage("mcd.java.titleyxyxg"))
						.append("</head><body>")
						.append("<p style=\"FONT-SIZE: 9pt\">" + userName + MpmLocaleUtil.getMessage("mcd.java.nhp")
								+ "</p>")
						.append("<p style=\"FONT-SIZE: 9pt\">&nbsp;&nbsp;&nbsp;&nbsp;"
								+ MpmLocaleUtil.getMessage("mcd.java.yxglxtzyrx") + sendObj.getResourceName() + "</p>")
						.append(sb2.toString()).append("</body></html>");
			} else {
				String strApproveUrl = "http://" + sendObj.getServerIp() + ":" + sendObj.getServerPort()
						+ MpmCache.getInstance().getMpmContextPath()
						+ "/mpm/mpmCampApproveDetail.aido?cmd=save&campId=" + sendObj.getCampId() + "&campsegId="
						+ sendObj.getCampsegId() + "&createUserid=" + sendObj.getCreateUserid()
						+ "&approveReceiveNums=" + sendObj.getApproveReceiveNums() + "&flowId=" + flowId
						+ "&approveUserId=" + nextApproveUserId + "&approveResult=";
				String strViewUrl = StringFunc.replace2(strApproveUrl, "cmd=save", "cmd=init");
				sb2.append("<table width='100%' style=\"FONT-SIZE: 9pt\"><tr height='40'>" + "<td><a href='"
						+ strViewUrl + "' target='_blank'>" + MpmLocaleUtil.getMessage("mcd.java.ckspcyxhd")
						+ "</a></td>" + "</tr></table>");
				sb.append("<html><head><meta http-equiv=\"Content-Language\" content=\"zh-cn\"></meta>")
						.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"></meta>")
						.append(MpmLocaleUtil.getMessage("mcd.java.titleyxyxg"))
						.append("</head><body>")
						.append("<p style=\"FONT-SIZE: 9pt\">" + userName + MpmLocaleUtil.getMessage("mcd.java.nhp")
								+ "</p>")
						.append("<p style=\"FONT-SIZE: 9pt\">&nbsp;&nbsp;&nbsp;&nbsp;"
								+ MpmLocaleUtil.getMessage("mcd.java.yxglxtzyrx2") + "</p>").append(sb2.toString())
						.append("</body></html>");
			}
		} else if (camp != null) {//营销案审批或者资源确认
			if (sendObj.getConfirmId() != null && sendObj.getConfirmId().trim().length() > 0
					&& sendObj.getResourceId() != null) {
				String strViewUrl = "http://" + sendObj.getServerIp() + ":" + sendObj.getServerPort()
						+ MpmCache.getInstance().getMpmContextPath()
						+ "/mpm/mpmCampConfirmDetail.aido?cmd=CampConfirmDetail&campId=" + sendObj.getCampId()
						+ "&showButton=email" + "&confirmUserid=" + nextApproveUserId;
				sb2.append("<table width='100%' style=\"FONT-SIZE: 9pt\"><tr height='40'>" + "<td><a href='"
						+ strViewUrl + "' target='_blank'>" + MpmLocaleUtil.getMessage("mcd.java.ckzyqrcyxa")
						+ "</a></td>" + "</tr></table>");
				sb.append("<html><head><meta http-equiv=\"Content-Language\" content=\"zh-cn\"></meta>")
						.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"></meta>")
						.append(MpmLocaleUtil.getMessage("mcd.java.titleyxyxg"))
						.append("</head><body>")
						.append("<p style=\"FONT-SIZE: 9pt\">" + userName + MpmLocaleUtil.getMessage("mcd.java.nhp")
								+ "</p>")
						.append("<p style=\"FONT-SIZE: 9pt\">&nbsp;&nbsp;&nbsp;&nbsp;"
								+ MpmLocaleUtil.getMessage("mcd.java.yxglxtzyrx3") + sendObj.getResourceName() + "</p>")
						.append(sb2.toString()).append("</body></html>");
			} else {
				String strApproveUrl = "http://" + sendObj.getServerIp() + ":" + sendObj.getServerPort()
						+ MpmCache.getInstance().getMpmContextPath()
						+ "/mpm/mpmCampApproveDetail.aido?cmd=saveCamp&campId=" + sendObj.getCampId()
						+ "&createUserid=" + sendObj.getCreateUserid() + "&approveReceiveNums="
						+ sendObj.getApproveReceiveNums() + "&flowId=" + flowId + "&approveUserId=" + nextApproveUserId
						+ "&approveResult=";
				String strViewUrl = StringFunc.replace2(strApproveUrl, "cmd=saveCamp", "cmd=initCamp");
				sb2.append("<table width='100%' style=\"FONT-SIZE: 9pt\"><tr height='40'>" + "<td><a href='"
						+ strViewUrl + "' target='_blank'>" + MpmLocaleUtil.getMessage("mcd.java.ckspcyxa")
						+ "</a></td>" + "</tr></table>");
				sb.append("<html><head><meta http-equiv=\"Content-Language\" content=\"zh-cn\"></meta>")
						.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"></meta>")
						.append(MpmLocaleUtil.getMessage("mcd.java.titleyxyxg"))
						.append("</head><body>")
						.append("<p style=\"FONT-SIZE: 9pt\">" + userName + MpmLocaleUtil.getMessage("mcd.java.nhp")
								+ "</p>")
						.append("<p style=\"FONT-SIZE: 9pt\">&nbsp;&nbsp;&nbsp;&nbsp;"
								+ MpmLocaleUtil.getMessage("mcd.java.yxglxtzyrx4") + "</p>").append(sb2.toString())
						.append("</body></html>");
			}
		}
		return sb.toString();
	}
*/
	/**
	 * 构造活动或波次的宣传设计html
	 * @param attachmentList
	 * @return
	 */
	/*public static String genAttachmentHtml(List attachmentList, List planList, List phaseList, List styleList,
			List mediaList) {
		StringBuffer sb = new StringBuffer();
		MtlAttachmentInfo ins[] = { null, null, null, null, null, null, null, null, null, null };
		MtlPublicizePlan plan = null;
		DimPublicizePhase phase = null;
		DimPublicizeStyle style = null;
		DimMediaType media = null;
		int i = 0;
		String attachmentUrl = "";
		int ins_count = 0;
		try {
			if (CollectionUtils.isEmpty(attachmentList) || CollectionUtils.isEmpty(planList)) {
				return "";
			}
			sb.append("<TABLE style='BORDER-COLLAPSE: collapse' borderColor='#81A3F5' height='100%' cellSpacing=0 cellPadding=0 width='100%' align=center border=0>");
			sb.append("<tr tr height='23' bgcolor='#B0C4DE' align='center' class='bluebold'>\n")
					.append("<td nowrap><b>\n").append(MpmLocaleUtil.getMessage("mcd.java.xcfamc")).append("</b></td>")
					.append("<td nowrap><b>\n").append(MpmLocaleUtil.getMessage("mcd.java.xcjd")).append("</b></td>")
					.append("<td nowrap><b>\n").append(MpmLocaleUtil.getMessage("mcd.java.xcms")).append("</b></td>")
					.append("<td nowrap><b>\n").append(MpmLocaleUtil.getMessage("mcd.java.mtlx")).append("</b></td>")
					.append("<td nowrap><b>\n").append(MpmLocaleUtil.getMessage("mcd.java.xcksrq")).append("</b></td>")
					.append("<td nowrap><b>\n").append(MpmLocaleUtil.getMessage("mcd.java.xcjsrq")).append("</b></td>")
					.append("<td nowrap><b>\n").append(MpmLocaleUtil.getMessage("mcd.java.xcsjfj")).append("</b></td>");

			while (i < planList.size()) {
				plan = (MtlPublicizePlan) planList.get(i);
				ins_count = 0;
				phase = null;
				style = null;
				media = null;
				for (int b = 0; ins != null && b < ins.length; b++) {
					ins[b] = null;
				}
				for (int j = 0; j < attachmentList.size(); j++) {
					ins[ins_count] = (MtlAttachmentInfo) attachmentList.get(j);
					if (plan.getPublicizeId().equals(ins[ins_count].getAttachmentExtflag())) {
						ins_count++;
					}
				}
				if (ins_count == 0) {
					sb.setLength(0);
					continue;
				}
				if (i % 2 == 0) {
					sb.append("<tr class='bule' align='center' height='21' title='"
							+ MpmLocaleUtil.getMessage("mcd.java.djxzljxzxc")
							+ "' bgcolor='#D9ECF6' onclick='onClickRow(this)'>");
				} else {
					sb.append("<tr class='bule' align='center' height='21' title='"
							+ MpmLocaleUtil.getMessage("mcd.java.djxzljxzxc")
							+ "' bgcolor='#EFF5FB' onclick='onClickRow(this)'>");
				}

				sb.append("<td>").append(plan.getPublicizeName()).append("</td>");

				for (int x = 0; x < phaseList.size(); x++) {
					phase = (DimPublicizePhase) phaseList.get(x);
					if (phase.getPhaseCode().equals(plan.getPhaseCode().toString())) {
						break;
					}
				}
				for (int x = 0; x < styleList.size(); x++) {
					style = (DimPublicizeStyle) styleList.get(x);
					if (style.getStyleCode().equals(plan.getStyleCode().toString())) {
						break;
					}
				}
				for (int x = 0; x < mediaList.size(); x++) {
					media = (DimMediaType) mediaList.get(x);
					if (media.getMediaTypeCode().equals(plan.getMediaTypeCode().toString())) {
						break;
					}
				}
				sb.append("<td>").append(phase.getPhaseName()).append("</td>");
				sb.append("<td>").append(style.getStyleName()).append("</td>");
				sb.append("<td>").append(media.getMediaTypeName()).append("</td>");
				sb.append("<td>").append(plan.getBeginDate()).append("</td>");
				sb.append("<td>").append(plan.getEndDate()).append("</td>");

				sb.append("<td>\n");
				sb.append("<table border='0'>\n");
				for (int a = 0; a < ins_count; a++) {
					sb.append("<tr><td>");
					attachmentUrl = java.net.URLEncoder.encode(ins[a].getAttachmentUrl().replaceAll("\\\\", "/"),
							"GB2312");
					sb.append("<a style='cursor:hand;text-decoration:underline'>")
							.append("<font color='blue' onclick=\"onViewFile('")
							.append(attachmentUrl + "','','',1)\">").append(ins[a].getAttachmentName())
							.append("</font></a>");
					sb.append("</td></tr>");
				}
				sb.append("</table>\n");
				sb.append("</td>\n");
				sb.append("</tr>\n");
				i++;
			}
			sb.append("</table>");
		} catch (Exception e) {
			log.error("", e);
		}
		return sb.toString();
	}*/

	/**
	 * 下载服务器端指定路径的文件(与HtmlHelper中的download()方法比，多了一个displayFileName参数)
	 * added by wwl 2007-1-24
	 * @param strRealFileName 在服务器端文件的实际路径及文件名
	 * @param displayFileName 下载时显示给用户看的下载文件名（即客户端看到的默认另存为文件名）
	 * @param response
	 * @param needDelete 是否下载后删除
	 * @param needEncode 是否需要转码文件名
	 */
	public static void download(String strRealFileName, String displayFileName, HttpServletResponse response,
			boolean needDelete, boolean needEncode) {
		FileInputStream fis = null;
		int byteRead;
		PrintWriter out = null;
		try {
			String dst_fname = displayFileName;
			if (needEncode) {
				dst_fname = URLEncoder.encode(dst_fname, "UTF-8");
			}
			//response.setContentType("application/octet-stream; charset=iso-8859-1");
			response.setContentType("application/octet-stream");
			response.setHeader("Content-disposition", "attachment; filename=\"" + dst_fname + "\"");

			out = response.getWriter();
			fis = new FileInputStream(strRealFileName);
			while ((byteRead = fis.read()) != -1) {
				out.write(byteRead);
			}
			out.flush();
			if (fis != null) {
				fis.close();
			}

			if (needDelete) {
				File f = new File(strRealFileName);
				f.delete();
			}
		} catch (Exception e) {
			log.error("", e);
		}
	}

	/**
	 * 从FTP服务器上下载一个文件并回写到浏览器客户端
	 * added by wwl 2007-05-25
	 * @param strRealFileName
	 * @param displayFileName
	 * @param response
	 * @param needEncode
	 * @param extFolder 额外需要进入的子目录名
	 * @param extFolder TODO
	 */
	/*public static void downloadFromFtp(String strRealFileName, String displayFileName, HttpServletResponse response,
			boolean needEncode, String extFolder) {
		BufferedOutputStream bos = null;
		ApacheFtpUtil ftp = null;
		try {
			if (strRealFileName != null && strRealFileName.lastIndexOf("/") > 0) {
				int pos = strRealFileName.lastIndexOf("/");
				strRealFileName = strRealFileName.substring(pos + 1);
			}
			String dst_fname = (displayFileName == null || displayFileName.length() < 1) ? strRealFileName
					: displayFileName;
			if (needEncode) {
				dst_fname = URLEncoder.encode(dst_fname, "UTF-8");
			}
			//response.setContentType("application/octet-stream; charset=iso-8859-1");
			response.reset();
			response.setContentType("application/octet-stream");
			response.setHeader("Content-disposition", "attachment; filename=\"" + dst_fname + "\"");

			bos = new BufferedOutputStream(response.getOutputStream());
			byte[] buff = new byte[2048];
			int bytesRead;

			String ftpServer = Configure.getInstance().getProperty("MPM_FTP_SERVER_IP");
			int ftpServerPort = Integer.parseInt(Configure.getInstance().getProperty("MPM_FTP_SERVER_PORT"));
			String ftpStorePath = Configure.getInstance().getProperty("MPM_FTP_SERVER_STORE_PATH");
			String ftpUserName = Configure.getInstance().getProperty("MPM_FTP_USERNAME");
			String ftpUserPwd = Configure.getInstance().getProperty("MPM_FTP_USERPWD");
			String ftpUserPwdEncrypt = Configure.getInstance().getProperty("MPM_FTP_USERPWD_ENCRYPT");
			if (ftpUserPwdEncrypt != null && ftpUserPwdEncrypt.equals("1")) {
				ftpUserPwd = DES.decrypt(ftpUserPwd);
			}

			ftp = ApacheFtpUtil.getInstance(ftpServer, ftpServerPort, ftpUserName, ftpUserPwd, null);
			if (ftpStorePath != null && ftpStorePath.length() != 0) {
				ftp.changeDir(ftpStorePath);
			}
			if (extFolder != null && extFolder.length() > 0) {
				ftp.changeDir(ftpStorePath + "/" + extFolder + "/");
			}
			ftp.download(bos, strRealFileName);
		} catch (Exception e) {
			log.error("", e);
		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
				ftp.forceCloseConnection();
			} catch (Exception e2) {
				log.error("", e2);
			}
		}
	}*/

	/**
	 * 构造审批人类型的select html代码
	 * @param selectName
	 * @param selectExt
	 * @param currentType
	 * @return
	 */
	public static String genApproveObjTypeSelectHtml(String selectName, String selectExt, String currentType) {
		StringBuffer sb = new StringBuffer();
		Map objTypeMap = MpmCache.getInstance().getMapByType(MpmCONST.MPM_APPROVE_OBJ_TYPE);
		Iterator<?> it = objTypeMap.keySet().iterator();
		String type, typeName;
		sb.append("<select name='" + selectName + "' " + selectExt + " style='width:140;'>");
		while (it.hasNext()) {
			type = (String) it.next();
			typeName = (String) objTypeMap.get(type);
			sb.append("<option value='" + type + "' ");
			if (currentType != null && currentType.equals(type)) {
				sb.append("selected");
			}
			sb.append(">" + typeName + "</option>");
		}
		sb.append("</select>");
		return sb.toString();
	}

	/**
	 * 构造审批触发条件中指标的select html代码
	 * @param selectName
	 * @param selectExt
	 * @param currentIndi
	 * @return
	 */
	public static String genApproveTriggerCondIndiSelectHtml(String selectName, String selectExt, String currentIndi) {
		StringBuffer sb = new StringBuffer();
		try {
			//			IMtlApproveFlowDefService service = (IMtlApproveFlowDefService) SystemServiceLocator.getInstance().getService(MpmCONST.MPM_APPROVE_FLOW_DEF_SERVICE);
			//			Iterator it = service.getAllApproveTriggerCondIndi().iterator();

			//modify by chengxc 成本判断的组成类型换成简单的mtlcostlist.
			IMpmResListSvc mrls = (IMpmResListSvc) SystemServiceLocator.getInstance().getService(MpmCONST.RES_LIST_SERVICE_BEAN_ID);
			Iterator it = mrls.getCostList().iterator();
			MtlCostList indi;
			sb.append("<select id='" + selectName + "' name='" + selectName + "' " + selectExt
					+ " onChange =changeIndi('" + selectName + "')>");
			while (it.hasNext()) {
				indi = (MtlCostList) it.next();
				sb.append("<option value='" + indi.getCostCode() + "' ");
				if (currentIndi != null && currentIndi.equals(indi.getCostCode().intValue() + "")) {
					sb.append("selected");
				}
				sb.append(">" + indi.getCostName() + "</option>");
			}
			sb.append("<option value='" + MpmCONST.CUSTGROUP_NUM_COND_ID + "'");
			if (MpmCONST.CUSTGROUP_NUM_COND_ID.equals(currentIndi)) {
				sb.append(" selected");
			}
			sb.append(">" + MpmLocaleUtil.getMessage("mcd.jsp.yhs") + "</option>");
			if (true) {//功能开关
				//for GDS
				sb.append("<option value='" + MpmCONST.NEED_HOD_APPROVE + "'");
				if (MpmCONST.NEED_HOD_APPROVE.equals(currentIndi)) {
					sb.append(" selected");
				}
				sb.append(">" + MpmLocaleUtil.getMessage("mcd.jsp.xyHODsp") + "</option>");

				sb.append("<option value='" + MpmCONST.NEED_CCO_APPROVE + "'");
				if (MpmCONST.NEED_CCO_APPROVE.equals(currentIndi)) {
					sb.append(" selected");
				}
				sb.append(">" + MpmLocaleUtil.getMessage("mcd.jsp.xyCCOsp") + "</option>");
			}
			sb.append("</select>");
		} catch (Exception e) {
			log.error("", e);
		}
		return sb.toString();
	}

	/**
	 * 构造触发条件指标值对比操作符select html代码
	 * @param selectName
	 * @param selectExt
	 * @param currentIndi
	 * @return
	 */
	public static String genApproveTriggerCondIndiOperatorSelectHtml(String selectName, String selectExt,
			String currentIndi) {
		StringBuffer sb = new StringBuffer();
		try {
			sb.append("<select id ='" + selectName + "'  name='" + selectName + "' " + selectExt + ">");
			if (currentIndi != null && currentIndi.trim().equals(">")) {
				sb.append("<option value='>' selected>></option>");
			} else {
				sb.append("<option value='>'>></option>");
			}
			if (currentIndi != null && currentIndi.trim().equals(">=")) {
				sb.append("<option value='>=' selected>>=</option>");
			} else {
				sb.append("<option value='>='>>=</option>");
			}
			if (currentIndi != null && currentIndi.trim().equals("<")) {
				sb.append("<option value='<' selected><</option>");
			} else {
				sb.append("<option value='<'><</option>");
			}
			if (currentIndi != null && currentIndi.trim().equals("<=")) {
				sb.append("<option value='<=' selected><=</option>");
			} else {
				sb.append("<option value='<='><=</option>");
			}
			if (currentIndi != null && currentIndi.trim().equals("=")) {
				sb.append("<option value='=' selected>=</option>");
			} else {
				sb.append("<option value='='>=</option>");
			}
			sb.append("</select>");
		} catch (Exception e) {
			log.error("", e);
		}
		return sb.toString();
	}

	/**
	 * 通过审批人类型、审批人编号，取审批人名称
	 * @param objType
	 * @param objId
	 * @return
	 */
	public static String getApproveObjNameByTypeAndId(Integer objType, String objId) {
		String res = objId;
		try {
			IMtlApproveFlowDefService service = (IMtlApproveFlowDefService) SystemServiceLocator.getInstance()
					.getService(MpmCONST.MPM_APPROVE_FLOW_DEF_SERVICE);
			res = service.getApproveObjNameByTypeAndIdCache(objType, objId);
		} catch (Exception e) {
			log.error("", e);
		}
		return res;
	}

	/**
	 * 获取营销案状态图片展示的Html代码
	 * @param campStatus
	 * @param jsLinkFunc
	 * @return
	 */
	public static String getCampStatusImgHtml(Short campStatus, String jsLinkFunc) {
		StringBuffer sb = new StringBuffer();
		sb.append("<span  title='" + MpmLocaleUtil.getMessage("mcd.java.yxazt") + "'>"
				+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.COMPAIGN_STATUS, campStatus.toString())
				+ "</span>");
		return sb.toString();
	}

	/**
	 * 获取营销案／营销活动审批结果图片展示的html
	 * @param approveResult
	 * @param jsLinkFunc
	 * @return
	 */
	public static String getApproveResultImgHtml(HttpServletRequest request, Short approveResult, String jsLinkFunc) {
		StringBuffer sb = new StringBuffer();
		if (approveResult.shortValue() >= 0) {//0 -- 等待审批	 1 -- 通过审批 2 -- 没有通过审批	9 -- 要求活动终止
			sb.append("<span style=\"cursor:hand\" onclick=\""
					+ jsLinkFunc
					+ "\" title=\""
					+ MpmLocaleUtil.getMessage("mcd.java.spjd")
					+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_SEG_APPROVE_RESULT,
							approveResult.toString()) + "\"><img src=\"" + request.getContextPath()
					+ "/mpm/assets/images/b" + approveResult + ".gif\" border=\"0\"></span>");
		} else if (approveResult.shortValue() == -1) {//-1 --需要审批但未提交审批
			sb.append("<span  title=\""
					+ MpmLocaleUtil.getMessage("mcd.java.spjd")
					+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_SEG_APPROVE_RESULT,
							approveResult.toString()) + "\"><img src=\"" + request.getContextPath()
					+ "/mpm/assets/images/b" + approveResult + ".gif\" border=\"0\"></span>");
		}
		return sb.toString();
	}

	/**
	 * 获取营销案／营销活动确认结果图片展示的html
	 * @param confirmResult
	 * @param jsLinkFunc
	 * @return
	 */
	public static String getConfirmResultImgHtml(HttpServletRequest request, Short confirmResult, String jsLinkFunc) {
		StringBuffer sb = new StringBuffer();
		if (confirmResult.shortValue() > 0) { //3 - 等待确认	1 - 确认通过	2 - 确认不通过	9 - 确认营销案终止
			sb.append("<span style=\"cursor:hand\" onclick=\"" + jsLinkFunc + "\" title=\""
					+ MpmLocaleUtil.getMessage("mcd.java.qrjg1")
					+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_CONFIRM_FLAG, confirmResult.toString())
					+ "\"><img src=\"" + request.getContextPath() + "/mpm/assets/images/c" + confirmResult
					+ ".gif\" border=\"0\"></span>");
		} else if (confirmResult.shortValue() == 0) { //0 - 未提交确认
			sb.append("<span  title=\"" + MpmLocaleUtil.getMessage("mcd.java.qrjg1")
					+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_CONFIRM_FLAG, confirmResult.toString())
					+ "\"><img src=\"" + request.getContextPath() + "/mpm/assets/images/c" + confirmResult
					+ ".gif\" border=\"0\"></span>");
		}
		return sb.toString();
	}

	/**
	 * 营销活动策划查询页面
	 * @param compaignList
	 * @return
	 */
	/*public static String genCampDisplay(HttpServletRequest request, List compaignList, int flagTemplate) {
		StringBuffer sbHeader = new StringBuffer();
		//String tmpTitle = "";
		String execer_belong_city = MpmConfigure.getInstance().getProperty("EXECER_BELONG_CITY");
		try {
			IMpmRulesDesignService dservice = (IMpmRulesDesignService) SystemServiceLocator.getInstance().getService(
					MpmCONST.RULEDESIGN_SERVICE_BEAN_ID);
			IMpmCampBaseInfoService mcbs = (IMpmCampBaseInfoService) SystemServiceLocator.getInstance().getService(
					"mpmCampBaseInfoService");
			int cnt = compaignList.size();
			if (cnt <= 0) {
				return "<tr height='25'><td align='center' colspan='12'>"
						+ MpmLocaleUtil.getMessage("mcd.java.myfhtjdcxj") + "</td></tr>";
			}

			int td_length = 40;

			MtlCampSeginfo seg = new MtlCampSeginfo();
			for (int i = 0; i < cnt; i++) {
				seg = (MtlCampSeginfo) compaignList.get(i);
				String campsegName = seg.getCampsegName();

				if (StringUtil.isNotEmpty(campsegName) && campsegName.length() > td_length) {
					campsegName = campsegName.substring(0, td_length) + "...";
				}

				sbHeader.append("<tr height='25' onclick=\"clickTrSelectRadio(this,'" + seg.getCampsegId() + "','"
						+ seg.getCampsegStatId() + "')\" style='cursor:hand' title='"
						+ MpmLocaleUtil.getMessage("mcd.java.sjckbjchdx") + "' >\n");
				sbHeader.append("<td class='aibi_align_left' nowrap width='22px'><input type='radio' name='acitivityCbox' onclick=\"onClickSegRow(this,'"
						+ seg.getCampsegId() + "','" + seg.getCampsegStatId() + "')\"/></td>");
				if (StringUtil.isEmpty(seg.getCampId())) {
					if (flagTemplate == 1) {
						sbHeader.append("<td class='aibi_align_left'  style='text-decoration:underline' onclick=\"onDBClickCampSeg('"
								+ seg.getCampsegId()
								+ "',1)\" title='"
								+ seg.getCampsegName()
								+ "'>"
								+ campsegName
								+ "</td>");
					} else {
						sbHeader.append("<td class='aibi_align_left'  style='text-decoration:underline' onclick=\"onDBClickCampSeg('"
								+ seg.getCampsegId()
								+ "',0)\" title='"
								+ seg.getCampsegName()
								+ "'>"
								+ campsegName
								+ "</td>");
					}
				} else {
					if (flagTemplate == 1) {
						sbHeader.append("<td class='aibi_align_left' style='text-decoration:underline'  title='"
								+ seg.getCampsegName() + "'><span onclick=\"onDBClickCampSeg('" + seg.getCampsegId()
								+ "',1)\">" + campsegName + "</span>" + "<span title='"
								+ MpmLocaleUtil.getMessage("mcd.java.ckssyxaxx")
								+ "' onclick=\"javascript:onViewCamp('" + seg.getCampId() + "')\"><img src='"
								+ request.getContextPath() + "/mpm/assets/images/more.gif'></span></td>");
					} else {
						sbHeader.append("<td class='aibi_align_left' style='text-decoration:underline'  title='"
								+ seg.getCampsegName() + "'><span onclick=\"onDBClickCampSeg('" + seg.getCampsegId()
								+ "',0)\">" + campsegName + "</span>" + "<span title='"
								+ MpmLocaleUtil.getMessage("mcd.java.ckssyxaxx")
								+ "' onclick=\"javascript:onViewCamp('" + seg.getCampId() + "')\"><img src='"
								+ request.getContextPath() + "/mpm/assets/images/more.gif'></span></td>");
					}
				}
				sbHeader.append("<td class='aibi_align_left'>");
				if (mcbs.getCampaignBaseInfo(seg.getCampId()) != null) {
					sbHeader.append(mcbs.getCampaignBaseInfo(seg.getCampId()).getCampName());
				} else {
					sbHeader.append("--");
				}
				sbHeader.append("</td>");
				String tmpStr = "";
				if ("1".equals(execer_belong_city)) {
					//tmpTitle = MpmLocaleUtil.getMessage("mcd.java.chrssbm");
					if (seg.getDeptId() != null) {
						tmpStr = MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_DEPTID_SERVICE,
								String.valueOf(seg.getDeptId()));
					}
				}
				if ("0".equals(execer_belong_city)) {
					//tmpTitle = MpmLocaleUtil.getMessage("mcd.java.chrssds");
					if (seg.getCityId() != null && seg.getCityId().length() > 0) {
						tmpStr = MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_CITY_SERVICE, seg.getCityId());
					}
				}

				sbHeader.append("<td nowrap width=80>" + tmpStr + "/");
				if (seg.getCreateUserid() != null && seg.getCreateUserid().length() > 0) {
					sbHeader.append(MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_USERID_SERVICE,
							seg.getCreateUserid()));
				}
				sbHeader.append("</td>\n");
				if (flagTemplate != 1) {
					sbHeader.append("<td nowrap width=80>");
					if (null != seg.getCampsegStatId()) {
						sbHeader.append(MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_CAMPSEG_STAT_DEFINE,
								seg.getCampsegStatId().toString()));
					}
					
					sbHeader.append("</td>\n");
				}

				//营销渠道
				String channelName = "";
				Iterator it2 = dservice.findMtlChannelDef(seg.getCampsegId()).iterator();
				MtlChannelDef def;
				while (it2.hasNext()) {
					def = (MtlChannelDef) it2.next();
					String defName = MpmCache.getInstance().getNameByKeyFromDic("dimMtlChanneltype",
							def.getChanneltypeId())
							+ (String.valueOf(def.getChanneltypeId()).equals(MpmCONST.CHANNEL_TYPE_HALL) ? "" : "-"
									+ MpmCache.getInstance().getNameByKeyFromDic("allChannel",
											def.getChanneltypeAndId()));
					if (channelName.indexOf(defName) < 0) {
						channelName += defName + ",";
					}
				}
				if (channelName.indexOf(",") != -1) {
					channelName = channelName.substring(0, channelName.length() - 1);
				}
				sbHeader.append("<td nowrap width=110>" + channelName + "&nbsp;</td>\n");
				//活动类型
				if (null != seg.getCampDrvId()) {
					sbHeader.append("<td nowrap width=90>"
							+ MpmCache.getInstance().getNameByKeyFromDic("dimCampDrvType",
									seg.getCampDrvId().toString()) + "</td>");
				} else {
					sbHeader.append("<td nowrap width=90>&nbsp;</td>");
				}
				//创建时间
				if (null != seg.getCreateTime()) {
					sbHeader.append("<td nowrap width=70>" + MpmUtil.date2String(seg.getCreateTime()) + "</td>");
				} else {
					sbHeader.append("<td nowrap width=70>&nbsp;</td>");
				}
				//开始时间
				if (seg.getStartDate() != null) {
					sbHeader.append("<td nowrap width=70>" + MpmUtil.parseOutDate(seg.getStartDate()) + "</td>");
				} else {
					sbHeader.append("<td nowrap width=70>&nbsp;</td>");
				}
				//生效时间
				if (seg.getEndDate() != null) {
					sbHeader.append("<td nowrap width=70>" + MpmUtil.parseOutDate(seg.getEndDate()) + "</td>\n");
				} else {
					sbHeader.append("<td nowrap width=70>&nbsp;</td>\n");
				}
				//查询进度
				String isTemplate = (String) request.getAttribute("isTemplate");
				if (!"1".equals(isTemplate)) {
					sbHeader.append("<td nowrap width=50 style='text-align:center;' title='"
							+ MpmLocaleUtil.getMessage("mcd.jsp.hdjdcx") + "' onclick=\"javascript:viewProgress('"
							+ seg.getCampsegId() + "','1')\"><img src='" + request.getContextPath()
							+ "/mpm/assets/images/process.gif'/></td>");
				}
				sbHeader.append("</tr>\n");
			}
		} catch (Exception ex) {
			log.error("", ex);
		}
		return sbHeader.toString();
	}*/

	/**
	 * 生成可选导出字段列表（综合派单页面）
	 * @param campsegid
	 * @return
	 */
	/*public static String genLoadColumn(String campsegid) {
		IDimPubCommonService colService;
		try {
			colService = (IDimPubCommonService) SystemServiceLocator.getInstance().getService(
					MpmCONST.MPM_DIM_PUB_COMMON_SERVICE);
			return colService.getLoadcolumnServlet(campsegid);
		} catch (Exception e) {
			log.error("", e);
			return null;
		}
	}*/

	/**
	 * 分组信息html语句（综合派单－显示活动详细信息页面）
	 * @param campsegid
	 * @return
	 */
/*	public static String genUsersegForCallOut(String campsegid) {
		String channelName = ""; //getCampsegSubsectionHtml
		try {
			IMpmCampSegInfoService service = (IMpmCampSegInfoService) SystemServiceLocator.getInstance().getService(
					MpmCONST.CAMPAIGN_SEG_INFO_SERVICE);
			return service.getCampsegSubsectionHtml(campsegid);
		} catch (Exception e) {
			log.error("", e);
			return null;
		}

	}*/

	/**
	 * 生成派单渠道选择（综合派单页面）
	 * @param campsegid
	 * @return
	 */
	/*public static String genChannelCheckbox(String campsegid) {
		String channelName = "";
		IMpmRulesDesignService dservice;
		try {
			dservice = (IMpmRulesDesignService) SystemServiceLocator.getInstance().getService(
					MpmCONST.RULEDESIGN_SERVICE_BEAN_ID);
			List list = dservice.findMtlChannelDef(campsegid);
			if (null == list) {
				return null;
			}
			Iterator it2 = list.iterator();
			MtlChannelDef def = null;
			MtlCampsegExportCond cond = null;
			while (it2.hasNext()) {
				String defName = "";
				def = (MtlChannelDef) it2.next();
				cond = dservice.findMtlCECByExportId(campsegid, def.getChannelId());
				if (null != cond
						&& null != cond.getExportResult()
						&& cond.getExportResult().shortValue() == Short
								.valueOf(MpmCONST.MPM_CAMPSEG_EXPORT_EXPORTSUCCESS)) {
					defName = "<input type=checkbox disabled=true title='"
							+ MpmLocaleUtil.getMessage("mcd.java.gqdyjpdcg") + "' checked=false disabled=true value='"
							+ def.getChanneltypeId() + "&" + def.getChannelId() + "'><label>"
							+ MpmCache.getInstance().getNameByKeyFromDic("dimMtlChanneltype", def.getChanneltypeId())
							+ "-" + MpmCache.getInstance().getNameByKeyFromDic("allChannel", def.getChanneltypeAndId())
							+ "</label>";
				} else {
					defName = "<input type=checkbox checked value='" + def.getChanneltypeId() + "&"
							+ def.getChannelId()
							+ "'><label style='font-family: \"verdana\",\"宋体\";font-size: 10pt;color: #2650A6;'>"
							+ MpmCache.getInstance().getNameByKeyFromDic("dimMtlChanneltype", def.getChanneltypeId())
							+ "-" + MpmCache.getInstance().getNameByKeyFromDic("allChannel", def.getChanneltypeAndId())
							+ "</label>";
				}
				if (channelName.indexOf(defName) < 0) {
					channelName += defName + "&nbsp;";
				}
			}
			if (channelName.indexOf("<br>") != -1) {
				channelName = channelName.substring(0, channelName.length() - 4);
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return channelName;
	}*/

	/**
	 * 营销活动派单查询页面（综合查询）
	 * @param compaignList
	 * @return
	 */
	/*public static String genCampsegSendDisplay(HttpServletRequest request, List compaignList) {
		StringBuffer sbHeader = new StringBuffer();

		try {
			IMpmCampSegInfoService segService = (IMpmCampSegInfoService) SystemServiceLocator.getInstance().getService(
					MpmCONST.CAMPAIGN_SEG_INFO_SERVICE);
			String execer_belong_city = MpmConfigure.getInstance().getProperty("EXECER_BELONG_CITY");
			int cnt = compaignList.size();
			if (cnt <= 0) {
				return "<tr height='25'><td align='center' colspan='11'>"
						+ MpmLocaleUtil.getMessage("mcd.java.myfhtjdcxj") + "</td></tr>";
			}
			String containsCamp = MpmConfigure.getInstance().getProperty("CONTAINS_CAMPSHOW");
			MtlCampSeginfo seg = null;
			for (int i = 0; i < cnt; i++) {
				seg = (MtlCampSeginfo) compaignList.get(i);
				String campClass = seg.getCampClass() == null ? "" : seg.getCampClass().toString();

				sbHeader.append("<tr align='center'  onclick=\"clickTrSelectRadio(this,'" + seg.getCampsegId() + "','"
						+ seg.getCampsegStatId() + "','" + seg.getCampId() + "','" + campClass
						+ "')\" style='cursor:hand' title='" + MpmLocaleUtil.getMessage("mcd.java.sjckbjchdx")
						+ "'  >\n");

				//第一列，Checkbox
				sbHeader.append("<td class='aibi_align_left' nowrap width='22px'><input type='radio' name='campsegSendCbox' onclick=\"onClickSegRow(this,'"
						+ seg.getCampsegId()
						+ "','"
						+ seg.getCampsegStatId()
						+ "','"
						+ seg.getCampId()
						+ "','"
						+ campClass + "')\"/></td>");
				//第二列，活动名称
				*//**
				 * 如果是老活动弹出原活动查询页面，
				 * 新活动则弹出新的查看页面
				 *//*
				String onClickStr = "";
				if (seg.getCampClass() == null) {
					onClickStr = "onclick=\"onDBClickCampSeg('" + seg.getCampsegId() + "')\"";
				} else {
					onClickStr = "onclick=\"onDBClickCampSegNew('" + seg.getCampsegId() + "')\"";
				}
				if (null != seg.getCampId() && !"".equals(seg.getCampId())) {
					sbHeader.append("<td class='aibi_align_left autocut' style='text-decoration:underline'  title='"
							+ seg.getCampsegName() + "'><a " + onClickStr + " >" + seg.getCampsegName()
							+ "</a><a style='cursor:hand' title='" + MpmLocaleUtil.getMessage("mcd.java.ckssyxaxx")
							+ "' onclick=\"javascript:onViewCamp('" + seg.getCampId() + "')\"><img src='"
							+ request.getContextPath() + "/mpm/assets/images/more.gif'></a></td>");
				} else {
					sbHeader.append("<td class='aibi_align_left autocut' style='text-decoration:underline' "
							+ onClickStr + "  title='" + seg.getCampsegName() + "'><a>" + seg.getCampsegName()
							+ "</a></td>");
				}
				//所属营销案
				if ("1".equals(containsCamp)) {
					String campName = "--";
					if (StringUtil.isNotEmpty(seg.getCampId())) {
						campName = MpmCache.getInstance().getNameByKeyFromDic("mpmCamp", seg.getCampId());
					}
					sbHeader.append("<td class='aibi_align_left autocut'" + onClickStr + " id='ssyxa_td_" + i
							+ "'  title='" + campName + "'>&nbsp;" + campName + "</td>");
				}
				//活动类型
				String campDrvName = "--";
				if (null != seg.getCampDrvId()) {
					campDrvName = MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.AP_CAMP_DRV_TYPE,
							String.valueOf(seg.getCampDrvId()));
				}
				sbHeader.append("<td class='autocut'" + onClickStr + "  title='"
						+ MpmLocaleUtil.getMessage("mcd.jsp.sshdlx") + "'>&nbsp;" + campDrvName + "</td>");
				//第二列，策划人所属地市/策划人
				String tmpStr = "-";
				String tmpTitle = "";
				if ("1".equals(execer_belong_city)) {
					tmpTitle = MpmLocaleUtil.getMessage("mcd.java.chrssbm");
					if (seg.getDeptId() != null) {
						tmpStr = MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_DEPTID_SERVICE,
								String.valueOf(seg.getDeptId()));
					}
				}
				if ("0".equals(execer_belong_city)) {
					tmpTitle = MpmLocaleUtil.getMessage("mcd.java.chrssds");
					if (seg.getCityId() != null && seg.getCityId().length() > 0) {
						tmpStr = MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_CITY_SERVICE, seg.getCityId());
					}
				}

				sbHeader.append("<td title='" + tmpTitle + "/" + MpmLocaleUtil.getMessage("mcd.java.hdchr") + "'>"
						+ tmpStr + "/");
				if (seg.getCreateUserid() != null && seg.getCreateUserid().length() > 0) {
					sbHeader.append(MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_USERID_SERVICE,
							seg.getCreateUserid()));
				} else {
					sbHeader.append("--");
				}
				sbHeader.append("</td>\n");

				//第三列，活动客户数
				Integer userNum = null;
				List<MtlCampsegCiCustgroup> mccg = segService.getCiCustGroupListByCampSeg(seg.getCampsegId());
				if (CollectionUtils.isNotEmpty(mccg)) {
					userNum = 0;
					for (MtlCampsegCiCustgroup mccTemp : mccg) {
						userNum += mccTemp.getCustgroupNumber();
					}
				}

				sbHeader.append("<td title='" + MpmLocaleUtil.getMessage("mcd.java.cjhddkhs") + "'>"
						+ MpmUtil.parseOutInteger(userNum) + "</td>\n");
				//第四列，活动优先级
				if (null != seg.getCampPriId()) {
					sbHeader.append("<td title='" + MpmLocaleUtil.getMessage("mcd.java.hdyxj") + "' id='hdyxj_td_" + i
							+ "'>"
							+ MpmCache.getInstance().getNameByKeyFromDic("dimCampPri", seg.getCampPriId().toString())
							+ "</td>\n");
				} else {
					sbHeader.append("<td title='" + MpmLocaleUtil.getMessage("mcd.java.hdyxj") + "'>&nbsp;</td>\n");
				}
				//第五列，开始日期
				sbHeader.append("<td nowrap title='" + MpmLocaleUtil.getMessage("mcd.java.hdksrq") + "'>"
						+ MpmUtil.parseOutDate(seg.getStartDate()) + "</td>\n");
				//第六列，结束日期
				sbHeader.append("<td width=80 nowrap title='" + MpmLocaleUtil.getMessage("mcd.java.hdjsrq") + "'>"
						+ MpmUtil.parseOutDate(seg.getEndDate()) + "</td>\n");
				//第七列，活动状态
				if (null != seg.getCampsegStatId()) {
					if (MpmCONST.MPM_CAMPSEG_STAT_DDSB.equals(seg.getCampsegStatId().toString())) {
						sbHeader.append("<td title='"
								+ MpmLocaleUtil.getMessage("mcd.java.hdzt")
								+ "' nowrap>"
								+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_CAMPSEG_STAT_DEFINE,
										seg.getCampsegStatId().toString()) + "<span style='cursor:hand' title='"
								+ MpmLocaleUtil.getMessage("mcd.jsp.cksbyy")
								+ "' onclick=\"javascript:onViewFailedReason('" + seg.getCampsegId()
								+ "')\"><img src='" + request.getContextPath()
								+ "/mpm/assets/images/more.gif'></span></td>\n");
					} else {
						sbHeader.append("<td title='"
								+ MpmLocaleUtil.getMessage("mcd.java.hdzt")
								+ "' nowrap>"
								+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_CAMPSEG_STAT_DEFINE,
										seg.getCampsegStatId().toString()) + "</td>\n");
					}
				} else {
					sbHeader.append("<td title='" + MpmLocaleUtil.getMessage("mcd.java.hdzt")
							+ "' nowrap>&nbsp;</td>\n");
				}
				//第八列，执行渠道

				*//**
				 * 获取活动下的执行渠道，用于页面展示
				 *//*
				StringBuffer channelName = new StringBuffer();

				List<String> firstCampsegId = new ArrayList<String>();
				if (!"".equals(campClass)) {
					List<MtlCampSeginfo> campinfoList = segService.getCampSeginfoListByCampsegId(seg.getCampsegId());
					for (MtlCampSeginfo seginfoTemp : campinfoList) {
						if (seginfoTemp.getCampClass() == 2) {
							firstCampsegId.add(seginfoTemp.getCampsegId());
						}
					}
				} else {
					firstCampsegId.add(seg.getCampsegId());
				}

				IMpmRulesDesignService dservice = (IMpmRulesDesignService) SystemServiceLocator.getInstance()
						.getService(MpmCONST.RULEDESIGN_SERVICE_BEAN_ID);
				for (String s : firstCampsegId) {
					Iterator it2 = dservice.findMtlChannelDef(s).iterator();
					MtlChannelDef def = null;
					while (it2.hasNext()) {
						def = (MtlChannelDef) it2.next();
						//modified by wanglei 营业厅特殊处理
						String defName = MpmCache.getInstance().getNameByKeyFromDic("dimMtlChanneltype",
								def.getChanneltypeId())
								+ ((def.getChanneltypeId().toString().equals(MpmCONST.CHANNEL_TYPE_HALL)) ? ""
										: ("-" + MpmCache.getInstance().getNameByKeyFromDic("allChannel",
												def.getChanneltypeAndId())));
						channelName.append(defName + ",");
					}
				}
				if(!StringUtil.isEmpty(channelName)){
				channelName.deleteCharAt(channelName.length() - 1);}
				sbHeader.append("<td id='executionChannelTd' class='autocut' title='" + channelName.toString() + "' >"
						+ channelName.toString() + "</td>\n");
				sbHeader.append("</tr>\n");
			}
		} catch (Exception ex) {
			log.error("", ex);
		}
		return sbHeader.toString();
	}*/

	/**
	 * 营销案策划查询页面
	 * @param compaignList
	 * @param flagTemplate
	 * 0:非模板回传；1：模板回传
	 * @return
	 */
	/*public static String genCaseDisplay(HttpServletRequest request, List compaignList, int flagTemplate) {
		StringBuffer sbHeader = new StringBuffer();
		try {
			IMpmUserPrivilegeService mpmUserPrivilegeService = (IMpmUserPrivilegeService) SystemServiceLocator
					.getInstance().getService(MpmCONST.MPM_USER_PRIVILEGE_SERVICE);
			int cnt = compaignList.size();
			if (cnt <= 0) {
				return "<tr  height='25'><td align='center' colspan='10'>"
						+ MpmLocaleUtil.getMessage("mcd.java.myfhtjdcxj") + "</td></tr>";
			}

			MtlCampBaseinfo compaign = new MtlCampBaseinfo();
			String divName, imgName;
			int segCnt = 0;
			String execer_belong_city = MpmConfigure.getInstance().getProperty("EXECER_BELONG_CITY");
			for (int i = 0; i < cnt; i++) {
				segCnt = 0;
				compaign = (MtlCampBaseinfo) compaignList.get(i);
				divName = "camp_" + compaign.getCampId();
				imgName = "camp_img_" + compaign.getCampId();
				sbHeader.append(
						"\n<tr nowrap align='center' onclick=\"clickTrSelectRadio(this,'" + compaign.getCampId()
								+ "','" + compaign.getCampStatus() + "','" + compaign.getApproveResult()
								+ "');\"  style='cursor:hand' >\n")
						.append("\n<td nowrap width='22px'><input type='radio' name='campaignCbox' onclick=\"onClickRow(this,'"
								+ compaign.getCampId()
								+ "','"
								+ compaign.getCampStatus()
								+ "','"
								+ compaign.getApproveResult() + "');\"/></td>")
						.append("\n<td style='text-decoration:underline' nowrap title='" + compaign.getCampName()
								+ "'>");
				if (compaign.getCampSegs() != null) {
					segCnt = compaign.getCampSegs().size();
				}
				String campName = compaign.getCampName();
				if (campName.length() > 10) {
					campName = campName.substring(0, 7) + "...";

				}
				if (segCnt > 0) {
					sbHeader.append("<img style='top:3px;' name='" + imgName
							+ "' flag='1' src='assets/images/plus.gif'\" onclick=\"showCompaign('document.all."
							+ divName + "',this," + segCnt + ");\"/><span onclick=\"onDBClick(\'"
							+ compaign.getCampId() + "\')\">" + campName + "(" + MpmLocaleUtil.getMessage("mcd.jsp.g")
							+ "<font color='blue'><b>" + segCnt + "</b></font>"
							+ MpmLocaleUtil.getMessage("mcd.java.bfonthdtdt") + ")</span></td>\n");
				} else {
					if (flagTemplate != 1) {
						sbHeader.append("<span onclick=\"onDBClick(\'" + compaign.getCampId() + "\'," + flagTemplate
								+ ")\">" + campName + "(" + MpmLocaleUtil.getMessage("mcd.jsp.g")
								+ "<font color='blue'><b>" + segCnt + "</b></font>"
								+ MpmLocaleUtil.getMessage("mcd.java.bfonthdtdt") + ")</span></td>\n");
					} else {
						sbHeader.append("<span onclick=\"onDBClick(\'" + compaign.getCampId() + "\'," + flagTemplate
								+ ")\">" + campName + "</span></td>\n");
					}

				}
				sbHeader.append("<td nowrap width='125'>");
				if (compaign.getDeptId() != null) {
					sbHeader.append(MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_DEPTID_SERVICE,
							String.valueOf(compaign.getDeptId())));
				} else {
					sbHeader.append("-");
				}
				sbHeader.append("/");
				if (compaign.getCreateUserid() != null && compaign.getCreateUserid().length() > 0) {
					sbHeader.append(MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_USERID_SERVICE,
							compaign.getCreateUserid()));
				} else {
					sbHeader.append("-");
				}
				sbHeader.append("</td>\n");
				if (flagTemplate != 1) {
					sbHeader.append("<td nowrap width='75'>");
					sbHeader.append("<span  title='" + MpmLocaleUtil.getMessage("mcd.java.yxazt") + "'>");
					if (compaign.getCampStatus() != null) {
						sbHeader.append(MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.COMPAIGN_STATUS,
								String.valueOf(compaign.getCampStatus())));
					} else {
						sbHeader.append("-");
					}
					sbHeader.append("</span>");
				
					sbHeader.append("</td>");
				}
				IMpmCampBaseInfoService service = (IMpmCampBaseInfoService) SystemServiceLocator.getInstance()
						.getService(MpmCONST.CAMPAIGN_BASE_INFO_SERVICE);

				List channelTypeList = service.findMtlCampChannelType(compaign.getCampId());
				String channelTypeName = "";
				Iterator iter = channelTypeList.iterator();
				while (iter.hasNext()) {
					com.ai.bdx.frame.approval.model.MtlCampChanneltype mtlCampChanneltype = (com.ai.bdx.frame.approval.model.MtlCampChanneltype) iter
							.next();
					channelTypeName += MpmCache.getInstance().getNameByKeyFromDic("dimMtlChanneltype",
							mtlCampChanneltype.getId().getChanneltypeId())
							+ "-"
							+ MpmCache.getInstance().getNameByKeyFromDic("allChannel",
									mtlCampChanneltype.getChanneltypeAndId()) + ",";
				}
				if (channelTypeName.indexOf(",") != -1) {
					channelTypeName = channelTypeName.substring(0, channelTypeName.length() - 1);
				}

				sbHeader.append("<td nowrap  width='120' nowrap title='" + channelTypeName + "'>" + channelTypeName
						+ "</td>\n");

				sbHeader.append("<td nowrap width='80'>" + MpmUtil.date2String(compaign.getCreateDate()) + "</td>\n")
						.append("<td width='80' nowrap>" + MpmUtil.parseOutDate(compaign.getStartDate()) + "</td>\n")
						.append("<td width='80' nowrap>" + MpmUtil.parseOutDate(compaign.getEndDate()) + "</td>\n");
				if (flagTemplate != 1) {
					sbHeader.append("<td nowrap width='50' style='text-align:center;' title='"
							+ MpmLocaleUtil.getMessage("mcd.jsp.hdjdcx") + "' onclick=\"javascript:viewProgress('"
							+ compaign.getCampId() + "','0')\"><img src='" + request.getContextPath()
							+ "/mpm/assets/images/process.gif'/></td>");
				}
				sbHeader.append("</tr>");
				if (segCnt > 0) {
					//sbHeader.append("\n<tr style='display:none' id='" + divName + "'>\n<td colspan='9'>\n");
					Iterator it = compaign.getCampSegs().iterator();
					MtlCampSeginfo seg;
					//sbHeader.append("<table width='100%' class='aibi_table_data' border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse'>\n");
					int index = 0;
					while (it.hasNext()) {
						seg = (MtlCampSeginfo) it.next();
						sbHeader.append("<tr class='aibi_align_left' style='cursor:hand;display:none' id='" + divName
								+ index + "' onclick=\"onClickSegRow(this,'" + seg.getCampsegId() + "')\">\n");
						sbHeader.append("<td width='22px'></td>");
						sbHeader.append("<td class='aibi_align_left' title='"
								+ MpmLocaleUtil.getMessage("mcd.java.hdmc") + "'>");
						if (index < segCnt - 1) {
							sbHeader.append("<img src=\"assets/images/join.gif\">");
						} else {
							sbHeader.append("<img src=\"assets/images/joinbottom.gif\">");
						}
						sbHeader.append("&nbsp;" + seg.getCampsegName() + "</td>");
						String tmpStr = "-";
						String tmpTitle = "";
						if ("1".equals(execer_belong_city)) {
							tmpTitle = MpmLocaleUtil.getMessage("mcd.java.chrssbm");
							IUser user = mpmUserPrivilegeService.getUser(seg.getCreateUserid());
							if (user != null) {
								tmpStr = MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_DEPTID_SERVICE,
										String.valueOf(user.getDepartmentid()));
							}
						}
						if ("0".equals(execer_belong_city)) {
							tmpTitle = MpmLocaleUtil.getMessage("mcd.java.chrssds");
							if (seg.getCityId() != null && seg.getCityId().length() > 0) {
								tmpStr = MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_CITY_SERVICE,
										seg.getCityId());
							}
						}
						sbHeader.append("<td  title='" + tmpTitle + "/" + MpmLocaleUtil.getMessage("mcd.java.hdchr")
								+ "'>" + tmpStr + "/");
						if (compaign.getCreateUserid() != null && compaign.getCreateUserid().length() > 0) {
							sbHeader.append(MpmCache.getInstance().getNameByKeyFromDic(MpmCONST.DIM_USERID_SERVICE,
									compaign.getCreateUserid()));
						} else {
							sbHeader.append("-");
						}
						sbHeader.append("</td>\n");

						sbHeader.append("<td title='"
								+ MpmLocaleUtil.getMessage("mcd.java.hdzt")
								+ "' nowrap>"
								+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_CAMPSEG_STAT_DEFINE,
										seg.getCampsegStatId().toString()));
						
						sbHeader.append("</td>\n");
						String channelName = "";
						IMpmRulesDesignService dservice = (IMpmRulesDesignService) SystemServiceLocator.getInstance()
								.getService(MpmCONST.RULEDESIGN_SERVICE_BEAN_ID);
						Iterator it2 = dservice.findMtlChannelDef(seg.getCampsegId()).iterator();
						MtlChannelDef def;
						while (it2.hasNext()) {
							def = (MtlChannelDef) it2.next();
							String defName = MpmCache.getInstance().getNameByKeyFromDic("dimMtlChanneltype",
									def.getChanneltypeId())
									+ "-"
									+ MpmCache.getInstance().getNameByKeyFromDic("allChannel",
											def.getChanneltypeAndId());
							if (channelName.indexOf(defName) < 0) {
								channelName += defName + ",";
							}
						}
						if (channelName.indexOf(",") != -1) {
							channelName = channelName.substring(0, channelName.length() - 1);
						}

						sbHeader.append("<td nowrap><div align='left' style='width:120px; white-space:nowrap;text-overflow:ellipsis;overflow: hidden' title='营销活动使用的渠道："
								+ channelName + "'>" + channelName + "</div></td>\n");

						sbHeader.append("\n<td nowrap title='" + MpmLocaleUtil.getMessage("mcd.java.hdcjrq") + "'>"
								+ DateUtil.date2String(seg.getCreateTime(), MpmUtil.DATE_LOCALE_FORMAT) + "</td>");
						sbHeader.append("\n<td nowrap title='" + MpmLocaleUtil.getMessage("mcd.java.hdksrq") + "'>"
								+ MpmUtil.parseOutDate(seg.getStartDate()) + "</td><td width=80 nowrap title='"
								+ MpmLocaleUtil.getMessage("mcd.java.hdjsrq") + "'>"
								+ MpmUtil.parseOutDate(seg.getEndDate()) + "</td>\n");
						sbHeader.append("<td width='50' style='text-align:center;' nowrap  title='"
								+ MpmLocaleUtil.getMessage("mcd.jsp.hdjdcx") + "' onclick=\"javascript:viewProgress('"
								+ seg.getCampsegId() + "','1')\"><img src='" + request.getContextPath()
								+ "/mpm/assets/images/process.gif'></td>");
						sbHeader.append("</tr>\n");
						index++;

					}
					
				}
			}
		} catch (Exception ex) {
			log.error("", ex);
		}
		return sbHeader.toString();
	}*/


	/**
	 * 活动首页列表
	 * @param request
	 * @param compaignList
	 * @return
	 */
/*	public static String genCampDisplayForHomePage(HttpServletRequest request, List compaignList) {
		StringBuffer sbHeader = new StringBuffer();
		String bgColor = "#D9ECF6";//"#EFF5FB";
		String execer_belong_city = MpmConfigure.getInstance().getProperty("EXECER_BELONG_CITY");
		IMpmUserPrivilegeService mpmUserPrivilegeService = null;

		try {
			mpmUserPrivilegeService = (IMpmUserPrivilegeService) SystemServiceLocator.getInstance().getService(
					MpmCONST.MPM_USER_PRIVILEGE_SERVICE);
		} catch (Exception e) {
			log.error("", e);
		}
		try {
			int cnt = compaignList.size();
			if (cnt <= 0) {
				return "";
			}
			MtlCampSeginfo seg = new MtlCampSeginfo();
			for (int i = 0; i < cnt; i++) {
				if (i % 2 == 0) {
					bgColor = "bule5";
				} else {
					bgColor = "bule1";
				}
				seg = (MtlCampSeginfo) compaignList.get(i);
				sbHeader.append("<tr class='" + bgColor + "' align='center'  style='cursor:hand'>\n");
				if (StringUtil.isEmpty(seg.getCampId())) {
					sbHeader.append("</td><td align='left' nowrap>&nbsp;" + seg.getCampsegName() + "</td>");
				} else {
					sbHeader.append("</td><td align='left' nowrap>&nbsp;"
							+ seg.getCampsegName()
							+ "<span style='cursor:hand' title='view campaigns information' onclick=\"javascript:onViewCamp('"
							+ seg.getCampId() + "')\"><img src='" + request.getContextPath()
							+ "/mpm/images/more.gif'></span></td>");
				}
				String tmpStr = "-";
				String tmpTitle = "";
				if ("1".equals(execer_belong_city)) {
					tmpTitle = MpmLocaleUtil.getMessage("mcd.java.chrssbm");
					IUser user = mpmUserPrivilegeService.getUser(seg.getCreateUserid());
					if (user != null) {
						IUserCompany dept = mpmUserPrivilegeService.getUserCompanyById(String.valueOf(user
								.getDepartmentid()));
						if (dept != null) {
							tmpStr = dept.getTitle();
						}
					}
				}
				if ("0".equals(execer_belong_city)) {
					tmpTitle = MpmLocaleUtil.getMessage("mcd.java.chrssds");
					ICity city = mpmUserPrivilegeService.getCityById(seg.getCityId());
					if (city != null) {
						tmpStr = city.getCityName();
					}
				}
				sbHeader.append("<td>" + tmpStr + "/"
						+ mpmUserPrivilegeService.getUser(seg.getCreateUserid()).getUsername() + "</td>\n");

				sbHeader.append("<td nowrap>"
						+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_CAMPSEG_STAT_DEFINE,
								seg.getCampsegStatId().toString()));
				sbHeader.append("</td>\n");
				String channelName = "";
				IMpmRulesDesignService dservice = (IMpmRulesDesignService) SystemServiceLocator.getInstance()
						.getService(MpmCONST.RULEDESIGN_SERVICE_BEAN_ID);
				Iterator it2 = dservice.findMtlChannelDef(seg.getCampsegId()).iterator();
				MtlChannelDef def;
				while (it2.hasNext()) {
					def = (MtlChannelDef) it2.next();
					String defName = MpmCache.getInstance().getNameByKeyFromDic("dimMtlChanneltype",
							def.getChanneltypeId())
							+ (def.getChanneltypeId().toString().equals(MpmCONST.CHANNEL_TYPE_HALL) ? "" : "-"
									+ MpmCache.getInstance().getNameByKeyFromDic("allChannel",
											def.getChanneltypeAndId()));
					if (channelName.indexOf(defName) < 0) {
						channelName += defName + ",";
					}
				}
				if (channelName.indexOf(",") != -1) {
					channelName = channelName.substring(0, channelName.length() - 1);
				}

				sbHeader.append("<td nowrap>" + channelName + "</td>\n");
				if (null == seg.getCampDrvId()) {
					sbHeader.append("<td nowrap >&nbsp;</td>");
				} else {
					sbHeader.append("<td nowrap>"
							+ MpmCache.getInstance().getNameByKeyFromDic("dimCampDrvType",
									seg.getCampDrvId().toString()) + "</td>");
				}
				if (null == seg.getCreateTime()) {
					sbHeader.append("<td nowrap>&nbsp;</td>");
				} else {
					sbHeader.append("<td nowrap>"
							+ DateUtil.date2String(seg.getCreateTime(), MpmUtil.DATE_LOCALE_FORMAT) + "</td>");
				}
				sbHeader.append("<td nowrap>" + MpmUtil.parseOutDate(seg.getStartDate()) + "</td><td width=80 nowrap>"
						+ MpmUtil.parseOutDate(seg.getEndDate()) + "</td>\n");
				sbHeader.append("</tr>\n");
			}
		} catch (Exception ex) {
			log.error("", ex);
		}
		return sbHeader.toString();
	}
*/
	


	
	
	public static String getMpmModelFilePath() {
		String mpmPath = Configure.getInstance().getProperty("SYS_COMMON_MPM_MODEL_PATH");
		return mpmPath;
	}

	/**
	 * 保存上载的文件到服务器端
	 * modified by wt 2008-07-03
	 * @param uploadFile
	 * @param storePath
	 * @param destFileName
	 * @param bCleanFolder
	 * @param needUseFtp 是否使用FTP（活动、波次、审批等的附件可能需要使用FTP，活动剔除用户清单、目标客户清单等不需要使用FTP）
	 * @return 返回上载成功后文件保存的完整路径
	 */
	/*public static String uploadFileOne(String uploadFile, String storePath, String destFileName, boolean bCleanFolder,
			boolean needUseFtp) {
		String remsg = "";
		ApacheFtpUtil ftp = null;
		try {
			if (StringUtil.isEmpty(storePath)) {
				remsg = MpmLocaleUtil.getMessage("mcd.java.myzdscljqy");
				return remsg;
			}

			java.io.File rootFolder = new java.io.File(storePath);
			//上载目录不存在，创建
			if (!rootFolder.exists()) {
				rootFolder.mkdirs();
			}
			//上载目录存在，清除目录下的所有文件
			else if (bCleanFolder) {
				java.io.File[] tmpFiles = rootFolder.listFiles();
				for (int i = 0; i < tmpFiles.length; i++) {
					tmpFiles[i].delete();
				}
			}

			//获得上传到的文件路径和名称
			String uploadName = storePath + File.separator + destFileName;
			log.debug("uploadFile:" + uploadFile);
			log.debug("uploadName:" + uploadName);
		
			remsg = uploadName;

			if (needUseFtp) {
				//added by wwl 2007-5-25 支持把上传文件存储到FTP服务器上
				String isUseFtpStore = Configure.getInstance().getProperty("MPM_USE_FTP_STORE");
				if (isUseFtpStore != null && isUseFtpStore.equals("1")) {
					String ftpServer = Configure.getInstance().getProperty("MPM_FTP_SERVER_IP");
					int ftpServerPort = Integer.parseInt(Configure.getInstance().getProperty("MPM_FTP_SERVER_PORT"));
					String ftpStorePath = Configure.getInstance().getProperty("MPM_FTP_SERVER_STORE_PATH");
					String ftpUserName = Configure.getInstance().getProperty("MPM_FTP_USERNAME");
					String ftpUserPwd = Configure.getInstance().getProperty("MPM_FTP_USERPWD");
					String ftpUserPwdEncrypt = Configure.getInstance().getProperty("MPM_FTP_USERPWD_ENCRYPT");
					if (ftpUserPwdEncrypt != null && ftpUserPwdEncrypt.equals("1")) {
						ftpUserPwd = DES.decrypt(ftpUserPwd);
					}

					ftp = ApacheFtpUtil.getInstance(ftpServer, ftpServerPort, ftpUserName, ftpUserPwd, null);
					if (ftpStorePath != null && ftpStorePath.length() != 0) {
						ftp.changeDir(ftpStorePath);
					}
					ftp.upload(uploadName, destFileName);
				}
			}
			//added end

		}// end of try
		catch (Exception e) {
			log.error("", e);
			remsg = "";
			ftp.closeFtpConnection();
		}
		return remsg;
	}*/

	/**
	 * 增加传递的营销案HTML信息页
	 */
	/*public static void exportCampInfoHtml(String userId, String campId, List haveAttachList,
			IMtlAttachmentService attachService, IMpmCampBaseInfoService service, MpmCampBaseInfoForm baseForm) {
		try {
			IMpmCampsegApproveService baseInfoService;
			IMpmCommonService mpmBaseService;
			baseInfoService = (IMpmCampsegApproveService) SystemServiceLocator.getInstance().getService(
					MpmCONST.CAMPSEG_APPROVE_SERVICE_BEAN_ID);
			mpmBaseService = (IMpmCommonService) SystemServiceLocator.getInstance().getService(
					MpmCONST.COMMON_SERVICE_BEAN_ID);
			MtlCampBaseinfo campObj = baseInfoService.findCampInfo(campId);
			IMpmUserPrivilegeService userPrivilegeService = (IMpmUserPrivilegeService) SystemServiceLocator
					.getInstance().getService(MpmCONST.MPM_USER_PRIVILEGE_SERVICE);

			FileWriter fw;

			String fileHtmlPath = MpmHtmlHelper.getMpmStoreFilePath();
			//String fileHtmlUrl = fileHtmlPath + "\\营销案基本信息_" + userId +"_" +  campId + ".html";
			String fileHtmlUrl = fileHtmlPath + File.separator + MpmLocaleUtil.getMessage("mcd.java.yxajbxx") + userId
					+ "_" + campId + ".html";
			// 把传递的HTML保存
			if (haveAttachList != null && haveAttachList.size() > 0) {
				int htmlISok = 0;
				for (int haveHtml = 0; haveHtml < haveAttachList.size(); haveHtml++) {
					// 已经有HTML了
					if (((MtlAttachmentInfo) haveAttachList.get(haveHtml)).getAttachmentName().equals(
							MpmLocaleUtil.getMessage("mcd.java.yxajbxx1"))) {
						htmlISok = 1;
					}
				}
				if (htmlISok == 0) {
					List attachListHtml = new ArrayList();

					MtlAttachmentInfo itemAttachHtml = new MtlAttachmentInfo();
					itemAttachHtml.setAttachmentName(MpmLocaleUtil.getMessage("mcd.java.yxajbxx1"));
					itemAttachHtml.setAttachmentUrl(fileHtmlUrl);
					itemAttachHtml.setCampCampsegId(campId);
					itemAttachHtml.setAttachmentType(Short.valueOf(MpmCONST.MPM_ATTACH_TYPE_CAMP));
					itemAttachHtml.setAttachmentContentType(Short.valueOf(MpmCONST.MPM_ATTACH_CONT_TYPE_SUPPORT));
					itemAttachHtml.setAttachmentUserid(userId);
					attachListHtml.add(itemAttachHtml);
					attachService.saveMtlAttachmentInfos(attachListHtml);
				}

			} else {
				List attachListHtml = new ArrayList();

				MtlAttachmentInfo itemAttachHtml = new MtlAttachmentInfo();
				itemAttachHtml.setAttachmentName(MpmLocaleUtil.getMessage("mcd.java.yxajbxx1"));
				itemAttachHtml.setAttachmentUrl(fileHtmlUrl);
				itemAttachHtml.setCampCampsegId(campId);
				itemAttachHtml.setAttachmentType(Short.valueOf(MpmCONST.MPM_ATTACH_TYPE_CAMP));
				itemAttachHtml.setAttachmentContentType(Short.valueOf(MpmCONST.MPM_ATTACH_CONT_TYPE_SUPPORT));
				itemAttachHtml.setAttachmentUserid(userId);
				attachListHtml.add(itemAttachHtml);
				attachService.saveMtlAttachmentInfos(attachListHtml);
			}

			fw = new FileWriter(fileHtmlUrl);
			fw.write("<html>																  ");
			fw.write("<head>                                                                  ");
			fw.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\" />  ");
			fw.write("<title></title>                                                         ");
			fw.write("</head>                                                                 ");
			fw.write("                                                                        ");
			fw.write("<body>                                                                  ");
			fw.write("<table width=\"934\" border=\"1\">                                          ");
			fw.write("  <tr>                                                                  ");
			fw.write("    <td width=\"133\"><b>" + MpmLocaleUtil.getMessage("mcd.java.yxamc1")
					+ "</b></td>                             ");
			fw.write("    <td width=\"785\">" + campObj.getCampName()
					+ "</td>                                         ");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><b>" + MpmLocaleUtil.getMessage("mcd.java.tdbyxjbtd") + "</b></td>");
			// 活动优先级
			Map PriMap = mpmBaseService.getCampPriMap();
			fw.write("    <td>" + (String) PriMap.get(campObj.getCampPriId())
					+ "</td>                                                     ");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><b>" + MpmLocaleUtil.getMessage("mcd.java.tdbksrqbtd") + "</b></td>");
			fw.write("    <td>" + MpmUtil.parseOutDate(campObj.getStartDate())
					+ "</td>                                                     ");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><b>" + MpmLocaleUtil.getMessage("mcd.java.tdbjsrqbtd") + "</b></td>");
			fw.write("    <td>" + MpmUtil.parseOutDate(campObj.getEndDate())
					+ "</td>                                                     ");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongqd") + "</strong></td>");
			// 驱动类型
			Map drvMap = mpmBaseService.getCampDrvTypeMap();
			fw.write("    <td>" + (String) drvMap.get(campObj.getCampDrvId())
					+ "</td>                                                     ");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx") + "</strong></td>");
			fw.write("    <td>" + campObj.getCampDesc() + "</td>                                                     ");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongmb") + "</strong></td>");
			fw.write("    <td>" + campObj.getGuessTotalCustNum() + MpmLocaleUtil.getMessage("mcd.java.wrtd") + "</td>");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx1") + "</strong></td>");
			fw.write("    <td>" + campObj.getCampStrageDesc()
					+ "</td>                                                     ");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx2") + "</strong></td>");
			haveAttachList = attachService.findAttachmentInfoByCampsegId(campId);
			fw.write("<td>");
			for (int i = 0; i < haveAttachList.size(); i++) {
				MtlAttachmentInfo itemAttach = (MtlAttachmentInfo) haveAttachList.get(i);
				fw.write(itemAttach.getAttachmentName() + "&nbsp;");
			}
			fw.write("</td>");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx3") + "</strong></td>");
			IdNameMapper mtlApproveFlowIdNameMapper = (IdNameMapper) SystemServiceLocator.getInstance().getService(
					MpmCONST.MTL_APPROVE_FLOW);
			fw.write("    <td>" + mtlApproveFlowIdNameMapper.getNameById(campObj.getApproveFlowid())
					+ "</td>                                                     ");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongnt") + "</strong></td>");
			fw.write("    <td>" + campObj.getGuessTotalCost() + MpmLocaleUtil.getMessage("mcd.java.wytd1") + "</td>");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx4") + "</strong></td>");
			IMpmCampBaseInfoService fService = (IMpmCampBaseInfoService) SystemServiceLocator.getInstance().getService(
					MpmCONST.CAMPAIGN_BASE_INFO_SERVICE);
			// 取营销案关联地市信息
			String campCity = fService.getCampCity(campId);
			String campCitys[] = campCity.split(",");
			String campCityName = "";
			if (campCitys != null && campCitys.length > 0) {
				for (int i = 0; i < campCitys.length; i++) {
					campCityName += userPrivilegeService.getCityById(campCitys[i]).getCityName() + " ";
				}
			}
			if (campCityName.length() > 1) {
				fw.write("    <td>" + campCityName.substring(0, campCityName.length() - 1)
						+ "</td>                                                     ");
			} else {
				fw.write("    <td>&nbsp;</td>                                                     ");
			}
			fw.write("  </tr>                                                                 ");
			if (campObj.getCampPlans() != null && campObj.getCampPlans().size() > 0) {
				fw.write("  <tr>                                                                  ");
				fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongtj") + "</strong></td>");
				fw.write("    <td>");
				Iterator itCampPlans = campObj.getCampPlans().iterator();
				while (itCampPlans.hasNext()) {
					fw.write(((MtlCampPlan) itCampPlans.next()).getPlanName() + "&nbsp;");
				}
				fw.write("</td>                                                     ");
				fw.write("  </tr>                                                                 ");
			}
			if (campObj.getCampIndis() != null && campObj.getCampIndis().size() > 0) {
				fw.write("		<tr><td><strong>" + MpmLocaleUtil.getMessage("mcd.java.trtdstrong") + "</strong></td>");
				fw.write("  <td><table width=\"790\" border=\"1\"> ");
				fw.write("<tr> ");
				fw.write("<td align=\"center\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.zbmc")
						+ "</strong></td> ");
				fw.write("<td align=\"center\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.ly") + "</strong></td> ");
				fw.write("<td align=\"center\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.mbz")
						+ "</strong> </td> ");
				fw.write("</tr> ");
				Iterator itCampIndis = campObj.getCampIndis().iterator();
				while (itCampIndis.hasNext()) {
					MtlCampIndiTargetval mtlCampIndiTargetval = (MtlCampIndiTargetval) itCampIndis.next();
					fw.write("<tr> ");
					fw.write("<td>" + mtlCampIndiTargetval.getNameIndi() + "</td> ");
					fw.write("<td>"
							+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_CAMP_INDI_RESOURCE,
									mtlCampIndiTargetval.getIndiResource().toString()) + "</td> ");
					fw.write("<td>" + mtlCampIndiTargetval.getTargetVal() + "</td> ");
					fw.write("</tr> ");
				}

				fw.write("</table></td>    ");
				fw.write("</tr> ");
			}
			fw.write("  <tr>                                                                  ");
			fw.write("    <td colspan=\"2\"><table width=\"924\" border=\"1\">                      ");
			fw.write("      <tr>                                                              ");
			fw.write("        <td width=\"184\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.qdmc")
					+ "</strong></td>                  ");
			fw.write("        <td width=\"115\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.kssyrq")
					+ "</strong></td>              ");
			fw.write("        <td width=\"115\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.jssyrq")
					+ "</strong></td>              ");
			fw.write("        <td width=\"115\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.mbkhswr")
					+ "</strong></td>         ");
			fw.write("        <td width=\"361\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.bz")
					+ "</strong></td>                      ");
			fw.write("      </tr>                                                             ");

			List channelTypeList = service.findMtlCampChannelType(campId);
			String[] chnTypeId = baseForm.getChannelTypeIds().split(",");
			if (channelTypeList != null && channelTypeList.size() > 0) {
				for (int chni = 0; chni < channelTypeList.size(); chni++) {
					MtlCampChanneltype mtlCampChanneltype = (MtlCampChanneltype) channelTypeList.get(chni);
					IdNameMapper dimMtlChanneltypeNameMapper = (IdNameMapper) SystemServiceLocator.getInstance()
							.getService(MpmCONST.DIM_MTL_CHANNELTYPE);
					IdNameMapper allChannelNameMapper = (IdNameMapper) SystemServiceLocator.getInstance().getService(
							MpmCONST.ALL_CHANNEL);
					fw.write("<tr>");
					//log.debug("baseForm.getChannelTypeIds():"+baseForm.getChannelTypeIds());
					//log.debug("chnTypeId[chni].split:"+chnTypeId[chni]);
					//log.debug("chnTypeId[chni].split:"+chnTypeId[chni].split("|")[0]);
					String[] chnTypeIdSearch = chnTypeId[chni].split("|");
					log.debug("chnTypeIdSearch:" + chnTypeIdSearch[0]);
					fw.write("<td>" + dimMtlChanneltypeNameMapper.getNameById(chnTypeIdSearch[0]) + "-"
							+ allChannelNameMapper.getNameById(mtlCampChanneltype.getChanneltypeAndId()) + "</td>");
					//log.debug("********************************");
					fw.write("<td>" + mtlCampChanneltype.getStartDate() + "</td>");
					fw.write("<td>" + mtlCampChanneltype.getEndDate() + "</td>");
					fw.write("<td>" + mtlCampChanneltype.getCustNums() + "</td>");
					fw.write("<td>" + mtlCampChanneltype.getUseDesc() + "</td>");
					fw.write("</tr>");
				}

			} else {
				fw.write("<tr>");
				fw.write("<td>&nbsp;</td>");
				fw.write("<td>&nbsp;</td>");
				fw.write("<td>&nbsp;</td>");
				fw.write("<td>&nbsp;</td>");
				fw.write("<td>&nbsp;</td>");
				fw.write("</tr>");
			}

			fw.write("    </table></td>                                                       ");
			fw.write("  </tr>                                                                 ");
			fw.write("</table>                                                                ");
			fw.write("</body>                                                                 ");
			fw.write("</html>                                                                 ");
			fw.close();
			String fileUrl = MpmHtmlHelper.uploadFileOne(fileHtmlUrl, fileHtmlPath,
					MpmLocaleUtil.getMessage("mcd.java.yxajbxx2") + userId + "_" + campId + ".html", false, true);
		} catch (IOException e) {
			log.error("", e);
		} catch (Exception e1) {
			log.error("", e1);
		}
	}*/

	/**
	 * 增加传递的营销活动HTML信息页
	 */
	/*public static void exportCampSegInfoHtml(MtlCampSeginfo baseInfo, String userId, String campsegId,
			List haveAttachList, IMtlAttachmentService attachService, MpmCampSegInfoForm baseForm) {
		try {
			IMpmCampsegApproveService baseInfoService = (IMpmCampsegApproveService) SystemServiceLocator.getInstance()
					.getService(MpmCONST.CAMPSEG_APPROVE_SERVICE_BEAN_ID);
			IMpmCommonService mpmBaseService = (IMpmCommonService) SystemServiceLocator.getInstance().getService(
					MpmCONST.COMMON_SERVICE_BEAN_ID);
			IMpmUserPrivilegeService userPrivilegeService = (IMpmUserPrivilegeService) SystemServiceLocator
					.getInstance().getService(MpmCONST.MPM_USER_PRIVILEGE_SERVICE);

			MtlCampBaseinfo campObj = baseInfoService.findCampInfo(baseInfo.getCampId());
			FileWriter fw;

			String fileHtmlPath = MpmHtmlHelper.getMpmStoreFilePath();
			//String fileHtmlUrl = fileHtmlPath + "\\营销活动基本信息_" + userId +"_" +  campsegId + ".html";
			String fileHtmlUrl = fileHtmlPath + File.separator + MpmLocaleUtil.getMessage("mcd.java.yxhdjbxx1")
					+ userId + "_" + campsegId + ".html";
			// 把传递的HTML保存
			if (haveAttachList != null && haveAttachList.size() > 0) {
				int htmlISok = 0;
				for (int haveHtml = 0; haveHtml < haveAttachList.size(); haveHtml++) {
					// 已经有HTML了
					if (((MtlAttachmentInfo) haveAttachList.get(haveHtml)).getAttachmentName().equals(
							MpmLocaleUtil.getMessage("mcd.java.yxhdjbxx2"))) {
						htmlISok = 1;
					}
				}
				if (htmlISok == 0) {
					List attachListHtml = new ArrayList();

					MtlAttachmentInfo itemAttachHtml = new MtlAttachmentInfo();
					itemAttachHtml.setAttachmentName(MpmLocaleUtil.getMessage("mcd.java.yxhdjbxx2"));
					itemAttachHtml.setAttachmentUrl(fileHtmlUrl);
					itemAttachHtml.setCampCampsegId(campsegId);
					itemAttachHtml.setAttachmentType(Short.valueOf(MpmCONST.MPM_ATTACH_TYPE_CAMPSEG));
					itemAttachHtml.setAttachmentContentType(Short.valueOf(MpmCONST.MPM_ATTACH_CONT_TYPE_SUPPORT));
					itemAttachHtml.setAttachmentUserid(userId);
					attachListHtml.add(itemAttachHtml);
					attachService.saveMtlAttachmentInfos(attachListHtml);
				}

			} else {
				List attachListHtml = new ArrayList();

				MtlAttachmentInfo itemAttachHtml = new MtlAttachmentInfo();
				itemAttachHtml.setAttachmentName(MpmLocaleUtil.getMessage("mcd.java.yxhdjbxx2"));
				itemAttachHtml.setAttachmentUrl(fileHtmlUrl);
				itemAttachHtml.setCampCampsegId(campsegId);
				itemAttachHtml.setAttachmentType(Short.valueOf(MpmCONST.MPM_ATTACH_TYPE_CAMPSEG));
				itemAttachHtml.setAttachmentContentType(Short.valueOf(MpmCONST.MPM_ATTACH_CONT_TYPE_SUPPORT));
				itemAttachHtml.setAttachmentUserid(userId);
				attachListHtml.add(itemAttachHtml);
				attachService.saveMtlAttachmentInfos(attachListHtml);
			}

			fw = new FileWriter(fileHtmlUrl);
			fw.write("<html>																  ");
			fw.write("<head>                                                                  ");
			fw.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\" />  ");
			fw.write("<title></title>                                                         ");
			fw.write("</head>                                                                 ");
			fw.write("                                                                        ");
			fw.write("<body>                                                                  ");
			fw.write("<table width=\"934\" border=\"1\">                                          ");
			fw.write("  <tr>                                                                  ");
			fw.write("    <td width=\"133\"><b>" + MpmLocaleUtil.getMessage("mcd.java.yxamc1")
					+ "</b></td>                             ");
			if (campObj != null && campObj.getCampName() != null && campObj.getCampName().length() > 0) {
				fw.write("<td width=\"785\">" + campObj.getCampName() + "</td>");
			} else {
				fw.write("<td width=\"785\"><b>&nbsp;</b></td>");
			}
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><b>" + MpmLocaleUtil.getMessage("mcd.java.tdbyxjbtd") + "</b></td>");
			// 活动优先级
			Map PriMap = mpmBaseService.getCampPriMap();
			if (campObj != null && campObj.getCampPriId() != null) {
				fw.write("    <td>" + (String) PriMap.get(campObj.getCampPriId())
						+ "</td>                                                     ");
			} else {
				fw.write("    <td><b>&nbsp;</b></td>                                                     ");
			}
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><b>" + MpmLocaleUtil.getMessage("mcd.java.tdbksrqbtd") + "</b></td>");
			if (campObj != null && campObj.getStartDate() != null && campObj.getStartDate().length() > 0) {
				fw.write("    <td>" + MpmUtil.parseOutDate(campObj.getStartDate())
						+ "</td>                                                     ");
			} else {
				fw.write("    <td><b>&nbsp;</b></td>                                                     ");
			}

			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><b>" + MpmLocaleUtil.getMessage("mcd.java.tdbjsrqbtd") + "</b></td>");
			if (campObj != null && campObj.getEndDate() != null && campObj.getEndDate().length() > 0) {
				fw.write("    <td>" + MpmUtil.parseOutDate(campObj.getEndDate())
						+ "</td>                                                     ");
			} else {
				fw.write("    <td><b>&nbsp;</b></td>                                                     ");
			}

			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongqd") + "</strong></td>");
			// 驱动类型
			Map drvMap = mpmBaseService.getCampDrvTypeMap();
			if (campObj != null && campObj.getCampDrvId() != null) {
				fw.write("    <td>" + (String) drvMap.get(campObj.getCampDrvId())
						+ "</td>                                                     ");
			} else {
				fw.write("    <td><b>&nbsp;</b></td>                                                     ");
			}
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx") + "</strong></td>");
			if (campObj != null && campObj.getCampDesc() != null && campObj.getCampDesc().length() > 0) {
				fw.write("    <td>" + campObj.getCampDesc()
						+ "</td>                                                     ");
			} else {
				fw.write("    <td><b>&nbsp;</b></td>                                                     ");
			}

			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongmb") + "</strong></td>");
			if (campObj != null && campObj.getGuessTotalCustNum() != null) {
				fw.write("    <td>" + campObj.getGuessTotalCustNum() + MpmLocaleUtil.getMessage("mcd.java.wrtd")
						+ "</td>");
			} else {
				fw.write("    <td><b>&nbsp;</b></td>                                                     ");
			}
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx1") + "</strong></td>");
			if (campObj != null && campObj.getCampStrageDesc() != null && campObj.getCampStrageDesc().length() > 0) {
				fw.write("    <td>" + campObj.getCampStrageDesc()
						+ "</td>                                                     ");
			} else {
				fw.write("    <td><b>&nbsp;</b></td>                                                     ");
			}
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx2") + "</strong></td>");
			haveAttachList = attachService.findAttachmentInfoByCampsegId(baseForm.getCampId());
			fw.write("<td>");
			for (int i = 0; i < haveAttachList.size(); i++) {
				MtlAttachmentInfo itemAttach = (MtlAttachmentInfo) haveAttachList.get(i);
				fw.write(itemAttach.getAttachmentName() + "&nbsp;");
			}
			fw.write("</td>");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx3") + "</strong></td>");
			IdNameMapper mtlApproveFlowIdNameMapper = (IdNameMapper) SystemServiceLocator.getInstance().getService(
					MpmCONST.MTL_APPROVE_FLOW);
			fw.write("    <td>" + mtlApproveFlowIdNameMapper.getNameById(baseForm.getApproveFlowid())
					+ "</td>                                                     ");
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongnt") + "</strong></td>");
			if (campObj != null && campObj.getGuessTotalCost() != null) {
				fw.write("    <td>" + campObj.getGuessTotalCost() + MpmLocaleUtil.getMessage("mcd.java.wytd1")
						+ "</td>");
			} else {
				fw.write("<td>" + MpmLocaleUtil.getMessage("mcd.java.tdwytd") + "</td>");
			}
			fw.write("  </tr>                                                                 ");
			fw.write("  <tr>                                                                  ");
			fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx4") + "</strong></td>");
			IMpmCampBaseInfoService fService = (IMpmCampBaseInfoService) SystemServiceLocator.getInstance().getService(
					MpmCONST.CAMPAIGN_BASE_INFO_SERVICE);
			// 取营销案关联地市信息
			String campCity = fService.getCampCity(baseForm.getCampId());
			String campCitys[] = campCity.split(",");
			String campCityName = "";
			if (campCitys != null && campCitys.length > 0) {
				for (int i = 0; i < campCitys.length; i++) {
					campCityName += userPrivilegeService.getCityById(campCitys[i]).getCityName() + " ";
				}
			}
			if (campCityName.length() > 1) {
				fw.write("    <td>" + campCityName.substring(0, campCityName.length() - 1)
						+ "</td>                                                     ");
			} else {
				fw.write("    <td>&nbsp;<b>&nbsp;</b></td>                                                     ");
			}
			fw.write("  </tr>                                                                 ");
			if (campObj != null && campObj.getCampPlans() != null && campObj.getCampPlans().size() > 0) {
				fw.write("  <tr>                                                                  ");
				fw.write("		<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongtj") + "</strong></td>");
				fw.write("    <td>");
				Iterator itCampPlans = campObj.getCampPlans().iterator();
				while (itCampPlans.hasNext()) {
					fw.write(((MtlCampPlan) itCampPlans.next()).getPlanName() + "&nbsp;");
				}
				fw.write("</td>                                                     ");
				fw.write("  </tr>                                                                 ");
			}
			if (campObj != null && campObj.getCampIndis() != null && campObj.getCampIndis().size() > 0) {
				fw.write("		<tr><td><strong>" + MpmLocaleUtil.getMessage("mcd.java.trtdstrong") + "</strong></td>");
				fw.write("  <td><table width=\"790\" border=\"1\"> ");
				fw.write("<tr> ");
				fw.write("<td align=\"center\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.zbmc")
						+ "</strong></td> ");
				fw.write("<td align=\"center\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.ly") + "</strong></td> ");
				fw.write("<td align=\"center\"><strong>" + MpmLocaleUtil.getMessage("mcd.java.mbz")
						+ "</strong> </td> ");
				fw.write("</tr> ");
				Iterator itCampIndis = campObj.getCampIndis().iterator();
				while (itCampIndis.hasNext()) {
					MtlCampIndiTargetval mtlCampIndiTargetval = (MtlCampIndiTargetval) itCampIndis.next();
					fw.write("<tr> ");
					fw.write("<td>" + mtlCampIndiTargetval.getNameIndi() + "</td> ");
					fw.write("<td>"
							+ MpmCache.getInstance().getNameByTypeAndKey(MpmCONST.MPM_CAMP_INDI_RESOURCE,
									mtlCampIndiTargetval.getIndiResource().toString()) + "</td> ");
					fw.write("<td>" + mtlCampIndiTargetval.getTargetVal() + "</td> ");
					fw.write("</tr> ");
				}

				fw.write("</table></td>    ");
				fw.write("</tr> ");
			}
			fw.write("<tr>");
			fw.write("<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx5") + "</strong></td>");
			fw.write("<td>" + baseInfo.getCampsegName() + "</td>");
			fw.write("</tr>");
			fw.write("<tr>");
			fw.write("<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx6") + "</strong></td>");
			fw.write("<td>" + baseInfo.getCampsegNo() + "</td>");
			fw.write("</tr>");
			fw.write("<tr>");
			fw.write("<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongks") + "</strong></td>");
			fw.write("<td>" + MpmUtil.parseOutDate(baseInfo.getStartDate()) + "</td>");
			fw.write("</tr>");
			fw.write("<tr>");
			fw.write("<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongjs") + "</strong></td>");
			fw.write("<td>" + MpmUtil.parseOutDate(baseInfo.getEndDate()) + "</td>");
			fw.write("</tr>");
			fw.write("<tr>");
			fw.write("<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongch") + "</strong></td>");
			fw.write("<td>" + baseInfo.getCreateUserid() + "</td>");
			fw.write("</tr>");
			fw.write("<tr>");
			fw.write("<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx7") + "</strong></td>");
			fw.write("<td>" + baseInfo.getCampsegDesc() + "</td>");
			fw.write("</tr>");
			fw.write("<tr>");
			fw.write("<td><strong>" + MpmLocaleUtil.getMessage("mcd.java.tdstrongyx8") + "</strong></td>");
			haveAttachList = attachService.findAttachmentInfoByCampsegId(campsegId);
			fw.write("<td>");
			for (int i = 0; i < haveAttachList.size(); i++) {
				MtlAttachmentInfo itemAttach = (MtlAttachmentInfo) haveAttachList.get(i);
				fw.write(itemAttach.getAttachmentName() + "&nbsp;");
			}
			fw.write("</td>");
			fw.write("</tr>");
			fw.write("</table>                                                                ");
			fw.write("</body>                                                                 ");
			fw.write("</html>                                                                 ");
			fw.close();
			String fileUrl = MpmHtmlHelper.uploadFileOne(fileHtmlUrl, fileHtmlPath,
					MpmLocaleUtil.getMessage("mcd.java.yxhdjbxx3") + userId + "_" + campsegId + ".html", false, true);
		} catch (IOException e) {
			log.error("", e);
		} catch (Exception e1) {
			log.error("", e1);
		}
	}
*/
	/*public static String getInterfaceReturnCN(String campsegid) {
		String result = MpmLocaleUtil.getMessage("mcd.java.w");
		try {
			IMpmSendOddDataSourceSvc sendService = (IMpmSendOddDataSourceSvc) SystemServiceLocator.getInstance()
					.getService("mpmSendOddDateSourceSvc");
			IMpmUserSubsectionService service = (IMpmUserSubsectionService) SystemServiceLocator.getInstance()
					.getService("userSubsectionService");
			String channelId = String.valueOf(sendService.getUsersegChannelDef(campsegid, Short.valueOf("0"))
					.getChanneltypeId());
			MtlSubsectionResult obj = service.getResultObj(campsegid, "0");
			if (obj != null && obj.getCallStatus() != null) {
				Map map = MpmCache.getInstance().getMapByType("mpm_interface_return_code");
				result = (String) map.get((new StringBuilder(String.valueOf(channelId))).append("-")
						.append(obj.getCallStatus()).toString());
				if (result == null) {
					result = MpmLocaleUtil.getMessage("mcd.java.w");
				}

			}
		} catch (Exception e) {
			log.error("", e);
		}
		return result;
	}*/

	//add
	public static String removeComma(String str) {

		if (StringUtil.isEmpty(str)) {
			return "";
		}
		String rs = str.replaceAll("\'", "");
		rs = rs.trim();
		if (rs.indexOf(",") == 0) {
			rs = rs.substring(1);
		}
		return rs;
	}

	public static String addComma(String str) {

		if (str.indexOf("'") == -1) {
			return "'" + str.replaceAll(",", "','") + "'";
		} else {
			return str;
		}
	}

	public static String getCompanyTree(Sqlca sqlInit, String strFolderFormat, String strPageFormat, boolean bGetUser,
			boolean bGetScript, String cityids) throws Exception {
		Menu menu = new Menu(null, true, bGetScript, false);
		log.debug("===RootID=======" + menu.getRootID());
		getCompanyTreeSub(menu, sqlInit, "0", menu.getRootID(), strFolderFormat, strPageFormat, bGetUser, cityids);
		return menu.getTreeHtml();

	}

	public static String getCompanyTree(Sqlca sqlInit, String strFolderFormat, String strPageFormat, boolean bGetUser,
			boolean bGetScript) throws Exception {
		Menu menu = new Menu(null, true, bGetScript, false);
		getCompanyTreeSub(menu, sqlInit, "0", menu.getRootID(), strFolderFormat, strPageFormat, bGetUser);
		return menu.getTreeHtml();
	}

	protected static int m_nInternal = 0;

	/**
	 * Get a new ID
	 *
	 * @return The new ID.
	 */
	protected static String getNewID() {
		return "AutoID" + m_nInternal++;
	}

	/**  mads2
	 *
	 *
	 *
	 */

	public static String getCompanySubTree(Sqlca sqlInit, String ParentID, String cityids) throws Exception {
		String nos = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
		if ("true".equalsIgnoreCase(nos)) {
			return getCompanySubTreeForSuite(sqlInit, ParentID, cityids);
		} else {
			return getCompanySubTreeForWebOS(sqlInit, ParentID, cityids);
		}
	}

	private static boolean getCompanyTreeSub(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID,
			String strFolderFormat, String strPageFormat, boolean bGetUser) throws Exception {
		String nos = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
		if ("true".equalsIgnoreCase(nos)) {
			return getCompanyTreeSubForSuite(menu, sqlInit, strParentID, strTreeID, strFolderFormat, strPageFormat,
					bGetUser);
		} else {
			return getCompanyTreeSubForWebOS(menu, sqlInit, strParentID, strTreeID, strFolderFormat, strPageFormat,
					bGetUser);
		}
	}

	private static boolean getCompanyTreeSub(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID,
			String strFolderFormat, String strPageFormat, boolean bGetUser, String cityids) throws Exception {
		String nos = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
		if ("true".equalsIgnoreCase(nos)) {
			return getCompanyTreeSubForSuite(menu, sqlInit, strParentID, strTreeID, strFolderFormat, strPageFormat,
					bGetUser, cityids);
		} else {
			return getCompanyTreeSubForWebOS(menu, sqlInit, strParentID, strTreeID, strFolderFormat, strPageFormat,
					bGetUser, cityids);
		}
	}

	/**
	 * get a synchronized company and user tree
	 * @param sqlca
	 * @return json array string
	 */
	public static String getCompanyTreeAsyn(Sqlca sqlca, String strParentID) throws Exception {
		String nos = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
		if ("true".equalsIgnoreCase(nos)) {
			return getCompanyTreeAsynForSuite(sqlca, strParentID);
		} else {
			return getCompanyTreeAsynForWebOS(sqlca, strParentID);
		}
	}

	private static boolean getCompanyTreeSubForSuite(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID,
			String strFolderFormat, String strPageFormat, boolean bGetUser) throws Exception {
		String strDisplayTable = "";
		Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
		String strSql = " select DEPTID,TITLE from user_company where STATUS=? and ParentID = ? order by sortnum,TITLE";
		sqlca1.execute(strSql, new String[] { SysManageConstants.STATUS_NORMAL, removeComma(strParentID) });
		int nCount = 0;
		List resList = new ArrayList();
		while (sqlca1.next()) {
			int intID = sqlca1.getInt("DEPTID");
			String strTopic = sqlca1.getString("TITLE");
			resList.add(intID + "_" + strTopic);
		}

		for (int i = 0; i < resList.size(); i++) {
			String strContent = (String) resList.get(i);
			int nPosFirst = strContent.indexOf("_");
			String intID = strContent.substring(0, nPosFirst);
			String strTopic = strContent.substring(nPosFirst + 1);

			strSql = "select deptid from user_company where STATUS=? and parentid = ? order by sortnum,title";
			sqlca1.execute(strSql, new String[] { SysManageConstants.STATUS_NORMAL, intID });
			boolean bHaveSub = sqlca1.next();
			String strMyID = getNewID();
			if (bHaveSub || bGetUser) {
				if (getCompanyTreeSub(menu, sqlInit, "" + intID, strMyID, strFolderFormat, strPageFormat, bGetUser)) {
					nCount++;
					menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, "" + intID), "", "", "", "", "");
				}
			} else {
				nCount++;
				menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, "" + intID), "", "", "", "", "");
			}
		}
		if (bGetUser) {
			strSql = " select UserID,username from user_user where departmentid = ?";
			sqlca1.execute(strSql, new String[] { strParentID });
			while (sqlca1.next()) {
				String strID = sqlca1.getString("UserID");
				String strTopic = sqlca1.getString("username");
				nCount++;
				String strMyID = getNewID();
				menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, strID), "", "", "", "", "");
			}
		}
		sqlca1.close();
		return true;
	}

	private static boolean getCompanyTreeSubForSuite(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID,
			String strFolderFormat, String strPageFormat, boolean bGetUser, String cityids) throws Exception {
		Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
		Sqlca sqlca2 = new Sqlca(sqlInit.getConnection());
		Sqlca sqlca3 = new Sqlca(sqlInit.getConnection());
		String strSql = (new StringBuilder(" select DEPTID,TITLE from user_company where ParentID = ?")).append(
				" order by sortnum,title").toString();
		sqlca1.execute(strSql, new String[] { removeComma(strParentID) });
		int nCount = 0;
		String sqlin = "";
		String roles = "";
		if (cityids != null) {
			String strRolesArry[] = cityids.split(",");
			int cnt = 1;
			if (strRolesArry.length > 1000) {
				for (int i = 0; i < strRolesArry.length; i++) {
					roles = (new StringBuilder(String.valueOf(roles))).append(strRolesArry[i]).append(",").toString();
					if (++cnt > 1000) {
						sqlin = (new StringBuilder(String.valueOf(sqlin))).append(" and cityid in (")
								.append(roles.substring(0, roles.lastIndexOf(","))).append(") ").toString();
						roles = "";
						cnt = 1;
					}
				}

			} else {
				sqlin = (new StringBuilder(" and cityid in (")).append(cityids).append(") ").toString();
			}
		}
		while (sqlca1.next()) {
			int intID = sqlca1.getInt("DEPTID");
			String strTopic = sqlca1.getString("TITLE");
			strSql = "select deptid from user_company where parentid = ? order by sortnum,title";
			sqlca2.execute(strSql, new Integer[] { intID });
			boolean bHaveSub = sqlca2.next();
			if (!bHaveSub) {
				if (cityids == null) {
					//sqlca3.execute((new StringBuilder(" select UserID,username from user_user where departmentid = ")).append(intID).toString());
					sqlca3.execute(" select UserID,username from user_user where departmentid = ?",
							new Integer[] { intID });
				} else {
					sqlca3.execute(
							(new StringBuilder(" select UserID,username from user_user where 1=1 ")).append(sqlin)
									.append(" and departmentid = ?").toString(), new Integer[] { intID });
				}
				if (!sqlca3.next()) {
					continue;
				}
			}
			String strMyID = getNewID();
			if (bHaveSub || bGetUser) {
				if (getCompanyTreeSub(menu, sqlInit, String.valueOf(intID), strMyID, strFolderFormat, strPageFormat,
						bGetUser, cityids)) {
					nCount++;
					menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, String.valueOf(intID)), "", "",
							"", "", "");
				}
			} else {
				nCount++;
				menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, String.valueOf(intID)), "", "", "",
						"", "");
			}
		}
		if (bGetUser) {
			String[] param = null;
			if (cityids == null) {
				strSql = " select UserID,username from user_user where departmentid =? ";
				param = new String[] { strParentID };
			} else {
				strSql = (new StringBuilder(" select UserID,username from user_user where 1=1 ")).append(sqlin)
						.append(" and departmentid = ?").toString();
				param = new String[] { strParentID };
			}

			sqlca1.execute(strSql, param);
			String strID;
			String strTopic;
			String strMyID;
			for (; sqlca1.next(); menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, strID), "", "", "",
					"", "")) {
				strID = sqlca1.getString("UserID");
				strTopic = sqlca1.getString("username");
				nCount++;
				strMyID = getNewID();
			}

		}
		sqlca1.close();
		sqlca2.close();
		sqlca3.close();
		return true;
	}

	public static String getCompanySubTreeForWebOS(Sqlca sqlInit, String ParentID, String cityids) throws Exception {
		String returnInfo = "[";
		if (ParentID.equals("root")) {
			ParentID = "0";
		}
		Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
		Sqlca sqlca2 = new Sqlca(sqlInit.getConnection());
		String[] params = null;
		String strSql = " SELECT DEP_ID,DEP_NAME FROM (SELECT DISTINCT DEP_ID,DEP_NAME,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
		params = new String[] { removeComma(ParentID) };
		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
			strSql = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE STATUS=? AND PARENTID = ? ORDER BY SORTNUM,TITLE";
			params = new String[] { SysManageConstants.STATUS_NORMAL, removeComma(ParentID) };
		}
		sqlca1.execute(strSql, params);
		if (null != sqlca1 || sqlca1.equals("")) {
			while (sqlca1.next()) {
				returnInfo += "{id: '" + sqlca1.getInt("DEP_ID") + "',text: '" + sqlca1.getString("DEP_NAME")
						+ "',leaf: false},";
			}
		}
		String[] params2 = null;
		String strSq2 = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE DEP_ID = ? ORDER BY STAFF_NAME";
		params2 = new String[] { removeComma(ParentID) };
		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
			strSq2 = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE MCD_DEP_ID = ? ORDER BY STAFF_NAME";
			params2 = new String[] { removeComma(ParentID) };
		}
		sqlca2.execute(strSq2, params2);
		if (null != sqlca2 || sqlca2.equals("")) {
			while (sqlca2.next()) {
				returnInfo += "{id: '" + sqlca2.getString("STAFF_ID") + "',text: '" + sqlca2.getString("STAFF_NAME")
						+ "',leaf: true},";
			}
		}
		sqlca1.close();
		sqlca2.close();
		if (returnInfo.length() > 1) {
			returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
		}
		returnInfo += "]";
		log.debug(returnInfo);
		return returnInfo;
	}

	private static boolean getCompanyTreeSubForWebOS(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID,
			String strFolderFormat, String strPageFormat, boolean bGetUser) throws Exception {
		String strDisplayTable = "";
		Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
		String[] params = null;
		String strSql = " SELECT DEP_ID,DEP_NAME FROM  (SELECT DISTINCT DEP_ID,DEP_NAME,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
		params = new String[] { removeComma(strParentID) };
		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
			strSql = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE STATUS=? AND PARENTID = ? ORDER BY SORTNUM,TITLE";
			params = new String[] { SysManageConstants.STATUS_NORMAL, removeComma(strParentID) };
		}
		sqlca1.execute(strSql, params);
		int nCount = 0;

		List resList = new ArrayList();

		while (sqlca1.next()) {
			int intID;
			if ("shaanxi".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
				intID = Integer.parseInt(sqlca1.getString("DEP_ID"));
			} else {
				intID = sqlca1.getInt("DEP_ID");
			}
			String strTopic = sqlca1.getString("DEP_NAME");
			resList.add(intID + "_" + strTopic);
		}

		for (int i = 0; i < resList.size(); i++) {
			String strContent = (String) resList.get(i);
			int nPosFirst = strContent.indexOf("_");
			String intID = strContent.substring(0, nPosFirst);
			String strTopic = strContent.substring(nPosFirst + 1);
			String[] param1 = null;
			strSql = "SELECT DEP_ID FROM  (SELECT DISTINCT DEP_ID,DEP_NAME,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
			param1 = new String[] { intID };
			if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
				strSql = "SELECT DEPTID as DEP_ID FROM LKG_STAFF_COMPANY WHERE STATUS=? AND PARENTID = ? ORDER BY SORTNUM,TITLE";
				param1 = new String[] { SysManageConstants.STATUS_NORMAL, intID };
			}
			sqlca1.execute(strSql, param1);
			boolean bHaveSub = sqlca1.next();
			String strMyID = getNewID();
			if (bHaveSub || bGetUser) {
				if (getCompanyTreeSub(menu, sqlInit, "" + intID, strMyID, strFolderFormat, strPageFormat, bGetUser)) {
					nCount++;
					menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, "" + intID), "", "", "", "", "");
				}
			} else {
				nCount++;
				menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, "" + intID), "", "", "", "", "");
			}
		}
		if (bGetUser) {
			strSql = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE DEP_ID = ?";
			if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
				strSql = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE MCD_DEP_ID =?";
			}
			sqlca1.execute(strSql, new String[] { strParentID });
			while (sqlca1.next()) {
				String strID = sqlca1.getString("STAFF_ID");
				String strTopic = sqlca1.getString("STAFF_NAME");
				nCount++;
				String strMyID = getNewID();
				menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, strID), "", "", "", "", "");
			}
		}
		sqlca1.close();
		return true;
	}

	private static boolean getCompanyTreeSubForWebOS(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID,
			String strFolderFormat, String strPageFormat, boolean bGetUser, String cityids) throws Exception {
		Sqlca sqlca1 = new Sqlca(new ConnectionEx());
		Sqlca sqlca2 = new Sqlca(new ConnectionEx());
		Sqlca sqlca3 = new Sqlca(new ConnectionEx());
		String strSql = (new StringBuilder(
				" SELECT DEP_ID,DEP_NAME FROM (SELECT DISTINCT DEP_ID,DEP_NAME,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ?"))
				.append(" ORDER BY DEP_ORDER").toString();
		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
			strSql = (new StringBuilder(
					" SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE PARENTID = ?")).append(
					" ORDER BY SORTNUM,TITLE").toString();
		}
		sqlca1.execute(strSql, new String[] { removeComma(strParentID) });
		int nCount = 0;
		String sqlin = "";
		String roles = "";
		if (cityids != null) {
			String strRolesArry[] = cityids.split(",");
			int cnt = 1;
			if (strRolesArry.length > 1000) {
				for (int i = 0; i < strRolesArry.length; i++) {
					roles = (new StringBuilder(String.valueOf(roles))).append(strRolesArry[i]).append(",").toString();
					if (++cnt > 1000) {
						sqlin = (new StringBuilder(String.valueOf(sqlin))).append(" AND CITY_ID IN (")
								.append(roles.substring(0, roles.lastIndexOf(","))).append(") ").toString();
						roles = "";
						cnt = 1;
					}
				}

			} else {
				sqlin = (new StringBuilder(" AND CITY_ID IN (")).append(cityids).append(") ").toString();
			}
		}
		while (sqlca1.next()) {
			int intID;
			if ("shaanxi".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
				intID = Integer.parseInt(sqlca1.getString("DEP_ID"));
			} else {
				intID = sqlca1.getInt("DEP_ID");
			}
			String strTopic = sqlca1.getString("DEP_NAME");
			strSql = (new StringBuilder(
					"SELECT DEP_ID FROM (SELECT DISTINCT DEP_ID,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ?"))
					.append(" ORDER BY DEP_ORDER").toString();
			if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
				strSql = (new StringBuilder("SELECT DEPTID as DEP_ID FROM LKG_STAFF_COMPANY WHERE PARENTID = ?"))
						.append(" ORDER BY SORTNUM,TITLE").toString();
			}
			sqlca2.execute(strSql, new Integer[] { intID });
			boolean bHaveSub = sqlca2.next();
			if (!bHaveSub) {
				StringBuilder sql1 = new StringBuilder(" SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF  WHERE 1=1 ");
				if (StringUtil.isNotEmpty(cityids)) {
					sql1.append(sqlin);
				}
				if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
					sql1.append(" AND MCD_DEP_ID = ?");
				} else {
					sql1.append(" AND DEP_ID = ?");
				}
				sqlca3.execute(sql1.toString(), new Integer[] { intID });
				if (!sqlca3.next()) {
					continue;
				}
			}
			String strMyID = getNewID();
			if (bHaveSub || bGetUser) {
				if (getCompanyTreeSub(menu, sqlInit, String.valueOf(intID), strMyID, strFolderFormat, strPageFormat,
						bGetUser, cityids)) {
					nCount++;
					menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, String.valueOf(intID)), "", "",
							"", "", "");
				}
			} else {
				nCount++;
				menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, String.valueOf(intID)), "", "", "",
						"", "");
			}
		}
		if (bGetUser) {
			StringBuilder sql1 = new StringBuilder(" SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF  WHERE 1=1 ");
			if (StringUtil.isNotEmpty(cityids)) {
				sql1.append(sqlin);
			}
			if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
				sql1.append(" AND MCD_DEP_ID = ?");
			} else {
				sql1.append(" AND DEP_ID = ?");
			}
			sqlca1.execute(sql1.toString(), new String[] { strParentID });
			String strID;
			String strTopic;
			String strMyID;
			for (; sqlca1.next(); menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, strID), "", "", "",
					"", "")) {
				strID = sqlca1.getString("STAFF_ID");
				strTopic = sqlca1.getString("STAFF_NAME");
				nCount++;
				strMyID = getNewID();
			}

		}
		sqlca1.closeAll();
		sqlca2.closeAll();
		sqlca3.closeAll();
		return true;
	}
	
	/**
	 * modified by zhuyq3 2015-5-28 16:03:04
	 * @param sqlca
	 * @param strParentID
	 * @return
	 * @throws Exception
	 */
	public static String getCompanyTreeAsynForWebOS(Sqlca sqlca, String strParentID) throws Exception {
		Sqlca sqlca1 = new Sqlca(sqlca.getConnection());
		Sqlca sqlca2 = new Sqlca(sqlca.getConnection());
		Sqlca sqlca3 = new Sqlca(sqlca.getConnection());
		String strSql1 = "SELECT DEP_ID FROM (SELECT DISTINCT DEP_ID,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
			strSql1 = "SELECT DEPTID as DEP_ID FROM LKG_STAFF_COMPANY WHERE PARENTID = ? ORDER BY SORTNUM,TITLE";
		}
		String strSql2 = " SELECT DEP_ID,DEP_NAME,PARENT_DEP_ID FROM (SELECT DISTINCT DEP_ID,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
			strSql2 = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE PARENTID = ? ORDER BY SORTNUM,TITLE";
		}
		String strSql3 = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE DEP_ID = ?";
		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
			strSql3 = " SELECT STAFF_ID,STAFF_NAME,MCD_DEP_ID FROM LKG_STAFF WHERE MCD_DEP_ID =? ";
		}

		String returnInfo = "[";

		sqlca1.execute(strSql1, new String[] { removeComma(strParentID) });
		boolean bHaveSub = sqlca1.next();
		if (bHaveSub) {
			sqlca2.execute(strSql2, new String[] { removeComma(strParentID) });
			while (sqlca2.next()) {
				int deptID = sqlca2.getInt("DEP_ID");
				String title = sqlca2.getString("DEP_NAME");
				String parentId = sqlca2.getString("PARENT_DEP_ID");
				returnInfo += "{id: '" + deptID + "',pId: '" + parentId + "',name: '" + title + "',isParent: true},";
			}
		} else {
			sqlca3.execute(strSql3, new String[] { removeComma(strParentID) });
			while (sqlca3.next()) {
				String userId = sqlca3.getString("STAFF_ID");
				String username = sqlca3.getString("STAFF_NAME");
				String parentId = sqlca3.getString("MCD_DEP_ID");
				returnInfo += "{id: '" + userId + "',pId: '" + parentId + "', name: '" + username + "',isParent: false},";
			}
		}

		if (returnInfo.length() > 1) {
			returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
		}
		returnInfo += "]";

		sqlca1.close();
		sqlca2.close();
		sqlca3.close();
		return returnInfo;
	}

	/**
	 * get a synchronized company and user tree
	 * @param sqlca
	 * @return json array string
	 */
//	public static String getCompanyTreeAsynForWebOS(Sqlca sqlca, String strParentID) throws Exception {
//		Sqlca sqlca1 = new Sqlca(sqlca.getConnection());
//		Sqlca sqlca2 = new Sqlca(sqlca.getConnection());
//		Sqlca sqlca3 = new Sqlca(sqlca.getConnection());
//		String strSql1 = "SELECT DEP_ID FROM (SELECT DISTINCT DEP_ID,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
//		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
//			strSql1 = "SELECT DEPTID as DEP_ID FROM LKG_STAFF_COMPANY WHERE PARENTID = ? ORDER BY SORTNUM,TITLE";
//		}
//		String strSql2 = " SELECT DEP_ID,DEP_NAME FROM (SELECT DISTINCT DEP_ID,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
//		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
//			strSql2 = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE PARENTID = ? ORDER BY SORTNUM,TITLE";
//		}
//		String strSql3 = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE DEP_ID = ?";
//		if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
//			strSql3 = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE MCD_DEP_ID =? ";
//		}
//
//		String returnInfo = "[";
//
//		sqlca1.execute(strSql1, new String[] { removeComma(strParentID) });
//		boolean bHaveSub = sqlca1.next();
//		if (bHaveSub) {
//			sqlca2.execute(strSql2, new String[] { removeComma(strParentID) });
//			while (sqlca2.next()) {
//				int deptID = sqlca2.getInt("DEP_ID");
//				String title = sqlca2.getString("DEP_NAME");
//				returnInfo += "{id: '" + deptID + "',text: '" + title + "',cls: 'folder',leaf: false},";
//			}
//		} else {
//			sqlca3.execute(strSql3, new String[] { removeComma(strParentID) });
//			while (sqlca3.next()) {
//				String userId = sqlca3.getString("STAFF_ID");
//				String username = sqlca3.getString("STAFF_NAME");
//				returnInfo += "{id: '" + userId + "',text: '" + username + "',cls: 'file',leaf: true},";
//			}
//		}
//
//		if (returnInfo.length() > 1) {
//			returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
//		}
//		returnInfo += "]";
//
//		sqlca1.close();
//		sqlca2.close();
//		sqlca3.close();
//		return returnInfo;
//	}

	/**
	 * Format a string ,replace specified resourceID with it's name and href.
	 *
	 * @param strFormat
	 *            string to be formated
	 * @param strTitle
	 *            The title
	 * @param strResID
	 *            The resourceID
	 * @return The string formated.
	 */
	public static String format(String strFormat, String strTitle, String strResID) {
		if (null == strFormat || strFormat.trim().length() < 3) {
			return strTitle;
		}
		String strBak = strFormat.toUpperCase();
		int n = strBak.indexOf("[S]");
		while (n >= 0) {
			strFormat = strFormat.substring(0, n) + strTitle + strFormat.substring(n + "[S]".length());
			strBak = strFormat.toUpperCase();
			n = strBak.indexOf("[S]", n + 1);
		}
		n = strBak.indexOf("[ID]");
		while (n >= 0) {
			strTitle = strFormat.substring(0, n) + strResID + strFormat.substring(n + "[ID]".length());
			strBak = strFormat.toUpperCase();
			n = strBak.indexOf("[ID]", n + 1);
		}
		return strTitle;
	}

	public static void main(String[] args) {

	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static String getCompanySubTreeForSuite(Sqlca sqlInit, String ParentID, String cityids) throws Exception {
		String returnInfo = "[";
		if (ParentID.equals("root")) {
			ParentID = "0";
		}
		Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
		Sqlca sqlca2 = new Sqlca(sqlInit.getConnection());
		//String strSql = "select DEPTID,TITLE from user_company where STATUS=? and ParentID = ? order by sortnum,TITLE";
		String strSql = "select t.deptid,t.title from user_company t where t.status=? and t.parentid=? order by t.sortnum,t.title";
		sqlca1.execute(strSql, new Object[] { SysManageConstants.STATUS_NORMAL, removeComma(ParentID) });
		if (null != sqlca1 || sqlca1.equals("")) {
			while (sqlca1.next()) {
				returnInfo += "{id: '" + sqlca1.getInt("DEPTID") + "',text: '" + sqlca1.getString("TITLE")
						+ "',leaf: false},";
			}
		}
		//String strSq2 = "select USERID,USERNAME from user_user where  DEPARTMENTID = ? order by USERNAME";
		String strSq2 = "select u.userid,u.username from user_user u where u.departmentid=? order by u.username";
		sqlca2.execute(strSq2, new String[] { removeComma(ParentID) });
		if (null != sqlca2 || sqlca2.equals("")) {
			while (sqlca2.next()) {
				returnInfo += "{id: '" + sqlca2.getString("USERID") + "',text: '" + sqlca2.getString("USERNAME")
						+ "',leaf: true},";
			}
		}
		sqlca1.close();
		sqlca2.close();
		if (returnInfo.length() > 1) {
			returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
		}
		returnInfo += "]";
		log.debug(returnInfo);
		return returnInfo;
	}

	/**
	 * modified by zhuyq3 2015-5-28 11:38:57
	 * @param sqlca
	 * @param strParentID
	 * @return
	 * @throws Exception
	 */
	public static String getCompanyTreeAsynForSuite(Sqlca sqlca, String strParentID) throws Exception {
		Sqlca sqlca1 = new Sqlca(sqlca.getConnection());
		Sqlca sqlca2 = new Sqlca(sqlca.getConnection());
		Sqlca sqlca3 = new Sqlca(sqlca.getConnection());
		String strSql1 = new StringBuilder("select deptid from user_company where parentid = ? order by sortnum,title")
				.toString();
		String strSql2 = new StringBuilder(
				" select DEPTID,TITLE, ParentID from user_company where ParentID = ? order by sortnum,title").toString();
		String strSql3 = new StringBuilder(" select UserID,username,departmentid from user_user where departmentid = ?").toString();

		String returnInfo = "[";

		sqlca1.execute(strSql1, new String[] { removeComma(strParentID) });
		boolean bHaveSub = sqlca1.next();
		if (bHaveSub) {
			sqlca2.execute(strSql2, new String[] { removeComma(strParentID) });
			while (sqlca2.next()) {
				int deptID = sqlca2.getInt("DEPTID");
				String title = sqlca2.getString("TITLE");
				String pId = sqlca2.getString("ParentID");
				returnInfo += "{id: '" + deptID + "', pId : '" + pId + "', name: '" + title + "',isParent: true},";
			}
		} else {
			sqlca3.execute(strSql3, new String[] { removeComma(strParentID) });
			while (sqlca3.next()) {
				String userId = sqlca3.getString("UserID");
				String username = sqlca3.getString("username");
				String pId = sqlca3.getString("departmentid");
				returnInfo += "{id: '" + userId + "', pId : '" + pId + "', name: '" + username + "',isParent: false},";
			}
		}

		if (returnInfo.length() > 1) {
			returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
		}
		returnInfo += "]";

		sqlca1.close();
		sqlca2.close();
		sqlca3.close();
		return returnInfo;
	}
	
	/**
	 * get a synchronized company and user tree
	 * @param sqlca
	 * @return json array string
	 */
//	public static String getCompanyTreeAsynForSuite(Sqlca sqlca, String strParentID) throws Exception {
//		Sqlca sqlca1 = new Sqlca(sqlca.getConnection());
//		Sqlca sqlca2 = new Sqlca(sqlca.getConnection());
//		Sqlca sqlca3 = new Sqlca(sqlca.getConnection());
//		String strSql1 = new StringBuilder("select deptid from user_company where parentid = ? order by sortnum,title")
//				.toString();
//		String strSql2 = new StringBuilder(
//				" select DEPTID,TITLE from user_company where ParentID = ? order by sortnum,title").toString();
//		String strSql3 = new StringBuilder(" select UserID,username from user_user where departmentid = ?").toString();
//
//		String returnInfo = "[";
//
//		sqlca1.execute(strSql1, new String[] { removeComma(strParentID) });
//		boolean bHaveSub = sqlca1.next();
//		if (bHaveSub) {
//			sqlca2.execute(strSql2, new String[] { removeComma(strParentID) });
//			while (sqlca2.next()) {
//				int deptID = sqlca2.getInt("DEPTID");
//				String title = sqlca2.getString("TITLE");
//				returnInfo += "{id: '" + deptID + "',text: '" + title + "',cls: 'folder',leaf: false},";
//			}
//		} else {
//			sqlca3.execute(strSql3, new String[] { removeComma(strParentID) });
//			while (sqlca3.next()) {
//				String userId = sqlca3.getString("UserID");
//				String username = sqlca3.getString("username");
//				returnInfo += "{id: '" + userId + "',text: '" + username + "',cls: 'file',leaf: true},";
//			}
//		}
//
//		if (returnInfo.length() > 1) {
//			returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
//		}
//		returnInfo += "]";
//
//		sqlca1.close();
//		sqlca2.close();
//		sqlca3.close();
//		return returnInfo;
//	}
}

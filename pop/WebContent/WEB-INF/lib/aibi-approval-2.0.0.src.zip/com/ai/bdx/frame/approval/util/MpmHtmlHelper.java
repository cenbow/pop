/*      */ package com.ai.bdx.frame.approval.util;
/*      */ 
/*      */ import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumn;
/*      */ import com.ai.bdx.frame.approval.model.MtlCampDatasrcColumnId;
/*      */ import com.ai.bdx.frame.approval.model.MtlCostList;
/*      */ import com.ai.bdx.frame.approval.model.MtlTempletActiveField;
/*      */ import com.ai.bdx.frame.approval.model.MtlTempletActiveFieldId;
/*      */ import com.ai.bdx.frame.approval.service.IMpmResListSvc;
/*      */ import com.ai.bdx.frame.approval.service.IMtlApproveFlowDefService;
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.net.URLEncoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.logging.log4j.LogManager;
/*      */ import org.apache.logging.log4j.Logger;
/*      */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*      */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*      */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*      */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*      */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*      */ 
/*      */ public class MpmHtmlHelper
/*      */ {
/*   45 */   private static Logger log = LogManager.getLogger();
/*      */ 
/* 3080 */   protected static int m_nInternal = 0;
/*      */ 
/*      */   public static String getMpmStoreFilePath()
/*      */   {
/*   53 */     String mpmPath = Configure.getInstance().getProperty("SYS_COMMON_UPLOAD_PATH");
/*   54 */     if (!mpmPath.endsWith(File.separator)) {
/*   55 */       mpmPath = new StringBuilder().append(mpmPath).append(File.separator).toString();
/*      */     }
/*   57 */     mpmPath = new StringBuilder().append(mpmPath).append("mpm").toString();
/*   58 */     File pathFile = new File(mpmPath);
/*   59 */     if (!pathFile.exists()) {
/*   60 */       pathFile.mkdirs();
/*      */     }
/*   62 */     return mpmPath;
/*      */   }
/*      */ 
/*      */   private static String[] subCompanyUpload(String fileUrl)
/*      */   {
/*  393 */     HSSFWorkbook wbread = null;
/*  394 */     HSSFSheet rSheet = null;
/*  395 */     HSSFRow rRow = null;
/*  396 */     POIFSFileSystem fsInr = null;
/*  397 */     FileInputStream fisr = null;
/*  398 */     boolean flag = false;
/*  399 */     String errStr = "";
/*      */     try {
/*  401 */       fisr = new FileInputStream(fileUrl);
/*  402 */       if (fisr == null) {
/*  403 */         log.debug(new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.gjwj")).append(fileUrl).append(MpmLocaleUtil.getMessage("mcd.java.hqFileInpu")).toString());
/*      */ 
/*  405 */         return null;
/*      */       }
/*  407 */       fsInr = new POIFSFileSystem(fisr);
/*  408 */       if (fsInr == null) {
/*  409 */         log.debug(new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.gjwj")).append(fileUrl).append(MpmLocaleUtil.getMessage("mcd.java.hqPOIFSFil")).toString());
/*      */ 
/*  411 */         return null;
/*      */       }
/*  413 */       wbread = new HSSFWorkbook(fsInr);
/*  414 */       fisr.close();
/*  415 */       rSheet = wbread.getSheetAt(0);
/*  416 */       for (int a = 2; a >= 2; a++) {
/*  417 */         rRow = rSheet.getRow(a);
/*  418 */         if ((rRow == null) && (a == 2)) {
/*  419 */           deleteFile(fileUrl);
/*  420 */           flag = true;
/*  421 */           errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj1");
/*  422 */           break;
/*      */         }
/*  424 */         if (rRow == null)
/*      */         {
/*      */           break;
/*      */         }
/*  428 */         if ((rRow.getCell((short)2) == null) && (a == 2)) {
/*  429 */           deleteFile(fileUrl);
/*  430 */           flag = true;
/*  431 */           errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj1");
/*  432 */           break;
/*      */         }
/*      */ 
/*  435 */         if (rRow.getCell((short)2) == null) {
/*      */           break;
/*      */         }
/*      */         try
/*      */         {
/*  440 */           if (rRow.getCell((short)0) != null)
/*  441 */             rRow.getCell((short)0).getStringCellValue();
/*      */         }
/*      */         catch (Exception e) {
/*  444 */           deleteFile(fileUrl);
/*  445 */           flag = true;
/*  446 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj2")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwzfx")).toString();
/*      */ 
/*  448 */           break;
/*      */         }
/*      */         try
/*      */         {
/*  452 */           if (rRow.getCell((short)1) != null)
/*  453 */             rRow.getCell((short)1).getStringCellValue();
/*      */         }
/*      */         catch (Exception e) {
/*  456 */           deleteFile(fileUrl);
/*  457 */           flag = true;
/*  458 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj3")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwzfx")).toString();
/*      */ 
/*  460 */           break;
/*      */         }
/*      */         try {
/*  463 */           if (((rRow.getCell((short)2).getStringCellValue() == null) || (rRow.getCell((short)2).getStringCellValue().trim().length() <= 0)) && (a == 2))
/*      */           {
/*  466 */             deleteFile(fileUrl);
/*  467 */             flag = true;
/*  468 */             errStr = MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj1");
/*  469 */             break;
/*      */           }
/*  471 */           if ((rRow.getCell((short)2).getStringCellValue() == null) || (rRow.getCell((short)2).getStringCellValue().trim().length() <= 0))
/*      */           {
/*  473 */             break;
/*      */           }
/*      */         } catch (Exception e) {
/*  476 */           deleteFile(fileUrl);
/*  477 */           flag = true;
/*  478 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj4")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwzfx")).toString();
/*      */ 
/*  480 */           break;
/*      */         }
/*      */         try
/*      */         {
/*  484 */           rRow.getCell((short)3).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  486 */           deleteFile(fileUrl);
/*  487 */           flag = true;
/*  488 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj5")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  490 */           break;
/*      */         }
/*      */         try {
/*  493 */           rRow.getCell((short)4).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  495 */           deleteFile(fileUrl);
/*  496 */           flag = true;
/*  497 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj6")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  499 */           break;
/*      */         }
/*      */         try {
/*  502 */           rRow.getCell((short)5).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  504 */           deleteFile(fileUrl);
/*  505 */           flag = true;
/*  506 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj7")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  508 */           break;
/*      */         }
/*      */         try {
/*  511 */           rRow.getCell((short)6).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  513 */           deleteFile(fileUrl);
/*  514 */           flag = true;
/*  515 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj8")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  517 */           break;
/*      */         }
/*      */         try {
/*  520 */           rRow.getCell((short)7).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  522 */           deleteFile(fileUrl);
/*  523 */           flag = true;
/*  524 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj9")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  526 */           break;
/*      */         }
/*      */         try {
/*  529 */           rRow.getCell((short)8).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  531 */           deleteFile(fileUrl);
/*  532 */           flag = true;
/*  533 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj10")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  535 */           break;
/*      */         }
/*      */         try {
/*  538 */           rRow.getCell((short)9).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  540 */           deleteFile(fileUrl);
/*  541 */           flag = true;
/*  542 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj11")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  544 */           break;
/*      */         }
/*      */         try {
/*  547 */           rRow.getCell((short)10).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  549 */           deleteFile(fileUrl);
/*  550 */           flag = true;
/*  551 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj12")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  553 */           break;
/*      */         }
/*      */         try {
/*  556 */           rRow.getCell((short)11).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  558 */           deleteFile(fileUrl);
/*  559 */           flag = true;
/*  560 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj13")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  562 */           break;
/*      */         }
/*      */         try {
/*  565 */           rRow.getCell((short)12).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  567 */           deleteFile(fileUrl);
/*  568 */           flag = true;
/*  569 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj14")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  571 */           break;
/*      */         }
/*      */         try {
/*  574 */           rRow.getCell((short)13).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  576 */           deleteFile(fileUrl);
/*  577 */           flag = true;
/*  578 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj15")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  580 */           break;
/*      */         }
/*      */         try {
/*  583 */           rRow.getCell((short)14).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  585 */           deleteFile(fileUrl);
/*  586 */           flag = true;
/*  587 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj16")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  589 */           break;
/*      */         }
/*      */         try {
/*  592 */           rRow.getCell((short)15).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  594 */           deleteFile(fileUrl);
/*  595 */           flag = true;
/*  596 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj17")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  598 */           break;
/*      */         }
/*      */         try {
/*  601 */           rRow.getCell((short)16).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  603 */           deleteFile(fileUrl);
/*  604 */           flag = true;
/*  605 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj18")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  607 */           break;
/*      */         }
/*      */         try {
/*  610 */           rRow.getCell((short)17).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  612 */           deleteFile(fileUrl);
/*  613 */           flag = true;
/*  614 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj19")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  616 */           break;
/*      */         }
/*      */         try {
/*  619 */           rRow.getCell((short)18).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  621 */           deleteFile(fileUrl);
/*  622 */           flag = true;
/*  623 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj20")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  625 */           break;
/*      */         }
/*      */         try {
/*  628 */           rRow.getCell((short)19).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  630 */           deleteFile(fileUrl);
/*  631 */           flag = true;
/*  632 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj21")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  634 */           break;
/*      */         }
/*      */         try {
/*  637 */           rRow.getCell((short)20).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  639 */           deleteFile(fileUrl);
/*  640 */           flag = true;
/*  641 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj22")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  643 */           break;
/*      */         }
/*      */         try {
/*  646 */           rRow.getCell((short)21).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  648 */           deleteFile(fileUrl);
/*  649 */           flag = true;
/*  650 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj23")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  652 */           break;
/*      */         }
/*      */         try {
/*  655 */           rRow.getCell((short)22).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  657 */           deleteFile(fileUrl);
/*  658 */           flag = true;
/*  659 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj24")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  661 */           break;
/*      */         }
/*      */         try {
/*  664 */           rRow.getCell((short)23).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  666 */           deleteFile(fileUrl);
/*  667 */           flag = true;
/*  668 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj25")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  670 */           break;
/*      */         }
/*      */         try {
/*  673 */           rRow.getCell((short)24).getNumericCellValue();
/*      */         } catch (Exception e) {
/*  675 */           deleteFile(fileUrl);
/*  676 */           flag = true;
/*  677 */           errStr = new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.scsbjtxxwj26")).append(a + 1).append(MpmLocaleUtil.getMessage("mcd.java.sjbwszx")).toString();
/*      */ 
/*  679 */           break;
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  683 */       log.error("", e);
/*      */     }
/*      */ 
/*  686 */     String[] result = new String[2];
/*  687 */     result[0] = (flag ? "true" : "false");
/*  688 */     result[1] = errStr;
/*      */ 
/*  690 */     return result;
/*      */   }
/*      */ 
/*      */   public static String deleteFile(String fileName)
/*      */   {
/*  774 */     String remsg = "";
/*      */     try {
/*  776 */       File delFile = new File(fileName);
/*  777 */       if (delFile.exists()) {
/*  778 */         delFile.delete();
/*      */       }
/*      */ 
/*  781 */       remsg = MpmLocaleUtil.getMessage("mcd.java.wjsccg");
/*      */     }
/*      */     catch (Exception e) {
/*  784 */       log.error("", e);
/*  785 */       remsg = MpmLocaleUtil.getMessage("mcd.java.wjscsb");
/*      */     }
/*  787 */     return remsg;
/*      */   }
/*      */ 
/*      */   public static String genBaseTableColumnTypeAndColumnLinkHtml(Set columnList)
/*      */     throws Exception
/*      */   {
/*  795 */     StringBuffer sb = new StringBuffer();
/*  796 */     sb.append("var baseColumnCount=0;\n").append("var subBaseColumn = new Array();\n");
/*  797 */     if (columnList == null) {
/*  798 */       return sb.toString();
/*      */     }
/*  800 */     Iterator it = columnList.iterator();
/*      */ 
/*  802 */     int index = 0;
/*      */ 
/*  805 */     while (it.hasNext()) {
/*  806 */       MtlCampDatasrcColumn column = (MtlCampDatasrcColumn)it.next();
/*      */ 
/*  808 */       if ((column.getColumnStatus() == null) || (column.getColumnStatus().shortValue() != 2))
/*      */       {
/*  811 */         String desc = column.getColumnCname();
/*  812 */         String columnKey = new StringBuilder().append(column.getId().getColumnName()).append("|").append(column.getId().getSourceName()).append("|").append(column.getId().getColumnType()).append("|").append(column.getColumnFlag()).append("|").append(desc == null ? "" : desc).toString();
/*      */ 
/*  815 */         sb.append(new StringBuilder().append("subBaseColumn[").append(index).append("] = new Array(\"").append(desc).append("\",\"").append(column.getColumnClass()).append("\",\"").append(columnKey).append("\");\n").toString());
/*      */ 
/*  817 */         index++;
/*      */       }
/*      */     }
/*  819 */     sb.append(new StringBuilder().append("baseColumnCount=").append(index++).append(";\n").toString());
/*  820 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String addColumnTypeToBaseTable(String baseHtml)
/*      */     throws Exception
/*      */   {
/*  827 */     StringBuffer sb = new StringBuffer(baseHtml);
/*      */     try {
/*  829 */       int markup1 = baseHtml.lastIndexOf("=");
/*  830 */       int markup2 = baseHtml.lastIndexOf(";");
/*  831 */       String baseCount = baseHtml.substring(markup1 + 1, markup2);
/*  832 */       int index = Integer.parseInt(baseCount.trim());
/*  833 */       sb.append(new StringBuilder().append("subBaseColumn[").append(index).append("] = new Array(\"").append(MpmLocaleUtil.getMessage("mcd.java.cjsj")).append("\",\"").append(1).append("\",\"").append("create_time|mtl_duser_xxxxx|").append(3).append(MpmLocaleUtil.getMessage("mcd.java.||cjsj")).append("\");\n").toString());
/*      */ 
/*  836 */       index++;
/*  837 */       sb.append(new StringBuilder().append("subBaseColumn[").append(index).append("] = new Array(\"").append(MpmLocaleUtil.getMessage("mcd.java.yhgsfp")).append("\",\"").append(1).append("\",\"").append("ser_segno|mtl_duser_xxxxx|").append(1).append(MpmLocaleUtil.getMessage("mcd.java.||yhgsfp")).append("\");\n").toString());
/*      */ 
/*  840 */       index++;
/*  841 */       sb.append(new StringBuilder().append("baseColumnCount=").append(index).append(";\n").toString());
/*      */     } catch (Exception e) {
/*  843 */       log.error("", e);
/*      */     }
/*  845 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String genInterfaceTableAndColumnLinkHtml(Set columnList)
/*      */     throws Exception
/*      */   {
/*  854 */     StringBuffer sb = new StringBuffer();
/*  855 */     sb.append("var interfaceColumnCount=0;\n").append("var subInterfaceColumn = new Array();\n");
/*  856 */     if (columnList == null) {
/*  857 */       return sb.toString();
/*      */     }
/*  859 */     Iterator it = columnList.iterator();
/*      */ 
/*  861 */     int index = 0;
/*      */ 
/*  864 */     while (it.hasNext()) {
/*  865 */       MtlCampDatasrcColumn column = (MtlCampDatasrcColumn)it.next();
/*      */ 
/*  867 */       if ((column.getColumnStatus() == null) || (column.getColumnStatus().shortValue() != 2))
/*      */       {
/*  870 */         String desc = column.getColumnCname();
/*  871 */         String columnKey = new StringBuilder().append(column.getId().getColumnName()).append("|").append(column.getId().getSourceName()).append("|").append(column.getId().getColumnType()).append("|").append(column.getColumnFlag()).append("|").append(desc == null ? "" : desc).toString();
/*      */ 
/*  874 */         sb.append(new StringBuilder().append("subInterfaceColumn[").append(index).append("] = new Array(\"").append(desc).append("\",\"").append(column.getId().getSourceName()).append("\",\"").append(columnKey).append("\");\n").toString());
/*      */ 
/*  876 */         index++;
/*      */       }
/*      */     }
/*  878 */     sb.append(new StringBuilder().append("interfaceColumnCount=").append(index++).append(";\n").toString());
/*  879 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String genActTempletAndColumnLinkHtml(Set columnList)
/*      */     throws Exception
/*      */   {
/*  971 */     StringBuffer sb = new StringBuffer();
/*  972 */     sb.append("var actTempletColumnCount=0;\n").append("var actTempletColumn = new Array();\n");
/*  973 */     if (columnList == null) {
/*  974 */       return sb.toString();
/*      */     }
/*  976 */     Iterator it = columnList.iterator();
/*      */ 
/*  978 */     int index = 0;
/*      */ 
/*  981 */     while (it.hasNext()) {
/*  982 */       MtlTempletActiveField column = (MtlTempletActiveField)it.next();
/*  983 */       String desc = column.getColumnCname();
/*  984 */       String columnKey = new StringBuilder().append(column.getId().getColumnName()).append("|").append(column.getId().getSourceName()).append("|").append(column.getId().getColumnType()).append("|").append(column.getColumnFlag()).append("|").append(desc == null ? "" : desc).toString();
/*      */ 
/*  987 */       sb.append(new StringBuilder().append("actTempletColumn[").append(index).append("] = new Array(\"").append(desc).append("\",\"").append(column.getId().getSourceName()).append("\",\"").append(columnKey).append("\",\"").append(column.getId().getActiveTempletId()).append("\",\"").append(column.getId().getColumnType()).append("\");\n").toString());
/*      */ 
/*  990 */       index++;
/*      */     }
/*  992 */     sb.append(new StringBuilder().append("actTempletColumnCount=").append(index++).append(";\n").toString());
/*  993 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String genColumnTypeTransferJSHtml()
/*      */   {
/* 1001 */     StringBuffer sb = new StringBuffer();
/* 1002 */     sb.append("function columnTypeTrans(columnType) {\n").append(new StringBuilder().append(" \tvar res = \"").append(MpmLocaleUtil.getMessage("mcd.java.wzlx")).append("\";\n").toString()).append(" \tif (columnType == 1)\n").append(new StringBuilder().append(" \t\tres = \"").append(MpmLocaleUtil.getMessage("mcd.java.szx1")).append("\";\n").toString()).append(" \telse if (columnType == 2)\n").append(new StringBuilder().append(" \t\tres = \"").append(MpmLocaleUtil.getMessage("mcd.java.zfx")).append("\";\n").toString()).append(" \telse if (columnType == 3)\n").append(new StringBuilder().append(" \t\tres = \"").append(MpmLocaleUtil.getMessage("mcd.java.rqx")).append("\";\n").toString()).append(" \treturn res;\n").append("}\n");
/*      */ 
/* 1011 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String genApproveEmailToCreateUser(String userName, String emailContent)
/*      */   {
/* 1044 */     StringBuffer sb = new StringBuffer();
/* 1045 */     sb.append("<html><head><meta http-equiv=\"Content-Language\" content=\"zh-cn\"></meta>").append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"></meta>").append(new StringBuilder().append("<title>").append(MpmLocaleUtil.getMessage("mcd.java.titleyxyxg")).append("</title>").toString()).append("</head><body>").append(new StringBuilder().append("<p style=\"FONT-SIZE: 9pt\">").append(userName).append(MpmLocaleUtil.getMessage("mcd.java.nhp")).append("</p>").toString()).append("<p style=\"FONT-SIZE: 9pt\">&nbsp;&nbsp;&nbsp;&nbsp;").append(emailContent).append("</p></body></html>");
/*      */ 
/* 1052 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static void download(String strRealFileName, String displayFileName, HttpServletResponse response, boolean needDelete, boolean needEncode)
/*      */   {
/* 1309 */     FileInputStream fis = null;
/*      */ 
/* 1311 */     PrintWriter out = null;
/*      */     try {
/* 1313 */       String dst_fname = displayFileName;
/* 1314 */       if (needEncode) {
/* 1315 */         dst_fname = URLEncoder.encode(dst_fname, "UTF-8");
/*      */       }
/*      */ 
/* 1318 */       response.setContentType("application/octet-stream");
/* 1319 */       response.setHeader("Content-disposition", new StringBuilder().append("attachment; filename=\"").append(dst_fname).append("\"").toString());
/*      */ 
/* 1321 */       out = response.getWriter();
/* 1322 */       fis = new FileInputStream(strRealFileName);
/*      */       int byteRead;
/* 1323 */       while ((byteRead = fis.read()) != -1) {
/* 1324 */         out.write(byteRead);
/*      */       }
/* 1326 */       out.flush();
/* 1327 */       if (fis != null) {
/* 1328 */         fis.close();
/*      */       }
/*      */ 
/* 1331 */       if (needDelete) {
/* 1332 */         File f = new File(strRealFileName);
/* 1333 */         f.delete();
/*      */       }
/*      */     } catch (Exception e) {
/* 1336 */       log.error("", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String genApproveObjTypeSelectHtml(String selectName, String selectExt, String currentType)
/*      */   {
/* 1413 */     StringBuffer sb = new StringBuffer();
/* 1414 */     Map objTypeMap = MpmCache.getInstance().getMapByType("approve_obj_type");
/* 1415 */     Iterator it = objTypeMap.keySet().iterator();
/*      */ 
/* 1417 */     sb.append(new StringBuilder().append("<select name='").append(selectName).append("' ").append(selectExt).append(" style='width:140;'>").toString());
/* 1418 */     while (it.hasNext()) {
/* 1419 */       String type = (String)it.next();
/* 1420 */       String typeName = (String)objTypeMap.get(type);
/* 1421 */       sb.append(new StringBuilder().append("<option value='").append(type).append("' ").toString());
/* 1422 */       if ((currentType != null) && (currentType.equals(type))) {
/* 1423 */         sb.append("selected");
/*      */       }
/* 1425 */       sb.append(new StringBuilder().append(">").append(typeName).append("</option>").toString());
/*      */     }
/* 1427 */     sb.append("</select>");
/* 1428 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String genApproveTriggerCondIndiSelectHtml(String selectName, String selectExt, String currentIndi)
/*      */   {
/* 1439 */     StringBuffer sb = new StringBuffer();
/*      */     try
/*      */     {
/* 1445 */       IMpmResListSvc mrls = (IMpmResListSvc)SystemServiceLocator.getInstance().getService("mpmResListService");
/* 1446 */       Iterator it = mrls.getCostList().iterator();
/*      */ 
/* 1448 */       sb.append(new StringBuilder().append("<select id='").append(selectName).append("' name='").append(selectName).append("' ").append(selectExt).append(" onChange =changeIndi('").append(selectName).append("')>").toString());
/*      */ 
/* 1450 */       while (it.hasNext()) {
/* 1451 */         MtlCostList indi = (MtlCostList)it.next();
/* 1452 */         sb.append(new StringBuilder().append("<option value='").append(indi.getCostCode()).append("' ").toString());
/* 1453 */         if ((currentIndi != null) && (currentIndi.equals(new StringBuilder().append(indi.getCostCode().intValue()).append("").toString()))) {
/* 1454 */           sb.append("selected");
/*      */         }
/* 1456 */         sb.append(new StringBuilder().append(">").append(indi.getCostName()).append("</option>").toString());
/*      */       }
/* 1458 */       sb.append("<option value='20000000'");
/* 1459 */       if ("20000000".equals(currentIndi)) {
/* 1460 */         sb.append(" selected");
/*      */       }
/* 1462 */       sb.append(new StringBuilder().append(">").append(MpmLocaleUtil.getMessage("mcd.jsp.yhs")).append("</option>").toString());
/*      */ 
/* 1465 */       sb.append("<option value='30000000'");
/* 1466 */       if ("30000000".equals(currentIndi)) {
/* 1467 */         sb.append(" selected");
/*      */       }
/* 1469 */       sb.append(new StringBuilder().append(">").append(MpmLocaleUtil.getMessage("mcd.jsp.xyHODsp")).append("</option>").toString());
/*      */ 
/* 1471 */       sb.append("<option value='40000000'");
/* 1472 */       if ("40000000".equals(currentIndi)) {
/* 1473 */         sb.append(" selected");
/*      */       }
/* 1475 */       sb.append(new StringBuilder().append(">").append(MpmLocaleUtil.getMessage("mcd.jsp.xyCCOsp")).append("</option>").toString());
/*      */ 
/* 1477 */       sb.append("</select>");
/*      */     } catch (Exception e) {
/* 1479 */       log.error("", e);
/*      */     }
/* 1481 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String genApproveTriggerCondIndiOperatorSelectHtml(String selectName, String selectExt, String currentIndi)
/*      */   {
/* 1493 */     StringBuffer sb = new StringBuffer();
/*      */     try {
/* 1495 */       sb.append(new StringBuilder().append("<select id ='").append(selectName).append("'  name='").append(selectName).append("' ").append(selectExt).append(">").toString());
/* 1496 */       if ((currentIndi != null) && (currentIndi.trim().equals(">")))
/* 1497 */         sb.append("<option value='>' selected>></option>");
/*      */       else {
/* 1499 */         sb.append("<option value='>'>></option>");
/*      */       }
/* 1501 */       if ((currentIndi != null) && (currentIndi.trim().equals(">=")))
/* 1502 */         sb.append("<option value='>=' selected>>=</option>");
/*      */       else {
/* 1504 */         sb.append("<option value='>='>>=</option>");
/*      */       }
/* 1506 */       if ((currentIndi != null) && (currentIndi.trim().equals("<")))
/* 1507 */         sb.append("<option value='<' selected><</option>");
/*      */       else {
/* 1509 */         sb.append("<option value='<'><</option>");
/*      */       }
/* 1511 */       if ((currentIndi != null) && (currentIndi.trim().equals("<=")))
/* 1512 */         sb.append("<option value='<=' selected><=</option>");
/*      */       else {
/* 1514 */         sb.append("<option value='<='><=</option>");
/*      */       }
/* 1516 */       if ((currentIndi != null) && (currentIndi.trim().equals("=")))
/* 1517 */         sb.append("<option value='=' selected>=</option>");
/*      */       else {
/* 1519 */         sb.append("<option value='='>=</option>");
/*      */       }
/* 1521 */       sb.append("</select>");
/*      */     } catch (Exception e) {
/* 1523 */       log.error("", e);
/*      */     }
/* 1525 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String getApproveObjNameByTypeAndId(Integer objType, String objId)
/*      */   {
/* 1535 */     String res = objId;
/*      */     try {
/* 1537 */       IMtlApproveFlowDefService service = (IMtlApproveFlowDefService)SystemServiceLocator.getInstance().getService("mpmApproveFlowDefService");
/*      */ 
/* 1539 */       res = service.getApproveObjNameByTypeAndIdCache(objType, objId);
/*      */     } catch (Exception e) {
/* 1541 */       log.error("", e);
/*      */     }
/* 1543 */     return res;
/*      */   }
/*      */ 
/*      */   public static String getCampStatusImgHtml(Short campStatus, String jsLinkFunc)
/*      */   {
/* 1553 */     StringBuffer sb = new StringBuffer();
/* 1554 */     sb.append(new StringBuilder().append("<span  title='").append(MpmLocaleUtil.getMessage("mcd.java.yxazt")).append("'>").append(MpmCache.getInstance().getNameByTypeAndKey("campStatus", campStatus.toString())).append("</span>").toString());
/*      */ 
/* 1557 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String getApproveResultImgHtml(HttpServletRequest request, Short approveResult, String jsLinkFunc)
/*      */   {
/* 1567 */     StringBuffer sb = new StringBuffer();
/* 1568 */     if (approveResult.shortValue() >= 0) {
/* 1569 */       sb.append(new StringBuilder().append("<span style=\"cursor:hand\" onclick=\"").append(jsLinkFunc).append("\" title=\"").append(MpmLocaleUtil.getMessage("mcd.java.spjd")).append(MpmCache.getInstance().getNameByTypeAndKey("segApproveResult", approveResult.toString())).append("\"><img src=\"").append(request.getContextPath()).append("/mpm/assets/images/b").append(approveResult).append(".gif\" border=\"0\"></span>").toString());
/*      */     }
/* 1576 */     else if (approveResult.shortValue() == -1) {
/* 1577 */       sb.append(new StringBuilder().append("<span  title=\"").append(MpmLocaleUtil.getMessage("mcd.java.spjd")).append(MpmCache.getInstance().getNameByTypeAndKey("segApproveResult", approveResult.toString())).append("\"><img src=\"").append(request.getContextPath()).append("/mpm/assets/images/b").append(approveResult).append(".gif\" border=\"0\"></span>").toString());
/*      */     }
/*      */ 
/* 1583 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String getConfirmResultImgHtml(HttpServletRequest request, Short confirmResult, String jsLinkFunc)
/*      */   {
/* 1593 */     StringBuffer sb = new StringBuffer();
/* 1594 */     if (confirmResult.shortValue() > 0) {
/* 1595 */       sb.append(new StringBuilder().append("<span style=\"cursor:hand\" onclick=\"").append(jsLinkFunc).append("\" title=\"").append(MpmLocaleUtil.getMessage("mcd.java.qrjg1")).append(MpmCache.getInstance().getNameByTypeAndKey("mpm_confirm_flag", confirmResult.toString())).append("\"><img src=\"").append(request.getContextPath()).append("/mpm/assets/images/c").append(confirmResult).append(".gif\" border=\"0\"></span>").toString());
/*      */     }
/* 1600 */     else if (confirmResult.shortValue() == 0) {
/* 1601 */       sb.append(new StringBuilder().append("<span  title=\"").append(MpmLocaleUtil.getMessage("mcd.java.qrjg1")).append(MpmCache.getInstance().getNameByTypeAndKey("mpm_confirm_flag", confirmResult.toString())).append("\"><img src=\"").append(request.getContextPath()).append("/mpm/assets/images/c").append(confirmResult).append(".gif\" border=\"0\"></span>").toString());
/*      */     }
/*      */ 
/* 1606 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String getMpmModelFilePath()
/*      */   {
/* 2411 */     String mpmPath = Configure.getInstance().getProperty("SYS_COMMON_MPM_MODEL_PATH");
/* 2412 */     return mpmPath;
/*      */   }
/*      */ 
/*      */   public static String removeComma(String str)
/*      */   {
/* 3044 */     if (StringUtil.isEmpty(str)) {
/* 3045 */       return "";
/*      */     }
/* 3047 */     String rs = str.replaceAll("'", "");
/* 3048 */     rs = rs.trim();
/* 3049 */     if (rs.indexOf(",") == 0) {
/* 3050 */       rs = rs.substring(1);
/*      */     }
/* 3052 */     return rs;
/*      */   }
/*      */ 
/*      */   public static String addComma(String str)
/*      */   {
/* 3057 */     if (str.indexOf("'") == -1) {
/* 3058 */       return new StringBuilder().append("'").append(str.replaceAll(",", "','")).append("'").toString();
/*      */     }
/* 3060 */     return str;
/*      */   }
/*      */ 
/*      */   public static String getCompanyTree(Sqlca sqlInit, String strFolderFormat, String strPageFormat, boolean bGetUser, boolean bGetScript, String cityids)
/*      */     throws Exception
/*      */   {
/* 3066 */     Menu menu = new Menu(null, true, bGetScript, false);
/* 3067 */     log.debug(new StringBuilder().append("===RootID=======").append(menu.getRootID()).toString());
/* 3068 */     getCompanyTreeSub(menu, sqlInit, "0", menu.getRootID(), strFolderFormat, strPageFormat, bGetUser, cityids);
/* 3069 */     return menu.getTreeHtml();
/*      */   }
/*      */ 
/*      */   public static String getCompanyTree(Sqlca sqlInit, String strFolderFormat, String strPageFormat, boolean bGetUser, boolean bGetScript)
/*      */     throws Exception
/*      */   {
/* 3075 */     Menu menu = new Menu(null, true, bGetScript, false);
/* 3076 */     getCompanyTreeSub(menu, sqlInit, "0", menu.getRootID(), strFolderFormat, strPageFormat, bGetUser);
/* 3077 */     return menu.getTreeHtml();
/*      */   }
/*      */ 
/*      */   protected static String getNewID()
/*      */   {
/* 3088 */     return new StringBuilder().append("AutoID").append(m_nInternal++).toString();
/*      */   }
/*      */ 
/*      */   public static String getCompanySubTree(Sqlca sqlInit, String ParentID, String cityids)
/*      */     throws Exception
/*      */   {
/* 3098 */     String nos = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
/* 3099 */     if ("true".equalsIgnoreCase(nos)) {
/* 3100 */       return getCompanySubTreeForSuite(sqlInit, ParentID, cityids);
/*      */     }
/* 3102 */     return getCompanySubTreeForWebOS(sqlInit, ParentID, cityids);
/*      */   }
/*      */ 
/*      */   private static boolean getCompanyTreeSub(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID, String strFolderFormat, String strPageFormat, boolean bGetUser)
/*      */     throws Exception
/*      */   {
/* 3108 */     String nos = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
/* 3109 */     if ("true".equalsIgnoreCase(nos)) {
/* 3110 */       return getCompanyTreeSubForSuite(menu, sqlInit, strParentID, strTreeID, strFolderFormat, strPageFormat, bGetUser);
/*      */     }
/*      */ 
/* 3113 */     return getCompanyTreeSubForWebOS(menu, sqlInit, strParentID, strTreeID, strFolderFormat, strPageFormat, bGetUser);
/*      */   }
/*      */ 
/*      */   private static boolean getCompanyTreeSub(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID, String strFolderFormat, String strPageFormat, boolean bGetUser, String cityids)
/*      */     throws Exception
/*      */   {
/* 3120 */     String nos = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
/* 3121 */     if ("true".equalsIgnoreCase(nos)) {
/* 3122 */       return getCompanyTreeSubForSuite(menu, sqlInit, strParentID, strTreeID, strFolderFormat, strPageFormat, bGetUser, cityids);
/*      */     }
/*      */ 
/* 3125 */     return getCompanyTreeSubForWebOS(menu, sqlInit, strParentID, strTreeID, strFolderFormat, strPageFormat, bGetUser, cityids);
/*      */   }
/*      */ 
/*      */   public static String getCompanyTreeAsyn(Sqlca sqlca, String strParentID)
/*      */     throws Exception
/*      */   {
/* 3136 */     String nos = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
/* 3137 */     if ("true".equalsIgnoreCase(nos)) {
/* 3138 */       return getCompanyTreeAsynForSuite(sqlca, strParentID);
/*      */     }
/* 3140 */     return getCompanyTreeAsynForWebOS(sqlca, strParentID);
/*      */   }
/*      */ 
/*      */   private static boolean getCompanyTreeSubForSuite(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID, String strFolderFormat, String strPageFormat, boolean bGetUser)
/*      */     throws Exception
/*      */   {
/* 3146 */     String strDisplayTable = "";
/* 3147 */     Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
/* 3148 */     String strSql = " select DEPTID,TITLE from user_company where STATUS=? and ParentID = ? order by sortnum,TITLE";
/* 3149 */     sqlca1.execute(strSql, new String[] { "0", removeComma(strParentID) });
/* 3150 */     int nCount = 0;
/* 3151 */     List resList = new ArrayList();
/* 3152 */     while (sqlca1.next()) {
/* 3153 */       int intID = sqlca1.getInt("DEPTID");
/* 3154 */       String strTopic = sqlca1.getString("TITLE");
/* 3155 */       resList.add(new StringBuilder().append(intID).append("_").append(strTopic).toString());
/*      */     }
/*      */ 
/* 3158 */     for (int i = 0; i < resList.size(); i++) {
/* 3159 */       String strContent = (String)resList.get(i);
/* 3160 */       int nPosFirst = strContent.indexOf("_");
/* 3161 */       String intID = strContent.substring(0, nPosFirst);
/* 3162 */       String strTopic = strContent.substring(nPosFirst + 1);
/*      */ 
/* 3164 */       strSql = "select deptid from user_company where STATUS=? and parentid = ? order by sortnum,title";
/* 3165 */       sqlca1.execute(strSql, new String[] { "0", intID });
/* 3166 */       boolean bHaveSub = sqlca1.next();
/* 3167 */       String strMyID = getNewID();
/* 3168 */       if ((bHaveSub) || (bGetUser)) {
/* 3169 */         if (getCompanyTreeSub(menu, sqlInit, new StringBuilder().append("").append(intID).toString(), strMyID, strFolderFormat, strPageFormat, bGetUser)) {
/* 3170 */           nCount++;
/* 3171 */           menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, new StringBuilder().append("").append(intID).toString()), "", "", "", "", "");
/*      */         }
/*      */       } else {
/* 3174 */         nCount++;
/* 3175 */         menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, new StringBuilder().append("").append(intID).toString()), "", "", "", "", "");
/*      */       }
/*      */     }
/* 3178 */     if (bGetUser) {
/* 3179 */       strSql = " select UserID,username from user_user where departmentid = ?";
/* 3180 */       sqlca1.execute(strSql, new String[] { strParentID });
/* 3181 */       while (sqlca1.next()) {
/* 3182 */         String strID = sqlca1.getString("UserID");
/* 3183 */         String strTopic = sqlca1.getString("username");
/* 3184 */         nCount++;
/* 3185 */         String strMyID = getNewID();
/* 3186 */         menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, strID), "", "", "", "", "");
/*      */       }
/*      */     }
/* 3189 */     sqlca1.close();
/* 3190 */     return true;
/*      */   }
/*      */ 
/*      */   private static boolean getCompanyTreeSubForSuite(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID, String strFolderFormat, String strPageFormat, boolean bGetUser, String cityids) throws Exception
/*      */   {
/* 3195 */     Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
/* 3196 */     Sqlca sqlca2 = new Sqlca(sqlInit.getConnection());
/* 3197 */     Sqlca sqlca3 = new Sqlca(sqlInit.getConnection());
/* 3198 */     String strSql = new StringBuilder(" select DEPTID,TITLE from user_company where ParentID = ?").append(" order by sortnum,title").toString();
/*      */ 
/* 3200 */     sqlca1.execute(strSql, new String[] { removeComma(strParentID) });
/* 3201 */     int nCount = 0;
/* 3202 */     String sqlin = "";
/* 3203 */     String roles = "";
/* 3204 */     if (cityids != null) {
/* 3205 */       String[] strRolesArry = cityids.split(",");
/* 3206 */       int cnt = 1;
/* 3207 */       if (strRolesArry.length > 1000) {
/* 3208 */         for (int i = 0; i < strRolesArry.length; i++) {
/* 3209 */           roles = new StringBuilder(String.valueOf(roles)).append(strRolesArry[i]).append(",").toString();
/* 3210 */           cnt++; if (cnt > 1000) {
/* 3211 */             sqlin = new StringBuilder(String.valueOf(sqlin)).append(" and cityid in (").append(roles.substring(0, roles.lastIndexOf(","))).append(") ").toString();
/*      */ 
/* 3213 */             roles = "";
/* 3214 */             cnt = 1;
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 3219 */         sqlin = new StringBuilder(" and cityid in (").append(cityids).append(") ").toString();
/*      */       }
/*      */     }
/* 3222 */     while (sqlca1.next()) {
/* 3223 */       int intID = sqlca1.getInt("DEPTID");
/* 3224 */       String strTopic = sqlca1.getString("TITLE");
/* 3225 */       strSql = "select deptid from user_company where parentid = ? order by sortnum,title";
/* 3226 */       sqlca2.execute(strSql, new Integer[] { Integer.valueOf(intID) });
/* 3227 */       boolean bHaveSub = sqlca2.next();
/* 3228 */       if (!bHaveSub) {
/* 3229 */         if (cityids == null)
/*      */         {
/* 3231 */           sqlca3.execute(" select UserID,username from user_user where departmentid = ?", new Integer[] { Integer.valueOf(intID) });
/*      */         }
/*      */         else {
/* 3234 */           sqlca3.execute(new StringBuilder(" select UserID,username from user_user where 1=1 ").append(sqlin).append(" and departmentid = ?").toString(), new Integer[] { Integer.valueOf(intID) });
/*      */         }
/*      */ 
/* 3238 */         if (!sqlca3.next());
/*      */       }
/*      */       else
/*      */       {
/* 3242 */         String strMyID = getNewID();
/* 3243 */         if ((bHaveSub) || (bGetUser)) {
/* 3244 */           if (getCompanyTreeSub(menu, sqlInit, String.valueOf(intID), strMyID, strFolderFormat, strPageFormat, bGetUser, cityids))
/*      */           {
/* 3246 */             nCount++;
/* 3247 */             menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, String.valueOf(intID)), "", "", "", "", "");
/*      */           }
/*      */         }
/*      */         else {
/* 3251 */           nCount++;
/* 3252 */           menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, String.valueOf(intID)), "", "", "", "", "");
/*      */         }
/*      */       }
/*      */     }
/* 3256 */     if (bGetUser) {
/* 3257 */       String[] param = null;
/* 3258 */       if (cityids == null) {
/* 3259 */         strSql = " select UserID,username from user_user where departmentid =? ";
/* 3260 */         param = new String[] { strParentID };
/*      */       } else {
/* 3262 */         strSql = new StringBuilder(" select UserID,username from user_user where 1=1 ").append(sqlin).append(" and departmentid = ?").toString();
/*      */ 
/* 3264 */         param = new String[] { strParentID };
/*      */       }
/*      */ 
/* 3267 */       sqlca1.execute(strSql, param);
/*      */       String strID;
/*      */       String strTopic;
/*      */       String strMyID;
/* 3271 */       for (; sqlca1.next(); menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, strID), "", "", "", "", ""))
/*      */       {
/* 3273 */         strID = sqlca1.getString("UserID");
/* 3274 */         strTopic = sqlca1.getString("username");
/* 3275 */         nCount++;
/* 3276 */         strMyID = getNewID();
/*      */       }
/*      */     }
/*      */ 
/* 3280 */     sqlca1.close();
/* 3281 */     sqlca2.close();
/* 3282 */     sqlca3.close();
/* 3283 */     return true;
/*      */   }
/*      */ 
/*      */   public static String getCompanySubTreeForWebOS(Sqlca sqlInit, String ParentID, String cityids) throws Exception {
/* 3287 */     String returnInfo = "[";
/* 3288 */     if (ParentID.equals("root")) {
/* 3289 */       ParentID = "0";
/*      */     }
/* 3291 */     Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
/* 3292 */     Sqlca sqlca2 = new Sqlca(sqlInit.getConnection());
/* 3293 */     String[] params = null;
/* 3294 */     String strSql = " SELECT DEP_ID,DEP_NAME FROM (SELECT DISTINCT DEP_ID,DEP_NAME,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
/* 3295 */     params = new String[] { removeComma(ParentID) };
/* 3296 */     if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3297 */       strSql = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE STATUS=? AND PARENTID = ? ORDER BY SORTNUM,TITLE";
/* 3298 */       params = new String[] { "0", removeComma(ParentID) };
/*      */     }
/* 3300 */     sqlca1.execute(strSql, params);
/* 3301 */     if ((null != sqlca1) || (sqlca1.equals(""))) {
/* 3302 */       while (sqlca1.next()) {
/* 3303 */         returnInfo = new StringBuilder().append(returnInfo).append("{id: '").append(sqlca1.getInt("DEP_ID")).append("',text: '").append(sqlca1.getString("DEP_NAME")).append("',leaf: false},").toString();
/*      */       }
/*      */     }
/*      */ 
/* 3307 */     String[] params2 = null;
/* 3308 */     String strSq2 = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE DEP_ID = ? ORDER BY STAFF_NAME";
/* 3309 */     params2 = new String[] { removeComma(ParentID) };
/* 3310 */     if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3311 */       strSq2 = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE MCD_DEP_ID = ? ORDER BY STAFF_NAME";
/* 3312 */       params2 = new String[] { removeComma(ParentID) };
/*      */     }
/* 3314 */     sqlca2.execute(strSq2, params2);
/* 3315 */     if ((null != sqlca2) || (sqlca2.equals(""))) {
/* 3316 */       while (sqlca2.next()) {
/* 3317 */         returnInfo = new StringBuilder().append(returnInfo).append("{id: '").append(sqlca2.getString("STAFF_ID")).append("',text: '").append(sqlca2.getString("STAFF_NAME")).append("',leaf: true},").toString();
/*      */       }
/*      */     }
/*      */ 
/* 3321 */     sqlca1.close();
/* 3322 */     sqlca2.close();
/* 3323 */     if (returnInfo.length() > 1) {
/* 3324 */       returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
/*      */     }
/* 3326 */     returnInfo = new StringBuilder().append(returnInfo).append("]").toString();
/* 3327 */     log.debug(returnInfo);
/* 3328 */     return returnInfo;
/*      */   }
/*      */ 
/*      */   private static boolean getCompanyTreeSubForWebOS(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID, String strFolderFormat, String strPageFormat, boolean bGetUser) throws Exception
/*      */   {
/* 3333 */     String strDisplayTable = "";
/* 3334 */     Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
/* 3335 */     String[] params = null;
/* 3336 */     String strSql = " SELECT DEP_ID,DEP_NAME FROM  (SELECT DISTINCT DEP_ID,DEP_NAME,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
/* 3337 */     params = new String[] { removeComma(strParentID) };
/* 3338 */     if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3339 */       strSql = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE STATUS=? AND PARENTID = ? ORDER BY SORTNUM,TITLE";
/* 3340 */       params = new String[] { "0", removeComma(strParentID) };
/*      */     }
/* 3342 */     sqlca1.execute(strSql, params);
/* 3343 */     int nCount = 0;
/*      */ 
/* 3345 */     List resList = new ArrayList();
/*      */ 
/* 3347 */     while (sqlca1.next())
/*      */     {
/*      */       int intID;
/*      */       int intID;
/* 3349 */       if ("shaanxi".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE")))
/* 3350 */         intID = Integer.parseInt(sqlca1.getString("DEP_ID"));
/*      */       else {
/* 3352 */         intID = sqlca1.getInt("DEP_ID");
/*      */       }
/* 3354 */       String strTopic = sqlca1.getString("DEP_NAME");
/* 3355 */       resList.add(new StringBuilder().append(intID).append("_").append(strTopic).toString());
/*      */     }
/*      */ 
/* 3358 */     for (int i = 0; i < resList.size(); i++) {
/* 3359 */       String strContent = (String)resList.get(i);
/* 3360 */       int nPosFirst = strContent.indexOf("_");
/* 3361 */       String intID = strContent.substring(0, nPosFirst);
/* 3362 */       String strTopic = strContent.substring(nPosFirst + 1);
/* 3363 */       String[] param1 = null;
/* 3364 */       strSql = "SELECT DEP_ID FROM  (SELECT DISTINCT DEP_ID,DEP_NAME,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
/* 3365 */       param1 = new String[] { intID };
/* 3366 */       if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3367 */         strSql = "SELECT DEPTID as DEP_ID FROM LKG_STAFF_COMPANY WHERE STATUS=? AND PARENTID = ? ORDER BY SORTNUM,TITLE";
/* 3368 */         param1 = new String[] { "0", intID };
/*      */       }
/* 3370 */       sqlca1.execute(strSql, param1);
/* 3371 */       boolean bHaveSub = sqlca1.next();
/* 3372 */       String strMyID = getNewID();
/* 3373 */       if ((bHaveSub) || (bGetUser)) {
/* 3374 */         if (getCompanyTreeSub(menu, sqlInit, new StringBuilder().append("").append(intID).toString(), strMyID, strFolderFormat, strPageFormat, bGetUser)) {
/* 3375 */           nCount++;
/* 3376 */           menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, new StringBuilder().append("").append(intID).toString()), "", "", "", "", "");
/*      */         }
/*      */       } else {
/* 3379 */         nCount++;
/* 3380 */         menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, new StringBuilder().append("").append(intID).toString()), "", "", "", "", "");
/*      */       }
/*      */     }
/* 3383 */     if (bGetUser) {
/* 3384 */       strSql = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE DEP_ID = ?";
/* 3385 */       if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3386 */         strSql = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE MCD_DEP_ID =?";
/*      */       }
/* 3388 */       sqlca1.execute(strSql, new String[] { strParentID });
/* 3389 */       while (sqlca1.next()) {
/* 3390 */         String strID = sqlca1.getString("STAFF_ID");
/* 3391 */         String strTopic = sqlca1.getString("STAFF_NAME");
/* 3392 */         nCount++;
/* 3393 */         String strMyID = getNewID();
/* 3394 */         menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, strID), "", "", "", "", "");
/*      */       }
/*      */     }
/* 3397 */     sqlca1.close();
/* 3398 */     return true;
/*      */   }
/*      */ 
/*      */   private static boolean getCompanyTreeSubForWebOS(Menu menu, Sqlca sqlInit, String strParentID, String strTreeID, String strFolderFormat, String strPageFormat, boolean bGetUser, String cityids) throws Exception
/*      */   {
/* 3403 */     Sqlca sqlca1 = new Sqlca(new ConnectionEx());
/* 3404 */     Sqlca sqlca2 = new Sqlca(new ConnectionEx());
/* 3405 */     Sqlca sqlca3 = new Sqlca(new ConnectionEx());
/* 3406 */     String strSql = new StringBuilder(" SELECT DEP_ID,DEP_NAME FROM (SELECT DISTINCT DEP_ID,DEP_NAME,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ?").append(" ORDER BY DEP_ORDER").toString();
/*      */ 
/* 3409 */     if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3410 */       strSql = new StringBuilder(" SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE PARENTID = ?").append(" ORDER BY SORTNUM,TITLE").toString();
/*      */     }
/*      */ 
/* 3414 */     sqlca1.execute(strSql, new String[] { removeComma(strParentID) });
/* 3415 */     int nCount = 0;
/* 3416 */     String sqlin = "";
/* 3417 */     String roles = "";
/* 3418 */     if (cityids != null) {
/* 3419 */       String[] strRolesArry = cityids.split(",");
/* 3420 */       int cnt = 1;
/* 3421 */       if (strRolesArry.length > 1000) {
/* 3422 */         for (int i = 0; i < strRolesArry.length; i++) {
/* 3423 */           roles = new StringBuilder(String.valueOf(roles)).append(strRolesArry[i]).append(",").toString();
/* 3424 */           cnt++; if (cnt > 1000) {
/* 3425 */             sqlin = new StringBuilder(String.valueOf(sqlin)).append(" AND CITY_ID IN (").append(roles.substring(0, roles.lastIndexOf(","))).append(") ").toString();
/*      */ 
/* 3427 */             roles = "";
/* 3428 */             cnt = 1;
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 3433 */         sqlin = new StringBuilder(" AND CITY_ID IN (").append(cityids).append(") ").toString();
/*      */       }
/*      */     }
/* 3436 */     while (sqlca1.next())
/*      */     {
/*      */       int intID;
/*      */       int intID;
/* 3438 */       if ("shaanxi".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE")))
/* 3439 */         intID = Integer.parseInt(sqlca1.getString("DEP_ID"));
/*      */       else {
/* 3441 */         intID = sqlca1.getInt("DEP_ID");
/*      */       }
/* 3443 */       String strTopic = sqlca1.getString("DEP_NAME");
/* 3444 */       strSql = new StringBuilder("SELECT DEP_ID FROM (SELECT DISTINCT DEP_ID,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ?").append(" ORDER BY DEP_ORDER").toString();
/*      */ 
/* 3447 */       if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3448 */         strSql = new StringBuilder("SELECT DEPTID as DEP_ID FROM LKG_STAFF_COMPANY WHERE PARENTID = ?").append(" ORDER BY SORTNUM,TITLE").toString();
/*      */       }
/*      */ 
/* 3451 */       sqlca2.execute(strSql, new Integer[] { Integer.valueOf(intID) });
/* 3452 */       boolean bHaveSub = sqlca2.next();
/* 3453 */       if (!bHaveSub) {
/* 3454 */         StringBuilder sql1 = new StringBuilder(" SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF  WHERE 1=1 ");
/* 3455 */         if (StringUtil.isNotEmpty(cityids)) {
/* 3456 */           sql1.append(sqlin);
/*      */         }
/* 3458 */         if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE")))
/* 3459 */           sql1.append(" AND MCD_DEP_ID = ?");
/*      */         else {
/* 3461 */           sql1.append(" AND DEP_ID = ?");
/*      */         }
/* 3463 */         sqlca3.execute(sql1.toString(), new Integer[] { Integer.valueOf(intID) });
/* 3464 */         if (!sqlca3.next());
/*      */       }
/*      */       else {
/* 3468 */         String strMyID = getNewID();
/* 3469 */         if ((bHaveSub) || (bGetUser)) {
/* 3470 */           if (getCompanyTreeSub(menu, sqlInit, String.valueOf(intID), strMyID, strFolderFormat, strPageFormat, bGetUser, cityids))
/*      */           {
/* 3472 */             nCount++;
/* 3473 */             menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, String.valueOf(intID)), "", "", "", "", "");
/*      */           }
/*      */         }
/*      */         else {
/* 3477 */           nCount++;
/* 3478 */           menu.addItem(strTreeID, strMyID, format(strFolderFormat, strTopic, String.valueOf(intID)), "", "", "", "", "");
/*      */         }
/*      */       }
/*      */     }
/* 3482 */     if (bGetUser) {
/* 3483 */       StringBuilder sql1 = new StringBuilder(" SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF  WHERE 1=1 ");
/* 3484 */       if (StringUtil.isNotEmpty(cityids)) {
/* 3485 */         sql1.append(sqlin);
/*      */       }
/* 3487 */       if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE")))
/* 3488 */         sql1.append(" AND MCD_DEP_ID = ?");
/*      */       else {
/* 3490 */         sql1.append(" AND DEP_ID = ?");
/*      */       }
/* 3492 */       sqlca1.execute(sql1.toString(), new String[] { strParentID });
/*      */       String strID;
/*      */       String strTopic;
/*      */       String strMyID;
/* 3496 */       for (; sqlca1.next(); menu.addItem(strTreeID, strMyID, format(strPageFormat, strTopic, strID), "", "", "", "", ""))
/*      */       {
/* 3498 */         strID = sqlca1.getString("STAFF_ID");
/* 3499 */         strTopic = sqlca1.getString("STAFF_NAME");
/* 3500 */         nCount++;
/* 3501 */         strMyID = getNewID();
/*      */       }
/*      */     }
/*      */ 
/* 3505 */     sqlca1.closeAll();
/* 3506 */     sqlca2.closeAll();
/* 3507 */     sqlca3.closeAll();
/* 3508 */     return true;
/*      */   }
/*      */ 
/*      */   public static String getCompanyTreeAsynForWebOS(Sqlca sqlca, String strParentID)
/*      */     throws Exception
/*      */   {
/* 3519 */     Sqlca sqlca1 = new Sqlca(sqlca.getConnection());
/* 3520 */     Sqlca sqlca2 = new Sqlca(sqlca.getConnection());
/* 3521 */     Sqlca sqlca3 = new Sqlca(sqlca.getConnection());
/* 3522 */     String strSql1 = "SELECT DEP_ID FROM (SELECT DISTINCT DEP_ID,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
/* 3523 */     if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3524 */       strSql1 = "SELECT DEPTID as DEP_ID FROM LKG_STAFF_COMPANY WHERE PARENTID = ? ORDER BY SORTNUM,TITLE";
/*      */     }
/* 3526 */     String strSql2 = " SELECT DEP_ID,DEP_NAME,PARENT_DEP_ID FROM (SELECT DISTINCT DEP_ID,PARENT_DEP_ID ,DEP_ORDER FROM LKG_PARAM_POST) tmp WHERE PARENT_DEP_ID = ? ORDER BY DEP_ORDER";
/* 3527 */     if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3528 */       strSql2 = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE PARENTID = ? ORDER BY SORTNUM,TITLE";
/*      */     }
/* 3530 */     String strSql3 = " SELECT STAFF_ID,STAFF_NAME FROM LKG_STAFF WHERE DEP_ID = ?";
/* 3531 */     if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 3532 */       strSql3 = " SELECT STAFF_ID,STAFF_NAME,MCD_DEP_ID FROM LKG_STAFF WHERE MCD_DEP_ID =? ";
/*      */     }
/*      */ 
/* 3535 */     String returnInfo = "[";
/*      */ 
/* 3537 */     sqlca1.execute(strSql1, new String[] { removeComma(strParentID) });
/* 3538 */     boolean bHaveSub = sqlca1.next();
/* 3539 */     if (bHaveSub) {
/* 3540 */       sqlca2.execute(strSql2, new String[] { removeComma(strParentID) });
/* 3541 */       while (sqlca2.next()) {
/* 3542 */         int deptID = sqlca2.getInt("DEP_ID");
/* 3543 */         String title = sqlca2.getString("DEP_NAME");
/* 3544 */         String parentId = sqlca2.getString("PARENT_DEP_ID");
/* 3545 */         returnInfo = new StringBuilder().append(returnInfo).append("{id: '").append(deptID).append("',pId: '").append(parentId).append("',name: '").append(title).append("',isParent: true},").toString();
/*      */       }
/*      */     }
/* 3548 */     sqlca3.execute(strSql3, new String[] { removeComma(strParentID) });
/* 3549 */     while (sqlca3.next()) {
/* 3550 */       String userId = sqlca3.getString("STAFF_ID");
/* 3551 */       String username = sqlca3.getString("STAFF_NAME");
/* 3552 */       String parentId = sqlca3.getString("MCD_DEP_ID");
/* 3553 */       returnInfo = new StringBuilder().append(returnInfo).append("{id: '").append(userId).append("',pId: '").append(parentId).append("', name: '").append(username).append("',isParent: false},").toString();
/*      */     }
/*      */ 
/* 3557 */     if (returnInfo.length() > 1) {
/* 3558 */       returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
/*      */     }
/* 3560 */     returnInfo = new StringBuilder().append(returnInfo).append("]").toString();
/*      */ 
/* 3562 */     sqlca1.close();
/* 3563 */     sqlca2.close();
/* 3564 */     sqlca3.close();
/* 3565 */     return returnInfo;
/*      */   }
/*      */ 
/*      */   public static String format(String strFormat, String strTitle, String strResID)
/*      */   {
/* 3633 */     if ((null == strFormat) || (strFormat.trim().length() < 3)) {
/* 3634 */       return strTitle;
/*      */     }
/* 3636 */     String strBak = strFormat.toUpperCase();
/* 3637 */     int n = strBak.indexOf("[S]");
/* 3638 */     while (n >= 0) {
/* 3639 */       strFormat = new StringBuilder().append(strFormat.substring(0, n)).append(strTitle).append(strFormat.substring(n + "[S]".length())).toString();
/* 3640 */       strBak = strFormat.toUpperCase();
/* 3641 */       n = strBak.indexOf("[S]", n + 1);
/*      */     }
/* 3643 */     n = strBak.indexOf("[ID]");
/* 3644 */     while (n >= 0) {
/* 3645 */       strTitle = new StringBuilder().append(strFormat.substring(0, n)).append(strResID).append(strFormat.substring(n + "[ID]".length())).toString();
/* 3646 */       strBak = strFormat.toUpperCase();
/* 3647 */       n = strBak.indexOf("[ID]", n + 1);
/*      */     }
/* 3649 */     return strTitle;
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/*      */   }
/*      */ 
/*      */   public static String getCompanySubTreeForSuite(Sqlca sqlInit, String ParentID, String cityids) throws Exception
/*      */   {
/* 3658 */     String returnInfo = "[";
/* 3659 */     if (ParentID.equals("root")) {
/* 3660 */       ParentID = "0";
/*      */     }
/* 3662 */     Sqlca sqlca1 = new Sqlca(sqlInit.getConnection());
/* 3663 */     Sqlca sqlca2 = new Sqlca(sqlInit.getConnection());
/*      */ 
/* 3665 */     String strSql = "select t.deptid,t.title from user_company t where t.status=? and t.parentid=? order by t.sortnum,t.title";
/* 3666 */     sqlca1.execute(strSql, new Object[] { "0", removeComma(ParentID) });
/* 3667 */     if ((null != sqlca1) || (sqlca1.equals(""))) {
/* 3668 */       while (sqlca1.next()) {
/* 3669 */         returnInfo = new StringBuilder().append(returnInfo).append("{id: '").append(sqlca1.getInt("DEPTID")).append("',text: '").append(sqlca1.getString("TITLE")).append("',leaf: false},").toString();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3674 */     String strSq2 = "select u.userid,u.username from user_user u where u.departmentid=? order by u.username";
/* 3675 */     sqlca2.execute(strSq2, new String[] { removeComma(ParentID) });
/* 3676 */     if ((null != sqlca2) || (sqlca2.equals(""))) {
/* 3677 */       while (sqlca2.next()) {
/* 3678 */         returnInfo = new StringBuilder().append(returnInfo).append("{id: '").append(sqlca2.getString("USERID")).append("',text: '").append(sqlca2.getString("USERNAME")).append("',leaf: true},").toString();
/*      */       }
/*      */     }
/*      */ 
/* 3682 */     sqlca1.close();
/* 3683 */     sqlca2.close();
/* 3684 */     if (returnInfo.length() > 1) {
/* 3685 */       returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
/*      */     }
/* 3687 */     returnInfo = new StringBuilder().append(returnInfo).append("]").toString();
/* 3688 */     log.debug(returnInfo);
/* 3689 */     return returnInfo;
/*      */   }
/*      */ 
/*      */   public static String getCompanyTreeAsynForSuite(Sqlca sqlca, String strParentID)
/*      */     throws Exception
/*      */   {
/* 3700 */     Sqlca sqlca1 = new Sqlca(sqlca.getConnection());
/* 3701 */     Sqlca sqlca2 = new Sqlca(sqlca.getConnection());
/* 3702 */     Sqlca sqlca3 = new Sqlca(sqlca.getConnection());
/* 3703 */     String strSql1 = new StringBuilder("select deptid from user_company where parentid = ? order by sortnum,title").toString();
/*      */ 
/* 3705 */     String strSql2 = new StringBuilder(" select DEPTID,TITLE, ParentID from user_company where ParentID = ? order by sortnum,title").toString();
/*      */ 
/* 3707 */     String strSql3 = new StringBuilder(" select UserID,username,departmentid from user_user where departmentid = ?").toString();
/*      */ 
/* 3709 */     String returnInfo = "[";
/*      */ 
/* 3711 */     sqlca1.execute(strSql1, new String[] { removeComma(strParentID) });
/* 3712 */     boolean bHaveSub = sqlca1.next();
/* 3713 */     if (bHaveSub) {
/* 3714 */       sqlca2.execute(strSql2, new String[] { removeComma(strParentID) });
/* 3715 */       while (sqlca2.next()) {
/* 3716 */         int deptID = sqlca2.getInt("DEPTID");
/* 3717 */         String title = sqlca2.getString("TITLE");
/* 3718 */         String pId = sqlca2.getString("ParentID");
/* 3719 */         returnInfo = new StringBuilder().append(returnInfo).append("{id: '").append(deptID).append("', pId : '").append(pId).append("', name: '").append(title).append("',isParent: true},").toString();
/*      */       }
/*      */     }
/* 3722 */     sqlca3.execute(strSql3, new String[] { removeComma(strParentID) });
/* 3723 */     while (sqlca3.next()) {
/* 3724 */       String userId = sqlca3.getString("UserID");
/* 3725 */       String username = sqlca3.getString("username");
/* 3726 */       String pId = sqlca3.getString("departmentid");
/* 3727 */       returnInfo = new StringBuilder().append(returnInfo).append("{id: '").append(userId).append("', pId : '").append(pId).append("', name: '").append(username).append("',isParent: false},").toString();
/*      */     }
/*      */ 
/* 3731 */     if (returnInfo.length() > 1) {
/* 3732 */       returnInfo = returnInfo.substring(0, returnInfo.length() - 1);
/*      */     }
/* 3734 */     returnInfo = new StringBuilder().append(returnInfo).append("]").toString();
/*      */ 
/* 3736 */     sqlca1.close();
/* 3737 */     sqlca2.close();
/* 3738 */     sqlca3.close();
/* 3739 */     return returnInfo;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.MpmHtmlHelper
 * JD-Core Version:    0.6.2
 */
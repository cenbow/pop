/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import edu.emory.mathcs.backport.java.util.Arrays;
/*    */ import java.util.Locale;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.springframework.context.MessageSource;
/*    */ 
/*    */ public class MpmLocaleUtil
/*    */ {
/* 15 */   private static Logger log = LogManager.getLogger();
/* 16 */   public static final Locale LOCALE = new Locale(Configure.getInstance().getProperty("LOCALE_LANGUAGE_DEFAULT"), Configure.getInstance().getProperty("LOCALE_COUNTRY_DEFAULT"), "");
/*    */   private static MessageSource messageSource;
/*    */ 
/*    */   public static void setMessageSource(MessageSource messageSource)
/*    */   {
/* 20 */     messageSource = messageSource;
/*    */   }
/*    */ 
/*    */   public static void setConfMessages(MessageSource messageSource)
/*    */   {
/* 25 */     messageSource = messageSource;
/*    */   }
/*    */ 
/*    */   public static String getMessage(String key)
/*    */   {
/* 34 */     String value = "";
/*    */     try {
/* 36 */       value = messageSource.getMessage(key, null, LOCALE);
/*    */     } catch (Exception e) {
/* 38 */       log.error("MpmLocaleUtil.getMessage(" + key + ")  error! ", e);
/*    */     }
/* 40 */     return value;
/*    */   }
/*    */ 
/*    */   public static String getMessage(String key, String[] params)
/*    */   {
/* 50 */     String value = "";
/*    */     try {
/* 52 */       value = messageSource.getMessage(key, params, LOCALE);
/*    */     } catch (Exception e) {
/* 54 */       log.error("MpmLocaleUtil.getMessage(" + key + "," + params != null ? Arrays.toString(params) : "null)  error! ", e);
/*    */     }
/* 56 */     return value;
/*    */   }
/*    */ 
/*    */   public static String escape4Html(String str) {
/* 60 */     if (StringUtils.isEmpty(str)) {
/* 61 */       if (str.indexOf("\"") != -1) {
/* 62 */         str = str.replaceAll("\"", "&quot;");
/*    */       }
/* 64 */       if (str.indexOf("'") != -1) {
/* 65 */         str = str.replaceAll("'", "&apos;");
/*    */       }
/*    */     }
/* 68 */     return str;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.MpmLocaleUtil
 * JD-Core Version:    0.6.2
 */
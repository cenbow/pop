/*      */ package com.ai.bdx.frame.approval.util;
/*      */ 
/*      */ import com.ai.bdx.frame.approval.exception.MpmException;
/*      */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*      */ import com.asiainfo.biframe.privilege.ICity;
/*      */ import com.asiainfo.biframe.privilege.IUserCompany;
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.date.DateUtil;
/*      */ import com.asiainfo.biframe.utils.number.NumberUtil;
/*      */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.management.RuntimeMXBean;
/*      */ import java.text.DateFormat;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.NumberFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import jodd.servlet.ServletUtil;
/*      */ import org.apache.commons.lang.ArrayUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.commons.lang.time.FastDateFormat;
/*      */ import org.apache.logging.log4j.LogManager;
/*      */ import org.apache.logging.log4j.Logger;
/*      */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*      */ import org.apache.poi.hssf.usermodel.HSSFCellStyle;
/*      */ import org.apache.poi.hssf.usermodel.HSSFFont;
/*      */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*      */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*      */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*      */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*      */ import org.hibernate.SessionFactory;
/*      */ import org.hibernate.cfg.Settings;
/*      */ import org.hibernate.engine.SessionFactoryImplementor;
/*      */ import org.hibernate.hql.QueryTranslator;
/*      */ import org.hibernate.hql.QueryTranslatorFactory;
/*      */ import org.hibernate.impl.SessionFactoryImpl;
/*      */ import org.springframework.jdbc.core.JdbcTemplate;
/*      */ 
/*      */ public class MpmUtil
/*      */ {
/*   67 */   private static Logger log = LogManager.getLogger();
/*      */ 
/*   70 */   public static final String DATE_LOCALE_FORMAT = MpmLocaleUtil.getMessage("mcd.dateFormat");
/*      */ 
/*   72 */   public static final String DATE_LOCALE_FORMAT_YM = MpmLocaleUtil.getMessage("mcd.dateFormatYM");
/*      */ 
/*   74 */   public static final String TIME_LOCALE_FORMAT = MpmLocaleUtil.getMessage("mcd.timeFormat");
/*      */ 
/*   77 */   public static final String DATE_EXT_LOCALE_FORMAT = MpmLocaleUtil.getMessage("mcd.dateExtFormat");
/*      */   public static final String DATE_DB_FORMAT = "yyyy-MM-dd";
/*      */   public static final String DATE_DB_FORMAT_YM = "yyyy-MM";
/*      */   public static final String NUMBER_DB_FORMAT = "#.##";
/*   86 */   public static final DateFormat DATE_US_FORMATER = new SimpleDateFormat(DATE_LOCALE_FORMAT, Locale.US);
/*   87 */   public static final DateFormat DATE_US_FORMATER_YM = new SimpleDateFormat(DATE_LOCALE_FORMAT_YM, Locale.US);
/*      */ 
/*   89 */   public static final DecimalFormat decimalFormat = new DecimalFormat(MpmLocaleUtil.getMessage("mcd.decimalFormat"));
/*   90 */   public static final DecimalFormat integerFormat = new DecimalFormat(MpmLocaleUtil.getMessage("mcd.integerFormat"));
/*   91 */   public static final DecimalFormat dbDecimalFormat = new DecimalFormat("#.##");
/*      */ 
/*   93 */   public static final DecimalFormat phoneNumberFormat = new DecimalFormat("0000");
/*      */   public static final String SINGLE_QUOTES = "&apos;";
/*   98 */   public static final boolean DATE_FORMAT_IS_DEFAULT = "yyyy-MM-dd".equals(DATE_LOCALE_FORMAT);
/*      */ 
/*  100 */   public static final int[] NUM_DATA = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
/*      */ 
/*  102 */   public static String lastTabTime = "";
/*      */ 
/*      */   public static Long getIfLongIsNull(Long longNum)
/*      */   {
/*  106 */     if (longNum == null) {
/*  107 */       return Long.valueOf(0L);
/*      */     }
/*  109 */     return longNum;
/*      */   }
/*      */ 
/*      */   public static String getNotNullString(String str)
/*      */   {
/*  114 */     if (StringUtil.isEmpty(str)) {
/*  115 */       return "--";
/*      */     }
/*  117 */     return str;
/*      */   }
/*      */ 
/*      */   public static String getIfStringIsNull(Object obj) {
/*  121 */     return obj == null ? "" : obj.toString();
/*      */   }
/*      */ 
/*      */   public static String getCountTotalSql(String table, String strPrimaryKey, String condition, String tail)
/*      */   {
/*  133 */     if (table == null) {
/*  134 */       return "";
/*      */     }
/*  136 */     String sql = new StringBuilder().append("select count(").append(strPrimaryKey).append(") from ").toString();
/*  137 */     sql = new StringBuilder().append(sql).append(table).append("    ").toString();
/*  138 */     if ((condition != null) && (!condition.equals(""))) {
/*  139 */       sql = new StringBuilder().append(sql).append("where ").append(condition).toString();
/*      */     }
/*  141 */     if ((tail != null) && (!tail.equals(""))) {
/*  142 */       sql = new StringBuilder().append(sql).append(tail).toString();
/*      */     }
/*  144 */     return sql;
/*      */   }
/*      */ 
/*      */   public static String getCountTotalBySQL(String sql, String primaryKey)
/*      */   {
/*  156 */     StringBuffer countSQL = new StringBuffer();
/*  157 */     if (StringUtil.isEmpty(primaryKey)) {
/*  158 */       primaryKey = "*";
/*      */     }
/*  160 */     countSQL.append(new StringBuilder().append("select count(").append(primaryKey).append(") from ( ").toString());
/*  161 */     countSQL.append(sql);
/*  162 */     countSQL.append(" ) tt");
/*  163 */     return countSQL.toString();
/*      */   }
/*      */ 
/*      */   public static synchronized String convertLongMillsToYYYYMMDDHHMMSS2(long longMills)
/*      */   {
/*  173 */     Calendar caldTmp = Calendar.getInstance();
/*  174 */     if (longMills > 0L)
/*  175 */       caldTmp.setTimeInMillis(longMills);
/*      */     else {
/*  177 */       caldTmp.setTimeInMillis(System.currentTimeMillis());
/*      */     }
/*  179 */     StringBuffer res = new StringBuffer().append(caldTmp.get(1));
/*  180 */     String tmpStr = String.valueOf(caldTmp.get(2) + 1);
/*  181 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/*  182 */     res.append(tmpStr);
/*  183 */     tmpStr = String.valueOf(caldTmp.get(5));
/*  184 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/*  185 */     res.append(tmpStr);
/*  186 */     res.append(caldTmp.get(11));
/*  187 */     tmpStr = String.valueOf(caldTmp.get(12));
/*  188 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/*  189 */     res.append(tmpStr);
/*  190 */     tmpStr = String.valueOf(caldTmp.get(13));
/*  191 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/*  192 */     res.append(tmpStr);
/*  193 */     return res.toString();
/*      */   }
/*      */ 
/*      */   public static String getPagedSql(String sql, String column, String strPrimaryKey, int curpage, int pagesize)
/*      */     throws Exception
/*      */   {
/*  207 */     String strDBType = getDBType();
/*  208 */     StringBuffer buffer = null;
/*  209 */     buffer = new StringBuffer();
/*  210 */     if ("ORACLE".equalsIgnoreCase(strDBType)) {
/*  211 */       buffer.append("select * from ( ");
/*  212 */       buffer.append("select ").append(column).append(" rownum as my_rownum from( ");
/*  213 */       buffer.append(sql).append(") ");
/*  214 */       int pageAll = pagesize * curpage + pagesize;
/*  215 */       buffer.append(new StringBuilder().append("where rownum <= ").append(pageAll).append(") a ").toString());
/*  216 */       buffer.append(new StringBuilder().append("where a.my_rownum > ").append(pagesize * curpage).toString());
/*  217 */     } else if ("DB2".equalsIgnoreCase(strDBType)) {
/*  218 */       buffer.append("select * from ( ");
/*  219 */       buffer.append("select ").append(column).append(new StringBuilder().append("  rownumber() over (order by ").append(strPrimaryKey).append(") as my_rownum from( ").toString());
/*      */ 
/*  223 */       buffer.append(sql).append(") as temp ");
/*  224 */       buffer.append(new StringBuilder().append("fetch first ").append(pagesize * curpage + pagesize).append(" rows only) as a ").toString());
/*      */ 
/*  226 */       buffer.append(new StringBuilder().append("where a.my_rownum > ").append(pagesize * curpage).toString());
/*  227 */     } else if ("TERA".equalsIgnoreCase(strDBType)) {
/*  228 */       buffer.append(sql);
/*  229 */       int orderByIndex = buffer.toString().toLowerCase().lastIndexOf("order by");
/*  230 */       if (orderByIndex > 0) {
/*  231 */         String orderBy = buffer.substring(orderByIndex);
/*  232 */         buffer.insert(orderByIndex, " QUALIFY row_number() OVER( ");
/*  233 */         buffer.append(" ) ");
/*  234 */         buffer.append(new StringBuilder().append(" between ").append(pagesize * curpage).append(" and ").append(pagesize * curpage + pagesize).toString());
/*      */ 
/*  236 */         buffer.append(orderBy);
/*      */       } else {
/*  238 */         buffer.append(new StringBuilder().append(" QUALIFY sum(1) over (rows unbounded preceding) between ").append(pagesize * curpage).append(" and ").append(pagesize * curpage + pagesize).toString());
/*      */       }
/*      */     }
/*  241 */     else if ("mysql".equalsIgnoreCase(strDBType)) {
/*  242 */       String columnTemp = column.substring(0, column.length() - 1);
/*  243 */       buffer.append("SELECT ").append(columnTemp).append("  FROM ( ");
/*  244 */       buffer.append(sql).append(" )  AS tempTable ORDER BY ").append(strPrimaryKey);
/*  245 */       boolean a = strPrimaryKey.contains("desc");
/*  246 */       if ((!strPrimaryKey.contains("DESC")) && (!strPrimaryKey.contains("desc"))) {
/*  247 */         buffer.append(" DESC");
/*      */       }
/*  249 */       buffer.append(" limit ").append(pagesize * curpage).append(",").append(pagesize * curpage + pagesize);
/*      */     }
/*  251 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   public static Long getLong(String str)
/*      */   {
/*  261 */     if (str == null)
/*  262 */       return null;
/*  263 */     if (str.trim().equals("")) {
/*  264 */       return null;
/*      */     }
/*  266 */     return Long.valueOf(str.trim());
/*      */   }
/*      */ 
/*      */   public static Short getShort(String str)
/*      */   {
/*  271 */     if (str == null) {
/*  272 */       return null;
/*      */     }
/*  274 */     return Short.valueOf(str);
/*      */   }
/*      */ 
/*      */   public static Date getDate(Date d)
/*      */   {
/*  285 */     if (d == null) {
/*  286 */       return null;
/*      */     }
/*  288 */     return d;
/*      */   }
/*      */ 
/*      */   public static Double getDouble(String str)
/*      */   {
/*  300 */     if (str == null)
/*  301 */       return null;
/*  302 */     if (str.trim().equals("")) {
/*  303 */       return null;
/*      */     }
/*  305 */     return Double.valueOf(str);
/*      */   }
/*      */ 
/*      */   public static Float getFloat(String str)
/*      */   {
/*  316 */     if (str == null) {
/*  317 */       return null;
/*      */     }
/*  319 */     return Float.valueOf(str);
/*      */   }
/*      */ 
/*      */   public static Date makeDate(int year, int month)
/*      */   {
/*  325 */     Calendar cal = Calendar.getInstance();
/*  326 */     cal.set(1, year);
/*  327 */     cal.set(2, month);
/*  328 */     return cal.getTime();
/*      */   }
/*      */ 
/*      */   public static double getDataArrayValue(Object o)
/*      */   {
/*  338 */     if (o == null) {
/*  339 */       return 0.0D;
/*      */     }
/*  341 */     double value = 0.0D;
/*      */     try {
/*  343 */       value = Double.valueOf(o.toString()).doubleValue();
/*      */     }
/*      */     catch (Exception e) {
/*      */     }
/*  347 */     return value;
/*      */   }
/*      */ 
/*      */   public static String getLocalizedPhoneNumber(String mobilePhone)
/*      */   {
/*  352 */     String sql = new StringBuilder().append(mobilePhone).append(" ").toString();
/*      */ 
/*  354 */     return sql;
/*      */   }
/*      */ 
/*      */   public static String getDBType() {
/*  358 */     String strDBType = Configure.getInstance().getProperty("MPM_DBTYPE");
/*  359 */     return strDBType.toUpperCase();
/*      */   }
/*      */ 
/*      */   public static String getMonth(String act)
/*      */   {
/*  364 */     FastDateFormat dFormat = FastDateFormat.getInstance("yyyy-MM");
/*  365 */     String currentDate = dFormat.format(new Date());
/*  366 */     String year = currentDate.split("-")[0];
/*  367 */     String month = currentDate.split("-")[1];
/*  368 */     if ("curr".equalsIgnoreCase(act)) {
/*  369 */       return new StringBuilder().append(year).append(month).toString();
/*      */     }
/*  371 */     if ("pre".equalsIgnoreCase(act)) {
/*  372 */       if (Integer.parseInt(month) == 1) {
/*  373 */         year = String.valueOf(Integer.parseInt(year) - 1);
/*  374 */         month = "12";
/*      */       } else {
/*  376 */         month = String.valueOf(Integer.parseInt(month) - 1);
/*      */       }
/*      */     }
/*      */ 
/*  380 */     if ("next".equalsIgnoreCase(act)) {
/*  381 */       if (Integer.parseInt(month) == 12) {
/*  382 */         year = String.valueOf(Integer.parseInt(year) + 1);
/*  383 */         month = "1";
/*      */       } else {
/*  385 */         month = String.valueOf(Integer.parseInt(month) + 1);
/*      */       }
/*      */     }
/*  388 */     if (month.length() == 1) {
/*  389 */       month = new StringBuilder().append("0").append(month).toString();
/*      */     }
/*  391 */     return new StringBuilder().append(year).append(month).toString();
/*      */   }
/*      */ 
/*      */   public static String getCeilOfCurrMonth()
/*      */   {
/*  400 */     String YYYYMM_TABLE_CREATE_DAY_Str = Configure.getInstance().getProperty("YYYYMM_TABLE_CREATE_DAY");
/*  401 */     int YYYYMM_TABLE_CREATE_DAY_INT = 6;
/*  402 */     if ((YYYYMM_TABLE_CREATE_DAY_Str != null) && (YYYYMM_TABLE_CREATE_DAY_Str.length() > 0))
/*      */       try {
/*  404 */         YYYYMM_TABLE_CREATE_DAY_INT = Integer.parseInt(YYYYMM_TABLE_CREATE_DAY_Str);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*  409 */     String today = DateUtil.getToday();
/*  410 */     String res = today;
/*  411 */     String day = today.substring(8, 10);
/*  412 */     int intDay = Integer.parseInt(day);
/*      */ 
/*  414 */     if (intDay < YYYYMM_TABLE_CREATE_DAY_INT) {
/*  415 */       res = DateUtil.date2String(DateUtil.getOffsetDate(today, -2, "month"), "yyyy-MM-dd");
/*      */     }
/*      */     else
/*      */     {
/*  419 */       res = DateUtil.date2String(DateUtil.getOffsetDate(today, -1, "month"), "yyyy-MM-dd");
/*      */     }
/*  421 */     res = res.substring(0, 7).replaceAll("-", "");
/*  422 */     return res;
/*      */   }
/*      */ 
/*      */   public static String getCeilOfMonthByDate(String date)
/*      */   {
/*  433 */     String YYYYMM_TABLE_CREATE_DAY_Str = Configure.getInstance().getProperty("YYYYMM_TABLE_CREATE_DAY");
/*  434 */     int YYYYMM_TABLE_CREATE_DAY_INT = 6;
/*  435 */     if ((YYYYMM_TABLE_CREATE_DAY_Str != null) && (YYYYMM_TABLE_CREATE_DAY_Str.length() > 0)) {
/*      */       try {
/*  437 */         YYYYMM_TABLE_CREATE_DAY_INT = Integer.parseInt(YYYYMM_TABLE_CREATE_DAY_Str);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*  443 */     String res = date;
/*  444 */     String day = date.substring(8, 10);
/*  445 */     int intDay = Integer.parseInt(day);
/*      */ 
/*  447 */     if (intDay < YYYYMM_TABLE_CREATE_DAY_INT) {
/*  448 */       res = DateUtil.date2String(DateUtil.getOffsetDate(date, -2, "month"), "yyyy-MM-dd");
/*      */     }
/*      */     else
/*      */     {
/*  452 */       res = DateUtil.date2String(DateUtil.getOffsetDate(date, -1, "month"), "yyyy-MM-dd");
/*      */     }
/*  454 */     res = res.substring(0, 7).replaceAll("-", "");
/*  455 */     return res;
/*      */   }
/*      */ 
/*      */   public static void download(String strFileName, HttpServletResponse response)
/*      */   {
/*      */     try {
/*  461 */       String[] arrFileName = StringUtils.split(strFileName, File.separator);
/*  462 */       String dst_fname = arrFileName[(arrFileName.length - 1)];
/*      */ 
/*  464 */       response.setContentType("application/octet-stream");
/*  465 */       response.setHeader("Content-disposition", new StringBuilder().append("attachment; filename=\"").append(dst_fname).append("\"").toString());
/*      */ 
/*  477 */       File file = new File(strFileName);
/*  478 */       if (!file.exists())
/*      */       {
/*  480 */         response.setCharacterEncoding("utf-8");
/*  481 */         response.getWriter().print("下载失败：文件未找到！！！");
/*  482 */         return;
/*      */       }
/*  484 */       ServletUtil.prepareDownload(response, file);
/*  485 */       InputStream fis = new BufferedInputStream(new FileInputStream(file));
/*  486 */       byte[] buffer = new byte[fis.available()];
/*  487 */       fis.read(buffer);
/*  488 */       fis.close();
/*      */ 
/*  490 */       OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
/*  491 */       toClient.write(buffer);
/*  492 */       toClient.flush();
/*  493 */       toClient.close();
/*      */ 
/*  495 */       file.delete();
/*      */     }
/*      */     catch (Exception e) {
/*  498 */       log.debug(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String getSqlDateTime(String dateTime) throws Exception
/*      */   {
/*  504 */     return getSql2Date(dateTime, "yyyy-MM-dd");
/*      */   }
/*      */ 
/*      */   public static String getSql2Date(String strDateStr, String splitStr)
/*      */     throws Exception
/*      */   {
/*  510 */     String strDBType = getDBType();
/*  511 */     return getSql2Date(strDBType, strDateStr, splitStr);
/*      */   }
/*      */ 
/*      */   public static String getSqlDateTime() throws Exception {
/*  515 */     return getSql2DateTimeNow();
/*      */   }
/*      */ 
/*      */   public static String getSql2DateTimeNow() throws MpmException {
/*  519 */     String strType = getDBType();
/*  520 */     String strRet = "";
/*  521 */     if (strType.equalsIgnoreCase("MYSQL"))
/*  522 */       strRet = "now()";
/*  523 */     else if (strType.equalsIgnoreCase("ORACLE"))
/*  524 */       strRet = "sysdate";
/*  525 */     else if (strType.equalsIgnoreCase("ACESS"))
/*  526 */       strRet = "date()+time()";
/*  527 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/*  528 */       strRet = "getdate()";
/*  529 */     else if (strType.equalsIgnoreCase("POSTGRESQL"))
/*  530 */       strRet = "current_timestamp";
/*  531 */     else if (strType.equalsIgnoreCase("DB2"))
/*  532 */       strRet = "current timestamp";
/*  533 */     else if (strType.equalsIgnoreCase("TERA"))
/*  534 */       strRet = "cast((date (format 'yyyy-mm-dd' )) as char(10)) ||' '|| time";
/*  535 */     else if (strType.equalsIgnoreCase("SYBASE"))
/*  536 */       strRet = "getdate()";
/*      */     else {
/*  538 */       throw new MpmException("can't get the current date of the function definition");
/*      */     }
/*  540 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static void printArray(Object[] arrs, String objName) {
/*  544 */     int len = arrs.length;
/*  545 */     StringBuffer sb = new StringBuffer();
/*  546 */     for (int i = 0; i < len; i++) {
/*  547 */       sb.append(new StringBuilder().append(objName).append("[").append(i).append("]=").append(arrs[i]).append(", ").toString());
/*      */     }
/*  549 */     log.debug(sb.toString());
/*      */   }
/*      */ 
/*      */   public static void printDouArray(double[] arrs, String objName) {
/*  553 */     int len = arrs.length;
/*  554 */     StringBuffer sb = new StringBuffer();
/*  555 */     for (int i = 0; i < len; i++) {
/*  556 */       sb.append(new StringBuilder().append(objName).append("[").append(i).append("]=").append(arrs[i]).append(", ").toString());
/*      */     }
/*  558 */     log.debug(sb.toString());
/*      */   }
/*      */ 
/*      */   public static String mpmDiyFormat(double yValue) {
/*  562 */     String tmpStr = NumberUtil.formatNumber(Double.valueOf(yValue), null, 2, 0);
/*  563 */     int pos = tmpStr.indexOf(".");
/*  564 */     if (pos > 0) {
/*  565 */       String tmpStr2 = tmpStr.substring(pos + 1);
/*  566 */       if (Integer.parseInt(tmpStr2) == 0) {
/*  567 */         tmpStr = tmpStr.substring(0, pos);
/*      */       }
/*      */     }
/*  570 */     return tmpStr;
/*      */   }
/*      */ 
/*      */   public static String getCreateAsTableSql(String newtable, String templettable)
/*      */     throws Exception
/*      */   {
/*  582 */     String tableSpace = Configure.getInstance().getProperty("MPM_TABLESPACE");
/*  583 */     String sql = getCreateAsTableSql(newtable, templettable, tableSpace);
/*      */ 
/*  590 */     return sql;
/*      */   }
/*      */ 
/*      */   public static String getCreateAsTableSqlNoTbs(String newtable, String templettable) throws Exception {
/*  594 */     String ss = "";
/*  595 */     String strDBType = getDBType();
/*  596 */     if (("ORACLE".equalsIgnoreCase(strDBType)) || ("POSTGRESQL".equalsIgnoreCase(strDBType))) {
/*  597 */       ss = new StringBuilder().append("create table ").append(newtable).append(" as select * from ").append(templettable).append(" where 1=2").toString();
/*      */     }
/*  599 */     else if ("DB2".equalsIgnoreCase(strDBType)) {
/*  600 */       ss = new StringBuilder().append("create table ").append(newtable).append(" like ").append(templettable).toString();
/*      */     }
/*  602 */     else if ("TERA".equalsIgnoreCase(strDBType)) {
/*  603 */       ss = new StringBuilder().append("create table ").append(newtable).append(" as ").append(templettable).append(" with no data").toString();
/*      */     }
/*      */ 
/*  606 */     return ss;
/*      */   }
/*      */ 
/*      */   public static String getCreateAsTableSql(String newtable, String templettable, String tableSpace) throws Exception {
/*  610 */     String ss = getCreateAsTableSql(newtable, templettable);
/*  611 */     if ((tableSpace == null) || (tableSpace.length() < 1)) {
/*  612 */       return ss;
/*      */     }
/*  614 */     String strDBType = getDBType();
/*  615 */     if (("ORACLE".equalsIgnoreCase(strDBType)) || ("POSTGRESQL".equalsIgnoreCase(strDBType))) {
/*  616 */       ss = ss.replaceAll(newtable, new StringBuilder().append(newtable).append(" tablespace ").append(tableSpace).toString());
/*      */     }
/*  618 */     else if ("DB2".equalsIgnoreCase(strDBType)) {
/*  619 */       ss = new StringBuilder().append(ss).append(" in ").append(tableSpace).toString();
/*      */     }
/*  621 */     return ss;
/*      */   }
/*      */ 
/*      */   public static String getCreateTableInTableSpaceSql(String tableDDLSql, String tableSpace) throws Exception
/*      */   {
/*  626 */     if ((tableSpace == null) || (tableSpace.length() < 1)) {
/*  627 */       return tableDDLSql;
/*      */     }
/*  629 */     String strDBType = getDBType();
/*  630 */     if (("ORACLE".equalsIgnoreCase(strDBType)) || ("POSTGRESQL".equalsIgnoreCase(strDBType))) {
/*  631 */       tableDDLSql = new StringBuilder().append(tableDDLSql).append(" tablespace ").append(tableSpace).toString();
/*      */     }
/*  633 */     else if ("DB2".equalsIgnoreCase(strDBType)) {
/*  634 */       tableDDLSql = new StringBuilder().append(tableDDLSql).append(" in ").append(tableSpace).toString();
/*      */     }
/*  636 */     return tableDDLSql;
/*      */   }
/*      */ 
/*      */   public static String getCreateTableSql(String tableDDLSql)
/*      */     throws Exception
/*      */   {
/*  647 */     String tableSpace = Configure.getInstance().getProperty("MPM_TABLESPACE");
/*  648 */     String sql = getCreateTableInTableSpaceSql(tableDDLSql, tableSpace);
/*  649 */     return sql;
/*      */   }
/*      */ 
/*      */   public static String getCreateIndexSql(String indexDDLSql)
/*      */     throws Exception
/*      */   {
/*  660 */     String tableSpace = Configure.getInstance().getProperty("MPM_INDEX_TABLESPACE");
/*  661 */     String sql = getCreateIndexInTableSpaceSql(indexDDLSql, tableSpace);
/*  662 */     return sql;
/*      */   }
/*      */ 
/*      */   public static String getCreateIndexInTableSpaceSql(String createIndexSql, String tableSpace) throws Exception
/*      */   {
/*  667 */     if ((tableSpace == null) || (tableSpace.length() < 1)) {
/*  668 */       return createIndexSql;
/*      */     }
/*  670 */     String strDBType = getDBType();
/*  671 */     if ("ORACLE".equalsIgnoreCase(strDBType)) {
/*  672 */       createIndexSql = new StringBuilder().append(createIndexSql).append(" using index tablespace ").append(tableSpace).toString();
/*      */     }
/*  674 */     else if ("DB2".equalsIgnoreCase(strDBType));
/*  677 */     return createIndexSql;
/*      */   }
/*      */ 
/*      */   public static String unicodeToGB(String strIn)
/*      */   {
/*  688 */     String strOut = null;
/*  689 */     if (StringUtil.isEmpty(strIn)) {
/*  690 */       return strIn;
/*      */     }
/*      */     try
/*      */     {
/*  694 */       String strMpmCharsetEncoding = Configure.getInstance().getProperty("MPM_CHARSETENCODING").toUpperCase();
/*  695 */       if ((strMpmCharsetEncoding.trim().equalsIgnoreCase("GBK")) || (StringUtil.isEmpty(strMpmCharsetEncoding))) {
/*  696 */         strOut = strIn;
/*      */       } else {
/*  698 */         byte[] b = strIn.getBytes("GBK");
/*  699 */         strOut = new String(b, strMpmCharsetEncoding);
/*      */       }
/*      */     } catch (Exception e) {
/*  702 */       strOut = strIn;
/*      */     }
/*  704 */     return strOut;
/*      */   }
/*      */ 
/*      */   public static String GBToUnicode(String strIn)
/*      */   {
/*  714 */     String strOut = null;
/*  715 */     if (StringUtil.isEmpty(strIn)) {
/*  716 */       return strIn;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  721 */       String strMpmCharsetEncoding = Configure.getInstance().getProperty("MPM_CHARSETENCODING").toUpperCase();
/*  722 */       if ((strMpmCharsetEncoding.trim().equalsIgnoreCase("GBK")) || (StringUtil.isEmpty(strMpmCharsetEncoding))) {
/*  723 */         strOut = strIn;
/*      */       } else {
/*  725 */         byte[] b = strIn.getBytes(strMpmCharsetEncoding);
/*  726 */         strOut = new String(b, "GBK");
/*      */       }
/*      */     } catch (Exception e) {
/*  729 */       strOut = strIn;
/*      */     }
/*  731 */     return strOut;
/*      */   }
/*      */ 
/*      */   public static String formatSql(String sql)
/*      */   {
/*  741 */     if (StringUtil.isEmpty(sql)) {
/*  742 */       return "";
/*      */     }
/*  744 */     sql = StringFunc.replace2(sql, "'", "''");
/*  745 */     return sql;
/*      */   }
/*      */ 
/*      */   public static String getCampExportSendPath()
/*      */     throws Exception
/*      */   {
/*  756 */     String filepath = Configure.getInstance().getProperty("SYS_COMMON_UPLOAD_PATH");
/*  757 */     if (!filepath.endsWith(File.separator)) {
/*  758 */       filepath = new StringBuilder().append(filepath).append(File.separator).toString();
/*      */     }
/*  760 */     filepath = new StringBuilder().append(filepath).append("mpm").append(File.separator).append("send").toString();
/*  761 */     File rootFolder = new File(filepath);
/*  762 */     if (!rootFolder.exists()) {
/*  763 */       rootFolder.mkdirs();
/*      */     }
/*  765 */     return filepath;
/*      */   }
/*      */ 
/*      */   public static String getCampExportChkPath()
/*      */     throws Exception
/*      */   {
/*  776 */     String filepath = Configure.getInstance().getProperty("SYS_COMMON_UPLOAD_PATH");
/*  777 */     if (!filepath.endsWith(File.separator)) {
/*  778 */       filepath = new StringBuilder().append(filepath).append(File.separator).toString();
/*      */     }
/*  780 */     filepath = new StringBuilder().append(filepath).append("mpm").append(File.separator).append("chk").toString();
/*  781 */     File rootFolder = new File(filepath);
/*  782 */     if (!rootFolder.exists()) {
/*  783 */       rootFolder.mkdirs();
/*      */     }
/*  785 */     return filepath;
/*      */   }
/*      */ 
/*      */   public static boolean containStr(String[] arr, String str)
/*      */     throws Exception
/*      */   {
/*  797 */     boolean res = false;
/*  798 */     if (ArrayUtils.isEmpty(arr)) {
/*  799 */       return res;
/*      */     }
/*  801 */     for (int i = 0; i < arr.length; i++) {
/*  802 */       if (arr[i].trim().equals(str)) {
/*  803 */         res = true;
/*  804 */         break;
/*      */       }
/*      */     }
/*  807 */     return res;
/*      */   }
/*      */ 
/*      */   public static int getStrRealLength(String str)
/*      */     throws Exception
/*      */   {
/*  818 */     if (StringUtil.isEmpty(str)) {
/*  819 */       return 0;
/*      */     }
/*      */ 
/*  823 */     int len = 0;
/*  824 */     for (int i = 0; i < str.length(); i++) {
/*  825 */       char chr = str.charAt(i);
/*  826 */       if (chr <= '~')
/*  827 */         len++;
/*      */       else {
/*  829 */         len += 2;
/*      */       }
/*      */     }
/*  832 */     return len;
/*      */   }
/*      */ 
/*      */   public static String getDeptTopNDeptId(String currDeptId, int topN)
/*      */     throws Exception
/*      */   {
/*  843 */     IUserPrivilegeCommonService mpmUserPrivilegeService = null;
/*      */     try
/*      */     {
/*  846 */       mpmUserPrivilegeService = (IUserPrivilegeCommonService)SystemServiceLocator.getInstance().getService("userPrivilegeCommonService");
/*      */     }
/*      */     catch (Exception e) {
/*  849 */       log.error("", e);
/*      */     }
/*  851 */     IUserCompany dept = null;
/*  852 */     int index = 0;
/*  853 */     String deptId = null;
/*      */     do {
/*  855 */       dept = mpmUserPrivilegeService.getUserCompanyById(currDeptId);
/*  856 */       if ((dept != null) && (index < topN)) {
/*  857 */         currDeptId = String.valueOf(dept.getParentid());
/*  858 */         index++;
/*      */       } else {
/*  860 */         deptId = currDeptId;
/*  861 */         break;
/*      */       }
/*      */     }
/*  863 */     while ((dept != null) && (index <= topN));
/*  864 */     return deptId;
/*      */   }
/*      */ 
/*      */   public static boolean matchApproveTriggerCondValue(double realValue, String operator, double condValue)
/*      */     throws Exception
/*      */   {
/*  878 */     boolean match = false;
/*  879 */     if ((operator.equals(">")) && (realValue > condValue))
/*  880 */       match = true;
/*  881 */     else if ((operator.equals(">=")) && (realValue >= condValue))
/*  882 */       match = true;
/*  883 */     else if ((operator.equals("<")) && (realValue < condValue))
/*  884 */       match = true;
/*  885 */     else if ((operator.equals("<=")) && (realValue <= condValue))
/*  886 */       match = true;
/*  887 */     else if ((operator.equals("=")) && (realValue == condValue)) {
/*  888 */       match = true;
/*      */     }
/*  890 */     return match;
/*      */   }
/*      */ 
/*      */   public static String getFlowIdByCustGroupType(short custGroupType)
/*      */     throws Exception
/*      */   {
/*  901 */     String flowId = "flow_def_001";
/*  902 */     if (custGroupType == 2)
/*  903 */       flowId = "flow_def_002";
/*  904 */     else if (custGroupType == 3)
/*  905 */       flowId = "flow_def_003";
/*  906 */     else if (custGroupType == 4)
/*  907 */       flowId = "flow_def_004";
/*  908 */     else if (custGroupType == 5) {
/*  909 */       flowId = "flow_def_005";
/*      */     }
/*  911 */     return flowId;
/*      */   }
/*      */ 
/*      */   public static String writeExcel(String[] srcFileName, String destFileName, String dateF)
/*      */   {
/*  916 */     HSSFWorkbook wbwrite = null; HSSFWorkbook wbread = null;
/*  917 */     HSSFSheet wSheet = null; HSSFSheet rSheet = null;
/*  918 */     HSSFRow wRow = null; HSSFRow rRow = null;
/*  919 */     HSSFCellStyle style = null; HSSFCellStyle style1 = null;
/*  920 */     HSSFFont font = null; HSSFFont font1 = null;
/*  921 */     POIFSFileSystem fsInr = null; POIFSFileSystem fsInw = null;
/*  922 */     FileInputStream fisr = null; FileInputStream fisw = null;
/*  923 */     double[][] counts = new double[1][29];
/*  924 */     int count = 2;
/*  925 */     double xjsum = 0.0D;
/*      */     try {
/*  927 */       fisw = new FileInputStream(destFileName);
/*      */       String str1;
/*  928 */       if (fisw == null) {
/*  929 */         log.debug(new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.gjwj")).append(destFileName).append(MpmLocaleUtil.getMessage("mcd.java.hqFileInpu")).toString());
/*      */ 
/*  931 */         str1 = null; return str1;
/*      */       }
/*  933 */       fsInw = new POIFSFileSystem(fisw);
/*  934 */       if (fsInw == null) {
/*  935 */         log.debug(new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.gjwj")).append(destFileName).append(MpmLocaleUtil.getMessage("mcd.java.hqPOIFSFil")).toString());
/*      */ 
/*  937 */         str1 = null; return str1;
/*      */       }
/*  939 */       wbwrite = new HSSFWorkbook(fsInw);
/*  940 */       fisw.close();
/*  941 */       wSheet = wbwrite.getSheetAt(0);
/*  942 */       font = wbwrite.createFont();
/*  943 */       font.setBoldweight((short)400);
/*  944 */       for (int i = 0; i < srcFileName.length; i++)
/*  945 */         if (!StringUtil.isEmpty(srcFileName[i]))
/*      */         {
/*  948 */           log.debug(new StringBuilder().append("=======================srcFileName=").append(srcFileName[i]).toString());
/*  949 */           fisr = new FileInputStream(srcFileName[i]);
/*      */           String str2;
/*  950 */           if (fisr == null) {
/*  951 */             log.debug(new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.gjwj")).append(srcFileName[i]).append(MpmLocaleUtil.getMessage("mcd.java.hqFileInpu")).toString());
/*      */ 
/*  953 */             str2 = null; return str2;
/*      */           }
/*  955 */           fsInr = new POIFSFileSystem(fisr);
/*  956 */           if (fsInr == null) {
/*  957 */             log.debug(new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.gjwj")).append(srcFileName[i]).append(MpmLocaleUtil.getMessage("mcd.java.hqPOIFSFil")).toString());
/*      */ 
/*  959 */             str2 = null; return str2;
/*      */           }
/*  961 */           wbread = new HSSFWorkbook(fsInr);
/*  962 */           fisr.close();
/*  963 */           rSheet = wbread.getSheetAt(0);
/*  964 */           for (int a = 2; a >= 2; a++) {
/*  965 */             rRow = rSheet.getRow(a);
/*  966 */             if (rRow == null) {
/*      */               break;
/*      */             }
/*  969 */             if ((rRow.getCell((short)2) == null) || (rRow.getCell((short)2).getStringCellValue() == null) || (rRow.getCell((short)2).getStringCellValue().trim().length() <= 0))
/*      */             {
/*      */               break;
/*      */             }
/*  973 */             wRow = wSheet.getRow(count);
/*  974 */             if (wRow == null) {
/*  975 */               wRow = wSheet.createRow(count);
/*      */             }
/*  977 */             if (wRow.getCell((short)0) == null) {
/*  978 */               wRow.createCell((short)0);
/*      */             }
/*  980 */             if ((rRow.getCell((short)0) != null) && (rRow.getCell((short)0).getStringCellValue().trim().length() > 0))
/*      */             {
/*  982 */               wRow.getCell((short)0).setCellStyle(wSheet.getRow(1).getCell((short)0).getCellStyle());
/*  983 */               wRow.getCell((short)0).setCellType(1);
/*  984 */               wRow.getCell((short)0).setCellValue(rRow.getCell((short)0).getStringCellValue());
/*      */             }
/*      */ 
/*  987 */             if (wRow.getCell((short)1) == null) {
/*  988 */               wRow.createCell((short)1);
/*      */             }
/*  990 */             if ((rRow.getCell((short)1) != null) && (rRow.getCell((short)1).getStringCellValue().trim().length() > 0))
/*      */             {
/*  992 */               wRow.getCell((short)1).setCellStyle(wSheet.getRow(1).getCell((short)1).getCellStyle());
/*  993 */               wRow.getCell((short)1).setCellType(1);
/*  994 */               wRow.getCell((short)1).setCellValue(rRow.getCell((short)1).getStringCellValue());
/*      */             }
/*      */ 
/*  997 */             if (wRow.getCell((short)2) == null) {
/*  998 */               wRow.createCell((short)2);
/*      */             }
/* 1000 */             wRow.getCell((short)2).setCellStyle(wSheet.getRow(1).getCell((short)2).getCellStyle());
/* 1001 */             wRow.getCell((short)2).setCellType(1);
/* 1002 */             rRow.getCell((short)2).setCellType(1);
/* 1003 */             wRow.getCell((short)2).setCellValue(rRow.getCell((short)2).getStringCellValue());
/* 1004 */             if (wRow.getCell((short)3) == null) {
/* 1005 */               wRow.createCell((short)3);
/*      */             }
/* 1007 */             wRow.getCell((short)3).setCellStyle(wSheet.getRow(1).getCell((short)3).getCellStyle());
/* 1008 */             style = wRow.getCell((short)3).getCellStyle();
/* 1009 */             style.setFont(font);
/*      */ 
/* 1011 */             wRow.getCell((short)3).setCellValue(rRow.getCell((short)3).getNumericCellValue());
/* 1012 */             counts[0][3] += rRow.getCell(3).getNumericCellValue();
/* 1013 */             if (wRow.getCell((short)4) == null) {
/* 1014 */               wRow.createCell((short)4);
/*      */             }
/* 1016 */             wRow.getCell((short)4).setCellStyle(wSheet.getRow(1).getCell((short)4).getCellStyle());
/* 1017 */             wRow.getCell((short)4).setCellValue(rRow.getCell((short)4).getNumericCellValue());
/* 1018 */             counts[0][4] += rRow.getCell(4).getNumericCellValue();
/* 1019 */             if (wRow.getCell((short)5) == null) {
/* 1020 */               wRow.createCell((short)5);
/*      */             }
/* 1022 */             wRow.getCell((short)5).setCellStyle(wSheet.getRow(1).getCell((short)5).getCellStyle());
/* 1023 */             wRow.getCell((short)5).setCellValue(rRow.getCell((short)5).getNumericCellValue());
/* 1024 */             counts[0][5] += rRow.getCell(5).getNumericCellValue();
/* 1025 */             if (wRow.getCell((short)6) == null) {
/* 1026 */               wRow.createCell((short)6);
/*      */             }
/* 1028 */             wRow.getCell((short)6).setCellStyle(wSheet.getRow(1).getCell((short)6).getCellStyle());
/* 1029 */             wRow.getCell((short)6).setCellValue(rRow.getCell((short)6).getNumericCellValue());
/* 1030 */             counts[0][6] += rRow.getCell(6).getNumericCellValue();
/* 1031 */             if (wRow.getCell((short)7) == null) {
/* 1032 */               wRow.createCell((short)7);
/*      */             }
/* 1034 */             wRow.getCell((short)7).setCellStyle(wSheet.getRow(1).getCell((short)7).getCellStyle());
/* 1035 */             wRow.getCell((short)7).setCellValue(rRow.getCell((short)7).getNumericCellValue());
/* 1036 */             counts[0][7] += rRow.getCell(7).getNumericCellValue();
/* 1037 */             if (wRow.getCell((short)8) == null) {
/* 1038 */               wRow.createCell((short)8);
/*      */             }
/* 1040 */             wRow.getCell((short)8).setCellStyle(wSheet.getRow(1).getCell((short)8).getCellStyle());
/* 1041 */             wRow.getCell((short)8).setCellValue(rRow.getCell((short)8).getNumericCellValue());
/* 1042 */             counts[0][8] += rRow.getCell(8).getNumericCellValue();
/* 1043 */             if (wRow.getCell((short)9) == null) {
/* 1044 */               wRow.createCell((short)9);
/*      */             }
/* 1046 */             xjsum = rRow.getCell((short)3).getNumericCellValue() + rRow.getCell((short)4).getNumericCellValue() + rRow.getCell((short)5).getNumericCellValue() + rRow.getCell((short)6).getNumericCellValue() + rRow.getCell((short)7).getNumericCellValue() + rRow.getCell((short)8).getNumericCellValue();
/*      */ 
/* 1052 */             wRow.getCell((short)9).setCellStyle(wSheet.getRow(1).getCell((short)9).getCellStyle());
/* 1053 */             wRow.getCell((short)9).setCellValue(xjsum);
/* 1054 */             counts[0][9] += xjsum;
/* 1055 */             if (wRow.getCell((short)10) == null) {
/* 1056 */               wRow.createCell((short)10);
/*      */             }
/* 1058 */             wRow.getCell((short)10).setCellStyle(wSheet.getRow(1).getCell((short)10).getCellStyle());
/* 1059 */             wRow.getCell((short)10).setCellValue(rRow.getCell((short)9).getNumericCellValue());
/* 1060 */             counts[0][10] += rRow.getCell(9).getNumericCellValue();
/* 1061 */             if (wRow.getCell((short)11) == null) {
/* 1062 */               wRow.createCell((short)11);
/*      */             }
/* 1064 */             wRow.getCell((short)11).setCellStyle(wSheet.getRow(1).getCell((short)11).getCellStyle());
/* 1065 */             wRow.getCell((short)11).setCellValue(rRow.getCell((short)10).getNumericCellValue());
/* 1066 */             counts[0][11] += rRow.getCell(10).getNumericCellValue();
/* 1067 */             if (wRow.getCell((short)12) == null) {
/* 1068 */               wRow.createCell((short)12);
/*      */             }
/* 1070 */             wRow.getCell((short)12).setCellStyle(wSheet.getRow(1).getCell((short)12).getCellStyle());
/* 1071 */             wRow.getCell((short)12).setCellValue(rRow.getCell((short)11).getNumericCellValue());
/* 1072 */             counts[0][12] += rRow.getCell(11).getNumericCellValue();
/* 1073 */             if (wRow.getCell((short)13) == null) {
/* 1074 */               wRow.createCell((short)13);
/*      */             }
/* 1076 */             wRow.getCell((short)13).setCellStyle(wSheet.getRow(1).getCell((short)13).getCellStyle());
/* 1077 */             wRow.getCell((short)13).setCellValue(rRow.getCell((short)12).getNumericCellValue());
/* 1078 */             counts[0][13] += rRow.getCell(12).getNumericCellValue();
/* 1079 */             if (wRow.getCell((short)14) == null) {
/* 1080 */               wRow.createCell((short)14);
/*      */             }
/* 1082 */             wRow.getCell((short)14).setCellStyle(wSheet.getRow(1).getCell((short)14).getCellStyle());
/* 1083 */             wRow.getCell((short)14).setCellValue(rRow.getCell((short)13).getNumericCellValue());
/* 1084 */             counts[0][14] += rRow.getCell(13).getNumericCellValue();
/* 1085 */             if (wRow.getCell((short)15) == null) {
/* 1086 */               wRow.createCell((short)15);
/*      */             }
/* 1088 */             xjsum = rRow.getCell((short)9).getNumericCellValue() + rRow.getCell((short)10).getNumericCellValue() + rRow.getCell((short)11).getNumericCellValue() + rRow.getCell((short)12).getNumericCellValue() + rRow.getCell((short)13).getNumericCellValue();
/*      */ 
/* 1093 */             wRow.getCell((short)15).setCellStyle(wSheet.getRow(1).getCell((short)15).getCellStyle());
/* 1094 */             wRow.getCell((short)15).setCellValue(xjsum);
/* 1095 */             counts[0][15] += xjsum;
/* 1096 */             if (wRow.getCell((short)16) == null) {
/* 1097 */               wRow.createCell((short)16);
/*      */             }
/* 1099 */             wRow.getCell((short)16).setCellStyle(wSheet.getRow(1).getCell((short)16).getCellStyle());
/* 1100 */             wRow.getCell((short)16).setCellValue(rRow.getCell((short)14).getNumericCellValue());
/* 1101 */             counts[0][16] += rRow.getCell(14).getNumericCellValue();
/* 1102 */             if (wRow.getCell((short)17) == null) {
/* 1103 */               wRow.createCell((short)17);
/*      */             }
/* 1105 */             wRow.getCell((short)17).setCellStyle(wSheet.getRow(1).getCell((short)17).getCellStyle());
/* 1106 */             wRow.getCell((short)17).setCellValue(rRow.getCell((short)15).getNumericCellValue());
/* 1107 */             counts[0][17] += rRow.getCell(15).getNumericCellValue();
/* 1108 */             if (wRow.getCell((short)18) == null) {
/* 1109 */               wRow.createCell((short)18);
/*      */             }
/* 1111 */             wRow.getCell((short)18).setCellStyle(wSheet.getRow(1).getCell((short)18).getCellStyle());
/* 1112 */             wRow.getCell((short)18).setCellValue(rRow.getCell((short)16).getNumericCellValue());
/* 1113 */             counts[0][18] += rRow.getCell(16).getNumericCellValue();
/* 1114 */             if (wRow.getCell((short)19) == null) {
/* 1115 */               wRow.createCell((short)19);
/*      */             }
/* 1117 */             wRow.getCell((short)19).setCellStyle(wSheet.getRow(1).getCell((short)19).getCellStyle());
/* 1118 */             wRow.getCell((short)19).setCellValue(rRow.getCell((short)17).getNumericCellValue());
/* 1119 */             counts[0][19] += rRow.getCell(17).getNumericCellValue();
/* 1120 */             if (wRow.getCell((short)20) == null) {
/* 1121 */               wRow.createCell((short)20);
/*      */             }
/* 1123 */             wRow.getCell((short)20).setCellStyle(wSheet.getRow(1).getCell((short)20).getCellStyle());
/* 1124 */             wRow.getCell((short)20).setCellValue(rRow.getCell((short)18).getNumericCellValue());
/* 1125 */             counts[0][20] += rRow.getCell(18).getNumericCellValue();
/* 1126 */             if (wRow.getCell((short)21) == null) {
/* 1127 */               wRow.createCell((short)21);
/*      */             }
/* 1129 */             xjsum = rRow.getCell((short)14).getNumericCellValue() + rRow.getCell((short)15).getNumericCellValue() + rRow.getCell((short)16).getNumericCellValue() + rRow.getCell((short)17).getNumericCellValue() + rRow.getCell((short)18).getNumericCellValue();
/*      */ 
/* 1134 */             wRow.getCell((short)21).setCellStyle(wSheet.getRow(1).getCell((short)21).getCellStyle());
/* 1135 */             wRow.getCell((short)21).setCellValue(xjsum);
/* 1136 */             counts[0][21] += xjsum;
/* 1137 */             if (wRow.getCell((short)22) == null) {
/* 1138 */               wRow.createCell((short)22);
/*      */             }
/* 1140 */             wRow.getCell((short)22).setCellStyle(wSheet.getRow(1).getCell((short)22).getCellStyle());
/* 1141 */             wRow.getCell((short)22).setCellValue(rRow.getCell((short)19).getNumericCellValue());
/* 1142 */             counts[0][22] += rRow.getCell(19).getNumericCellValue();
/* 1143 */             if (wRow.getCell((short)23) == null) {
/* 1144 */               wRow.createCell((short)23);
/*      */             }
/* 1146 */             wRow.getCell((short)23).setCellStyle(wSheet.getRow(1).getCell((short)23).getCellStyle());
/* 1147 */             wRow.getCell((short)23).setCellValue(rRow.getCell((short)20).getNumericCellValue());
/* 1148 */             counts[0][23] += rRow.getCell(20).getNumericCellValue();
/* 1149 */             if (wRow.getCell((short)24) == null) {
/* 1150 */               wRow.createCell((short)24);
/*      */             }
/* 1152 */             wRow.getCell((short)24).setCellStyle(wSheet.getRow(1).getCell((short)24).getCellStyle());
/* 1153 */             wRow.getCell((short)24).setCellValue(rRow.getCell((short)21).getNumericCellValue());
/* 1154 */             counts[0][24] += rRow.getCell(21).getNumericCellValue();
/* 1155 */             if (wRow.getCell((short)25) == null) {
/* 1156 */               wRow.createCell((short)25);
/*      */             }
/* 1158 */             wRow.getCell((short)25).setCellStyle(wSheet.getRow(1).getCell((short)25).getCellStyle());
/* 1159 */             wRow.getCell((short)25).setCellValue(rRow.getCell((short)22).getNumericCellValue());
/* 1160 */             counts[0][25] += rRow.getCell(22).getNumericCellValue();
/* 1161 */             if (wRow.getCell((short)26) == null) {
/* 1162 */               wRow.createCell((short)26);
/*      */             }
/* 1164 */             wRow.getCell((short)26).setCellStyle(wSheet.getRow(1).getCell((short)26).getCellStyle());
/* 1165 */             wRow.getCell((short)26).setCellValue(rRow.getCell((short)23).getNumericCellValue());
/* 1166 */             counts[0][26] += rRow.getCell(23).getNumericCellValue();
/* 1167 */             if (wRow.getCell((short)27) == null) {
/* 1168 */               wRow.createCell((short)27);
/*      */             }
/* 1170 */             wRow.getCell((short)27).setCellStyle(wSheet.getRow(1).getCell((short)27).getCellStyle());
/* 1171 */             wRow.getCell((short)27).setCellValue(rRow.getCell((short)24).getNumericCellValue());
/* 1172 */             counts[0][27] += rRow.getCell(24).getNumericCellValue();
/* 1173 */             if (wRow.getCell((short)28) == null) {
/* 1174 */               wRow.createCell((short)28);
/*      */             }
/* 1176 */             xjsum = rRow.getCell((short)20).getNumericCellValue() + rRow.getCell((short)21).getNumericCellValue() + rRow.getCell((short)22).getNumericCellValue() + rRow.getCell((short)23).getNumericCellValue() + rRow.getCell((short)24).getNumericCellValue();
/*      */ 
/* 1181 */             wRow.getCell((short)28).setCellStyle(wSheet.getRow(1).getCell((short)28).getCellStyle());
/* 1182 */             wRow.getCell((short)28).setCellValue(xjsum);
/* 1183 */             counts[0][28] += xjsum;
/* 1184 */             count++;
/*      */           }
/*      */         }
/* 1187 */       wRow = wSheet.getRow(count);
/* 1188 */       if (wRow == null) {
/* 1189 */         wRow = wSheet.createRow(count);
/*      */       }
/* 1191 */       for (short i = 0; i < 29; i = (short)(i + 1)) {
/* 1192 */         if (wRow.getCell(i) == null) {
/* 1193 */           wRow.createCell(i);
/*      */         }
/* 1195 */         if (i == 0) {
/* 1196 */           style = wRow.getCell(i).getCellStyle();
/* 1197 */           style.setFillForegroundColor((short)10);
/* 1198 */           style.setFillBackgroundColor((short)10);
/* 1199 */           font.setBoldweight((short)700);
/* 1200 */           style.setFont(font);
/* 1201 */           wRow.getCell(i).setCellType(1);
/* 1202 */           wRow.getCell(i).setCellValue(MpmLocaleUtil.getMessage("mcd.java.hj"));
/*      */         }
/* 1205 */         else if (i > 2)
/*      */         {
/* 1208 */           style = wRow.getCell(i).getCellStyle();
/* 1209 */           style.setFillForegroundColor((short)53);
/* 1210 */           style.setFillBackgroundColor((short)53);
/* 1211 */           style.setFont(font);
/* 1212 */           wRow.getCell(i).setCellStyle(style);
/* 1213 */           wRow.getCell(i).setCellValue(counts[0][i]);
/*      */         }
/*      */       } } catch (FileNotFoundException ex) { ex = 
/* 1222 */         ex;
/*      */ 
/* 1216 */       log.error("", ex); } catch (IOException ex2) {
/* 1217 */       ex2 = 
/* 1222 */         ex2;
/*      */ 
/* 1218 */       log.error("", ex2); } catch (Exception e) {
/* 1219 */       e = 
/* 1222 */         e;
/*      */ 
/* 1220 */       log.error("", e);
/*      */     } finally {
/*      */     }
/* 1223 */     FileOutputStream fos = null;
/* 1224 */     BufferedOutputStream bos = null;
/*      */     try {
/* 1226 */       Calendar cd = Calendar.getInstance();
/* 1227 */       FastDateFormat df = FastDateFormat.getInstance("yyyyMMddHHmmss");
/* 1228 */       destFileName = destFileName.replaceAll("report_template.xls", new StringBuilder().append(MpmLocaleUtil.getMessage("mcd.java.fgssbhz")).append(dateF).append("_").append(df.format(Calendar.getInstance().getTime())).append(".xls").toString());
/*      */ 
/* 1230 */       fos = new FileOutputStream(destFileName, false);
/* 1231 */       bos = new BufferedOutputStream(fos);
/* 1232 */       wbwrite.write(bos);
/* 1233 */       bos.flush();
/* 1234 */       fos.close();
/* 1235 */       bos.close();
/*      */     } catch (FileNotFoundException ex3) {
/* 1237 */       log.error("", ex3);
/* 1238 */       return null;
/*      */     } catch (IOException ex5) {
/* 1240 */       log.error("", ex5);
/* 1241 */       return null;
/*      */     }
/* 1243 */     return destFileName;
/*      */   }
/*      */ 
/*      */   public static String convertLongMillsToStrTime(long longMills)
/*      */   {
/* 1253 */     Calendar caldTmp = Calendar.getInstance();
/* 1254 */     caldTmp.setTimeInMillis(longMills);
/* 1255 */     StringBuffer res = new StringBuffer().append(caldTmp.get(1)).append("-").append(caldTmp.get(2) + 1).append("-").append(caldTmp.get(5)).append(" ").append(caldTmp.get(11)).append(":").append(caldTmp.get(12)).append(":").append(caldTmp.get(13));
/*      */ 
/* 1259 */     return res.toString();
/*      */   }
/*      */ 
/*      */   public static synchronized String convertLongMillsToYYYYMMDDHHMMSS(long longMills)
/*      */   {
/* 1269 */     Calendar caldTmp = Calendar.getInstance();
/* 1270 */     if (longMills > 0L)
/* 1271 */       caldTmp.setTimeInMillis(longMills);
/*      */     else {
/* 1273 */       caldTmp.setTimeInMillis(System.currentTimeMillis());
/*      */     }
/* 1275 */     StringBuffer res = new StringBuffer().append(caldTmp.get(1));
/* 1276 */     String tmpStr = String.valueOf(caldTmp.get(2) + 1);
/* 1277 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/* 1278 */     res.append(tmpStr);
/* 1279 */     tmpStr = String.valueOf(caldTmp.get(5));
/* 1280 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/* 1281 */     res.append(tmpStr);
/* 1282 */     res.append(caldTmp.get(11));
/* 1283 */     tmpStr = String.valueOf(caldTmp.get(12));
/* 1284 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/* 1285 */     res.append(tmpStr);
/* 1286 */     tmpStr = String.valueOf(caldTmp.get(13));
/* 1287 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/* 1288 */     res.append(tmpStr);
/* 1289 */     tmpStr = formatNumber(caldTmp.get(14), "000");
/* 1290 */     res.append(tmpStr);
/* 1291 */     return res.toString();
/*      */   }
/*      */ 
/*      */   public static synchronized String convertLongMillsToYYYYMMDDHHMMSSSSS()
/*      */   {
/* 1299 */     String timeStamp = "";
/* 1300 */     Calendar caldTmp = Calendar.getInstance();
/* 1301 */     caldTmp.setTimeInMillis(System.currentTimeMillis());
/* 1302 */     StringBuffer res = new StringBuffer().append(caldTmp.get(1));
/* 1303 */     String tmpStr = String.valueOf(caldTmp.get(2) + 1);
/* 1304 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/* 1305 */     res.append(tmpStr);
/* 1306 */     tmpStr = String.valueOf(caldTmp.get(5));
/* 1307 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/* 1308 */     res.append(tmpStr);
/* 1309 */     res.append(caldTmp.get(11));
/* 1310 */     tmpStr = String.valueOf(caldTmp.get(12));
/* 1311 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/* 1312 */     res.append(tmpStr);
/* 1313 */     tmpStr = String.valueOf(caldTmp.get(13));
/* 1314 */     tmpStr = tmpStr.length() < 2 ? new StringBuilder().append("0").append(tmpStr).toString() : tmpStr;
/* 1315 */     res.append(tmpStr);
/* 1316 */     tmpStr = formatNumber(caldTmp.get(14), "000");
/* 1317 */     res.append(tmpStr);
/* 1318 */     timeStamp = res.toString();
/* 1319 */     if (lastTabTime.equals(timeStamp))
/* 1320 */       timeStamp = convertLongMillsToYYYYMMDDHHMMSSSSS();
/*      */     else {
/* 1322 */       lastTabTime = timeStamp;
/*      */     }
/* 1324 */     return timeStamp;
/*      */   }
/*      */ 
/*      */   public static synchronized String getRandomTimeStr(int length)
/*      */   {
/* 1333 */     FastDateFormat df = FastDateFormat.getInstance("yyyyMMddHHmmss");
/* 1334 */     String dateStr = df.format(new Date());
/* 1335 */     if (length > 0) {
/* 1336 */       if (dateStr.length() < length)
/* 1337 */         dateStr = new StringBuilder().append(dateStr).append(genFixLenNumStr(length - dateStr.length())).toString();
/* 1338 */       else if (dateStr.length() > length) {
/* 1339 */         dateStr = dateStr.substring(0, length);
/*      */       }
/*      */     }
/* 1342 */     return dateStr;
/*      */   }
/*      */ 
/*      */   public static synchronized String generateCampsegAndTaskNo()
/*      */   {
/* 1351 */     FastDateFormat df = FastDateFormat.getInstance("yyyyMMddHHmmssSSS");
/* 1352 */     String dateStr = df.format(new Date());
/* 1353 */     String noLen = MpmConfigure.getInstance().getProperty("CAMPSEG_TASK_NO_LENGTH");
/* 1354 */     if (StringUtil.isNotEmpty(noLen)) {
/* 1355 */       int len = Integer.valueOf(noLen).intValue();
/* 1356 */       if (dateStr.length() < len)
/* 1357 */         dateStr = new StringBuilder().append(dateStr).append(genFixLenNumStr(len - dateStr.length())).toString();
/* 1358 */       else if (dateStr.length() > len) {
/* 1359 */         dateStr = dateStr.substring(0, len);
/*      */       }
/*      */     }
/* 1362 */     return dateStr;
/*      */   }
/*      */ 
/*      */   public static synchronized String generateTestTaskNo()
/*      */   {
/* 1370 */     String dateStr = "00000000000000000";
/* 1371 */     String noLen = MpmConfigure.getInstance().getProperty("CAMPSEG_TASK_NO_LENGTH");
/* 1372 */     if (StringUtil.isNotEmpty(noLen)) {
/* 1373 */       int len = Integer.valueOf(noLen).intValue();
/* 1374 */       if (dateStr.length() < len) {
/* 1375 */         for (int i = 0; i < len - dateStr.length(); i++)
/* 1376 */           dateStr = new StringBuilder().append(dateStr).append("0").toString();
/*      */       }
/* 1378 */       else if (dateStr.length() > len) {
/* 1379 */         dateStr = dateStr.substring(0, len);
/*      */       }
/*      */     }
/* 1382 */     return dateStr;
/*      */   }
/*      */ 
/*      */   public static String genFixLenNumStr(int len)
/*      */   {
/* 1391 */     StringBuffer sb = new StringBuffer();
/* 1392 */     for (int i = 0; i < len; i++) {
/* 1393 */       int index = (int)(Math.random() * 10.0D);
/* 1394 */       sb.append(NUM_DATA[index]);
/*      */     }
/* 1396 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static boolean isNumeric(String str)
/*      */   {
/* 1406 */     if (StringUtil.isEmpty(str)) {
/* 1407 */       return false;
/*      */     }
/* 1409 */     Pattern pattern = Pattern.compile("[0-9]*");
/* 1410 */     Matcher isNum = pattern.matcher(str);
/* 1411 */     if (!isNum.matches()) {
/* 1412 */       return false;
/*      */     }
/* 1414 */     return true;
/*      */   }
/*      */ 
/*      */   public static String percentStr(int count, int sum, String fStr)
/*      */   {
/* 1429 */     if ((count == 0) || (sum == 0)) {
/* 1430 */       return "0%";
/*      */     }
/* 1432 */     DecimalFormat myformat = null;
/* 1433 */     myformat = (DecimalFormat)NumberFormat.getPercentInstance();
/* 1434 */     if (StringUtil.isEmpty(fStr))
/* 1435 */       myformat.applyPattern("0%");
/*      */     else {
/* 1437 */       myformat.applyPattern(fStr);
/*      */     }
/* 1439 */     double rat = count / sum;
/* 1440 */     return myformat.format(rat);
/*      */   }
/*      */ 
/*      */   public static String formatSqlInString(String strInString)
/*      */   {
/* 1451 */     String strResult = strInString;
/* 1452 */     String[] arrayStr = null;
/* 1453 */     if ((strResult != null) && (strResult.indexOf("'") == -1)) {
/* 1454 */       strResult = "";
/* 1455 */       arrayStr = strInString.split("\\,");
/* 1456 */       if (arrayStr.length > 0) {
/* 1457 */         for (int i = 0; i < arrayStr.length; i++) {
/* 1458 */           strResult = new StringBuilder().append(strResult).append("'").append(arrayStr[i]).append("'").toString();
/* 1459 */           if (i != arrayStr.length - 1) {
/* 1460 */             strResult = new StringBuilder().append(strResult).append(",").toString();
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1467 */     return strResult;
/*      */   }
/*      */ 
/*      */   public static String getToday(String strType)
/*      */   {
/* 1472 */     FastDateFormat sdf = FastDateFormat.getInstance("yyyy-MM-dd");
/* 1473 */     String strDateStr = sdf.format(new Date());
/* 1474 */     if (strDateStr.indexOf("0000-00-00") >= 0) {
/* 1475 */       return "null";
/*      */     }
/* 1477 */     String strRet = "";
/* 1478 */     int i = strDateStr.indexOf(" ");
/* 1479 */     if (i > 0) {
/* 1480 */       strDateStr = strDateStr.substring(0, i);
/*      */     }
/* 1482 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1483 */       strRet = new StringBuilder("'").append(strDateStr).append("'").toString();
/* 1484 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1485 */       strRet = new StringBuilder("date('").append(strDateStr).append("')").toString();
/* 1486 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1487 */       strRet = new StringBuilder("to_date('").append(strDateStr).append("','YYYY-mm-dd')").toString();
/* 1488 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1489 */       strRet = new StringBuilder("'").append(strDateStr).append("'").toString();
/* 1490 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/* 1491 */       strRet = new StringBuilder("convert(varchar(10), convert(datetime,'").append(strDateStr).append("'), 111)").toString();
/*      */     }
/* 1493 */     else if (strType.equalsIgnoreCase("TERA")) {
/* 1494 */       strRet = new StringBuilder("cast('").append(strDateStr).append("' as date FORMAT 'YYYY-MM-DD')").toString();
/*      */     }
/* 1496 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 1497 */       strRet = new StringBuilder("cast('").append(strDateStr).append("' as Date)").toString();
/*      */     }
/* 1499 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String convertPercentStr(Object obj, String fStr)
/*      */   {
/* 1512 */     DecimalFormat myformat = null;
/* 1513 */     myformat = (DecimalFormat)NumberFormat.getPercentInstance();
/* 1514 */     if (StringUtil.isEmpty(fStr))
/* 1515 */       myformat.applyPattern("0%");
/*      */     else {
/* 1517 */       myformat.applyPattern(fStr);
/*      */     }
/* 1519 */     float value = Float.parseFloat(obj.toString()) / 100.0F;
/* 1520 */     return myformat.format(value);
/*      */   }
/*      */ 
/*      */   public static String parseInDate(String date)
/*      */   {
/* 1530 */     if (DATE_FORMAT_IS_DEFAULT) {
/* 1531 */       return date;
/*      */     }
/* 1533 */     String parsed = "";
/*      */     try {
/* 1535 */       parsed = DateUtil.date2String(DATE_US_FORMATER.parse(date), "yyyy-MM-dd");
/*      */     } catch (Exception e) {
/* 1537 */       log.debug(new StringBuilder().append("--------date parse to in error, orign date is ").append(date).toString());
/* 1538 */       parsed = date;
/*      */     }
/*      */ 
/* 1541 */     return parsed;
/*      */   }
/*      */ 
/*      */   public static String parseOutDate(String date)
/*      */   {
/* 1551 */     if (DATE_FORMAT_IS_DEFAULT) {
/* 1552 */       return date;
/*      */     }
/* 1554 */     String parsed = "";
/*      */     try {
/* 1556 */       parsed = DATE_US_FORMATER.format(DateUtil.string2Date(date, "yyyy-MM-dd"));
/*      */     } catch (Exception e) {
/* 1558 */       log.debug(new StringBuilder().append("--------date parse to out error, orign date is ").append(date).toString());
/* 1559 */       parsed = date;
/*      */     }
/* 1561 */     return parsed;
/*      */   }
/*      */ 
/*      */   public static String parseOutDateYM(String date)
/*      */   {
/* 1571 */     if (DATE_FORMAT_IS_DEFAULT) {
/* 1572 */       return date;
/*      */     }
/* 1574 */     String parsed = "";
/*      */     try {
/* 1576 */       parsed = DATE_US_FORMATER_YM.format(DateUtil.string2Date(date, "yyyy-MM"));
/*      */     } catch (Exception e) {
/* 1578 */       log.debug(new StringBuilder().append("--------date parse to out error, orign date is ").append(date).toString());
/* 1579 */       parsed = date;
/*      */     }
/* 1581 */     return parsed;
/*      */   }
/*      */ 
/*      */   public static String parseOutNumber(Object date)
/*      */   {
/* 1591 */     if (date == null) {
/* 1592 */       return "--";
/*      */     }
/* 1594 */     String parsed = "";
/* 1595 */     if ((date instanceof String))
/* 1596 */       date = Double.valueOf(Double.parseDouble((String)date));
/*      */     try
/*      */     {
/* 1599 */       parsed = decimalFormat.format(date);
/*      */     } catch (Exception e) {
/* 1601 */       log.debug(new StringBuilder().append("--------date parse to out error, orign date is ").append(date).toString());
/*      */     }
/* 1603 */     return parsed;
/*      */   }
/*      */ 
/*      */   public static String getSqlRound(String str1, String str2) throws Exception {
/* 1607 */     String strType = getDBType();
/* 1608 */     String strRet = "";
/* 1609 */     if (strType.equalsIgnoreCase("TERA")) {
/* 1610 */       strRet = new StringBuilder().append(" cast ((").append(str1).append(") as decimal(10,").append(str2).append(")) ").toString();
/*      */     }
/*      */     else {
/* 1613 */       strRet = new StringBuilder().append(" round(").append(str1).append(",").append(str2).append(") ").toString();
/*      */     }
/*      */ 
/* 1616 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String getSqlNvl(String str1, String str2) throws Exception {
/* 1620 */     String strType = getDBType();
/* 1621 */     String strRet = "";
/* 1622 */     if (strType.equalsIgnoreCase("DB2")) {
/* 1623 */       strRet = new StringBuilder().append("value(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/* 1625 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("POSTGRESQL")))
/* 1626 */       strRet = new StringBuilder().append("nvl(").append(str1).append(",").append(str2).append(")").toString();
/* 1627 */     else if (strType.equalsIgnoreCase("MYSQL")) {
/* 1628 */       strRet = new StringBuilder().append("ifnull(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/* 1630 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 1631 */       strRet = new StringBuilder().append("isnull(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/* 1633 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/* 1634 */       strRet = new StringBuilder().append("isnull(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/* 1636 */     else if (strType.equalsIgnoreCase("TERA")) {
/* 1637 */       strRet = new StringBuilder().append("COALESCE(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/*      */     else {
/* 1640 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 1642 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String parseOutInteger(Object date)
/*      */   {
/* 1652 */     if (date == null) {
/* 1653 */       return "--";
/*      */     }
/* 1655 */     String parsed = "";
/* 1656 */     if ((date instanceof String))
/* 1657 */       date = Double.valueOf(Double.parseDouble((String)date));
/*      */     try
/*      */     {
/* 1660 */       parsed = integerFormat.format(date);
/*      */     } catch (Exception e) {
/* 1662 */       log.debug(new StringBuilder().append("--------date parse to out error, orign date is ").append(date).toString());
/*      */     }
/* 1664 */     return parsed;
/*      */   }
/*      */ 
/*      */   public static String addBracket(String data)
/*      */   {
/* 1674 */     if (null == data) {
/* 1675 */       return "0";
/*      */     }
/*      */ 
/* 1678 */     return new StringBuilder().append(" (").append(data).append(")").toString();
/*      */   }
/*      */ 
/*      */   public static String parseInNumber(String date)
/*      */   {
/* 1688 */     if (date == null) {
/* 1689 */       return null;
/*      */     }
/* 1691 */     String parsed = null;
/*      */     try {
/* 1693 */       parsed = dbDecimalFormat.format(decimalFormat.parse(date));
/*      */     } catch (Exception e) {
/* 1695 */       log.debug(new StringBuilder().append("--------date parse to out error, orign date is ").append(date).toString());
/* 1696 */       return null;
/*      */     }
/* 1698 */     return parsed;
/*      */   }
/*      */ 
/*      */   public static String date2String(Date date)
/*      */   {
/* 1708 */     if (date == null) {
/* 1709 */       return "";
/*      */     }
/* 1711 */     String parsed = "";
/*      */     try {
/* 1713 */       if (DATE_FORMAT_IS_DEFAULT)
/* 1714 */         parsed = DateUtil.date2String(date, DATE_LOCALE_FORMAT);
/*      */       else
/* 1716 */         parsed = DATE_US_FORMATER.format(date);
/*      */     }
/*      */     catch (Exception e) {
/* 1719 */       log.debug(new StringBuilder().append("--------date parse to out error, orign date is ").append(date).toString());
/* 1720 */       parsed = "";
/*      */     }
/* 1722 */     return parsed;
/*      */   }
/*      */ 
/*      */   public static String replaceSingleQuotes(String replaced)
/*      */   {
/* 1732 */     if (StringUtil.isEmpty(replaced)) {
/* 1733 */       return null;
/*      */     }
/*      */ 
/* 1736 */     replaced = replaced.replace("'", "&apos;");
/*      */ 
/* 1738 */     return replaced;
/*      */   }
/*      */ 
/*      */   public static void main(String[] args) {
/* 1742 */     long s = System.currentTimeMillis();
/* 1743 */     log.debug(convertLongMillsToStrTime(s));
/* 1744 */     log.debug(convertLongMillsToYYYYMMDDHHMMSS(s));
/*      */   }
/*      */ 
/*      */   public static int getPid()
/*      */   {
/* 1750 */     RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
/* 1751 */     String name = runtime.getName();
/*      */     try {
/* 1753 */       return Integer.parseInt(name.substring(0, name.indexOf(64))); } catch (Exception e) {
/*      */     }
/* 1755 */     return -1;
/*      */   }
/*      */ 
/*      */   public static String getDateForCustGroup(int flag)
/*      */   {
/* 1764 */     Calendar calendar = Calendar.getInstance();
/* 1765 */     String currentDate = DateUtil.date2String(calendar.getTime(), "yyyy-MM-dd");
/* 1766 */     if (flag == 1) {
/* 1767 */       calendar.add(6, -1);
/* 1768 */       currentDate = DateUtil.date2String(calendar.getTime(), "yyyy-MM-dd");
/* 1769 */     } else if (flag == 2) {
/* 1770 */       calendar.add(2, -1);
/* 1771 */       calendar.set(5, 1);
/* 1772 */       currentDate = DateUtil.date2String(calendar.getTime(), "yyyy-MM-dd");
/* 1773 */     } else if (flag == 3) {
/* 1774 */       int dayofweek = calendar.get(7) - 1;
/* 1775 */       if (dayofweek == 0) {
/* 1776 */         dayofweek = 7;
/*      */       }
/* 1778 */       calendar.add(5, -dayofweek - 7);
/* 1779 */       currentDate = DateUtil.date2String(calendar.getTime(), "yyyy-MM-dd");
/*      */     }
/*      */     else {
/* 1782 */       calendar.add(2, -1);
/* 1783 */       calendar.set(5, 1);
/* 1784 */       currentDate = DateUtil.date2String(calendar.getTime(), "yyyy-MM-dd");
/*      */     }
/*      */ 
/* 1787 */     return currentDate;
/*      */   }
/*      */ 
/*      */   public static String getLastMonth()
/*      */   {
/* 1793 */     String currentDate = getDateForCustGroup(2);
/* 1794 */     return currentDate;
/*      */   }
/*      */ 
/*      */   public static String getYesterday()
/*      */   {
/* 1799 */     String currentDate = getDateForCustGroup(1);
/* 1800 */     return currentDate;
/*      */   }
/*      */ 
/*      */   public static String getLastWeek()
/*      */   {
/* 1805 */     String currentDate = getDateForCustGroup(3);
/* 1806 */     return currentDate;
/*      */   }
/*      */ 
/*      */   public static final String escapeHTML(String s) {
/* 1810 */     if (s == null) {
/* 1811 */       return "";
/*      */     }
/* 1813 */     StringBuffer sb = new StringBuffer();
/* 1814 */     int n = s.length();
/* 1815 */     for (int i = 0; i < n; i++) {
/* 1816 */       char c = s.charAt(i);
/* 1817 */       switch (c) {
/*      */       case '<':
/* 1819 */         sb.append("&lt;");
/* 1820 */         break;
/*      */       case '>':
/* 1822 */         sb.append("&gt;");
/* 1823 */         break;
/*      */       case '&':
/* 1825 */         sb.append("&amp;");
/* 1826 */         break;
/*      */       case '"':
/* 1828 */         sb.append("&quot;");
/* 1829 */         break;
/*      */       case '€':
/* 1831 */         sb.append("&euro;");
/* 1832 */         break;
/*      */       case ' ':
/* 1834 */         sb.append("&nbsp;");
/* 1835 */         break;
/*      */       default:
/* 1837 */         sb.append(c);
/*      */       }
/*      */     }
/*      */ 
/* 1841 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String replace2(String source, String oldString, String newString)
/*      */   {
/* 1853 */     if (StringUtil.isEmpty(source)) {
/* 1854 */       return "";
/*      */     }
/* 1856 */     StringBuffer output = new StringBuffer();
/* 1857 */     int lengthOfSource = source.length();
/* 1858 */     int lengthOfOld = oldString.length();
/*      */     int pos;
/* 1861 */     for (int posStart = 0; (pos = source.indexOf(oldString, posStart)) >= 0; posStart = pos + lengthOfOld) {
/* 1862 */       output.append(source.substring(posStart, pos));
/* 1863 */       output.append(newString);
/*      */     }
/*      */ 
/* 1866 */     if (posStart < lengthOfSource) {
/* 1867 */       output.append(source.substring(posStart));
/*      */     }
/* 1869 */     return output.toString();
/*      */   }
/*      */ 
/*      */   public static String getSql2DateWithFormat(String sDateStr, String format) throws Exception {
/* 1873 */     String dbType = getDBType();
/* 1874 */     String strRet = sDateStr;
/* 1875 */     if (dbType.equalsIgnoreCase("DB2"))
/* 1876 */       strRet = new StringBuilder().append("date('").append(sDateStr).append("')").toString();
/* 1877 */     else if (dbType.equalsIgnoreCase("ORACLE")) {
/* 1878 */       strRet = new StringBuilder().append("to_date('").append(sDateStr).append("','").append(format).append("')").toString();
/*      */     }
/* 1880 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String getSql2Date(String dbType, String sDateStr, String splitStr)
/*      */     throws Exception
/*      */   {
/* 1891 */     String strDateStr = sDateStr;
/* 1892 */     if (StringUtil.isEmpty(strDateStr)) {
/* 1893 */       return null;
/*      */     }
/* 1895 */     if (strDateStr.indexOf("0000-00-00") >= 0) {
/* 1896 */       return "null";
/*      */     }
/* 1898 */     String strRet = "";
/* 1899 */     int i = strDateStr.indexOf(" ");
/* 1900 */     if (i > 0) {
/* 1901 */       strDateStr = strDateStr.substring(0, i);
/*      */     }
/*      */ 
/* 1904 */     if ((dbType.equalsIgnoreCase("MYSQL")) || (dbType.equalsIgnoreCase("GBASE")))
/* 1905 */       strRet = new StringBuilder().append("'").append(strDateStr).append("'").toString();
/* 1906 */     else if (dbType.equalsIgnoreCase("DB2"))
/* 1907 */       strRet = new StringBuilder().append("date('").append(strDateStr).append("')").toString();
/* 1908 */     else if ((dbType.equalsIgnoreCase("ORACLE")) || (dbType.equalsIgnoreCase("POSTGRESQL"))) {
/* 1909 */       if ("-".equals(splitStr))
/* 1910 */         strRet = new StringBuilder().append("to_date('").append(strDateStr).append("','YYYY-mm-dd')").toString();
/*      */       else
/* 1912 */         strRet = new StringBuilder().append("to_date('").append(strDateStr).append("','YYYY/mm/dd')").toString();
/*      */     }
/* 1914 */     else if (dbType.equalsIgnoreCase("ACESS"))
/* 1915 */       strRet = new StringBuilder().append("'").append(strDateStr).append("'").toString();
/* 1916 */     else if (dbType.equalsIgnoreCase("SQLSERVER")) {
/* 1917 */       if ("-".equals(splitStr))
/* 1918 */         strRet = new StringBuilder().append("convert(varchar(10), convert(datetime,'").append(strDateStr).append("'), 111)").toString();
/*      */       else
/* 1920 */         strRet = new StringBuilder().append("CONVERT(Datetime,'").append(strDateStr).append("',20)").toString();
/*      */     }
/* 1922 */     else if (dbType.equalsIgnoreCase("TERA")) {
/* 1923 */       if ("-".equals(splitStr))
/* 1924 */         strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as date FORMAT 'YYYY-MM-DD')").toString();
/*      */       else
/* 1926 */         strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as date FORMAT 'YYYY/MM/DD')").toString();
/*      */     }
/* 1928 */     else if (dbType.equalsIgnoreCase("SYBASE"))
/* 1929 */       strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as Date)").toString();
/*      */     else {
/* 1931 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1933 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String getSql2DateCol(String dbType, String colName, String splitStr)
/*      */     throws Exception
/*      */   {
/* 1944 */     String colNameStr = colName;
/* 1945 */     if (StringUtil.isEmpty(colNameStr)) {
/* 1946 */       return null;
/*      */     }
/* 1948 */     String strRet = "";
/*      */ 
/* 1950 */     if ((dbType.equalsIgnoreCase("MYSQL")) || (dbType.equalsIgnoreCase("GBASE")))
/* 1951 */       strRet = colNameStr;
/* 1952 */     else if (dbType.equalsIgnoreCase("DB2"))
/* 1953 */       strRet = new StringBuilder().append("date(").append(colNameStr).append(")").toString();
/* 1954 */     else if ((dbType.equalsIgnoreCase("ORACLE")) || (dbType.equalsIgnoreCase("POSTGRESQL"))) {
/* 1955 */       if ("-".equals(splitStr))
/* 1956 */         strRet = new StringBuilder().append("to_date(").append(colNameStr).append(",'YYYY-mm-dd')").toString();
/*      */       else
/* 1958 */         strRet = new StringBuilder().append("to_date(").append(colNameStr).append(",'YYYY/mm/dd')").toString();
/*      */     }
/* 1960 */     else if (dbType.equalsIgnoreCase("ACESS"))
/* 1961 */       strRet = colNameStr;
/* 1962 */     else if (dbType.equalsIgnoreCase("SQLSERVER")) {
/* 1963 */       if ("-".equals(splitStr))
/* 1964 */         strRet = new StringBuilder().append("convert(varchar(10), convert(datetime,").append(colNameStr).append("), 111)").toString();
/*      */       else
/* 1966 */         strRet = new StringBuilder().append("CONVERT(Datetime,").append(colNameStr).append(",20)").toString();
/*      */     }
/* 1968 */     else if (dbType.equalsIgnoreCase("TERA")) {
/* 1969 */       if ("-".equals(splitStr))
/* 1970 */         strRet = new StringBuilder().append("cast(").append(colNameStr).append(" as date FORMAT 'YYYY-MM-DD')").toString();
/*      */       else
/* 1972 */         strRet = new StringBuilder().append("cast(").append(colNameStr).append(" as date FORMAT 'YYYY/MM/DD')").toString();
/*      */     }
/* 1974 */     else if (dbType.equalsIgnoreCase("SYBASE"))
/* 1975 */       strRet = new StringBuilder().append("cast(").append(colNameStr).append(" as Date)").toString();
/*      */     else {
/* 1977 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1979 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String getRealConcatedColumns(String dbType, String concatedCols)
/*      */     throws Exception
/*      */   {
/* 1990 */     String realConcatStr = "";
/* 1991 */     if (StringUtil.isNotEmpty(concatedCols)) {
/* 1992 */       realConcatStr = getConcatSqlStr(dbType, (Object[])concatedCols.split("\\|\\|"));
/*      */     }
/* 1994 */     return realConcatStr;
/*      */   }
/*      */ 
/*      */   public static String getConcatSqlStr(String dbType, Object[] values)
/*      */   {
/* 2004 */     StringBuffer sb = new StringBuffer();
/*      */ 
/* 2006 */     if ((dbType.equalsIgnoreCase("db2")) || (dbType.equalsIgnoreCase("oracle")) || (dbType.equalsIgnoreCase("POSTGRESQL")))
/*      */     {
/* 2008 */       sb.append(jionStr("||", values));
/* 2009 */       return sb.toString();
/*      */     }
/*      */ 
/* 2012 */     if (dbType.equalsIgnoreCase("SQL Server")) {
/* 2013 */       sb.append(jionStr("+", values));
/* 2014 */       return sb.toString();
/*      */     }
/*      */ 
/* 2017 */     if ((dbType.equalsIgnoreCase("MySQL")) || (dbType.equalsIgnoreCase("gbase"))) {
/* 2018 */       sb.append("CONCAT(");
/* 2019 */       sb.append(jionStr(",", values));
/* 2020 */       sb.append(")");
/* 2021 */       return sb.toString();
/*      */     }
/*      */ 
/* 2024 */     return null;
/*      */   }
/*      */ 
/*      */   public static String jionStr(String sep, Object[] values)
/*      */   {
/* 2034 */     StringBuffer sb = new StringBuffer();
/* 2035 */     if (values.length > 0) {
/* 2036 */       int index = 0;
/* 2037 */       for (Object col : values) {
/* 2038 */         if (index != 0) {
/* 2039 */           sb.append(sep);
/*      */         }
/* 2041 */         sb.append(col);
/* 2042 */         index++;
/*      */       }
/*      */     }
/* 2045 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Date getDate(String date) throws Exception {
/* 2049 */     Date d = null;
/* 2050 */     DateFormat sd = new SimpleDateFormat("yyyyMMdd");
/* 2051 */     String dateStr = "";
/* 2052 */     if ((StringUtil.isNotEmpty(date)) && (date.length() == 6))
/* 2053 */       dateStr = new StringBuilder().append(date).append("01").toString();
/* 2054 */     else if ((StringUtil.isNotEmpty(date)) && (date.length() == 4))
/* 2055 */       dateStr = new StringBuilder().append(date).append("0101").toString();
/*      */     else {
/* 2057 */       dateStr = date;
/*      */     }
/* 2059 */     if (StringUtil.isNotEmpty(dateStr)) {
/* 2060 */       d = sd.parse(dateStr);
/*      */     }
/* 2062 */     return d;
/*      */   }
/*      */ 
/*      */   public static Date getDate(String date, String format) throws Exception {
/* 2066 */     Date d = null;
/* 2067 */     DateFormat sd = new SimpleDateFormat(format);
/* 2068 */     if (StringUtil.isNotEmpty(date))
/* 2069 */       d = sd.parse(date);
/*      */     else {
/* 2071 */       throw new Exception("The data date is empty!Please check it!");
/*      */     }
/* 2073 */     return d;
/*      */   }
/*      */ 
/*      */   public static <T> List<List<T>> splitList(List<T> list, int rowSize)
/*      */   {
/* 2083 */     List lists = new ArrayList();
/* 2084 */     if ((list != null) && (!list.isEmpty()) && (rowSize > 0)) {
/* 2085 */       int remainder = list.size() % rowSize;
/* 2086 */       int intPart = list.size() / rowSize;
/* 2087 */       for (int i = 0; i < intPart; i++) {
/* 2088 */         lists.add(list.subList(i * rowSize, (i + 1) * rowSize));
/*      */       }
/* 2090 */       if (remainder > 0) {
/* 2091 */         lists.add(list.subList(intPart * rowSize, intPart * rowSize + remainder));
/*      */       }
/*      */     }
/* 2094 */     return lists;
/*      */   }
/*      */ 
/*      */   public static String hql2sql(String hql)
/*      */   {
/* 2106 */     long startTime = System.currentTimeMillis();
/* 2107 */     SessionFactory sf = (SessionFactory)SpringContext.getBean("dataSourceAPP", SessionFactory.class);
/* 2108 */     SessionFactoryImplementor sfi = (SessionFactoryImpl)sf;
/* 2109 */     QueryTranslatorFactory qft = sfi.getSettings().getQueryTranslatorFactory();
/* 2110 */     Map m = new HashMap();
/* 2111 */     QueryTranslator qt = qft.createQueryTranslator(hql, hql, new HashMap(), sfi);
/* 2112 */     qt.compile(m, false);
/* 2113 */     log.debug(new StringBuilder().append("hql2sql used time:").append((System.currentTimeMillis() - startTime) / 1000L).append("s").toString());
/* 2114 */     return qt.getSQLString();
/*      */   }
/*      */ 
/*      */   public static String phoneNumberZeroAdd(short phoneNumber)
/*      */   {
/* 2123 */     return phoneNumberFormat.format(phoneNumber);
/*      */   }
/*      */ 
/*      */   public static String formatNumber(long number, String format)
/*      */   {
/* 2133 */     DecimalFormat numberFormat = new DecimalFormat(format);
/* 2134 */     return numberFormat.format(number);
/*      */   }
/*      */ 
/*      */   public static String formatPhoneNo(short num) {
/* 2138 */     String str = String.valueOf(num);
/* 2139 */     int n = str.length();
/* 2140 */     StringBuilder sb = new StringBuilder();
/* 2141 */     switch (n) {
/*      */     case 1:
/* 2143 */       sb.append("000").append(str);
/* 2144 */       break;
/*      */     case 2:
/* 2146 */       sb.append("00").append(str);
/* 2147 */       break;
/*      */     case 3:
/* 2149 */       sb.append("0").append(str);
/* 2150 */       break;
/*      */     case 4:
/* 2152 */       sb.append(str);
/* 2153 */       break;
/*      */     default:
/* 2155 */       sb.append(str);
/*      */     }
/*      */ 
/* 2158 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String getSqlCreateAsTable(String newTab, String tmpTable)
/*      */   {
/* 2169 */     StringBuilder strRet = new StringBuilder();
/* 2170 */     String tabSpace = Configure.getInstance().getProperty("MPM_TABLESPACE");
/* 2171 */     String dbType = getDBType();
/* 2172 */     if ((dbType.equalsIgnoreCase("ORACLE")) || (dbType.equalsIgnoreCase("POSTGRESQL"))) {
/* 2173 */       if (StringUtil.isNotEmpty(tabSpace)) {
/* 2174 */         strRet.append("create table ").append(newTab).append(" tablespace ").append(tabSpace).append(" as select * from ").append(tmpTable).append(" where 1=2 ");
/*      */       }
/*      */       else {
/* 2177 */         strRet.append("create table ").append(newTab).append(" as select * from ").append(tmpTable).append(" where 1=2 ");
/*      */       }
/*      */     }
/* 2180 */     else if (dbType.equalsIgnoreCase("DB2")) {
/* 2181 */       if (StringUtil.isNotEmpty(tabSpace)) {
/* 2182 */         strRet.append("create table ").append(newTab).append(" like ").append(tmpTable).append(" in ").append(tabSpace).append(" NOT LOGGED INITIALLY ");
/*      */       }
/*      */       else {
/* 2185 */         strRet.append("create table ").append(newTab).append(" like ").append(tmpTable).append(" NOT LOGGED INITIALLY ");
/*      */       }
/*      */     }
/* 2188 */     else if (dbType.equalsIgnoreCase("MYSQL")) {
/* 2189 */       strRet.append("create table ").append(newTab).append(" as select * from ").append(tmpTable).append(" where 1=2 ");
/*      */     }
/*      */ 
/* 2192 */     return strRet.toString();
/*      */   }
/*      */ 
/*      */   public static String getChartSetName(String str)
/*      */   {
/* 2202 */     if (null != str) {
/* 2203 */       String encode = "ISO-8859-1";
/*      */       try {
/* 2205 */         if (str.equals(new String(str.getBytes(encode), encode)))
/* 2206 */           return encode;
/*      */       }
/*      */       catch (Exception exception)
/*      */       {
/*      */       }
/* 2211 */       encode = "GB2312";
/*      */       try {
/* 2213 */         if (str.equals(new String(str.getBytes(encode), encode)))
/* 2214 */           return encode;
/*      */       }
/*      */       catch (Exception exception1)
/*      */       {
/*      */       }
/* 2219 */       encode = "UTF-8";
/*      */       try {
/* 2221 */         if (str.equals(new String(str.getBytes(encode), encode)))
/* 2222 */           return encode;
/*      */       }
/*      */       catch (Exception exception2)
/*      */       {
/*      */       }
/* 2227 */       encode = "GBK";
/*      */       try {
/* 2229 */         if (str.equals(new String(str.getBytes(encode), encode))) {
/* 2230 */           return encode;
/*      */         }
/*      */       }
/*      */       catch (Exception exception3)
/*      */       {
/*      */       }
/*      */     }
/* 2237 */     return "";
/*      */   }
/*      */ 
/*      */   public static String getSql2DateNow() {
/* 2241 */     String strType = getDBType();
/* 2242 */     String strRet = "";
/* 2243 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 2244 */       strRet = "now()";
/* 2245 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 2246 */       strRet = "sysdate";
/* 2247 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 2248 */       strRet = "date()";
/* 2249 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 2250 */       strRet = "getdate()";
/* 2251 */     else if (strType.equalsIgnoreCase("DB2"))
/* 2252 */       strRet = "current date";
/* 2253 */     else if (strType.equalsIgnoreCase("POSTGRESQL"))
/* 2254 */       strRet = "current_date";
/* 2255 */     else if (strType.equalsIgnoreCase("TERA"))
/* 2256 */       strRet = "cast((date (format 'yyyy-mm-dd' )) as char(10)) ||' '|| time";
/* 2257 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 2258 */       strRet = "getdate()";
/*      */     }
/* 2260 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String getSql2DateYesterday() {
/* 2264 */     String strType = getDBType();
/* 2265 */     String strRet = "";
/* 2266 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 2267 */       strRet = "date_sub(now(),interval 1 day)";
/* 2268 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 2269 */       strRet = "sysdate -1";
/* 2270 */     else if (strType.equalsIgnoreCase("DB2"))
/* 2271 */       strRet = "current date - 1 day";
/* 2272 */     else if (strType.equalsIgnoreCase("POSTGRESQL")) {
/* 2273 */       strRet = "current_date - interval '1 day'";
/*      */     }
/* 2275 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String[] splitStr(String str, String del) {
/* 2279 */     Vector vect = StringUtil.getVector(str, del);
/* 2280 */     int num = vect.size();
/* 2281 */     String[] strArray = new String[num];
/* 2282 */     for (int i = 0; i < num; i++) {
/* 2283 */       strArray[i] = ((String)vect.elementAt(i));
/*      */     }
/* 2285 */     return strArray;
/*      */   }
/*      */ 
/*      */   public static String getTwoDbDateOptByDays(String date1, String date2, String opt) {
/* 2289 */     StringBuffer sb = new StringBuffer("(");
/* 2290 */     if ("ORACLE".equalsIgnoreCase(getDBType()))
/* 2291 */       sb.append("trunc(").append(date1).append(")").append(opt).append("trunc(").append(date2).append(")");
/* 2292 */     else if ("DB2".equalsIgnoreCase(getDBType()))
/* 2293 */       sb.append("days(").append(date1).append(")").append(opt).append("days(").append(date2).append(")");
/* 2294 */     else if ("MYSQL".equalsIgnoreCase(getDBType()))
/* 2295 */       sb.append("to_days(").append(date1).append(")").append(opt).append("to_days(").append(date2).append(")");
/*      */     else {
/* 2297 */       sb.append(date1).append(opt).append(date2);
/*      */     }
/* 2299 */     sb.append(")");
/* 2300 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static boolean isMobileNumber(String mobiles)
/*      */   {
/* 2305 */     Pattern p = Pattern.compile("^((13[4-9])|(15[0|1|2|7|8|9])|(18[2|3|4|7|8]))\\d{8}$");
/* 2306 */     Matcher m = p.matcher(mobiles);
/* 2307 */     return m.matches();
/*      */   }
/*      */ 
/*      */   public static String getMonthFromDateStr(String dateStr) {
/* 2311 */     if (StringUtils.isNotEmpty(dateStr)) {
/* 2312 */       return dateStr.substring(0, 7);
/*      */     }
/* 2314 */     return dateStr;
/*      */   }
/*      */ 
/*      */   public static String getCityNameByCityId(String cityId)
/*      */   {
/* 2319 */     IUserPrivilegeCommonService pService = null;
/*      */     try {
/* 2321 */       pService = (IUserPrivilegeCommonService)SystemServiceLocator.getInstance().getService("userPrivilegeCommonService");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2325 */       e.printStackTrace();
/*      */     }
/* 2327 */     ICity city = pService.getCityById(cityId);
/* 2328 */     if (city != null) {
/* 2329 */       return city.getCityName();
/*      */     }
/* 2331 */     return cityId;
/*      */   }
/*      */ 
/*      */   public static String[] strSplit(String msg, int num)
/*      */   {
/* 2341 */     int len = msg.length();
/* 2342 */     if (len <= num) {
/* 2343 */       return new String[] { msg };
/*      */     }
/* 2345 */     int count = len / (num - 1);
/* 2346 */     count += (len > (num - 1) * count ? 1 : 0);
/* 2347 */     String[] result = new String[count];
/* 2348 */     int pos = 0;
/* 2349 */     int splitLen = num - 1;
/* 2350 */     for (int i = 0; i < count; i++) {
/* 2351 */       if (i == count - 1) {
/* 2352 */         splitLen = len - pos;
/*      */       }
/* 2354 */       result[i] = msg.substring(pos, pos + splitLen);
/* 2355 */       pos += splitLen;
/*      */     }
/*      */ 
/* 2358 */     return result;
/*      */   }
/*      */ 
/*      */   public static String convertPercentNumber(Double num) {
/* 2362 */     if ((num != null) && (num.doubleValue() != 0.0D)) {
/* 2363 */       return convertPercentStr(Double.valueOf(num.doubleValue() * 100.0D), "0.00%");
/*      */     }
/* 2365 */     return num.toString();
/*      */   }
/*      */ 
/*      */   public static void dropTable(String tabName) throws Exception {
/* 2369 */     if (StringUtil.isNotEmpty(tabName))
/*      */       try {
/* 2371 */         JdbcTemplate jdbcTemplate = (JdbcTemplate)SpringContext.getBean("jdbcTemplate", JdbcTemplate.class);
/* 2372 */         jdbcTemplate.execute(new StringBuilder("drop table ").append(tabName).toString());
/*      */       } catch (Exception e) {
/* 2374 */         log.warn(new StringBuilder().append("drop table error:").append(e.getMessage()).toString());
/*      */       }
/*      */   }
/*      */ 
/*      */   public static void clearTabData(String tabName)
/*      */     throws Exception
/*      */   {
/* 2385 */     String dbType = getDBType();
/* 2386 */     JdbcTemplate jdbcTemplate = (JdbcTemplate)SpringContext.getBean("jdbcTemplate", JdbcTemplate.class);
/* 2387 */     if (StringUtil.isNotEmpty(tabName))
/*      */       try {
/* 2389 */         StringBuffer b = null;
/* 2390 */         if ("DB2".equals(dbType)) {
/* 2391 */           b = new StringBuffer();
/* 2392 */           b.append("alter table ").append(tabName).append(" activate NOT LOGGED INITIALLY WITH EMPTY TABLE");
/* 2393 */           jdbcTemplate.execute(b.toString());
/*      */         }
/* 2395 */         else if ("ORACLE".equals(dbType)) {
/* 2396 */           b = new StringBuffer("truncate table ").append(tabName);
/* 2397 */           jdbcTemplate.execute(b.toString());
/*      */         } else {
/* 2399 */           b = new StringBuffer("delete from ").append(tabName);
/* 2400 */           jdbcTemplate.execute(b.toString());
/*      */         }
/*      */       } catch (Exception e) {
/* 2403 */         log.error("Clear data of {} error:", new Object[] { tabName, e });
/*      */       }
/*      */   }
/*      */ 
/*      */   public static void clearTabData(JdbcTemplate jdbcTemplate, String tabName)
/*      */     throws Exception
/*      */   {
/* 2414 */     String dbType = getDBType();
/* 2415 */     if (StringUtil.isNotEmpty(tabName))
/*      */       try {
/* 2417 */         String sql = "";
/* 2418 */         if ("DB2".equals(dbType)) {
/* 2419 */           sql = new StringBuffer("alter table ").append(tabName).append(" activate NOT LOGGED INITIALLY WITH EMPTY TABLE").toString();
/*      */ 
/* 2421 */           jdbcTemplate.execute(sql);
/* 2422 */         } else if ("ORACLE".equals(dbType)) {
/* 2423 */           sql = new StringBuffer("truncate table ").append(tabName).toString();
/* 2424 */           jdbcTemplate.execute(sql);
/*      */         } else {
/* 2426 */           sql = new StringBuffer("delete from ").append(tabName).toString();
/* 2427 */           jdbcTemplate.execute(sql);
/*      */         }
/*      */       }
/*      */       catch (Exception e) {
/* 2431 */         log.error(new StringBuilder().append("Clear data of ").append(tabName).append(" error:").toString(), e);
/*      */       }
/*      */   }
/*      */ 
/*      */   public static boolean isExistsBasePageExtendJs(ServletContext application, String province)
/*      */   {
/* 2437 */     boolean flag = false;
/* 2438 */     String basePage_extendPath = application.getRealPath(new StringBuilder().append("/mpm/assets/js/province/").append(province).append("/basePage-extend.js").toString());
/*      */ 
/* 2440 */     File basePage_extendFile = new File(basePage_extendPath);
/* 2441 */     if (basePage_extendFile.exists()) {
/* 2442 */       flag = true;
/* 2443 */       return flag;
/*      */     }
/* 2445 */     return flag;
/*      */   }
/*      */ 
/*      */   public static boolean isExistsExtendJSP(ServletContext application, String province, String JspName)
/*      */   {
/* 2451 */     boolean flag = false;
/* 2452 */     String basePage_extendPath = application.getRealPath(new StringBuilder().append("/mpm/province/").append(province).append("/").append(JspName).append("_extend.jsp").toString());
/*      */ 
/* 2454 */     File basePage_extendFile = new File(basePage_extendPath);
/* 2455 */     if (basePage_extendFile.exists()) {
/* 2456 */       flag = true;
/* 2457 */       return flag;
/*      */     }
/* 2459 */     return flag;
/*      */   }
/*      */ 
/*      */   public static boolean isExistsSceneExtendJSP(ServletContext application, String province, String JspName)
/*      */   {
/* 2465 */     boolean flag = false;
/* 2466 */     String basePage_extendPath = application.getRealPath(new StringBuilder().append("/mpm/sceneCamp/province/").append(province).append("/").append(JspName).append("_extend.jsp").toString());
/*      */ 
/* 2468 */     File basePage_extendFile = new File(basePage_extendPath);
/* 2469 */     if (basePage_extendFile.exists()) {
/* 2470 */       flag = true;
/* 2471 */       return flag;
/*      */     }
/* 2473 */     return flag;
/*      */   }
/*      */ 
/*      */   public static String getSql2Date2(String dbType, String sDateStr, String splitStr)
/*      */     throws Exception
/*      */   {
/* 2486 */     String strDateStr = sDateStr;
/* 2487 */     if (StringUtil.isEmpty(sDateStr)) {
/* 2488 */       return null;
/*      */     }
/* 2490 */     if (strDateStr.indexOf("0000-00-00") >= 0) {
/* 2491 */       return "null";
/*      */     }
/* 2493 */     String strRet = "";
/*      */ 
/* 2495 */     if ((dbType.equalsIgnoreCase("MYSQL")) || (dbType.equalsIgnoreCase("GBASE")))
/* 2496 */       strRet = new StringBuilder().append("'").append(strDateStr).append("'").toString();
/* 2497 */     else if (dbType.equalsIgnoreCase("DB2"))
/* 2498 */       strRet = new StringBuilder().append("TIMESTAMP('").append(strDateStr).append("')").toString();
/* 2499 */     else if ((dbType.equalsIgnoreCase("ORACLE")) || (dbType.equalsIgnoreCase("POSTGRESQL"))) {
/* 2500 */       if ("-".equals(splitStr))
/* 2501 */         strRet = new StringBuilder().append("to_date('").append(strDateStr).append("','YYYY-mm-dd HH24:mi:ss')").toString();
/*      */       else
/* 2503 */         strRet = new StringBuilder().append("to_date('").append(strDateStr).append("','YYYY/mm/dd HH24:mi:ss')").toString();
/*      */     }
/* 2505 */     else if (dbType.equalsIgnoreCase("ACESS"))
/* 2506 */       strRet = new StringBuilder().append("'").append(strDateStr).append("'").toString();
/* 2507 */     else if (dbType.equalsIgnoreCase("SQLSERVER")) {
/* 2508 */       if ("-".equals(splitStr))
/* 2509 */         strRet = new StringBuilder().append("convert(varchar(10), convert(datetime,'").append(strDateStr).append("'), 111)").toString();
/*      */       else
/* 2511 */         strRet = new StringBuilder().append("CONVERT(Datetime,'").append(strDateStr).append("',20)").toString();
/*      */     }
/* 2513 */     else if (dbType.equalsIgnoreCase("TERA")) {
/* 2514 */       if ("-".equals(splitStr))
/* 2515 */         strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as date FORMAT 'YYYY-MM-DD HH24:mi:ss')").toString();
/*      */       else
/* 2517 */         strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as date FORMAT 'YYYY/MM/DD HH24:mi:ss')").toString();
/*      */     }
/* 2519 */     else if (dbType.equalsIgnoreCase("SYBASE"))
/* 2520 */       strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as Date)").toString();
/*      */     else {
/* 2522 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 2524 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String escape4Html(String str)
/*      */   {
/* 2533 */     if (StringUtils.isNotEmpty(str)) {
/* 2534 */       if (str.indexOf("\"") != -1) {
/* 2535 */         str = str.replaceAll("\"", "&quot;");
/*      */       }
/* 2537 */       if (str.indexOf("'") != -1) {
/* 2538 */         str = str.replaceAll("'", "&apos;");
/*      */       }
/*      */     }
/* 2541 */     return str;
/*      */   }
/*      */ 
/*      */   public static String formatNum(int num, int length)
/*      */   {
/* 2548 */     StringBuilder sb = new StringBuilder();
/* 2549 */     sb.append(num);
/* 2550 */     int delta = length - sb.length();
/* 2551 */     if (delta > 0) {
/* 2552 */       for (int i = 0; i < delta; i++) {
/* 2553 */         sb.insert(0, 0);
/*      */       }
/*      */     }
/* 2556 */     return sb.toString();
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.MpmUtil
 * JD-Core Version:    0.6.2
 */
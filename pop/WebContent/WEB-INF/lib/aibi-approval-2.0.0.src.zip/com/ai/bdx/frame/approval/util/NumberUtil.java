/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.text.DecimalFormat;
/*     */ 
/*     */ public class NumberUtil
/*     */ {
/*     */   static final String zhnum_0 = "零壹贰叁肆伍陆柒捌玖";
/*     */   static final String zhnum = "零一二三四五六七八九";
/*  10 */   static final String[] zhnum1 = { "", "十", "百", "千" };
/*     */ 
/*  12 */   static final String[] zhnum1_0 = { "", "拾", "佰", "仟" };
/*     */ 
/*  14 */   static final String[] zhnum2 = { "", "万", "亿", "万亿", "亿亿" };
/*     */ 
/*     */   private static String numberToZH4(String s, boolean fan) {
/*  17 */     StringBuilder sb = new StringBuilder();
/*  18 */     if (s.length() != 4)
/*  19 */       return null;
/*  20 */     for (int i = 0; i < 4; i++) {
/*  21 */       char c1 = s.charAt(i);
/*  22 */       if ((c1 != '0') || (i <= 1) || (s.charAt(i - 1) != '0'))
/*     */       {
/*  24 */         if ((c1 != '0') && (i > 1) && (s.charAt(i - 1) == '0'))
/*  25 */           sb.append(38646);
/*  26 */         if (c1 != '0')
/*  27 */           if (fan) {
/*  28 */             sb.append("零壹贰叁肆伍陆柒捌玖".charAt(c1 - '0'));
/*  29 */             sb.append(zhnum1_0[(4 - i - 1)]);
/*     */           } else {
/*  31 */             sb.append("零一二三四五六七八九".charAt(c1 - '0'));
/*  32 */             sb.append(zhnum1[(4 - i - 1)]);
/*     */           }
/*     */       }
/*     */     }
/*  36 */     return new String(sb);
/*     */   }
/*     */ 
/*     */   public static String numberToZH(long n, boolean fan) {
/*  40 */     StringBuilder sb = new StringBuilder();
/*  41 */     String strN = new StringBuilder().append("000").append(n).toString();
/*  42 */     int strN_L = strN.length() / 4;
/*  43 */     strN = strN.substring(strN.length() - strN_L * 4);
/*  44 */     for (int i = 0; i < strN_L; i++) {
/*  45 */       String s1 = strN.substring(i * 4, i * 4 + 4);
/*  46 */       String s2 = numberToZH4(s1, fan);
/*  47 */       sb.append(s2);
/*  48 */       if (s2.length() != 0)
/*  49 */         sb.append(zhnum2[(strN_L - i - 1)]);
/*     */     }
/*  51 */     String s = new String(sb);
/*  52 */     if ((s.length() != 0) && (s.startsWith("零")))
/*  53 */       s = s.substring(1);
/*  54 */     return s;
/*     */   }
/*     */ 
/*     */   public static String numberToZH(double d, boolean fan) {
/*  58 */     return numberToZH(new StringBuilder().append("").append(d).toString(), fan);
/*     */   }
/*     */ 
/*     */   public static String numberToZH(String str, boolean fan)
/*     */   {
/*  69 */     StringBuilder sb = new StringBuilder();
/*  70 */     int dot = str.indexOf(".");
/*  71 */     if (dot < 0) {
/*  72 */       dot = str.length();
/*     */     }
/*  74 */     String zhengshu = str.substring(0, dot);
/*  75 */     sb.append(numberToZH(Long.parseLong(zhengshu), fan));
/*  76 */     if (dot != str.length()) {
/*  77 */       sb.append("点");
/*  78 */       String xiaoshu = str.substring(dot + 1);
/*  79 */       for (int i = 0; i < xiaoshu.length(); i++) {
/*  80 */         if (fan) {
/*  81 */           sb.append("零壹贰叁肆伍陆柒捌玖".charAt(Integer.parseInt(xiaoshu.substring(i, i + 1))));
/*     */         }
/*     */         else {
/*  84 */           sb.append("零一二三四五六七八九".charAt(Integer.parseInt(xiaoshu.substring(i, i + 1))));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  89 */     String s = new String(sb);
/*  90 */     if (s.startsWith("零"))
/*  91 */       s = s.substring(1);
/*  92 */     if (s.startsWith("一十"))
/*  93 */       s = s.substring(1);
/*  94 */     while (s.endsWith("零")) {
/*  95 */       s = s.substring(0, s.length() - 1);
/*     */     }
/*  97 */     if (s.endsWith("点"))
/*  98 */       s = s.substring(0, s.length() - 1);
/*  99 */     return s;
/*     */   }
/*     */ 
/*     */   public static String numberToRMB(double rmb) {
/* 103 */     String strRMB = new StringBuilder().append("").append(rmb).toString();
/* 104 */     DecimalFormat nf = new DecimalFormat("#.#");
/* 105 */     nf.setMaximumFractionDigits(2);
/* 106 */     strRMB = nf.format(rmb).toString();
/* 107 */     strRMB = numberToZH(strRMB, true);
/* 108 */     if (strRMB.indexOf("点") >= 0) {
/* 109 */       strRMB = new StringBuilder().append(strRMB).append("零").toString();
/* 110 */       strRMB = strRMB.replaceAll("点", "圆");
/* 111 */       String s1 = strRMB.substring(0, strRMB.indexOf("圆") + 1);
/* 112 */       String s2 = strRMB.substring(strRMB.indexOf("圆") + 1);
/* 113 */       strRMB = new StringBuilder().append(s1).append(s2.charAt(0)).append("角").append(s2.charAt(1)).append("分整").toString();
/*     */     } else {
/* 115 */       strRMB = new StringBuilder().append(strRMB).append("圆整").toString();
/*     */     }
/* 117 */     return new StringBuilder().append("人民币(大写):").append(strRMB).toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 122 */     System.out.println(numberToZH("1103", false));
/* 123 */     System.out.println(numberToZH("1023", false));
/* 124 */     System.out.println(numberToZH("1003", false));
/*     */ 
/* 126 */     System.out.println(numberToZH("103", false));
/* 127 */     System.out.println(numberToZH("31", false));
/* 128 */     System.out.println(numberToZH("30", false));
/*     */ 
/* 130 */     System.out.println(numberToZH("9", false));
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.NumberUtil
 * JD-Core Version:    0.6.2
 */
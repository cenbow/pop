/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.URISyntaxException;
/*    */ import java.net.URL;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class PathUtil
/*    */ {
/* 11 */   private static Logger log = Logger.getLogger(PathUtil.class);
/*    */   private static String appPath;
/*    */ 
/*    */   public static String getWebRootPath()
/*    */   {
/* 20 */     if (appPath == null) {
/*    */       try {
/* 22 */         appPath = new File(PathUtil.class.getResource("/").toURI()).getParentFile().getParentFile().getPath();
/*    */       } catch (URISyntaxException e) {
/* 24 */         String msg = "获取系统应用根路径异常.";
/* 25 */         log.error(msg, e);
/* 26 */         throw new RuntimeException(msg, e);
/*    */       }
/*    */     }
/* 29 */     return appPath;
/*    */   }
/*    */ 
/*    */   public static String getClassPath()
/*    */   {
/* 36 */     String classPath = null;
/*    */     try {
/* 38 */       classPath = new File(PathUtil.class.getResource("/").toURI()).getPath().toString();
/*    */     } catch (URISyntaxException e) {
/* 40 */       e.printStackTrace();
/*    */     }
/* 42 */     return classPath;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 46 */     log.debug("getWebRootPath:" + getWebRootPath());
/* 47 */     log.debug("getClassPath:" + getClassPath());
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.PathUtil
 * JD-Core Version:    0.6.2
 */
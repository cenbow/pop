/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.commons.lang.StringEscapeUtils;
/*    */ 
/*    */ public class RequestUtil
/*    */ {
/*    */   public static String getEscapedString(HttpServletRequest request, String paramName)
/*    */   {
/* 22 */     String value = request.getParameter(paramName);
/* 23 */     return StringEscapeUtils.escapeHtml(value);
/*    */   }
/*    */ 
/*    */   public static String getEscapedString(HttpServletRequest request, String paramName, String defaultValue)
/*    */   {
/* 35 */     String value = request.getParameter(paramName);
/* 36 */     if (value == null) {
/* 37 */       return defaultValue;
/*    */     }
/* 39 */     return StringEscapeUtils.escapeHtml(value);
/*    */   }
/*    */ 
/*    */   public static String getString(HttpServletRequest request, String paramName)
/*    */   {
/* 50 */     return request.getParameter(paramName);
/*    */   }
/*    */ 
/*    */   public static String getString(HttpServletRequest request, String paramName, String defaultValue)
/*    */   {
/* 62 */     String value = request.getParameter(paramName);
/* 63 */     if (value == null) {
/* 64 */       return defaultValue;
/*    */     }
/* 66 */     return value;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.RequestUtil
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLDecoder;
/*    */ import java.net.URLEncoder;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class RequestUtils
/*    */ {
/* 22 */   private static Logger log = Logger.getLogger(RequestUtils.class);
/*    */ 
/*    */   public static Map<String, String> getParameterMap(HttpServletRequest request)
/*    */     throws UnsupportedEncodingException
/*    */   {
/* 32 */     Map arrayMap = request.getParameterMap();
/* 33 */     Map map = new HashMap();
/* 34 */     if (arrayMap.isEmpty()) {
/* 35 */       return map;
/*    */     }
/* 37 */     log.debug("\nparameter in request:");
/* 38 */     Pattern ptn = Pattern.compile("[一-龠]");
/* 39 */     Matcher m = null;
/* 40 */     Iterator it = arrayMap.keySet().iterator();
/* 41 */     while (it.hasNext()) {
/* 42 */       String key = (String)it.next();
/* 43 */       String value = ((String[])(String[])arrayMap.get(key))[0];
/* 44 */       log.debug("[" + key + ":" + value + "]");
/* 45 */       m = ptn.matcher(value);
/* 46 */       if (m.find())
/* 47 */         value = URLEncoder.encode(value, "UTF-8");
/* 48 */       else if (key.indexOf("dsSql_") >= 0) {
/* 49 */         value = URLEncoder.encode(value, "UTF-8");
/*    */       }
/* 51 */       value = URLDecoder.decode(value, "UTF-8");
/* 52 */       log.debug("decode:key=[" + key + "],value=[" + value + "]");
/* 53 */       map.put(key, value);
/*    */     }
/* 55 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.RequestUtils
 * JD-Core Version:    0.6.2
 */
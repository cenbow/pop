package com.ai.bdx.frame.approval.util;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

/**
 * request公用类 仅适用于解析Ajax提交的参数
 * 
 * @author www.asiainfo.com 2008-11-26
 * 
 */
public class RequestUtils {
	private static Logger log = Logger.getLogger(RequestUtils.class);

	/**
	 * 获取ruquest的参数Map
	 * 
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static Map<String,String> getParameterMap(HttpServletRequest request) throws UnsupportedEncodingException {
		Map arrayMap = request.getParameterMap();
		Map<String, String> map = new HashMap<String, String>();
		if (arrayMap.isEmpty()) {
			return map;
		}
		log.debug("\nparameter in request:");
		Pattern ptn = Pattern.compile("[\u4E00-\u9FA0]");
		Matcher m = null;
		Iterator<String> it = arrayMap.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			String value = ((String[]) arrayMap.get(key))[0];
		    log.debug("["+key+":"+value+"]");
			m = ptn.matcher(value);
	        if(m.find()){//含有中文
	        	value = URLEncoder.encode(value, "UTF-8");
	        }else if(key.indexOf("dsSql_") >= 0){//处理Ext表格中的模糊查询bug edited by liuwei@20101215
	        	value = URLEncoder.encode(value, "UTF-8");
	        }
			value = URLDecoder.decode(value, "UTF-8");
			log.debug("decode:key=[" + key + "],value=[" + value + "]");
			map.put(key, value);
		}
		return map;
	}
}

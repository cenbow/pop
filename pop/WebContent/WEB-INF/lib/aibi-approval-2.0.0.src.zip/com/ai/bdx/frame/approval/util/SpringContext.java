/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ public final class SpringContext
/*     */ {
/*     */   private static ApplicationContext context;
/*  25 */   private static final Logger log = LogManager.getLogger();
/*     */   private static SpringContext instance;
/*     */ 
/*     */   private SpringContext()
/*     */   {
/*     */   }
/*     */ 
/*     */   private SpringContext(ServletContext sContext)
/*     */   {
/*     */     try
/*     */     {
/*  43 */       if (context == null) {
/*  44 */         context = WebApplicationContextUtils.getWebApplicationContext(sContext);
/*  45 */         log.debug("--------->>SpringContext init successful by web...");
/*     */       }
/*     */     } catch (Exception e) {
/*  48 */       log.error("", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static SpringContext init(ServletContext context)
/*     */   {
/*  59 */     if (instance == null) {
/*  60 */       instance = new SpringContext(context);
/*     */     }
/*  62 */     return instance;
/*     */   }
/*     */ 
/*     */   public static SpringContext init(ApplicationContext context)
/*     */   {
/*  72 */     if (instance == null) {
/*  73 */       instance = new SpringContext();
/*  74 */       context = context;
/*     */     }
/*  76 */     return instance;
/*     */   }
/*     */ 
/*     */   public static String getMessage(String code, Object[] args, HttpServletRequest request)
/*     */   {
/*  89 */     return getMessage(code, args, request.getLocale());
/*     */   }
/*     */ 
/*     */   public static String getMessage(String code, Object[] args, Locale locale)
/*     */   {
/* 102 */     return context.getMessage(code, args, null, locale);
/*     */   }
/*     */ 
/*     */   public static String getMessage(String strKey, HttpServletRequest request)
/*     */   {
/* 113 */     return context.getMessage(strKey, null, request.getLocale());
/*     */   }
/*     */ 
/*     */   public static String getMessage(String strKey, Locale local)
/*     */   {
/* 126 */     return context.getMessage(strKey, null, local);
/*     */   }
/*     */ 
/*     */   public static String getMessage(String strKey, String strLabel, HttpServletRequest request)
/*     */   {
/* 137 */     return getMessage(strKey, strLabel, request.getLocale());
/*     */   }
/*     */ 
/*     */   public static String getMessage(String strKey, String strLabel, Locale locale)
/*     */   {
/* 148 */     String strCName = context.getMessage(strKey, null, new Locale("zh", "CN"));
/* 149 */     if (!strCName.equals(strLabel)) {
/* 150 */       log.debug("(not error) wrong application properties key:" + strKey);
/*     */     }
/* 152 */     return context.getMessage(strKey, null, locale);
/*     */   }
/*     */ 
/*     */   public static <T> T getBean(String beanId, Class<T> clazz)
/*     */   {
/* 164 */     Object obj = context.getBean(beanId);
/*     */ 
/* 166 */     if (obj == null)
/* 167 */       return null;
/*     */     try
/*     */     {
/* 170 */       return clazz.cast(obj);
/*     */     } catch (ClassCastException ex) {
/* 172 */       log.error("Class " + obj.getClass().toString() + " cannot cast to " + clazz.toString(), ex);
/* 173 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <T> T getBean(Class<T> clazz)
/*     */   {
/*     */     try
/*     */     {
/* 188 */       String strName = clazz.getName();
/* 189 */       int nLast = strName.lastIndexOf('.');
/* 190 */       strName = Introspector.decapitalize(strName.substring(nLast + 1));
/* 191 */       Object obj = context.getBean(strName);
/*     */ 
/* 193 */       if (obj == null) {
/* 194 */         return null;
/*     */       }
/*     */ 
/* 197 */       return clazz.cast(obj);
/*     */     } catch (Exception ex) {
/* 199 */       log.error("", ex);
/*     */     }
/*     */ 
/* 202 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.SpringContext
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class StringFunc
/*     */ {
/*     */   private static final String DEFAULT_FILTERED_CHAR = "`~\\:;\"'<,>./";
/*  19 */   private static final String[] DEFAULT_INVALID_STR = { "script", "and ", "or ", "union ", "between ", "\"", "\\", "\\t", "insert|values", "select|from", "update|set", "delete|from", "drop", "where", "alter" };
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  42 */     System.out.println(str_to_array("1,2,3,"));
/*     */   }
/*     */ 
/*     */   public static String filterStr(String src, String filteredChar)
/*     */   {
/*  53 */     if ((src == null) || (src.length() < 0))
/*  54 */       return "";
/*  55 */     src = src.trim();
/*  56 */     if ((filteredChar == null) || (filteredChar.length() < 0)) {
/*  57 */       filteredChar = "`~\\:;\"'<,>./";
/*     */     }
/*  59 */     int len = filteredChar.length();
/*  60 */     for (int i = 0; i < len; i++) {
/*  61 */       src = replace2(src, String.valueOf(filteredChar.charAt(i)), "");
/*     */     }
/*     */ 
/*  65 */     return src;
/*     */   }
/*     */ 
/*     */   public static boolean isContainInvalidStr(String src, String invalidStr)
/*     */   {
/*  76 */     boolean res = false;
/*  77 */     if ((src == null) || (src.length() < 1)) {
/*  78 */       return res;
/*     */     }
/*     */ 
/*  81 */     if ((invalidStr != null) && (invalidStr.length() > 0)) {
/*  82 */       res = src.indexOf(invalidStr) >= 0;
/*     */     }
/*     */     else
/*     */     {
/*  86 */       int len = DEFAULT_INVALID_STR.length;
/*  87 */       src = src.toLowerCase();
/*     */ 
/*  91 */       for (int i = 0; i < len; i++) {
/*  92 */         String tmpInvalidStr = DEFAULT_INVALID_STR[i];
/*     */ 
/*  95 */         if (tmpInvalidStr.indexOf("|") >= 0) {
/*  96 */           boolean tmpBol = false;
/*  97 */           String[] tmpArr = tmpInvalidStr.split("[|]");
/*  98 */           for (int j = 0; j < tmpArr.length; j++)
/*     */           {
/* 101 */             if (src.indexOf(tmpArr[j]) >= 0) {
/* 102 */               System.out.println(new StringBuilder().append("invalid str [").append(tmpArr[j]).append("] exist,").toString());
/*     */ 
/* 104 */               tmpBol = true;
/*     */             }
/*     */             else
/*     */             {
/* 108 */               tmpBol = false;
/* 109 */               break;
/*     */             }
/*     */           }
/* 112 */           if (tmpBol) {
/* 113 */             res = true;
/* 114 */             break;
/*     */           }
/*     */ 
/*     */         }
/* 119 */         else if (src.indexOf(tmpInvalidStr) >= 0) {
/* 120 */           System.out.println(new StringBuilder().append("invalid str [").append(tmpInvalidStr).append("] exist, quit").toString());
/*     */ 
/* 122 */           res = true;
/* 123 */           break;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 129 */     return res;
/*     */   }
/*     */ 
/*     */   public static String split(String str, String str1, String str2)
/*     */   {
/* 140 */     String strTemp = "";
/* 141 */     if ((str == null) || (str.trim().length() < 1))
/* 142 */       return "";
/* 143 */     int pos = str.indexOf(str2);
/* 144 */     while (pos != -1) {
/* 145 */       str = new StringBuilder().append(str.substring(0, pos)).append(str.substring(pos + 1, str.length())).toString();
/* 146 */       pos = str.indexOf(str2);
/*     */     }
/* 148 */     if (str.indexOf(str1) < 1)
/* 149 */       str = str.substring(1, str.length());
/* 150 */     return str;
/*     */   }
/*     */ 
/*     */   public static String replace(String str1, String str2, String str3)
/*     */   {
/* 164 */     int pos = 0;
/* 165 */     String str = str1;
/* 166 */     while (str.indexOf(str2) != -1) {
/* 167 */       pos += str.indexOf(str2);
/* 168 */       str1 = new StringBuilder().append(str1.substring(0, pos)).append(str3).append(str1.substring(pos + 1)).toString();
/* 169 */       str = str1.substring(pos + 1);
/* 170 */       pos++;
/*     */     }
/* 172 */     return str1;
/*     */   }
/*     */ 
/*     */   public static String replace2(String source, String oldString, String newString)
/*     */   {
/* 189 */     if ((source == null) || (source.equals(""))) {
/* 190 */       return "";
/*     */     }
/* 192 */     StringBuffer output = new StringBuffer();
/*     */ 
/* 194 */     int lengthOfSource = source.length();
/* 195 */     int lengthOfOld = oldString.length();
/*     */ 
/* 197 */     int posStart = 0;
/*     */     int pos;
/* 200 */     while ((pos = source.indexOf(oldString, posStart)) >= 0) {
/* 201 */       output.append(source.substring(posStart, pos));
/*     */ 
/* 203 */       output.append(newString);
/* 204 */       posStart = pos + lengthOfOld;
/*     */     }
/*     */ 
/* 207 */     if (posStart < lengthOfSource) {
/* 208 */       output.append(source.substring(posStart));
/*     */     }
/*     */ 
/* 211 */     return output.toString();
/*     */   }
/*     */ 
/*     */   public static String convertStr(String str)
/*     */   {
/* 222 */     int pos = str.indexOf("'");
/* 223 */     int pos1 = 0;
/* 224 */     while (pos != -1) {
/* 225 */       str = new StringBuilder().append(str.substring(0, pos1 + pos)).append("'").append(str.substring(pos + pos1, str.length())).toString();
/*     */ 
/* 227 */       pos1 = pos1 + pos + 2;
/* 228 */       pos = str.substring(pos1, str.length()).indexOf("'");
/*     */     }
/* 230 */     return str;
/*     */   }
/*     */ 
/*     */   public static String replaceStr(String str1)
/*     */   {
/* 241 */     if ((str1 == null) || (str1.length() < 1))
/* 242 */       return null;
/* 243 */     str1 = new StringBuilder().append("'").append(str1.trim()).toString();
/* 244 */     int pos = str1.indexOf(",");
/* 245 */     int len = str1.length();
/* 246 */     while (pos != -1) {
/* 247 */       str1 = new StringBuilder().append(str1.substring(0, pos)).append("','").append(str1.substring(pos + 1, len)).toString();
/*     */ 
/* 249 */       len += 2;
/* 250 */       pos += 2;
/* 251 */       if (str1.substring(pos).indexOf(",") == -1) break;
/* 252 */       pos = str1.substring(pos).indexOf(",") + pos;
/*     */     }
/*     */ 
/* 256 */     str1 = new StringBuilder().append(str1).append("'").toString();
/*     */ 
/* 258 */     return str1;
/*     */   }
/*     */ 
/*     */   public static Vector getVector(String str, String partition)
/*     */   {
/* 271 */     Vector vect = new Vector();
/* 272 */     int pos = str.indexOf(partition);
/* 273 */     while (pos >= 0) {
/* 274 */       vect.addElement(str.substring(0, pos));
/*     */ 
/* 276 */       str = str.substring(pos + 1, str.length());
/* 277 */       pos = str.indexOf(partition);
/*     */     }
/* 279 */     vect.addElement(str.substring(0, str.length()));
/* 280 */     return vect;
/*     */   }
/*     */ 
/*     */   public static Vector getVector2(String str, String partition1, String partition2, String partition3)
/*     */   {
/* 285 */     Vector vect = new Vector();
/* 286 */     String strTemp = "";
/* 287 */     int bpos = str.indexOf(partition1);
/* 288 */     int epos = str.indexOf(partition2);
/* 289 */     while ((bpos >= 0) && (epos > 0)) {
/* 290 */       strTemp = str.substring(bpos + 1, epos);
/*     */ 
/* 292 */       Vector subvect = getVector(strTemp, partition3);
/* 293 */       vect.addElement(subvect);
/* 294 */       str = str.substring(epos + 1, str.length());
/* 295 */       bpos = str.indexOf(partition1);
/* 296 */       epos = str.indexOf(partition2);
/*     */     }
/* 298 */     return vect;
/*     */   }
/*     */ 
/*     */   public static Vector getVector3(String str)
/*     */   {
/* 304 */     Vector vect = new Vector();
/* 305 */     int lnum = 0;
/* 306 */     int rnum = 0;
/* 307 */     int bpos = 0;
/* 308 */     int epos = 0;
/* 309 */     boolean bFirst = true;
/* 310 */     int len = str.length();
/* 311 */     byte[] bstr = str.getBytes();
/* 312 */     int i = 0;
/* 313 */     while (i < len) {
/* 314 */       if (bstr[i] == 123) {
/* 315 */         lnum++;
/* 316 */         if (bFirst) {
/* 317 */           bpos = i;
/* 318 */           bFirst = false;
/*     */         }
/*     */       }
/* 321 */       if (bstr[i] == 125)
/* 322 */         rnum++;
/* 323 */       if ((lnum == rnum) && (lnum != 0) && (rnum != 0)) {
/* 324 */         epos = i;
/* 325 */         vect = getSubVect(str.substring(bpos + 1, epos), vect);
/* 326 */         lnum = 0;
/* 327 */         rnum = 0;
/* 328 */         bFirst = true;
/*     */       }
/* 330 */       i++;
/*     */     }
/* 332 */     return vect;
/*     */   }
/*     */ 
/*     */   private static Vector getSubVect(String str, Vector vect) {
/* 336 */     int bpos = 0;
/* 337 */     int epos = str.indexOf(" ");
/* 338 */     String strBegin = str.substring(bpos, epos);
/*     */ 
/* 340 */     str = str.substring(epos + 1);
/* 341 */     epos = str.indexOf(" ");
/* 342 */     String strEnd = str.substring(bpos, epos);
/*     */ 
/* 344 */     str = str.substring(epos + 2, str.length() - 1);
/*     */ 
/* 346 */     if ((str.length() < 1) || (str.equals(" "))) {
/* 347 */       Vector subvect = new Vector();
/* 348 */       subvect.addElement(strBegin);
/* 349 */       subvect.addElement(strEnd);
/* 350 */       subvect.addElement("");
/* 351 */       subvect.addElement("");
/* 352 */       vect.addElement(subvect);
/*     */     } else {
/* 354 */       byte[] bstr = str.getBytes();
/* 355 */       int len = str.length();
/* 356 */       int i = 0;
/* 357 */       String strTemp = "";
/* 358 */       boolean bFirst = true;
/* 359 */       bpos = 0;
/* 360 */       epos = 0;
/* 361 */       while (i < len) {
/* 362 */         if (bstr[i] == 123)
/* 363 */           bpos = i;
/* 364 */         if (bstr[i] == 125) {
/* 365 */           epos = i;
/*     */         }
/* 367 */         if ((bpos >= 0) && (epos > 0)) {
/* 368 */           strTemp = str.substring(bpos + 1, epos);
/*     */ 
/* 370 */           Vector subvect = new Vector();
/* 371 */           subvect.addElement(strBegin);
/* 372 */           subvect.addElement(strEnd);
/* 373 */           int pos = strTemp.indexOf(" ");
/* 374 */           subvect.addElement(strTemp.substring(0, pos));
/* 375 */           strTemp = strTemp.substring(pos + 1);
/* 376 */           subvect.addElement(strTemp.substring(strTemp.indexOf(" ") + 1));
/* 377 */           vect.addElement(subvect);
/* 378 */           bpos = 0;
/* 379 */           epos = 0;
/*     */         }
/* 381 */         i++;
/*     */       }
/*     */     }
/* 384 */     return vect;
/*     */   }
/*     */ 
/*     */   public static String str_to_double(String str, int num) {
/* 388 */     return NumberFormat.getInstance().format(Double.parseDouble(str));
/*     */   }
/*     */ 
/*     */   public static String array_to_str(Object[] array)
/*     */   {
/* 399 */     String str = "";
/* 400 */     for (int i = 0; i < array.length; i++) {
/* 401 */       str = new StringBuilder().append(str).append(array[i].toString()).append(",").toString();
/*     */     }
/* 403 */     if (str.length() > 0)
/* 404 */       str = str.substring(0, str.length() - 1);
/* 405 */     return str;
/*     */   }
/*     */ 
/*     */   public static String[] str_to_array(String str) {
/* 409 */     Vector vect = getVector(str, ",");
/* 410 */     int num = vect.size();
/* 411 */     String[] strArray = new String[num];
/* 412 */     for (int i = 0; i < num; i++) {
/* 413 */       strArray[i] = ((String)vect.elementAt(i));
/*     */     }
/*     */ 
/* 416 */     return strArray;
/*     */   }
/*     */ 
/*     */   public static String addSpace(String str, String strspace, int strlen)
/*     */   {
/* 423 */     if ((str == null) || (str.length() < 1))
/* 424 */       return null;
/* 425 */     while (str.length() < strlen) {
/* 426 */       str = new StringBuilder().append(strspace).append(str).toString();
/*     */     }
/* 428 */     return str;
/*     */   }
/*     */ 
/*     */   public static String list_to_str(Collection list, String separator, boolean addComma)
/*     */   {
/* 439 */     String str = "";
/* 440 */     if ((null == list) || (list.size() < 1)) {
/* 441 */       return str;
/*     */     }
/* 443 */     if ((null == separator) || (separator.length() < 1)) {
/* 444 */       separator = ",";
/*     */     }
/* 446 */     for (Iterator it = list.iterator(); it.hasNext(); ) {
/* 447 */       String id = it.next().toString();
/* 448 */       str = new StringBuilder().append(str).append(addComma ? "'" : "").append(id).append(addComma ? "'" : "").append(separator).toString();
/*     */     }
/*     */ 
/* 451 */     if (str.length() > 0)
/* 452 */       str = str.substring(0, str.length() - 1);
/* 453 */     return str;
/*     */   }
/*     */ 
/*     */   public static List str_to_list(String str, String partition, boolean removeComma)
/*     */   {
/* 458 */     List list = new ArrayList();
/* 459 */     int pos = str.indexOf(partition);
/* 460 */     while (pos >= 0) {
/* 461 */       String obj = str.substring(0, pos);
/* 462 */       if (removeComma) {
/* 463 */         obj = obj.substring(1, obj.length() - 1);
/*     */       }
/* 465 */       list.add(obj);
/* 466 */       str = str.substring(pos + 1, str.length());
/* 467 */       pos = str.indexOf(partition);
/*     */     }
/* 469 */     return list;
/*     */   }
/*     */ 
/*     */   public static List getDistinctList(List[] lists)
/*     */   {
/* 479 */     List retList = new ArrayList();
/* 480 */     Map map = new HashMap();
/* 481 */     for (int i = 0; i < lists.length; i++) {
/* 482 */       List list = lists[i];
/* 483 */       for (int j = 0; j < list.size(); j++) {
/* 484 */         if (list.get(j) != null) {
/* 485 */           map.put(list.get(j), list.get(j));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 490 */     Iterator it = map.keySet().iterator();
/* 491 */     while (it.hasNext()) {
/* 492 */       retList.add(it.next());
/*     */     }
/*     */ 
/* 495 */     return retList;
/*     */   }
/*     */ 
/*     */   public static List arry_to_list(Object[] obj, String partition, boolean addComma)
/*     */   {
/* 500 */     List retList = new ArrayList();
/* 501 */     retList = str_to_list(array_to_str(obj), partition, addComma);
/* 502 */     return retList;
/*     */   }
/*     */ 
/*     */   public static String addComma(String str) {
/* 506 */     if (str.indexOf("'") == -1) {
/* 507 */       return new StringBuilder().append("'").append(str.replaceAll(",", "','")).append("'").toString();
/*     */     }
/* 509 */     return str;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.StringFunc
 * JD-Core Version:    0.6.2
 */
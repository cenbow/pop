package com.ai.bdx.frame.approval.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class StringFunc {

	private static final String DEFAULT_FILTERED_CHAR = "`~\\:;\"'<,>./";

	// private static final String[] DEFAULT_INVALID_STR = new
	// String[]{"'","script","and ","or ","union ","between ","\"","\\","=","\\t","insert|values","select|from","update|set","delete|from","drop","where","alter"};
	// private static final String[] DEFAULT_INVALID_STR = new
	// String[]{"'","script","and ","or ","union ","between ","\"","\\","\\t","insert|values","select|from","update|set","delete|from","drop","where","alter"};
	private static final String[] DEFAULT_INVALID_STR = new String[] {
			"script", "and ", "or ", "union ", "between ", "\"", "\\", "\\t",
			"insert|values", "select|from", "update|set", "delete|from",
			"drop", "where", "alter" };

	public StringFunc() {
	}

	public static void main(String[] args) {
		// StringFunc stringFunc1 = new StringFunc();
		// String str =
		// "{0 88 { }} {88 128 {{000080 20} {000070 30} {4839843 u839ru}}} {128 228 {{000080 40} {000070 50}}} {228 -1 {{000070 150} {000080 100}}}";
		// String
		// str="{3.09553223915890065009321285469949801695E-01,8.14938484771241830065359477124183006536E05,1.69287843137254901960784313725490196078E04,3.11648477777777777777777777777777777778E06,1.72067189542483660130718954248366013072E04}";
		// Vector vect = stringFunc1.getVector2(str,"{","}",",");
		// for(int i=0;i<vect.size();i++)
		// {
		// Vector subvect = (Vector)vect.elementAt(i);
		// System.out.println(vect.elementAt(i));
		// System.out.println("=================");
		// }
		// String str = "20003,30004,5000";
		// System.out.println(stringFunc1.replace(str,"'',''",","));
		System.out.println(StringFunc.str_to_array("1,2,3,"));
	}

	/**
	 * 删除某个字串中需要被过滤得字符 added by wwl 2007-2-8
	 * 
	 * @param src
	 * @param filteredChar
	 * @return
	 */
	public static String filterStr(String src, String filteredChar) {
		if (src == null || src.length() < 0)
			return "";
		src = src.trim();
		if (filteredChar == null || filteredChar.length() < 0)
			filteredChar = DEFAULT_FILTERED_CHAR;

		int len = filteredChar.length();
		for (int i = 0; i < len; i++) {
			src = StringFunc.replace2(src,
					String.valueOf(filteredChar.charAt(i)), "");
		}

		return src;
	}

	/**
	 * 判断字串中是否包含非法字串 added by wwl 2007-6-15
	 * 
	 * @param src
	 * @param invalidStr
	 * @return
	 */
	public static boolean isContainInvalidStr(String src, String invalidStr) {
		boolean res = false;
		if (src == null || src.length() < 1)
			return res;

		// 使用自定义非法字串进行检查
		if (invalidStr != null && invalidStr.length() > 0) {
			res = (src.indexOf(invalidStr) >= 0) ? true : false;
		}
		// 使用系统内置非法字串进行检查
		else {
			int len = DEFAULT_INVALID_STR.length;
			src = src.toLowerCase();
			String tmpInvalidStr;
			String[] tmpArr;
			boolean tmpBol;
			for (int i = 0; i < len; i++) {
				tmpInvalidStr = DEFAULT_INVALID_STR[i];
				// System.out.println(i + "." + tmpInvalidStr);
				// 多个关联非法字串
				if (tmpInvalidStr.indexOf("|") >= 0) {
					tmpBol = false;
					tmpArr = tmpInvalidStr.split("[|]");
					for (int j = 0; j < tmpArr.length; j++) {
						// System.out.println(i + "." + j + " " + tmpArr[j]);
						// 每个关联非法字串都在源字串中，才能判断整个源字串是非法的
						if (src.indexOf(tmpArr[j]) >= 0) {
							System.out.println("invalid str [" + tmpArr[j]
									+ "] exist,");
							tmpBol = true;
						}
						// 有一个关联非法字串不在源字串中，源字串就是合法的
						else {
							tmpBol = false;
							break;
						}
					}
					if (tmpBol) {
						res = true;
						break;
					}
				}
				// 单个非法字串
				else {
					if (src.indexOf(tmpInvalidStr) >= 0) {
						System.out.println("invalid str [" + tmpInvalidStr
								+ "] exist, quit");
						res = true;
						break;
					}
				}
			}
		}

		return res;
	}

	/**
	 *
	 * @param str
	 * @param str1
	 * @param str2
	 * @return 将字符串str按照str2分割，并去掉首位的str1字符串
	 */
	public static String split(String str, String str1, String str2) {
		String strTemp = "";
		if (str == null || str.trim().length() < 1)
			return "";
		int pos = str.indexOf(str2);
		while (pos != -1) {
			str = str.substring(0, pos) + str.substring(pos + 1, str.length());
			pos = str.indexOf(str2);
		}
		if (str.indexOf(str1) < 1)
			str = str.substring(1, str.length());
		return str;
	}

	/**
	 *
	 * @param str1
	 *            原字符串
	 * @param str2
	 *            用于替换的字符串
	 * @param str3
	 *            要被替换掉的字符串
	 * @return
	 */
	public static String replace(String str1, String str2, String str3) {
		int pos = 0;
		String str = str1;
		while (str.indexOf(str2) != -1) {
			pos += str.indexOf(str2);
			str1 = str1.substring(0, pos) + str3 + str1.substring(pos + 1);
			str = str1.substring(pos + 1);
			pos += 1;
		}
		return str1;
	}

	/**
	 * 字符串替换，将 source 中的 oldString 全部换成 newString added by wwl 2004-11-10
	 * 支持一次能替换原字符串中的多个字符
	 * 
	 * @param source
	 *            源字符串
	 * @param oldString
	 *            老的字符串
	 * @param newString
	 *            新的字符串
	 * @return 替换后的字符串
	 */
	public static String replace2(String source, String oldString,
			String newString) {
		if ((source == null) || (source.equals(""))) {
			return "";
		}
		StringBuffer output = new StringBuffer();

		int lengthOfSource = source.length(); // 源字符串长度
		int lengthOfOld = oldString.length(); // 老字符串长度

		int posStart = 0; // 开始搜索位置
		int pos; // 搜索到老字符串的位置

		while ((pos = source.indexOf(oldString, posStart)) >= 0) {
			output.append(source.substring(posStart, pos));

			output.append(newString);
			posStart = pos + lengthOfOld;
		}

		if (posStart < lengthOfSource) {
			output.append(source.substring(posStart));
		}

		return output.toString();
	}

	/**
	 * 将字符串转换成可存入db2的字符串
	 * 
	 * @param str
	 *            String
	 * @return String
	 */
	public static String convertStr(String str) {
		int pos = str.indexOf("'");
		int pos1 = 0;
		while (pos != -1) {
			str = str.substring(0, pos1 + pos) + "'"
					+ str.substring(pos + pos1, str.length());
			pos1 = pos1 + pos + 2;
			pos = str.substring(pos1, str.length()).indexOf("'");
		}
		return str;
	}

	/**
	 * 把型如"12,23,34,56"的字串转换为"'12','23','34','56'"能在SQL中使用的字串
	 * 
	 * @param str1
	 *            String
	 * @return String
	 */
	public static String replaceStr(String str1) {
		if (str1 == null || str1.length() < 1)
			return null;
		str1 = "'" + str1.trim();
		int pos = str1.indexOf(",");
		int len = str1.length();
		while (pos != -1) {
			str1 = str1.substring(0, pos) + "','"
					+ str1.substring(pos + 1, len);
			len += 2;
			pos += 2;
			if (str1.substring(pos).indexOf(",") != -1)
				pos = str1.substring(pos).indexOf(",") + pos;
			else
				break;
		}
		str1 += "'";
		// System.out.println(str1);
		return str1;
	}

	/**
	 * 将一个字符串按照指定的分割符进行分割
	 * 
	 * @param str
	 *            String
	 * @param partition
	 *            String
	 * @return Vector
	 */
	public static Vector getVector(String str, String partition) {
		Vector vect = new Vector();
		int pos = str.indexOf(partition);
		while (pos >= 0) {
			vect.addElement(str.substring(0, pos));
			// System.out.println(str.substring(0,pos));
			str = str.substring(pos + 1, str.length());
			pos = str.indexOf(partition);
		}
		vect.addElement(str.substring(0, str.length()));
		return vect;
	}

	public static Vector getVector2(String str, String partition1,
			String partition2, String partition3) {
		Vector vect = new Vector();
		String strTemp = "";
		int bpos = str.indexOf(partition1);
		int epos = str.indexOf(partition2);
		while (bpos >= 0 && epos > 0) {
			strTemp = str.substring(bpos + 1, epos);
			// System.out.println(strTemp);
			Vector subvect = getVector(strTemp, partition3);
			vect.addElement(subvect);
			str = str.substring(epos + 1, str.length());
			bpos = str.indexOf(partition1);
			epos = str.indexOf(partition2);
		}
		return vect;
	}

	// {0 88 { }} {88 128 {{000080 20} {000070 30}}}
	// {128 228 {{000080 40} {000070 50}}} {228 -1 {{000070 150} {000080 100}}}
	public static Vector getVector3(String str) {
		Vector vect = new Vector();
		int lnum = 0;
		int rnum = 0;
		int bpos = 0;
		int epos = 0;
		boolean bFirst = true;
		int len = str.length();
		byte[] bstr = str.getBytes();
		int i = 0;
		while (i < len) {
			if (bstr[i] == '{') {
				lnum++;
				if (bFirst) {
					bpos = i;
					bFirst = false;
				}
			}
			if (bstr[i] == '}')
				rnum++;
			if (lnum == rnum && lnum != 0 && rnum != 0) {
				epos = i;
				vect = getSubVect(str.substring(bpos + 1, epos), vect);
				lnum = 0;
				rnum = 0;
				bFirst = true;
			}
			i++;
		}
		return vect;
	}

	private static Vector getSubVect(String str, Vector vect) {
		int bpos = 0;
		int epos = str.indexOf(" ");
		String strBegin = str.substring(bpos, epos);
		// System.out.println("begin:"+strBegin);
		str = str.substring(epos + 1);
		epos = str.indexOf(" ");
		String strEnd = str.substring(bpos, epos);
		// System.out.println("end:"+strEnd);
		str = str.substring(epos + 2, str.length() - 1);
		// System.out.println(str);
		if (str.length() < 1 || str.equals(" ")) {
			Vector subvect = new Vector();
			subvect.addElement(strBegin);
			subvect.addElement(strEnd);
			subvect.addElement("");
			subvect.addElement("");
			vect.addElement(subvect);
		} else {
			byte[] bstr = str.getBytes();
			int len = str.length();
			int i = 0;
			String strTemp = "";
			boolean bFirst = true;
			bpos = 0;
			epos = 0;
			while (i < len) {
				if (bstr[i] == '{')
					bpos = i;
				if (bstr[i] == '}')
					epos = i;
				// System.out.println(i+":"+bpos+" "+epos);
				if (bpos >= 0 && epos > 0) {
					strTemp = str.substring(bpos + 1, epos);
					// System.out.println("temp:"+strTemp);
					Vector subvect = new Vector();
					subvect.addElement(strBegin);
					subvect.addElement(strEnd);
					int pos = strTemp.indexOf(" ");
					subvect.addElement(strTemp.substring(0, pos));
					strTemp = strTemp.substring(pos + 1);
					subvect.addElement(strTemp.substring(strTemp.indexOf(" ") + 1));
					vect.addElement(subvect);
					bpos = 0;
					epos = 0;
				}
				i++;
			}
		}
		return vect;
	}

	public static String str_to_double(String str, int num) {
		return java.text.NumberFormat.getInstance().format(
				Double.parseDouble(str));
	}

	/**
	 * 将字符串数组转换成用逗号分割的字符串
	 * 
	 * @param strArray
	 * @return
	 */
	public static String array_to_str(Object[] array) {
		String str = "";
		for (int i = 0; i < array.length; i++) {
			str += array[i].toString() + ",";
		}
		if (str.length() > 0)
			str = str.substring(0, str.length() - 1);
		return str;
	}

	public static String[] str_to_array(String str) {
		Vector vect = (Vector) getVector(str, ",");
		int num = vect.size();
		String strArray[] = new String[num];
		for (int i = 0; i < num; i++) {
			strArray[i] = (String) vect.elementAt(i);
			// System.out.println(strArray[i]);
		}
		return strArray;
	}

	/*
	 * 为一个字符串的左面添加字符 str 字符串 strspace 添加的字符 strlen 要求修改后的长度
	 */
	public static String addSpace(String str, String strspace, int strlen) {
		if (str == null || str.length() < 1)
			return null;
		while (str.length() < strlen) {
			str = strspace + str;
		}
		return str;
	}

	/**
	 * 将字符串List转换成用逗号分割的字符串
	 * 
	 * @param strArray
	 * @return
	 */
	public static String list_to_str(Collection list, String separator,
			boolean addComma) {
		String str = "";
		if (null == list || list.size() < 1) {
			return str;
		}
		if (null == separator || separator.length() < 1) {
			separator = ",";
		}
		for (Iterator it = list.iterator(); it.hasNext();) {
			String id = it.next().toString();
			str += (addComma ? "'" : "") + id + (addComma ? "'" : "")
					+ separator;
		}
		if (str.length() > 0)
			str = str.substring(0, str.length() - 1);
		return str;
	}

	public static List str_to_list(String str, String partition,
			boolean removeComma) {
		List list = new ArrayList();
		int pos = str.indexOf(partition);
		while (pos >= 0) {
			String obj = str.substring(0, pos);
			if (removeComma) {
				obj = obj.substring(1, obj.length() - 1);
			}
			list.add(obj);
			str = str.substring(pos + 1, str.length());
			pos = str.indexOf(partition);
		}
		return list;
	}

	/**
	 * 将多个list中的数据合并,剔除重复的数据
	 * 
	 * @param lists
	 * @return
	 */
	public static List getDistinctList(List[] lists) {
		List retList = new ArrayList();
		Map map = new HashMap();
		for (int i = 0; i < lists.length; i++) {
			List list = (List) lists[i];
			for (int j = 0; j < list.size(); j++) {
				if (list.get(j) != null) {
					map.put(list.get(j), list.get(j));
				}
			}
		}

		Iterator it = map.keySet().iterator();
		while (it.hasNext()) {
			retList.add(it.next());
		}

		return retList;
	}

	public static List arry_to_list(Object[] obj, String partition,
			boolean addComma) {
		List retList = new ArrayList();
		retList = str_to_list(array_to_str(obj), partition, addComma);
		return retList;
	}

	public static String addComma(String str) {
		if (str.indexOf("'") == -1)
			return "'" + str.replaceAll(",", "','") + "'";
		else
			return str;
	}
}

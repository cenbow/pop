/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SysMenuMaintain
/*    */ {
/*    */   public static List<String> getSubMenuItem(Sqlca sqlca, String menuItemId, boolean isCascade)
/*    */   {
/* 13 */     List list = new ArrayList();
/*    */     try {
/* 15 */       sqlca = new Sqlca(sqlca.getConnection());
/*    */ 
/* 17 */       String strSql = "SELECT FOLDER_ID FROM LKG_FUNC_FOLDER WHERE PARENT_ID=? ORDER BY FOLDER_ID";
/* 18 */       String isSuite = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
/* 19 */       if ("true".equalsIgnoreCase(isSuite)) {
/* 20 */         strSql = "SELECT MENUITEMID as FOLDER_ID FROM SYS_MENU_ITEM WHERE PARENTID= ?";
/*    */       }
/* 22 */       sqlca.execute(strSql, new String[] { menuItemId });
/* 23 */       List menuList = new ArrayList();
/* 24 */       while (sqlca.next()) {
/* 25 */         menuList.add(sqlca.getString("FOLDER_ID"));
/*    */       }
/* 27 */       list.addAll(menuList);
/* 28 */       sqlca.close();
/*    */ 
/* 30 */       if (isCascade) {
/* 31 */         for (int i = 0; i < menuList.size(); i++) {
/* 32 */           list.addAll(getSubMenuItem(sqlca, (String)menuList.get(i), isCascade));
/*    */         }
/*    */       }
/*    */ 
/* 36 */       if (null != sqlca) {
/* 37 */         sqlca.close();
/*    */       }
/*    */ 
/* 46 */       if (null != sqlca)
/* 47 */         sqlca.close();
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 40 */       ex.printStackTrace();
/*    */ 
/* 42 */       if (null != sqlca) {
/* 43 */         sqlca.close();
/*    */       }
/*    */ 
/* 46 */       if (null != sqlca)
/* 47 */         sqlca.close();
/*    */     }
/*    */     finally
/*    */     {
/* 46 */       if (null != sqlca) {
/* 47 */         sqlca.close();
/*    */       }
/*    */     }
/* 50 */     return list;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.SysMenuMaintain
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.cache.service.IdAndName;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class SystemCacheManager
/*    */ {
/*    */   private Map sysCacheContainer;
/*    */   private static SystemCacheManager instance;
/*    */ 
/*    */   private SystemCacheManager()
/*    */   {
/* 13 */     this.sysCacheContainer = new HashMap();
/*    */   }
/*    */ 
/*    */   public static SystemCacheManager getInstance()
/*    */   {
/* 18 */     if (instance == null)
/* 19 */       instance = new SystemCacheManager();
/* 20 */     return instance;
/*    */   }
/*    */ 
/*    */   public String getNameById(String dicName, Object key)
/*    */   {
/* 25 */     String res = "";
/* 26 */     if (this.sysCacheContainer.containsKey(dicName))
/*    */     {
/* 28 */       Object obj = this.sysCacheContainer.get(dicName);
/* 29 */       if ((obj instanceof Map))
/*    */       {
/* 31 */         Map objMap = (Map)obj;
/* 32 */         Object obj2 = objMap.get(key);
/* 33 */         if ((obj2 instanceof String)) {
/* 34 */           res = obj2.toString();
/*    */         }
/* 36 */         else if ((obj2 instanceof IdAndName))
/*    */         {
/* 38 */           IdAndName idObj = (IdAndName)obj2;
/* 39 */           res = idObj.getName();
/*    */         }
/*    */       }
/* 42 */       else if ((obj instanceof String)) {
/* 43 */         res = obj.toString();
/*    */       }
/*    */     }
/* 45 */     return res;
/*    */   }
/*    */ 
/*    */   public void setSubCache(String dicName, Map subCache)
/*    */   {
/* 50 */     this.sysCacheContainer.put(dicName, subCache);
/*    */   }
/*    */ 
/*    */   public Map getSysCacheContainer()
/*    */   {
/* 55 */     return this.sysCacheContainer;
/*    */   }
/*    */ 
/*    */   public void setSysCacheContainer(Map sysCacheContainer)
/*    */   {
/* 60 */     this.sysCacheContainer = sysCacheContainer;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.SystemCacheManager
 * JD-Core Version:    0.6.2
 */
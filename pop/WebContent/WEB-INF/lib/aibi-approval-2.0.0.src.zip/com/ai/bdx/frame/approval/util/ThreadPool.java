/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import org.apache.commons.lang.math.NumberUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class ThreadPool
/*     */ {
/*  23 */   private static final Logger log = LogManager.getLogger();
/*     */   private final ExecutorService service;
/*     */ 
/*     */   public static ThreadPool getInstance()
/*     */   {
/*  42 */     return ThreadPoolHolder.instance;
/*     */   }
/*     */ 
/*     */   private ThreadPool()
/*     */   {
/*  50 */     int threadNum = Runtime.getRuntime().availableProcessors() * 2;
/*     */     try
/*     */     {
/*  53 */       threadNum = NumberUtils.toInt(Configure.getInstance().getProperty("THREAD_NUM"), threadNum);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */ 
/*  60 */     this.service = Executors.newFixedThreadPool(threadNum);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ThreadPool(int nThreads)
/*     */   {
/*  72 */     this.service = Executors.newFixedThreadPool(nThreads);
/*     */   }
/*     */ 
/*     */   public int getSize()
/*     */   {
/*  81 */     ThreadPoolExecutor pool = (ThreadPoolExecutor)this.service;
/*  82 */     return pool.getQueue().size();
/*     */   }
/*     */ 
/*     */   public void execute(Runnable r)
/*     */   {
/*     */     try
/*     */     {
/*  97 */       this.service.execute(r);
/*     */     }
/*     */     catch (Exception ex) {
/* 100 */       log.error("", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Callable r)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 117 */       this.service.submit(r);
/*     */     }
/*     */     catch (Exception ex) {
/* 120 */       log.error("", ex);
/* 121 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Runnable> shutdownNow()
/*     */   {
/* 132 */     ThreadPoolExecutor pool = (ThreadPoolExecutor)this.service;
/* 133 */     return pool.shutdownNow();
/*     */   }
/*     */ 
/*     */   static class ThreadPoolHolder
/*     */   {
/*  33 */     static ThreadPool instance = new ThreadPool(null);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.ThreadPool
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.approval.util;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.GetPy;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ public class TreeNode
/*     */   implements Comparable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 309047327307446894L;
/*     */   private String id;
/*     */   private String pid;
/*  26 */   private String text = "";
/*     */ 
/*  30 */   private boolean leaf = true;
/*     */   private String qtip;
/*     */   private String cls;
/*     */   private String icon;
/*  34 */   private List<TreeNode> children = new ArrayList();
/*     */   private boolean checked;
/*     */   private boolean disabled;
/*  37 */   private boolean draggable = true;
/*  38 */   private boolean expanded = false;
/*  39 */   private String href = "";
/*     */   private String hrefTarget;
/*     */   private String param1;
/*     */   private String param2;
/*     */   private String param3;
/*  46 */   private boolean match = false;
/*     */ 
/*  48 */   private boolean isParent = false;
/*     */ 
/*  51 */   private String state = "open";
/*     */   private String iconCls;
/*     */ 
/*     */   public boolean isMatch()
/*     */   {
/*  55 */     return this.match;
/*     */   }
/*     */ 
/*     */   public void setMatch(boolean match) {
/*  59 */     this.match = match;
/*  60 */     if (match);
/*     */   }
/*     */ 
/*     */   public TreeNode()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TreeNode(String id, String pid, String text)
/*     */   {
/*  77 */     this.id = id;
/*  78 */     this.pid = pid;
/*  79 */     this.text = text;
/*     */   }
/*     */ 
/*     */   public TreeNode(String id, String pid, String text, String href) {
/*  83 */     this.id = id;
/*  84 */     this.pid = pid;
/*  85 */     this.text = text;
/*  86 */     this.href = href;
/*     */   }
/*     */ 
/*     */   public boolean isDisabled() {
/*  90 */     return this.disabled;
/*     */   }
/*     */ 
/*     */   public void setDisabled(boolean disabled) {
/*  94 */     this.disabled = disabled;
/*     */   }
/*     */ 
/*     */   public boolean isDraggable() {
/*  98 */     return this.draggable;
/*     */   }
/*     */ 
/*     */   public void setDraggable(boolean draggable) {
/* 102 */     this.draggable = draggable;
/*     */   }
/*     */ 
/*     */   public boolean isExpanded() {
/* 106 */     return this.expanded;
/*     */   }
/*     */ 
/*     */   public void setExpanded(boolean expanded) {
/* 110 */     this.expanded = expanded;
/*     */   }
/*     */ 
/*     */   public List<TreeNode> getChildren() {
/* 114 */     return this.children;
/*     */   }
/*     */ 
/*     */   public void setChildren(List children) {
/* 118 */     this.children = children;
/*     */   }
/*     */ 
/*     */   public String getCls() {
/* 122 */     return this.cls;
/*     */   }
/*     */ 
/*     */   public void setCls(String cls) {
/* 126 */     this.cls = cls;
/*     */   }
/*     */ 
/*     */   public boolean isLeaf() {
/* 130 */     return this.leaf;
/*     */   }
/*     */ 
/*     */   public void setLeaf(boolean leaf) {
/* 134 */     this.leaf = leaf;
/*     */   }
/*     */ 
/*     */   public String getText() {
/* 138 */     return this.text;
/*     */   }
/*     */ 
/*     */   public void setText(String text) {
/* 142 */     this.text = text;
/*     */   }
/*     */ 
/*     */   public String getIcon() {
/* 146 */     return this.icon;
/*     */   }
/*     */ 
/*     */   public void setIcon(String icon) {
/* 150 */     this.icon = icon;
/*     */   }
/*     */ 
/*     */   public String getHref() {
/* 154 */     return this.href;
/*     */   }
/*     */ 
/*     */   public void setHref(String href) {
/* 158 */     this.href = href;
/*     */   }
/*     */ 
/*     */   public String getHrefTarget() {
/* 162 */     return this.hrefTarget;
/*     */   }
/*     */ 
/*     */   public void setHrefTarget(String hrefTarget) {
/* 166 */     this.hrefTarget = hrefTarget;
/*     */   }
/*     */ 
/*     */   public String getQtip() {
/* 170 */     return this.qtip;
/*     */   }
/*     */ 
/*     */   public void setQtip(String qtip) {
/* 174 */     this.qtip = qtip;
/*     */   }
/*     */ 
/*     */   public boolean isChecked() {
/* 178 */     return this.checked;
/*     */   }
/*     */ 
/*     */   public void setChecked(boolean checked) {
/* 182 */     this.checked = checked;
/*     */   }
/*     */ 
/*     */   public int compareTo(Object o)
/*     */   {
/* 189 */     if ((o instanceof TreeNode)) {
/* 190 */       TreeNode tn = (TreeNode)o;
/* 191 */       String pid = tn.getPid();
/* 192 */       String text = tn.getText();
/* 193 */       if (this.pid.compareTo(pid) > 0)
/* 194 */         return 1;
/* 195 */       if (this.pid.compareTo(pid) == 0) {
/* 196 */         if (this.text.compareTo(text) > 0)
/* 197 */           return 1;
/* 198 */         if (this.text.compareTo(text) < 0) {
/* 199 */           return -1;
/*     */         }
/* 201 */         return 0;
/*     */       }
/*     */ 
/* 204 */       return -1;
/*     */     }
/*     */ 
/* 207 */     throw new ClassCastException("Can't compare");
/*     */   }
/*     */ 
/*     */   public boolean match(String filterStr)
/*     */   {
/* 218 */     if ((filterStr == null) || (filterStr.trim().length() == 0)) {
/* 219 */       return true;
/*     */     }
/* 221 */     return (getText().indexOf(filterStr) >= 0) || (GetPy.getGBKpy(getText()).indexOf(filterStr) >= 0);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 226 */     return "id=[" + this.id + "],pid=[" + this.pid + "],text=[" + this.text + "],href=[" + this.href + "]" + ",target=[" + this.hrefTarget + "],expanded=[" + this.expanded + "]";
/*     */   }
/*     */ 
/*     */   public String getId()
/*     */   {
/* 231 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String id) {
/* 235 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getPid() {
/* 239 */     return this.pid;
/*     */   }
/*     */ 
/*     */   public void setPid(String pid) {
/* 243 */     this.pid = pid;
/*     */   }
/*     */ 
/*     */   public String getParam1() {
/* 247 */     return this.param1;
/*     */   }
/*     */ 
/*     */   public void setParam1(String param1) {
/* 251 */     this.param1 = param1;
/*     */   }
/*     */ 
/*     */   public String getParam2() {
/* 255 */     return this.param2;
/*     */   }
/*     */ 
/*     */   public void setParam2(String param2) {
/* 259 */     this.param2 = param2;
/*     */   }
/*     */ 
/*     */   public String getParam3() {
/* 263 */     return this.param3;
/*     */   }
/*     */ 
/*     */   public void setParam3(String param3) {
/* 267 */     this.param3 = param3;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 272 */     if ((o == null) || (!(o instanceof TreeNode))) {
/* 273 */       return false;
/*     */     }
/* 275 */     TreeNode node = (TreeNode)o;
/* 276 */     if (getId().equals(node.getId())) {
/* 277 */       return true;
/*     */     }
/* 279 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 285 */     HashCodeBuilder hb = new HashCodeBuilder();
/* 286 */     hb.append(getId());
/* 287 */     hb.append(getPid());
/* 288 */     return hb.toHashCode();
/*     */   }
/*     */ 
/*     */   public String getState() {
/* 292 */     return this.state;
/*     */   }
/*     */ 
/*     */   public void setState(String state) {
/* 296 */     this.state = state;
/*     */   }
/*     */ 
/*     */   public String getIconCls() {
/* 300 */     return this.iconCls;
/*     */   }
/*     */ 
/*     */   public void setIconCls(String iconCls) {
/* 304 */     this.iconCls = iconCls;
/*     */   }
/*     */ 
/*     */   public boolean getIsParent() {
/* 308 */     return this.isParent;
/*     */   }
/*     */ 
/*     */   public void setIsParent(boolean isParent) {
/* 312 */     this.isParent = isParent;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.TreeNode
 * JD-Core Version:    0.6.2
 */
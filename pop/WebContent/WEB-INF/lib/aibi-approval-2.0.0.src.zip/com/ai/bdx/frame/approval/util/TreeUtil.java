/*    */ package com.ai.bdx.frame.approval.util;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.json.JsonUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import net.sf.json.JSONArray;
/*    */ 
/*    */ public class TreeUtil
/*    */ {
/* 13 */   private List<String> rootIdList = new ArrayList();
/*    */ 
/*    */   public String getTreeData(List<TreeNode> nodeList)
/*    */     throws Exception
/*    */   {
/* 18 */     getRootId(nodeList);
/*    */ 
/* 20 */     List treeList = new ArrayList();
/* 21 */     treeList = convertToTreeData(nodeList, true);
/*    */ 
/* 23 */     String str = JsonUtil.Object2Json(treeList).toString();
/* 24 */     return str;
/*    */   }
/*    */ 
/*    */   private void getRootId(List<TreeNode> nodeList)
/*    */   {
/* 29 */     HashSet set = new HashSet(nodeList.size());
/* 30 */     for (TreeNode node : nodeList) {
/* 31 */       set.add(node.getId());
/*    */     }
/*    */ 
/* 34 */     for (TreeNode node : nodeList)
/* 35 */       if (!set.contains(node.getPid()))
/*    */       {
/* 38 */         if (!this.rootIdList.contains(node.getPid()))
/* 39 */           this.rootIdList.add(node.getPid());
/*    */       }
/*    */   }
/*    */ 
/*    */   private List<TreeNode> convertToTreeData(List<TreeNode> nodeList, boolean ignore)
/*    */     throws Exception
/*    */   {
/* 47 */     List returnList = new ArrayList();
/* 48 */     if ((nodeList == null) || (nodeList.size() == 0)) {
/* 49 */       return returnList;
/*    */     }
/*    */ 
/* 53 */     for (TreeNode node : nodeList) {
/* 54 */       if ((this.rootIdList.contains(node.getPid())) && 
/* 55 */         (ignore)) {
/* 56 */         returnList.add(node);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 62 */     Map map = getByMap(nodeList);
/*    */ 
/* 64 */     for (TreeNode node : nodeList) {
/* 65 */       String pid = node.getPid();
/* 66 */       if (map.containsKey(pid)) {
/* 67 */         TreeNode mnode = (TreeNode)map.get(pid);
/* 68 */         if (!mnode.getChildren().contains(node)) {
/* 69 */           mnode.getChildren().add(node);
/*    */         }
/*    */       }
/*    */     }
/* 73 */     return returnList;
/*    */   }
/*    */ 
/*    */   private Map<String, TreeNode> getByMap(List<TreeNode> nodeList) {
/* 77 */     Map map = new HashMap(nodeList.size());
/* 78 */     for (TreeNode node : nodeList) {
/* 79 */       map.put(node.getId(), node);
/*    */     }
/* 81 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.approval.util.TreeUtil
 * JD-Core Version:    0.6.2
 */
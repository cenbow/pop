package com.ai.bdx.frame.approval.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.asiainfo.biframe.utils.json.JsonUtil;

public class TreeUtil {
	// 根节点
	private List<String> rootIdList = new ArrayList<String>();

	public String getTreeData(List<TreeNode> nodeList) throws Exception {

		// 获取根节点
		getRootId(nodeList);
		// 转换节点列表为树状的节点列表
		List<TreeNode> treeList = new ArrayList<TreeNode>();
		treeList = convertToTreeData(nodeList, true);
		// 转换树数据为json字符串
		String str = JsonUtil.Object2Json(treeList).toString();
		return str;
	}

	private void getRootId(List<TreeNode> nodeList) {
		//转换为HashSet，以提高性能
		HashSet<String> set = new HashSet<String>(nodeList.size());
		for (TreeNode node : nodeList) {
			set.add(node.getId());
		}
		//判断标准：如果节点的父节点不存在，那么该节点的父节点即为根节点
		for (TreeNode node : nodeList) {
			if (set.contains(node.getPid())) {
				continue;
			} else {
				if (!rootIdList.contains(node.getPid())) {
					rootIdList.add(node.getPid());
				}
			}
		}
	}

	private List<TreeNode> convertToTreeData(List<TreeNode> nodeList, boolean ignore) throws Exception {
		// 合法性验证
		List<TreeNode> returnList = new ArrayList<TreeNode>();
		if ((nodeList == null) || (nodeList.size() == 0)) {
			return returnList;
		}

		// 只包含根节点；根节点节点下的子节点包含在children中；以此类推。
		for (TreeNode node : nodeList) {
			if (this.rootIdList.contains(node.getPid())) {//如果不是，取根节点下的一级节点
				if (ignore) {
					returnList.add(node);
				}
			}
		}

		//填充节点的children信息
		Map<String, TreeNode> map = getByMap(nodeList);
		String pid;
		for (TreeNode node : nodeList) {
			pid = node.getPid();
			if (map.containsKey(pid)) {
				TreeNode mnode = map.get(pid);
				if (!mnode.getChildren().contains(node)) {
					mnode.getChildren().add(node);
				}
			}
		}
		return returnList;
	}

	private Map<String, TreeNode> getByMap(List<TreeNode> nodeList) {
		Map<String, TreeNode> map = new HashMap<String, TreeNode>(nodeList.size());
		for (TreeNode node : nodeList) {
			map.put(node.getId(), node);
		}
		return map;
	}
}

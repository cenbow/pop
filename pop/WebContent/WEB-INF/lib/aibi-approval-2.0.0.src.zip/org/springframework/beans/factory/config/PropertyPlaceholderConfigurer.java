/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class PropertyPlaceholderConfigurer extends PropertyResourceConfigurer
/*     */   implements BeanNameAware, BeanFactoryAware
/*     */ {
/*     */   public static final String DEFAULT_PLACEHOLDER_PREFIX = "${";
/*     */   public static final String DEFAULT_PLACEHOLDER_SUFFIX = "}";
/*     */   public static final int SYSTEM_PROPERTIES_MODE_NEVER = 0;
/*     */   public static final int SYSTEM_PROPERTIES_MODE_FALLBACK = 1;
/*     */   public static final int SYSTEM_PROPERTIES_MODE_OVERRIDE = 2;
/* 124 */   private static final Constants constants = new Constants(PropertyPlaceholderConfigurer.class);
/*     */   private String placeholderPrefix;
/*     */   private String placeholderSuffix;
/*     */   private int systemPropertiesMode;
/*     */   private boolean searchSystemEnvironment;
/*     */   private boolean ignoreUnresolvablePlaceholders;
/*     */   private String nullValue;
/*     */   private String beanName;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public PropertyPlaceholderConfigurer()
/*     */   {
/* 126 */     this.placeholderPrefix = "${";
/*     */ 
/* 128 */     this.placeholderSuffix = "}";
/*     */ 
/* 130 */     this.systemPropertiesMode = 1;
/*     */ 
/* 132 */     this.searchSystemEnvironment = true;
/*     */ 
/* 134 */     this.ignoreUnresolvablePlaceholders = false;
/*     */   }
/*     */ 
/*     */   public void setPlaceholderPrefix(String placeholderPrefix)
/*     */   {
/* 149 */     this.placeholderPrefix = placeholderPrefix;
/*     */   }
/*     */ 
/*     */   public void setPlaceholderSuffix(String placeholderSuffix)
/*     */   {
/* 158 */     this.placeholderSuffix = placeholderSuffix;
/*     */   }
/*     */ 
/*     */   public void setSystemPropertiesModeName(String constantName)
/*     */     throws IllegalArgumentException
/*     */   {
/* 169 */     this.systemPropertiesMode = constants.asNumber(constantName).intValue();
/*     */   }
/*     */ 
/*     */   public void setSystemPropertiesMode(int systemPropertiesMode)
/*     */   {
/* 185 */     this.systemPropertiesMode = systemPropertiesMode;
/*     */   }
/*     */ 
/*     */   public void setSearchSystemEnvironment(boolean searchSystemEnvironment)
/*     */   {
/* 207 */     this.searchSystemEnvironment = searchSystemEnvironment;
/*     */   }
/*     */ 
/*     */   public void setIgnoreUnresolvablePlaceholders(boolean ignoreUnresolvablePlaceholders)
/*     */   {
/* 215 */     this.ignoreUnresolvablePlaceholders = ignoreUnresolvablePlaceholders;
/*     */   }
/*     */ 
/*     */   public void setNullValue(String nullValue)
/*     */   {
/* 228 */     this.nullValue = nullValue;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName)
/*     */   {
/* 240 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 252 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public String getNullValue()
/*     */   {
/* 258 */     return this.nullValue;
/*     */   }
/*     */ 
/*     */   public String getBeanName() {
/* 262 */     return this.beanName;
/*     */   }
/*     */ 
/*     */   public BeanFactory getBeanFactory() {
/* 266 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props)
/*     */     throws BeansException
/*     */   {
/* 272 */     StringValueResolver valueResolver = new PlaceholderResolvingStringValueResolver(props);
/* 273 */     BeanDefinitionVisitor visitor = new BeanDefinitionVisitor(valueResolver);
/*     */ 
/* 275 */     String[] beanNames = beanFactoryToProcess.getBeanDefinitionNames();
/* 276 */     for (int i = 0; i < beanNames.length; i++)
/*     */     {
/* 279 */       if ((!beanNames[i].equals(this.beanName)) || (!beanFactoryToProcess.equals(this.beanFactory))) {
/* 280 */         BeanDefinition bd = beanFactoryToProcess.getBeanDefinition(beanNames[i]);
/*     */         try {
/* 282 */           visitor.visitBeanDefinition(bd);
/*     */         }
/*     */         catch (BeanDefinitionStoreException ex) {
/* 285 */           throw new BeanDefinitionStoreException(bd.getResourceDescription(), beanNames[i], ex.getMessage());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 291 */     beanFactoryToProcess.resolveAliases(valueResolver);
/*     */   }
/*     */ 
/*     */   protected String parseStringValue(String strVal, Properties props, Set visitedPlaceholders)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 309 */     StringBuffer buf = new StringBuffer(strVal);
/*     */ 
/* 311 */     int startIndex = strVal.indexOf(this.placeholderPrefix);
/* 312 */     while (startIndex != -1) {
/* 313 */       int endIndex = findPlaceholderEndIndex(buf, startIndex);
/* 314 */       if (endIndex != -1) {
/* 315 */         String placeholder = buf.substring(startIndex + this.placeholderPrefix.length(), endIndex);
/* 316 */         if (!visitedPlaceholders.add(placeholder)) {
/* 317 */           throw new BeanDefinitionStoreException("Circular placeholder reference '" + placeholder + "' in property definitions");
/*     */         }
/*     */ 
/* 321 */         placeholder = parseStringValue(placeholder, props, visitedPlaceholders);
/*     */ 
/* 323 */         String propVal = resolvePlaceholder(placeholder, props, this.systemPropertiesMode);
/* 324 */         if (propVal != null)
/*     */         {
/* 327 */           propVal = parseStringValue(propVal, props, visitedPlaceholders);
/*     */ 
/* 330 */           if ((strVal.indexOf("com.ai.bdx.frame.approval") != -1) && (strVal.indexOf("${PROVINCE}") != -1))
/*     */           {
/* 332 */             if ("${PROVINCE}".equals(buf.substring(startIndex, endIndex + this.placeholderSuffix.length())))
/*     */             {
/* 334 */               isHaveThisClass(buf, startIndex, endIndex + this.placeholderSuffix.length(), propVal);
/*     */             }
/*     */             else {
/* 337 */               buf.replace(startIndex, endIndex + this.placeholderSuffix.length(), propVal);
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 342 */             buf.replace(startIndex, endIndex + this.placeholderSuffix.length(), propVal);
/*     */           }
/* 344 */           if (this.logger.isTraceEnabled()) {
/* 345 */             this.logger.trace("Resolved placeholder '" + placeholder + "'");
/*     */           }
/* 347 */           startIndex = buf.indexOf(this.placeholderPrefix, startIndex + propVal.length());
/*     */         }
/* 349 */         else if (this.ignoreUnresolvablePlaceholders)
/*     */         {
/* 351 */           startIndex = buf.indexOf(this.placeholderPrefix, endIndex + this.placeholderSuffix.length());
/*     */         }
/*     */         else {
/* 354 */           throw new BeanDefinitionStoreException("Could not resolve placeholder '" + placeholder + "'");
/*     */         }
/* 356 */         visitedPlaceholders.remove(placeholder);
/*     */       }
/*     */       else {
/* 359 */         startIndex = -1;
/*     */       }
/*     */     }
/*     */ 
/* 363 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   private int findPlaceholderEndIndex(CharSequence buf, int startIndex) {
/* 367 */     int index = startIndex + this.placeholderPrefix.length();
/* 368 */     int withinNestedPlaceholder = 0;
/* 369 */     while (index < buf.length()) {
/* 370 */       if (StringUtils.substringMatch(buf, index, this.placeholderSuffix)) {
/* 371 */         if (withinNestedPlaceholder > 0) {
/* 372 */           withinNestedPlaceholder--;
/* 373 */           index += this.placeholderSuffix.length();
/*     */         }
/*     */         else {
/* 376 */           return index;
/*     */         }
/*     */       }
/* 379 */       else if (StringUtils.substringMatch(buf, index, this.placeholderPrefix)) {
/* 380 */         withinNestedPlaceholder++;
/* 381 */         index += this.placeholderPrefix.length();
/*     */       }
/*     */       else {
/* 384 */         index++;
/*     */       }
/*     */     }
/* 387 */     return -1;
/*     */   }
/*     */ 
/*     */   protected String resolvePlaceholder(String placeholder, Properties props, int systemPropertiesMode)
/*     */   {
/* 407 */     String propVal = null;
/* 408 */     if (systemPropertiesMode == 2) {
/* 409 */       propVal = resolveSystemProperty(placeholder);
/*     */     }
/* 411 */     if (propVal == null) {
/* 412 */       propVal = resolvePlaceholder(placeholder, props);
/*     */     }
/* 414 */     if ((propVal == null) && (systemPropertiesMode == 1)) {
/* 415 */       propVal = resolveSystemProperty(placeholder);
/*     */     }
/* 417 */     return propVal;
/*     */   }
/*     */ 
/*     */   protected String resolvePlaceholder(String placeholder, Properties props)
/*     */   {
/* 434 */     return props.getProperty(placeholder);
/*     */   }
/*     */ 
/*     */   protected String resolveSystemProperty(String key)
/*     */   {
/*     */     try
/*     */     {
/* 448 */       String value = System.getProperty(key);
/* 449 */       if ((value == null) && (this.searchSystemEnvironment));
/* 450 */       return System.getenv(key);
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 455 */       if (this.logger.isDebugEnabled())
/* 456 */         this.logger.debug("Could not access system property '" + key + "': " + ex);
/*     */     }
/* 458 */     return null;
/*     */   }
/*     */ 
/*     */   public void isHaveThisClass(StringBuffer className, int begin, int end, String replaceProvince)
/*     */   {
/* 487 */     StringBuffer classNameTmp = new StringBuffer(className);
/* 488 */     classNameTmp.replace(begin, end, replaceProvince);
/*     */     try {
/* 490 */       Class.forName(classNameTmp.toString());
/* 491 */       this.logger.info("当前省市：" + replaceProvince + ",已经实现serviceImpl代码,不替换defaults代码,路径:" + classNameTmp.toString());
/* 492 */       className.replace(begin, end, replaceProvince);
/*     */     } catch (ClassNotFoundException e) {
/* 494 */       StringBuffer tmp = new StringBuffer(className);
/* 495 */       className.replace(begin, end, "defaults");
/* 496 */       this.logger.info("当前省市" + replaceProvince + ",没有对应serviceImpl,将当前class:" + tmp.toString() + "替换为:-->" + className.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class PlaceholderResolvingStringValueResolver
/*     */     implements StringValueResolver
/*     */   {
/*     */     private final Properties props;
/*     */ 
/*     */     public PlaceholderResolvingStringValueResolver(Properties props)
/*     */     {
/* 473 */       this.props = props;
/*     */     }
/*     */ 
/*     */     public String resolveStringValue(String strVal) throws BeansException {
/* 477 */       String value = PropertyPlaceholderConfigurer.this.parseStringValue(strVal, this.props, new HashSet());
/* 478 */       return value.equals(PropertyPlaceholderConfigurer.this.nullValue) ? null : value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-approval-2.0.0.jar
 * Qualified Name:     org.springframework.beans.factory.config.PropertyPlaceholderConfigurer
 * JD-Core Version:    0.6.2
 */
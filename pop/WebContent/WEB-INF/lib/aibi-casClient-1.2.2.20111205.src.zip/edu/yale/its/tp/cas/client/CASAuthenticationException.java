/*    */ package edu.yale.its.tp.cas.client;
/*    */ 
/*    */ public class CASAuthenticationException extends Exception
/*    */ {
/*    */   public CASAuthenticationException(String string)
/*    */   {
/* 16 */     super(string);
/*    */   }
/*    */ 
/*    */   public CASAuthenticationException(String message, Throwable cause)
/*    */   {
/* 24 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.CASAuthenticationException
 * JD-Core Version:    0.6.2
 */
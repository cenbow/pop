/*     */ package edu.yale.its.tp.cas.client;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class CASReceipt
/*     */   implements Serializable
/*     */ {
/*  26 */   private static Log log = LogFactory.getLog(CASReceipt.class);
/*     */   private String casValidateUrl;
/*     */   private String pgtIou;
/*  99 */   private boolean primaryAuthentication = false;
/*     */   private String proxyCallbackUrl;
/* 108 */   private List proxyList = new ArrayList();
/*     */   private String userName;
/*     */ 
/*     */   public static CASReceipt getReceipt(ProxyTicketValidator ptv)
/*     */     throws CASAuthenticationException
/*     */   {
/*  43 */     if (log.isTraceEnabled()) {
/*  44 */       log.trace("entering getReceipt(ProxyTicketValidator=[" + ptv + "])");
/*     */     }
/*     */ 
/*  49 */     if (!ptv.isAuthenticationSuccesful()) {
/*     */       try {
/*  51 */         ptv.validate();
/*     */       } catch (Exception e) {
/*  53 */         CASAuthenticationException casException = new CASAuthenticationException("Unable to validate ProxyTicketValidator [" + ptv + "]", e);
/*     */ 
/*  56 */         log.error(casException);
/*  57 */         throw casException;
/*     */       }
/*     */     }
/*     */ 
/*  61 */     if (!ptv.isAuthenticationSuccesful()) {
/*  62 */       log.error("validation of [" + ptv + "] was not successful.");
/*  63 */       throw new CASAuthenticationException("Unable to validate ProxyTicketValidator [" + ptv + "]");
/*     */     }
/*     */ 
/*  67 */     CASReceipt receipt = new CASReceipt();
/*  68 */     receipt.casValidateUrl = ptv.getCasValidateUrl();
/*  69 */     receipt.pgtIou = ptv.getPgtIou();
/*  70 */     receipt.userName = ptv.getUser();
/*  71 */     receipt.proxyCallbackUrl = ptv.getProxyCallbackUrl();
/*  72 */     receipt.proxyList = ptv.getProxyList();
/*  73 */     receipt.primaryAuthentication = ptv.isRenew();
/*     */ 
/*  75 */     if (!receipt.validate()) {
/*  76 */       throw new CASAuthenticationException("Validation of [" + ptv + "] did not result in an internally consistent CASReceipt.");
/*     */     }
/*     */ 
/*  82 */     if (log.isTraceEnabled()) {
/*  83 */       log.trace("returning from getReceipt() with return value [" + receipt + "]");
/*     */     }
/*     */ 
/*  86 */     return receipt;
/*     */   }
/*     */ 
/*     */   public String getCasValidateUrl()
/*     */   {
/* 128 */     return this.casValidateUrl;
/*     */   }
/*     */ 
/*     */   public String getPgtIou()
/*     */   {
/* 138 */     return this.pgtIou;
/*     */   }
/*     */ 
/*     */   public String getProxyCallbackUrl()
/*     */   {
/* 147 */     return this.proxyCallbackUrl;
/*     */   }
/*     */ 
/*     */   public List getProxyList()
/*     */   {
/* 158 */     return Collections.unmodifiableList(this.proxyList);
/*     */   }
/*     */ 
/*     */   public String getUserName()
/*     */   {
/* 167 */     return this.userName;
/*     */   }
/*     */ 
/*     */   public boolean isPrimaryAuthentication()
/*     */   {
/* 181 */     return this.primaryAuthentication;
/*     */   }
/*     */ 
/*     */   public boolean isProxied()
/*     */   {
/* 191 */     return !this.proxyList.isEmpty();
/*     */   }
/*     */ 
/*     */   public String getProxyingService()
/*     */   {
/* 202 */     if (this.proxyList.isEmpty()) {
/* 203 */       return null;
/*     */     }
/* 205 */     return (String)this.proxyList.get(0);
/*     */   }
/*     */ 
/*     */   public void setCasValidateUrl(String casValidateUrl)
/*     */   {
/* 213 */     this.casValidateUrl = casValidateUrl;
/*     */   }
/*     */ 
/*     */   public void setPgtIou(String pgtIou)
/*     */   {
/* 221 */     this.pgtIou = pgtIou;
/*     */   }
/*     */ 
/*     */   public void setPrimaryAuthentication(boolean primaryAuthentication)
/*     */   {
/* 229 */     this.primaryAuthentication = primaryAuthentication;
/*     */   }
/*     */ 
/*     */   public void setProxyCallbackUrl(String proxyCallbackUrl)
/*     */   {
/* 237 */     this.proxyCallbackUrl = proxyCallbackUrl;
/*     */   }
/*     */ 
/*     */   public void setProxyList(List proxyList)
/*     */   {
/* 245 */     this.proxyList = proxyList;
/*     */   }
/*     */ 
/*     */   public void setUserName(String userName)
/*     */   {
/* 253 */     this.userName = userName;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 257 */     StringBuffer sb = new StringBuffer();
/* 258 */     sb.append("[");
/* 259 */     sb.append(CASReceipt.class.getName());
/* 260 */     sb.append(" userName=[");
/* 261 */     sb.append(this.userName);
/* 262 */     sb.append("]");
/* 263 */     sb.append(" casValidateUrl=[");
/* 264 */     sb.append(this.casValidateUrl);
/* 265 */     sb.append("]");
/* 266 */     sb.append(" proxyCallbackUrl=[");
/* 267 */     sb.append(this.proxyCallbackUrl);
/* 268 */     sb.append("]");
/* 269 */     sb.append(" pgtIou=[");
/* 270 */     sb.append(this.pgtIou);
/* 271 */     sb.append("]");
/* 272 */     sb.append(" casValidateUrl=[");
/* 273 */     sb.append(this.casValidateUrl);
/* 274 */     sb.append("]");
/* 275 */     sb.append(" proxyList=[");
/* 276 */     sb.append(this.proxyList);
/* 277 */     sb.append("]");
/*     */ 
/* 279 */     sb.append("]");
/* 280 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private boolean validate()
/*     */   {
/* 290 */     boolean valid = true;
/* 291 */     if (this.userName == null) {
/* 292 */       log.error("Receipt was invalid because userName was null. Receipt:[" + this + "]");
/*     */ 
/* 295 */       valid = false;
/*     */     }
/* 297 */     if (this.casValidateUrl == null) {
/* 298 */       log.error("Receipt was invalid because casValidateUrl was null.  Receipt:[" + this + "]");
/*     */ 
/* 301 */       valid = false;
/*     */     }
/* 303 */     if (this.proxyList == null) {
/* 304 */       log.error("receipt was invalid because proxyList was null.  Receipt:[" + this + "]");
/*     */ 
/* 306 */       valid = false;
/*     */     }
/*     */ 
/* 320 */     if ((this.primaryAuthentication) && (!this.proxyList.isEmpty())) {
/* 321 */       log.error("If authentication was by primary credentials then it could not have been proxied. Yet, primaryAuthentication is true where proxyList is not empty.  Receipt:[" + this + "]");
/*     */ 
/* 325 */       valid = false;
/*     */     }
/*     */ 
/* 328 */     return valid;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.CASReceipt
 * JD-Core Version:    0.6.2
 */
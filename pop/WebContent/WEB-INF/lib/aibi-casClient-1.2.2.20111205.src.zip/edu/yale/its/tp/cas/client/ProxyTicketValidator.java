/*     */ package edu.yale.its.tp.cas.client;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ public class ProxyTicketValidator extends ServiceTicketValidator
/*     */ {
/*     */   protected List proxyList;
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  54 */     System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
/*     */ 
/*  56 */     ProxyTicketValidator pv = new ProxyTicketValidator();
/*     */ 
/*  58 */     pv.setCasValidateUrl("https://portal.yale.edu/cas/proxyValidate");
/*     */ 
/*  60 */     pv.setService(args[0]);
/*  61 */     pv.setServiceTicket(args[1]);
/*  62 */     pv.validate();
/*  63 */     System.out.println(pv.getResponse());
/*  64 */     System.out.println();
/*  65 */     if (pv.isAuthenticationSuccesful()) {
/*  66 */       System.out.println("user: " + pv.getUser());
/*     */ 
/*  68 */       System.out.println("proxies:\n " + pv.getProxyList());
/*     */     } else {
/*  70 */       System.out.println("error code: " + pv.getErrorCode());
/*  71 */       System.out.println("error message: " + pv.getErrorMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getProxyList()
/*     */   {
/*  88 */     return this.proxyList;
/*     */   }
/*     */ 
/*     */   protected DefaultHandler newHandler()
/*     */   {
/*  96 */     return new ProxyHandler();
/*     */   }
/*     */ 
/*     */   protected void clear()
/*     */   {
/* 145 */     super.clear();
/* 146 */     this.proxyList = null;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 150 */     StringBuffer sb = new StringBuffer();
/* 151 */     sb.append("[");
/* 152 */     sb.append(ProxyTicketValidator.class.getName());
/* 153 */     sb.append(" proxyList=[");
/* 154 */     sb.append(this.proxyList);
/* 155 */     sb.append("] ");
/* 156 */     sb.append(super.toString());
/* 157 */     sb.append("]");
/* 158 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   protected class ProxyHandler extends ServiceTicketValidator.Handler
/*     */   {
/*     */     protected static final String PROXIES = "cas:proxies";
/*     */     protected static final String PROXY = "cas:proxy";
/* 110 */     protected List proxyList = new ArrayList();
/* 111 */     protected boolean proxyFragment = false;
/*     */ 
/*     */     protected ProxyHandler()
/*     */     {
/*  99 */       super();
/*     */     }
/*     */ 
/*     */     public void startElement(String ns, String ln, String qn, Attributes a)
/*     */     {
/* 117 */       super.startElement(ns, ln, qn, a);
/* 118 */       if ((this.authenticationSuccess) && (qn.equals("cas:proxies")))
/* 119 */         this.proxyFragment = true;
/*     */     }
/*     */ 
/*     */     public void endElement(String ns, String ln, String qn) throws SAXException
/*     */     {
/* 124 */       super.endElement(ns, ln, qn);
/* 125 */       if (qn.equals("cas:proxies"))
/* 126 */         this.proxyFragment = false;
/* 127 */       else if ((this.proxyFragment) && (qn.equals("cas:proxy")))
/* 128 */         this.proxyList.add(this.currentText.toString().trim());
/*     */     }
/*     */ 
/*     */     public void endDocument() throws SAXException {
/* 132 */       super.endDocument();
/* 133 */       if (this.authenticationSuccess)
/* 134 */         ProxyTicketValidator.this.proxyList = this.proxyList;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.ProxyTicketValidator
 * JD-Core Version:    0.6.2
 */
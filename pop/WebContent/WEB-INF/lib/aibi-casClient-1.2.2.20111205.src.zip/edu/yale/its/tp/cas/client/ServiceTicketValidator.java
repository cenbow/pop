/*     */ package edu.yale.its.tp.cas.client;
/*     */ 
/*     */ import edu.yale.its.tp.cas.util.SecureURL;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringReader;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ public class ServiceTicketValidator
/*     */ {
/*     */   private String casValidateUrl;
/*     */   private String proxyCallbackUrl;
/*     */   private String st;
/*     */   private String service;
/*     */   private String pgtIou;
/*     */   private String user;
/*     */   private String errorCode;
/*     */   private String errorMessage;
/*     */   private String entireResponse;
/*     */   private boolean renew;
/*     */   private boolean attemptedAuthentication;
/*     */   private boolean successfulAuthentication;
/*     */ 
/*     */   public ServiceTicketValidator()
/*     */   {
/*  84 */     this.renew = false;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  58 */     System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
/*     */ 
/*  60 */     ServiceTicketValidator sv = new ServiceTicketValidator();
/*     */ 
/*  62 */     sv.setCasValidateUrl("https://portal1.wss.yale.edu/cas/serviceValidate");
/*  63 */     sv.setProxyCallbackUrl("https://portal1.wss.yale.edu/casProxy/receptor");
/*  64 */     sv.setService(args[0]);
/*  65 */     sv.setServiceTicket(args[1]);
/*  66 */     sv.validate();
/*  67 */     System.out.println(sv.getResponse());
/*  68 */     System.out.println();
/*  69 */     if (sv.isAuthenticationSuccesful()) {
/*  70 */       System.out.println("user: " + sv.getUser());
/*  71 */       System.out.println("pgtIou: " + sv.getPgtIou());
/*     */     } else {
/*  73 */       System.out.println("error code: " + sv.getErrorCode());
/*  74 */       System.out.println("error message: " + sv.getErrorMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCasValidateUrl(String x)
/*     */   {
/*  97 */     this.casValidateUrl = x;
/*     */   }
/*     */ 
/*     */   public String getCasValidateUrl()
/*     */   {
/* 105 */     return this.casValidateUrl;
/*     */   }
/*     */ 
/*     */   public void setProxyCallbackUrl(String x)
/*     */   {
/* 113 */     this.proxyCallbackUrl = x;
/*     */   }
/*     */ 
/*     */   public void setRenew(boolean b)
/*     */   {
/* 122 */     this.renew = b;
/*     */   }
/*     */ 
/*     */   public String getProxyCallbackUrl()
/*     */   {
/* 130 */     return this.proxyCallbackUrl;
/*     */   }
/*     */ 
/*     */   public void setServiceTicket(String x)
/*     */   {
/* 137 */     this.st = x;
/*     */   }
/*     */ 
/*     */   public void setService(String x)
/*     */   {
/* 144 */     this.service = x;
/*     */   }
/*     */ 
/*     */   public String getUser()
/*     */   {
/* 151 */     return this.user;
/*     */   }
/*     */ 
/*     */   public String getPgtIou()
/*     */   {
/* 158 */     return this.pgtIou;
/*     */   }
/*     */ 
/*     */   public boolean isAuthenticationSuccesful()
/*     */   {
/* 166 */     return this.successfulAuthentication;
/*     */   }
/*     */ 
/*     */   public String getErrorMessage()
/*     */   {
/* 173 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */   public String getErrorCode()
/*     */   {
/* 180 */     return this.errorCode;
/*     */   }
/*     */ 
/*     */   public String getResponse()
/*     */   {
/* 187 */     return this.entireResponse;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */     throws IOException, SAXException, ParserConfigurationException
/*     */   {
/* 196 */     if ((this.casValidateUrl == null) || (this.st == null))
/* 197 */       throw new IllegalStateException("must set validation URL and ticket");
/* 198 */     clear();
/* 199 */     this.attemptedAuthentication = true;
/* 200 */     StringBuffer sb = new StringBuffer();
/* 201 */     sb.append(this.casValidateUrl);
/* 202 */     if (this.casValidateUrl.indexOf('?') == -1)
/* 203 */       sb.append('?');
/*     */     else
/* 205 */       sb.append('&');
/* 206 */     sb.append("service=" + this.service + "&ticket=" + this.st);
/* 207 */     if (this.proxyCallbackUrl != null)
/* 208 */       sb.append("&pgtUrl=" + this.proxyCallbackUrl);
/* 209 */     if (this.renew)
/* 210 */       sb.append("&renew=true");
/* 211 */     String url = sb.toString();
/* 212 */     String response = SecureURL.retrieve(url);
/* 213 */     this.entireResponse = response;
/*     */ 
/* 216 */     if (response != null) {
/* 217 */       XMLReader r = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
/*     */ 
/* 219 */       r.setFeature("http://xml.org/sax/features/namespaces", false);
/* 220 */       r.setContentHandler(newHandler());
/* 221 */       r.parse(new InputSource(new StringReader(response)));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected DefaultHandler newHandler()
/*     */   {
/* 230 */     return new Handler();
/*     */   }
/*     */ 
/*     */   protected void clear()
/*     */   {
/* 313 */     this.user = (this.pgtIou = this.errorMessage = null);
/* 314 */     this.attemptedAuthentication = false;
/* 315 */     this.successfulAuthentication = false;
/*     */   }
/*     */ 
/*     */   public boolean isRenew()
/*     */   {
/* 324 */     return this.renew;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 328 */     StringBuffer sb = new StringBuffer();
/* 329 */     sb.append("[");
/* 330 */     sb.append(ServiceTicketValidator.class.getName());
/* 331 */     if (this.casValidateUrl != null) {
/* 332 */       sb.append(" casValidateUrl=[");
/* 333 */       sb.append(this.casValidateUrl);
/* 334 */       sb.append("]");
/*     */     }
/*     */ 
/* 337 */     if (this.proxyCallbackUrl != null) {
/* 338 */       sb.append(" proxyCallbackUrl=[");
/* 339 */       sb.append(this.proxyCallbackUrl);
/* 340 */       sb.append("]");
/*     */     }
/* 342 */     if (this.st != null) {
/* 343 */       sb.append(" ticket=[");
/* 344 */       sb.append(this.st);
/* 345 */       sb.append("]");
/*     */     }
/* 347 */     if (this.service != null) {
/* 348 */       sb.append(" service=[");
/* 349 */       sb.append(this.service);
/* 350 */       sb.append("]");
/*     */     }
/* 352 */     if (this.pgtIou != null) {
/* 353 */       sb.append(" pgtIou=[");
/* 354 */       sb.append(this.pgtIou);
/* 355 */       sb.append("]");
/*     */     }
/* 357 */     if (this.user != null) {
/* 358 */       sb.append(" user=[");
/* 359 */       sb.append(this.user);
/* 360 */       sb.append("]");
/*     */     }
/* 362 */     if (this.errorCode != null) {
/* 363 */       sb.append(" errorCode=[");
/* 364 */       sb.append(this.errorCode);
/* 365 */       sb.append("]");
/*     */     }
/* 367 */     if (this.errorMessage != null) {
/* 368 */       sb.append(" errorMessage=[");
/* 369 */       sb.append(this.errorMessage);
/* 370 */       sb.append("]");
/*     */     }
/* 372 */     sb.append(" renew=");
/* 373 */     sb.append(this.renew);
/* 374 */     if (this.entireResponse != null) {
/* 375 */       sb.append(" entireResponse=[");
/* 376 */       sb.append(this.entireResponse);
/* 377 */       sb.append("]");
/*     */     }
/* 379 */     sb.append("]");
/* 380 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   protected class Handler extends DefaultHandler
/*     */   {
/*     */     protected static final String AUTHENTICATION_SUCCESS = "cas:authenticationSuccess";
/*     */     protected static final String AUTHENTICATION_FAILURE = "cas:authenticationFailure";
/*     */     protected static final String PROXY_GRANTING_TICKET = "cas:proxyGrantingTicket";
/*     */     protected static final String USER = "cas:user";
/* 249 */     protected StringBuffer currentText = new StringBuffer();
/* 250 */     protected boolean authenticationSuccess = false;
/* 251 */     protected boolean authenticationFailure = false;
/*     */     protected String netid;
/*     */     protected String pgtIou;
/*     */     protected String errorCode;
/*     */     protected String errorMessage;
/*     */ 
/*     */     protected Handler()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void startElement(String ns, String ln, String qn, Attributes a)
/*     */     {
/* 260 */       this.currentText = new StringBuffer();
/*     */ 
/* 263 */       if (qn.equals("cas:authenticationSuccess")) {
/* 264 */         this.authenticationSuccess = true;
/* 265 */       } else if (qn.equals("cas:authenticationFailure")) {
/* 266 */         this.authenticationFailure = true;
/* 267 */         this.errorCode = a.getValue("code");
/* 268 */         if (this.errorCode != null)
/* 269 */           this.errorCode = this.errorCode.trim();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void characters(char[] ch, int start, int length)
/*     */     {
/* 275 */       this.currentText.append(ch, start, length);
/*     */     }
/*     */ 
/*     */     public void endElement(String ns, String ln, String qn) throws SAXException
/*     */     {
/* 280 */       if (this.authenticationSuccess) {
/* 281 */         if (qn.equals("cas:user"))
/* 282 */           ServiceTicketValidator.this.user = this.currentText.toString().trim();
/* 283 */         if (qn.equals("cas:proxyGrantingTicket"))
/* 284 */           this.pgtIou = this.currentText.toString().trim();
/* 285 */       } else if ((this.authenticationFailure) && 
/* 286 */         (qn.equals("cas:authenticationFailure"))) {
/* 287 */         this.errorMessage = this.currentText.toString().trim();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void endDocument() throws SAXException
/*     */     {
/* 293 */       if (this.authenticationSuccess) {
/* 294 */         ServiceTicketValidator.this.user = ServiceTicketValidator.this.user;
/* 295 */         ServiceTicketValidator.this.pgtIou = this.pgtIou;
/* 296 */         ServiceTicketValidator.this.successfulAuthentication = true;
/* 297 */       } else if (this.authenticationFailure) {
/* 298 */         ServiceTicketValidator.this.errorMessage = this.errorMessage;
/* 299 */         ServiceTicketValidator.this.errorCode = this.errorCode;
/* 300 */         ServiceTicketValidator.this.successfulAuthentication = false;
/*     */       } else {
/* 302 */         throw new SAXException("no indication of success or failure from CAS");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.ServiceTicketValidator
 * JD-Core Version:    0.6.2
 */
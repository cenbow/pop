/*     */ package edu.yale.its.tp.cas.client;
/*     */ 
/*     */ import java.net.URLEncoder;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class Util
/*     */ {
/*  48 */   private static Log log = LogFactory.getLog(Util.class);
/*     */ 
/*     */   public static String getService(HttpServletRequest request, String server)
/*     */     throws ServletException
/*     */   {
/*  56 */     if (log.isTraceEnabled()) {
/*  57 */       log.trace("entering getService(" + request + ", " + server + ")");
/*     */     }
/*     */ 
/*  61 */     if (server == null) {
/*  62 */       log.error("getService() argument \"server\" was illegally null.");
/*  63 */       throw new IllegalArgumentException("name of server is required");
/*     */     }
/*     */ 
/*  68 */     StringBuffer sb = new StringBuffer();
/*  69 */     if (request.isSecure())
/*  70 */       sb.append("https://");
/*     */     else
/*  72 */       sb.append("http://");
/*  73 */     sb.append(server);
/*  74 */     sb.append(request.getRequestURI());
/*     */ 
/*  76 */     if ((request.getQueryString() != null) && (!"".equals(request.getQueryString())))
/*     */     {
/*  78 */       int ticketLoc = request.getQueryString().indexOf("ticket=");
/*     */ 
/*  84 */       if (ticketLoc == -1) {
/*  85 */         sb.append("?" + request.getQueryString());
/*  86 */       } else if (ticketLoc > 0) {
/*  87 */         ticketLoc = request.getQueryString().indexOf("&ticket=");
/*  88 */         if (ticketLoc == -1)
/*     */         {
/*  90 */           sb.append("?" + request.getQueryString());
/*  91 */         } else if (ticketLoc > 0)
/*     */         {
/*  93 */           sb.append("?" + request.getQueryString().substring(0, ticketLoc));
/*     */         }
/*     */       }
/*     */     }
/*  97 */     String encodedService = URLEncoder.encode(sb.toString());
/*  98 */     if (log.isTraceEnabled()) {
/*  99 */       log.trace("returning from getService() with encoded service [" + encodedService + "]");
/*     */     }
/* 101 */     return encodedService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.Util
 * JD-Core Version:    0.6.2
 */
/*     */ package edu.yale.its.tp.cas.client.filter;
/*     */ 
/*     */ import edu.yale.its.tp.cas.client.CASAuthenticationException;
/*     */ import edu.yale.its.tp.cas.client.CASReceipt;
/*     */ import edu.yale.its.tp.cas.client.ProxyTicketValidator;
/*     */ import edu.yale.its.tp.cas.client.Util;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public abstract class CASFilter
/*     */   implements Filter
/*     */ {
/*  36 */   private static Log log = LogFactory.getLog(CASFilter.class);
/*     */   public static final String ALIVE_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.aliveUrl";
/*     */   public static final String LOAD_BALANCE_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.loadBalance.distributeMachineAddress";
/*     */   public static final String LOGIN_4A_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.4ALoginUrl";
/*     */   public static final String LOGIN_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.loginUrl";
/*     */   public static final String VALIDATE_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.validateUrl";
/*     */   public static final String SERVICE_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.serviceUrl";
/*     */   public static final String SERVERNAME_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.serverName";
/*     */   public static final String RENEW_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.renew";
/*     */   public static final String AUTHORIZED_PROXY_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.authorizedProxy";
/*     */   public static final String PROXY_CALLBACK_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.proxyCallbackUrl";
/*     */   public static final String WRAP_REQUESTS_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.wrapRequest";
/*     */   public static final String GATEWAY_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.gateway";
/*     */   public static final String CAS_FILTER_USER = "edu.yale.its.tp.cas.client.filter.user";
/*     */   public static final String CAS_FILTER_RECEIPT = "edu.yale.its.tp.cas.client.filter.receipt";
/*     */   private static final String CAS_FILTER_GATEWAYED = "edu.yale.its.tp.cas.client.filter.didGateway";
/*     */   private static final String UNPROTECTED_URL = "edu.yale.its.tp.cas.client.filter.unprotectedUrl";
/*     */   private static final String IS_AUTO_LOGIN_PARAM = "isAutoLogin";
/*     */   private static final String AUTO_LOGIN_SIGNAL = "true";
/*     */   private String distributeMachineAddress;
/*     */   private String casAlive;
/*     */   private String casLogin;
/*     */   private String cas4ALogin;
/*     */   private String casValidate;
/*     */   private String casServiceUrl;
/*     */   private String casServerName;
/*     */   private String casProxyCallbackUrl;
/*     */   private boolean casRenew;
/*     */   private boolean wrapRequest;
/*     */   private boolean casGateway;
/*     */   private List authorizedProxies;
/*     */   private String[] unproectedUrl;
/*  74 */   private static Object lock = new Object();
/*     */ 
/*     */   public CASFilter() {
/*  77 */     this.casGateway = false;
/*  78 */     this.authorizedProxies = new ArrayList();
/*     */   }
/*     */ 
/*     */   protected boolean belongUnprotectdUrl(String uri) {
/*  82 */     if (this.unproectedUrl == null)
/*  83 */       return false;
/*  84 */     String[] as = this.unproectedUrl;
/*  85 */     int i = 0;
/*  86 */     for (int j = as.length; i < j; i++) {
/*  87 */       String t = as[i];
/*  88 */       Pattern p = Pattern.compile(t);
/*  89 */       if (p.matcher(uri).matches()) {
/*  90 */         return true;
/*     */       }
/*     */     }
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig config) throws ServletException
/*     */   {
/*  98 */     this.distributeMachineAddress = config.getInitParameter("edu.yale.its.tp.cas.client.filter.loadBalance.distributeMachineAddress");
/*  99 */     this.casAlive = config.getInitParameter("edu.yale.its.tp.cas.client.filter.aliveUrl");
/*     */ 
/* 101 */     this.cas4ALogin = config.getInitParameter("edu.yale.its.tp.cas.client.filter.4ALoginUrl");
/* 102 */     this.casLogin = config.getInitParameter("edu.yale.its.tp.cas.client.filter.loginUrl");
/*     */ 
/* 104 */     if (StringUtils.isBlank(this.casAlive))
/* 105 */       this.casAlive = this.casLogin;
/* 106 */     this.casValidate = config.getInitParameter("edu.yale.its.tp.cas.client.filter.validateUrl");
/* 107 */     this.casServiceUrl = config.getInitParameter("edu.yale.its.tp.cas.client.filter.serviceUrl");
/* 108 */     String casAuthorizedProxy = config.getInitParameter("edu.yale.its.tp.cas.client.filter.authorizedProxy");
/*     */ 
/* 110 */     String tem = config.getInitParameter("edu.yale.its.tp.cas.client.filter.unprotectedUrl");
/* 111 */     this.unproectedUrl = (tem != null ? tem.split(";") : null);
/* 112 */     this.casRenew = Boolean.valueOf(config.getInitParameter("edu.yale.its.tp.cas.client.filter.renew")).booleanValue();
/*     */ 
/* 114 */     this.casServerName = config.getInitParameter("edu.yale.its.tp.cas.client.filter.serverName");
/* 115 */     this.casProxyCallbackUrl = config.getInitParameter("edu.yale.its.tp.cas.client.filter.proxyCallbackUrl");
/*     */ 
/* 117 */     this.wrapRequest = Boolean.valueOf(config.getInitParameter("edu.yale.its.tp.cas.client.filter.wrapRequest")).booleanValue();
/*     */ 
/* 120 */     this.casGateway = Boolean.valueOf(config.getInitParameter("edu.yale.its.tp.cas.client.filter.gateway")).booleanValue();
/*     */ 
/* 122 */     if ((this.casGateway) && (Boolean.valueOf(this.casRenew).booleanValue())) {
/* 123 */       throw new ServletException("gateway and renew cannot both be true in filter configuration");
/*     */     }
/* 125 */     if ((this.casServerName != null) && (this.casServiceUrl != null)) {
/* 126 */       throw new ServletException("serverName and serviceUrl cannot both be set: choose one.");
/*     */     }
/* 128 */     if ((this.casServerName == null) && (this.casServiceUrl == null)) {
/* 129 */       throw new ServletException("one of serverName or serviceUrl must be set.");
/*     */     }
/* 131 */     if (this.casValidate == null)
/* 132 */       throw new ServletException("validateUrl parameter must be set.");
/* 133 */     if (casAuthorizedProxy != null)
/*     */     {
/* 135 */       StringTokenizer casProxies = new StringTokenizer(casAuthorizedProxy);
/*     */       String anAuthorizedProxy;
/* 136 */       for (; casProxies.hasMoreTokens(); this.authorizedProxies.add(anAuthorizedProxy))
/*     */       {
/* 138 */         anAuthorizedProxy = casProxies.nextToken();
/*     */       }
/*     */     }
/* 141 */     if (log.isDebugEnabled())
/* 142 */       log.debug("CASFilter initialized as: [" + toString() + "]");
/*     */   }
/*     */ 
/*     */   private boolean isLive(String url)
/*     */   {
/* 147 */     log.debug("===========casAlive address is " + url);
/* 148 */     if (!StringUtils.isBlank(url)) {
/* 149 */       HttpURLConnection urlconn = null;
/*     */       try {
/* 151 */         urlconn = (HttpURLConnection)new URL(url).openConnection();
/*     */ 
/* 153 */         urlconn.setConnectTimeout(30000);
/* 154 */         urlconn.setReadTimeout(30000);
/* 155 */         int code = urlconn.getResponseCode();
/* 156 */         if (code == 200)
/* 157 */           return true;
/*     */       } catch (Exception ex) {
/*     */       }
/*     */       finally {
/* 161 */         urlconn.disconnect();
/*     */       }
/*     */     }
/* 164 */     return false;
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc) throws ServletException, IOException
/*     */   {
/* 169 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/* 170 */     HttpServletResponse httpResponse = (HttpServletResponse)response;
/* 171 */     String url = getUrl(httpRequest);
/* 172 */     log.debug("[CASFilter]=================请求地址为=" + url);
/*     */ 
/* 175 */     log.debug("============进入casFilter的sessionID是：" + httpRequest.getSession().getId());
/*     */ 
/* 180 */     if (!isLive(this.casAlive)) {
/* 181 */       log.error("=========casAlive is not available，cas 连接不上！");
/* 182 */       fc.doFilter(request, response);
/* 183 */       return;
/*     */     }
/*     */ 
/* 187 */     String uri = httpRequest.getRequestURL().toString();
/* 188 */     if (belongUnprotectdUrl(uri)) {
/* 189 */       fc.doFilter(request, response);
/* 190 */       return;
/*     */     }
/*     */ 
/* 193 */     HttpSession session = httpRequest.getSession();
/* 194 */     log.debug("===================session中的CAS_FILTER_RECEIPT是：" + session.getAttribute("edu.yale.its.tp.cas.client.filter.receipt"));
/*     */ 
/* 197 */     CASReceipt receipt = (CASReceipt)session.getAttribute("edu.yale.its.tp.cas.client.filter.receipt");
/* 198 */     if ((this.casProxyCallbackUrl != null) && (this.casProxyCallbackUrl.endsWith(httpRequest.getRequestURI())) && (httpRequest.getParameter("pgtId") != null) && (httpRequest.getParameter("pgtIou") != null) && (isReceiptAcceptable(receipt)))
/*     */     {
/* 203 */       log.debug("[CASFilter]passing through what we hope is CAS's request for proxy ticket receptor.");
/* 204 */       fc.doFilter(request, response);
/* 205 */       return;
/*     */     }
/* 207 */     if (this.wrapRequest) {
/* 208 */       request = new CASFilterRequestWrapper(httpRequest);
/*     */     }
/*     */ 
/* 211 */     String ticket = request.getParameter("ticket");
/*     */ 
/* 213 */     if (StringUtils.isBlank(ticket))
/*     */     {
/* 221 */       if ((session.getAttribute("edu.yale.its.tp.cas.client.filter.receipt") != null) || (!StringUtils.isBlank(request.getParameter("casReceiptFlag"))))
/*     */       {
/* 223 */         if (session.getAttribute("isPwdExpired") != null) {
/* 224 */           request.setCharacterEncoding("GBK");
/* 225 */           response.setContentType("text/html; charset=GBK");
/* 226 */           if (session.getAttribute("isPwdExpired").toString().endsWith("true")) {
/* 227 */             response.getWriter().print("<script charset=\"GBK\" language=\"javascript\">alert('尊敬的用户,您的密码已过期,请修改密码.\\n密码过期并不影响您正常使用经营分析系统,\\n但出于安全考虑,我们强烈建议您及时修改您的密码!')</script>");
/* 228 */           } else if (session.getAttribute("isPwdExpired").toString().endsWith("false")) {
/* 229 */             String remainDays = session.getAttribute("remainDays").toString();
/* 230 */             response.getWriter().print(new StringBuilder("<script charset=\"GBK\" language=\"javascript\">alert('尊敬的用户,您的密码离过期还剩余").append(remainDays).append("天.为了不影响您的正常使用,请及时修改您的设置')</script>"));
/*     */           }
/*     */ 
/* 234 */           session.removeAttribute("isPwdExpired");
/* 235 */           session.removeAttribute("remainDays");
/*     */         }
/* 237 */         Object obj = session.getAttribute("aibi_component_privilege_sessionlistener");
/*     */ 
/* 239 */         log.debug("=========================session.getAttribute(CAS_FILTER_RECEIPT)!=null 的sessionid为：" + session.getId());
/*     */ 
/* 241 */         log.debug("=========================session.getAttribute(CAS_FILTER_RECEIPT)!=null 放入的sessionListener为：" + obj);
/* 242 */         fc.doFilter(request, response);
/* 243 */         return;
/*     */       }
/*     */ 
/* 247 */       log.info("[CASFilter]第一次请求: ticket = " + ticket + ", sessionId = " + session.getId());
/*     */ 
/* 249 */       boolean didGateway = Boolean.valueOf((String)session.getAttribute("edu.yale.its.tp.cas.client.filter.didGateway")).booleanValue();
/*     */ 
/* 251 */       if (this.casLogin == null) {
/* 252 */         log.fatal("[CASFilter]casLogin was not set, so filter cannot redirect request for authentication.");
/* 253 */         throw new ServletException("When CASFilter protects pages that do not receive a 'ticket' parameter, it needs a edu.yale.its.tp.cas.client.filter.loginUrl filter parameter");
/*     */       }
/* 255 */       if (!didGateway) {
/* 256 */         log.debug("[CASFilter]Did not previously gateway.  Setting session attribute to true.");
/* 257 */         session.setAttribute("edu.yale.its.tp.cas.client.filter.didGateway", "true");
/* 258 */         redirectToCAS(httpRequest, httpResponse);
/* 259 */         return;
/*     */       }
/* 261 */       if ((this.casGateway) || (session.getAttribute("edu.yale.its.tp.cas.client.filter.user") != null)) {
/* 262 */         fc.doFilter(request, response);
/* 263 */         return;
/*     */       }
/* 265 */       session.setAttribute("edu.yale.its.tp.cas.client.filter.didGateway", "true");
/*     */ 
/* 267 */       redirectToCAS(httpRequest, httpResponse);
/* 268 */       return;
/*     */     }
/*     */ 
/* 273 */     log.info("[CASFilter]第二次请求: ticket = " + ticket + ", sessionId = " + session.getId());
/*     */     try
/*     */     {
/* 277 */       receipt = getAuthenticatedUser(httpRequest);
/*     */     } catch (CASAuthenticationException e) {
/* 279 */       log.error(e);
/* 280 */       throw new ServletException(e);
/*     */     }
/* 282 */     if (!isReceiptAcceptable(receipt)) {
/* 283 */       throw new ServletException("Authentication was technically successful but rejected as a matter of policy. [" + receipt + "]");
/*     */     }
/* 285 */     if (session != null) {
/* 286 */       session.setAttribute("edu.yale.its.tp.cas.client.filter.user", receipt.getUserName());
/* 287 */       session.setAttribute("edu.yale.its.tp.cas.client.filter.receipt", receipt);
/* 288 */       session.removeAttribute("edu.yale.its.tp.cas.client.filter.didGateway");
/*     */     }
/* 290 */     if (log.isTraceEnabled()) {
/* 291 */       log.debug("[CASFilter]validated ticket to get authenticated receipt [" + receipt + "], now passing request along filter chain.");
/*     */     }
/* 293 */     url = httpRequest.getRequestURL().toString();
/*     */     try
/*     */     {
/* 296 */       login(httpRequest, httpResponse, receipt.getUserName());
/* 297 */       Object obj = httpRequest.getSession().getAttribute("aibi_component_privilege_sessionlistener");
/*     */ 
/* 299 */       log.debug("=========================放入的sessionListener为：" + obj);
/*     */     } catch (Exception e) {
/* 301 */       log.error("login(httpRequest,httpResponse,receipt.getUserName());登陆出错了！", e);
/* 302 */       throw new ServletException("login happens error");
/*     */     }
/*     */ 
/* 306 */     String goTo = request.getParameter("original_url");
/*     */ 
/* 308 */     goTo = getNoEnocdeUrl(goTo);
/* 309 */     log.debug("==========解码后的goTo:" + goTo);
/*     */ 
/* 312 */     if (goTo.indexOf("cas_flag1") != -1)
/*     */     {
/* 314 */       String goTo_prefix = goTo.substring(0, goTo.indexOf("cas_flag1") + 1);
/*     */ 
/* 316 */       String goTo_suffix = URLEncoder.encode(goTo.substring(goTo.indexOf("cas_flag1") + 1), "UTF-8");
/*     */ 
/* 318 */       goTo_suffix = goTo_suffix.replaceAll("%3D", "=");
/*     */ 
/* 320 */       goTo = goTo_prefix + goTo_suffix;
/*     */     }
/*     */ 
/* 323 */     log.debug("===========这是拼凑的goTo:" + goTo);
/*     */ 
/* 325 */     goTo = goTo.replace("cas_flag1", "?");
/* 326 */     goTo = goTo.replace("cas_flag2", "&");
/*     */ 
/* 328 */     if (goTo.indexOf("?") != -1)
/* 329 */       goTo = goTo + "&casReceiptFlag=0";
/*     */     else {
/* 331 */       goTo = goTo + "?casReceiptFlag=0";
/*     */     }
/* 333 */     if ((url != null) && (goTo != null) && (request.getParameter("ticket") != null)) {
/* 334 */       String port = httpRequest.getServerPort() + "";
/* 335 */       int startIndex = goTo.indexOf(port) + port.length();
/* 336 */       if ((goTo.substring(startIndex).length() > 2) && (goTo.indexOf("login.jsp") == -1))
/*     */       {
/* 338 */         log.debug("[CASFilter]从哪来回哪去的最终地址：" + goTo);
/*     */ 
/* 340 */         if ((!StringUtils.isBlank(this.distributeMachineAddress)) && (goTo.indexOf(this.distributeMachineAddress) != -1)) {
/* 341 */           httpResponse.sendRedirect(this.casServiceUrl);
/*     */         }
/*     */ 
/* 344 */         httpResponse.sendRedirect(goTo);
/*     */       } else {
/* 346 */         httpResponse.sendRedirect(this.casServiceUrl);
/*     */       }
/* 348 */       return;
/*     */     }
/* 350 */     fc.doFilter(request, response);
/* 351 */     log.debug("returning from doFilter()");
/*     */   }
/*     */ 
/*     */   private boolean isReceiptAcceptable(CASReceipt receipt)
/*     */   {
/* 357 */     if (receipt == null) {
/* 358 */       throw new IllegalArgumentException("Cannot evaluate a null receipt.");
/*     */     }
/* 360 */     if ((this.casRenew) && (!receipt.isPrimaryAuthentication()))
/* 361 */       return false;
/* 362 */     return (!receipt.isProxied()) || (this.authorizedProxies.contains(receipt.getProxyingService()));
/*     */   }
/*     */ 
/*     */   private CASReceipt getAuthenticatedUser(HttpServletRequest request)
/*     */     throws ServletException, CASAuthenticationException, UnsupportedEncodingException
/*     */   {
/* 377 */     log.debug("entering getAuthenticatedUser()");
/* 378 */     ProxyTicketValidator pv = null;
/* 379 */     pv = new ProxyTicketValidator();
/* 380 */     pv.setCasValidateUrl(this.casValidate);
/* 381 */     pv.setServiceTicket(request.getParameter("ticket"));
/* 382 */     String service_url = getService(request);
/* 383 */     String original_url = request.getParameter("original_url");
/* 384 */     log.debug("===========getAuthenticatedUser中的返回地址：" + original_url);
/*     */ 
/* 386 */     original_url = getNoEnocdeUrl(original_url);
/*     */ 
/* 388 */     original_url = URLEncoder.encode(original_url, "UTF-8");
/*     */ 
/* 391 */     if (!StringUtils.isBlank(original_url)) {
/* 392 */       if (service_url.indexOf("%3F") != -1)
/* 393 */         service_url = service_url + URLEncoder.encode(new StringBuilder().append("&original_url=").append(URLEncoder.encode(original_url, "UTF-8")).toString(), "UTF-8");
/*     */       else {
/* 395 */         service_url = service_url + URLEncoder.encode(new StringBuilder().append("?original_url=").append(URLEncoder.encode(original_url, "UTF-8")).toString(), "UTF-8");
/*     */       }
/*     */     }
/* 398 */     System.out.println("=======================第二次重定向getAuthenticatedUser中的serviceURL是：" + service_url);
/* 399 */     log.debug("=======================第二次重定向getAuthenticatedUser中的serviceURL是：" + service_url);
/* 400 */     pv.setService(service_url);
/* 401 */     pv.setRenew(Boolean.valueOf(this.casRenew).booleanValue());
/* 402 */     if (this.casProxyCallbackUrl != null)
/* 403 */       pv.setProxyCallbackUrl(this.casProxyCallbackUrl);
/* 404 */     if (log.isDebugEnabled()) {
/* 405 */       log.debug("about to validate ProxyTicketValidator: [" + pv + "]");
/*     */     }
/*     */ 
/* 408 */     return CASReceipt.getReceipt(pv);
/*     */   }
/*     */ 
/*     */   private String getService(HttpServletRequest request)
/*     */     throws ServletException, UnsupportedEncodingException
/*     */   {
/* 421 */     log.debug("entering getService()");
/* 422 */     if ((this.casServerName == null) && (this.casServiceUrl == null))
/* 423 */       throw new ServletException("need one of the following configuration parameters: edu.yale.its.tp.cas.client.filter.serviceUrl or edu.yale.its.tp.cas.client.filter.serverName");
/*     */     String serviceString;
/*     */     String serviceString;
/* 426 */     if (this.casServiceUrl != null)
/* 427 */       serviceString = URLEncoder.encode(this.casServiceUrl, "UTF-8");
/*     */     else
/* 429 */       serviceString = Util.getService(request, this.casServerName);
/* 430 */     if (log.isTraceEnabled()) {
/* 431 */       log.debug("returning from getService() with service [" + serviceString + "]");
/*     */     }
/*     */ 
/* 434 */     return serviceString;
/*     */   }
/*     */ 
/*     */   private void redirectToCAS(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 449 */     log.debug("===配置的4A登录地址:" + this.cas4ALogin);
/* 450 */     log.debug("===4A登录地址是否连通：" + isLive(this.cas4ALogin));
/* 451 */     if ((!StringUtils.isBlank(this.cas4ALogin)) && (isLive(this.cas4ALogin)) && (!"true".equalsIgnoreCase(request.getParameter("isAutoLogin")))) {
/* 452 */       response.sendRedirect(this.cas4ALogin);
/* 453 */       return;
/*     */     }
/* 455 */     String service_url = getService(request);
/* 456 */     String original_url = "";
/* 457 */     if (StringUtils.isBlank(request.getParameter("original_url")))
/* 458 */       original_url = getUrl(request);
/*     */     else {
/* 460 */       original_url = request.getParameter("original_url");
/*     */     }
/*     */ 
/* 463 */     original_url = getNoEnocdeUrl(original_url);
/*     */ 
/* 465 */     original_url = original_url.replace("?", "cas_flag1");
/* 466 */     original_url = original_url.replace("&", "cas_flag2");
/*     */ 
/* 468 */     original_url = URLEncoder.encode(original_url, "UTF-8");
/*     */ 
/* 470 */     if (service_url.indexOf("%3F") != -1)
/* 471 */       service_url = service_url + URLEncoder.encode(new StringBuilder().append("&original_url=").append(URLEncoder.encode(original_url, "UTF-8")).toString(), "UTF-8");
/*     */     else {
/* 473 */       service_url = service_url + URLEncoder.encode(new StringBuilder().append("?original_url=").append(URLEncoder.encode(original_url, "UTF-8")).toString(), "UTF-8");
/*     */     }
/*     */ 
/* 476 */     System.out.println("casLogin " + this.casLogin);
/* 477 */     System.out.println("=======================第一次重定向改造后的serviceURL是：" + service_url);
/* 478 */     log.debug("=======================第一次重定向改造后的serviceURL是：" + service_url);
/* 479 */     String redirectLoginUrl = this.casLogin + "?service=" + service_url + (this.casRenew ? "&renew=true" : "") + (this.casGateway ? "&gateway=true" : "");
/*     */ 
/* 483 */     if (log.isDebugEnabled()) {
/* 484 */       log.debug("Redirecting browser to  [" + redirectLoginUrl + ")");
/*     */     }
/*     */ 
/* 489 */     String reqParam = request.getQueryString();
/* 490 */     if ((reqParam != null) && (!"".equals(reqParam))) {
/* 491 */       redirectLoginUrl = redirectLoginUrl + "&" + reqParam;
/*     */     }
/* 493 */     response.sendRedirect(redirectLoginUrl);
/* 494 */     if (log.isDebugEnabled())
/* 495 */       log.debug("returning from redirectToCAS()");
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 499 */     StringBuffer sb = new StringBuffer();
/* 500 */     sb.append("[CASFilter:");
/* 501 */     sb.append(" casGateway=");
/* 502 */     sb.append(this.casGateway);
/* 503 */     sb.append(" wrapRequest=");
/* 504 */     sb.append(this.wrapRequest);
/* 505 */     sb.append(" casAuthorizedProxies=[");
/* 506 */     sb.append(this.authorizedProxies);
/* 507 */     sb.append("]");
/* 508 */     if (this.casLogin != null) {
/* 509 */       sb.append(" casLogin=[");
/* 510 */       sb.append(this.casLogin);
/* 511 */       sb.append("]");
/*     */     } else {
/* 513 */       sb.append(" casLogin=NULL!!!!!");
/*     */     }
/* 515 */     if (this.casProxyCallbackUrl != null) {
/* 516 */       sb.append(" casProxyCallbackUrl=[");
/* 517 */       sb.append(this.casProxyCallbackUrl);
/* 518 */       sb.append("]");
/*     */     }
/* 520 */     if (this.casRenew)
/* 521 */       sb.append(" casRenew=true");
/* 522 */     if (this.casServerName != null) {
/* 523 */       sb.append(" casServerName=[");
/* 524 */       sb.append(this.casServerName);
/* 525 */       sb.append("]");
/*     */     }
/* 527 */     if (this.casServiceUrl != null) {
/* 528 */       sb.append(" casServiceUrl=[");
/* 529 */       sb.append(this.casServiceUrl);
/* 530 */       sb.append("]");
/*     */     }
/* 532 */     if (this.casValidate != null) {
/* 533 */       sb.append(" casValidate=[");
/* 534 */       sb.append(this.casValidate);
/* 535 */       sb.append("]");
/*     */     } else {
/* 537 */       sb.append(" casValidate=NULL!!!");
/*     */     }
/* 539 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*     */   }
/*     */ 
/*     */   private String getUrl(HttpServletRequest request) {
/* 546 */     StringBuffer buffer = new StringBuffer("?");
/* 547 */     Enumeration it = request.getParameterNames();
/* 548 */     if (it != null)
/*     */     {
/*     */       String name;
/*     */       String value;
/* 551 */       for (; it.hasMoreElements(); buffer.append(name + "=" + value + "&"))
/*     */       {
/* 554 */         name = (String)it.nextElement();
/* 555 */         value = request.getParameterValues(name)[0];
/*     */       }
/*     */     }
/* 558 */     buffer.delete(buffer.length() - 1, buffer.length());
/* 559 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   private String getNoEnocdeUrl(String url)
/*     */   {
/* 570 */     if (!StringUtils.isBlank(url)) {
/*     */       try {
/* 572 */         String decodeUrl = URLDecoder.decode(url, "UTF-8");
/* 573 */         if (decodeUrl.equals(url)) {
/* 574 */           return url;
/*     */         }
/* 576 */         return getNoEnocdeUrl(decodeUrl);
/*     */       }
/*     */       catch (UnsupportedEncodingException e) {
/* 579 */         e.printStackTrace();
/* 580 */         return url;
/*     */       }
/*     */     }
/* 583 */     return "";
/*     */   }
/*     */ 
/*     */   public abstract void login(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString)
/*     */     throws Exception;
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.filter.CASFilter
 * JD-Core Version:    0.6.2
 */
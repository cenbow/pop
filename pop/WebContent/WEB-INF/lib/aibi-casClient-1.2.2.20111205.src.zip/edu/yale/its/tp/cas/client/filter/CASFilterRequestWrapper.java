/*    */ package edu.yale.its.tp.cas.client.filter;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletRequestWrapper;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class CASFilterRequestWrapper extends HttpServletRequestWrapper
/*    */ {
/* 17 */   private static Log log = LogFactory.getLog(CASFilterRequestWrapper.class);
/*    */ 
/*    */   public CASFilterRequestWrapper(HttpServletRequest request) {
/* 20 */     super(request);
/* 21 */     if (log.isTraceEnabled())
/* 22 */       log.trace("wrapping an HttpServletRequest in a CASFilterRequestWrapper.");
/*    */   }
/*    */ 
/*    */   public String getRemoteUser()
/*    */   {
/* 32 */     String user = (String)getSession().getAttribute("edu.yale.its.tp.cas.client.filter.user");
/* 33 */     if (log.isTraceEnabled()) {
/* 34 */       log.trace("getRemoteUser() returning [" + user + "]");
/*    */     }
/* 36 */     return user;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.filter.CASFilterRequestWrapper
 * JD-Core Version:    0.6.2
 */
/*     */ package edu.yale.its.tp.cas.client.filter;
/*     */ 
/*     */ import edu.yale.its.tp.cas.client.CASAuthenticationException;
/*     */ import edu.yale.its.tp.cas.client.CASReceipt;
/*     */ import edu.yale.its.tp.cas.client.ProxyTicketValidator;
/*     */ import edu.yale.its.tp.cas.client.Util;
/*     */ import java.io.IOException;
/*     */ import java.net.URLEncoder;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class CASValidateFilter
/*     */   implements Filter
/*     */ {
/*  84 */   private static Log log = LogFactory.getLog(CASValidateFilter.class);
/*     */   public static final String VALIDATE_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.validateUrl";
/*     */   public static final String SERVICE_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.serviceUrl";
/*     */   public static final String SERVERNAME_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.serverName";
/*     */   public static final String RENEW_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.renew";
/*     */   public static final String PROXY_CALLBACK_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.proxyCallbackUrl";
/*     */   public static final String WRAP_REQUESTS_INIT_PARAM = "edu.yale.its.tp.cas.client.filter.wrapRequest";
/*     */   public static final String CAS_FILTER_USER = "edu.yale.its.tp.cas.client.filter.user";
/*     */   public static final String CAS_FILTER_RECEIPT = "edu.yale.its.tp.cas.client.filter.receipt";
/*     */   private String casValidate;
/*     */   private String casServiceUrl;
/*     */   private String casServerName;
/*     */   private String casProxyCallbackUrl;
/*     */   private boolean casRenew;
/*     */   private boolean wrapRequest;
/*     */ 
/*     */   public void init(FilterConfig config)
/*     */     throws ServletException
/*     */   {
/* 181 */     this.casValidate = config.getInitParameter("edu.yale.its.tp.cas.client.filter.validateUrl");
/* 182 */     this.casServiceUrl = config.getInitParameter("edu.yale.its.tp.cas.client.filter.serviceUrl");
/* 183 */     this.casRenew = Boolean.valueOf(config.getInitParameter("edu.yale.its.tp.cas.client.filter.renew")).booleanValue();
/*     */ 
/* 185 */     this.casServerName = config.getInitParameter("edu.yale.its.tp.cas.client.filter.serverName");
/* 186 */     this.casProxyCallbackUrl = config.getInitParameter("edu.yale.its.tp.cas.client.filter.proxyCallbackUrl");
/*     */ 
/* 188 */     this.wrapRequest = Boolean.valueOf(config.getInitParameter("edu.yale.its.tp.cas.client.filter.wrapRequest")).booleanValue();
/*     */ 
/* 192 */     if ((this.casServerName != null) && (this.casServiceUrl != null)) {
/* 193 */       throw new ServletException("serverName and serviceUrl cannot both be set: choose one.");
/*     */     }
/*     */ 
/* 196 */     if ((this.casServerName == null) && (this.casServiceUrl == null)) {
/* 197 */       throw new ServletException("one of serverName or serviceUrl must be set.");
/*     */     }
/*     */ 
/* 200 */     if ((this.casServiceUrl != null) && 
/* 201 */       (!this.casServiceUrl.startsWith("https://")) && (!this.casServiceUrl.startsWith("http://")))
/*     */     {
/* 203 */       throw new ServletException("service URL must start with http:// or https://; its current value is [" + this.casServiceUrl + "]");
/*     */     }
/*     */ 
/* 209 */     if (this.casValidate == null) {
/* 210 */       throw new ServletException("validateUrl parameter must be set.");
/*     */     }
/* 212 */     if (!this.casValidate.startsWith("https://")) {
/* 213 */       throw new ServletException("validateUrl must start with https://, its current value is [" + this.casValidate + "]");
/*     */     }
/*     */ 
/* 218 */     if (log.isDebugEnabled())
/* 219 */       log.debug("CASValidateFilter initialized as: [" + toString() + "]");
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc)
/*     */     throws ServletException, IOException
/*     */   {
/* 230 */     if (log.isTraceEnabled()) {
/* 231 */       log.trace("entering doFilter()");
/*     */     }
/*     */ 
/* 235 */     if ((!(request instanceof HttpServletRequest)) || (!(response instanceof HttpServletResponse)))
/*     */     {
/* 237 */       log.error("doFilter() called on a request or response that was not an HttpServletRequest or response.");
/*     */ 
/* 239 */       throw new ServletException("CASFilter protects only HTTP resources");
/*     */     }
/*     */ 
/* 244 */     if ((this.casProxyCallbackUrl != null) && (this.casProxyCallbackUrl.endsWith(((HttpServletRequest)request).getRequestURI())) && (request.getParameter("pgtId") != null) && (request.getParameter("pgtIou") != null))
/*     */     {
/* 249 */       log.trace("passing through what we hope is CAS's request for proxy ticket receptor.");
/*     */ 
/* 251 */       fc.doFilter(request, response);
/* 252 */       return;
/*     */     }
/*     */ 
/* 256 */     if (this.wrapRequest) {
/* 257 */       log.trace("Wrapping request with CASFilterRequestWrapper.");
/* 258 */       request = new CASFilterRequestWrapper((HttpServletRequest)request);
/*     */     }
/*     */ 
/* 261 */     HttpSession session = ((HttpServletRequest)request).getSession();
/*     */ 
/* 265 */     CASReceipt receipt = (CASReceipt)session.getAttribute("edu.yale.its.tp.cas.client.filter.receipt");
/*     */ 
/* 267 */     if (receipt != null) {
/* 268 */       log.trace("CAS_FILTER_RECEIPT attribute was present - passing  request through filter..");
/*     */ 
/* 270 */       fc.doFilter(request, response);
/* 271 */       return;
/*     */     }
/*     */ 
/* 275 */     String ticket = request.getParameter("ticket");
/*     */ 
/* 278 */     if ((ticket == null) || (ticket.equals(""))) {
/* 279 */       log.trace("CAS ticket was not present on request.");
/* 280 */       fc.doFilter(request, response);
/* 281 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 285 */       receipt = getAuthenticatedUser((HttpServletRequest)request);
/*     */     } catch (CASAuthenticationException e) {
/* 287 */       log.error(e);
/* 288 */       throw new ServletException(e);
/*     */     }
/*     */ 
/* 292 */     if (session != null) {
/* 293 */       session.setAttribute("edu.yale.its.tp.cas.client.filter.user", receipt.getUserName());
/* 294 */       session.setAttribute("edu.yale.its.tp.cas.client.filter.receipt", receipt);
/*     */     }
/* 296 */     if (log.isTraceEnabled()) {
/* 297 */       log.trace("validated ticket to get authenticated receipt [" + receipt + "], now passing request along filter chain.");
/*     */     }
/*     */ 
/* 302 */     fc.doFilter(request, response);
/* 303 */     log.trace("returning from doFilter()");
/*     */   }
/*     */ 
/*     */   private CASReceipt getAuthenticatedUser(HttpServletRequest request)
/*     */     throws ServletException, CASAuthenticationException
/*     */   {
/* 320 */     log.trace("entering getAuthenticatedUser()");
/* 321 */     ProxyTicketValidator pv = null;
/*     */ 
/* 323 */     pv = new ProxyTicketValidator();
/* 324 */     pv.setCasValidateUrl(this.casValidate);
/* 325 */     pv.setServiceTicket(request.getParameter("ticket"));
/* 326 */     pv.setService(getService(request));
/* 327 */     pv.setRenew(Boolean.valueOf(this.casRenew).booleanValue());
/* 328 */     if (this.casProxyCallbackUrl != null) {
/* 329 */       pv.setProxyCallbackUrl(this.casProxyCallbackUrl);
/*     */     }
/* 331 */     if (log.isDebugEnabled()) {
/* 332 */       log.debug("about to validate ProxyTicketValidator: [" + pv + "]");
/*     */     }
/*     */ 
/* 335 */     return CASReceipt.getReceipt(pv);
/*     */   }
/*     */ 
/*     */   private String getService(HttpServletRequest request)
/*     */     throws ServletException
/*     */   {
/* 346 */     log.trace("entering getService()");
/*     */ 
/* 350 */     if ((this.casServerName == null) && (this.casServiceUrl == null))
/* 351 */       throw new ServletException("need one of the following configuration parameters: edu.yale.its.tp.cas.client.filter.serviceUrl or edu.yale.its.tp.cas.client.filter.serverName");
/*     */     String serviceString;
/*     */     String serviceString;
/* 357 */     if (this.casServiceUrl != null) {
/* 358 */       serviceString = URLEncoder.encode(this.casServiceUrl);
/*     */     }
/*     */     else
/* 361 */       serviceString = Util.getService(request, this.casServerName);
/* 362 */     if (log.isTraceEnabled()) {
/* 363 */       log.trace("returning from getService() with service [" + serviceString + "]");
/*     */     }
/*     */ 
/* 366 */     return serviceString;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 370 */     StringBuffer sb = new StringBuffer();
/* 371 */     sb.append("[CASValidateFilter:");
/*     */ 
/* 373 */     sb.append(" wrapRequest=");
/* 374 */     sb.append(this.wrapRequest);
/*     */ 
/* 376 */     sb.append(" casProxyCallbackUrl=[");
/* 377 */     sb.append(this.casProxyCallbackUrl);
/* 378 */     sb.append("]");
/*     */ 
/* 380 */     if (this.casRenew) {
/* 381 */       sb.append(" casRenew=true");
/*     */     }
/*     */ 
/* 384 */     sb.append(" casServerName=[");
/* 385 */     sb.append(this.casServerName);
/* 386 */     sb.append("]");
/*     */ 
/* 388 */     sb.append(" casServiceUrl=[");
/* 389 */     sb.append(this.casServiceUrl);
/* 390 */     sb.append("]");
/*     */ 
/* 392 */     sb.append(" casValidate=[");
/* 393 */     sb.append(this.casValidate);
/* 394 */     sb.append("]");
/*     */ 
/* 396 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.filter.CASValidateFilter
 * JD-Core Version:    0.6.2
 */
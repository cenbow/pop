/*     */ package edu.yale.its.tp.cas.client.filter;
/*     */ 
/*     */ import edu.yale.its.tp.cas.client.CASReceipt;
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ProxyChainScrutinizerFilter
/*     */   implements Filter
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(ProxyChainScrutinizerFilter.class);
/*     */ 
/*  44 */   private Set authorizedProxyChains = new HashSet();
/*     */   public static final String AUTHORIZED_PROXIES_INITPARAM = "edu.yale.its.tp.cas.client.filter.authorizedProxyChains";
/*     */ 
/*     */   public void init(FilterConfig config)
/*     */     throws ServletException
/*     */   {
/*  59 */     String authorizedProxiesString = config.getInitParameter("edu.yale.its.tp.cas.client.filter.authorizedProxyChains");
/*  60 */     if (authorizedProxiesString == null) {
/*  61 */       throw new ServletException("The filter initialization parameter edu.yale.its.tp.cas.client.filter.authorizedProxyChains must be a semicolon delimited list of authorized filter chains.");
/*     */     }
/*  63 */     List currentAuthorizedChain = new LinkedList();
/*  64 */     StringTokenizer tokenizer = new StringTokenizer(authorizedProxiesString);
/*  65 */     if (!tokenizer.hasMoreTokens()) {
/*  66 */       throw new ServletException("The filter initialization paramter edu.yale.its.tp.cas.client.filter.authorizedProxyChains must contain at least one token.");
/*     */     }
/*  68 */     while (tokenizer.hasMoreTokens()) {
/*  69 */       String token = tokenizer.nextToken();
/*  70 */       if (token.equals(";"))
/*     */       {
/*  72 */         this.authorizedProxyChains.add(currentAuthorizedChain);
/*  73 */         currentAuthorizedChain = new LinkedList();
/*     */       }
/*     */       else {
/*  76 */         if (!token.toUpperCase().startsWith("HTTPS://")) {
/*  77 */           throw new ServletException("Illegal authorized proxy chain element [" + token + "] in value of filter initialization parameter " + "edu.yale.its.tp.cas.client.filter.authorizedProxyChains");
/*     */         }
/*  79 */         currentAuthorizedChain.add(token);
/*     */       }
/*     */     }
/*     */ 
/*  83 */     if (!currentAuthorizedChain.isEmpty()) {
/*  84 */       this.authorizedProxyChains.add(currentAuthorizedChain);
/*     */     }
/*  86 */     if (log.isTraceEnabled())
/*  87 */       log.trace("Configured filter named [" + config.getFilterName() + "] as " + toString());
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc)
/*     */     throws IOException, ServletException
/*     */   {
/*  97 */     if (isRequestAuthorized(request)) {
/*  98 */       if (log.isDebugEnabled()) {
/*  99 */         log.debug("Filter " + this + " is passing through request " + request);
/*     */       }
/* 101 */       fc.doFilter(request, response);
/* 102 */       return;
/*     */     }
/* 104 */     if ((response instanceof HttpServletResponse)) {
/* 105 */       log.info("Sending FORBIDDEN.");
/* 106 */       HttpServletResponse httpResponse = (HttpServletResponse)response;
/* 107 */       httpResponse.sendError(403);
/*     */     } else {
/* 109 */       throw new ServletException("Request was unauthorized (probably not an HttpServletRequest at all) and response was not an HttpServletResponse so couldn't send 403/Forbidden.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isRequestAuthorized(ServletRequest request)
/*     */   {
/* 121 */     if (log.isTraceEnabled()) {
/* 122 */       log.trace("entering isRequestAuthorized(" + request + ")");
/*     */     }
/* 124 */     if (!(request instanceof HttpServletRequest)) {
/* 125 */       log.warn("request was not of expected type HttpServletRequest - considering request unauthorized.");
/* 126 */       return false;
/*     */     }
/* 128 */     HttpSession session = ((HttpServletRequest)request).getSession(false);
/* 129 */     if (session == null) {
/* 130 */       log.info("No HttpSession was established into which a CASReceipt might have been stored - considering request unauthorized.");
/* 131 */       return false;
/*     */     }
/* 133 */     Object potentialReceipt = session.getAttribute("edu.yale.its.tp.cas.client.filter.receipt");
/* 134 */     if (potentialReceipt == null) {
/* 135 */       log.info("CASReceipt was not present in HttpSession - considered request unauthorized.");
/* 136 */       return false;
/*     */     }
/* 138 */     if (!(potentialReceipt instanceof CASReceipt)) {
/* 139 */       log.warn("An object was present in the session attribute edu.yale.its.tp.cas.client.filter.receipt but it wasn't of type " + CASReceipt.class.getName());
/* 140 */       return false;
/*     */     }
/* 142 */     CASReceipt receipt = (CASReceipt)potentialReceipt;
/*     */ 
/* 144 */     if (!this.authorizedProxyChains.contains(receipt.getProxyList())) {
/* 145 */       log.info("CAS receipt: " + receipt + " did not present a proxy chain among those authorized: " + this.authorizedProxyChains + " - considering request unauthorized.");
/* 146 */       return false;
/*     */     }
/* 148 */     log.trace("returning from isRequestAuthorized() with true");
/* 149 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 161 */     StringBuffer sb = new StringBuffer();
/* 162 */     sb.append(getClass().getName());
/* 163 */     sb.append(" authorizedProxyChains:").append(this.authorizedProxyChains);
/* 164 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.filter.ProxyChainScrutinizerFilter
 * JD-Core Version:    0.6.2
 */
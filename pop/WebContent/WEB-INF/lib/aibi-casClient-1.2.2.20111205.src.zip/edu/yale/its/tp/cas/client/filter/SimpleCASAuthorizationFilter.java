/*     */ package edu.yale.its.tp.cas.client.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SimpleCASAuthorizationFilter
/*     */   implements Filter
/*     */ {
/*     */   public static final String AUTHORIZED_USER_STRING = "edu.yale.its.tp.cas.client.filter.authorizedUsers";
/*  43 */   private static final Log log = LogFactory.getLog(SimpleCASAuthorizationFilter.class);
/*     */   private String authorizedUsersString;
/*     */   private List authorizedUsers;
/*     */ 
/*     */   public void init(FilterConfig config)
/*     */     throws ServletException
/*     */   {
/*  55 */     log.trace("entering init()");
/*  56 */     this.authorizedUsersString = config.getInitParameter("edu.yale.its.tp.cas.client.filter.authorizedUsers");
/*     */ 
/*  58 */     StringTokenizer tokenizer = new StringTokenizer(this.authorizedUsersString);
/*  59 */     this.authorizedUsers = new ArrayList();
/*  60 */     while (tokenizer.hasMoreTokens()) {
/*  61 */       this.authorizedUsers.add(tokenizer.nextElement());
/*     */     }
/*  63 */     if (log.isTraceEnabled())
/*  64 */       log.trace("returning from init() having initialized filter as [" + toString() + "]");
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc)
/*     */     throws ServletException, IOException
/*     */   {
/*  77 */     if (log.isTraceEnabled()) {
/*  78 */       log.trace("entering doFilter(" + request + ", " + response + ", " + fc + ")");
/*     */     }
/*     */ 
/*  82 */     if ((!(request instanceof HttpServletRequest)) || (!(response instanceof HttpServletResponse)))
/*     */     {
/*  84 */       log.error("doFilter() called on instance of HttpServletRequest or HttpServletResponse.");
/*  85 */       throw new ServletException(SimpleCASAuthorizationFilter.class.getName() + ": protects only HTTP resources");
/*     */     }
/*     */ 
/*  89 */     HttpSession session = ((HttpServletRequest)request).getSession();
/*  90 */     String currentUser = (String)session.getAttribute("edu.yale.its.tp.cas.client.filter.user");
/*  91 */     if (this.authorizedUsers.isEmpty())
/*     */     {
/*  93 */       log.error("User cannot be authorized if no users are authorized.");
/*     */ 
/*  95 */       throw new ServletException(SimpleCASAuthorizationFilter.class.getName() + ": no authorized users set.");
/*     */     }
/*  97 */     if (!this.authorizedUsers.contains(currentUser)) {
/*  98 */       log.info("Current user [" + currentUser + "] not among authorized users.");
/*     */ 
/* 100 */       throw new ServletException(SimpleCASAuthorizationFilter.class.getName() + ": user " + session.getAttribute("edu.yale.its.tp.cas.client.filter.user") + " not authorized.");
/*     */     }
/*     */ 
/* 106 */     if (log.isTraceEnabled()) {
/* 107 */       log.trace("User [" + currentUser + "] was authorized.  Passing request along filter chain.");
/*     */     }
/*     */ 
/* 110 */     fc.doFilter(request, response);
/* 111 */     log.trace("returning from doFilter()");
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.filter.SimpleCASAuthorizationFilter
 * JD-Core Version:    0.6.2
 */
/*    */ package edu.yale.its.tp.cas.client.filter;
/*    */ 
/*    */ import edu.yale.its.tp.cas.client.CASReceipt;
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class StaticCasReceiptCacherFilter
/*    */   implements Filter
/*    */ {
/* 22 */   private static Log log = LogFactory.getLog(StaticCasReceiptCacherFilter.class);
/*    */ 
/* 25 */   private static Map ticketsToReceipts = Collections.synchronizedMap(new HashMap());
/*    */ 
/*    */   public void init(FilterConfig config)
/*    */     throws ServletException
/*    */   {
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc)
/*    */     throws ServletException, IOException
/*    */   {
/* 35 */     if (log.isTraceEnabled()) {
/* 36 */       log.trace("entering doFilter()");
/*    */     }
/*    */ 
/* 40 */     if ((!(request instanceof HttpServletRequest)) || (!(response instanceof HttpServletResponse)))
/*    */     {
/* 42 */       log.error("doFilter() called on a request or response that was not an HttpServletRequest or response.");
/*    */ 
/* 44 */       throw new ServletException("StaticCasReceiptCacherFilter applies to only HTTP resources");
/*    */     }
/*    */ 
/* 48 */     HttpSession session = ((HttpServletRequest)request).getSession();
/*    */ 
/* 52 */     CASReceipt receipt = (CASReceipt)session.getAttribute("edu.yale.its.tp.cas.client.filter.receipt");
/*    */ 
/* 56 */     String ticket = request.getParameter("ticket");
/*    */ 
/* 58 */     if ((ticket != null) && (receipt != null)) {
/* 59 */       ticketsToReceipts.put(ticket, receipt);
/*    */     }
/*    */ 
/* 63 */     fc.doFilter(request, response);
/* 64 */     log.trace("returning from doFilter()");
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 68 */     StringBuffer sb = new StringBuffer();
/* 69 */     sb.append("[CASFilter:");
/* 70 */     sb.append(ticketsToReceipts);
/* 71 */     sb.append("]");
/* 72 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public static CASReceipt receiptForTicket(String ticket)
/*    */   {
/* 82 */     return (CASReceipt)ticketsToReceipts.get(ticket);
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.filter.StaticCasReceiptCacherFilter
 * JD-Core Version:    0.6.2
 */
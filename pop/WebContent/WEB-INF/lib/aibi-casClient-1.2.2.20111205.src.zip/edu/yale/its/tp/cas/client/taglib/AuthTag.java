/*     */ package edu.yale.its.tp.cas.client.taglib;
/*     */ 
/*     */ import edu.yale.its.tp.cas.client.ProxyTicketValidator;
/*     */ import edu.yale.its.tp.cas.client.Util;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class AuthTag extends TagSupport
/*     */ {
/*     */   private String var;
/*     */   private int scope;
/*     */   private String casLogin;
/*     */   private String casValidate;
/*     */   private String service;
/*     */   private List acceptedProxies;
/*     */   private HttpServletRequest request;
/*     */   private HttpServletResponse response;
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*  78 */     this.request = ((HttpServletRequest)this.pageContext.getRequest());
/*  79 */     this.response = ((HttpServletResponse)this.pageContext.getResponse());
/*     */ 
/*  82 */     this.casLogin = null;
/*  83 */     this.casValidate = null;
/*     */     try {
/*  85 */       this.service = Util.getService(this.request, this.pageContext.getServletContext().getInitParameter("edu.yale.its.tp.cas.serverName"));
/*     */     }
/*     */     catch (ServletException ex)
/*     */     {
/*  91 */       throw new JspException(ex);
/*     */     }
/*  93 */     this.acceptedProxies = new ArrayList();
/*  94 */     return 1;
/*     */   }
/*     */ 
/*     */   public int doEndTag() throws JspTagException
/*     */   {
/*     */     try {
/* 100 */       if (this.pageContext.getAttribute(this.var, this.scope) != null) {
/* 101 */         return 6;
/*     */       }
/*     */ 
/* 104 */       String ticket = this.request.getParameter("ticket");
/*     */ 
/* 107 */       if ((ticket == null) || (ticket.equals(""))) {
/* 108 */         if (this.casLogin == null) {
/* 109 */           throw new JspTagException("for pages that expect to be called without 'ticket' parameter, cas:auth must have a cas:loginUrl subtag");
/*     */         }
/*     */ 
/* 112 */         this.response.sendRedirect(this.casLogin + "?service=" + this.service);
/* 113 */         return 5;
/*     */       }
/*     */ 
/* 117 */       String netid = getAuthenticatedNetid(ticket);
/* 118 */       if (netid == null) {
/* 119 */         throw new JspTagException("Unexpected CAS authentication error");
/*     */       }
/*     */ 
/* 122 */       this.pageContext.setAttribute(this.var, netid, this.scope);
/*     */ 
/* 124 */       return 6;
/*     */     }
/*     */     catch (IOException ex) {
/* 127 */       throw new JspTagException(ex.getMessage());
/*     */     } catch (SAXException ex) {
/* 129 */       throw new JspTagException(ex.getMessage());
/*     */     } catch (ParserConfigurationException ex) {
/* 131 */       throw new JspTagException(ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setVar(String var)
/*     */   {
/* 139 */     this.var = var;
/*     */   }
/*     */ 
/*     */   public void setScope(String scope) {
/* 143 */     if (scope.equals("page"))
/* 144 */       this.scope = 1;
/* 145 */     else if (scope.equals("request"))
/* 146 */       this.scope = 2;
/* 147 */     else if (scope.equals("session"))
/* 148 */       this.scope = 3;
/* 149 */     else if (scope.equals("application"))
/* 150 */       this.scope = 4;
/*     */     else
/* 152 */       throw new IllegalArgumentException("invalid scope");
/*     */   }
/*     */ 
/*     */   public void setCasLogin(String url)
/*     */   {
/* 159 */     this.casLogin = url;
/*     */   }
/*     */ 
/*     */   public void setCasValidate(String url) {
/* 163 */     this.casValidate = url;
/*     */   }
/*     */ 
/*     */   public void addAuthorizedProxy(String proxyId) {
/* 167 */     this.acceptedProxies.add(proxyId);
/*     */   }
/*     */ 
/*     */   public void setService(String service) {
/* 171 */     this.service = service;
/*     */   }
/*     */ 
/*     */   public AuthTag()
/*     */   {
/* 179 */     init();
/*     */   }
/*     */ 
/*     */   public void release()
/*     */   {
/* 184 */     super.release();
/* 185 */     init();
/*     */   }
/*     */ 
/*     */   private void init()
/*     */   {
/* 190 */     this.var = null;
/* 191 */     this.scope = 1;
/* 192 */     this.casLogin = null;
/* 193 */     this.casValidate = null;
/* 194 */     this.acceptedProxies = null;
/*     */   }
/*     */ 
/*     */   private String getAuthenticatedNetid(String ticket)
/*     */     throws ParserConfigurationException, SAXException, IOException, JspTagException
/*     */   {
/* 202 */     ProxyTicketValidator pv = new ProxyTicketValidator();
/* 203 */     pv.setCasValidateUrl(this.casValidate);
/* 204 */     pv.setServiceTicket(ticket);
/* 205 */     pv.setService(this.service);
/* 206 */     pv.validate();
/* 207 */     if (!pv.isAuthenticationSuccesful()) {
/* 208 */       throw new JspTagException("CAS authentication error: " + pv.getErrorCode());
/*     */     }
/* 210 */     if (pv.getProxyList().size() != 0)
/*     */     {
/* 212 */       if (this.acceptedProxies.size() == 0)
/* 213 */         throw new JspTagException("this page does not accept proxied tickets");
/* 214 */       if (!this.acceptedProxies.contains(pv.getProxyList().get(0))) {
/* 215 */         throw new JspTagException("unauthorized top-level proxy: '" + pv.getProxyList().get(0) + "'");
/*     */       }
/*     */     }
/* 218 */     return pv.getUser();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.taglib.AuthTag
 * JD-Core Version:    0.6.2
 */
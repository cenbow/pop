/*    */ package edu.yale.its.tp.cas.client.taglib;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.tagext.BodyContent;
/*    */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*    */ 
/*    */ public class AuthorizedProxyTag extends BodyTagSupport
/*    */ {
/*    */   public int doEndTag()
/*    */     throws JspTagException
/*    */   {
/* 49 */     String authorizedProxy = null;
/* 50 */     if (this.bodyContent != null)
/* 51 */       authorizedProxy = this.bodyContent.getString();
/* 52 */     if (authorizedProxy != null)
/* 53 */       authorizedProxy = authorizedProxy.trim();
/* 54 */     if (!(getParent() instanceof AuthTag)) {
/* 55 */       throw new JspTagException("illegal cas:authorizedProxy outside cas:auth");
/*    */     }
/* 57 */     ((AuthTag)getParent()).addAuthorizedProxy(authorizedProxy);
/* 58 */     return 6;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.taglib.AuthorizedProxyTag
 * JD-Core Version:    0.6.2
 */
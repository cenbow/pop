/*     */ package edu.yale.its.tp.cas.client.taglib;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ 
/*     */ public class LogoutTag extends TagSupport
/*     */ {
/*     */   private String var;
/*     */   private String logoutUrl;
/*     */   private int scope;
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/*  67 */       HttpServletResponse response = (HttpServletResponse)this.pageContext.getResponse();
/*     */ 
/*  71 */       this.pageContext.removeAttribute(this.var, this.scope);
/*     */ 
/*  74 */       if (this.scope == 3) {
/*  75 */         this.pageContext.getSession().invalidate();
/*     */       }
/*     */ 
/*  78 */       response.sendRedirect(this.logoutUrl);
/*     */ 
/*  80 */       return 0;
/*     */     }
/*     */     catch (IOException ex) {
/*  83 */       throw new JspTagException(ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public int doEndTag() {
/*  88 */     return 5;
/*     */   }
/*     */ 
/*     */   public void setVar(String var)
/*     */   {
/*  95 */     this.var = var;
/*     */   }
/*     */ 
/*     */   public void setScope(String scope) {
/*  99 */     if (scope.equals("page"))
/* 100 */       this.scope = 1;
/* 101 */     else if (scope.equals("request"))
/* 102 */       this.scope = 2;
/* 103 */     else if (scope.equals("session"))
/* 104 */       this.scope = 3;
/* 105 */     else if (scope.equals("application"))
/* 106 */       this.scope = 4;
/*     */     else
/* 108 */       throw new IllegalArgumentException("invalid scope");
/*     */   }
/*     */ 
/*     */   public void setLogoutUrl(String logoutUrl) {
/* 112 */     this.logoutUrl = logoutUrl;
/*     */   }
/*     */ 
/*     */   public LogoutTag()
/*     */   {
/* 121 */     init();
/*     */   }
/*     */ 
/*     */   public void release()
/*     */   {
/* 126 */     super.release();
/* 127 */     init();
/*     */   }
/*     */ 
/*     */   private void init()
/*     */   {
/* 132 */     this.var = (this.logoutUrl = null);
/* 133 */     this.scope = 1;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.taglib.LogoutTag
 * JD-Core Version:    0.6.2
 */
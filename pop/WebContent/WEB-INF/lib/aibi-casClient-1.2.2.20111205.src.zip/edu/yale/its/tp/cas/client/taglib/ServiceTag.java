/*    */ package edu.yale.its.tp.cas.client.taglib;
/*    */ 
/*    */ import java.net.URLEncoder;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.tagext.BodyContent;
/*    */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*    */ 
/*    */ public class ServiceTag extends BodyTagSupport
/*    */ {
/*    */   public int doEndTag()
/*    */     throws JspTagException
/*    */   {
/* 49 */     String service = null;
/* 50 */     if (this.bodyContent != null)
/* 51 */       service = this.bodyContent.getString();
/* 52 */     if (service != null)
/* 53 */       service = service.trim();
/* 54 */     if (!(getParent() instanceof AuthTag)) {
/* 55 */       throw new JspTagException("illegal cas:service outside cas:auth");
/*    */     }
/* 57 */     ((AuthTag)getParent()).setService(URLEncoder.encode(service));
/* 58 */     return 6;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.client.taglib.ServiceTag
 * JD-Core Version:    0.6.2
 */
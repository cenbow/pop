/*     */ package edu.yale.its.tp.cas.proxy;
/*     */ 
/*     */ import edu.yale.its.tp.cas.util.SecureURL;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ProxyEchoFilter
/*     */   implements Filter
/*     */ {
/*  35 */   private static final Log log = LogFactory.getLog(ProxyEchoFilter.class);
/*     */   public static final String INIT_PARAM_ECHO_TARGETS = "edu.yale.its.tp.cas.proxy.echo.targets";
/*  46 */   private Set receivedPgtIous = Collections.synchronizedSet(new HashSet());
/*     */ 
/*  51 */   private Set echoTargets = new HashSet();
/*     */ 
/*     */   public void init(FilterConfig config)
/*     */     throws ServletException
/*     */   {
/*  57 */     if (log.isTraceEnabled()) {
/*  58 */       log.trace("initializing ProxyExchoFilter using config " + config);
/*     */     }
/*  60 */     String echoTargetsParam = config.getInitParameter("edu.yale.its.tp.cas.proxy.echo.targets");
/*  61 */     if (echoTargetsParam == null) {
/*  62 */       throw new ServletException("The ProxyEchoFilter requires initialization parameter edu.yale.its.tp.cas.proxy.echo.targets to be a whitespace delimited list of echo targets.");
/*     */     }
/*  64 */     StringTokenizer st = new StringTokenizer(echoTargetsParam);
/*  65 */     while (st.hasMoreTokens()) {
/*  66 */       String target = st.nextToken();
/*  67 */       this.echoTargets.add(target);
/*     */     }
/*  69 */     if (log.isTraceEnabled())
/*  70 */       log.trace("returning from init() having initialized " + this);
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc)
/*     */     throws IOException, ServletException
/*     */   {
/*  79 */     String pgtIou = request.getParameter("pgtIou");
/*  80 */     if (this.receivedPgtIous.add(pgtIou)) {
/*  81 */       int successes = echoRequest(pgtIou, request.getParameter("pgtId"));
/*  82 */       if (log.isDebugEnabled()) {
/*  83 */         log.debug("Echoed the PGT request to " + successes + " of " + this.echoTargets.size() + " targets.");
/*     */       }
/*     */ 
/*  86 */       fc.doFilter(request, response);
/*     */     }
/*  88 */     else if (log.isDebugEnabled()) {
/*  89 */       log.debug("Have already seen pgtIou=[" + pgtIou + "] and so am not echoing it.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private int echoRequest(String pgtIou, String pgtID)
/*     */   {
/* 108 */     int successes = 0;
/* 109 */     for (Iterator iter = this.echoTargets.iterator(); iter.hasNext(); ) {
/* 110 */       StringBuffer target = new StringBuffer();
/* 111 */       target.append((String)iter.next());
/* 112 */       if (target.indexOf("?") == -1)
/* 113 */         target.append("?");
/*     */       else {
/* 115 */         target.append("&");
/*     */       }
/* 117 */       target.append("pgtIou").append("=").append(pgtIou);
/* 118 */       target.append("&").append("pgtId").append("=").append(pgtID);
/*     */       try {
/* 120 */         SecureURL.retrieve(target.toString());
/* 121 */         successes++;
/*     */       } catch (Throwable t) {
/* 123 */         log.error("Failed to retrieve [" + target.toString() + "]", t);
/*     */       }
/*     */     }
/* 126 */     return successes;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 137 */     StringBuffer sb = new StringBuffer();
/* 138 */     sb.append(getClass().getName());
/* 139 */     sb.append(" echoTargets=");
/* 140 */     sb.append(this.echoTargets);
/* 141 */     sb.append(" receivedPgtIous=");
/* 142 */     sb.append(this.receivedPgtIous);
/* 143 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.proxy.ProxyEchoFilter
 * JD-Core Version:    0.6.2
 */
/*     */ package edu.yale.its.tp.cas.proxy;
/*     */ 
/*     */ import edu.yale.its.tp.cas.util.SecureURL;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ class ProxyGrantingTicket
/*     */ {
/*  25 */   private static Log log = LogFactory.getLog(ProxyGrantingTicket.class);
/*     */   private String pgtId;
/*     */   private String casProxyUrl;
/*     */ 
/*     */   ProxyGrantingTicket(String pgtId, String casProxyUrl)
/*     */   {
/*  51 */     if ((pgtId == null) || (casProxyUrl == null)) {
/*  52 */       throw new IllegalArgumentException("Cannot instantiate ProxyGrantingTicket(" + pgtId + "," + casProxyUrl + ")");
/*     */     }
/*     */ 
/*  55 */     this.pgtId = pgtId;
/*  56 */     this.casProxyUrl = casProxyUrl;
/*     */   }
/*     */ 
/*     */   public String getProxyTicket(String target)
/*     */     throws IOException
/*     */   {
/*  70 */     if (log.isTraceEnabled()) {
/*  71 */       log.trace("entering getProxyTicket(target=[" + target + "]) of PGT " + this);
/*     */     }
/*     */ 
/*  75 */     String proxyTicket = null;
/*     */ 
/*  78 */     String url = this.casProxyUrl + "?pgt=" + this.pgtId + "&targetService=" + target;
/*     */ 
/*  80 */     String response = SecureURL.retrieve(url);
/*     */ 
/*  83 */     if ((response.indexOf("<cas:proxySuccess>") != -1) && (response.indexOf("<cas:proxyTicket>") != -1))
/*     */     {
/*  85 */       int startIndex = response.indexOf("<cas:proxyTicket>") + "<cas:proxyTicket>".length();
/*     */ 
/*  87 */       int endIndex = response.indexOf("</cas:proxyTicket>");
/*  88 */       proxyTicket = response.substring(startIndex, endIndex);
/*     */     } else {
/*  90 */       log.error("CAS server responded with error for request [" + url + "].  Full response was [" + response + "]");
/*     */     }
/*     */ 
/*  94 */     log.trace("returning from getProxyTicket() with proxy ticket [" + proxyTicket + "]");
/*     */ 
/*  96 */     return proxyTicket;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 100 */     StringBuffer sb = new StringBuffer();
/* 101 */     sb.append(getClass().getName());
/* 102 */     sb.append(" pgtId=[").append(this.pgtId).append("] ");
/* 103 */     sb.append(" casProxyUrl=[").append(this.casProxyUrl).append("]");
/* 104 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.proxy.ProxyGrantingTicket
 * JD-Core Version:    0.6.2
 */
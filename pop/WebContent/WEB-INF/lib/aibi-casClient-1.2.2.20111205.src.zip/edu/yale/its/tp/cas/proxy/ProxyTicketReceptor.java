/*     */ package edu.yale.its.tp.cas.proxy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ProxyTicketReceptor extends HttpServlet
/*     */ {
/*     */   public static final String CAS_PROXYURL_INIT_PARAM = "edu.yale.its.tp.cas.proxyUrl";
/*     */   static final String PGT_IOU_PARAM = "pgtIou";
/*     */   static final String PGT_ID_PARAM = "pgtId";
/*  52 */   private static Map pgtMap = Collections.synchronizedMap(new HashMap());
/*     */   private String casProxyUrl;
/*  59 */   private static final Log log = LogFactory.getLog(ProxyTicketReceptor.class);
/*     */ 
/*     */   public void init(ServletConfig config)
/*     */     throws ServletException
/*     */   {
/*  65 */     super.init(config);
/*  66 */     if (log.isTraceEnabled()) {
/*  67 */       log.trace("entering init(" + config + ")");
/*     */     }
/*     */ 
/*  71 */     this.casProxyUrl = config.getInitParameter("edu.yale.its.tp.cas.proxyUrl");
/*     */ 
/*  75 */     if (this.casProxyUrl == null) {
/*  76 */       ServletContext app = config.getServletContext();
/*  77 */       this.casProxyUrl = app.getInitParameter("edu.yale.its.tp.cas.proxyUrl");
/*  78 */       if (this.casProxyUrl == null) {
/*  79 */         throw new ServletException("The servlet (or application context) initialization parameter edu.yale.its.tp.cas.proxyUrl must be set.");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  84 */     if (!this.casProxyUrl.toUpperCase().startsWith("HTTPS:")) {
/*  85 */       throw new ServletException("Initialization parameter edu.yale.its.tp.cas.proxyUrl must specify an https: address; its current, unacceptable value is [" + this.casProxyUrl + "]");
/*     */     }
/*     */ 
/*  91 */     if (log.isTraceEnabled())
/*  92 */       log.trace("returning from init() having configured a ProxyTicketReceptor as [" + this + "]");
/*     */   }
/*     */ 
/*     */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 101 */     doGet(request, response);
/*     */   }
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*     */   {
/* 106 */     String pgtId = request.getParameter("pgtId");
/* 107 */     String pgtIou = request.getParameter("pgtIou");
/* 108 */     if ((pgtId != null) && (pgtIou != null)) {
/* 109 */       ProxyGrantingTicket pgt = new ProxyGrantingTicket(pgtId, this.casProxyUrl);
/*     */ 
/* 111 */       log.debug("adding pgtIou=[" + pgtIou + "], pgt=[" + pgt + "] to the cache.");
/*     */ 
/* 114 */       pgtMap.put(pgtIou, pgt);
/*     */ 
/* 117 */       PrintWriter out = response.getWriter();
/*     */ 
/* 120 */       out.println("<casClient:proxySuccess xmlns:casClient=\"http://www.yale.edu/tp/casClient\"/>");
/*     */ 
/* 122 */       out.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getProxyTicket(String pgtIou, String target)
/*     */     throws IOException
/*     */   {
/* 142 */     if (log.isTraceEnabled()) {
/* 143 */       log.trace("entering getProxyTicket(pgtIou=[" + pgtIou + "], target=[" + target + "]");
/*     */     }
/*     */ 
/* 148 */     ProxyGrantingTicket pgt = (ProxyGrantingTicket)pgtMap.get(pgtIou);
/* 149 */     String proxyTicket = null;
/*     */ 
/* 151 */     if (pgt == null)
/* 152 */       log.error("No ProxyGrantingTicket found for pgtIou=[" + pgtIou + "]");
/*     */     else {
/* 154 */       proxyTicket = pgt.getProxyTicket(target);
/*     */     }
/* 156 */     log.trace("returning from getProxyTicket() with proxy ticket [" + proxyTicket + "]");
/*     */ 
/* 158 */     return proxyTicket;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 162 */     StringBuffer sb = new StringBuffer();
/* 163 */     sb.append(getClass().getName());
/* 164 */     sb.append(" ");
/* 165 */     sb.append("casProxyUrl=[");
/* 166 */     sb.append(this.casProxyUrl);
/* 167 */     sb.append("]");
/* 168 */     sb.append(" static map from pgtIous to ProxyGrantingTickets: ");
/* 169 */     sb.append(pgtMap);
/* 170 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.proxy.ProxyTicketReceptor
 * JD-Core Version:    0.6.2
 */
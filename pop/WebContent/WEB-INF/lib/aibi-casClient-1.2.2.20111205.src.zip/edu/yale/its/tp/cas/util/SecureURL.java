/*    */ package edu.yale.its.tp.cas.util;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.PrintStream;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class SecureURL
/*    */ {
/* 51 */   private static Log log = LogFactory.getLog(SecureURL.class);
/*    */ 
/*    */   public static void main(String[] args)
/*    */     throws IOException
/*    */   {
/* 57 */     System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
/*    */ 
/* 60 */     System.out.println(retrieve(args[0]));
/*    */   }
/*    */ 
/*    */   public static String retrieve(String url)
/*    */     throws IOException
/*    */   {
/* 68 */     if (log.isTraceEnabled()) {
/* 69 */       log.trace("entering retrieve(" + url + ")");
/*    */     }
/* 71 */     BufferedReader r = null;
/*    */     try {
/* 73 */       URL u = new URL(url);
/*    */ 
/* 82 */       URLConnection uc = u.openConnection();
/* 83 */       uc.setRequestProperty("Connection", "close");
/* 84 */       r = new BufferedReader(new InputStreamReader(uc.getInputStream()));
/*    */ 
/* 86 */       StringBuffer buf = new StringBuffer();
/*    */       String line;
/* 87 */       while ((line = r.readLine()) != null)
/* 88 */         buf.append(line + "\n");
/* 89 */       return buf.toString();
/*    */     } finally {
/*    */       try {
/* 92 */         if (r != null)
/* 93 */           r.close();
/*    */       }
/*    */       catch (IOException ex)
/*    */       {
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-casClient-1.2.2.20111205.jar
 * Qualified Name:     edu.yale.its.tp.cas.util.SecureURL
 * JD-Core Version:    0.6.2
 */
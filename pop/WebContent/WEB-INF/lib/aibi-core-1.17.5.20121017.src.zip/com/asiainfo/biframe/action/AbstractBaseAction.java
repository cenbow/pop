/*     */ package com.asiainfo.biframe.action;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.BaseRuntimeException;
/*     */ import com.asiainfo.biframe.exception.NotLoginException;
/*     */ import com.asiainfo.biframe.log.ILogService;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*     */ import com.asiainfo.biframe.privilege.IUserSession;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.struts.action.ActionMessage;
/*     */ import org.apache.struts.action.ActionMessages;
/*     */ import org.apache.struts.actions.DispatchAction;
/*     */ 
/*     */ public abstract class AbstractBaseAction extends DispatchAction
/*     */ {
/*     */   protected final String getUserId(HttpServletRequest request)
/*     */     throws NotLoginException
/*     */   {
/*     */     try
/*     */     {
/*  42 */       IUserSession mysession = (IUserSession)request.getSession().getAttribute("biplatform_user");
/*     */ 
/*  46 */       return mysession.getUserID();
/*     */     } catch (Exception e) {
/*  48 */       log.error(LocaleUtil.getLocaleMessage("core", "core.java.getUserFail"), e);
/*     */ 
/*  50 */       throw new NotLoginException(LocaleUtil.getLocaleMessage("core", "core.java.getOperatorFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final String getUserGroupId(HttpServletRequest request)
/*     */     throws NotLoginException
/*     */   {
/*     */     try
/*     */     {
/*  65 */       IUserSession mysession = (IUserSession)request.getSession().getAttribute("biplatform_user");
/*     */ 
/*  67 */       return mysession.getGroupId();
/*     */     } catch (Exception e) {
/*  69 */       log.error(LocaleUtil.getLocaleMessage("core", "core.java.getUserGroupFail"), e);
/*     */ 
/*  71 */       throw new NotLoginException(LocaleUtil.getLocaleMessage("core", "core.java.getOperatorGroupFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected IUser getUser(HttpServletRequest request)
/*     */     throws NotLoginException
/*     */   {
/*     */     try
/*     */     {
/*  86 */       IUserSession mysession = (IUserSession)request.getSession().getAttribute("biplatform_user");
/*     */ 
/*  88 */       return mysession.getUser();
/*     */     } catch (Exception e) {
/*  90 */       log.error(LocaleUtil.getLocaleMessage("core", "core.java.getUserObjectFail"), e);
/*     */ 
/*  92 */       throw new NotLoginException(LocaleUtil.getLocaleMessage("core", "core.java.getUserObjectFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final Object getBean(String name)
/*     */     throws Exception
/*     */   {
/* 107 */     return SystemServiceLocator.getInstance().getService(name);
/*     */   }
/*     */ 
/*     */   protected final IUserPrivilegeService getUserPrivilegeService()
/*     */     throws Exception
/*     */   {
/* 118 */     IUserPrivilegeService retService = null;
/* 119 */     Object service = getBean("userPrivilegeService");
/*     */ 
/* 121 */     if (service != null) {
/* 122 */       retService = (IUserPrivilegeService)service;
/*     */     }
/* 124 */     return retService;
/*     */   }
/*     */ 
/*     */   protected final ILogService getLogService()
/*     */     throws Exception
/*     */   {
/* 134 */     ILogService retService = null;
/* 135 */     Object service = getBean("logService");
/* 136 */     if (service != null) {
/* 137 */       retService = (ILogService)service;
/*     */     }
/* 139 */     return retService;
/*     */   }
/*     */ 
/*     */   protected void saveSuccess(HttpServletRequest request, String msg, String msgKey)
/*     */   {
/* 153 */     ActionMessages messages = getMessages(request);
/* 154 */     if (msg == null) {
/* 155 */       messages.add("org.apache.struts.action.GLOBAL_MESSAGE", new ActionMessage(msgKey, "Failure:"));
/*     */     }
/*     */     else {
/* 158 */       messages.add("org.apache.struts.action.GLOBAL_MESSAGE", new ActionMessage(msgKey, msg));
/*     */     }
/*     */ 
/* 161 */     saveMessages(request, messages);
/*     */   }
/*     */ 
/*     */   protected void saveFailure(HttpServletRequest request, Exception e, String msg, String msgKey)
/*     */   {
/* 176 */     ActionMessages errors = getErrors(request);
/* 177 */     StringBuffer error = new StringBuffer(e.getMessage().length() + 100);
/* 178 */     if (msg != null) {
/* 179 */       error.append(msg);
/*     */     }
/* 181 */     if (e != null) {
/* 182 */       error.append(e.getMessage());
/*     */     }
/* 184 */     errors.add("org.apache.struts.action.GLOBAL_MESSAGE", new ActionMessage(msgKey, error.toString()));
/*     */ 
/* 186 */     saveErrors(request, errors);
/*     */   }
/*     */ 
/*     */   protected void saveFailure(HttpServletRequest request, String msg, String msgKey)
/*     */   {
/* 201 */     saveFailure(request, new BaseRuntimeException(""), msg, msgKey);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.action.AbstractBaseAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.action;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionSupport;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class BaseAction extends ActionSupport
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public ActionContext getContex()
/*     */   {
/*  44 */     ActionContext ctx = ActionContext.getContext();
/*  45 */     return ctx;
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getRequest()
/*     */   {
/*  55 */     ActionContext ctx = ActionContext.getContext();
/*  56 */     HttpServletRequest request = (HttpServletRequest)ctx.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*     */ 
/*  58 */     return request;
/*     */   }
/*     */ 
/*     */   public HttpServletResponse getResponse()
/*     */   {
/*  67 */     ActionContext ctx = ActionContext.getContext();
/*  68 */     HttpServletResponse response = (HttpServletResponse)ctx.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/*  70 */     return response;
/*     */   }
/*     */ 
/*     */   public Map getSession()
/*     */   {
/*  79 */     ActionContext ctx = ActionContext.getContext();
/*  80 */     Map session = ctx.getSession();
/*  81 */     return session;
/*     */   }
/*     */ 
/*     */   public Map getApplication()
/*     */   {
/*  91 */     ActionContext ctx = ActionContext.getContext();
/*  92 */     Map application = ctx.getApplication();
/*  93 */     return application;
/*     */   }
/*     */ 
/*     */   public void sendJson(HttpServletResponse response, String text)
/*     */     throws Exception
/*     */   {
/* 105 */     response.setContentType("text/json; charset=UTF-8");
/* 106 */     response.setHeader("progma", "no-cache");
/* 107 */     response.setHeader("Cache-Control", "no-cache");
/* 108 */     response.getWriter().print(text);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.action.BaseAction
 * JD-Core Version:    0.6.2
 */
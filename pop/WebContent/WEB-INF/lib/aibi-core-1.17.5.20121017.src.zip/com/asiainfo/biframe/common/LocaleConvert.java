/*    */ package com.asiainfo.biframe.common;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class LocaleConvert
/*    */ {
/* 17 */   private static Logger log = Logger.getLogger(LocaleConvert.class);
/*    */ 
/*    */   public static String getParameter(HttpServletRequest request, String paramName)
/*    */     throws Exception
/*    */   {
/* 29 */     String value = "";
/* 30 */     if ((request != null) && (request.getParameter(paramName) != null)) {
/* 31 */       value = request.getParameter(paramName);
/* 32 */       boolean autoConvert = Boolean.parseBoolean(Configure.getInstance().getProperty("LOCALE_AUTO_CONVERT"));
/*    */ 
/* 34 */       if (!autoConvert) {
/* 35 */         log.debug("initial value=[" + value + "]");
/* 36 */         value = new String(value.getBytes("iso-8859-1"), "utf-8");
/* 37 */         log.debug("after convert, value=[" + value + "]");
/*    */       }
/* 39 */       return value;
/*    */     }
/* 41 */     log.warn("request is null or [" + paramName + "] not exist!");
/* 42 */     return null;
/*    */   }
/*    */ 
/*    */   public static String convert(String paramValue)
/*    */     throws Exception
/*    */   {
/* 54 */     boolean autoConvert = Boolean.parseBoolean(Configure.getInstance().getProperty("LOCALE_AUTO_CONVERT"));
/*    */ 
/* 56 */     if (!autoConvert) {
/* 57 */       log.debug("--initial value=[" + paramValue + "]");
/* 58 */       paramValue = new String(paramValue.getBytes("iso-8859-1"), "utf-8");
/* 59 */       log.debug("--after convert, value=[" + paramValue + "]");
/*    */     }
/* 61 */     return paramValue;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.common.LocaleConvert
 * JD-Core Version:    0.6.2
 */
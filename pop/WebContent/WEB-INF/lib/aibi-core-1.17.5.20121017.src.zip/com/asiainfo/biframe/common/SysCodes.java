/*      */ package com.asiainfo.biframe.common;
/*      */ 
/*      */ import com.asiainfo.biframe.common.cache.SysParametersCache;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import org.apache.struts.util.LabelValueBean;
/*      */ 
/*      */ public class SysCodes
/*      */ {
/*   24 */   private static Map m_hashDicts = new HashMap();
/*      */ 
/*   26 */   private static Map m_hashDictNames = new HashMap();
/*      */   public static final String SYSMANAGE_RETURN_INFO = "SYSMANAGE_RETURN_INFO";
/*      */   public static final String DEFAULT_PASSWORD = "asiainfo";
/*      */   public static final String DEFAULT_THEME = "theme";
/*      */   public static final String SYS_ADMIN_GROUP = "1";
/*      */   public static final String SYS_ADMIN_ROLE = "-999";
/*      */   public static final String ALL_RESOURCE_RIGHT = "-1";
/*      */   public static final int ROLE_TYPE = 106;
/*      */   public static final int ROLETYPE_CITY = 0;
/*      */   public static final int ROLETYPE_RESOURCE = 1;
/*      */   public static final int ROLETYPE_OPERATION = 2;
/*      */   public static final int ROLETYPE_USERRELATION = 10;
/*      */   public static final int USER_STATUS = 111;
/*      */   public static final int USERSTATUS_NORMAL = 0;
/*      */   public static final int USERSTATUS_LOCKED = 1;
/*      */   public static final int GROUP_STATUS = 119;
/*      */   public static final int GROUP_NORMAL = 0;
/*      */   public static final int GROUP_UNUSED = 1;
/*      */   public static final int ROLESTATUS_NORMAL = 0;
/*      */   public static final int ROLESTATUS_UNUSED = 1;
/*      */   public static final int OPERATION_TYPE = 107;
/*      */   public static final int OPERATION_TYPE_VIEW = 0;
/*      */   public static final int OPERATION_TYPE_ADD = 1;
/*      */   public static final int OPERATION_TYPE_DELETE = 2;
/*      */   public static final int OPERATION_TYPE_UPDATE = 3;
/*      */   public static final int OPERATION_TYPE_UPLOAD = 4;
/*      */   public static final int OPERATION_TYPE_EXPORT = 5;
/*      */   public static final int OPERATION_TYPE_AUDIT = 6;
/*      */   public static final int OPERATION_TYPE_MANAGEKPI = 7;
/*      */   public static final int OPERATION_TYPE_IMPORT = 8;
/*      */   public static String accessType;
/*      */   public static String INDI_VIEW_RIGHT;
/*      */   public static String INDI_ADMIN_RIGHT;
/*      */   public static final String REPORT_RIGHT_VIEW_RPT_DATA = "1";
/*      */   public static final String REPORT_RIGHT_UPLOAD_RPT = "2";
/*      */   public static final String REPORT_RIGHT_AUDIT_RPT = "3";
/*      */   public static final String REPORT_RIGHT_VIEW_RPT_HEADER = "4";
/*      */   public static final int KPI_STYLE = 101;
/*      */   public static final int KPISTYLE_NORMAL = 0;
/*      */   public static final int KPISTYLE_SENSE = 1;
/*      */   public static final int KPISTYLE_DATAMART = 2;
/*      */   public static final int TASK_SENDTYPE = 102;
/*      */   public static final int TASKSENDTYPE_HTML = 1;
/*      */   public static final int TASKSENDTYPE_EMAIL = 2;
/*      */   public static final int TASKSENDTYPE_SMS = 4;
/*      */   public static final int TASK_STATUS = 103;
/*      */   public static final int TASKSTATUS_DEAL = 0;
/*      */   public static final int TASKSTATUS_FINISH = 2;
/*      */   public static final int TASKSTATUS_CLOSE = 3;
/*      */   public static final int MSG_STATUS = 104;
/*      */   public static final int MSGSTATUS_CREATE = 0;
/*      */   public static final int MSGSTATUS_DEALING = 1;
/*      */   public static final int MSGSTATUS_DEALED = 2;
/*      */   public static final int MSGSTATUS_DEALINTIME = 3;
/*      */   public static final int MSGSTATUS_DEALOUTTIME = 4;
/*      */   public static final int TASK_MSGTYPE = 105;
/*      */   public static final int TASKMSGTYPE_DISPATCH = 0;
/*      */   public static final int TASKMSGTYPE_FW_DISPATCH = 1;
/*      */   public static final int TASKMSGTYPE_REPLY = 2;
/*      */   public static final int TASKMSGTYPE_REJECT = 3;
/*      */   public static final int TAGFLOW_MAINTANCE = 0;
/*      */   public static final int TAGFLOW_SIGN = 2;
/*      */   public static int TAGFLOW_OPEN;
/*      */   public static final int TAGFLOW_DEL = 1;
/*      */   public static final String BRIO6 = "6";
/*      */   public static final String BRIO8 = "8";
/*      */   public static final String SYSTEM_ADMIN_GROUP_ID = "1";
/*      */   public static final String COOKIE_BRIOUSER = "BRIOUSER";
/*      */   public static final String COOKIE_OAUSER = "BRIOUSER_OA";
/*      */   public static final String ASIA_SESSION_NAME = "ASIA_SESSION_NAME";
/*      */   public static final String RESOURCETYPE_USERGROUP = "0";
/*      */   public static final String RESOURCETYPE_USER = "1";
/*      */   public static final String RESOURCETYPE_MANAGEKPI = "2";
/*      */   public static final String RESOURCETYPE_REPORT = "3";
/*      */   public static final String RESOURCETYPE_KPI = "4";
/*      */   public static final String RESOURCETYPE_CITY = "5";
/*      */   public static final String RESOURCETYPE_KPIDEFINE = "6";
/*      */   public static final String RESOURCETYPE_RPTDEFINE = "7";
/*      */   public static final String RESOURCETYPE_LOG = "8";
/*      */   public static final String RESOURCETYPE_HITRATE = "9";
/*      */   public static final String RESOURCETYPE_WARNLEVEL = "10";
/*      */   public static final String RESOURCETYPE_MANAGEHELP = "11";
/*      */   public static final String RESOURCETYPE_NORMALHTTP = "12";
/*      */   public static final String RESOURCETYPE_HELPTOPIC = "13";
/*      */   public static final String RESOURCETYPE_IPPOLICY = "14";
/*      */   public static final String RESOURCETYPE_KPIDATABASE = "15";
/*      */   public static final String RESOURCETYPE_OAUSERMAP = "16";
/*      */   public static final String RESOURCETYPE_NEWS = "17";
/*      */   public static final String RESOURCETYPE_EXTERN = "18";
/*      */   public static final String RESOURCETYPE_EXTERNMANAGE = "19";
/*      */   public static final String RESOURCETYPE_MANAGECONPANY = "20";
/*      */   public static final String RESOURCETYPE_USERDEFINEMENU = "21";
/*      */   public static final String RESOURCETYPE_RPTADMIN = "22";
/*      */   public static final String RESOURCETYPE_COMPANY = "23";
/*      */   public static final String RESOURCETYPE_HELP = "24";
/*      */   public static final String RESOURCETYPE_BALANCE = "25";
/*      */   public static final String RESOURCETYPE_LOG_OP = "26";
/*      */   public static final String RESOURCETYPE_LOGIN = "27";
/*      */   public static final String RESOURCETYPE_LOG_ONLINE = "28";
/*      */   public static final String RESOURCETYPE_PLAN_SET1 = "29";
/*      */   public static final String RESOURCETYPE_PLAN_SET2 = "30";
/*      */   public static final String RESOURCETYPE_SNAP_SHOT = "31";
/*      */   public static final String RESOURCETYPE_MANAGER_DEFINE_SMS = "32";
/*      */   public static final String RESOURCETYPE_ASIGN_RIGHT_BY_RESOURCE = "33";
/*      */   public static final String RESOURCETYPE_REPORT_FILE = "34";
/*      */   public static final String RESOURCETYPE_KPIGRAPH_EXPORT = "35";
/*      */   public static final String RESOURCETYPE_REPORT_FILE_MANAGER = "36";
/*      */   public static final String RESOURCETYPE_IRINDI = "37";
/*      */   public static final String RESOURCETYPE_DATAMART = "38";
/*      */   public static final String RESOURCETYPE_USER_PWD = "39";
/*      */   public static final String RESOURCETYPE_KPILIMIT_DEFINE = "40";
/*      */   public static final String RESOURCETYPE_PORTLET = "41";
/*      */   public static final String RESOURCETYPE_MENUITEM = "50";
/*      */   public static final String RESOURCETYPE_FEE_SALE = "91";
/*      */   public static final String RESOURCETYPE_FEE_SALE_MANAGER = "92";
/*      */   public static final String RESOURCETYPE_TAGFLOW = "99";
/*      */   public static final String LOG_OPERATION_ADD = "0";
/*      */   public static final String LOG_OPERATION_DELETE = "1";
/*      */   public static final String LOG_OPERATION_UPDATE = "2";
/*      */   public static final String LOG_OPERATION_ACCREDIT = "3";
/*      */   public static final String LOG_OPERATION_EXPORT = "4";
/*      */   public static final String LOG_OPERATION_GETPWD = "5";
/*      */   public static final String STATUS_NORMAL = "0";
/*      */   public static final String STATUS_INVALID = "1";
/*      */   public static final String STATUS_TIMESPAN = "2";
/*      */   public static final String STATUS_CHGPWD = "3";
/*      */   public static final String DICT_STATUS = "0";
/*      */   public static final String DICT_OPERATION = "1";
/*      */   public static final String DICT_RESTYPE = "2";
/*      */   public static final String DICT_TOPIC = "3";
/*      */   public static final String DICT_FUNCTION = "4";
/*      */   public static final String DICT_PICTYPE = "5";
/*      */   public static final int MENU_RESTYPE_URL = 1;
/*      */   public static final int MENU_RESTYPE_REPORT = 2;
/*      */   public static final String SYS_KPI_LAYOUT = "SYS_KPI_LAYOUT";
/*      */   public static final String SYS_KPI_SECTION_COUNT = "SYS_KPI_SECTION_COUNT";
/*      */   public static final String SYS_KPI_SECTION0 = "SYS_KPI_SECTION0";
/*      */   public static final String SYS_KPI_SECTION1 = "SYS_KPI_SECTION1";
/*      */   public static final String SYS_KPI_SECTION2 = "SYS_KPI_SECTION2";
/*      */   public static final String SYS_KPI_SECTION3 = "SYS_KPI_SECTION3";
/*      */   public static final String SYS_SHOW_HIDE = "SYS_SHOW_HIDE";
/*      */   public static final String SYS_USE_BALANCE = "SYS_USE_BALANCE";
/*      */   public static final String SYS_ROLEPOLICY = "SYS_ROLEPOLICY";
/*      */   public static final String SYS_SHOW_POLICY = "SYS_SHOW_POLICY";
/*      */   public static final String SYS_SHOW_SINGLELOGIN = "SYS_SHOW_SINGLELOGIN";
/*      */   public static final String SYS_SHOW_POPUP = "SYS_SHOW_POPUP";
/*      */   public static final String SYS_SHOW_USERPARAM = "SYS_SHOW_USERPARAM";
/*      */   public static final String SYS_FIRSTLOGIN_CHANGEPASSWORD = "SYS_FIRSTLOGIN_CHANGEPASSWORD";
/*      */   public static final String SYS_PWDSMS = "SYS_PWDSMS";
/*      */   public static final String SYS_SHOW_SENDPWD = "SYS_SHOW_SENDPWD";
/*      */   public static final String SYS_SHOW_SENSEKPI = "SYS_SHOW_SENSEKPI";
/*      */   public static final String SYS_SHOW_EXPRESSKPI = "SYS_SHOW_EXPRESSKPI";
/*      */   public static final String SYS_SHOW_KPIBRAND = "SYS_SHOW_KPIBRAND";
/*      */   public static final String SYS_SHOW_KPICOUNTY = "SYS_SHOW_KPICOUNTY";
/*      */   public static final String SYS_SHOW_KPISUBBRAND = "SYS_SHOW_KPISUBBRAND";
/*      */   public static final String SYS_KPIALL_PAGE = "SYS_KPIALL_PAGE";
/*      */   public static final String SYS_SHOW_HOLIDAY = "SYS_SHOW_HOLIDAY";
/*      */   public static final String SYS_KPI_PAIMING_ONLYSHOWRIGHTCITY = "SYS_KPI_PAIMING_ONLYSHOWRIGHTCITY";
/*      */   public static final String SYS_RPT_MODIFY = "SYS_RPT_MODIFY";
/*      */   public static final String SYS_RPT_REGION = "SYS_RPT_REGION";
/*      */   public static final String SYS_RPT_REGION2 = "SYS_RPT_REGION2";
/*      */   public static final String SYS_SHOWUSERMENU2LOGO = "SYS_SHOWUSERMENU2LOGO";
/*      */   public static final String SYS_SHOWBIGLOGO = "SYS_SHOWBIGLOGO";
/*      */   public static final String SYS_SHOW_THEME = "SYS_SHOW_THEME";
/*      */   public static final String SYS_DYN_CITYID = "SYS_DYN_CITYID";
/*      */   public static final String SYS_SHOW_FAVOR = "SYS_SHOW_FAVOR";
/*      */   public static final String SYS_SHOW_USERDEFINE_HOMEPAGESET = "SYS_SHOW_USERDEFINE_HOMEPAGESET";
/*      */   public static final String SYS_SHOW_USERDEFINE_SENSEKPIHOMEPAGESET = "SYS_SHOW_USERDEFINE_SENSEKPIHOMEPAGESET";
/*      */   public static final String SYS_SHOW_USERDEFINE_DATAMARTHOMEPAGESET = "SYS_SHOW_USERDEFINE_DATAMARTHOMEPAGESET";
/*      */   public static final String SYS_SHOW_USERDEFINE_SEARCH = "SYS_SHOW_USERDEFINE_SEARCH";
/*      */   public static final String SYS_SHOW_USERDEFINE_USERPROPER = "SYS_SHOW_USERDEFINE_USERPROPER";
/*      */   public static final String SYS_SHOW_USERDEFINE_USERPWD = "SYS_SHOW_USERDEFINE_USERPWD";
/*      */   public static final String SYS_SHOW_KPIDEFINE = "SYS_SHOW_KPIDEFINE";
/*      */   public static final String SYS_SHOW_KPILIMITDEFINE = "SYS_SHOW_KPILIMITDEFINE";
/*      */   public static final String SYS_SHOW_USERDEFINE_SENSEKPIDEFINE = "SYS_SHOW_USERDEFINE_SENSEKPIDEFINE";
/*      */   public static final String SYS_SHOW_USERDEFINE_SENSEKPILIMITDEFINE = "SYS_SHOW_USERDEFINE_SENSEKPILIMITDEFINE";
/*      */   public static final String SYS_SHOW_DATAMART_DEFINE = "SYS_SHOW_DATAMART_DEFINE";
/*      */   public static final String SYS_SHOW_DATAMART_KPILIMITDEFINE = "SYS_SHOW_DATAMART_KPILIMITDEFINE";
/*      */   public static final String SYS_SHOW_USERDEFINE_RPTNAVBAR = "SYS_SHOW_USERDEFINE_RPTNAVBAR";
/*      */   public static final String SYS_SHOW_RPTDEFINE = "SYS_SHOW_RPTDEFINE";
/*      */   public static final String SYS_SHOW_PORTAL = "SYS_SHOW_PORTAL";
/*      */   public static final String SYS_SHOW_OA = "SYS_SHOW_OA";
/*      */   public static final String SYS_SHOW_EXTENDS = "SYS_SHOW_EXTENDS";
/*      */   public static final String SYS_SHOW_HITRATE = "SYS_SHOW_HITRATE";
/*      */   public static final String SYS_SHOW_ONLINE_USER = "SYS_SHOW_ONLINE_USER";
/*      */   public static final String SYS_SHOW_LOGS = "SYS_SHOW_LOGS";
/*      */   public static final String SYS_SHOW_COMPANY = "SYS_SHOW_COMPANY";
/*      */   public static final String SYS_ADD_KPISHOW2TOPIC = "SYS_ADD_KPISHOW2TOPIC";
/*      */   public static final String SYS_SHOW_RPTTREE = "SYS_SHOW_RPTTREE";
/*      */   public static final String SYS_SHOW_REPORT = "SYS_SHOW_REPORT";
/*      */   public static final String SYS_SHOW_SUBJECT = "SYS_SHOW_SUBJECT";
/*      */   public static final String SYS_PLAN_SET1 = "SYS_PLAN_SET1";
/*      */   public static final String SYS_PLAN_SET2 = "SYS_PLAN_SET2";
/*      */   public static final String SYS_SNAP_SHOT = "SYS_SNAP_SHOT";
/*      */   public static final String SYS_DAY_REPORT = "SYS_DAY_REPORT";
/*      */   public static final String SYS_REPORT_FILE = "SYS_REPORT_FILE";
/*      */   public static final String SYS_SEGMENT = "SYS_SEGMENT";
/*      */   public static final String SYS_SHOW_IRINDI = "SYS_SHOW_IRINDI";
/*      */   public static final String SYS_SHOW_TAGFLOW = "SYS_SHOW_TAGFLOW";
/*      */   public static final String SYS_USER_SINGLECITY = "SYS_USER_SINGLECITY";
/*      */   public static final String SYS_KPIDETAIL_SELF = "SYS_KPIDETAIL_SELF";
/*      */   public static final String SYS_RIGHT_HERIT = "SYS_RIGHT_HERIT";
/*      */   public static final String SYS_RANDOMSMS = "SYS_RANDOMSMS";
/*      */   public static final String SYS_HOME_PAGE = "SYS_HOME_PAGE";
/*      */   public static final String SYS_RIGHT_REGIONDETAIL = "SYS_RIGHT_REGIONDETAIL";
/*      */   public static final String SYS_USERPARAM = "USERPARAM";
/*      */   public static final String SYS_SHOW_NETTYPE = "SYS_SHOW_NETTYPE";
/*      */   public static final String SYS_SHOW_NETSUBTYPE = "SYS_SHOW_NETSUBTYPE";
/*      */   public static final String USER_CACHE_DIC_NAME = "user";
/*      */   public static final String USER_CITY_CACHE_DIC_NAME = "userCity";
/*      */   public static final String USER_CAMPANY_CACHE_DIC_NAME = "userCampany";
/*      */   public static final String SYS_MENU_TOPNAV = "SYS_MENU_TOPNAV";
/*      */   public static final String SYS_MENU_TOPIC = "SYS_MENU_TOPIC";
/*      */   public static final String SYS_MENU_ADMIN = "SYS_BAR_ADMIN";
/*      */   public static final String SYS_MENU_ADMIN_USERMANAG = "1";
/*      */   public static final String SYS_MENU_ADMIN_ASIGN_RIGHT_BY_RESOURCE = "11";
/*      */   public static final String SYS_MENU_ADMIN_ROLEMANAG = "100";
/*      */   public static final String SYS_MENU_ADMIN_OAUSER = "2";
/*      */   public static final String SYS_MENU_ADMIN_USERPOLICY = "3";
/*      */   public static final String SYS_MENU_ADMIN_COMPANY = "4";
/*      */   public static final String SYS_MENU_ADMIN_EXTRES = "5";
/*      */   public static final String SYS_MENU_ADMIN_KPI = "6";
/*      */   public static final String SYS_MENU_ADMIN_KPIWARN = "7";
/*      */   public static final String SYS_MENU_ADMIN_KPIDB = "8";
/*      */   public static final String SYS_MENU_ADMIN_NEWS = "9";
/*      */   public static final String SYS_MENU_ADMIN_USERMENU = "10";
/*      */   public static final String SYS_MENU_ADMIN_SUBJECT = "102";
/*      */   public static final String SYS_MENU_ADMIN_BALANCE = "300";
/*      */   public static final String SYS_MENU_ADMIN_TAGFLOW = "12";
/*      */   public static final String SYS_MENU_LOG = "SYS_BAR_QUERYLOG";
/*      */   public static final String SYS_MENU_LOG_HIT10 = "11";
/*      */   public static final String SYS_MENU_LOG_HIT = "12";
/*      */   public static final String SYS_MENU_LOG_QUERY = "13";
/*      */   public static final String SYS_MENU_LOGIN_QUERY = "131";
/*      */   public static final String SYS_MENU_LOG_ONLINE = "14";
/*      */   public static final String SYS_MENU_USER = "SYS_BAR_USERDEFINE";
/*      */   public static final String SYS_MENU_USER_HOMEPAGE = "26";
/*      */   public static final String SYS_MENU_USER_QUERY = "21";
/*      */   public static final String SYS_MENU_USER_PROFILE = "22";
/*      */   public static final String SYS_MENU_USER_RPTASS = "23";
/*      */   public static final String SYS_MENU_USER_RPTATTR = "230";
/*      */   public static final String SYS_MENU_USER_KPI = "24";
/*      */   public static final String SYS_MENU_USER_RPT = "25";
/*      */   public static final String SYS_MENU_USER_TASK = "26";
/*      */   public static final String SYS_MENU_USER_KPILIMIT = "27";
/*      */   public static final String SYS_MENU_USER_PASSWORD = "28";
/*      */   public static final String SYS_MENU_FAVOR = "SYS_BAR_FAVOR";
/*      */   public static final String SYS_MENU_EXTERN = "SYS_BAR_EXTERN";
/*      */   public static final String SYS_MENU_RPT = "SYS_BAR_REPORT";
/*      */   public static final String SYS_MENU_NONE = "SYS_MENU_NONE";
/*      */   public static final String SYS_MENU_IRINDI = "SYS_MENU_IRINDI";
/*      */   public static final int KPITYPE_FOLDER = 0;
/*      */   public static final int KPITYPE_DAY = 1;
/*      */   public static final int KPITYPE_MONTH = 2;
/*      */   public static final int KPITYPE_YEAR = 3;
/*      */   public static final int KPITYPE_WEEK = 5;
/*      */   public static final int PICTYPE_NONE = 0;
/*      */   public static final int PICTYPE_TREND = 1;
/*      */   public static final int PICTYPE_PIE = 2;
/*      */   public static final int PICTYPE_BAR = 3;
/*      */   public static final int PICTYPE_TABLE = 4;
/*      */   public static final int PICTYPE_DUIBI = 5;
/*      */   public static final int PICTYPE_DUIJI = 6;
/*      */   public static final int PICTYPE_PLAIN_TEXT = 7;
/*      */   public static final int PICTYPE_KPI_TOPIC = 8;
/*      */   public static final int RPTTYPE_CITY = 4;
/*      */   public static final int RPTTYPE_TOPIC = 2;
/*      */   public static final int RPTTYPE_FUNCTION = 3;
/*      */   public static final int RPTTYPE_NORMAL = 1;
/*      */   public static final int RPTTYPE_FOLDER = 0;
/*      */   public static final int RPTTYPE_REPORT = 5;
/*      */   public static final int RPTTOPIC_YONGHU = 1;
/*      */   public static final int RPTTOPIC_KEHU = 2;
/*      */   public static final int RPTTOPIC_YEWU = 3;
/*      */   public static final int RPTTOPIC_SHOUYI = 4;
/*      */   public static final int RPTTOPIC_JINGZHEN = 5;
/*      */   public static final int RPTTOPIC_DAKEHU = 6;
/*      */   public static final int RPTTOPIC_VPMN = 7;
/*      */   public static final int RPTTOPIC_XINYEWU = 8;
/*      */   public static final int RPTTOPIC_DAIXIAO = 9;
/*      */   public static final int RPTTOPIC_YINGXIAO = 10;
/*      */   public static final int RPTTOPIC_FUWU = 11;
/*      */   public static final int RPTTOPIC_ZHUANTI = 12;
/*      */   public static final int RPTTOPIC_ZIYUAN = 13;
/*      */   public static final int RPTTOPIC_JIESUAN = 14;
/*      */   public static final int RPTFUNC_GOUCHENG = 31;
/*      */   public static final int RPTFUNC_QUSHI = 32;
/*      */   public static final int RPTFUNC_DUOWEI = 33;
/*      */   public static final int RPTFUNC_ZHUANTI = 34;
/*      */   public static final int RPTFUNC_JIXI = 35;
/*      */   public static final int RPTFUNC_LINGHUO = 36;
/*      */   public static final int RPTFUNC_DUIBI = 37;
/*      */   public static final int RPTFUNC_PAIMING = 38;
/*      */   public static final String RPTDESC_SYSUSER = "SYSUSER77J01E05A70S3XON";
/*  876 */   public static String WEBAPP_PATH = "";
/*      */   public static final String MODULE_CONFIG_FILES_STORE_BASE_PATH = "/WEB-INF/classes/config/";
/*      */   public static final String USER_PRIVILEGE_SERVICE_BEAN_NAME = "userPrivilegeService";
/*      */   public static final String LOG_SERVICE_BEAN_NAME = "logService";
/*      */   public static final String CACHE_KEY_PRIVILEGE_USER = "privlege-user-cache";
/*      */   public static final String CACHE_KEY_PRIVILEGE_USER_CITY = "privlege-user-city-cache";
/*      */   public static final String CACHE_KEY_PRIVILEGE_USER_COMPANY = "privlege-user-company-cache";
/*      */   public static final String CACHE_KEY_PRIVILEGE_USER_GROUP = "privlege-user-group-cache";
/*      */   public static final String CACHE_KEY_PRIVILEGE_USER_ROLE = "privlege-user-role-cache";
/*      */   public static final String CACHE_KEY_PRIVILEGE_USER_DUTY = "privlege-user-duty-cache";
/*      */   public static final String CACHE_KEY_PRIVILEGE_MENU_ITEM = "privlege-menu-item-cache";
/*      */   public static final String CACHE_KEY_PRIVILEGE_SYS_RESOURCES_TYPE = "privlege-sys-resources-type-cache";
/*      */   public static final String CACHE_KEY_PRIVILEGE_USER_CITY_DM_TYPE = "privlege-user-city-dm-type";
/*      */   public static final String CACHE_KEY_PRIVILEGE_SYS_RESOURCE_DS_PROP = "privlege-sys_resource_ds_prop";
/*      */   public static final String CACHE_KEY_CORE_BRAND = "core-brand-cache";
/*      */   public static final String CACHE_KEY_CORE_SYS_PARAMETERS = "core-sys-parameters-cache";
/*      */   public static final String CACHE_KEY_DIMTABLE = "dimTable-cache";
/*      */   public static final String COMPONENT_NAME_CORE = "core";
/*      */   public static final String COMPONENT_NAME_PAGECOMPONENT = "pageComponent";
/*      */   public static final String COMPONENT_NAME_UTILS = "utils";
/*      */   public static final String COMPONENT_NAME_TASK = "task";
/*      */   public static final String COMPONENT_NAME_CHART = "chart";
/*      */   public static final String COMPONENT_NAME_DIMTABLE = "dimTable";
/*      */   public static final String COMPONENT_NAME_PRIVILEGE = "privilege";
/*      */   public static final String COMPONENT_NAME_UNILOG = "uniLog";
/*      */   public static final String COMPONENT_NAME_UNITOUCH = "uniTouch";
/*      */   public static final String COMPONENT_NAME_DATAPROVIDER = "dataProvider";
/*      */   public static final String COMPONENT_NAME_OPERREVIEW = "operReview";
/*      */   public static final String COMPONENT_NAME_FAVOR = "favor";
/*      */   public static final String COMPONENT_NAME_SELFQUERY = "selfQuery";
/*      */   public static final String COMPONENT_NAME_DOWNLOAD = "download";
/*      */   public static final String COMPONENT_NAME_PORTAL = "portal";
/*      */   public static final String COMPONENT_NAME_PAGEFLOW = "pageflow";
/*      */   public static final String COMPONENT_NAME_KPI = "kpi";
/*      */   public static final String COMPONENT_NAME_ALARM = "alarm";
/*      */   public static final String COMPONENT_NAME_UPLOAD = "upload";
/*      */   public static final String COMPONENT_NAME_ACT = "act";
/*      */   public static final String DM_CITY = "CITY";
/*      */   public static final String DM_COUNTY = "COUNTY";
/*      */   public static final String DM_DEPT = "DEPT";
/*      */   public static final String DM_ALL = "-1";
/*      */   public static final String DBTYPE_DW = "DBTYPE_DW";
/*      */   public static final String DBTYPE_APP = "DBTYPE_APP";
/*      */   public static final int LOGDEFINE_OPERATION = 1;
/*      */   public static final int LOGDEFINE_LOGTYPE = 2;
/*      */   public static final int LOGDEFINE_DEFAULTVALUE = 999;
/*      */ 
/*      */   public static String getSysParameter(String strID)
/*      */   {
/* 1005 */     return SysParametersCache.getInstance().getValue("core", strID);
/*      */   }
/*      */ 
/*      */   public static String getSysParameter(String moduleName, String strID)
/*      */   {
/* 1019 */     return SysParametersCache.getInstance().getValue(moduleName, strID);
/*      */   }
/*      */ 
/*      */   public static boolean checkSysParameter(String strKey)
/*      */   {
/* 1030 */     String str = getSysParameter(strKey);
/* 1031 */     return (str != null) && (!str.trim().equals("0"));
/*      */   }
/*      */ 
/*      */   public static void initAllSysParameters()
/*      */   {
/* 1039 */     SysParametersCache.getInstance().refreshAll();
/*      */   }
/*      */ 
/*      */   private static void addDict(int dictGroup, int id, String strName)
/*      */   {
/* 1184 */     if (null != getDictName(dictGroup, id)) {
/* 1185 */       m_hashDictNames.put("" + dictGroup + "_" + id, strName);
/*      */     }
/* 1187 */     Vector vect = getDictIDs(dictGroup);
/* 1188 */     if (null == vect) {
/* 1189 */       vect = new Vector();
/*      */     }
/* 1191 */     vect.addElement("" + id);
/* 1192 */     m_hashDicts.put("" + dictGroup, vect);
/*      */   }
/*      */ 
/*      */   public static String getDictName(int nGroup, int nID)
/*      */   {
/* 1205 */     return "" + m_hashDictNames.get(new StringBuilder().append("").append(nGroup).append("_").append(nID).toString());
/*      */   }
/*      */ 
/*      */   public static Vector getDictIDs(int nGroup)
/*      */   {
/* 1216 */     return (Vector)m_hashDicts.get("" + nGroup);
/*      */   }
/*      */ 
/*      */   public static String getDictOptions(int nDictGroup, String strSelected)
/*      */   {
/* 1229 */     Vector vect = getDictIDs(nDictGroup);
/* 1230 */     if (null == vect) {
/* 1231 */       return "";
/*      */     }
/* 1233 */     String strRet = "";
/* 1234 */     for (int i = 0; i < vect.size(); i++) {
/* 1235 */       String strID = (String)vect.elementAt(i);
/* 1236 */       String strName = getDictName(nDictGroup, Integer.parseInt(strID));
/* 1237 */       if (null != strName)
/*      */       {
/* 1240 */         strRet = strRet + "<option value='" + strID + "' ";
/* 1241 */         if ((null != strSelected) && (strID.equals(strSelected))) {
/* 1242 */           strRet = strRet + " selected ";
/*      */         }
/* 1244 */         strRet = strRet + ">" + strName + "</option>";
/*      */       }
/*      */     }
/* 1246 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static List getDictList(int nDictGroup)
/*      */   {
/* 1257 */     List list = new ArrayList();
/* 1258 */     Vector vect = getDictIDs(nDictGroup);
/* 1259 */     if (null == vect) {
/* 1260 */       return list;
/*      */     }
/* 1262 */     for (int i = 0; i < vect.size(); i++) {
/* 1263 */       String strID = (String)vect.elementAt(i);
/* 1264 */       String strName = getDictName(nDictGroup, Integer.parseInt(strID));
/* 1265 */       if (null != strName)
/*      */       {
/* 1268 */         list.add(new LabelValueBean(strName, strID));
/*      */       }
/*      */     }
/* 1271 */     return list;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   55 */     addDict(106, 0, LocaleUtil.getLocaleMessage("core", "core.java.cityRole"));
/*      */ 
/*   57 */     addDict(106, 1, LocaleUtil.getLocaleMessage("core", "core.java.resourceRole"));
/*      */ 
/*   59 */     addDict(106, 2, LocaleUtil.getLocaleMessage("core", "core.java.operationRole"));
/*      */ 
/*   69 */     addDict(111, 0, LocaleUtil.getLocaleMessage("core", "core.java.normal"));
/*      */ 
/*   71 */     addDict(111, 1, LocaleUtil.getLocaleMessage("core", "core.java.locked"));
/*      */ 
/*   81 */     addDict(119, 0, LocaleUtil.getLocaleMessage("core", "core.java.normal"));
/*      */ 
/*   83 */     addDict(119, 1, LocaleUtil.getLocaleMessage("core", "core.java.unused"));
/*      */ 
/*  114 */     addDict(107, 0, LocaleUtil.getLocaleMessage("core", "core.java.view"));
/*      */ 
/*  116 */     addDict(107, 1, LocaleUtil.getLocaleMessage("core", "core.java.add"));
/*      */ 
/*  118 */     addDict(107, 2, LocaleUtil.getLocaleMessage("core", "core.java.delete"));
/*      */ 
/*  120 */     addDict(107, 3, LocaleUtil.getLocaleMessage("core", "core.java.update"));
/*      */ 
/*  122 */     addDict(107, 4, LocaleUtil.getLocaleMessage("core", "core.java.upload"));
/*      */ 
/*  124 */     addDict(107, 5, LocaleUtil.getLocaleMessage("core", "core.java.export"));
/*      */ 
/*  126 */     addDict(107, 6, LocaleUtil.getLocaleMessage("core", "core.java.audit"));
/*      */ 
/*  128 */     addDict(107, 7, LocaleUtil.getLocaleMessage("core", "core.java.manageKpi"));
/*      */ 
/*  130 */     addDict(107, 8, LocaleUtil.getLocaleMessage("core", "core.java.import"));
/*      */ 
/*  134 */     accessType = "1";
/*      */ 
/*  140 */     INDI_VIEW_RIGHT = "1";
/*      */ 
/*  143 */     INDI_ADMIN_RIGHT = "2";
/*      */ 
/*  172 */     addDict(101, 0, LocaleUtil.getLocaleMessage("core", "core.java.normalKpi"));
/*      */ 
/*  174 */     addDict(101, 1, LocaleUtil.getLocaleMessage("core", "core.java.senseKpi"));
/*      */ 
/*  176 */     addDict(101, 2, LocaleUtil.getLocaleMessage("core", "core.java.datamartKpi"));
/*      */ 
/*  191 */     addDict(102, 1, LocaleUtil.getLocaleMessage("core", "core.java.html"));
/*      */ 
/*  193 */     addDict(102, 2, LocaleUtil.getLocaleMessage("core", "core.java.email"));
/*      */ 
/*  195 */     addDict(102, 4, LocaleUtil.getLocaleMessage("core", "core.java.sms"));
/*      */ 
/*  210 */     addDict(103, 0, LocaleUtil.getLocaleMessage("core", "core.java.deal"));
/*      */ 
/*  212 */     addDict(103, 2, LocaleUtil.getLocaleMessage("core", "core.java.finish"));
/*      */ 
/*  214 */     addDict(103, 3, LocaleUtil.getLocaleMessage("core", "core.java.close"));
/*      */ 
/*  237 */     addDict(104, 0, LocaleUtil.getLocaleMessage("core", "core.java.create"));
/*      */ 
/*  239 */     addDict(104, 1, LocaleUtil.getLocaleMessage("core", "core.java.dealing"));
/*      */ 
/*  241 */     addDict(104, 2, LocaleUtil.getLocaleMessage("core", "core.java.dealed"));
/*      */ 
/*  243 */     addDict(104, 3, LocaleUtil.getLocaleMessage("core", "core.java.dealInTime"));
/*      */ 
/*  245 */     addDict(104, 4, LocaleUtil.getLocaleMessage("core", "core.java.dealOutTime"));
/*      */ 
/*  262 */     addDict(105, 0, LocaleUtil.getLocaleMessage("core", "core.java.dispatch"));
/*      */ 
/*  264 */     addDict(105, 1, LocaleUtil.getLocaleMessage("core", "core.java.forwardDispatch"));
/*      */ 
/*  266 */     addDict(105, 2, LocaleUtil.getLocaleMessage("core", "core.java.reply"));
/*      */ 
/*  268 */     addDict(105, 3, LocaleUtil.getLocaleMessage("core", "core.java.reject"));
/*      */ 
/*  279 */     TAGFLOW_OPEN = 0;
/*      */ 
/*  441 */     addDict(Integer.parseInt("1"), Integer.parseInt("5"), LocaleUtil.getLocaleMessage("core", "core.java.getPwd"));
/*      */ 
/*  444 */     addDict(Integer.parseInt("2"), Integer.parseInt("39"), LocaleUtil.getLocaleMessage("core", "core.java.userPwd"));
/*      */ 
/*  475 */     addDict(Integer.parseInt("0"), Integer.parseInt("0"), LocaleUtil.getLocaleMessage("core", "core.java.normal"));
/*      */ 
/*  477 */     addDict(Integer.parseInt("0"), Integer.parseInt("1"), LocaleUtil.getLocaleMessage("core", "core.java.invalid"));
/*      */ 
/*  480 */     addDict(Integer.parseInt("0"), Integer.parseInt("2"), LocaleUtil.getLocaleMessage("core", "core.java.timespan"));
/*      */ 
/*  483 */     addDict(Integer.parseInt("0"), Integer.parseInt("3"), LocaleUtil.getLocaleMessage("core", "core.java.changePwd"));
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.common.SysCodes
 * JD-Core Version:    0.6.2
 */
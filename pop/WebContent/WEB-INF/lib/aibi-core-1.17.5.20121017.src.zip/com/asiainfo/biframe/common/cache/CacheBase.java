/*     */ package com.asiainfo.biframe.common.cache;
/*     */ 
/*     */ import com.asiainfo.biframe.service.ICache;
/*     */ import com.asiainfo.biframe.service.ISynCacheService;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public abstract class CacheBase
/*     */   implements Serializable, ICache
/*     */ {
/*     */   private static final long serialVersionUID = -7459350401500368073L;
/*     */   protected Map cacheContainer;
/*     */ 
/*     */   protected abstract boolean init();
/*     */ 
/*     */   public abstract String getNameByKey(Object paramObject);
/*     */ 
/*     */   public Object getObjectByKey(Object key)
/*     */   {
/*  66 */     if (key == null) {
/*  67 */       return null;
/*     */     }
/*  69 */     if (this.cacheContainer.containsKey(key)) {
/*  70 */       return this.cacheContainer.get(key);
/*     */     }
/*     */ 
/*  73 */     refreshByKey(key);
/*  74 */     if (this.cacheContainer.containsKey(key)) {
/*  75 */       return this.cacheContainer.get(key);
/*     */     }
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   public abstract boolean refreshByKey(Object paramObject);
/*     */ 
/*     */   public boolean refreshAll()
/*     */   {
/*  95 */     boolean res = false;
/*  96 */     res = init();
/*     */ 
/* 100 */     ISynCacheService synService = null;
/*     */     try {
/* 102 */       synService = (ISynCacheService)SystemServiceLocator.getInstance().getService("core_sysSynCacheService");
/*     */     }
/*     */     catch (Exception e) {
/* 105 */       e.printStackTrace();
/*     */     }
/* 107 */     if (synService != null) {
/* 108 */       synService.addSynCache(getClass().getName(), Configure.getInstance().getProperty("HOST_ADDRESS"));
/*     */     }
/*     */ 
/* 113 */     return res;
/*     */   }
/*     */ 
/*     */   public Collection getAllCachedObject()
/*     */   {
/* 120 */     if (this.cacheContainer != null) {
/* 121 */       return this.cacheContainer.values();
/*     */     }
/*     */ 
/* 124 */     refreshAll();
/* 125 */     if (this.cacheContainer != null) {
/* 126 */       return this.cacheContainer.values();
/*     */     }
/*     */ 
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   public Collection getAllCachedSortedObject()
/*     */   {
/* 136 */     if (this.cacheContainer == null)
/*     */     {
/* 138 */       refreshAll();
/* 139 */       if (this.cacheContainer == null) {
/* 140 */         return null;
/*     */       }
/*     */     }
/* 143 */     SortedMap sortContainer = new TreeMap();
/* 144 */     sortContainer.putAll(this.cacheContainer);
/* 145 */     return sortContainer.values();
/*     */   }
/*     */ 
/*     */   public Map getObjectByCondition(CacheFilter cf)
/*     */   {
/* 155 */     Map ret = new Hashtable();
/* 156 */     Iterator en = this.cacheContainer.keySet().iterator();
/* 157 */     while (en.hasNext()) {
/* 158 */       Object tmpKey = en.next();
/* 159 */       Object tmpObj = this.cacheContainer.get(tmpKey);
/* 160 */       if (cf.match(tmpObj)) {
/* 161 */         ret.put(tmpKey, tmpObj);
/*     */       }
/*     */     }
/* 164 */     return ret;
/*     */   }
/*     */ 
/*     */   public Collection getTailByCondition(CacheFilter cf, Object fromKey)
/*     */   {
/* 175 */     if (this.cacheContainer == null)
/*     */     {
/* 177 */       refreshAll();
/* 178 */       if (this.cacheContainer == null) {
/* 179 */         return null;
/*     */       }
/*     */     }
/* 182 */     SortedMap sortContainer = new TreeMap();
/* 183 */     Iterator en = this.cacheContainer.keySet().iterator();
/* 184 */     while (en.hasNext()) {
/* 185 */       Object tmpKey = en.next();
/* 186 */       Object tmpObj = this.cacheContainer.get(tmpKey);
/* 187 */       if (cf.match(tmpObj)) {
/* 188 */         sortContainer.put(tmpKey, tmpObj);
/*     */       }
/*     */     }
/* 191 */     sortContainer = sortContainer.tailMap(fromKey);
/* 192 */     return sortContainer.values();
/*     */   }
/*     */ 
/*     */   public Collection getHeadByCondition(CacheFilter cf, Object toKey)
/*     */   {
/* 204 */     if (this.cacheContainer == null)
/*     */     {
/* 206 */       refreshAll();
/* 207 */       if (this.cacheContainer == null) {
/* 208 */         return null;
/*     */       }
/*     */     }
/* 211 */     SortedMap sortContainer = new TreeMap();
/* 212 */     Iterator en = this.cacheContainer.keySet().iterator();
/* 213 */     while (en.hasNext()) {
/* 214 */       Object tmpKey = en.next();
/* 215 */       Object tmpObj = this.cacheContainer.get(tmpKey);
/* 216 */       if (cf.match(tmpObj)) {
/* 217 */         sortContainer.put(tmpKey, tmpObj);
/*     */       }
/*     */     }
/* 220 */     sortContainer = sortContainer.headMap(toKey);
/* 221 */     return sortContainer.values();
/*     */   }
/*     */ 
/*     */   public Collection getTailCachedObject(Object fromKey)
/*     */   {
/* 232 */     if (this.cacheContainer == null)
/*     */     {
/* 234 */       refreshAll();
/* 235 */       if (this.cacheContainer == null) {
/* 236 */         return null;
/*     */       }
/*     */     }
/* 239 */     SortedMap sortContainer = new TreeMap();
/* 240 */     sortContainer.putAll(this.cacheContainer);
/* 241 */     sortContainer = sortContainer.tailMap(fromKey);
/* 242 */     return sortContainer.values();
/*     */   }
/*     */ 
/*     */   public Collection getHeadCachedObject(Object toKey)
/*     */   {
/* 252 */     if (this.cacheContainer == null)
/*     */     {
/* 254 */       refreshAll();
/* 255 */       if (this.cacheContainer == null) {
/* 256 */         return null;
/*     */       }
/*     */     }
/* 259 */     SortedMap sortContainer = new TreeMap();
/* 260 */     sortContainer.putAll(this.cacheContainer);
/* 261 */     sortContainer = sortContainer.headMap(toKey);
/* 262 */     return sortContainer.values();
/*     */   }
/*     */ 
/*     */   public Collection getMidCachedObject(Object fromKey, Object toKey)
/*     */   {
/* 273 */     if (this.cacheContainer == null)
/*     */     {
/* 275 */       refreshAll();
/* 276 */       if (this.cacheContainer == null) {
/* 277 */         return null;
/*     */       }
/*     */     }
/* 280 */     SortedMap sortContainer = new TreeMap();
/* 281 */     sortContainer.putAll(this.cacheContainer);
/* 282 */     sortContainer = sortContainer.subMap(fromKey, toKey);
/* 283 */     return sortContainer.values();
/*     */   }
/*     */ 
/*     */   public void removeObjectByKey(Object key)
/*     */   {
/* 292 */     if (this.cacheContainer.containsKey(key))
/* 293 */       this.cacheContainer.remove(key);
/*     */   }
/*     */ 
/*     */   public void putObject(Object key, Object value)
/*     */   {
/* 301 */     this.cacheContainer.put(key, value);
/*     */   }
/*     */ 
/*     */   public Map getContainer()
/*     */   {
/* 310 */     return this.cacheContainer;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.common.cache.CacheBase
 * JD-Core Version:    0.6.2
 */
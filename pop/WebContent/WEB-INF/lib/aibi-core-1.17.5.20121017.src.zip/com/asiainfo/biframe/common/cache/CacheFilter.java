package com.asiainfo.biframe.common.cache;

public abstract class CacheFilter
{
  public abstract boolean match(Object paramObject);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.common.cache.CacheFilter
 * JD-Core Version:    0.6.2
 */
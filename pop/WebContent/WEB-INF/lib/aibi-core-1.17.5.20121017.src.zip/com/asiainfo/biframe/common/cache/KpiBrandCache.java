/*     */ package com.asiainfo.biframe.common.cache;
/*     */ 
/*     */ import com.asiainfo.biframe.model.Kpi_Brand;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class KpiBrandCache extends CacheBase
/*     */ {
/*     */   private static final long serialVersionUID = 56097338291829961L;
/*  26 */   private static Log log = LogFactory.getLog(KpiBrandCache.class);
/*     */   private static KpiBrandCache theInstance;
/*     */   private ArrayList<String> cacheKeyArray;
/*     */ 
/*     */   private KpiBrandCache()
/*     */   {
/*  37 */     init();
/*     */   }
/*     */ 
/*     */   protected boolean init()
/*     */   {
/*  45 */     Sqlca m_Sqlca = null;
/*  46 */     boolean res = false;
/*  47 */     this.cacheContainer = new HashMap();
/*  48 */     this.cacheKeyArray = new ArrayList();
/*     */     try {
/*  50 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  51 */       String loadSql = "select brand_id,brand_name,parent_brand_id,use_tag,sort_num  from kpi_brand where use_tag=0 order by parent_brand_id,sort_num,brand_id";
/*     */ 
/*  53 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  56 */       while (m_Sqlca.next()) {
/*  57 */         Kpi_Brand tmpObj = new Kpi_Brand();
/*  58 */         tmpObj.setBrand_id(m_Sqlca.getInt("brand_id"));
/*  59 */         tmpObj.setBrand_name(m_Sqlca.getString("brand_name"));
/*  60 */         tmpObj.setParent_brand_id(m_Sqlca.getInt("parent_brand_id"));
/*  61 */         tmpObj.setUse_tag(m_Sqlca.getInt("use_tag"));
/*  62 */         tmpObj.setSort_num(m_Sqlca.getInt("sort_num"));
/*     */ 
/*  64 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*  65 */         this.cacheKeyArray.add(tmpObj.getPrimaryKey());
/*     */       }
/*     */ 
/*  68 */       res = true;
/*     */ 
/*  70 */       log.debug(">>KpiBrandCache init successful...");
/*     */     } catch (Exception e) {
/*  72 */       log.error("KpiBrandCache init() " + LocaleUtil.getLocaleMessage("core", "core.java.errorOccur") + "：\n", e);
/*     */     }
/*     */     finally
/*     */     {
/*  76 */       if (m_Sqlca != null) {
/*  77 */         m_Sqlca.closeAll();
/*     */       }
/*     */     }
/*  80 */     return res;
/*     */   }
/*     */ 
/*     */   public static KpiBrandCache getInstance()
/*     */   {
/*  89 */     if (theInstance == null) {
/*  90 */       theInstance = new KpiBrandCache();
/*     */     }
/*  92 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/* 104 */     if (key == null) {
/* 105 */       return null;
/*     */     }
/* 107 */     if (this.cacheContainer.containsKey(key)) {
/* 108 */       return ((Kpi_Brand)this.cacheContainer.get(key)).getBrand_name();
/*     */     }
/*     */ 
/* 111 */     refreshByKey(key);
/* 112 */     if (this.cacheContainer.containsKey(key)) {
/* 113 */       return ((Kpi_Brand)this.cacheContainer.get(key)).getBrand_name();
/*     */     }
/* 115 */     return "";
/*     */   }
/*     */ 
/*     */   public boolean refreshByKey(Object key)
/*     */   {
/* 124 */     Sqlca m_Sqlca = null;
/* 125 */     boolean res = false;
/*     */     try {
/* 127 */       m_Sqlca = new Sqlca(new ConnectionEx());
/* 128 */       String loadSql = "select brand_id,brand_name,parent_brand_id,use_tag,sort_num from kpi_brand  where brand_id=" + key + " and use_tag=0";
/*     */ 
/* 133 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 136 */       if (m_Sqlca.next()) {
/* 137 */         Kpi_Brand tmpObj = new Kpi_Brand();
/* 138 */         tmpObj.setBrand_id(m_Sqlca.getInt("brand_id"));
/* 139 */         tmpObj.setBrand_name(m_Sqlca.getString("brand_name"));
/* 140 */         tmpObj.setParent_brand_id(m_Sqlca.getInt("parent_brand_id"));
/* 141 */         tmpObj.setUse_tag(m_Sqlca.getInt("use_tag"));
/* 142 */         tmpObj.setSort_num(m_Sqlca.getInt("sort_num"));
/*     */ 
/* 144 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */       }
/*     */ 
/* 148 */       refreshKeyArray();
/*     */ 
/* 150 */       res = true;
/*     */     } catch (Exception e) {
/* 152 */       log.error("KpiBrandCache refreshByKey(" + key + ") " + LocaleUtil.getLocaleMessage("core", "core.java.errorOccur") + "：\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 158 */       if (m_Sqlca != null) {
/* 159 */         m_Sqlca.closeAll();
/*     */       }
/*     */     }
/* 162 */     return res;
/*     */   }
/*     */ 
/*     */   public boolean refreshKeyArray()
/*     */   {
/* 169 */     Sqlca m_Sqlca = null;
/* 170 */     boolean res = false;
/*     */     try {
/* 172 */       ArrayList keyArray = new ArrayList();
/* 173 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 175 */       String loadSql = "select brand_id,parent_brand_id,brand_name,use_tag,sort_num  from kpi_brand where use_tag=0 order by parent_brand_id,sort_num,brand_id";
/*     */ 
/* 177 */       m_Sqlca.execute(loadSql);
/* 178 */       while (m_Sqlca.next()) {
/* 179 */         keyArray.add(m_Sqlca.getString("brand_id"));
/*     */       }
/* 181 */       this.cacheKeyArray.clear();
/* 182 */       this.cacheKeyArray.addAll(keyArray);
/* 183 */       res = true;
/*     */     } catch (Exception e) {
/* 185 */       log.error("KpiBrandCache refreshKeyArray() " + LocaleUtil.getLocaleMessage("core", "core.java.errorOccur") + "：\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 189 */       if (m_Sqlca != null) {
/* 190 */         m_Sqlca.closeAll();
/*     */       }
/*     */     }
/* 193 */     return res;
/*     */   }
/*     */ 
/*     */   public List getBrandListByFilter(CacheFilter cf)
/*     */   {
/* 204 */     ArrayList ret = new ArrayList();
/* 205 */     for (int i = 0; i < this.cacheKeyArray.size(); i++) {
/* 206 */       Object tmpKey = this.cacheKeyArray.get(i);
/* 207 */       if (null != tmpKey)
/*     */       {
/* 210 */         Object tmpObj = this.cacheContainer.get(tmpKey);
/* 211 */         if (cf.match(tmpObj))
/* 212 */           ret.add(tmpObj);
/*     */       }
/*     */     }
/* 215 */     return ret;
/*     */   }
/*     */ 
/*     */   public List getAllSortedBrandList()
/*     */   {
/* 224 */     ArrayList ret = new ArrayList();
/* 225 */     for (int i = 0; i < this.cacheKeyArray.size(); i++) {
/* 226 */       Object tmpKey = this.cacheKeyArray.get(i);
/* 227 */       if (null != tmpKey)
/*     */       {
/* 230 */         Object tmpObj = this.cacheContainer.get(tmpKey);
/* 231 */         ret.add(tmpObj);
/*     */       }
/*     */     }
/* 233 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.common.cache.KpiBrandCache
 * JD-Core Version:    0.6.2
 */
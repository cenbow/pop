/*    */ package com.asiainfo.biframe.common.cache;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import net.sf.ehcache.Cache;
/*    */ import net.sf.ehcache.Element;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class MethodCacheInterceptor
/*    */   implements MethodInterceptor, InitializingBean
/*    */ {
/* 27 */   private static final Log logger = LogFactory.getLog(MethodCacheInterceptor.class);
/*    */   private Cache cache;
/*    */ 
/*    */   public void setCache(Cache cache)
/*    */   {
/* 36 */     this.cache = cache;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */     throws Exception
/*    */   {
/* 43 */     Assert.notNull(this.cache, "A cache is required. Use setCache(Cache) to provide one.");
/*    */   }
/*    */ 
/*    */   public Object invoke(MethodInvocation invocation)
/*    */     throws Throwable
/*    */   {
/* 51 */     String targetName = invocation.getThis().getClass().getName();
/* 52 */     String methodName = invocation.getMethod().getName();
/* 53 */     Object[] arguments = invocation.getArguments();
/*    */ 
/* 57 */     String cacheKey = getCacheKey(targetName, methodName, arguments);
/* 58 */     Element element = this.cache.get(cacheKey);
/* 59 */     if (element == null)
/*    */     {
/* 62 */       Object result = invocation.proceed();
/*    */ 
/* 66 */       element = new Element(cacheKey, (Serializable)result);
/* 67 */       this.cache.put(element);
/*    */     }
/* 69 */     return element.getValue();
/*    */   }
/*    */ 
/*    */   private String getCacheKey(String targetName, String methodName, Object[] arguments)
/*    */   {
/* 77 */     StringBuffer sb = new StringBuffer();
/* 78 */     sb.append(targetName).append(".").append(methodName);
/* 79 */     if ((arguments != null) && (arguments.length != 0)) {
/* 80 */       for (int i = 0; i < arguments.length; i++) {
/* 81 */         sb.append(".").append(arguments[i]);
/*    */       }
/*    */     }
/*    */ 
/* 85 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.common.cache.MethodCacheInterceptor
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.common.cache;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SysParametersCache extends CacheBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  25 */   private Log log = LogFactory.getLog(getClass());
/*     */   private static SysParametersCache instance;
/*     */ 
/*     */   private SysParametersCache()
/*     */   {
/*  34 */     this.cacheContainer = new HashMap();
/*  35 */     init();
/*     */   }
/*     */ 
/*     */   public static SysParametersCache getInstance()
/*     */   {
/*  44 */     if (instance == null) {
/*  45 */       instance = new SysParametersCache();
/*     */     }
/*  47 */     return instance;
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/*  59 */     return null;
/*     */   }
/*     */ 
/*     */   public String getValue(String moduleName, String parameterId)
/*     */   {
/*  70 */     String ret = "";
/*  71 */     if (this.cacheContainer.containsKey(moduleName)) {
/*  72 */       Map moduleParameterMap = (Map)this.cacheContainer.get(moduleName);
/*     */ 
/*  74 */       if (moduleParameterMap.containsKey(parameterId)) {
/*  75 */         ret = (String)moduleParameterMap.get(parameterId);
/*     */       } else {
/*  77 */         boolean res = refreshByKey(moduleName, parameterId);
/*  78 */         if ((res) && (moduleParameterMap.containsKey(parameterId))) {
/*  79 */           ret = (String)moduleParameterMap.get(parameterId);
/*     */         }
/*     */       }
/*     */     }
/*  83 */     return ret;
/*     */   }
/*     */ 
/*     */   protected boolean init()
/*     */   {
/*  93 */     this.log.debug(">>Begin initialize " + getClass().getName());
/*  94 */     String sql = "select module_name,parameterid,parametervalue from sys_parameters order by module_name";
/*  95 */     this.log.debug(">>End initialize " + getClass().getName());
/*  96 */     return transferDataFromDBToCache(sql);
/*     */   }
/*     */ 
/*     */   private boolean transferDataFromDBToCache(String sql)
/*     */   {
/* 106 */     Sqlca sqlca = null;
/* 107 */     boolean ret = false;
/*     */     try {
/* 109 */       sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 111 */       sqlca.execute(sql);
/*     */ 
/* 114 */       while (sqlca.next()) {
/* 115 */         String moduleName = sqlca.getString("module_name");
/* 116 */         String parameterId = sqlca.getString("parameterid");
/* 117 */         String parameterValue = sqlca.getString("parametervalue");
/*     */         Map moduleParameterMap;
/*     */         Map moduleParameterMap;
/* 119 */         if (this.cacheContainer.containsKey(moduleName)) {
/* 120 */           moduleParameterMap = (Map)this.cacheContainer.get(moduleName);
/*     */         }
/*     */         else {
/* 123 */           moduleParameterMap = new HashMap();
/*     */         }
/* 125 */         moduleParameterMap.put(parameterId, parameterValue);
/*     */ 
/* 127 */         this.cacheContainer.put(moduleName, moduleParameterMap);
/*     */       }
/* 129 */       ret = true;
/*     */ 
/* 133 */       if (null != sqlca)
/* 134 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 131 */       this.log.error("", e);
/*     */ 
/* 133 */       if (null != sqlca)
/* 134 */         sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 133 */       if (null != sqlca) {
/* 134 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 137 */     return ret;
/*     */   }
/*     */ 
/*     */   public boolean refreshByKey(Object moduleName)
/*     */   {
/* 145 */     String sql = "select module_name,parameterid,parametervalue from sys_parameters where module_name='" + moduleName + "'";
/*     */ 
/* 147 */     return transferDataFromDBToCache(sql);
/*     */   }
/*     */ 
/*     */   public boolean refreshByKey(String moduleName, String parameterId)
/*     */   {
/* 158 */     this.log.debug(">>Begin initialize " + getClass().getName() + ".refreshByKey(" + moduleName + "," + parameterId + ")");
/*     */ 
/* 160 */     String sql = "select module_name,parameterid,parametervalue from sys_parameters where module_name='" + moduleName + "' and parameterid='" + parameterId + "'";
/*     */ 
/* 162 */     this.log.debug(">>End initialize " + getClass().getName() + ".refreshByKey(" + moduleName + "," + parameterId + ")");
/*     */ 
/* 164 */     return transferDataFromDBToCache(sql);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.common.cache.SysParametersCache
 * JD-Core Version:    0.6.2
 */
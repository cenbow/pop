package com.asiainfo.biframe.dao;

import java.io.Serializable;
import java.util.List;

public abstract interface IGeneralDao<T, ID extends Serializable>
{
  public abstract T findById(ID paramID);

  public abstract List<T> findAll();

  public abstract void delete(T paramT);

  public abstract void deleteById(ID paramID);

  public abstract void delete(List<T> paramList);

  public abstract T save(T paramT);

  public abstract void save(List<T> paramList);

  public abstract T update(T paramT);

  public abstract void update(List<T> paramList);

  public abstract T saveOrUpdate(T paramT);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.dao.IGeneralDao
 * JD-Core Version:    0.6.2
 */
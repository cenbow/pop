package com.asiainfo.biframe.dao;

import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

public abstract interface IJdbcDao
{
  @Deprecated
  public abstract SimpleJdbcTemplate getSimpleJdbcTemplateDeprecated();

  @Deprecated
  public abstract JdbcTemplate getJdbcTemplateDeprecated();

  public abstract <T> List<T> query(String paramString, ParameterizedRowMapper<T> paramParameterizedRowMapper, Map<String, Object> paramMap);

  public abstract <T> List<T> query(String paramString, ParameterizedRowMapper<T> paramParameterizedRowMapper, Object[] paramArrayOfObject);

  @Deprecated
  public abstract <T> List<T> query(String paramString, ParameterizedRowMapper<T> paramParameterizedRowMapper, SqlParameterSource paramSqlParameterSource);

  public abstract List<Map<String, Object>> queryForList(String paramString, Map<String, Object> paramMap);

  public abstract <T> List<T> queryForList(String paramString, Object[] paramArrayOfObject, Class<T> paramClass);

  public abstract <T> T queryForObject(String paramString, ParameterizedRowMapper<T> paramParameterizedRowMapper, Map<String, Object> paramMap);

  public abstract int update(String paramString, Object[] paramArrayOfObject);

  public abstract int update(String paramString, SqlParameterSource paramSqlParameterSource);

  public abstract int[] batchUpdate(String paramString, SqlParameterSource[] paramArrayOfSqlParameterSource);

  public abstract int queryForInt(String paramString, Object[] paramArrayOfObject);

  public abstract int queryForCount(String paramString, Object[] paramArrayOfObject);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.dao.IJdbcDao
 * JD-Core Version:    0.6.2
 */
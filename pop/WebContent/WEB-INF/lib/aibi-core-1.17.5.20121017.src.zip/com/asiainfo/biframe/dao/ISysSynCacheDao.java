package com.asiainfo.biframe.dao;

import com.asiainfo.biframe.exception.DaoException;

public abstract interface ISysSynCacheDao
{
  public abstract void addSynCache(String paramString1, String paramString2)
    throws DaoException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.dao.ISysSynCacheDao
 * JD-Core Version:    0.6.2
 */
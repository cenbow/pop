/*     */ package com.asiainfo.biframe.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.dao.IGeneralDao;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class GeneralDaoImpl<T, ID extends Serializable> extends HibernateDaoSupport
/*     */   implements IGeneralDao<T, ID>
/*     */ {
/*     */   private Class<T> entityClass;
/*     */ 
/*     */   public GeneralDaoImpl(Class<T> classType)
/*     */   {
/*  30 */     this.entityClass = classType;
/*     */   }
/*     */ 
/*     */   public GeneralDaoImpl() {
/*  34 */     this.entityClass = ((Class)((java.lang.reflect.ParameterizedType)getClass().getGenericSuperclass()).getActualTypeArguments()[0]);
/*     */   }
/*     */ 
/*     */   public void delete(T entity)
/*     */   {
/*  39 */     getHibernateTemplate().delete(entity);
/*     */   }
/*     */ 
/*     */   public void delete(List<T> entityList) {
/*  43 */     if (entityList == null) {
/*  44 */       return;
/*     */     }
/*  46 */     for (Iterator i$ = entityList.iterator(); i$.hasNext(); ) { Object entity = i$.next();
/*  47 */       getHibernateTemplate().delete(entity); }
/*     */   }
/*     */ 
/*     */   public List<T> findAll()
/*     */   {
/*  52 */     String queryString = "from " + getEntityClass().getName();
/*  53 */     return getHibernateTemplate().find(queryString, getEntityClass());
/*     */   }
/*     */ 
/*     */   public T findById(ID id)
/*     */   {
/*  58 */     return getHibernateTemplate().get(getEntityClass(), id);
/*     */   }
/*     */ 
/*     */   public T save(T entity) {
/*  62 */     getHibernateTemplate().save(entity);
/*  63 */     return entity;
/*     */   }
/*     */ 
/*     */   public T update(T entity) {
/*  67 */     getHibernateTemplate().update(entity);
/*  68 */     return entity;
/*     */   }
/*     */ 
/*     */   public T saveOrUpdate(T entity) {
/*  72 */     getHibernateTemplate().saveOrUpdate(entity);
/*  73 */     return entity;
/*     */   }
/*     */ 
/*     */   public void deleteById(ID id) {
/*  77 */     Object obj = findById(id);
/*  78 */     if (obj != null)
/*  79 */       getHibernateTemplate().delete(obj);
/*     */   }
/*     */ 
/*     */   public void save(List<T> entityList)
/*     */   {
/*  84 */     if (entityList == null) {
/*  85 */       return;
/*     */     }
/*  87 */     for (Iterator i$ = entityList.iterator(); i$.hasNext(); ) { Object entity = i$.next();
/*  88 */       getHibernateTemplate().save(entity); }
/*     */   }
/*     */ 
/*     */   public void update(List<T> entityList)
/*     */   {
/*  93 */     if (entityList == null) {
/*  94 */       return;
/*     */     }
/*  96 */     for (Iterator i$ = entityList.iterator(); i$.hasNext(); ) { Object entity = i$.next();
/*  97 */       getHibernateTemplate().update(entity); }
/*     */   }
/*     */ 
/*     */   protected Class<T> getEntityClass()
/*     */   {
/* 102 */     return this.entityClass;
/*     */   }
/*     */ 
/*     */   protected List<T> findByHql(String hql)
/*     */   {
/* 112 */     return getHibernateTemplate().find(hql, getEntityClass());
/*     */   }
/*     */ 
/*     */   protected List<T> executeHqlQueryList(final String hql, final Object[] objects, final int startRow, final int pageRows)
/*     */   {
/* 130 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException
/*     */       {
/* 134 */         Query query = session.createQuery(hql);
/* 135 */         int i = 0;
/* 136 */         if (objects != null) {
/* 137 */           for (Object obj : objects) {
/* 138 */             query.setParameter(i++, obj);
/*     */           }
/*     */         }
/* 141 */         query.setFirstResult(startRow);
/* 142 */         query.setMaxResults(pageRows);
/* 143 */         return query.list();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   protected int countHqlQuery(final String hql)
/*     */   {
/* 157 */     return ((Integer)getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session session)
/*     */         throws HibernateException, SQLException
/*     */       {
/* 163 */         Query query = session.createQuery(hql);
/* 164 */         Integer rowCount = (Integer)query.uniqueResult();
/*     */ 
/* 167 */         return rowCount;
/*     */       }
/*     */     })).intValue();
/*     */   }
/*     */ 
/*     */   private String parseHqlCountString(String hql)
/*     */   {
/* 181 */     int position1 = hql.toUpperCase().indexOf("FROM");
/* 182 */     String s2 = hql.substring(position1, hql.length());
/* 183 */     int position2 = s2.toUpperCase().indexOf(" ORDER BY");
/* 184 */     int position3 = s2.toUpperCase().indexOf(" GROUP BY");
/*     */ 
/* 186 */     if ((position2 != -1) || (position3 != -1)) {
/* 187 */       if (position2 < position3) {
/* 188 */         if (position2 != -1)
/* 189 */           s2 = s2.substring(0, position2);
/*     */         else
/* 191 */           s2 = s2.substring(0, position3);
/*     */       }
/* 193 */       else if (position2 > position3) {
/* 194 */         if (position3 != -1)
/* 195 */           s2 = s2.substring(0, position3);
/*     */         else {
/* 197 */           s2 = s2.substring(0, position2);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 202 */     return "select count(*) " + s2;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.dao.impl.GeneralDaoImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.dao.IJdbcDao;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
/*     */ import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
/*     */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*     */ 
/*     */ public final class JdbcDaoImpl extends JdbcDaoSupport
/*     */   implements IJdbcDao
/*     */ {
/*  48 */   private Log log = LogFactory.getLog(JdbcDaoImpl.class);
/*     */   private SimpleJdbcTemplate simpleJdbcTemplate;
/*     */ 
/*     */   public JdbcDaoImpl(DataSource dataSource)
/*     */   {
/*  55 */     this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
/*     */ 
/*  57 */     super.setDataSource(dataSource);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public SimpleJdbcTemplate getSimpleJdbcTemplateDeprecated()
/*     */   {
/*  65 */     return this.simpleJdbcTemplate;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public JdbcTemplate getJdbcTemplateDeprecated() {
/*  70 */     return getJdbcTemplate();
/*     */   }
/*     */ 
/*     */   private String calArgs(Object[] args) {
/*  74 */     String argsStr = "";
/*  75 */     for (Object object : args) {
/*  76 */       argsStr = argsStr + String.valueOf(object) + ";";
/*     */     }
/*  78 */     return argsStr;
/*     */   }
/*     */ 
/*     */   public <T> List<T> query(String sql, ParameterizedRowMapper<T> rm, Map<String, Object> args)
/*     */   {
/*  85 */     this.log.info(sql);
/*     */ 
/*  87 */     return this.simpleJdbcTemplate.query(sql, rm, args);
/*     */   }
/*     */ 
/*     */   public <T> List<T> query(String sql, ParameterizedRowMapper<T> rm, Object[] args)
/*     */   {
/*  94 */     this.log.info(sql + "...");
/*  95 */     this.log.info(calArgs(args));
/*  96 */     return this.simpleJdbcTemplate.query(sql, rm, args);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public <T> List<T> query(String sql, ParameterizedRowMapper<T> rm, SqlParameterSource args)
/*     */   {
/* 104 */     this.log.info(sql);
/*     */ 
/* 106 */     return this.simpleJdbcTemplate.query(sql, rm, args);
/*     */   }
/*     */ 
/*     */   public List<Map<String, Object>> queryForList(String sql, Map<String, Object> args)
/*     */   {
/* 112 */     this.log.info(sql);
/* 113 */     return this.simpleJdbcTemplate.queryForList(sql, args);
/*     */   }
/*     */ 
/*     */   public List queryForList(String sql, Object[] args, Class elementType)
/*     */   {
/* 118 */     this.log.info(sql);
/* 119 */     return getJdbcTemplate().queryForList(sql, args, elementType);
/*     */   }
/*     */ 
/*     */   public List<Map<String, Object>> queryForList(String sql, Object[] args)
/*     */   {
/* 124 */     this.log.info(sql + "...");
/* 125 */     return this.simpleJdbcTemplate.queryForList(sql, args);
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, ParameterizedRowMapper<T> rm, Map<String, Object> args)
/*     */   {
/* 131 */     this.log.info(sql);
/* 132 */     this.log.info(calArgs(new Object[] { args }));
/*     */ 
/* 134 */     return this.simpleJdbcTemplate.queryForObject(sql, rm, args);
/*     */   }
/*     */ 
/*     */   public int update(String sql, Object[] args)
/*     */   {
/* 145 */     this.log.info(sql);
/* 146 */     this.log.info(calArgs(args));
/* 147 */     return getJdbcTemplate().update(sql, args);
/*     */   }
/*     */ 
/*     */   public int update(String sql, SqlParameterSource args)
/*     */   {
/* 156 */     this.log.info(sql);
/*     */ 
/* 158 */     return this.simpleJdbcTemplate.update(sql, args);
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, SqlParameterSource[] batchArgs) {
/* 162 */     this.log.info(sql);
/*     */ 
/* 164 */     return this.simpleJdbcTemplate.batchUpdate(sql, batchArgs);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 168 */     System.out.println("我公司的%1的销量达到了%2册".replaceAll("\\%1", "user"));
/* 169 */     System.out.println("我公司的%1的销量达到了%2册".replaceAll("%1", "user"));
/*     */ 
/* 171 */     System.out.println("我公司的$1的销量达到了$2册".replaceAll("\\$1", "user"));
/* 172 */     System.out.println("我公司的$1的销量达到了$2册".replaceAll("$1", "user"));
/*     */   }
/*     */ 
/*     */   public int queryForInt(String sql, Object[] args)
/*     */   {
/* 177 */     this.log.info(sql);
/* 178 */     return getJdbcTemplateDeprecated().queryForInt(sql, args);
/*     */   }
/*     */ 
/*     */   public int queryForCount(String sql, Object[] args)
/*     */   {
/* 183 */     sql = "select count(1) from ( " + sql + " )";
/* 184 */     this.log.info(sql);
/* 185 */     return getJdbcTemplateDeprecated().queryForInt(sql, args);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.dao.impl.JdbcDaoImpl
 * JD-Core Version:    0.6.2
 */
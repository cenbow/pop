/*    */ package com.asiainfo.biframe.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.dao.ISysSynCacheDao;
/*    */ import com.asiainfo.biframe.exception.DaoException;
/*    */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*    */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*    */ 
/*    */ public class SysSynCacheDaoImpl extends JdbcDaoSupport
/*    */   implements ISysSynCacheDao
/*    */ {
/* 36 */   private static Log log = LogFactory.getLog(SysSynCacheDaoImpl.class);
/*    */ 
/*    */   public void addSynCache(String cacheName, String exceptHostIP)
/*    */     throws DaoException
/*    */   {
/* 47 */     Sqlca m_Sqlca = null;
/* 48 */     Sqlca m_Sqlca1 = null;
/*    */     try {
/* 50 */       m_Sqlca = new Sqlca(new ConnectionEx());
/* 51 */       m_Sqlca1 = new Sqlca(new ConnectionEx());
/*    */ 
/* 53 */       m_Sqlca.execute("select serverip from balance_server where serverip<>'" + exceptHostIP + "'");
/*    */ 
/* 56 */       while (m_Sqlca.next()) {
/* 57 */         int syn_id = 1;
/* 58 */         m_Sqlca1.execute("select max(syn_id) as maxid from sys_syn_cache");
/*    */ 
/* 60 */         if (m_Sqlca1.next()) {
/* 61 */           syn_id = m_Sqlca1.getInt("maxid") + 1;
/*    */         }
/* 63 */         m_Sqlca1.execute("select CACHE_CLASS from sys_syn_cache where SYN_HOST_ADDRESS='" + m_Sqlca.getString(1) + "' and SYN_FLAG=1 and CACHE_CLASS='" + cacheName + "'");
/*    */ 
/* 69 */         if (m_Sqlca1.next()) {
/* 70 */           m_Sqlca1.execute("update sys_syn_cache set OP_DATE=" + m_Sqlca1.getSql2DateTimeNow() + ",SYN_DATE=" + m_Sqlca1.getSql2DateTimeNow() + " where SYN_HOST_ADDRESS='" + m_Sqlca.getString(1) + "' and SYN_FLAG=1 and CACHE_CLASS='" + cacheName + "'");
/*    */         }
/*    */         else
/*    */         {
/* 78 */           m_Sqlca1.execute("insert into sys_syn_cache values(" + syn_id + "," + m_Sqlca1.getSql2DateTimeNow() + ",0,'0','" + m_Sqlca.getString(1) + "','" + cacheName + "',1," + m_Sqlca1.getSql2DateTimeNow() + ")");
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 97 */       if (null != m_Sqlca) {
/* 98 */         m_Sqlca.closeAll();
/*    */       }
/* 100 */       if (null != m_Sqlca1)
/* 101 */         m_Sqlca1.closeAll();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 86 */       log.error("", e);
/* 87 */       if (null != m_Sqlca1) {
/*    */         try {
/* 89 */           m_Sqlca1.rollback();
/*    */         } catch (Exception e1) {
/* 91 */           log.error("", e1);
/*    */         }
/*    */       }
/* 94 */       throw new DaoException("Occurs error when adding new sys_syn_cache record.");
/*    */     }
/*    */     finally {
/* 97 */       if (null != m_Sqlca) {
/* 98 */         m_Sqlca.closeAll();
/*    */       }
/* 100 */       if (null != m_Sqlca1)
/* 101 */         m_Sqlca1.closeAll();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.dao.impl.SysSynCacheDaoImpl
 * JD-Core Version:    0.6.2
 */
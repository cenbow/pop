/*    */ package com.asiainfo.biframe.exception;
/*    */ 
/*    */ public class BaseRuntimeException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public BaseRuntimeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BaseRuntimeException(String message)
/*    */   {
/* 21 */     super(message);
/*    */   }
/*    */ 
/*    */   public BaseRuntimeException(String message, Throwable cause) {
/* 25 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public BaseRuntimeException(Throwable cause) {
/* 29 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.exception.BaseRuntimeException
 * JD-Core Version:    0.6.2
 */
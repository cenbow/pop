/*    */ package com.asiainfo.biframe.exception;
/*    */ 
/*    */ public class CacheBaseException extends BaseRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public CacheBaseException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CacheBaseException(String message)
/*    */   {
/* 21 */     super(message);
/*    */   }
/*    */ 
/*    */   public CacheBaseException(String message, Throwable cause) {
/* 25 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public CacheBaseException(Throwable cause) {
/* 29 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.exception.CacheBaseException
 * JD-Core Version:    0.6.2
 */
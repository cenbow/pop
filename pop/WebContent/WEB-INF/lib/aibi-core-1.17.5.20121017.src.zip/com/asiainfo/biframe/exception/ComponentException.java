/*    */ package com.asiainfo.biframe.exception;
/*    */ 
/*    */ public class ComponentException extends BaseRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 7628101230316729775L;
/*    */ 
/*    */   public ComponentException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ComponentException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */ 
/*    */   public ComponentException(String message, Throwable cause)
/*    */   {
/* 35 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ComponentException(Throwable cause)
/*    */   {
/* 43 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.exception.ComponentException
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.exception;
/*    */ 
/*    */ public class NotLoginException extends BaseRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public NotLoginException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NotLoginException(String message)
/*    */   {
/* 29 */     super(message);
/*    */   }
/*    */ 
/*    */   public NotLoginException(String message, Throwable cause)
/*    */   {
/* 38 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public NotLoginException(Throwable cause)
/*    */   {
/* 46 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.exception.NotLoginException
 * JD-Core Version:    0.6.2
 */
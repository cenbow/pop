/*    */ package com.asiainfo.biframe.exception;
/*    */ 
/*    */ public class SuiteRunException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -4263564937421474716L;
/*    */   private String remark;
/*    */ 
/*    */   public SuiteRunException(String message, String remark, Throwable cause)
/*    */   {
/* 38 */     super(message, cause);
/* 39 */     this.remark = remark;
/*    */   }
/*    */ 
/*    */   public String getRemark() {
/* 43 */     return this.remark;
/*    */   }
/*    */ 
/*    */   public void setRemark(String remark) {
/* 47 */     this.remark = remark;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.exception.SuiteRunException
 * JD-Core Version:    0.6.2
 */
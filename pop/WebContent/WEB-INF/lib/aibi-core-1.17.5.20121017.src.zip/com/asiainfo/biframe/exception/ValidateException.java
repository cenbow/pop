/*    */ package com.asiainfo.biframe.exception;
/*    */ 
/*    */ public class ValidateException extends BaseRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ValidateException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ValidateException(String message)
/*    */   {
/* 21 */     super(message);
/*    */   }
/*    */ 
/*    */   public ValidateException(String message, Throwable cause) {
/* 25 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ValidateException(Throwable cause) {
/* 29 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.exception.ValidateException
 * JD-Core Version:    0.6.2
 */
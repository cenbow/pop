/*    */ package com.asiainfo.biframe.kpi.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class KpiAlarmDataVO
/*    */   implements Serializable
/*    */ {
/*    */   private String id;
/*    */   private String kpiName;
/*    */   private String kpiValue;
/*    */   private String statDate;
/*    */   private String alarmThreshold;
/*    */   private String margin;
/*    */   private String columName;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 45 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(String id) {
/* 49 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getKpiName() {
/* 53 */     return this.kpiName;
/*    */   }
/*    */ 
/*    */   public void setKpiName(String kpiName) {
/* 57 */     this.kpiName = kpiName;
/*    */   }
/*    */ 
/*    */   public String getKpiValue() {
/* 61 */     return this.kpiValue;
/*    */   }
/*    */ 
/*    */   public void setKpiValue(String kpiValue) {
/* 65 */     this.kpiValue = kpiValue;
/*    */   }
/*    */ 
/*    */   public String getStatDate() {
/* 69 */     return this.statDate;
/*    */   }
/*    */ 
/*    */   public void setStatDate(String statDate) {
/* 73 */     this.statDate = statDate;
/*    */   }
/*    */ 
/*    */   public String getAlarmThreshold() {
/* 77 */     return this.alarmThreshold;
/*    */   }
/*    */ 
/*    */   public void setAlarmThreshold(String alarmThreshold) {
/* 81 */     this.alarmThreshold = alarmThreshold;
/*    */   }
/*    */ 
/*    */   public String getMargin() {
/* 85 */     return this.margin;
/*    */   }
/*    */ 
/*    */   public void setMargin(String margin) {
/* 89 */     this.margin = margin;
/*    */   }
/*    */   public String getColumName() {
/* 92 */     return this.columName;
/*    */   }
/*    */ 
/*    */   public void setColumName(String columName) {
/* 96 */     this.columName = columName;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiAlarmDataVO
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class KpiAlarmRecordData
/*     */   implements Serializable
/*     */ {
/*     */   private String kpiId;
/*     */   private String kpiName;
/*     */   private String drillDimId;
/*     */   private String drillDimName;
/*     */   private float kpiValue;
/*     */   private String thresholdDesc;
/*     */   private String alarmLevelId;
/*     */   private String alarmContent;
/*     */ 
/*     */   public String getKpiId()
/*     */   {
/*  64 */     return this.kpiId;
/*     */   }
/*     */ 
/*     */   public void setKpiId(String kpiId)
/*     */   {
/*  69 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public String getKpiName()
/*     */   {
/*  74 */     return this.kpiName;
/*     */   }
/*     */ 
/*     */   public void setKpiName(String kpiName)
/*     */   {
/*  79 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public String getDrillDimId()
/*     */   {
/*  84 */     return this.drillDimId;
/*     */   }
/*     */ 
/*     */   public void setDrillDimId(String drillDimId)
/*     */   {
/*  89 */     this.drillDimId = drillDimId;
/*     */   }
/*     */ 
/*     */   public String getDrillDimName()
/*     */   {
/*  94 */     return this.drillDimName;
/*     */   }
/*     */ 
/*     */   public void setDrillDimName(String drillDimName)
/*     */   {
/*  99 */     this.drillDimName = drillDimName;
/*     */   }
/*     */ 
/*     */   public float getKpiValue()
/*     */   {
/* 104 */     return this.kpiValue;
/*     */   }
/*     */ 
/*     */   public void setKpiValue(float kpiValue)
/*     */   {
/* 109 */     this.kpiValue = kpiValue;
/*     */   }
/*     */ 
/*     */   public String getThresholdDesc()
/*     */   {
/* 114 */     return this.thresholdDesc;
/*     */   }
/*     */ 
/*     */   public void setThresholdDesc(String thresholdDesc)
/*     */   {
/* 119 */     this.thresholdDesc = thresholdDesc;
/*     */   }
/*     */ 
/*     */   public String getAlarmContent()
/*     */   {
/* 126 */     return this.alarmContent;
/*     */   }
/*     */ 
/*     */   public void setAlarmContent(String alarmContent)
/*     */   {
/* 131 */     this.alarmContent = alarmContent;
/*     */   }
/*     */ 
/*     */   public String getAlarmLevelId()
/*     */   {
/* 137 */     return this.alarmLevelId;
/*     */   }
/*     */ 
/*     */   public void setAlarmLevelId(String alarmLevelId)
/*     */   {
/* 143 */     this.alarmLevelId = alarmLevelId;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiAlarmRecordData
 * JD-Core Version:    0.6.2
 */
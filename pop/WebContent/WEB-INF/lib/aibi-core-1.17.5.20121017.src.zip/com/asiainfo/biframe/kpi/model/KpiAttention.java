/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ public class KpiAttention
/*     */   implements Serializable
/*     */ {
/*     */   private String kpiAttentionId;
/*     */   private String operatorid;
/*     */   private BigDecimal operatortype;
/*     */   private String kpiId;
/*     */   private BigDecimal displayOrder;
/*     */   private String periodName;
/*     */   private String kpiName;
/*     */ 
/*     */   public KpiAttention()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KpiAttention(String kpiId)
/*     */   {
/*  35 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public KpiAttention(String operatorid, BigDecimal operatortype, String kpiId, BigDecimal displayOrder, String periodName, String kpiName)
/*     */   {
/*  41 */     this.operatorid = operatorid;
/*  42 */     this.operatortype = operatortype;
/*  43 */     this.kpiId = kpiId;
/*  44 */     this.displayOrder = displayOrder;
/*  45 */     this.periodName = periodName;
/*  46 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public String getKpiAttentionId()
/*     */   {
/*  51 */     return this.kpiAttentionId;
/*     */   }
/*     */ 
/*     */   public void setKpiAttentionId(String kpiAttentionId) {
/*  55 */     this.kpiAttentionId = kpiAttentionId;
/*     */   }
/*     */ 
/*     */   public String getOperatorid()
/*     */   {
/*  60 */     return this.operatorid;
/*     */   }
/*     */ 
/*     */   public void setOperatorid(String operatorid)
/*     */   {
/*  65 */     this.operatorid = operatorid;
/*     */   }
/*     */ 
/*     */   public BigDecimal getOperatortype() {
/*  69 */     return this.operatortype;
/*     */   }
/*     */ 
/*     */   public void setOperatortype(BigDecimal operatortype) {
/*  73 */     this.operatortype = operatortype;
/*     */   }
/*     */ 
/*     */   public String getKpiId() {
/*  77 */     return this.kpiId;
/*     */   }
/*     */ 
/*     */   public void setKpiId(String kpiId) {
/*  81 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public BigDecimal getDisplayOrder() {
/*  85 */     return this.displayOrder;
/*     */   }
/*     */ 
/*     */   public String getPeriodName()
/*     */   {
/*  90 */     return this.periodName;
/*     */   }
/*     */ 
/*     */   public void setPeriodName(String periodName) {
/*  94 */     this.periodName = periodName;
/*     */   }
/*     */ 
/*     */   public void setDisplayOrder(BigDecimal displayOrder) {
/*  98 */     this.displayOrder = displayOrder;
/*     */   }
/*     */ 
/*     */   public String getKpiName() {
/* 102 */     return this.kpiName;
/*     */   }
/*     */ 
/*     */   public void setKpiName(String kpiName) {
/* 106 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/* 110 */     if (this == other)
/* 111 */       return true;
/* 112 */     if (other == null)
/* 113 */       return false;
/* 114 */     if (!(other instanceof KpiAttention))
/* 115 */       return false;
/* 116 */     KpiAttention castOther = (KpiAttention)other;
/*     */ 
/* 118 */     return ((getOperatorid() == castOther.getOperatorid()) || ((getOperatorid() != null) && (castOther.getOperatorid() != null) && (getOperatorid().equals(castOther.getOperatorid())))) && ((getOperatortype() == castOther.getOperatortype()) || ((getOperatortype() != null) && (castOther.getOperatortype() != null) && (getOperatortype().equals(castOther.getOperatortype())))) && ((getKpiId() == castOther.getKpiId()) || ((getKpiId() != null) && (castOther.getKpiId() != null) && (getKpiId().equals(castOther.getKpiId())))) && ((getDisplayOrder() == castOther.getDisplayOrder()) || ((getDisplayOrder() != null) && (castOther.getDisplayOrder() != null) && (getDisplayOrder().equals(castOther.getDisplayOrder())))) && ((getPeriodName() == castOther.getPeriodName()) || ((getPeriodName() != null) && (castOther.getPeriodName() != null) && (getPeriodName().equals(castOther.getPeriodName())))) && ((getKpiName() == castOther.getKpiName()) || ((getKpiName() != null) && (castOther.getKpiName() != null) && (getKpiName().equals(castOther.getKpiName()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 142 */     int result = 17;
/*     */ 
/* 144 */     result = 37 * result + (getOperatorid() == null ? 0 : getOperatorid().hashCode());
/* 145 */     result = 37 * result + (getOperatortype() == null ? 0 : getOperatortype().hashCode());
/* 146 */     result = 37 * result + (getKpiId() == null ? 0 : getKpiId().hashCode());
/* 147 */     result = 37 * result + (getDisplayOrder() == null ? 0 : getDisplayOrder().hashCode());
/* 148 */     result = 37 * result + (getPeriodName() == null ? 0 : getPeriodName().hashCode());
/* 149 */     result = 37 * result + (getKpiName() == null ? 0 : getKpiName().hashCode());
/* 150 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiAttention
 * JD-Core Version:    0.6.2
 */
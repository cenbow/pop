/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.List;
/*     */ 
/*     */ public class KpiDaily
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6668582833681731499L;
/*     */   private String dailyId;
/*     */   private String kpiId;
/*     */   private String kpiName;
/*     */   private String kpiDimDataGroupId;
/*     */   private Timestamp dailyDate;
/*     */   private double dailyValue;
/*     */   private double dailyLastValue;
/*     */   private double dailyLastTrend;
/*     */   private double dailyWeekValue;
/*     */   private double dailyWeekTrend;
/*     */   private Integer dailyAreaOrder;
/*     */   private double dailyAreaOccupancy;
/*     */   private double dailyAreaAvg;
/*     */   private double dailyMonthValue;
/*     */   private double dailyMonthTrend;
/*     */   private double dailyAddUp;
/*     */   private double dailyLastAddUp;
/*     */   private double dailyAddUpTrend;
/*     */   private double dailyMission;
/*     */   private double dailyPercent;
/*     */   private Integer dailyAlertStatus;
/*     */   private List<KpiDimDataGroup> dimDataGroupVO;
/*     */   private double dailyProgressRate;
/*     */   private Integer dailyBranchOrder;
/*     */   private double dailyLastTrendValue;
/*     */ 
/*     */   public Integer getDailyBranchOrder()
/*     */   {
/*  73 */     return this.dailyBranchOrder;
/*     */   }
/*     */ 
/*     */   public void setDailyBranchOrder(Integer dailyBranchOrder)
/*     */   {
/*  78 */     this.dailyBranchOrder = dailyBranchOrder;
/*     */   }
/*     */ 
/*     */   public double getDailyLastTrendValue()
/*     */   {
/*  83 */     return this.dailyLastTrendValue;
/*     */   }
/*     */ 
/*     */   public void setDailyLastTrendValue(double dailyLastTrendValue)
/*     */   {
/*  88 */     this.dailyLastTrendValue = dailyLastTrendValue;
/*     */   }
/*     */ 
/*     */   public double getDailyProgressRate() {
/*  92 */     return this.dailyProgressRate;
/*     */   }
/*     */ 
/*     */   public void setDailyProgressRate(double dailyProgressRate) {
/*  96 */     this.dailyProgressRate = dailyProgressRate;
/*     */   }
/*     */ 
/*     */   public String getDailyId() {
/* 100 */     return this.dailyId;
/*     */   }
/*     */ 
/*     */   public void setDailyId(String dailyId) {
/* 104 */     this.dailyId = dailyId;
/*     */   }
/*     */ 
/*     */   public String getKpiId() {
/* 108 */     return this.kpiId;
/*     */   }
/*     */ 
/*     */   public void setKpiId(String kpiId) {
/* 112 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public String getKpiName() {
/* 116 */     return this.kpiName;
/*     */   }
/*     */ 
/*     */   public void setKpiName(String kpiName) {
/* 120 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataGroupId() {
/* 124 */     return this.kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataGroupId(String kpiDimDataGroupId) {
/* 128 */     this.kpiDimDataGroupId = kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public Timestamp getDailyDate()
/*     */   {
/* 133 */     return this.dailyDate;
/*     */   }
/*     */ 
/*     */   public void setDailyDate(Timestamp dailyDate) {
/* 137 */     this.dailyDate = dailyDate;
/*     */   }
/*     */ 
/*     */   public double getDailyValue() {
/* 141 */     return this.dailyValue;
/*     */   }
/*     */ 
/*     */   public void setDailyValue(double dailyValue) {
/* 145 */     this.dailyValue = dailyValue;
/*     */   }
/*     */ 
/*     */   public double getDailyLastValue() {
/* 149 */     return this.dailyLastValue;
/*     */   }
/*     */ 
/*     */   public void setDailyLastValue(double dailyLastValue) {
/* 153 */     this.dailyLastValue = dailyLastValue;
/*     */   }
/*     */ 
/*     */   public double getDailyLastTrend() {
/* 157 */     return this.dailyLastTrend;
/*     */   }
/*     */ 
/*     */   public void setDailyLastTrend(double dailyLastTrend) {
/* 161 */     this.dailyLastTrend = dailyLastTrend;
/*     */   }
/*     */ 
/*     */   public double getDailyWeekValue() {
/* 165 */     return this.dailyWeekValue;
/*     */   }
/*     */ 
/*     */   public void setDailyWeekValue(double dailyWeekValue) {
/* 169 */     this.dailyWeekValue = dailyWeekValue;
/*     */   }
/*     */ 
/*     */   public double getDailyWeekTrend() {
/* 173 */     return this.dailyWeekTrend;
/*     */   }
/*     */ 
/*     */   public void setDailyWeekTrend(double dailyWeekTrend) {
/* 177 */     this.dailyWeekTrend = dailyWeekTrend;
/*     */   }
/*     */ 
/*     */   public Integer getDailyAreaOrder() {
/* 181 */     return this.dailyAreaOrder;
/*     */   }
/*     */ 
/*     */   public void setDailyAreaOrder(Integer dailyAreaOrder) {
/* 185 */     this.dailyAreaOrder = dailyAreaOrder;
/*     */   }
/*     */ 
/*     */   public double getDailyAreaOccupancy() {
/* 189 */     return this.dailyAreaOccupancy;
/*     */   }
/*     */ 
/*     */   public void setDailyAreaOccupancy(double dailyAreaOccupancy) {
/* 193 */     this.dailyAreaOccupancy = dailyAreaOccupancy;
/*     */   }
/*     */ 
/*     */   public double getDailyAreaAvg() {
/* 197 */     return this.dailyAreaAvg;
/*     */   }
/*     */ 
/*     */   public void setDailyAreaAvg(double dailyAreaAvg) {
/* 201 */     this.dailyAreaAvg = dailyAreaAvg;
/*     */   }
/*     */ 
/*     */   public double getDailyMonthValue() {
/* 205 */     return this.dailyMonthValue;
/*     */   }
/*     */ 
/*     */   public void setDailyMonthValue(double dailyMonthValue) {
/* 209 */     this.dailyMonthValue = dailyMonthValue;
/*     */   }
/*     */ 
/*     */   public double getDailyMonthTrend() {
/* 213 */     return this.dailyMonthTrend;
/*     */   }
/*     */ 
/*     */   public void setDailyMonthTrend(double dailyMonthTrend) {
/* 217 */     this.dailyMonthTrend = dailyMonthTrend;
/*     */   }
/*     */ 
/*     */   public double getDailyAddUp() {
/* 221 */     return this.dailyAddUp;
/*     */   }
/*     */ 
/*     */   public void setDailyAddUp(double dailyAddUp) {
/* 225 */     this.dailyAddUp = dailyAddUp;
/*     */   }
/*     */ 
/*     */   public double getDailyLastAddUp() {
/* 229 */     return this.dailyLastAddUp;
/*     */   }
/*     */ 
/*     */   public void setDailyLastAddUp(double dailyLastAddUp) {
/* 233 */     this.dailyLastAddUp = dailyLastAddUp;
/*     */   }
/*     */ 
/*     */   public double getDailyAddUpTrend() {
/* 237 */     return this.dailyAddUpTrend;
/*     */   }
/*     */ 
/*     */   public void setDailyAddUpTrend(double dailyAddUpTrend) {
/* 241 */     this.dailyAddUpTrend = dailyAddUpTrend;
/*     */   }
/*     */ 
/*     */   public double getDailyMission() {
/* 245 */     return this.dailyMission;
/*     */   }
/*     */ 
/*     */   public void setDailyMission(double dailyMission) {
/* 249 */     this.dailyMission = dailyMission;
/*     */   }
/*     */ 
/*     */   public double getDailyPercent() {
/* 253 */     return this.dailyPercent;
/*     */   }
/*     */ 
/*     */   public void setDailyPercent(double dailyPercent) {
/* 257 */     this.dailyPercent = dailyPercent;
/*     */   }
/*     */ 
/*     */   public Integer getDailyAlertStatus() {
/* 261 */     return this.dailyAlertStatus;
/*     */   }
/*     */ 
/*     */   public void setDailyAlertStatus(Integer dailyAlertStatus) {
/* 265 */     this.dailyAlertStatus = dailyAlertStatus;
/*     */   }
/*     */   public List<KpiDimDataGroup> getDimDataGroupVO() {
/* 268 */     return this.dimDataGroupVO;
/*     */   }
/*     */ 
/*     */   public void setDimDataGroupVO(List<KpiDimDataGroup> dimDataGroupVO) {
/* 272 */     this.dimDataGroupVO = dimDataGroupVO;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiDaily
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ public class KpiDataColumn
/*     */   implements Serializable
/*     */ {
/*     */   private String dataColId;
/*     */   private String dataColName;
/*     */   private String dataColChn;
/*     */   private String dataTableId;
/*     */   private String dataColDataType;
/*     */   private BigDecimal dataColType;
/*     */ 
/*     */   public KpiDataColumn()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KpiDataColumn(String dataColId, String dataColName, String dataColChn, String dataTableId, String dataColDataType, BigDecimal dataColType)
/*     */   {
/*  34 */     this.dataColId = dataColId;
/*  35 */     this.dataColName = dataColName;
/*  36 */     this.dataColChn = dataColChn;
/*  37 */     this.dataTableId = dataTableId;
/*  38 */     this.dataColDataType = dataColDataType;
/*  39 */     this.dataColType = dataColType;
/*     */   }
/*     */ 
/*     */   public String getDataColId()
/*     */   {
/*  45 */     return this.dataColId;
/*     */   }
/*     */ 
/*     */   public void setDataColId(String dataColId) {
/*  49 */     this.dataColId = dataColId;
/*     */   }
/*     */ 
/*     */   public String getDataColName() {
/*  53 */     return this.dataColName;
/*     */   }
/*     */ 
/*     */   public void setDataColName(String dataColName) {
/*  57 */     this.dataColName = dataColName;
/*     */   }
/*     */ 
/*     */   public String getDataColChn() {
/*  61 */     return this.dataColChn;
/*     */   }
/*     */ 
/*     */   public void setDataColChn(String dataColChn) {
/*  65 */     this.dataColChn = dataColChn;
/*     */   }
/*     */ 
/*     */   public String getDataTableId() {
/*  69 */     return this.dataTableId;
/*     */   }
/*     */ 
/*     */   public void setDataTableId(String dataTableId) {
/*  73 */     this.dataTableId = dataTableId;
/*     */   }
/*     */ 
/*     */   public String getDataColDataType() {
/*  77 */     return this.dataColDataType;
/*     */   }
/*     */ 
/*     */   public void setDataColDataType(String dataColDataType) {
/*  81 */     this.dataColDataType = dataColDataType;
/*     */   }
/*     */ 
/*     */   public BigDecimal getDataColType() {
/*  85 */     return this.dataColType;
/*     */   }
/*     */ 
/*     */   public void setDataColType(BigDecimal dataColType) {
/*  89 */     this.dataColType = dataColType;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/*  93 */     if (this == other)
/*  94 */       return true;
/*  95 */     if (other == null)
/*  96 */       return false;
/*  97 */     if (!(other instanceof KpiDataColumn))
/*  98 */       return false;
/*  99 */     KpiDataColumn castOther = (KpiDataColumn)other;
/*     */ 
/* 101 */     return ((getDataColId() == castOther.getDataColId()) || ((getDataColId() != null) && (castOther.getDataColId() != null) && (getDataColId().equals(castOther.getDataColId())))) && ((getDataColName() == castOther.getDataColName()) || ((getDataColName() != null) && (castOther.getDataColName() != null) && (getDataColName().equals(castOther.getDataColName())))) && ((getDataColChn() == castOther.getDataColChn()) || ((getDataColChn() != null) && (castOther.getDataColChn() != null) && (getDataColChn().equals(castOther.getDataColChn())))) && ((getDataTableId() == castOther.getDataTableId()) || ((getDataTableId() != null) && (castOther.getDataTableId() != null) && (getDataTableId().equals(castOther.getDataTableId())))) && ((getDataColDataType() == castOther.getDataColDataType()) || ((getDataColDataType() != null) && (castOther.getDataColDataType() != null) && (getDataColDataType().equals(castOther.getDataColDataType())))) && ((getDataColType() == castOther.getDataColType()) || ((getDataColType() != null) && (castOther.getDataColType() != null) && (getDataColType().equals(castOther.getDataColType()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 123 */     int result = 17;
/*     */ 
/* 125 */     result = 37 * result + (getDataColId() == null ? 0 : getDataColId().hashCode());
/* 126 */     result = 37 * result + (getDataColName() == null ? 0 : getDataColName().hashCode());
/* 127 */     result = 37 * result + (getDataColChn() == null ? 0 : getDataColChn().hashCode());
/* 128 */     result = 37 * result + (getDataTableId() == null ? 0 : getDataTableId().hashCode());
/* 129 */     result = 37 * result + (getDataColDataType() == null ? 0 : getDataColDataType().hashCode());
/*     */ 
/* 131 */     result = 37 * result + (getDataColType() == null ? 0 : getDataColType().hashCode());
/* 132 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiDataColumn
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class KpiDefine
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String kpiId;
/*     */   private String kpiCode;
/*     */   private String kpiName;
/*     */   private String kpiNameKey;
/*     */   private String kpiTypeId;
/*     */   private String kpiTypeName;
/*     */   private String kpiPeriodId;
/*     */   private Integer kpiDataUnit;
/*     */   private String kpiUnit;
/*     */   private String kpiParentId;
/*     */   private String kpiFormat;
/*     */   private Integer kpiAddUp;
/*     */   private String kpiCaliber;
/*     */   private String kpiDesc;
/*     */   private Integer kpiDisplayOrder;
/*     */   private Integer kpiTelecomsOperator;
/*     */   private Integer resourceType;
/*     */   private Map<String, String> extendValue;
/*     */   private Integer kpiOrderRule;
/*     */ 
/*     */   public KpiDefine()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KpiDefine(String kpiId, String kpiCode, String kpiName, String kpiNameKey, String kpiTypeId, String kpiTypeName, String kpiPeriodId, Integer kpiDataUnit, String kpiFormat, Integer kpiAddUp, Integer kpiDisplayOrder, Integer kpiTelecomsOperator, String kpiUnit, Integer resourceType)
/*     */   {
/*  64 */     this.kpiId = kpiId;
/*  65 */     this.kpiCode = kpiCode;
/*  66 */     this.kpiName = kpiName;
/*  67 */     this.kpiNameKey = kpiNameKey;
/*  68 */     this.kpiTypeId = kpiTypeId;
/*  69 */     this.kpiTypeName = kpiTypeName;
/*  70 */     this.kpiPeriodId = kpiPeriodId;
/*  71 */     this.kpiDataUnit = kpiDataUnit;
/*  72 */     this.kpiFormat = kpiFormat;
/*  73 */     this.kpiAddUp = kpiAddUp;
/*  74 */     this.kpiDisplayOrder = kpiDisplayOrder;
/*  75 */     this.kpiTelecomsOperator = kpiTelecomsOperator;
/*  76 */     this.kpiUnit = kpiUnit;
/*  77 */     this.resourceType = resourceType;
/*     */   }
/*     */ 
/*     */   public KpiDefine(String kpiId, String kpiCode, String kpiName, String kpiNameKey, String kpiTypeId, String kpiTypeName, String kpiPeriodId, Integer kpiDataUnit, String kpiParentId, String kpiFormat, Integer kpiAddUp, String kpiCaliber, String kpiDesc, Integer kpiDisplayOrder, Integer kpiTelecomsOperator, String kpiUnit, Integer resourceType)
/*     */   {
/*  85 */     this.kpiId = kpiId;
/*  86 */     this.kpiCode = kpiCode;
/*  87 */     this.kpiName = kpiName;
/*  88 */     this.kpiNameKey = kpiNameKey;
/*  89 */     this.kpiTypeId = kpiTypeId;
/*  90 */     this.kpiTypeName = kpiTypeName;
/*  91 */     this.kpiPeriodId = kpiPeriodId;
/*  92 */     this.kpiDataUnit = kpiDataUnit;
/*  93 */     this.kpiParentId = kpiParentId;
/*  94 */     this.kpiFormat = kpiFormat;
/*  95 */     this.kpiAddUp = kpiAddUp;
/*  96 */     this.kpiCaliber = kpiCaliber;
/*  97 */     this.kpiDesc = kpiDesc;
/*  98 */     this.kpiDisplayOrder = kpiDisplayOrder;
/*  99 */     this.kpiTelecomsOperator = kpiTelecomsOperator;
/* 100 */     this.kpiUnit = kpiUnit;
/* 101 */     this.resourceType = resourceType;
/*     */   }
/*     */ 
/*     */   public String getKpiId()
/*     */   {
/* 107 */     return this.kpiId;
/*     */   }
/*     */ 
/*     */   public void setKpiId(String kpiId) {
/* 111 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public String getKpiCode() {
/* 115 */     return this.kpiCode;
/*     */   }
/*     */ 
/*     */   public void setKpiCode(String kpiCode) {
/* 119 */     this.kpiCode = kpiCode;
/*     */   }
/*     */ 
/*     */   public String getKpiName() {
/* 123 */     return this.kpiName;
/*     */   }
/*     */ 
/*     */   public void setKpiName(String kpiName) {
/* 127 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public String getKpiNameKey() {
/* 131 */     return this.kpiNameKey;
/*     */   }
/*     */ 
/*     */   public void setKpiNameKey(String kpiNameKey) {
/* 135 */     this.kpiNameKey = kpiNameKey;
/*     */   }
/*     */ 
/*     */   public String getKpiTypeId() {
/* 139 */     return this.kpiTypeId;
/*     */   }
/*     */ 
/*     */   public void setKpiTypeId(String kpiTypeId) {
/* 143 */     this.kpiTypeId = kpiTypeId;
/*     */   }
/*     */ 
/*     */   public String getKpiPeriodId() {
/* 147 */     return this.kpiPeriodId;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodId(String kpiPeriodId) {
/* 151 */     this.kpiPeriodId = kpiPeriodId;
/*     */   }
/*     */ 
/*     */   public Integer getKpiDataUnit() {
/* 155 */     return this.kpiDataUnit;
/*     */   }
/*     */ 
/*     */   public void setKpiDataUnit(Integer kpiDataUnit) {
/* 159 */     this.kpiDataUnit = kpiDataUnit;
/*     */   }
/*     */ 
/*     */   public String getKpiParentId() {
/* 163 */     return this.kpiParentId;
/*     */   }
/*     */ 
/*     */   public void setKpiParentId(String kpiParentId) {
/* 167 */     this.kpiParentId = kpiParentId;
/*     */   }
/*     */ 
/*     */   public String getKpiFormat() {
/* 171 */     return this.kpiFormat;
/*     */   }
/*     */ 
/*     */   public void setKpiFormat(String kpiFormat) {
/* 175 */     this.kpiFormat = kpiFormat;
/*     */   }
/*     */ 
/*     */   public Integer getKpiAddUp() {
/* 179 */     return this.kpiAddUp;
/*     */   }
/*     */ 
/*     */   public void setKpiAddUp(Integer kpiAddUp) {
/* 183 */     this.kpiAddUp = kpiAddUp;
/*     */   }
/*     */ 
/*     */   public String getKpiCaliber() {
/* 187 */     return this.kpiCaliber;
/*     */   }
/*     */ 
/*     */   public void setKpiCaliber(String kpiCaliber) {
/* 191 */     this.kpiCaliber = kpiCaliber;
/*     */   }
/*     */ 
/*     */   public String getKpiDesc() {
/* 195 */     return this.kpiDesc;
/*     */   }
/*     */ 
/*     */   public void setKpiDesc(String kpiDesc) {
/* 199 */     this.kpiDesc = kpiDesc;
/*     */   }
/*     */ 
/*     */   public Integer getKpiDisplayOrder() {
/* 203 */     return this.kpiDisplayOrder;
/*     */   }
/*     */ 
/*     */   public void setKpiDisplayOrder(Integer kpiDisplayOrder) {
/* 207 */     this.kpiDisplayOrder = kpiDisplayOrder;
/*     */   }
/*     */ 
/*     */   public Integer getKpiTelecomsOperator() {
/* 211 */     return this.kpiTelecomsOperator;
/*     */   }
/*     */ 
/*     */   public void setKpiTelecomsOperator(Integer kpiTelecomsOperator) {
/* 215 */     this.kpiTelecomsOperator = kpiTelecomsOperator;
/*     */   }
/*     */ 
/*     */   public String getKpiUnit() {
/* 219 */     return this.kpiUnit;
/*     */   }
/*     */ 
/*     */   public void setKpiUnit(String kpiUnit) {
/* 223 */     this.kpiUnit = kpiUnit;
/*     */   }
/*     */   public String getKpiTypeName() {
/* 226 */     return this.kpiTypeName;
/*     */   }
/*     */ 
/*     */   public void setKpiTypeName(String kpiTypeName) {
/* 230 */     this.kpiTypeName = kpiTypeName;
/*     */   }
/*     */ 
/*     */   public Integer getResourceType() {
/* 234 */     return this.resourceType;
/*     */   }
/*     */ 
/*     */   public void setResourceType(Integer resourceType) {
/* 238 */     this.resourceType = resourceType;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getExtendValue() {
/* 242 */     return this.extendValue;
/*     */   }
/*     */ 
/*     */   public void setExtendValue(Map<String, String> extendValue) {
/* 246 */     this.extendValue = extendValue;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 251 */     return "KpiDefine [kpiAddUp=" + this.kpiAddUp + ", kpiCaliber=" + this.kpiCaliber + ", kpiCode=" + this.kpiCode + ", kpiDataUnit=" + this.kpiDataUnit + ", kpiDesc=" + this.kpiDesc + ", kpiDisplayOrder=" + this.kpiDisplayOrder + ", kpiFormat=" + this.kpiFormat + ", kpiId=" + this.kpiId + ", kpiName=" + this.kpiName + ", kpiNameKey=" + this.kpiNameKey + ", kpiParentId=" + this.kpiParentId + ", kpiPeriodId=" + this.kpiPeriodId + ", kpiTelecomsOperator=" + this.kpiTelecomsOperator + ", kpiTypeId=" + this.kpiTypeId + ", kpiTypeName=" + this.kpiTypeName + ", kpiUnit=" + this.kpiUnit + ", resourceType=" + this.resourceType + "]";
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 265 */     int prime = 31;
/* 266 */     int result = 1;
/* 267 */     result = 31 * result + (this.kpiAddUp == null ? 0 : this.kpiAddUp.hashCode());
/*     */ 
/* 269 */     result = 31 * result + (this.kpiCaliber == null ? 0 : this.kpiCaliber.hashCode());
/*     */ 
/* 271 */     result = 31 * result + (this.kpiCode == null ? 0 : this.kpiCode.hashCode());
/* 272 */     result = 31 * result + (this.kpiDataUnit == null ? 0 : this.kpiDataUnit.hashCode());
/*     */ 
/* 274 */     result = 31 * result + (this.kpiDesc == null ? 0 : this.kpiDesc.hashCode());
/* 275 */     result = 31 * result + (this.kpiDisplayOrder == null ? 0 : this.kpiDisplayOrder.hashCode());
/*     */ 
/* 277 */     result = 31 * result + (this.kpiFormat == null ? 0 : this.kpiFormat.hashCode());
/*     */ 
/* 279 */     result = 31 * result + (this.kpiId == null ? 0 : this.kpiId.hashCode());
/* 280 */     result = 31 * result + (this.kpiName == null ? 0 : this.kpiName.hashCode());
/* 281 */     result = 31 * result + (this.kpiNameKey == null ? 0 : this.kpiNameKey.hashCode());
/*     */ 
/* 283 */     result = 31 * result + (this.kpiParentId == null ? 0 : this.kpiParentId.hashCode());
/*     */ 
/* 285 */     result = 31 * result + (this.kpiPeriodId == null ? 0 : this.kpiPeriodId.hashCode());
/*     */ 
/* 287 */     result = 31 * result + (this.kpiTelecomsOperator == null ? 0 : this.kpiTelecomsOperator.hashCode());
/*     */ 
/* 291 */     result = 31 * result + (this.kpiTypeId == null ? 0 : this.kpiTypeId.hashCode());
/*     */ 
/* 293 */     result = 31 * result + (this.kpiTypeName == null ? 0 : this.kpiTypeName.hashCode());
/*     */ 
/* 295 */     result = 31 * result + (this.kpiUnit == null ? 0 : this.kpiUnit.hashCode());
/* 296 */     result = 31 * result + (this.resourceType == null ? 0 : this.resourceType.hashCode());
/*     */ 
/* 298 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 303 */     if (this == obj)
/* 304 */       return true;
/* 305 */     if (obj == null)
/* 306 */       return false;
/* 307 */     if (getClass() != obj.getClass())
/* 308 */       return false;
/* 309 */     KpiDefine other = (KpiDefine)obj;
/* 310 */     if (this.kpiAddUp == null) {
/* 311 */       if (other.kpiAddUp != null)
/* 312 */         return false;
/* 313 */     } else if (!this.kpiAddUp.equals(other.kpiAddUp))
/* 314 */       return false;
/* 315 */     if (this.kpiCaliber == null) {
/* 316 */       if (other.kpiCaliber != null)
/* 317 */         return false;
/* 318 */     } else if (!this.kpiCaliber.equals(other.kpiCaliber))
/* 319 */       return false;
/* 320 */     if (this.kpiCode == null) {
/* 321 */       if (other.kpiCode != null)
/* 322 */         return false;
/* 323 */     } else if (!this.kpiCode.equals(other.kpiCode))
/* 324 */       return false;
/* 325 */     if (this.kpiDataUnit == null) {
/* 326 */       if (other.kpiDataUnit != null)
/* 327 */         return false;
/* 328 */     } else if (!this.kpiDataUnit.equals(other.kpiDataUnit))
/* 329 */       return false;
/* 330 */     if (this.kpiDesc == null) {
/* 331 */       if (other.kpiDesc != null)
/* 332 */         return false;
/* 333 */     } else if (!this.kpiDesc.equals(other.kpiDesc))
/* 334 */       return false;
/* 335 */     if (this.kpiDisplayOrder == null) {
/* 336 */       if (other.kpiDisplayOrder != null)
/* 337 */         return false;
/* 338 */     } else if (!this.kpiDisplayOrder.equals(other.kpiDisplayOrder))
/* 339 */       return false;
/* 340 */     if (this.kpiFormat == null) {
/* 341 */       if (other.kpiFormat != null)
/* 342 */         return false;
/* 343 */     } else if (!this.kpiFormat.equals(other.kpiFormat))
/* 344 */       return false;
/* 345 */     if (this.kpiId == null) {
/* 346 */       if (other.kpiId != null)
/* 347 */         return false;
/* 348 */     } else if (!this.kpiId.equals(other.kpiId))
/* 349 */       return false;
/* 350 */     if (this.kpiName == null) {
/* 351 */       if (other.kpiName != null)
/* 352 */         return false;
/* 353 */     } else if (!this.kpiName.equals(other.kpiName))
/* 354 */       return false;
/* 355 */     if (this.kpiNameKey == null) {
/* 356 */       if (other.kpiNameKey != null)
/* 357 */         return false;
/* 358 */     } else if (!this.kpiNameKey.equals(other.kpiNameKey))
/* 359 */       return false;
/* 360 */     if (this.kpiParentId == null) {
/* 361 */       if (other.kpiParentId != null)
/* 362 */         return false;
/* 363 */     } else if (!this.kpiParentId.equals(other.kpiParentId))
/* 364 */       return false;
/* 365 */     if (this.kpiPeriodId == null) {
/* 366 */       if (other.kpiPeriodId != null)
/* 367 */         return false;
/* 368 */     } else if (!this.kpiPeriodId.equals(other.kpiPeriodId))
/* 369 */       return false;
/* 370 */     if (this.kpiTelecomsOperator == null) {
/* 371 */       if (other.kpiTelecomsOperator != null)
/* 372 */         return false;
/* 373 */     } else if (!this.kpiTelecomsOperator.equals(other.kpiTelecomsOperator))
/* 374 */       return false;
/* 375 */     if (this.kpiTypeId == null) {
/* 376 */       if (other.kpiTypeId != null)
/* 377 */         return false;
/* 378 */     } else if (!this.kpiTypeId.equals(other.kpiTypeId))
/* 379 */       return false;
/* 380 */     if (this.kpiTypeName == null) {
/* 381 */       if (other.kpiTypeName != null)
/* 382 */         return false;
/* 383 */     } else if (!this.kpiTypeName.equals(other.kpiTypeName))
/* 384 */       return false;
/* 385 */     if (this.kpiUnit == null) {
/* 386 */       if (other.kpiUnit != null)
/* 387 */         return false;
/* 388 */     } else if (!this.kpiUnit.equals(other.kpiUnit))
/* 389 */       return false;
/* 390 */     if (this.resourceType == null) {
/* 391 */       if (other.resourceType != null)
/* 392 */         return false;
/* 393 */     } else if (!this.resourceType.equals(other.resourceType))
/* 394 */       return false;
/* 395 */     return true;
/*     */   }
/*     */ 
/*     */   public Integer getKpiOrderRule()
/*     */   {
/* 400 */     return this.kpiOrderRule;
/*     */   }
/*     */ 
/*     */   public void setKpiOrderRule(Integer kpiOrderRule)
/*     */   {
/* 405 */     this.kpiOrderRule = kpiOrderRule;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiDefine
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.kpi.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class KpiDim
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String kpiDimId;
/*    */   private String kpiDimName;
/*    */   private String kpiDimDesc;
/*    */   private Integer kpiDimPrivilegeFlag;
/*    */   private String kpiDimRoleType;
/*    */   private String kpiDimRoleResourceType;
/*    */   private Integer kpiDimDisplayOrder;
/*    */ 
/*    */   public String getKpiDimId()
/*    */   {
/* 33 */     return this.kpiDimId;
/*    */   }
/*    */ 
/*    */   public void setKpiDimId(String kpiDimId) {
/* 37 */     this.kpiDimId = kpiDimId;
/*    */   }
/*    */ 
/*    */   public String getKpiDimName() {
/* 41 */     return this.kpiDimName;
/*    */   }
/*    */ 
/*    */   public void setKpiDimName(String kpiDimName) {
/* 45 */     this.kpiDimName = kpiDimName;
/*    */   }
/*    */ 
/*    */   public String getKpiDimDesc() {
/* 49 */     return this.kpiDimDesc;
/*    */   }
/*    */ 
/*    */   public void setKpiDimDesc(String kpiDimDesc) {
/* 53 */     this.kpiDimDesc = kpiDimDesc;
/*    */   }
/*    */ 
/*    */   public Integer getKpiDimPrivilegeFlag() {
/* 57 */     return this.kpiDimPrivilegeFlag;
/*    */   }
/*    */ 
/*    */   public void setKpiDimPrivilegeFlag(Integer kpiDimPrivilegeFlag) {
/* 61 */     this.kpiDimPrivilegeFlag = kpiDimPrivilegeFlag;
/*    */   }
/*    */ 
/*    */   public String getKpiDimRoleType() {
/* 65 */     return this.kpiDimRoleType;
/*    */   }
/*    */ 
/*    */   public void setKpiDimRoleType(String kpiDimRoleType) {
/* 69 */     this.kpiDimRoleType = kpiDimRoleType;
/*    */   }
/*    */ 
/*    */   public String getKpiDimRoleResourceType() {
/* 73 */     return this.kpiDimRoleResourceType;
/*    */   }
/*    */ 
/*    */   public void setKpiDimRoleResourceType(String kpiDimRoleResourceType) {
/* 77 */     this.kpiDimRoleResourceType = kpiDimRoleResourceType;
/*    */   }
/*    */ 
/*    */   public Integer getKpiDimDisplayOrder() {
/* 81 */     return this.kpiDimDisplayOrder;
/*    */   }
/*    */ 
/*    */   public void setKpiDimDisplayOrder(Integer kpiDimDisplayOrder) {
/* 85 */     this.kpiDimDisplayOrder = kpiDimDisplayOrder;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiDim
 * JD-Core Version:    0.6.2
 */
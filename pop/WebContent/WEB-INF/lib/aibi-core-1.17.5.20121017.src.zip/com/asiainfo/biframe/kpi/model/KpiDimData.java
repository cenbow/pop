/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class KpiDimData
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String kpiDimDataId;
/*     */   private String kpiDimId;
/*     */   private String kpiDimDataName;
/*     */   private String kpiDimDataValue;
/*     */   private String kpiDimDataParentId;
/*     */   private String kpiDimDataLevel;
/*     */   private Integer kpiDimDataTelecomsOperator;
/*     */   private String kpiDimSuffix;
/*     */   private Integer kpiDimState;
/*     */   private Integer kpiUnknownFlag;
/*     */   private Integer kpiDimDataDisplayOrder;
/*     */ 
/*     */   public KpiDimData()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KpiDimData(String kpiDimDataId, String kpiDimId, String kpiDimDataName, String kpiDimDataValue, String kpiDimDataParentId, String kpiDimDataLevel, Integer kpiDimDataTelecomsOperator)
/*     */   {
/*  46 */     this.kpiDimDataId = kpiDimDataId;
/*  47 */     this.kpiDimId = kpiDimId;
/*  48 */     this.kpiDimDataName = kpiDimDataName;
/*  49 */     this.kpiDimDataValue = kpiDimDataValue;
/*  50 */     this.kpiDimDataParentId = kpiDimDataParentId;
/*  51 */     this.kpiDimDataLevel = kpiDimDataLevel;
/*  52 */     this.kpiDimDataTelecomsOperator = kpiDimDataTelecomsOperator;
/*     */   }
/*     */ 
/*     */   public KpiDimData(String kpiDimDataId, String kpiDimId, String kpiDimDataName, String kpiDimDataValue, String kpiDimDataParentId, String kpiDimDataLevel, Integer kpiDimDataTelecomsOperator, String kpiDimSuffix)
/*     */   {
/*  59 */     this.kpiDimDataId = kpiDimDataId;
/*  60 */     this.kpiDimId = kpiDimId;
/*  61 */     this.kpiDimDataName = kpiDimDataName;
/*  62 */     this.kpiDimDataValue = kpiDimDataValue;
/*  63 */     this.kpiDimDataParentId = kpiDimDataParentId;
/*  64 */     this.kpiDimDataLevel = kpiDimDataLevel;
/*  65 */     this.kpiDimDataTelecomsOperator = kpiDimDataTelecomsOperator;
/*  66 */     this.kpiDimSuffix = kpiDimSuffix;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataId()
/*     */   {
/*  72 */     return this.kpiDimDataId;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataId(String kpiDimDataId) {
/*  76 */     this.kpiDimDataId = kpiDimDataId;
/*     */   }
/*     */ 
/*     */   public String getKpiDimId() {
/*  80 */     return this.kpiDimId;
/*     */   }
/*     */ 
/*     */   public void setKpiDimId(String kpiDimId) {
/*  84 */     this.kpiDimId = kpiDimId;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataName() {
/*  88 */     return this.kpiDimDataName;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataName(String kpiDimDataName) {
/*  92 */     this.kpiDimDataName = kpiDimDataName;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataValue() {
/*  96 */     return this.kpiDimDataValue;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataValue(String kpiDimDataValue) {
/* 100 */     this.kpiDimDataValue = kpiDimDataValue;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataParentId() {
/* 104 */     return this.kpiDimDataParentId;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataParentId(String kpiDimDataParentId) {
/* 108 */     this.kpiDimDataParentId = kpiDimDataParentId;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataLevel() {
/* 112 */     return this.kpiDimDataLevel;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataLevel(String kpiDimDataLevel) {
/* 116 */     this.kpiDimDataLevel = kpiDimDataLevel;
/*     */   }
/*     */ 
/*     */   public Integer getKpiDimDataTelecomsOperator() {
/* 120 */     return this.kpiDimDataTelecomsOperator;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataTelecomsOperator(Integer kpiDimDataTelecomsOperator) {
/* 124 */     this.kpiDimDataTelecomsOperator = kpiDimDataTelecomsOperator;
/*     */   }
/*     */ 
/*     */   public String getKpiDimSuffix() {
/* 128 */     return this.kpiDimSuffix;
/*     */   }
/*     */ 
/*     */   public void setKpiDimSuffix(String kpiDimSuffix) {
/* 132 */     this.kpiDimSuffix = kpiDimSuffix;
/*     */   }
/*     */ 
/*     */   public Integer getKpiDimState() {
/* 136 */     return this.kpiDimState;
/*     */   }
/*     */ 
/*     */   public void setKpiDimState(Integer kpiDimState) {
/* 140 */     this.kpiDimState = kpiDimState;
/*     */   }
/*     */ 
/*     */   public Integer getKpiUnknownFlag() {
/* 144 */     return this.kpiUnknownFlag;
/*     */   }
/*     */ 
/*     */   public void setKpiUnknownFlag(Integer kpiUnknownFlag) {
/* 148 */     this.kpiUnknownFlag = kpiUnknownFlag;
/*     */   }
/*     */ 
/*     */   public Integer getKpiDimDataDisplayOrder()
/*     */   {
/* 153 */     return this.kpiDimDataDisplayOrder;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataDisplayOrder(Integer kpiDimDataDisplayOrder)
/*     */   {
/* 158 */     this.kpiDimDataDisplayOrder = kpiDimDataDisplayOrder;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiDimData
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.kpi.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class KpiDimDataGroup
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4861923349989784016L;
/*    */   private String kpiDimDataGroupId;
/*    */   private String kpiDimDataName;
/*    */   private String kpiDimDataValue;
/*    */   private String kpiDimId;
/*    */ 
/*    */   public String getKpiDimDataGroupId()
/*    */   {
/* 28 */     return this.kpiDimDataGroupId;
/*    */   }
/*    */ 
/*    */   public void setKpiDimDataGroupId(String kpiDimDataGroupId) {
/* 32 */     this.kpiDimDataGroupId = kpiDimDataGroupId;
/*    */   }
/*    */ 
/*    */   public String getKpiDimDataName() {
/* 36 */     return this.kpiDimDataName;
/*    */   }
/*    */ 
/*    */   public void setKpiDimDataName(String kpiDimDataName) {
/* 40 */     this.kpiDimDataName = kpiDimDataName;
/*    */   }
/*    */ 
/*    */   public String getKpiDimDataValue() {
/* 44 */     return this.kpiDimDataValue;
/*    */   }
/*    */ 
/*    */   public void setKpiDimDataValue(String kpiDimDataValue) {
/* 48 */     this.kpiDimDataValue = kpiDimDataValue;
/*    */   }
/*    */ 
/*    */   public String getKpiDimId() {
/* 52 */     return this.kpiDimId;
/*    */   }
/*    */ 
/*    */   public void setKpiDimId(String kpiDimId) {
/* 56 */     this.kpiDimId = kpiDimId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiDimDataGroup
 * JD-Core Version:    0.6.2
 */
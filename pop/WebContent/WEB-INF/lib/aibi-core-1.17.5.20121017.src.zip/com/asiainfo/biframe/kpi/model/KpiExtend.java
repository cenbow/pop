/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class KpiExtend
/*     */   implements Serializable
/*     */ {
/*     */   private String kpiExtendId;
/*     */   private String kpiExtendName;
/*     */   private String kpiExtendCode;
/*     */   private String kpiExtendDesc;
/*     */ 
/*     */   public KpiExtend()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KpiExtend(String kpiExtendId, String kpiExtendName, String kpiExtendCode)
/*     */   {
/*  27 */     this.kpiExtendId = kpiExtendId;
/*  28 */     this.kpiExtendName = kpiExtendName;
/*  29 */     this.kpiExtendCode = kpiExtendCode;
/*     */   }
/*     */ 
/*     */   public KpiExtend(String kpiExtendId, String kpiExtendName, String kpiExtendCode, String kpiExtendDesc)
/*     */   {
/*  35 */     this.kpiExtendId = kpiExtendId;
/*  36 */     this.kpiExtendName = kpiExtendName;
/*  37 */     this.kpiExtendCode = kpiExtendCode;
/*  38 */     this.kpiExtendDesc = kpiExtendDesc;
/*     */   }
/*     */ 
/*     */   public String getKpiExtendId()
/*     */   {
/*  44 */     return this.kpiExtendId;
/*     */   }
/*     */ 
/*     */   public void setKpiExtendId(String kpiExtendId) {
/*  48 */     this.kpiExtendId = kpiExtendId;
/*     */   }
/*     */ 
/*     */   public String getKpiExtendName() {
/*  52 */     return this.kpiExtendName;
/*     */   }
/*     */ 
/*     */   public void setKpiExtendName(String kpiExtendName) {
/*  56 */     this.kpiExtendName = kpiExtendName;
/*     */   }
/*     */ 
/*     */   public String getKpiExtendCode() {
/*  60 */     return this.kpiExtendCode;
/*     */   }
/*     */ 
/*     */   public void setKpiExtendCode(String kpiExtendCode) {
/*  64 */     this.kpiExtendCode = kpiExtendCode;
/*     */   }
/*     */ 
/*     */   public String getKpiExtendDesc() {
/*  68 */     return this.kpiExtendDesc;
/*     */   }
/*     */ 
/*     */   public void setKpiExtendDesc(String kpiExtendDesc) {
/*  72 */     this.kpiExtendDesc = kpiExtendDesc;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/*  76 */     if (this == other)
/*  77 */       return true;
/*  78 */     if (other == null)
/*  79 */       return false;
/*  80 */     if (!(other instanceof KpiExtend))
/*  81 */       return false;
/*  82 */     KpiExtend castOther = (KpiExtend)other;
/*     */ 
/*  84 */     return ((getKpiExtendId() == castOther.getKpiExtendId()) || ((getKpiExtendId() != null) && (castOther.getKpiExtendId() != null) && (getKpiExtendId().equals(castOther.getKpiExtendId())))) && ((getKpiExtendName() == castOther.getKpiExtendName()) || ((getKpiExtendName() != null) && (castOther.getKpiExtendName() != null) && (getKpiExtendName().equals(castOther.getKpiExtendName())))) && ((getKpiExtendCode() == castOther.getKpiExtendCode()) || ((getKpiExtendCode() != null) && (castOther.getKpiExtendCode() != null) && (getKpiExtendCode().equals(castOther.getKpiExtendCode())))) && ((getKpiExtendDesc() == castOther.getKpiExtendDesc()) || ((getKpiExtendDesc() != null) && (castOther.getKpiExtendDesc() != null) && (getKpiExtendDesc().equals(castOther.getKpiExtendDesc()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 102 */     int result = 17;
/*     */ 
/* 104 */     result = 37 * result + (getKpiExtendId() == null ? 0 : getKpiExtendId().hashCode());
/* 105 */     result = 37 * result + (getKpiExtendName() == null ? 0 : getKpiExtendName().hashCode());
/*     */ 
/* 107 */     result = 37 * result + (getKpiExtendCode() == null ? 0 : getKpiExtendCode().hashCode());
/*     */ 
/* 109 */     result = 37 * result + (getKpiExtendDesc() == null ? 0 : getKpiExtendDesc().hashCode());
/*     */ 
/* 111 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiExtend
 * JD-Core Version:    0.6.2
 */
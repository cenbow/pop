/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class KpiExtendValue
/*     */   implements Serializable
/*     */ {
/*     */   private String kpiExtendValueId;
/*     */   private String kpiId;
/*     */   private String kpiExtendId;
/*     */   private String kpiExtendValue;
/*     */ 
/*     */   public KpiExtendValue()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KpiExtendValue(String kpiExtendValueId, String kpiId, String kpiExtendId, String kpiExtendValue)
/*     */   {
/*  28 */     this.kpiExtendValueId = kpiExtendValueId;
/*  29 */     this.kpiId = kpiId;
/*  30 */     this.kpiExtendId = kpiExtendId;
/*  31 */     this.kpiExtendValue = kpiExtendValue;
/*     */   }
/*     */ 
/*     */   public String getKpiExtendValueId()
/*     */   {
/*  37 */     return this.kpiExtendValueId;
/*     */   }
/*     */ 
/*     */   public void setKpiExtendValueId(String kpiExtendValueId) {
/*  41 */     this.kpiExtendValueId = kpiExtendValueId;
/*     */   }
/*     */ 
/*     */   public String getKpiId() {
/*  45 */     return this.kpiId;
/*     */   }
/*     */ 
/*     */   public void setKpiId(String kpiId) {
/*  49 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public String getKpiExtendId() {
/*  53 */     return this.kpiExtendId;
/*     */   }
/*     */ 
/*     */   public void setKpiExtendId(String kpiExtendId) {
/*  57 */     this.kpiExtendId = kpiExtendId;
/*     */   }
/*     */ 
/*     */   public String getKpiExtendValue() {
/*  61 */     return this.kpiExtendValue;
/*     */   }
/*     */ 
/*     */   public void setKpiExtendValue(String kpiExtendValue) {
/*  65 */     this.kpiExtendValue = kpiExtendValue;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/*  69 */     if (this == other)
/*  70 */       return true;
/*  71 */     if (other == null)
/*  72 */       return false;
/*  73 */     if (!(other instanceof KpiExtendValue))
/*  74 */       return false;
/*  75 */     KpiExtendValue castOther = (KpiExtendValue)other;
/*     */ 
/*  77 */     return ((getKpiExtendValueId() == castOther.getKpiExtendValueId()) || ((getKpiExtendValueId() != null) && (castOther.getKpiExtendValueId() != null) && (getKpiExtendValueId().equals(castOther.getKpiExtendValueId())))) && ((getKpiId() == castOther.getKpiId()) || ((getKpiId() != null) && (castOther.getKpiId() != null) && (getKpiId().equals(castOther.getKpiId())))) && ((getKpiExtendId() == castOther.getKpiExtendId()) || ((getKpiExtendId() != null) && (castOther.getKpiExtendId() != null) && (getKpiExtendId().equals(castOther.getKpiExtendId())))) && ((getKpiExtendValue() == castOther.getKpiExtendValue()) || ((getKpiExtendValue() != null) && (castOther.getKpiExtendValue() != null) && (getKpiExtendValue().equals(castOther.getKpiExtendValue()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  94 */     int result = 17;
/*     */ 
/*  96 */     result = 37 * result + (getKpiExtendValueId() == null ? 0 : getKpiExtendValueId().hashCode());
/*     */ 
/*  98 */     result = 37 * result + (getKpiId() == null ? 0 : getKpiId().hashCode());
/*  99 */     result = 37 * result + (getKpiExtendId() == null ? 0 : getKpiExtendId().hashCode());
/* 100 */     result = 37 * result + (getKpiExtendValue() == null ? 0 : getKpiExtendValue().hashCode());
/*     */ 
/* 102 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiExtendValue
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.kpi.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class KpiKpiRelation
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private KpiRelation kpiRelation;
/*    */   private Map<String, KpiDefine> kpiDefines;
/*    */ 
/*    */   public KpiRelation getKpiRelation()
/*    */   {
/* 17 */     return this.kpiRelation;
/*    */   }
/*    */ 
/*    */   public Map<String, KpiDefine> getKpiDefines() {
/* 21 */     return this.kpiDefines;
/*    */   }
/*    */ 
/*    */   public void setKpiDefines(Map<String, KpiDefine> kpiDefines) {
/* 25 */     this.kpiDefines = kpiDefines;
/*    */   }
/*    */ 
/*    */   public void setKpiRelation(KpiRelation kpiRelation) {
/* 29 */     this.kpiRelation = kpiRelation;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiKpiRelation
 * JD-Core Version:    0.6.2
 */
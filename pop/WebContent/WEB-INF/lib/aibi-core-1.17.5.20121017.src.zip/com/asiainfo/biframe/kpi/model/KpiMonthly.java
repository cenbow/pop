/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.List;
/*     */ 
/*     */ public class KpiMonthly
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -9154945266148143487L;
/*     */   private String monthlyId;
/*     */   private String kpiId;
/*     */   private String kpiName;
/*     */   private String kpiDimDataGroupId;
/*     */   private Timestamp monthlyStartDate;
/*     */   private Integer monthlyNo;
/*     */   private double monthlyValue;
/*     */   private double monthlyLastValue;
/*     */   private double monthlyLastTrend;
/*     */   private double monthlyYearValue;
/*     */   private double monthlyYearTrend;
/*     */   private Integer monthlyAreaOrder;
/*     */   private double monthlyAreaOccupancy;
/*     */   private double monthlyAreaAvg;
/*     */   private double monthlyAddUp;
/*     */   private double monthlyMission;
/*     */   private double monthlyPercent;
/*     */   private Integer monthlyAlertStatus;
/*     */   private Integer monthlyChangePlace;
/*     */   private String monthlyValueText;
/*     */   private double monthlyAddUpYearTrend;
/*     */   private Integer monthlyBranchOrder;
/*     */   private double monthlyLastTrendValue;
/*     */   private List<KpiDimDataGroup> dimDataGroupVO;
/*     */ 
/*     */   public List<KpiDimDataGroup> getDimDataGroupVO()
/*     */   {
/*  70 */     return this.dimDataGroupVO;
/*     */   }
/*     */ 
/*     */   public void setDimDataGroupVO(List<KpiDimDataGroup> dimDataGroupVO) {
/*  74 */     this.dimDataGroupVO = dimDataGroupVO;
/*     */   }
/*     */ 
/*     */   public String getMonthlyId() {
/*  78 */     return this.monthlyId;
/*     */   }
/*     */ 
/*     */   public void setMonthlyId(String monthlyId) {
/*  82 */     this.monthlyId = monthlyId;
/*     */   }
/*     */ 
/*     */   public String getKpiId() {
/*  86 */     return this.kpiId;
/*     */   }
/*     */ 
/*     */   public void setKpiId(String kpiId) {
/*  90 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public String getKpiName() {
/*  94 */     return this.kpiName;
/*     */   }
/*     */ 
/*     */   public void setKpiName(String kpiName) {
/*  98 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataGroupId() {
/* 102 */     return this.kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataGroupId(String kpiDimDataGroupId) {
/* 106 */     this.kpiDimDataGroupId = kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public Timestamp getMonthlyStartDate() {
/* 110 */     return this.monthlyStartDate;
/*     */   }
/*     */ 
/*     */   public void setMonthlyStartDate(Timestamp monthlyStartDate) {
/* 114 */     this.monthlyStartDate = monthlyStartDate;
/*     */   }
/*     */ 
/*     */   public Integer getMonthlyNo() {
/* 118 */     return this.monthlyNo;
/*     */   }
/*     */ 
/*     */   public void setMonthlyNo(Integer monthlyNo) {
/* 122 */     this.monthlyNo = monthlyNo;
/*     */   }
/*     */ 
/*     */   public double getMonthlyValue() {
/* 126 */     return this.monthlyValue;
/*     */   }
/*     */ 
/*     */   public void setMonthlyValue(double monthlyValue) {
/* 130 */     this.monthlyValue = monthlyValue;
/*     */   }
/*     */ 
/*     */   public double getMonthlyLastValue() {
/* 134 */     return this.monthlyLastValue;
/*     */   }
/*     */ 
/*     */   public void setMonthlyLastValue(double monthlyLastValue) {
/* 138 */     this.monthlyLastValue = monthlyLastValue;
/*     */   }
/*     */ 
/*     */   public double getMonthlyLastTrend() {
/* 142 */     return this.monthlyLastTrend;
/*     */   }
/*     */ 
/*     */   public void setMonthlyLastTrend(double monthlyLastTrend) {
/* 146 */     this.monthlyLastTrend = monthlyLastTrend;
/*     */   }
/*     */ 
/*     */   public double getMonthlyYearValue() {
/* 150 */     return this.monthlyYearValue;
/*     */   }
/*     */ 
/*     */   public void setMonthlyYearValue(double monthlyYearValue) {
/* 154 */     this.monthlyYearValue = monthlyYearValue;
/*     */   }
/*     */ 
/*     */   public double getMonthlyYearTrend() {
/* 158 */     return this.monthlyYearTrend;
/*     */   }
/*     */ 
/*     */   public void setMonthlyYearTrend(double monthlyYearTrend) {
/* 162 */     this.monthlyYearTrend = monthlyYearTrend;
/*     */   }
/*     */ 
/*     */   public Integer getMonthlyAreaOrder() {
/* 166 */     return this.monthlyAreaOrder;
/*     */   }
/*     */ 
/*     */   public void setMonthlyAreaOrder(Integer monthlyAreaOrder) {
/* 170 */     this.monthlyAreaOrder = monthlyAreaOrder;
/*     */   }
/*     */ 
/*     */   public double getMonthlyAreaOccupancy() {
/* 174 */     return this.monthlyAreaOccupancy;
/*     */   }
/*     */ 
/*     */   public void setMonthlyAreaOccupancy(double monthlyAreaOccupancy) {
/* 178 */     this.monthlyAreaOccupancy = monthlyAreaOccupancy;
/*     */   }
/*     */ 
/*     */   public double getMonthlyAreaAvg() {
/* 182 */     return this.monthlyAreaAvg;
/*     */   }
/*     */ 
/*     */   public void setMonthlyAreaAvg(double monthlyAreaAvg) {
/* 186 */     this.monthlyAreaAvg = monthlyAreaAvg;
/*     */   }
/*     */ 
/*     */   public double getMonthlyAddUp() {
/* 190 */     return this.monthlyAddUp;
/*     */   }
/*     */ 
/*     */   public void setMonthlyAddUp(double monthlyAddUp) {
/* 194 */     this.monthlyAddUp = monthlyAddUp;
/*     */   }
/*     */ 
/*     */   public double getMonthlyMission() {
/* 198 */     return this.monthlyMission;
/*     */   }
/*     */ 
/*     */   public void setMonthlyMission(double monthlyMission) {
/* 202 */     this.monthlyMission = monthlyMission;
/*     */   }
/*     */ 
/*     */   public double getMonthlyPercent() {
/* 206 */     return this.monthlyPercent;
/*     */   }
/*     */ 
/*     */   public void setMonthlyPercent(double monthlyPercent) {
/* 210 */     this.monthlyPercent = monthlyPercent;
/*     */   }
/*     */ 
/*     */   public Integer getMonthlyAlertStatus() {
/* 214 */     return this.monthlyAlertStatus;
/*     */   }
/*     */ 
/*     */   public void setMonthlyAlertStatus(Integer monthlyAlertStatus) {
/* 218 */     this.monthlyAlertStatus = monthlyAlertStatus;
/*     */   }
/*     */ 
/*     */   public Integer getMonthlyChangePlace()
/*     */   {
/* 223 */     return this.monthlyChangePlace;
/*     */   }
/*     */ 
/*     */   public void setMonthlyChangePlace(Integer monthlyChangePlace)
/*     */   {
/* 228 */     this.monthlyChangePlace = monthlyChangePlace;
/*     */   }
/*     */ 
/*     */   public String getMonthlyValueText()
/*     */   {
/* 233 */     return this.monthlyValueText;
/*     */   }
/*     */ 
/*     */   public void setMonthlyValueText(String monthlyValueText)
/*     */   {
/* 238 */     this.monthlyValueText = monthlyValueText;
/*     */   }
/*     */ 
/*     */   public double getMonthlyAddUpYearTrend()
/*     */   {
/* 243 */     return this.monthlyAddUpYearTrend;
/*     */   }
/*     */ 
/*     */   public void setMonthlyAddUpYearTrend(double monthlyAddUpYearTrend)
/*     */   {
/* 248 */     this.monthlyAddUpYearTrend = monthlyAddUpYearTrend;
/*     */   }
/*     */ 
/*     */   public Integer getMonthlyBranchOrder()
/*     */   {
/* 253 */     return this.monthlyBranchOrder;
/*     */   }
/*     */ 
/*     */   public void setMonthlyBranchOrder(Integer monthlyBranchOrder)
/*     */   {
/* 258 */     this.monthlyBranchOrder = monthlyBranchOrder;
/*     */   }
/*     */ 
/*     */   public double getMonthlyLastTrendValue()
/*     */   {
/* 263 */     return this.monthlyLastTrendValue;
/*     */   }
/*     */ 
/*     */   public void setMonthlyLastTrendValue(double monthlyLastTrendValue)
/*     */   {
/* 268 */     this.monthlyLastTrendValue = monthlyLastTrendValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiMonthly
 * JD-Core Version:    0.6.2
 */
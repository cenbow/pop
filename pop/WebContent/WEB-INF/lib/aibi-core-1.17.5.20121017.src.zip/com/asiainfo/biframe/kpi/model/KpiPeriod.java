/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class KpiPeriod
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7861944116328803738L;
/*     */   public static final String KPI_PERIOD_DAILY = "DAILY";
/*     */   public static final String KPI_PERIOD_MONTHLY = "MONTHLY";
/*     */   public static final String KPI_PERIOD_YEARLY = "YEARLY";
/*     */   public static final String KPI_PERIOD_REALTIME = "REAL_TIME";
/*     */   private String kpiPeriodId;
/*     */   private String kpiPeriodName;
/*     */   private String kpiPeriodAlias;
/*     */   private String kpiPeriodCode;
/*     */   private Double kpiPeriodLevel;
/*     */   private Timestamp kpiPeriodDate;
/*     */   private String kpiPeriodAlertId;
/*     */   private Integer displayOrder;
/*     */ 
/*     */   public KpiPeriod()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KpiPeriod(String kpiPeriodId, String kpiPeriodName, String kpiPeriodAlias, String kpiPeriodCode, Double kpiPeriodLevel, Timestamp kpiPeriodDate, String kpiPeriodAlertId)
/*     */   {
/*  53 */     this.kpiPeriodId = kpiPeriodId;
/*  54 */     this.kpiPeriodName = kpiPeriodName;
/*  55 */     this.kpiPeriodAlias = kpiPeriodAlias;
/*  56 */     this.kpiPeriodCode = kpiPeriodCode;
/*  57 */     this.kpiPeriodLevel = kpiPeriodLevel;
/*  58 */     this.kpiPeriodDate = kpiPeriodDate;
/*  59 */     this.kpiPeriodAlertId = kpiPeriodAlertId;
/*     */   }
/*     */ 
/*     */   public KpiPeriod(String kpiPeriodId, String kpiPeriodName, String kpiPeriodAlias, String kpiPeriodCode, Double kpiPeriodLevel, Timestamp kpiPeriodDate, String kpiPeriodAlertId, Integer displayOrder)
/*     */   {
/*  66 */     this.kpiPeriodId = kpiPeriodId;
/*  67 */     this.kpiPeriodName = kpiPeriodName;
/*  68 */     this.kpiPeriodAlias = kpiPeriodAlias;
/*  69 */     this.kpiPeriodCode = kpiPeriodCode;
/*  70 */     this.kpiPeriodLevel = kpiPeriodLevel;
/*  71 */     this.kpiPeriodDate = kpiPeriodDate;
/*  72 */     this.kpiPeriodAlertId = kpiPeriodAlertId;
/*  73 */     this.displayOrder = displayOrder;
/*     */   }
/*     */ 
/*     */   public String getKpiPeriodId()
/*     */   {
/*  79 */     return this.kpiPeriodId;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodId(String kpiPeriodId) {
/*  83 */     this.kpiPeriodId = kpiPeriodId;
/*     */   }
/*     */ 
/*     */   public String getKpiPeriodName() {
/*  87 */     return this.kpiPeriodName;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodName(String kpiPeriodName) {
/*  91 */     this.kpiPeriodName = kpiPeriodName;
/*     */   }
/*     */ 
/*     */   public String getKpiPeriodAlias() {
/*  95 */     return this.kpiPeriodAlias;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodAlias(String kpiPeriodAlias) {
/*  99 */     this.kpiPeriodAlias = kpiPeriodAlias;
/*     */   }
/*     */ 
/*     */   public String getKpiPeriodCode() {
/* 103 */     return this.kpiPeriodCode;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodCode(String kpiPeriodCode) {
/* 107 */     this.kpiPeriodCode = kpiPeriodCode;
/*     */   }
/*     */ 
/*     */   public Double getKpiPeriodLevel() {
/* 111 */     return this.kpiPeriodLevel;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodLevel(Double kpiPeriodLevel) {
/* 115 */     this.kpiPeriodLevel = kpiPeriodLevel;
/*     */   }
/*     */ 
/*     */   public Timestamp getKpiPeriodDate()
/*     */   {
/* 120 */     return this.kpiPeriodDate;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodDate(Timestamp kpiPeriodDate) {
/* 124 */     this.kpiPeriodDate = kpiPeriodDate;
/*     */   }
/*     */ 
/*     */   public String getKpiPeriodAlertId() {
/* 128 */     return this.kpiPeriodAlertId;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodAlertId(String kpiPeriodAlertId) {
/* 132 */     this.kpiPeriodAlertId = kpiPeriodAlertId;
/*     */   }
/*     */ 
/*     */   public Integer getDisplayOrder() {
/* 136 */     return this.displayOrder;
/*     */   }
/*     */ 
/*     */   public void setDisplayOrder(Integer displayOrder) {
/* 140 */     this.displayOrder = displayOrder;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiPeriod
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class KpiPeriodColumn
/*     */   implements Serializable
/*     */ {
/*     */   private String periodColumnId;
/*     */   private String kpiPeriodId;
/*     */   private String periodColumnWidth;
/*     */   private String periodColumnName;
/*     */   private String periodColumnChn;
/*     */   private Integer periodColumnAccess;
/*     */   private Integer periodColumnDisplayOrder;
/*     */   private String periodColumnDesc;
/*     */   private String periodColumnUnitType;
/*     */ 
/*     */   public KpiPeriodColumn()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KpiPeriodColumn(String periodColumnId, String kpiPeriodId, String periodColumnWidth, String periodColumnName, String periodColumnChn, Integer periodColumnAccess)
/*     */   {
/*  42 */     this.periodColumnId = periodColumnId;
/*  43 */     this.kpiPeriodId = kpiPeriodId;
/*  44 */     this.periodColumnWidth = periodColumnWidth;
/*  45 */     this.periodColumnName = periodColumnName;
/*  46 */     this.periodColumnChn = periodColumnChn;
/*  47 */     this.periodColumnAccess = periodColumnAccess;
/*     */   }
/*     */ 
/*     */   public KpiPeriodColumn(String periodColumnId, String kpiPeriodId, String periodColumnWidth, String periodColumnName, String periodColumnChn, Integer periodColumnAccess, Integer periodColumnDisplayOrder, String periodColumnDesc)
/*     */   {
/*  55 */     this.periodColumnId = periodColumnId;
/*  56 */     this.kpiPeriodId = kpiPeriodId;
/*  57 */     this.periodColumnWidth = periodColumnWidth;
/*  58 */     this.periodColumnName = periodColumnName;
/*  59 */     this.periodColumnChn = periodColumnChn;
/*  60 */     this.periodColumnAccess = periodColumnAccess;
/*  61 */     this.periodColumnDisplayOrder = periodColumnDisplayOrder;
/*  62 */     this.periodColumnDesc = periodColumnDesc;
/*     */   }
/*     */ 
/*     */   public String getPeriodColumnId()
/*     */   {
/*  68 */     return this.periodColumnId;
/*     */   }
/*     */ 
/*     */   public void setPeriodColumnId(String periodColumnId) {
/*  72 */     this.periodColumnId = periodColumnId;
/*     */   }
/*     */ 
/*     */   public String getKpiPeriodId() {
/*  76 */     return this.kpiPeriodId;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodId(String kpiPeriodId) {
/*  80 */     this.kpiPeriodId = kpiPeriodId;
/*     */   }
/*     */ 
/*     */   public String getPeriodColumnWidth() {
/*  84 */     return this.periodColumnWidth;
/*     */   }
/*     */ 
/*     */   public void setPeriodColumnWidth(String periodColumnWidth) {
/*  88 */     this.periodColumnWidth = periodColumnWidth;
/*     */   }
/*     */ 
/*     */   public String getPeriodColumnName() {
/*  92 */     return this.periodColumnName;
/*     */   }
/*     */ 
/*     */   public void setPeriodColumnName(String periodColumnName) {
/*  96 */     this.periodColumnName = periodColumnName;
/*     */   }
/*     */ 
/*     */   public String getPeriodColumnChn() {
/* 100 */     return this.periodColumnChn;
/*     */   }
/*     */ 
/*     */   public void setPeriodColumnChn(String periodColumnChn) {
/* 104 */     this.periodColumnChn = periodColumnChn;
/*     */   }
/*     */ 
/*     */   public Integer getPeriodColumnAccess() {
/* 108 */     return this.periodColumnAccess;
/*     */   }
/*     */ 
/*     */   public void setPeriodColumnAccess(Integer periodColumnAccess) {
/* 112 */     this.periodColumnAccess = periodColumnAccess;
/*     */   }
/*     */ 
/*     */   public Integer getPeriodColumnDisplayOrder() {
/* 116 */     return this.periodColumnDisplayOrder;
/*     */   }
/*     */ 
/*     */   public void setPeriodColumnDisplayOrder(Integer periodColumnDisplayOrder) {
/* 120 */     this.periodColumnDisplayOrder = periodColumnDisplayOrder;
/*     */   }
/*     */ 
/*     */   public String getPeriodColumnDesc() {
/* 124 */     return this.periodColumnDesc;
/*     */   }
/*     */ 
/*     */   public void setPeriodColumnDesc(String periodColumnDesc) {
/* 128 */     this.periodColumnDesc = periodColumnDesc;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/* 132 */     if (this == other)
/* 133 */       return true;
/* 134 */     if (other == null)
/* 135 */       return false;
/* 136 */     if (!(other instanceof KpiPeriodColumn))
/* 137 */       return false;
/* 138 */     KpiPeriodColumn castOther = (KpiPeriodColumn)other;
/*     */ 
/* 140 */     return ((getPeriodColumnId() == castOther.getPeriodColumnId()) || ((getPeriodColumnId() != null) && (castOther.getPeriodColumnId() != null) && (getPeriodColumnId().equals(castOther.getPeriodColumnId())))) && ((getKpiPeriodId() == castOther.getKpiPeriodId()) || ((getKpiPeriodId() != null) && (castOther.getKpiPeriodId() != null) && (getKpiPeriodId().equals(castOther.getKpiPeriodId())))) && ((getPeriodColumnWidth() == castOther.getPeriodColumnWidth()) || ((getPeriodColumnWidth() != null) && (castOther.getPeriodColumnWidth() != null) && (getPeriodColumnWidth().equals(castOther.getPeriodColumnWidth())))) && ((getPeriodColumnName() == castOther.getPeriodColumnName()) || ((getPeriodColumnName() != null) && (castOther.getPeriodColumnName() != null) && (getPeriodColumnName().equals(castOther.getPeriodColumnName())))) && ((getPeriodColumnChn() == castOther.getPeriodColumnChn()) || ((getPeriodColumnChn() != null) && (castOther.getPeriodColumnChn() != null) && (getPeriodColumnChn().equals(castOther.getPeriodColumnChn())))) && ((getPeriodColumnAccess() == castOther.getPeriodColumnAccess()) || ((getPeriodColumnAccess() != null) && (castOther.getPeriodColumnAccess() != null) && (getPeriodColumnAccess().equals(castOther.getPeriodColumnAccess())))) && ((getPeriodColumnDisplayOrder() == castOther.getPeriodColumnDisplayOrder()) || ((getPeriodColumnDisplayOrder() != null) && (castOther.getPeriodColumnDisplayOrder() != null) && (getPeriodColumnDisplayOrder().equals(castOther.getPeriodColumnDisplayOrder())))) && ((getPeriodColumnDesc() == castOther.getPeriodColumnDesc()) || ((getPeriodColumnDesc() != null) && (castOther.getPeriodColumnDesc() != null) && (getPeriodColumnDesc().equals(castOther.getPeriodColumnDesc()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 175 */     int result = 17;
/*     */ 
/* 177 */     result = 37 * result + (getPeriodColumnId() == null ? 0 : getPeriodColumnId().hashCode());
/*     */ 
/* 179 */     result = 37 * result + (getKpiPeriodId() == null ? 0 : getKpiPeriodId().hashCode());
/* 180 */     result = 37 * result + (getPeriodColumnWidth() == null ? 0 : getPeriodColumnWidth().hashCode());
/*     */ 
/* 182 */     result = 37 * result + (getPeriodColumnName() == null ? 0 : getPeriodColumnName().hashCode());
/*     */ 
/* 184 */     result = 37 * result + (getPeriodColumnChn() == null ? 0 : getPeriodColumnChn().hashCode());
/*     */ 
/* 186 */     result = 37 * result + (getPeriodColumnAccess() == null ? 0 : getPeriodColumnAccess().hashCode());
/*     */ 
/* 188 */     result = 37 * result + (getPeriodColumnDisplayOrder() == null ? 0 : getPeriodColumnDisplayOrder().hashCode());
/*     */ 
/* 192 */     result = 37 * result + (getPeriodColumnDesc() == null ? 0 : getPeriodColumnDesc().hashCode());
/*     */ 
/* 194 */     return result;
/*     */   }
/*     */ 
/*     */   public String getPeriodColumnUnitType()
/*     */   {
/* 199 */     return this.periodColumnUnitType;
/*     */   }
/*     */ 
/*     */   public void setPeriodColumnUnitType(String periodColumnUnitType)
/*     */   {
/* 204 */     this.periodColumnUnitType = periodColumnUnitType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiPeriodColumn
 * JD-Core Version:    0.6.2
 */
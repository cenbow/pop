/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.List;
/*     */ 
/*     */ public class KpiRealTime
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String realTimeId;
/*     */   private String kpiId;
/*     */   private String kpiName;
/*     */   private String kpiDimDataGroupId;
/*     */   private Timestamp realTimeStartDate;
/*     */   private double realTimeValue;
/*     */   private double realTimeLastValue;
/*     */   private double realTimeYearTrend;
/*     */   private double realTimeLastTrend;
/*     */   private Integer realTimeAreaOrder;
/*     */   private double realTimeAreaOccupancy;
/*     */   private double realTimeMission;
/*     */   private Integer realTimeBranchOrder;
/*     */   private double realTimeLastTrendValue;
/*     */   private List<KpiDimDataGroup> dimDataGroupVO;
/*     */   private double realTimePercent;
/*     */   private Integer realTimeAlertStatus;
/*     */ 
/*     */   public Integer getRealTimeBranchOrder()
/*     */   {
/*  61 */     return this.realTimeBranchOrder;
/*     */   }
/*     */ 
/*     */   public void setRealTimeBranchOrder(Integer realTimeBranchOrder)
/*     */   {
/*  66 */     this.realTimeBranchOrder = realTimeBranchOrder;
/*     */   }
/*     */ 
/*     */   public double getRealTimeLastTrendValue()
/*     */   {
/*  71 */     return this.realTimeLastTrendValue;
/*     */   }
/*     */ 
/*     */   public void setRealTimeLastTrendValue(double realTimeLastTrendValue)
/*     */   {
/*  76 */     this.realTimeLastTrendValue = realTimeLastTrendValue;
/*     */   }
/*     */ 
/*     */   public List<KpiDimDataGroup> getDimDataGroupVO()
/*     */   {
/*  83 */     return this.dimDataGroupVO;
/*     */   }
/*     */ 
/*     */   public void setDimDataGroupVO(List<KpiDimDataGroup> dimDataGroupVO) {
/*  87 */     this.dimDataGroupVO = dimDataGroupVO;
/*     */   }
/*     */ 
/*     */   public String getRealTimeId() {
/*  91 */     return this.realTimeId;
/*     */   }
/*     */ 
/*     */   public void setRealTimeId(String realTimeId) {
/*  95 */     this.realTimeId = realTimeId;
/*     */   }
/*     */ 
/*     */   public String getKpiId() {
/*  99 */     return this.kpiId;
/*     */   }
/*     */ 
/*     */   public void setKpiId(String kpiId) {
/* 103 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public String getKpiName() {
/* 107 */     return this.kpiName;
/*     */   }
/*     */ 
/*     */   public void setKpiName(String kpiName) {
/* 111 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataGroupId() {
/* 115 */     return this.kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataGroupId(String kpiDimDataGroupId) {
/* 119 */     this.kpiDimDataGroupId = kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public Timestamp getRealTimeStartDate() {
/* 123 */     return this.realTimeStartDate;
/*     */   }
/*     */ 
/*     */   public void setRealTimeStartDate(Timestamp realTimeStartDate) {
/* 127 */     this.realTimeStartDate = realTimeStartDate;
/*     */   }
/*     */ 
/*     */   public double getRealTimeValue() {
/* 131 */     return this.realTimeValue;
/*     */   }
/*     */ 
/*     */   public void setRealTimeValue(double realTimeValue) {
/* 135 */     this.realTimeValue = realTimeValue;
/*     */   }
/*     */ 
/*     */   public double getRealTimeLastValue() {
/* 139 */     return this.realTimeLastValue;
/*     */   }
/*     */ 
/*     */   public void setRealTimeLastValue(double realTimeLastValue) {
/* 143 */     this.realTimeLastValue = realTimeLastValue;
/*     */   }
/*     */ 
/*     */   public double getRealTimeYearTrend() {
/* 147 */     return this.realTimeYearTrend;
/*     */   }
/*     */ 
/*     */   public void setRealTimeYearTrend(double realTimeYearTrend) {
/* 151 */     this.realTimeYearTrend = realTimeYearTrend;
/*     */   }
/*     */ 
/*     */   public double getRealTimeLastTrend() {
/* 155 */     return this.realTimeLastTrend;
/*     */   }
/*     */ 
/*     */   public void setRealTimeLastTrend(double realTimeLastTrend) {
/* 159 */     this.realTimeLastTrend = realTimeLastTrend;
/*     */   }
/*     */ 
/*     */   public Integer getRealTimeAreaOrder() {
/* 163 */     return this.realTimeAreaOrder;
/*     */   }
/*     */ 
/*     */   public void setRealTimeAreaOrder(Integer realTimeAreaOrder) {
/* 167 */     this.realTimeAreaOrder = realTimeAreaOrder;
/*     */   }
/*     */ 
/*     */   public double getRealTimeAreaOccupancy() {
/* 171 */     return this.realTimeAreaOccupancy;
/*     */   }
/*     */ 
/*     */   public void setRealTimeAreaOccupancy(double realTimeAreaOccupancy) {
/* 175 */     this.realTimeAreaOccupancy = realTimeAreaOccupancy;
/*     */   }
/*     */ 
/*     */   public double getRealTimeMission() {
/* 179 */     return this.realTimeMission;
/*     */   }
/*     */ 
/*     */   public void setRealTimeMission(double realTimeMission) {
/* 183 */     this.realTimeMission = realTimeMission;
/*     */   }
/*     */ 
/*     */   public double getRealTimePercent() {
/* 187 */     return this.realTimePercent;
/*     */   }
/*     */ 
/*     */   public void setRealTimePercent(double realTimePercent) {
/* 191 */     this.realTimePercent = realTimePercent;
/*     */   }
/*     */ 
/*     */   public Integer getRealTimeAlertStatus() {
/* 195 */     return this.realTimeAlertStatus;
/*     */   }
/*     */ 
/*     */   public void setRealTimeAlertStatus(Integer realTimeAlertStatus) {
/* 199 */     this.realTimeAlertStatus = realTimeAlertStatus;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiRealTime
 * JD-Core Version:    0.6.2
 */
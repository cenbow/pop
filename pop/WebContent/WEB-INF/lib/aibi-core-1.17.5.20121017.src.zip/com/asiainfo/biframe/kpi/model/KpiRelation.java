/*    */ package com.asiainfo.biframe.kpi.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class KpiRelation
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String relaId;
/*    */   private String kpiId;
/*    */   private String relaKpiId;
/*    */   private Integer ifShow;
/*    */   private Integer relaKpiType;
/*    */   private Integer ifSameKind;
/*    */   private Integer relaChartType;
/*    */ 
/*    */   public String getRelaId()
/*    */   {
/* 27 */     return this.relaId;
/*    */   }
/*    */ 
/*    */   public void setRelaId(String relaId) {
/* 31 */     this.relaId = relaId;
/*    */   }
/*    */ 
/*    */   public String getKpiId() {
/* 35 */     return this.kpiId;
/*    */   }
/*    */ 
/*    */   public void setKpiId(String kpiId) {
/* 39 */     this.kpiId = kpiId;
/*    */   }
/*    */ 
/*    */   public String getRelaKpiId() {
/* 43 */     return this.relaKpiId;
/*    */   }
/*    */ 
/*    */   public void setRelaKpiId(String relaKpiId) {
/* 47 */     this.relaKpiId = relaKpiId;
/*    */   }
/*    */ 
/*    */   public Integer getIfShow() {
/* 51 */     return this.ifShow;
/*    */   }
/*    */ 
/*    */   public void setIfShow(Integer ifShow) {
/* 55 */     this.ifShow = ifShow;
/*    */   }
/*    */ 
/*    */   public Integer getRelaKpiType() {
/* 59 */     return this.relaKpiType;
/*    */   }
/*    */ 
/*    */   public void setRelaKpiType(Integer relaKpiType) {
/* 63 */     this.relaKpiType = relaKpiType;
/*    */   }
/*    */ 
/*    */   public Integer getIfSameKind() {
/* 67 */     return this.ifSameKind;
/*    */   }
/*    */ 
/*    */   public void setIfSameKind(Integer ifSameKind) {
/* 71 */     this.ifSameKind = ifSameKind;
/*    */   }
/*    */ 
/*    */   public Integer getRelaChartType() {
/* 75 */     return this.relaChartType;
/*    */   }
/*    */ 
/*    */   public void setRelaChartType(Integer relaChartType) {
/* 79 */     this.relaChartType = relaChartType;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiRelation
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class KpiType
/*     */   implements Serializable
/*     */ {
/*     */   private String kpiTypeId;
/*     */   private String kpiTypeName;
/*     */   private String kpiTypeParentId;
/*     */   private Integer kpiTypeSource;
/*     */   private Timestamp kpiTypeDate;
/*     */   private String kpiTypeDesc;
/*     */ 
/*     */   public KpiType()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KpiType(String kpiTypeId, String kpiTypeName, Timestamp kpiTypeDate)
/*     */   {
/*  35 */     this.kpiTypeId = kpiTypeId;
/*  36 */     this.kpiTypeName = kpiTypeName;
/*  37 */     this.kpiTypeDate = kpiTypeDate;
/*     */   }
/*     */ 
/*     */   public KpiType(String kpiTypeId, String kpiTypeName, String kpiTypeParentId, Integer kpiTypeSource, Timestamp kpiTypeDate, String kpiTypeDesc)
/*     */   {
/*  43 */     this.kpiTypeId = kpiTypeId;
/*  44 */     this.kpiTypeName = kpiTypeName;
/*  45 */     this.kpiTypeParentId = kpiTypeParentId;
/*  46 */     this.kpiTypeSource = kpiTypeSource;
/*  47 */     this.kpiTypeDate = kpiTypeDate;
/*  48 */     this.kpiTypeDesc = kpiTypeDesc;
/*     */   }
/*     */ 
/*     */   public String getKpiTypeId()
/*     */   {
/*  54 */     return this.kpiTypeId;
/*     */   }
/*     */ 
/*     */   public void setKpiTypeId(String kpiTypeId) {
/*  58 */     this.kpiTypeId = kpiTypeId;
/*     */   }
/*     */ 
/*     */   public String getKpiTypeName() {
/*  62 */     return this.kpiTypeName;
/*     */   }
/*     */ 
/*     */   public void setKpiTypeName(String kpiTypeName) {
/*  66 */     this.kpiTypeName = kpiTypeName;
/*     */   }
/*     */ 
/*     */   public String getKpiTypeParentId() {
/*  70 */     return this.kpiTypeParentId;
/*     */   }
/*     */ 
/*     */   public void setKpiTypeParentId(String kpiTypeParentId) {
/*  74 */     this.kpiTypeParentId = kpiTypeParentId;
/*     */   }
/*     */ 
/*     */   public Integer getKpiTypeSource() {
/*  78 */     return this.kpiTypeSource;
/*     */   }
/*     */ 
/*     */   public void setKpiTypeSource(Integer kpiTypeSource) {
/*  82 */     this.kpiTypeSource = kpiTypeSource;
/*     */   }
/*     */ 
/*     */   public Timestamp getKpiTypeDate() {
/*  86 */     return this.kpiTypeDate;
/*     */   }
/*     */ 
/*     */   public void setKpiTypeDate(Timestamp kpiTypeDate) {
/*  90 */     this.kpiTypeDate = kpiTypeDate;
/*     */   }
/*     */ 
/*     */   public String getKpiTypeDesc() {
/*  94 */     return this.kpiTypeDesc;
/*     */   }
/*     */ 
/*     */   public void setKpiTypeDesc(String kpiTypeDesc) {
/*  98 */     this.kpiTypeDesc = kpiTypeDesc;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/* 102 */     if (this == other)
/* 103 */       return true;
/* 104 */     if (other == null)
/* 105 */       return false;
/* 106 */     if (!(other instanceof KpiType))
/* 107 */       return false;
/* 108 */     KpiType castOther = (KpiType)other;
/*     */ 
/* 110 */     return ((getKpiTypeId() == castOther.getKpiTypeId()) || ((getKpiTypeId() != null) && (castOther.getKpiTypeId() != null) && (getKpiTypeId().equals(castOther.getKpiTypeId())))) && ((getKpiTypeName() == castOther.getKpiTypeName()) || ((getKpiTypeName() != null) && (castOther.getKpiTypeName() != null) && (getKpiTypeName().equals(castOther.getKpiTypeName())))) && ((getKpiTypeParentId() == castOther.getKpiTypeParentId()) || ((getKpiTypeParentId() != null) && (castOther.getKpiTypeParentId() != null) && (getKpiTypeParentId().equals(castOther.getKpiTypeParentId())))) && ((getKpiTypeSource() == castOther.getKpiTypeSource()) || ((getKpiTypeSource() != null) && (castOther.getKpiTypeSource() != null) && (getKpiTypeSource().equals(castOther.getKpiTypeSource())))) && ((getKpiTypeDate() == castOther.getKpiTypeDate()) || ((getKpiTypeDate() != null) && (castOther.getKpiTypeDate() != null) && (getKpiTypeDate().equals(castOther.getKpiTypeDate())))) && ((getKpiTypeDesc() == castOther.getKpiTypeDesc()) || ((getKpiTypeDesc() != null) && (castOther.getKpiTypeDesc() != null) && (getKpiTypeDesc().equals(castOther.getKpiTypeDesc()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 133 */     int result = 17;
/*     */ 
/* 135 */     result = 37 * result + (getKpiTypeId() == null ? 0 : getKpiTypeId().hashCode());
/* 136 */     result = 37 * result + (getKpiTypeName() == null ? 0 : getKpiTypeName().hashCode());
/* 137 */     result = 37 * result + (getKpiTypeParentId() == null ? 0 : getKpiTypeParentId().hashCode());
/*     */ 
/* 139 */     result = 37 * result + (getKpiTypeSource() == null ? 0 : getKpiTypeSource().hashCode());
/*     */ 
/* 141 */     result = 37 * result + (getKpiTypeDate() == null ? 0 : getKpiTypeDate().hashCode());
/* 142 */     result = 37 * result + (getKpiTypeDesc() == null ? 0 : getKpiTypeDesc().hashCode());
/* 143 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiType
 * JD-Core Version:    0.6.2
 */
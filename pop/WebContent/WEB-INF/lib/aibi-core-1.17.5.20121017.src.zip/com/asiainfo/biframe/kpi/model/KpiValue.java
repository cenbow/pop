/*    */ package com.asiainfo.biframe.kpi.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class KpiValue
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -2315814831411272315L;
/* 31 */   private Map<String, List<KpiDaily>> kpiDailyMap = new HashMap();
/*    */ 
/* 34 */   private Map<String, List<KpiMonthly>> kpiMonthlyMap = new HashMap();
/*    */ 
/* 37 */   private Map<String, List<KpiYearly>> kpiYearlyMap = new HashMap();
/*    */ 
/* 40 */   private Map<String, List<KpiRealTime>> kpiRealTimeMap = new HashMap();
/*    */   private String dataTableName;
/*    */ 
/*    */   public Map<String, List<KpiRealTime>> getKpiRealTimeMap()
/*    */   {
/* 46 */     return this.kpiRealTimeMap;
/*    */   }
/*    */ 
/*    */   public void setKpiRealTimeMap(Map<String, List<KpiRealTime>> kpiRealTimeMap) {
/* 50 */     this.kpiRealTimeMap = kpiRealTimeMap;
/*    */   }
/*    */ 
/*    */   public Map<String, List<KpiDaily>> getKpiDailyMap() {
/* 54 */     return this.kpiDailyMap;
/*    */   }
/*    */ 
/*    */   public void setKpiDailyMap(Map<String, List<KpiDaily>> kpiDailyMap) {
/* 58 */     this.kpiDailyMap = kpiDailyMap;
/*    */   }
/*    */ 
/*    */   public Map<String, List<KpiMonthly>> getKpiMonthlyMap() {
/* 62 */     return this.kpiMonthlyMap;
/*    */   }
/*    */ 
/*    */   public void setKpiMonthlyMap(Map<String, List<KpiMonthly>> kpiMonthlyMap) {
/* 66 */     this.kpiMonthlyMap = kpiMonthlyMap;
/*    */   }
/*    */ 
/*    */   public Map<String, List<KpiYearly>> getKpiYearlyMap() {
/* 70 */     return this.kpiYearlyMap;
/*    */   }
/*    */ 
/*    */   public String getDataTableName() {
/* 74 */     return this.dataTableName;
/*    */   }
/*    */ 
/*    */   public void setDataTableName(String dataTableName) {
/* 78 */     this.dataTableName = dataTableName;
/*    */   }
/*    */ 
/*    */   public void setKpiYearlyMap(Map<String, List<KpiYearly>> kpiYearlyMap) {
/* 82 */     this.kpiYearlyMap = kpiYearlyMap;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiValue
 * JD-Core Version:    0.6.2
 */
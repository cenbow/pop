/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class KpiValueQryCondVO
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3149411162097038890L;
/*     */   private String kpiId;
/*     */   private String kpiName;
/*     */   private String kpiDimDataGroupId;
/*     */   private String kpiPeriodCode;
/*     */   private Map<String, String> kpiDims;
/*     */   private String statDate;
/*     */   private String columnName;
/*     */   private String isDesc;
/*     */   private boolean isContainNullValue;
/*     */   private String alertStatus;
/*     */   private String thresholdId;
/*     */ 
/*     */   public String getKpiId()
/*     */   {
/*  51 */     return this.kpiId;
/*     */   }
/*     */ 
/*     */   public void setKpiId(String kpiId) {
/*  55 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public String getKpiName() {
/*  59 */     return this.kpiName;
/*     */   }
/*     */ 
/*     */   public void setKpiName(String kpiName) {
/*  63 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getKpiDims() {
/*  67 */     return this.kpiDims;
/*     */   }
/*     */ 
/*     */   public void setKpiDims(Map<String, String> kpiDims) {
/*  71 */     this.kpiDims = kpiDims;
/*     */   }
/*     */ 
/*     */   public String getKpiPeriodCode() {
/*  75 */     return this.kpiPeriodCode;
/*     */   }
/*     */ 
/*     */   public void setKpiPeriodCode(String kpiPeriodCode) {
/*  79 */     this.kpiPeriodCode = kpiPeriodCode;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataGroupId() {
/*  83 */     return this.kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataGroupId(String kpiDimDataGroupId) {
/*  87 */     this.kpiDimDataGroupId = kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public String getStatDate() {
/*  91 */     return this.statDate;
/*     */   }
/*     */ 
/*     */   public void setStatDate(String statDate) {
/*  95 */     this.statDate = statDate;
/*     */   }
/*     */ 
/*     */   public String getColumnName() {
/*  99 */     return this.columnName;
/*     */   }
/*     */ 
/*     */   public void setColumnName(String columnName) {
/* 103 */     this.columnName = columnName;
/*     */   }
/*     */ 
/*     */   public String getIsDesc() {
/* 107 */     return this.isDesc;
/*     */   }
/*     */ 
/*     */   public void setIsDesc(String isDesc) {
/* 111 */     this.isDesc = isDesc;
/*     */   }
/*     */ 
/*     */   public String getAlertStatus() {
/* 115 */     return this.alertStatus;
/*     */   }
/*     */ 
/*     */   public void setAlertStatus(String alertStatus) {
/* 119 */     this.alertStatus = alertStatus;
/*     */   }
/*     */ 
/*     */   public void setThresholdId(String thresholdId) {
/* 123 */     this.thresholdId = thresholdId;
/*     */   }
/*     */ 
/*     */   public String getThresholdId() {
/* 127 */     return this.thresholdId;
/*     */   }
/*     */ 
/*     */   public boolean isContainNullValue()
/*     */   {
/* 132 */     return this.isContainNullValue;
/*     */   }
/*     */ 
/*     */   public void setContainNullValue(boolean isContainNullValue)
/*     */   {
/* 137 */     this.isContainNullValue = isContainNullValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiValueQryCondVO
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.kpi.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.List;
/*     */ 
/*     */ public class KpiYearly
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String yearlyId;
/*     */   private String kpiId;
/*     */   private String kpiName;
/*     */   private String kpiDimDataGroupId;
/*     */   private Timestamp yearlyStartDate;
/*     */   private double yearlyValue;
/*     */   private double yearlyLastValue;
/*     */   private double yearlyLastTrend;
/*     */   private Integer yearlyAreaOrder;
/*     */   private double yearlyAreaOccupancy;
/*     */   private double yearlyAreaAvg;
/*     */   private double yearlyMission;
/*     */   private double yearlyPercent;
/*     */   private Integer yearlyAlertStatus;
/*     */   private Integer yearlyBranchOrder;
/*     */   private double yearlyLastTrendValue;
/*     */   private List<KpiDimDataGroup> dimDataGroupVO;
/*     */ 
/*     */   public Integer getYearlyBranchOrder()
/*     */   {
/*  46 */     return this.yearlyBranchOrder;
/*     */   }
/*     */ 
/*     */   public void setYearlyBranchOrder(Integer yearlyBranchOrder)
/*     */   {
/*  51 */     this.yearlyBranchOrder = yearlyBranchOrder;
/*     */   }
/*     */ 
/*     */   public double getYearlyLastTrendValue()
/*     */   {
/*  56 */     return this.yearlyLastTrendValue;
/*     */   }
/*     */ 
/*     */   public void setYearlyLastTrendValue(double yearlyLastTrendValue)
/*     */   {
/*  61 */     this.yearlyLastTrendValue = yearlyLastTrendValue;
/*     */   }
/*     */ 
/*     */   public List<KpiDimDataGroup> getDimDataGroupVO() {
/*  65 */     return this.dimDataGroupVO;
/*     */   }
/*     */ 
/*     */   public void setDimDataGroupVO(List<KpiDimDataGroup> dimDataGroupVO) {
/*  69 */     this.dimDataGroupVO = dimDataGroupVO;
/*     */   }
/*     */ 
/*     */   public String getYearlyId() {
/*  73 */     return this.yearlyId;
/*     */   }
/*     */ 
/*     */   public void setYearlyId(String yearlyId) {
/*  77 */     this.yearlyId = yearlyId;
/*     */   }
/*     */ 
/*     */   public String getKpiId() {
/*  81 */     return this.kpiId;
/*     */   }
/*     */ 
/*     */   public void setKpiId(String kpiId) {
/*  85 */     this.kpiId = kpiId;
/*     */   }
/*     */ 
/*     */   public String getKpiName() {
/*  89 */     return this.kpiName;
/*     */   }
/*     */ 
/*     */   public void setKpiName(String kpiName) {
/*  93 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public String getKpiDimDataGroupId() {
/*  97 */     return this.kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public void setKpiDimDataGroupId(String kpiDimDataGroupId) {
/* 101 */     this.kpiDimDataGroupId = kpiDimDataGroupId;
/*     */   }
/*     */ 
/*     */   public Timestamp getYearlyStartDate() {
/* 105 */     return this.yearlyStartDate;
/*     */   }
/*     */ 
/*     */   public void setYearlyStartDate(Timestamp yearlyStartDate) {
/* 109 */     this.yearlyStartDate = yearlyStartDate;
/*     */   }
/*     */ 
/*     */   public double getYearlyValue() {
/* 113 */     return this.yearlyValue;
/*     */   }
/*     */ 
/*     */   public void setYearlyValue(double yearlyValue) {
/* 117 */     this.yearlyValue = yearlyValue;
/*     */   }
/*     */ 
/*     */   public double getYearlyLastValue() {
/* 121 */     return this.yearlyLastValue;
/*     */   }
/*     */ 
/*     */   public void setYearlyLastValue(double yearlyLastValue) {
/* 125 */     this.yearlyLastValue = yearlyLastValue;
/*     */   }
/*     */ 
/*     */   public double getYearlyLastTrend() {
/* 129 */     return this.yearlyLastTrend;
/*     */   }
/*     */ 
/*     */   public void setYearlyLastTrend(double yearlyLastTrend) {
/* 133 */     this.yearlyLastTrend = yearlyLastTrend;
/*     */   }
/*     */ 
/*     */   public Integer getYearlyAreaOrder() {
/* 137 */     return this.yearlyAreaOrder;
/*     */   }
/*     */ 
/*     */   public void setYearlyAreaOrder(Integer yearlyAreaOrder) {
/* 141 */     this.yearlyAreaOrder = yearlyAreaOrder;
/*     */   }
/*     */ 
/*     */   public double getYearlyAreaOccupancy() {
/* 145 */     return this.yearlyAreaOccupancy;
/*     */   }
/*     */ 
/*     */   public void setYearlyAreaOccupancy(double yearlyAreaOccupancy) {
/* 149 */     this.yearlyAreaOccupancy = yearlyAreaOccupancy;
/*     */   }
/*     */ 
/*     */   public double getYearlyAreaAvg() {
/* 153 */     return this.yearlyAreaAvg;
/*     */   }
/*     */ 
/*     */   public void setYearlyAreaAvg(double yearlyAreaAvg) {
/* 157 */     this.yearlyAreaAvg = yearlyAreaAvg;
/*     */   }
/*     */ 
/*     */   public double getYearlyMission() {
/* 161 */     return this.yearlyMission;
/*     */   }
/*     */ 
/*     */   public void setYearlyMission(double yearlyMission) {
/* 165 */     this.yearlyMission = yearlyMission;
/*     */   }
/*     */ 
/*     */   public double getYearlyPercent() {
/* 169 */     return this.yearlyPercent;
/*     */   }
/*     */ 
/*     */   public void setYearlyPercent(double yearlyPercent) {
/* 173 */     this.yearlyPercent = yearlyPercent;
/*     */   }
/*     */ 
/*     */   public Integer getYearlyAlertStatus() {
/* 177 */     return this.yearlyAlertStatus;
/*     */   }
/*     */ 
/*     */   public void setYearlyAlertStatus(Integer yearlyAlertStatus) {
/* 181 */     this.yearlyAlertStatus = yearlyAlertStatus;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.KpiYearly
 * JD-Core Version:    0.6.2
 */
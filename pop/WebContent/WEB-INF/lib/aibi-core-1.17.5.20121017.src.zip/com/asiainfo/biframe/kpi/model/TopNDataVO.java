/*    */ package com.asiainfo.biframe.kpi.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class TopNDataVO
/*    */   implements Serializable
/*    */ {
/*    */   private String id;
/*    */   private String rownum;
/*    */   private String kpiName;
/*    */   private String kpiTip;
/*    */   private String kpiValue;
/*    */   private String kpiValueClass;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 29 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 32 */     this.id = id;
/*    */   }
/*    */   public String getKpiName() {
/* 35 */     return this.kpiName;
/*    */   }
/*    */   public void setKpiName(String kpiName) {
/* 38 */     this.kpiName = kpiName;
/*    */   }
/*    */   public String getKpiTip() {
/* 41 */     return this.kpiTip;
/*    */   }
/*    */   public void setKpiTip(String kpiTip) {
/* 44 */     this.kpiTip = kpiTip;
/*    */   }
/*    */   public String getKpiValue() {
/* 47 */     return this.kpiValue;
/*    */   }
/*    */   public void setKpiValue(String kpiValue) {
/* 50 */     this.kpiValue = kpiValue;
/*    */   }
/*    */   public String getRownum() {
/* 53 */     return this.rownum;
/*    */   }
/*    */   public void setRownum(String rownum) {
/* 56 */     this.rownum = rownum;
/*    */   }
/*    */   public String getKpiValueClass() {
/* 59 */     return this.kpiValueClass;
/*    */   }
/*    */   public void setKpiValueClass(String kpiValueClass) {
/* 62 */     this.kpiValueClass = kpiValueClass;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.model.TopNDataVO
 * JD-Core Version:    0.6.2
 */
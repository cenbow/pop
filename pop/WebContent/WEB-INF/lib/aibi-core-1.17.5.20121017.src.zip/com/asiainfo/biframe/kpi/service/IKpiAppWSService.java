package com.asiainfo.biframe.kpi.service;

import com.asiainfo.biframe.kpi.model.KpiAlarmDataVO;
import com.asiainfo.biframe.kpi.model.KpiAlarmRecordData;
import com.asiainfo.biframe.kpi.model.KpiAttention;
import com.asiainfo.biframe.kpi.model.KpiDefine;
import com.asiainfo.biframe.kpi.model.KpiDim;
import com.asiainfo.biframe.kpi.model.KpiDimData;
import com.asiainfo.biframe.kpi.model.KpiDimDataGroup;
import com.asiainfo.biframe.kpi.model.KpiExtendValue;
import com.asiainfo.biframe.kpi.model.KpiKpiRelation;
import com.asiainfo.biframe.kpi.model.KpiPeriod;
import com.asiainfo.biframe.kpi.model.KpiPeriodColumn;
import com.asiainfo.biframe.kpi.model.KpiRelation;
import com.asiainfo.biframe.kpi.model.KpiType;
import com.asiainfo.biframe.kpi.model.KpiValue;
import com.asiainfo.biframe.kpi.model.KpiValueQryCondVO;
import java.util.List;
import java.util.Map;
import javax.jws.WebService;

@WebService
public abstract interface IKpiAppWSService
{
  public abstract String saveKpiRelationList(List<KpiRelation> paramList)
    throws Exception;

  public abstract String deleteKpiRelationList(List<KpiRelation> paramList)
    throws Exception;

  public abstract List<KpiKpiRelation> queryKpiRelationListByRela(String paramString1, String paramString2, KpiRelation paramKpiRelation)
    throws Exception;

  public abstract String deleteKpiProductRelation(String paramString, List<String> paramList);

  public abstract String saveKpiAttentionList(List<KpiAttention> paramList);

  public abstract KpiPeriod getKpiPeriodInfo(String paramString);

  public abstract List<KpiPeriod> getKpiPeriodList();

  public abstract List<KpiPeriodColumn> getKpiPeriodColumnList(String paramString);

  public abstract List<KpiPeriodColumn> getKpiPeriodColumnListByKpiID(String paramString);

  public abstract List<KpiDim> getAllKpiDimList(String paramString);

  public abstract List<String> getDimIdByKpiId(String paramString1, String paramString2)
    throws Exception;

  public abstract List<KpiDim> getKpiDimList(List<String> paramList);

  public abstract List<KpiDimData> getKpiDimDataList(KpiDimData paramKpiDimData, String paramString);

  public abstract int saveOrUpdateKpiDimDataList(List<KpiDimData> paramList)
    throws Exception;

  public abstract int deleteKpiDimDataList(List<KpiDimData> paramList)
    throws Exception;

  public abstract List<KpiDimData> getKpiDimData(String paramString1, String paramString2);

  public abstract List<KpiDimData> getKpiDimDataAll(String paramString);

  public abstract List<KpiDimData> getKpiDimDataByParent(String paramString1, String paramString2, String paramString3);

  public abstract List<KpiDimDataGroup> getKpiDimDataGroupListByGroupId(String paramString)
    throws Exception;

  public abstract String getGroupIdByKpiId(String paramString1, String paramString2, Map<String, String> paramMap)
    throws Exception;

  public abstract List<KpiType> getAllKpiTypes();

  public abstract List<KpiType> getKpiTypeListByParent(String paramString);

  public abstract KpiType getKpiTypeById(String paramString1, String paramString2);

  public abstract List<KpiDefine> getKpiDefineList(String paramString1, String paramString2, String paramString3);

  public abstract List<KpiDefine> getKpiDefineListByIDs(List<String> paramList, String paramString1, String paramString2);

  public abstract KpiDefine findByKpiIdExtend(String paramString1, String paramString2);

  public abstract List<KpiDefine> getKpiDefineListByIDsAll(List<String> paramList, String paramString);

  public abstract List<KpiExtendValue> queryKpiExtendValueAllList(KpiExtendValue paramKpiExtendValue, String paramString);

  public abstract List<KpiDefine> getAllKpiDefineList(String paramString1, String paramString2, String paramString3);

  public abstract List<KpiDefine> getKpiDefineListByCond(String paramString1, KpiDefine paramKpiDefine, List<String> paramList, String paramString2);

  public abstract List<KpiDefine> filterKpiByRight(List<KpiDefine> paramList, String paramString)
    throws Exception;

  @Deprecated
  public abstract KpiValue getPagedKpiValueByDim(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2);

  @Deprecated
  public abstract KpiValue getKpiValueByDim(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3);

  @Deprecated
  public abstract KpiValue getPagedSubKpiValueByDim(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2);

  @Deprecated
  public abstract KpiValue getSubKpiValueByDim(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;

  @Deprecated
  public abstract String getKpiMaxAndMinDate(Map<String, Map> paramMap, String paramString);

  @Deprecated
  public abstract Map<String, String> getKpiValueByColumn(Map<String, KpiValueQryCondVO> paramMap);

  @Deprecated
  public abstract KpiValue getPagedKpiValue(String paramString1, Map<String, String> paramMap, String paramString2, int paramInt1, int paramInt2);

  @Deprecated
  public abstract List<KpiAlarmDataVO> queryKpiAlarmList(String paramString1, Map<String, String> paramMap, String paramString2, String paramString3, int paramInt1, int paramInt2, String paramString4, String paramString5);

  public abstract List<Map<String, KpiDimDataGroup>> getKpiDimDataGroupByDimDatas(String paramString1, String paramString2, Map<String, String> paramMap)
    throws Exception;

  public abstract List<Map<String, Object>> queryKpiAlarmByKpiIdList(List<Map<String, String>> paramList, String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract List<Map<String, Object>> queryKpiAlarmByKpiInfoPageList(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2)
    throws Exception;

  public abstract List<Map<String, Object>> queryKpiAttentionByKpiInfoList(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract List<KpiAlarmRecordData> queryKpiAlarmRecordList(Map<String, String> paramMap, String paramString1, boolean paramBoolean, String paramString2, String paramString3, String paramString4)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.service.IKpiAppWSService
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.kpi.service;

import java.util.List;
import java.util.Map;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public abstract interface IKpiForAppWsService
{
  public abstract String getTableMaxTimeInfo(Map<String, String> paramMap, String paramString, int paramInt)
    throws Exception;

  public abstract List<Map<String, String>> getTableDescInfo(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, String paramString4, boolean paramBoolean2, String paramString5)
    throws Exception;

  @WebMethod(operationName="getTableDescInfoByKpiId")
  public abstract List<Map<String, String>> getTableDescInfo(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean1, String paramString6, boolean paramBoolean2, String paramString7)
    throws Exception;

  public abstract List<Map<String, String>> getTableDescInfoCollect(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, String paramString4, boolean paramBoolean2, String paramString5)
    throws Exception;

  public abstract String getDimDataGroupInfo(Map<String, String> paramMap)
    throws Exception;

  public abstract List<Map<String, String>> getDimDataGroupList(Map<String, String> paramMap, String paramString1, boolean paramBoolean, String paramString2)
    throws Exception;

  public abstract List<Map<String, String>> getDimDataPackageList(Map<String, String> paramMap1, String paramString1, Map<String, String> paramMap2, boolean paramBoolean, String paramString2)
    throws Exception;

  @WebMethod(operationName="getDimDataPackageListByKpiId")
  public abstract List<Map<String, String>> getDimDataPackageList(String paramString1, String paramString2, Map<String, String> paramMap1, String paramString3, Map<String, String> paramMap2, boolean paramBoolean, String paramString4)
    throws Exception;

  @WebMethod(operationName="queryKpiAttentionDataListOrder")
  public abstract List<Map<String, String>> queryKpiAttentionDataList(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, String paramString4, Map<String, String> paramMap2, Map<String, String> paramMap3, String paramString5, String paramString6)
    throws Exception;

  @WebMethod(operationName="queryKpiAttentionDataList")
  public abstract List<Map<String, String>> queryKpiAttentionDataList(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, String paramString4, Map<String, String> paramMap2, Map<String, String> paramMap3)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiAnalysisDataList(Map<String, String> paramMap1, String paramString1, boolean paramBoolean, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, Map<String, String> paramMap2, Map<String, String> paramMap3)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiAnalysisUnitDataList(Map<String, String> paramMap1, String paramString1, boolean paramBoolean, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, Map<String, String> paramMap2, Map<String, String> paramMap3, String paramString7)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiAnalysisDataListCollect(Map<String, String> paramMap1, String paramString1, boolean paramBoolean, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, Map<String, String> paramMap2, Map<String, String> paramMap3)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiAnalysisDataListUnSuffix(Map<String, String> paramMap1, String paramString1, boolean paramBoolean, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, Map<String, String> paramMap2, Map<String, String> paramMap3)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiTrendGraphDataList(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, int paramInt, String paramString4, String paramString5, boolean paramBoolean2, String paramString6, Map<String, String> paramMap2)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiTrendGraphUnitDataList(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, int paramInt, String paramString4, String paramString5, boolean paramBoolean2, String paramString6, Map<String, String> paramMap2, String paramString7)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiTrendGraphDataListCollect(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, int paramInt, String paramString4, String paramString5, boolean paramBoolean2, String paramString6, String paramString7, Map<String, String> paramMap2)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiTrendGridDataList(Map<String, String> paramMap, String paramString1, boolean paramBoolean, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws Exception;

  @WebMethod(operationName="queryKpiOverviewDataList")
  public abstract List<Map<String, String>> queryKpiOverviewDataList(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, Map<String, String> paramMap2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
    throws Exception;

  @WebMethod(operationName="queryKpiOverviewDataListOrder")
  public abstract List<Map<String, String>> queryKpiOverviewDataList(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, Map<String, String> paramMap2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString7)
    throws Exception;

  @WebMethod(operationName="queryKpiOverviewDataListForMat")
  public abstract List<Map<String, String>> queryKpiOverviewDataList(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, Map<String, String> paramMap2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString7, boolean paramBoolean4)
    throws Exception;

  @WebMethod(operationName="queryKpiOverviewDataPackageList")
  public abstract List<Map<String, String>> queryKpiOverviewDataPackageList(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Map<String, String> paramMap2, Map<String, String> paramMap3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
    throws Exception;

  @WebMethod(operationName="queryKpiOverviewDataPackageListFormat")
  public abstract List<Map<String, String>> queryKpiOverviewDataPackageList(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Map<String, String> paramMap2, Map<String, String> paramMap3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiDataListByMoreCondition(Map<String, String> paramMap1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean1, String paramString6, Map<String, String> paramMap2, String paramString7, String paramString8, boolean paramBoolean2)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiTimeContrastGraphDataList(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws Exception;

  public abstract List<Map<String, String>> queryKpiTimeContrastGridDataList(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws Exception;

  public abstract List<Map<String, String>> getDateDiffDesc(String paramString1, String paramString2, String paramString3, Map<String, String> paramMap)
    throws Exception;

  public abstract List<String> queryKpiIdsByAttention(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract List<String> getKpiIdsByTypeId(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract String getKpiTypesByTypeId(String paramString1, String paramString2)
    throws Exception;

  public abstract void progressRate(String paramString1, String paramString2, List<Map<String, String>> paramList)
    throws Exception;

  @WebMethod
  public abstract List<Map<String, String>> queryKpiDataByGroupList(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Map<String, String> paramMap, String paramString6)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.kpi.service.IKpiForAppWsService
 * JD-Core Version:    0.6.2
 */
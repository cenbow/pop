package com.asiainfo.biframe.log;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

public abstract interface ILogService
{
  @Deprecated
  public abstract void log(LogInfo paramLogInfo)
    throws Exception;

  @Deprecated
  public abstract void log(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Map<String, Map<String, String>> paramMap1, Map<String, Map<String, String>> paramMap2);

  @Deprecated
  public abstract void log(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, Map<String, Map<String, String>> paramMap1, Map<String, Map<String, String>> paramMap2);

  public abstract void log(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Map<String, Map<String, String>> paramMap1, Map<String, Map<String, String>> paramMap2, OperResultEnum paramOperResultEnum, LogLevelEnum paramLogLevelEnum);

  public abstract void log(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, Map<String, Map<String, String>> paramMap1, Map<String, Map<String, String>> paramMap2, OperResultEnum paramOperResultEnum, LogLevelEnum paramLogLevelEnum);

  public abstract void logBankFor4A(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, Map<String, Map<String, String>> paramMap1, Map<String, Map<String, String>> paramMap2, OperResultEnum paramOperResultEnum, LogLevelEnum paramLogLevelEnum, String paramString11, String paramString12);

  public abstract String getLogDefineValue(int paramInt, String paramString);

  public abstract List getFuncHitrateRank(int paramInt);

  public abstract String logESB(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Timestamp paramTimestamp1, String paramString6, Timestamp paramTimestamp2, String paramString7, long paramLong1, long paramLong2);

  public abstract void logESBUpdate(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, Timestamp paramTimestamp1, String paramString7, Timestamp paramTimestamp2, String paramString8, long paramLong1, long paramLong2);

  public abstract List<Map> getRelatedRecommendByResourceIdAndUserId(int paramInt, String paramString1, String paramString2);

  public abstract List<IUserOperLog> getOperatorLogList(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7);

  public abstract List<IUserOperLog> getOperatorLogList(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6);

  public abstract void deleteOperatorLog(String paramString);

  public abstract void deleteOperatorLog(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract String getLastLoginTime(String paramString);

  public abstract void logHit(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract void logESB(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Timestamp paramTimestamp1, String paramString6, Timestamp paramTimestamp2, String paramString7, long paramLong1, long paramLong2, long paramLong3, long paramLong4, String paramString8, String paramString9, String paramString10, String paramString11);

  public abstract void log(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, Map<String, Map<String, String>> paramMap1, Map<String, Map<String, String>> paramMap2, OperResultEnum paramOperResultEnum, LogLevelEnum paramLogLevelEnum, String paramString11);

  public abstract void logHit(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6);

  public abstract void log(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, Map<String, Map<String, String>> paramMap1, Map<String, Map<String, String>> paramMap2, OperResultEnum paramOperResultEnum, LogLevelEnum paramLogLevelEnum, String paramString9);

  public abstract void logBankFor4A(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, Map<String, Map<String, String>> paramMap1, Map<String, Map<String, String>> paramMap2, OperResultEnum paramOperResultEnum, LogLevelEnum paramLogLevelEnum, String paramString11, String paramString12, String paramString13);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.log.ILogService
 * JD-Core Version:    0.6.2
 */
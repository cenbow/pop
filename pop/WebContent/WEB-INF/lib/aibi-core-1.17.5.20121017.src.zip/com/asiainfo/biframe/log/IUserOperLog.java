package com.asiainfo.biframe.log;

import java.util.Date;

public abstract interface IUserOperLog
{
  public abstract OperResultEnum getOperResult();

  public abstract LogLevelEnum getLogLevel();

  public abstract String getLogId();

  public abstract String getSessionId();

  public abstract String getOperatorId();

  public abstract String getOperatorName();

  public abstract String getHostAddress();

  public abstract String getClientAddress();

  public abstract Date getOperateDate();

  public abstract Integer getResourceType();

  public abstract Integer getOperaterType();

  public abstract String getResourceId();

  public abstract String getResourceName();

  public abstract String getMsg();

  public abstract String getOperateDateStr();

  public abstract String getDepartmentName();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.log.IUserOperLog
 * JD-Core Version:    0.6.2
 */
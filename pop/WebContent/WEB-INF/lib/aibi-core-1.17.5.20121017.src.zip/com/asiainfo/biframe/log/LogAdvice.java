/*    */ package com.asiainfo.biframe.log;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class LogAdvice
/*    */   implements MethodInterceptor
/*    */ {
/* 24 */   private static Logger log = Logger.getLogger(LogAdvice.class);
/*    */ 
/*    */   public Object invoke(MethodInvocation invocation) throws Throwable {
/* 27 */     StringBuffer sb = new StringBuffer();
/* 28 */     sb.append("\n ====================方法执行信息========================：");
/* 29 */     sb.append("\n 执行方法：" + invocation.getMethod().toString());
/* 30 */     Object[] args = invocation.getArguments();
/* 31 */     sb.append("\n 参数 (类型 ：值)");
/* 32 */     for (Object arg : args) {
/* 33 */       sb.append(";    " + arg.getClass().getName() + ": " + arg);
/*    */     }
/* 35 */     long start = System.currentTimeMillis();
/* 36 */     Object result = invocation.proceed();
/* 37 */     long end = System.currentTimeMillis();
/* 38 */     sb.append("\n 执行时长(毫秒)：" + (end - start));
/* 39 */     sb.append("\n 返回值：" + result);
/* 40 */     log.debug(sb.toString());
/* 41 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.log.LogAdvice
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.log;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class LogInfo
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  21 */   private static ThreadLocal<String> sessionID = new ThreadLocal();
/*     */ 
/*  23 */   private static ThreadLocal<String> hostAddress = new ThreadLocal();
/*     */ 
/*  25 */   private static ThreadLocal<String> clientAddress = new ThreadLocal();
/*     */ 
/*  27 */   private static ThreadLocal<String> operatorID = new ThreadLocal();
/*     */ 
/*  29 */   private static ThreadLocal<String> operatorName = new ThreadLocal();
/*     */ 
/*  32 */   private String operaterType = "0";
/*     */ 
/*  35 */   private String resourceType = "0";
/*     */ 
/*  37 */   private String resourceID = "";
/*     */ 
/*  39 */   private String resourceName = "";
/*     */ 
/*  42 */   private String msg = "";
/*     */ 
/*  45 */   private List sqlList = new ArrayList();
/*     */ 
/*  49 */   private Map oldMap = new HashMap();
/*     */ 
/*  52 */   private Map newMap = new HashMap();
/*     */   private static Map sessionInfoMap;
/*     */   private OperResultEnum operResult;
/*     */   private LogLevelEnum logLevel;
/*     */ 
/*     */   public OperResultEnum getOperResult()
/*     */   {
/*  67 */     return this.operResult;
/*     */   }
/*     */ 
/*     */   public void setOperResult(OperResultEnum operResult) {
/*  71 */     this.operResult = operResult;
/*     */   }
/*     */ 
/*     */   public LogLevelEnum getLogLevel() {
/*  75 */     return this.logLevel;
/*     */   }
/*     */ 
/*     */   public void setLogLevel(LogLevelEnum logLevel) {
/*  79 */     this.logLevel = logLevel;
/*     */   }
/*     */ 
/*     */   public static void setSessionInfoMap(Map map)
/*     */   {
/*  90 */     sessionInfoMap = map;
/*     */   }
/*     */ 
/*     */   public static String getClientAddress()
/*     */   {
/*  99 */     return (String)clientAddress.get();
/*     */   }
/*     */ 
/*     */   public static void setClientAddress(String clientAddressPara)
/*     */   {
/* 109 */     clientAddress.set(clientAddressPara);
/*     */   }
/*     */ 
/*     */   public static String getHostAddress()
/*     */   {
/* 118 */     return (String)hostAddress.get();
/*     */   }
/*     */ 
/*     */   public static void setHostAddress(String hostAddressPara)
/*     */   {
/* 128 */     hostAddress.set(hostAddressPara);
/*     */   }
/*     */ 
/*     */   public String getMsg()
/*     */   {
/* 137 */     return this.msg;
/*     */   }
/*     */ 
/*     */   public void setMsg(String msg)
/*     */   {
/* 147 */     this.msg = msg;
/*     */   }
/*     */ 
/*     */   public String getOperaterType()
/*     */   {
/* 156 */     return this.operaterType;
/*     */   }
/*     */ 
/*     */   public void setOperaterType(String operaterType)
/*     */   {
/* 166 */     this.operaterType = operaterType;
/*     */   }
/*     */ 
/*     */   public static String getOperatorID()
/*     */   {
/* 175 */     return (String)operatorID.get();
/*     */   }
/*     */ 
/*     */   public static void setOperatorID(String operatorIdPara)
/*     */   {
/* 185 */     operatorID.set(operatorIdPara);
/*     */   }
/*     */ 
/*     */   public static String getOperatorName()
/*     */   {
/* 194 */     return (String)operatorName.get();
/*     */   }
/*     */ 
/*     */   public static void setOperatorName(String operatorNamePara)
/*     */   {
/* 204 */     operatorName.set(operatorNamePara);
/*     */   }
/*     */ 
/*     */   public String getResourceID()
/*     */   {
/* 213 */     return this.resourceID;
/*     */   }
/*     */ 
/*     */   public void setResourceID(String resourceID)
/*     */   {
/* 223 */     this.resourceID = resourceID;
/*     */   }
/*     */ 
/*     */   public String getResourceName()
/*     */   {
/* 232 */     return this.resourceName;
/*     */   }
/*     */ 
/*     */   public void setResourceName(String resourceName)
/*     */   {
/* 242 */     this.resourceName = resourceName;
/*     */   }
/*     */ 
/*     */   public String getResourceType()
/*     */   {
/* 251 */     return this.resourceType;
/*     */   }
/*     */ 
/*     */   public void setResourceType(String resourceType)
/*     */   {
/* 261 */     this.resourceType = resourceType;
/*     */   }
/*     */ 
/*     */   public static String getSessionID()
/*     */   {
/* 270 */     return (String)sessionID.get();
/*     */   }
/*     */ 
/*     */   public static void setSessionID(String sessionIdPara)
/*     */   {
/* 280 */     sessionID.set(sessionIdPara);
/*     */   }
/*     */ 
/*     */   public List getSqlList()
/*     */   {
/* 289 */     return this.sqlList;
/*     */   }
/*     */ 
/*     */   public void setSqlList(List sqlList)
/*     */   {
/* 299 */     this.sqlList = sqlList;
/*     */   }
/*     */ 
/*     */   public Map getNewMap()
/*     */   {
/* 308 */     return this.newMap;
/*     */   }
/*     */ 
/*     */   public void setNewMap(Map newMap)
/*     */   {
/* 317 */     this.newMap = newMap;
/*     */   }
/*     */ 
/*     */   public Map getOldMap()
/*     */   {
/* 326 */     return this.oldMap;
/*     */   }
/*     */ 
/*     */   public void setOldMap(Map oldMap)
/*     */   {
/* 335 */     this.oldMap = oldMap;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.log.LogInfo
 * JD-Core Version:    0.6.2
 */
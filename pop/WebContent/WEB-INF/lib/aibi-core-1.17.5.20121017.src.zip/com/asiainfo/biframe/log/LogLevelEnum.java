/*    */ package com.asiainfo.biframe.log;
/*    */ 
/*    */ public enum LogLevelEnum
/*    */ {
/* 13 */   Normal("01"), Importance("02"), Risk("03"), Unknown("-1");
/*    */ 
/*    */   private String value;
/*    */ 
/*    */   public String getValue() {
/* 18 */     return this.value;
/*    */   }
/*    */ 
/*    */   private LogLevelEnum(String value) {
/* 22 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public static LogLevelEnum fromValue(String value) {
/* 26 */     if (value.equals(Normal.getValue())) {
/* 27 */       return Normal;
/*    */     }
/* 29 */     if (value.equals(Importance.getValue())) {
/* 30 */       return Importance;
/*    */     }
/* 32 */     if (value.equals(Risk.getValue())) {
/* 33 */       return Risk;
/*    */     }
/* 35 */     return Unknown;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.log.LogLevelEnum
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.log;
/*    */ 
/*    */ public enum OperResultEnum
/*    */ {
/* 12 */   Success("00"), Failure("01"), Unknown("-1");
/*    */ 
/*    */   private String value;
/*    */ 
/*    */   public String getValue() {
/* 17 */     return this.value;
/*    */   }
/*    */ 
/*    */   private OperResultEnum(String value) {
/* 21 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public static OperResultEnum fromValue(String value) {
/* 25 */     if (value.equals(Success.getValue())) {
/* 26 */       return Success;
/*    */     }
/* 28 */     if (value.equals(Failure.getValue())) {
/* 29 */       return Failure;
/*    */     }
/* 31 */     return Unknown;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.log.OperResultEnum
 * JD-Core Version:    0.6.2
 */
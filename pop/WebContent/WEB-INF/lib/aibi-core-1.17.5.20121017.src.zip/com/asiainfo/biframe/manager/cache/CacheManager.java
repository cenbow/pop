/*    */ package com.asiainfo.biframe.manager.cache;
/*    */ 
/*    */ import com.asiainfo.biframe.common.cache.CacheBase;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class CacheManager
/*    */ {
/*    */   private Map<String, CacheBase> sysCacheContainer;
/*    */   private static CacheManager instance;
/*    */ 
/*    */   private CacheManager()
/*    */   {
/* 23 */     this.sysCacheContainer = new HashMap();
/*    */   }
/*    */ 
/*    */   public static CacheManager getInstance()
/*    */   {
/* 32 */     if (instance == null) {
/* 33 */       instance = new CacheManager();
/*    */     }
/* 35 */     return instance;
/*    */   }
/*    */ 
/*    */   public Map<String, CacheBase> getAllCache()
/*    */   {
/* 44 */     return this.sysCacheContainer;
/*    */   }
/*    */ 
/*    */   public String getNameById(String cacheKey, Object objId)
/*    */   {
/* 55 */     String res = "";
/* 56 */     if (this.sysCacheContainer.containsKey(cacheKey)) {
/* 57 */       CacheBase cache = (CacheBase)this.sysCacheContainer.get(cacheKey);
/* 58 */       res = cache.getNameByKey(objId);
/*    */     }
/* 60 */     return res;
/*    */   }
/*    */ 
/*    */   public void registerCache(String cacheKey, CacheBase cache)
/*    */   {
/* 72 */     this.sysCacheContainer.put(cacheKey, cache);
/*    */   }
/*    */ 
/*    */   public void removeCache(String cacheKey)
/*    */   {
/* 81 */     this.sysCacheContainer.remove(cacheKey);
/*    */   }
/*    */ 
/*    */   public CacheBase getCache(String cacheKey)
/*    */   {
/* 91 */     return (CacheBase)this.sysCacheContainer.get(cacheKey);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.cache.CacheManager
 * JD-Core Version:    0.6.2
 */
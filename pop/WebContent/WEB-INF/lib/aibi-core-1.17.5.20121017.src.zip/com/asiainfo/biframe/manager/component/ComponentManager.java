/*     */ package com.asiainfo.biframe.manager.component;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.ComponentException;
/*     */ import com.asiainfo.biframe.manager.context.ContextManager;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ComponentManager
/*     */ {
/*  38 */   private static Log log = LogFactory.getLog(ComponentManager.class);
/*     */   private Map<String, ComponentManifest> componentMfMap;
/*  42 */   private static ComponentManager manager = new ComponentManager();
/*     */ 
/*  44 */   private static int VersionDigit = 2;
/*     */ 
/*     */   public ComponentManager()
/*     */   {
/*  40 */     this.componentMfMap = new HashMap();
/*     */   }
/*     */ 
/*     */   public static ComponentManager getInstance()
/*     */   {
/*  52 */     return manager;
/*     */   }
/*     */ 
/*     */   public ComponentManifest getComponentManifest(String bundleName)
/*     */   {
/*  73 */     return (ComponentManifest)this.componentMfMap.get(bundleName);
/*     */   }
/*     */ 
/*     */   public Map<String, ComponentManifest> getAllComponentMF()
/*     */   {
/*  82 */     return this.componentMfMap;
/*     */   }
/*     */ 
/*     */   public void getMetaInfFromComponentJar(String baseComponentJarPath)
/*     */     throws ComponentException
/*     */   {
/*     */     try
/*     */     {
/*  94 */       File pathFile = new File(baseComponentJarPath);
/*  95 */       if (!pathFile.exists()) {
/*  96 */         throw new FileNotFoundException(baseComponentJarPath + " is not exist.");
/*     */       }
/*     */ 
/* 100 */       File[] componentJarFileArr = pathFile.listFiles(new ComponentJarFilenameFilter());
/*     */ 
/* 107 */       for (File tmpFile : componentJarFileArr) {
/* 108 */         JarFile componentJarFile = new JarFile(tmpFile);
/* 109 */         Manifest componentMf = componentJarFile.getManifest();
/* 110 */         Attributes attributes = componentMf.getMainAttributes();
/* 111 */         ComponentManifest componentManifest = genManifestFromAttributes(attributes);
/* 112 */         if ((componentManifest.getBundleName() != null) && (componentManifest.getBundleName().trim().length() >= 1))
/*     */         {
/* 116 */           log.info("Detecting Component : " + componentManifest.getBundleName() + "[" + componentManifest.getBundleVersion() + "]");
/*     */ 
/* 119 */           this.componentMfMap.put(componentManifest.getBundleName(), componentManifest);
/*     */         }
/*     */       }
/*     */     } catch (IOException ie) {
/* 123 */       log.error("", ie);
/* 124 */       throw new ComponentException("Read Jar file or MANIFEST.MF file error.");
/*     */     }
/*     */     catch (Exception e) {
/* 127 */       log.error("", e);
/* 128 */       throw new ComponentException("Occur unkown error when reading metainfo of aibi components.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void validateComponents()
/*     */     throws ComponentException
/*     */   {
/* 139 */     String bundleName = "";
/*     */     try {
/* 141 */       StringBuffer errSb = new StringBuffer();
/* 142 */       Iterator bundleNameIt = this.componentMfMap.keySet().iterator();
/*     */ 
/* 146 */       while (bundleNameIt.hasNext()) {
/* 147 */         bundleName = (String)bundleNameIt.next();
/* 148 */         ComponentManifest componentManifest = (ComponentManifest)this.componentMfMap.get(bundleName);
/* 149 */         String bundleVersion = componentManifest.getBundleVersion();
/* 150 */         String[][] requireBundleArr = componentManifest.getRequireBundle();
/* 151 */         if ((requireBundleArr != null) && (requireBundleArr.length >= 1))
/*     */         {
/* 155 */           for (int i = 0; i < requireBundleArr.length; i++) {
/* 156 */             if (requireBundleArr[i].length < 2) {
/* 157 */               errSb.append("The 'Require-Bundle' config item in Component [" + bundleName + "(" + bundleVersion + ")] is not formatted, please check it.");
/*     */             }
/*     */             else
/*     */             {
/* 165 */               String requireBundleName = requireBundleArr[i][0].toLowerCase().trim();
/*     */ 
/* 167 */               String requireBundleVersion = requireBundleArr[i][1].trim();
/* 168 */               componentManifest = (ComponentManifest)this.componentMfMap.get(requireBundleName);
/* 169 */               if (componentManifest == null) {
/* 170 */                 errSb.append("The component [" + requireBundleName + "(" + requireBundleVersion + ")] which [" + bundleName + "(" + bundleVersion + ") depend on not exist.");
/*     */               }
/* 177 */               else if (isVersionMath(requireBundleVersion, componentManifest.getBundleVersion()) > 0)
/*     */               {
/* 179 */                 errSb.append("The version of component [" + requireBundleName + "(" + componentManifest.getBundleVersion() + ")] which [" + bundleName + "(" + bundleVersion + ") depend is too lower, needed version is : " + requireBundleVersion + ".");
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 191 */       if (errSb.length() > 0)
/*     */       {
/* 193 */         log.warn(errSb.toString());
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 197 */       log.error("", e);
/* 198 */       throw new ComponentException(" Occur unkown error on [" + bundleName + "] when validate capability of aibi components.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private int isVersionMath(String version1, String version2)
/*     */   {
/* 212 */     if ((version1 == null) || (version2 == null)) {
/* 213 */       return 0;
/*     */     }
/* 215 */     if ((!version1.contains(".")) || (!version2.contains("."))) {
/* 216 */       return version1.compareToIgnoreCase(version2);
/*     */     }
/*     */ 
/* 219 */     return getCompareVersion(version1).compareToIgnoreCase(getCompareVersion(version2));
/*     */   }
/*     */ 
/*     */   private String getCompareVersion(String version)
/*     */   {
/* 229 */     if (!version.contains(".")) {
/* 230 */       return version;
/*     */     }
/*     */ 
/* 233 */     String[] vs = version.split("\\.");
/* 234 */     int n = VersionDigit > vs.length ? vs.length : VersionDigit;
/* 235 */     String cVersion = "";
/* 236 */     for (int i = 0; i < n; i++) {
/* 237 */       cVersion = cVersion + vs[i] + ".";
/*     */     }
/* 239 */     return cVersion.substring(0, cVersion.length() - 1);
/*     */   }
/*     */ 
/*     */   public void initializeComponents(ContextManager context)
/*     */     throws ComponentException
/*     */   {
/* 250 */     invokeComponentActivator("start", context);
/*     */   }
/*     */ 
/*     */   public void finalizeComponents(ContextManager context)
/*     */     throws ComponentException
/*     */   {
/* 261 */     invokeComponentActivator("stop", context);
/*     */   }
/*     */ 
/*     */   private void invokeComponentActivator(String methodName, ContextManager context)
/*     */     throws ComponentException
/*     */   {
/* 275 */     String activatorClassName = "";
/*     */     try {
/* 277 */       Collection cmfList = this.componentMfMap.values();
/* 278 */       for (ComponentManifest mf : cmfList) {
/* 279 */         activatorClassName = mf.getBundleActivator();
/*     */ 
/* 281 */         log.info("[invokeComponentActivator--] " + mf.getBundleName() + " activatorClassName=[" + activatorClassName + "]");
/*     */ 
/* 283 */         if ((activatorClassName != null) && (activatorClassName.length() >= 1))
/*     */         {
/* 287 */           Class activatorClass = Class.forName(activatorClassName.trim());
/* 288 */           if (activatorClass != null)
/*     */           {
/* 291 */             Object activator = activatorClass.newInstance();
/* 292 */             Method method = activatorClass.getMethod(methodName, new Class[] { ContextManager.class });
/*     */ 
/* 294 */             if (method != null)
/*     */             {
/* 297 */               method.invoke(activator, new Object[] { context }); } 
/*     */           }
/*     */         }
/*     */       } } catch (ClassNotFoundException cnfe) { log.error("", cnfe);
/* 301 */       throw new ComponentException(cnfe.getMessage() + " when invoking Class.forName(" + activatorClassName + ").");
/*     */     }
/*     */     catch (IllegalAccessException iae)
/*     */     {
/* 305 */       log.error("", iae);
/* 306 */       throw new ComponentException(iae.getMessage() + " when invoking " + activatorClassName + ".newInstance().");
/*     */     }
/*     */     catch (InstantiationException ie) {
/* 309 */       log.error("", ie);
/* 310 */       throw new ComponentException(ie.getMessage() + " when invoking " + activatorClassName + ".newInstance().");
/*     */     }
/*     */     catch (NoSuchMethodException nse) {
/* 313 */       log.error("", nse);
/* 314 */       throw new ComponentException(nse.getMessage() + " when invoking " + activatorClassName + ".getMethod(" + methodName + ").");
/*     */     }
/*     */     catch (InvocationTargetException ite) {
/* 317 */       log.error("", ite);
/* 318 */       throw new ComponentException(ite.getMessage() + " when method.invoke() of " + activatorClassName + "." + methodName + ".");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 322 */       log.error("", e);
/* 323 */       throw new ComponentException("Occur unknown error when invoking [" + methodName + "] of " + activatorClassName);
/*     */     }
/*     */   }
/*     */ 
/*     */   private ComponentManifest genManifestFromAttributes(Attributes attributes)
/*     */   {
/* 336 */     ComponentManifest componentManifest = new ComponentManifest();
/*     */ 
/* 338 */     String bundleName = attributes.getValue("Bundle-Name");
/*     */ 
/* 340 */     if (bundleName != null) {
/* 341 */       bundleName = bundleName.toLowerCase().trim();
/*     */     }
/* 343 */     componentManifest.setBundleName(bundleName);
/*     */ 
/* 345 */     componentManifest.setBundleActivator(attributes.getValue("Bundle-Activator"));
/*     */ 
/* 347 */     componentManifest.setBundleAuthor(attributes.getValue("Bundle-Author"));
/*     */ 
/* 349 */     componentManifest.setBundleSymboilcName(attributes.getValue("Bundle-SymbolicName"));
/*     */ 
/* 351 */     componentManifest.setBundleVersion(attributes.getValue("Bundle-Version"));
/*     */ 
/* 353 */     componentManifest.setCompatibleBIPlatformVersion(parseValueToArr(attributes.getValue("Compatible-BIPlatform-Version"), ","));
/*     */ 
/* 357 */     componentManifest.setExportPackage(parseValueToArr(attributes.getValue("Export-Package"), ","));
/*     */ 
/* 359 */     componentManifest.setExportPackageDoc(attributes.getValue("Export-Package-Doc"));
/*     */ 
/* 361 */     componentManifest.setExportServiceType(parseValueToArr(attributes.getValue("Export-Service-Type"), ","));
/*     */ 
/* 363 */     componentManifest.setExportTld(attributes.getValue("Export-Tld"));
/*     */ 
/* 365 */     componentManifest.setExportTldDoc(attributes.getValue("Export-Tld-Doc"));
/*     */ 
/* 367 */     componentManifest.setExportUrl(parseValueToArr(attributes.getValue("Export-Url"), ","));
/*     */ 
/* 369 */     componentManifest.setExportUrlDoc(attributes.getValue("Export-Url-Doc"));
/*     */ 
/* 371 */     componentManifest.setExportWsdlFile(attributes.getValue("Export-Wsdl-File"));
/*     */ 
/* 373 */     componentManifest.setExportWsdlDoc(attributes.getValue("Export-Wsdl-Doc"));
/*     */ 
/* 375 */     componentManifest.setPublishDay(attributes.getValue("Publish-Day"));
/*     */ 
/* 377 */     componentManifest.setRequireBundle(parseValueToMutilArr(attributes.getValue("Require-Bundle")));
/*     */ 
/* 380 */     return componentManifest;
/*     */   }
/*     */ 
/*     */   private String[] parseValueToArr(String attributeValue, String splitChar)
/*     */   {
/* 392 */     if ((attributeValue == null) || (attributeValue.trim().length() < 1)) {
/* 393 */       return new String[0];
/*     */     }
/* 395 */     return attributeValue.split("[" + splitChar + "]");
/*     */   }
/*     */ 
/*     */   private String[][] parseValueToMutilArr(String attributeValue)
/*     */   {
/* 408 */     String[] tmpArr = parseValueToArr(attributeValue, ",");
/* 409 */     String[][] retArr = new String[tmpArr.length][2];
/*     */ 
/* 411 */     int index = 0;
/* 412 */     for (String tmpString : tmpArr) {
/* 413 */       String[] tmpArr2 = parseValueToArr(tmpString, ";");
/* 414 */       if (tmpArr2.length >= 2) {
/* 415 */         retArr[index][0] = tmpArr2[0].trim();
/* 416 */         tmpString = tmpArr2[1].trim();
/* 417 */         int pos1 = tmpString.indexOf("\"");
/* 418 */         retArr[index][1] = tmpString.substring(pos1 + 1, tmpString.length() - 1);
/*     */       }
/*     */ 
/* 421 */       index++;
/*     */     }
/* 423 */     return retArr;
/*     */   }
/*     */ 
/*     */   public void getMetaInfFromMultiPath(Set<String> lstFilePaths)
/*     */     throws ComponentException
/*     */   {
/* 434 */     if ((lstFilePaths == null) || (lstFilePaths.size() == 0)) {
/* 435 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 439 */       List lst = new ArrayList();
/* 440 */       for (String path : lstFilePaths) {
/* 441 */         File pathFile = new File(URLDecoder.decode(path, "utf-8"));
/* 442 */         if (!pathFile.exists()) {
/* 443 */           throw new FileNotFoundException(path + " not exist.");
/*     */         }
/*     */ 
/* 446 */         File[] componentJarFileArr = pathFile.listFiles(new ComponentJarFilenameFilter());
/*     */ 
/* 448 */         lst.addAll(Arrays.asList(componentJarFileArr));
/*     */       }
/*     */ 
/* 451 */       if (lst.size() > 0)
/* 452 */         for (File file : lst) {
/* 453 */           JarFile componentJarFile = new JarFile(file);
/* 454 */           Manifest componentMf = componentJarFile.getManifest();
/* 455 */           Attributes attributes = componentMf.getMainAttributes();
/* 456 */           ComponentManifest componentManifest = genManifestFromAttributes(attributes);
/* 457 */           if ((componentManifest.getBundleName() != null) && (componentManifest.getBundleName().trim().length() >= 1))
/*     */           {
/* 460 */             log.info("Detecting Component : " + componentManifest.getBundleName() + "[" + componentManifest.getBundleVersion() + "]");
/*     */ 
/* 465 */             this.componentMfMap.put(componentManifest.getBundleName(), componentManifest);
/*     */           }
/*     */         }
/*     */     }
/*     */     catch (IOException ie)
/*     */     {
/* 471 */       log.error("", ie);
/* 472 */       throw new ComponentException("Read Jar file or MANIFEST.MF file error.");
/*     */     }
/*     */     catch (Exception e) {
/* 475 */       log.error("", e);
/* 476 */       throw new ComponentException("Occur unkown error when reading metainfo of aibi components.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 482 */     String v1 = "1.1";
/* 483 */     String v2 = "1.1";
/* 484 */     String v3 = "1.2.1.20031201";
/* 485 */     String v4 = "1.1";
/* 486 */     String v5 = "1.1.1.20031201";
/* 487 */     String v6 = "1.1";
/* 488 */     String v7 = "1.1";
/* 489 */     String v8 = "1.1.1.20031201";
/* 490 */     String v9 = "V04R00C00";
/* 491 */     String v10 = "V04R00C01";
/* 492 */     ComponentManager comp = getInstance();
/*     */ 
/* 494 */     String cv1 = comp.getCompareVersion(v1);
/* 495 */     String cv2 = comp.getCompareVersion(v2);
/* 496 */     int b = comp.isVersionMath(v1, v2);
/* 497 */     System.out.println("v1=[" + v1 + "],v2=[" + v2 + "],cv1=[" + cv1 + "],cv2=[" + cv2 + "],b=" + b);
/*     */ 
/* 499 */     String cv3 = comp.getCompareVersion(v3);
/* 500 */     String cv4 = comp.getCompareVersion(v4);
/* 501 */     b = comp.isVersionMath(v3, v4);
/* 502 */     System.out.println("v3=[" + v3 + "],v4=[" + v4 + "],cv3=[" + cv3 + "],cv4=[" + cv4 + "],b=" + b);
/*     */ 
/* 504 */     String cv5 = comp.getCompareVersion(v5);
/* 505 */     String cv6 = comp.getCompareVersion(v6);
/* 506 */     b = comp.isVersionMath(v5, v6);
/* 507 */     System.out.println("v5=[" + v5 + "],v6=[" + v6 + "],cv5=[" + cv5 + "],cv6=[" + cv6 + "],b=" + b);
/*     */ 
/* 509 */     String cv7 = comp.getCompareVersion(v7);
/* 510 */     String cv8 = comp.getCompareVersion(v8);
/* 511 */     b = comp.isVersionMath(v7, v8);
/* 512 */     System.out.println("v7=[" + v7 + "],v8=[" + v8 + "],cv7=[" + cv7 + "],cv8=[" + cv8 + "],b=" + b);
/*     */ 
/* 514 */     String cv9 = comp.getCompareVersion(v9);
/* 515 */     String cv10 = comp.getCompareVersion(v10);
/* 516 */     b = comp.isVersionMath(v9, v10);
/* 517 */     System.out.println("v9=[" + v9 + "],v10=[" + v10 + "],cv9=[" + cv9 + "],cv10=[" + cv10 + "],b=" + b);
/*     */   }
/*     */ 
/*     */   class ComponentJarFilenameFilter
/*     */     implements FilenameFilter
/*     */   {
/*     */     ComponentJarFilenameFilter()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean accept(File dir, String name)
/*     */     {
/*  58 */       return (name.toLowerCase().startsWith("aibi-")) && (name.toLowerCase().endsWith(".jar")) && (name.toLowerCase().indexOf("-component-") < 0);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.component.ComponentManager
 * JD-Core Version:    0.6.2
 */
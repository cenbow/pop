/*     */ package com.asiainfo.biframe.manager.component;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class ComponentManifest
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -1569833561684978335L;
/*     */   private String bundleName;
/*     */   private String bundleSymboilcName;
/*     */   private String bundleActivator;
/*     */   private String bundleVersion;
/*     */   private String bundleVendor;
/*     */   private String bundleAuthor;
/*     */   private String[] compatibleBIPlatformVersion;
/*     */   private String publishDay;
/*     */   private String[][] requireBundle;
/*     */   private String[][] importPackage;
/*     */   private String[] exportServiceType;
/*     */   private String[] exportPackage;
/*     */   private String exportPackageDoc;
/*     */   private String exportWsdlFile;
/*     */   private String exportWsdlDoc;
/*     */   private String[] exportUrl;
/*     */   private String exportUrlDoc;
/*     */   private String exportTld;
/*     */   private String exportTldDoc;
/*     */ 
/*     */   public String getBundleName()
/*     */   {
/*  56 */     return this.bundleName;
/*     */   }
/*     */ 
/*     */   public void setBundleName(String bundleName) {
/*  60 */     this.bundleName = bundleName;
/*     */   }
/*     */ 
/*     */   public String getBundleSymboilcName() {
/*  64 */     return this.bundleSymboilcName;
/*     */   }
/*     */ 
/*     */   public void setBundleSymboilcName(String bundleSymboilcName) {
/*  68 */     this.bundleSymboilcName = bundleSymboilcName;
/*     */   }
/*     */ 
/*     */   public String getBundleActivator() {
/*  72 */     return this.bundleActivator;
/*     */   }
/*     */ 
/*     */   public void setBundleActivator(String bundleActivator) {
/*  76 */     this.bundleActivator = bundleActivator;
/*     */   }
/*     */ 
/*     */   public String getBundleVersion() {
/*  80 */     return this.bundleVersion;
/*     */   }
/*     */ 
/*     */   public void setBundleVersion(String bundleVersion) {
/*  84 */     this.bundleVersion = bundleVersion;
/*     */   }
/*     */ 
/*     */   public String getBundleVendor() {
/*  88 */     return this.bundleVendor;
/*     */   }
/*     */ 
/*     */   public void setBundleVendor(String bundleVendor) {
/*  92 */     this.bundleVendor = bundleVendor;
/*     */   }
/*     */ 
/*     */   public String getBundleAuthor() {
/*  96 */     return this.bundleAuthor;
/*     */   }
/*     */ 
/*     */   public void setBundleAuthor(String bundleAuthor) {
/* 100 */     this.bundleAuthor = bundleAuthor;
/*     */   }
/*     */ 
/*     */   public String[] getCompatibleBIPlatformVersion() {
/* 104 */     return this.compatibleBIPlatformVersion;
/*     */   }
/*     */ 
/*     */   public void setCompatibleBIPlatformVersion(String[] compatibleBIPlatformVersion)
/*     */   {
/* 109 */     this.compatibleBIPlatformVersion = compatibleBIPlatformVersion;
/*     */   }
/*     */ 
/*     */   public String getPublishDay() {
/* 113 */     return this.publishDay;
/*     */   }
/*     */ 
/*     */   public void setPublishDay(String publishDay) {
/* 117 */     this.publishDay = publishDay;
/*     */   }
/*     */ 
/*     */   public String[][] getRequireBundle() {
/* 121 */     return this.requireBundle;
/*     */   }
/*     */ 
/*     */   public void setRequireBundle(String[][] requireBundle) {
/* 125 */     this.requireBundle = requireBundle;
/*     */   }
/*     */ 
/*     */   public String[][] getImportPackage() {
/* 129 */     return this.importPackage;
/*     */   }
/*     */ 
/*     */   public void setImportPackage(String[][] importPackage) {
/* 133 */     this.importPackage = importPackage;
/*     */   }
/*     */ 
/*     */   public String[] getExportServiceType() {
/* 137 */     return this.exportServiceType;
/*     */   }
/*     */ 
/*     */   public void setExportServiceType(String[] exportServiceType) {
/* 141 */     this.exportServiceType = exportServiceType;
/*     */   }
/*     */ 
/*     */   public String[] getExportPackage() {
/* 145 */     return this.exportPackage;
/*     */   }
/*     */ 
/*     */   public void setExportPackage(String[] exportPackage) {
/* 149 */     this.exportPackage = exportPackage;
/*     */   }
/*     */ 
/*     */   public String getExportPackageDoc() {
/* 153 */     return this.exportPackageDoc;
/*     */   }
/*     */ 
/*     */   public void setExportPackageDoc(String exportPackageDoc) {
/* 157 */     this.exportPackageDoc = exportPackageDoc;
/*     */   }
/*     */ 
/*     */   public String getExportWsdlFile() {
/* 161 */     return this.exportWsdlFile;
/*     */   }
/*     */ 
/*     */   public void setExportWsdlFile(String exportWsdlFile) {
/* 165 */     this.exportWsdlFile = exportWsdlFile;
/*     */   }
/*     */ 
/*     */   public String getExportWsdlDoc() {
/* 169 */     return this.exportWsdlDoc;
/*     */   }
/*     */ 
/*     */   public void setExportWsdlDoc(String exportWsdlDoc) {
/* 173 */     this.exportWsdlDoc = exportWsdlDoc;
/*     */   }
/*     */ 
/*     */   public String[] getExportUrl() {
/* 177 */     return this.exportUrl;
/*     */   }
/*     */ 
/*     */   public void setExportUrl(String[] exportUrl) {
/* 181 */     this.exportUrl = exportUrl;
/*     */   }
/*     */ 
/*     */   public String getExportUrlDoc() {
/* 185 */     return this.exportUrlDoc;
/*     */   }
/*     */ 
/*     */   public void setExportUrlDoc(String exportUrlDoc) {
/* 189 */     this.exportUrlDoc = exportUrlDoc;
/*     */   }
/*     */ 
/*     */   public String getExportTld() {
/* 193 */     return this.exportTld;
/*     */   }
/*     */ 
/*     */   public void setExportTld(String exportTld) {
/* 197 */     this.exportTld = exportTld;
/*     */   }
/*     */ 
/*     */   public String getExportTldDoc() {
/* 201 */     return this.exportTldDoc;
/*     */   }
/*     */ 
/*     */   public void setExportTldDoc(String exportTldDoc) {
/* 205 */     this.exportTldDoc = exportTldDoc;
/*     */   }
/*     */ 
/*     */   public String getCompatibleBIPlatformVersions() {
/* 209 */     StringBuffer sb = new StringBuffer();
/* 210 */     if ((this.compatibleBIPlatformVersion != null) && (this.compatibleBIPlatformVersion.length > 0))
/*     */     {
/* 212 */       for (String tmpStr : this.compatibleBIPlatformVersion) {
/* 213 */         sb.append("BIPlatform " + tmpStr + "\n");
/*     */       }
/*     */     }
/* 216 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getExportServiceTypes() {
/* 220 */     return convertArrayToString(this.exportServiceType);
/*     */   }
/*     */ 
/*     */   public String getExportPackages() {
/* 224 */     return convertArrayToString(this.exportPackage);
/*     */   }
/*     */ 
/*     */   public String getExportUrls() {
/* 228 */     return convertArrayToString(this.exportUrl);
/*     */   }
/*     */ 
/*     */   public String getRequireBundles() {
/* 232 */     StringBuffer sb = new StringBuffer();
/* 233 */     if ((this.requireBundle != null) && (this.requireBundle.length > 0)) {
/* 234 */       for (int i = 0; i < this.requireBundle.length; i++) {
/* 235 */         sb.append(this.requireBundle[i][0] + ":" + this.requireBundle[i][1] + "; ");
/*     */       }
/*     */     }
/*     */ 
/* 239 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private String convertArrayToString(String[] array) {
/* 243 */     StringBuffer sb = new StringBuffer();
/* 244 */     if ((array != null) && (array.length > 0)) {
/* 245 */       for (String tmpStr : array) {
/* 246 */         sb.append(tmpStr + "; \n");
/*     */       }
/*     */     }
/* 249 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.component.ComponentManifest
 * JD-Core Version:    0.6.2
 */
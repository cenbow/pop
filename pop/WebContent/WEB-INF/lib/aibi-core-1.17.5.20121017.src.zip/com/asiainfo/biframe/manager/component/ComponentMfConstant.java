/*    */ package com.asiainfo.biframe.manager.component;
/*    */ 
/*    */ public class ComponentMfConstant
/*    */ {
/*    */   public static final String PREFIX_OF_COMPONENT_JAR_FILENAME = "aibi-";
/* 21 */   public static final String[] COMPONENT_LOAD_INDEX_ARRAY = { "-core-", "-pagecomponent-", "-privilege-", "-unilog-" };
/*    */   public static final String BUNDLE_NAME = "Bundle-Name";
/*    */   public static final String BUNDLE_ACTIVATOR = "Bundle-Activator";
/*    */   public static final String BUNDLE_SYMBOLIC_NAME = "Bundle-SymbolicName";
/*    */   public static final String BUNDLE_VERSION = "Bundle-Version";
/*    */   public static final String BUNDLE_AUTHOR = "Bundle-Author";
/*    */   public static final String PUBLISH_DAY = "Publish-Day";
/*    */   public static final String COMPATIBLE_BIPLATFORM_VERSION = "Compatible-BIPlatform-Version";
/*    */   public static final String REQUIRE_BUNDLE = "Require-Bundle";
/*    */   public static final String IMPORT_PACKAGE = "Import-Package";
/*    */   public static final String EXPORT_SERVICE_TYPE = "Export-Service-Type";
/*    */   public static final String EXPORT_PACAKGE = "Export-Package";
/*    */   public static final String EXPORT_PACAKGE_DOC = "Export-Package-Doc";
/*    */   public static final String EXPORT_WSDL_FILE = "Export-Wsdl-File";
/*    */   public static final String EXPORT_WSDL_DOC = "Export-Wsdl-Doc";
/*    */   public static final String EXPORT_URL = "Export-Url";
/*    */   public static final String EXPORT_URL_DOC = "Export-Url-Doc";
/*    */   public static final String EXPORT_TLD = "Export-Tld";
/*    */   public static final String EXPORT_TLD_DOC = "Export-Tld-Doc";
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.component.ComponentMfConstant
 * JD-Core Version:    0.6.2
 */
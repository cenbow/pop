/*     */ package com.asiainfo.biframe.manager.context;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.exception.BaseRuntimeException;
/*     */ import com.asiainfo.biframe.exception.ComponentException;
/*     */ import com.asiainfo.biframe.manager.cache.CacheManager;
/*     */ import com.asiainfo.biframe.manager.component.ComponentManager;
/*     */ import com.asiainfo.biframe.manager.component.ComponentManifest;
/*     */ import com.asiainfo.biframe.manager.startup.StartupInfoManager;
/*     */ import com.asiainfo.biframe.manager.thread.ThreadManager;
/*     */ import com.asiainfo.biframe.manager.timertask.TimerTaskManager;
/*     */ import com.asiainfo.biframe.service.ITimerService;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContextEvent;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ContextManager
/*     */ {
/*     */   private ServletContextEvent servletContextEvent;
/*  38 */   private static Log log = LogFactory.getLog(ContextManager.class);
/*     */ 
/*     */   public void initializeComponents(String componentFilePath, ServletContextEvent event)
/*     */     throws ComponentException
/*     */   {
/*  47 */     this.servletContextEvent = event;
/*     */ 
/*  49 */     ComponentManager.getInstance().getMetaInfFromComponentJar(componentFilePath);
/*     */ 
/*  52 */     ComponentManager.getInstance().validateComponents();
/*     */ 
/*  54 */     ComponentManager.getInstance().initializeComponents(this);
/*     */   }
/*     */ 
/*     */   public void finalizeComponents(ServletContextEvent event)
/*     */     throws ComponentException
/*     */   {
/*  62 */     this.servletContextEvent = event;
/*  63 */     ComponentManager.getInstance().finalizeComponents(this);
/*     */   }
/*     */ 
/*     */   public ComponentManifest getComponentManifest(String bundleName)
/*     */   {
/*  74 */     return ComponentManager.getInstance().getComponentManifest(bundleName);
/*     */   }
/*     */ 
/*     */   public void registerCacheService(String cacheKey, CacheBase cache)
/*     */   {
/*  85 */     CacheManager.getInstance().registerCache(cacheKey, cache);
/*     */   }
/*     */ 
/*     */   public void removeCacheService(String cacheKey)
/*     */   {
/*  95 */     CacheManager.getInstance().removeCache(cacheKey);
/*     */   }
/*     */ 
/*     */   public CacheBase getCacheService(String cacheKey)
/*     */   {
/* 106 */     return CacheManager.getInstance().getCache(cacheKey);
/*     */   }
/*     */ 
/*     */   public void registerTimerTaskService(String taskServiceKey, ITimerService timerService)
/*     */   {
/* 136 */     TimerTaskManager.getInstance().registerTimerTaskService(taskServiceKey, timerService);
/*     */   }
/*     */ 
/*     */   public void removeTimerTaskService(String taskServiceKey)
/*     */   {
/* 147 */     TimerTaskManager.getInstance().removeTimerTaskService(taskServiceKey);
/*     */   }
/*     */ 
/*     */   public void cancelTimerServiceTask(String taskServiceKey, String taskKey)
/*     */   {
/* 159 */     TimerTaskManager.getInstance().cancelTimerTask(taskServiceKey, taskKey);
/*     */   }
/*     */ 
/*     */   private boolean cancelTimerTask(String taskType, String taskKey)
/*     */   {
/* 175 */     throw new BaseRuntimeException("Needed to implement");
/*     */   }
/*     */ 
/*     */   public void registerThread(String threadKey, Runnable thread)
/*     */   {
/* 185 */     ThreadManager.getInstance().registerThread(threadKey, thread);
/*     */   }
/*     */ 
/*     */   public void removeThread(String threadKey)
/*     */   {
/* 194 */     ThreadManager.getInstance().removeThread(threadKey);
/*     */   }
/*     */ 
/*     */   public void registerStrutModule(String moduleName, String moduleStrutsConfigFile)
/*     */   {
/* 205 */     StartupInfoManager.getInstance().registerStrutModule(moduleName, moduleStrutsConfigFile);
/*     */   }
/*     */ 
/*     */   public void registerSpringConfigFile(String moduleName, String moduleSpringConfigFiles)
/*     */   {
/* 216 */     StartupInfoManager.getInstance().registerSpringConfigFile(moduleName, moduleSpringConfigFiles);
/*     */   }
/*     */ 
/*     */   public ServletContextEvent getServletContextEvent()
/*     */   {
/* 221 */     return this.servletContextEvent;
/*     */   }
/*     */ 
/*     */   public void setServletContextEvent(ServletContextEvent servletContextEvent) {
/* 225 */     this.servletContextEvent = servletContextEvent;
/*     */   }
/*     */ 
/*     */   public void initializeComponents(ServletContextEvent event)
/*     */     throws ComponentException, IOException
/*     */   {
/* 238 */     this.servletContextEvent = event;
/* 239 */     Set lstFilePaths = getFilePaths();
/* 240 */     ComponentManager.getInstance().getMetaInfFromMultiPath(lstFilePaths);
/* 241 */     ComponentManager.getInstance().validateComponents();
/* 242 */     ComponentManager.getInstance().initializeComponents(this);
/*     */   }
/*     */ 
/*     */   private Set<String> getFilePaths()
/*     */     throws IOException
/*     */   {
/* 252 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */ 
/* 254 */     String metaStr = "META-INF/MANIFEST.MF";
/* 255 */     Enumeration resources = classLoader.getResources(metaStr);
/* 256 */     Set set = new HashSet();
/* 257 */     while (resources.hasMoreElements()) {
/* 258 */       URL resource = (URL)resources.nextElement();
/* 259 */       String mfPath = resource.getFile();
/* 260 */       String jarName = getJarNameFromPath(mfPath);
/* 261 */       if ((jarName.indexOf("aibi-") >= 0) && (jarName.indexOf("aibi-component-") < 0))
/*     */       {
/* 263 */         log.debug("mfPath=" + mfPath);
/* 264 */         String strPath = "";
/* 265 */         if (mfPath.indexOf("!") > 0) {
/* 266 */           if (mfPath.startsWith("file:"))
/* 267 */             strPath = mfPath.substring(5, mfPath.indexOf("!"));
/*     */           else {
/* 269 */             strPath = mfPath.substring(0, mfPath.indexOf("!"));
/*     */           }
/*     */         }
/* 272 */         else if (mfPath.startsWith("file:"))
/* 273 */           strPath = mfPath.substring(5);
/*     */         else {
/* 275 */           strPath = mfPath;
/*     */         }
/*     */ 
/* 278 */         strPath = strPath.substring(0, strPath.lastIndexOf("/") + 1);
/* 279 */         if (!set.contains(strPath)) {
/* 280 */           log.info("add path :" + strPath);
/* 281 */           set.add(strPath);
/*     */         }
/*     */       }
/*     */     }
/* 285 */     return set;
/*     */   }
/*     */ 
/*     */   private String getJarNameFromPath(String path)
/*     */   {
/* 295 */     String metaStr = "/META-INF/MANIFEST.MF";
/* 296 */     String jarName = "";
/* 297 */     if (path.contains(metaStr)) {
/* 298 */       path = path.substring(0, path.length() - metaStr.length());
/* 299 */       int i = path.lastIndexOf('/');
/* 300 */       jarName = path.substring(i + 1);
/* 301 */       if (jarName.endsWith("!")) {
/* 302 */         jarName = jarName.substring(0, jarName.length() - 1);
/*     */       }
/*     */     }
/* 305 */     return jarName;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 309 */     String path1 = "file:/E:/appserver/tomcat/tomcat5.5/common/lib/spring-1.2.6.jar!/META-INF/MANIFEST.MF";
/* 310 */     String path2 = "/D:/work/svn/BIPlatformV5/branches/5.1/PageComponent/aiomni3_dev/appfront/target/aibi-component-pageComponent-1.3.0-SNAPSHOT/WEB-INF/classes/META-INF/MANIFEST.MF";
/* 311 */     String path3 = "/E:/appserver/tomcat/tomcat5.5/common/lib/aibi-component-pageComponent-1.2.6.jar!/META-INF/MANIFEST.MF";
/* 312 */     ContextManager context = new ContextManager();
/* 313 */     System.out.println(path1);
/* 314 */     System.out.println(context.getJarNameFromPath(path1));
/* 315 */     System.out.println(path1);
/* 316 */     System.out.println(context.getJarNameFromPath(path2));
/* 317 */     System.out.println(context.getJarNameFromPath(path3));
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.context.ContextManager
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.manager.startup;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class StartupInfoManager
/*    */ {
/*    */   private Map<String, String> loadedStrutsModuleInfoMap;
/*    */   private Map<String, String> loadedSpringModuleInfoMap;
/*    */   private static StartupInfoManager instance;
/*    */ 
/*    */   private StartupInfoManager()
/*    */   {
/* 29 */     this.loadedStrutsModuleInfoMap = new HashMap();
/* 30 */     this.loadedSpringModuleInfoMap = new HashMap();
/*    */   }
/*    */ 
/*    */   public static StartupInfoManager getInstance()
/*    */   {
/* 39 */     if (instance == null) {
/* 40 */       instance = new StartupInfoManager();
/*    */     }
/* 42 */     return instance;
/*    */   }
/*    */ 
/*    */   public void registerStrutModule(String moduleName, String moduleStrutsConfigFile)
/*    */   {
/* 53 */     this.loadedStrutsModuleInfoMap.put(moduleName, moduleStrutsConfigFile);
/*    */   }
/*    */ 
/*    */   public Map<String, String> getAllLoadedStrutModules()
/*    */   {
/* 62 */     return this.loadedStrutsModuleInfoMap;
/*    */   }
/*    */ 
/*    */   public void registerSpringConfigFile(String moduleName, String moduleSpringConfigFiles)
/*    */   {
/* 72 */     this.loadedSpringModuleInfoMap.put(moduleName, moduleSpringConfigFiles);
/*    */   }
/*    */ 
/*    */   public Map<String, String> getAllLoadedSpringModules()
/*    */   {
/* 81 */     return this.loadedSpringModuleInfoMap;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.startup.StartupInfoManager
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.manager.thread;
/*    */ 
/*    */ import com.asiainfo.biframe.manager.timertask.ThreadAndTaskInfo;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ public class ThreadManager
/*    */ {
/*    */   public static final String THREAD_TYPE_NORMAL = "normalThread";
/*    */   private static Map<String, Runnable> threadMap;
/*    */   private static ThreadManager instance;
/*    */ 
/*    */   private ThreadManager()
/*    */   {
/* 29 */     threadMap = new HashMap();
/*    */   }
/*    */ 
/*    */   public static ThreadManager getInstance() {
/* 33 */     if (instance == null) {
/* 34 */       instance = new ThreadManager();
/*    */     }
/* 36 */     return instance;
/*    */   }
/*    */ 
/*    */   public List<ThreadAndTaskInfo> getAllRunnable()
/*    */   {
/* 45 */     List retList = new ArrayList();
/* 46 */     Iterator it = new TreeSet(threadMap.keySet()).iterator();
/*    */ 
/* 51 */     while (it.hasNext()) {
/* 52 */       String tmpKey = (String)it.next();
/* 53 */       Runnable thread = (Runnable)threadMap.get(tmpKey);
/* 54 */       ThreadAndTaskInfo info = new ThreadAndTaskInfo();
/* 55 */       info.setName(thread.getClass().getName());
/* 56 */       info.setDesc(tmpKey);
/* 57 */       retList.add(info);
/*    */     }
/* 59 */     return retList;
/*    */   }
/*    */ 
/*    */   public void registerThread(String threadKey, Runnable thread)
/*    */   {
/* 69 */     threadMap.put(threadKey, thread);
/*    */   }
/*    */ 
/*    */   public void removeThread(String threadKey)
/*    */   {
/* 78 */     threadMap.remove(threadKey);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.thread.ThreadManager
 * JD-Core Version:    0.6.2
 */
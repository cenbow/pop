/*    */ package com.asiainfo.biframe.manager.timertask;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import org.quartz.JobDetail;
/*    */ import org.springframework.scheduling.quartz.CronTriggerBean;
/*    */ 
/*    */ public class BICronTriggerBean extends CronTriggerBean
/*    */ {
/*    */   private static final long serialVersionUID = 5395063454808088234L;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */     throws ParseException
/*    */   {
/* 22 */     super.afterPropertiesSet();
/*    */ 
/* 24 */     TimerTaskManager.getInstance().registerCronTriggerJob(getJobDetail().getJobClass().getName(), this);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.timertask.BICronTriggerBean
 * JD-Core Version:    0.6.2
 */
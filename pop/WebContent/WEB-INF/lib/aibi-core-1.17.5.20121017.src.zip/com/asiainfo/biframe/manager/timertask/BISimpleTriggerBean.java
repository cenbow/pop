/*    */ package com.asiainfo.biframe.manager.timertask;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import org.quartz.JobDetail;
/*    */ import org.springframework.scheduling.quartz.SimpleTriggerBean;
/*    */ 
/*    */ public class BISimpleTriggerBean extends SimpleTriggerBean
/*    */ {
/*    */   private static final long serialVersionUID = 2325690178545733468L;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */     throws ParseException
/*    */   {
/* 33 */     super.afterPropertiesSet();
/*    */ 
/* 35 */     TimerTaskManager.getInstance().registerSimpleTriggerJob(getJobDetail().getJobClass().getName(), this);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.timertask.BISimpleTriggerBean
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.manager.timertask;
/*    */ 
/*    */ import java.util.Timer;
/*    */ import org.springframework.scheduling.timer.ScheduledTimerTask;
/*    */ import org.springframework.scheduling.timer.TimerFactoryBean;
/*    */ 
/*    */ public class BITimerFactoryBean extends TimerFactoryBean
/*    */ {
/*    */   protected void registerTasks(ScheduledTimerTask[] tasks, Timer timer)
/*    */   {
/* 30 */     super.registerTasks(tasks, timer);
/*    */ 
/* 32 */     for (ScheduledTimerTask task : tasks)
/* 33 */       TimerTaskManager.getInstance().registerTimerTask(task.getTimerTask().getClass().getName(), task);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.timertask.BITimerFactoryBean
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.manager.timertask;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class ThreadAndTaskInfo
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -1746241403698590939L;
/*    */   private String name;
/*    */   private String firstTime;
/*    */   private String period;
/*    */   private String desc;
/*    */   private String scheduledExecutionTime;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 28 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 32 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getDesc() {
/* 36 */     return this.desc;
/*    */   }
/*    */ 
/*    */   public void setDesc(String desc) {
/* 40 */     this.desc = desc;
/*    */   }
/*    */ 
/*    */   public String getFirstTime() {
/* 44 */     return this.firstTime;
/*    */   }
/*    */ 
/*    */   public void setFirstTime(String firstTime) {
/* 48 */     this.firstTime = firstTime;
/*    */   }
/*    */ 
/*    */   public String getPeriod() {
/* 52 */     return this.period;
/*    */   }
/*    */ 
/*    */   public void setPeriod(String period) {
/* 56 */     this.period = period;
/*    */   }
/*    */ 
/*    */   public String getScheduledExecutionTime() {
/* 60 */     return this.scheduledExecutionTime;
/*    */   }
/*    */ 
/*    */   public void setScheduledExecutionTime(String scheduledExecutionTime) {
/* 64 */     this.scheduledExecutionTime = scheduledExecutionTime;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.timertask.ThreadAndTaskInfo
 * JD-Core Version:    0.6.2
 */
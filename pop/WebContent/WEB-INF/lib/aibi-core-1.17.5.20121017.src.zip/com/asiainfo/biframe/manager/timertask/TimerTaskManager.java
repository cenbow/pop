/*     */ package com.asiainfo.biframe.manager.timertask;
/*     */ 
/*     */ import com.asiainfo.biframe.service.ITimerService;
/*     */ import com.asiainfo.biframe.service.impl.TimerTaskWrapper;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TimerTask;
/*     */ import java.util.TreeSet;
/*     */ import org.springframework.scheduling.timer.ScheduledTimerTask;
/*     */ 
/*     */ public class TimerTaskManager
/*     */ {
/*     */   public static final String TASK_TYPE_SCHEDULED = "scheduledTask";
/*     */   public static final String TASK_TYPE_CRON = "cronTask";
/*     */   private static Map<String, ScheduledTimerTask> timerTaskMap;
/*     */   private static Map<String, BICronTriggerBean> cronTriggerMap;
/*     */   private static Map<String, BISimpleTriggerBean> simpleTriggerMap;
/*     */   private static Map<String, ITimerService> timerServiceMap;
/*     */   private static List<String> schedulerList;
/*     */   private static TimerTaskManager instance;
/*     */ 
/*     */   private TimerTaskManager()
/*     */   {
/*  45 */     timerTaskMap = new HashMap();
/*  46 */     timerServiceMap = new HashMap();
/*  47 */     cronTriggerMap = new HashMap();
/*  48 */     simpleTriggerMap = new HashMap();
/*  49 */     schedulerList = new ArrayList();
/*     */   }
/*     */ 
/*     */   public List<ThreadAndTaskInfo> getTimerTaskByType(String taskType)
/*     */   {
/*  59 */     if ("scheduledTask".equalsIgnoreCase(taskType)) {
/*  60 */       return getScheduledTimerTask();
/*     */     }
/*  62 */     return getTriggerTimerTask();
/*     */   }
/*     */ 
/*     */   public List<String> getSchedulerByType(String taskType)
/*     */   {
/*  67 */     if ("scheduledTask".equalsIgnoreCase(taskType)) {
/*  68 */       return null;
/*     */     }
/*  70 */     return getTriggerScheduler();
/*     */   }
/*     */ 
/*     */   private List<ThreadAndTaskInfo> getScheduledTimerTask()
/*     */   {
/*  80 */     List retList = new ArrayList();
/*     */ 
/*  82 */     Iterator it = new TreeSet(timerTaskMap.keySet()).iterator();
/*     */ 
/*  87 */     while (it.hasNext()) {
/*  88 */       ThreadAndTaskInfo info = new ThreadAndTaskInfo();
/*  89 */       String tmpName = (String)it.next();
/*  90 */       ScheduledTimerTask scheduledTask = (ScheduledTimerTask)timerTaskMap.get(tmpName);
/*  91 */       info.setName(tmpName);
/*  92 */       info.setPeriod(String.valueOf(scheduledTask.getPeriod()));
/*  93 */       info.setScheduledExecutionTime(convertLongMillsToString(scheduledTask.getTimerTask().scheduledExecutionTime() + scheduledTask.getPeriod()));
/*     */ 
/*  97 */       retList.add(info);
/*     */     }
/*     */ 
/* 100 */     it = new TreeSet(timerServiceMap.keySet()).iterator();
/*     */ 
/* 106 */     while (it.hasNext()) {
/* 107 */       String tmpName = (String)it.next();
/* 108 */       ITimerService tmpService = (ITimerService)timerServiceMap.get(tmpName);
/* 109 */       Map tmpMap = tmpService.getAllScheduledTimerTask();
/* 110 */       Iterator objIt = tmpMap.keySet().iterator();
/* 111 */       while (objIt.hasNext()) {
/* 112 */         Object objKey = objIt.next();
/* 113 */         TimerTaskWrapper taskWrapper = (TimerTaskWrapper)tmpMap.get(objKey);
/* 114 */         ThreadAndTaskInfo info = new ThreadAndTaskInfo();
/* 115 */         info.setName(objKey.toString());
/* 116 */         info.setFirstTime(taskWrapper.getFirstTime());
/* 117 */         info.setPeriod(taskWrapper.getPeriod());
/* 118 */         long period = 0L;
/* 119 */         if ((taskWrapper.getPeriod() != null) && (taskWrapper.getPeriod().trim().length() > 0))
/*     */         {
/* 121 */           period = Long.parseLong(taskWrapper.getPeriod());
/*     */         }
/* 123 */         info.setScheduledExecutionTime(convertLongMillsToString(taskWrapper.scheduledExecutionTime() + period));
/*     */ 
/* 127 */         retList.add(info);
/*     */       }
/*     */     }
/*     */ 
/* 131 */     return retList;
/*     */   }
/*     */ 
/*     */   private List<String> getTriggerScheduler() {
/* 135 */     List retList = new ArrayList();
/*     */ 
/* 137 */     for (String s : schedulerList) {
/* 138 */       String schedulerName = s;
/* 139 */       retList.add(schedulerName);
/*     */     }
/* 141 */     return retList;
/*     */   }
/*     */ 
/*     */   private List<ThreadAndTaskInfo> getTriggerTimerTask()
/*     */   {
/* 150 */     List retList = new ArrayList();
/*     */ 
/* 152 */     Iterator it = new TreeSet(cronTriggerMap.keySet()).iterator();
/*     */ 
/* 157 */     while (it.hasNext()) {
/* 158 */       String tmpName = (String)it.next();
/* 159 */       BICronTriggerBean cronBean = (BICronTriggerBean)cronTriggerMap.get(tmpName);
/* 160 */       ThreadAndTaskInfo info = new ThreadAndTaskInfo();
/* 161 */       info.setName(tmpName);
/* 162 */       info.setPeriod(cronBean.getCronExpression());
/* 163 */       info.setFirstTime(DateUtil.date2String(cronBean.getStartTime(), "yyyy-MM-dd HH:mm:ss"));
/*     */ 
/* 165 */       info.setScheduledExecutionTime(DateUtil.date2String(cronBean.getNextFireTime(), "yyyy-MM-dd HH:mm:ss"));
/*     */ 
/* 167 */       retList.add(info);
/*     */     }
/*     */ 
/* 170 */     it = new TreeSet(simpleTriggerMap.keySet()).iterator();
/*     */ 
/* 172 */     while (it.hasNext()) {
/* 173 */       String tmpName = (String)it.next();
/* 174 */       BISimpleTriggerBean simpleTriggerBean = (BISimpleTriggerBean)simpleTriggerMap.get(tmpName);
/* 175 */       ThreadAndTaskInfo info = new ThreadAndTaskInfo();
/* 176 */       info.setName(tmpName);
/* 177 */       info.setPeriod(String.valueOf(simpleTriggerBean.getRepeatInterval()));
/*     */ 
/* 179 */       info.setFirstTime(DateUtil.date2String(simpleTriggerBean.getStartTime(), "yyyy-MM-dd HH:mm:ss"));
/*     */ 
/* 181 */       info.setScheduledExecutionTime(DateUtil.date2String(simpleTriggerBean.getNextFireTime(), "yyyy-MM-dd HH:mm:ss"));
/*     */ 
/* 184 */       retList.add(info);
/*     */     }
/*     */ 
/* 187 */     return retList;
/*     */   }
/*     */ 
/*     */   public static TimerTaskManager getInstance()
/*     */   {
/* 196 */     if (instance == null) {
/* 197 */       instance = new TimerTaskManager();
/*     */     }
/* 199 */     return instance;
/*     */   }
/*     */ 
/*     */   public void registerTimerTask(String taskKey, ScheduledTimerTask timerTask)
/*     */   {
/* 211 */     timerTaskMap.put(taskKey, timerTask);
/*     */   }
/*     */ 
/*     */   public void removeTimerTask(String taskKey)
/*     */   {
/* 221 */     ScheduledTimerTask timerTask = (ScheduledTimerTask)timerTaskMap.get(taskKey);
/* 222 */     if (timerTask != null) {
/* 223 */       timerTask.getTimerTask().cancel();
/*     */     }
/* 225 */     timerTaskMap.remove(taskKey);
/*     */   }
/*     */ 
/*     */   public void registerTimerTaskService(String taskServiceKey, ITimerService timerService)
/*     */   {
/* 238 */     timerServiceMap.put(taskServiceKey, timerService);
/*     */   }
/*     */ 
/*     */   public void removeTimerTaskService(String taskServiceKey)
/*     */   {
/* 248 */     ITimerService timerService = (ITimerService)timerServiceMap.get(taskServiceKey);
/* 249 */     if (timerService != null) {
/* 250 */       timerService.cancelAll();
/*     */     }
/* 252 */     timerServiceMap.remove(taskServiceKey);
/*     */   }
/*     */ 
/*     */   public void cancelTimerTask(String taskServiceKey, String taskKey)
/*     */   {
/* 264 */     ITimerService timerService = (ITimerService)timerServiceMap.get(taskServiceKey);
/* 265 */     if (timerService != null)
/* 266 */       timerService.cancel(taskKey);
/*     */   }
/*     */ 
/*     */   public void registerCronTriggerJob(String jobKey, BICronTriggerBean cronBean)
/*     */   {
/* 279 */     cronTriggerMap.put(jobKey, cronBean);
/*     */   }
/*     */ 
/*     */   public void registerScheduler(String schedulerName) {
/* 283 */     schedulerList.add(schedulerName);
/*     */   }
/*     */ 
/*     */   public void removeCronTriggerJob(String jobKey)
/*     */   {
/* 293 */     BICronTriggerBean cronBean = (BICronTriggerBean)cronTriggerMap.get(jobKey);
/* 294 */     if (cronBean != null) {
/* 295 */       cronBean.clearAllTriggerListeners();
/*     */     }
/* 297 */     cronTriggerMap.remove(jobKey);
/*     */   }
/*     */ 
/*     */   public void removeScheduler(String schedulerName) {
/* 301 */     schedulerList.remove(schedulerName);
/*     */   }
/*     */ 
/*     */   public void registerSimpleTriggerJob(String jobKey, BISimpleTriggerBean cronBean)
/*     */   {
/* 314 */     simpleTriggerMap.put(jobKey, cronBean);
/*     */   }
/*     */ 
/*     */   public void removeSimpleTriggerJob(String jobKey)
/*     */   {
/* 324 */     BISimpleTriggerBean cronBean = (BISimpleTriggerBean)simpleTriggerMap.get(jobKey);
/* 325 */     if (cronBean != null) {
/* 326 */       cronBean.clearAllTriggerListeners();
/*     */     }
/* 328 */     simpleTriggerMap.remove(jobKey);
/*     */   }
/*     */ 
/*     */   private String convertLongMillsToString(long millis)
/*     */   {
/* 339 */     Calendar cal = Calendar.getInstance();
/* 340 */     cal.setTimeInMillis(millis);
/* 341 */     return DateUtil.date2String(cal.getTime(), "yyyy-MM-dd HH:mm:ss");
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.manager.timertask.TimerTaskManager
 * JD-Core Version:    0.6.2
 */
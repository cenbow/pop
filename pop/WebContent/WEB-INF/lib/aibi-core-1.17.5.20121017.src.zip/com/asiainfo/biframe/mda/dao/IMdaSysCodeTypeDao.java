package com.asiainfo.biframe.mda.dao;

import com.asiainfo.biframe.mda.model.MdaSysCodeType;
import java.util.List;

public abstract interface IMdaSysCodeTypeDao
{
  public abstract void createCodeType(MdaSysCodeType paramMdaSysCodeType);

  public abstract void batchCreateCodeType(List<MdaSysCodeType> paramList);

  public abstract MdaSysCodeType getCodeTypeById(String paramString);

  public abstract List<MdaSysCodeType> getCodeTypeListByName(String paramString);

  public abstract void updateCodeType(MdaSysCodeType paramMdaSysCodeType);

  public abstract void removeCodeTypeById(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.dao.IMdaSysCodeTypeDao
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.mda.dao.impl;
/*    */ 
/*    */ import org.springframework.jdbc.core.JdbcTemplate;
/*    */ 
/*    */ public class JdbcTemplateDaoSupport
/*    */ {
/*    */   protected JdbcTemplate template;
/*    */ 
/*    */   public JdbcTemplate getTemplate()
/*    */   {
/* 37 */     return this.template;
/*    */   }
/*    */ 
/*    */   public void setTemplate(JdbcTemplate template) {
/* 41 */     this.template = template;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.dao.impl.JdbcTemplateDaoSupport
 * JD-Core Version:    0.6.2
 */
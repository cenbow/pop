/*     */ package com.asiainfo.biframe.mda.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.mda.dao.IMdaSysCodeDao;
/*     */ import com.asiainfo.biframe.mda.model.MdaSysCode;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.BeanPropertyRowMapper;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ 
/*     */ public class MdaSysCodeDaoImpl extends JdbcTemplateDaoSupport
/*     */   implements IMdaSysCodeDao
/*     */ {
/*     */   public void batchCreateCode(final List<MdaSysCode> mdaSysCodes)
/*     */   {
/*  57 */     if ((mdaSysCodes != null) && (mdaSysCodes.size() > 0)) {
/*  58 */       String insertSql = "insert into mda_sys_code(code_define_id, code_type_id, code_id, code_value, code_desc, display_order) values(?,?,?,?,?,?)";
/*  59 */       this.template.batchUpdate("insert into mda_sys_code(code_define_id, code_type_id, code_id, code_value, code_desc, display_order) values(?,?,?,?,?,?)", new BatchPreparedStatementSetter()
/*     */       {
/*     */         public void setValues(PreparedStatement ps, int i) throws SQLException
/*     */         {
/*  63 */           MdaSysCode sysCode = (MdaSysCode)mdaSysCodes.get(i);
/*  64 */           ps.setString(1, sysCode.getCodeDefineId());
/*  65 */           ps.setString(2, sysCode.getCodeTypeId());
/*  66 */           ps.setString(3, sysCode.getCodeId());
/*  67 */           ps.setString(4, sysCode.getCodeValue());
/*  68 */           ps.setString(5, sysCode.getCodeDesc());
/*  69 */           ps.setString(6, sysCode.getDisplayOrder());
/*     */         }
/*     */ 
/*     */         public int getBatchSize() {
/*  73 */           return mdaSysCodes.size();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void createCode(final MdaSysCode mdaSysCode)
/*     */   {
/*  85 */     String insertSql = "insert into mda_sys_code(code_define_id, code_type_id, code_id, code_value, code_desc, display_order) values(?,?,?,?,?,?)";
/*  86 */     this.template.update(new PreparedStatementCreator()
/*     */     {
/*     */       public PreparedStatement createPreparedStatement(Connection con) throws SQLException
/*     */       {
/*  90 */         PreparedStatement ps = con.prepareStatement("insert into mda_sys_code(code_define_id, code_type_id, code_id, code_value, code_desc, display_order) values(?,?,?,?,?,?)");
/*  91 */         ps.setString(1, mdaSysCode.getCodeDefineId());
/*  92 */         ps.setString(2, mdaSysCode.getCodeTypeId());
/*  93 */         ps.setString(3, mdaSysCode.getCodeId());
/*  94 */         ps.setString(4, mdaSysCode.getCodeValue());
/*  95 */         ps.setString(5, mdaSysCode.getCodeDesc());
/*  96 */         ps.setString(6, mdaSysCode.getDisplayOrder());
/*  97 */         return ps;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public MdaSysCode getCodeById(String codeDefineId)
/*     */   {
/* 108 */     String sql = "select code_define_id, code_type_id, code_id, code_value, code_desc, display_order from mda_sys_code where code_define_id=?";
/* 109 */     List ul = this.template.query(sql, new Object[] { codeDefineId }, new BeanPropertyRowMapper(MdaSysCode.class));
/*     */ 
/* 111 */     if (ul.size() > 0) {
/* 112 */       return (MdaSysCode)ul.get(0);
/*     */     }
/*     */ 
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   public List<MdaSysCode> getCodeListByType(String type)
/*     */   {
/* 124 */     String sql = "select code_define_id, code_type_id, code_id, code_value, code_desc, display_order from mda_sys_code where 1=1";
/* 125 */     if (StringUtil.isNotEmpty(type)) {
/* 126 */       sql = sql + " and code_type_id='" + type + "'";
/*     */     }
/* 128 */     return this.template.query(sql, new BeanPropertyRowMapper(MdaSysCode.class));
/*     */   }
/*     */ 
/*     */   public void removeCodeById(String codeDefineId)
/*     */   {
/* 137 */     String sql = "delete from mda_sys_code where code_define_id=?";
/* 138 */     this.template.update(sql, new Object[] { codeDefineId });
/*     */   }
/*     */ 
/*     */   public void updateCode(MdaSysCode mdaSysCode)
/*     */   {
/* 147 */     String sql = "update mda_sys_code set code_id=?, code_type_id=?, code_value=?, code_desc=?, display_order=? where code_define_id=?";
/* 148 */     this.template.update(sql, new Object[] { mdaSysCode.getCodeId(), mdaSysCode.getCodeTypeId(), mdaSysCode.getCodeValue(), mdaSysCode.getCodeDesc(), mdaSysCode.getDisplayOrder(), mdaSysCode.getCodeDefineId() });
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.dao.impl.MdaSysCodeDaoImpl
 * JD-Core Version:    0.6.2
 */
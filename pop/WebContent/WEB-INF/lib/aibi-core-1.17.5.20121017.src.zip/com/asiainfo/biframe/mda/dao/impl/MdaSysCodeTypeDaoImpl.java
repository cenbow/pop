/*     */ package com.asiainfo.biframe.mda.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.mda.dao.IMdaSysCodeTypeDao;
/*     */ import com.asiainfo.biframe.mda.model.MdaSysCodeType;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.BeanPropertyRowMapper;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ 
/*     */ public class MdaSysCodeTypeDaoImpl extends JdbcTemplateDaoSupport
/*     */   implements IMdaSysCodeTypeDao
/*     */ {
/*     */   public void batchCreateCodeType(final List<MdaSysCodeType> mdaSysCodeTypes)
/*     */   {
/*  57 */     if ((mdaSysCodeTypes != null) && (mdaSysCodeTypes.size() > 0)) {
/*  58 */       String insertSql = "insert into mda_sys_code_type(code_type_id, code_type_name, code_type_desc, is_sys_type) values(?,?,?,?)";
/*  59 */       this.template.batchUpdate("insert into mda_sys_code_type(code_type_id, code_type_name, code_type_desc, is_sys_type) values(?,?,?,?)", new BatchPreparedStatementSetter()
/*     */       {
/*     */         public void setValues(PreparedStatement ps, int i) throws SQLException
/*     */         {
/*  63 */           MdaSysCodeType sysCodeType = (MdaSysCodeType)mdaSysCodeTypes.get(i);
/*  64 */           ps.setString(1, sysCodeType.getCodeTypeId());
/*  65 */           ps.setString(2, sysCodeType.getCodeTypeName());
/*  66 */           ps.setString(3, sysCodeType.getCodeTypeDesc());
/*  67 */           ps.setString(4, sysCodeType.getIsSysType());
/*     */         }
/*     */ 
/*     */         public int getBatchSize() {
/*  71 */           return mdaSysCodeTypes.size();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void createCodeType(final MdaSysCodeType mdaSysCodeType)
/*     */   {
/*  83 */     String insertSql = "insert into mda_sys_code_type(code_type_id, code_type_name, code_type_desc, is_sys_type) values(?,?,?,?)";
/*  84 */     this.template.update(new PreparedStatementCreator()
/*     */     {
/*     */       public PreparedStatement createPreparedStatement(Connection con) throws SQLException
/*     */       {
/*  88 */         PreparedStatement ps = con.prepareStatement("insert into mda_sys_code_type(code_type_id, code_type_name, code_type_desc, is_sys_type) values(?,?,?,?)");
/*  89 */         ps.setString(1, mdaSysCodeType.getCodeTypeId());
/*  90 */         ps.setString(2, mdaSysCodeType.getCodeTypeName());
/*  91 */         ps.setString(3, mdaSysCodeType.getCodeTypeDesc());
/*  92 */         ps.setString(4, mdaSysCodeType.getIsSysType());
/*  93 */         return ps;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public MdaSysCodeType getCodeTypeById(String codeTypeId)
/*     */   {
/* 104 */     String sql = "select code_type_id, code_type_name, code_type_desc, is_sys_type from mda_sys_code_type where code_type_id=?";
/* 105 */     List ul = this.template.query(sql, new Object[] { codeTypeId }, new BeanPropertyRowMapper(MdaSysCodeType.class));
/*     */ 
/* 107 */     if (ul.size() > 0) {
/* 108 */       return (MdaSysCodeType)ul.get(0);
/*     */     }
/*     */ 
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */   public List<MdaSysCodeType> getCodeTypeListByName(String typeName)
/*     */   {
/* 120 */     String sql = "select code_type_id, code_type_name, code_type_desc, is_sys_type from mda_sys_code_type where 1=1";
/* 121 */     if (StringUtil.isNotEmpty(typeName)) {
/* 122 */       sql = sql + " and code_type_name like '%" + typeName + "%'";
/*     */     }
/* 124 */     return this.template.query(sql, new BeanPropertyRowMapper(MdaSysCodeType.class));
/*     */   }
/*     */ 
/*     */   public void removeCodeTypeById(String codeTypeId)
/*     */   {
/* 134 */     String sql = "delete from mda_sys_code_type where code_type_id=?";
/* 135 */     this.template.update(sql, new Object[] { codeTypeId });
/*     */   }
/*     */ 
/*     */   public void updateCodeType(MdaSysCodeType mdaSysCodeType)
/*     */   {
/* 144 */     String sql = "update mda_sys_code_type set code_type_name=?, code_type_desc=?, is_sys_type=? where code_type_id=?";
/* 145 */     this.template.update(sql, new Object[] { mdaSysCodeType.getCodeTypeName(), mdaSysCodeType.getCodeTypeDesc(), mdaSysCodeType.getIsSysType(), mdaSysCodeType.getCodeTypeId() });
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.dao.impl.MdaSysCodeTypeDaoImpl
 * JD-Core Version:    0.6.2
 */
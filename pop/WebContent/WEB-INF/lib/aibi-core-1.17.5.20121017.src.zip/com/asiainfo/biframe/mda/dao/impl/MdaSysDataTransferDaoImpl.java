/*     */ package com.asiainfo.biframe.mda.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.mda.dao.IMdaSysDataTransferDao;
/*     */ import com.asiainfo.biframe.mda.model.MdaSysDataTransfer;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.BeanPropertyRowMapper;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ 
/*     */ public class MdaSysDataTransferDaoImpl extends JdbcTemplateDaoSupport
/*     */   implements IMdaSysDataTransferDao
/*     */ {
/*     */   public void createDataTransfer(final MdaSysDataTransfer sysDT)
/*     */   {
/*  46 */     String insertSql = "insert into mda_sys_data_transfer(dim_trans_id, dim_trans_name, dim_trans_flag, dim_table_id, dim_table_where_cond, code_type_id, dim_trans_sql) values(?,?,?,?,?,?,?)";
/*  47 */     this.template.update(new PreparedStatementCreator()
/*     */     {
/*     */       public PreparedStatement createPreparedStatement(Connection con) throws SQLException
/*     */       {
/*  51 */         PreparedStatement ps = con.prepareStatement("insert into mda_sys_data_transfer(dim_trans_id, dim_trans_name, dim_trans_flag, dim_table_id, dim_table_where_cond, code_type_id, dim_trans_sql) values(?,?,?,?,?,?,?)");
/*  52 */         ps.setString(1, sysDT.getDimTransId());
/*  53 */         ps.setString(2, sysDT.getDimTransName());
/*  54 */         ps.setString(3, sysDT.getDimTransFlag());
/*  55 */         ps.setString(4, sysDT.getDimTableId());
/*  56 */         ps.setString(5, sysDT.getDimTableWhere());
/*  57 */         ps.setString(6, sysDT.getCodeTypeId());
/*  58 */         ps.setString(7, sysDT.getDimTransSql());
/*  59 */         return ps;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void batchCreateDataTransfer(final List<MdaSysDataTransfer> dataTransfers)
/*     */   {
/*  69 */     if ((dataTransfers != null) && (dataTransfers.size() > 0)) {
/*  70 */       String insertSql = "insert into mda_sys_data_transfer(dim_trans_id, dim_trans_name, dim_trans_flag, dim_table_id, dim_table_where_cond, code_type_id, dim_trans_sql) values(?,?,?,?,?,?,?)";
/*  71 */       this.template.batchUpdate("insert into mda_sys_data_transfer(dim_trans_id, dim_trans_name, dim_trans_flag, dim_table_id, dim_table_where_cond, code_type_id, dim_trans_sql) values(?,?,?,?,?,?,?)", new BatchPreparedStatementSetter()
/*     */       {
/*     */         public void setValues(PreparedStatement ps, int i) throws SQLException
/*     */         {
/*  75 */           MdaSysDataTransfer sysDT = (MdaSysDataTransfer)dataTransfers.get(i);
/*  76 */           ps.setString(1, sysDT.getDimTransId());
/*  77 */           ps.setString(2, sysDT.getDimTransName());
/*  78 */           ps.setString(3, sysDT.getDimTransFlag());
/*  79 */           ps.setString(4, sysDT.getDimTableId());
/*  80 */           ps.setString(5, sysDT.getDimTableWhere());
/*  81 */           ps.setString(6, sysDT.getCodeTypeId());
/*  82 */           ps.setString(7, sysDT.getDimTransSql());
/*     */         }
/*     */ 
/*     */         public int getBatchSize() {
/*  86 */           return dataTransfers.size();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ 
/*     */   public MdaSysDataTransfer getDataTransferById(String dataTransferId)
/*     */   {
/*  96 */     String sql = "select dim_trans_id, dim_trans_name, dim_trans_flag, dim_table_id, dim_table_where_cond, code_type_id, dim_trans_sql from mda_sys_data_transfer where dim_trans_id=?";
/*  97 */     List ul = this.template.query(sql, new Object[] { dataTransferId }, new BeanPropertyRowMapper(MdaSysDataTransfer.class));
/*     */ 
/*  99 */     if (ul.size() > 0) {
/* 100 */       return (MdaSysDataTransfer)ul.get(0);
/*     */     }
/*     */ 
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */   public List<MdaSysDataTransfer> getDataTransferList()
/*     */   {
/* 110 */     String sql = "select dim_trans_id, dim_trans_name, dim_trans_flag, dim_table_id, dim_table_where_cond, code_type_id, dim_trans_sql from mda_sys_data_transfer";
/* 111 */     return this.template.query(sql, new BeanPropertyRowMapper(MdaSysDataTransfer.class));
/*     */   }
/*     */ 
/*     */   public void removeDataTransferById(String dataTransferId)
/*     */   {
/* 119 */     String sql = "delete from mda_sys_data_transfer where dim_trans_id=?";
/* 120 */     this.template.update(sql, new Object[] { dataTransferId });
/*     */   }
/*     */ 
/*     */   public void updateDataTransfer(MdaSysDataTransfer msd)
/*     */   {
/* 127 */     String sql = "update mda_sys_DataTransfer set dim_trans_name=?, dim_trans_flag=?, dim_table_id=?, dim_table_where_cond=?, code_type_id=?, dim_trans_sql=? where dim_trans_id=?";
/* 128 */     this.template.update(sql, new Object[] { msd.getDimTransName(), msd.getDimTransFlag(), msd.getDimTableId(), msd.getDimTableWhere(), msd.getCodeTypeId(), msd.getDimTransSql(), msd.getDimTransId() });
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.dao.impl.MdaSysDataTransferDaoImpl
 * JD-Core Version:    0.6.2
 */
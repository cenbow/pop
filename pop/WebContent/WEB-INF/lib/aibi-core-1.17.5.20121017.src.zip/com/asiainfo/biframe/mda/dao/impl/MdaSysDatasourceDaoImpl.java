/*     */ package com.asiainfo.biframe.mda.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.mda.dao.IMdaSysDatasourceDao;
/*     */ import com.asiainfo.biframe.mda.model.MdaSysDatasource;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.BeanPropertyRowMapper;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ 
/*     */ public class MdaSysDatasourceDaoImpl extends JdbcTemplateDaoSupport
/*     */   implements IMdaSysDatasourceDao
/*     */ {
/*     */   public void createDatasource(final MdaSysDatasource sysDs)
/*     */   {
/*  47 */     String insertSql = "insert into mda_sys_datasource(datasource_id, datasource_name, datasource_jndi, datasource_charset) values(?,?,?,?)";
/*  48 */     this.template.update(new PreparedStatementCreator()
/*     */     {
/*     */       public PreparedStatement createPreparedStatement(Connection con) throws SQLException
/*     */       {
/*  52 */         PreparedStatement ps = con.prepareStatement("insert into mda_sys_datasource(datasource_id, datasource_name, datasource_jndi, datasource_charset) values(?,?,?,?)");
/*  53 */         ps.setString(1, sysDs.getDatasourceId());
/*  54 */         ps.setString(2, sysDs.getDatasourceName());
/*  55 */         ps.setString(3, sysDs.getDatasourceJndi());
/*  56 */         ps.setString(4, sysDs.getDatasourceCharset());
/*  57 */         return ps;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void batchCreateDatasource(final List<MdaSysDatasource> datasources)
/*     */   {
/*  68 */     if ((datasources != null) && (datasources.size() > 0)) {
/*  69 */       String insertSql = "insert into mda_sys_datasource(datasource_id, datasource_name, datasource_jndi, datasource_charset) values(?,?,?,?)";
/*  70 */       this.template.batchUpdate("insert into mda_sys_datasource(datasource_id, datasource_name, datasource_jndi, datasource_charset) values(?,?,?,?)", new BatchPreparedStatementSetter()
/*     */       {
/*     */         public void setValues(PreparedStatement ps, int i) throws SQLException
/*     */         {
/*  74 */           MdaSysDatasource sysDs = (MdaSysDatasource)datasources.get(i);
/*  75 */           ps.setString(1, sysDs.getDatasourceId());
/*  76 */           ps.setString(2, sysDs.getDatasourceName());
/*  77 */           ps.setString(3, sysDs.getDatasourceJndi());
/*  78 */           ps.setString(4, sysDs.getDatasourceCharset());
/*     */         }
/*     */ 
/*     */         public int getBatchSize() {
/*  82 */           return datasources.size();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ 
/*     */   public MdaSysDatasource getDatasourceById(String datasourceId)
/*     */   {
/*  94 */     String sql = "select datasource_id, datasource_name, datasource_jndi, datasource_charset from mda_sys_datasource where datasource_id=?";
/*  95 */     List ul = this.template.query(sql, new Object[] { datasourceId }, new BeanPropertyRowMapper(MdaSysDatasource.class));
/*     */ 
/*  97 */     if (ul.size() > 0) {
/*  98 */       return (MdaSysDatasource)ul.get(0);
/*     */     }
/*     */ 
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */   public List<MdaSysDatasource> getDatasourceList(String datasourceName, String jndi)
/*     */   {
/* 110 */     String sql = "select datasource_id, datasource_name, datasource_jndi, datasource_charset from mda_sys_datasource where 1=1";
/* 111 */     if (StringUtil.isNotEmpty(datasourceName)) {
/* 112 */       sql = sql + " and datasource_name like '%" + datasourceName + "%'";
/*     */     }
/* 114 */     if (StringUtil.isNotEmpty(jndi)) {
/* 115 */       sql = sql + " and datasource_jndi like '%" + jndi + "%'";
/*     */     }
/* 117 */     return this.template.query(sql, new BeanPropertyRowMapper(MdaSysDatasource.class));
/*     */   }
/*     */ 
/*     */   public void removeDatasourceById(String datasourceId)
/*     */   {
/* 127 */     String sql = "delete from mda_sys_datasource where datasource_id=?";
/* 128 */     this.template.update(sql, new Object[] { datasourceId });
/*     */   }
/*     */ 
/*     */   public void updateDatasource(MdaSysDatasource msd)
/*     */   {
/* 137 */     String sql = "update mda_sys_datasource set datasource_name=?, datasource_jndi=?, datasource_charset=? where datasource_id=?";
/* 138 */     this.template.update(sql, new Object[] { msd.getDatasourceName(), msd.getDatasourceJndi(), msd.getDatasourceCharset(), msd.getDatasourceId() });
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.dao.impl.MdaSysDatasourceDaoImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.mda.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class MdaSysCode
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -5234684176807928406L;
/*     */   private String codeDefineId;
/*     */   private String codeTypeId;
/*     */   private String codeId;
/*     */   private String codeValue;
/*     */   private String codeDesc;
/*     */   private String displayOrder;
/*     */ 
/*     */   public MdaSysCode()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MdaSysCode(String codeDefineId, String codeTypeId, String codeId, String codeValue, String codeDesc, String displayOrder)
/*     */   {
/*  58 */     this.codeDefineId = codeDefineId;
/*  59 */     this.codeTypeId = codeTypeId;
/*  60 */     this.codeId = codeId;
/*  61 */     this.codeValue = codeValue;
/*  62 */     this.codeDesc = codeDesc;
/*  63 */     this.displayOrder = displayOrder;
/*     */   }
/*     */ 
/*     */   public String getCodeDefineId()
/*     */   {
/*  73 */     return this.codeDefineId;
/*     */   }
/*     */ 
/*     */   public void setCodeDefineId(String codeDefineId)
/*     */   {
/*  83 */     this.codeDefineId = codeDefineId;
/*     */   }
/*     */ 
/*     */   public String getCodeTypeId()
/*     */   {
/*  93 */     return this.codeTypeId;
/*     */   }
/*     */ 
/*     */   public void setCodeTypeId(String codeTypeId)
/*     */   {
/* 103 */     this.codeTypeId = codeTypeId;
/*     */   }
/*     */ 
/*     */   public String getCodeId()
/*     */   {
/* 113 */     return this.codeId;
/*     */   }
/*     */ 
/*     */   public void setCodeId(String codeId)
/*     */   {
/* 123 */     this.codeId = codeId;
/*     */   }
/*     */ 
/*     */   public String getCodeValue()
/*     */   {
/* 133 */     return this.codeValue;
/*     */   }
/*     */ 
/*     */   public void setCodeValue(String codeValue)
/*     */   {
/* 143 */     this.codeValue = codeValue;
/*     */   }
/*     */ 
/*     */   public String getCodeDesc()
/*     */   {
/* 153 */     return this.codeDesc;
/*     */   }
/*     */ 
/*     */   public void setCodeDesc(String codeDesc)
/*     */   {
/* 163 */     this.codeDesc = codeDesc;
/*     */   }
/*     */ 
/*     */   public String getDisplayOrder()
/*     */   {
/* 173 */     return this.displayOrder;
/*     */   }
/*     */ 
/*     */   public void setDisplayOrder(String displayOrder)
/*     */   {
/* 183 */     this.displayOrder = displayOrder;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.model.MdaSysCode
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.mda.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class MdaSysCodeType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6465535212747098417L;
/*     */   private String codeTypeId;
/*     */   private String codeTypeName;
/*     */   private String codeTypeDesc;
/*     */   private String isSysType;
/*     */ 
/*     */   public MdaSysCodeType()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MdaSysCodeType(String codeTypeId, String codeTypeName, String codeTypeDesc, String isSysType)
/*     */   {
/*  53 */     this.codeTypeId = codeTypeId;
/*  54 */     this.codeTypeName = codeTypeName;
/*  55 */     this.codeTypeDesc = codeTypeDesc;
/*  56 */     this.isSysType = isSysType;
/*     */   }
/*     */ 
/*     */   public String getCodeTypeId()
/*     */   {
/*  66 */     return this.codeTypeId;
/*     */   }
/*     */ 
/*     */   public void setCodeTypeId(String codeTypeId)
/*     */   {
/*  76 */     this.codeTypeId = codeTypeId;
/*     */   }
/*     */ 
/*     */   public String getCodeTypeName()
/*     */   {
/*  86 */     return this.codeTypeName;
/*     */   }
/*     */ 
/*     */   public void setCodeTypeName(String codeTypeName)
/*     */   {
/*  96 */     this.codeTypeName = codeTypeName;
/*     */   }
/*     */ 
/*     */   public String getCodeTypeDesc()
/*     */   {
/* 106 */     return this.codeTypeDesc;
/*     */   }
/*     */ 
/*     */   public void setCodeTypeDesc(String codeTypeDesc)
/*     */   {
/* 116 */     this.codeTypeDesc = codeTypeDesc;
/*     */   }
/*     */ 
/*     */   public String getIsSysType()
/*     */   {
/* 126 */     return this.isSysType;
/*     */   }
/*     */ 
/*     */   public void setIsSysType(String isSysType)
/*     */   {
/* 136 */     this.isSysType = isSysType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.model.MdaSysCodeType
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.mda.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class MdaSysDataTransfer
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 938530848646771881L;
/*     */   private String dimTransId;
/*     */   private String dimTransName;
/*     */   private String dimTransFlag;
/*     */   private String dimTableId;
/*     */   private String dimTableWhere;
/*     */   private String codeTypeId;
/*     */   private String dimTransSql;
/*     */ 
/*     */   public String getDimTransId()
/*     */   {
/*  61 */     return this.dimTransId;
/*     */   }
/*     */ 
/*     */   public void setDimTransId(String dimTransId)
/*     */   {
/*  71 */     this.dimTransId = dimTransId;
/*     */   }
/*     */ 
/*     */   public String getDimTransName()
/*     */   {
/*  81 */     return this.dimTransName;
/*     */   }
/*     */ 
/*     */   public void setDimTransName(String dimTransName)
/*     */   {
/*  91 */     this.dimTransName = dimTransName;
/*     */   }
/*     */ 
/*     */   public String getDimTransFlag()
/*     */   {
/* 101 */     return this.dimTransFlag;
/*     */   }
/*     */ 
/*     */   public void setDimTransFlag(String dimTransFlag)
/*     */   {
/* 111 */     this.dimTransFlag = dimTransFlag;
/*     */   }
/*     */ 
/*     */   public String getDimTableId()
/*     */   {
/* 121 */     return this.dimTableId;
/*     */   }
/*     */ 
/*     */   public void setDimTableId(String dimTableId)
/*     */   {
/* 131 */     this.dimTableId = dimTableId;
/*     */   }
/*     */ 
/*     */   public String getDimTableWhere()
/*     */   {
/* 141 */     return this.dimTableWhere;
/*     */   }
/*     */ 
/*     */   public void setDimTableWhere(String dimTableWhere)
/*     */   {
/* 151 */     this.dimTableWhere = dimTableWhere;
/*     */   }
/*     */ 
/*     */   public String getCodeTypeId()
/*     */   {
/* 161 */     return this.codeTypeId;
/*     */   }
/*     */ 
/*     */   public void setCodeTypeId(String codeTypeId)
/*     */   {
/* 171 */     this.codeTypeId = codeTypeId;
/*     */   }
/*     */ 
/*     */   public String getDimTransSql()
/*     */   {
/* 181 */     return this.dimTransSql;
/*     */   }
/*     */ 
/*     */   public void setDimTransSql(String dimTransSql)
/*     */   {
/* 191 */     this.dimTransSql = dimTransSql;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.model.MdaSysDataTransfer
 * JD-Core Version:    0.6.2
 */
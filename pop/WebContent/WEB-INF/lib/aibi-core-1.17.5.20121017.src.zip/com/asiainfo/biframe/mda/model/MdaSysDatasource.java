/*    */ package com.asiainfo.biframe.mda.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MdaSysDatasource
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 9066718014981344376L;
/*    */   private String datasourceId;
/*    */   private String datasourceName;
/*    */   private String datasourceJndi;
/*    */   private String datasourceCharset;
/*    */ 
/*    */   public MdaSysDatasource()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MdaSysDatasource(String datasourceId, String datasourceName, String datasourceJndi)
/*    */   {
/* 48 */     this.datasourceId = datasourceId;
/* 49 */     this.datasourceName = datasourceName;
/* 50 */     this.datasourceJndi = datasourceJndi;
/*    */   }
/*    */ 
/*    */   public MdaSysDatasource(String datasourceId, String datasourceName, String datasourceJndi, String datasourceCharset)
/*    */   {
/* 55 */     this.datasourceId = datasourceId;
/* 56 */     this.datasourceName = datasourceName;
/* 57 */     this.datasourceJndi = datasourceJndi;
/* 58 */     this.datasourceCharset = datasourceCharset;
/*    */   }
/*    */ 
/*    */   public String getDatasourceId() {
/* 62 */     return this.datasourceId;
/*    */   }
/*    */ 
/*    */   public void setDatasourceId(String datasourceId) {
/* 66 */     this.datasourceId = datasourceId;
/*    */   }
/*    */ 
/*    */   public String getDatasourceName() {
/* 70 */     return this.datasourceName;
/*    */   }
/*    */ 
/*    */   public void setDatasourceName(String datasourceName) {
/* 74 */     this.datasourceName = datasourceName;
/*    */   }
/*    */ 
/*    */   public String getDatasourceJndi() {
/* 78 */     return this.datasourceJndi;
/*    */   }
/*    */ 
/*    */   public void setDatasourceJndi(String datasourceJndi) {
/* 82 */     this.datasourceJndi = datasourceJndi;
/*    */   }
/*    */ 
/*    */   public String getDatasourceCharset() {
/* 86 */     return this.datasourceCharset;
/*    */   }
/*    */ 
/*    */   public void setDatasourceCharset(String datasourceCharset) {
/* 90 */     this.datasourceCharset = datasourceCharset;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.model.MdaSysDatasource
 * JD-Core Version:    0.6.2
 */
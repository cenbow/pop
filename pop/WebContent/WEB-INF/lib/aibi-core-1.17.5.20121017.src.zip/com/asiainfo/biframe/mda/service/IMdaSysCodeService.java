package com.asiainfo.biframe.mda.service;

import com.asiainfo.biframe.mda.model.MdaSysCode;
import java.util.List;

public abstract interface IMdaSysCodeService
{
  public abstract void createCode(MdaSysCode paramMdaSysCode);

  public abstract void batchCreateCode(List<MdaSysCode> paramList);

  public abstract MdaSysCode getCodeById(String paramString);

  public abstract List<MdaSysCode> getCodeListByType(String paramString);

  public abstract void updateCode(MdaSysCode paramMdaSysCode);

  public abstract void removeCodeById(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.service.IMdaSysCodeService
 * JD-Core Version:    0.6.2
 */
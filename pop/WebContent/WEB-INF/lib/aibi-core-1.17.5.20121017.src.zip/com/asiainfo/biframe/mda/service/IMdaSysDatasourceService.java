package com.asiainfo.biframe.mda.service;

import com.asiainfo.biframe.mda.model.MdaSysDatasource;
import java.util.List;

public abstract interface IMdaSysDatasourceService
{
  public abstract void createDatasource(MdaSysDatasource paramMdaSysDatasource);

  public abstract void batchCreateDatasource(List<MdaSysDatasource> paramList);

  public abstract MdaSysDatasource getDatasourceById(String paramString);

  public abstract List<MdaSysDatasource> getDatasourceList(String paramString1, String paramString2);

  public abstract void updateDatasource(MdaSysDatasource paramMdaSysDatasource);

  public abstract void removeDatasourceById(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.service.IMdaSysDatasourceService
 * JD-Core Version:    0.6.2
 */
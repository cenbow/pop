/*     */ package com.asiainfo.biframe.mda.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.mda.dao.IMdaSysCodeDao;
/*     */ import com.asiainfo.biframe.mda.model.MdaSysCode;
/*     */ import com.asiainfo.biframe.mda.service.IMdaSysCodeService;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.List;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class MdaSysCodeServiceImpl
/*     */   implements IMdaSysCodeService
/*     */ {
/*  48 */   private Log log = LogFactory.getLog(MdaSysCodeServiceImpl.class);
/*     */   IMdaSysCodeDao mdaSysCodeDao;
/*     */ 
/*     */   public IMdaSysCodeDao getMdaSysCodeDao()
/*     */   {
/*  58 */     return this.mdaSysCodeDao;
/*     */   }
/*     */ 
/*     */   public void setMdaSysCodeDao(IMdaSysCodeDao mdaSysCodeDao)
/*     */   {
/*  68 */     this.mdaSysCodeDao = mdaSysCodeDao;
/*     */   }
/*     */ 
/*     */   public void batchCreateCode(List<MdaSysCode> mdaSysCodes)
/*     */   {
/*  77 */     if (CollectionUtils.isEmpty(mdaSysCodes)) {
/*  78 */       this.log.info("mdaSysCodes is empty can not to save");
/*  79 */       return;
/*     */     }
/*  81 */     this.mdaSysCodeDao.batchCreateCode(mdaSysCodes);
/*     */   }
/*     */ 
/*     */   public void createCode(MdaSysCode mdaSysCode)
/*     */   {
/*  90 */     if (StringUtil.isEmpty(mdaSysCode)) {
/*  91 */       this.log.info("mdaSysCode is empty can not to save");
/*  92 */       return;
/*     */     }
/*  94 */     this.mdaSysCodeDao.createCode(mdaSysCode);
/*     */   }
/*     */ 
/*     */   public MdaSysCode getCodeById(String codeDefineId)
/*     */   {
/* 103 */     if (StringUtil.isEmpty(codeDefineId)) {
/* 104 */       this.log.info("codeDefineId is empty can not to get data by codeDefineId");
/* 105 */       return null;
/*     */     }
/* 107 */     return this.mdaSysCodeDao.getCodeById(codeDefineId);
/*     */   }
/*     */ 
/*     */   public List<MdaSysCode> getCodeListByType(String type)
/*     */   {
/* 116 */     return this.mdaSysCodeDao.getCodeListByType(type);
/*     */   }
/*     */ 
/*     */   public void removeCodeById(String codeDefineId)
/*     */   {
/* 125 */     if (StringUtil.isEmpty(codeDefineId)) {
/* 126 */       this.log.info("codeDefineId is empty can not to delete data by codeDefineId");
/* 127 */       return;
/*     */     }
/* 129 */     this.mdaSysCodeDao.removeCodeById(codeDefineId);
/*     */   }
/*     */ 
/*     */   public void updateCode(MdaSysCode mdaSysCode)
/*     */   {
/* 138 */     if (StringUtil.isEmpty(mdaSysCode)) {
/* 139 */       this.log.info("mdaSysCode is empty can not to update");
/* 140 */       return;
/*     */     }
/* 142 */     this.mdaSysCodeDao.updateCode(mdaSysCode);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.service.impl.MdaSysCodeServiceImpl
 * JD-Core Version:    0.6.2
 */
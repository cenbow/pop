/*     */ package com.asiainfo.biframe.mda.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.mda.dao.IMdaSysCodeTypeDao;
/*     */ import com.asiainfo.biframe.mda.model.MdaSysCodeType;
/*     */ import com.asiainfo.biframe.mda.service.IMdaSysCodeTypeService;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.List;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class MdaSysCodeTypeServiceImpl
/*     */   implements IMdaSysCodeTypeService
/*     */ {
/*  48 */   private Log log = LogFactory.getLog(MdaSysCodeTypeServiceImpl.class);
/*     */   IMdaSysCodeTypeDao mdaSysCodeTypeDao;
/*     */ 
/*     */   public IMdaSysCodeTypeDao getMdaSysCodeTypeDao()
/*     */   {
/*  58 */     return this.mdaSysCodeTypeDao;
/*     */   }
/*     */ 
/*     */   public void setMdaSysCodeTypeDao(IMdaSysCodeTypeDao mdaSysCodeTypeDao)
/*     */   {
/*  68 */     this.mdaSysCodeTypeDao = mdaSysCodeTypeDao;
/*     */   }
/*     */ 
/*     */   public void batchCreateCodeType(List<MdaSysCodeType> mdaSysCodeTypes)
/*     */   {
/*  77 */     if (CollectionUtils.isEmpty(mdaSysCodeTypes)) {
/*  78 */       this.log.info("mdaSysCodeTypes is empty can not to save");
/*  79 */       return;
/*     */     }
/*  81 */     this.mdaSysCodeTypeDao.batchCreateCodeType(mdaSysCodeTypes);
/*     */   }
/*     */ 
/*     */   public void createCodeType(MdaSysCodeType mdaSysCodeType)
/*     */   {
/*  90 */     if (StringUtil.isEmpty(mdaSysCodeType)) {
/*  91 */       this.log.info("mdaSysCodeType is empty can not to save");
/*  92 */       return;
/*     */     }
/*  94 */     this.mdaSysCodeTypeDao.createCodeType(mdaSysCodeType);
/*     */   }
/*     */ 
/*     */   public MdaSysCodeType getCodeTypeById(String codeTypeId)
/*     */   {
/* 103 */     if (StringUtil.isEmpty(codeTypeId)) {
/* 104 */       this.log.info("codeTypeId is empty can not to get data by codeTypeId");
/* 105 */       return null;
/*     */     }
/* 107 */     return this.mdaSysCodeTypeDao.getCodeTypeById(codeTypeId);
/*     */   }
/*     */ 
/*     */   public List<MdaSysCodeType> getCodeTypeListByName(String typeName)
/*     */   {
/* 116 */     return this.mdaSysCodeTypeDao.getCodeTypeListByName(typeName);
/*     */   }
/*     */ 
/*     */   public void removeCodeTypeById(String codeTypeId)
/*     */   {
/* 125 */     if (StringUtil.isEmpty(codeTypeId)) {
/* 126 */       this.log.info("codeTypeId is empty can not to delete data by codeTypeId");
/* 127 */       return;
/*     */     }
/* 129 */     this.mdaSysCodeTypeDao.removeCodeTypeById(codeTypeId);
/*     */   }
/*     */ 
/*     */   public void updateCodeType(MdaSysCodeType mdaSysCodeType)
/*     */   {
/* 138 */     if (StringUtil.isEmpty(mdaSysCodeType)) {
/* 139 */       this.log.info("mdaSysCodeType is empty can not to update");
/* 140 */       return;
/*     */     }
/* 142 */     this.mdaSysCodeTypeDao.updateCodeType(mdaSysCodeType);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.service.impl.MdaSysCodeTypeServiceImpl
 * JD-Core Version:    0.6.2
 */
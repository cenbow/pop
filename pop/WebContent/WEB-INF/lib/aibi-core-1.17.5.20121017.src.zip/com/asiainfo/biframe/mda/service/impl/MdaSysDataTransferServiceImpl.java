/*     */ package com.asiainfo.biframe.mda.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.mda.dao.IMdaSysDataTransferDao;
/*     */ import com.asiainfo.biframe.mda.model.MdaSysDataTransfer;
/*     */ import com.asiainfo.biframe.mda.service.IMdaSysDataTransferService;
/*     */ import java.util.List;
/*     */ 
/*     */ public class MdaSysDataTransferServiceImpl
/*     */   implements IMdaSysDataTransferService
/*     */ {
/*     */   private IMdaSysDataTransferDao mdaSysDataTransferDao;
/*     */ 
/*     */   public void batchCreateDataTransfer(List<MdaSysDataTransfer> mdaSysDataTransfers)
/*     */   {
/*  53 */     this.mdaSysDataTransferDao.batchCreateDataTransfer(mdaSysDataTransfers);
/*     */   }
/*     */ 
/*     */   public void createDataTransfer(MdaSysDataTransfer mdaSysDataTransfer)
/*     */   {
/*  62 */     this.mdaSysDataTransferDao.createDataTransfer(mdaSysDataTransfer);
/*     */   }
/*     */ 
/*     */   public MdaSysDataTransfer getDataTransferById(String DataTransferId)
/*     */   {
/*  71 */     return this.mdaSysDataTransferDao.getDataTransferById(DataTransferId);
/*     */   }
/*     */ 
/*     */   public List<MdaSysDataTransfer> getDataTransferList()
/*     */   {
/*  80 */     return this.mdaSysDataTransferDao.getDataTransferList();
/*     */   }
/*     */ 
/*     */   public void removeDataTransferById(String dataTransferId)
/*     */   {
/*  89 */     this.mdaSysDataTransferDao.removeDataTransferById(dataTransferId);
/*     */   }
/*     */ 
/*     */   public void updateDataTransfer(MdaSysDataTransfer mdaSysDataTransfer)
/*     */   {
/*  98 */     this.mdaSysDataTransferDao.updateDataTransfer(mdaSysDataTransfer);
/*     */   }
/*     */ 
/*     */   public IMdaSysDataTransferDao getMdaSysDataTransferDao()
/*     */   {
/* 108 */     return this.mdaSysDataTransferDao;
/*     */   }
/*     */ 
/*     */   public void setMdaSysDataTransferDao(IMdaSysDataTransferDao mdaSysDataTransferDao)
/*     */   {
/* 119 */     this.mdaSysDataTransferDao = mdaSysDataTransferDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.service.impl.MdaSysDataTransferServiceImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.mda.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.mda.dao.IMdaSysDatasourceDao;
/*     */ import com.asiainfo.biframe.mda.model.MdaSysDatasource;
/*     */ import com.asiainfo.biframe.mda.service.IMdaSysDatasourceService;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.List;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class MdaSysDatasourceServiceImpl
/*     */   implements IMdaSysDatasourceService
/*     */ {
/*  48 */   private Log log = LogFactory.getLog(MdaSysDatasourceServiceImpl.class);
/*     */   IMdaSysDatasourceDao mdaSysDatasourceDao;
/*     */ 
/*     */   public void batchCreateDatasource(List<MdaSysDatasource> mdaSysDatasources)
/*     */   {
/*  57 */     if (CollectionUtils.isEmpty(mdaSysDatasources)) {
/*  58 */       this.log.info("mdaSysDatasources is empty can not to save");
/*  59 */       return;
/*     */     }
/*  61 */     this.mdaSysDatasourceDao.batchCreateDatasource(mdaSysDatasources);
/*     */   }
/*     */ 
/*     */   public void createDatasource(MdaSysDatasource mdaSysDatasource)
/*     */   {
/*  70 */     if (StringUtil.isEmpty(mdaSysDatasource)) {
/*  71 */       this.log.info("mdaSysDatasource is empty can not to save");
/*  72 */       return;
/*     */     }
/*  74 */     this.mdaSysDatasourceDao.createDatasource(mdaSysDatasource);
/*     */   }
/*     */ 
/*     */   public MdaSysDatasource getDatasourceById(String datasourceId)
/*     */   {
/*  83 */     if (StringUtil.isEmpty(datasourceId)) {
/*  84 */       this.log.info("datasourceId is empty can not to get data by datasourceId");
/*  85 */       return null;
/*     */     }
/*  87 */     return this.mdaSysDatasourceDao.getDatasourceById(datasourceId);
/*     */   }
/*     */ 
/*     */   public List<MdaSysDatasource> getDatasourceList(String datasourceName, String jndi)
/*     */   {
/*  96 */     return this.mdaSysDatasourceDao.getDatasourceList(datasourceName, jndi);
/*     */   }
/*     */ 
/*     */   public void removeDatasourceById(String datasourceId)
/*     */   {
/* 105 */     if (StringUtil.isEmpty(datasourceId)) {
/* 106 */       this.log.info("datasourceId is empty can not to delete data by datasourceId");
/* 107 */       return;
/*     */     }
/* 109 */     this.mdaSysDatasourceDao.removeDatasourceById(datasourceId);
/*     */   }
/*     */ 
/*     */   public void updateDatasource(MdaSysDatasource mdaSysDatasource)
/*     */   {
/* 118 */     if (StringUtil.isEmpty(mdaSysDatasource)) {
/* 119 */       this.log.info("mdaSysDatasource is empty can not to update");
/* 120 */       return;
/*     */     }
/* 122 */     this.mdaSysDatasourceDao.updateDatasource(mdaSysDatasource);
/*     */   }
/*     */ 
/*     */   public IMdaSysDatasourceDao getMdaSysDatasourceDao()
/*     */   {
/* 132 */     return this.mdaSysDatasourceDao;
/*     */   }
/*     */ 
/*     */   public void setMdaSysDatasourceDao(IMdaSysDatasourceDao mdaSysDatasourceDao)
/*     */   {
/* 142 */     this.mdaSysDatasourceDao = mdaSysDatasourceDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.mda.service.impl.MdaSysDatasourceServiceImpl
 * JD-Core Version:    0.6.2
 */
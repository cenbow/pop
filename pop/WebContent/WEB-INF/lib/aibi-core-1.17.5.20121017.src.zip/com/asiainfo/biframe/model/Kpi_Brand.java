/*     */ package com.asiainfo.biframe.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class Kpi_Brand
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 391403702830701393L;
/*  18 */   private int parent_brand_id = -2;
/*     */   private int brand_id;
/*     */   private String brand_name;
/*  24 */   private int use_tag = 0;
/*     */   private int sort_num;
/*     */ 
/*     */   public String getPrimaryKey()
/*     */   {
/*  37 */     return String.valueOf(this.brand_id);
/*     */   }
/*     */ 
/*     */   public int getSort_num()
/*     */   {
/*  44 */     return this.sort_num;
/*     */   }
/*     */ 
/*     */   public int getBrand_id()
/*     */   {
/*  51 */     return this.brand_id;
/*     */   }
/*     */ 
/*     */   public String getBrand_name()
/*     */   {
/*  58 */     return this.brand_name;
/*     */   }
/*     */ 
/*     */   public int getParent_brand_id()
/*     */   {
/*  65 */     return this.parent_brand_id;
/*     */   }
/*     */ 
/*     */   public int getUse_tag()
/*     */   {
/*  72 */     return this.use_tag;
/*     */   }
/*     */ 
/*     */   public void setSort_num(int i)
/*     */   {
/*  79 */     this.sort_num = i;
/*     */   }
/*     */ 
/*     */   public void setBrand_id(int i)
/*     */   {
/*  86 */     this.brand_id = i;
/*     */   }
/*     */ 
/*     */   public void setBrand_name(String string)
/*     */   {
/*  93 */     this.brand_name = string;
/*     */   }
/*     */ 
/*     */   public void setParent_brand_id(int i)
/*     */   {
/* 100 */     this.parent_brand_id = i;
/*     */   }
/*     */ 
/*     */   public void setUse_tag(int i)
/*     */   {
/* 107 */     this.use_tag = i;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.model.Kpi_Brand
 * JD-Core Version:    0.6.2
 */
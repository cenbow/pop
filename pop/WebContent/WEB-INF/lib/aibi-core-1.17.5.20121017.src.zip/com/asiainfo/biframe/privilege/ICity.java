package com.asiainfo.biframe.privilege;

public abstract interface ICity
{
  public abstract String getCityId();

  public abstract String getParentId();

  public abstract String getDmCityId();

  public abstract String getDmDeptId();

  public abstract String getDmCountyId();

  public abstract String getCityName();

  public abstract int getSortNum();

  public abstract String getDmTypeId();

  public abstract String getDmTypeCode();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.ICity
 * JD-Core Version:    0.6.2
 */
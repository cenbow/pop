package com.asiainfo.biframe.privilege;

import javax.xml.bind.annotation.XmlElement;

public abstract interface IMenuItem
{
  @XmlElement(name="menuId")
  public abstract Integer getMenuItemId();

  @XmlElement(name="menuName")
  public abstract String getMenuItemTitle();

  public abstract Integer getParentId();

  public abstract Integer getMenuType();

  public abstract String getUrl();

  public abstract Integer getAccessToken();

  public abstract String getUrlTarget();

  public abstract String getUrlPort();

  public abstract String getApplicationId();

  public abstract Integer getResourceType();

  public abstract String getResId();

  public abstract Integer getSortNum();

  public abstract boolean isFolderOrNot();

  public abstract String getOperationType();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IMenuItem
 * JD-Core Version:    0.6.2
 */
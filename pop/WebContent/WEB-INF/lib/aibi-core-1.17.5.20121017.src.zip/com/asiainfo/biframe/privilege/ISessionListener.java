package com.asiainfo.biframe.privilege;

import java.io.Serializable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSessionBindingListener;

public abstract interface ISessionListener extends HttpSessionBindingListener, Serializable
{
  public abstract void login(HttpServletRequest paramHttpServletRequest, String paramString1, String paramString2)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.ISessionListener
 * JD-Core Version:    0.6.2
 */
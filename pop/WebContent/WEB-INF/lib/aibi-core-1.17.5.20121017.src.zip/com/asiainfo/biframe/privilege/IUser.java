package com.asiainfo.biframe.privilege;

import javax.xml.bind.annotation.XmlElement;

public abstract interface IUser
{
  public abstract String getUserid();

  public abstract String getUsername();

  public abstract String getCityid();

  @XmlElement(name="deptId")
  public abstract int getDepartmentid();

  public abstract String getGroupId();

  public abstract String getEmail();

  public abstract String getMobilePhone();

  public abstract String getLoginId();

  public abstract String getDomainType();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUser
 * JD-Core Version:    0.6.2
 */
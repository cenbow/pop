package com.asiainfo.biframe.privilege;

public abstract interface IUserApplication
{
  public abstract String getApplicationId();

  public abstract String getApplicationName();

  public abstract String getNote();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserApplication
 * JD-Core Version:    0.6.2
 */
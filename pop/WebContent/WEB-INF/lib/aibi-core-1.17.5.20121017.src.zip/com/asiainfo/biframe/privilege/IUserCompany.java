package com.asiainfo.biframe.privilege;

import javax.xml.bind.annotation.XmlElement;

public abstract interface IUserCompany
{
  public abstract Integer getDeptid();

  @XmlElement(name="deptName")
  public abstract String getTitle();

  public abstract String getServiceCode();

  public abstract Integer getParentid();

  public abstract String getStatus();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserCompany
 * JD-Core Version:    0.6.2
 */
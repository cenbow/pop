package com.asiainfo.biframe.privilege;

public abstract interface IUserDuty
{
  public abstract int getDutyid();

  public abstract String getName();

  public abstract int getParentid();

  public abstract String getCityid();

  public abstract String getCityName();

  public abstract String getStatus();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserDuty
 * JD-Core Version:    0.6.2
 */
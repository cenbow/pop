package com.asiainfo.biframe.privilege;

public abstract interface IUserExt
{
  public abstract String getUserid();

  public abstract String getParam0();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserExt
 * JD-Core Version:    0.6.2
 */
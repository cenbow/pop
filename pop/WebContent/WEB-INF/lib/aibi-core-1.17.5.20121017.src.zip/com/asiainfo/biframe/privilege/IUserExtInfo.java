package com.asiainfo.biframe.privilege;

public abstract interface IUserExtInfo
{
  public abstract String getExtId();

  public abstract String getUserId();

  public abstract String getExtName();

  public abstract String getExtValue();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserExtInfo
 * JD-Core Version:    0.6.2
 */
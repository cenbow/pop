package com.asiainfo.biframe.privilege;

public abstract interface IUserGroup
{
  public abstract String getGroupid();

  public abstract String getGroupname();

  public abstract String getParentid();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserGroup
 * JD-Core Version:    0.6.2
 */
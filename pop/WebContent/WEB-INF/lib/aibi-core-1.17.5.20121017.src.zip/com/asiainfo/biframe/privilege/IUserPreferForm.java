package com.asiainfo.biframe.privilege;

public abstract interface IUserPreferForm
{
  public abstract String getUserId();

  public abstract String getPreferId();

  public abstract String getPreferValue();

  public abstract String getPreferValuedesc();

  public abstract String getNotes();

  public abstract String getPreferName();

  public abstract String getPreferKey();

  public abstract String getPreferKeyId();

  public abstract String getPreferKeyValue();

  public abstract long getHavePrivilege();

  public abstract long getSortNum();

  public abstract String getDb();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserPreferForm
 * JD-Core Version:    0.6.2
 */
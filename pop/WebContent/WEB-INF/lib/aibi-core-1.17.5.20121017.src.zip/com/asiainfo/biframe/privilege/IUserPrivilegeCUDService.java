package com.asiainfo.biframe.privilege;

import com.asiainfo.biframe.exception.ServiceException;
import java.io.PrintWriter;
import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public abstract interface IUserPrivilegeCUDService
{
  public abstract String createUser(IUser paramIUser, IUserExt paramIUserExt)
    throws ServiceException;

  public abstract void modifyUser(IUser paramIUser)
    throws ServiceException;

  public abstract void modifyUserExt(IUserExt paramIUserExt)
    throws ServiceException;

  public abstract void deleteUser(String paramString)
    throws ServiceException;

  public abstract void realDeleteUser(String paramString)
    throws ServiceException;

  public abstract void lockUser(String paramString)
    throws ServiceException;

  public abstract void unlockUser(String paramString)
    throws ServiceException;

  @Deprecated
  public abstract void modifyUserPw(IUser paramIUser, String paramString)
    throws ServiceException;

  public abstract void modifyUserPwd(IUser paramIUser, String paramString1, String paramString2)
    throws ServiceException;

  public abstract String createRole(IUserRole paramIUserRole)
    throws ServiceException;

  public abstract void modifyRole(IUserRole paramIUserRole)
    throws ServiceException;

  public abstract void deleteRole(String paramString)
    throws ServiceException;

  public abstract void realDeleteRole(String paramString)
    throws ServiceException;

  public abstract String createGroup(IUserGroup paramIUserGroup)
    throws ServiceException;

  public abstract void modifyGroup(IUserGroup paramIUserGroup)
    throws ServiceException;

  public abstract void deleteGroup(String paramString)
    throws ServiceException;

  public abstract void realDeleteGroup(String paramString)
    throws ServiceException;

  public abstract void saveGroupRoleMaps(List<IGroupRoleMap> paramList)
    throws ServiceException;

  public abstract String createCompany(IUserCompany paramIUserCompany)
    throws ServiceException;

  public abstract void modifyCompany(IUserCompany paramIUserCompany)
    throws ServiceException;

  public abstract void deleteCompany(String paramString)
    throws ServiceException;

  public abstract void realDeleteCompany(String paramString)
    throws ServiceException;

  public abstract void importUser(String paramString)
    throws ServiceException;

  public abstract void importGroup(String paramString)
    throws ServiceException;

  @WebMethod(exclude=true)
  public abstract void importRole(String paramString)
    throws ServiceException;

  @WebMethod(exclude=true)
  public abstract void importRight(String paramString)
    throws ServiceException;

  @WebMethod(exclude=true)
  public abstract void exportMatrixMenuData(PrintWriter paramPrintWriter)
    throws ServiceException;

  @WebMethod(exclude=true)
  public abstract void exportRightsData(PrintWriter paramPrintWriter, List<String> paramList)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserPrivilegeCUDService
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege;

import com.asiainfo.biframe.exception.ServiceException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import org.apache.struts.util.LabelValueBean;

@WebService
public abstract interface IUserPrivilegeService
{
  public abstract IUser getUser(String paramString)
    throws ServiceException;

  public abstract List<IUser> getUsersOfDepartment(int paramInt)
    throws ServiceException;

  public abstract List<IUser> getUsersByGroupId(String paramString)
    throws ServiceException;

  public abstract String getUserSensitiveLevel(String paramString)
    throws ServiceException;

  public abstract IUserGroup getGroupObject(String paramString)
    throws ServiceException;

  public abstract String getUserCurrentCity(String paramString)
    throws ServiceException;

  public abstract String getUserDmCity(String paramString1, String paramString2)
    throws ServiceException;

  public abstract IUserExt getUserExt(String paramString)
    throws ServiceException;

  public abstract boolean isAdminUser(String paramString)
    throws ServiceException;

  public abstract List<IUser> getMapUsers(String paramString1, int paramInt, String paramString2)
    throws ServiceException;

  public abstract String getDmCity(String paramString1, String paramString2, String paramString3, String paramString4)
    throws ServiceException;

  public abstract String getShowDmCity(String paramString1, String paramString2, String paramString3, String paramString4)
    throws ServiceException;

  public abstract List<IUserRight> getRight(String paramString, int paramInt1, int paramInt2)
    throws ServiceException;

  public abstract List<IUserRight> getRightByOperation(String paramString1, int paramInt1, int paramInt2, String paramString2)
    throws ServiceException;

  /** @deprecated */
  public abstract boolean haveRightByUserId(String paramString1, int paramInt1, int paramInt2, String paramString2)
    throws ServiceException;

  @WebMethod(operationName="haveRightByUserIdAndRight")
  public abstract boolean haveRightByUserId(String paramString, IUserRight paramIUserRight)
    throws ServiceException;

  /** @deprecated */
  public abstract List<LabelValueBean> getRoleType()
    throws ServiceException;

  public abstract List<LabelValueBean> getResourceTypeByRoleType(int paramInt)
    throws ServiceException;

  public abstract List<IUserRole> getAllRoles(String paramString, int paramInt1, int paramInt2)
    throws ServiceException;

  public abstract List<IUserGroup> getAllSubGroupsByUserId(String paramString)
    throws ServiceException;

  public abstract List<IUser> getAllSubUsersByUserId(String paramString)
    throws ServiceException;

  public abstract Collection<IUserApplication> getAllApplications()
    throws ServiceException;

  public abstract String getResourceName(int paramInt1, int paramInt2, String paramString)
    throws ServiceException;

  public abstract List<IUserPreferForm> getUserPreferList(String paramString)
    throws ServiceException;

  public abstract void saveUserPrefer(String paramString1, String paramString2, String paramString3)
    throws ServiceException;

  public abstract List<String> getPreferDescListByPreferType(String paramString1, String paramString2)
    throws ServiceException;

  public abstract List<IUser> getAllUsers()
    throws ServiceException;

  public abstract IUserGroup getUserGroupById(String paramString)
    throws ServiceException;

  public abstract List<IUserGroup> getValidChildGroups(String paramString)
    throws ServiceException;

  public abstract List<IUserGroup> getUserGroupByUserId(List<String> paramList)
    throws ServiceException;

  public abstract List<IUserGroup> getAllUserGroup()
    throws ServiceException;

  public abstract IUserRole getUserRoleById(String paramString)
    throws ServiceException;

  public abstract List<IUserRole> getAllUserRole()
    throws ServiceException;

  public abstract List<IUserRole> getUserRole(String paramString1, String paramString2)
    throws ServiceException;

  public abstract List<IGroupRoleMap> getGroupRoleMapList()
    throws ServiceException;

  public abstract IUserCompany getUserCompanyById(String paramString)
    throws ServiceException;

  public abstract List<IUserCompany> getUserCompanyByName(String paramString)
    throws ServiceException;

  public abstract List<IUserCompany> getAllUserCompany()
    throws ServiceException;

  public abstract ICity getCityByCityID(String paramString)
    throws ServiceException;

  public abstract List<ICity> getAllCity()
    throws ServiceException;

  public abstract IMenuItem getMeunItemById(Integer paramInteger)
    throws ServiceException;

  public abstract ISysResourceType getResourceTypeByRoleRes(int paramInt1, int paramInt2)
    throws ServiceException;

  public abstract IUserDuty getUserDutyById(String paramString)
    throws ServiceException;

  public abstract List<ICity> getCityByUser(String paramString)
    throws ServiceException;

  public abstract String getAllCityID(String paramString, boolean paramBoolean)
    throws ServiceException;

  public abstract List<IMenuItem> getAllMenuItem(String paramString)
    throws ServiceException;

  public abstract List<ICity> getSubCitysById(String paramString)
    throws ServiceException;

  public abstract List<IUserCompany> getSubCompanyById(String paramString)
    throws ServiceException;

  public abstract List<IMenuItem> getSubMenuItemById(Integer paramInteger, String paramString, boolean paramBoolean);

  public abstract boolean isPwdNeedChange(String paramString);

  public abstract boolean isPwdChangedByOthers(String paramString);

  public abstract boolean isUserLegal(String paramString1, String paramString2);

  public abstract long getUserAmount();

  public abstract List<IUser> getUsersByPage(String paramString1, String paramString2);

  public abstract IUserCompany getUserDept(String paramString)
    throws ServiceException;

  @WebMethod(operationName="getRights")
  public abstract List<IUserRight> getRight(String paramString, int paramInt)
    throws ServiceException;

  public abstract boolean haveOperRight(String paramString1, String paramString2, String paramString3);

  public abstract List<IUserRight> getPrivacyRights(String paramString);

  @WebMethod(operationName="haveRightOrNot")
  public abstract boolean haveRightByUserId(String paramString1, int paramInt, String paramString2)
    throws ServiceException;

  public abstract boolean haveOperateRight(String paramString1, int paramInt, String paramString2, String paramString3)
    throws ServiceException;

  public abstract List<IUser> getUserList(List<String> paramList)
    throws ServiceException;

  public abstract void saveRight(String paramString1, int paramInt1, int paramInt2, String paramString2, int paramInt3, String paramString3)
    throws ServiceException;

  public abstract String doCreateApply(String paramString1, String paramString2, String paramString3, String paramString4, List<IUserRight> paramList)
    throws ServiceException;

  public abstract void doAffirmApply(String paramString1, String paramString2)
    throws ServiceException;

  public abstract Collection<IUserRight> getTempRightsByApplyId(String paramString)
    throws ServiceException;

  public abstract IUserRightApply getApplyById(String paramString)
    throws ServiceException;

  public abstract List<IUserExtInfo> getUserExtInfo(String paramString)
    throws Exception;

  public abstract String encryption(String paramString);

  @WebMethod(exclude=true)
  public abstract String decryption(String paramString);

  public abstract List<IUserRight> getShowTreeRight(String paramString, int paramInt);

  public abstract ICity getCityByDmCity(String paramString1, String paramString2)
    throws ServiceException;

  public abstract IUserDuty getUserDutyByUser(IUser paramIUser)
    throws ServiceException;

  public abstract boolean addPublishMenu(@WebParam(name="pMenuId") int paramInt, @WebParam(name="resType") String paramString1, @WebParam(name="resId") String paramString2, @WebParam(name="menuName") String paramString3, @WebParam(name="menuUrl") String paramString4, @WebParam(name="userId") String paramString5, @WebParam(name="roleIds") String[] paramArrayOfString);

  public abstract boolean deletePublishMenu(@WebParam(name="resType") String paramString1, @WebParam(name="resId") String paramString2);

  public abstract String queryFolderList(@WebParam(name="menuItemId") int paramInt);

  public abstract boolean modPublishMenu(@WebParam(name="pMenuId") int paramInt, @WebParam(name="resType") String paramString1, @WebParam(name="resId") String paramString2, @WebParam(name="menuName") String paramString3, @WebParam(name="menuUrl") String paramString4, @WebParam(name="userId") String paramString5, @WebParam(name="roleIds") String[] paramArrayOfString);

  public abstract List<IMenuItem> getMenuItemList(String paramString, Map<String, String> paramMap)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserPrivilegeService
 * JD-Core Version:    0.6.2
 */
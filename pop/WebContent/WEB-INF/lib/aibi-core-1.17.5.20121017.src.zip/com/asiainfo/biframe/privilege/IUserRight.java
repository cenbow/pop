package com.asiainfo.biframe.privilege;

public abstract interface IUserRight
{
  public abstract String getResourceId();

  public abstract int getResourceType();

  public abstract String getOperationType();

  public abstract String getOperationName();

  public abstract String getRightId();

  public abstract int getRoleType();

  public abstract String getParentId();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserRight
 * JD-Core Version:    0.6.2
 */
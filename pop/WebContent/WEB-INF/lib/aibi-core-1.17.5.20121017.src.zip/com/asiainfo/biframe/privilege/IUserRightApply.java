package com.asiainfo.biframe.privilege;

import java.util.Date;

public abstract interface IUserRightApply
{
  public abstract String getApplyId();

  public abstract String getApplyType();

  public abstract String getProposerId();

  public abstract String getProposerName();

  public abstract Date getApplyTime();

  public abstract String getState();

  public abstract String getApproverId();

  public abstract String getApproverName();

  public abstract String getApproverPhone();

  public abstract String getElectronicCode();

  public abstract String getApplySmsMessage();

  public abstract String getApplyTimeStr();

  public abstract String getBeginDateStr();

  public abstract String getEndDateStr();

  public abstract String getApprovalTimeStr();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserRightApply
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege;

public abstract interface IUserSession
{
  public static final String ASIA_SESSION_NAME = "biplatform_user";

  public abstract IUser getUser();

  public abstract String getSessionID();

  public abstract String getClientIP();

  public abstract String getUserID();

  public abstract String getUserName();

  public abstract String getUserCityID();

  public abstract String getOAUserID();

  public abstract String getGroupId();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.IUserSession
 * JD-Core Version:    0.6.2
 */
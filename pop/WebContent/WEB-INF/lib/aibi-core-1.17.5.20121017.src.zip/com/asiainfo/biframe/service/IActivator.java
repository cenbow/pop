package com.asiainfo.biframe.service;

import com.asiainfo.biframe.manager.context.ContextManager;

public abstract interface IActivator
{
  public abstract void start(ContextManager paramContextManager)
    throws Exception;

  public abstract void stop(ContextManager paramContextManager)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.IActivator
 * JD-Core Version:    0.6.2
 */
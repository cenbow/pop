package com.asiainfo.biframe.service;

public abstract interface IMessagePortalService
{
  public abstract int insertMsg(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.IMessagePortalService
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.service;

import com.asiainfo.biframe.service.impl.TimerTaskWrapper;
import java.util.Date;
import java.util.Map;

@Deprecated
public abstract interface ITimerService
{
  public abstract void schedule(ITimerTask paramITimerTask, Date paramDate, long paramLong, Object paramObject);

  public abstract void schedule(ITimerTask paramITimerTask, Date paramDate, Object paramObject);

  public abstract void scheduleAtFixedRate(ITimerTask paramITimerTask, Date paramDate, long paramLong, Object paramObject);

  public abstract void stopSchedule();

  public abstract void cancelAll();

  public abstract void cancel(Object paramObject);

  public abstract void remove(Object paramObject);

  public abstract Map<Object, TimerTaskWrapper> getAllScheduledTimerTask();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.ITimerService
 * JD-Core Version:    0.6.2
 */
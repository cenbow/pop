/*    */ package com.asiainfo.biframe.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.common.cache.CacheBase;
/*    */ import com.asiainfo.biframe.manager.cache.CacheManager;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import java.util.TimerTask;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class CacheRefreshTask extends TimerTask
/*    */ {
/* 23 */   private Log log = LogFactory.getLog(CacheRefreshTask.class);
/*    */ 
/*    */   public void run()
/*    */   {
/* 27 */     this.log.debug("All Cache Refresh Start---------------");
/* 28 */     refreshCache();
/* 29 */     this.log.debug("All Cache Refresh End-----------------");
/*    */   }
/*    */ 
/*    */   private void refreshCache()
/*    */   {
/* 37 */     HashMap cacheHP = (HashMap)CacheManager.getInstance().getAllCache();
/* 38 */     Iterator cacheHPKey = cacheHP.keySet().iterator();
/* 39 */     while (cacheHPKey.hasNext()) {
/* 40 */       CacheBase cacheBase = (CacheBase)cacheHP.get(cacheHPKey.next());
/* 41 */       cacheBase.refreshAll();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.impl.CacheRefreshTask
 * JD-Core Version:    0.6.2
 */
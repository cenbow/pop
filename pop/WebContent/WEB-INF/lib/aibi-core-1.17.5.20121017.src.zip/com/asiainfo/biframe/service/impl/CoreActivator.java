/*    */ package com.asiainfo.biframe.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.common.cache.SysParametersCache;
/*    */ import com.asiainfo.biframe.manager.context.ContextManager;
/*    */ import com.asiainfo.biframe.service.IActivator;
/*    */ 
/*    */ public class CoreActivator
/*    */   implements IActivator
/*    */ {
/*    */   public void start(ContextManager context)
/*    */     throws Exception
/*    */   {
/* 27 */     SysParametersCache cache = SysParametersCache.getInstance();
/* 28 */     context.registerCacheService("core-sys-parameters-cache", cache);
/*    */   }
/*    */ 
/*    */   public void stop(ContextManager context)
/*    */     throws Exception
/*    */   {
/* 44 */     context.removeCacheService("core-sys-parameters-cache");
/* 45 */     context.removeCacheService("core-brand-cache");
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.impl.CoreActivator
 * JD-Core Version:    0.6.2
 */
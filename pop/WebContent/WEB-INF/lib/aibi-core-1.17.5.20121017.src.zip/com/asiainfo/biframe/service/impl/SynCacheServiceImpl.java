/*    */ package com.asiainfo.biframe.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.dao.ISysSynCacheDao;
/*    */ import com.asiainfo.biframe.exception.DaoException;
/*    */ import com.asiainfo.biframe.exception.ServiceException;
/*    */ import com.asiainfo.biframe.service.ISynCacheService;
/*    */ 
/*    */ public class SynCacheServiceImpl
/*    */   implements ISynCacheService
/*    */ {
/*    */   private ISysSynCacheDao sysSynCacheDao;
/*    */ 
/*    */   public void addSynCache(String cacheName, String exceptHostIP)
/*    */     throws ServiceException
/*    */   {
/*    */     try
/*    */     {
/* 31 */       getSysSynCacheDao().addSynCache(cacheName, exceptHostIP);
/*    */     } catch (DaoException de) {
/* 33 */       throw new ServiceException(de.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public ISysSynCacheDao getSysSynCacheDao()
/*    */   {
/* 39 */     return this.sysSynCacheDao;
/*    */   }
/*    */ 
/*    */   public void setSysSynCacheDao(ISysSynCacheDao sysSynCacheDao) {
/* 43 */     this.sysSynCacheDao = sysSynCacheDao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.impl.SynCacheServiceImpl
 * JD-Core Version:    0.6.2
 */
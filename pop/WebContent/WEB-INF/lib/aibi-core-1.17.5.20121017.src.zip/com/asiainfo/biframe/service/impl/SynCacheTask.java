/*    */ package com.asiainfo.biframe.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*    */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.TimerTask;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class SynCacheTask extends TimerTask
/*    */ {
/* 23 */   private Log log = LogFactory.getLog(SynCacheTask.class);
/*    */ 
/* 25 */   private static String HOST_ADDRESS = "";
/*    */ 
/* 27 */   private static String REFRESH_STATUS = "";
/*    */   private static final String START_CACHE_REFRESH = "1";
/*    */   private static final String STOP_CACHE_REFRESH = "0";
/*    */ 
/*    */   public SynCacheTask()
/*    */   {
/* 34 */     HOST_ADDRESS = Configure.getInstance().getProperty("HOST_ADDRESS");
/* 35 */     REFRESH_STATUS = Configure.getInstance().getProperty("CACHE_REFRESH_STATUS");
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 42 */       if (REFRESH_STATUS.equals("1"))
/* 43 */         refreshCache(HOST_ADDRESS);
/*    */     }
/*    */     catch (Exception e) {
/* 46 */       this.log.error("", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private void updateSynCache(String cacheName, String hostIP)
/*    */     throws Exception
/*    */   {
/* 59 */     Sqlca m_Sqlca = new Sqlca(new ConnectionEx());
/*    */     try {
/* 61 */       m_Sqlca.execute("update sys_syn_cache set SYN_FLAG=0,SYN_DATE=" + m_Sqlca.getSql2DateNow() + "  where SYN_HOST_ADDRESS='" + hostIP + "' and SYN_FLAG=1 and CACHE_CLASS='" + cacheName + "'");
/*    */ 
/* 68 */       if (null != m_Sqlca)
/* 69 */         m_Sqlca.closeAll();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 66 */       throw e;
/*    */     } finally {
/* 68 */       if (null != m_Sqlca)
/* 69 */         m_Sqlca.closeAll();
/*    */     }
/*    */   }
/*    */ 
/*    */   private void refreshCache(String hostIP)
/*    */     throws Exception
/*    */   {
/* 79 */     Sqlca m_Sqlca = null;
/*    */     try {
/* 81 */       m_Sqlca = new Sqlca(new ConnectionEx());
/* 82 */       m_Sqlca.execute("select CACHE_CLASS from sys_syn_cache where SYN_HOST_ADDRESS='" + hostIP + "' and SYN_FLAG=1");
/*    */ 
/* 85 */       while (m_Sqlca.next()) {
/* 86 */         String cacheName = m_Sqlca.getString(1);
/*    */ 
/* 89 */         Class cls = Class.forName(cacheName);
/* 90 */         if (cls == null) {
/* 91 */           throw new Exception(cacheName + " is not a valid class name, it must include the name of package.");
/*    */         }
/*    */ 
/* 96 */         Class[] partypes = null;
/* 97 */         Object[] arglist = null;
/* 98 */         Method method = null;
/* 99 */         method = cls.getMethod("getInstance", partypes);
/* 100 */         Object instance = method.invoke(cls, arglist);
/* 101 */         method = cls.getMethod("refreshAll", partypes);
/* 102 */         method.invoke(instance, arglist);
/* 103 */         updateSynCache(cacheName, hostIP);
/*    */       }
/*    */ 
/* 106 */       if (null != m_Sqlca)
/* 107 */         m_Sqlca.closeAll();
/*    */     }
/*    */     finally
/*    */     {
/* 106 */       if (null != m_Sqlca)
/* 107 */         m_Sqlca.closeAll();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.impl.SynCacheTask
 * JD-Core Version:    0.6.2
 */
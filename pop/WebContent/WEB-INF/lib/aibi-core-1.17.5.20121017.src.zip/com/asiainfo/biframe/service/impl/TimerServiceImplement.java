/*    */ package com.asiainfo.biframe.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.service.ITimerService;
/*    */ import com.asiainfo.biframe.service.ITimerTask;
/*    */ import java.util.Collection;
/*    */ import java.util.Date;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Timer;
/*    */ import java.util.TimerTask;
/*    */ 
/*    */ @Deprecated
/*    */ public class TimerServiceImplement
/*    */   implements ITimerService
/*    */ {
/* 24 */   private Timer m_timer = null;
/*    */ 
/* 26 */   protected HashMap<Object, TimerTaskWrapper> m_ht = null;
/*    */ 
/*    */   public void scheduleAtFixedRate(ITimerTask it, Date firstTime, long period, Object taskIDKey)
/*    */   {
/* 37 */     if (it != null) {
/* 38 */       TimerTaskWrapper ttw = new TimerTaskWrapper(it);
/* 39 */       ttw.setFirstTime(firstTime.toLocaleString());
/* 40 */       ttw.setPeriod(String.valueOf(period));
/* 41 */       this.m_timer.scheduleAtFixedRate(ttw, firstTime, period);
/* 42 */       this.m_ht.put(taskIDKey, ttw);
/*    */     }
/*    */   }
/*    */ 
/*    */   public TimerServiceImplement() {
/* 47 */     this.m_timer = new Timer();
/* 48 */     this.m_ht = new HashMap();
/*    */   }
/*    */ 
/*    */   public void schedule(ITimerTask it, Date firstTime, long period, Object taskIDKey)
/*    */   {
/* 54 */     if (it != null) {
/* 55 */       TimerTaskWrapper ttw = new TimerTaskWrapper(it);
/* 56 */       ttw.setFirstTime(firstTime.toLocaleString());
/* 57 */       ttw.setPeriod(String.valueOf(period));
/* 58 */       this.m_timer.schedule(ttw, firstTime, period);
/* 59 */       this.m_ht.put(taskIDKey, ttw);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void schedule(ITimerTask it, Date firstTime, Object taskIDKey) {
/* 64 */     if (it != null) {
/* 65 */       TimerTaskWrapper ttw = new TimerTaskWrapper(it);
/* 66 */       ttw.setFirstTime(firstTime.toLocaleString());
/* 67 */       this.m_timer.schedule(ttw, firstTime);
/* 68 */       this.m_ht.put(taskIDKey, ttw);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void cancelAll()
/*    */   {
/* 75 */     Collection e = this.m_ht.values();
/* 76 */     for (TimerTask tt : e)
/* 77 */       ((TimerTaskWrapper)tt).cancel();
/*    */   }
/*    */ 
/*    */   public void cancel(Object id)
/*    */   {
/* 83 */     if ((this.m_ht.containsKey(id)) && (this.m_ht.containsValue(this.m_ht.get(id))))
/*    */     {
/* 85 */       ((TimerTaskWrapper)this.m_ht.get(id)).cancel();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void remove(Object id) {
/* 90 */     cancel(id);
/* 91 */     this.m_ht.remove(id);
/*    */   }
/*    */ 
/*    */   public void stopSchedule() {
/* 95 */     this.m_timer.cancel();
/*    */   }
/*    */ 
/*    */   public Map<Object, TimerTaskWrapper> getAllScheduledTimerTask() {
/* 99 */     return this.m_ht;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.impl.TimerServiceImplement
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.service.ITimerTask;
/*    */ import java.util.TimerTask;
/*    */ 
/*    */ @Deprecated
/*    */ public class TimerTaskWrapper extends TimerTask
/*    */ {
/*    */   private ITimerTask itt;
/*    */   private String firstTime;
/*    */   private String period;
/*    */ 
/*    */   public TimerTaskWrapper(ITimerTask itt)
/*    */   {
/* 25 */     this.itt = itt;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 30 */     this.itt.run();
/*    */   }
/*    */ 
/*    */   public boolean cancel()
/*    */   {
/* 35 */     this.itt.cancel();
/* 36 */     return super.cancel();
/*    */   }
/*    */ 
/*    */   public String getFirstTime() {
/* 40 */     return this.firstTime;
/*    */   }
/*    */ 
/*    */   public void setFirstTime(String firstTime) {
/* 44 */     this.firstTime = firstTime;
/*    */   }
/*    */ 
/*    */   public String getPeriod() {
/* 48 */     return this.period;
/*    */   }
/*    */ 
/*    */   public void setPeriod(String period) {
/* 52 */     this.period = period;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.impl.TimerTaskWrapper
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import com.asiainfo.biframe.utils.webservice.ResponseMessageBuilder;
/*     */ import com.asiainfo.biframe.utils.webservice.WebServiceTemplate;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import org.apache.cxf.endpoint.Client;
/*     */ import org.apache.cxf.endpoint.dynamic.DynamicClientFactory;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class WSDynamicClient
/*     */ {
/*  44 */   static Logger log = Logger.getLogger(WSDynamicClient.class);
/*     */ 
/*  49 */   private static Hashtable table = new Hashtable();
/*     */ 
/*  54 */   private static DynamicClientFactory dcf = DynamicClientFactory.newInstance();
/*     */ 
/*  57 */   private static WebServiceTemplate wsTemplate = new WebServiceTemplate();
/*     */ 
/*     */   public static String invokeWSByURL(String URL, String method, String param)
/*     */   {
/*  70 */     Client client = (Client)table.get(URL);
/*  71 */     if (client == null) {
/*  72 */       client = dcf.createClient(URL);
/*  73 */       table.put(URL, client);
/*     */     }
/*     */ 
/*  76 */     Object[] resultArr = null;
/*     */     try {
/*  78 */       resultArr = client.invoke(method, new Object[] { param });
/*     */     } catch (Exception e) {
/*  80 */       table.remove(URL);
/*  81 */       log.debug("" + e);
/*  82 */       ResponseMessageBuilder rmb = new ResponseMessageBuilder();
/*  83 */       rmb.clearResponseContent();
/*  84 */       rmb.setRespResult(999);
/*  85 */       rmb.setRespCode("OtherErr");
/*  86 */       rmb.setRespDesc(e.getMessage());
/*  87 */       return rmb.createResponseMessage();
/*     */     }
/*     */ 
/*  90 */     String result = (String)resultArr[0];
/*     */ 
/*  92 */     return result != null ? result : "";
/*     */   }
/*     */ 
/*     */   public static int refresh(List<String> URLS)
/*     */   {
/* 102 */     int count = 0;
/* 103 */     for (String url : URLS) {
/* 104 */       if (refresh(url)) {
/* 105 */         count++;
/*     */       }
/*     */     }
/* 108 */     return count;
/*     */   }
/*     */ 
/*     */   public static boolean refresh(String URL)
/*     */   {
/* 119 */     boolean sucessOrNot = true;
/* 120 */     if (StringUtil.isNotEmpty(URL)) {
/*     */       try {
/* 122 */         Client client = dcf.createClient(URL);
/* 123 */         table.put(URL, client);
/* 124 */         log.debug("Refresh WebService Client URL:" + URL);
/*     */       } catch (Exception e) {
/* 126 */         log.debug(e);
/* 127 */         sucessOrNot = false;
/*     */       }
/*     */     }
/* 130 */     return sucessOrNot;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 134 */     List list = new ArrayList();
/* 135 */     list.add("http://localhost:8181/services/QueryUserInfoSoap?wsdl");
/* 136 */     list.add("http://localhost:8181/services/QueryAppRoleSoap?wsdl");
/* 137 */     list.add("http://localhost:8181/services/UpdateAppAcctSoap?wsdl");
/* 138 */     int count = refresh(list);
/* 139 */     System.out.println("refresh client:" + count);
/* 140 */     for (int i = 0; i < 10; i++) {
/* 141 */       String result = invokeWSByURL("http://localhost:8181/services/QueryUserInfoSoap?wsdl", "getUserExt", "admin");
/*     */ 
/* 144 */       System.out.println(i);
/* 145 */       System.out.println("result:" + result);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.service.impl.WSDynamicClient
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.servlet;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.ValidateException;
/*     */ import com.asiainfo.biframe.manager.context.ContextManager;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.web.context.ConfigurableWebApplicationContext;
/*     */ import org.springframework.web.context.ContextLoader;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ public class BISpringContextLoader extends ContextLoader
/*     */ {
/*  37 */   private static Log log = LogFactory.getLog(BISpringContextLoader.class);
/*     */   private static final String MODULE_SPRING_CONFIG_FILE_PREFIX = "application-";
/*     */ 
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext servletContext, ApplicationContext parent)
/*     */     throws BeansException
/*     */   {
/*  50 */     Class contextClass = determineContextClass(servletContext);
/*  51 */     if (!ConfigurableWebApplicationContext.class.isAssignableFrom(contextClass))
/*     */     {
/*  53 */       throw new ApplicationContextException("Custom context class [" + contextClass.getName() + "] is not of type [" + ConfigurableWebApplicationContext.class.getName() + "]");
/*     */     }
/*     */ 
/*  58 */     ConfigurableWebApplicationContext wac = (ConfigurableWebApplicationContext)BeanUtils.instantiateClass(contextClass);
/*     */ 
/*  60 */     wac.setParent(parent);
/*  61 */     wac.setServletContext(servletContext);
/*     */ 
/*  64 */     ContextManager biContext = new ContextManager();
/*     */ 
/*  66 */     String configLocation = servletContext.getInitParameter("contextConfigLocation");
/*     */ 
/*  68 */     if (configLocation != null) {
/*  69 */       biContext.registerSpringConfigFile("Config-In-Web.xml", configLocation);
/*     */     }
/*     */ 
/*  72 */     log.debug("Configured Spring config file(s) location: " + configLocation);
/*     */ 
/*  75 */     String springConfigFiles = getSpringConfigFiles(servletContext, biContext);
/*     */ 
/*  77 */     log.debug("Detect Spring Config file(s) location: " + springConfigFiles);
/*     */ 
/*  81 */     String totalSpringConfigFiles = (configLocation == null ? "" : configLocation) + springConfigFiles;
/*     */ 
/*  84 */     log.info("Total Spring Config file(s) location: " + totalSpringConfigFiles);
/*     */ 
/*  86 */     wac.setConfigLocation(totalSpringConfigFiles);
/*     */ 
/*  89 */     customizeContext(servletContext, wac);
/*  90 */     wac.refresh();
/*     */ 
/*  92 */     return wac;
/*     */   }
/*     */ 
/*     */   private String getSpringConfigFiles(ServletContext servletContext, ContextManager biContext)
/*     */   {
/* 103 */     List springConfigfileList = new ArrayList();
/*     */ 
/* 105 */     String configBasePath = servletContext.getRealPath("/WEB-INF/classes/config/");
/*     */ 
/* 107 */     File basePathFile = new File(configBasePath);
/* 108 */     File[] fileAndPathArr = basePathFile.listFiles();
/*     */ 
/* 111 */     StringBuffer tmpFileNameSb = new StringBuffer();
/*     */ 
/* 114 */     for (File tmpDirectory : fileAndPathArr)
/*     */     {
/* 116 */       if (tmpDirectory.isDirectory()) {
/* 117 */         tmpFileNameSb = new StringBuffer();
/*     */ 
/* 119 */         File[] springConfigFileArr = tmpDirectory.listFiles(new SpringConfigFilenameFilter());
/*     */ 
/* 121 */         for (File tmpFile : springConfigFileArr) {
/* 122 */           String tmpFileName = tmpFile.getAbsolutePath();
/* 123 */           int pos = tmpFileName.indexOf(File.separator + "config" + File.separator);
/*     */ 
/* 126 */           tmpFileName = tmpFileName.substring(pos);
/* 127 */           tmpFileName = StringUtil.replaceAll(tmpFileName, "\\", "/");
/* 128 */           springConfigfileList.add("classpath:" + tmpFileName);
/* 129 */           tmpFileNameSb.append(" " + tmpFileName);
/*     */         }
/*     */ 
/* 132 */         if (tmpFileNameSb.length() > 0) {
/* 133 */           biContext.registerSpringConfigFile(tmpDirectory.getName(), tmpFileNameSb.toString());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 139 */     List orderedConfigfileList = reOrderFileList(springConfigfileList);
/*     */ 
/* 144 */     StringBuffer retSb = new StringBuffer();
/* 145 */     for (String tmpSpringFileName : orderedConfigfileList) {
/* 146 */       log.info("\nload spring file:[" + tmpSpringFileName + "]");
/* 147 */       retSb.append(" " + tmpSpringFileName);
/*     */     }
/*     */ 
/* 150 */     return retSb.toString();
/*     */   }
/*     */ 
/*     */   private List<String> reOrderFileList(List<String> springConfigfileList)
/*     */   {
/* 159 */     List retList = new ArrayList(springConfigfileList.size());
/*     */ 
/* 161 */     String[] componentsLoadIndexArr = getComponentsLoadedIndexFromConfig();
/*     */ 
/* 164 */     for (String tmpFileName : springConfigfileList) {
/* 165 */       int loadIndex = getIndexOfComponentLoad(tmpFileName, componentsLoadIndexArr);
/*     */ 
/* 167 */       if ((loadIndex == 0) || ((loadIndex > 0) && (loadIndex < retList.size()))) {
/* 168 */         log.info("\n" + loadIndex + "----------------" + tmpFileName);
/* 169 */         retList.add(loadIndex, tmpFileName);
/*     */       } else {
/* 171 */         retList.add(tmpFileName);
/*     */       }
/*     */     }
/* 174 */     return retList;
/*     */   }
/*     */ 
/*     */   private String[] getComponentsLoadedIndexFromConfig()
/*     */     throws ValidateException
/*     */   {
/* 185 */     String componentsLoadIndexStr = Configure.getInstance().getProperty("COMPONENTS_LOADED_INDEX");
/*     */ 
/* 187 */     if ((null == componentsLoadIndexStr) || (componentsLoadIndexStr.trim().length() < 1))
/*     */     {
/* 189 */       throw new ValidateException("the config item [COMPONENTS_LOADED_INDEX] in core.properties is empty.");
/*     */     }
/*     */ 
/* 192 */     return componentsLoadIndexStr.split("[,]");
/*     */   }
/*     */ 
/*     */   private int getIndexOfComponentLoad(String tmpFileName, String[] componentsLoadIndexArr)
/*     */   {
/* 218 */     int retInt = -1;
/* 219 */     int index = 0;
/* 220 */     for (String componentName : componentsLoadIndexArr) {
/* 221 */       if ((tmpFileName != null) && (tmpFileName.toLowerCase().indexOf(componentName.trim().toLowerCase()) > 0))
/*     */       {
/* 224 */         retInt = index;
/* 225 */         break;
/*     */       }
/* 227 */       index++;
/*     */     }
/* 229 */     return retInt;
/*     */   }
/*     */ 
/*     */   class SpringConfigFilenameFilter
/*     */     implements FilenameFilter
/*     */   {
/*     */     SpringConfigFilenameFilter()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean accept(File dir, String name)
/*     */     {
/* 203 */       return (name.toLowerCase().startsWith("application-")) && (name.toLowerCase().endsWith(".xml"));
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.servlet.BISpringContextLoader
 * JD-Core Version:    0.6.2
 */
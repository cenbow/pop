/*     */ package com.asiainfo.biframe.servlet;
/*     */ 
/*     */ import com.asiainfo.biframe.manager.context.ContextManager;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.UnavailableException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.struts.action.ActionServlet;
/*     */ import org.apache.struts.config.ModuleConfig;
/*     */ 
/*     */ public class BIStrutsActionServlet extends ActionServlet
/*     */ {
/*     */   private static final long serialVersionUID = -7135568208021001660L;
/*     */   private static final String MODULE_STRUTS_CONFIG_FILE_PREFIX = "struts-";
/*     */ 
/*     */   public void init()
/*     */     throws ServletException
/*     */   {
/*     */     try
/*     */     {
/*  48 */       initInternal();
/*  49 */       initOther();
/*  50 */       initServlet();
/*     */ 
/*  52 */       getServletContext().setAttribute("org.apache.struts.action.ACTION_SERVLET", this);
/*  53 */       initModuleConfigFactory();
/*     */ 
/*  55 */       ModuleConfig moduleConfig = initModuleConfig("", this.config);
/*  56 */       initModuleMessageResources(moduleConfig);
/*  57 */       initModuleDataSources(moduleConfig);
/*  58 */       initModulePlugIns(moduleConfig);
/*  59 */       moduleConfig.freeze();
/*     */ 
/*  61 */       Enumeration names = getServletConfig().getInitParameterNames();
/*     */ 
/*  65 */       List hasInitedModuleNameList = new ArrayList();
/*  66 */       ContextManager biContext = new ContextManager();
/*     */ 
/*  68 */       while (names.hasMoreElements()) {
/*  69 */         String name = (String)names.nextElement();
/*  70 */         if (name.startsWith("config/"))
/*     */         {
/*  73 */           String prefix = name.substring(6);
/*  74 */           String moduleConfigFilePath = getServletConfig().getInitParameter(name);
/*     */ 
/*  76 */           log.info("Initialize Struts module: " + prefix + ", module config file: " + moduleConfigFilePath);
/*     */ 
/*  78 */           moduleConfig = initModuleConfig(prefix, moduleConfigFilePath);
/*  79 */           hasInitedModuleNameList.add(prefix);
/*  80 */           initModule(moduleConfig);
/*     */ 
/*  82 */           biContext.registerStrutModule(prefix, moduleConfigFilePath);
/*     */         }
/*     */       }
/*  85 */       Map moduleNameAndConfigfileMap = getStrutsConfigFiles();
/*     */ 
/*  87 */       Iterator moduleNameIt = moduleNameAndConfigfileMap.keySet().iterator();
/*     */ 
/*  89 */       while (moduleNameIt.hasNext()) {
/*  90 */         String moduleName = (String)moduleNameIt.next();
/*     */ 
/*  92 */         if (!hasInitedModuleNameList.contains(moduleName))
/*     */         {
/*  95 */           String moduleConfigFilePath = (String)moduleNameAndConfigfileMap.get(moduleName);
/*     */ 
/*  97 */           log.info("Initialize Struts module: " + moduleName + ", module config file: " + moduleConfigFilePath);
/*     */ 
/*  99 */           moduleConfig = initModuleConfig(moduleName, moduleConfigFilePath);
/*     */ 
/* 101 */           initModule(moduleConfig);
/*     */ 
/* 103 */           biContext.registerStrutModule(moduleName, moduleConfigFilePath);
/*     */         }
/*     */       }
/*     */ 
/* 107 */       initModulePrefixes(getServletContext());
/*     */ 
/* 109 */       destroyConfigDigester();
/*     */     } catch (UnavailableException ex) {
/* 111 */       throw ex;
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 117 */       log.error("Unable to initialize Struts ActionServlet due to an unexpected exception or error thrown, so marking the servlet as unavailable.  Most likely, this is due to an incorrect or missing library dependency.", t);
/*     */ 
/* 123 */       throw new UnavailableException(t.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initModule(ModuleConfig moduleConfig) throws ServletException {
/* 128 */     initModuleMessageResources(moduleConfig);
/* 129 */     initModuleDataSources(moduleConfig);
/* 130 */     initModulePlugIns(moduleConfig);
/* 131 */     moduleConfig.freeze();
/*     */   }
/*     */ 
/*     */   private Map<String, String> getStrutsConfigFiles()
/*     */   {
/* 154 */     Map moduleNameAndConfigfileMap = new HashMap();
/* 155 */     String configBasePath = getServletContext().getRealPath("/WEB-INF/classes/config/");
/*     */ 
/* 157 */     File basePathFile = new File(configBasePath);
/* 158 */     File[] fileAndPathArr = basePathFile.listFiles();
/*     */ 
/* 162 */     for (File tmpDirectory : fileAndPathArr) {
/* 163 */       if (tmpDirectory.isDirectory()) {
/* 164 */         File[] strutsConfigFileArr = tmpDirectory.listFiles(new StrutsConfigFilenameFilter());
/*     */ 
/* 166 */         for (File tmpFile : strutsConfigFileArr) {
/* 167 */           String tmpFileName = tmpFile.getAbsolutePath();
/* 168 */           int pos = tmpFileName.indexOf(File.separator + "WEB-INF" + File.separator);
/*     */ 
/* 170 */           tmpFileName = tmpFileName.substring(pos);
/* 171 */           String moduleName = getModuleNameFromFileName(tmpFileName);
/* 172 */           moduleNameAndConfigfileMap.put("/" + moduleName, StringUtil.replaceAll(tmpFileName, "\\", "/"));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 177 */     return moduleNameAndConfigfileMap;
/*     */   }
/*     */ 
/*     */   private String getModuleNameFromFileName(String fileName)
/*     */   {
/* 188 */     int pos = fileName.indexOf("struts-");
/* 189 */     String tmpFileName = fileName.substring(pos + "struts-".length());
/*     */ 
/* 191 */     pos = tmpFileName.indexOf("-");
/* 192 */     return tmpFileName.substring(0, pos);
/*     */   }
/*     */ 
/*     */   class StrutsConfigFilenameFilter
/*     */     implements FilenameFilter
/*     */   {
/*     */     StrutsConfigFilenameFilter()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean accept(File dir, String name)
/*     */     {
/* 142 */       return (name.toLowerCase().startsWith("struts-")) && (name.toLowerCase().endsWith(".xml"));
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.servlet.BIStrutsActionServlet
 * JD-Core Version:    0.6.2
 */
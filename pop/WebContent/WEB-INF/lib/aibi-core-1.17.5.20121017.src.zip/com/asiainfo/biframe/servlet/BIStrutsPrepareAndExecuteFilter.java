/*     */ package com.asiainfo.biframe.servlet;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter;
/*     */ 
/*     */ public class BIStrutsPrepareAndExecuteFilter extends StrutsPrepareAndExecuteFilter
/*     */ {
/*     */   private static final String MODULE_CONFIG_FILES_STORE_BASE_PATH = "/WEB-INF/classes/config";
/*     */   private static final String MODULE_CONFIG_FILE_STRUTS_CONFIG = "\\config\\aibi_core\\struts2-common.xml";
/*     */   private static final String MODULE_CONFIG_FILES_INIT_PATH = "CONFIG_INIT_PATH";
/*     */   private static final String STRUTS2_CONFIG_TAG = "config";
/*     */   private static final String MODULE_CONFIG_FILES_STRUTS_DEFAULT = "struts-default.xml";
/*     */   private static final String MODULE_CONFIG_FILES_STRUTS_PLUGIN = "struts-plugin.xml";
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/*  60 */     final FilterConfig finalFilterConfig = filterConfig;
/*  61 */     Set configurePath = getConfigurePath(finalFilterConfig.getServletContext(), filterConfig);
/*     */ 
/*  63 */     Set strutsConfigFile = getStrutsConfigFiles(finalFilterConfig.getServletContext(), filterConfig);
/*     */ 
/*  65 */     if ((null != configurePath) && (configurePath.size() > 0)) {
/*  66 */       for (String configure : configurePath) {
/*  67 */         strutsConfigFile.add(configure);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  73 */     final String configValue = getStrutsConfig(strutsConfigFile);
/*     */ 
/* 124 */     super.init(new FilterConfig()
/*     */     {
/*     */       public String getFilterName()
/*     */       {
/*  80 */         return finalFilterConfig.getFilterName();
/*     */       }
/*     */ 
/*     */       public String getInitParameter(String name)
/*     */       {
/*  88 */         if ("config".equalsIgnoreCase(name)) {
/*  89 */           return configValue;
/*     */         }
/*  91 */         return finalFilterConfig.getInitParameter(name);
/*     */       }
/*     */ 
/*     */       public Enumeration getInitParameterNames()
/*     */       {
/* 100 */         Enumeration enumeration = finalFilterConfig.getInitParameterNames();
/*     */ 
/* 102 */         Vector vector = new Vector();
/* 103 */         while (enumeration.hasMoreElements()) {
/* 104 */           String initConfigKey = enumeration.nextElement().toString();
/* 105 */           if ((!"config".equalsIgnoreCase(initConfigKey)) && (!"CONFIG_INIT_PATH".equalsIgnoreCase(initConfigKey)))
/*     */           {
/* 110 */             vector.add(initConfigKey);
/*     */           }
/*     */         }
/* 112 */         vector.add("config");
/* 113 */         return vector.elements();
/*     */       }
/*     */ 
/*     */       public ServletContext getServletContext()
/*     */       {
/* 120 */         return finalFilterConfig.getServletContext();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private String getStrutsConfig(Set<String> configSet)
/*     */   {
/* 135 */     StringBuilder strutsConfig = new StringBuilder();
/* 136 */     strutsConfig.append("struts-default.xml").append(",").append("struts-plugin.xml");
/*     */ 
/* 138 */     strutsConfig.append(",").append(StringUtil.replaceAll("\\config\\aibi_core\\struts2-common.xml", "\\", "/"));
/*     */ 
/* 141 */     for (String configString : configSet) {
/* 142 */       int pos = configString.indexOf(File.separator + "config" + File.separator);
/*     */ 
/* 144 */       configString = configString.substring(pos);
/* 145 */       if (!"\\config\\aibi_core\\struts2-common.xml".equals(configString))
/*     */       {
/* 148 */         configString = StringUtil.replaceAll(configString, "\\", "/");
/*     */ 
/* 150 */         strutsConfig.append(",").append(configString);
/*     */       }
/*     */     }
/* 153 */     return strutsConfig.toString();
/*     */   }
/*     */ 
/*     */   private Set<String> getStrutsConfigFiles(ServletContext servletContext, FilterConfig filterConfig)
/*     */   {
/* 166 */     Set fileConfigSet = new HashSet();
/* 167 */     String configFileStoreBasePath = filterConfig.getInitParameter("CONFIG_INIT_PATH");
/*     */ 
/* 169 */     if (StringUtil.isEmpty(configFileStoreBasePath)) {
/* 170 */       configFileStoreBasePath = "/WEB-INF/classes/config";
/*     */     }
/* 172 */     String configBasePath = servletContext.getRealPath(configFileStoreBasePath);
/*     */ 
/* 175 */     File basePathFile = new File(configBasePath);
/* 176 */     File[] fileAndPathArr = basePathFile.listFiles();
/*     */ 
/* 180 */     for (File tmpDirectory : fileAndPathArr) {
/* 181 */       if (tmpDirectory.isDirectory()) {
/* 182 */         File[] strutsConfigFileArr = tmpDirectory.listFiles(new StrutsConfigFilenameFilter());
/*     */ 
/* 184 */         for (File tmpFile : strutsConfigFileArr) {
/* 185 */           String tmpFileName = tmpFile.getAbsolutePath();
/* 186 */           tmpFileName = "\\" + tmpFileName;
/* 187 */           fileConfigSet.add(tmpFileName);
/*     */         }
/*     */       }
/*     */     }
/* 191 */     return fileConfigSet;
/*     */   }
/*     */ 
/*     */   public static Set<String> getConfigurePath(ServletContext ctx, FilterConfig filterConfig)
/*     */   {
/* 206 */     Set configSet = new HashSet();
/* 207 */     String configureConfig = filterConfig.getInitParameter("config");
/*     */ 
/* 210 */     if (StringUtil.isNotEmpty(configureConfig)) {
/* 211 */       String[] configureConfigArray = configureConfig.split(",");
/* 212 */       for (String configValue : configureConfigArray) {
/* 213 */         if ((!configValue.equals("struts-default.xml")) && (!configValue.equals("struts-plugin.xml")))
/*     */         {
/* 218 */           int sign = configValue.indexOf("/config/");
/* 219 */           configValue = configValue.substring(sign);
/* 220 */           URL configValueUrl = BIStrutsPrepareAndExecuteFilter.class.getResource(configValue);
/*     */ 
/* 222 */           configSet.add(StringUtil.replaceAll(configValueUrl.getPath(), "/", File.separator));
/*     */         }
/*     */       }
/*     */     }
/* 226 */     return configSet;
/*     */   }
/*     */ 
/*     */   class StrutsConfigFilenameFilter implements FilenameFilter
/*     */   {
/*     */     StrutsConfigFilenameFilter() {
/*     */     }
/*     */ 
/*     */     public boolean accept(File dir, String name) {
/* 235 */       return (name.toLowerCase().startsWith("struts2-")) && (name.toLowerCase().endsWith(".xml"));
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.servlet.BIStrutsPrepareAndExecuteFilter
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.servlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ 
/*     */ public class SetCharacterEncodingFilter
/*     */   implements Filter
/*     */ {
/*  52 */   protected String encoding = null;
/*     */ 
/*  58 */   protected FilterConfig filterConfig = null;
/*     */ 
/*  63 */   protected boolean ignore = true;
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  72 */     this.encoding = null;
/*  73 */     this.filterConfig = null;
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  95 */     if ((!this.ignore) || (request.getCharacterEncoding() == null)) {
/*  96 */       String encoding = selectEncoding(request);
/*  97 */       if (encoding != null)
/*     */       {
/*  99 */         request.setCharacterEncoding(encoding);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 104 */     chain.doFilter(request, response);
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/* 116 */     this.filterConfig = filterConfig;
/* 117 */     this.encoding = filterConfig.getInitParameter("encoding");
/* 118 */     String value = filterConfig.getInitParameter("ignore");
/* 119 */     if (value == null)
/* 120 */       this.ignore = true;
/* 121 */     else if (value.equalsIgnoreCase("true"))
/* 122 */       this.ignore = true;
/* 123 */     else if (value.equalsIgnoreCase("yes"))
/* 124 */       this.ignore = true;
/*     */     else
/* 126 */       this.ignore = false;
/*     */   }
/*     */ 
/*     */   protected String selectEncoding(ServletRequest request)
/*     */   {
/* 148 */     return this.encoding;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.servlet.SetCharacterEncodingFilter
 * JD-Core Version:    0.6.2
 */
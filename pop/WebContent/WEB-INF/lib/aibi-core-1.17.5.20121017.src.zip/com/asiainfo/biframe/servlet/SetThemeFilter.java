/*    */ package com.asiainfo.biframe.servlet;
/*    */ 
/*    */ import com.asiainfo.biframe.common.SysCodes;
/*    */ import com.asiainfo.biframe.utils.string.StringUtil;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class SetThemeFilter
/*    */   implements Filter
/*    */ {
/*    */   public void init(FilterConfig arg0)
/*    */     throws ServletException
/*    */   {
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 50 */     HttpServletRequest hrequest = (HttpServletRequest)request;
/* 51 */     HttpSession session = hrequest.getSession();
/*    */ 
/* 53 */     String theme = hrequest.getParameter("theme");
/* 54 */     if (StringUtil.isNotEmpty(theme))
/*    */     {
/* 56 */       session.setAttribute("theme", theme);
/*    */     }
/*    */     else {
/* 59 */       Object currentTheme = session.getAttribute("theme");
/* 60 */       if (currentTheme == null)
/*    */       {
/* 62 */         theme = SysCodes.getSysParameter("SYS_SHOW_THEME");
/* 63 */         if (StringUtil.isNotEmpty(theme))
/*    */         {
/* 65 */           session.setAttribute("theme", theme);
/*    */         }
/*    */         else {
/* 68 */           session.setAttribute("theme", "default");
/*    */         }
/*    */       }
/*    */     }
/* 72 */     chain.doFilter(request, response);
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.servlet.SetThemeFilter
 * JD-Core Version:    0.6.2
 */
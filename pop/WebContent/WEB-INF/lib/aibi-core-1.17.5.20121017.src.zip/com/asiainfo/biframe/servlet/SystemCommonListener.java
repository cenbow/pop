/*     */ package com.asiainfo.biframe.servlet;
/*     */ 
/*     */ import com.asiainfo.biframe.common.SysCodes;
/*     */ import com.asiainfo.biframe.exception.ComponentException;
/*     */ import com.asiainfo.biframe.manager.context.ContextManager;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.io.File;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletContextEvent;
/*     */ import org.apache.commons.beanutils.ConvertUtils;
/*     */ import org.apache.commons.beanutils.converters.DateConverter;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ import org.springframework.web.context.ContextLoader;
/*     */ import org.springframework.web.context.ContextLoaderListener;
/*     */ 
/*     */ public class SystemCommonListener extends ContextLoaderListener
/*     */ {
/*  37 */   private static Log log = LogFactory.getLog(SystemCommonListener.class);
/*     */   private static final String Log4jFile = "/WEB-INF/classes/config/aibi_core/log4j.properties";
/*     */   private static final String CoreFile = "/WEB-INF/classes/config/aibi_core/core.properties";
/*     */   private static final String DEFAULT_CONFIG_TYPE = "ASIAINFO_PROPERTIES";
/*     */   private static final String UTILS = "utils";
/*     */   private static final String URLFile = "/WEB-INF/classes/config/aibi_core/requestUrl.properties";
/*     */ 
/*     */   protected ContextLoader createContextLoader()
/*     */   {
/*  62 */     return new BISpringContextLoader();
/*     */   }
/*     */ 
/*     */   public void contextInitialized(ServletContextEvent event)
/*     */   {
/*     */     try
/*     */     {
/*  75 */       ServletContext servletContext = event.getServletContext();
/*     */ 
/*  77 */       String log4jPath = servletContext.getRealPath("/WEB-INF/classes/config/aibi_core/log4j.properties");
/*  78 */       PropertyConfigurator.configure(log4jPath);
/*     */ 
/*  80 */       ConvertUtils.register(new DateConverter(null), Date.class);
/*     */ 
/*  83 */       String confFilePath = servletContext.getRealPath("/WEB-INF/classes/config/aibi_core/core.properties");
/*  84 */       Configure.getInstance().addConfFileName("ASIAINFO_PROPERTIES", confFilePath);
/*     */ 
/*  88 */       String urlFilePath = servletContext.getRealPath("/WEB-INF/classes/config/aibi_core/requestUrl.properties");
/*  89 */       Configure.getInstance().addConfFileName("URL_PATH", urlFilePath);
/*     */ 
/*  93 */       initLocaleProperties(event);
/*  94 */       String i18nAdd = "" + LocaleUtil.getLocaleMessage("core", "core.java.add") + "";
/*     */ 
/*  96 */       log.info("test i18n, core.java.add=[" + i18nAdd + "]");
/*     */ 
/*  99 */       super.contextInitialized(event);
/* 100 */       SystemServiceLocator.getWebInstance(event.getServletContext());
/*     */ 
/* 105 */       ContextManager context = new ContextManager();
/* 106 */       log.info("---------------------initalize components");
/*     */ 
/* 108 */       context.initializeComponents(event);
/*     */ 
/* 112 */       String basePath = servletContext.getRealPath("/");
/* 113 */       if ((StringUtils.isNotEmpty(basePath)) && (!basePath.endsWith(File.separator)))
/*     */       {
/* 115 */         basePath = basePath + File.separator;
/*     */       }
/* 117 */       SysCodes.WEBAPP_PATH = basePath;
/* 118 */       log.info("basePath=[" + SysCodes.WEBAPP_PATH + "]");
/*     */     } catch (ComponentException ce) {
/* 120 */       ce.printStackTrace();
/*     */     } catch (Exception e) {
/* 122 */       e.printStackTrace();
/* 123 */       log.error("", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void contextDestroyed(ServletContextEvent event)
/*     */   {
/*     */     try
/*     */     {
/* 137 */       super.contextDestroyed(event);
/*     */ 
/* 140 */       ContextManager context = new ContextManager();
/* 141 */       context.finalizeComponents(event);
/*     */     } catch (Exception e) {
/* 143 */       e.printStackTrace();
/* 144 */       log.error("", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initLocaleProperties(ServletContextEvent event)
/*     */   {
/* 156 */     String languageSet = Configure.getInstance().getProperty("LOCALE_LANGUAGE_DEFAULT");
/*     */ 
/* 158 */     String countrySet = Configure.getInstance().getProperty("LOCALE_COUNTRY_DEFAULT");
/*     */ 
/* 160 */     Locale locale = null;
/* 161 */     if ((languageSet == null) || (languageSet.trim().length() < 1))
/* 162 */       locale = new Locale("en");
/*     */     else {
/* 164 */       locale = new Locale(languageSet, countrySet);
/*     */     }
/* 166 */     String contextPath = event.getServletContext().getRealPath("WEB-INF/classes/") + File.separator;
/*     */ 
/* 169 */     File configFileDir = new File(contextPath + "config" + File.separator);
/* 170 */     log.info("message file dir : " + configFileDir.getName());
/* 171 */     if ((configFileDir.exists()) && (configFileDir.isDirectory())) {
/* 172 */       File[] dirList = configFileDir.listFiles();
/* 173 */       for (int i = 0; i < dirList.length; i++) {
/* 174 */         File compFile = dirList[i];
/* 175 */         String compName = compFile.getName().substring(5);
/* 176 */         log.info("compName=[" + compName + "]");
/* 177 */         if (!compName.equalsIgnoreCase("utils"))
/*     */         {
/* 180 */           if ((compFile.isDirectory()) && 
/* 181 */             (compFile.getName() != null) && (compFile.getName().startsWith("aibi_")))
/*     */           {
/* 183 */             String filePath = "config.aibi_" + compName + ".";
/* 184 */             String absolutePath = contextPath + "config" + File.separator + "aibi_" + compName + File.separator;
/*     */ 
/* 187 */             log.info("i18n filePath=[" + filePath + "]");
/* 188 */             File messageFile = new File(absolutePath + compName + "-appresources.properties");
/*     */ 
/* 190 */             if (messageFile.exists()) {
/* 191 */               LocaleUtil.addSysLocale(compName, filePath, compName + "-appresources", ".properties", "en");
/*     */ 
/* 194 */               LocaleUtil.setLocale(locale);
/* 195 */               log.info(compName + "-appresources  loaded");
/*     */             } else {
/* 197 */               log.warn("===========init i18n message file failed, file [" + compName + "-appresources" + "] not exist!]");
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 207 */       log.warn("===========init i18n message file failed, directory [" + configFileDir + "] not exist!");
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.servlet.SystemCommonListener
 * JD-Core Version:    0.6.2
 */
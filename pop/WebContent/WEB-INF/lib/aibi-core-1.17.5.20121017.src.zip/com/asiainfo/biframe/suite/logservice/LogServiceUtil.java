/*     */ package com.asiainfo.biframe.suite.logservice;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.BaseRuntimeException;
/*     */ import com.asiainfo.biframe.log.ILogService;
/*     */ import com.asiainfo.biframe.log.LogInfo;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LogServiceUtil
/*     */ {
/*  45 */   private static Log log = LogFactory.getLog(LogServiceUtil.class);
/*     */ 
/*     */   public static void log(String operateType, String resourceType, String resourceId, String resourceName, String msg, Map<String, Map<String, String>> oldMap, Map<String, Map<String, String>> newMap)
/*     */   {
/*  69 */     getLogDetailBean().log(LogInfo.getSessionID(), LogInfo.getOperatorID(), LogInfo.getOperatorName(), LogInfo.getHostAddress(), LogInfo.getClientAddress(), operateType, resourceType, resourceId, resourceName, msg, oldMap, newMap);
/*     */   }
/*     */ 
/*     */   public static void log(String sessionId, String operatorId, String operatorName, String serverIp, String clientIp, String operateType, String resourceType, String resourceId, String resourceName, String msg, Map<String, Map<String, String>> oldMap, Map<String, Map<String, String>> newMap)
/*     */   {
/* 110 */     getLogDetailBean().log(sessionId, operatorId, operatorName, serverIp, clientIp, operateType, resourceType, resourceId, resourceName, msg, oldMap, newMap);
/*     */   }
/*     */ 
/*     */   private static ILogService getLogDetailBean()
/*     */   {
/*     */     try
/*     */     {
/* 117 */       return (ILogService)SystemServiceLocator.getInstance().getService("logService");
/*     */     }
/*     */     catch (Exception e) {
/* 120 */       log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"));
/*     */     }
/* 122 */     throw new BaseRuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"));
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.suite.logservice.LogServiceUtil
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.task.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlType(namespace="http://com.asiainfo.suite/unitask")
/*     */ public class CompTask
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String comptaskId;
/*     */   private CompTaskInstance comptaskInstance;
/*     */   private Long instanceId;
/*     */   private String executionId;
/*     */   private String comptaskTitle;
/*     */   private Date comptaskDuedate;
/*     */   private Long comptaskDuedays;
/*     */   private Integer comptaskStatus;
/*     */   private Date comptaskEnddate;
/*     */   private Date comptaskCreatedate;
/*     */   private Integer comptaskWarningSenttype;
/*     */   private String comptaskAction;
/*     */   private String comptaskContent;
/*     */   private String comptaskAssignee;
/*     */   private String comptaskAssigner;
/*     */   private Long comptaskTypeId;
/*     */   private String parentId;
/*     */   private String comptaskCreatorId;
/*     */   private String comptaskOwnerId;
/*     */   private Integer comptaskMark;
/*     */   private String comptaskAssigneeId;
/*     */   private List<CompTaskExtend> comptaskExtends;
/*     */   private Set<CompTaskAttachment> comptaskAttachments;
/*     */   private Date comptaskWarningdate;
/*     */   private Integer comptaskWarningTag;
/*     */ 
/*     */   public Set<CompTaskAttachment> getComptaskAttachments()
/*     */   {
/*  55 */     return this.comptaskAttachments;
/*     */   }
/*     */ 
/*     */   public void setComptaskAttachments(Set<CompTaskAttachment> comptaskAttachments) {
/*  59 */     this.comptaskAttachments = comptaskAttachments;
/*     */   }
/*     */ 
/*     */   public String getComptaskAssigneeId()
/*     */   {
/*  69 */     return this.comptaskAssigneeId;
/*     */   }
/*     */ 
/*     */   public void setComptaskAssigneeId(String comptaskAssigneeId)
/*     */   {
/*  76 */     this.comptaskAssigneeId = comptaskAssigneeId;
/*     */   }
/*     */ 
/*     */   public Integer getComptaskWarningSenttype() {
/*  80 */     return this.comptaskWarningSenttype;
/*     */   }
/*     */ 
/*     */   public void setComptaskWarningSenttype(Integer comptaskWarningSenttype) {
/*  84 */     this.comptaskWarningSenttype = comptaskWarningSenttype;
/*     */   }
/*     */ 
/*     */   public Integer getComptaskMark()
/*     */   {
/*  89 */     return this.comptaskMark;
/*     */   }
/*     */ 
/*     */   public void setComptaskMark(Integer comptaskMark) {
/*  93 */     this.comptaskMark = comptaskMark;
/*     */   }
/*     */ 
/*     */   public String getComptaskOwnerId() {
/*  97 */     return this.comptaskOwnerId;
/*     */   }
/*     */ 
/*     */   public void setComptaskOwnerId(String comptaskOwnerId) {
/* 101 */     this.comptaskOwnerId = comptaskOwnerId;
/*     */   }
/*     */ 
/*     */   public Integer getComptaskWarningTag() {
/* 105 */     return this.comptaskWarningTag;
/*     */   }
/*     */ 
/*     */   public void setComptaskWarningTag(Integer comptaskWarningTag) {
/* 109 */     this.comptaskWarningTag = comptaskWarningTag;
/*     */   }
/*     */ 
/*     */   public Date getComptaskWarningdate() {
/* 113 */     return this.comptaskWarningdate;
/*     */   }
/*     */ 
/*     */   public void setComptaskWarningdate(Date comptaskWarningdate) {
/* 117 */     this.comptaskWarningdate = comptaskWarningdate;
/*     */   }
/*     */ 
/*     */   public String getComptaskCreatorId() {
/* 121 */     return this.comptaskCreatorId;
/*     */   }
/*     */ 
/*     */   public void setComptaskCreatorId(String comptaskCreator) {
/* 125 */     this.comptaskCreatorId = comptaskCreator;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/* 129 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setParentId(String parentId) {
/* 133 */     this.parentId = parentId;
/*     */   }
/*     */ 
/*     */   public Long getComptaskTypeId() {
/* 137 */     return this.comptaskTypeId;
/*     */   }
/*     */ 
/*     */   public void setComptaskTypeId(Long comptaskTypeId) {
/* 141 */     this.comptaskTypeId = comptaskTypeId;
/*     */   }
/*     */ 
/*     */   public String getComptaskContent()
/*     */   {
/* 153 */     return this.comptaskContent;
/*     */   }
/*     */ 
/*     */   public void setComptaskContent(String comptaskContent) {
/* 157 */     this.comptaskContent = comptaskContent;
/*     */   }
/*     */ 
/*     */   public String getComptaskAction() {
/* 161 */     return this.comptaskAction;
/*     */   }
/*     */ 
/*     */   public void setComptaskAction(String comptaskAction) {
/* 165 */     this.comptaskAction = comptaskAction;
/*     */   }
/*     */ 
/*     */   public String getComptaskAssignee() {
/* 169 */     return this.comptaskAssignee;
/*     */   }
/*     */ 
/*     */   public void setComptaskAssignee(String comptaskAssignee) {
/* 173 */     this.comptaskAssignee = comptaskAssignee;
/*     */   }
/*     */ 
/*     */   public String getComptaskAssigner() {
/* 177 */     return this.comptaskAssigner;
/*     */   }
/*     */ 
/*     */   public void setComptaskAssigner(String comptaskAssigner) {
/* 181 */     this.comptaskAssigner = comptaskAssigner;
/*     */   }
/*     */ 
/*     */   public CompTask()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CompTask(String comptaskId)
/*     */   {
/* 198 */     this.comptaskId = comptaskId;
/*     */   }
/*     */ 
/*     */   public CompTask(String comptaskId, CompTaskInstance comptaskInstance, Long instanceId, String executionId, String comptaskTitle, Date comptaskDuedate, Long comptaskDuedays, Integer comptaskStatus, Date comptaskEdndate, Date comptaskCreatedate, Integer comptaskSentType, String attribute1, String attribute2, String attribute3, String attribute4)
/*     */   {
/* 203 */     this.comptaskId = comptaskId;
/* 204 */     this.comptaskInstance = comptaskInstance;
/* 205 */     this.instanceId = instanceId;
/* 206 */     this.executionId = executionId;
/* 207 */     this.comptaskTitle = comptaskTitle;
/* 208 */     this.comptaskDuedate = comptaskDuedate;
/* 209 */     this.comptaskDuedays = comptaskDuedays;
/* 210 */     this.comptaskStatus = comptaskStatus;
/* 211 */     this.comptaskEnddate = comptaskEdndate;
/* 212 */     this.comptaskCreatedate = comptaskCreatedate;
/* 213 */     this.comptaskWarningSenttype = comptaskSentType;
/*     */   }
/*     */ 
/*     */   public String getComptaskId()
/*     */   {
/* 223 */     return this.comptaskId;
/*     */   }
/*     */ 
/*     */   public void setComptaskId(String comptaskId) {
/* 227 */     this.comptaskId = comptaskId;
/*     */   }
/*     */ 
/*     */   public CompTaskInstance getComptaskInstance() {
/* 231 */     return this.comptaskInstance;
/*     */   }
/*     */ 
/*     */   public void setComptaskInstance(CompTaskInstance comptaskInstance) {
/* 235 */     this.comptaskInstance = comptaskInstance;
/*     */   }
/*     */ 
/*     */   public Long getInstanceId() {
/* 239 */     return this.instanceId;
/*     */   }
/*     */ 
/*     */   public void setInstanceId(Long instanceId) {
/* 243 */     this.instanceId = instanceId;
/*     */   }
/*     */ 
/*     */   public String getExecutionId() {
/* 247 */     return this.executionId;
/*     */   }
/*     */ 
/*     */   public void setExecutionId(String executionId) {
/* 251 */     this.executionId = executionId;
/*     */   }
/*     */ 
/*     */   public String getComptaskTitle() {
/* 255 */     return this.comptaskTitle;
/*     */   }
/*     */ 
/*     */   public void setComptaskTitle(String comptaskTitle) {
/* 259 */     this.comptaskTitle = comptaskTitle;
/*     */   }
/*     */ 
/*     */   public Date getComptaskDuedate() {
/* 263 */     return this.comptaskDuedate;
/*     */   }
/*     */ 
/*     */   public void setComptaskDuedate(Date comptaskDuedate) {
/* 267 */     this.comptaskDuedate = comptaskDuedate;
/*     */   }
/*     */ 
/*     */   public Long getComptaskDuedays() {
/* 271 */     return this.comptaskDuedays;
/*     */   }
/*     */ 
/*     */   public void setComptaskDuedays(Long comptaskDuedays) {
/* 275 */     this.comptaskDuedays = comptaskDuedays;
/*     */   }
/*     */ 
/*     */   public Integer getComptaskStatus() {
/* 279 */     return this.comptaskStatus;
/*     */   }
/*     */ 
/*     */   public void setComptaskStatus(Integer comptaskStatus) {
/* 283 */     this.comptaskStatus = comptaskStatus;
/*     */   }
/*     */ 
/*     */   public Date getComptaskEnddate() {
/* 287 */     return this.comptaskEnddate;
/*     */   }
/*     */ 
/*     */   public void setComptaskEnddate(Date comptaskEdndate) {
/* 291 */     this.comptaskEnddate = comptaskEdndate;
/*     */   }
/*     */ 
/*     */   public Date getComptaskCreatedate() {
/* 295 */     return this.comptaskCreatedate;
/*     */   }
/*     */ 
/*     */   public void setComptaskCreatedate(Date comptaskCreatedate) {
/* 299 */     this.comptaskCreatedate = comptaskCreatedate;
/*     */   }
/*     */ 
/*     */   public Integer getComptaskSentType() {
/* 303 */     return this.comptaskWarningSenttype;
/*     */   }
/*     */ 
/*     */   public void setComptaskSentType(Integer comptaskSentType) {
/* 307 */     this.comptaskWarningSenttype = comptaskSentType;
/*     */   }
/*     */ 
/*     */   public List<CompTaskExtend> getComptaskExtends() {
/* 311 */     return this.comptaskExtends;
/*     */   }
/*     */ 
/*     */   public void setComptaskExtends(List<CompTaskExtend> comptaskExtends) {
/* 315 */     this.comptaskExtends = comptaskExtends;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.task.model.CompTask
 * JD-Core Version:    0.6.2
 */
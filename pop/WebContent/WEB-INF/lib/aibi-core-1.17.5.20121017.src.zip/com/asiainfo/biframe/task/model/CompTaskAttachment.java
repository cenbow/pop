/*     */ package com.asiainfo.biframe.task.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlType(namespace="http://com.asiainfo.suite/unitask")
/*     */ public class CompTaskAttachment
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Long attachmentId;
/*     */   private String comptaskId;
/*     */   private String attachmentUrl;
/*     */   private String attachmentName;
/*     */   private String attachmentDesc;
/*     */   private Long attachmentSize;
/*     */ 
/*     */   public CompTaskAttachment()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CompTaskAttachment(Long attachmentId)
/*     */   {
/*  38 */     this.attachmentId = attachmentId;
/*     */   }
/*     */ 
/*     */   public CompTaskAttachment(Long attachmentId, CompTask comptask, String comptaskId, String attachmentUrl, String attachmentName, String attachmentDesc, Long attachmentSize, String attribute1, String attribute2, String attribute3)
/*     */   {
/*  46 */     this.attachmentId = attachmentId;
/*     */ 
/*  48 */     this.comptaskId = comptaskId;
/*  49 */     this.attachmentUrl = attachmentUrl;
/*  50 */     this.attachmentName = attachmentName;
/*  51 */     this.attachmentDesc = attachmentDesc;
/*  52 */     this.attachmentSize = attachmentSize;
/*     */   }
/*     */ 
/*     */   public Long getAttachmentId()
/*     */   {
/*  59 */     return this.attachmentId;
/*     */   }
/*     */ 
/*     */   public void setAttachmentId(Long attachmentId) {
/*  63 */     this.attachmentId = attachmentId;
/*     */   }
/*     */ 
/*     */   public String getComptaskId() {
/*  67 */     return this.comptaskId;
/*     */   }
/*     */ 
/*     */   public void setComptaskId(String comptaskId) {
/*  71 */     this.comptaskId = comptaskId;
/*     */   }
/*     */ 
/*     */   public String getAttachmentUrl() {
/*  75 */     return this.attachmentUrl;
/*     */   }
/*     */ 
/*     */   public void setAttachmentUrl(String attachmentUrl) {
/*  79 */     this.attachmentUrl = attachmentUrl;
/*     */   }
/*     */ 
/*     */   public String getAttachmentName() {
/*  83 */     return this.attachmentName;
/*     */   }
/*     */ 
/*     */   public void setAttachmentName(String attachmentName) {
/*  87 */     this.attachmentName = attachmentName;
/*     */   }
/*     */ 
/*     */   public String getAttachmentDesc() {
/*  91 */     return this.attachmentDesc;
/*     */   }
/*     */ 
/*     */   public void setAttachmentDesc(String attachmentDesc) {
/*  95 */     this.attachmentDesc = attachmentDesc;
/*     */   }
/*     */ 
/*     */   public Long getAttachmentSize() {
/*  99 */     return this.attachmentSize;
/*     */   }
/*     */ 
/*     */   public void setAttachmentSize(Long attachmentSize) {
/* 103 */     this.attachmentSize = attachmentSize;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.task.model.CompTaskAttachment
 * JD-Core Version:    0.6.2
 */
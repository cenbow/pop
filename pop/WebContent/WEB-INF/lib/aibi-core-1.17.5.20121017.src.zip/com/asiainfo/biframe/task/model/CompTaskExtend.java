/*     */ package com.asiainfo.biframe.task.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlType(namespace="http://com.asiainfo.suite/unitask")
/*     */ public class CompTaskExtend
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Integer extendId;
/*     */   private String comptaskId;
/*     */   private String extendName;
/*     */   private String extendContent;
/*     */   private String extendDesc;
/*     */   private Integer extendType;
/*     */   private String extendSizeCode;
/*     */   private Integer extendSize;
/*     */   private Short extendDisplay;
/*     */   private Integer extendSortId;
/*     */   private String itemId;
/*     */   private FormItemInfo itemInfo;
/*     */ 
/*     */   public Integer getExtendId()
/*     */   {
/*  37 */     return this.extendId;
/*     */   }
/*     */   public void setExtendId(Integer extendId) {
/*  40 */     this.extendId = extendId;
/*     */   }
/*     */   public String getComptaskId() {
/*  43 */     return this.comptaskId;
/*     */   }
/*     */   public void setComptaskId(String comptaskId) {
/*  46 */     this.comptaskId = comptaskId;
/*     */   }
/*     */   public String getExtendName() {
/*  49 */     return this.extendName;
/*     */   }
/*     */   public void setExtendName(String extendName) {
/*  52 */     this.extendName = extendName;
/*     */   }
/*     */   public String getExtendContent() {
/*  55 */     return this.extendContent;
/*     */   }
/*     */   public void setExtendContent(String extendContent) {
/*  58 */     this.extendContent = extendContent;
/*     */   }
/*     */   public String getExtendDesc() {
/*  61 */     return this.extendDesc;
/*     */   }
/*     */   public void setExtendDesc(String extendDesc) {
/*  64 */     this.extendDesc = extendDesc;
/*     */   }
/*     */   public Integer getExtendType() {
/*  67 */     return this.extendType;
/*     */   }
/*     */   public void setExtendType(Integer extendType) {
/*  70 */     this.extendType = extendType;
/*     */   }
/*     */   public Integer getExtendSize() {
/*  73 */     return this.extendSize;
/*     */   }
/*     */   public void setExtendSize(Integer extendSize) {
/*  76 */     this.extendSize = extendSize;
/*     */   }
/*     */   public Short getExtendDisplay() {
/*  79 */     return this.extendDisplay;
/*     */   }
/*     */   public void setExtendDisplay(Short extendDisplay) {
/*  82 */     this.extendDisplay = extendDisplay;
/*     */   }
/*     */   public Integer getExtendSortId() {
/*  85 */     return this.extendSortId;
/*     */   }
/*     */   public void setExtendSortId(Integer extendSortId) {
/*  88 */     this.extendSortId = extendSortId;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  92 */     return "CompTaskExtend [comptaskId=" + this.comptaskId + ", extendContent=" + this.extendContent + ", extendDesc=" + this.extendDesc + ", extendDisplay=" + this.extendDisplay + ", extendId=" + this.extendId + ", extendName=" + this.extendName + ", extendSize=" + this.extendSize + ", extendSizeCode=" + this.extendSizeCode + ", extendSortId=" + this.extendSortId + ", extendType=" + this.extendType + "]";
/*     */   }
/*     */ 
/*     */   public String getItemId()
/*     */   {
/* 100 */     return this.itemId;
/*     */   }
/*     */   public void setItemId(String itemId) {
/* 103 */     this.itemId = itemId;
/*     */   }
/*     */   public FormItemInfo getItemInfo() {
/* 106 */     return this.itemInfo;
/*     */   }
/*     */   public void setItemInfo(FormItemInfo itemInfo) {
/* 109 */     this.itemInfo = itemInfo;
/*     */   }
/*     */   public String getExtendSizeCode() {
/* 112 */     return this.extendSizeCode;
/*     */   }
/*     */   public void setExtendSizeCode(String extendSizeCode) {
/* 115 */     this.extendSizeCode = extendSizeCode;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.task.model.CompTaskExtend
 * JD-Core Version:    0.6.2
 */
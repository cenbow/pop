/*     */ package com.asiainfo.biframe.task.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.Set;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlType(namespace="http://com.asiainfo.suite/unitask")
/*     */ public class CompTaskInstance
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Long instanceId;
/*     */   private Long instanceTypeId;
/*     */   private Date instanceCreatedate;
/*     */   private Date instanceEnddate;
/*     */   private String instanceCreater;
/*     */   private String instanceDesc;
/*  32 */   private Integer instanceIsAuto = Integer.valueOf(0);
/*     */   private String instanceTitle;
/*     */   private String instanceClass;
/*  38 */   private Integer instanceIsAudit = Integer.valueOf(0);
/*     */   private String instanceCreaterId;
/*     */   private Integer instanceStatus;
/*     */   private Integer instanceFrom;
/*     */   private Integer instanceBack;
/*     */   private String instanceProcessor;
/*     */   private String instanceProcessorId;
/*     */ 
/*     */   public String getInstanceProcessor()
/*     */   {
/*  52 */     return this.instanceProcessor;
/*     */   }
/*     */ 
/*     */   public void setInstanceProcessor(String instanceProcessor)
/*     */   {
/*  60 */     this.instanceProcessor = instanceProcessor;
/*     */   }
/*     */ 
/*     */   public String getInstanceProcessorId()
/*     */   {
/*  67 */     return this.instanceProcessorId;
/*     */   }
/*     */ 
/*     */   public void setInstanceProcessorId(String instanceProcessorId)
/*     */   {
/*  75 */     this.instanceProcessorId = instanceProcessorId;
/*     */   }
/*     */ 
/*     */   public String getInstanceCreaterId()
/*     */   {
/*  86 */     return this.instanceCreaterId;
/*     */   }
/*     */ 
/*     */   public void setInstanceCreaterId(String instanceCreaterId)
/*     */   {
/*  94 */     this.instanceCreaterId = instanceCreaterId;
/*     */   }
/*     */ 
/*     */   public Integer getInstanceStatus()
/*     */   {
/* 101 */     return this.instanceStatus;
/*     */   }
/*     */ 
/*     */   public void setInstanceStatus(Integer instanceStatus)
/*     */   {
/* 109 */     this.instanceStatus = instanceStatus;
/*     */   }
/*     */ 
/*     */   public Integer getInstanceIsAudit() {
/* 113 */     return this.instanceIsAudit;
/*     */   }
/*     */ 
/*     */   public void setInstanceIsAudit(Integer instanceIsAudit) {
/* 117 */     this.instanceIsAudit = instanceIsAudit;
/*     */   }
/*     */ 
/*     */   public String getInstanceTitle() {
/* 121 */     return this.instanceTitle;
/*     */   }
/*     */ 
/*     */   public void setInstanceTitle(String instanceTitle) {
/* 125 */     this.instanceTitle = instanceTitle;
/*     */   }
/*     */ 
/*     */   public String getInstanceClass() {
/* 129 */     return this.instanceClass;
/*     */   }
/*     */ 
/*     */   public void setInstanceClass(String instanceClass) {
/* 133 */     this.instanceClass = instanceClass;
/*     */   }
/*     */ 
/*     */   public Date getInstanceEnddate() {
/* 137 */     return this.instanceEnddate;
/*     */   }
/*     */ 
/*     */   public void setInstanceEnddate(Date instanceEnddate) {
/* 141 */     this.instanceEnddate = instanceEnddate;
/*     */   }
/*     */ 
/*     */   public CompTaskInstance()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CompTaskInstance(Long instanceId)
/*     */   {
/* 152 */     this.instanceId = instanceId;
/*     */   }
/*     */ 
/*     */   public CompTaskInstance(Long instanceId, Long instanceTypeId, Date instanceCreatedate, String instanceCreater, String instanceDesc, Integer instanceIsAuto, String attribute1, String attribute2, String attribute3, Set comptasks)
/*     */   {
/* 160 */     this.instanceId = instanceId;
/* 161 */     this.instanceTypeId = instanceTypeId;
/* 162 */     this.instanceCreatedate = instanceCreatedate;
/* 163 */     this.instanceCreater = instanceCreater;
/* 164 */     this.instanceDesc = instanceDesc;
/* 165 */     this.instanceIsAuto = instanceIsAuto;
/*     */   }
/*     */ 
/*     */   public Long getInstanceId()
/*     */   {
/* 172 */     return this.instanceId;
/*     */   }
/*     */ 
/*     */   public void setInstanceId(Long instanceId) {
/* 176 */     this.instanceId = instanceId;
/*     */   }
/*     */ 
/*     */   public Long getInstanceTypeId() {
/* 180 */     return this.instanceTypeId;
/*     */   }
/*     */ 
/*     */   public void setInstanceTypeId(Long instanceTypeId) {
/* 184 */     this.instanceTypeId = instanceTypeId;
/*     */   }
/*     */ 
/*     */   public Date getInstanceCreatedate() {
/* 188 */     return this.instanceCreatedate;
/*     */   }
/*     */ 
/*     */   public void setInstanceCreatedate(Date instanceCreatedate) {
/* 192 */     this.instanceCreatedate = instanceCreatedate;
/*     */   }
/*     */ 
/*     */   public String getInstanceCreater() {
/* 196 */     return this.instanceCreater;
/*     */   }
/*     */ 
/*     */   public void setInstanceCreater(String instanceCreater) {
/* 200 */     this.instanceCreater = instanceCreater;
/*     */   }
/*     */ 
/*     */   public String getInstanceDesc() {
/* 204 */     return this.instanceDesc;
/*     */   }
/*     */ 
/*     */   public void setInstanceDesc(String instanceDesc) {
/* 208 */     this.instanceDesc = instanceDesc;
/*     */   }
/*     */ 
/*     */   public Integer getInstanceIsAuto() {
/* 212 */     return this.instanceIsAuto;
/*     */   }
/*     */ 
/*     */   public void setInstanceIsAuto(Integer instanceIsAuto) {
/* 216 */     this.instanceIsAuto = instanceIsAuto;
/*     */   }
/*     */ 
/*     */   public Integer getInstanceFrom() {
/* 220 */     return this.instanceFrom;
/*     */   }
/*     */ 
/*     */   public void setInstanceFrom(Integer instanceFrom) {
/* 224 */     this.instanceFrom = instanceFrom;
/*     */   }
/*     */ 
/*     */   public Integer getInstanceBack() {
/* 228 */     return this.instanceBack;
/*     */   }
/*     */ 
/*     */   public void setInstanceBack(Integer instanceBack) {
/* 232 */     this.instanceBack = instanceBack;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.task.model.CompTaskInstance
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.task.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class CompTaskType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Long typeId;
/*     */   private String typeCode;
/*     */   private String typeName;
/*     */   private String typeDesc;
/*     */   private Set<FormItemInfo> formItemInfos;
/*     */ 
/*     */   public CompTaskType()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CompTaskType(Long typeId, String typeName)
/*     */   {
/*  31 */     this.typeId = typeId;
/*  32 */     this.typeName = typeName;
/*     */   }
/*     */ 
/*     */   public CompTaskType(Long typeId, String typeName, String typeDesc)
/*     */   {
/*  37 */     this.typeId = typeId;
/*  38 */     this.typeName = typeName;
/*  39 */     this.typeDesc = typeDesc;
/*     */   }
/*     */ 
/*     */   public Long getTypeId()
/*     */   {
/*  45 */     return this.typeId;
/*     */   }
/*     */ 
/*     */   public void setTypeId(Long typeId) {
/*  49 */     this.typeId = typeId;
/*     */   }
/*     */ 
/*     */   public String getTypeName() {
/*  53 */     return this.typeName;
/*     */   }
/*     */ 
/*     */   public void setTypeName(String typeName) {
/*  57 */     this.typeName = typeName;
/*     */   }
/*     */ 
/*     */   public String getTypeDesc() {
/*  61 */     return this.typeDesc;
/*     */   }
/*     */ 
/*     */   public void setTypeDesc(String typeDesc) {
/*  65 */     this.typeDesc = typeDesc;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/*  69 */     if (this == other)
/*  70 */       return true;
/*  71 */     if (other == null)
/*  72 */       return false;
/*  73 */     if (!(other instanceof CompTaskType))
/*  74 */       return false;
/*  75 */     CompTaskType castOther = (CompTaskType)other;
/*     */ 
/*  77 */     return ((getTypeId() == castOther.getTypeId()) || ((getTypeId() != null) && (castOther.getTypeId() != null) && (getTypeId().equals(castOther.getTypeId())))) && ((getTypeName() == castOther.getTypeName()) || ((getTypeName() != null) && (castOther.getTypeName() != null) && (getTypeName().equals(castOther.getTypeName())))) && ((getTypeDesc() == castOther.getTypeDesc()) || ((getTypeDesc() != null) && (castOther.getTypeDesc() != null) && (getTypeDesc().equals(castOther.getTypeDesc()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  92 */     int result = 17;
/*     */ 
/*  94 */     result = 37 * result + (getTypeId() == null ? 0 : getTypeId().hashCode());
/*     */ 
/*  96 */     result = 37 * result + (getTypeName() == null ? 0 : getTypeName().hashCode());
/*     */ 
/*  98 */     result = 37 * result + (getTypeDesc() == null ? 0 : getTypeDesc().hashCode());
/*     */ 
/* 100 */     return result;
/*     */   }
/*     */ 
/*     */   public String getTypeCode() {
/* 104 */     return this.typeCode;
/*     */   }
/*     */ 
/*     */   public void setTypeCode(String typeCode) {
/* 108 */     this.typeCode = typeCode;
/*     */   }
/*     */ 
/*     */   public Set<FormItemInfo> getFormItemInfos() {
/* 112 */     return this.formItemInfos;
/*     */   }
/*     */ 
/*     */   public void setFormItemInfos(Set<FormItemInfo> formItemInfos) {
/* 116 */     this.formItemInfos = formItemInfos;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.task.model.CompTaskType
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.task.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class FormItemInfo
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String itemId;
/*     */   private String itemLabel;
/*     */   private String itemName;
/*     */   private Short itemType;
/*     */   private String itemStyle;
/*     */   private String itemControl;
/*  26 */   private Short itemDataType = Short.valueOf((short)1);
/*     */   private String itemData;
/*     */   private Short itemOrder;
/*     */   private Set<CompTaskType> compTaskTypes;
/*     */ 
/*     */   public String getItemId()
/*     */   {
/*  32 */     return this.itemId;
/*     */   }
/*     */   public void setItemId(String itemId) {
/*  35 */     this.itemId = itemId;
/*     */   }
/*     */   public String getItemLabel() {
/*  38 */     return this.itemLabel;
/*     */   }
/*     */   public void setItemLabel(String itemLabel) {
/*  41 */     this.itemLabel = itemLabel;
/*     */   }
/*     */   public String getItemName() {
/*  44 */     return this.itemName;
/*     */   }
/*     */   public void setItemName(String itemName) {
/*  47 */     this.itemName = itemName;
/*     */   }
/*     */   public Short getItemType() {
/*  50 */     return this.itemType;
/*     */   }
/*     */   public void setItemType(Short itemType) {
/*  53 */     this.itemType = itemType;
/*     */   }
/*     */   public String getItemStyle() {
/*  56 */     return this.itemStyle;
/*     */   }
/*     */   public void setItemStyle(String itemStyle) {
/*  59 */     this.itemStyle = itemStyle;
/*     */   }
/*     */   public String getItemControl() {
/*  62 */     return this.itemControl;
/*     */   }
/*     */   public void setItemControl(String itemControl) {
/*  65 */     this.itemControl = itemControl;
/*     */   }
/*     */   public Short getItemDataType() {
/*  68 */     if (this.itemDataType == null) {
/*  69 */       this.itemDataType = Short.valueOf((short)1);
/*     */     }
/*  71 */     return this.itemDataType;
/*     */   }
/*     */   public void setItemDataType(Short itemDataType) {
/*  74 */     this.itemDataType = itemDataType;
/*     */   }
/*     */   public String getItemData() {
/*  77 */     return this.itemData;
/*     */   }
/*     */   public void setItemData(String itemData) {
/*  80 */     this.itemData = itemData;
/*     */   }
/*     */   public Short getItemOrder() {
/*  83 */     if (this.itemOrder == null) {
/*  84 */       this.itemOrder = Short.valueOf((short)255);
/*     */     }
/*  86 */     return this.itemOrder;
/*     */   }
/*     */   public void setItemOrder(Short itemOrder) {
/*  89 */     this.itemOrder = itemOrder;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  93 */     return "FormItemInfo [itemControl=" + this.itemControl + ", itemData=" + this.itemData + ", itemDataType=" + this.itemDataType + ", itemId=" + this.itemId + ", itemLabel=" + this.itemLabel + ", itemName=" + this.itemName + ", itemOrder=" + this.itemOrder + ", itemStyle=" + this.itemStyle + ", itemType=" + this.itemType + "]";
/*     */   }
/*     */ 
/*     */   public Set<CompTaskType> getCompTaskTypes()
/*     */   {
/*  98 */     return this.compTaskTypes;
/*     */   }
/*     */   public void setCompTaskTypes(Set<CompTaskType> compTaskTypes) {
/* 101 */     this.compTaskTypes = compTaskTypes;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.task.model.FormItemInfo
 * JD-Core Version:    0.6.2
 */
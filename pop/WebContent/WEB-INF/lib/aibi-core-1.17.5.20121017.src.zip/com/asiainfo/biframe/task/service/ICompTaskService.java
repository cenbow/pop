package com.asiainfo.biframe.task.service;

import com.asiainfo.biframe.task.model.CompTask;
import com.asiainfo.biframe.task.model.CompTaskInstance;
import java.util.Date;
import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService(targetNamespace="http://com.asiainfo.suite/unitask")
public abstract interface ICompTaskService
{
  @WebMethod(exclude=true)
  public abstract void save(CompTask paramCompTask)
    throws Exception;

  @WebMethod(exclude=true)
  public abstract List<CompTask> findAllByInstanceId(Long paramLong)
    throws Exception;

  @WebMethod(exclude=true)
  public abstract List<CompTask> findAllByInstanceIdNoStatus(Long paramLong)
    throws Exception;

  public abstract List<CompTaskInstance> findHistoryByCreatorOrOwner(String paramString)
    throws Exception;

  @WebMethod(exclude=true)
  public abstract List<CompTaskInstance> findHistoryByCreatorOrOwner(String paramString, int paramInt)
    throws Exception;

  @WebMethod(exclude=true)
  public abstract void update(CompTask paramCompTask)
    throws Exception;

  @WebMethod(exclude=true)
  public abstract CompTask findById(String paramString)
    throws Exception;

  @WebMethod(exclude=true)
  public abstract Date findDueDateByInstanceOwner(Long paramLong, String paramString)
    throws Exception;

  @WebMethod(operationName="getAllTaskByStaffId", exclude=false)
  public abstract List<CompTask> getAllTaskByStaffId(String paramString1, int paramInt1, int paramInt2, String paramString2, String paramString3)
    throws Exception;

  @WebMethod(exclude=true)
  public abstract List<CompTask> getAllTaskByStaffId(String paramString1, int paramInt1, int paramInt2, String paramString2, String paramString3, int paramInt3)
    throws Exception;

  public abstract List<CompTask> findAllByInstanceIdCurrent(Long paramLong)
    throws Exception;

  public abstract CompTask findDetailById(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-core-1.17.5.20121017.jar
 * Qualified Name:     com.asiainfo.biframe.task.service.ICompTaskService
 * JD-Core Version:    0.6.2
 */
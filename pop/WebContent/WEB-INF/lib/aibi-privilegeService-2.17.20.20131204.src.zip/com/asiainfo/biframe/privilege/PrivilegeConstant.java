/*    */ package com.asiainfo.biframe.privilege;
/*    */ 
/*    */ public class PrivilegeConstant
/*    */ {
/*  6 */   public static String USERLOGIN_RETURN_TYPE_0 = "0";
/*  7 */   public static String USERLOGIN_RETURN_TYPE_1 = "1";
/*  8 */   public static String USERLOGIN_RETURN_TYPE_2 = "2";
/*    */ 
/* 12 */   public static int USER_STATUS_0 = 0;
/* 13 */   public static int USER_STATUS_1 = 1;
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.PrivilegeConstant
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.autologin.dao;

import com.asiainfo.biframe.privilege.model.User_User;

public abstract interface IAutoLoginDao
{
  public abstract User_User getUserInfoByUserId(String paramString);

  public abstract String getUserIdByOaUSerId(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.autologin.dao.IAutoLoginDao
 * JD-Core Version:    0.6.2
 */
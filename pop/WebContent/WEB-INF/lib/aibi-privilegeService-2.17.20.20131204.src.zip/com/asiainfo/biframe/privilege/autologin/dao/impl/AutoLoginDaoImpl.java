/*    */ package com.asiainfo.biframe.privilege.autologin.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.autologin.dao.IAutoLoginDao;
/*    */ import com.asiainfo.biframe.privilege.model.UserOaMap;
/*    */ import com.asiainfo.biframe.privilege.model.User_User;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class AutoLoginDaoImpl extends HibernateDaoSupport
/*    */   implements IAutoLoginDao
/*    */ {
/*    */   public User_User getUserInfoByUserId(String userId)
/*    */   {
/* 20 */     if ((userId == null) || ("".equals(userId))) {
/* 21 */       return null;
/*    */     }
/* 23 */     User_User userUser = null;
/* 24 */     Object obj = getHibernateTemplate().get(User_User.class, userId);
/* 25 */     if (obj != null) {
/* 26 */       userUser = (User_User)obj;
/*    */     }
/* 28 */     return userUser;
/*    */   }
/*    */ 
/*    */   public String getUserIdByOaUSerId(String oaUserId)
/*    */   {
/* 37 */     if ((oaUserId == null) || ("".equals(oaUserId))) {
/* 38 */       return null;
/*    */     }
/* 40 */     String userId = null;
/* 41 */     String hql = "from UserOaMap a where a.oaUserId=?";
/* 42 */     List list = getHibernateTemplate().find(hql, oaUserId);
/* 43 */     if ((list != null) && (list.size() > 0)) {
/* 44 */       userId = ((UserOaMap)list.get(0)).getRoleId();
/*    */     }
/* 46 */     return userId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.autologin.dao.impl.AutoLoginDaoImpl
 * JD-Core Version:    0.6.2
 */
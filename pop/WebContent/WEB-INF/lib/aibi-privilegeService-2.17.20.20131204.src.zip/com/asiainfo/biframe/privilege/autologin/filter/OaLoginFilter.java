/*     */ package com.asiainfo.biframe.privilege.autologin.filter;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.PrivilegeConstant;
/*     */ import com.asiainfo.biframe.privilege.autologin.service.IAutoLoginService;
/*     */ import com.asiainfo.biframe.privilege.base.filter.AutoLoginFilter;
/*     */ import com.asiainfo.biframe.privilege.base.listener.SessionListener;
/*     */ import com.asiainfo.biframe.privilege.base.util.SpringUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.URLDecoder;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class OaLoginFilter
/*     */   implements Filter
/*     */ {
/*  28 */   private static Log log = LogFactory.getLog(AutoLoginFilter.class);
/*     */   private String filterUtl;
/*     */   private String isCoding;
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/*  35 */     this.filterUtl = filterConfig.getInitParameter("filterUrl");
/*  36 */     this.isCoding = filterConfig.getInitParameter("isCoding");
/*  37 */     if ((this.isCoding == null) || (!this.isCoding.equals("true")))
/*  38 */       this.isCoding = "false";
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws IOException, ServletException
/*     */   {
/*  44 */     log.debug("进入拦截器");
/*  45 */     if ((this.filterUtl == null) || ("".equals(this.filterUtl))) {
/*  46 */       filterChain.doFilter(request, response);
/*  47 */       return;
/*     */     }
/*     */ 
/*  50 */     HttpServletRequest servletRequest = (HttpServletRequest)request;
/*  51 */     log.debug("debug:" + servletRequest.getRequestURL());
/*  52 */     StringBuffer pathInfo = new StringBuffer(servletRequest.getContextPath());
/*  53 */     pathInfo.append("/").append(this.filterUtl);
/*  54 */     if (!pathInfo.toString().equals(servletRequest.getRequestURI())) {
/*  55 */       filterChain.doFilter(request, response);
/*  56 */       return;
/*     */     }
/*  58 */     log.debug("pathInfo:" + pathInfo);
/*  59 */     String userId = servletRequest.getParameter("userId");
/*  60 */     if ((this.isCoding != null) && (this.isCoding.equals("true")) && (userId != null) && (!"".equals(userId))) {
/*  61 */       userId = URLDecoder.decode(userId, "UTF-8");
/*     */     }
/*     */ 
/*  64 */     IAutoLoginService autoLoginService = (IAutoLoginService)SpringUtil.getBean("right_autoLoginService");
/*  65 */     HttpServletResponse servletResponse = (HttpServletResponse)response;
/*     */ 
/*  67 */     userId = autoLoginService.getOriginalUserId(userId);
/*  68 */     String retInfo = autoLoginService.checkUserId(userId);
/*  69 */     if ((userId == null) || ("".equals(userId)) || (!retInfo.equals(PrivilegeConstant.USERLOGIN_RETURN_TYPE_0))) {
/*  70 */       if (retInfo.equals(PrivilegeConstant.USERLOGIN_RETURN_TYPE_1))
/*  71 */         retInfo = "Sorry, User does not exist!";
/*  72 */       else if (retInfo.equals(PrivilegeConstant.USERLOGIN_RETURN_TYPE_2)) {
/*  73 */         retInfo = "Sorry, the user is locked!";
/*     */       }
/*     */ 
/*  77 */       filterChain.doFilter(request, response);
/*  78 */       return;
/*     */     }
/*  80 */     userLogin(servletRequest, userId);
/*  81 */     String redirectUrl = request.getParameter("redirectUrl");
/*  82 */     if ((redirectUrl != null) && (!"".equals(redirectUrl))) {
/*  83 */       redirectUrl = URLDecoder.decode(redirectUrl, "UTF-8");
/*  84 */       if (redirectUrl.indexOf("/") == 0) {
/*  85 */         redirectUrl = redirectUrl.substring(1, redirectUrl.length());
/*     */       }
/*  87 */       String contextPath = servletRequest.getContextPath();
/*  88 */       if (StringUtil.isNotEmpty(contextPath)) {
/*  89 */         if (contextPath.indexOf("/") == 0) {
/*  90 */           contextPath = contextPath.substring(1, contextPath.length());
/*     */         }
/*     */ 
/*  93 */         if (redirectUrl.indexOf(contextPath) == 0) {
/*  94 */           redirectUrl = redirectUrl.substring(contextPath.length() + 1, redirectUrl.length());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  99 */     log.debug("redirectUrl:" + redirectUrl);
/* 100 */     servletResponse.sendRedirect(redirectUrl);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   private void userLogin(HttpServletRequest request, String userId) {
/* 108 */     SessionListener mySession = (SessionListener)request.getSession().getAttribute("ASIA_SESSION_NAME");
/*     */     try {
/* 110 */       if (mySession == null) {
/* 111 */         SessionListener sessionListener = SessionListener.login(request, userId, null);
/* 112 */         request.getSession().setAttribute("ASIA_SESSION_NAME", sessionListener);
/* 113 */         request.getSession().setAttribute("aibi_component_privilege_sessionlistener", sessionListener);
/* 114 */       } else if ((mySession != null) && 
/* 115 */         (!mySession.getUserID().equalsIgnoreCase(userId))) {
/* 116 */         SessionListener sessionListener = SessionListener.login(request, userId, null);
/* 117 */         request.getSession().setAttribute("ASIA_SESSION_NAME", sessionListener);
/* 118 */         request.getSession().setAttribute("aibi_component_privilege_sessionlistener", sessionListener);
/*     */       }
/*     */     } catch (Exception e) {
/* 121 */       log.error("自动登录用户出现异常！", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.autologin.filter.OaLoginFilter
 * JD-Core Version:    0.6.2
 */
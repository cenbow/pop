/*    */ package com.asiainfo.biframe.privilege.autologin.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*    */ import com.asiainfo.biframe.privilege.PrivilegeConstant;
/*    */ import com.asiainfo.biframe.privilege.autologin.dao.IAutoLoginDao;
/*    */ import com.asiainfo.biframe.privilege.autologin.service.IAutoLoginService;
/*    */ import com.asiainfo.biframe.privilege.base.filter.AutoLoginFilter;
/*    */ import com.asiainfo.biframe.privilege.model.User_User;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class AutoLoginServiceImpl
/*    */   implements IAutoLoginService
/*    */ {
/* 14 */   private static Log log = LogFactory.getLog(AutoLoginFilter.class);
/*    */   private IAutoLoginDao autoLoginDao;
/*    */   private IUserPrivilegeService privilegeService;
/*    */ 
/*    */   public String getOriginalUserId(String oaUserId)
/*    */   {
/* 24 */     oaUserId = this.privilegeService.decryption(oaUserId);
/* 25 */     String userId = this.autoLoginDao.getUserIdByOaUSerId(oaUserId);
/* 26 */     return userId;
/*    */   }
/*    */ 
/*    */   public String checkUserId(String userId)
/*    */   {
/* 36 */     User_User user = this.autoLoginDao.getUserInfoByUserId(userId);
/* 37 */     if (user == null)
/* 38 */       return PrivilegeConstant.USERLOGIN_RETURN_TYPE_1;
/* 39 */     if (user.getStatus() == PrivilegeConstant.USER_STATUS_1) {
/* 40 */       return PrivilegeConstant.USERLOGIN_RETURN_TYPE_2;
/*    */     }
/* 42 */     return PrivilegeConstant.USERLOGIN_RETURN_TYPE_0;
/*    */   }
/*    */ 
/*    */   public IAutoLoginDao getAutoLoginDao()
/*    */   {
/* 51 */     return this.autoLoginDao;
/*    */   }
/*    */ 
/*    */   public void setAutoLoginDao(IAutoLoginDao autoLoginDao)
/*    */   {
/* 58 */     this.autoLoginDao = autoLoginDao;
/*    */   }
/*    */ 
/*    */   public IUserPrivilegeService getPrivilegeService()
/*    */   {
/* 66 */     return this.privilegeService;
/*    */   }
/*    */ 
/*    */   public void setPrivilegeService(IUserPrivilegeService privilegeService)
/*    */   {
/* 74 */     this.privilegeService = privilegeService;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.autologin.service.impl.AutoLoginServiceImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.base.constants;
/*     */ 
/*     */ import com.asiainfo.biframe.common.SysCodes;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class PrivilegeCodes extends SysCodes
/*     */ {
/*  24 */   protected static final transient Logger log = Logger.getLogger(PrivilegeCodes.class);
/*     */   public static final String AIBI_PRIVILEGE_PROPERTIES = "AIBI_PRIVILEGE_PROPERTIES";
/*     */   public static final String PRIVILEGE_SESSION_LISTENER = "aibi_component_privilege_sessionlistener";
/*     */   public static final String RESOURCETYPE_SPECIAL_V4 = "1002";
/*     */   public static final String RESOURCETYPE_SPECIAL_V5 = "1003";
/*     */   public static final String RESOURCETYPE_CITY_REPORT = "300";
/*     */   public static final String RESOURCETYPE_FUNCTION_DEFINE = "1001";
/*     */   public static final int DATA_TYPE_INT = 1;
/*     */   public static final int DATA_TYPE_DOUBLE = 2;
/*     */   public static final int DATA_TYPE_PERSENT = 3;
/*     */   public static final int DATA_TYPE_ACCOUNT = 4;
/*     */   public static final int DATA_TYPE_STRING = 5;
/*     */   public static final int DATA_TYPE_DATE = 6;
/*     */   public static final int DATA_TYPE_TIME = 7;
/*     */   public static final String DATA_PACAGE_USERNAME_OR_PASS = "0";
/*     */   public static final String DATA_PACAGE_TOKEN = "1";
/*     */   public static final String PRIVILEGE_TEMP_DIR = "privilege_upload";
/*     */   public static final String TEMP_RIGHT_NEED_APPROVE = "0";
/*     */   public static final String TEMP_RIGHT_NEED_NOT_APPROVE = "1";
/*  78 */   private static Map<String, String> applyTypeMap = null;
/*     */   public static final String TRANSACTION_MANAGER_BEAN_NAME = "transactionManager";
/*     */   public static final String RESOURCETYPE_PRIVACY = "1005";
/*     */   public static final int DS_TYPE_LOCAL_XML = 0;
/*     */   public static final int DS_TYPE_LOCAL_TABLE = 1;
/*     */   public static final int DS_TYPE_JNDI = 2;
/*     */   public static final int DS_TYPE_WS = 3;
/*     */   public static final String CACHE_KEY_PRIVILEGE_USER_ROLE_CLASSIFY = "privlege-user-role_classify_cache";
/*     */   public static final String TOP_LEVEL_COMPANY_PARENT_ID = "0";
/*     */   public static final String CACHE_KEY_PRIVILEGE_SYS_MENU_ITEM_VIEW = "privlege-sys-menu-item-view-cache";
/*     */ 
/*     */   public static boolean checkSysParameter(String strKey)
/*     */   {
/*  43 */     String str = getSysParameter(strKey);
/*  44 */     return (str != null) && (!str.trim().equals("0"));
/*     */   }
/*     */ 
/*     */   public static Map<String, String> getApplyTypeMap()
/*     */   {
/*  81 */     Map applyTypeMap = new HashMap();
/*  82 */     applyTypeMap.put("0", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.needApplication") + "");
/*  83 */     applyTypeMap.put("1", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.needNotApplication") + "");
/*  84 */     return applyTypeMap;
/*     */   }
/*     */ 
/*     */   public static String getPrivilegeTempFileDir()
/*     */   {
/*  91 */     String parentDir = Configure.getInstance().getProperty("SYS_COMMON_UPLOAD_PATH");
/*  92 */     if (StringUtils.isBlank(parentDir)) {
/*  93 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findUploadDirFailDetail"));
/*  94 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findUploadDirFail") + "");
/*     */     }
/*     */ 
/*  97 */     String privilegeTempDir = "";
/*     */     try {
/*  99 */       privilegeTempDir = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "PRIVILEGEADMIN_UPLOAD_DIR");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 106 */       e.printStackTrace();
/*     */     }
/* 108 */     if (StringUtil.isEmpty(privilegeTempDir)) privilegeTempDir = "privilege_upload";
/*     */ 
/* 110 */     String tempDir = parentDir + File.separator + privilegeTempDir;
/* 111 */     log.debug("----tempDir:" + tempDir);
/* 112 */     File dirFile = new File(tempDir);
/* 113 */     if (!dirFile.exists()) {
/* 114 */       dirFile.mkdirs();
/*     */     }
/* 116 */     return tempDir;
/*     */   }
/*     */ 
/*     */   public static boolean isSurpport4AOfCompany()
/*     */   {
/* 124 */     String surpportCompany4AOrNot = null;
/*     */     try {
/* 126 */       surpportCompany4AOrNot = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "SURPPORT_COMPANY_4A_OR_NOT");
/*     */     } catch (Exception e) {
/* 128 */       e.printStackTrace();
/*     */     }
/* 130 */     return "true".equals(surpportCompany4AOrNot);
/*     */   }
/*     */ 
/*     */   public static String getWsUrl4A()
/*     */   {
/* 152 */     String wsUrl4A = "";
/*     */     try {
/* 154 */       wsUrl4A = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "WEBSERVICE_URL_4A");
/*     */     } catch (Exception e) {
/* 156 */       throw new RuntimeException("---get---Configure--err--" + e.getMessage(), e);
/*     */     }
/*     */ 
/* 159 */     return wsUrl4A;
/*     */   }
/*     */ 
/*     */   public static String get4A_SERVICEID()
/*     */   {
/* 169 */     String fourAServiceId = "";
/*     */     try {
/* 171 */       fourAServiceId = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "4A_SERVICEID");
/*     */     } catch (Exception e) {
/* 173 */       throw new RuntimeException("---get---Configure--err--" + e.getMessage(), e);
/*     */     }
/*     */ 
/* 176 */     return fourAServiceId;
/*     */   }
/*     */ 
/*     */   public static boolean isRecordUserLogin()
/*     */   {
/* 186 */     String isRecordUserLogin = null;
/*     */     try {
/* 188 */       isRecordUserLogin = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "RECORD_USER_LOGIN_OR_NOT");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 192 */       throw new RuntimeException(e);
/*     */     }
/* 194 */     return "true".equals(isRecordUserLogin);
/*     */   }
/*     */ 
/*     */   public static String get3TreeInitResourceType()
/*     */   {
/* 199 */     String initResourceType = "5";
/*     */     try {
/* 201 */       initResourceType = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "THREE_TREE_RESOURCE_TYPE_LIST_BOX_INIT_TYPE");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 205 */       throw new RuntimeException(e);
/*     */     }
/* 207 */     return initResourceType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.constants.PrivilegeCodes
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.base.constants;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.base.util.PrivilegeConfigure;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserManager extends PrivilegeCodes
/*     */ {
/*  17 */   private static Log log = LogFactory.getLog(UserManager.class);
/*     */ 
/*  81 */   private static Hashtable m_hashCityName = new Hashtable();
/*     */ 
/*     */   public static String getOlapClient()
/*     */   {
/*  20 */     String OlapClient = PrivilegeConfigure.getInstance().getProperty("OLAPCLIENT");
/*  21 */     if ((OlapClient == null) || (OlapClient.length() < 1))
/*     */     {
/*  23 */       OlapClient = "BRIO";
/*     */     }
/*  25 */     return OlapClient;
/*     */   }
/*     */ 
/*     */   public static String getHostAddress()
/*     */   {
/*  33 */     String strHost = "";
/*     */     try
/*     */     {
/*  36 */       strHost = Configure.getInstance().getProperty("HOST_ADDRESS");
/*  37 */       if ((null == strHost) || (strHost.trim().length() < 1))
/*     */       {
/*  39 */         log.warn("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.hostAddressNotConfig") + "");
/*  40 */         strHost = "localhost";
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  45 */       strHost = "localhost";
/*     */     }
/*  47 */     return strHost;
/*     */   }
/*     */ 
/*     */   public static String getUserFromOAUserID(String strOaID)
/*     */     throws Exception
/*     */   {
/*  58 */     Sqlca sqlca = null;
/*  59 */     String strRet = null;
/*     */     try
/*     */     {
/*  62 */       sqlca = new Sqlca(new ConnectionEx());
/*  63 */       sqlca.execute("select roleid from user_oa_map where oauserid='" + strOaID + "'");
/*  64 */       if (sqlca.next())
/*     */       {
/*  66 */         strRet = sqlca.getString("roleid");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/*  72 */       throw excep;
/*     */     }
/*     */     finally
/*     */     {
/*  76 */       sqlca.closeAll();
/*     */     }
/*  78 */     return strRet;
/*     */   }
/*     */ 
/*     */   public static String getCityName(String strCityID)
/*     */     throws Exception
/*     */   {
/*  91 */     if (null != m_hashCityName.get(strCityID))
/*     */     {
/*  93 */       return "" + m_hashCityName.get(strCityID);
/*     */     }
/*  95 */     Sqlca sqlca = null;
/*     */     try
/*     */     {
/*  98 */       sqlca = new Sqlca(new ConnectionEx());
/*  99 */       sqlca.execute("select cityname from user_city where cityid ='" + strCityID + "'");
/* 100 */       if (!sqlca.next())
/*     */       {
/* 102 */         throw new Exception("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cityFail") + "");
/*     */       }
/* 104 */       String str = sqlca.getString("cityname");
/* 105 */       m_hashCityName.put(strCityID, str);
/* 106 */       return str;
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/* 110 */       excep.printStackTrace();
/* 111 */       throw new Exception("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cityFail") + "");
/*     */     }
/*     */     finally
/*     */     {
/* 115 */       if (null != sqlca)
/*     */       {
/* 117 */         sqlca.closeAll();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getCenterCityId()
/*     */   {
/* 128 */     String strCenterid = "";
/*     */     try
/*     */     {
/* 131 */       strCenterid = Configure.getInstance().getProperty("CENTER_CITYID");
/* 132 */       if ((null == strCenterid) || (strCenterid.trim().length() < 1))
/*     */       {
/* 134 */         strCenterid = "999";
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 139 */       strCenterid = "999";
/*     */     }
/* 141 */     return strCenterid;
/*     */   }
/*     */ 
/*     */   public static boolean isCenterCity(String strUserRoles, boolean bLoginCity)
/*     */     throws Exception
/*     */   {
/* 155 */     String strCenterid = getCenterCityId();
/* 156 */     if (bLoginCity)
/*     */     {
/* 158 */       String strLoginCityId = strUserRoles;
/* 159 */       return strLoginCityId.equals(strCenterid);
/*     */     }
/*     */ 
/* 162 */     Sqlca sqlca = null;
/*     */     try
/*     */     {
/* 165 */       sqlca = new Sqlca(new ConnectionEx());
/* 166 */       boolean bLoginCenterCity = false;
/* 167 */       String strAllCityID = getAllCityID(sqlca, strUserRoles, false);
/* 168 */       if (strAllCityID.indexOf("'" + strCenterid + "'") >= 0)
/*     */       {
/* 170 */         bLoginCenterCity = true;
/*     */       }
/* 172 */       return bLoginCenterCity;
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/* 176 */       excep.printStackTrace();
/*     */     }
/*     */     finally
/*     */     {
/* 180 */       sqlca.closeAll();
/*     */     }
/* 182 */     return false;
/*     */   }
/*     */ 
/*     */   public static String getAllCityID(Sqlca sqlcaA, String strRoles, boolean bTopLevel)
/*     */   {
/* 199 */     if ((null == strRoles) || (strRoles.trim().length() < 1))
/* 200 */       return null;
/* 201 */     Sqlca sqlca = null;
/*     */     try
/*     */     {
/* 204 */       if (sqlcaA != null)
/* 205 */         sqlca = new Sqlca(sqlcaA.getConnection());
/*     */       else
/* 207 */         sqlca = new Sqlca(new ConnectionEx());
/* 208 */       String sqlin = popularUserRightWhere(strRoles);
/* 209 */       String strRet = "";
/* 210 */       String strSQL = "select distinct resourceid  from user_right a,user_city b where 1=1 " + sqlin + " and operatortype=" + "0" + " and resourcetype=" + "5" + " and a.resourceid = b.cityid";
/*     */ 
/* 221 */       if (strRoles.equals("-999")) {
/* 222 */         strSQL = "select cityid resourceid from user_city b where 1=1 ";
/*     */       }
/*     */ 
/* 227 */       if ((bTopLevel) || (!PrivilegeCodes.checkSysParameter("SYS_RIGHT_REGIONDETAIL")))
/*     */       {
/* 229 */         strSQL = strSQL + " and b.parentid ='-1'";
/*     */       }
/* 231 */       sqlca.execute(strSQL);
/*     */       String strID;
/* 232 */       while (sqlca.next())
/*     */       {
/* 234 */         strID = sqlca.getString("resourceid");
/* 235 */         if (strRet.length() > 0)
/* 236 */           strRet = strRet + ",";
/* 237 */         strRet = strRet + "'" + strID + "'";
/*     */       }
/* 239 */       return strRet;
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/* 244 */       excep.printStackTrace();
/*     */     }
/*     */     finally
/*     */     {
/* 248 */       if (sqlcaA != null)
/* 249 */         sqlca.close();
/*     */       else
/* 251 */         sqlca.closeAll();
/*     */     }
/* 253 */     return null;
/*     */   }
/*     */ 
/*     */   private static String popularUserRightWhere(String strRoles)
/*     */   {
/* 260 */     String roles = "";
/* 261 */     String[] strRolesArry = strRoles.split(",");
/* 262 */     int cnt = 1;
/* 263 */     for (int i = 0; i < strRolesArry.length; i++) {
/* 264 */       if (strRolesArry[i].indexOf("'") < 0) {
/* 265 */         roles = roles + "'" + strRolesArry[i] + "'" + ",";
/*     */       }
/*     */       else {
/* 268 */         roles = roles + strRolesArry[i] + ",";
/*     */       }
/*     */ 
/* 271 */       cnt++;
/* 272 */       if (cnt > 1000) {
/*     */         break;
/*     */       }
/*     */     }
/* 276 */     return " and operatorid in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/*     */   }
/*     */ 
/*     */   public static String getUserCityID(Sqlca sqlcaA, String strUserID)
/*     */     throws Exception
/*     */   {
/* 289 */     Sqlca sqlca = null;
/*     */     try
/*     */     {
/* 294 */       String strRet = "";
/* 295 */       String strSql = "";
/* 296 */       String strCityId = "";
/* 297 */       String strParam7 = "";
/* 298 */       User_User user = (User_User)UserCache.getInstance().getObjectByKey(strUserID);
/* 299 */       if (checkSysParameter("SYS_DYN_CITYID"))
/*     */       {
/* 301 */         if (sqlcaA != null)
/* 302 */           sqlca = new Sqlca(sqlcaA.getConnection());
/*     */         else {
/* 304 */           sqlca = new Sqlca(new ConnectionEx());
/*     */         }
/*     */ 
/* 307 */         strSql = "select PARAM7 city from user_user,user_user_ext where user_user.userid=user_user_ext.userid and user_user.userid ='" + strUserID.trim() + "'";
/*     */ 
/* 309 */         sqlca.execute(strSql);
/* 310 */         if (sqlca.next())
/*     */         {
/* 312 */           strParam7 = sqlca.getString("city");
/*     */         }
/*     */       }
/* 315 */       strCityId = user.getCityid();
/* 316 */       if (strParam7.length() > 0)
/*     */       {
/* 318 */         strRet = strParam7;
/*     */       }
/*     */       else
/*     */       {
/* 322 */         strRet = strCityId;
/*     */       }
/* 324 */       return strRet;
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/* 328 */       excep.printStackTrace();
/* 329 */       throw new Exception(excep.getMessage());
/*     */     }
/*     */     finally
/*     */     {
/* 333 */       if ((sqlcaA == null) && (sqlca != null))
/* 334 */         sqlca.closeAll();
/* 335 */       else if (sqlca != null)
/* 336 */         sqlca.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.constants.UserManager
 * JD-Core Version:    0.6.2
 */
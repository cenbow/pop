/*    */ package com.asiainfo.biframe.privilege.base.exception;
/*    */ 
/*    */ public class MessageException extends RuntimeException
/*    */ {
/*    */   public MessageException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MessageException(String message)
/*    */   {
/* 22 */     super(message);
/*    */   }
/*    */ 
/*    */   public MessageException(String message, Throwable cause)
/*    */   {
/* 27 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public MessageException(Throwable cause)
/*    */   {
/* 32 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.exception.MessageException
 * JD-Core Version:    0.6.2
 */
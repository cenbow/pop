/*    */ package com.asiainfo.biframe.privilege.base.filter;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.NotLoginException;
/*    */ import com.asiainfo.biframe.privilege.base.listener.SessionListener;
/*    */ import com.asiainfo.biframe.utils.string.DES;
/*    */ import com.asiainfo.biframe.utils.string.StringUtil;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class AutoLoginFilter
/*    */   implements Filter
/*    */ {
/* 35 */   private static Log log = LogFactory.getLog(AutoLoginFilter.class);
/* 36 */   protected boolean autoLogin = false;
/*    */ 
/*    */   public void init(FilterConfig arg0)
/*    */     throws ServletException
/*    */   {
/* 43 */     String value = arg0.getInitParameter("autoLogin");
/* 44 */     if ((value != null) && ((value.equalsIgnoreCase("yes")) || (value.equalsIgnoreCase("true"))))
/* 45 */       this.autoLogin = true;
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 54 */     HttpServletRequest hrequest = (HttpServletRequest)request;
/* 55 */     HttpServletResponse hresponse = (HttpServletResponse)response;
/* 56 */     String userId = hrequest.getParameter("ailk_autoLogin_userId");
/* 57 */     if ((StringUtil.isEmpty(userId)) || (userId.equalsIgnoreCase("null"))) {
/* 58 */       chain.doFilter(hrequest, hresponse);
/* 59 */       return;
/*    */     }
/* 61 */     log.debug("AutoLoginFilter userId=" + userId);
/*    */     try
/*    */     {
/* 65 */       userId = DES.decrypt(userId);
/*    */     } catch (Exception ex) {
/* 67 */       log.warn("AutoLoginFilter userId=[" + userId + "],cant't be decrypted, ignore...");
/* 68 */       throw new NotLoginException();
/*    */     }
/*    */     try {
/* 71 */       log.debug("AutoLoginFilter after decrypt,userId=" + userId);
/*    */ 
/* 73 */       SessionListener mysession = (SessionListener)hrequest.getSession().getAttribute("ASIA_SESSION_NAME");
/* 74 */       if (mysession == null) {
/* 75 */         log.info("\n\n\n>>AutoLoginFilter New user [" + userId + "] from" + hrequest.getRemoteAddr() + " login in...");
/* 76 */         SessionListener sessionListener = SessionListener.login(hrequest, userId, null);
/* 77 */         hrequest.getSession().setAttribute("ASIA_SESSION_NAME", sessionListener);
/* 78 */         hrequest.getSession().setAttribute("aibi_component_privilege_sessionlistener", sessionListener);
/* 79 */       } else if ((mysession != null) && 
/* 80 */         (!mysession.getUserID().equalsIgnoreCase(userId))) {
/* 81 */         log.info("\n\n\n>>AutoLoginFilter Request has a session, but a new user [" + userId + "] from" + hrequest.getRemoteAddr() + " login in...");
/* 82 */         SessionListener sessionListener = SessionListener.login(hrequest, userId, null);
/* 83 */         hrequest.getSession().setAttribute("ASIA_SESSION_NAME", sessionListener);
/* 84 */         hrequest.getSession().setAttribute("aibi_component_privilege_sessionlistener", sessionListener);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 88 */       log.error(e);
/*    */     }
/*    */ 
/* 91 */     chain.doFilter(hrequest, hresponse);
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 95 */     this.autoLogin = false;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.filter.AutoLoginFilter
 * JD-Core Version:    0.6.2
 */
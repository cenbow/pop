/*    */ package com.asiainfo.biframe.privilege.base.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.StringTokenizer;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class CheckLoginFilter
/*    */   implements Filter
/*    */ {
/* 22 */   protected FilterConfig filterConfig = null;
/* 23 */   private String redirectURL = null;
/* 24 */   private List notCheckURLList = new ArrayList();
/* 25 */   private String sessionKey = null;
/*    */ 
/*    */   public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException
/*    */   {
/* 29 */     HttpServletRequest request = (HttpServletRequest)servletRequest;
/* 30 */     HttpServletResponse response = (HttpServletResponse)servletResponse;
/*    */ 
/* 32 */     HttpSession session = request.getSession();
/* 33 */     if (this.sessionKey == null)
/*    */     {
/* 35 */       filterChain.doFilter(request, response);
/* 36 */       return;
/*    */     }
/* 38 */     if ((!checkRequestURIIntNotFilterList(request)) && (session.getAttribute(this.sessionKey) == null))
/*    */     {
/* 40 */       response.sendRedirect(request.getContextPath() + this.redirectURL);
/* 41 */       return;
/*    */     }
/* 43 */     filterChain.doFilter(servletRequest, servletResponse);
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/* 48 */     this.notCheckURLList.clear();
/*    */   }
/*    */ 
/*    */   private boolean checkRequestURIIntNotFilterList(HttpServletRequest request)
/*    */   {
/* 53 */     String uri = request.getServletPath() + (request.getPathInfo() == null ? "" : request.getPathInfo());
/* 54 */     return this.notCheckURLList.contains(uri);
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig filterConfig) throws ServletException
/*    */   {
/* 59 */     this.filterConfig = filterConfig;
/* 60 */     this.redirectURL = filterConfig.getInitParameter("redirectURL");
/* 61 */     this.sessionKey = filterConfig.getInitParameter("checkSessionKey");
/*    */ 
/* 63 */     String notCheckURLListStr = filterConfig.getInitParameter("notCheckURLList");
/*    */ 
/* 65 */     if (notCheckURLListStr != null)
/*    */     {
/* 67 */       StringTokenizer st = new StringTokenizer(notCheckURLListStr, ";");
/* 68 */       this.notCheckURLList.clear();
/* 69 */       while (st.hasMoreTokens())
/*    */       {
/* 71 */         this.notCheckURLList.add(st.nextToken());
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.filter.CheckLoginFilter
 * JD-Core Version:    0.6.2
 */
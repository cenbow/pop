/*     */ package com.asiainfo.biframe.privilege.base.filter;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.NotLoginException;
/*     */ import com.asiainfo.biframe.privilege.base.listener.SessionListener;
/*     */ import java.io.IOException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SessionValidFilter
/*     */   implements Filter
/*     */ {
/*  32 */   private Logger log = Logger.getLogger(SessionValidFilter.class);
/*     */   private String[] unproectedUrl;
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  43 */     HttpServletRequest httpReq = (HttpServletRequest)request;
/*  44 */     String requestURI = httpReq.getRequestURI();
/*  45 */     String contextPath = httpReq.getContextPath();
/*  46 */     SessionListener sessionListener = (SessionListener)httpReq.getSession().getAttribute("aibi_component_privilege_sessionlistener");
/*     */ 
/*  49 */     if (sessionListener != null) {
/*  50 */       chain.doFilter(request, response);
/*  51 */       return;
/*     */     }
/*  53 */     if (isExclude(contextPath, requestURI)) {
/*  54 */       chain.doFilter(request, response);
/*  55 */       return;
/*     */     }
/*  57 */     throw new NotLoginException();
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig config)
/*     */     throws ServletException
/*     */   {
/*  77 */     String tem = config.getInitParameter("excludedUrl");
/*  78 */     this.unproectedUrl = (tem == null ? null : tem.split(";"));
/*     */   }
/*     */ 
/*     */   protected final boolean isExclude(String contextPath, String uri)
/*     */   {
/*  91 */     Pattern p = Pattern.compile(contextPath + "/?");
/*  92 */     if (p.matcher(uri).matches()) {
/*  93 */       return true;
/*     */     }
/*  95 */     if (this.unproectedUrl == null) {
/*  96 */       return false;
/*     */     }
/*  98 */     for (String t : this.unproectedUrl) {
/*  99 */       if (t.startsWith("^"))
/* 100 */         p = Pattern.compile(contextPath + "/" + t.substring(1));
/*     */       else {
/* 102 */         p = Pattern.compile(t);
/*     */       }
/* 104 */       if (p.matcher(uri).matches()) {
/* 105 */         return true;
/*     */       }
/*     */     }
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.filter.SessionValidFilter
 * JD-Core Version:    0.6.2
 */
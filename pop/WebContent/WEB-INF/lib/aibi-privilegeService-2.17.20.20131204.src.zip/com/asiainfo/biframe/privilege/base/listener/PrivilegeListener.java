/*    */ package com.asiainfo.biframe.privilege.base.listener;
/*    */ 
/*    */ import com.asiainfo.biframe.manager.context.ContextManager;
/*    */ import com.asiainfo.biframe.privilege.cache.object.SysMenuItemCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.SysMenuItemViewCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.SysResourceDsPropCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.UserCityCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.UserCompanyCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.UserDutyCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.UserGroupDefineCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.UserRoleCache;
/*    */ import com.asiainfo.biframe.privilege.cache.object.UserRoleClassifyCache;
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class PrivilegeListener
/*    */   implements ServletContextListener
/*    */ {
/* 27 */   private static Log log = LogFactory.getLog(PrivilegeListener.class);
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent arg0)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void contextInitialized(ServletContextEvent arg0) {
/*    */     try {
/* 35 */       log.debug(" begin PrivilegeListener");
/*    */ 
/* 38 */       String confFilePath = arg0.getServletContext().getRealPath("/WEB-INF/classes/config/aibi_privilege/privilege.properties");
/* 39 */       Configure.getInstance().addConfFileName("AIBI_PRIVILEGE_PROPERTIES", confFilePath);
/*    */ 
/* 41 */       ContextManager context = new ContextManager();
/* 42 */       context.registerCacheService("privlege-user-cache", UserCache.getInstance());
/* 43 */       context.registerCacheService("privlege-user-group-cache", UserGroupDefineCache.getInstance());
/* 44 */       context.registerCacheService("privlege-user-role-cache", UserRoleCache.getInstance());
/* 45 */       context.registerCacheService("privlege-user-city-cache", UserCityCache.getInstance());
/* 46 */       context.registerCacheService("privlege-user-company-cache", UserCompanyCache.getInstance());
/* 47 */       context.registerCacheService("privlege-user-duty-cache", UserDutyCache.getInstance());
/* 48 */       context.registerCacheService("privlege-sys-resources-type-cache", SysResourceTypeCache.getInstance());
/* 49 */       context.registerCacheService("privlege-menu-item-cache", SysMenuItemCache.getInstance());
/* 50 */       context.registerCacheService("privlege-sys_resource_ds_prop", SysResourceDsPropCache.getInstance());
/* 51 */       context.registerCacheService("privlege-user-role_classify_cache", UserRoleClassifyCache.getInstance());
/* 52 */       context.registerCacheService("privlege-sys-menu-item-view-cache", SysMenuItemViewCache.getInstance());
/*    */ 
/* 54 */       log.debug(" end PrivilegeListener");
/*    */     } catch (Exception e) {
/* 56 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.loadListenerFail"), e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.listener.PrivilegeListener
 * JD-Core Version:    0.6.2
 */
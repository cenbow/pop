/*     */ package com.asiainfo.biframe.privilege.base.listener;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.base.constants.PrivilegeCodes;
/*     */ import com.asiainfo.biframe.privilege.base.constants.UserManager;
/*     */ import com.asiainfo.biframe.privilege.base.vo.PrivilegeUserSession;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.SqlcaPst;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionBindingEvent;
/*     */ import javax.servlet.http.HttpSessionBindingListener;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SessionListener
/*     */   implements HttpSessionBindingListener, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 501911809540566762L;
/*  48 */   private static Log log = LogFactory.getLog(SessionListener.class);
/*  49 */   private User_User m_User = null;
/*  50 */   private String m_strLoginOAUser = "";
/*  51 */   private String m_strSessionID = null;
/*  52 */   private String m_strClientIP = null;
/*  53 */   private String m_strServerAddress = "";
/*  54 */   private String m_browser_version = "";
/*     */   public static final String LOGOUTTYPE_ZHUDONG = "1";
/*     */   public static final String LOGOUTTYPE_BEIDONG = "2";
/*     */ 
/*     */   protected static final IUserAdminService getUserAdminService()
/*     */     throws Exception
/*     */   {
/*  57 */     return (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/*     */   }
/*     */ 
/*     */   public static String getIpAddr(HttpServletRequest request)
/*     */   {
/*  64 */     Enumeration xx = request.getHeaderNames();
/*  65 */     String ip = request.getHeader("x-forwarded-for");
/*  66 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  67 */       ip = request.getHeader("Proxy-Client-IP");
/*     */     }
/*  69 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  70 */       ip = request.getHeader("WL-Proxy-Client-IP");
/*     */     }
/*  72 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  73 */       ip = request.getRemoteAddr();
/*     */     }
/*  75 */     String[] ips = null;
/*  76 */     if (StringUtil.isNotEmpty(ip)) {
/*  77 */       ips = ip.split(",");
/*  78 */       return ips[0];
/*     */     }
/*  80 */     return ip;
/*     */   }
/*     */ 
/*     */   public static SessionListener login(HttpServletRequest request, String strUserID, String strOaUser)
/*     */     throws Exception
/*     */   {
/*  91 */     SessionListener session = new SessionListener();
/*  92 */     session.m_strClientIP = getIpAddr(request);
/*  93 */     session.m_strSessionID = request.getSession().getId();
/*  94 */     session.m_strLoginOAUser = strOaUser;
/*  95 */     session.m_browser_version = getBrowserVersion(request.getHeader("user-agent"));
/*  96 */     log.info("[SessionListener] login sessionid=====" + session.m_strSessionID);
/*     */     try {
/*  98 */       session.m_strServerAddress = UserManager.getHostAddress();
/*     */     } catch (Exception exceo) {
/* 100 */       session.m_strServerAddress = "127.0.0.1";
/*     */     }
/*     */ 
/* 103 */     Sqlca sqlca = null;
/*     */     try {
/* 105 */       IUserUserDAO userDao = (IUserUserDAO)SystemServiceLocator.getInstance().getService("right_userUserDao");
/* 106 */       session.m_User = userDao.findById(strUserID);
/*     */ 
/* 111 */       if (null != sqlca)
/* 112 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/* 108 */       excep.printStackTrace();
/* 109 */       throw excep;
/*     */     } finally {
/* 111 */       if (null != sqlca)
/* 112 */         sqlca.closeAll();
/*     */     }
/* 114 */     return session;
/*     */   }
/*     */ 
/*     */   public void valueBound(HttpSessionBindingEvent event)
/*     */   {
/* 123 */     SqlcaPst sqlca = null;
/* 124 */     Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
/*     */     try {
/* 126 */       sqlca = new SqlcaPst(new ConnectionEx());
/*     */ 
/* 129 */       boolean isRecordUserLogin = PrivilegeCodes.isRecordUserLogin();
/* 130 */       if (isRecordUserLogin == true) {
/* 131 */         String productId = Configure.getInstance().getProperty("PRODUCTID");
/*     */         try {
/* 133 */           String updateSql = "update user_login_history set logouttime=null where sessionid=? and userid=?";
/* 134 */           if (StringUtils.isNotBlank(productId)) {
/* 135 */             updateSql = updateSql + " and productid = ? ";
/*     */           }
/* 137 */           log.info("[SessionListener] --valueBound update sql:" + updateSql);
/*     */ 
/* 139 */           log.info("[SessionListener] --valueBound update sql m_strSessionID:" + this.m_strSessionID);
/*     */ 
/* 142 */           log.info("[SessionListener] --valueBound update sql userId:" + this.m_User.getUserid());
/*     */ 
/* 145 */           sqlca.setSql(updateSql);
/* 146 */           sqlca.setString(1, this.m_strSessionID);
/* 147 */           sqlca.setString(2, this.m_User.getUserid());
/* 148 */           if (StringUtils.isNotBlank(productId)) {
/* 149 */             sqlca.setString(3, productId);
/*     */           }
/* 151 */           sqlca.execute();
/* 152 */           if (sqlca.getSqlRows() < 1) {
/* 153 */             String str = this.m_strLoginOAUser;
/* 154 */             if (null == this.m_strLoginOAUser) {
/* 155 */               str = "";
/*     */             }
/* 157 */             String insertSql = "insert into user_login_history(sessionid,userid,oauser,clientaddress,logintime,serveraddress,browserversion,productid) values(?,?,?,?,?,?,?,?)";
/*     */ 
/* 159 */             log.info("[SessionListener] --valueBound insert sql:" + insertSql);
/*     */ 
/* 161 */             log.info("[SessionListener] --valueBound update sql m_strSessionID:" + this.m_strSessionID);
/*     */ 
/* 164 */             log.info("[SessionListener] --valueBound update sql userId:" + this.m_User.getUserid());
/*     */ 
/* 167 */             log.info("[SessionListener] --valueBound update sql oauser:" + str);
/*     */ 
/* 170 */             log.info("[SessionListener] --valueBound update sql clientaddress:" + this.m_strClientIP);
/*     */ 
/* 173 */             log.info("[SessionListener] --valueBound update sql logintime:" + currentTimestamp);
/*     */ 
/* 176 */             log.info("[SessionListener] --valueBound update sql serveraddress:" + this.m_strServerAddress);
/*     */ 
/* 179 */             log.info("[SessionListener] --valueBound update sql browserversion:" + this.m_browser_version);
/*     */ 
/* 182 */             sqlca.setSql(insertSql);
/* 183 */             int index = 1;
/* 184 */             sqlca.setString(index++, this.m_strSessionID);
/* 185 */             sqlca.setString(index++, this.m_User.getUserid());
/* 186 */             sqlca.setString(index++, str);
/* 187 */             sqlca.setString(index++, this.m_strClientIP);
/* 188 */             sqlca.setTimestamp(index++, currentTimestamp);
/* 189 */             sqlca.setString(index++, this.m_strServerAddress);
/* 190 */             sqlca.setString(index++, this.m_browser_version);
/* 191 */             sqlca.setString(index++, productId);
/* 192 */             sqlca.execute();
/*     */           }
/*     */         } catch (Exception ex) {
/* 195 */           throw new RuntimeException(ex);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 200 */       String oaUserId = "";
/* 201 */       String oaUserSql = " select oauserid from user_oa_map where roletype=1 and roleid='" + this.m_User.getUserid() + "'";
/*     */ 
/* 203 */       sqlca.execute(oaUserSql);
/* 204 */       while (sqlca.next()) {
/* 205 */         oaUserId = sqlca.getString("oauserid");
/*     */       }
/* 207 */       User_Group group = getUserAdminService().getGroupObject(this.m_User.getUserid());
/*     */ 
/* 209 */       if (group == null) {
/* 210 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userGroupEmpty") + "");
/*     */       }
/*     */ 
/* 214 */       this.m_User.setGroupId(group.getGroupid());
/*     */ 
/* 216 */       PrivilegeUserSession sessionUser = new PrivilegeUserSession();
/* 217 */       sessionUser.setUser(this.m_User);
/* 218 */       sessionUser.setClientIp(this.m_strClientIP);
/* 219 */       sessionUser.setServerIp(this.m_strServerAddress);
/* 220 */       sessionUser.setSessionId(this.m_strSessionID);
/* 221 */       sessionUser.setLoginTime(currentTimestamp);
/* 222 */       sessionUser.setOaUserId(oaUserId);
/* 223 */       sessionUser.setGroupId(group.getGroupid());
/* 224 */       event.getSession().setAttribute("biplatform_user", sessionUser);
/*     */ 
/* 226 */       SessionListenerContainer.userSessionMap.put(this.m_strSessionID, sessionUser);
/*     */ 
/* 228 */       log.info("[SessionListener] --valueBound put PrivilegeUserSession into \"biplatform_user\"");
/*     */ 
/* 234 */       if (null != sqlca)
/* 235 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 232 */       throw new RuntimeException(e);
/*     */     } finally {
/* 234 */       if (null != sqlca)
/* 235 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void valueUnbound(HttpSessionBindingEvent event)
/*     */   {
/* 251 */     boolean isRecordUserLogin = PrivilegeCodes.isRecordUserLogin();
/* 252 */     if (isRecordUserLogin == true) {
/* 253 */       String productId = Configure.getInstance().getProperty("PRODUCTID");
/* 254 */       SqlcaPst sqlca = null;
/*     */       try {
/* 256 */         sqlca = new SqlcaPst(new ConnectionEx());
/* 257 */         String sql = " update user_login_history set logouttime=?,logouttype = ?  where userid = ? and sessionid = ? and logouttime is null ";
/*     */ 
/* 259 */         if (StringUtils.isNotBlank(productId)) {
/* 260 */           sql = sql + " and productid = ? ";
/*     */         }
/* 262 */         log.info("[SessionListener] --valueUnbound  sql:" + sql);
/* 263 */         sqlca.setSql(sql);
/* 264 */         Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
/* 265 */         sqlca.setTimestamp(1, currentTimestamp);
/* 266 */         sqlca.setString(2, "2");
/* 267 */         sqlca.setString(3, this.m_User.getUserid());
/* 268 */         sqlca.setString(4, this.m_strSessionID);
/* 269 */         if (StringUtils.isNotBlank(productId)) {
/* 270 */           sqlca.setString(5, productId);
/*     */         }
/* 272 */         sqlca.execute();
/*     */ 
/* 276 */         if (null != sqlca)
/* 277 */           sqlca.closeAll();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 274 */         throw new RuntimeException(e);
/*     */       } finally {
/* 276 */         if (null != sqlca) {
/* 277 */           sqlca.closeAll();
/*     */         }
/*     */       }
/*     */     }
/* 281 */     SessionListenerContainer.userSessionMap.remove(this.m_strSessionID);
/*     */   }
/*     */ 
/*     */   public String getUserID()
/*     */     throws Exception
/*     */   {
/* 291 */     return this.m_User.getUserid();
/*     */   }
/*     */ 
/*     */   public String getUserName()
/*     */     throws Exception
/*     */   {
/* 301 */     return this.m_User.getUsername();
/*     */   }
/*     */ 
/*     */   public String getOAUserID() throws Exception {
/* 305 */     return this.m_strLoginOAUser;
/*     */   }
/*     */ 
/*     */   public String getUserRoles()
/*     */     throws Exception
/*     */   {
/* 316 */     IUserAdminService userService = (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/* 317 */     return userService.getGroup(this.m_User.getUserid());
/*     */   }
/*     */ 
/*     */   public String getUserCityID()
/*     */     throws Exception
/*     */   {
/* 327 */     return this.m_User.getCityid();
/*     */   }
/*     */ 
/*     */   public String getClientIP()
/*     */   {
/* 336 */     return this.m_strClientIP;
/*     */   }
/*     */ 
/*     */   public String getLoginOAUser()
/*     */   {
/* 345 */     return this.m_strLoginOAUser;
/*     */   }
/*     */ 
/*     */   public String getSessionID()
/*     */   {
/* 354 */     return this.m_strSessionID;
/*     */   }
/*     */ 
/*     */   private static String getBrowserVersion(String user_agent)
/*     */   {
/* 364 */     if (user_agent.indexOf("MSIE 6.0") > 0)
/* 365 */       return "IE 6.0";
/* 366 */     if (user_agent.indexOf("MSIE 8.0") > 0)
/* 367 */       return "IE 8.0";
/* 368 */     if (user_agent.indexOf("MSIE 7.0") > 0)
/* 369 */       return "IE 7.0";
/* 370 */     if (user_agent.indexOf("MSIE 5.5") > 0)
/* 371 */       return "IE 5.5";
/* 372 */     if (user_agent.indexOf("MSIE 5.01") > 0)
/* 373 */       return "IE 5.01";
/* 374 */     if (user_agent.indexOf("MSIE 5.0") > 0)
/* 375 */       return "IE 5.0";
/* 376 */     if (user_agent.indexOf("MSIE 4.0") > 0)
/* 377 */       return "IE 4.0";
/* 378 */     if (user_agent.indexOf("Firefox") > 0)
/* 379 */       return "Firefox";
/* 380 */     if (user_agent.indexOf("Netscape") > 0)
/* 381 */       return "Netscape";
/* 382 */     if (user_agent.indexOf("Opera") > 0) {
/* 383 */       return "Opera";
/*     */     }
/* 385 */     return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.other") + "";
/*     */   }
/*     */ 
/*     */   public User_User getUser()
/*     */   {
/* 390 */     return this.m_User;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.listener.SessionListener
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.base.listener;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.base.vo.PrivilegeUserSession;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class SessionListenerContainer
/*    */ {
/* 34 */   public static Map<String, PrivilegeUserSession> userSessionMap = new HashMap();
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.listener.SessionListenerContainer
 * JD-Core Version:    0.6.2
 */
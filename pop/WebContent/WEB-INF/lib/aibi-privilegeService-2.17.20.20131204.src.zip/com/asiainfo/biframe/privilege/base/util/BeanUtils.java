/*    */ package com.asiainfo.biframe.privilege.base.util;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.BaseRuntimeException;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import org.apache.commons.beanutils.PropertyUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class BeanUtils
/*    */ {
/* 21 */   private static Log logger = LogFactory.getLog(BeanUtils.class);
/*    */ 
/*    */   public static Object getProperty(Object obj, String property) {
/*    */     try {
/* 25 */       return PropertyUtils.getProperty(obj, property);
/*    */     } catch (IllegalAccessException exp) {
/* 27 */       logger.error("BeanUtils.getProperty() Error: ", exp);
/* 28 */       return null;
/*    */     } catch (InvocationTargetException exp) {
/* 30 */       logger.error("BeanUtils.getProperty() Error: ", exp);
/* 31 */       return null;
/*    */     } catch (NoSuchMethodException exp) {
/* 33 */       logger.error("BeanUtils.getProperty() Error: ", exp);
/* 34 */     }return null;
/*    */   }
/*    */ 
/*    */   public static String getPropertyString(Object obj, String property)
/*    */   {
/* 39 */     return String.valueOf(getProperty(obj, property));
/*    */   }
/*    */ 
/*    */   public static void copyProperties(Object dest, Object source) throws BaseRuntimeException {
/*    */     try {
/* 44 */       org.apache.commons.beanutils.BeanUtils.copyProperties(dest, source);
/*    */     } catch (IllegalAccessException exp) {
/* 46 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyFail") + "", exp);
/* 47 */       throw new BaseRuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyFail") + "", exp);
/*    */     } catch (InvocationTargetException exp) {
/* 49 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyFail") + "", exp);
/* 50 */       throw new BaseRuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyFail") + "", exp);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.BeanUtils
 * JD-Core Version:    0.6.2
 */
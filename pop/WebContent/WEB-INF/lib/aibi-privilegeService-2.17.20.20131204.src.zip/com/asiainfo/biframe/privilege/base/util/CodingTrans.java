/*    */ package com.asiainfo.biframe.privilege.base.util;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class CodingTrans
/*    */ {
/*    */   public static final int INT_PRIM_NUMBER = 95;
/*    */   public static final int INT_RETURN_LOOP = 94;
/*    */ 
/*    */   public static String encode(String strOriginal)
/*    */   {
/* 23 */     String strCodeMe = "";
/* 24 */     if ((strOriginal == null) || ("".equals(strOriginal))) {
/* 25 */       return strCodeMe;
/*    */     }
/*    */ 
/* 28 */     int intRnd = (int)(Math.random() * 92.0D + 2.0D);
/* 29 */     String strCode = new CodingTrans().loopCode(strOriginal, intRnd);
/*    */ 
/* 31 */     char rnd = (char)(intRnd + sighHashCode());
/* 32 */     int intStrLen = strCode.length();
/* 33 */     strCodeMe = strCode.substring(0, intStrLen / 2) + rnd + strCode.substring(intStrLen / 2, intStrLen);
/*    */ 
/* 35 */     if (strCodeMe.indexOf("??") >= 0) {
/* 36 */       return encode(strOriginal);
/*    */     }
/* 38 */     return strCodeMe;
/*    */   }
/*    */ 
/*    */   public static String decode(String strCode)
/*    */   {
/* 48 */     String strDecodeMe = "";
/* 49 */     if ((strCode == null) || ("".equals(strCode))) {
/* 50 */       return strDecodeMe;
/*    */     }
/* 52 */     int intStrLen = strCode.length() - 1;
/* 53 */     String strRnd = strCode.substring(intStrLen / 2, intStrLen / 2 + 1);
/* 54 */     int intRnd = strRnd.hashCode() - sighHashCode();
/* 55 */     strCode = strCode.substring(0, intStrLen / 2) + strCode.substring(intStrLen / 2 + 1, intStrLen + 1);
/* 56 */     String strOriginal = new CodingTrans().loopCode(strCode, 94 - intRnd);
/* 57 */     strDecodeMe = strOriginal;
/* 58 */     return strDecodeMe;
/*    */   }
/*    */ 
/*    */   private static int maxHashCode()
/*    */   {
/* 63 */     return "~".hashCode() - "!".hashCode() + 1;
/*    */   }
/*    */ 
/*    */   private static int sighHashCode()
/*    */   {
/* 68 */     return "!".hashCode();
/*    */   }
/*    */ 
/*    */   private String kaiserCode(String strOriginal)
/*    */   {
/* 73 */     int intStrLen = strOriginal.length();
/* 74 */     String strCode = "";
/*    */ 
/* 77 */     for (int i = 0; i < intStrLen; i++) {
/* 78 */       int intChar = strOriginal.substring(i, i + 1).hashCode();
/* 79 */       int intTmp = intChar - sighHashCode();
/* 80 */       intTmp = (intTmp * 95 + i + 1) % maxHashCode() + sighHashCode();
/* 81 */       strCode = strCode + (char)intTmp;
/*    */     }
/* 83 */     return strCode;
/*    */   }
/*    */ 
/*    */   private String loopCode(String strOriginal, int intLoopCount)
/*    */   {
/* 88 */     String strCode = strOriginal;
/* 89 */     for (int i = 0; i < intLoopCount; i++) {
/* 90 */       strCode = kaiserCode(strCode);
/*    */     }
/* 92 */     return strCode;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 96 */     System.out.println(encode("111"));
/* 97 */     System.out.println(decode(encode("111")));
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.CodingTrans
 * JD-Core Version:    0.6.2
 */
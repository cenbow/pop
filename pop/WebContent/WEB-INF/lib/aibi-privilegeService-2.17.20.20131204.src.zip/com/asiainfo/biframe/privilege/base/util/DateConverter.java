/*    */ package com.asiainfo.biframe.privilege.base.util;
/*    */ 
/*    */ import java.sql.Timestamp;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import org.apache.commons.beanutils.ConversionException;
/*    */ import org.apache.commons.beanutils.Converter;
/*    */ 
/*    */ public class DateConverter
/*    */   implements Converter
/*    */ {
/*    */   public Object convert(Class type, Object value)
/*    */   {
/* 24 */     if (value == null)
/* 25 */       return null;
/* 26 */     if (type == Timestamp.class)
/* 27 */       return convertToDate(type, value, "yyyy-MM-dd HH:mm:ss");
/* 28 */     if (type == Date.class)
/* 29 */       return convertToDate(type, value, "yyyy-MM-dd");
/* 30 */     if (type == String.class) {
/* 31 */       return convertToString(type, value);
/*    */     }
/*    */ 
/* 34 */     throw new ConversionException("不能转换 " + value.getClass().getName() + " 为 " + type.getName());
/*    */   }
/*    */ 
/*    */   protected Object convertToDate(Class type, Object value, String pattern) {
/* 38 */     SimpleDateFormat sdf = new SimpleDateFormat(pattern);
/* 39 */     if ((value instanceof String))
/*    */       try {
/* 41 */         if (value.toString().trim().length() == 0) {
/* 42 */           return null;
/*    */         }
/* 44 */         Date date = sdf.parse((String)value);
/* 45 */         if (type.equals(Timestamp.class)) {
/* 46 */           return new Timestamp(date.getTime());
/*    */         }
/* 48 */         return date;
/*    */       } catch (Exception pe) {
/* 50 */         return null;
/*    */       }
/* 52 */     if ((value instanceof Date)) {
/* 53 */       return value;
/*    */     }
/*    */ 
/* 56 */     throw new ConversionException("不能转换 " + value.getClass().getName() + " 为 " + type.getName());
/*    */   }
/*    */ 
/*    */   protected Object convertToString(Class type, Object value) {
/* 60 */     if ((value instanceof Date)) {
/* 61 */       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*    */ 
/* 63 */       if ((value instanceof Timestamp)) {
/* 64 */         sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*    */       }
/*    */       try
/*    */       {
/* 68 */         return sdf.format(value);
/*    */       } catch (Exception e) {
/* 70 */         throw new ConversionException("日期转换为字符串时出错！");
/*    */       }
/*    */     }
/* 73 */     return value.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.DateConverter
 * JD-Core Version:    0.6.2
 */
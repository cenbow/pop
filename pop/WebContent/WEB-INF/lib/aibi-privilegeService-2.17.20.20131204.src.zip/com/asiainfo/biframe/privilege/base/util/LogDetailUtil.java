/*    */ package com.asiainfo.biframe.privilege.base.util;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.BaseRuntimeException;
/*    */ import com.asiainfo.biframe.log.ILogService;
/*    */ import com.asiainfo.biframe.log.LogInfo;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class LogDetailUtil
/*    */ {
/* 25 */   private static Log log = LogFactory.getLog(LogDetailUtil.class);
/*    */   public static final int LOGDEFINE_OPERATION = 1;
/*    */   public static final int LOGDEFINE_LOGTYPE = 2;
/*    */   public static final int LOGDEFINE_DEFAULTVALUE = 999;
/*    */ 
/*    */   public static String getLogDefineValue(int defineType, String defineKey)
/*    */   {
/* 39 */     return getLogDetailBean().getLogDefineValue(defineType, defineKey);
/*    */   }
/*    */ 
/*    */   public static void log(LogInfo info)
/*    */     throws Exception
/*    */   {
/* 49 */     if (info == null) {
/* 50 */       return;
/*    */     }
/* 52 */     getLogDetailBean().log(info.getOperaterType(), info.getResourceType(), info.getResourceID(), info.getResourceName(), info.getMsg(), info.getOldMap(), info.getNewMap());
/*    */   }
/*    */ 
/*    */   public static void log(String operateType, String resourceType, String resourceId, String resourceName, String msg, Map<String, Map<String, String>> oldMap, Map<String, Map<String, String>> newMap)
/*    */   {
/* 68 */     getLogDetailBean().log(LogInfo.getSessionID(), LogInfo.getOperatorID(), LogInfo.getOperatorName(), LogInfo.getHostAddress(), LogInfo.getClientAddress(), operateType, resourceType, resourceId, resourceName, msg, oldMap, newMap);
/*    */   }
/*    */ 
/*    */   public static void log(String sessionId, String operatorId, String operatorName, String serverIp, String clientIp, String operateType, String resourceType, String resourceId, String resourceName, String msg, Map<String, Map<String, String>> oldMap, Map<String, Map<String, String>> newMap)
/*    */   {
/* 91 */     getLogDetailBean().log(sessionId, operatorId, operatorName, serverIp, clientIp, operateType, resourceType, resourceId, resourceName, msg, oldMap, newMap);
/*    */   }
/*    */   private static ILogService getLogDetailBean() {
/*    */     try {
/* 95 */       return (ILogService)SystemServiceLocator.getInstance().getService("logService");
/*    */     } catch (Exception e) {
/* 97 */       log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"));
/* 98 */     }throw new BaseRuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"));
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.LogDetailUtil
 * JD-Core Version:    0.6.2
 */
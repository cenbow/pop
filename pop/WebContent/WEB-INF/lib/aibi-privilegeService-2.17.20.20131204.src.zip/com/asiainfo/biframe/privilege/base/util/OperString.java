/*     */ package com.asiainfo.biframe.privilege.base.util;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ 
/*     */ public class OperString
/*     */ {
/*     */   public static String Gb2ToUnicode(String str)
/*     */   {
/*  21 */     if (str == null)
/*     */     {
/*  23 */       return null;
/*     */     }
/*     */     try
/*     */     {
/*  27 */       boolean isCharTran = "true".equals(Configure.getInstance().getProperty("CHAR_TRAN"));
/*     */       byte[] b;
/*  28 */       if (isCharTran) {
/*  29 */         byte[] b = str.trim().getBytes("ISO-8859-1");
/*  30 */         str = new String(b, "gb2312");
/*     */       } else {
/*  32 */         b = str.trim().getBytes("gb2312");
/*  33 */       }return new String(b, "gb2312");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  39 */       e.printStackTrace(System.out);
/*     */     }
/*     */ 
/*  42 */     return null;
/*     */   }
/*     */ 
/*     */   public static String UnicodeToGb2(String str)
/*     */   {
/*  51 */     if (str == null)
/*     */     {
/*  53 */       return null;
/*     */     }
/*     */     try
/*     */     {
/*  57 */       boolean isCharTran = "true".equals(Configure.getInstance().getProperty("CHAR_TRAN"));
/*     */       byte[] b;
/*  58 */       if (isCharTran) {
/*  59 */         byte[] b = str.getBytes("gb2312");
/*  60 */         str = new String(b, "ISO-8859-1");
/*     */       } else {
/*  62 */         b = str.getBytes("gb2312");
/*  63 */       }return new String(b, "gb2312");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  69 */       e.printStackTrace(System.out);
/*     */     }
/*     */ 
/*  72 */     return null;
/*     */   }
/*     */ 
/*     */   public static String GBK2UTF(String str)
/*     */   {
/*  82 */     if (str == null)
/*     */     {
/*  84 */       return null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  89 */       byte[] b = str.getBytes("GBK");
/*  90 */       return new String(b, "UTF-8");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  97 */       e.printStackTrace();
/*     */     }
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */   public static String UTF2GBK(String str)
/*     */   {
/* 109 */     if (str == null)
/*     */     {
/* 111 */       return null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 116 */       byte[] b = str.getBytes("UTF-8");
/* 117 */       return new String(b, "GBK");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 124 */       e.printStackTrace();
/*     */     }
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */   public static String ISO2GBK(String str)
/*     */   {
/* 136 */     if (str == null)
/*     */     {
/* 138 */       return null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 143 */       byte[] b = str.getBytes("ISO-8859-1");
/* 144 */       return new String(b, "GBK");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 151 */       e.printStackTrace();
/*     */     }
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   public static String GBK2ISO(String str)
/*     */   {
/* 163 */     if (str == null)
/*     */     {
/* 165 */       return null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 170 */       byte[] b = str.getBytes("GBK");
/* 171 */       return new String(b, "ISO-8859-1");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 178 */       e.printStackTrace();
/*     */     }
/* 180 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.OperString
 * JD-Core Version:    0.6.2
 */
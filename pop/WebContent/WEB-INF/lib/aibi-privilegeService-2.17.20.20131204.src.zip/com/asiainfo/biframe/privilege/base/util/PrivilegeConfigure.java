/*    */ package com.asiainfo.biframe.privilege.base.util;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class PrivilegeConfigure
/*    */ {
/* 20 */   private static Log log = LogFactory.getLog(PrivilegeConfigure.class);
/*    */ 
/* 22 */   private static PrivilegeConfigure configure = new PrivilegeConfigure();
/*    */ 
/*    */   public static PrivilegeConfigure getInstance()
/*    */   {
/* 27 */     return configure;
/*    */   }
/*    */ 
/*    */   public String getProperty(String strKey) {
/*    */     try {
/* 32 */       return Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", strKey);
/*    */     } catch (Exception e) {
/* 34 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getPropertiesFail"), e);
/* 35 */     }return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.PrivilegeConfigure
 * JD-Core Version:    0.6.2
 */
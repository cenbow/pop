/*    */ package com.asiainfo.biframe.privilege.base.util;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.ServiceException;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class SpringUtil
/*    */ {
/* 20 */   private static Log log = LogFactory.getLog(SpringUtil.class);
/*    */ 
/*    */   public static final Object getBean(String name) {
/*    */     try { return SystemServiceLocator.getInstance().getService(name); } catch (Exception e) {
/*    */     }
/* 25 */     throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"));
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.SpringUtil
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.base.util;
/*    */ 
/*    */ public class SqlUtil
/*    */ {
/*    */   public static String getSqlIn(String sqlParam, String columnName)
/*    */   {
/* 26 */     int buff_length = 0;
/* 27 */     int spIndex = 500;
/* 28 */     if ((sqlParam == null) || ("".equals(sqlParam))) {
/* 29 */       return "";
/*    */     }
/* 31 */     String[] str_arr = sqlParam.split(",");
/* 32 */     int width = str_arr.length;
/* 33 */     int arr_width = width / spIndex;
/* 34 */     if (width % spIndex != 0) {
/* 35 */       arr_width++;
/*    */     }
/* 37 */     StringBuffer buffer = new StringBuffer("");
/* 38 */     for (int i = 0; i < arr_width; i++) {
/* 39 */       buffer.append(" " + columnName + " IN(");
/* 40 */       int j = i * spIndex; for (int k = 0; (j < width) && (k < spIndex); k++) {
/* 41 */         buffer.append(str_arr[j] + ",");
/*    */ 
/* 40 */         j++;
/*    */       }
/*    */ 
/* 43 */       buff_length = buffer.length();
/* 44 */       buffer = buffer.delete(buff_length - 1, buff_length).append(") OR");
/*    */     }
/* 46 */     return buffer.substring(0, buffer.length() - 2);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.SqlUtil
 * JD-Core Version:    0.6.2
 */
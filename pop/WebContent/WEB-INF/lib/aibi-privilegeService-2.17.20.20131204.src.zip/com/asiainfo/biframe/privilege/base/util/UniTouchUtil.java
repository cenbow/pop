/*    */ package com.asiainfo.biframe.privilege.base.util;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.ServiceException;
/*    */ import com.asiainfo.biframe.privilege.base.exception.MessageException;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import com.asiainfo.biframe.utils.webservice.uniTouch.TaskModel;
/*    */ import com.asiainfo.biframe.utils.webservice.uniTouch.UniTouchClient;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class UniTouchUtil
/*    */ {
/* 24 */   private static Log log = LogFactory.getLog(UniTouchUtil.class);
/*    */ 
/*    */   public static String sendSmsMessage(TaskModel model, String toPhoneNumber)
/*    */     throws MessageException, ServiceException
/*    */   {
/*    */     try
/*    */     {
/* 35 */       log.debug("in sendSmsMessage");
/* 36 */       model.setSysId(PrivilegeConfigure.getInstance().getProperty("SMS_SYS_ID"));
/* 37 */       model.setSubsysId(PrivilegeConfigure.getInstance().getProperty("SMS_SUB_SYS_ID"));
/* 38 */       model.setChannelId(PrivilegeConfigure.getInstance().getProperty("SMS_CHANNEL_ID"));
/* 39 */       model.setStartTime(PrivilegeConfigure.getInstance().getProperty("SMS_START_TIME"));
/* 40 */       model.setEndTime(PrivilegeConfigure.getInstance().getProperty("SMS_END_TIME"));
/*    */ 
/* 42 */       UniTouchClient ic = UniTouchClient.getInstance(PrivilegeConfigure.getInstance().getProperty("TASK_UNITOUCH_URL"));
/*    */ 
/* 44 */       String result = ic.sendSmsRequest(model, toPhoneNumber);
/* 45 */       if (!result.equals("0")) {
/* 46 */         log.warn("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.sendSmsByUniTouchFail"));
/* 47 */         throw new MessageException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.sendSmsFail"));
/*    */       }
/* 49 */       log.debug("end sendSmsMessage");
/* 50 */       return result;
/*    */     } catch (Exception e) {
/* 52 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.sendSmsByUniTouchFail2"), e);
/* 53 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.sendSmsFail2") + "", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.UniTouchUtil
 * JD-Core Version:    0.6.2
 */
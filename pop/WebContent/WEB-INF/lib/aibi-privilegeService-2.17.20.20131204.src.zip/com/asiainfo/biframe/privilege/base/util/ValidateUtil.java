/*    */ package com.asiainfo.biframe.privilege.base.util;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.ValidateException;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class ValidateUtil
/*    */ {
/*    */   public static void assertNotBlank(String param, String paramDesc)
/*    */     throws ValidateException
/*    */   {
/* 27 */     if (StringUtils.isBlank(param))
/* 28 */       throw new ValidateException(paramDesc + "" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.notEmpty") + "!");
/*    */   }
/*    */ 
/*    */   public static void assertRegEx(String param, String regEx, String message)
/*    */     throws ValidateException
/*    */   {
/* 40 */     Pattern pattern = Pattern.compile(regEx);
/* 41 */     Matcher matcher = pattern.matcher(param);
/* 42 */     if (!matcher.find())
/* 43 */       throw new ValidateException(message);
/*    */   }
/*    */ 
/*    */   public static void assertNumber(String param, String message)
/*    */     throws ValidateException
/*    */   {
/* 53 */     String regEx = "^[0-9]+$";
/* 54 */     Pattern pattern = Pattern.compile(regEx);
/* 55 */     Matcher matcher = pattern.matcher(param);
/* 56 */     if (!matcher.find())
/* 57 */       throw new ValidateException(message);
/*    */   }
/*    */ 
/*    */   public static void assertChar(String param, String message)
/*    */     throws ValidateException
/*    */   {
/* 66 */     String regEx = "^[a-z|A-Z]+$";
/* 67 */     Pattern pattern = Pattern.compile(regEx);
/* 68 */     Matcher matcher = pattern.matcher(param);
/* 69 */     if (!matcher.find())
/* 70 */       throw new ValidateException(message);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.util.ValidateUtil
 * JD-Core Version:    0.6.2
 */
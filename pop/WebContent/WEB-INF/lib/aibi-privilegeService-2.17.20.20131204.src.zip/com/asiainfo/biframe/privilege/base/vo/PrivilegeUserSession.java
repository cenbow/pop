/*     */ package com.asiainfo.biframe.privilege.base.vo;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.IUserSession;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class PrivilegeUserSession
/*     */   implements IUserSession, Serializable
/*     */ {
/*     */   private String clientIp;
/*     */   private String serverIp;
/*     */   private String oaUserId;
/*     */   private Timestamp loginTime;
/*     */   private String sessionId;
/*     */   private IUser user;
/*     */   private String groupId;
/*     */ 
/*     */   public String getClientIP()
/*     */   {
/*  29 */     return this.clientIp;
/*     */   }
/*     */ 
/*     */   public String getOAUserID()
/*     */   {
/*  36 */     return this.oaUserId;
/*     */   }
/*     */ 
/*     */   public String getServerIp() {
/*  40 */     return this.serverIp;
/*     */   }
/*     */ 
/*     */   public void setServerIp(String serverIp)
/*     */   {
/*  45 */     this.serverIp = serverIp;
/*     */   }
/*     */ 
/*     */   public String getSessionID()
/*     */   {
/*  52 */     return this.sessionId;
/*     */   }
/*     */ 
/*     */   public IUser getUser()
/*     */   {
/*  59 */     return this.user;
/*     */   }
/*     */ 
/*     */   public String getUserCityID()
/*     */   {
/*  66 */     return this.user.getCityid();
/*     */   }
/*     */ 
/*     */   public String getUserID()
/*     */   {
/*  73 */     return this.user.getUserid();
/*     */   }
/*     */ 
/*     */   public String getUserName()
/*     */   {
/*  80 */     return this.user.getUsername();
/*     */   }
/*     */ 
/*     */   public Timestamp getLoginTime()
/*     */   {
/*  85 */     return this.loginTime;
/*     */   }
/*     */ 
/*     */   public void setLoginTime(Timestamp loginTime)
/*     */   {
/*  90 */     this.loginTime = loginTime;
/*     */   }
/*     */ 
/*     */   public void setClientIp(String clientIp)
/*     */   {
/*  95 */     this.clientIp = clientIp;
/*     */   }
/*     */ 
/*     */   public void setOaUserId(String oaUserId) {
/*  99 */     this.oaUserId = oaUserId;
/*     */   }
/*     */ 
/*     */   public void setSessionId(String sessionId) {
/* 103 */     this.sessionId = sessionId;
/*     */   }
/*     */ 
/*     */   public void setUser(IUser user) {
/* 107 */     this.user = user;
/*     */   }
/*     */ 
/*     */   public String getGroupId() {
/* 111 */     return this.groupId;
/*     */   }
/*     */ 
/*     */   public void setGroupId(String groupId) {
/* 115 */     this.groupId = groupId;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.vo.PrivilegeUserSession
 * JD-Core Version:    0.6.2
 */
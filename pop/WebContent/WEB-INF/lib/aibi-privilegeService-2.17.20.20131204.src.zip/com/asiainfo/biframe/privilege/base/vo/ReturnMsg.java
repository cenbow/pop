/*    */ package com.asiainfo.biframe.privilege.base.vo;
/*    */ 
/*    */ public class ReturnMsg
/*    */ {
/* 10 */   private boolean result = true;
/* 11 */   private String msg = "";
/*    */ 
/*    */   public ReturnMsg()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ReturnMsg(boolean result, String msg) {
/* 18 */     this.result = result;
/* 19 */     this.msg = msg;
/*    */   }
/*    */ 
/*    */   public String getMsg() {
/* 23 */     return this.msg;
/*    */   }
/*    */   public void setMsg(String msg) {
/* 26 */     this.msg = msg;
/*    */   }
/*    */   public boolean isResult() {
/* 29 */     return this.result;
/*    */   }
/*    */   public void setResult(boolean result) {
/* 32 */     this.result = result;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 37 */     return "result:" + this.result + ", message:" + this.msg;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.vo.ReturnMsg
 * JD-Core Version:    0.6.2
 */
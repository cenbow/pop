/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.CacheBaseException;
/*     */ import com.asiainfo.biframe.privilege.base.util.SpringUtil;
/*     */ import com.asiainfo.biframe.service.ISynCacheService;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ 
/*     */ public class CacheUtils
/*     */ {
/*  17 */   private static final String userCacheName = UserCache.class.getName();
/*  18 */   private static final String groupCacheName = UserGroupDefineCache.class.getName();
/*  19 */   private static final String roleCacheName = UserRoleCache.class.getName();
/*  20 */   private static final String dutyCacheName = UserDutyCache.class.getName();
/*  21 */   private static final String companyCacheName = UserCompanyCache.class.getName();
/*  22 */   private static final String menuCacheName = SysMenuItemCache.class.getName();
/*  23 */   private static final String menuViewCacheName = SysMenuItemViewCache.class.getName();
/*     */ 
/*     */   public static void refreshUserCache() throws CacheBaseException {
/*  26 */     UserCache.getInstance().refreshAll();
/*  27 */     synCache(userCacheName);
/*     */   }
/*     */ 
/*     */   public static void refreshGroupCache() throws CacheBaseException
/*     */   {
/*  32 */     UserGroupDefineCache.getInstance().refreshAll();
/*  33 */     synCache(groupCacheName);
/*     */   }
/*     */ 
/*     */   public static void refreshRoleCache() throws CacheBaseException
/*     */   {
/*  38 */     UserRoleCache.getInstance().refreshAll();
/*  39 */     synCache(roleCacheName);
/*     */   }
/*     */ 
/*     */   public static void refreshDutyCache() throws CacheBaseException {
/*  43 */     UserDutyCache.getInstance().refreshAll();
/*  44 */     synCache(dutyCacheName);
/*     */   }
/*     */ 
/*     */   public static void refreshCompanyCache() throws CacheBaseException {
/*  48 */     UserCompanyCache.getInstance().refreshAll();
/*  49 */     synCache(companyCacheName);
/*     */   }
/*     */ 
/*     */   public static void refreshUserCacheByKey(String userId) throws CacheBaseException
/*     */   {
/*  54 */     UserCache.getInstance().refreshByKey(userId);
/*  55 */     synCache(userCacheName);
/*     */   }
/*     */ 
/*     */   public static void refreshGroupCacheByKey(String groupId) throws CacheBaseException
/*     */   {
/*  60 */     UserGroupDefineCache.getInstance().refreshByKey(groupId);
/*  61 */     synCache(groupCacheName);
/*     */   }
/*     */ 
/*     */   public static void refreshRoleCacheByKey(String roleId) throws CacheBaseException
/*     */   {
/*  66 */     UserRoleCache.getInstance().refreshByKey(roleId);
/*  67 */     synCache(roleCacheName);
/*     */   }
/*     */ 
/*     */   public static void refreshMenuCacheByKey(String menuItemId)
/*     */     throws CacheBaseException
/*     */   {
/*  73 */     SysMenuItemCache.getInstance().refreshByKey(menuItemId);
/*  74 */     synCache(menuCacheName);
/*  75 */     SysMenuItemViewCache.getInstance().refreshById(menuItemId);
/*  76 */     synCache(menuViewCacheName);
/*     */   }
/*     */ 
/*     */   public static void refreshCompanyCacheByKey(String companyId) throws CacheBaseException {
/*  80 */     UserCompanyCache.getInstance().refreshByKey(companyId);
/*  81 */     synCache(companyCacheName);
/*     */   }
/*     */ 
/*     */   public static void removeUserCacheByKey(String userId) throws CacheBaseException
/*     */   {
/*  86 */     UserCache.getInstance().removeObjectByKey(userId);
/*  87 */     synCache(userCacheName);
/*     */   }
/*     */ 
/*     */   public static void removeGroupCacheByKey(String groupId) throws CacheBaseException
/*     */   {
/*  92 */     UserGroupDefineCache.getInstance().removeObjectByKey(groupId);
/*  93 */     synCache(groupCacheName);
/*     */   }
/*     */ 
/*     */   public static void removeRoleCacheByKey(String roleId) throws CacheBaseException
/*     */   {
/*  98 */     UserRoleCache.getInstance().removeObjectByKey(roleId);
/*  99 */     synCache(roleCacheName);
/*     */   }
/*     */ 
/*     */   public static void removeMenuCacheByKey(String menuItemId) throws CacheBaseException {
/* 103 */     SysMenuItemCache.getInstance().removeObjectByKey(menuItemId);
/* 104 */     synCache(menuCacheName);
/* 105 */     SysMenuItemViewCache.getInstance().removeObjectById(menuItemId);
/* 106 */     synCache(menuViewCacheName);
/*     */   }
/*     */ 
/*     */   private static void synCache(String cacheName) throws CacheBaseException {
/* 110 */     ISynCacheService synCacheService = (ISynCacheService)SpringUtil.getBean("core_sysSynCacheService");
/* 111 */     synCacheService.addSynCache(cacheName, Configure.getInstance().getProperty("HOST_ADDRESS"));
/*     */   }
/*     */ 
/*     */   public static void refreshSysMenuItemCache()
/*     */   {
/* 116 */     SysMenuItemViewCache.getInstance().refreshAll();
/* 117 */     synCache(menuViewCacheName);
/* 118 */     SysMenuItemCache.getInstance().refreshAll();
/* 119 */     synCache(menuCacheName);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.CacheUtils
 * JD-Core Version:    0.6.2
 */
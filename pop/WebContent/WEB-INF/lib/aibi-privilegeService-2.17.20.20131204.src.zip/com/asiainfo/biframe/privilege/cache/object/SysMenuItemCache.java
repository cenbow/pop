/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.common.cache.CacheFilter;
/*     */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.SqlcaPst;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SysMenuItemCache extends CacheBase
/*     */ {
/*  18 */   private Log log = LogFactory.getLog(SysMenuItemCache.class);
/*     */ 
/*  20 */   private static SysMenuItemCache theInstance = new SysMenuItemCache();
/*     */   private ArrayList cacheKeyArray;
/*     */ 
/*     */   public static SysMenuItemCache getInstance()
/*     */   {
/*  29 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public SysMenuItemCache()
/*     */   {
/*  37 */     init();
/*     */   }
/*     */ 
/*     */   protected synchronized boolean init()
/*     */   {
/*  43 */     this.cacheContainer = new Hashtable();
/*  44 */     this.cacheKeyArray = new ArrayList();
/*     */ 
/*  46 */     Sqlca sqlca = null;
/*  47 */     SqlcaPst subSqlca = null;
/*     */     try {
/*  49 */       subSqlca = new SqlcaPst(new ConnectionEx());
/*  50 */       String subSql = " SELECT PARENTID FROM SYS_MENU_ITEM GROUP BY PARENTID ";
/*  51 */       subSqlca.setSql(subSql);
/*  52 */       subSqlca.execute();
/*  53 */       list = new ArrayList();
/*  54 */       while (subSqlca.next()) {
/*  55 */         list.add(Integer.valueOf(subSqlca.getInt("PARENTID")));
/*     */       }
/*     */ 
/*  58 */       sqlca = new Sqlca(new ConnectionEx());
/*  59 */       String sql = "select * from sys_menu_item order by parentid,sortnum";
/*  60 */       sqlca.execute(sql);
/*  61 */       while (sqlca.next()) {
/*  62 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/*  63 */         sysMenuItem.setMENUITEMID(sqlca.getInt("menuitemid"));
/*  64 */         sysMenuItem.setMENUITEMTITLE(sqlca.getString("menuitemtitle"));
/*  65 */         sysMenuItem.setPARENTID(sqlca.getInt("parentid"));
/*  66 */         sysMenuItem.setSORTNUM(sqlca.getInt("sortnum"));
/*  67 */         sysMenuItem.setPIC1(sqlca.getString("pic1"));
/*  68 */         sysMenuItem.setPIC2(sqlca.getString("pic2"));
/*  69 */         sysMenuItem.setMENUTYPE(sqlca.getInt("menutype"));
/*  70 */         sysMenuItem.setURL(sqlca.getString("url"));
/*  71 */         sysMenuItem.setRESID(sqlca.getString("resid"));
/*  72 */         sysMenuItem.setRESTYPE(sqlca.getInt("restype"));
/*  73 */         sysMenuItem.setACCESSTOKEN(sqlca.getInt("accesstoken"));
/*  74 */         sysMenuItem.setURLTARGET(sqlca.getString("urltarget"));
/*  75 */         sysMenuItem.setURLPORT(sqlca.getString("urlport"));
/*  76 */         sysMenuItem.setImagePath(sqlca.getString("imagepath"));
/*  77 */         sysMenuItem.setApplicationId(sqlca.getString("application_id"));
/*     */ 
/*  80 */         if (list.contains(Integer.valueOf(sysMenuItem.getMENUITEMID())))
/*  81 */           sysMenuItem.setHasSon(true);
/*     */         else {
/*  83 */           sysMenuItem.setHasSon(false);
/*     */         }
/*     */ 
/*  86 */         this.cacheContainer.put("" + sysMenuItem.getMENUITEMID(), sysMenuItem);
/*  87 */         this.cacheKeyArray.add("" + sysMenuItem.getMENUITEMID());
/*     */       }
/*     */ 
/*  93 */       if (null != sqlca) {
/*  94 */         sqlca.closeAll();
/*     */       }
/*  96 */       if (null != subSqlca)
/*  97 */         subSqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       List list;
/*  90 */       this.log.error("SysMenuItemCache init " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*  91 */       return 0;
/*     */     } finally {
/*  93 */       if (null != sqlca) {
/*  94 */         sqlca.closeAll();
/*     */       }
/*  96 */       if (null != subSqlca) {
/*  97 */         subSqlca.closeAll();
/*     */       }
/*     */     }
/* 100 */     this.log.debug(">>SysMenuItemCache init successful...");
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean hasSon(Object key) {
/* 105 */     if (this.cacheContainer.get(key) != null)
/*     */     {
/* 107 */       return ((SysMenuItemBean)this.cacheContainer.get(key)).isHasSon();
/*     */     }
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 113 */     SysMenuItemCache sysMenuItemRightCache1 = new SysMenuItemCache();
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/* 123 */     if (key == null)
/* 124 */       return null;
/* 125 */     if (this.cacheContainer.containsKey(key)) {
/* 126 */       return ((SysMenuItemBean)this.cacheContainer.get(key)).getMENUITEMTITLE();
/*     */     }
/*     */ 
/* 129 */     refreshByKey(key);
/* 130 */     if (this.cacheContainer.containsKey(key))
/* 131 */       return ((SysMenuItemBean)this.cacheContainer.get(key)).getMENUITEMTITLE();
/* 132 */     return "";
/*     */   }
/*     */ 
/*     */   public synchronized boolean refreshByKey(Object key)
/*     */   {
/* 141 */     SqlcaPst m_Sqlca = null;
/* 142 */     SqlcaPst subSqlca = null;
/* 143 */     boolean res = false;
/*     */     try {
/* 145 */       subSqlca = new SqlcaPst(new ConnectionEx());
/* 146 */       String subSql = " SELECT PARENTID FROM SYS_MENU_ITEM GROUP BY PARENTID ";
/* 147 */       subSqlca.setSql(subSql);
/* 148 */       subSqlca.execute();
/* 149 */       List list = new ArrayList();
/* 150 */       while (subSqlca.next()) {
/* 151 */         list.add(Integer.valueOf(subSqlca.getInt("PARENTID")));
/*     */       }
/*     */ 
/* 154 */       m_Sqlca = new SqlcaPst(new ConnectionEx());
/* 155 */       String loadSql = "select * from sys_menu_item where menuitemid=?";
/* 156 */       m_Sqlca.setSql(loadSql);
/* 157 */       m_Sqlca.setInteger(1, Integer.valueOf(key.toString()));
/* 158 */       m_Sqlca.execute();
/*     */ 
/* 160 */       if (m_Sqlca.next()) {
/* 161 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/* 162 */         sysMenuItem.setMENUITEMID(m_Sqlca.getInt("menuitemid"));
/* 163 */         sysMenuItem.setMENUITEMTITLE(m_Sqlca.getString("menuitemtitle"));
/* 164 */         sysMenuItem.setPARENTID(m_Sqlca.getInt("parentid"));
/* 165 */         sysMenuItem.setSORTNUM(m_Sqlca.getInt("sortnum"));
/* 166 */         sysMenuItem.setPIC1(m_Sqlca.getString("pic1"));
/* 167 */         sysMenuItem.setPIC2(m_Sqlca.getString("pic2"));
/* 168 */         sysMenuItem.setMENUTYPE(m_Sqlca.getInt("menutype"));
/* 169 */         sysMenuItem.setURL(m_Sqlca.getString("url"));
/* 170 */         sysMenuItem.setRESID(m_Sqlca.getString("resid"));
/* 171 */         sysMenuItem.setRESTYPE(m_Sqlca.getInt("restype"));
/* 172 */         sysMenuItem.setACCESSTOKEN(m_Sqlca.getInt("accesstoken"));
/* 173 */         sysMenuItem.setURLTARGET(m_Sqlca.getString("urltarget"));
/* 174 */         sysMenuItem.setURLPORT(m_Sqlca.getString("urlport"));
/* 175 */         sysMenuItem.setImagePath(m_Sqlca.getString("imagepath"));
/* 176 */         sysMenuItem.setApplicationId(m_Sqlca.getString("application_id"));
/*     */ 
/* 179 */         if (list.contains(Integer.valueOf(sysMenuItem.getMENUITEMID())))
/* 180 */           sysMenuItem.setHasSon(true);
/*     */         else {
/* 182 */           sysMenuItem.setHasSon(false);
/*     */         }
/*     */ 
/* 185 */         this.cacheContainer.put("" + sysMenuItem.getMENUITEMID(), sysMenuItem);
/*     */       }
/*     */ 
/* 188 */       refreshKeyArray();
/* 189 */       res = true;
/*     */     } catch (Exception e) {
/* 191 */       this.log.error("SysMenuItemCache refreshByKey(" + key + ") " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 193 */       if (m_Sqlca != null) {
/* 194 */         m_Sqlca.closeAll();
/*     */       }
/* 196 */       if (subSqlca != null) {
/* 197 */         subSqlca.closeAll();
/*     */       }
/*     */     }
/* 200 */     return res;
/*     */   }
/*     */ 
/*     */   public synchronized boolean refreshKeyArray()
/*     */   {
/* 208 */     Sqlca m_Sqlca = null;
/* 209 */     boolean res = false;
/*     */     try
/*     */     {
/* 212 */       ArrayList keyArray = new ArrayList();
/* 213 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 215 */       String loadSql = "select * from sys_menu_item order by parentid,sortnum";
/* 216 */       m_Sqlca.execute(loadSql);
/* 217 */       while (m_Sqlca.next())
/*     */       {
/* 219 */         keyArray.add(m_Sqlca.getString("menuitemid"));
/*     */       }
/* 221 */       this.cacheKeyArray.clear();
/* 222 */       this.cacheKeyArray.addAll(keyArray);
/* 223 */       res = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 227 */       this.log.error("SysMenuItemCache refreshKeyArray() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 231 */       if (m_Sqlca != null)
/* 232 */         m_Sqlca.closeAll();
/*     */     }
/* 234 */     return res;
/*     */   }
/*     */ 
/*     */   public List getMenuItemListByFilter(CacheFilter cf)
/*     */   {
/* 242 */     ArrayList ret = new ArrayList();
/* 243 */     for (int i = 0; i < this.cacheKeyArray.size(); i++)
/*     */     {
/* 245 */       Object tmpKey = this.cacheKeyArray.get(i);
/* 246 */       if (null != tmpKey)
/*     */       {
/* 248 */         Object tmpObj = this.cacheContainer.get(tmpKey);
/* 249 */         if (cf.match(tmpObj))
/*     */         {
/* 251 */           ret.add(tmpObj);
/*     */         }
/*     */       }
/*     */     }
/* 254 */     return ret;
/*     */   }
/*     */ 
/*     */   public List getAllSortedCityList() {
/* 258 */     ArrayList ret = new ArrayList();
/* 259 */     for (int i = 0; i < this.cacheKeyArray.size(); i++)
/*     */     {
/* 261 */       Object tmpKey = this.cacheKeyArray.get(i);
/* 262 */       if (null != tmpKey)
/*     */       {
/* 264 */         Object tmpObj = this.cacheContainer.get(tmpKey);
/* 265 */         ret.add(tmpObj);
/*     */       }
/*     */     }
/* 267 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<SysMenuItemBean> getSubMenuItemById(int menuItemId, List<SysMenuItemBean> ret, boolean isCascade)
/*     */   {
/* 276 */     for (int i = 0; i < this.cacheKeyArray.size(); i++)
/*     */     {
/* 278 */       Object tmpKey = this.cacheKeyArray.get(i);
/* 279 */       if (null != tmpKey)
/*     */       {
/* 281 */         SysMenuItemBean tmpObj = (SysMenuItemBean)this.cacheContainer.get(tmpKey);
/* 282 */         if ((tmpObj != null) && (menuItemId == tmpObj.getPARENTID()))
/*     */         {
/* 284 */           ret.add(tmpObj);
/* 285 */           if (isCascade) {
/* 286 */             getSubMenuItemById(tmpObj.getMENUITEMID(), ret, isCascade);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 291 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.SysMenuItemCache
 * JD-Core Version:    0.6.2
 */
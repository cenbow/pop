/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.privilege.model.SysMenuItem;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.SqlcaPst;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SysMenuItemViewCache extends CacheBase
/*     */ {
/*  26 */   private Log log = LogFactory.getLog(SysMenuItemViewCache.class);
/*     */ 
/*  29 */   private static SysMenuItemViewCache theInstance = new SysMenuItemViewCache();
/*     */ 
/*     */   public static SysMenuItemViewCache getInstance()
/*     */   {
/*  37 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public SysMenuItemViewCache()
/*     */   {
/*  45 */     init();
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object arg0)
/*     */   {
/*  50 */     String menuItemTitle = "";
/*  51 */     List smiList = new ArrayList();
/*  52 */     Collection collection = getAllCachedObject();
/*  53 */     if ((null != collection) && (!collection.isEmpty())) {
/*  54 */       Iterator it = collection.iterator();
/*  55 */       while (it.hasNext()) {
/*  56 */         SysMenuItem smi = (SysMenuItem)it.next();
/*  57 */         if (Integer.parseInt(arg0.toString()) == smi.getMenuItemId().intValue()) {
/*  58 */           menuItemTitle = smi.getMenuItemTitle();
/*  59 */           break;
/*     */         }
/*     */       }
/*     */     }
/*  63 */     if ((StringUtils.isBlank(menuItemTitle)) && (0 == Integer.parseInt(arg0.toString()))) {
/*  64 */       menuItemTitle = LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.menuRoot");
/*     */     }
/*  66 */     return menuItemTitle;
/*     */   }
/*     */ 
/*     */   protected boolean init()
/*     */   {
/*  71 */     this.cacheContainer = new Hashtable();
/*     */ 
/*  73 */     Sqlca sqlca = null;
/*  74 */     SqlcaPst subSqlca = null;
/*     */     try
/*     */     {
/*  77 */       subSqlca = new SqlcaPst(new ConnectionEx());
/*  78 */       String subSql = " SELECT PARENTID FROM V_SYS_MENU_ITEM GROUP BY PARENTID ";
/*  79 */       subSqlca.setSql(subSql);
/*  80 */       subSqlca.execute();
/*  81 */       List list = new ArrayList();
/*  82 */       while (subSqlca.next()) {
/*  83 */         list.add(Integer.valueOf(subSqlca.getInt("PARENTID")));
/*     */       }
/*     */ 
/*  86 */       sqlca = new Sqlca(new ConnectionEx());
/*  87 */       String sql = "select * from v_sys_menu_item order by parentid,sortnum";
/*  88 */       sqlca.execute(sql);
/*  89 */       while (sqlca.next()) {
/*  90 */         SysMenuItem sysMenuItem = new SysMenuItem();
/*  91 */         sysMenuItem.setMenuItemId(Integer.valueOf(sqlca.getInt("menuitemid")));
/*  92 */         sysMenuItem.setMenuItemTitle(sqlca.getString("menuitemtitle"));
/*  93 */         sysMenuItem.setParentId(Integer.valueOf(sqlca.getInt("parentid")));
/*  94 */         sysMenuItem.setSortNum(Integer.valueOf(sqlca.getInt("sortnum")));
/*  95 */         sysMenuItem.setPic1(sqlca.getString("pic1"));
/*  96 */         sysMenuItem.setPic2(sqlca.getString("pic2"));
/*  97 */         sysMenuItem.setMenuType(Integer.valueOf(sqlca.getInt("menutype")));
/*  98 */         sysMenuItem.setUrl(sqlca.getString("url"));
/*  99 */         sysMenuItem.setResId(sqlca.getString("resid"));
/* 100 */         sysMenuItem.setResType(Integer.valueOf(sqlca.getInt("restype")));
/* 101 */         sysMenuItem.setAccessToken(Integer.valueOf(sqlca.getInt("accesstoken")));
/* 102 */         sysMenuItem.setUrlTarget(sqlca.getString("urltarget"));
/* 103 */         sysMenuItem.setUrlPort(sqlca.getString("urlport"));
/* 104 */         sysMenuItem.setImagePath(sqlca.getString("imagepath"));
/* 105 */         sysMenuItem.setApplicationId(sqlca.getString("application_id"));
/* 106 */         sysMenuItem.setResourceType(Integer.valueOf(sqlca.getInt("resource_type")));
/*     */ 
/* 109 */         if (list.contains(sysMenuItem.getMenuItemId()))
/* 110 */           sysMenuItem.setFolderOrNot(true);
/*     */         else {
/* 112 */           sysMenuItem.setFolderOrNot(false);
/*     */         }
/*     */ 
/* 115 */         this.cacheContainer.put(sysMenuItem.getMenuItemId() + "|" + sysMenuItem.getParentId(), sysMenuItem);
/*     */       }
/*     */ 
/* 120 */       if (null != sqlca) {
/* 121 */         sqlca.closeAll();
/*     */       }
/* 123 */       if (null != subSqlca)
/* 124 */         subSqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 118 */       this.log.error("SysMenuItemViewCache init error... " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */ 
/* 120 */       if (null != sqlca) {
/* 121 */         sqlca.closeAll();
/*     */       }
/* 123 */       if (null != subSqlca)
/* 124 */         subSqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 120 */       if (null != sqlca) {
/* 121 */         sqlca.closeAll();
/*     */       }
/* 123 */       if (null != subSqlca) {
/* 124 */         subSqlca.closeAll();
/*     */       }
/*     */     }
/* 127 */     this.log.debug(">>SysMenuItemViewCache init successful...");
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean refreshByKey(Object key)
/*     */   {
/* 133 */     String[] menuKey = key.toString().split("\\|");
/* 134 */     SqlcaPst m_Sqlca = null;
/* 135 */     SqlcaPst subSqlca = null;
/* 136 */     boolean res = false;
/*     */     try
/*     */     {
/* 139 */       subSqlca = new SqlcaPst(new ConnectionEx());
/* 140 */       String subSql = " SELECT PARENTID FROM V_SYS_MENU_ITEM GROUP BY PARENTID ";
/* 141 */       subSqlca.setSql(subSql);
/* 142 */       subSqlca.execute();
/* 143 */       List list = new ArrayList();
/* 144 */       while (subSqlca.next()) {
/* 145 */         list.add(Integer.valueOf(subSqlca.getInt("PARENTID")));
/*     */       }
/*     */ 
/* 148 */       m_Sqlca = new SqlcaPst(new ConnectionEx());
/* 149 */       String loadSql = "select * from v_sys_menu_item where menuitemid= ? and parentid=?";
/* 150 */       m_Sqlca.setSql(loadSql);
/* 151 */       m_Sqlca.setInteger(1, Integer.valueOf(Integer.parseInt(menuKey[0])));
/* 152 */       m_Sqlca.setInteger(2, Integer.valueOf(Integer.parseInt(menuKey[1])));
/* 153 */       m_Sqlca.execute();
/*     */ 
/* 156 */       while (m_Sqlca.next()) {
/* 157 */         SysMenuItem sysMenuItem = new SysMenuItem();
/* 158 */         sysMenuItem.setMenuItemId(Integer.valueOf(m_Sqlca.getInt("menuitemid")));
/* 159 */         sysMenuItem.setMenuItemTitle(m_Sqlca.getString("menuitemtitle"));
/* 160 */         sysMenuItem.setParentId(Integer.valueOf(m_Sqlca.getInt("parentid")));
/* 161 */         sysMenuItem.setSortNum(Integer.valueOf(m_Sqlca.getInt("sortnum")));
/* 162 */         sysMenuItem.setPic1(m_Sqlca.getString("pic1"));
/* 163 */         sysMenuItem.setPic2(m_Sqlca.getString("pic2"));
/* 164 */         sysMenuItem.setMenuType(Integer.valueOf(m_Sqlca.getInt("menutype")));
/* 165 */         sysMenuItem.setUrl(m_Sqlca.getString("url"));
/* 166 */         sysMenuItem.setResId(m_Sqlca.getString("resid"));
/* 167 */         sysMenuItem.setResType(Integer.valueOf(m_Sqlca.getInt("restype")));
/* 168 */         sysMenuItem.setAccessToken(Integer.valueOf(m_Sqlca.getInt("accesstoken")));
/* 169 */         sysMenuItem.setUrlTarget(m_Sqlca.getString("urltarget"));
/* 170 */         sysMenuItem.setUrlPort(m_Sqlca.getString("urlport"));
/* 171 */         sysMenuItem.setImagePath(m_Sqlca.getString("imagepath"));
/* 172 */         sysMenuItem.setApplicationId(m_Sqlca.getString("application_id"));
/* 173 */         sysMenuItem.setResourceType(Integer.valueOf(m_Sqlca.getInt("resource_type")));
/*     */ 
/* 176 */         if (list.contains(sysMenuItem.getMenuItemId()))
/* 177 */           sysMenuItem.setFolderOrNot(true);
/*     */         else {
/* 179 */           sysMenuItem.setFolderOrNot(false);
/*     */         }
/*     */ 
/* 182 */         this.cacheContainer.put(sysMenuItem.getMenuItemId() + "|" + sysMenuItem.getParentId(), sysMenuItem);
/*     */       }
/* 184 */       res = true;
/*     */     } catch (Exception e) {
/* 186 */       this.log.error("SysMenuItemViewCache refreshByKey(" + key + ") " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 188 */       if (m_Sqlca != null) {
/* 189 */         m_Sqlca.closeAll();
/*     */       }
/* 191 */       if (subSqlca != null) {
/* 192 */         subSqlca.closeAll();
/*     */       }
/*     */     }
/* 195 */     return res;
/*     */   }
/*     */ 
/*     */   public boolean refreshById(Object key) {
/* 199 */     SqlcaPst m_Sqlca = null;
/* 200 */     SqlcaPst subSqlca = null;
/* 201 */     boolean res = false;
/*     */     try {
/* 203 */       subSqlca = new SqlcaPst(new ConnectionEx());
/* 204 */       String subSql = " SELECT PARENTID FROM V_SYS_MENU_ITEM GROUP BY PARENTID ";
/* 205 */       subSqlca.setSql(subSql);
/* 206 */       subSqlca.execute();
/* 207 */       List list = new ArrayList();
/* 208 */       while (subSqlca.next()) {
/* 209 */         list.add(Integer.valueOf(subSqlca.getInt("PARENTID")));
/*     */       }
/*     */ 
/* 212 */       m_Sqlca = new SqlcaPst(new ConnectionEx());
/* 213 */       String loadSql = "select * from v_sys_menu_item where menuitemid= ?";
/* 214 */       m_Sqlca.setSql(loadSql);
/* 215 */       m_Sqlca.setInteger(1, Integer.valueOf(Integer.parseInt(key.toString())));
/* 216 */       m_Sqlca.execute();
/*     */ 
/* 218 */       while (m_Sqlca.next()) {
/* 219 */         SysMenuItem sysMenuItem = new SysMenuItem();
/* 220 */         sysMenuItem.setMenuItemId(Integer.valueOf(m_Sqlca.getInt("menuitemid")));
/* 221 */         sysMenuItem.setMenuItemTitle(m_Sqlca.getString("menuitemtitle"));
/* 222 */         sysMenuItem.setParentId(Integer.valueOf(m_Sqlca.getInt("parentid")));
/* 223 */         sysMenuItem.setSortNum(Integer.valueOf(m_Sqlca.getInt("sortnum")));
/* 224 */         sysMenuItem.setPic1(m_Sqlca.getString("pic1"));
/* 225 */         sysMenuItem.setPic2(m_Sqlca.getString("pic2"));
/* 226 */         sysMenuItem.setMenuType(Integer.valueOf(m_Sqlca.getInt("menutype")));
/* 227 */         sysMenuItem.setUrl(m_Sqlca.getString("url"));
/* 228 */         sysMenuItem.setResId(m_Sqlca.getString("resid"));
/* 229 */         sysMenuItem.setResType(Integer.valueOf(m_Sqlca.getInt("restype")));
/* 230 */         sysMenuItem.setAccessToken(Integer.valueOf(m_Sqlca.getInt("accesstoken")));
/* 231 */         sysMenuItem.setUrlTarget(m_Sqlca.getString("urltarget"));
/* 232 */         sysMenuItem.setUrlPort(m_Sqlca.getString("urlport"));
/* 233 */         sysMenuItem.setImagePath(m_Sqlca.getString("imagepath"));
/* 234 */         sysMenuItem.setApplicationId(m_Sqlca.getString("application_id"));
/* 235 */         sysMenuItem.setResourceType(Integer.valueOf(m_Sqlca.getInt("resource_type")));
/*     */ 
/* 238 */         if (list.contains(sysMenuItem.getMenuItemId()))
/* 239 */           sysMenuItem.setFolderOrNot(true);
/*     */         else {
/* 241 */           sysMenuItem.setFolderOrNot(false);
/*     */         }
/* 243 */         this.cacheContainer.put(sysMenuItem.getMenuItemId() + "|" + sysMenuItem.getParentId(), sysMenuItem);
/*     */       }
/* 245 */       res = true;
/*     */     } catch (Exception e) {
/* 247 */       this.log.error("SysMenuItemViewCache refreshByKey(" + key + ") " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 249 */       if (m_Sqlca != null) {
/* 250 */         m_Sqlca.closeAll();
/*     */       }
/* 252 */       if (subSqlca != null) {
/* 253 */         subSqlca.closeAll();
/*     */       }
/*     */     }
/* 256 */     return res;
/*     */   }
/*     */ 
/*     */   public void removeObjectById(Object id) {
/* 260 */     Iterator iterator = this.cacheContainer.entrySet().iterator();
/* 261 */     while (iterator.hasNext()) {
/* 262 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 263 */       SysMenuItem smi = (SysMenuItem)entry.getValue();
/* 264 */       if (Integer.parseInt(id.toString()) == smi.getMenuItemId().intValue()) {
/* 265 */         iterator.remove();
/* 266 */         this.cacheContainer.remove(smi.getMenuItemId() + "|" + smi.getParentId());
/* 267 */         refreshById(smi.getParentId());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<SysMenuItem> getMenuItemListById(int menuItemId)
/*     */   {
/* 280 */     List smiList = new ArrayList();
/* 281 */     Collection collection = getAllCachedObject();
/* 282 */     if ((null != collection) && (!collection.isEmpty())) {
/* 283 */       Iterator it = collection.iterator();
/* 284 */       while (it.hasNext()) {
/* 285 */         SysMenuItem smi = (SysMenuItem)it.next();
/* 286 */         if (menuItemId == smi.getMenuItemId().intValue()) {
/* 287 */           smiList.add(smi);
/*     */         }
/*     */       }
/*     */     }
/* 291 */     return smiList;
/*     */   }
/*     */ 
/*     */   public List<SysMenuItem> getSubMenuItemById(int menuItemId, List<SysMenuItem> smiList, boolean isCascade)
/*     */   {
/* 304 */     Collection collection = getAllCachedObject();
/* 305 */     if ((null != collection) && (!collection.isEmpty())) {
/* 306 */       Iterator it = collection.iterator();
/* 307 */       while (it.hasNext()) {
/* 308 */         SysMenuItem smi = (SysMenuItem)it.next();
/* 309 */         if (menuItemId == smi.getParentId().intValue()) {
/* 310 */           smiList.add(smi);
/* 311 */           if ((isCascade) && (smi.isFolderOrNot() == true)) {
/* 312 */             this.log.debug("menuItemId= " + smi.getMenuItemId());
/* 313 */             getSubMenuItemById(smi.getMenuItemId().intValue(), smiList, isCascade);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 318 */     return smiList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.SysMenuItemViewCache
 * JD-Core Version:    0.6.2
 */
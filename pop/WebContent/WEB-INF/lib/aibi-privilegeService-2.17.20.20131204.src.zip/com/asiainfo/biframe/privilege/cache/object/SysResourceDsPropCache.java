/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.common.cache.CacheFilter;
/*     */ import com.asiainfo.biframe.privilege.model.SysResourceDsProp;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SysResourceDsPropCache extends CacheBase
/*     */ {
/*  21 */   private static Log log = LogFactory.getLog(SysResourceDsPropCache.class);
/*     */ 
/*  23 */   private static SysResourceDsPropCache theInstance = new SysResourceDsPropCache();
/*     */ 
/*  25 */   private String selectField = " select t.resourcetype,t.prop_name,t.prop_key,t.prop_value ";
/*     */ 
/*  27 */   private String tableName = " sys_resource_ds_prop t ";
/*     */ 
/*  29 */   private String whereCause = " where 1=1  ";
/*     */ 
/*     */   public SysResourceDsPropCache()
/*     */   {
/*  33 */     init();
/*     */   }
/*     */ 
/*     */   public static SysResourceDsPropCache getInstance() {
/*  37 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/*  43 */     return null;
/*     */   }
/*     */ 
/*     */   protected synchronized boolean init()
/*     */   {
/*  48 */     Sqlca m_Sqlca = null;
/*  49 */     boolean res = false;
/*  50 */     this.cacheContainer = new Hashtable();
/*     */     try {
/*  52 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  53 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause;
/*  54 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  56 */       while (m_Sqlca.next()) {
/*  57 */         SysResourceDsProp resourceDsProp = new SysResourceDsProp();
/*  58 */         resourceDsProp.setResourceType(m_Sqlca.getInt("resourcetype"));
/*  59 */         resourceDsProp.setPropName(m_Sqlca.getString("prop_name"));
/*  60 */         resourceDsProp.setPropKey(m_Sqlca.getString("prop_key"));
/*  61 */         resourceDsProp.setPropValue(m_Sqlca.getString("prop_value"));
/*  62 */         this.cacheContainer.put(resourceDsProp.getPrimaryKey(), resourceDsProp);
/*     */       }
/*     */ 
/*  65 */       res = true;
/*     */     } catch (Exception e) {
/*  67 */       log.error("SysResourceDsPropCache init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/*  71 */       if (m_Sqlca != null)
/*  72 */         m_Sqlca.closeAll();
/*     */     }
/*  74 */     return res;
/*     */   }
/*     */ 
/*     */   public boolean refreshByKey(Object key)
/*     */   {
/*  79 */     Sqlca m_Sqlca = null;
/*  80 */     boolean res = false;
/*  81 */     String[] keyArray = key.toString().split("\\|", -1);
/*  82 */     String resourceType = keyArray[0];
/*  83 */     String propKey = keyArray[1];
/*  84 */     log.debug("key:" + key.toString() + ",resourceType:" + resourceType + ",propKey:" + propKey);
/*     */     try
/*     */     {
/*  87 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  88 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " and t.resourcetype=" + resourceType + " and t.prop_key = '" + propKey + "' ";
/*     */ 
/*  91 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  93 */       while (m_Sqlca.next()) {
/*  94 */         SysResourceDsProp resourceDsProp = new SysResourceDsProp();
/*  95 */         resourceDsProp.setResourceType(m_Sqlca.getInt("resourcetype"));
/*  96 */         resourceDsProp.setPropName(m_Sqlca.getString("prop_name"));
/*  97 */         resourceDsProp.setPropKey(m_Sqlca.getString("prop_key"));
/*  98 */         resourceDsProp.setPropValue(m_Sqlca.getString("prop_value"));
/*  99 */         this.cacheContainer.put(resourceDsProp.getPrimaryKey(), resourceDsProp);
/*     */       }
/*     */ 
/* 102 */       res = true;
/*     */ 
/* 104 */       log.debug(">>SysResourceDsProp refresh successful...");
/*     */     } catch (Exception e) {
/* 106 */       log.error("SysResourceDsProp init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 110 */       if (m_Sqlca != null)
/* 111 */         m_Sqlca.closeAll();
/*     */     }
/* 113 */     return res;
/*     */   }
/*     */ 
/*     */   public String getPropValue(int resourceType, String propKey) {
/* 117 */     if (this.cacheContainer.containsKey(resourceType + "|" + propKey)) {
/* 118 */       return ((SysResourceDsProp)this.cacheContainer.get(resourceType + "|" + propKey)).getPropValue();
/*     */     }
/*     */ 
/* 122 */     refreshByKey(resourceType + "|" + propKey);
/* 123 */     if (this.cacheContainer.containsKey(resourceType + "|" + propKey)) {
/* 124 */       return ((SysResourceDsProp)this.cacheContainer.get(resourceType + "|" + propKey)).getPropValue();
/*     */     }
/*     */ 
/* 127 */     return "";
/*     */   }
/*     */ 
/*     */   public Collection<SysResourceDsProp> getObjectByResourceType(final int resourceType)
/*     */   {
/* 132 */     Map map = getObjectByCondition(new CacheFilter()
/*     */     {
/*     */       public boolean match(Object a) {
/* 135 */         int resType = ((SysResourceDsProp)a).getResourceType();
/* 136 */         if (resType == resourceType) {
/* 137 */           return true;
/*     */         }
/* 139 */         return false;
/*     */       }
/*     */     });
/* 142 */     Collection srdpList = map.values();
/*     */ 
/* 144 */     if (CollectionUtils.isEmpty(srdpList)) {
/* 145 */       refreshByType(resourceType);
/* 146 */       map = getObjectByCondition(new CacheFilter()
/*     */       {
/*     */         public boolean match(Object a) {
/* 149 */           int resType = ((SysResourceDsProp)a).getResourceType();
/* 150 */           if (resType == resourceType) {
/* 151 */             return true;
/*     */           }
/* 153 */           return false;
/*     */         }
/*     */       });
/* 156 */       srdpList = map.values();
/*     */     }
/* 158 */     return srdpList;
/*     */   }
/*     */ 
/*     */   public boolean refreshByType(int resourceType) {
/* 162 */     Sqlca m_Sqlca = null;
/* 163 */     boolean res = false;
/*     */     try {
/* 165 */       m_Sqlca = new Sqlca(new ConnectionEx());
/* 166 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " and t.resourcetype=" + resourceType;
/*     */ 
/* 168 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 170 */       while (m_Sqlca.next()) {
/* 171 */         SysResourceDsProp resourceDsProp = new SysResourceDsProp();
/* 172 */         resourceDsProp.setResourceType(m_Sqlca.getInt("resourcetype"));
/* 173 */         resourceDsProp.setPropName(m_Sqlca.getString("prop_name"));
/* 174 */         resourceDsProp.setPropKey(m_Sqlca.getString("prop_key"));
/* 175 */         resourceDsProp.setPropValue(m_Sqlca.getString("prop_value"));
/* 176 */         this.cacheContainer.put(resourceDsProp.getPrimaryKey(), resourceDsProp);
/*     */       }
/*     */ 
/* 179 */       res = true;
/*     */ 
/* 181 */       log.debug(">>SysResourceDsProp refresh successful...");
/*     */     } catch (Exception e) {
/* 183 */       log.error("SysResourceDsProp init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 187 */       if (m_Sqlca != null)
/* 188 */         m_Sqlca.closeAll();
/*     */     }
/* 190 */     return res;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.SysResourceDsPropCache
 * JD-Core Version:    0.6.2
 */
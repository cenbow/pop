/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.comparator.SysResourceTypeComparator;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SysResourceTypeCache extends CacheBase
/*     */ {
/*  33 */   private static Log log = LogFactory.getLog(SysResourceTypeCache.class);
/*     */ 
/*  35 */   private static SysResourceTypeCache theInstance = new SysResourceTypeCache();
/*     */ 
/*  37 */   private String selectField = "select type.resourcetype,type.resourcetype_name,type.res_right_table,type.res_define_table, type.right_img,type.role_type,type.resourcekey,type.role_right_table,type.ds_type,  (select '-1' from resource_operation_define t where t.operationkey = '-1' and (select count(operationkey) from resource_operation_define x where x.resourcetype = t.resourcetype group by x.resourcetype) = 1 and t.resourcetype=type.resourcetype) isDistinguishOperation";
/*     */ 
/*  44 */   private String tableName = " sys_resource_type type";
/*     */ 
/*  46 */   private String whereCause = " where 1=1  ";
/*     */ 
/*     */   public static SysResourceTypeCache getInstance() {
/*  49 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public SysResourceTypeCache()
/*     */   {
/*  55 */     init();
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean init()
/*     */   {
/*  71 */     Sqlca m_Sqlca = null;
/*  72 */     boolean res = false;
/*  73 */     this.cacheContainer = new Hashtable();
/*     */     try {
/*  75 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  76 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause;
/*  77 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  79 */       while (m_Sqlca.next()) {
/*  80 */         SysResourceType type = new SysResourceType();
/*  81 */         type.setResourceType(m_Sqlca.getInt("resourcetype"));
/*  82 */         type.setResourcetypeName(m_Sqlca.getString("resourcetype_name"));
/*  83 */         type.setResRightTable(m_Sqlca.getString("res_right_table"));
/*  84 */         type.setResDefineTable(m_Sqlca.getString("res_define_table"));
/*  85 */         type.setRightImg(m_Sqlca.getInteger("right_img"));
/*  86 */         type.setRoleType(m_Sqlca.getInt("role_type"));
/*  87 */         type.setResourceKey(m_Sqlca.getString("resourcekey"));
/*  88 */         type.setRoleRightTable(m_Sqlca.getString("role_right_table"));
/*  89 */         type.setDsType(m_Sqlca.getInt("ds_type"));
/*     */ 
/*  91 */         if (2 == type.getRoleType())
/*     */         {
/*  93 */           if (StringUtils.isBlank(type.getRoleRightTable()))
/*  94 */             type.setIsDistinguishOperation(false);
/*     */           else
/*  96 */             type.setIsDistinguishOperation(true);
/*     */         }
/*     */         else {
/*  99 */           String isDistinguishOperation = m_Sqlca.getString("isDistinguishOperation");
/* 100 */           if ("-1".equals(isDistinguishOperation))
/* 101 */             type.setIsDistinguishOperation(false);
/*     */           else {
/* 103 */             type.setIsDistinguishOperation(true);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 108 */         this.cacheContainer.put(type.getPrimaryKey(), type);
/*     */       }
/* 110 */       res = true;
/*     */ 
/* 112 */       log.debug(">>SysResourceTypeCache init successful...");
/*     */     } catch (Exception e) {
/* 114 */       log.error("SysResourceTypeCache init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 116 */       if (m_Sqlca != null)
/* 117 */         m_Sqlca.closeAll();
/*     */     }
/* 119 */     return res;
/*     */   }
/*     */ 
/*     */   public boolean refreshByKey(Object key)
/*     */   {
/* 127 */     Sqlca m_Sqlca = null;
/* 128 */     boolean res = false;
/* 129 */     String[] keyArray = key.toString().split("\\|", -1);
/* 130 */     String roleType = keyArray[0];
/* 131 */     String resourceType = keyArray[1];
/* 132 */     log.debug("key:" + key.toString() + ",roleType:" + roleType + ",resourceType:" + resourceType);
/*     */     try {
/* 134 */       m_Sqlca = new Sqlca(new ConnectionEx());
/* 135 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " and type.role_type=" + roleType + " and type.resourcetype=" + resourceType;
/* 136 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 138 */       while (m_Sqlca.next()) {
/* 139 */         SysResourceType type = new SysResourceType();
/* 140 */         type.setResourceType(m_Sqlca.getInt("resourcetype"));
/* 141 */         type.setResourcetypeName(m_Sqlca.getString("resourcetype_name"));
/* 142 */         type.setResRightTable(m_Sqlca.getString("res_right_table"));
/* 143 */         type.setResDefineTable(m_Sqlca.getString("res_define_table"));
/* 144 */         type.setRightImg(m_Sqlca.getInteger("right_img"));
/* 145 */         type.setRoleType(m_Sqlca.getInt("role_type"));
/* 146 */         type.setResourceKey(m_Sqlca.getString("resourcekey"));
/* 147 */         type.setRoleRightTable(m_Sqlca.getString("role_right_table"));
/* 148 */         type.setDsType(m_Sqlca.getInt("ds_type"));
/*     */ 
/* 150 */         if (2 == type.getRoleType())
/*     */         {
/* 152 */           if (StringUtils.isBlank(type.getRoleRightTable()))
/* 153 */             type.setIsDistinguishOperation(false);
/*     */           else
/* 155 */             type.setIsDistinguishOperation(true);
/*     */         }
/*     */         else {
/* 158 */           String isDistinguishOperation = m_Sqlca.getString("isDistinguishOperation");
/* 159 */           if ("-1".equals(isDistinguishOperation))
/* 160 */             type.setIsDistinguishOperation(false);
/*     */           else {
/* 162 */             type.setIsDistinguishOperation(true);
/*     */           }
/*     */         }
/*     */ 
/* 166 */         this.cacheContainer.put(type.getPrimaryKey(), type);
/*     */       }
/* 168 */       res = true;
/*     */ 
/* 170 */       log.debug(">>SysResourceTypeCache init successful...");
/*     */     } catch (Exception e) {
/* 172 */       log.error("SysResourceTypeCache init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 174 */       if (m_Sqlca != null)
/* 175 */         m_Sqlca.closeAll();
/*     */     }
/* 177 */     return res;
/*     */   }
/*     */ 
/*     */   public SysResourceType getSysResourceType(int roleType, int resourceType)
/*     */   {
/* 182 */     Collection collection = getAllCachedObject();
/* 183 */     SysResourceType returnObject = null;
/* 184 */     if (collection != null) {
/* 185 */       Iterator it = collection.iterator();
/* 186 */       while (it.hasNext()) {
/* 187 */         SysResourceType sysResourceType = (SysResourceType)it.next();
/*     */ 
/* 189 */         if ((sysResourceType.getResourceType() == resourceType) && 
/* 190 */           (sysResourceType.getRoleType() == roleType)) {
/* 191 */           returnObject = sysResourceType;
/*     */         }
/*     */       }
/*     */     }
/* 195 */     return returnObject;
/*     */   }
/*     */ 
/*     */   public SysResourceType getSysResourceType(int resourceType) {
/* 199 */     Collection collection = getAllCachedObject();
/* 200 */     SysResourceType returnObject = null;
/* 201 */     if (collection != null) {
/* 202 */       Iterator it = collection.iterator();
/* 203 */       while (it.hasNext()) {
/* 204 */         SysResourceType sysResourceType = (SysResourceType)it.next();
/* 205 */         if (sysResourceType.getResourceType() == resourceType) {
/* 206 */           returnObject = sysResourceType;
/* 207 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 211 */     return returnObject;
/*     */   }
/*     */ 
/*     */   public Collection getAllSysResourceTypeByName()
/*     */   {
/* 216 */     if (this.cacheContainer == null)
/*     */     {
/* 218 */       refreshAll();
/* 219 */       if (this.cacheContainer == null) {
/* 220 */         return null;
/*     */       }
/*     */     }
/* 223 */     SysResourceType[] resourceTypeArray = (SysResourceType[])this.cacheContainer.values().toArray(new SysResourceType[0]);
/*     */ 
/* 225 */     Arrays.sort(resourceTypeArray, new SysResourceTypeComparator());
/*     */ 
/* 227 */     List srtList = new ArrayList();
/* 228 */     CollectionUtils.addAll(srtList, resourceTypeArray);
/*     */ 
/* 230 */     return srtList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache
 * JD-Core Version:    0.6.2
 */
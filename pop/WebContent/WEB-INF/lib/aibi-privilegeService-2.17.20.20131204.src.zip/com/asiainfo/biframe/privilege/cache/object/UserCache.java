/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.comparator.UserComparator;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.SqlcaPst;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserCache extends CacheBase
/*     */ {
/*  41 */   private static Log log = LogFactory.getLog(UserCache.class);
/*     */ 
/*  43 */   private static UserCache theInstance = new UserCache();
/*     */ 
/*  45 */   private String selectField = "select us.*,ugmap.group_id ";
/*     */ 
/*  47 */   private String tableName = " user_user us,user_group_map ugmap ";
/*     */ 
/*  49 */   private String whereCause = " where us.userid=ugmap.userid ";
/*     */ 
/*     */   public static UserCache getInstance()
/*     */   {
/*  56 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public UserCache()
/*     */   {
/*  64 */     init();
/*     */   }
/*     */ 
/*     */   protected synchronized boolean init()
/*     */   {
/*  72 */     Sqlca m_Sqlca = null;
/*  73 */     boolean res = false;
/*     */ 
/*  75 */     Hashtable tempContainer = new Hashtable();
/*     */     try {
/*  77 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  78 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " order by us.userId";
/*  79 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  81 */       while (m_Sqlca.next()) {
/*  82 */         User_User tmpObj = new User_User();
/*  83 */         tmpObj.setUserid(m_Sqlca.getString("userId"));
/*  84 */         tmpObj.setCityid(m_Sqlca.getString("cityId"));
/*  85 */         tmpObj.setDepartmentid(m_Sqlca.getInt("departmentId"));
/*  86 */         tmpObj.setUsername(m_Sqlca.getString("userName"));
/*  87 */         tmpObj.setPassword(m_Sqlca.getString("pwd"));
/*     */ 
/*  89 */         tmpObj.setStatus(m_Sqlca.getInt("status"));
/*  90 */         tmpObj.setBegindate(m_Sqlca.getDate("begindate"));
/*  91 */         tmpObj.setEnddate(m_Sqlca.getDate("enddate"));
/*  92 */         tmpObj.setCreatetime(m_Sqlca.getDate("createtime"));
/*     */ 
/*  94 */         tmpObj.setBirthday(m_Sqlca.getDate("birthday"));
/*  95 */         tmpObj.setMobilephone(m_Sqlca.getString("mobilephone"));
/*  96 */         tmpObj.setMobilephone1(m_Sqlca.getString("mobilephone1"));
/*  97 */         tmpObj.setMobilephone2(m_Sqlca.getString("mobilephone2"));
/*  98 */         tmpObj.setHomephone(m_Sqlca.getString("homephone"));
/*  99 */         tmpObj.setOfficephone(m_Sqlca.getString("officephone"));
/*     */ 
/* 101 */         tmpObj.setOfficefax(m_Sqlca.getString("officefax"));
/* 102 */         tmpObj.setEmail(m_Sqlca.getString("email"));
/* 103 */         tmpObj.setEmail1(m_Sqlca.getString("email1"));
/* 104 */         tmpObj.setEmail2(m_Sqlca.getString("email2"));
/* 105 */         tmpObj.setNotes(m_Sqlca.getString("notes"));
/* 106 */         tmpObj.setDutyid(Integer.valueOf(m_Sqlca.getInt("dutyid")));
/*     */ 
/* 108 */         tmpObj.setSex(m_Sqlca.getString("sex"));
/* 109 */         tmpObj.setAge(m_Sqlca.getString("age"));
/* 110 */         tmpObj.setAddress(m_Sqlca.getString("address"));
/* 111 */         tmpObj.setPostalcode(m_Sqlca.getString("postalcode"));
/* 112 */         tmpObj.setNation(m_Sqlca.getString("nation"));
/*     */ 
/* 114 */         tmpObj.setPassportNo(m_Sqlca.getString("passportNo"));
/* 115 */         tmpObj.setDirector(m_Sqlca.getString("director"));
/* 116 */         tmpObj.setGroupId(m_Sqlca.getString("group_id"));
/* 117 */         tmpObj.setDeleteTime(m_Sqlca.getString("delete_time"));
/* 118 */         tmpObj.setSensitiveDataLevel(m_Sqlca.getString("sensitive_data_level"));
/* 119 */         tmpObj.setDomainType(m_Sqlca.getString("domain_type"));
/*     */ 
/* 121 */         tempContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */       }
/* 123 */       this.cacheContainer = tempContainer;
/* 124 */       res = true;
/*     */ 
/* 126 */       log.debug("--user cache size:" + this.cacheContainer.size());
/* 127 */       log.debug(">>UserCache init successful...");
/*     */     } catch (Exception e) {
/* 129 */       log.error("UserCache init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 131 */       if (m_Sqlca != null)
/* 132 */         m_Sqlca.closeAll();
/*     */     }
/* 134 */     return res;
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/* 142 */     if (key == null)
/* 143 */       return null;
/* 144 */     if (this.cacheContainer.containsKey(key)) {
/* 145 */       return ((User_User)this.cacheContainer.get(key)).getUsername();
/*     */     }
/*     */ 
/* 148 */     refreshByKey(key);
/* 149 */     if (this.cacheContainer.containsKey(key))
/* 150 */       return ((User_User)this.cacheContainer.get(key)).getUsername();
/* 151 */     return "";
/*     */   }
/*     */ 
/*     */   public synchronized boolean refreshByKey(Object key)
/*     */   {
/* 160 */     SqlcaPst m_Sqlca = null;
/* 161 */     boolean res = false;
/*     */     try {
/* 163 */       m_Sqlca = new SqlcaPst(new ConnectionEx());
/* 164 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " and us.userId=?";
/*     */ 
/* 166 */       m_Sqlca.setSql(loadSql);
/* 167 */       m_Sqlca.setString(1, key.toString());
/* 168 */       m_Sqlca.execute();
/*     */ 
/* 170 */       if (m_Sqlca.next()) {
/* 171 */         User_User tmpObj = new User_User();
/* 172 */         tmpObj.setUserid(m_Sqlca.getString("userId"));
/* 173 */         tmpObj.setCityid(m_Sqlca.getString("cityId"));
/* 174 */         tmpObj.setDepartmentid(m_Sqlca.getInt("departmentId"));
/* 175 */         tmpObj.setUsername(m_Sqlca.getString("userName"));
/* 176 */         tmpObj.setPassword(m_Sqlca.getString("pwd"));
/*     */ 
/* 178 */         tmpObj.setStatus(m_Sqlca.getInt("status"));
/* 179 */         tmpObj.setBegindate(m_Sqlca.getDate("begindate"));
/* 180 */         tmpObj.setEnddate(m_Sqlca.getDate("enddate"));
/* 181 */         tmpObj.setCreatetime(m_Sqlca.getDate("createtime"));
/*     */ 
/* 183 */         tmpObj.setBirthday(m_Sqlca.getDate("birthday"));
/* 184 */         tmpObj.setMobilephone(m_Sqlca.getString("mobilephone"));
/* 185 */         tmpObj.setMobilephone1(m_Sqlca.getString("mobilephone1"));
/* 186 */         tmpObj.setMobilephone2(m_Sqlca.getString("mobilephone2"));
/* 187 */         tmpObj.setHomephone(m_Sqlca.getString("homephone"));
/* 188 */         tmpObj.setOfficephone(m_Sqlca.getString("officephone"));
/*     */ 
/* 190 */         tmpObj.setOfficefax(m_Sqlca.getString("officefax"));
/* 191 */         tmpObj.setEmail(m_Sqlca.getString("email"));
/* 192 */         tmpObj.setEmail1(m_Sqlca.getString("email1"));
/* 193 */         tmpObj.setEmail2(m_Sqlca.getString("email2"));
/* 194 */         tmpObj.setNotes(m_Sqlca.getString("notes"));
/* 195 */         tmpObj.setDutyid(Integer.valueOf(m_Sqlca.getInt("dutyid")));
/*     */ 
/* 197 */         tmpObj.setSex(m_Sqlca.getString("sex"));
/* 198 */         tmpObj.setAge(m_Sqlca.getString("age"));
/* 199 */         tmpObj.setAddress(m_Sqlca.getString("address"));
/* 200 */         tmpObj.setPostalcode(m_Sqlca.getString("postalcode"));
/* 201 */         tmpObj.setNation(m_Sqlca.getString("nation"));
/*     */ 
/* 203 */         tmpObj.setPassportNo(m_Sqlca.getString("passportNo"));
/* 204 */         tmpObj.setDirector(m_Sqlca.getString("director"));
/* 205 */         tmpObj.setGroupId(m_Sqlca.getString("group_id"));
/* 206 */         tmpObj.setDeleteTime(m_Sqlca.getString("delete_time"));
/* 207 */         tmpObj.setSensitiveDataLevel(m_Sqlca.getString("sensitive_data_level"));
/* 208 */         tmpObj.setDomainType(m_Sqlca.getString("domain_type"));
/*     */ 
/* 210 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */       }
/* 212 */       res = true;
/*     */     } catch (Exception e) {
/* 214 */       log.error("UserCache refreshByKey() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 216 */       if (m_Sqlca != null)
/* 217 */         m_Sqlca.closeAll();
/*     */     }
/* 219 */     return res;
/*     */   }
/*     */ 
/*     */   public Collection getAllUsersSortedByName() {
/* 223 */     if (this.cacheContainer == null)
/*     */     {
/* 225 */       refreshAll();
/* 226 */       if (this.cacheContainer == null)
/* 227 */         return null;
/*     */     }
/* 229 */     log.debug("cacheContainer.values().size:" + this.cacheContainer.values().size());
/*     */ 
/* 231 */     User_User[] userArray = (User_User[])this.cacheContainer.values().toArray(new User_User[0]);
/* 232 */     Arrays.sort(userArray, new UserComparator());
/* 233 */     log.debug("userArray.length:" + userArray.length);
/*     */ 
/* 235 */     List userList = new ArrayList();
/* 236 */     CollectionUtils.addAll(userList, userArray);
/*     */ 
/* 238 */     log.debug("userList.size:" + userList.size());
/* 239 */     return userList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.UserCache
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.common.cache.CacheFilter;
/*     */ import com.asiainfo.biframe.privilege.model.User_City;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserCityCache extends CacheBase
/*     */ {
/*  24 */   private static Log log = LogFactory.getLog(UserCityCache.class);
/*     */ 
/*  26 */   private static UserCityCache theInstance = new UserCityCache();
/*     */   private ArrayList cacheKeyArray;
/*     */ 
/*     */   public static UserCityCache getInstance()
/*     */   {
/*  35 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public UserCityCache()
/*     */   {
/*  43 */     init();
/*     */   }
/*     */ 
/*     */   protected boolean init()
/*     */   {
/*  52 */     Sqlca m_Sqlca = null;
/*  53 */     boolean res = false;
/*  54 */     this.cacheContainer = new Hashtable();
/*  55 */     this.cacheKeyArray = new ArrayList();
/*     */     try {
/*  57 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  58 */       String loadSql = "select *  from user_city order by parentId,sortnum,cityId";
/*     */ 
/*  60 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  63 */       ResultSetMetaData rsMetaData = m_Sqlca.getMetaData();
/*  64 */       int columnCount = rsMetaData.getColumnCount();
/*  65 */       Set columnNames = new HashSet();
/*  66 */       for (int i = 1; i <= columnCount; i++) {
/*  67 */         columnNames.add(rsMetaData.getColumnName(i).toUpperCase());
/*     */       }
/*  69 */       if (columnNames.contains("DM_TYPE_ID")) {
/*  70 */         while (m_Sqlca.next()) {
/*  71 */           User_City tmpObj = new User_City();
/*  72 */           tmpObj.setCityId(m_Sqlca.getString("cityId"));
/*  73 */           tmpObj.setCityName(m_Sqlca.getString("cityName"));
/*  74 */           tmpObj.setParentId(m_Sqlca.getString("parentId"));
/*  75 */           tmpObj.setSortNum(m_Sqlca.getInt("sortNum"));
/*  76 */           tmpObj.setDmCityId(m_Sqlca.getString("dm_city_id"));
/*  77 */           tmpObj.setDmCountyId(m_Sqlca.getString("dm_county_id"));
/*  78 */           tmpObj.setDmDeptId(m_Sqlca.getString("dm_dept_id"));
/*  79 */           tmpObj.setDmTypeId(m_Sqlca.getString("dm_type_id"));
/*  80 */           tmpObj.setDmTypeCode(m_Sqlca.getString("dm_type_code"));
/*     */ 
/*  82 */           this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*  83 */           this.cacheKeyArray.add(tmpObj.getPrimaryKey());
/*     */         }
/*     */       }
/*  86 */       while (m_Sqlca.next()) {
/*  87 */         User_City tmpObj = new User_City();
/*  88 */         tmpObj.setCityId(m_Sqlca.getString("cityId"));
/*  89 */         tmpObj.setCityName(m_Sqlca.getString("cityName"));
/*  90 */         tmpObj.setParentId(m_Sqlca.getString("parentId"));
/*  91 */         tmpObj.setSortNum(m_Sqlca.getInt("sortNum"));
/*  92 */         tmpObj.setDmCityId(m_Sqlca.getString("dm_city_id"));
/*  93 */         tmpObj.setDmCountyId(m_Sqlca.getString("dm_county_id"));
/*  94 */         tmpObj.setDmDeptId(m_Sqlca.getString("dm_dept_id"));
/*     */ 
/*  96 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*  97 */         this.cacheKeyArray.add(tmpObj.getPrimaryKey());
/*     */       }
/*     */ 
/* 100 */       res = true;
/*     */ 
/* 102 */       log.debug(">>UserCityCache init successful...");
/*     */     } catch (Exception e) {
/* 104 */       log.error("UserCityCache init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 106 */       if (m_Sqlca != null)
/* 107 */         m_Sqlca.closeAll();
/*     */     }
/* 109 */     return res;
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/* 122 */     if (key == null)
/* 123 */       return null;
/* 124 */     if (this.cacheContainer.containsKey(key)) {
/* 125 */       return ((User_City)this.cacheContainer.get(key)).getCityName();
/*     */     }
/*     */ 
/* 128 */     refreshByKey(key);
/* 129 */     if (this.cacheContainer.containsKey(key))
/* 130 */       return ((User_City)this.cacheContainer.get(key)).getCityName();
/* 131 */     return "";
/*     */   }
/*     */ 
/*     */   public boolean refreshByKey(Object key)
/*     */   {
/* 140 */     Sqlca m_Sqlca = null;
/* 141 */     boolean res = false;
/*     */     try {
/* 143 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 145 */       String loadSql = "select *  from user_city where cityId='" + key + "'";
/*     */ 
/* 147 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 150 */       ResultSetMetaData rsMetaData = m_Sqlca.getMetaData();
/* 151 */       int columnCount = rsMetaData.getColumnCount();
/* 152 */       Set columnNames = new HashSet();
/* 153 */       for (int i = 1; i < columnCount; i++) {
/* 154 */         columnNames.add(rsMetaData.getColumnName(i).toUpperCase());
/*     */       }
/* 156 */       if (columnNames.contains("DM_TYPE_ID")) {
/* 157 */         while (m_Sqlca.next()) {
/* 158 */           User_City tmpObj = new User_City();
/* 159 */           tmpObj.setCityId(m_Sqlca.getString("cityId"));
/* 160 */           tmpObj.setCityName(m_Sqlca.getString("cityName"));
/* 161 */           tmpObj.setParentId(m_Sqlca.getString("parentId"));
/* 162 */           tmpObj.setSortNum(m_Sqlca.getInt("sortNum"));
/* 163 */           tmpObj.setDmCityId(m_Sqlca.getString("dm_city_id"));
/* 164 */           tmpObj.setDmCountyId(m_Sqlca.getString("dm_county_id"));
/* 165 */           tmpObj.setDmDeptId(m_Sqlca.getString("dm_dept_id"));
/* 166 */           tmpObj.setDmDeptId(m_Sqlca.getString("dm_type_id"));
/* 167 */           tmpObj.setDmTypeCode(m_Sqlca.getString("dm_type_code"));
/*     */ 
/* 169 */           this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */         }
/*     */       }
/* 172 */       while (m_Sqlca.next()) {
/* 173 */         User_City tmpObj = new User_City();
/* 174 */         tmpObj.setCityId(m_Sqlca.getString("cityId"));
/* 175 */         tmpObj.setCityName(m_Sqlca.getString("cityName"));
/* 176 */         tmpObj.setParentId(m_Sqlca.getString("parentId"));
/* 177 */         tmpObj.setSortNum(m_Sqlca.getInt("sortNum"));
/* 178 */         tmpObj.setDmCityId(m_Sqlca.getString("dm_city_id"));
/* 179 */         tmpObj.setDmCountyId(m_Sqlca.getString("dm_county_id"));
/* 180 */         tmpObj.setDmDeptId(m_Sqlca.getString("dm_dept_id"));
/*     */ 
/* 182 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */       }
/*     */ 
/* 186 */       refreshKeyArray();
/* 187 */       res = true;
/*     */     } catch (Exception e) {
/* 189 */       log.error("UserCityCache refreshByKey(" + key + ") " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 191 */       if (m_Sqlca != null)
/* 192 */         m_Sqlca.closeAll();
/*     */     }
/* 194 */     return res;
/*     */   }
/*     */ 
/*     */   public synchronized boolean refreshKeyArray()
/*     */   {
/* 202 */     Sqlca m_Sqlca = null;
/* 203 */     boolean res = false;
/*     */     try
/*     */     {
/* 206 */       ArrayList keyArray = new ArrayList();
/* 207 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 209 */       String loadSql = "select cityId,cityName,parentId from user_city  order by parentId,sortnum,cityId";
/*     */ 
/* 211 */       m_Sqlca.execute(loadSql);
/* 212 */       while (m_Sqlca.next())
/*     */       {
/* 214 */         keyArray.add(m_Sqlca.getString("cityId"));
/*     */       }
/* 216 */       this.cacheKeyArray.clear();
/* 217 */       this.cacheKeyArray.addAll(keyArray);
/* 218 */       res = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 222 */       log.error("UserCityCache refreshKeyArray() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 226 */       if (m_Sqlca != null)
/* 227 */         m_Sqlca.closeAll();
/*     */     }
/* 229 */     return res;
/*     */   }
/*     */ 
/*     */   public List getCityListByFilter(CacheFilter cf)
/*     */   {
/* 237 */     ArrayList ret = new ArrayList();
/* 238 */     for (int i = 0; i < this.cacheKeyArray.size(); i++)
/*     */     {
/* 240 */       Object tmpKey = this.cacheKeyArray.get(i);
/* 241 */       if (null != tmpKey)
/*     */       {
/* 243 */         Object tmpObj = this.cacheContainer.get(tmpKey);
/* 244 */         if (cf.match(tmpObj))
/*     */         {
/* 246 */           ret.add(tmpObj);
/*     */         }
/*     */       }
/*     */     }
/* 249 */     return ret;
/*     */   }
/*     */ 
/*     */   public List getAllSortedCityList() {
/* 253 */     ArrayList ret = new ArrayList();
/* 254 */     for (int i = 0; i < this.cacheKeyArray.size(); i++)
/*     */     {
/* 256 */       Object tmpKey = this.cacheKeyArray.get(i);
/* 257 */       if (null != tmpKey)
/*     */       {
/* 259 */         Object tmpObj = this.cacheContainer.get(tmpKey);
/* 260 */         ret.add(tmpObj);
/*     */       }
/*     */     }
/* 262 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<User_City> getParentListById(String cityId)
/*     */   {
/* 267 */     if ((cityId == null) || ("".equals(cityId)) || (this.cacheContainer == null) || (this.cacheContainer.size() <= 0) || (this.cacheContainer.get(cityId) == null)) {
/* 268 */       return null;
/*     */     }
/*     */ 
/* 271 */     List retList = null;
/* 272 */     User_City userCity = null;
/* 273 */     if (this.cacheContainer.containsKey(cityId)) {
/* 274 */       userCity = (User_City)this.cacheContainer.get(cityId);
/*     */     }
/*     */ 
/* 277 */     while (this.cacheContainer.containsKey(userCity.getParentId())) {
/* 278 */       userCity = (User_City)this.cacheContainer.get(userCity.getParentId());
/* 279 */       if ((userCity == null) || (null == userCity.getParentId()) || ("".equals(userCity))) break;
/* 280 */       if (retList == null) {
/* 281 */         retList = new ArrayList();
/*     */       }
/* 283 */       retList.add(userCity);
/*     */     }
/*     */ 
/* 291 */     return retList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.UserCityCache
 * JD-Core Version:    0.6.2
 */
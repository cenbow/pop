/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.privilege.model.UserCityDmType;
/*     */ import com.asiainfo.biframe.privilege.model.User_Company;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.comparator.UserCityDmTypeComparator;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserCityDmTypeCache extends CacheBase
/*     */ {
/*  33 */   private static Log log = LogFactory.getLog(UserCityDmTypeCache.class);
/*     */ 
/*  35 */   private static UserCityDmTypeCache theInstance = new UserCityDmTypeCache();
/*     */ 
/*  37 */   private String selectField = "select * ";
/*     */ 
/*  39 */   private String tableName = "user_city_dm_type";
/*     */ 
/*  41 */   private String whereCause = "";
/*     */   private static List<UserCityDmType> objectSortedList;
/*     */ 
/*     */   public static UserCityDmTypeCache getInstance()
/*     */   {
/*  50 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public UserCityDmTypeCache()
/*     */   {
/*  58 */     init();
/*     */   }
/*     */ 
/*     */   protected synchronized boolean init()
/*     */   {
/*  66 */     Sqlca m_Sqlca = null;
/*  67 */     boolean res = false;
/*  68 */     this.cacheContainer = new Hashtable();
/*     */     try
/*     */     {
/*  71 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  72 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " order by DM_LEVEL";
/*     */ 
/*  74 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  76 */       while (m_Sqlca.next())
/*     */       {
/*  78 */         UserCityDmType tmpObj = new UserCityDmType();
/*  79 */         tmpObj.setUserCityDmTypeId(m_Sqlca.getString("USER_CITY_DM_TYPE_ID"));
/*  80 */         tmpObj.setDmTypeCode(m_Sqlca.getString("DM_TYPE_CODE"));
/*  81 */         tmpObj.setDmTable(m_Sqlca.getString("DM_TABLE"));
/*  82 */         tmpObj.setDmCol(m_Sqlca.getString("DM_COL"));
/*  83 */         tmpObj.setDmLevel(m_Sqlca.getInt("DM_LEVEL"));
/*  84 */         tmpObj.setDmTypeDesc(m_Sqlca.getString("DM_TYPE_DESC"));
/*     */ 
/*  86 */         this.cacheContainer.put(tmpObj.getDmTypeCode(), tmpObj);
/*     */       }
/*  88 */       objectSortedList = new ArrayList();
/*  89 */       objectSortedList.addAll(getAllCachedSortedObject());
/*  90 */       res = true;
/*     */ 
/*  92 */       log.debug(">>UserCityDmTypeCache init successful...");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  96 */       log.error("UserCityDmType init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 100 */       if (m_Sqlca != null)
/* 101 */         m_Sqlca.closeAll();
/*     */     }
/* 103 */     return res;
/*     */   }
/*     */ 
/*     */   public List<UserCityDmType> getObjectSortedList() {
/* 107 */     return objectSortedList;
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/* 116 */     if (key == null)
/* 117 */       return null;
/* 118 */     if (this.cacheContainer.containsKey(key)) {
/* 119 */       return ((User_Company)this.cacheContainer.get(key)).getTitle();
/*     */     }
/*     */ 
/* 122 */     refreshByKey(key);
/* 123 */     if (this.cacheContainer.containsKey(key))
/* 124 */       return ((User_Company)this.cacheContainer.get(key)).getTitle();
/* 125 */     return "";
/*     */   }
/*     */ 
/*     */   public synchronized boolean refreshByKey(Object key)
/*     */   {
/* 134 */     Sqlca m_Sqlca = null;
/* 135 */     boolean res = false;
/*     */     try
/*     */     {
/* 138 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 140 */       String loadSql = this.selectField + " from " + this.tableName + " where dm_type_code='" + key + "'";
/*     */ 
/* 142 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 144 */       if (m_Sqlca.next())
/*     */       {
/* 146 */         UserCityDmType tmpObj = new UserCityDmType();
/* 147 */         tmpObj.setUserCityDmTypeId(m_Sqlca.getString("USER_CITY_DM_TYPE_ID"));
/* 148 */         tmpObj.setDmTypeCode(m_Sqlca.getString("DM_TYPE_CODE"));
/* 149 */         tmpObj.setDmTable(m_Sqlca.getString("DM_TABLE"));
/* 150 */         tmpObj.setDmCol(m_Sqlca.getString("DM_COL"));
/* 151 */         tmpObj.setDmLevel(m_Sqlca.getInt("DM_LEVEL"));
/* 152 */         tmpObj.setDmTypeDesc(m_Sqlca.getString("DM_TYPE_DESC"));
/*     */ 
/* 154 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */       }
/* 156 */       objectSortedList = new ArrayList();
/* 157 */       objectSortedList.addAll(getAllCachedSortedObject());
/* 158 */       res = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 162 */       log.error("UserCityDmType refreshByKey() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 166 */       if (m_Sqlca != null)
/* 167 */         m_Sqlca.closeAll();
/*     */     }
/* 169 */     return res;
/*     */   }
/*     */ 
/*     */   public Collection getAllUserCityDmTypeSortedByLevel()
/*     */   {
/* 175 */     if (this.cacheContainer == null)
/*     */     {
/* 177 */       refreshAll();
/* 178 */       if (this.cacheContainer == null) {
/* 179 */         return null;
/*     */       }
/*     */     }
/* 182 */     UserCityDmType[] userCityDmTypeArray = (UserCityDmType[])this.cacheContainer.values().toArray(new UserCityDmType[0]);
/* 183 */     Arrays.sort(userCityDmTypeArray, new UserCityDmTypeComparator());
/* 184 */     log.debug("roleArray.length:" + userCityDmTypeArray.length);
/*     */ 
/* 186 */     List userCityDmTypeList = new ArrayList();
/* 187 */     CollectionUtils.addAll(userCityDmTypeList, userCityDmTypeArray);
/*     */ 
/* 189 */     log.debug("userCityDmTypeList.size:" + userCityDmTypeList.size());
/* 190 */     return userCityDmTypeList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.UserCityDmTypeCache
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.privilege.model.User_Company;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserCompanyCache extends CacheBase
/*     */ {
/*  27 */   private static Log log = LogFactory.getLog(UserCompanyCache.class);
/*     */ 
/*  29 */   private static UserCompanyCache theInstance = new UserCompanyCache();
/*     */ 
/*  31 */   private String selectField = "select deptId,parentId,title,notes,service_code,cityId ";
/*     */ 
/*  33 */   private String tableName = "user_company";
/*     */ 
/*  35 */   private String whereCause = "";
/*     */ 
/*     */   public static UserCompanyCache getInstance()
/*     */   {
/*  42 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public UserCompanyCache()
/*     */   {
/*  50 */     init();
/*     */   }
/*     */ 
/*     */   protected synchronized boolean init()
/*     */   {
/*  58 */     Sqlca m_Sqlca = null;
/*  59 */     boolean res = false;
/*  60 */     this.cacheContainer = new Hashtable();
/*     */     try
/*     */     {
/*  63 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  64 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " order by sortnum,title";
/*     */ 
/*  66 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  68 */       while (m_Sqlca.next())
/*     */       {
/*  70 */         User_Company tmpObj = new User_Company();
/*  71 */         tmpObj.setDeptid(Integer.valueOf(m_Sqlca.getInt("deptId")));
/*  72 */         tmpObj.setParentid(Integer.valueOf(m_Sqlca.getInt("parentId")));
/*  73 */         tmpObj.setTitle(m_Sqlca.getString("title"));
/*  74 */         tmpObj.setNotes(m_Sqlca.getString("notes"));
/*  75 */         tmpObj.setServiceCode(m_Sqlca.getString("service_code"));
/*  76 */         tmpObj.setCityId(m_Sqlca.getString("cityid"));
/*     */ 
/*  78 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */       }
/*  80 */       res = true;
/*     */ 
/*  82 */       log.debug(">>UserCompanyCache init successful...");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  86 */       log.error("User_Company init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/*  90 */       if (m_Sqlca != null)
/*  91 */         m_Sqlca.closeAll();
/*     */     }
/*  93 */     return res;
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/* 101 */     if (key == null)
/* 102 */       return null;
/* 103 */     if (this.cacheContainer.containsKey(key)) {
/* 104 */       return ((User_Company)this.cacheContainer.get(key)).getTitle();
/*     */     }
/*     */ 
/* 107 */     refreshByKey(key);
/* 108 */     if (this.cacheContainer.containsKey(key))
/* 109 */       return ((User_Company)this.cacheContainer.get(key)).getTitle();
/* 110 */     return "";
/*     */   }
/*     */ 
/*     */   public synchronized boolean refreshByKey(Object key)
/*     */   {
/* 119 */     Sqlca m_Sqlca = null;
/* 120 */     boolean res = false;
/*     */     try
/*     */     {
/* 123 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 125 */       String loadSql = this.selectField + " from " + this.tableName + " where deptId=" + key;
/*     */ 
/* 127 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 129 */       if (m_Sqlca.next())
/*     */       {
/* 131 */         User_Company tmpObj = new User_Company();
/* 132 */         tmpObj.setDeptid(Integer.valueOf(m_Sqlca.getInt("deptId")));
/* 133 */         tmpObj.setParentid(Integer.valueOf(m_Sqlca.getInt("parentId")));
/* 134 */         tmpObj.setTitle(m_Sqlca.getString("title"));
/* 135 */         tmpObj.setNotes(m_Sqlca.getString("notes"));
/* 136 */         tmpObj.setServiceCode(m_Sqlca.getString("service_code"));
/* 137 */         tmpObj.setCityId(m_Sqlca.getString("cityid"));
/*     */ 
/* 139 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */       }
/* 141 */       res = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 145 */       log.error("User_Company refreshByKey() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 149 */       if (m_Sqlca != null)
/* 150 */         m_Sqlca.closeAll();
/*     */     }
/* 152 */     return res;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.UserCompanyCache
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.privilege.model.User_Duty;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserDutyCache extends CacheBase
/*     */ {
/*  27 */   private static Log log = LogFactory.getLog(UserDutyCache.class);
/*     */ 
/*  29 */   private static UserDutyCache theInstance = new UserDutyCache();
/*     */ 
/*  31 */   private String selectField = "select dutyId,parentId,title,cityid,status,delete_time";
/*     */ 
/*  33 */   private String tableName = "user_duty";
/*     */ 
/*  35 */   private String whereCause = "";
/*     */ 
/*     */   public static UserDutyCache getInstance()
/*     */   {
/*  42 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public UserDutyCache()
/*     */   {
/*  50 */     init();
/*     */   }
/*     */ 
/*     */   protected synchronized boolean init()
/*     */   {
/*  58 */     Sqlca m_Sqlca = null;
/*  59 */     boolean res = false;
/*  60 */     this.cacheContainer = new Hashtable();
/*     */     try
/*     */     {
/*  63 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  64 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " order by dutyId";
/*     */ 
/*  66 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  68 */       while (m_Sqlca.next())
/*     */       {
/*  70 */         User_Duty tmpObj = new User_Duty();
/*  71 */         tmpObj.setDutyid(m_Sqlca.getInt("dutyId"));
/*  72 */         tmpObj.setParentid(m_Sqlca.getInt("parentId"));
/*  73 */         tmpObj.setTitle(m_Sqlca.getString("title"));
/*  74 */         tmpObj.setCityid(m_Sqlca.getString("cityid"));
/*  75 */         tmpObj.setStatus(m_Sqlca.getString("status"));
/*  76 */         tmpObj.setDeleteTime(m_Sqlca.getString("delete_time"));
/*     */ 
/*  79 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */       }
/*  81 */       res = true;
/*     */ 
/*  83 */       log.debug(">>UserDutyCache init successful...");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  87 */       log.error("User_Duty init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/*  91 */       if (m_Sqlca != null)
/*  92 */         m_Sqlca.closeAll();
/*     */     }
/*  94 */     return res;
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/* 102 */     if (key == null)
/* 103 */       return null;
/* 104 */     if (this.cacheContainer.containsKey(key)) {
/* 105 */       return ((User_Duty)this.cacheContainer.get(key)).getTitle();
/*     */     }
/*     */ 
/* 108 */     refreshByKey(key);
/* 109 */     if (this.cacheContainer.containsKey(key))
/* 110 */       return ((User_Duty)this.cacheContainer.get(key)).getTitle();
/* 111 */     return "";
/*     */   }
/*     */ 
/*     */   public synchronized boolean refreshByKey(Object key)
/*     */   {
/* 120 */     Sqlca m_Sqlca = null;
/* 121 */     boolean res = false;
/*     */     try
/*     */     {
/* 124 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 126 */       String loadSql = "";
/* 127 */       if (key.toString() != "null") {
/* 128 */         int dutyid = Integer.parseInt(key.toString());
/* 129 */         loadSql = this.selectField + " from " + this.tableName + " where dutyId=" + dutyid;
/*     */       }
/*     */       else {
/* 132 */         loadSql = this.selectField + " from " + this.tableName;
/*     */       }
/*     */ 
/* 135 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 137 */       if (m_Sqlca.next())
/*     */       {
/* 139 */         User_Duty tmpObj = new User_Duty();
/* 140 */         tmpObj.setDutyid(m_Sqlca.getInt("dutyId"));
/* 141 */         tmpObj.setParentid(m_Sqlca.getInt("parentId"));
/* 142 */         tmpObj.setTitle(m_Sqlca.getString("title"));
/* 143 */         tmpObj.setCityid(m_Sqlca.getString("cityid"));
/* 144 */         tmpObj.setStatus(m_Sqlca.getString("status"));
/* 145 */         tmpObj.setDeleteTime(m_Sqlca.getString("delete_time"));
/*     */ 
/* 148 */         this.cacheContainer.put(tmpObj.getPrimaryKey(), tmpObj);
/*     */       }
/* 150 */       res = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 154 */       log.error("User_Duty refreshByKey() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally
/*     */     {
/* 158 */       if (m_Sqlca != null)
/* 159 */         m_Sqlca.closeAll();
/*     */     }
/* 161 */     return res;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.UserDutyCache
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.comparator.GroupComparator;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserGroupDefineCache extends CacheBase
/*     */ {
/*  46 */   private Log log = LogFactory.getLog(UserGroupDefineCache.class);
/*     */ 
/*  48 */   private static UserGroupDefineCache theInstance = new UserGroupDefineCache();
/*     */ 
/*  50 */   private String selectField = " select GROUP_ID,GROUP_NAME,PARENT_ID,STATUS,CREATE_TIME,BEGIN_DATE,END_DATE,USER_LIMIT,SORTNUM,DELETE_TIME ";
/*     */ 
/*  52 */   private String tableName = "USER_GROUP";
/*     */ 
/*     */   public static UserGroupDefineCache getInstance()
/*     */   {
/*  61 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public UserGroupDefineCache()
/*     */   {
/*  69 */     init();
/*     */   }
/*     */ 
/*     */   protected synchronized boolean init()
/*     */   {
/*  78 */     Sqlca m_Sqlca = null;
/*  79 */     boolean res = false;
/*  80 */     Hashtable tempContainer = new Hashtable();
/*     */     try {
/*  82 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  83 */       String loadSql = this.selectField + " from " + this.tableName + " order by PARENT_ID,SORTNUM";
/*  84 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  86 */       while (m_Sqlca.next()) {
/*  87 */         User_Group tmpObj = new User_Group();
/*  88 */         tmpObj.setGroupid(m_Sqlca.getString("GROUP_ID"));
/*  89 */         tmpObj.setGroupname(m_Sqlca.getString("GROUP_NAME"));
/*  90 */         tmpObj.setParentid(m_Sqlca.getString("PARENT_ID"));
/*  91 */         tmpObj.setStatus(Long.valueOf(m_Sqlca.getLong("STATUS")));
/*  92 */         tmpObj.setDeleteTime(m_Sqlca.getString("delete_time"));
/*     */ 
/*  94 */         tempContainer.put(tmpObj.getGroupid(), tmpObj);
/*     */       }
/*  96 */       this.cacheContainer = tempContainer;
/*     */ 
/*  98 */       Collection values = this.cacheContainer.values();
/*  99 */       for (Iterator iterator = values.iterator(); iterator.hasNext(); ) {
/* 100 */         User_Group group = (User_Group)iterator.next();
/* 101 */         addParentId(group, group.getParentid());
/*     */       }
/*     */ 
/* 106 */       res = true;
/*     */ 
/* 108 */       this.log.debug(">>UserGroupDefineCache init successful...");
/*     */     } catch (Exception e) {
/* 110 */       this.log.error("UserGroupDefineCache init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 112 */       if (m_Sqlca != null)
/* 113 */         m_Sqlca.closeAll();
/*     */     }
/* 115 */     return res;
/*     */   }
/*     */ 
/*     */   private void addParentId(User_Group group, String parentId) {
/* 119 */     group.getAllParentId().add(parentId);
/*     */ 
/* 121 */     if (!"0".equals(parentId)) {
/* 122 */       Object parentObj = getObjectByKey(parentId);
/* 123 */       if (parentObj == null) {
/* 124 */         this.log.warn("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parentUserGroupNotExist") + "groupId:" + group.getGroupid() + ",parentId:" + parentId);
/*     */       } else {
/* 126 */         User_Group parentGroup = (User_Group)parentObj;
/* 127 */         addParentId(group, parentGroup.getParentid());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/* 142 */     if (key == null)
/* 143 */       return null;
/* 144 */     if (this.cacheContainer.containsKey(key)) {
/* 145 */       return ((User_Group)this.cacheContainer.get(key)).getGroupname();
/*     */     }
/*     */ 
/* 148 */     refreshByKey(key);
/* 149 */     if (this.cacheContainer.containsKey(key))
/* 150 */       return ((User_Group)this.cacheContainer.get(key)).getGroupname();
/* 151 */     return "";
/*     */   }
/*     */ 
/*     */   public synchronized boolean refreshByKey(Object key)
/*     */   {
/* 159 */     boolean res = false;
/* 160 */     Sqlca m_Sqlca = null;
/* 161 */     Sqlca sqlca2 = null;
/*     */     try {
/* 163 */       m_Sqlca = new Sqlca(new ConnectionEx());
/* 164 */       String loadSql = this.selectField + " from " + this.tableName + " where GROUP_ID='" + key + "' ";
/* 165 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 168 */       if (m_Sqlca.next()) {
/* 169 */         User_Group tmpObj = new User_Group();
/* 170 */         tmpObj.setGroupid(m_Sqlca.getString("GROUP_ID"));
/* 171 */         tmpObj.setGroupname(m_Sqlca.getString("GROUP_NAME"));
/* 172 */         tmpObj.setParentid(m_Sqlca.getString("PARENT_ID"));
/* 173 */         tmpObj.setStatus(Long.valueOf(m_Sqlca.getLong("STATUS")));
/* 174 */         tmpObj.setDeleteTime(m_Sqlca.getString("delete_time"));
/* 175 */         tmpObj.setHaveSon(false);
/*     */ 
/* 183 */         addParentId(tmpObj, tmpObj.getParentid());
/* 184 */         this.cacheContainer.put(tmpObj.getGroupid(), tmpObj);
/*     */       }
/*     */     } catch (Exception e) {
/* 187 */       this.log.error("UserGroupDefineCache refreshByKey(" + key + ") " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     }
/*     */     finally {
/* 190 */       if (sqlca2 != null)
/* 191 */         sqlca2.close();
/* 192 */       if (m_Sqlca != null)
/* 193 */         m_Sqlca.closeAll();
/*     */     }
/* 195 */     return res;
/*     */   }
/*     */ 
/*     */   public Collection getAllGroupsSortedByName()
/*     */   {
/* 200 */     if (this.cacheContainer == null)
/*     */     {
/* 203 */       refreshAll();
/* 204 */       if (this.cacheContainer == null)
/* 205 */         return null;
/*     */     }
/* 207 */     this.log.debug("cacheContainer.values().size:" + this.cacheContainer.values().size());
/*     */ 
/* 209 */     User_Group[] groupArray = (User_Group[])this.cacheContainer.values().toArray(new User_Group[0]);
/* 210 */     Arrays.sort(groupArray, new GroupComparator());
/* 211 */     this.log.debug("groupArray.length:" + groupArray.length);
/*     */ 
/* 213 */     List groupList = new ArrayList();
/* 214 */     CollectionUtils.addAll(groupList, groupArray);
/*     */ 
/* 216 */     this.log.debug("groupList.size:" + groupList.size());
/* 217 */     return groupList;
/*     */   }
/*     */ 
/*     */   public User_Group getObjectByName(String groupName)
/*     */   {
/* 222 */     Collection collection = getAllCachedObject();
/* 223 */     User_Group ug = null;
/* 224 */     if (CollectionUtils.isNotEmpty(collection)) {
/* 225 */       Iterator it = collection.iterator();
/* 226 */       while (it.hasNext()) {
/* 227 */         User_Group group = (User_Group)it.next();
/* 228 */         if (group.getGroupname().equals(groupName)) {
/* 229 */           ug = group;
/* 230 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 234 */     return ug;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.UserGroupDefineCache
 * JD-Core Version:    0.6.2
 */
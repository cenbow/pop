/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.comparator.RoleComparator;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserRoleCache extends CacheBase
/*     */ {
/*  30 */   private static Log log = LogFactory.getLog(UserRoleCache.class);
/*     */ 
/*  32 */   private static UserRoleCache theInstance = new UserRoleCache();
/*     */ 
/*  34 */   private String selectField = "select ur.role_id,ur.role_name,ur.parent_id,ur.role_type,ur.resourcetype,ur.status,ur.create_time,ur.begin_date,ur.end_date,ur.user_limit,ur.create_group,ur.delete_time,ur.classify_id  ";
/*     */ 
/*  36 */   private String tableName = " user_role ur ";
/*     */ 
/*  38 */   private String whereCause = " where 1=1  ";
/*     */ 
/*     */   public static UserRoleCache getInstance() {
/*  41 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public UserRoleCache()
/*     */   {
/*  46 */     init();
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/*  54 */     if (key == null)
/*  55 */       return null;
/*  56 */     if (this.cacheContainer.containsKey(key)) {
/*  57 */       return ((UserRole)this.cacheContainer.get(key)).getRoleName();
/*     */     }
/*     */ 
/*  60 */     refreshByKey(key);
/*  61 */     if (this.cacheContainer.containsKey(key))
/*  62 */       return ((UserRole)this.cacheContainer.get(key)).getRoleName();
/*  63 */     return "";
/*     */   }
/*     */ 
/*     */   protected synchronized boolean init()
/*     */   {
/*  71 */     Sqlca m_Sqlca = null;
/*  72 */     boolean res = false;
/*  73 */     Hashtable tempContainer = new Hashtable();
/*     */     try {
/*  75 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  76 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause;
/*  77 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  79 */       while (m_Sqlca.next()) {
/*  80 */         UserRole role = new UserRole();
/*  81 */         role.setRoleId(m_Sqlca.getString("role_id"));
/*  82 */         role.setRoleName(m_Sqlca.getString("role_name"));
/*  83 */         role.setParentId(m_Sqlca.getString("parent_id"));
/*  84 */         role.setRoleType(m_Sqlca.getInt("role_type"));
/*  85 */         role.setResourceType(m_Sqlca.getInt("resourcetype"));
/*  86 */         role.setStatus(m_Sqlca.getInt("status"));
/*  87 */         role.setCreateTime(m_Sqlca.getDate("create_time"));
/*  88 */         role.setBeginDate(m_Sqlca.getDate("begin_date"));
/*  89 */         role.setEndDate(m_Sqlca.getDate("end_date"));
/*  90 */         role.setUserLimit(m_Sqlca.getInt("user_limit"));
/*  91 */         role.setCreateGroup(m_Sqlca.getString("create_group"));
/*  92 */         role.setDeleteTime(m_Sqlca.getString("delete_time"));
/*  93 */         role.setClassifyId(m_Sqlca.getString("classify_id"));
/*     */ 
/*  95 */         tempContainer.put(role.getPrimaryKey(), role);
/*     */       }
/*  97 */       this.cacheContainer = tempContainer;
/*  98 */       res = true;
/*     */ 
/* 100 */       log.debug(">>UserRoleCache init successful...");
/*     */     } catch (Exception e) {
/* 102 */       log.error("UserRoleCache init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 104 */       if (m_Sqlca != null)
/* 105 */         m_Sqlca.closeAll();
/*     */     }
/* 107 */     return res;
/*     */   }
/*     */ 
/*     */   public synchronized boolean refreshByKey(Object key)
/*     */   {
/* 115 */     Sqlca m_Sqlca = null;
/* 116 */     boolean res = false;
/*     */     try {
/* 118 */       m_Sqlca = new Sqlca(new ConnectionEx());
/* 119 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " and ur.role_id='" + key + "'";
/* 120 */       log.debug("--sql:" + loadSql);
/* 121 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 123 */       while (m_Sqlca.next()) {
/* 124 */         UserRole role = new UserRole();
/* 125 */         role.setRoleId(m_Sqlca.getString("role_id"));
/* 126 */         role.setRoleName(m_Sqlca.getString("role_name"));
/* 127 */         role.setParentId(m_Sqlca.getString("parent_id"));
/* 128 */         role.setRoleType(m_Sqlca.getInt("role_type"));
/* 129 */         role.setResourceType(m_Sqlca.getInt("resourcetype"));
/* 130 */         role.setStatus(m_Sqlca.getInt("status"));
/* 131 */         role.setCreateTime(m_Sqlca.getDate("create_time"));
/* 132 */         role.setBeginDate(m_Sqlca.getDate("begin_date"));
/* 133 */         role.setEndDate(m_Sqlca.getDate("end_date"));
/* 134 */         role.setUserLimit(m_Sqlca.getInt("user_limit"));
/* 135 */         role.setCreateGroup(m_Sqlca.getString("create_group"));
/* 136 */         role.setDeleteTime(m_Sqlca.getString("delete_time"));
/* 137 */         role.setClassifyId(m_Sqlca.getString("classify_id"));
/*     */ 
/* 139 */         this.cacheContainer.put(role.getPrimaryKey(), role);
/*     */       }
/* 141 */       res = true;
/*     */ 
/* 143 */       log.debug(">>UserRoleCache refresh by key successful...");
/*     */     } catch (Exception e) {
/* 145 */       log.error("UserRoleCache refresh by key " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 147 */       if (m_Sqlca != null)
/* 148 */         m_Sqlca.closeAll();
/*     */     }
/* 150 */     return res;
/*     */   }
/*     */ 
/*     */   public Collection getAllRolesSortedByName() {
/* 154 */     if (this.cacheContainer == null)
/*     */     {
/* 156 */       refreshAll();
/* 157 */       if (this.cacheContainer == null) {
/* 158 */         return null;
/*     */       }
/*     */     }
/* 161 */     UserRole[] roleArray = (UserRole[])this.cacheContainer.values().toArray(new UserRole[0]);
/* 162 */     Arrays.sort(roleArray, new RoleComparator());
/* 163 */     log.debug("roleArray.length:" + roleArray.length);
/*     */ 
/* 165 */     List roleList = new ArrayList();
/* 166 */     CollectionUtils.addAll(roleList, roleArray);
/*     */ 
/* 168 */     log.debug("roleList.size:" + roleList.size());
/* 169 */     return roleList;
/*     */   }
/*     */ 
/*     */   public UserRole getObjectByName(String roleName)
/*     */   {
/* 174 */     Collection collection = getAllCachedObject();
/* 175 */     UserRole ur = null;
/* 176 */     if (CollectionUtils.isNotEmpty(collection)) {
/* 177 */       Iterator it = collection.iterator();
/* 178 */       while (it.hasNext()) {
/* 179 */         UserRole role = (UserRole)it.next();
/* 180 */         if (role.getRoleName().equals(roleName)) {
/* 181 */           ur = role;
/* 182 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 186 */     return ur;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.UserRoleCache
 * JD-Core Version:    0.6.2
 */
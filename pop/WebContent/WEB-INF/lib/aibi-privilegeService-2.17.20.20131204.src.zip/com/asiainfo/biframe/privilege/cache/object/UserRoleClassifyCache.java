/*     */ package com.asiainfo.biframe.privilege.cache.object;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheBase;
/*     */ import com.asiainfo.biframe.privilege.model.UserRoleClassify;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserRoleClassifyCache extends CacheBase
/*     */ {
/*  43 */   private static Log log = LogFactory.getLog(UserRoleClassifyCache.class);
/*     */ 
/*  45 */   private static UserRoleClassifyCache theInstance = new UserRoleClassifyCache();
/*     */ 
/*  47 */   private String selectField = "select urc.classify_id,urc.parent_id,urc.classify_name,urc.classify_desc ";
/*  48 */   private String tableName = " USER_ROLE_CLASSIFY urc ";
/*  49 */   private String whereCause = " where 1=1  ";
/*     */ 
/*     */   public static UserRoleClassifyCache getInstance() {
/*  52 */     return theInstance;
/*     */   }
/*     */ 
/*     */   public UserRoleClassifyCache()
/*     */   {
/*  57 */     init();
/*     */   }
/*     */ 
/*     */   public String getNameByKey(Object key)
/*     */   {
/*  65 */     if (key == null)
/*  66 */       return null;
/*  67 */     if (this.cacheContainer.containsKey(key)) {
/*  68 */       return ((UserRoleClassify)this.cacheContainer.get(key)).getClassifyName();
/*     */     }
/*     */ 
/*  71 */     refreshByKey(key);
/*  72 */     if (this.cacheContainer.containsKey(key))
/*  73 */       return ((UserRoleClassify)this.cacheContainer.get(key)).getClassifyName();
/*  74 */     return "";
/*     */   }
/*     */ 
/*     */   protected boolean init()
/*     */   {
/*  82 */     Sqlca m_Sqlca = null;
/*  83 */     boolean res = false;
/*  84 */     Hashtable tempContainer = new Hashtable();
/*     */     try {
/*  86 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*  87 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause;
/*  88 */       m_Sqlca.execute(loadSql);
/*     */ 
/*  90 */       while (m_Sqlca.next()) {
/*  91 */         UserRoleClassify classify = new UserRoleClassify();
/*  92 */         classify.setClassifyId(m_Sqlca.getString("classify_id"));
/*  93 */         classify.setClassifyName(m_Sqlca.getString("classify_name"));
/*  94 */         classify.setParentId(m_Sqlca.getString("parent_id"));
/*  95 */         classify.setClassifyDesc(m_Sqlca.getString("classify_desc"));
/*     */ 
/*  97 */         tempContainer.put(classify.getClassifyId(), classify);
/*     */       }
/*  99 */       this.cacheContainer = tempContainer;
/* 100 */       res = true;
/*     */ 
/* 102 */       log.debug(">>UserRoleClassifyCache init successful...");
/*     */     } catch (Exception e) {
/* 104 */       log.error("UserRoleClassifyCache init() " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 106 */       if (m_Sqlca != null)
/* 107 */         m_Sqlca.closeAll();
/*     */     }
/* 109 */     return res;
/*     */   }
/*     */ 
/*     */   public boolean refreshByKey(Object key)
/*     */   {
/* 117 */     Sqlca m_Sqlca = null;
/* 118 */     boolean res = false;
/*     */     try {
/* 120 */       m_Sqlca = new Sqlca(new ConnectionEx());
/* 121 */       String loadSql = this.selectField + " from " + this.tableName + this.whereCause + " and urc.classify_id='" + key + "'";
/* 122 */       log.debug("--sql:" + loadSql);
/* 123 */       m_Sqlca.execute(loadSql);
/*     */ 
/* 125 */       while (m_Sqlca.next()) {
/* 126 */         UserRoleClassify classify = new UserRoleClassify();
/* 127 */         classify.setClassifyId(m_Sqlca.getString("classify_id"));
/* 128 */         classify.setClassifyName(m_Sqlca.getString("classify_name"));
/* 129 */         classify.setParentId(m_Sqlca.getString("parent_id"));
/* 130 */         classify.setClassifyDesc(m_Sqlca.getString("classify_desc"));
/*     */ 
/* 132 */         this.cacheContainer.put(classify.getClassifyId(), classify);
/*     */       }
/* 134 */       res = true;
/*     */ 
/* 136 */       log.debug(">>UserRoleClassifyCache refresh by key successful...");
/*     */     } catch (Exception e) {
/* 138 */       log.error("UserRoleClassifyCache refresh by key " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorOccur") + "\n", e);
/*     */     } finally {
/* 140 */       if (m_Sqlca != null)
/* 141 */         m_Sqlca.closeAll();
/*     */     }
/* 143 */     return res;
/*     */   }
/*     */ 
/*     */   public UserRoleClassify getObjectByName(String classifyName)
/*     */   {
/* 148 */     Collection collection = getAllCachedObject();
/* 149 */     UserRoleClassify urc = null;
/* 150 */     if (CollectionUtils.isNotEmpty(collection)) {
/* 151 */       Iterator it = collection.iterator();
/* 152 */       while (it.hasNext()) {
/* 153 */         UserRoleClassify classify = (UserRoleClassify)it.next();
/* 154 */         if (classify.getClassifyName().equals(classifyName)) {
/* 155 */           urc = classify;
/* 156 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 160 */     return urc;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.object.UserRoleClassifyCache
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.cache.service;

public abstract interface IdAndName
{
  public abstract Object getPrimaryKey();

  public abstract String getName();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.cache.service.IdAndName
 * JD-Core Version:    0.6.2
 */
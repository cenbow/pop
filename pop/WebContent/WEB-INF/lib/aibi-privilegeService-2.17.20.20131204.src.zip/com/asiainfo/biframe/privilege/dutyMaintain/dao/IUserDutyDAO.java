package com.asiainfo.biframe.privilege.dutyMaintain.dao;

import com.asiainfo.biframe.privilege.model.User_Duty;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
import java.util.List;
import java.util.Map;

public abstract interface IUserDutyDAO
{
  public abstract void save(User_Duty paramUser_Duty)
    throws Exception;

  public abstract void update(User_Duty paramUser_Duty)
    throws Exception;

  public abstract void delete(User_Duty paramUser_Duty)
    throws Exception;

  public abstract User_Duty findById(String paramString);

  public abstract List<User_Duty> findAll(SearchCondition paramSearchCondition);

  public abstract List findByName(String paramString);

  public abstract Map getPagedUserList(SearchCondition paramSearchCondition, int paramInt1, int paramInt2);

  public abstract List<User_Duty> getDutyByName(String paramString);

  public abstract String doRealDelete(DeletedParameterVO paramDeletedParameterVO);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.dutyMaintain.dao.IUserDutyDAO
 * JD-Core Version:    0.6.2
 */
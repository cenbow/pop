/*     */ package com.asiainfo.biframe.privilege.dutyMaintain.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserDutyCache;
/*     */ import com.asiainfo.biframe.privilege.dutyMaintain.dao.IUserDutyDAO;
/*     */ import com.asiainfo.biframe.privilege.model.User_Duty;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserDutyDaoImpl extends HibernateDaoSupport
/*     */   implements IUserDutyDAO
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(UserDutyDaoImpl.class);
/*     */ 
/*     */   public void save(User_Duty duty) throws Exception {
/*  40 */     log.debug("saving");
/*  41 */     getHibernateTemplate().save(duty);
/*     */ 
/*  43 */     log.debug("save successful");
/*     */   }
/*     */ 
/*     */   public void update(User_Duty duty) throws Exception {
/*  47 */     log.debug("update");
/*  48 */     log.debug("**********dao update:" + duty.getDutyid() + " cityid:" + duty.getCityid());
/*     */ 
/*  50 */     getHibernateTemplate().update(duty);
/*  51 */     log.debug("update successful");
/*     */   }
/*     */ 
/*     */   public void delete(User_Duty duty) throws Exception {
/*  55 */     log.debug("deleting User_Duty instance");
/*  56 */     getHibernateTemplate().delete(duty);
/*  57 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public User_Duty findById(String id)
/*     */   {
/*  62 */     log.debug("getting User_Duty instance with id: " + id);
/*  63 */     if (id == null) {
/*  64 */       return null;
/*     */     }
/*  66 */     User_Duty instance = (User_Duty)UserDutyCache.getInstance().getObjectByKey(id);
/*  67 */     if (null == instance) {
/*  68 */       instance = (User_Duty)getHibernateTemplate().get(User_Duty.class, new Integer(Integer.parseInt(id)));
/*     */     }
/*  70 */     return instance;
/*     */   }
/*     */ 
/*     */   public List findByName(String title)
/*     */   {
/*  75 */     List list = getHibernateTemplate().find("from User_Duty duty where duty.title='" + title + "'");
/*     */ 
/*  77 */     return list;
/*     */   }
/*     */ 
/*     */   public List<User_Duty> findAll(SearchCondition condition)
/*     */   {
/*  82 */     log.debug("--------------in UserUserDaoImpl.findAll()..........");
/*  83 */     String strCond = getConditionSql(condition);
/*  84 */     String listSql = "from User_Duty as user" + strCond + " order by user.dutyid ";
/*  85 */     List list = getHibernateTemplate().find(listSql);
/*  86 */     log.debug("-----------------list.size=" + list.size());
/*  87 */     return list;
/*     */   }
/*     */ 
/*     */   public Map getPagedUserList(SearchCondition condition, final int currpage, final int pagesize) {
/*  91 */     log.debug("in getPagedUserList........");
/*     */ 
/*  93 */     HashMap map = new HashMap();
/*     */     try
/*     */     {
/*  96 */       final String strCond = getConditionSql(condition);
/*  97 */       String countSql = "select count(user) from User_Duty user " + strCond;
/*  98 */       log.info("----totals:" + countSql);
/*  99 */       List list = getHibernateTemplate().find(countSql);
/* 100 */       int totals = 0;
/* 101 */       if ((list != null) && (list.size() > 0)) {
/* 102 */         totals = ((Long)list.get(0)).intValue();
/*     */       }
/* 104 */       list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session s) throws HibernateException, SQLException
/*     */         {
/* 108 */           String listSql = "";
/* 109 */           listSql = "from User_Duty user " + strCond + " order by user.cityid ";
/*     */ 
/* 111 */           UserDutyDaoImpl.log.info("----listSql=" + listSql);
/* 112 */           Query query = s.createQuery(listSql);
/* 113 */           int firstResult = currpage * pagesize;
/* 114 */           int maxResult = pagesize;
/* 115 */           query.setFirstResult(firstResult);
/* 116 */           query.setMaxResults(maxResult);
/* 117 */           List tmpList = query.list();
/* 118 */           return tmpList;
/*     */         }
/*     */       });
/* 121 */       map.put("total", new Integer(totals));
/* 122 */       map.put("result", list);
/*     */     } catch (RuntimeException ex) {
/* 124 */       map.put("total", new Integer(0));
/* 125 */       map.put("result", new ArrayList());
/* 126 */       throw ex;
/*     */     }
/* 128 */     return map;
/*     */   }
/*     */ 
/*     */   private String getConditionSql(SearchCondition condition)
/*     */   {
/* 138 */     String sql = " where 1=1";
/* 139 */     if ((condition.getQueryCityid() != null) && (condition.getQueryCityid().trim().length() > 0)) {
/* 140 */       sql = sql + " and user.cityid='" + condition.getQueryCityid() + "'";
/*     */     }
/* 142 */     if (StringUtils.isNotBlank(condition.getQueryDutyName())) {
/* 143 */       sql = sql + " and user.title like '%" + condition.getQueryDutyName() + "%'";
/*     */     }
/* 145 */     if (condition.getQueryStatus() != -1) {
/* 146 */       sql = sql + " and user.status='" + condition.getQueryStatus() + "'";
/*     */     }
/* 148 */     if ((StringUtils.isNotBlank(condition.getBeginDeleteTime())) && (StringUtils.isNotBlank(condition.getEndDeleteTime()))) {
/* 149 */       sql = sql + " and user.deleteTime >= '" + condition.getBeginDeleteTime() + "'";
/* 150 */       sql = sql + " and user.deleteTime <= '" + condition.getEndDeleteTime() + "'";
/*     */     }
/* 152 */     if ((StringUtils.isNotBlank(condition.getQueryCityIds())) && (!condition.getQueryCityIds().equals("-1"))) {
/* 153 */       sql = sql + " and user.cityid in(" + condition.getQueryCityIds() + ")";
/*     */     }
/* 155 */     return sql;
/*     */   }
/*     */ 
/*     */   public List<User_Duty> getDutyByName(String dutyName)
/*     */   {
/* 162 */     List dutyList = getHibernateTemplate().find("from User_Duty ud where ud.title='" + dutyName + "'");
/* 163 */     return dutyList;
/*     */   }
/*     */ 
/*     */   public String doRealDelete(DeletedParameterVO vo) {
/* 167 */     log.debug("in doRealDelete ");
/*     */     try {
/* 169 */       StringBuilder hql = new StringBuilder(256);
/* 170 */       hql.append("from User_Duty duty where 1=1 and duty.status='").append("2").append("'");
/* 171 */       hql.append(vo.getWhereHql("dutyid", vo, "duty"));
/*     */ 
/* 173 */       log.debug("--deleteHql:" + hql);
/* 174 */       Collection dutys = getHibernateTemplate().find(hql.toString());
/* 175 */       StringBuilder dutyNames = new StringBuilder(256);
/* 176 */       for (User_Duty duty : dutys) {
/* 177 */         dutyNames.append(duty.getName()).append(",");
/*     */       }
/* 179 */       getHibernateTemplate().deleteAll(dutys);
/* 180 */       log.debug("end doRealDelete ");
/* 181 */       return dutyNames.toString();
/*     */     } catch (DataAccessException e) {
/* 183 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteDutyFail") + "", e);
/* 184 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteDutyFail") + "", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.dutyMaintain.dao.impl.UserDutyDaoImpl
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.dutyMaintain.service;

import com.asiainfo.biframe.privilege.model.User_Duty;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
import java.util.List;
import java.util.Map;

public abstract interface IDutyAdminService
{
  public abstract boolean addDuty(User_Duty paramUser_Duty)
    throws Exception;

  public abstract boolean[] updateDuty(User_Duty paramUser_Duty);

  public abstract void deleteDuty(User_Duty paramUser_Duty);

  public abstract boolean checkDuty(User_Duty paramUser_Duty)
    throws Exception;

  public abstract User_Duty getDuty(String paramString);

  public abstract List<User_Duty> getUserDutyList(SearchCondition paramSearchCondition);

  public abstract Map getPagedUserDutyList(SearchCondition paramSearchCondition, Integer paramInteger1, Integer paramInteger2);

  public abstract List<User_Duty> getDutyByName(String paramString);

  public abstract void doRealDeleteGroup(DeletedParameterVO paramDeletedParameterVO);

  public abstract void updateUserDuty(User_Duty paramUser_Duty);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.dutyMaintain.service.IDutyAdminService
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.dutyMaintain.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.cache.object.CacheUtils;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCityCache;
/*     */ import com.asiainfo.biframe.privilege.dutyMaintain.dao.IUserDutyDAO;
/*     */ import com.asiainfo.biframe.privilege.dutyMaintain.service.IDutyAdminService;
/*     */ import com.asiainfo.biframe.privilege.model.User_City;
/*     */ import com.asiainfo.biframe.privilege.model.User_Duty;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleMapDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.impl.ListService;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class DutyAdminServiceImpl
/*     */   implements IDutyAdminService
/*     */ {
/*  41 */   protected Logger logger = Logger.getLogger(getClass());
/*     */   private IUserDutyDAO userDutyDao;
/*     */   private IUserRoleDAO userRoleDao;
/*     */   private IUserRoleMapDAO userRoleMapDao;
/*     */   private IUserAdminService userAdminService;
/*     */ 
/*     */   public User_Duty getDuty(String dutyId)
/*     */   {
/*  49 */     this.logger.debug("in findUser");
/*     */ 
/*  51 */     User_Duty duty = this.userDutyDao.findById(dutyId);
/*  52 */     return duty;
/*     */   }
/*     */ 
/*     */   public boolean addDuty(User_Duty duty) {
/*  56 */     this.logger.debug("in addUser");
/*     */     try {
/*  58 */       if (duty != null) {
/*  59 */         List dutylist = this.userDutyDao.findByName(duty.getTitle());
/*  60 */         Iterator iterator = dutylist.iterator();
/*  61 */         while (iterator.hasNext()) {
/*  62 */           if (((User_Duty)iterator.next()).getCityid().equals(duty.getCityid())) {
/*  63 */             return false;
/*     */           }
/*     */         }
/*  66 */         this.userDutyDao.save(duty);
/*  67 */         return true;
/*     */       }
/*     */     } catch (Exception e) {
/*  70 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.createUserFail") + ":" + e, e);
/*  71 */       if ((e instanceof SysmanageException)) {
/*  72 */         throw ((SysmanageException)e);
/*     */       }
/*  74 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.createUserFail") + "!");
/*     */     }
/*     */ 
/*  78 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean checkDuty(User_Duty duty1)
/*     */     throws Exception
/*     */   {
/*  86 */     Sqlca m_Sqlca = null;
/*  87 */     boolean isuse = false;
/*  88 */     User_Duty duty = this.userDutyDao.findById(duty1.getDutyid() + "");
/*  89 */     int dutyid = duty.getDutyid();
/*     */ 
/*  91 */     m_Sqlca = new Sqlca(new ConnectionEx());
/*  92 */     m_Sqlca.execute("select * from user_user where dutyid=" + dutyid + "");
/*  93 */     if (m_Sqlca.next())
/*     */     {
/*  95 */       isuse = true;
/*  96 */     }if (m_Sqlca != null)
/*  97 */       m_Sqlca.closeAll();
/*  98 */     return isuse;
/*     */   }
/*     */ 
/*     */   public boolean[] updateDuty(User_Duty duty1) {
/* 102 */     Sqlca m_Sqlca = null;
/* 103 */     boolean[] update_flag = new boolean[2];
/* 104 */     update_flag[0] = true;
/* 105 */     update_flag[1] = false;
/*     */ 
/* 107 */     User_Duty dutytemp = null;
/* 108 */     User_Duty duty = this.userDutyDao.findById(duty1.getDutyid() + "");
/* 109 */     this.logger.debug("in updateDuty");
/*     */     try
/*     */     {
/* 112 */       int dutyid = duty.getDutyid();
/* 113 */       m_Sqlca = new Sqlca(new ConnectionEx());
/* 114 */       m_Sqlca.execute("select * from user_user where dutyid=" + dutyid + "");
/* 115 */       if (m_Sqlca.next())
/*     */       {
/* 117 */         update_flag[1] = true;
/*     */       }
/* 119 */       String strtitle = duty1.getTitle();
/* 120 */       String strcityid = duty1.getCityid();
/* 121 */       List dutylist = this.userDutyDao.findByName(duty1.getTitle());
/*     */ 
/* 123 */       Iterator iterator = dutylist.iterator();
/*     */       User_Duty dutys;
/* 124 */       while (iterator.hasNext())
/*     */       {
/* 126 */         dutys = (User_Duty)iterator.next();
/* 127 */         if ((dutys.getDutyid() == duty1.getDutyid()) && (dutys.getCityid().equals(duty1.getCityid()))) {
/* 128 */           update_flag[0] = true; } else {
/* 129 */           if ((dutys.getName().equals(strtitle)) && (dutys.getCityid().equals(strcityid))) {
/* 130 */             update_flag[0] = false;
/* 131 */             return update_flag;
/*     */           }
/* 133 */           update_flag[0] = true;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 139 */       return update_flag;
/*     */     }
/*     */     catch (Exception e) {
/* 142 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.modDutyFail") + ":" + e);
/* 143 */       if ((e instanceof SysmanageException)) {
/* 144 */         throw ((SysmanageException)e);
/*     */       }
/* 146 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.modDutyFail") + "!");
/*     */     }
/*     */     finally {
/* 149 */       if (null != m_Sqlca)
/* 150 */         m_Sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteDuty(User_Duty duty)
/*     */   {
/* 162 */     this.logger.debug("in deleteUser");
/*     */     try {
/* 164 */       String dutyNames = duty.getTitle();
/*     */ 
/* 166 */       String logResourceId = String.valueOf(duty.getDutyid());
/*     */ 
/* 168 */       this.userDutyDao.delete(duty);
/* 169 */       CacheUtils.refreshDutyCache();
/* 170 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), logResourceId, dutyNames, "职务维护-->删除职务", null, null);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 175 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.delUserFail2") + ":" + e);
/*     */ 
/* 178 */       if ((e instanceof SysmanageException)) {
/* 179 */         throw ((SysmanageException)e);
/*     */       }
/* 181 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.delUserFail2") + "!");
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<User_Duty> getUserDutyList(SearchCondition condition)
/*     */   {
/* 188 */     return this.userDutyDao.findAll(condition);
/*     */   }
/*     */ 
/*     */   public Map getPagedUserDutyList(SearchCondition condition, Integer currpage, Integer pagesize) {
/* 192 */     List cityList = new ArrayList();
/* 193 */     if (StringUtils.isNotBlank(condition.getQueryUserid())) {
/* 194 */       cityList = ListService.getAuthCityList(condition.getQueryUserid(), "1");
/*     */     }
/*     */ 
/* 197 */     StringBuffer cityIds = new StringBuffer();
/* 198 */     for (User_City city : cityList) {
/* 199 */       cityIds.append("'" + city.getCityId() + "',");
/*     */     }
/* 201 */     if ((null != cityIds) && (cityIds.length() > 0)) {
/* 202 */       condition.setQueryCityIds(cityIds.toString().substring(0, cityIds.toString().length() - 1));
/*     */     }
/*     */ 
/* 205 */     Map map = new HashMap();
/* 206 */     map = this.userDutyDao.getPagedUserList(condition, currpage.intValue(), pagesize.intValue());
/*     */ 
/* 209 */     Iterator iter = ((List)map.get("result")).iterator();
/* 210 */     List list = new ArrayList();
/* 211 */     while (iter.hasNext()) {
/* 212 */       User_Duty duty = (User_Duty)iter.next();
/*     */ 
/* 214 */       String cityName = UserCityCache.getInstance().getNameByKey(duty.getCityid());
/*     */ 
/* 216 */       if (StringUtils.isBlank(cityName)) {
/* 217 */         cityName = "" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.unknown") + "";
/*     */       }
/*     */ 
/* 221 */       duty.setCityName(cityName);
/* 222 */       list.add(duty);
/*     */     }
/* 224 */     map.remove("result");
/* 225 */     map.put("result", list);
/* 226 */     return map;
/*     */   }
/*     */ 
/*     */   public List<User_Duty> getDutyByName(String dutyName)
/*     */   {
/* 234 */     return getUserDutyDao().getDutyByName(dutyName);
/*     */   }
/*     */ 
/*     */   public IUserDutyDAO getUserDutyDao()
/*     */   {
/* 239 */     return this.userDutyDao;
/*     */   }
/*     */ 
/*     */   public void setUserDutyDao(IUserDutyDAO userDutyDao)
/*     */   {
/* 244 */     this.userDutyDao = userDutyDao;
/*     */   }
/*     */ 
/*     */   public IUserRoleDAO getUserRoleDao()
/*     */   {
/* 249 */     return this.userRoleDao;
/*     */   }
/*     */ 
/*     */   public void setUserRoleDao(IUserRoleDAO userRoleDao)
/*     */   {
/* 254 */     this.userRoleDao = userRoleDao;
/*     */   }
/*     */ 
/*     */   public IUserRoleMapDAO getUserRoleMapDao()
/*     */   {
/* 259 */     return this.userRoleMapDao;
/*     */   }
/*     */ 
/*     */   public void setUserRoleMapDao(IUserRoleMapDAO userRoleMapDao)
/*     */   {
/* 264 */     this.userRoleMapDao = userRoleMapDao;
/*     */   }
/*     */ 
/*     */   public IUserAdminService getUserAdminService()
/*     */   {
/* 269 */     return this.userAdminService;
/*     */   }
/*     */   public void setUserAdminService(IUserAdminService userAdminService) {
/* 272 */     this.userAdminService = userAdminService;
/*     */   }
/*     */ 
/*     */   public void doRealDeleteGroup(DeletedParameterVO vo)
/*     */   {
/*     */     try {
/* 278 */       this.logger.debug(" in doRealDeleteUser");
/*     */ 
/* 280 */       String dutyNames = this.userDutyDao.doRealDelete(vo);
/*     */ 
/* 282 */       String logResourceId = vo.getIdString();
/* 283 */       if (StringUtils.isBlank(logResourceId)) {
/* 284 */         logResourceId = "resourceId";
/*     */       }
/*     */ 
/* 289 */       this.logger.debug(" end doRealDeleteUser");
/*     */     } catch (DaoException e) {
/* 291 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.actualDelDutyFail") + "", e);
/* 292 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.actualDelDutyFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateUserDuty(User_Duty duty) {
/*     */     try {
/* 298 */       this.userDutyDao.update(duty);
/*     */     } catch (Exception e) {
/* 300 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.modDutyFail") + ":" + e);
/* 301 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.modDutyFail") + "!");
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.dutyMaintain.service.impl.DutyAdminServiceImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.foura.des;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.KeySpec;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ 
/*     */ public class EncryptData
/*     */ {
/*  26 */   private String keyfile = null;
/*     */ 
/*     */   public EncryptData() {
/*     */   }
/*     */ 
/*     */   public EncryptData(String keyfile) {
/*  32 */     this.keyfile = keyfile;
/*     */   }
/*     */ 
/*     */   public void createEncryptData(String filename, String filenamekey)
/*     */     throws IllegalStateException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException, IOException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalStateException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException, IOException
/*     */   {
/*  50 */     if ((this.keyfile == null) || (this.keyfile.equals("")))
/*     */     {
/*  52 */       throw new NullPointerException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invalidKeyFilePath"));
/*     */     }
/*     */ 
/*  55 */     encryptData(filename, filenamekey);
/*     */   }
/*     */ 
/*     */   private void encryptData(String filename, String encryptfile)
/*     */     throws IOException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, NoSuchAlgorithmException, BadPaddingException, IllegalBlockSizeException, IllegalStateException, ClassNotFoundException, SecurityException, NoSuchMethodException, InvocationTargetException, IllegalArgumentException, IllegalAccessException, InstantiationException
/*     */   {
/*  79 */     byte[] data = Util.readFile(filename);
/*     */ 
/*  81 */     byte[] encryptedClassData = getencryptData(data, "file");
/*     */ 
/*  83 */     Util.writeFile(encryptedClassData, encryptfile);
/*     */   }
/*     */ 
/*     */   public byte[] createEncryptData(byte[] bytes, String algorithm)
/*     */     throws IllegalStateException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException, IOException
/*     */   {
/* 111 */     bytes = getencryptData(bytes, algorithm);
/* 112 */     return bytes;
/*     */   }
/*     */ 
/*     */   private byte[] getencryptData(byte[] bytes, String algorithm)
/*     */     throws IOException, ClassNotFoundException, SecurityException, NoSuchMethodException, InvocationTargetException, IllegalArgumentException, IllegalAccessException, InstantiationException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, IllegalStateException
/*     */   {
/* 123 */     SecureRandom sr = new SecureRandom();
/*     */ 
/* 126 */     byte[] rawKeyData = Util.readFile("../webapps/ROOT/WEB-INF/conf/DES.properties");
/*     */     Class classkeyspec;
/*     */     Class classkeyspec;
/* 132 */     if (algorithm.equals("DES"))
/*     */     {
/* 134 */       classkeyspec = Class.forName("javax.crypto.spec.DESKeySpec");
/*     */     }
/*     */     else
/*     */     {
/*     */       Class classkeyspec;
/* 136 */       if (algorithm.equals("PBE"))
/*     */       {
/* 138 */         classkeyspec = Class.forName("javax.crypto.spec.PBEKeySpec");
/*     */       }
/* 140 */       else classkeyspec = Class.forName("javax.crypto.spec.DESKeySpec");
/*     */     }
/*     */ 
/* 143 */     Constructor constructor = classkeyspec.getConstructor(new Class[] { [B.class });
/* 144 */     KeySpec dks = (KeySpec)constructor.newInstance(new Object[] { rawKeyData });
/*     */ 
/* 146 */     SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algorithm);
/* 147 */     SecretKey key = keyFactory.generateSecret(dks);
/*     */ 
/* 149 */     Cipher cipher = Cipher.getInstance(algorithm);
/*     */ 
/* 151 */     cipher.init(1, key, sr);
/*     */ 
/* 153 */     bytes = cipher.doFinal(bytes);
/*     */ 
/* 155 */     return bytes;
/*     */   }
/*     */ 
/*     */   public void setKeyFile(String keyfile)
/*     */   {
/* 163 */     this.keyfile = keyfile;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.des.EncryptData
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.foura.des;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ 
/*     */ public class EncryptInterface
/*     */ {
/*     */   public static String desEncryptData(String str)
/*     */   {
/*  20 */     EncryptData ed = new EncryptData();
/*  21 */     StringBuffer sb = new StringBuffer();
/*     */ 
/*  23 */     String result = "";
/*  24 */     byte[] date_byte = str.getBytes();
/*     */     try {
/*  26 */       byte[] bss = ed.createEncryptData(date_byte, "DES");
/*     */ 
/*  28 */       System.out.println("bss.length = " + bss.length);
/*  29 */       sb.append(bss.length + "|");
/*     */ 
/*  31 */       for (int i = 0; i < bss.length; i++) {
/*  32 */         sb.append(bss[i] + "|");
/*     */       }
/*  34 */       result = sb.toString();
/*  35 */       result = result.substring(0, result.length() - 1);
/*     */     }
/*     */     catch (InvalidKeyException e)
/*     */     {
/*  39 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalStateException e) {
/*  42 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalBlockSizeException e) {
/*  45 */       e.printStackTrace();
/*     */     }
/*     */     catch (BadPaddingException e) {
/*  48 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchPaddingException e) {
/*  51 */       e.printStackTrace();
/*     */     }
/*     */     catch (InvalidKeySpecException e) {
/*  54 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchAlgorithmException e) {
/*  57 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/*  60 */       e.printStackTrace();
/*     */     }
/*     */     catch (SecurityException e) {
/*  63 */       e.printStackTrace();
/*     */     }
/*     */     catch (InstantiationException e) {
/*  66 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalAccessException e) {
/*  69 */       e.printStackTrace();
/*     */     }
/*     */     catch (InvocationTargetException e) {
/*  72 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchMethodException e) {
/*  75 */       e.printStackTrace();
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/*  78 */       e.printStackTrace();
/*     */     }
/*     */     catch (IOException e) {
/*  81 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  84 */     return result;
/*     */   }
/*     */ 
/*     */   public static String desUnEncryptData(String str)
/*     */   {
/*  90 */     UnEncryptData ud = new UnEncryptData();
/*  91 */     String ss = "";
/*     */     try
/*     */     {
/*  95 */       int byte_i = Integer.parseInt(str.substring(0, str.indexOf("|")));
/*  96 */       byte[] date_byte = new byte[byte_i];
/*  97 */       str = str.substring(str.indexOf("|") + 1);
/*  98 */       StringTokenizer st = new StringTokenizer(str, "|");
/*     */ 
/* 100 */       int i = 0;
/*     */ 
/* 102 */       while (st.hasMoreTokens()) {
/* 103 */         byte_i = Integer.parseInt(st.nextToken());
/*     */ 
/* 105 */         date_byte[i] = ((byte)byte_i);
/* 106 */         i++;
/*     */       }
/*     */ 
/* 109 */       byte[] bss = ud.createUnEncryptData(date_byte, "DES");
/* 110 */       ss = new String(bss);
/*     */     }
/*     */     catch (Exception e) {
/* 113 */       e.printStackTrace();
/*     */     }
/* 115 */     return ss;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.des.EncryptInterface
 * JD-Core Version:    0.6.2
 */
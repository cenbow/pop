/*    */ package com.asiainfo.biframe.privilege.foura.des;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class FinalValue
/*    */ {
/* 17 */   private static Locale locale = Locale.CHINA;
/*    */ 
/* 19 */   public static final String DELETE_ERROR = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteError") + "";
/*    */   public static final String ALGORITHM_DES = "DES";
/*    */   public static final String ALGORITHM_DES_CLASS = "javax.crypto.spec.DESKeySpec";
/*    */   public static final String ALGORITHM_PBE = "PBE";
/*    */   public static final String ALGORITHM_PBE_CLASS = "javax.crypto.spec.PBEKeySpec";
/*    */   public static final String KEY_FILE_NAME = "../webapps/ROOT/WEB-INF/conf/DES.properties";
/*    */   public static final String ADD = "add";
/*    */   public static final String CHANGE = "change";
/*    */   public static final String DELETE = "delete";
/*    */   public static final String ORACLEID = "10110";
/*    */   public static final String HOSTLOGID = "10370";
/*    */   public static final String DBLOGID = "10371";
/*    */   public static final String APPKINDID = "1";
/*    */   public static final String HOSTKINDID = "2";
/*    */   public static final String DBKINDID = "3";
/*    */   public static final String NETKINDID = "4";
/*    */   public static final String COMMONUSEID = "1";
/*    */   public static final String AUTHOROTHERID = "2";
/*    */   public static final String AUTHORSELFID = "3";
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.des.FinalValue
 * JD-Core Version:    0.6.2
 */
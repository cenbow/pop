/*     */ package com.asiainfo.biframe.privilege.foura.des;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ public class Util
/*     */ {
/*  17 */   private static ResourceBundle resources = null;
/*     */ 
/*     */   public static byte[] readFile(String filename)
/*     */     throws IOException
/*     */   {
/*  40 */     File file = new File(filename);
/*  41 */     if ((filename == null) || (filename.equals("")))
/*     */     {
/*  43 */       throw new NullPointerException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invalidFilePath") + "");
/*     */     }
/*  45 */     long len = file.length();
/*  46 */     byte[] bytes = new byte[(int)len];
/*     */ 
/*  48 */     System.out.println(file.getAbsolutePath());
/*  49 */     System.out.println(file.getCanonicalPath());
/*     */ 
/*  51 */     BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
/*  52 */     int r = bufferedInputStream.read(bytes);
/*  53 */     if (r != len)
/*  54 */       throw new IOException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.readFileError") + "");
/*  55 */     bufferedInputStream.close();
/*     */ 
/*  57 */     return bytes;
/*     */   }
/*     */ 
/*     */   public static void writeFile(byte[] data, String filename)
/*     */     throws IOException
/*     */   {
/*  67 */     File file = new File(filename);
/*  68 */     file.getParentFile().mkdirs();
/*  69 */     BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(file));
/*  70 */     bufferedOutputStream.write(data);
/*  71 */     bufferedOutputStream.close();
/*     */   }
/*     */ 
/*     */   public byte[] readFileJar(String filename)
/*     */     throws IOException
/*     */   {
/*  82 */     BufferedInputStream bufferedInputStream = new BufferedInputStream(getClass().getResource(filename).openStream());
/*  83 */     int len = bufferedInputStream.available();
/*  84 */     byte[] bytes = new byte[len];
/*  85 */     int r = bufferedInputStream.read(bytes);
/*  86 */     if (len != r)
/*     */     {
/*  88 */       bytes = null;
/*  89 */       throw new IOException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.readFileError") + "");
/*     */     }
/*  91 */     bufferedInputStream.close();
/*  92 */     return bytes;
/*     */   }
/*     */ 
/*     */   public static String getAlgorithm()
/*     */   {
/* 102 */     return "DES";
/*     */   }
/*     */ 
/*     */   public static String getValue(String skey)
/*     */   {
/* 111 */     return resources.getString(skey);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  22 */     new Util();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.des.Util
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.foura.des;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class test
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 15 */     EncryptInterface ei = new EncryptInterface();
/* 16 */     String ss = "o9i";
/* 17 */     UnEncryptData ud = new UnEncryptData();
/* 18 */     String encrypt_str = "";
/*    */     try
/*    */     {
/* 22 */       String str = EncryptInterface.desEncryptData(ss);
/* 23 */       System.err.println(str);
/*    */ 
/* 26 */       str = EncryptInterface.desUnEncryptData(str);
/* 27 */       System.out.println("DES = " + str);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 31 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.des.test
 * JD-Core Version:    0.6.2
 */
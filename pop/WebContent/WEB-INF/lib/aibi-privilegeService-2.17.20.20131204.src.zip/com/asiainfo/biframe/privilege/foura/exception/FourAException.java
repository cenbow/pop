/*    */ package com.asiainfo.biframe.privilege.foura.exception;
/*    */ 
/*    */ public class FourAException extends Exception
/*    */ {
/*    */   public FourAException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FourAException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */ 
/*    */   public FourAException(Throwable cause)
/*    */   {
/* 34 */     super(cause);
/*    */   }
/*    */ 
/*    */   public FourAException(String message, Throwable cause)
/*    */   {
/* 43 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.exception.FourAException
 * JD-Core Version:    0.6.2
 */
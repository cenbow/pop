/*    */ package com.asiainfo.biframe.privilege.foura.util;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ConfigureProperties
/*    */ {
/*    */   private String serverIpAndPort;
/*    */   private Map<String, String> propertiesMap;
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getServerIpAndPort()
/*    */   {
/* 29 */     return this.serverIpAndPort;
/*    */   }
/*    */ 
/*    */   public void setServerIpAndPort(String serverIpAndPort) {
/* 33 */     this.serverIpAndPort = serverIpAndPort;
/*    */   }
/*    */ 
/*    */   public void setPropertiesMap(Map<String, String> propertiesMap)
/*    */   {
/* 41 */     this.propertiesMap = propertiesMap;
/*    */   }
/*    */ 
/*    */   public String getProperties(String key)
/*    */   {
/* 50 */     String res = null;
/* 51 */     if (this.propertiesMap != null)
/* 52 */       res = (String)this.propertiesMap.get(key);
/* 53 */     return res;
/*    */   }
/*    */ 
/*    */   public void registerProperty(String key, String value)
/*    */   {
/* 62 */     if (this.propertiesMap == null)
/* 63 */       this.propertiesMap = new HashMap();
/* 64 */     this.propertiesMap.put(key, value);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.util.ConfigureProperties
 * JD-Core Version:    0.6.2
 */
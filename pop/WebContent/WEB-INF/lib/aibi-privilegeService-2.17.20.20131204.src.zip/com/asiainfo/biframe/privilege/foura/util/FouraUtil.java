/*    */ package com.asiainfo.biframe.privilege.foura.util;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class FouraUtil
/*    */ {
/*    */   public static Map getLogSessionInfoMap(String operatorId)
/*    */     throws Exception
/*    */   {
/* 30 */     Map map = new HashMap();
/*    */ 
/* 32 */     map.put("operatorId", operatorId);
/* 33 */     ConfigureProperties configure = (ConfigureProperties)SystemServiceLocator.getInstance().getService("right_configureProperties");
/*    */ 
/* 38 */     String operatorName = UserCache.getInstance().getNameByKey(operatorId);
/* 39 */     if ((null == operatorName) || (operatorName.length() < 1))
/* 40 */       operatorName = operatorId;
/* 41 */     map.put("operatorName", operatorName);
/*    */ 
/* 43 */     map.put("sessionId", String.valueOf(System.currentTimeMillis()));
/* 44 */     String hostAddress = Configure.getInstance().getProperty("HOST_ADDRESS");
/* 45 */     map.put("hostAddress", hostAddress);
/*    */ 
/* 47 */     return map;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.util.FouraUtil
 * JD-Core Version:    0.6.2
 */
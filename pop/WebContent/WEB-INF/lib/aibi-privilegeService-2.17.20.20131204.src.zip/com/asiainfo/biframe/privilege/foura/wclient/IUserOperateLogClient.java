package com.asiainfo.biframe.privilege.foura.wclient;

import com.asiainfo.biframe.log.LogInfo;

public abstract interface IUserOperateLogClient
{
  public abstract void userOperateLog(LogInfo paramLogInfo);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wclient.IUserOperateLogClient
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.foura.wclient.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.log.LogInfo;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.foura.util.ConfigureProperties;
/*     */ import com.asiainfo.biframe.privilege.foura.wclient.IUserOperateLogClient;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserOperateLogClientImpl
/*     */   implements IUserOperateLogClient
/*     */ {
/*     */   private ConfigureProperties configureProperties;
/*  33 */   private Log log = LogFactory.getLog(UserOperateLogClientImpl.class);
/*     */ 
/*     */   public void userOperateLog(LogInfo logInfo)
/*     */   {
/*     */   }
/*     */ 
/*     */   private String get4ATypeID(String resourceType, String operatorType)
/*     */   {
/*  91 */     String res = "";
/*  92 */     if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_LOGONFAILURE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_LOGON"))))
/*     */     {
/*  94 */       res = "BI20011";
/*     */     }
/*  96 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERLOGIN"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_LOGON"))))
/*     */     {
/*  98 */       res = "BI20010";
/*     */     }
/* 100 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 102 */       res = "BI20040";
/*     */     }
/* 104 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 106 */       res = "BI20041";
/*     */     }
/* 108 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 110 */       res = "BI20042";
/*     */     }
/* 112 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 114 */       res = "BI20043";
/*     */     }
/* 116 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 118 */       res = "BI20044";
/*     */     }
/* 120 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 122 */       res = "BI20045";
/*     */     }
/* 124 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 126 */       res = "BI20047";
/*     */     }
/* 128 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 130 */       res = "BI20048";
/*     */     }
/* 132 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 134 */       res = "BI20049";
/*     */     }
/* 136 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_DUTY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 138 */       res = "BI20032";
/*     */     }
/* 140 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_DUTY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 142 */       res = "BI20031";
/*     */     }
/* 144 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_DUTY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 146 */       res = "BI20030";
/*     */     }
/* 148 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_FIRSTPAGE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 150 */       res = "BI20022";
/*     */     }
/* 152 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_FIRSTPAGE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 154 */       res = "BI20020";
/*     */     }
/* 156 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_FIRSTPAGE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 158 */       res = "BI20021";
/*     */     }
/* 160 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 162 */       res = "BI20050";
/*     */     }
/* 164 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERLOGIN"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_SENDPWD"))))
/*     */     {
/* 166 */       res = "BI20012";
/*     */     }
/* 168 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER_EXT"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 170 */       res = "BI20046";
/*     */     }
/* 172 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER_EXT"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 174 */       res = "BI20046";
/*     */     }
/* 176 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER_EXT"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 178 */       res = "BI20046";
/*     */     }
/* 180 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_BALANCE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 182 */       res = "BI20053";
/*     */     }
/* 184 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_BALANCE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 186 */       res = "BI20051";
/*     */     }
/* 188 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_BALANCE"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 190 */       res = "BI20052";
/*     */     }
/* 192 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGEKPI"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 194 */       res = "BI20054";
/*     */     }
/* 196 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGEKPI"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 198 */       res = "BI20055";
/*     */     }
/* 200 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGEKPI"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 202 */       res = "BI20056";
/*     */     }
/* 204 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGEKPILIMIT"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 206 */       res = "BI20057";
/*     */     }
/* 208 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGEKPILIMIT"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 210 */       res = "BI20058";
/*     */     }
/* 212 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGEKPILIMIT"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 214 */       res = "BI20059";
/*     */     }
/* 216 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGEKPIMISSION"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 218 */       res = "BI20060";
/*     */     }
/* 220 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGEKPIMISSION"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 222 */       res = "BI20061";
/*     */     }
/* 224 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGEKPIMISSION"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 226 */       res = "BI20062";
/*     */     }
/* 228 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ENTMANAGER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 230 */       res = "BI20063";
/*     */     }
/* 232 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ENTMANAGER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 234 */       res = "BI20064";
/*     */     }
/* 236 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ENTMANAGER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 238 */       res = "BI20065";
/*     */     }
/* 240 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_VIPMANAGER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 242 */       res = "BI20066";
/*     */     }
/* 244 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_VIPMANAGER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 246 */       res = "BI20067";
/*     */     }
/* 248 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_VIPMANAGER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 250 */       res = "BI20068";
/*     */     }
/* 252 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_UNLOCKUSER"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UNLOCK"))))
/*     */     {
/* 254 */       res = "BI20069";
/*     */     }
/* 256 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_NEWS"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 258 */       res = "BI20070";
/*     */     }
/* 260 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_NEWS"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 262 */       res = "BI20071";
/*     */     }
/* 264 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_NEWS"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 266 */       res = "BI20072";
/*     */     }
/* 268 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_CLIENTPOLICY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 270 */       res = "BI20073";
/*     */     }
/* 272 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_CLIENTPOLICY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 274 */       res = "BI20074";
/*     */     }
/* 276 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_CLIENTPOLICY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 278 */       res = "BI20075";
/*     */     }
/* 280 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGECONPANY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 282 */       res = "BI20076";
/*     */     }
/* 284 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGECONPANY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 286 */       res = "BI20077";
/*     */     }
/* 288 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGECONPANY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 290 */       res = "BI20078";
/*     */     }
/* 292 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_PASSWDPOLICY"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 294 */       res = "BI20079";
/*     */     }
/* 296 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MENUMAINTAIN"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"))))
/*     */     {
/* 298 */       res = "BI20080";
/*     */     }
/* 300 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MENUMAINTAIN"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"))))
/*     */     {
/* 302 */       res = "BI20081";
/*     */     }
/* 304 */     else if ((resourceType.equals(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MENUMAINTAIN"))) && (operatorType.equals(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"))))
/*     */     {
/* 306 */       res = "BI20082";
/*     */     }
/*     */ 
/* 311 */     return res;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 318 */     UserOperateLogClientImpl client = new UserOperateLogClientImpl();
/* 319 */     ConfigureProperties properties = new ConfigureProperties();
/* 320 */     properties.setServerIpAndPort("10.1.22.141:8088");
/* 321 */     client.setConfigureProperties(properties);
/*     */ 
/* 323 */     LogInfo logInfo = new LogInfo();
/* 324 */     LogInfo.setClientAddress("10.1.1.2");
/* 325 */     LogInfo.setHostAddress("10.1.1.1");
/* 326 */     logInfo.setMsg(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userLocked"));
/* 327 */     LogInfo.setOperatorID("admin");
/* 328 */     logInfo.setResourceType("3");
/*     */ 
/* 330 */     client.userOperateLog(logInfo);
/*     */   }
/*     */ 
/*     */   public ConfigureProperties getConfigureProperties() {
/* 334 */     return this.configureProperties;
/*     */   }
/*     */ 
/*     */   public void setConfigureProperties(ConfigureProperties configureProperties) {
/* 338 */     this.configureProperties = configureProperties;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wclient.impl.UserOperateLogClientImpl
 * JD-Core Version:    0.6.2
 */
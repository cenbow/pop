package com.asiainfo.biframe.privilege.foura.wservice;

import javax.jws.WebService;

@WebService
public abstract interface IUserAccQuery
{
  public abstract String QueryAppAcctSoap(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wservice.IUserAccQuery
 * JD-Core Version:    0.6.2
 */
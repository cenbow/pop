package com.asiainfo.biframe.privilege.foura.wservice;

import javax.jws.WebService;

@WebService
public abstract interface IUserGroupChgService
{
  public abstract String UpdateAppRoleSoap(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wservice.IUserGroupChgService
 * JD-Core Version:    0.6.2
 */
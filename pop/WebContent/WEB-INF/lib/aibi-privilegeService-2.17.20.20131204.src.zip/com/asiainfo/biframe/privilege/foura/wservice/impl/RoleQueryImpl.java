/*     */ package com.asiainfo.biframe.privilege.foura.wservice.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.foura.wservice.IRoleQuery;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ public class RoleQueryImpl
/*     */   implements IRoleQuery
/*     */ {
/*     */   public String QueryAppRoleSoap(String requestInfo)
/*     */     throws Exception
/*     */   {
/*  23 */     String ResponseInfo = "";
/*  24 */     String reqMode = "";
/*  25 */     String roleId = "";
/*     */     try {
/*  27 */       Map xmlMap = parseXml(requestInfo);
/*  28 */       if (null != xmlMap.get("ERROR")) {
/*  29 */         return (String)xmlMap.get("ERROR");
/*     */       }
/*     */ 
/*  32 */       roleId = (String)xmlMap.get("ROLEID");
/*  33 */       reqMode = (String)xmlMap.get("REQMODE");
/*  34 */       IUserGroupAdminService userGroupService = (IUserGroupAdminService)SystemServiceLocator.getInstance().getService("right_userGroupAdminService");
/*  35 */       if (reqMode.equals("batch")) {
/*  36 */         List list = userGroupService.getAllSubGroup("1");
/*  37 */         list.add(userGroupService.getUserGroup("1"));
/*  38 */         if ((list == null) || (list.size() == 0))
/*     */         {
/*  40 */           return genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appHasNoRole") + "");
/*     */         }
/*     */ 
/*  43 */         StringBuffer returnInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<ROLERSP>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD><BODY><ROLELIST>");
/*     */ 
/*  49 */         for (int i = 0; i < list.size(); i++) {
/*  50 */           User_Group ug = new User_Group();
/*  51 */           ug = (User_Group)list.get(i);
/*  52 */           returnInfo.append("<ROLEINFO><ROLEID>" + ug.getGroupid() + "</ROLEID>" + "<FLAG></FLAG>" + "<ROLENAME>" + ug.getGroupname() + "</ROLENAME>" + "<ROLEDESC></ROLEDESC>" + "<PARENTROLEID>" + ug.getParentid() + "</PARENTROLEID>" + "</ROLEINFO>");
/*     */         }
/*     */ 
/*  59 */         returnInfo.append("</ROLELIST></BODY></ROLERSP>");
/*  60 */         ResponseInfo = returnInfo.toString();
/*     */       }
/*  63 */       else if (reqMode.equals("single")) {
/*  64 */         User_Group ug = userGroupService.getUserGroup(roleId);
/*  65 */         if (ug == null) {
/*  66 */           return genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appHasNoRole") + "");
/*     */         }
/*     */ 
/*  69 */         StringBuffer returnInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<ROLERSP>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD><BODY><ROLELIST>");
/*     */ 
/*  75 */         returnInfo.append("<ROLEINFO><ROLEID>" + ug.getGroupid() + "</ROLEID>" + "<FLAG></FLAG>" + "<ROLENAME>" + ug.getGroupname() + "</ROLENAME>" + "<ROLEDESC></ROLEDESC>" + "<PARENTROLEID>" + ug.getParentid() + "</PARENTROLEID>" + "</ROLEINFO>");
/*     */ 
/*  81 */         returnInfo.append("</ROLELIST></BODY></ROLERSP>");
/*  82 */         ResponseInfo = returnInfo.toString();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  87 */       e.printStackTrace();
/*     */     }
/*  89 */     return ResponseInfo;
/*     */   }
/*     */ 
/*     */   private Map parseXml(String requestInfo) {
/*  93 */     Map resultMap = new HashMap();
/*     */     try
/*     */     {
/*  96 */       SAXBuilder builder = new SAXBuilder(false);
/*  97 */       ByteArrayInputStream is = new ByteArrayInputStream(requestInfo.getBytes());
/*     */ 
/* 100 */       Document doc = builder.build(is);
/* 101 */       Element body = doc.getRootElement();
/*     */ 
/* 103 */       List body_list = body.getChildren("BODY");
/* 104 */       Element e2 = (Element)body_list.get(0);
/* 105 */       String operId = e2.getChildText("OPERATORID");
/* 106 */       String roleId = e2.getChildText("ROLEID");
/* 107 */       String reqMode = e2.getChildText("REQMODE");
/*     */ 
/* 109 */       resultMap.put("OPERATORID", operId);
/* 110 */       resultMap.put("ROLEID", roleId);
/* 111 */       resultMap.put("REQMODE", reqMode);
/*     */     }
/*     */     catch (JDOMException e)
/*     */     {
/* 116 */       e.printStackTrace();
/*     */ 
/* 119 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 120 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 124 */       e.printStackTrace();
/*     */ 
/* 126 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 127 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */ 
/* 130 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private String genErrorMsg(String key, String errCode, String errDesc) {
/* 134 */     if ((null == key) || (key.length() < 1)) {
/* 135 */       key = "ERROR";
/*     */     }
/* 137 */     if ((null == errCode) || (errCode.length() < 1)) {
/* 138 */       errCode = "errorcode";
/*     */     }
/* 140 */     if ((null == errDesc) || (errDesc.length() < 1)) {
/* 141 */       errDesc = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeError") + "";
/*     */     }
/*     */ 
/* 144 */     StringBuffer errorInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERREQ>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><KEY>" + key + "</KEY>").append("<ERRCODE>" + errCode + "</ERRCODE>").append("<ERRDES>" + errDesc + "</ERRDES>").append("</BODY></USERREQ>");
/*     */ 
/* 156 */     return errorInfo.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wservice.impl.RoleQueryImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.foura.wservice.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.log.LogInfo;
/*     */ import com.asiainfo.biframe.privilege.foura.des.EncryptInterface;
/*     */ import com.asiainfo.biframe.privilege.foura.util.ConfigureProperties;
/*     */ import com.asiainfo.biframe.privilege.foura.util.FouraUtil;
/*     */ import com.asiainfo.biframe.privilege.foura.wservice.IUserAccManage;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import com.asiainfo.biframe.utils.string.DES;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ public class UserAccManageImpl
/*     */   implements IUserAccManage
/*     */ {
/*     */   private ConfigureProperties configureProperties;
/*  29 */   private Log log = LogFactory.getLog(UserAccManageImpl.class);
/*     */ 
/*     */   public String UpdateAppAcctSoap(String requestInfo) throws Exception
/*     */   {
/*  33 */     String ResponseInfo = "";
/*  34 */     String modifyMode = "";
/*  35 */     String userId = "";
/*  36 */     String userName = "";
/*  37 */     String pwd = "";
/*  38 */     String userDesc = "";
/*  39 */     IUserAdminService userService = (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/*  40 */     User_User user = new User_User();
/*     */     try {
/*  42 */       Map xmlMap = parseXml(requestInfo);
/*  43 */       if (null != xmlMap.get("ERROR")) {
/*  44 */         return (String)xmlMap.get("ERROR");
/*     */       }
/*     */ 
/*  47 */       userId = (String)xmlMap.get("USERID");
/*  48 */       modifyMode = (String)xmlMap.get("MODIFYMODE");
/*  49 */       userName = (String)xmlMap.get("USERNAME");
/*  50 */       pwd = (String)xmlMap.get("USERPWD");
/*  51 */       userDesc = (String)xmlMap.get("USERDESC");
/*     */ 
/*  53 */       String operatorId = (String)xmlMap.get("OPERATORID");
/*  54 */       LogInfo.setSessionInfoMap(FouraUtil.getLogSessionInfoMap(operatorId));
/*     */ 
/*  56 */       if (modifyMode.equals("delete")) {
/*  57 */         if (userId == null) {
/*  58 */           return genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.notInputUserId") + "");
/*     */         }
/*     */ 
/*  61 */         user = userService.getUser(userId);
/*     */ 
/*  63 */         if (user == null) {
/*  64 */           return genSuccessMsg(modifyMode, userId, "1");
/*     */         }
/*     */ 
/*  68 */         userService.deleteUser(user);
/*  69 */         ResponseInfo = genSuccessMsg(modifyMode, userId, "0");
/*     */       }
/*  72 */       else if (modifyMode.equals("change")) {
/*  73 */         if (userId == null) {
/*  74 */           return genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.notInputUserId") + "");
/*     */         }
/*     */ 
/*  78 */         user = userService.getUser(userId);
/*  79 */         if (user == null) {
/*  80 */           return genSuccessMsg(modifyMode, userId, "1");
/*     */         }
/*     */ 
/*  83 */         user.setUsername(userName);
/*  84 */         user.setDesPwd(pwd);
/*  85 */         user.setPwd(DES.encrypt(user.getDesPwd()));
/*  86 */         userService.updateUser(user);
/*  87 */         ResponseInfo = genSuccessMsg(modifyMode, userId, "0");
/*     */       }
/*  90 */       else if (modifyMode.equals("add")) {
/*  91 */         boolean isExist = userService.isUserExists(userId, userName, true);
/*  92 */         if (isExist) {
/*  93 */           return genSuccessMsg(modifyMode, userId, "1");
/*     */         }
/*     */ 
/*  96 */         user.setUserid(userId);
/*  97 */         user.setUserid(userId);
/*  98 */         user.setUsername(userName);
/*  99 */         user.setDesPwd(pwd);
/* 100 */         user.setPwd(DES.encrypt(user.getDesPwd()));
/* 101 */         user.setGroupId("0");
/* 102 */         user.setCityid("999");
/* 103 */         user.setStatus(0);
/* 104 */         user.setCreatetime(new Date());
/* 105 */         userService.addUser(user);
/* 106 */         ResponseInfo = genSuccessMsg(modifyMode, userId, "0");
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 111 */       e.printStackTrace();
/*     */     }
/* 113 */     return ResponseInfo;
/*     */   }
/*     */ 
/*     */   private Map parseXml(String requestInfo)
/*     */   {
/* 119 */     Map resultMap = new HashMap();
/*     */     try
/*     */     {
/* 122 */       SAXBuilder builder = new SAXBuilder(false);
/* 123 */       ByteArrayInputStream is = new ByteArrayInputStream(requestInfo.getBytes());
/*     */ 
/* 126 */       Document doc = builder.build(is);
/* 127 */       Element body = doc.getRootElement();
/* 128 */       List body_list = body.getChildren("BODY");
/* 129 */       Element e2 = (Element)body_list.get(0);
/* 130 */       String operId = e2.getChildText("OPERATORID");
/* 131 */       String userId = e2.getChildText("USERID");
/* 132 */       String modifyMode = e2.getChildText("MODIFYMODE");
/*     */ 
/* 134 */       List userInfo = e2.getChildren("USERINFO");
/* 135 */       Element e3 = (Element)userInfo.get(0);
/* 136 */       String userName = e3.getChildText("USERNAME");
/* 137 */       String userPwd = e3.getChildText("USERPWD");
/* 138 */       String userDesc = e3.getChildText("USERDESC");
/*     */ 
/* 141 */       if (null != userPwd) {
/* 142 */         EncryptInterface ei = new EncryptInterface();
/* 143 */         String encrypt_str = userPwd;
/*     */         try {
/* 145 */           userPwd = EncryptInterface.desUnEncryptData(encrypt_str);
/* 146 */           System.out.println("DES = " + userPwd);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 150 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */ 
/* 154 */       resultMap.put("OPERATORID", operId);
/* 155 */       resultMap.put("USERID", userId);
/* 156 */       resultMap.put("MODIFYMODE", modifyMode);
/* 157 */       resultMap.put("USERNAME", userName);
/* 158 */       resultMap.put("USERPWD", userPwd);
/* 159 */       resultMap.put("USERDESC", userDesc);
/*     */     }
/*     */     catch (JDOMException e)
/*     */     {
/* 164 */       e.printStackTrace();
/*     */ 
/* 167 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 168 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 172 */       e.printStackTrace();
/*     */ 
/* 174 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 175 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */ 
/* 178 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private String genErrorMsg(String key, String errCode, String errDesc) {
/* 182 */     if ((null == key) || (key.length() < 1)) {
/* 183 */       key = "ERROR";
/*     */     }
/* 185 */     if ((null == errCode) || (errCode.length() < 1)) {
/* 186 */       errCode = "errorcode";
/*     */     }
/* 188 */     if ((null == errDesc) || (errDesc.length() < 1)) {
/* 189 */       errDesc = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeError") + "";
/*     */     }
/*     */ 
/* 192 */     StringBuffer errorInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERREQ>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><KEY>" + key + "</KEY>").append("<ERRCODE>" + errCode + "</ERRCODE>").append("<ERRDES>" + errDesc + "</ERRDES>").append("</BODY></USERREQ>");
/*     */ 
/* 204 */     return errorInfo.toString();
/*     */   }
/*     */ 
/*     */   private String genSuccessMsg(String modifyMode, String userId, String rsp) {
/* 208 */     StringBuffer successInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERMODIFYRSP>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><MODIFYMODE>" + modifyMode + "</MODIFYMODE>").append("<USERID>" + userId + "</USERID>").append("<RSP>" + rsp + "</RSP>").append("</BODY></USERMODIFYRSP >");
/*     */ 
/* 220 */     return successInfo.toString();
/*     */   }
/*     */ 
/*     */   public ConfigureProperties getConfigureProperties() {
/* 224 */     return this.configureProperties;
/*     */   }
/*     */ 
/*     */   public void setConfigureProperties(ConfigureProperties configureProperties) {
/* 228 */     this.configureProperties = configureProperties;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wservice.impl.UserAccManageImpl
 * JD-Core Version:    0.6.2
 */
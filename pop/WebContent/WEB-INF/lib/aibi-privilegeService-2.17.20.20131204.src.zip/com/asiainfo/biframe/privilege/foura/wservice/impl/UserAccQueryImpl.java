/*     */ package com.asiainfo.biframe.privilege.foura.wservice.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.foura.wservice.IUserAccQuery;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ public class UserAccQueryImpl
/*     */   implements IUserAccQuery
/*     */ {
/*  25 */   private Log log = LogFactory.getLog(UserAccQueryImpl.class);
/*     */ 
/*     */   private IUserAdminService getUserAdminService() {
/*     */     try { return (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/*     */     } catch (Exception e) {
/*  30 */       this.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*  31 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private IUserGroupAdminService getUserGroupAdminService() {
/*     */     try { return (IUserGroupAdminService)SystemServiceLocator.getInstance().getService("right_userGroupAdminService");
/*     */     } catch (Exception e) {
/*  38 */       this.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*  39 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String QueryAppAcctSoap(String requestInfo) throws Exception
/*     */   {
/*  45 */     List list = null;
/*  46 */     String ResponseInfo = "";
/*  47 */     String reqMode = "";
/*  48 */     String userId = "";
/*     */     try {
/*  50 */       Map xmlMap = parseXml(requestInfo);
/*  51 */       if (null != xmlMap.get("ERROR")) {
/*  52 */         return (String)xmlMap.get("ERROR");
/*     */       }
/*     */ 
/*  55 */       userId = (String)xmlMap.get("USERID");
/*  56 */       reqMode = (String)xmlMap.get("REQMODE");
/*  57 */       IUserAdminService userService = getUserAdminService();
/*  58 */       if (reqMode.equals("batch")) {
/*  59 */         list = getUserGroupAdminService().getAllSubUsersByGroupId("1");
/*  60 */         if ((list == null) || (list.size() == 0))
/*     */         {
/*  62 */           return genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appHasNoUserId") + "");
/*     */         }
/*     */ 
/*  65 */         StringBuffer returnInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERRSP>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD><BODY><USERLIST>");
/*     */ 
/*  71 */         for (int i = 0; i < list.size(); i++) {
/*  72 */           User_User user = (User_User)list.get(i);
/*     */ 
/*  74 */           returnInfo.append("<USERINFO><USERID>" + user.getUserid() + "</USERID>" + "<FLAG>1</FLAG>" + "<USERNAME>" + user.getUsername() + "</USERNAME>" + "<DEPART>" + user.getDepName() + "</DEPART>" + "<SEX></SEX>" + "<MOBILE>" + user.getMobilePhone() + "</MOBILE>" + "<TEL>" + user.getOfficephone() + "</TEL>" + "<MAIL>" + user.getEmail() + "</MAIL>" + "<ADDRESS>" + user.getCityid() + "</ADDRESS><POSTCODE></POSTCODE><AREA></AREA><NOTE></NOTE>");
/*     */ 
/*  86 */           returnInfo.append(getGroupInfo(user.getUserid()));
/*     */ 
/*  89 */           returnInfo.append("</USERINFO>");
/*     */         }
/*  91 */         returnInfo.append("</USERLIST></BODY></USERRSP>");
/*  92 */         ResponseInfo = returnInfo.toString();
/*  93 */       } else if (reqMode.equals("single")) {
/*  94 */         User_User user = userService.getUser(userId);
/*  95 */         if (user == null) {
/*  96 */           return genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userIdNotExist") + "");
/*     */         }
/*     */ 
/* 101 */         StringBuffer returnInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERRSP>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD><BODY><USERLIST>");
/*     */ 
/* 107 */         returnInfo.append("<USERINFO><USERID>" + user.getUserid() + "</USERID>" + "<FLAG>1</FLAG>" + "<USERNAME>" + user.getUsername() + "</USERNAME>" + "<DEPART>" + user.getDepName() + "</DEPART>" + "<SEX></SEX>" + "<MOBILE>" + user.getMobilePhone() + "</MOBILE>" + "<TEL>" + user.getOfficephone() + "</TEL>" + "<MAIL>" + user.getEmail() + "</MAIL>" + "<ADDRESS>" + user.getCityid() + "</ADDRESS><POSTCODE></POSTCODE><AREA></AREA><NOTE></NOTE>");
/*     */ 
/* 119 */         returnInfo.append(getGroupInfo(user.getUserid()));
/*     */ 
/* 122 */         returnInfo.append("</USERINFO>");
/* 123 */         returnInfo.append("</USERLIST></BODY></USERRSP>");
/* 124 */         ResponseInfo = returnInfo.toString();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 129 */       e.printStackTrace();
/* 130 */       ResponseInfo = genErrorMsg("", "", LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ":" + e.getMessage());
/*     */     }
/*     */ 
/* 133 */     return ResponseInfo;
/*     */   }
/*     */ 
/*     */   private String getGroupInfo(String userId)
/*     */     throws Exception
/*     */   {
/* 144 */     IUserAdminService userService = getUserAdminService();
/* 145 */     User_Group groupObj = userService.getGroupObject(userId);
/* 146 */     String groupId = "";
/* 147 */     String groupName = "";
/* 148 */     if (null != groupObj) {
/* 149 */       groupId = groupObj.getGroupid();
/* 150 */       groupName = groupObj.getGroupname();
/*     */     }
/*     */ 
/* 153 */     StringBuffer returnInfo = new StringBuffer(256);
/* 154 */     returnInfo.append("<RIGHTLIST><RIGHT>");
/* 155 */     returnInfo.append("<ID>").append(groupId).append("</ID>");
/* 156 */     returnInfo.append("<NAME>").append(groupName).append("</NAME>");
/* 157 */     returnInfo.append("<TYPE>role</TYPE>");
/* 158 */     returnInfo.append("</RIGHT></RIGHTLIST>");
/*     */ 
/* 160 */     return returnInfo.toString();
/*     */   }
/*     */   private Map parseXml(String requestInfo) {
/* 163 */     Map resultMap = new HashMap();
/*     */     try
/*     */     {
/* 166 */       SAXBuilder builder = new SAXBuilder(false);
/* 167 */       ByteArrayInputStream is = new ByteArrayInputStream(requestInfo.getBytes());
/*     */ 
/* 171 */       Document doc = builder.build(is);
/* 172 */       Element body = doc.getRootElement();
/*     */ 
/* 174 */       List body_list = body.getChildren("BODY");
/* 175 */       Element e2 = (Element)body_list.get(0);
/* 176 */       String operId = e2.getChildText("OPERATORID");
/* 177 */       String userId = e2.getChildText("USERID");
/* 178 */       String reqMode = e2.getChildText("REQMODE");
/*     */ 
/* 180 */       resultMap.put("OPERATORID", operId);
/* 181 */       resultMap.put("USERID", userId);
/* 182 */       resultMap.put("REQMODE", reqMode);
/*     */     }
/*     */     catch (JDOMException e)
/*     */     {
/* 187 */       e.printStackTrace();
/*     */ 
/* 190 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 191 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 195 */       e.printStackTrace();
/*     */ 
/* 197 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 198 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */ 
/* 201 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private String genErrorMsg(String key, String errCode, String errDesc) {
/* 205 */     if ((null == key) || (key.length() < 1)) {
/* 206 */       key = "ERROR";
/*     */     }
/* 208 */     if ((null == errCode) || (errCode.length() < 1)) {
/* 209 */       errCode = "errorcode";
/*     */     }
/* 211 */     if ((null == errDesc) || (errDesc.length() < 1)) {
/* 212 */       errDesc = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeError") + "";
/*     */     }
/*     */ 
/* 215 */     StringBuffer errorInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERREQ>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><KEY>" + key + "</KEY>").append("<ERRCODE>" + errCode + "</ERRCODE>").append("<ERRDES>" + errDesc + "</ERRDES>").append("</BODY></USERREQ>");
/*     */ 
/* 227 */     return errorInfo.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wservice.impl.UserAccQueryImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.foura.wservice.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.log.LogInfo;
/*     */ import com.asiainfo.biframe.privilege.foura.des.EncryptInterface;
/*     */ import com.asiainfo.biframe.privilege.foura.util.FouraUtil;
/*     */ import com.asiainfo.biframe.privilege.foura.wservice.IUserAcctPwdManage;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ public class UserAcctPwdManageImpl
/*     */   implements IUserAcctPwdManage
/*     */ {
/*  38 */   private Log log = LogFactory.getLog(UserAcctPwdManageImpl.class);
/*     */ 
/*     */   public String UpdateBatchAppAcctPwdSoap(String requestInfo)
/*     */     throws Exception
/*     */   {
/*  44 */     IUserAdminService userAdminService = (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/*     */     try
/*     */     {
/*  48 */       SAXBuilder builder = new SAXBuilder(false);
/*  49 */       ByteArrayInputStream is = new ByteArrayInputStream(requestInfo.getBytes());
/*     */ 
/*  51 */       Document doc = builder.build(is);
/*  52 */       Element body = doc.getRootElement();
/*  53 */       List body_list = body.getChildren("BODY");
/*  54 */       Element e2 = (Element)body_list.get(0);
/*  55 */       String modifyMode = e2.getChildText("MODIFYMODE");
/*  56 */       if (!"batchupdpwd".equalsIgnoreCase(modifyMode)) {
/*  57 */         this.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.propertyNotBatchupdpwd"));
/*  58 */         return genErrorMsg("", "", LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.propertyNotBatchupdpwd"));
/*     */       }
/*  60 */       String operId = e2.getChildText("OPERATORID");
/*  61 */       LogInfo.setSessionInfoMap(FouraUtil.getLogSessionInfoMap(operId));
/*     */ 
/*  63 */       Element userListEle = (Element)e2.getChildren("USERLIST").get(0);
/*  64 */       List userInfoList = userListEle.getChildren("USERINFO");
/*  65 */       for (Iterator iterator = userInfoList.iterator(); iterator.hasNext(); ) {
/*  66 */         Element userEle = (Element)iterator.next();
/*  67 */         String userId = userEle.getChildText("USERID");
/*  68 */         String userPwd = userEle.getChildText("USERPWD");
/*     */ 
/*  71 */         if (StringUtils.isNotBlank(userPwd)) {
/*  72 */           EncryptInterface ei = new EncryptInterface();
/*  73 */           String encrypt_str = userPwd;
/*  74 */           this.log.debug("--pwd1:" + encrypt_str);
/*  75 */           userPwd = EncryptInterface.desUnEncryptData(encrypt_str);
/*  76 */           this.log.debug("--pwd2:" + userPwd);
/*     */         }
/*  78 */         this.log.debug("--userId:" + userId + "--userPwd:" + userPwd);
/*     */ 
/*  80 */         User_User user = userAdminService.getUser(userId);
/*  81 */         if (user == null) {
/*  82 */           this.log.error("userId=[" + userId + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExist") + "");
/*  83 */           return genSuccessMsg("1");
/*     */         }
/*  85 */         user.setDesPwd(userPwd);
/*  86 */         userAdminService.updateUser(user);
/*     */       }
/*     */ 
/*  89 */       return genSuccessMsg("0");
/*     */     } catch (JDOMException e1) {
/*  91 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e1.getMessage());
/*  92 */       this.log.error(errorInfo, e1);
/*  93 */       return errorInfo;
/*     */     } catch (IOException e2) {
/*  95 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e2.getMessage());
/*  96 */       this.log.error(errorInfo, e2);
/*  97 */       return errorInfo;
/*     */     } catch (Exception e3) {
/*  99 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e3.getMessage());
/* 100 */       this.log.error(errorInfo, e3);
/* 101 */       return errorInfo;
/*     */     }
/*     */   }
/*     */ 
/*     */   private Map<String, String> parseXml(String requestInfo) {
/* 106 */     Map resultMap = new HashMap();
/*     */ 
/* 108 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private String genErrorMsg(String key, String errCode, String errDesc)
/*     */   {
/* 113 */     if ((null == key) || (key.length() < 1)) {
/* 114 */       key = "ERROR";
/*     */     }
/* 116 */     if ((null == errCode) || (errCode.length() < 1)) {
/* 117 */       errCode = "errorcode";
/*     */     }
/* 119 */     if ((null == errDesc) || (errDesc.length() < 1)) {
/* 120 */       errDesc = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeError") + "";
/*     */     }
/*     */ 
/* 123 */     StringBuffer errorInfo = new StringBuffer(256);
/* 124 */     errorInfo.append("<?xml version='1.0' encoding='GBK'?>");
/* 125 */     errorInfo.append("<USERREQ>");
/* 126 */     errorInfo.append("<HEAD>");
/* 127 */     errorInfo.append("<CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID>");
/* 128 */     errorInfo.append("</HEAD>");
/* 129 */     errorInfo.append("<BODY>");
/* 130 */     errorInfo.append("<KEY>").append(key).append("</KEY>");
/* 131 */     errorInfo.append("<ERRCODE>").append(errCode).append("</ERRCODE>");
/* 132 */     errorInfo.append("<ERRDES>").append(errDesc).append("</ERRDES>");
/* 133 */     errorInfo.append("</BODY>");
/* 134 */     errorInfo.append("</USERREQ>");
/*     */ 
/* 136 */     return errorInfo.toString();
/*     */   }
/*     */ 
/*     */   private String genSuccessMsg(String result)
/*     */   {
/* 145 */     StringBuffer successInfo = new StringBuffer(256);
/* 146 */     successInfo.append("<?xml version='1.0' encoding='GBK'?>");
/* 147 */     successInfo.append("<USERMODIFYRSP>");
/* 148 */     successInfo.append("<HEAD>");
/* 149 */     successInfo.append("<CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID>");
/* 150 */     successInfo.append("</HEAD>");
/* 151 */     successInfo.append("<BODY>");
/* 152 */     successInfo.append("<RESULT>").append(result).append("</RESULT>");
/* 153 */     successInfo.append("</BODY>");
/* 154 */     successInfo.append("</USERMODIFYRSP>");
/*     */ 
/* 156 */     return successInfo.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wservice.impl.UserAcctPwdManageImpl
 * JD-Core Version:    0.6.2
 */
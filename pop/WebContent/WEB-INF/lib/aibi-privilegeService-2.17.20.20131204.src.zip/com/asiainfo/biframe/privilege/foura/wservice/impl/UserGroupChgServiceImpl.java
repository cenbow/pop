/*     */ package com.asiainfo.biframe.privilege.foura.wservice.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.foura.wservice.IUserGroupChgService;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.impl.ListService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ public class UserGroupChgServiceImpl
/*     */   implements IUserGroupChgService
/*     */ {
/*     */   private IUserGroupAdminService userGroupAdminService;
/*     */ 
/*     */   public String UpdateAppRoleSoap(String requestInfo)
/*     */   {
/*  38 */     String chgMode = "add";
/*  39 */     String groupId = "";
/*  40 */     String groupName = "";
/*  41 */     String pid = "";
/*  42 */     String retFlag = "0";
/*  43 */     String ResponseInfo = "";
/*     */     try
/*     */     {
/*  46 */       Map xmlMap = parseXml(requestInfo);
/*  47 */       if (null != xmlMap.get("ERROR")) {
/*  48 */         return (String)xmlMap.get("ERROR");
/*     */       }
/*     */ 
/*  52 */       String operId = (String)xmlMap.get("OPERATORID");
/*     */ 
/*  54 */       chgMode = (String)xmlMap.get("MODIFYMODE");
/*  55 */       groupId = (String)xmlMap.get("ROLEID");
/*  56 */       groupName = (String)xmlMap.get("ROLENAME");
/*  57 */       pid = (String)xmlMap.get("PARENTROLEID");
/*  58 */       String desc = (String)xmlMap.get("ROLEDESC");
/*     */ 
/*  61 */       String msg = "";
/*     */ 
/*  63 */       if (chgMode.equalsIgnoreCase("add")) {
/*  64 */         User_Group userGroup = new User_Group();
/*  65 */         userGroup.setGroupid("");
/*  66 */         userGroup.setGroupname(groupName);
/*  67 */         userGroup.setParentid(pid);
/*  68 */         userGroup.setStatus(new Long(0L));
/*     */ 
/*  70 */         String ret = addUserGroup(userGroup);
/*  71 */         String flag = ret.substring(0, 1);
/*  72 */         msg = ret.substring(1);
/*  73 */         if (flag.equalsIgnoreCase("F"))
/*     */         {
/*  75 */           retFlag = "1";
/*  76 */         } else if (flag.equalsIgnoreCase("T"))
/*     */         {
/*  78 */           groupId = msg.substring(0, msg.indexOf("_"));
/*  79 */           msg = msg.substring(msg.indexOf("_") + 1);
/*  80 */           retFlag = "0";
/*     */         }
/*     */ 
/*     */       }
/*  85 */       else if (chgMode.equalsIgnoreCase("change")) {
/*  86 */         User_Group newGrp = new User_Group();
/*  87 */         newGrp.setGroupid(groupId);
/*  88 */         newGrp.setGroupname(groupName);
/*  89 */         newGrp.setParentid(pid);
/*     */ 
/*  91 */         User_Group oldGrp = this.userGroupAdminService.getUserGroup(groupId);
/*  92 */         String ret = changeUserGroup(newGrp, oldGrp);
/*  93 */         String flag = ret.substring(0, 1);
/*  94 */         msg = ret.substring(1);
/*     */ 
/*  96 */         retFlag = flag.equalsIgnoreCase("T") ? "0" : "1";
/*     */       }
/*  99 */       else if (chgMode.equalsIgnoreCase("delete")) {
/* 100 */         String ret = deleteUserGroup(groupId);
/* 101 */         String flag = ret.substring(0, 1);
/* 102 */         msg = ret.substring(1);
/*     */ 
/* 104 */         retFlag = flag.equalsIgnoreCase("T") ? "0" : "1";
/*     */       }
/*     */ 
/* 108 */       StringBuffer returnInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<ROLEMODIFYRSP>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><MODIFYMODE>" + chgMode + "</MODIFYMODE>").append("<ROLEID>" + groupId + "</ROLEID>").append("<RSP>" + retFlag + "</RSP>").append("</BODY></ROLEMODIFYRSP>");
/*     */ 
/* 118 */       ResponseInfo = returnInfo.toString();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 122 */       e.printStackTrace();
/*     */     }
/* 124 */     return ResponseInfo;
/*     */   }
/*     */ 
/*     */   private Map parseXml(String requestInfo)
/*     */   {
/* 133 */     Map resultMap = new HashMap();
/*     */     try
/*     */     {
/* 136 */       SAXBuilder builder = new SAXBuilder(false);
/* 137 */       ByteArrayInputStream is = new ByteArrayInputStream(requestInfo.getBytes());
/*     */ 
/* 140 */       Document doc = builder.build(is);
/* 141 */       Element body = doc.getRootElement();
/*     */ 
/* 143 */       List body_list = body.getChildren("BODY");
/* 144 */       Element e2 = (Element)body_list.get(0);
/* 145 */       String operId = e2.getChildText("OPERATORID");
/*     */ 
/* 147 */       String chgMode = e2.getChildText("MODIFYMODE");
/* 148 */       String groupId = e2.getChildText("ROLEID");
/* 149 */       List roleInfoList = e2.getChildren("ROLEINFO");
/* 150 */       Element roleInfo = (Element)roleInfoList.get(0);
/* 151 */       String groupName = roleInfo.getChildText("ROLENAME");
/* 152 */       String pid = roleInfo.getChildText("PARENTROLEID");
/* 153 */       String desc = roleInfo.getChildText("ROLEDESC");
/*     */ 
/* 155 */       resultMap.put("OPERATORID", operId);
/* 156 */       resultMap.put("MODIFYMODE", chgMode);
/* 157 */       resultMap.put("ROLEID", groupId);
/* 158 */       resultMap.put("ROLENAME", groupName);
/* 159 */       resultMap.put("PARENTROLEID", pid);
/* 160 */       resultMap.put("ROLEDESC", desc);
/*     */     }
/*     */     catch (JDOMException e)
/*     */     {
/* 164 */       e.printStackTrace();
/*     */ 
/* 167 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 168 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 172 */       e.printStackTrace();
/*     */ 
/* 174 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 175 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */ 
/* 178 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private String genErrorMsg(String key, String errCode, String errDesc) {
/* 182 */     if ((null == key) || (key.length() < 1)) {
/* 183 */       key = "ERROR";
/*     */     }
/* 185 */     if ((null == errCode) || (errCode.length() < 1)) {
/* 186 */       errCode = "errorcode";
/*     */     }
/* 188 */     if ((null == errDesc) || (errDesc.length() < 1)) {
/* 189 */       errDesc = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeError") + "";
/*     */     }
/*     */ 
/* 192 */     StringBuffer errorInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERREQ>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><KEY>" + key + "</KEY>").append("<ERRCODE>" + errCode + "</ERRCODE>").append("<ERRDES>" + errDesc + "</ERRDES>").append("</BODY></USERREQ>");
/*     */ 
/* 204 */     return errorInfo.toString();
/*     */   }
/*     */ 
/*     */   private String deleteUserGroup(String groupId)
/*     */   {
/* 214 */     String msg = "";
/* 215 */     if (groupId.equals("1")) {
/* 216 */       msg = "F" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.reservedGroupDeleteFail") + "";
/* 217 */       return msg;
/*     */     }
/* 219 */     boolean roleByUsed = this.userGroupAdminService.roleByGroupUsed(groupId);
/* 220 */     if (roleByUsed) {
/* 221 */       msg = "F" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleCannotDelete") + "";
/* 222 */       return msg;
/*     */     }
/* 224 */     List subUserList = this.userGroupAdminService.getUsersByGroupId(groupId);
/* 225 */     if ((subUserList != null) && (subUserList.size() > 0)) {
/* 226 */       msg = "F" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupHasUser") + "";
/* 227 */       return msg;
/*     */     }
/* 229 */     List subList = this.userGroupAdminService.getAllSubUsersByGroupId(groupId);
/* 230 */     if ((subList != null) && (subList.size() > 0)) {
/* 231 */       msg = "F" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.subGroupHasUser") + "";
/* 232 */       return msg;
/*     */     }
/*     */ 
/* 235 */     List groupList = this.userGroupAdminService.getAllSubGroup(groupId);
/* 236 */     if ((groupList != null) && (groupList.size() > 0)) {
/* 237 */       for (int i = 0; i < groupList.size(); i++) {
/* 238 */         User_Group group = (User_Group)groupList.get(i);
/* 239 */         String gid = group.getGroupid();
/* 240 */         String gName = group.getGroupname();
/* 241 */         this.userGroupAdminService.deleteUserGroup(group);
/*     */ 
/* 243 */         ListService.deleteBalanceServerRole(gid, gName);
/*     */       }
/*     */     }
/*     */ 
/* 247 */     User_Group group = this.userGroupAdminService.getUserGroup(groupId);
/* 248 */     String gid = group.getGroupid();
/* 249 */     String gName = group.getGroupname();
/* 250 */     this.userGroupAdminService.deleteUserGroup(group);
/*     */ 
/* 252 */     ListService.deleteBalanceServerRole(gid, gName);
/* 253 */     msg = "T" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupSuccess") + "";
/*     */ 
/* 257 */     return msg;
/*     */   }
/*     */ 
/*     */   private String changeUserGroup(User_Group newGroup, User_Group oldGroup)
/*     */   {
/* 268 */     String groupName = newGroup.getGroupname();
/* 269 */     String groupId = newGroup.getGroupid();
/* 270 */     String oldName = oldGroup.getGroupname();
/*     */ 
/* 273 */     if (groupName.equals(oldName)) {
/* 274 */       return "T" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyGroupSuccess") + "";
/*     */     }
/*     */ 
/* 277 */     if (this.userGroupAdminService.isUserGroupExists(groupName)) {
/* 278 */       return "F" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyGroupName") + "[ " + groupName + " ]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.inUse");
/*     */     }
/* 280 */     oldGroup.setGroupname(newGroup.getGroupname());
/* 281 */     this.userGroupAdminService.updateUserGroup(oldGroup);
/* 282 */     return "T" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyGroupSuccess") + "";
/*     */   }
/*     */ 
/*     */   private String addUserGroup(User_Group userGroup)
/*     */   {
/* 294 */     String groupName = userGroup.getGroupname();
/*     */ 
/* 296 */     boolean bExist = this.userGroupAdminService.isUserGroupExists(groupName);
/*     */ 
/* 298 */     String msg = "";
/* 299 */     if (bExist == true) {
/* 300 */       msg = "F" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.newGroupName") + " [ " + groupName + "  ]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.inUse");
/*     */     } else {
/* 302 */       String parentid = userGroup.getParentid();
/*     */ 
/* 304 */       this.userGroupAdminService.addUserGroup(userGroup);
/* 305 */       String groupId = userGroup.getGroupid();
/*     */ 
/* 307 */       msg = "T" + groupId + "_" + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.createGroupSuccess") + "";
/*     */     }
/*     */ 
/* 310 */     return msg;
/*     */   }
/*     */ 
/*     */   public IUserGroupAdminService getUserGroupAdminService()
/*     */   {
/* 318 */     return this.userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserGroupAdminService(IUserGroupAdminService userGroupAdminService)
/*     */   {
/* 327 */     this.userGroupAdminService = userGroupAdminService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wservice.impl.UserGroupChgServiceImpl
 * JD-Core Version:    0.6.2
 */
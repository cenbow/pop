/*     */ package com.asiainfo.biframe.privilege.foura.wservice.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.log.LogInfo;
/*     */ import com.asiainfo.biframe.privilege.foura.util.FouraUtil;
/*     */ import com.asiainfo.biframe.privilege.foura.wservice.IUserGroupMapChgService;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.impl.ListService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ public class UserGroupMapChgServiceImpl
/*     */   implements IUserGroupMapChgService
/*     */ {
/*     */   private IUserAdminService userAdminService;
/*     */   private IUserGroupAdminService userGroupAdminService;
/*     */ 
/*     */   public String UpdateAppAcctRoleSoap(String requestInfo)
/*     */   {
/*  44 */     String ResponseInfo = "";
/*     */ 
/*  46 */     String userId = "";
/*  47 */     String groupId = "";
/*  48 */     String retFlag = "0";
/*  49 */     String retMsg = "";
/*     */     try
/*     */     {
/*  52 */       Map xmlMap = parseXml(requestInfo);
/*  53 */       if (null != xmlMap.get("ERROR")) {
/*  54 */         return (String)xmlMap.get("ERROR");
/*     */       }
/*     */ 
/*  58 */       String operId = (String)xmlMap.get("OPERATORID");
/*  59 */       userId = (String)xmlMap.get("USERID");
/*  60 */       groupId = (String)xmlMap.get("ROLEID");
/*  61 */       String groupName = (String)xmlMap.get("ROLENAME");
/*  62 */       String groupDesc = (String)xmlMap.get("ROLEDESC");
/*     */ 
/*  65 */       User_User userObj = this.userAdminService.getUser(userId);
/*  66 */       User_Group userGroup = this.userGroupAdminService.getUserGroup(groupId);
/*     */ 
/*  68 */       if ((null == userObj) || (null == userGroup)) {
/*  69 */         retFlag = "1";
/*  70 */         if (null == userObj)
/*  71 */           retMsg = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExistFail") + "";
/*  72 */         else if (null == userGroup)
/*  73 */           retMsg = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupNotExistFail") + "";
/*     */       }
/*     */       else {
/*  76 */         LogInfo.setSessionInfoMap(FouraUtil.getLogSessionInfoMap(operId));
/*     */ 
/*  78 */         String[] groupList = { groupId };
/*  79 */         this.userAdminService.saveUserGroupMap(userId, groupList);
/*     */ 
/*  81 */         retFlag = "0";
/*  82 */         retMsg = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveGroupUserSuccess") + "";
/*     */ 
/*  85 */         List resourceList = this.userGroupAdminService.getRightByGroup(groupId, 0, Integer.parseInt("5"), false);
/*     */ 
/*  87 */         String oldCityId = userObj.getCityid();
/*  88 */         List resIdList = new ArrayList();
/*     */         try {
/*  90 */           resIdList = ListService.convertToNewList(resourceList, "ResourceId");
/*     */         }
/*     */         catch (Exception e) {
/*  93 */           e.printStackTrace();
/*     */         }
/*     */ 
/*  96 */         if (((null == oldCityId) || (!resIdList.contains(oldCityId))) && (resIdList.size() > 0)) {
/*  97 */           userObj.setCityid((String)resIdList.get(0));
/*  98 */           this.userAdminService.updateUser(userObj);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 104 */       ResponseInfo = genResultMsg(userId, retFlag, retMsg);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 108 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 111 */     return ResponseInfo;
/*     */   }
/*     */ 
/*     */   private String genResultMsg(String userId, String resultFlag, String resultMsg)
/*     */   {
/* 123 */     if (null == userId) {
/* 124 */       userId = "";
/*     */     }
/* 126 */     if ((null == resultFlag) || (resultFlag.length() < 1)) {
/* 127 */       resultFlag = "1";
/*     */     }
/* 129 */     if (null == resultMsg) {
/* 130 */       resultMsg = "";
/*     */     }
/*     */ 
/* 133 */     StringBuffer resultInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERROLEMODIFYRSP>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><USERID>" + userId + "</USERID>").append("<RESULT>" + resultFlag + "</RESULT>").append("</BODY></USERROLEMODIFYRSP>");
/*     */ 
/* 138 */     return resultInfo.toString();
/*     */   }
/*     */ 
/*     */   private Map parseXml(String requestInfo)
/*     */   {
/* 149 */     Map resultMap = new HashMap();
/*     */     try
/*     */     {
/* 152 */       SAXBuilder builder = new SAXBuilder(false);
/* 153 */       ByteArrayInputStream is = new ByteArrayInputStream(requestInfo.getBytes());
/*     */ 
/* 155 */       Document doc = builder.build(is);
/* 156 */       Element body = doc.getRootElement();
/*     */ 
/* 158 */       List body_list = body.getChildren("BODY");
/* 159 */       Element e2 = (Element)body_list.get(0);
/* 160 */       String operId = e2.getChildText("OPERATORID");
/* 161 */       String userId = e2.getChildText("USERID");
/* 162 */       List roleList = e2.getChildren("ROLELIST");
/* 163 */       Element roleListE = (Element)roleList.get(0);
/* 164 */       List roles = roleListE.getChildren("ROLE");
/* 165 */       Iterator it = roles.iterator();
/* 166 */       String groupId = "";
/* 167 */       String groupName = "";
/* 168 */       String roleDesc = "";
/* 169 */       while (it.hasNext()) {
/* 170 */         Element role = (Element)it.next();
/* 171 */         groupId = role.getChildText("ID");
/* 172 */         groupName = role.getChildText("NAME");
/* 173 */         roleDesc = role.getChildText("DESC");
/*     */       }
/*     */ 
/* 177 */       resultMap.put("OPERATORID", operId);
/* 178 */       resultMap.put("USERID", userId);
/* 179 */       resultMap.put("ROLEID", groupId);
/* 180 */       resultMap.put("ROLENAME", groupName);
/* 181 */       resultMap.put("ROLEDESC", roleDesc);
/*     */     }
/*     */     catch (JDOMException e)
/*     */     {
/* 185 */       e.printStackTrace();
/*     */ 
/* 188 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 189 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 193 */       e.printStackTrace();
/*     */ 
/* 195 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 196 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */ 
/* 199 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private String genErrorMsg(String key, String errCode, String errDesc) {
/* 203 */     if ((null == key) || (key.length() < 1)) {
/* 204 */       key = "ERROR";
/*     */     }
/* 206 */     if ((null == errCode) || (errCode.length() < 1)) {
/* 207 */       errCode = "errorcode";
/*     */     }
/* 209 */     if ((null == errDesc) || (errDesc.length() < 1)) {
/* 210 */       errDesc = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeError") + "";
/*     */     }
/*     */ 
/* 213 */     StringBuffer errorInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERREQ>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><KEY>" + key + "</KEY>").append("<ERRCODE>" + errCode + "</ERRCODE>").append("<ERRDES>" + errDesc + "</ERRDES>").append("</BODY></USERREQ>");
/*     */ 
/* 218 */     return errorInfo.toString();
/*     */   }
/*     */ 
/*     */   public IUserAdminService getUserAdminService()
/*     */   {
/* 225 */     return this.userAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserAdminService(IUserAdminService userAdminService)
/*     */   {
/* 232 */     this.userAdminService = userAdminService;
/*     */   }
/*     */ 
/*     */   public IUserGroupAdminService getUserGroupAdminService()
/*     */   {
/* 239 */     return this.userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserGroupAdminService(IUserGroupAdminService userGroupAdminService)
/*     */   {
/* 246 */     this.userGroupAdminService = userGroupAdminService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wservice.impl.UserGroupMapChgServiceImpl
 * JD-Core Version:    0.6.2
 */
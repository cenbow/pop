/*     */ package com.asiainfo.biframe.privilege.foura.wservice.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.foura.wservice.IUserGroupMapService;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ public class UserGroupMapServiceImpl
/*     */   implements IUserGroupMapService
/*     */ {
/*     */   private IUserAdminService userAdminService;
/*     */ 
/*     */   public String QueryAppAcctRightSoap(String requestInfo)
/*     */   {
/*  37 */     String ResponseInfo = "";
/*     */     try {
/*  39 */       Map xmlMap = parseXml(requestInfo);
/*  40 */       if (null != xmlMap.get("ERROR")) {
/*  41 */         return (String)xmlMap.get("ERROR");
/*     */       }
/*     */ 
/*  45 */       String operUserId = (String)xmlMap.get("OPERATORID");
/*  46 */       String userId = (String)xmlMap.get("USERID");
/*     */ 
/*  50 */       System.out.println("===Sax:" + operUserId + "--" + userId);
/*     */ 
/*  53 */       User_Group groupObj = this.userAdminService.getGroupObject(userId);
/*  54 */       String groupId = "";
/*  55 */       String groupName = "";
/*  56 */       if (null != groupObj) {
/*  57 */         groupId = groupObj.getGroupid();
/*  58 */         groupName = groupObj.getGroupname();
/*     */       }
/*     */ 
/*  62 */       StringBuffer returnInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERRIGHTQUERYRSP>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><USERID>" + userId + "</USERID>").append("<RIGHTLIST><RIGHT><ID>" + groupId + "</ID>").append("<NAME>" + groupName + "</NAME>").append("<TYPE>role</TYPE></RIGHT></RIGHTLIST>").append("</BODY></USERRIGHTQUERYRSP>");
/*     */ 
/*  73 */       ResponseInfo = returnInfo.toString();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  77 */       e.printStackTrace();
/*     */     }
/*  79 */     return ResponseInfo;
/*     */   }
/*     */ 
/*     */   private Map parseXml(String requestInfo)
/*     */   {
/*  88 */     Map resultMap = new HashMap();
/*     */     try
/*     */     {
/*  91 */       SAXBuilder builder = new SAXBuilder(false);
/*  92 */       ByteArrayInputStream is = new ByteArrayInputStream(requestInfo.getBytes());
/*     */ 
/*  95 */       Document doc = builder.build(is);
/*  96 */       Element body = doc.getRootElement();
/*     */ 
/*  98 */       List body_list = body.getChildren("BODY");
/*  99 */       Element e2 = (Element)body_list.get(0);
/* 100 */       String operUserId = e2.getChildText("OPERATORID");
/* 101 */       String userId = e2.getChildText("USERID");
/*     */ 
/* 103 */       resultMap.put("OPERATORID", operUserId);
/* 104 */       resultMap.put("USERID", userId);
/*     */     }
/*     */     catch (JDOMException e)
/*     */     {
/* 108 */       e.printStackTrace();
/*     */ 
/* 111 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 112 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 116 */       e.printStackTrace();
/*     */ 
/* 118 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/* 119 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/*     */ 
/* 122 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private String genErrorMsg(String key, String errCode, String errDesc) {
/* 126 */     if ((null == key) || (key.length() < 1)) {
/* 127 */       key = "ERROR";
/*     */     }
/* 129 */     if ((null == errCode) || (errCode.length() < 1)) {
/* 130 */       errCode = "errorcode";
/*     */     }
/* 132 */     if ((null == errDesc) || (errDesc.length() < 1)) {
/* 133 */       errDesc = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeError") + "";
/*     */     }
/*     */ 
/* 136 */     StringBuffer errorInfo = new StringBuffer().append("<?xml version='1.0' encoding='GBK'?>").append("<USERREQ>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>serviceId</SERVICEID></HEAD>").append("<BODY><KEY>" + key + "</KEY>").append("<ERRCODE>" + errCode + "</ERRCODE>").append("<ERRDES>" + errDesc + "</ERRDES>").append("</BODY></USERREQ>");
/*     */ 
/* 148 */     return errorInfo.toString();
/*     */   }
/*     */ 
/*     */   public IUserAdminService getUserAdminService()
/*     */   {
/* 155 */     return this.userAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserAdminService(IUserAdminService userAdminService)
/*     */   {
/* 163 */     this.userAdminService = userAdminService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.foura.wservice.impl.UserGroupMapServiceImpl
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.functionright.dao;

import com.asiainfo.biframe.exception.DaoException;
import com.asiainfo.biframe.privilege.model.SystemFunctionAction;
import java.util.List;
import java.util.Map;

public abstract interface ISystemFunctionActionDao
{
  public abstract void save(SystemFunctionAction paramSystemFunctionAction)
    throws DaoException;

  public abstract void update(SystemFunctionAction paramSystemFunctionAction)
    throws DaoException;

  public abstract void delete(SystemFunctionAction paramSystemFunctionAction)
    throws DaoException;

  public abstract SystemFunctionAction getById(String paramString)
    throws DaoException;

  public abstract Map getPagedActionList(SystemFunctionAction paramSystemFunctionAction, int paramInt1, int paramInt2)
    throws DaoException;

  public abstract List<SystemFunctionAction> getAll()
    throws DaoException;

  public abstract List<SystemFunctionAction> getFunctionActionsBy(String paramString)
    throws DaoException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.functionright.dao.ISystemFunctionActionDao
 * JD-Core Version:    0.6.2
 */
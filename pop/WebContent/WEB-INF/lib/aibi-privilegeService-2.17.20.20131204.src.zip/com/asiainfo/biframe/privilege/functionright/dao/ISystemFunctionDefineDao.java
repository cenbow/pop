package com.asiainfo.biframe.privilege.functionright.dao;

import com.asiainfo.biframe.exception.DaoException;
import com.asiainfo.biframe.privilege.model.SystemFunctionDefine;
import java.util.List;
import java.util.Map;

public abstract interface ISystemFunctionDefineDao
{
  public abstract void save(SystemFunctionDefine paramSystemFunctionDefine)
    throws DaoException;

  public abstract void update(SystemFunctionDefine paramSystemFunctionDefine)
    throws DaoException;

  public abstract void delete(SystemFunctionDefine paramSystemFunctionDefine)
    throws DaoException;

  public abstract SystemFunctionDefine getById(String paramString)
    throws DaoException;

  public abstract Map getPagedDefineList(SystemFunctionDefine paramSystemFunctionDefine, int paramInt1, int paramInt2)
    throws DaoException;

  public abstract List<SystemFunctionDefine> getAll()
    throws DaoException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.functionright.dao.ISystemFunctionDefineDao
 * JD-Core Version:    0.6.2
 */
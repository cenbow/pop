/*     */ package com.asiainfo.biframe.privilege.functionright.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.functionright.dao.ISystemFunctionActionDao;
/*     */ import com.asiainfo.biframe.privilege.model.SystemFunctionAction;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class SystemFunctionActionDao extends HibernateDaoSupport
/*     */   implements ISystemFunctionActionDao
/*     */ {
/*  34 */   private static Logger log = Logger.getLogger(SystemFunctionActionDao.class);
/*     */ 
/*     */   public void delete(SystemFunctionAction action) throws DaoException {
/*     */     try {
/*  38 */       getHibernateTemplate().delete(action);
/*     */     } catch (DataAccessException e) {
/*  40 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delFuncRightError") + "", e);
/*  41 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delFuncRightError") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public SystemFunctionAction getById(String actionId) throws DaoException {
/*     */     try {
/*  47 */       return (SystemFunctionAction)getHibernateTemplate().get(SystemFunctionAction.class, actionId);
/*     */     }
/*     */     catch (DataAccessException e) {
/*  50 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncByIdFail"), e);
/*  51 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncByIdFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map getPagedActionList(SystemFunctionAction action, final int currpage, final int pagesize) throws DaoException {
/*  56 */     log.debug("in getPagedActionList........");
/*  57 */     HashMap map = new HashMap();
/*     */     try {
/*  59 */       String whereSql = getWhereSql(action);
/*     */ 
/*  61 */       String countSql = "select count(funcAction) from SystemFunctionAction funcAction " + whereSql;
/*  62 */       log.debug("--countSql:" + countSql);
/*  63 */       List list = getHibernateTemplate().find(countSql);
/*  64 */       int totals = 0;
/*  65 */       if ((list != null) && (list.size() > 0)) {
/*  66 */         totals = ((Long)list.get(0)).intValue();
/*     */       }
/*     */ 
/*  69 */       final String listSql = "from SystemFunctionAction funcAction " + whereSql;
/*  70 */       log.debug("--listSql:" + listSql);
/*  71 */       list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */         public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  73 */           Query query = s.createQuery(listSql);
/*  74 */           int firstResult = currpage * pagesize;
/*  75 */           int maxResult = pagesize;
/*  76 */           query.setFirstResult(firstResult);
/*  77 */           query.setMaxResults(maxResult);
/*  78 */           List tmpList = query.list();
/*  79 */           return tmpList;
/*     */         }
/*     */       });
/*  83 */       map.put("total", new Integer(totals));
/*  84 */       map.put("result", list);
/*  85 */       return map;
/*     */     } catch (DataAccessException e) {
/*  87 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncByCondition") + "", e);
/*  88 */       map.put("total", new Integer(0));
/*  89 */       map.put("result", new ArrayList());
/*  90 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncByCondition") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getWhereSql(SystemFunctionAction action) {
/*  95 */     StringBuilder whereSql = new StringBuilder(256).append(" where 1=1 ");
/*  96 */     String actionId = action.getActionId();
/*  97 */     String resourceId = action.getResourceId();
/*  98 */     Integer resourceType = action.getResourceType();
/*  99 */     String operationType = action.getOperationType();
/*     */ 
/* 101 */     if (StringUtils.isNotBlank(actionId)) {
/* 102 */       whereSql.append(" and funcAction.actionId='").append(actionId).append("'");
/*     */     }
/* 104 */     if (StringUtils.isNotBlank(resourceId)) {
/* 105 */       whereSql.append(" and funcAction.resourceId='").append(resourceId).append("'");
/*     */     }
/* 107 */     if ((resourceType != null) && (resourceType.intValue() != Integer.parseInt("-1"))) {
/* 108 */       whereSql.append(" and funcAction.resourceType=").append(resourceType);
/*     */     }
/* 110 */     if (StringUtils.isNotBlank(operationType)) {
/* 111 */       whereSql.append(" and funcAction.operationType='").append(operationType).append("'");
/*     */     }
/* 113 */     return whereSql.toString();
/*     */   }
/*     */ 
/*     */   public void save(SystemFunctionAction action) throws DaoException {
/*     */     try {
/* 118 */       getHibernateTemplate().save(action);
/*     */     } catch (DataAccessException e) {
/* 120 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveFuncRightFail") + "", e);
/* 121 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveFuncRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void update(SystemFunctionAction action) throws DaoException {
/*     */     try {
/* 127 */       getHibernateTemplate().update(action);
/*     */     } catch (DataAccessException e) {
/* 129 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modFuncRightFail") + "", e);
/* 130 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modFuncRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<SystemFunctionAction> getAll() throws DaoException {
/*     */     try {
/* 136 */       return getHibernateTemplate().find("from SystemFunctionAction");
/*     */     } catch (DataAccessException e) {
/* 138 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncRightFail") + "", e);
/* 139 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<SystemFunctionAction> getFunctionActionsBy(String functionId)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/* 148 */       String hql = "from SystemFunctionAction funcAction where funcAction.resourceId='" + functionId + "'";
/* 149 */       return getHibernateTemplate().find(hql);
/*     */     } catch (DataAccessException e) {
/* 151 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncRightFail") + "", e);
/* 152 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.functionright.dao.impl.SystemFunctionActionDao
 * JD-Core Version:    0.6.2
 */
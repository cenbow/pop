/*     */ package com.asiainfo.biframe.privilege.functionright.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.functionright.dao.ISystemFunctionDefineDao;
/*     */ import com.asiainfo.biframe.privilege.model.SystemFunctionDefine;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class SystemFunctionDefineDao extends HibernateDaoSupport
/*     */   implements ISystemFunctionDefineDao
/*     */ {
/*  33 */   private static Logger log = Logger.getLogger(SystemFunctionDefineDao.class);
/*     */ 
/*     */   public void delete(SystemFunctionDefine def) throws DaoException {
/*     */     try {
/*  37 */       getHibernateTemplate().delete(def);
/*     */     } catch (DataAccessException e) {
/*  39 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delFuncRightError") + "", e);
/*  40 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delFuncRightError") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public SystemFunctionDefine getById(String functionId) throws DaoException {
/*     */     try {
/*  46 */       return (SystemFunctionDefine)getHibernateTemplate().get(SystemFunctionDefine.class, functionId);
/*     */     }
/*     */     catch (DataAccessException e) {
/*  49 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByIdFail"), e);
/*  50 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByIdFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map getPagedDefineList(SystemFunctionDefine def, final int currpage, final int pagesize) throws DaoException {
/*  55 */     log.debug("in getPagedDefineList........");
/*  56 */     HashMap map = new HashMap();
/*     */     try {
/*  58 */       String whereSql = getWhereSql(def);
/*     */ 
/*  60 */       String countSql = "select count(funcDef) from SystemFunctionDefine funcDef " + whereSql;
/*  61 */       log.debug("--countSql:" + countSql);
/*  62 */       List list = getHibernateTemplate().find(countSql);
/*  63 */       int totals = 0;
/*  64 */       if ((list != null) && (list.size() > 0)) {
/*  65 */         totals = ((Long)list.get(0)).intValue();
/*     */       }
/*     */ 
/*  68 */       final String listSql = "from SystemFunctionDefine funcDef " + whereSql;
/*  69 */       log.debug("--listSql:" + listSql);
/*  70 */       list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */         public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  72 */           Query query = s.createQuery(listSql);
/*  73 */           int firstResult = currpage * pagesize;
/*  74 */           int maxResult = pagesize;
/*  75 */           query.setFirstResult(firstResult);
/*  76 */           query.setMaxResults(maxResult);
/*  77 */           List tmpList = query.list();
/*  78 */           return tmpList;
/*     */         }
/*     */       });
/*  82 */       map.put("total", new Integer(totals));
/*  83 */       map.put("result", list);
/*  84 */       return map;
/*     */     } catch (DataAccessException e) {
/*  86 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByConditionFail") + "", e);
/*  87 */       map.put("total", new Integer(0));
/*  88 */       map.put("result", new ArrayList());
/*  89 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByConditionFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getWhereSql(SystemFunctionDefine def) {
/*  94 */     StringBuilder whereSql = new StringBuilder(256).append(" where 1=1 ");
/*  95 */     String functionId = def.getFunctionId();
/*  96 */     String functionName = def.getFunctionName();
/*  97 */     Integer resourceType = def.getResourceType();
/*  98 */     String parentId = def.getParentId();
/*     */ 
/* 100 */     if (StringUtils.isNotBlank(functionId)) {
/* 101 */       whereSql.append(" and funcDef.functionId like '%").append(functionId).append("%'");
/*     */     }
/* 103 */     if (StringUtils.isNotBlank(functionName)) {
/* 104 */       whereSql.append(" and funcDef.functionName like '%").append(functionName).append("%'");
/*     */     }
/* 106 */     if ((resourceType != null) && (resourceType.intValue() != Integer.parseInt("-1"))) {
/* 107 */       whereSql.append(" and funcDef.resourceType=").append(resourceType);
/*     */     }
/* 109 */     if ((StringUtils.isNotBlank(parentId)) && (!"-1".equals(parentId))) {
/* 110 */       whereSql.append(" and funcDef.parentId='").append(parentId).append("'");
/*     */     }
/* 112 */     return whereSql.toString();
/*     */   }
/*     */ 
/*     */   public void save(SystemFunctionDefine def) throws DaoException {
/*     */     try {
/* 117 */       getHibernateTemplate().save(def);
/*     */     } catch (DataAccessException e) {
/* 119 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveFuncDefineFail") + "", e);
/* 120 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveFuncDefineFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void update(SystemFunctionDefine def) throws DaoException {
/*     */     try {
/* 126 */       getHibernateTemplate().update(def);
/*     */     } catch (DataAccessException e) {
/* 128 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modFuncDefineFail") + "", e);
/* 129 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modFuncDefineFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<SystemFunctionDefine> getAll() throws DaoException {
/*     */     try {
/* 135 */       return getHibernateTemplate().find("from SystemFunctionDefine");
/*     */     } catch (DataAccessException e) {
/* 137 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncDefineFail") + "", e);
/* 138 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncDefineFail") + "", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.functionright.dao.impl.SystemFunctionDefineDao
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.functionright.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.model.SystemFunctionAction;
import java.util.List;
import java.util.Map;

public abstract interface ISystemFunctionActionService
{
  public abstract void save(SystemFunctionAction paramSystemFunctionAction)
    throws ServiceException;

  public abstract void update(SystemFunctionAction paramSystemFunctionAction)
    throws ServiceException;

  public abstract void delete(SystemFunctionAction paramSystemFunctionAction)
    throws ServiceException;

  public abstract SystemFunctionAction getById(String paramString)
    throws ServiceException;

  public abstract Map getPagedActionList(SystemFunctionAction paramSystemFunctionAction, int paramInt1, int paramInt2)
    throws ServiceException;

  public abstract List<SystemFunctionAction> getAll()
    throws ServiceException;

  public abstract boolean isUserdByRoles(SystemFunctionAction paramSystemFunctionAction);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.functionright.service.ISystemFunctionActionService
 * JD-Core Version:    0.6.2
 */
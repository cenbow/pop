package com.asiainfo.biframe.privilege.functionright.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.model.SystemFunctionAction;
import com.asiainfo.biframe.privilege.model.SystemFunctionDefine;
import java.util.List;
import java.util.Map;

public abstract interface ISystemFunctionDefineService
{
  public abstract void save(SystemFunctionDefine paramSystemFunctionDefine)
    throws ServiceException;

  public abstract void update(SystemFunctionDefine paramSystemFunctionDefine)
    throws ServiceException;

  public abstract void delete(SystemFunctionDefine paramSystemFunctionDefine)
    throws ServiceException;

  public abstract SystemFunctionDefine getById(String paramString)
    throws ServiceException;

  public abstract Map getPagedDefineList(SystemFunctionDefine paramSystemFunctionDefine, int paramInt1, int paramInt2)
    throws ServiceException;

  public abstract List<SystemFunctionDefine> getAll()
    throws ServiceException;

  public abstract List<SystemFunctionAction> getFunctionActionsBy(String paramString)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.functionright.service.ISystemFunctionDefineService
 * JD-Core Version:    0.6.2
 */
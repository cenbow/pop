/*     */ package com.asiainfo.biframe.privilege.functionright.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.base.util.BeanUtils;
/*     */ import com.asiainfo.biframe.privilege.functionright.dao.ISystemFunctionActionDao;
/*     */ import com.asiainfo.biframe.privilege.functionright.service.ISystemFunctionActionService;
/*     */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*     */ import com.asiainfo.biframe.privilege.model.SystemFunctionAction;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.ISysResourceTypeService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SystemFunctionActionService
/*     */   implements ISystemFunctionActionService
/*     */ {
/*  35 */   private static Logger log = Logger.getLogger(SystemFunctionActionService.class);
/*     */   private ISystemFunctionActionDao systemFunctionActionDao;
/*     */   private ISysResourceTypeService sysResourceTypeService;
/*     */   private IRoleAdminService roleAdminService;
/*     */ 
/*     */   private SystemFunctionAction getRealAction(String mockActionId)
/*     */   {
/*  42 */     SystemFunctionAction realAction = getById(mockActionId);
/*  43 */     if (realAction == null) {
/*  44 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.funcRightNotExist") + "!");
/*     */     }
/*  46 */     return realAction;
/*     */   }
/*     */ 
/*     */   public void delete(SystemFunctionAction mockAction) throws ServiceException {
/*     */     try {
/*  51 */       log.debug(" in delete");
/*  52 */       SystemFunctionAction realAction = getRealAction(mockAction.getActionId());
/*     */ 
/*  54 */       if (isUserdByRoles(realAction)) {
/*  55 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.operationDefine") + "[" + realAction.getActionId() + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.usedByRole") + "");
/*     */       }
/*     */ 
/*  58 */       getSystemFunctionActionDao().delete(realAction);
/*  59 */       log.debug(" end delete");
/*     */     } catch (DaoException e) {
/*  61 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delFuncRightError") + "", e);
/*  62 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delFuncRightError") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isUserdByRoles(SystemFunctionAction realAction)
/*     */   {
/*  68 */     IResourceRightDAO dao = getRoleAdminService().getResourceRightDAO(2, Integer.parseInt("1001"));
/*     */ 
/*  71 */     Right right = new Right();
/*  72 */     right.setRightId(realAction.getActionId());
/*     */ 
/*  76 */     List roleRightList = dao.getRoleRightListByRight(right);
/*  77 */     if (roleRightList.isEmpty()) {
/*  78 */       return false;
/*     */     }
/*  80 */     return true;
/*     */   }
/*     */ 
/*     */   public SystemFunctionAction getById(String actionId) throws ServiceException {
/*     */     try {
/*  85 */       log.debug(" in getById");
/*  86 */       SystemFunctionAction action = getSystemFunctionActionDao().getById(actionId);
/*  87 */       populateAction(action);
/*  88 */       return action;
/*     */     } catch (DaoException e) {
/*  90 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByIdFail"));
/*  91 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByIdFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map getPagedActionList(SystemFunctionAction conditionAction, int currpage, int pagesize) throws ServiceException {
/*     */     try {
/*  97 */       log.debug(" in getPagedDefineList");
/*  98 */       Map map = getSystemFunctionActionDao().getPagedActionList(conditionAction, currpage, pagesize);
/*  99 */       List actionList = (List)map.get("result");
/* 100 */       for (SystemFunctionAction action : actionList) {
/* 101 */         populateAction(action);
/*     */       }
/*     */ 
/* 104 */       return map;
/*     */     } catch (DaoException e) {
/* 106 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncByCondition") + "", e);
/* 107 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncByCondition") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void populateAction(SystemFunctionAction action)
/*     */     throws DaoException
/*     */   {
/* 114 */     List typeList = getSysResourceTypeService().findByResourceType(action.getResourceType().intValue());
/* 115 */     String resourceTypeName = "";
/* 116 */     if (!typeList.isEmpty()) {
/* 117 */       resourceTypeName = ((SysResourceType)typeList.get(0)).getResourcetypeName();
/*     */     }
/* 119 */     action.setResourceTypeName(resourceTypeName);
/*     */   }
/*     */ 
/*     */   public void save(SystemFunctionAction action) throws ServiceException {
/* 123 */     log.debug("in save");
/*     */     try {
/* 125 */       SystemFunctionAction realAction = getSystemFunctionActionDao().getById(action.getActionId());
/* 126 */       if (realAction != null) {
/* 127 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.funcRightIdExist"));
/*     */       }
/* 129 */       getSystemFunctionActionDao().save(action);
/* 130 */       log.debug("end save");
/*     */     } catch (DaoException e) {
/* 132 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveFuncRightFail") + "", e);
/* 133 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveFuncRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void update(SystemFunctionAction mockAction) throws ServiceException {
/*     */     try {
/* 139 */       log.debug(" in update");
/* 140 */       SystemFunctionAction realAction = getRealAction(mockAction.getActionId());
/* 141 */       BeanUtils.copyProperties(realAction, mockAction);
/* 142 */       getSystemFunctionActionDao().update(realAction);
/* 143 */       log.debug(" end update");
/*     */     } catch (DaoException e) {
/* 145 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modFuncRightFail") + "", e);
/* 146 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modFuncRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<SystemFunctionAction> getAll() throws ServiceException {
/*     */     try {
/* 152 */       log.debug(" in getAll");
/* 153 */       return getSystemFunctionActionDao().getAll();
/*     */     } catch (DaoException e) {
/* 155 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncRightFail2") + "", e);
/* 156 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncRightFail2") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ISysResourceTypeService getSysResourceTypeService()
/*     */   {
/* 162 */     return this.sysResourceTypeService;
/*     */   }
/*     */ 
/*     */   public void setSysResourceTypeService(ISysResourceTypeService sysResourceTypeService) {
/* 166 */     this.sysResourceTypeService = sysResourceTypeService;
/*     */   }
/*     */ 
/*     */   public ISystemFunctionActionDao getSystemFunctionActionDao() {
/* 170 */     return this.systemFunctionActionDao;
/*     */   }
/*     */ 
/*     */   public void setSystemFunctionActionDao(ISystemFunctionActionDao systemFunctionActionDao) {
/* 174 */     this.systemFunctionActionDao = systemFunctionActionDao;
/*     */   }
/*     */ 
/*     */   public IRoleAdminService getRoleAdminService() {
/* 178 */     return this.roleAdminService;
/*     */   }
/*     */ 
/*     */   public void setRoleAdminService(IRoleAdminService roleAdminService) {
/* 182 */     this.roleAdminService = roleAdminService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.functionright.service.impl.SystemFunctionActionService
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.functionright.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.base.util.BeanUtils;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.functionright.dao.ISystemFunctionActionDao;
/*     */ import com.asiainfo.biframe.privilege.functionright.dao.ISystemFunctionDefineDao;
/*     */ import com.asiainfo.biframe.privilege.functionright.service.ISystemFunctionActionService;
/*     */ import com.asiainfo.biframe.privilege.functionright.service.ISystemFunctionDefineService;
/*     */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*     */ import com.asiainfo.biframe.privilege.model.SystemFunctionAction;
/*     */ import com.asiainfo.biframe.privilege.model.SystemFunctionDefine;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.ISysResourceTypeService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SystemFunctionDefineService
/*     */   implements ISystemFunctionDefineService
/*     */ {
/*  33 */   private static Logger log = Logger.getLogger(SystemFunctionDefineService.class);
/*     */   private ISystemFunctionDefineDao systemFunctionDefineDao;
/*     */   private ISystemFunctionActionDao systemFunctionActionDao;
/*     */   private ISysResourceTypeService sysResourceTypeService;
/*     */   private ISystemFunctionActionService systemFunctionActionService;
/*     */ 
/*     */   private SystemFunctionDefine getRealDefine(String mockDefineId)
/*     */   {
/*  41 */     SystemFunctionDefine realDefine = getById(mockDefineId);
/*  42 */     if (realDefine == null) {
/*  43 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.funcDefineNotExist") + "!");
/*     */     }
/*  45 */     return realDefine;
/*     */   }
/*     */ 
/*     */   public void delete(SystemFunctionDefine mockDef) throws ServiceException {
/*     */     try {
/*  50 */       log.debug(" in delete");
/*  51 */       SystemFunctionDefine realDef = getRealDefine(mockDef.getFunctionId());
/*  52 */       String functionId = realDef.getFunctionId();
/*  53 */       String functionName = realDef.getFunctionName();
/*  54 */       List actionList = getFunctionActionsBy(realDef.getFunctionId());
/*  55 */       for (SystemFunctionAction action : actionList) {
/*  56 */         if (getSystemFunctionActionService().isUserdByRoles(action)) {
/*  57 */           throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.operationDefine") + "[" + action.getActionId() + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.usedByRole2") + "");
/*     */         }
/*     */       }
/*  60 */       for (SystemFunctionAction action : actionList) {
/*  61 */         getSystemFunctionActionService().delete(action);
/*     */       }
/*     */ 
/*  64 */       getSystemFunctionDefineDao().delete(realDef);
/*  65 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_SYSTEMFUNCTION"), functionId, functionName, "系统功能权限管理-->删除系统功能", null, null);
/*     */ 
/*  70 */       log.debug(" end delete");
/*     */     } catch (DaoException e) {
/*  72 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delFuncRightError") + "", e);
/*  73 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delFuncRightError") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public SystemFunctionDefine getById(String functionId) throws ServiceException {
/*     */     try {
/*  79 */       log.debug(" in getById");
/*  80 */       SystemFunctionDefine def = getSystemFunctionDefineDao().getById(functionId);
/*  81 */       if (null != def) {
/*  82 */         populateDefine(def);
/*     */       }
/*  84 */       return def;
/*     */     } catch (DaoException e) {
/*  86 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByIdFail"), e);
/*  87 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByIdFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map getPagedDefineList(SystemFunctionDefine conditiondef, int currpage, int pagesize) throws ServiceException {
/*     */     try {
/*  93 */       log.debug(" in getPagedDefineList");
/*  94 */       Map map = getSystemFunctionDefineDao().getPagedDefineList(conditiondef, currpage, pagesize);
/*  95 */       List defList = (List)map.get("result");
/*  96 */       for (SystemFunctionDefine def : defList) {
/*  97 */         populateDefine(def);
/*     */       }
/*     */ 
/* 100 */       return map;
/*     */     } catch (DaoException e) {
/* 102 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByConditionFail") + "", e);
/* 103 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findFuncDefineByConditionFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void populateDefine(SystemFunctionDefine def)
/*     */     throws DaoException
/*     */   {
/* 110 */     List typeList = getSysResourceTypeService().findByResourceType(def.getResourceType().intValue());
/* 111 */     String resourceTypeName = "";
/* 112 */     if (!typeList.isEmpty()) {
/* 113 */       resourceTypeName = ((SysResourceType)typeList.get(0)).getResourcetypeName();
/*     */     }
/* 115 */     def.setResourceTypeName(resourceTypeName);
/*     */ 
/* 118 */     if ("0".equals(def.getParentId())) {
/* 119 */       def.setParentName("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.rootNode") + "");
/*     */     } else {
/* 121 */       SystemFunctionDefine parentDefine = getSystemFunctionDefineDao().getById(def.getParentId());
/* 122 */       if (parentDefine != null)
/* 123 */         def.setParentName(parentDefine.getFunctionName());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void save(SystemFunctionDefine def) throws ServiceException
/*     */   {
/* 129 */     log.debug("in save");
/*     */     try {
/* 131 */       String functionId = def.getFunctionId();
/* 132 */       String functionName = def.getFunctionName();
/* 133 */       SystemFunctionDefine realDef = getSystemFunctionDefineDao().getById(def.getFunctionId());
/* 134 */       if (realDef != null) {
/* 135 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.funcDefineIdExist"));
/*     */       }
/* 137 */       getSystemFunctionDefineDao().save(def);
/* 138 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_SYSTEMFUNCTION"), functionId, functionName, "系统功能权限管理-->新建系统功能", null, null);
/*     */ 
/* 143 */       log.debug("end save");
/*     */     } catch (DaoException e) {
/* 145 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveFuncDefineFail") + "", e);
/* 146 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveFuncDefineFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void update(SystemFunctionDefine mockDef) throws ServiceException {
/*     */     try {
/* 152 */       log.debug(" in update");
/* 153 */       String functionId = mockDef.getFunctionId();
/* 154 */       String functionName = mockDef.getFunctionName();
/* 155 */       SystemFunctionDefine realDef = getRealDefine(mockDef.getFunctionId());
/* 156 */       BeanUtils.copyProperties(realDef, mockDef);
/* 157 */       getSystemFunctionDefineDao().update(realDef);
/* 158 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_SYSTEMFUNCTION"), functionId, functionName, "系统功能权限管理-->修改系统功能", null, null);
/*     */ 
/* 163 */       log.debug(" end update");
/*     */     } catch (DaoException e) {
/* 165 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modFuncDefineFail") + "", e);
/* 166 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modFuncDefineFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<SystemFunctionDefine> getAll() throws ServiceException {
/*     */     try {
/* 172 */       log.debug(" in getAll");
/* 173 */       return getSystemFunctionDefineDao().getAll();
/*     */     } catch (DaoException e) {
/* 175 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncDefineFail") + "", e);
/* 176 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllFuncDefineFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<SystemFunctionAction> getFunctionActionsBy(String functionId) throws ServiceException {
/*     */     try {
/* 182 */       log.debug(" in getFunctionActionsBy");
/* 183 */       return getSystemFunctionActionDao().getFunctionActionsBy(functionId);
/*     */     } catch (DaoException e) {
/* 185 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getSubFuncRightFailById"), e);
/* 186 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getSubFuncRightFailById"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ISystemFunctionDefineDao getSystemFunctionDefineDao() {
/* 191 */     return this.systemFunctionDefineDao;
/*     */   }
/*     */ 
/*     */   public void setSystemFunctionDefineDao(ISystemFunctionDefineDao systemFunctionDefineDao) {
/* 195 */     this.systemFunctionDefineDao = systemFunctionDefineDao;
/*     */   }
/*     */ 
/*     */   public ISysResourceTypeService getSysResourceTypeService() {
/* 199 */     return this.sysResourceTypeService;
/*     */   }
/*     */ 
/*     */   public void setSysResourceTypeService(ISysResourceTypeService sysResourceTypeService) {
/* 203 */     this.sysResourceTypeService = sysResourceTypeService;
/*     */   }
/*     */ 
/*     */   public ISystemFunctionActionDao getSystemFunctionActionDao() {
/* 207 */     return this.systemFunctionActionDao;
/*     */   }
/*     */ 
/*     */   public void setSystemFunctionActionDao(ISystemFunctionActionDao systemFunctionActionDao) {
/* 211 */     this.systemFunctionActionDao = systemFunctionActionDao;
/*     */   }
/*     */ 
/*     */   public ISystemFunctionActionService getSystemFunctionActionService() {
/* 215 */     return this.systemFunctionActionService;
/*     */   }
/*     */ 
/*     */   public void setSystemFunctionActionService(ISystemFunctionActionService systemFunctionActionService) {
/* 219 */     this.systemFunctionActionService = systemFunctionActionService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.functionright.service.impl.SystemFunctionDefineService
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.fuse.dao;

public abstract interface IPrivilegeSyncDao
{
  public abstract void setProperties();

  public abstract void syncUserInfo();

  public abstract void syncRoleInfo();

  public abstract void syncUserRoleMap();

  public abstract void syncUserCity();

  public abstract void syncUserCityRight();

  public abstract void synRoleRight();

  public abstract void synRoleRoleMap();

  public abstract void deleteTableData();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.fuse.dao.IPrivilegeSyncDao
 * JD-Core Version:    0.6.2
 */
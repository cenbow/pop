/*     */ package com.asiainfo.biframe.privilege.fuse.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.fuse.dao.IPrivilegeSyncDao;
/*     */ import com.asiainfo.biframe.privilege.fuse.model.LkgParamArea;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.AiomniConnectionFactory;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*     */ 
/*     */ public class PrivilegeSyncDao extends JdbcDaoSupport
/*     */   implements IPrivilegeSyncDao
/*     */ {
/*  29 */   private Logger log = Logger.getLogger(PrivilegeSyncDao.class);
/*  30 */   private String jndiNJ = "";
/*  31 */   private String adminId = "";
/*  32 */   private String adminName = "";
/*  33 */   private String provId = "";
/*  34 */   private String provName = "";
/*  35 */   private String townsDmTypeCode = "";
/*  36 */   private String businessHallDmTypeCode = "";
/*  37 */   private String countyIdDefault = "";
/*  38 */   private String countyNameDefault = "";
/*  39 */   private String deptIdDefault = "";
/*  40 */   private String deptNameDefault = "";
/*  41 */   private String townsIdDefault = "";
/*  42 */   private String townsNameDefault = "";
/*  43 */   private String businessHallIdDefault = "";
/*  44 */   private String businessHallNameDefault = "";
/*  45 */   private String cityIdDefault = "";
/*  46 */   private String adminJobId = "";
/*     */ 
/*     */   public void setProperties()
/*     */   {
/*     */     try
/*     */     {
/*  52 */       this.jndiNJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "JNDI_NJ");
/*  53 */       this.adminId = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "ADMIN_ID");
/*  54 */       this.adminName = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "ADMIN_NAME");
/*  55 */       this.provId = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "PROV_ID");
/*  56 */       this.provName = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "PROV_NAME");
/*  57 */       this.townsDmTypeCode = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "TOWNS_DM_TYPE_CODE");
/*  58 */       this.businessHallDmTypeCode = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "BUSINESS_HALL_DM_TYPE_CODE");
/*  59 */       this.countyIdDefault = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "COUNTY_ID_DEFAULT");
/*  60 */       this.countyNameDefault = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "COUNTY_NAME_DEFAULT");
/*  61 */       this.deptIdDefault = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "DEPT_ID_DEFAULT");
/*  62 */       this.deptNameDefault = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "DEPT_NAME_DEFAULT");
/*  63 */       this.townsIdDefault = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "TOWNS_ID_DEFAULT");
/*  64 */       this.townsNameDefault = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "TOWNS_NAME_DEFAULT");
/*  65 */       this.businessHallIdDefault = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "BUSINESS_HALL_ID_DEFAULT");
/*  66 */       this.businessHallNameDefault = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "BUSINESS_HALL_NAME_DEFAULT");
/*  67 */       this.cityIdDefault = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "CITY_ID_DEFAULT");
/*  68 */       this.adminJobId = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "ADMIN_JOB_ID");
/*     */     } catch (Exception e) {
/*  70 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void synRoleRight()
/*     */   {
/*  81 */     this.log.info("synRoleRight  sync start-------LKG_JOB_FUNC--------");
/*  82 */     String insertSql = " INSERT INTO LKG_JOB_FUNC(JOB_ID,FUNC_ID,OPERATE_FLAG,RIGHT_FLAG,BACK1_FLAG,BACK2_FLAG,  BACK3_FLAG,BACK4_FLAG,BACK5_FLAG,BACK6_FLAG,ADMIN_ID,ADMIN_NAME,ADMIN_TIME)  SELECT LJ.JOB_ID,LF.FUNC_ID,'F','F','F','F','F','F','F','F', '" + this.adminId + "','" + this.adminName + "','" + DateUtil.getFormatCurrentTime("yyyyMMddHHmmss") + "' " + " FROM LKG_JOB LJ,LKG_FUNC LF";
/*     */ 
/*  93 */     Sqlca sqlca = null;
/*  94 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/*     */     try {
/*  96 */       sqlca = new Sqlca(con);
/*  97 */       sqlca.execute(insertSql);
/*     */ 
/* 101 */       if (null != con)
/*     */         try {
/* 103 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 107 */       if (null != sqlca)
/* 108 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  99 */       throw new RuntimeException(e);
/*     */     } finally {
/* 101 */       if (null != con)
/*     */         try {
/* 103 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 107 */       if (null != sqlca) {
/* 108 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 111 */     this.log.info("synRoleRight  sync end---------------");
/*     */   }
/*     */ 
/*     */   public void synRoleRoleMap() {
/* 115 */     this.log.info("synRoleRoleMap  sync start-----lkg_job_manage----------");
/* 116 */     Sqlca sqlca = null;
/* 117 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 118 */     String insertSql = " INSERT INTO LKG_JOB_MANAGE(JOB_ID,JOB_ID2,ADMIN_ID,ADMIN_NAME,ADMIN_TIME)  SELECT '" + this.adminJobId + "',LJ.JOB_ID,'" + this.adminId + "','" + this.adminName + "','" + DateUtil.getFormatCurrentTime("yyyyMMddHHmmss") + "' FROM LKG_JOB LJ";
/*     */     try
/*     */     {
/* 122 */       sqlca = new Sqlca(con);
/* 123 */       sqlca.execute(insertSql);
/* 124 */       insertSql = " INSERT INTO LKG_JOB_MANAGE(JOB_ID,JOB_ID2,ADMIN_ID,ADMIN_NAME,ADMIN_TIME)  SELECT LJ.JOB_ID,LJ.JOB_ID,'" + this.adminId + "','" + this.adminName + "','" + DateUtil.getFormatCurrentTime("yyyyMMddHHmmss") + "' FROM LKG_JOB LJ";
/*     */ 
/* 126 */       sqlca.execute(insertSql);
/*     */ 
/* 130 */       if (null != con)
/*     */         try {
/* 132 */           con.close();
/*     */         }
/*     */         catch (SQLException e)
/*     */         {
/*     */         }
/* 137 */       if (null != sqlca)
/* 138 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 128 */       throw new RuntimeException(e);
/*     */     } finally {
/* 130 */       if (null != con)
/*     */         try {
/* 132 */           con.close();
/*     */         }
/*     */         catch (SQLException e)
/*     */         {
/*     */         }
/* 137 */       if (null != sqlca) {
/* 138 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 141 */     this.log.info("synRoleRoleMap  sync end---------------");
/*     */   }
/*     */ 
/*     */   public void syncRoleInfo() {
/* 145 */     this.log.info("syncRoleInfo  sync start----lkg_job-----------");
/* 146 */     Sqlca sqlca = null;
/* 147 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 148 */     PreparedStatement pst = null;
/* 149 */     String selectSql = " SELECT ROLE_ID, ROLE_NAME FROM USER_ROLE where resourcetype=50 and status=0 ";
/* 150 */     String insertSql = " insert into lkg_job (JOB_ID,JOB_NAME,ADMIN_ID,ADMIN_NAME,ADMIN_TIME) values(?,?,?,?,?)";
/*     */     try {
/* 152 */       sqlca = new Sqlca(new ConnectionEx());
/* 153 */       sqlca.execute(selectSql);
/* 154 */       con.setAutoCommit(false);
/* 155 */       pst = con.prepareStatement(insertSql);
/* 156 */       boolean isJobAdminExist = false;
/* 157 */       while (sqlca.next()) {
/* 158 */         if (this.adminJobId.equals(sqlca.getString("ROLE_ID"))) {
/* 159 */           isJobAdminExist = true;
/*     */         }
/* 161 */         pst.setString(1, sqlca.getString("ROLE_ID"));
/* 162 */         pst.setString(2, sqlca.getString("ROLE_NAME"));
/* 163 */         pst.setString(3, this.adminId);
/* 164 */         pst.setString(4, this.adminName);
/* 165 */         pst.setString(5, DateUtil.getFormatCurrentTime("yyyyMMddHHmmss"));
/* 166 */         pst.addBatch();
/*     */       }
/* 168 */       if (!isJobAdminExist) {
/* 169 */         pst.setString(1, this.adminJobId);
/* 170 */         pst.setString(2, this.adminName);
/* 171 */         pst.setString(3, this.adminId);
/* 172 */         pst.setString(4, this.adminName);
/* 173 */         pst.setString(5, DateUtil.getFormatCurrentTime("yyyyMMddHHmmss"));
/* 174 */         pst.addBatch();
/*     */       }
/* 176 */       pst.executeBatch();
/* 177 */       pst.clearBatch();
/* 178 */       con.commit();
/*     */ 
/* 186 */       if (null != pst)
/*     */         try {
/* 188 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 192 */       if (null != con)
/*     */         try {
/* 194 */           con.setAutoCommit(true);
/* 195 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 199 */       if (null != sqlca)
/* 200 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       try
/*     */       {
/* 181 */         con.rollback();
/*     */       } catch (SQLException e1) {
/*     */       }
/* 184 */       throw new RuntimeException(e);
/*     */     } finally {
/* 186 */       if (null != pst)
/*     */         try {
/* 188 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 192 */       if (null != con)
/*     */         try {
/* 194 */           con.setAutoCommit(true);
/* 195 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 199 */       if (null != sqlca) {
/* 200 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 203 */     this.log.info("syncRoleInfo  sync end---------------");
/*     */   }
/*     */ 
/*     */   public void syncUserCity() {
/* 207 */     this.log.info("syncUserCity  sync start------lkg_param_area---------");
/* 208 */     syncCity();
/* 209 */     syncCounty();
/* 210 */     syncDept();
/* 211 */     if (StringUtils.isNotBlank(this.townsDmTypeCode)) {
/* 212 */       syncTowns();
/*     */     }
/* 214 */     if (StringUtils.isNotBlank(this.businessHallDmTypeCode)) {
/* 215 */       syncBusinessHall();
/*     */     }
/* 217 */     this.log.info("syncUserCity() sync end---------------");
/*     */   }
/*     */ 
/*     */   public void syncUserCityRight()
/*     */   {
/* 226 */     this.log.info("syncUserCityRight  sync start-------LKG_STAFF_SCOPE--------");
/* 227 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 228 */     Sqlca sqlca = null;
/*     */     try {
/* 230 */       String sql = " INSERT INTO LKG_STAFF_SCOPE (STAFF_ID,PROV_SCOPE,CITY_SCOPE,COUNTRY_SCOPE,AREA_SCOPE,  SUB1_AREA_SCOPE,SUB2_AREA_SCOPE,ADMIN_ID,ADMIN_NAME,ADMIN_TIME)  SELECT LS.STAFF_ID,LS.PROV_ID,LS.CITY_ID,LS.COUNTRY_ID,LS.AREA_ID , LS.SUB1_AREA_ID,LS.SUB2_AREA_ID,'" + this.adminId + "','" + this.adminName + "'," + " '" + DateUtil.getFormatCurrentTime("yyyyMMddHHmmss") + "' FROM LKG_STAFF LS ";
/*     */ 
/* 241 */       sqlca = new Sqlca(con);
/* 242 */       sqlca.execute(sql);
/*     */ 
/* 246 */       if (null != con)
/*     */         try {
/* 248 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 252 */       if (null != sqlca)
/* 253 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 244 */       throw new RuntimeException(e);
/*     */     } finally {
/* 246 */       if (null != con)
/*     */         try {
/* 248 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 252 */       if (null != sqlca) {
/* 253 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 256 */     this.log.info("syncUserCityRight  sync end---------------");
/*     */   }
/*     */ 
/*     */   public void syncUserInfo()
/*     */   {
/* 266 */     this.log.info("syncUserInfo  sync start-----LKG_STAFF----------");
/* 267 */     Sqlca sqlca = null;
/* 268 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 269 */     PreparedStatement pst = null;
/* 270 */     ResultSet rs = null;
/*     */     try {
/* 272 */       String selectSql = " SELECT LPA.CITY_ID,LPA.COUNTRY_ID,LPA.AREA_ID, LPA.SUB1_AREA_ID,LPA.SUB2_AREA_ID FROM LKG_PARAM_AREA LPA ";
/*     */ 
/* 274 */       pst = con.prepareStatement(selectSql);
/* 275 */       rs = pst.executeQuery();
/* 276 */       Map map = new HashMap();
/* 277 */       while (rs.next()) {
/* 278 */         String cityId = rs.getString("CITY_ID");
/* 279 */         String countryId = rs.getString("COUNTRY_ID");
/* 280 */         String areaId = rs.getString("AREA_ID");
/* 281 */         String sub1AreaId = rs.getString("SUB1_AREA_ID");
/* 282 */         String sub2AreaId = rs.getString("SUB2_AREA_ID");
/* 283 */         LkgParamArea lpa = new LkgParamArea();
/* 284 */         lpa.setCityId(cityId);
/* 285 */         if (this.countyIdDefault.equals(countryId)) {
/* 286 */           lpa.setCountryId(this.countyIdDefault);
/* 287 */           lpa.setAreaId(this.deptIdDefault);
/* 288 */           lpa.setSub1AreaId(this.townsIdDefault);
/* 289 */           lpa.setSub2AreaId(this.businessHallIdDefault);
/* 290 */           map.put(cityId, lpa);
/*     */         }
/* 292 */         if ((!this.countyIdDefault.equals(countryId)) && (this.deptIdDefault.equals(areaId))) {
/* 293 */           lpa.setCountryId(countryId);
/* 294 */           lpa.setAreaId(this.deptIdDefault);
/* 295 */           lpa.setSub1AreaId(this.townsIdDefault);
/* 296 */           lpa.setSub2AreaId(this.businessHallIdDefault);
/* 297 */           map.put(countryId, lpa);
/*     */         }
/* 299 */         if ((!this.deptIdDefault.equals(areaId)) && (this.townsIdDefault.equals(sub1AreaId))) {
/* 300 */           lpa.setCountryId(countryId);
/* 301 */           lpa.setAreaId(areaId);
/* 302 */           lpa.setSub1AreaId(this.townsIdDefault);
/* 303 */           lpa.setSub2AreaId(this.businessHallIdDefault);
/* 304 */           map.put(areaId, lpa);
/*     */         }
/* 306 */         if ((!this.townsIdDefault.equals(sub1AreaId)) && (this.businessHallIdDefault.equals(sub2AreaId))) {
/* 307 */           lpa.setCountryId(countryId);
/* 308 */           lpa.setAreaId(areaId);
/* 309 */           lpa.setSub1AreaId(sub1AreaId);
/* 310 */           lpa.setSub2AreaId(this.businessHallIdDefault);
/* 311 */           map.put(sub1AreaId, lpa);
/*     */         }
/* 313 */         if (!this.businessHallIdDefault.equals(sub2AreaId)) {
/* 314 */           lpa.setCountryId(countryId);
/* 315 */           lpa.setAreaId(areaId);
/* 316 */           lpa.setSub1AreaId(sub1AreaId);
/* 317 */           lpa.setSub2AreaId(sub2AreaId);
/* 318 */           map.put(sub2AreaId, lpa);
/*     */         }
/*     */       }
/*     */ 
/* 322 */       selectSql = " SELECT UU.USERID, UU.CITYID, UU.USERNAME, UU.MOBILEPHONE, UU.EMAIL ,UC.DM_TYPE_CODE  FROM USER_USER UU,USER_CITY UC WHERE UU.CITYID=UC.CITYID ";
/*     */ 
/* 324 */       sqlca = new Sqlca(new ConnectionEx());
/* 325 */       sqlca.execute(selectSql);
/* 326 */       con.setAutoCommit(false);
/* 327 */       String insertSql = " INSERT INTO LKG_STAFF (STAFF_ID,STAFF_NAME,PROV_ID,PHONE,EMAIL,CITY_ID,COUNTRY_ID, AREA_ID,SUB1_AREA_ID,SUB2_AREA_ID,ADMIN_ID,ADMIN_NAME,ADMIN_TIME) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
/*     */ 
/* 329 */       pst = con.prepareStatement(insertSql);
/* 330 */       boolean isExistUserID = false;
/* 331 */       while (sqlca.next()) {
/* 332 */         if (this.adminId.equals(sqlca.getString("USERID").toUpperCase())) {
/* 333 */           isExistUserID = true;
/*     */         }
/* 335 */         pst.setString(1, sqlca.getString("USERID").toUpperCase());
/* 336 */         pst.setString(2, sqlca.getString("USERNAME"));
/* 337 */         pst.setString(3, this.provId);
/* 338 */         pst.setString(4, sqlca.getString("MOBILEPHONE"));
/* 339 */         pst.setString(5, sqlca.getString("EMAIL"));
/* 340 */         pst.setString(6, sqlca.getString("CITYID"));
/* 341 */         LkgParamArea lpa = (LkgParamArea)map.get(sqlca.getString("CITYID"));
/* 342 */         if (null != lpa) {
/* 343 */           pst.setString(7, lpa.getCountryId());
/* 344 */           pst.setString(8, lpa.getAreaId());
/* 345 */           pst.setString(9, lpa.getSub1AreaId());
/* 346 */           pst.setString(10, lpa.getSub2AreaId());
/*     */         } else {
/* 348 */           pst.setString(7, this.countyIdDefault);
/* 349 */           pst.setString(8, this.deptIdDefault);
/* 350 */           pst.setString(9, this.townsIdDefault);
/* 351 */           pst.setString(10, this.businessHallIdDefault);
/*     */         }
/* 353 */         pst.setString(11, this.adminId);
/* 354 */         pst.setString(12, this.adminName);
/* 355 */         pst.setString(13, DateUtil.getFormatCurrentTime("yyyyMMddHHmmss"));
/* 356 */         pst.addBatch();
/*     */       }
/* 358 */       if (!isExistUserID) {
/* 359 */         pst.setString(1, this.adminId);
/* 360 */         pst.setString(2, this.adminName);
/* 361 */         pst.setString(3, this.provId);
/* 362 */         pst.setString(4, "");
/* 363 */         pst.setString(5, "");
/* 364 */         pst.setString(6, this.cityIdDefault);
/* 365 */         pst.setString(7, this.countyIdDefault);
/* 366 */         pst.setString(8, this.deptIdDefault);
/* 367 */         pst.setString(9, this.townsIdDefault);
/* 368 */         pst.setString(10, this.businessHallIdDefault);
/* 369 */         pst.setString(11, this.adminId);
/* 370 */         pst.setString(12, this.adminName);
/* 371 */         pst.setString(13, DateUtil.getFormatCurrentTime("yyyyMMddHHmmss"));
/* 372 */         pst.addBatch();
/*     */       }
/* 374 */       pst.executeBatch();
/* 375 */       pst.clearBatch();
/* 376 */       con.commit();
/*     */ 
/* 384 */       if (null != rs)
/*     */         try {
/* 386 */           rs.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 390 */       if (null != pst)
/*     */         try {
/* 392 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 396 */       if (null != con)
/*     */         try {
/* 398 */           con.setAutoCommit(true);
/* 399 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 403 */       if (null != sqlca)
/* 404 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       try
/*     */       {
/* 379 */         con.rollback();
/*     */       } catch (SQLException e1) {
/*     */       }
/* 382 */       throw new RuntimeException(e);
/*     */     } finally {
/* 384 */       if (null != rs)
/*     */         try {
/* 386 */           rs.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 390 */       if (null != pst)
/*     */         try {
/* 392 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 396 */       if (null != con)
/*     */         try {
/* 398 */           con.setAutoCommit(true);
/* 399 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 403 */       if (null != sqlca) {
/* 404 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 407 */     this.log.info("syncUserInfo  sync end---------------");
/*     */   }
/*     */ 
/*     */   public void syncUserRoleMap() {
/* 411 */     this.log.info("syncUserRoleMap  sync start-------lkg_staff_job--------");
/* 412 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 413 */     PreparedStatement pst = null;
/* 414 */     String insertSql = " insert into lkg_staff_job (STAFF_ID,JOB_ID,ADMIN_ID,ADMIN_NAME,ADMIN_TIME) values(?,?,?,?,?)";
/*     */     try {
/* 416 */       con.setAutoCommit(false);
/* 417 */       pst = con.prepareStatement(insertSql);
/* 418 */       Map userRoleMap = new HashMap();
/* 419 */       userRoleMap = syncUserRole();
/* 420 */       syncUserGroupRole(userRoleMap);
/* 421 */       Iterator it = userRoleMap.entrySet().iterator();
/*     */       String userId;
/* 422 */       while (it.hasNext()) {
/* 423 */         Map.Entry entry = (Map.Entry)it.next();
/* 424 */         userId = (String)entry.getKey();
/* 425 */         Set roleSet = (Set)entry.getValue();
/* 426 */         for (String role : roleSet) {
/* 427 */           pst.setString(1, userId.toUpperCase());
/* 428 */           pst.setString(2, role);
/* 429 */           pst.setString(3, this.adminId);
/* 430 */           pst.setString(4, this.adminName);
/* 431 */           pst.setString(5, DateUtil.getFormatCurrentTime("yyyyMMddHHmmss"));
/* 432 */           pst.addBatch();
/*     */         }
/*     */       }
/*     */ 
/* 436 */       pst.setString(1, this.adminId);
/* 437 */       pst.setString(2, this.adminJobId);
/* 438 */       pst.setString(3, this.adminId);
/* 439 */       pst.setString(4, this.adminName);
/* 440 */       pst.setString(5, DateUtil.getFormatCurrentTime("yyyyMMddHHmmss"));
/* 441 */       pst.addBatch();
/* 442 */       pst.executeBatch();
/* 443 */       pst.clearBatch();
/* 444 */       con.commit();
/*     */ 
/* 452 */       if (null != pst)
/*     */         try {
/* 454 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 458 */       if (null != con)
/*     */         try {
/* 460 */           con.setAutoCommit(true);
/* 461 */           con.close();
/*     */         }
/*     */         catch (SQLException e)
/*     */         {
/*     */         }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       try
/*     */       {
/* 447 */         con.rollback();
/*     */       } catch (SQLException e1) {
/*     */       }
/* 450 */       throw new RuntimeException(e);
/*     */     } finally {
/* 452 */       if (null != pst)
/*     */         try {
/* 454 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 458 */       if (null != con)
/*     */         try {
/* 460 */           con.setAutoCommit(true);
/* 461 */           con.close();
/*     */         }
/*     */         catch (SQLException e)
/*     */         {
/*     */         }
/*     */     }
/* 467 */     this.log.info("syncUserRoleMap  sync end---------------");
/*     */   }
/*     */   private Map<String, Set<String>> syncUserRole() {
/* 470 */     this.log.info("syncUserRole  sync start-------lkg_staff_job--------");
/* 471 */     Map userRoleMap = new HashMap();
/* 472 */     Sqlca sqlca = null;
/* 473 */     String selectSql = " SELECT URM.USERID,URM.ROLE_ID FROM USER_ROLE_MAP URM,USER_ROLE UR WHERE URM.ROLE_ID=UR.ROLE_ID AND UR.RESOURCETYPE=50 ";
/*     */     try {
/* 475 */       sqlca = new Sqlca(new ConnectionEx());
/* 476 */       sqlca.execute(selectSql);
/* 477 */       while (sqlca.next()) {
/* 478 */         String userId = sqlca.getString("USERID");
/* 479 */         String roleId = sqlca.getString("ROLE_ID");
/* 480 */         Set roleSet = new HashSet();
/* 481 */         if (null != userRoleMap.get(userId)) {
/* 482 */           roleSet = (Set)userRoleMap.get(userId);
/* 483 */           roleSet.add(roleId);
/* 484 */           userRoleMap.put(userId, roleSet);
/*     */         } else {
/* 486 */           roleSet.add(roleId);
/* 487 */           userRoleMap.put(userId, roleSet);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 494 */       if (null != sqlca)
/* 495 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 492 */       throw new RuntimeException(e);
/*     */     } finally {
/* 494 */       if (null != sqlca) {
/* 495 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 498 */     this.log.info("syncUserRole  sync end---------------");
/* 499 */     return userRoleMap;
/*     */   }
/*     */ 
/*     */   private void syncUserGroupRole(Map<String, Set<String>> userRoleMap)
/*     */   {
/* 507 */     this.log.info("syncUserGroupRole  sync start-------lkg_staff_job--------");
/* 508 */     Sqlca sqlca = null;
/* 509 */     String selectSql = " SELECT UGM.USERID,SS.ROLE_ID FROM  (SELECT GRM.GROUP_ID, GRM.ROLE_ID FROM GROUP_ROLE_MAP GRM,USER_ROLE UR  WHERE GRM.ROLE_ID=UR.ROLE_ID AND UR.RESOURCETYPE=50)SS  ,USER_GROUP_MAP UGM WHERE SS.GROUP_ID=UGM.GROUP_ID ";
/*     */     try
/*     */     {
/* 514 */       sqlca = new Sqlca(new ConnectionEx());
/* 515 */       sqlca.execute(selectSql);
/* 516 */       while (sqlca.next()) {
/* 517 */         String userId = sqlca.getString("USERID");
/* 518 */         String roleId = sqlca.getString("ROLE_ID");
/* 519 */         Set roleSet = new HashSet();
/* 520 */         if (null != userRoleMap.get(userId)) {
/* 521 */           roleSet = (Set)userRoleMap.get(userId);
/* 522 */           roleSet.add(roleId);
/* 523 */           userRoleMap.put(userId, roleSet);
/*     */         } else {
/* 525 */           roleSet.add(roleId);
/* 526 */           userRoleMap.put(userId, roleSet);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 533 */       if (null != sqlca)
/* 534 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 531 */       throw new RuntimeException(e);
/*     */     } finally {
/* 533 */       if (null != sqlca) {
/* 534 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 537 */     this.log.info("syncUserGroupRole  sync end---------------");
/*     */   }
/*     */ 
/*     */   private void syncCity() {
/* 541 */     this.log.info("syncCity  sync start---------------");
/* 542 */     Sqlca sqlca = null;
/* 543 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 544 */     PreparedStatement pst = null;
/* 545 */     String selectSql = " SELECT UC.CITYID,UC.CITYNAME FROM USER_CITY UC WHERE UC.DM_TYPE_CODE='CITY' ";
/* 546 */     String insertSql = " insert into lkg_param_area (PROV_ID,CITY_ID,COUNTRY_ID,AREA_ID,SUB1_AREA_ID,SUB2_AREA_ID,PROV_NAME, CITY_NAME,COUNTRY_NAME,AREA_NAME,SUB1_AREA_NAME,SUB2_AREA_NAME ) values(?,?,?,?,?,?,?,?,?,?,?,?)";
/*     */     try
/*     */     {
/* 549 */       sqlca = new Sqlca(new ConnectionEx());
/* 550 */       sqlca.execute(selectSql);
/* 551 */       con.setAutoCommit(false);
/* 552 */       pst = con.prepareStatement(insertSql);
/* 553 */       while (sqlca.next()) {
/* 554 */         pst.setString(1, this.provId);
/* 555 */         pst.setString(2, sqlca.getString("CITYID"));
/* 556 */         pst.setString(3, this.countyIdDefault);
/* 557 */         pst.setString(4, this.deptIdDefault);
/* 558 */         pst.setString(5, this.townsIdDefault);
/* 559 */         pst.setString(6, this.businessHallIdDefault);
/* 560 */         pst.setString(7, this.provName);
/* 561 */         pst.setString(8, sqlca.getString("CITYNAME"));
/* 562 */         pst.setString(9, this.countyNameDefault);
/* 563 */         pst.setString(10, this.deptNameDefault);
/* 564 */         pst.setString(11, this.townsNameDefault);
/* 565 */         pst.setString(12, this.businessHallNameDefault);
/* 566 */         pst.addBatch();
/*     */       }
/* 568 */       pst.executeBatch();
/* 569 */       pst.clearBatch();
/* 570 */       con.commit();
/*     */ 
/* 578 */       if (null != pst)
/*     */         try {
/* 580 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 584 */       if (null != con)
/*     */         try {
/* 586 */           con.setAutoCommit(true);
/* 587 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 591 */       if (null != sqlca)
/* 592 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       try
/*     */       {
/* 573 */         con.rollback();
/*     */       } catch (SQLException e1) {
/*     */       }
/* 576 */       throw new RuntimeException(e);
/*     */     } finally {
/* 578 */       if (null != pst)
/*     */         try {
/* 580 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 584 */       if (null != con)
/*     */         try {
/* 586 */           con.setAutoCommit(true);
/* 587 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 591 */       if (null != sqlca) {
/* 592 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 595 */     this.log.info("syncCity  sync end---------------");
/*     */   }
/*     */   private void syncCounty() {
/* 598 */     this.log.info("syncCounty  sync start---------------");
/* 599 */     Sqlca sqlca = null;
/* 600 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 601 */     PreparedStatement pst = null;
/* 602 */     String selectSql = " SELECT UC1.CITYID AS COUNTRY_ID,UC1.CITYNAME AS COUNTRY_NAME, UC1.PARENTID AS CITY_ID,UC2.CITYNAME AS CITY_NAME  FROM USER_CITY UC1,USER_CITY UC2 WHERE UC1.DM_TYPE_CODE='COUNTY' AND UC1.PARENTID=UC2.CITYID";
/*     */ 
/* 606 */     String insertSql = " insert into lkg_param_area (PROV_ID,CITY_ID,COUNTRY_ID,AREA_ID,SUB1_AREA_ID,SUB2_AREA_ID,PROV_NAME, CITY_NAME,COUNTRY_NAME,AREA_NAME,SUB1_AREA_NAME,SUB2_AREA_NAME ) values(?,?,?,?,?,?,?,?,?,?,?,?)";
/*     */     try
/*     */     {
/* 609 */       sqlca = new Sqlca(new ConnectionEx());
/* 610 */       sqlca.execute(selectSql);
/* 611 */       con.setAutoCommit(false);
/* 612 */       pst = con.prepareStatement(insertSql);
/* 613 */       while (sqlca.next()) {
/* 614 */         pst.setString(1, this.provId);
/* 615 */         pst.setString(2, sqlca.getString("CITY_ID"));
/* 616 */         pst.setString(3, sqlca.getString("COUNTRY_ID"));
/* 617 */         pst.setString(4, this.deptIdDefault);
/* 618 */         pst.setString(5, this.townsIdDefault);
/* 619 */         pst.setString(6, this.businessHallIdDefault);
/* 620 */         pst.setString(7, this.provName);
/* 621 */         pst.setString(8, sqlca.getString("CITY_NAME"));
/* 622 */         pst.setString(9, sqlca.getString("COUNTRY_NAME"));
/* 623 */         pst.setString(10, this.deptNameDefault);
/* 624 */         pst.setString(11, this.townsNameDefault);
/* 625 */         pst.setString(12, this.businessHallNameDefault);
/* 626 */         pst.addBatch();
/*     */       }
/* 628 */       pst.executeBatch();
/* 629 */       pst.clearBatch();
/* 630 */       con.commit();
/*     */ 
/* 638 */       if (null != pst)
/*     */         try {
/* 640 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 644 */       if (null != con)
/*     */         try {
/* 646 */           con.setAutoCommit(true);
/* 647 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 651 */       if (null != sqlca)
/* 652 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       try
/*     */       {
/* 633 */         con.rollback();
/*     */       } catch (SQLException e1) {
/*     */       }
/* 636 */       throw new RuntimeException(e);
/*     */     } finally {
/* 638 */       if (null != pst)
/*     */         try {
/* 640 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 644 */       if (null != con)
/*     */         try {
/* 646 */           con.setAutoCommit(true);
/* 647 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 651 */       if (null != sqlca) {
/* 652 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 655 */     this.log.info("syncCounty  sync end---------------");
/*     */   }
/*     */   private void syncDept() {
/* 658 */     this.log.info("syncDept  sync start---------------");
/* 659 */     Sqlca sqlca = null;
/* 660 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 661 */     PreparedStatement pst = null;
/* 662 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 665 */       String sql = " SELECT LPA.CITY_ID,LPA.COUNTRY_ID,LPA.CITY_NAME,LPA.COUNTRY_NAME  FROM LKG_PARAM_AREA LPA WHERE LPA.COUNTRY_ID!=? AND LPA.AREA_ID=? ";
/*     */ 
/* 667 */       pst = con.prepareStatement(sql);
/* 668 */       pst.setString(1, this.countyIdDefault);
/* 669 */       pst.setString(2, this.deptIdDefault);
/* 670 */       rs = pst.executeQuery();
/* 671 */       Map map = new HashMap();
/* 672 */       while (rs.next()) {
/* 673 */         LkgParamArea lpa = new LkgParamArea();
/* 674 */         lpa.setCityId(rs.getString("CITY_ID"));
/* 675 */         lpa.setCountryId(rs.getString("COUNTRY_ID"));
/* 676 */         lpa.setCityName(rs.getString("CITY_NAME"));
/* 677 */         lpa.setCountryName(rs.getString("COUNTRY_NAME"));
/* 678 */         map.put(rs.getString("COUNTRY_ID"), lpa);
/*     */       }
/*     */ 
/* 681 */       sqlca = new Sqlca(new ConnectionEx());
/* 682 */       String selectSql = " SELECT UC.CITYID,UC.CITYNAME,UC.PARENTID FROM USER_CITY UC WHERE UC.DM_TYPE_CODE='DEPT'";
/* 683 */       sqlca.execute(selectSql);
/*     */ 
/* 685 */       String insertSql = " insert into lkg_param_area (PROV_ID,CITY_ID,COUNTRY_ID,AREA_ID,SUB1_AREA_ID,SUB2_AREA_ID,PROV_NAME, CITY_NAME,COUNTRY_NAME,AREA_NAME,SUB1_AREA_NAME,SUB2_AREA_NAME ) values(?,?,?,?,?,?,?,?,?,?,?,?)";
/*     */ 
/* 687 */       con.setAutoCommit(false);
/* 688 */       pst = con.prepareStatement(insertSql);
/* 689 */       while (sqlca.next()) {
/* 690 */         String cityId = sqlca.getString("CITYID");
/* 691 */         String cityName = sqlca.getString("CITYNAME");
/* 692 */         String parentId = sqlca.getString("PARENTID");
/* 693 */         LkgParamArea lkgParamArea = (LkgParamArea)map.get(parentId);
/* 694 */         pst.setString(1, this.provId);
/* 695 */         pst.setString(2, lkgParamArea.getCityId());
/* 696 */         pst.setString(3, parentId);
/* 697 */         pst.setString(4, cityId);
/* 698 */         pst.setString(5, this.townsIdDefault);
/* 699 */         pst.setString(6, this.businessHallIdDefault);
/* 700 */         pst.setString(7, this.provName);
/* 701 */         pst.setString(8, lkgParamArea.getCityName());
/* 702 */         pst.setString(9, lkgParamArea.getCountryName());
/* 703 */         pst.setString(10, cityName);
/* 704 */         pst.setString(11, this.townsNameDefault);
/* 705 */         pst.setString(12, this.businessHallNameDefault);
/* 706 */         pst.addBatch();
/*     */       }
/* 708 */       pst.executeBatch();
/* 709 */       pst.clearBatch();
/* 710 */       con.commit();
/*     */ 
/* 714 */       if (null != rs)
/*     */         try {
/* 716 */           rs.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 720 */       if (null != pst)
/*     */         try {
/* 722 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 726 */       if (null != con)
/*     */         try {
/* 728 */           con.setAutoCommit(true);
/* 729 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 733 */       if (null != sqlca)
/* 734 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 712 */       throw new RuntimeException(e);
/*     */     } finally {
/* 714 */       if (null != rs)
/*     */         try {
/* 716 */           rs.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 720 */       if (null != pst)
/*     */         try {
/* 722 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 726 */       if (null != con)
/*     */         try {
/* 728 */           con.setAutoCommit(true);
/* 729 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 733 */       if (null != sqlca) {
/* 734 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 737 */     this.log.info("syncDept  sync end---------------");
/*     */   }
/*     */   private void syncTowns() {
/* 740 */     this.log.info("syncTowns  sync start---------------");
/* 741 */     Sqlca sqlca = null;
/* 742 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 743 */     PreparedStatement pst = null;
/* 744 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 747 */       String sql = " SELECT LPA.CITY_ID,LPA.COUNTRY_ID,LPA.CITY_NAME,LPA.COUNTRY_NAME,  LPA.AREA_ID,LPA.AREA_NAME  FROM LKG_PARAM_AREA LPA WHERE LPA.AREA_ID!=? AND LPA.SUB1_AREA_ID=? ";
/*     */ 
/* 750 */       pst = con.prepareStatement(sql);
/* 751 */       pst.setString(1, this.deptIdDefault);
/* 752 */       pst.setString(2, this.townsIdDefault);
/* 753 */       rs = pst.executeQuery();
/* 754 */       Map map = new HashMap();
/* 755 */       while (rs.next()) {
/* 756 */         LkgParamArea lpa = new LkgParamArea();
/* 757 */         lpa.setCityId(rs.getString("CITY_ID"));
/* 758 */         lpa.setCountryId(rs.getString("COUNTRY_ID"));
/* 759 */         lpa.setCityName(rs.getString("CITY_NAME"));
/* 760 */         lpa.setCountryName(rs.getString("COUNTRY_NAME"));
/* 761 */         lpa.setAreaId(rs.getString("AREA_ID"));
/* 762 */         lpa.setAreaName(rs.getString("AREA_NAME"));
/* 763 */         map.put(rs.getString("AREA_ID"), lpa);
/*     */       }
/*     */ 
/* 766 */       sqlca = new Sqlca(new ConnectionEx());
/* 767 */       String selectSql = " SELECT UC.CITYID,UC.CITYNAME,UC.PARENTID FROM USER_CITY UC WHERE UC.DM_TYPE_CODE='" + this.townsDmTypeCode + "'";
/* 768 */       sqlca.execute(selectSql);
/*     */ 
/* 770 */       String insertSql = " insert into lkg_param_area (PROV_ID,CITY_ID,COUNTRY_ID,AREA_ID,SUB1_AREA_ID,SUB2_AREA_ID,PROV_NAME, CITY_NAME,COUNTRY_NAME,AREA_NAME,SUB1_AREA_NAME,SUB2_AREA_NAME ) values(?,?,?,?,?,?,?,?,?,?,?,?)";
/*     */ 
/* 772 */       con.setAutoCommit(false);
/* 773 */       pst = con.prepareStatement(insertSql);
/* 774 */       while (sqlca.next()) {
/* 775 */         String cityId = sqlca.getString("CITYID");
/* 776 */         String cityName = sqlca.getString("CITYNAME");
/* 777 */         String parentId = sqlca.getString("PARENTID");
/* 778 */         LkgParamArea lkgParamArea = (LkgParamArea)map.get(parentId);
/* 779 */         pst.setString(1, this.provId);
/* 780 */         pst.setString(2, lkgParamArea.getCityId());
/* 781 */         pst.setString(3, lkgParamArea.getCountryId());
/* 782 */         pst.setString(4, parentId);
/* 783 */         pst.setString(5, cityId);
/* 784 */         pst.setString(6, this.businessHallIdDefault);
/* 785 */         pst.setString(7, this.provName);
/* 786 */         pst.setString(8, lkgParamArea.getCityName());
/* 787 */         pst.setString(9, lkgParamArea.getCountryName());
/* 788 */         pst.setString(10, lkgParamArea.getAreaName());
/* 789 */         pst.setString(11, cityName);
/* 790 */         pst.setString(12, this.businessHallNameDefault);
/* 791 */         pst.addBatch();
/*     */       }
/* 793 */       pst.executeBatch();
/* 794 */       pst.clearBatch();
/* 795 */       con.commit();
/*     */ 
/* 799 */       if (null != rs)
/*     */         try {
/* 801 */           rs.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 805 */       if (null != pst)
/*     */         try {
/* 807 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 811 */       if (null != con)
/*     */         try {
/* 813 */           con.setAutoCommit(true);
/* 814 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 818 */       if (null != sqlca)
/* 819 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 797 */       throw new RuntimeException(e);
/*     */     } finally {
/* 799 */       if (null != rs)
/*     */         try {
/* 801 */           rs.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 805 */       if (null != pst)
/*     */         try {
/* 807 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 811 */       if (null != con)
/*     */         try {
/* 813 */           con.setAutoCommit(true);
/* 814 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 818 */       if (null != sqlca) {
/* 819 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 822 */     this.log.info("syncTowns  sync end---------------");
/*     */   }
/*     */   private void syncBusinessHall() {
/* 825 */     this.log.info("syncBusinessHall  sync start---------------");
/* 826 */     Sqlca sqlca = null;
/* 827 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/* 828 */     PreparedStatement pst = null;
/* 829 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 832 */       String sql = " SELECT LPA.CITY_ID,LPA.COUNTRY_ID,LPA.CITY_NAME,LPA.COUNTRY_NAME,  LPA.AREA_ID,LPA.AREA_NAME,LPA.SUB1_AREA_ID,LPA.SUB1_AREA_NAME  FROM LKG_PARAM_AREA LPA WHERE LPA.SUB1_AREA_ID!=? AND LPA.SUB2_AREA_ID=? ";
/*     */ 
/* 835 */       pst = con.prepareStatement(sql);
/* 836 */       pst.setString(1, this.townsIdDefault);
/* 837 */       pst.setString(2, this.businessHallIdDefault);
/* 838 */       rs = pst.executeQuery();
/* 839 */       Map map = new HashMap();
/* 840 */       while (rs.next()) {
/* 841 */         LkgParamArea lpa = new LkgParamArea();
/* 842 */         lpa.setCityId(rs.getString("CITY_ID"));
/* 843 */         lpa.setCountryId(rs.getString("COUNTRY_ID"));
/* 844 */         lpa.setCityName(rs.getString("CITY_NAME"));
/* 845 */         lpa.setCountryName(rs.getString("COUNTRY_NAME"));
/* 846 */         lpa.setAreaId(rs.getString("AREA_ID"));
/* 847 */         lpa.setAreaName(rs.getString("AREA_NAME"));
/* 848 */         lpa.setSub1AreaId(rs.getString("SUB1_AREA_ID"));
/* 849 */         lpa.setSub1AreaName(rs.getString("SUB1_AREA_NAME"));
/* 850 */         map.put(rs.getString("SUB1_AREA_ID"), lpa);
/*     */       }
/*     */ 
/* 853 */       sqlca = new Sqlca(new ConnectionEx());
/* 854 */       String selectSql = " SELECT UC.CITYID,UC.CITYNAME,UC.PARENTID FROM USER_CITY UC WHERE UC.DM_TYPE_CODE='" + this.businessHallDmTypeCode + "'";
/* 855 */       sqlca.execute(selectSql);
/*     */ 
/* 857 */       String insertSql = " insert into lkg_param_area (PROV_ID,CITY_ID,COUNTRY_ID,AREA_ID,SUB1_AREA_ID,SUB2_AREA_ID,PROV_NAME, CITY_NAME,COUNTRY_NAME,AREA_NAME,SUB1_AREA_NAME,SUB2_AREA_NAME ) values(?,?,?,?,?,?,?,?,?,?,?,?)";
/*     */ 
/* 859 */       con.setAutoCommit(false);
/* 860 */       pst = con.prepareStatement(insertSql);
/* 861 */       while (sqlca.next()) {
/* 862 */         String cityId = sqlca.getString("CITYID");
/* 863 */         String cityName = sqlca.getString("CITYNAME");
/* 864 */         String parentId = sqlca.getString("PARENTID");
/* 865 */         LkgParamArea lkgParamArea = (LkgParamArea)map.get(parentId);
/* 866 */         pst.setString(1, this.provId);
/* 867 */         pst.setString(2, lkgParamArea.getCityId());
/* 868 */         pst.setString(3, lkgParamArea.getCountryId());
/* 869 */         pst.setString(4, lkgParamArea.getAreaId());
/* 870 */         pst.setString(5, parentId);
/* 871 */         pst.setString(6, cityId);
/* 872 */         pst.setString(7, this.provName);
/* 873 */         pst.setString(8, lkgParamArea.getCityName());
/* 874 */         pst.setString(9, lkgParamArea.getCountryName());
/* 875 */         pst.setString(10, lkgParamArea.getAreaName());
/* 876 */         pst.setString(11, lkgParamArea.getSub1AreaName());
/* 877 */         pst.setString(12, cityName);
/* 878 */         pst.addBatch();
/*     */       }
/* 880 */       pst.executeBatch();
/* 881 */       pst.clearBatch();
/* 882 */       con.commit();
/*     */ 
/* 886 */       if (null != rs)
/*     */         try {
/* 888 */           rs.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 892 */       if (null != pst)
/*     */         try {
/* 894 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 898 */       if (null != con)
/*     */         try {
/* 900 */           con.setAutoCommit(true);
/* 901 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 905 */       if (null != sqlca)
/* 906 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 884 */       throw new RuntimeException(e);
/*     */     } finally {
/* 886 */       if (null != rs)
/*     */         try {
/* 888 */           rs.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 892 */       if (null != pst)
/*     */         try {
/* 894 */           pst.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 898 */       if (null != con)
/*     */         try {
/* 900 */           con.setAutoCommit(true);
/* 901 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 905 */       if (null != sqlca) {
/* 906 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 909 */     this.log.info("syncBusinessHall  sync end---------------");
/*     */   }
/*     */ 
/*     */   public void deleteTableData() {
/* 913 */     this.log.info("deleteTableData   start---------------");
/* 914 */     Sqlca sqlca = null;
/* 915 */     Connection con = AiomniConnectionFactory.getInstance(this.jndiNJ).getConnection();
/*     */     try {
/* 917 */       sqlca = new Sqlca(con);
/* 918 */       String deleteSql = " DELETE FROM  LKG_STAFF";
/* 919 */       sqlca.execute(deleteSql);
/* 920 */       deleteSql = " DELETE FROM  LKG_JOB";
/* 921 */       sqlca.execute(deleteSql);
/* 922 */       deleteSql = " DELETE FROM  LKG_STAFF_JOB";
/* 923 */       sqlca.execute(deleteSql);
/* 924 */       deleteSql = " DELETE FROM  LKG_PARAM_AREA";
/* 925 */       sqlca.execute(deleteSql);
/* 926 */       deleteSql = " DELETE FROM  LKG_STAFF_SCOPE";
/* 927 */       sqlca.execute(deleteSql);
/* 928 */       deleteSql = " DELETE FROM  LKG_JOB_FUNC";
/* 929 */       sqlca.execute(deleteSql);
/* 930 */       deleteSql = " DELETE FROM  LKG_JOB_MANAGE";
/* 931 */       sqlca.execute(deleteSql);
/*     */ 
/* 935 */       if (null != con)
/*     */         try {
/* 937 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 941 */       if (null != sqlca)
/* 942 */         sqlca.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 933 */       throw new RuntimeException(e);
/*     */     } finally {
/* 935 */       if (null != con)
/*     */         try {
/* 937 */           con.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 941 */       if (null != sqlca) {
/* 942 */         sqlca.close();
/*     */       }
/*     */     }
/* 945 */     this.log.info("deleteTableData   end---------------");
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.fuse.dao.impl.PrivilegeSyncDao
 * JD-Core Version:    0.6.2
 */
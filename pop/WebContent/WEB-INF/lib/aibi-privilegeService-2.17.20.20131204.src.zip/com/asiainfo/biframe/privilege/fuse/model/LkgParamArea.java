/*     */ package com.asiainfo.biframe.privilege.fuse.model;
/*     */ 
/*     */ public class LkgParamArea
/*     */ {
/*     */   private String provId;
/*     */   private String cityId;
/*     */   private String countryId;
/*     */   private String areaId;
/*     */   private String sub1AreaId;
/*     */   private String sub2AreaId;
/*     */   private String provName;
/*     */   private String cityName;
/*     */   private String countryName;
/*     */   private String areaName;
/*     */   private String sub1AreaName;
/*     */   private String sub2AreaName;
/*     */ 
/*     */   public String getProvId()
/*     */   {
/*  20 */     return this.provId;
/*     */   }
/*     */ 
/*     */   public void setProvId(String provId) {
/*  24 */     this.provId = provId;
/*     */   }
/*     */ 
/*     */   public String getCityId() {
/*  28 */     return this.cityId;
/*     */   }
/*     */ 
/*     */   public void setCityId(String cityId) {
/*  32 */     this.cityId = cityId;
/*     */   }
/*     */ 
/*     */   public String getCountryId() {
/*  36 */     return this.countryId;
/*     */   }
/*     */ 
/*     */   public void setCountryId(String countryId) {
/*  40 */     this.countryId = countryId;
/*     */   }
/*     */ 
/*     */   public String getAreaId() {
/*  44 */     return this.areaId;
/*     */   }
/*     */ 
/*     */   public void setAreaId(String areaId) {
/*  48 */     this.areaId = areaId;
/*     */   }
/*     */ 
/*     */   public String getSub1AreaId() {
/*  52 */     return this.sub1AreaId;
/*     */   }
/*     */ 
/*     */   public void setSub1AreaId(String sub1AreaId) {
/*  56 */     this.sub1AreaId = sub1AreaId;
/*     */   }
/*     */ 
/*     */   public String getSub2AreaId() {
/*  60 */     return this.sub2AreaId;
/*     */   }
/*     */ 
/*     */   public void setSub2AreaId(String sub2AreaId) {
/*  64 */     this.sub2AreaId = sub2AreaId;
/*     */   }
/*     */ 
/*     */   public String getProvName() {
/*  68 */     return this.provName;
/*     */   }
/*     */ 
/*     */   public void setProvName(String provName) {
/*  72 */     this.provName = provName;
/*     */   }
/*     */ 
/*     */   public String getCityName() {
/*  76 */     return this.cityName;
/*     */   }
/*     */ 
/*     */   public void setCityName(String cityName) {
/*  80 */     this.cityName = cityName;
/*     */   }
/*     */ 
/*     */   public String getCountryName() {
/*  84 */     return this.countryName;
/*     */   }
/*     */ 
/*     */   public void setCountryName(String countryName) {
/*  88 */     this.countryName = countryName;
/*     */   }
/*     */ 
/*     */   public String getAreaName() {
/*  92 */     return this.areaName;
/*     */   }
/*     */ 
/*     */   public void setAreaName(String areaName) {
/*  96 */     this.areaName = areaName;
/*     */   }
/*     */ 
/*     */   public String getSub1AreaName() {
/* 100 */     return this.sub1AreaName;
/*     */   }
/*     */ 
/*     */   public void setSub1AreaName(String sub1AreaName) {
/* 104 */     this.sub1AreaName = sub1AreaName;
/*     */   }
/*     */ 
/*     */   public String getSub2AreaName() {
/* 108 */     return this.sub2AreaName;
/*     */   }
/*     */ 
/*     */   public void setSub2AreaName(String sub2AreaName) {
/* 112 */     this.sub2AreaName = sub2AreaName;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.fuse.model.LkgParamArea
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.fuse.service;

public abstract interface IPrivilegeSyncService
{
  public abstract void synData();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.fuse.service.IPrivilegeSyncService
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.fuse.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.fuse.service.IPrivilegeSyncService;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*     */ import org.springframework.jdbc.datasource.SimpleDriverDataSource;
/*     */ import org.springframework.mock.jndi.SimpleNamingContextBuilder;
/*     */ 
/*     */ public class PrivilegeSync
/*     */ {
/*  26 */   private static Logger log = Logger.getLogger(PrivilegeSync.class);
/*     */ 
/*     */   private static ClassLoader getClassLoader()
/*     */   {
/*  34 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*  35 */     if (cl == null) {
/*  36 */       cl = PrivilegeSync.class.getClassLoader();
/*     */     }
/*  38 */     return cl;
/*     */   }
/*     */ 
/*     */   public static Properties loadProperties(String location)
/*     */   {
/*  51 */     Properties ps = new Properties();
/*  52 */     if ((location != null) && (!"".equals(location))) {
/*  53 */       ClassLoader cl = getClassLoader();
/*  54 */       InputStream inStream = cl.getResourceAsStream(location);
/*  55 */       if (inStream == null)
/*  56 */         System.out.println("类路径下找不到文件:" + location);
/*     */       try
/*     */       {
/*  59 */         ps.load(inStream);
/*     */       } catch (IOException e) {
/*  61 */         e.printStackTrace();
/*     */       }
/*     */     }
/*  64 */     return ps;
/*     */   }
/*     */ 
/*     */   public static void initLog4j()
/*     */   {
/*  71 */     String log4jConfig = "config/aibi_core/log4j.properties";
/*  72 */     Properties ps = loadProperties(log4jConfig);
/*  73 */     PropertyConfigurator.configure(ps);
/*     */   }
/*     */ 
/*     */   public static void initLocaleProperties() {
/*  77 */     Locale locale = null;
/*  78 */     locale = new Locale("en");
/*  79 */     String filePath = "config.aibi_core.";
/*  80 */     String absolutePath = "config" + File.separator + "aibi_core" + File.separator;
/*     */ 
/*  82 */     File messageFile = new File(absolutePath + "core-appresources.properties");
/*     */ 
/*  84 */     if (messageFile.exists()) {
/*  85 */       LocaleUtil.addSysLocale("core", filePath, "core-appresources", ".properties", "en");
/*     */ 
/*  87 */       LocaleUtil.setLocale(locale);
/*     */     } else {
/*  89 */       log.warn("==init i18n message file failed, file [core-appresources] not exist!]");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initConfigProperties()
/*     */   {
/*     */     try
/*     */     {
/* 102 */       String confFilePath = "config/aibi_core/core.properties";
/* 103 */       Configure.getInstance().addConfFileName("ASIAINFO_PROPERTIES", confFilePath);
/*     */ 
/* 106 */       confFilePath = "config/aibi_privilegeService/privilege.properties";
/* 107 */       Configure.getInstance().addConfFileName("AIBI_PRIVILEGE_PROPERTIES", confFilePath);
/*     */     }
/*     */     catch (Exception e) {
/* 110 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void loadDataSource(JndiDataSource[] jndiDataSources)
/*     */   {
/* 123 */     if (jndiDataSources != null) {
/* 124 */       SimpleNamingContextBuilder builder = new SimpleNamingContextBuilder();
/* 125 */       for (int i = 0; i < jndiDataSources.length; i++) {
/* 126 */         SimpleDriverDataSource sds = new SimpleDriverDataSource();
/* 127 */         sds.setDriverClass(jndiDataSources[i].driverClass);
/* 128 */         sds.setUrl(jndiDataSources[i].url);
/* 129 */         sds.setUsername(jndiDataSources[i].username);
/* 130 */         sds.setPassword(jndiDataSources[i].password);
/* 131 */         builder.bind(jndiDataSources[i].jndiName, sds);
/*     */       }
/*     */       try {
/* 134 */         builder.activate();
/*     */       } catch (Exception e) {
/* 136 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static ApplicationContext loadSpringContext(String[] configLocations)
/*     */   {
/* 166 */     String[] contextPath = new String[2];
/* 167 */     contextPath[0] = "config/aibi_core/*-configure.xml";
/* 168 */     contextPath[1] = "config/aibi_privilegeService/*-config.xml";
/* 169 */     ApplicationContext context = new ClassPathXmlApplicationContext(contextPath);
/*     */ 
/* 171 */     return context;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 180 */     initLog4j();
/* 181 */     initConfigProperties();
/* 182 */     initLocaleProperties();
/*     */     try {
/* 184 */       String prifx = Configure.getInstance().getProperty("JNDI_PREFIX");
/* 185 */       String jndiBJ = Configure.getInstance().getProperty("JDBC_AIOMNI");
/* 186 */       String driverBJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "DRIVER_BJ");
/* 187 */       String urlBJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "URL_BJ");
/* 188 */       String userBJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "USER_BJ");
/* 189 */       String pwdBJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "PWD_BJ");
/* 190 */       String jndiNJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "JNDI_NJ");
/* 191 */       String urlNJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "URL_NJ");
/* 192 */       String userNJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "USER_NJ");
/* 193 */       String pwdNJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "PWD_NJ");
/* 194 */       String driverNJ = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "DRIVER_NJ");
/* 195 */       JndiDataSource aiomniDB = new JndiDataSource(prifx + jndiBJ, Class.forName(driverBJ), urlBJ, userBJ, pwdBJ);
/*     */ 
/* 197 */       JndiDataSource sdapJNDI = new JndiDataSource(prifx + jndiNJ, Class.forName(driverNJ), urlNJ, userNJ, pwdNJ);
/*     */ 
/* 199 */       loadDataSource(new JndiDataSource[] { aiomniDB, sdapJNDI });
/*     */     } catch (Exception e) {
/* 201 */       throw new RuntimeException(e);
/*     */     }
/* 203 */     ApplicationContext factory = loadSpringContext(new String[0]);
/* 204 */     IPrivilegeSyncService privilegeSyncService = (IPrivilegeSyncService)factory.getBean("right_privilegeSyncTask");
/* 205 */     privilegeSyncService.synData();
/*     */   }
/*     */ 
/*     */   public static class JndiDataSource
/*     */   {
/*     */     String jndiName;
/*     */     Class<?> driverClass;
/*     */     String url;
/*     */     String username;
/*     */     String password;
/*     */ 
/*     */     public JndiDataSource(String jndiName, Class<?> driverClass, String url, String username, String password)
/*     */     {
/* 155 */       this.jndiName = jndiName;
/* 156 */       this.driverClass = driverClass;
/* 157 */       this.url = url;
/* 158 */       this.username = username;
/* 159 */       this.password = password;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.fuse.service.impl.PrivilegeSync
 * JD-Core Version:    0.6.2
 */
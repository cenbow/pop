/*    */ package com.asiainfo.biframe.privilege.fuse.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.fuse.dao.IPrivilegeSyncDao;
/*    */ import com.asiainfo.biframe.privilege.fuse.service.IPrivilegeSyncService;
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ 
/*    */ public class PrivilegeSyncService
/*    */   implements IPrivilegeSyncService
/*    */ {
/*    */   private IPrivilegeSyncDao privilegeSyncDao;
/*    */ 
/*    */   public void synData()
/*    */   {
/* 15 */     String syncSwitch = "false";
/*    */     try {
/* 17 */       syncSwitch = Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "SYNC_SWITCH");
/*    */     } catch (Exception e) {
/* 19 */       throw new RuntimeException(e);
/*    */     }
/* 21 */     if ("true".equals(syncSwitch)) {
/* 22 */       this.privilegeSyncDao.setProperties();
/* 23 */       this.privilegeSyncDao.deleteTableData();
/* 24 */       this.privilegeSyncDao.syncUserCity();
/* 25 */       this.privilegeSyncDao.syncUserInfo();
/* 26 */       this.privilegeSyncDao.syncUserCityRight();
/* 27 */       this.privilegeSyncDao.syncRoleInfo();
/* 28 */       this.privilegeSyncDao.synRoleRoleMap();
/* 29 */       this.privilegeSyncDao.syncUserRoleMap();
/* 30 */       this.privilegeSyncDao.synRoleRight();
/*    */     }
/*    */   }
/*    */ 
/*    */   public IPrivilegeSyncDao getPrivilegeSyncDao()
/*    */   {
/* 36 */     return this.privilegeSyncDao;
/*    */   }
/*    */ 
/*    */   public void setPrivilegeSyncDao(IPrivilegeSyncDao privilegeSyncDao)
/*    */   {
/* 41 */     this.privilegeSyncDao = privilegeSyncDao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.fuse.service.impl.PrivilegeSyncService
 * JD-Core Version:    0.6.2
 */
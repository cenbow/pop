/*      */ package com.asiainfo.biframe.privilege.menu;
/*      */ 
/*      */ import com.asiainfo.biframe.exception.ServiceException;
/*      */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysMenuItemCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*      */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*      */ import com.asiainfo.biframe.privilege.model.User_User;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.impl.ListService;
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.AiomniConnectionFactory;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.SqlcaPst;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.io.File;
/*      */ import java.io.PrintStream;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import org.apache.commons.dbutils.handlers.MapListHandler;
/*      */ import org.apache.commons.fileupload.DiskFileUpload;
/*      */ import org.apache.commons.fileupload.FileItem;
/*      */ import org.apache.commons.fileupload.FileUploadException;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ 
/*      */ public class SysMenuMaintain
/*      */ {
/*   93 */   static Connection cn = null;
/*      */ 
/*   95 */   static Statement st = null;
/*      */ 
/*   97 */   static ResultSet rs = null;
/*      */ 
/*   99 */   static MapListHandler mlh = new MapListHandler();
/*      */ 
/*  101 */   static List li = null;
/*      */ 
/*      */   private static final IUserAdminService getUserAdminService()
/*      */   {
/*      */     try
/*      */     {
/*   71 */       return (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/*      */     }
/*      */     catch (Exception e) {
/*   74 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final IRoleAdminService getRoleAdminService()
/*      */   {
/*      */     try {
/*   81 */       return (IRoleAdminService)SystemServiceLocator.getInstance().getService("right_roleAdminService");
/*      */     }
/*      */     catch (Exception e) {
/*   84 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void createConnection()
/*      */   {
/*      */     try
/*      */     {
/*  109 */       if ((cn == null) || (cn.isClosed())) {
/*  110 */         cn = AiomniConnectionFactory.getInstance().getConnection();
/*      */       }
/*  112 */       if (st == null)
/*  113 */         st = cn.createStatement();
/*      */     }
/*      */     catch (SQLException excep) {
/*  116 */       excep.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void destroyConnection()
/*      */   {
/*      */     try
/*      */     {
/*  124 */       if (rs != null) {
/*  125 */         rs.close();
/*      */       }
/*  127 */       rs = null;
/*  128 */       if (st != null) {
/*  129 */         st.close();
/*      */       }
/*  131 */       st = null;
/*  132 */       if ((cn != null) && (!cn.isClosed())) {
/*  133 */         cn.close();
/*      */       }
/*  135 */       cn = null;
/*      */     }
/*      */     catch (SQLException excep) {
/*  138 */       excep.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String getRolebyUserID(String usrid)
/*      */     throws Exception
/*      */   {
/*  151 */     SqlcaPst sqlcaPst = null;
/*  152 */     String rss = null;
/*      */     try {
/*  154 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*  155 */       String sql = "select group_id from user_group_map where userid = ? ";
/*  156 */       int index = 1;
/*  157 */       sqlcaPst.setSql(sql);
/*  158 */       sqlcaPst.setString(index++, usrid);
/*  159 */       sqlcaPst.execute();
/*  160 */       if (sqlcaPst.next()) {
/*  161 */         rss = sqlcaPst.getString("group_id");
/*      */       }
/*      */ 
/*  166 */       if (null != sqlcaPst)
/*  167 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  164 */       ex.printStackTrace();
/*      */ 
/*  166 */       if (null != sqlcaPst)
/*  167 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  166 */       if (null != sqlcaPst) {
/*  167 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  170 */     return rss;
/*      */   }
/*      */ 
/*      */   public static String getParentMenuItemTitle(int id)
/*      */   {
/*  175 */     SqlcaPst sqlcaPst = null;
/*  176 */     String rss = null;
/*      */     try {
/*  178 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*  179 */       String sql = "select MENUITEMTITLE from sys_menu_item where MENUITEMID =?";
/*  180 */       int index = 1;
/*  181 */       sqlcaPst.setSql(sql);
/*  182 */       sqlcaPst.setInteger(index++, Integer.valueOf(id));
/*  183 */       sqlcaPst.execute();
/*  184 */       if (sqlcaPst.next()) {
/*  185 */         rss = sqlcaPst.getString("MENUITEMTITLE");
/*      */       }
/*      */ 
/*  191 */       if (null != sqlcaPst)
/*  192 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  189 */       e.printStackTrace();
/*      */ 
/*  191 */       if (null != sqlcaPst)
/*  192 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  191 */       if (null != sqlcaPst) {
/*  192 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  195 */     return rss;
/*      */   }
/*      */ 
/*      */   public static List getAllMenu() {
/*  199 */     SqlcaPst sqlcaPst = null;
/*  200 */     String sql = "select * from sys_menu_item order by parentid,sortnum";
/*      */ 
/*  202 */     List li = new ArrayList();
/*      */     try {
/*  204 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*  205 */       sqlcaPst.execute(sql);
/*  206 */       while (sqlcaPst.next()) {
/*  207 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/*  208 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/*  209 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/*  211 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/*  212 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/*  213 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/*  214 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/*  215 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/*  216 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/*  217 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/*  218 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/*  219 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/*  220 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/*  221 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/*  222 */         li.add(sysMenuItem);
/*      */       }
/*      */ 
/*  228 */       if (null != sqlcaPst)
/*  229 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  226 */       e.printStackTrace();
/*      */ 
/*  228 */       if (null != sqlcaPst)
/*  229 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  228 */       if (null != sqlcaPst) {
/*  229 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  232 */     return li;
/*      */   }
/*      */ 
/*      */   public static List getTopLevelMenuByRole(String role) {
/*  236 */     SqlcaPst sqlcaPst = null;
/*  237 */     String sql = "select menuitemid,menuitemtitle,parentid,sortnum,pic1,pic2,menutype,url,resid,restype,accesstoken,urltarget,urlport  from sys_menu_item where accesstoken=0 and parentid=0 order by sortnum,menuitemid";
/*      */ 
/*  241 */     List li = new ArrayList();
/*      */     try {
/*  243 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*  244 */       sqlcaPst.execute(sql);
/*  245 */       while (sqlcaPst.next()) {
/*  246 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/*  247 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/*  248 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/*  250 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/*  251 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/*  252 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/*  253 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/*  254 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/*  255 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/*  256 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/*  257 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/*  258 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/*  259 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/*  260 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/*  261 */         li.add(sysMenuItem);
/*      */       }
/*      */ 
/*  264 */       sql = "select a.menuitemid,a.menuitemtitle,a.parentid,a.sortnum,a.pic1,a.pic2,a.menutype,a.url,a.resid,a.restype,a.accesstoken,a.urltarget,a.urlport  from sys_menu_item a,sys_menuitem_right b  where a.accesstoken=1 and a.parentid=0  and a.menuitemid=? and b.operatorid=? and b.operatortype=? order by a.sortnum,a.menuitemid";
/*      */ 
/*  273 */       sqlcaPst.setSql(sql);
/*  274 */       int index = 1;
/*  275 */       sqlcaPst.setInteger(index++, sqlcaPst.getSql_charToint("b.resourceid"));
/*      */ 
/*  277 */       sqlcaPst.setString(index++, role);
/*  278 */       sqlcaPst.setInteger(index++, Integer.valueOf("0"));
/*      */ 
/*  280 */       sqlcaPst.execute();
/*  281 */       while (sqlcaPst.next()) {
/*  282 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/*  283 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/*  284 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/*  286 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/*  287 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/*  288 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/*  289 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/*  290 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/*  291 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/*  292 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/*  293 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/*  294 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/*  295 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/*  296 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/*  297 */         li.add(sysMenuItem);
/*      */       }
/*      */ 
/*  302 */       if (null != sqlcaPst)
/*  303 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  300 */       ex.printStackTrace();
/*      */ 
/*  302 */       if (null != sqlcaPst)
/*  303 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  302 */       if (null != sqlcaPst) {
/*  303 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  306 */     return li;
/*      */   }
/*      */ 
/*      */   public static List getSubMenuByRole(String pid, String role) {
/*  310 */     SqlcaPst sqlcaPst = null;
/*  311 */     String sql = "select menuitemid,menuitemtitle,parentid,sortnum,pic1,pic2,menutype,url,resid,restype,accesstoken,urltarget,urlport  from sys_menu_item where accesstoken=0 and  parentid=" + pid + " order by sortnum,menuitemid";
/*      */ 
/*  315 */     List li = new ArrayList();
/*      */     try {
/*  317 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*  318 */       sqlcaPst.execute(sql);
/*  319 */       while (sqlcaPst.next()) {
/*  320 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/*  321 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/*  322 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/*  324 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/*  325 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/*  326 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/*  327 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/*  328 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/*  329 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/*  330 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/*  331 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/*  332 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/*  333 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/*  334 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/*  335 */         li.add(sysMenuItem);
/*      */       }
/*      */ 
/*  338 */       sql = "select a.menuitemid,a.menuitemtitle,a.parentid,a.sortnum,a.pic1,a.pic2,a.menutype,a.url,a.resid,a.restype,a.accesstoken,a.urltarget,a.urlport  from sys_menu_item a,sys_menuitem_right b  where a.accesstoken!=0 and a.parentid=? and a.menuitemid=? and b.operatorid=? and b.operatortype=? order by a.sortnum,a.menuitemid";
/*      */ 
/*  347 */       sqlcaPst.setSql(sql);
/*  348 */       int index = 1;
/*  349 */       sqlcaPst.setInteger(index++, pid);
/*  350 */       sqlcaPst.setInteger(index++, sqlcaPst.getSql_charToint("b.resourceid"));
/*      */ 
/*  352 */       sqlcaPst.setString(index++, role);
/*  353 */       sqlcaPst.setInteger(index++, Integer.valueOf("0"));
/*      */ 
/*  355 */       sqlcaPst.execute();
/*  356 */       while (sqlcaPst.next()) {
/*  357 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/*  358 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/*  359 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/*  361 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/*  362 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/*  363 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/*  364 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/*  365 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/*  366 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/*  367 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/*  368 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/*  369 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/*  370 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/*  371 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/*  372 */         li.add(sysMenuItem);
/*      */       }
/*      */ 
/*  378 */       if (null != sqlcaPst)
/*  379 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  376 */       ex.printStackTrace();
/*      */ 
/*  378 */       if (null != sqlcaPst)
/*  379 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  378 */       if (null != sqlcaPst) {
/*  379 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*      */ 
/*  383 */     return li;
/*      */   }
/*      */ 
/*      */   public static List getAllSubMenuByRole(String pid, String role) {
/*  387 */     SqlcaPst sqlcaPst = null;
/*  388 */     String sql = "select menuitemid,menuitemtitle,parentid,sortnum,pic1,pic2,menutype,url,resid,restype,accesstoken,urltarget,urlport  from sys_menu_item where accesstoken=0 and  parentid=" + pid + " order by sortnum,menuitemid";
/*      */ 
/*  392 */     List li = new ArrayList();
/*      */     try {
/*  394 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*  395 */       sqlcaPst.execute(sql);
/*  396 */       while (sqlcaPst.next()) {
/*  397 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/*  398 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/*  399 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/*  401 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/*  402 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/*  403 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/*  404 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/*  405 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/*  406 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/*  407 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/*  408 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/*  409 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/*  410 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/*  411 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/*  412 */         li.add(sysMenuItem);
/*      */       }
/*      */ 
/*  415 */       sql = "select a.menuitemid,a.menuitemtitle,a.parentid,a.sortnum,a.pic1,a.pic2,a.menutype,a.url,a.resid,a.restype,a.accesstoken,a.urltarget,a.urlport  from sys_menu_item a,sys_menuitem_right b where a.accesstoken!=0 and a.parentid=? and a.menuitemid=? and b.operatorid=? and b.operatortype=? order by a.sortnum,a.menuitemid";
/*      */ 
/*  422 */       sqlcaPst.setSql(sql);
/*  423 */       int index = 1;
/*  424 */       sqlcaPst.setInteger(index++, pid);
/*  425 */       sqlcaPst.setInteger(index++, sqlcaPst.getSql_charToint("b.resourceid"));
/*      */ 
/*  427 */       sqlcaPst.setString(index++, role);
/*  428 */       sqlcaPst.setInteger(index++, Integer.valueOf("0"));
/*      */ 
/*  430 */       sqlcaPst.execute();
/*  431 */       while (sqlcaPst.next()) {
/*  432 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/*  433 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/*  434 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/*  436 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/*  437 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/*  438 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/*  439 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/*  440 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/*  441 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/*  442 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/*  443 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/*  444 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/*  445 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/*  446 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/*  447 */         li.add(sysMenuItem);
/*      */       }
/*  449 */       Iterator it = li.iterator();
/*  450 */       List menuList = new ArrayList();
/*  451 */       while (it.hasNext()) {
/*  452 */         SysMenuItemBean smi = (SysMenuItemBean)it.next();
/*  453 */         String id = String.valueOf(smi.getMENUITEMID());
/*  454 */         menuList.addAll(getSubMenuByRole(id, role));
/*      */       }
/*  456 */       li.addAll(menuList);
/*      */ 
/*  461 */       if (null != sqlcaPst)
/*  462 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  459 */       e.printStackTrace();
/*      */ 
/*  461 */       if (null != sqlcaPst)
/*  462 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  461 */       if (null != sqlcaPst) {
/*  462 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*      */ 
/*  466 */     return li;
/*      */   }
/*      */ 
/*      */   public static void createMenuItem(SysMenuItemBean smi) {
/*  470 */     SqlcaPst sqlcaPst = null;
/*      */     try {
/*  472 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*      */ 
/*  474 */       String sql = "insert into sys_menu_item  (MENUITEMID,MENUITEMTITLE,PARENTID,SORTNUM,PIC1,PIC2,MENUTYPE,URL,RESID,RESTYPE,ACCESSTOKEN,URLTARGET,URLPORT,APPLICATION_ID,RESOURCE_TYPE )values(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?)";
/*      */ 
/*  481 */       sqlcaPst.setSql(sql);
/*  482 */       int index = 1;
/*  483 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getMENUITEMID()));
/*  484 */       sqlcaPst.setString(index++, smi.getMENUITEMTITLE());
/*  485 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getPARENTID()));
/*  486 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getSORTNUM()));
/*  487 */       sqlcaPst.setString(index++, smi.getPIC1());
/*  488 */       sqlcaPst.setString(index++, smi.getPIC2());
/*  489 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getMENUTYPE()));
/*  490 */       sqlcaPst.setString(index++, smi.getURL());
/*  491 */       sqlcaPst.setString(index++, smi.getRESID());
/*  492 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getRESTYPE()));
/*  493 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getACCESSTOKEN()));
/*  494 */       sqlcaPst.setString(index++, smi.getURLTARGET());
/*  495 */       sqlcaPst.setString(index++, smi.getURLPORT());
/*  496 */       sqlcaPst.setString(index++, smi.getApplicationId());
/*  497 */       sqlcaPst.setInteger(index++, Integer.valueOf("50"));
/*      */ 
/*  499 */       sqlcaPst.execute();
/*  500 */       if (smi.getACCESSTOKEN() == 1) {
/*  501 */         createRoles(String.valueOf(smi.getMENUITEMID()), smi.getRoles());
/*      */       }
/*      */ 
/*  504 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), "" + smi.getMENUITEMID(), smi.getMENUITEMTITLE(), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.menuManage") + "-->" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.newMenu") + "-->" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveMenu") + "", null, null);
/*      */ 
/*  522 */       if (null != sqlcaPst)
/*  523 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  520 */       e.printStackTrace();
/*      */ 
/*  522 */       if (null != sqlcaPst)
/*  523 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  522 */       if (null != sqlcaPst)
/*  523 */         sqlcaPst.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static int genNewID()
/*      */   {
/*  533 */     Sqlca sqlca = null;
/*  534 */     String sql1 = "select max(MENUITEMID)+1 as newItemID from sys_menu_item";
/*  535 */     int newItemID = 0;
/*      */     try {
/*  537 */       sqlca = new Sqlca(new ConnectionEx());
/*  538 */       sqlca.execute(sql1);
/*  539 */       if (sqlca.next()) {
/*  540 */         newItemID = sqlca.getInt("newItemID");
/*      */       }
/*      */ 
/*  547 */       if (null != sqlca)
/*  548 */         sqlca.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  545 */       e.printStackTrace();
/*      */ 
/*  547 */       if (null != sqlca)
/*  548 */         sqlca.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  547 */       if (null != sqlca) {
/*  548 */         sqlca.closeAll();
/*      */       }
/*      */     }
/*  551 */     return newItemID;
/*      */   }
/*      */ 
/*      */   public static void delRoles(String menuitem, String[] newRoles)
/*      */   {
/*  557 */     List oldRoles = getMenuRolesList(menuitem);
/*  558 */     if (null != newRoles) {
/*  559 */       for (int i = 0; i < newRoles.length; i++) {
/*  560 */         String role = newRoles[i];
/*  561 */         if (oldRoles.contains(role)) {
/*  562 */           oldRoles.remove(role);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  567 */     if (oldRoles.size() > 0)
/*  568 */       delRoles(menuitem, oldRoles);
/*      */   }
/*      */ 
/*      */   public static void delRoles(String menuitem, List delRolesList)
/*      */   {
/*  574 */     Sqlca sqlca = null;
/*      */     try
/*      */     {
/*  582 */       sqlca = new Sqlca(new ConnectionEx());
/*  583 */       Vector v = new Vector();
/*      */ 
/*  586 */       delMenuItemTree(sqlca, menuitem, v);
/*      */ 
/*  588 */       Iterator iter = v.iterator();
/*  589 */       StringBuffer strMenuItemIds = new StringBuffer();
/*  590 */       while (iter.hasNext()) {
/*  591 */         String strMenuItemid = iter.next().toString();
/*  592 */         strMenuItemIds.append(strMenuItemid);
/*  593 */         strMenuItemIds.append(",");
/*      */       }
/*  595 */       strMenuItemIds.deleteCharAt(strMenuItemIds.lastIndexOf(","));
/*      */ 
/*  597 */       String delRoles = StringUtil.list2String(delRolesList, ",", true);
/*      */ 
/*  600 */       StringBuffer strSqlbuf = new StringBuffer();
/*  601 */       strSqlbuf.append("delete from sys_menuitem_right ");
/*  602 */       strSqlbuf.append("where resourcetype=");
/*  603 */       strSqlbuf.append("50");
/*  604 */       strSqlbuf.append(" and resourceid in(");
/*  605 */       strSqlbuf.append(StringUtil.addInvertedComma(strMenuItemIds.toString()));
/*      */ 
/*  607 */       strSqlbuf.append(")");
/*  608 */       strSqlbuf.append(" and operatorid in(");
/*  609 */       strSqlbuf.append(delRoles);
/*  610 */       strSqlbuf.append(")");
/*      */ 
/*  612 */       String sql = strSqlbuf.toString();
/*      */ 
/*  614 */       sqlca.execute(sql);
/*      */ 
/*  621 */       if (null != sqlca)
/*  622 */         sqlca.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  619 */       e.printStackTrace();
/*      */ 
/*  621 */       if (null != sqlca)
/*  622 */         sqlca.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  621 */       if (null != sqlca)
/*  622 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void createRoles(String menuitem, String[] roles)
/*      */   {
/*  628 */     if (roles != null) {
/*  629 */       SqlcaPst sqlcaPst = null;
/*      */       try {
/*  631 */         sqlcaPst = new SqlcaPst(new ConnectionEx());
/*      */ 
/*  633 */         Vector v = new Vector();
/*      */ 
/*  635 */         fMenuItemTree(sqlcaPst, menuitem, v);
/*  636 */         Iterator iter = v.iterator();
/*      */ 
/*  639 */         String realOperType = "";
/*  640 */         if (StringUtils.isBlank(realOperType)) {
/*  641 */           if (getRoleAdminService().isDistinguishOperation(1, Integer.parseInt("50")))
/*      */           {
/*  644 */             realOperType = "0";
/*      */           }
/*  646 */           else realOperType = "-1";
/*      */         }
/*      */ 
/*  649 */         while (iter.hasNext()) {
/*  650 */           String strMenuItemid = iter.next().toString();
/*  651 */           for (int i = 0; i < roles.length; i++) {
/*  652 */             String sql1 = "select operatorid from sys_menuitem_right where operatorid=? and operatortype=? and resourcetype=? and resourceid=? ";
/*  653 */             sqlcaPst.setSql(sql1);
/*  654 */             int index = 1;
/*  655 */             sqlcaPst.setString(index++, roles[i]);
/*  656 */             sqlcaPst.setInteger(index++, Integer.valueOf("0"));
/*      */ 
/*  658 */             sqlcaPst.setInteger(index++, Integer.valueOf("50"));
/*      */ 
/*  660 */             sqlcaPst.setString(index++, strMenuItemid);
/*  661 */             sqlcaPst.execute();
/*  662 */             if (!sqlcaPst.next()) {
/*  663 */               String sql = "insert into sys_menuitem_right(operatorid,operatortype,resourcetype,resourceid,accesstype,controltype) values(?,?,?,?,?,?)";
/*      */ 
/*  665 */               sqlcaPst.setSql(sql);
/*  666 */               index = 1;
/*  667 */               sqlcaPst.setString(index++, roles[i]);
/*  668 */               sqlcaPst.setInteger(index++, Integer.valueOf("0"));
/*      */ 
/*  670 */               sqlcaPst.setInteger(index++, Integer.valueOf("50"));
/*      */ 
/*  672 */               sqlcaPst.setString(index++, strMenuItemid);
/*  673 */               sqlcaPst.setInteger(index++, Integer.valueOf(realOperType));
/*      */ 
/*  675 */               sqlcaPst.setString(index++, "0");
/*      */ 
/*  677 */               sqlcaPst.execute();
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  686 */         if (null != sqlcaPst)
/*  687 */           sqlcaPst.closeAll();
/*      */       }
/*      */       catch (Exception ex)
/*      */       {
/*  684 */         ex.printStackTrace();
/*      */ 
/*  686 */         if (null != sqlcaPst)
/*  687 */           sqlcaPst.closeAll();
/*      */       }
/*      */       finally
/*      */       {
/*  686 */         if (null != sqlcaPst)
/*  687 */           sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void deleteMenuItem(int id)
/*      */   {
/*  700 */     Sqlca sqlca = null;
/*      */     try {
/*  702 */       List list = ViewMenuItem(id);
/*  703 */       SysMenuItemBean sysMenuItem = null;
/*  704 */       if ((list != null) && (list.size() > 0)) {
/*  705 */         sysMenuItem = (SysMenuItemBean)list.get(0);
/*      */       }
/*      */ 
/*  708 */       sqlca = new Sqlca(new ConnectionEx());
/*      */ 
/*  710 */       delMenuItem(sqlca, String.valueOf(id));
/*      */ 
/*  712 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), "" + id, "" + sysMenuItem != null ? sysMenuItem.getMENUITEMTITLE() : String.valueOf(id), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.newMenu") + "-->" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteMenu") + "", null, null);
/*      */ 
/*  732 */       if (null != sqlca)
/*  733 */         sqlca.closeAll();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  730 */       ex.printStackTrace();
/*      */ 
/*  732 */       if (null != sqlca)
/*  733 */         sqlca.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  732 */       if (null != sqlca)
/*  733 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void UpdateMenuItem(SysMenuItemBean smi)
/*      */   {
/*  740 */     SqlcaPst sqlcaPst = null;
/*      */ 
/*  742 */     String sql = "update sys_menu_item  set MENUITEMTITLE=?,PARENTID=?,SORTNUM=?,PIC1=?,PIC2=?,MENUTYPE=?,URL=?,RESID=?,RESTYPE=?,ACCESSTOKEN=?,URLTARGET=?,URLPORT=?, APPLICATION_ID=?  where MENUITEMID=?";
/*      */     try
/*      */     {
/*  749 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*  750 */       sqlcaPst.setSql(sql);
/*  751 */       int index = 1;
/*  752 */       sqlcaPst.setString(index++, smi.getMENUITEMTITLE());
/*  753 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getPARENTID()));
/*  754 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getSORTNUM()));
/*      */ 
/*  756 */       sqlcaPst.setString(index++, smi.getPIC1());
/*  757 */       sqlcaPst.setString(index++, smi.getPIC2());
/*  758 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getMENUTYPE()));
/*  759 */       sqlcaPst.setString(index++, smi.getURL());
/*  760 */       sqlcaPst.setString(index++, smi.getRESID());
/*      */ 
/*  762 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getRESTYPE()));
/*  763 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getACCESSTOKEN()));
/*  764 */       sqlcaPst.setString(index++, smi.getURLTARGET());
/*  765 */       sqlcaPst.setString(index++, smi.getURLPORT());
/*  766 */       sqlcaPst.setString(index++, smi.getApplicationId());
/*      */ 
/*  768 */       sqlcaPst.setInteger(index++, Integer.valueOf(smi.getMENUITEMID()));
/*  769 */       sqlcaPst.execute();
/*      */ 
/*  771 */       if (smi.getACCESSTOKEN() == 1) {
/*  772 */         delRoles(String.valueOf(smi.getMENUITEMID()), smi.getRoles());
/*  773 */         createRoles(String.valueOf(smi.getMENUITEMID()), smi.getRoles());
/*      */       }
/*      */ 
/*  779 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), "" + smi.getMENUITEMID(), smi.getMENUITEMTITLE(), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.newMenu") + "-->" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyMenu") + "-->" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveMenu") + "", null, null);
/*      */ 
/*  797 */       if (null != sqlcaPst)
/*  798 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  795 */       e.printStackTrace();
/*      */ 
/*  797 */       if (null != sqlcaPst)
/*  798 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  797 */       if (null != sqlcaPst)
/*  798 */         sqlcaPst.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static List ViewMenuItem(int id)
/*      */   {
/*  804 */     SqlcaPst sqlcaPst = null;
/*  805 */     String sql = "select * from sys_menu_item  where MENUITEMID=?";
/*      */ 
/*  807 */     List li = new ArrayList();
/*      */     try {
/*  809 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*  810 */       sqlcaPst.setSql(sql);
/*  811 */       int index = 1;
/*  812 */       sqlcaPst.setInteger(index++, Integer.valueOf(id));
/*  813 */       sqlcaPst.execute();
/*  814 */       while (sqlcaPst.next()) {
/*  815 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/*  816 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/*  817 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/*  819 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/*  820 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/*  821 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/*  822 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/*  823 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/*  824 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/*  825 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/*  826 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/*  827 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/*  828 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/*  829 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/*  830 */         sysMenuItem.setApplicationId(sqlcaPst.getString("application_id"));
/*      */ 
/*  832 */         li.add(sysMenuItem);
/*      */       }
/*      */ 
/*  838 */       if (null != sqlcaPst)
/*  839 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  836 */       e.printStackTrace();
/*      */ 
/*  838 */       if (null != sqlcaPst)
/*  839 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/*  838 */       if (null != sqlcaPst) {
/*  839 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  842 */     return li;
/*      */   }
/*      */ 
/*      */   public static String[] getRolesSelected(int menuId)
/*      */   {
/*  848 */     String sql = "select operatorid from sys_menuitem_right  where resourceid='" + menuId + "' " + " and resourcetype=" + "50" + " and operatortype=" + "0";
/*      */     try
/*      */     {
/*  854 */       createConnection();
/*  855 */       rs = st.executeQuery(sql);
/*      */ 
/*  857 */       li = mlh.handle(rs);
/*      */     } catch (SQLException e) {
/*  859 */       e.printStackTrace();
/*      */     } finally {
/*  861 */       destroyConnection();
/*      */     }
/*  863 */     String[] re = new String[li.size()];
/*  864 */     for (int i = 0; i < li.size(); i++) {
/*  865 */       re[i] = ((Map)li.get(i)).get("operatorid").toString();
/*      */     }
/*  867 */     return re;
/*      */   }
/*      */ 
/*      */   public static void processUploadFile(HttpServletRequest request) {
/*  871 */     DiskFileUpload upload = new DiskFileUpload();
/*  872 */     List items = null;
/*  873 */     String topic = null;
/*  874 */     String content = null;
/*  875 */     String userid = null;
/*      */     try {
/*  877 */       items = upload.parseRequest(request);
/*  878 */       Iterator it = items.iterator();
/*  879 */       while (it.hasNext())
/*      */       {
/*  881 */         FileItem item = (FileItem)it.next();
/*  882 */         if (!item.isFormField()) {
/*  883 */           String dir = "../webapps/ROOT/upload/";
/*      */ 
/*  885 */           File target_dir = new File(dir);
/*  886 */           if (!target_dir.exists()) {
/*  887 */             target_dir.mkdir();
/*      */           }
/*  889 */           String fieldName = item.getFieldName();
/*  890 */           String fileName = item.getName();
/*  891 */           fileName = fileName.substring(fileName.lastIndexOf("\\") + 1);
/*      */ 
/*  893 */           String contentType = item.getContentType();
/*  894 */           boolean isInMemory = item.isInMemory();
/*  895 */           long sizeInBytes = item.getSize();
/*  896 */           File uploadedFile = new File(target_dir, fileName);
/*      */ 
/*  898 */           item.write(uploadedFile);
/*      */         }
/*      */         else {
/*  901 */           String name = item.getFieldName();
/*  902 */           String value = item.getString();
/*  903 */           if (name.equals("appName"))
/*  904 */             topic = value;
/*  905 */           else if (name.equals("appDetail"))
/*  906 */             content = value;
/*  907 */           else if (name.equals("userid")) {
/*  908 */             userid = value;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  913 */       if ((topic.length() != 0) && (content.length() != 0)) {
/*  914 */         User_User oFromUser = null;
/*  915 */         User_User oToUser = null;
/*  916 */         String tmp = null;
/*  917 */         System.out.println("userid:" + userid);
/*  918 */         Object tmpObj = UserCache.getInstance().getObjectByKey(userid);
/*  919 */         if (tmpObj != null) {
/*  920 */           oFromUser = (User_User)tmpObj;
/*      */         }
/*  922 */         oFromUser.getGroupId();
/*  923 */         createConnection();
/*  924 */         String sql = "select parent_id from user_group where group_id='" + oFromUser.getGroupId() + "'";
/*      */ 
/*  926 */         System.out.println("sql:" + sql);
/*  927 */         rs = st.executeQuery(sql);
/*  928 */         if (rs.next()) {
/*  929 */           tmp = rs.getString("parentid");
/*      */         }
/*  931 */         sql = "select userid from user_group_map  where group_id='" + tmp + "'";
/*      */ 
/*  933 */         rs = st.executeQuery(sql);
/*  934 */         if (rs.next()) {
/*  935 */           tmp = rs.getString("userid");
/*      */         }
/*  937 */         destroyConnection();
/*  938 */         tmpObj = UserCache.getInstance().getObjectByKey(tmp);
/*  939 */         if (tmpObj != null) {
/*  940 */           oToUser = (User_User)tmpObj;
/*      */         }
/*  942 */         if ((oFromUser != null) && (oToUser != null)) {
/*  943 */           createConnection();
/*      */ 
/*  945 */           int cur_id = 0;
/*  946 */           rs = st.executeQuery("select max(email_id) as memail_id from email_message");
/*      */ 
/*  948 */           if (rs.next()) {
/*  949 */             cur_id = rs.getInt("memail_id") + 1;
/*      */           }
/*      */ 
/*  952 */           String title = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appRelease") + "";
/*      */ 
/*  956 */           sql = "insert into email_message (email_id,title,msg,from_address,send_date,history,to_address)values(" + cur_id + ",'" + title + oFromUser.getUsername() + "','" + content + "','" + oFromUser.getEMail() + "'," + new Sqlca(cn).getSql2DateTimeNow() + "," + 0 + ",'" + oToUser.getEMail() + "')";
/*      */ 
/*  970 */           st.execute(sql);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (FileUploadException e)
/*      */     {
/*  976 */       e.printStackTrace();
/*      */     }
/*      */     catch (NullPointerException e) {
/*  979 */       e.printStackTrace();
/*      */     }
/*      */     catch (Exception e1) {
/*  982 */       e1.printStackTrace();
/*      */     } finally {
/*  984 */       destroyConnection();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static List getAllTopLevelMenu() {
/*  989 */     SqlcaPst sqlcaPst = null;
/*      */ 
/*  991 */     String sql = "select menuitemid,menuitemtitle,parentid,sortnum,pic1,pic2,menutype,url,resid,restype,accesstoken,urltarget,urlport  from sys_menu_item where parentid=0 order by sortnum,menuitemid";
/*      */ 
/*  994 */     List li = new ArrayList();
/*      */     try {
/*  996 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/*  997 */       sqlcaPst.execute(sql);
/*  998 */       while (sqlcaPst.next()) {
/*  999 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/* 1000 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/* 1001 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/* 1003 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/* 1004 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/* 1005 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/* 1006 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/* 1007 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/* 1008 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/* 1009 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/* 1010 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/* 1011 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/* 1012 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/* 1013 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/* 1014 */         li.add(sysMenuItem);
/*      */       }
/*      */ 
/* 1019 */       if (null != sqlcaPst)
/* 1020 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 1017 */       ex.printStackTrace();
/*      */ 
/* 1019 */       if (null != sqlcaPst)
/* 1020 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/* 1019 */       if (null != sqlcaPst) {
/* 1020 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/* 1023 */     return li;
/*      */   }
/*      */ 
/*      */   public static String delMenuItem(Sqlca sqlca, String menuItemId) throws Exception
/*      */   {
/* 1028 */     StringBuffer ret = new StringBuffer();
/* 1029 */     Vector v = new Vector();
/*      */ 
/* 1032 */     delMenuItemTree(sqlca, menuItemId, v);
/*      */ 
/* 1034 */     Iterator iter = v.iterator();
/* 1035 */     StringBuffer strMenuItemIds = new StringBuffer();
/* 1036 */     while (iter.hasNext()) {
/* 1037 */       String strMenuItemid = iter.next().toString();
/* 1038 */       strMenuItemIds.append(strMenuItemid);
/* 1039 */       strMenuItemIds.append(",");
/*      */     }
/*      */ 
/* 1042 */     strMenuItemIds.deleteCharAt(strMenuItemIds.lastIndexOf(","));
/*      */ 
/* 1045 */     StringBuffer strSqlbuf = new StringBuffer();
/* 1046 */     Sqlca mSqlca = null;
/*      */     try
/*      */     {
/* 1049 */       mSqlca = new Sqlca(sqlca.getConnection());
/* 1050 */       strSqlbuf.append("delete from sys_menuitem_right ");
/* 1051 */       strSqlbuf.append("where resourcetype=");
/* 1052 */       strSqlbuf.append("50");
/* 1053 */       strSqlbuf.append(" and resourceid in(");
/* 1054 */       strSqlbuf.append(StringUtil.addInvertedComma(strMenuItemIds.toString()));
/*      */ 
/* 1056 */       strSqlbuf.append(")");
/* 1057 */       mSqlca.execute(strSqlbuf.toString());
/*      */ 
/* 1059 */       strSqlbuf = null;
/* 1060 */       strSqlbuf = new StringBuffer();
/* 1061 */       strSqlbuf.append("delete from sys_menu_item where menuitemid in (");
/* 1062 */       strSqlbuf.append(strMenuItemIds);
/* 1063 */       strSqlbuf.append(")");
/* 1064 */       mSqlca.execute(strSqlbuf.toString());
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1070 */       throw e;
/*      */     } finally {
/*      */       try {
/* 1073 */         if (mSqlca != null)
/* 1074 */           mSqlca.close();
/*      */       }
/*      */       catch (Exception e) {
/* 1077 */         throw e;
/*      */       }
/*      */     }
/* 1080 */     return ret.toString();
/*      */   }
/*      */ 
/*      */   private static void delMenuItemTree(Sqlca sqlca, String menuItemId, Vector v)
/*      */   {
/*      */     try
/*      */     {
/* 1094 */       sqlca = new Sqlca(sqlca.getConnection());
/* 1095 */       v.add(menuItemId);
/* 1096 */       String strSql = "select menuitemid from sys_menu_item where parentid=" + menuItemId;
/*      */ 
/* 1098 */       sqlca.execute(strSql);
/* 1099 */       List menuList = new ArrayList();
/* 1100 */       while (sqlca.next()) {
/* 1101 */         menuList.add(sqlca.getString("menuitemid"));
/*      */       }
/* 1103 */       sqlca.close();
/* 1104 */       for (int i = 0; i < menuList.size(); i++) {
/* 1105 */         delMenuItemTree(sqlca, (String)menuList.get(i), v);
/*      */       }
/*      */ 
/* 1110 */       if (null != sqlca)
/* 1111 */         sqlca.close();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 1108 */       ex.printStackTrace();
/*      */ 
/* 1110 */       if (null != sqlca)
/* 1111 */         sqlca.close();
/*      */     }
/*      */     finally
/*      */     {
/* 1110 */       if (null != sqlca)
/* 1111 */         sqlca.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void fMenuItemTree(Sqlca sqlca, String menuItemId, Vector v)
/*      */   {
/*      */     try
/*      */     {
/* 1128 */       sqlca = new Sqlca(sqlca.getConnection());
/* 1129 */       v.add(menuItemId);
/* 1130 */       String strSql = "select parentid from sys_menu_item where menuitemid=" + menuItemId;
/*      */ 
/* 1132 */       sqlca.execute(strSql);
/* 1133 */       List menuList = new ArrayList();
/* 1134 */       while (sqlca.next()) {
/* 1135 */         menuList.add(sqlca.getString("parentid"));
/*      */       }
/* 1137 */       sqlca.close();
/* 1138 */       for (int i = 0; i < menuList.size(); i++) {
/* 1139 */         fMenuItemTree(sqlca, (String)menuList.get(i), v);
/*      */       }
/*      */ 
/* 1144 */       if (null != sqlca)
/* 1145 */         sqlca.close();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 1142 */       ex.printStackTrace();
/*      */ 
/* 1144 */       if (null != sqlca)
/* 1145 */         sqlca.close();
/*      */     }
/*      */     finally
/*      */     {
/* 1144 */       if (null != sqlca)
/* 1145 */         sqlca.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static boolean initSysAdminMenu(String sysMenuPID, HttpServletRequest request)
/*      */   {
/* 1158 */     List adminMenuList = getAdminListMenu();
/* 1159 */     return initMenu(adminMenuList, sysMenuPID, request);
/*      */   }
/*      */ 
/*      */   public static boolean initLogMenu(String logMenuPID, HttpServletRequest request)
/*      */   {
/* 1170 */     List logMenuList = getLogListMenu();
/* 1171 */     return initMenu(logMenuList, logMenuPID, request);
/*      */   }
/*      */ 
/*      */   public static boolean initOtherMenu(String otherMenuPID, HttpServletRequest request)
/*      */   {
/* 1182 */     List otherMenuList = getOtherListMenu();
/* 1183 */     return initMenu(otherMenuList, otherMenuPID, request);
/*      */   }
/*      */ 
/*      */   public static boolean initMenu(List menuList, String menuPID, HttpServletRequest request)
/*      */   {
/* 1196 */     Sqlca sqlca = null;
/* 1197 */     String strSql = "insert into sys_menu_item  (MENUITEMID,MENUITEMTITLE,PARENTID,SORTNUM,PIC1,PIC2,MENUTYPE,URL,RESID,RESTYPE,ACCESSTOKEN,URLTARGET,URLPORT)values(";
/*      */     try
/*      */     {
/* 1202 */       sqlca = new Sqlca(new ConnectionEx());
/* 1203 */       for (int i = 0; i < menuList.size(); i++) {
/* 1204 */         obj = menuList.get(i);
/* 1205 */         if (null != obj)
/*      */         {
/* 1208 */           SysMenuItemBean smi = (SysMenuItemBean)obj;
/* 1209 */           smi.setMENUITEMID(genNewID());
/* 1210 */           String sql = strSql + smi.getMENUITEMID() + ",'" + smi.getMENUITEMTITLE() + "'," + menuPID + "," + "0" + ",'" + smi.getPIC1() + "','" + smi.getPIC2() + "'," + "1" + ",'" + smi.getURL() + "','" + "" + "'," + 1 + "," + "1" + "," + "'" + "" + "'," + "'" + "" + "'" + ")";
/*      */ 
/* 1218 */           String strExistSql = "select menuitemid from sys_menu_item where url='" + smi.getURL() + "'";
/*      */ 
/* 1220 */           sqlca.execute(strExistSql);
/* 1221 */           if (!sqlca.next())
/*      */           {
/* 1224 */             sqlca.execute(sql);
/*      */           }
/*      */         }
/*      */       }
/* 1227 */       return 1;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       Object obj;
/* 1229 */       ex.printStackTrace();
/* 1230 */       return 0;
/*      */     } finally {
/* 1232 */       if (null != sqlca)
/* 1233 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static List getAdminListMenu()
/*      */   {
/* 1244 */     String strProvince = Configure.getInstance().getProperty("PROVINCE");
/* 1245 */     List listMenu = new ArrayList();
/*      */ 
/* 1247 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userManage") + "", "/sysmanage/userCommon.aido?actionType=userHomePage", "/images/admin/useradmin.gif", "/images/admin/useradmin-1.gif", "1"));
/*      */ 
/* 1254 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleManage") + "", "/sysmanage/roleAdminAction.aido?actionType=roleHomePage", "/images/admin/roleadmin.gif", "/images/admin/roleadmin-1.gif", "0"));
/*      */ 
/* 1261 */     listMenu.add(getSysMenuitem(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupManage"), "/sysmanage/userGroupCommon.aido?actionType=userGroupHomePage", "/images/admin/useradmin.gif", "/images/admin/useradmin-1.gif", "0"));
/*      */ 
/* 1267 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.dutyManage") + "", "/sysmanage/dutyCommon.aido?actionType=dutyHomePage", "/images/admin/useradmin.gif", "/images/admin/useradmin-1.gif", "1"));
/*      */ 
/* 1274 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourceAuth") + "", "/useradmin/resource/resourceList.jsp", "/images/admin/extadmin.gif", "/images/admin/extadmin-1.gif", "33"));
/*      */ 
/* 1281 */     listMenu.add(getSysMenuitem(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.menuMaintain"), "/menumaintain/menulist.jsp", "/images/admin/extadmin.gif", "/images/admin/extadmin-1.gif", "-1"));
/*      */ 
/* 1289 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.fileReportManage") + "", "/useradmin/report/index.jsp?mode=SYS_REPORT_FILE", "/images/admin/newsadmin.gif", "/images/admin/newsadmin-1.gif", "36"));
/*      */ 
/* 1301 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.tagFlowConf") + "", "/tagflow/tagflowconf.jsp", "/images/admin/newsadmin.gif", "/images/admin/newsadmin-1.gif", "99"));
/*      */ 
/* 1307 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.tagFlowMain") + "", "/tagflow/tagflowmain.jsp", "/images/admin/newsadmin.gif", "/images/admin/newsadmin-1.gif", "-1"));
/*      */ 
/* 1315 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.companyManage") + "", "/company/companymain.jsp", "/images/admin/companyadmin.gif", "/images/admin/companyadmin-1.gif", "20"));
/*      */ 
/* 1323 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.reportMain") + "", "/rptadmin/rptmain.jsp", "/images/admin/rptadmin.gif", "/images/admin/rptadmin-1.gif", "22"));
/*      */ 
/* 1328 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.reportDescMain") + "", "/rptadmin/rptdescmain.jsp?BALL=1", "/images/admin/rptdescadmin.gif", "/images/admin/rptdescadmin-1.gif", "22"));
/*      */ 
/* 1336 */     listMenu.add(getSysMenuitem(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.kpiAdmin"), "/kpiadmin/kpimain.jsp", "/images/admin/kpiadmin.gif", "/images/admin/kpiadmin-1.gif", "2"));
/*      */ 
/* 1342 */     listMenu.add(getSysMenuitem(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.kpiAlarmAdmin"), "/kpiadmin/kpialarmadmin.jsp", "/images/admin/kpiadmin.gif", "/images/admin/kpiadmin-1.gif", "2"));
/*      */ 
/* 1349 */     listMenu.add(getSysMenuitem(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.kpiTaskAdmin"), "/kpiadmin/kpitaskadmin.jsp", "/images/admin/kpiadmin.gif", "/images/admin/kpiadmin-1.gif", "2"));
/*      */ 
/* 1355 */     if ((null != strProvince) && (strProvince.equalsIgnoreCase("JILIN"))) {
/* 1356 */       listMenu.add(getSysMenuitem(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.kpiSmsAdmin"), "/jsp/local/jilin/kpisms/kpismsconfirm.jsp", "/images/admin/kpiadmin.gif", "/images/admin/kpiadmin-1.gif", "2"));
/*      */ 
/* 1361 */       listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupSms") + "", "/jsp/local/jilin/kpisms/groupsmssender.jsp", "/images/admin/kpiadmin.gif", "/images/admin/kpiadmin-1.gif", "2"));
/*      */     }
/*      */ 
/* 1369 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.template") + "", "/template/main.jsp", "/images/admin/kpiadmin.gif", "/images/admin/kpiadmin-1.gif", "2"));
/*      */ 
/* 1377 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.newsAdmin") + "", "/useradmin/usernewsadmin.jsp", "/images/admin/newsadmin.gif", "/images/admin/newsadmin-1.gif", "17"));
/*      */ 
/* 1384 */     listMenu.add(getSysMenuitem(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.loginAdmin"), "/userpolicy/userpolicyadmin.jsp", "/images/admin/loginadmin.gif", "/images/admin/loginadmin-1.gif", "25"));
/*      */ 
/* 1393 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.balanceAdmin") + "", "/balance/balanceadmin.jsp", "/images/admin/loginadmin.gif", "/images/admin/loginadmin-1.gif", "25"));
/*      */ 
/* 1402 */     listMenu.add(getSysMenuitem("OA" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userManage") + "", "/oausermanage/oausermapadmin.jsp", "/images/admin/oauseradmin.gif", "/images/admin/oauseradmin-1.gif", "25"));
/*      */ 
/* 1411 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.otherUserMapAdmin") + "", "/otherusermanage/otherusermapadmin.jsp", "/images/admin/oauseradmin.gif", "/images/admin/oauseradmin-1.gif", "25"));
/*      */ 
/* 1420 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.managerMapAdmin") + "", "/managermap/managermapmain.jsp?type=vip", "/images/admin/companyadmin.gif", "/images/admin/companyadmin-1.gif", "20"));
/*      */ 
/* 1427 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.entMapAdmin") + "", "/managermap/managermapmain.jsp?type=ent", "/images/admin/companyadmin.gif", "/images/admin/companyadmin-1.gif", "20"));
/*      */ 
/* 1436 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.pwdPolicy") + "", "/servlet/PwdPolicyServlet?cmd=init", "/images/admin/extadmin.gif", "/images/admin/extadmin-1.gif", "20"));
/*      */ 
/* 1442 */     listMenu.add(getSysMenuitem(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.firstPageSet"), "/common/firstPageSet.aido?cmd=showFirstpagelist", "/images/admin/kpiadmin.gif", "/images/admin/kpiadmin-1.gif", "20"));
/*      */ 
/* 1447 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unlockUser") + "", "/useradmin/unlockuser.jsp", "/images/admin/extadmin.gif", "/images/admin/extadmin-1.gif", "20"));
/*      */ 
/* 1453 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.statCcfg") + "", "/log/stat_ccfg.jsp", "/images/admin/extadmin.gif", "/images/admin/extadmin-1.gif", "20"));
/*      */ 
/* 1459 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exchangePlatformConfig") + "", "/exchangeplatform/userRightList.jsp", "/images/admin/oauseradmin.gif", "/images/admin/oauseradmin-1.gif", "20"));
/*      */ 
/* 1466 */     return listMenu;
/*      */   }
/*      */ 
/*      */   private static List getLogListMenu()
/*      */   {
/* 1475 */     List listMenu = new ArrayList();
/*      */ 
/* 1479 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.hitrate") + "", "/hitrate/hitratemain.jsp", "/images/admin/hitrate.gif", "/images/admin/hitrate-1.gif", "9"));
/*      */ 
/* 1490 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.operationLog") + "", "/log/logquery.jsp", "/images/admin/log.gif", "/images/admin/log-1.gif", "26"));
/*      */ 
/* 1495 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.loginLog") + "", "/log/loginlogquery.jsp", "/images/admin/loginlog.gif", "/images/admin/loginlog-1.gif", "27"));
/*      */ 
/* 1505 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userOnLine") + "", "/useradmin/useronline.jsp", "/images/admin/onlineuser.gif", "/images/admin/onlineuser-1.gif", "28"));
/*      */ 
/* 1512 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.kpiLimitSum") + "", "/kpi/kpilimitsumlog.jsp", "/images/admin/extadmin.gif", "/images/admin/extadmin-1.gif", "28"));
/*      */ 
/* 1519 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.taskSum") + "", "/taskdispatch/tasksumlog.jsp", "/images/admin/companyadmin.gif", "/images/admin/companyadmin-1.gif", "28"));
/*      */ 
/* 1525 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.statPc") + "", "/log/stat_pc.jsp", "/images/admin/login2.gif", "/images/admin/login2-1.gif", "28"));
/*      */ 
/* 1531 */     return listMenu;
/*      */   }
/*      */ 
/*      */   private static List getOtherListMenu()
/*      */   {
/* 1540 */     List listMenu = new ArrayList();
/* 1541 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exchangePlatform") + "", "/exchangeplatform/index.jsp", "/images/admin/flat2.gif", "/images/admin/flat2-1.gif", "28"));
/*      */ 
/* 1546 */     listMenu.add(getSysMenuitem("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.fileReport") + "", "/report/view/index.jsp", "", "", "28"));
/*      */ 
/* 1551 */     return listMenu;
/*      */   }
/*      */ 
/*      */   public static SysMenuItemBean getSysMenuitem(String title, String url, String pic1, String pic2, String restype)
/*      */   {
/* 1566 */     SysMenuItemBean sysMenuitem = new SysMenuItemBean();
/* 1567 */     sysMenuitem.setMENUITEMTITLE(title);
/* 1568 */     sysMenuitem.setPIC1(pic1);
/* 1569 */     sysMenuitem.setPIC2(pic2);
/* 1570 */     sysMenuitem.setURL(url);
/* 1571 */     int nResType = -1;
/*      */     try {
/* 1573 */       nResType = Integer.parseInt(restype);
/*      */     } catch (Exception ex) {
/* 1575 */       nResType = -1;
/*      */     }
/* 1577 */     sysMenuitem.setRESTYPE(nResType);
/* 1578 */     return sysMenuitem;
/*      */   }
/*      */ 
/*      */   public static void UpdateSortNum(String strSort)
/*      */     throws Exception
/*      */   {
/* 1589 */     Sqlca sqlca = null;
/*      */     try {
/* 1591 */       sqlca = new Sqlca(new ConnectionEx());
/* 1592 */       if ((null != strSort) && (strSort.trim().length() > 0)) {
/* 1593 */         int nD = 0;
/* 1594 */         while (strSort.length() > 0) {
/* 1595 */           int nP = strSort.indexOf(";");
/* 1596 */           String str = "";
/* 1597 */           if (nP >= 0) {
/* 1598 */             str = strSort.substring(0, nP).trim();
/* 1599 */             strSort = strSort.substring(nP + 1).trim();
/*      */           } else {
/* 1601 */             str = strSort;
/* 1602 */             strSort = "";
/*      */           }
/* 1604 */           if (str.trim().length() > 0) {
/* 1605 */             sqlca.execute("update sys_menu_item set sortnum=" + nD + " where menuitemid=" + str);
/*      */ 
/* 1607 */             nD++;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1616 */       if (null != sqlca)
/* 1617 */         sqlca.closeAll();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 1613 */       ex.printStackTrace();
/* 1614 */       throw ex;
/*      */     } finally {
/* 1616 */       if (null != sqlca)
/* 1617 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static int genNewSortNum(int parentId)
/*      */   {
/* 1634 */     Sqlca sqlca = null;
/* 1635 */     String sql = "select max(sortnum)+1 as newSortNum from sys_menu_item where parentid=" + parentId;
/*      */ 
/* 1637 */     int newSortNum = -1;
/*      */     try {
/* 1639 */       sqlca = new Sqlca(new ConnectionEx());
/* 1640 */       sqlca.execute(sql);
/* 1641 */       if (sqlca.next()) {
/* 1642 */         newSortNum = sqlca.getInt("newSortNum");
/*      */       }
/*      */ 
/* 1647 */       if (null != sqlca)
/* 1648 */         sqlca.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1645 */       e.printStackTrace();
/*      */ 
/* 1647 */       if (null != sqlca)
/* 1648 */         sqlca.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/* 1647 */       if (null != sqlca) {
/* 1648 */         sqlca.closeAll();
/*      */       }
/*      */     }
/* 1651 */     return newSortNum;
/*      */   }
/*      */ 
/*      */   public static List getMenuRolesList(String menuitemId)
/*      */   {
/* 1661 */     List roleList = new ArrayList();
/*      */ 
/* 1663 */     SqlcaPst sqlcaPst = null;
/* 1664 */     String sql = "select operatorid,operatortype,resourceid,resourcetype  from sys_menuitem_right where resourceid=? and resourcetype=? and operatortype=?";
/*      */     try
/*      */     {
/* 1667 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/* 1668 */       sqlcaPst.setSql(sql);
/* 1669 */       int index = 1;
/* 1670 */       sqlcaPst.setString(index++, menuitemId);
/* 1671 */       sqlcaPst.setInteger(index++, Integer.valueOf("50"));
/*      */ 
/* 1673 */       sqlcaPst.setInteger(index++, Integer.valueOf("0"));
/*      */ 
/* 1675 */       sqlcaPst.execute();
/* 1676 */       while (sqlcaPst.next()) {
/* 1677 */         String operatorid = sqlcaPst.getString("operatorid");
/* 1678 */         roleList.add(operatorid);
/*      */       }
/*      */ 
/* 1683 */       if (null != sqlcaPst)
/* 1684 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1681 */       e.printStackTrace();
/*      */ 
/* 1683 */       if (null != sqlcaPst)
/* 1684 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/* 1683 */       if (null != sqlcaPst) {
/* 1684 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*      */ 
/* 1688 */     return roleList;
/*      */   }
/*      */ 
/*      */   public static List<SysMenuItemBean> getMenuListByApplicationId(String applicationId)
/*      */   {
/* 1693 */     SqlcaPst sqlcaPst = null;
/*      */ 
/* 1695 */     String sql = "select menuitemid,menuitemtitle,parentid,sortnum,pic1,pic2,menutype,url,resid,restype,accesstoken,urltarget,urlport  from sys_menu_item where application_id=? order by sortnum,menuitemid";
/*      */ 
/* 1698 */     List li = new ArrayList();
/*      */     try {
/* 1700 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/* 1701 */       sqlcaPst.setSql(sql);
/* 1702 */       sqlcaPst.setString(1, applicationId);
/* 1703 */       sqlcaPst.execute();
/* 1704 */       while (sqlcaPst.next()) {
/* 1705 */         SysMenuItemBean sysMenuItem = new SysMenuItemBean();
/* 1706 */         sysMenuItem.setMENUITEMID(sqlcaPst.getInt("menuitemid"));
/* 1707 */         sysMenuItem.setMENUITEMTITLE(sqlcaPst.getString("menuitemtitle"));
/*      */ 
/* 1709 */         sysMenuItem.setPARENTID(sqlcaPst.getInt("parentid"));
/* 1710 */         sysMenuItem.setSORTNUM(sqlcaPst.getInt("sortnum"));
/* 1711 */         sysMenuItem.setPIC1(sqlcaPst.getString("pic1"));
/* 1712 */         sysMenuItem.setPIC2(sqlcaPst.getString("pic2"));
/* 1713 */         sysMenuItem.setMENUTYPE(sqlcaPst.getInt("menutype"));
/* 1714 */         sysMenuItem.setURL(sqlcaPst.getString("url"));
/* 1715 */         sysMenuItem.setRESID(sqlcaPst.getString("resid"));
/* 1716 */         sysMenuItem.setRESTYPE(sqlcaPst.getInt("restype"));
/* 1717 */         sysMenuItem.setACCESSTOKEN(sqlcaPst.getInt("accesstoken"));
/* 1718 */         sysMenuItem.setURLTARGET(sqlcaPst.getString("urltarget"));
/* 1719 */         sysMenuItem.setURLPORT(sqlcaPst.getString("urlport"));
/* 1720 */         sysMenuItem.setApplicationId(applicationId);
/* 1721 */         li.add(sysMenuItem);
/*      */       }
/*      */ 
/* 1726 */       if (null != sqlcaPst)
/* 1727 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 1724 */       ex.printStackTrace();
/*      */ 
/* 1726 */       if (null != sqlcaPst)
/* 1727 */         sqlcaPst.closeAll();
/*      */     }
/*      */     finally
/*      */     {
/* 1726 */       if (null != sqlcaPst) {
/* 1727 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/* 1730 */     return li;
/*      */   }
/*      */ 
/*      */   public static List<String> getSubMenuItem(Sqlca sqlca, int menuItemId, boolean isCascade)
/*      */   {
/* 1746 */     List list = null;
/*      */ 
/* 1748 */     List menuItemList = SysMenuItemCache.getInstance().getSubMenuItemById(menuItemId, new ArrayList(), isCascade);
/*      */     try {
/* 1750 */       list = ListService.convertToNewList(menuItemList, "MENUITEMID");
/*      */     } catch (Exception e) {
/* 1752 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 1781 */     return list;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.SysMenuMaintain
 * JD-Core Version:    0.6.2
 */
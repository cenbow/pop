/*    */ package com.asiainfo.biframe.privilege.menu;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class TreeItem
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Integer menuItemId;
/*    */   private String menuItemTitle;
/*    */   private Integer parentId;
/*    */   private String url;
/*    */   private Integer childNum;
/*    */   private String nodeTitle;
/* 17 */   private List<TreeItem> children = new ArrayList();
/*    */ 
/*    */   public List<TreeItem> getChildren() {
/* 20 */     return this.children;
/*    */   }
/*    */   public void setChildren(List<TreeItem> children) {
/* 23 */     this.children = children;
/*    */   }
/*    */   public String getNodeTitle() {
/* 26 */     return this.nodeTitle;
/*    */   }
/*    */   public void setNodeTitle(String nodeTitle) {
/* 29 */     this.nodeTitle = nodeTitle;
/*    */   }
/*    */   public Integer getChildNum() {
/* 32 */     return this.childNum;
/*    */   }
/*    */   public void setChildNum(Integer childNum) {
/* 35 */     this.childNum = childNum;
/*    */   }
/*    */   public Integer getMenuItemId() {
/* 38 */     return this.menuItemId;
/*    */   }
/*    */   public void setMenuItemId(Integer menuItemId) {
/* 41 */     this.menuItemId = menuItemId;
/*    */   }
/*    */   public String getMenuItemTitle() {
/* 44 */     return this.menuItemTitle;
/*    */   }
/*    */   public void setMenuItemTitle(String menuItemTitle) {
/* 47 */     this.menuItemTitle = menuItemTitle;
/*    */   }
/*    */   public Integer getParentId() {
/* 50 */     return this.parentId;
/*    */   }
/*    */   public void setParentId(Integer parentId) {
/* 53 */     this.parentId = parentId;
/*    */   }
/*    */   public String getUrl() {
/* 56 */     return this.url;
/*    */   }
/*    */   public void setUrl(String url) {
/* 59 */     this.url = url;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.TreeItem
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.menu.bean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class SysMenuItemBean
/*     */   implements Serializable
/*     */ {
/*     */   int MENUITEMID;
/*     */   String MENUITEMTITLE;
/*     */   int PARENTID;
/*     */   int SORTNUM;
/*     */   String PIC1;
/*     */   String PIC2;
/*     */   int MENUTYPE;
/*     */   String URL;
/*     */   String RESID;
/*     */   int RESTYPE;
/*     */   int ACCESSTOKEN;
/*     */   String URLTARGET;
/*     */   String URLPORT;
/*     */   String[] roles;
/*     */   boolean hasSon;
/*     */   String imagePath;
/*     */   String applicationId;
/*     */   String applicaionName;
/*     */ 
/*     */   public String getImagePath()
/*     */   {
/*  39 */     return this.imagePath;
/*     */   }
/*     */ 
/*     */   public void setImagePath(String imagePath) {
/*  43 */     this.imagePath = imagePath;
/*     */   }
/*     */ 
/*     */   public String get(String strColName)
/*     */   {
/*  48 */     if (strColName.equalsIgnoreCase("MENUITEMID"))
/*     */     {
/*  50 */       return "" + this.MENUITEMID;
/*     */     }
/*  52 */     if (strColName.equalsIgnoreCase("MENUITEMTITLE"))
/*     */     {
/*  54 */       return "" + this.MENUITEMTITLE;
/*     */     }
/*  56 */     if (strColName.equalsIgnoreCase("PARENTID"))
/*     */     {
/*  58 */       return "" + this.PARENTID;
/*     */     }
/*  60 */     if (strColName.equalsIgnoreCase("SORTNUM"))
/*     */     {
/*  62 */       return "" + this.SORTNUM;
/*     */     }
/*  64 */     if (strColName.equalsIgnoreCase("PIC1"))
/*     */     {
/*  66 */       return "" + this.PIC1;
/*     */     }
/*  68 */     if (strColName.equalsIgnoreCase("PIC2"))
/*     */     {
/*  70 */       return "" + this.PIC2;
/*     */     }
/*  72 */     if (strColName.equalsIgnoreCase("MENUTYPE"))
/*     */     {
/*  74 */       return "" + this.MENUTYPE;
/*     */     }
/*  76 */     if (strColName.equalsIgnoreCase("URL"))
/*     */     {
/*  78 */       return "" + this.URL;
/*     */     }
/*  80 */     if (strColName.equalsIgnoreCase("RESID"))
/*     */     {
/*  82 */       return "" + this.RESID;
/*     */     }
/*  84 */     if (strColName.equalsIgnoreCase("RESTYPE"))
/*     */     {
/*  86 */       return "" + this.RESTYPE;
/*     */     }
/*  88 */     if (strColName.equalsIgnoreCase("ACCESSTOKEN"))
/*     */     {
/*  90 */       return "" + this.ACCESSTOKEN;
/*     */     }
/*  92 */     if (strColName.equalsIgnoreCase("URLTARGET"))
/*     */     {
/*  94 */       return "" + this.URLTARGET;
/*     */     }
/*  96 */     if (strColName.equalsIgnoreCase("URLPORT"))
/*     */     {
/*  98 */       return "" + this.URLPORT;
/*     */     }
/* 100 */     return "";
/*     */   }
/*     */ 
/*     */   public void set(String strColName, String strValue)
/*     */   {
/*     */     try
/*     */     {
/* 107 */       if (strColName.equalsIgnoreCase("MENUITEMID"))
/*     */       {
/* 109 */         this.MENUITEMID = Integer.parseInt(strValue);
/*     */       }
/* 111 */       if (strColName.equalsIgnoreCase("MENUITEMTITLE"))
/*     */       {
/* 113 */         this.MENUITEMTITLE = strValue;
/*     */       }
/* 115 */       if (strColName.equalsIgnoreCase("PARENTID"))
/*     */       {
/* 117 */         this.PARENTID = Integer.parseInt(strValue);
/*     */       }
/* 119 */       if (strColName.equalsIgnoreCase("SORTNUM"))
/*     */       {
/* 121 */         this.SORTNUM = Integer.parseInt(strValue);
/*     */       }
/* 123 */       if (strColName.equalsIgnoreCase("PIC1"))
/*     */       {
/* 125 */         this.PIC1 = strValue;
/*     */       }
/* 127 */       if (strColName.equalsIgnoreCase("PIC2"))
/*     */       {
/* 129 */         this.PIC2 = strValue;
/*     */       }
/* 131 */       if (strColName.equalsIgnoreCase("MENUTYPE"))
/*     */       {
/* 133 */         this.MENUTYPE = Integer.parseInt(strValue);
/*     */       }
/* 135 */       if (strColName.equalsIgnoreCase("URL"))
/*     */       {
/* 137 */         this.URL = strValue;
/*     */       }
/* 139 */       if (strColName.equalsIgnoreCase("RESID"))
/*     */       {
/* 141 */         this.RESID = strValue;
/*     */       }
/* 143 */       if (strColName.equalsIgnoreCase("RESTYPE"))
/*     */       {
/* 145 */         this.RESTYPE = Integer.parseInt(strValue);
/*     */       }
/* 147 */       if (strColName.equalsIgnoreCase("ACCESSTOKEN"))
/*     */       {
/* 149 */         this.ACCESSTOKEN = Integer.parseInt(strValue);
/*     */       }
/* 151 */       if (strColName.equalsIgnoreCase("URLTARGET"))
/*     */       {
/* 153 */         this.URLTARGET = strValue;
/*     */       }
/* 155 */       if (strColName.equalsIgnoreCase("URLPORT"))
/*     */       {
/* 157 */         this.URLPORT = strValue;
/*     */       }
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getURLPORT()
/*     */   {
/* 167 */     return this.URLPORT;
/*     */   }
/*     */   public void setURLPORT(String urlPort) {
/* 170 */     this.URLPORT = urlPort;
/*     */   }
/*     */ 
/*     */   public String getURLTARGET() {
/* 174 */     return this.URLTARGET;
/*     */   }
/*     */   public void setURLTARGET(String urlTarget) {
/* 177 */     this.URLTARGET = urlTarget;
/*     */   }
/*     */ 
/*     */   public int getACCESSTOKEN() {
/* 181 */     return this.ACCESSTOKEN;
/*     */   }
/*     */   public void setACCESSTOKEN(int accesstoken) {
/* 184 */     this.ACCESSTOKEN = accesstoken;
/*     */   }
/*     */   public int getMENUITEMID() {
/* 187 */     return this.MENUITEMID;
/*     */   }
/*     */   public void setMENUITEMID(int menuitemid) {
/* 190 */     this.MENUITEMID = menuitemid;
/*     */   }
/*     */   public String getMENUITEMTITLE() {
/* 193 */     return this.MENUITEMTITLE;
/*     */   }
/*     */   public void setMENUITEMTITLE(String menuitemtitle) {
/* 196 */     this.MENUITEMTITLE = menuitemtitle;
/*     */   }
/*     */   public int getMENUTYPE() {
/* 199 */     return this.MENUTYPE;
/*     */   }
/*     */   public void setMENUTYPE(int menutype) {
/* 202 */     this.MENUTYPE = menutype;
/*     */   }
/*     */   public int getPARENTID() {
/* 205 */     return this.PARENTID;
/*     */   }
/*     */   public void setPARENTID(int parentid) {
/* 208 */     this.PARENTID = parentid;
/*     */   }
/*     */   public String getPIC1() {
/* 211 */     return this.PIC1;
/*     */   }
/*     */   public void setPIC1(String pic1) {
/* 214 */     this.PIC1 = pic1;
/*     */   }
/*     */   public String getPIC2() {
/* 217 */     return this.PIC2;
/*     */   }
/*     */   public void setPIC2(String pic2) {
/* 220 */     this.PIC2 = pic2;
/*     */   }
/*     */   public String getRESID() {
/* 223 */     return this.RESID;
/*     */   }
/*     */   public void setRESID(String resid) {
/* 226 */     this.RESID = resid;
/*     */   }
/*     */   public int getRESTYPE() {
/* 229 */     return this.RESTYPE;
/*     */   }
/*     */   public void setRESTYPE(int restype) {
/* 232 */     this.RESTYPE = restype;
/*     */   }
/*     */   public int getSORTNUM() {
/* 235 */     return this.SORTNUM;
/*     */   }
/*     */   public void setSORTNUM(int sortnum) {
/* 238 */     this.SORTNUM = sortnum;
/*     */   }
/*     */   public String getURL() {
/* 241 */     return this.URL;
/*     */   }
/*     */   public void setURL(String url) {
/* 244 */     this.URL = url;
/*     */   }
/*     */   public String[] getRoles() {
/* 247 */     return this.roles;
/*     */   }
/*     */   public void setRoles(String[] roles) {
/* 250 */     this.roles = roles;
/*     */   }
/*     */ 
/*     */   public boolean isHasSon() {
/* 254 */     return this.hasSon;
/*     */   }
/*     */ 
/*     */   public void setHasSon(boolean hasSon) {
/* 258 */     this.hasSon = hasSon;
/*     */   }
/*     */ 
/*     */   public String getApplicationId() {
/* 262 */     return this.applicationId;
/*     */   }
/*     */ 
/*     */   public void setApplicationId(String applicationId) {
/* 266 */     this.applicationId = applicationId;
/*     */   }
/*     */ 
/*     */   public String getApplicaionName() {
/* 270 */     return this.applicaionName;
/*     */   }
/*     */ 
/*     */   public void setApplicaionName(String applicaionName) {
/* 274 */     this.applicaionName = applicaionName;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean
 * JD-Core Version:    0.6.2
 */
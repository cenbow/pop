/*    */ package com.asiainfo.biframe.privilege.menu.bo;
/*    */ 
/*    */ public class ZTreeNodeBo
/*    */ {
/*    */   private String id;
/*    */   private String name;
/*    */   private String pid;
/*    */   private String url;
/*    */   private String target;
/*    */   private boolean open;
/*    */   private boolean isParent;
/*    */   private boolean checked;
/*    */   private boolean nocheck;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 15 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 18 */     this.id = id;
/*    */   }
/*    */   public String getName() {
/* 21 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 24 */     this.name = name;
/*    */   }
/*    */   public String getPid() {
/* 27 */     return this.pid;
/*    */   }
/*    */   public void setPid(String pid) {
/* 30 */     this.pid = pid;
/*    */   }
/*    */ 
/*    */   public String getUrl()
/*    */   {
/* 36 */     return this.url;
/*    */   }
/*    */ 
/*    */   public void setUrl(String url)
/*    */   {
/* 42 */     this.url = url;
/*    */   }
/*    */ 
/*    */   public String getTarget()
/*    */   {
/* 48 */     return this.target;
/*    */   }
/*    */ 
/*    */   public void setTarget(String target)
/*    */   {
/* 54 */     this.target = target;
/*    */   }
/*    */ 
/*    */   public boolean isOpen()
/*    */   {
/* 59 */     return this.open;
/*    */   }
/*    */ 
/*    */   public void setOpen(boolean open) {
/* 63 */     this.open = open;
/*    */   }
/*    */ 
/*    */   public boolean getIsParent()
/*    */   {
/* 69 */     return this.isParent;
/*    */   }
/*    */ 
/*    */   public void setIsParent(boolean isParent)
/*    */   {
/* 75 */     this.isParent = isParent;
/*    */   }
/*    */ 
/*    */   public boolean isChecked() {
/* 79 */     return this.checked;
/*    */   }
/*    */ 
/*    */   public void setChecked(boolean checked) {
/* 83 */     this.checked = checked;
/*    */   }
/*    */ 
/*    */   public boolean isNocheck() {
/* 87 */     return this.nocheck;
/*    */   }
/*    */ 
/*    */   public void setNocheck(boolean nocheck) {
/* 91 */     this.nocheck = nocheck;
/*    */   }
/*    */ 
/*    */   public void setParent(boolean isParent) {
/* 95 */     this.isParent = isParent;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.bo.ZTreeNodeBo
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.menu.dao;

import com.asiainfo.biframe.exception.DaoException;
import com.asiainfo.biframe.privilege.model.UserApplication;
import java.util.List;
import java.util.Map;

public abstract interface IUserApplicationDao
{
  public abstract void save(UserApplication paramUserApplication)
    throws DaoException;

  public abstract void update(UserApplication paramUserApplication)
    throws DaoException;

  public abstract void delete(UserApplication paramUserApplication)
    throws DaoException;

  public abstract UserApplication getById(String paramString)
    throws DaoException;

  public abstract UserApplication getByName(String paramString)
    throws DaoException;

  public abstract List<UserApplication> getAllApplications()
    throws DaoException;

  public abstract Map getPagedApplications(UserApplication paramUserApplication, int paramInt1, int paramInt2)
    throws DaoException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.dao.IUserApplicationDao
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.menu.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.menu.dao.IUserApplicationDao;
/*     */ import com.asiainfo.biframe.privilege.model.UserApplication;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserApplicationDao extends HibernateDaoSupport
/*     */   implements IUserApplicationDao
/*     */ {
/*  33 */   private static Logger log = Logger.getLogger(UserApplicationDao.class);
/*     */ 
/*     */   public void delete(UserApplication app) throws DaoException {
/*     */     try {
/*  37 */       log.debug("in delete");
/*  38 */       getHibernateTemplate().delete(app);
/*  39 */       log.debug("end delete");
/*     */     } catch (DataAccessException e) {
/*  41 */       log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteAppFail") + "", e);
/*  42 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteAppFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public UserApplication getById(String applicationId) {
/*     */     try {
/*  48 */       log.debug("in getById");
/*  49 */       UserApplication app = (UserApplication)getHibernateTemplate().get(UserApplication.class, applicationId);
/*  50 */       log.debug("end getById");
/*  51 */       return app;
/*     */     } catch (DataAccessException e) {
/*  53 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByIdFail"), e);
/*  54 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByIdFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public UserApplication getByName(String applicationName)
/*     */   {
/*     */     try
/*     */     {
/*  63 */       log.debug("in getByName");
/*  64 */       String hql = "from UserApplication app where app.applicationName='" + applicationName + "'";
/*  65 */       log.debug("--hql:" + hql);
/*  66 */       List appList = getHibernateTemplate().find(hql);
/*  67 */       if (appList.isEmpty()) {
/*  68 */         return null;
/*     */       }
/*  70 */       log.debug("end getByName");
/*  71 */       return (UserApplication)appList.get(0);
/*     */     } catch (DataAccessException e) {
/*  73 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByNameFail") + "", e);
/*  74 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByNameFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<UserApplication> getAllApplications()
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/*  83 */       log.debug("in getAllApplications");
/*  84 */       String hql = "from UserApplication";
/*  85 */       List appList = getHibernateTemplate().find(hql);
/*  86 */       log.debug("end getAllApplications");
/*  87 */       return appList;
/*     */     } catch (DataAccessException e) {
/*  89 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAllAppFail") + "", e);
/*  90 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAllAppFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map getPagedApplications(UserApplication app, final int currPage, final int pageSize) throws DaoException {
/*  95 */     log.debug("in getPagedApplications........");
/*  96 */     HashMap map = new HashMap();
/*     */     try {
/*  98 */       String whereSql = getWhereSql(app);
/*     */ 
/* 100 */       String countSql = "select count(app) from UserApplication app " + whereSql;
/* 101 */       log.debug("--countSql:" + countSql);
/* 102 */       List list = getHibernateTemplate().find(countSql);
/* 103 */       int totals = 0;
/* 104 */       if ((list != null) && (list.size() > 0)) {
/* 105 */         totals = ((Long)list.get(0)).intValue();
/*     */       }
/*     */ 
/* 108 */       final String listSql = "from UserApplication app " + whereSql;
/* 109 */       log.debug("--listSql:" + listSql);
/* 110 */       list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */         public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 112 */           Query query = s.createQuery(listSql);
/* 113 */           int firstResult = currPage * pageSize;
/* 114 */           query.setFirstResult(firstResult);
/* 115 */           query.setMaxResults(pageSize);
/* 116 */           List tmpList = query.list();
/* 117 */           return tmpList;
/*     */         }
/*     */       });
/* 121 */       map.put("total", new Integer(totals));
/* 122 */       map.put("result", list);
/* 123 */       log.debug("end getPagedApplications");
/* 124 */       return map;
/*     */     } catch (DataAccessException e) {
/* 126 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByConditionFail") + "", e);
/* 127 */       map.put("total", new Integer(0));
/* 128 */       map.put("result", new ArrayList());
/* 129 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByConditionFail") + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getWhereSql(UserApplication app) {
/* 134 */     StringBuilder whereSql = new StringBuilder(256).append(" where 1=1 ");
/* 135 */     String applicationId = app.getApplicationId();
/* 136 */     String applicationName = app.getApplicationName();
/* 137 */     String note = app.getNote();
/*     */ 
/* 139 */     if (StringUtils.isNotBlank(applicationId)) {
/* 140 */       whereSql.append(" and app.applicationId like '%").append(applicationId).append("%'");
/*     */     }
/* 142 */     if (StringUtils.isNotBlank(applicationName)) {
/* 143 */       whereSql.append(" and app.applicationName like '%").append(applicationName).append("%'");
/*     */     }
/* 145 */     if (StringUtils.isNotBlank(note)) {
/* 146 */       whereSql.append(" and app.note like '%").append(note).append("%'");
/*     */     }
/* 148 */     return whereSql.toString();
/*     */   }
/*     */ 
/*     */   public void save(UserApplication app) throws DaoException {
/*     */     try {
/* 153 */       log.debug("in save");
/* 154 */       getHibernateTemplate().save(app);
/* 155 */       log.debug("end save");
/*     */     } catch (DataAccessException e) {
/* 157 */       log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addAppDefineFail") + "", e);
/* 158 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addAppDefineFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void update(UserApplication app) throws DaoException {
/*     */     try {
/* 164 */       log.debug("in update");
/* 165 */       getHibernateTemplate().update(app);
/* 166 */       log.debug("end update");
/*     */     } catch (DataAccessException e) {
/* 168 */       log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyAppFail") + "", e);
/* 169 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyAppFail") + "", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.dao.impl.UserApplicationDao
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.menu.serivce;

import com.asiainfo.biframe.privilege.menu.bo.ZTreeNodeBo;
import java.util.List;

public abstract interface IMenuMangerService
{
  public abstract List<ZTreeNodeBo> getMenuTreeList(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract List<ZTreeNodeBo> getMenuTreeList(String paramString1, String paramString2, String paramString3);

  public abstract List<ZTreeNodeBo> getMenuList(String paramString1, String paramString2, String paramString3);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.serivce.IMenuMangerService
 * JD-Core Version:    0.6.2
 */
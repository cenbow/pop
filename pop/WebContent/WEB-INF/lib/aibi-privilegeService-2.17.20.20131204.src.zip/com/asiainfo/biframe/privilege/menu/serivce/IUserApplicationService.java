package com.asiainfo.biframe.privilege.menu.serivce;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.model.UserApplication;
import java.util.Collection;
import java.util.Map;

public abstract interface IUserApplicationService
{
  public abstract void add(UserApplication paramUserApplication)
    throws ServiceException;

  public abstract void update(UserApplication paramUserApplication)
    throws ServiceException;

  public abstract void delete(UserApplication paramUserApplication)
    throws ServiceException;

  public abstract UserApplication getById(String paramString)
    throws ServiceException;

  public abstract UserApplication getByName(String paramString)
    throws ServiceException;

  public abstract Collection getAllApplications()
    throws ServiceException;

  public abstract Map getPagedApplications(UserApplication paramUserApplication, int paramInt1, int paramInt2)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.serivce.IUserApplicationService
 * JD-Core Version:    0.6.2
 */
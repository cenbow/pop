/*     */ package com.asiainfo.biframe.privilege.menu.serivce.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.cache.object.SysMenuItemViewCache;
/*     */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*     */ import com.asiainfo.biframe.privilege.menu.bo.ZTreeNodeBo;
/*     */ import com.asiainfo.biframe.privilege.menu.serivce.IMenuMangerService;
/*     */ import com.asiainfo.biframe.privilege.model.SysMenuItem;
/*     */ import com.asiainfo.biframe.privilege.uniauth.service.IUserRightService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class MenuMangerServiceImpl
/*     */   implements IMenuMangerService
/*     */ {
/*  27 */   private Log log = LogFactory.getLog(MenuMangerServiceImpl.class);
/*     */   private IUserRightService rightService;
/*     */ 
/*     */   public List<ZTreeNodeBo> getMenuTreeList(String userId, String userGroupId, String parentId, String name)
/*     */   {
/*  36 */     List list = new ArrayList();
/*  37 */     ZTreeNodeBo item = null;
/*  38 */     if ((parentId == null) || ("".equals(parentId))) {
/*  39 */       parentId = "0";
/*  40 */       item = new ZTreeNodeBo();
/*  41 */       item.setName(LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.menuRoot"));
/*  42 */       item.setId(parentId);
/*  43 */       item.setPid("-1");
/*  44 */       item.setIsParent(true);
/*  45 */       item.setOpen(true);
/*  46 */       list.add(item);
/*     */     }
/*     */ 
/*  50 */     List alllist = this.rightService.getResourceIdListOfRight(userId, "50");
/*  51 */     this.log.debug("allList:" + alllist.toString());
/*     */ 
/*  54 */     List menuList = this.rightService.getSystemMenuResourceListByName(name);
/*  55 */     this.log.debug("menuList:" + menuList.toString());
/*     */ 
/*  58 */     Set nodeSet = new HashSet();
/*  59 */     List smiList = new ArrayList();
/*     */     Iterator iterator;
/*  60 */     if (alllist != null) {
/*  61 */       for (iterator = menuList.iterator(); iterator.hasNext(); ) {
/*  62 */         SysMenuItemBean menuItem = (SysMenuItemBean)iterator.next();
/*  63 */         if (alllist.contains(menuItem.getMENUITEMID())) {
/*  64 */           getAllParentMenuList(Integer.valueOf(menuItem.getMENUITEMID()), smiList, nodeSet);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  69 */     Map map = new HashMap();
/*  70 */     for (SysMenuItem smi : smiList) {
/*  71 */       map.put(smi.getParentId().toString(), smi.getMenuItemId().toString());
/*     */     }
/*  73 */     for (SysMenuItem smi : smiList) {
/*  74 */       item = new ZTreeNodeBo();
/*  75 */       smi.setMenuItemTitle(encodeString(smi.getMenuItemTitle()));
/*  76 */       item.setName(smi.getMenuItemTitle());
/*  77 */       item.setId(String.valueOf(smi.getMenuItemId()));
/*  78 */       item.setPid(String.valueOf(smi.getParentId()));
/*  79 */       if (null != map.get(item.getId()))
/*  80 */         item.setIsParent(true);
/*     */       else {
/*  82 */         item.setIsParent(false);
/*     */       }
/*  84 */       list.add(item);
/*     */     }
/*  86 */     return list;
/*     */   }
/*     */ 
/*     */   public List<ZTreeNodeBo> getMenuTreeList(String userId, String userGroupId, String parentId)
/*     */   {
/*  94 */     List list = new ArrayList();
/*  95 */     ZTreeNodeBo item = null;
/*  96 */     if ((parentId == null) || ("".equals(parentId))) {
/*  97 */       parentId = "0";
/*  98 */       item = new ZTreeNodeBo();
/*  99 */       item.setName(LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.menuRoot"));
/* 100 */       item.setId(parentId);
/* 101 */       item.setPid("-1");
/* 102 */       item.setIsParent(true);
/* 103 */       item.setOpen(true);
/* 104 */       list.add(item);
/*     */     }
/*     */ 
/* 107 */     List alllist = this.rightService.getResourceIdListOfRight(userId, "50");
/* 108 */     this.log.debug("allList:" + alllist.toString());
/* 109 */     Iterator iter = SysMenuItemViewCache.getInstance().getAllCachedObject().iterator();
/* 110 */     while (iter.hasNext()) {
/* 111 */       SysMenuItem smi = (SysMenuItem)iter.next();
/* 112 */       if ((null != smi) && (Integer.parseInt(parentId) == smi.getParentId().intValue()) && 
/* 113 */         (null != alllist) && (alllist.contains(smi.getMenuItemId().toString()))) {
/* 114 */         item = new ZTreeNodeBo();
/* 115 */         smi.setMenuItemTitle(encodeString(smi.getMenuItemTitle()));
/* 116 */         item.setName(smi.getMenuItemTitle());
/* 117 */         item.setId(String.valueOf(smi.getMenuItemId()));
/* 118 */         item.setPid(String.valueOf(smi.getParentId()));
/* 119 */         item.setIsParent(smi.isFolderOrNot());
/* 120 */         list.add(item);
/*     */       }
/*     */     }
/*     */ 
/* 124 */     this.log.debug("resultList:" + list.toString());
/* 125 */     SysMenuItem object = null;
/* 126 */     return list;
/*     */   }
/*     */ 
/*     */   public static String encodeString(String strData)
/*     */   {
/* 131 */     if (strData == null)
/*     */     {
/* 133 */       return "";
/*     */     }
/* 135 */     strData = StringUtil.replaceAll(strData, "&", "&amp;");
/* 136 */     strData = StringUtil.replaceAll(strData, "<", "&lt;");
/* 137 */     strData = StringUtil.replaceAll(strData, ">", "&gt;");
/* 138 */     strData = StringUtil.replaceAll(strData, "&apos;", "&apos;");
/* 139 */     strData = StringUtil.replaceAll(strData, "\"", "&quot;");
/* 140 */     return strData;
/*     */   }
/*     */ 
/*     */   public boolean isHasSon(SysMenuItemBean menuItem)
/*     */   {
/* 148 */     boolean isHasSon = false;
/* 149 */     List menuList = this.rightService.getSystemMenuResourceListOfRight(Integer.valueOf(menuItem.getMENUITEMID()).toString());
/* 150 */     if ((menuList != null) && (menuList.size() > 0)) {
/* 151 */       isHasSon = true;
/*     */     }
/* 153 */     return isHasSon;
/*     */   }
/*     */ 
/*     */   public List<ZTreeNodeBo> getParentTreeNodes(SysMenuItemBean subMenuItem, Set<String> nodeSet)
/*     */   {
/* 161 */     ZTreeNodeBo item = null;
/* 162 */     List list = new ArrayList();
/* 163 */     List menuList = this.rightService.getAllParentSystemMenuResouceList(subMenuItem.getMENUITEMID());
/* 164 */     if ((menuList != null) && (menuList.size() > 0)) {
/* 165 */       for (SysMenuItemBean menuItem : menuList) {
/* 166 */         item = new ZTreeNodeBo();
/* 167 */         menuItem.setMENUITEMTITLE(encodeString(menuItem.getMENUITEMTITLE()));
/* 168 */         item.setName(menuItem.getMENUITEMTITLE());
/* 169 */         item.setId(String.valueOf(menuItem.getMENUITEMID()));
/* 170 */         item.setPid(String.valueOf(menuItem.getPARENTID()));
/* 171 */         item.setIsParent(true);
/* 172 */         if (!nodeSet.contains(item.getId() + "|" + item.getPid())) {
/* 173 */           list.add(item);
/* 174 */           nodeSet.add(item.getId() + "|" + item.getPid());
/*     */         }
/*     */       }
/*     */     }
/* 178 */     return list;
/*     */   }
/*     */ 
/*     */   public List<ZTreeNodeBo> getMenuList(String userId, String parentId, String modifyId) {
/* 182 */     List itemList = new ArrayList();
/* 183 */     if (StringUtils.isNotBlank(modifyId)) {
/* 184 */       itemList.add(modifyId);
/* 185 */       List smiList = new ArrayList();
/* 186 */       smiList = SysMenuItemViewCache.getInstance().getSubMenuItemById(Integer.parseInt(modifyId), smiList, true);
/* 187 */       for (SysMenuItem smi : smiList) {
/* 188 */         itemList.add(smi.getMenuItemId().toString());
/*     */       }
/*     */     }
/*     */ 
/* 192 */     List list = new ArrayList();
/* 193 */     ZTreeNodeBo item = null;
/* 194 */     if (StringUtils.isBlank(parentId)) {
/* 195 */       parentId = "0";
/* 196 */       item = new ZTreeNodeBo();
/* 197 */       item.setName(LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.menuRoot"));
/* 198 */       item.setId(parentId);
/* 199 */       item.setPid("-1");
/* 200 */       item.setIsParent(true);
/* 201 */       item.setOpen(true);
/* 202 */       list.add(item);
/*     */     }
/*     */     try {
/* 205 */       List menuList = new ArrayList();
/* 206 */       menuList = this.rightService.getResourceIdListOfRight(userId, "50");
/* 207 */       Iterator iter = SysMenuItemViewCache.getInstance().getAllCachedObject().iterator();
/* 208 */       while (iter.hasNext()) {
/* 209 */         SysMenuItem smi = (SysMenuItem)iter.next();
/* 210 */         if ((null != smi) && (Integer.parseInt(parentId) == smi.getParentId().intValue()) && (menuList.contains(smi.getMenuItemId().toString()))) {
/* 211 */           item = new ZTreeNodeBo();
/* 212 */           smi.setMenuItemTitle(encodeString(smi.getMenuItemTitle()));
/* 213 */           item.setName(smi.getMenuItemTitle());
/* 214 */           item.setId(String.valueOf(smi.getMenuItemId()));
/* 215 */           item.setPid(String.valueOf(smi.getParentId()));
/* 216 */           item.setIsParent(smi.isFolderOrNot());
/* 217 */           if (itemList.contains(String.valueOf(smi.getMenuItemId()))) {
/* 218 */             item.setNocheck(true);
/*     */           }
/* 220 */           list.add(item);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 224 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/* 227 */     return list;
/*     */   }
/*     */ 
/*     */   private void getAllParentMenuList(Integer menuitemId, List<SysMenuItem> smiList, Set<String> menuSet) {
/* 231 */     if ((menuitemId.intValue() == 0) || (menuitemId.intValue() == -1)) {
/* 232 */       return;
/*     */     }
/* 234 */     Collection collection = SysMenuItemViewCache.getInstance().getAllCachedObject();
/* 235 */     if ((null != collection) && (!collection.isEmpty())) {
/* 236 */       Iterator it = collection.iterator();
/* 237 */       while (it.hasNext()) {
/* 238 */         SysMenuItem smi = (SysMenuItem)it.next();
/* 239 */         if ((menuitemId.equals(smi.getMenuItemId())) && (!menuSet.contains(smi.getMenuItemId() + "|" + smi.getParentId()))) {
/* 240 */           smiList.add(smi);
/* 241 */           menuSet.add(smi.getMenuItemId() + "|" + smi.getParentId());
/* 242 */           getAllParentMenuList(smi.getParentId(), smiList, menuSet);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/* 248 */   public IUserRightService getRightService() { return this.rightService; }
/*     */ 
/*     */ 
/*     */   public void setRightService(IUserRightService rightService)
/*     */   {
/* 253 */     this.rightService = rightService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.serivce.impl.MenuMangerServiceImpl
 * JD-Core Version:    0.6.2
 */
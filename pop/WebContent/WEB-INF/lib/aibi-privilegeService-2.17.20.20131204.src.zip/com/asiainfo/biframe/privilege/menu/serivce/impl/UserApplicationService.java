/*     */ package com.asiainfo.biframe.privilege.menu.serivce.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.base.util.BeanUtils;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.menu.SysMenuMaintain;
/*     */ import com.asiainfo.biframe.privilege.menu.dao.IUserApplicationDao;
/*     */ import com.asiainfo.biframe.privilege.menu.serivce.IUserApplicationService;
/*     */ import com.asiainfo.biframe.privilege.model.UserApplication;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UserApplicationService
/*     */   implements IUserApplicationService
/*     */ {
/*  30 */   private static Logger log = Logger.getLogger(UserApplicationService.class);
/*     */   private IUserApplicationDao userApplicationDao;
/*     */ 
/*     */   public void add(UserApplication app)
/*     */     throws ServiceException
/*     */   {
/*  37 */     log.debug("in add");
/*     */     try {
/*  39 */       String applicationId = app.getApplicationId();
/*  40 */       String applicationName = app.getApplicationName();
/*  41 */       UserApplication realApp = getUserApplicationDao().getById(applicationId);
/*  42 */       if (realApp != null) {
/*  43 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appIdExist") + applicationId);
/*     */       }
/*  45 */       UserApplication realAppByName = getUserApplicationDao().getByName(applicationName);
/*  46 */       if (realAppByName != null) {
/*  47 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appNameExist") + "" + applicationName);
/*     */       }
/*     */ 
/*  50 */       getUserApplicationDao().save(app);
/*  51 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_APPDEFINE"), applicationId, applicationName, "应用定义管理-->添加应用定义", null, null);
/*     */ 
/*  54 */       log.debug("end add");
/*     */     } catch (DaoException e) {
/*  56 */       log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addAppFail") + "", e);
/*  57 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addAppFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(UserApplication app)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/*  68 */       log.debug("in delete");
/*  69 */       UserApplication realApp = getUserApplicationDao().getById(app.getApplicationId());
/*  70 */       String applicationId = realApp.getApplicationId();
/*  71 */       String applicationName = realApp.getApplicationName();
/*     */ 
/*  73 */       if (realApp == null) {
/*  74 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appDefineExist") + applicationId);
/*     */       }
/*     */ 
/*  77 */       if (isUsedByMenu(applicationId)) {
/*  78 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appInUse") + applicationId);
/*     */       }
/*     */ 
/*  81 */       getUserApplicationDao().delete(realApp);
/*  82 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_APPDEFINE"), applicationId, applicationName, "应用定义管理-->删除应用定义", null, null);
/*     */ 
/*  85 */       log.debug("end delete");
/*     */     } catch (DaoException e) {
/*  87 */       log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteAppFail") + "", e);
/*  88 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteAppFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isUsedByMenu(String applicationId)
/*     */   {
/*  99 */     List list = SysMenuMaintain.getMenuListByApplicationId(applicationId);
/* 100 */     if (list.isEmpty()) {
/* 101 */       return false;
/*     */     }
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */   public UserApplication getById(String applicationId)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 111 */       log.debug("in getById");
/* 112 */       UserApplication app = getUserApplicationDao().getById(applicationId);
/* 113 */       log.debug("end getById");
/* 114 */       return app;
/*     */     } catch (DaoException e) {
/* 116 */       log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByIdFail"), e);
/* 117 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByIdFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public UserApplication getByName(String applicationName)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 126 */       log.debug("in getByName");
/* 127 */       UserApplication app = getUserApplicationDao().getByName(applicationName);
/* 128 */       log.debug("end getByName");
/* 129 */       return app;
/*     */     } catch (DaoException e) {
/* 131 */       log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByNameFail") + "", e);
/* 132 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByNameFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Collection getAllApplications()
/*     */     throws ServiceException
/*     */   {
/* 140 */     log.debug("in getAllApplications");
/* 141 */     return getUserApplicationDao().getAllApplications();
/*     */   }
/*     */ 
/*     */   public Map getPagedApplications(UserApplication app, int currPage, int pageSize)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 150 */       log.debug("in getPagedApplications");
/* 151 */       return getUserApplicationDao().getPagedApplications(app, currPage, pageSize);
/*     */     } catch (DaoException e) {
/* 153 */       log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByConditionFail"), e);
/* 154 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findAppByConditionFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void update(UserApplication app)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 163 */       log.debug("in update");
/* 164 */       String applicationId = app.getApplicationId();
/* 165 */       String applicationName = app.getApplicationName();
/* 166 */       UserApplication realApp = getUserApplicationDao().getById(applicationId);
/* 167 */       if (realApp == null) {
/* 168 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appDefineExist") + ":" + applicationId);
/*     */       }
/* 170 */       UserApplication realAppByName = getUserApplicationDao().getByName(applicationName);
/* 171 */       if ((realAppByName != null) && (!realAppByName.getApplicationId().equals(applicationId))) {
/* 172 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appNameExist1") + "[" + applicationName + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.appNameExist2") + "");
/*     */       }
/*     */ 
/* 175 */       BeanUtils.copyProperties(realApp, app);
/* 176 */       getUserApplicationDao().update(realApp);
/* 177 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_APPDEFINE"), applicationId, applicationName, "应用定义管理-->修改应用定义", null, null);
/*     */ 
/* 180 */       log.debug("end update");
/*     */     } catch (DaoException e) {
/* 182 */       log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyAppFail") + "", e);
/* 183 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyAppFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public IUserApplicationDao getUserApplicationDao()
/*     */   {
/* 189 */     return this.userApplicationDao;
/*     */   }
/*     */ 
/*     */   public void setUserApplicationDao(IUserApplicationDao userApplicationDao) {
/* 193 */     this.userApplicationDao = userApplicationDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.menu.serivce.impl.UserApplicationService
 * JD-Core Version:    0.6.2
 */
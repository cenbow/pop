/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class FirstpagesetParam
/*     */   implements Serializable
/*     */ {
/*  15 */   private int hashValue = 0;
/*     */   private String operatorId;
/*     */   private Short operatorType;
/*     */   private String resourcePath;
/*     */ 
/*     */   public String getOperatorId()
/*     */   {
/*  32 */     return this.operatorId;
/*     */   }
/*     */ 
/*     */   public void setOperatorId(String operatorValue)
/*     */   {
/*  41 */     this.hashValue = 0;
/*  42 */     this.operatorId = operatorValue;
/*     */   }
/*     */ 
/*     */   public Short getOperatorType()
/*     */   {
/*  51 */     return this.operatorType;
/*     */   }
/*     */ 
/*     */   public void setOperatorType(Short operatorType)
/*     */   {
/*  60 */     this.operatorType = operatorType;
/*     */   }
/*     */ 
/*     */   public String getResourcePath()
/*     */   {
/*  69 */     return this.resourcePath;
/*     */   }
/*     */ 
/*     */   public void setResourcePath(String resourcePath)
/*     */   {
/*  78 */     this.resourcePath = resourcePath;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object rhs)
/*     */   {
/*  89 */     if (rhs == null)
/*  90 */       return false;
/*  91 */     if (!(rhs instanceof FirstpagesetParam))
/*  92 */       return false;
/*  93 */     FirstpagesetParam that = (FirstpagesetParam)rhs;
/*  94 */     if ((getOperatorId() == null) || (that.getOperatorId() == null))
/*  95 */       return false;
/*  96 */     return getOperatorId().equals(that.getOperatorId());
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 107 */     if (this.hashValue == 0)
/*     */     {
/* 109 */       int result = 17;
/* 110 */       int operatorValueValue = getOperatorId() == null ? 0 : getOperatorId().hashCode();
/* 111 */       result = result * 37 + operatorValueValue;
/* 112 */       this.hashValue = result;
/*     */     }
/* 114 */     return this.hashValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.FirstpagesetParam
 * JD-Core Version:    0.6.2
 */
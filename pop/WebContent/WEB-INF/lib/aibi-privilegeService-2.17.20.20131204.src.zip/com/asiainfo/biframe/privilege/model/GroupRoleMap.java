/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.IGroupRoleMap;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ public class GroupRoleMap
/*    */   implements Serializable, IGroupRoleMap
/*    */ {
/*    */   private String groupId;
/*    */   private String roleId;
/*    */ 
/*    */   public GroupRoleMap()
/*    */   {
/*    */   }
/*    */ 
/*    */   public GroupRoleMap(String groupId, String roleId)
/*    */   {
/* 28 */     this.groupId = groupId;
/* 29 */     this.roleId = roleId;
/*    */   }
/*    */ 
/*    */   public String getGroupId()
/*    */   {
/* 35 */     return this.groupId;
/*    */   }
/*    */ 
/*    */   public void setGroupId(String groupId) {
/* 39 */     this.groupId = groupId;
/*    */   }
/*    */ 
/*    */   public String getRoleId() {
/* 43 */     return this.roleId;
/*    */   }
/*    */ 
/*    */   public void setRoleId(String roleId) {
/* 47 */     this.roleId = roleId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 52 */     if (this == other)
/* 53 */       return true;
/* 54 */     if (other == null)
/* 55 */       return false;
/* 56 */     if (!(other instanceof GroupRoleMap))
/* 57 */       return false;
/* 58 */     GroupRoleMap castOther = (GroupRoleMap)other;
/*    */ 
/* 60 */     return ((getGroupId() == castOther.getGroupId()) || ((getGroupId() != null) && (castOther.getGroupId() != null) && (getGroupId().equals(castOther.getGroupId())))) && ((getRoleId() == castOther.getRoleId()) || ((getRoleId() != null) && (castOther.getRoleId() != null) && (getRoleId().equals(castOther.getRoleId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 72 */     int result = 17;
/*    */ 
/* 74 */     result = 37 * result + (getGroupId() == null ? 0 : getGroupId().hashCode());
/*    */ 
/* 76 */     result = 37 * result + (getRoleId() == null ? 0 : getRoleId().hashCode());
/*    */ 
/* 78 */     return result;
/*    */   }
/*    */   public Map toMap() {
/* 81 */     Map map = new HashMap();
/* 82 */     Map infoMap = new HashMap();
/* 83 */     infoMap.put("GROUPID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userGroup") + "ID", getGroupId());
/* 84 */     infoMap.put("ROLEID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.role") + "ID", getRoleId());
/* 85 */     map.put("GROUPROLEMAP", infoMap);
/* 86 */     return map;
/*    */   }
/*    */   public Map roleToMap() {
/* 89 */     Map map = new HashMap();
/* 90 */     Map infoMap = new HashMap();
/* 91 */     infoMap.put("ROLEID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.role") + "ID", getRoleId());
/* 92 */     map.put("GROUPROLEMAP", infoMap);
/* 93 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.GroupRoleMap
 * JD-Core Version:    0.6.2
 */
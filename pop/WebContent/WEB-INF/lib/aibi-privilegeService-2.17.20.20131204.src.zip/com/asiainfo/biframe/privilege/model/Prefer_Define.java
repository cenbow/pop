/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class Prefer_Define
/*     */   implements Serializable
/*     */ {
/*     */   private String preferId;
/*     */   private String preferName;
/*     */   private String preferKey;
/*     */   private String preferKeyId;
/*     */   private String preferKeyValue;
/*     */   private long havePrivilege;
/*     */   private long sortNum;
/*     */   private String db;
/*     */   private String notes;
/*     */ 
/*     */   public Prefer_Define()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Prefer_Define(String preferId, String preferKey, String preferKeyId, String preferKeyValue, long havePrivilege, long sortNum, String notes)
/*     */   {
/*  35 */     this.preferId = preferId;
/*  36 */     this.preferKey = preferKey;
/*  37 */     this.preferKeyId = preferKeyId;
/*  38 */     this.preferKeyValue = preferKeyValue;
/*  39 */     this.havePrivilege = havePrivilege;
/*  40 */     this.sortNum = sortNum;
/*  41 */     this.notes = notes;
/*     */   }
/*     */ 
/*     */   public Prefer_Define(String preferId, String preferName, String preferKey, String preferKeyId, String preferKeyValue, long havePrivilege, long sortNum, String db, String notes)
/*     */   {
/*  46 */     this.preferId = preferId;
/*  47 */     this.preferName = preferName;
/*  48 */     this.preferKey = preferKey;
/*  49 */     this.preferKeyId = preferKeyId;
/*  50 */     this.preferKeyValue = preferKeyValue;
/*  51 */     this.havePrivilege = havePrivilege;
/*  52 */     this.sortNum = sortNum;
/*  53 */     this.db = db;
/*  54 */     this.notes = notes;
/*     */   }
/*     */ 
/*     */   public String getPreferId()
/*     */   {
/*  61 */     return this.preferId;
/*     */   }
/*     */ 
/*     */   public void setPreferId(String preferId) {
/*  65 */     this.preferId = preferId;
/*     */   }
/*     */ 
/*     */   public String getPreferName() {
/*  69 */     return this.preferName;
/*     */   }
/*     */ 
/*     */   public void setPreferName(String preferName) {
/*  73 */     this.preferName = preferName;
/*     */   }
/*     */ 
/*     */   public String getPreferKey() {
/*  77 */     return this.preferKey;
/*     */   }
/*     */ 
/*     */   public void setPreferKey(String preferKey) {
/*  81 */     this.preferKey = preferKey;
/*     */   }
/*     */ 
/*     */   public String getPreferKeyId() {
/*  85 */     return this.preferKeyId;
/*     */   }
/*     */ 
/*     */   public void setPreferKeyId(String preferKeyId) {
/*  89 */     this.preferKeyId = preferKeyId;
/*     */   }
/*     */ 
/*     */   public String getPreferKeyValue() {
/*  93 */     return this.preferKeyValue;
/*     */   }
/*     */ 
/*     */   public void setPreferKeyValue(String preferKeyValue) {
/*  97 */     this.preferKeyValue = preferKeyValue;
/*     */   }
/*     */ 
/*     */   public long getHavePrivilege() {
/* 101 */     return this.havePrivilege;
/*     */   }
/*     */ 
/*     */   public void setHavePrivilege(long havePrivilege) {
/* 105 */     this.havePrivilege = havePrivilege;
/*     */   }
/*     */ 
/*     */   public long getSortNum() {
/* 109 */     return this.sortNum;
/*     */   }
/*     */ 
/*     */   public void setSortNum(long sortNum) {
/* 113 */     this.sortNum = sortNum;
/*     */   }
/*     */ 
/*     */   public String getDb() {
/* 117 */     return this.db;
/*     */   }
/*     */ 
/*     */   public void setDb(String db) {
/* 121 */     this.db = db;
/*     */   }
/*     */ 
/*     */   public String getNotes() {
/* 125 */     return this.notes;
/*     */   }
/*     */ 
/*     */   public void setNotes(String notes) {
/* 129 */     this.notes = notes;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.Prefer_Define
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.commons.lang.builder.EqualsBuilder;
/*    */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*    */ 
/*    */ public class ResourceOperationDefine
/*    */   implements Serializable
/*    */ {
/*    */   private String operationId;
/*    */   private String operationName;
/*    */   private String operationKey;
/*    */   private String parentId;
/*    */   private Integer resourceType;
/*    */ 
/*    */   public String getOperationId()
/*    */   {
/* 25 */     return this.operationId;
/*    */   }
/*    */   public void setOperationId(String operationId) {
/* 28 */     this.operationId = operationId;
/*    */   }
/*    */   public String getOperationName() {
/* 31 */     return this.operationName;
/*    */   }
/*    */   public void setOperationName(String operationName) {
/* 34 */     this.operationName = operationName;
/*    */   }
/*    */   public String getOperationKey() {
/* 37 */     return this.operationKey;
/*    */   }
/*    */   public void setOperationKey(String operationKey) {
/* 40 */     this.operationKey = operationKey;
/*    */   }
/*    */   public String getParentId() {
/* 43 */     return this.parentId;
/*    */   }
/*    */   public void setParentId(String parentId) {
/* 46 */     this.parentId = parentId;
/*    */   }
/*    */   public Integer getResourceType() {
/* 49 */     return this.resourceType;
/*    */   }
/*    */   public void setResourceType(Integer resourceType) {
/* 52 */     this.resourceType = resourceType;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 57 */     if (!(other instanceof ResourceOperationDefine))
/* 58 */       return false;
/* 59 */     ResourceOperationDefine castOther = (ResourceOperationDefine)other;
/* 60 */     return new EqualsBuilder().append(getOperationId(), castOther.getOperationId()).isEquals();
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 65 */     return new HashCodeBuilder().append(getOperationId()).toHashCode();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.ResourceOperationDefine
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class SysInfo
/*     */   implements Serializable
/*     */ {
/*  18 */   private int hashValue = 0;
/*     */   private Long sysId;
/*     */   private String sysName;
/*     */   private String interfaceUrl;
/*     */   private Long mapFlag;
/*     */   private String notes;
/*     */   private String param0;
/*     */   private String param1;
/*     */   private String param2;
/*     */   private String param3;
/*     */ 
/*     */   public SysInfo()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SysInfo(Long sysId)
/*     */   {
/*  60 */     setSysId(sysId);
/*     */   }
/*     */ 
/*     */   public Long getSysId()
/*     */   {
/*  70 */     return this.sysId;
/*     */   }
/*     */ 
/*     */   public void setSysId(Long sysId)
/*     */   {
/*  79 */     this.hashValue = 0;
/*  80 */     this.sysId = sysId;
/*     */   }
/*     */ 
/*     */   public String getSysName()
/*     */   {
/*  89 */     return this.sysName;
/*     */   }
/*     */ 
/*     */   public void setSysName(String sysName)
/*     */   {
/*  98 */     this.sysName = sysName;
/*     */   }
/*     */ 
/*     */   public String getInterfaceUrl()
/*     */   {
/* 107 */     return this.interfaceUrl;
/*     */   }
/*     */ 
/*     */   public void setInterfaceUrl(String interfaceUrl)
/*     */   {
/* 116 */     this.interfaceUrl = interfaceUrl;
/*     */   }
/*     */ 
/*     */   public Long getMapFlag()
/*     */   {
/* 125 */     return this.mapFlag;
/*     */   }
/*     */ 
/*     */   public void setMapFlag(Long mapFlag)
/*     */   {
/* 134 */     this.mapFlag = mapFlag;
/*     */   }
/*     */ 
/*     */   public String getNotes()
/*     */   {
/* 143 */     return this.notes;
/*     */   }
/*     */ 
/*     */   public void setNotes(String notes)
/*     */   {
/* 152 */     this.notes = notes;
/*     */   }
/*     */ 
/*     */   public String getParam0()
/*     */   {
/* 161 */     return this.param0;
/*     */   }
/*     */ 
/*     */   public void setParam0(String param0)
/*     */   {
/* 170 */     this.param0 = param0;
/*     */   }
/*     */ 
/*     */   public String getParam1()
/*     */   {
/* 179 */     return this.param1;
/*     */   }
/*     */ 
/*     */   public void setParam1(String param1)
/*     */   {
/* 188 */     this.param1 = param1;
/*     */   }
/*     */ 
/*     */   public String getParam2()
/*     */   {
/* 197 */     return this.param2;
/*     */   }
/*     */ 
/*     */   public void setParam2(String param2)
/*     */   {
/* 206 */     this.param2 = param2;
/*     */   }
/*     */ 
/*     */   public String getParam3()
/*     */   {
/* 215 */     return this.param3;
/*     */   }
/*     */ 
/*     */   public void setParam3(String param3)
/*     */   {
/* 224 */     this.param3 = param3;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object rhs)
/*     */   {
/* 235 */     if (rhs == null)
/* 236 */       return false;
/* 237 */     if (!(rhs instanceof SysInfo))
/* 238 */       return false;
/* 239 */     SysInfo that = (SysInfo)rhs;
/* 240 */     if ((getSysId() == null) || (that.getSysId() == null))
/* 241 */       return false;
/* 242 */     return getSysId().equals(that.getSysId());
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 253 */     if (this.hashValue == 0)
/*     */     {
/* 255 */       int result = 17;
/* 256 */       int sysIdValue = getSysId() == null ? 0 : getSysId().hashCode();
/* 257 */       result = result * 37 + sysIdValue;
/* 258 */       this.hashValue = result;
/*     */     }
/* 260 */     return this.hashValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.SysInfo
 * JD-Core Version:    0.6.2
 */
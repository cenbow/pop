/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import java.io.Serializable;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class SysMenuItem
/*     */   implements Serializable, IMenuItem
/*     */ {
/*     */   private Integer menuItemId;
/*     */   private String menuItemTitle;
/*     */   private Integer parentId;
/*     */   private Integer sortNum;
/*     */   private String pic1;
/*     */   private String pic2;
/*     */   private Integer menuType;
/*     */   private String url;
/*     */   private String resId;
/*     */   private Integer resType;
/*     */   private Integer accessToken;
/*     */   private String urlTarget;
/*     */   private String urlPort;
/*     */   private char realValidate;
/*     */   private String imagePath;
/*     */   private Integer resourceType;
/*     */   private String applicationId;
/*     */   private boolean folderOrNot;
/*     */   private String operationType;
/*     */ 
/*     */   public boolean isFolderOrNot()
/*     */   {
/*  39 */     return this.folderOrNot;
/*     */   }
/*     */ 
/*     */   public void setFolderOrNot(boolean folderOrNot) {
/*  43 */     this.folderOrNot = folderOrNot;
/*     */   }
/*     */   public Integer getMenuItemId() {
/*  46 */     return this.menuItemId;
/*     */   }
/*     */   public void setMenuItemId(Integer menuItemId) {
/*  49 */     this.menuItemId = menuItemId;
/*     */   }
/*     */   public String getMenuItemTitle() {
/*  52 */     return this.menuItemTitle;
/*     */   }
/*     */   public void setMenuItemTitle(String menuItemTitle) {
/*  55 */     this.menuItemTitle = menuItemTitle;
/*     */   }
/*     */   public Integer getParentId() {
/*  58 */     return this.parentId;
/*     */   }
/*     */   public void setParentId(Integer parentId) {
/*  61 */     this.parentId = parentId;
/*     */   }
/*     */   public Integer getSortNum() {
/*  64 */     return this.sortNum;
/*     */   }
/*     */   public void setSortNum(Integer sortNum) {
/*  67 */     this.sortNum = sortNum;
/*     */   }
/*     */   public String getPic1() {
/*  70 */     return this.pic1;
/*     */   }
/*     */   public void setPic1(String pic1) {
/*  73 */     this.pic1 = pic1;
/*     */   }
/*     */   public String getPic2() {
/*  76 */     return this.pic2;
/*     */   }
/*     */   public void setPic2(String pic2) {
/*  79 */     this.pic2 = pic2;
/*     */   }
/*     */   public Integer getMenuType() {
/*  82 */     return this.menuType;
/*     */   }
/*     */   public void setMenuType(Integer menuType) {
/*  85 */     this.menuType = menuType;
/*     */   }
/*     */   public String getUrl() {
/*  88 */     return this.url;
/*     */   }
/*     */   public void setUrl(String url) {
/*  91 */     this.url = url;
/*     */   }
/*     */   public String getResId() {
/*  94 */     return this.resId;
/*     */   }
/*     */   public void setResId(String resId) {
/*  97 */     this.resId = resId;
/*     */   }
/*     */   public Integer getResType() {
/* 100 */     return this.resType;
/*     */   }
/*     */   public void setResType(Integer resType) {
/* 103 */     this.resType = resType;
/*     */   }
/*     */   public Integer getAccessToken() {
/* 106 */     return this.accessToken;
/*     */   }
/*     */   public void setAccessToken(Integer accessToken) {
/* 109 */     this.accessToken = accessToken;
/*     */   }
/*     */   public String getUrlTarget() {
/* 112 */     return this.urlTarget;
/*     */   }
/*     */   public void setUrlTarget(String urlTarget) {
/* 115 */     this.urlTarget = urlTarget;
/*     */   }
/*     */   public String getUrlPort() {
/* 118 */     return this.urlPort;
/*     */   }
/*     */   public void setUrlPort(String urlPort) {
/* 121 */     this.urlPort = urlPort;
/*     */   }
/*     */   public char getRealValidate() {
/* 124 */     return this.realValidate;
/*     */   }
/*     */   public void setRealValidate(char realValidate) {
/* 127 */     this.realValidate = realValidate;
/*     */   }
/*     */   public String getImagePath() {
/* 130 */     return this.imagePath;
/*     */   }
/*     */   public void setImagePath(String imagePath) {
/* 133 */     this.imagePath = imagePath;
/*     */   }
/*     */   public Integer getResourceType() {
/* 136 */     return this.resourceType;
/*     */   }
/*     */   public void setResourceType(Integer resourceType) {
/* 139 */     this.resourceType = resourceType;
/*     */   }
/*     */   public String getApplicationId() {
/* 142 */     return this.applicationId;
/*     */   }
/*     */   public void setApplicationId(String applicationId) {
/* 145 */     this.applicationId = applicationId;
/*     */   }
/*     */   public String getOperationType() {
/* 148 */     return this.operationType;
/*     */   }
/*     */   public void setOperationType(String operationType) {
/* 151 */     this.operationType = operationType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.SysMenuItem
 * JD-Core Version:    0.6.2
 */
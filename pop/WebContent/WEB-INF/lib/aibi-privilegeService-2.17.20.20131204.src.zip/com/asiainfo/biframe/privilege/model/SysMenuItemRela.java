/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class SysMenuItemRela
/*    */   implements Serializable
/*    */ {
/*    */   private Integer menuitemId;
/*    */   private Integer parentId;
/*    */ 
/*    */   public Integer getMenuitemId()
/*    */   {
/* 13 */     return this.menuitemId;
/*    */   }
/*    */ 
/*    */   public void setMenuitemId(Integer menuitemId) {
/* 17 */     this.menuitemId = menuitemId;
/*    */   }
/*    */ 
/*    */   public Integer getParentId() {
/* 21 */     return this.parentId;
/*    */   }
/*    */ 
/*    */   public void setParentId(Integer parentId) {
/* 25 */     this.parentId = parentId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.SysMenuItemRela
 * JD-Core Version:    0.6.2
 */
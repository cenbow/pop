/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class SysResourceDsProp
/*    */   implements Serializable
/*    */ {
/*    */   private int resourceType;
/*    */   private String propName;
/*    */   private String propKey;
/*    */   private String propValue;
/*    */ 
/*    */   public String getPrimaryKey()
/*    */   {
/* 18 */     return getResourceType() + "|" + getPropKey();
/*    */   }
/*    */ 
/*    */   public int getResourceType() {
/* 22 */     return this.resourceType;
/*    */   }
/*    */ 
/*    */   public void setResourceType(int resourceType) {
/* 26 */     this.resourceType = resourceType;
/*    */   }
/*    */ 
/*    */   public String getPropName() {
/* 30 */     return this.propName;
/*    */   }
/*    */ 
/*    */   public void setPropName(String propName) {
/* 34 */     this.propName = propName;
/*    */   }
/*    */ 
/*    */   public String getPropKey() {
/* 38 */     return this.propKey;
/*    */   }
/*    */ 
/*    */   public void setPropKey(String propKey) {
/* 42 */     this.propKey = propKey;
/*    */   }
/*    */ 
/*    */   public String getPropValue() {
/* 46 */     return this.propValue;
/*    */   }
/*    */ 
/*    */   public void setPropValue(String propValue) {
/* 50 */     this.propValue = propValue;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.SysResourceDsProp
 * JD-Core Version:    0.6.2
 */
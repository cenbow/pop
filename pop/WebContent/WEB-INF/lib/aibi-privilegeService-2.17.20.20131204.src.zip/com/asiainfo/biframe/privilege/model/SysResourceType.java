/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.ISysResourceType;
/*     */ import java.io.Serializable;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class SysResourceType
/*     */   implements Serializable, ISysResourceType
/*     */ {
/*     */   private int resourceType;
/*     */   private String resourcetypeName;
/*     */   private String resRightTable;
/*     */   private String resDefineTable;
/*     */   private Integer rightImg;
/*     */   private String resourceKey;
/*     */   private int roleType;
/*     */   private String roleRightTable;
/*     */   private boolean isDistinguishOperation;
/*     */   private int dsType;
/*     */ 
/*     */   public boolean getIsDistinguishOperation()
/*     */   {
/*  37 */     return this.isDistinguishOperation;
/*     */   }
/*     */ 
/*     */   public void setIsDistinguishOperation(boolean isDistinguishOperation) {
/*  41 */     this.isDistinguishOperation = isDistinguishOperation;
/*     */   }
/*     */ 
/*     */   public SysResourceType()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SysResourceType(int resourceType) {
/*  49 */     this.resourceType = resourceType;
/*     */   }
/*     */ 
/*     */   public String getPrimaryKey()
/*     */   {
/*  54 */     return getRoleType() + "|" + getResourceType();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  59 */     if (this == other)
/*  60 */       return true;
/*  61 */     if (other == null)
/*  62 */       return false;
/*  63 */     if (!(other instanceof SysResourceType))
/*  64 */       return false;
/*  65 */     SysResourceType castOther = (SysResourceType)other;
/*     */ 
/*  67 */     return (getResourceType() == castOther.getResourceType()) && (getRoleType() == castOther.getRoleType());
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  73 */     int result = 17;
/*     */ 
/*  75 */     result = 37 * result + getResourceType();
/*  76 */     result = 37 * result + getRoleType();
/*  77 */     return result;
/*     */   }
/*     */ 
/*     */   public int getResourceType()
/*     */   {
/*  84 */     return this.resourceType;
/*     */   }
/*     */ 
/*     */   public void setResourceType(int resourceType)
/*     */   {
/*  92 */     this.resourceType = resourceType;
/*     */   }
/*     */ 
/*     */   public String getResourceKey()
/*     */   {
/*  99 */     return this.resourceKey;
/*     */   }
/*     */ 
/*     */   public void setResourceKey(String resourceKey)
/*     */   {
/* 107 */     this.resourceKey = resourceKey;
/*     */   }
/*     */ 
/*     */   public String getResourcetypeName() {
/* 111 */     return this.resourcetypeName;
/*     */   }
/*     */ 
/*     */   public void setResourcetypeName(String resourcetypeName) {
/* 115 */     this.resourcetypeName = resourcetypeName;
/*     */   }
/*     */ 
/*     */   public String getResRightTable() {
/* 119 */     return this.resRightTable;
/*     */   }
/*     */ 
/*     */   public void setResRightTable(String resRightTable) {
/* 123 */     this.resRightTable = resRightTable;
/*     */   }
/*     */ 
/*     */   public String getResDefineTable() {
/* 127 */     return this.resDefineTable;
/*     */   }
/*     */ 
/*     */   public void setResDefineTable(String resDefineTable) {
/* 131 */     this.resDefineTable = resDefineTable;
/*     */   }
/*     */ 
/*     */   public Integer getRightImg() {
/* 135 */     return this.rightImg;
/*     */   }
/*     */ 
/*     */   public void setRightImg(Integer rightImg) {
/* 139 */     this.rightImg = rightImg;
/*     */   }
/*     */ 
/*     */   public int getRoleType()
/*     */   {
/* 146 */     return this.roleType;
/*     */   }
/*     */ 
/*     */   public void setRoleType(int roleType)
/*     */   {
/* 154 */     this.roleType = roleType;
/*     */   }
/*     */ 
/*     */   public String getRoleRightTable() {
/* 158 */     return this.roleRightTable;
/*     */   }
/*     */ 
/*     */   public void setRoleRightTable(String roleRightTable) {
/* 162 */     this.roleRightTable = roleRightTable;
/*     */   }
/*     */ 
/*     */   public int getDsType() {
/* 166 */     return this.dsType;
/*     */   }
/*     */ 
/*     */   public void setDsType(int dsType) {
/* 170 */     this.dsType = dsType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.SysResourceType
 * JD-Core Version:    0.6.2
 */
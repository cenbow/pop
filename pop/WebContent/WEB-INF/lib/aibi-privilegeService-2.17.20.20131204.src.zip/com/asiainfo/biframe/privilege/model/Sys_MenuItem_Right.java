/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ public class Sys_MenuItem_Right
/*     */   implements Serializable
/*     */ {
/*     */   private int operatorType;
/*     */   private String operatorId;
/*     */   private String resourceId;
/*     */   private int resourceType;
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  24 */     if (this == other)
/*  25 */       return true;
/*  26 */     if (other == null)
/*  27 */       return false;
/*  28 */     if (!(other instanceof Sys_MenuItem_Right))
/*  29 */       return false;
/*  30 */     Sys_MenuItem_Right castOther = (Sys_MenuItem_Right)other;
/*     */ 
/*  32 */     return new EqualsBuilder().append(getOperatorId(), castOther.getOperatorId()).append(getResourceId(), castOther.getResourceId()).append(new Integer(getOperatorType()), new Integer(castOther.getOperatorType())).append(new Integer(getResourceType()), new Integer(castOther.getResourceType())).isEquals();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  44 */     return new HashCodeBuilder().append(getOperatorId()).append(getResourceId()).append(new Integer(getOperatorType())).append(new Integer(getResourceType())).toHashCode();
/*     */   }
/*     */ 
/*     */   public String getOperatorId()
/*     */   {
/*  57 */     return this.operatorId;
/*     */   }
/*     */ 
/*     */   public int getOperatorType()
/*     */   {
/*  64 */     return this.operatorType;
/*     */   }
/*     */ 
/*     */   public String getResourceId()
/*     */   {
/*  71 */     return this.resourceId;
/*     */   }
/*     */ 
/*     */   public int getResourceType()
/*     */   {
/*  78 */     return this.resourceType;
/*     */   }
/*     */ 
/*     */   public void setOperatorId(String string)
/*     */   {
/*  86 */     this.operatorId = string;
/*     */   }
/*     */ 
/*     */   public void setOperatorType(int i)
/*     */   {
/*  93 */     this.operatorType = i;
/*     */   }
/*     */ 
/*     */   public void setResourceId(String string)
/*     */   {
/* 100 */     this.resourceId = string;
/*     */   }
/*     */ 
/*     */   public void setResourceType(int i)
/*     */   {
/* 107 */     this.resourceType = i;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.Sys_MenuItem_Right
 * JD-Core Version:    0.6.2
 */
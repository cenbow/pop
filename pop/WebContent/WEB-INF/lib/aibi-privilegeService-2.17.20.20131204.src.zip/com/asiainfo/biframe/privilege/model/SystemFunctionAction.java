/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.commons.lang.builder.EqualsBuilder;
/*    */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*    */ 
/*    */ public class SystemFunctionAction
/*    */   implements Serializable
/*    */ {
/*    */   private String actionId;
/*    */   private String resourceId;
/*    */   private Integer resourceType;
/*    */   private String operationType;
/*    */   private String operationName;
/*    */   private String note;
/*    */   private String resourceTypeName;
/*    */ 
/*    */   public String getActionId()
/*    */   {
/* 29 */     return this.actionId;
/*    */   }
/*    */   public void setActionId(String actionId) {
/* 32 */     this.actionId = actionId;
/*    */   }
/*    */   public String getResourceId() {
/* 35 */     return this.resourceId;
/*    */   }
/*    */   public void setResourceId(String resourceId) {
/* 38 */     this.resourceId = resourceId;
/*    */   }
/*    */   public Integer getResourceType() {
/* 41 */     return this.resourceType;
/*    */   }
/*    */   public void setResourceType(Integer resourceType) {
/* 44 */     this.resourceType = resourceType;
/*    */   }
/*    */   public String getOperationType() {
/* 47 */     return this.operationType;
/*    */   }
/*    */   public void setOperationType(String operationType) {
/* 50 */     this.operationType = operationType;
/*    */   }
/*    */   public String getOperationName() {
/* 53 */     return this.operationName;
/*    */   }
/*    */   public void setOperationName(String operationName) {
/* 56 */     this.operationName = operationName;
/*    */   }
/*    */   public String getNote() {
/* 59 */     return this.note;
/*    */   }
/*    */   public void setNote(String note) {
/* 62 */     this.note = note;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 68 */     if (!(other instanceof SystemFunctionAction))
/* 69 */       return false;
/* 70 */     SystemFunctionAction castOther = (SystemFunctionAction)other;
/* 71 */     return new EqualsBuilder().append(getActionId(), castOther.getActionId()).isEquals();
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 76 */     return new HashCodeBuilder().append(getActionId()).toHashCode();
/*    */   }
/*    */   public String getResourceTypeName() {
/* 79 */     return this.resourceTypeName;
/*    */   }
/*    */   public void setResourceTypeName(String resourceTypeName) {
/* 82 */     this.resourceTypeName = resourceTypeName;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.SystemFunctionAction
 * JD-Core Version:    0.6.2
 */
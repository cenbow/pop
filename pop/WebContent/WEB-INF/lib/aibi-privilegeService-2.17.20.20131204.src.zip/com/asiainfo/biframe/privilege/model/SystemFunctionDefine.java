/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ public class SystemFunctionDefine
/*     */   implements Serializable
/*     */ {
/*     */   private String functionId;
/*     */   private String functionName;
/*  24 */   private Integer resourceType = Integer.valueOf("1001");
/*     */   private String parentId;
/*     */   private String url;
/*     */   private String parameter;
/*     */   private String note;
/*     */   private Integer sortNum;
/*     */   private String resourceTypeName;
/*     */   private String parentName;
/*     */ 
/*     */   public String getFunctionId()
/*     */   {
/*  34 */     return this.functionId;
/*     */   }
/*     */   public void setFunctionId(String functionId) {
/*  37 */     this.functionId = functionId;
/*     */   }
/*     */   public String getFunctionName() {
/*  40 */     return this.functionName;
/*     */   }
/*     */   public void setFunctionName(String functionName) {
/*  43 */     this.functionName = functionName;
/*     */   }
/*     */   public Integer getResourceType() {
/*  46 */     return this.resourceType;
/*     */   }
/*     */   public void setResourceType(Integer resourceType) {
/*  49 */     this.resourceType = resourceType;
/*     */   }
/*     */   public String getParentId() {
/*  52 */     return this.parentId;
/*     */   }
/*     */   public void setParentId(String parentId) {
/*  55 */     this.parentId = parentId;
/*     */   }
/*     */   public String getUrl() {
/*  58 */     return this.url;
/*     */   }
/*     */   public void setUrl(String url) {
/*  61 */     this.url = url;
/*     */   }
/*     */   public String getParameter() {
/*  64 */     return this.parameter;
/*     */   }
/*     */   public void setParameter(String parameter) {
/*  67 */     this.parameter = parameter;
/*     */   }
/*     */   public String getNote() {
/*  70 */     return this.note;
/*     */   }
/*     */   public void setNote(String note) {
/*  73 */     this.note = note;
/*     */   }
/*     */   public Integer getSortNum() {
/*  76 */     return this.sortNum;
/*     */   }
/*     */   public void setSortNum(Integer sortNum) {
/*  79 */     this.sortNum = sortNum;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  86 */     if (!(other instanceof SystemFunctionDefine))
/*  87 */       return false;
/*  88 */     SystemFunctionDefine castOther = (SystemFunctionDefine)other;
/*  89 */     return new EqualsBuilder().append(getFunctionId(), castOther.getFunctionId()).isEquals();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  94 */     return new HashCodeBuilder().append(getFunctionId()).toHashCode();
/*     */   }
/*     */   public String getResourceTypeName() {
/*  97 */     return this.resourceTypeName;
/*     */   }
/*     */   public void setResourceTypeName(String resourceTypeName) {
/* 100 */     this.resourceTypeName = resourceTypeName;
/*     */   }
/*     */   public String getParentName() {
/* 103 */     return this.parentName;
/*     */   }
/*     */   public void setParentName(String parentName) {
/* 106 */     this.parentName = parentName;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.SystemFunctionDefine
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class UniauthUserParam
/*     */   implements Serializable
/*     */ {
/*  18 */   private int hashValue = 0;
/*     */   private UniauthUserParamKey id;
/*     */   private String name;
/*     */   private String value;
/*     */   private Date opDate;
/*     */ 
/*     */   public UniauthUserParam()
/*     */   {
/*     */   }
/*     */ 
/*     */   public UniauthUserParam(UniauthUserParamKey id)
/*     */   {
/*  45 */     setId(id);
/*     */   }
/*     */ 
/*     */   public UniauthUserParamKey getId()
/*     */   {
/*  55 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(UniauthUserParamKey id)
/*     */   {
/*  64 */     this.hashValue = 0;
/*  65 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  74 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  83 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getValue()
/*     */   {
/*  92 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(String value)
/*     */   {
/* 101 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public Date getOpDate()
/*     */   {
/* 110 */     return this.opDate;
/*     */   }
/*     */ 
/*     */   public void setOpDate(Date opDate)
/*     */   {
/* 119 */     this.opDate = opDate;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object rhs)
/*     */   {
/* 130 */     if (rhs == null)
/* 131 */       return false;
/* 132 */     if (!(rhs instanceof UniauthUserParam))
/* 133 */       return false;
/* 134 */     UniauthUserParam that = (UniauthUserParam)rhs;
/* 135 */     if ((getId() == null) || (that.getId() == null))
/* 136 */       return false;
/* 137 */     return getId().equals(that.getId());
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 148 */     if (this.hashValue == 0)
/*     */     {
/* 150 */       int result = 17;
/* 151 */       if (getId() == null)
/*     */       {
/* 153 */         result = super.hashCode();
/*     */       }
/*     */       else
/*     */       {
/* 157 */         result = getId().hashCode();
/*     */       }
/* 159 */       this.hashValue = result;
/*     */     }
/* 161 */     return this.hashValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UniauthUserParam
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class UniauthUserParamKey
/*     */   implements Serializable
/*     */ {
/*  23 */   private volatile int hashValue = 0;
/*     */   private String param;
/*     */   private Integer portletId;
/*     */   private String userId;
/*     */ 
/*     */   public String getParam()
/*     */   {
/*  47 */     return this.param;
/*     */   }
/*     */ 
/*     */   public void setParam(String param)
/*     */   {
/*  56 */     this.hashValue = 0;
/*  57 */     this.param = param;
/*     */   }
/*     */ 
/*     */   public Integer getPortletId()
/*     */   {
/*  66 */     return this.portletId;
/*     */   }
/*     */ 
/*     */   public void setPortletId(Integer portletId)
/*     */   {
/*  75 */     this.hashValue = 0;
/*  76 */     this.portletId = portletId;
/*     */   }
/*     */ 
/*     */   public String getUserId()
/*     */   {
/*  85 */     return this.userId;
/*     */   }
/*     */ 
/*     */   public void setUserId(String userId)
/*     */   {
/*  94 */     this.hashValue = 0;
/*  95 */     this.userId = userId;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object rhs)
/*     */   {
/* 106 */     if (rhs == null)
/* 107 */       return false;
/* 108 */     if (!(rhs instanceof UniauthUserParamKey))
/* 109 */       return false;
/* 110 */     UniauthUserParamKey that = (UniauthUserParamKey)rhs;
/* 111 */     if ((getParam() == null) || (that.getParam() == null))
/*     */     {
/* 113 */       return false;
/*     */     }
/* 115 */     if (!getParam().equals(that.getParam()))
/*     */     {
/* 117 */       return false;
/*     */     }
/* 119 */     if ((getPortletId() == null) || (that.getPortletId() == null))
/*     */     {
/* 121 */       return false;
/*     */     }
/* 123 */     if (!getPortletId().equals(that.getPortletId()))
/*     */     {
/* 125 */       return false;
/*     */     }
/* 127 */     if ((getUserId() == null) || (that.getUserId() == null))
/*     */     {
/* 129 */       return false;
/*     */     }
/* 131 */     if (!getUserId().equals(that.getUserId()))
/*     */     {
/* 133 */       return false;
/*     */     }
/* 135 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 146 */     if (this.hashValue == 0)
/*     */     {
/* 148 */       int result = 17;
/* 149 */       int paramValue = getParam() == null ? 0 : getParam().hashCode();
/* 150 */       result = result * 37 + paramValue;
/* 151 */       int portletIdValue = getPortletId() == null ? 0 : getPortletId().hashCode();
/* 152 */       result = result * 37 + portletIdValue;
/* 153 */       int userIdValue = getUserId() == null ? 0 : getUserId().hashCode();
/* 154 */       result = result * 37 + userIdValue;
/* 155 */       this.hashValue = result;
/*     */     }
/* 157 */     return this.hashValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UniauthUserParamKey
 * JD-Core Version:    0.6.2
 */
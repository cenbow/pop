/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.IUserApplication;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ public class UserApplication
/*    */   implements IUserApplication
/*    */ {
/*    */   String applicationId;
/*    */   String applicationName;
/*    */   String note;
/*    */ 
/*    */   public String getApplicationId()
/*    */   {
/* 22 */     return this.applicationId;
/*    */   }
/*    */   public void setApplicationId(String applicationId) {
/* 25 */     this.applicationId = applicationId;
/*    */   }
/*    */   public String getApplicationName() {
/* 28 */     return this.applicationName;
/*    */   }
/*    */   public void setApplicationName(String applicationName) {
/* 31 */     this.applicationName = applicationName;
/*    */   }
/*    */   public String getNote() {
/* 34 */     return this.note;
/*    */   }
/*    */   public void setNote(String note) {
/* 37 */     this.note = note;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserApplication
 * JD-Core Version:    0.6.2
 */
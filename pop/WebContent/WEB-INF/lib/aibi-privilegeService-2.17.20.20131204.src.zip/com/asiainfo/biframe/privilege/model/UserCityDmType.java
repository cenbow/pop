/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ public class UserCityDmType
/*    */   implements Serializable
/*    */ {
/*    */   private String UserCityDmTypeId;
/*    */   private String DmTypeCode;
/*    */   private String DmTable;
/*    */   private String DmCol;
/*    */   private int DmLevel;
/*    */   private String DmTypeDesc;
/*    */ 
/*    */   public String getUserCityDmTypeId()
/*    */   {
/* 24 */     return this.UserCityDmTypeId;
/*    */   }
/*    */ 
/*    */   public void setUserCityDmTypeId(String userCityDmTypeId) {
/* 28 */     this.UserCityDmTypeId = userCityDmTypeId;
/*    */   }
/*    */ 
/*    */   public String getDmTypeCode() {
/* 32 */     return this.DmTypeCode;
/*    */   }
/*    */ 
/*    */   public void setDmTypeCode(String dmTypeCode) {
/* 36 */     this.DmTypeCode = dmTypeCode;
/*    */   }
/*    */ 
/*    */   public String getDmTable() {
/* 40 */     return this.DmTable;
/*    */   }
/*    */ 
/*    */   public void setDmTable(String dmTable) {
/* 44 */     this.DmTable = dmTable;
/*    */   }
/*    */ 
/*    */   public String getDmCol() {
/* 48 */     return this.DmCol;
/*    */   }
/*    */ 
/*    */   public void setDmCol(String dmCol) {
/* 52 */     this.DmCol = dmCol;
/*    */   }
/*    */ 
/*    */   public int getDmLevel() {
/* 56 */     return this.DmLevel;
/*    */   }
/*    */ 
/*    */   public void setDmLevel(int dmLevel) {
/* 60 */     this.DmLevel = dmLevel;
/*    */   }
/*    */ 
/*    */   public String getDmTypeDesc() {
/* 64 */     return this.DmTypeDesc;
/*    */   }
/*    */ 
/*    */   public void setDmTypeDesc(String dmTypeDesc) {
/* 68 */     this.DmTypeDesc = dmTypeDesc;
/*    */   }
/*    */ 
/*    */   public String getPrimaryKey() {
/* 72 */     return this.UserCityDmTypeId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserCityDmType
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserExtInfo;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class UserExtInfo
/*     */   implements Serializable, IUserExtInfo
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String extId;
/*     */   private String userId;
/*     */   private String extName;
/*     */   private String extValue;
/*     */   private String description;
/*     */ 
/*     */   public UserExtInfo()
/*     */   {
/*     */   }
/*     */ 
/*     */   public UserExtInfo(String extId, String userId, String extName, String extValue)
/*     */   {
/*  29 */     this.extId = extId;
/*  30 */     this.userId = userId;
/*  31 */     this.extName = extName;
/*  32 */     this.extValue = extValue;
/*     */   }
/*     */ 
/*     */   public UserExtInfo(String extId, String userId, String extName, String extValue, String description)
/*     */   {
/*  37 */     this.extId = extId;
/*  38 */     this.userId = userId;
/*  39 */     this.extName = extName;
/*  40 */     this.extValue = extValue;
/*  41 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public String getExtName() {
/*  45 */     return this.extName;
/*     */   }
/*     */ 
/*     */   public void setExtName(String extName) {
/*  49 */     this.extName = extName;
/*     */   }
/*     */ 
/*     */   public String getExtValue() {
/*  53 */     return this.extValue;
/*     */   }
/*     */ 
/*     */   public void setExtValue(String extValue) {
/*  57 */     this.extValue = extValue;
/*     */   }
/*     */ 
/*     */   public String getExtId() {
/*  61 */     return this.extId;
/*     */   }
/*     */ 
/*     */   public void setExtId(String extId) {
/*  65 */     this.extId = extId;
/*     */   }
/*     */ 
/*     */   public String getUserId() {
/*  69 */     return this.userId;
/*     */   }
/*     */ 
/*     */   public void setUserId(String userId) {
/*  73 */     this.userId = userId;
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/*  77 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) {
/*  81 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other) {
/*  85 */     if (this == other)
/*  86 */       return true;
/*  87 */     if (other == null)
/*  88 */       return false;
/*  89 */     if (!(other instanceof UserExtInfo))
/*  90 */       return false;
/*  91 */     UserExtInfo castOther = (UserExtInfo)other;
/*     */ 
/*  93 */     return ((getExtId() == castOther.getExtId()) || ((getExtId() != null) && (castOther.getExtId() != null) && (getExtId().equals(castOther.getExtId())))) && ((getUserId() == castOther.getUserId()) || ((getUserId() != null) && (castOther.getUserId() != null) && (getUserId().equals(castOther.getUserId()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 103 */     int result = 17;
/*     */ 
/* 105 */     result = 37 * result + (getExtId() == null ? 0 : getExtId().hashCode());
/*     */ 
/* 107 */     result = 37 * result + (getUserId() == null ? 0 : getUserId().hashCode());
/*     */ 
/* 109 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserExtInfo
 * JD-Core Version:    0.6.2
 */
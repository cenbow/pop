/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class UserExtInfoDefine
/*    */   implements Serializable
/*    */ {
/*    */   private String extId;
/*    */   private String extName;
/*    */   private String domainType;
/*    */   private String description;
/*    */ 
/*    */   public UserExtInfoDefine()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UserExtInfoDefine(String extId)
/*    */   {
/* 23 */     this.extId = extId;
/*    */   }
/*    */ 
/*    */   public UserExtInfoDefine(String extId, String extName, String domainType, String description)
/*    */   {
/* 28 */     this.extId = extId;
/* 29 */     this.extName = extName;
/* 30 */     this.domainType = domainType;
/* 31 */     this.description = description;
/*    */   }
/*    */ 
/*    */   public String getExtId() {
/* 35 */     return this.extId;
/*    */   }
/*    */ 
/*    */   public void setExtId(String extId) {
/* 39 */     this.extId = extId;
/*    */   }
/*    */ 
/*    */   public String getExtName() {
/* 43 */     return this.extName;
/*    */   }
/*    */ 
/*    */   public void setExtName(String extName) {
/* 47 */     this.extName = extName;
/*    */   }
/*    */ 
/*    */   public String getDomainType() {
/* 51 */     return this.domainType;
/*    */   }
/*    */ 
/*    */   public void setDomainType(String domainType) {
/* 55 */     this.domainType = domainType;
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 59 */     return this.description;
/*    */   }
/*    */ 
/*    */   public void setDescription(String description) {
/* 63 */     this.description = description;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserExtInfoDefine
 * JD-Core Version:    0.6.2
 */
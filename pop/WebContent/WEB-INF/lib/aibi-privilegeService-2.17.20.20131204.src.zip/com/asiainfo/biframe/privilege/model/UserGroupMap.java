/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class UserGroupMap
/*    */   implements Serializable
/*    */ {
/*    */   private String userid;
/*    */   private String groupId;
/*    */ 
/*    */   public UserGroupMap()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UserGroupMap(String userid, String groupId)
/*    */   {
/* 33 */     this.userid = userid;
/* 34 */     this.groupId = groupId;
/*    */   }
/*    */ 
/*    */   public String getUserid()
/*    */   {
/* 43 */     return this.userid;
/*    */   }
/*    */ 
/*    */   public void setUserid(String userid) {
/* 47 */     this.userid = userid;
/*    */   }
/*    */ 
/*    */   public String getGroupId() {
/* 51 */     return this.groupId;
/*    */   }
/*    */ 
/*    */   public void setGroupId(String groupId) {
/* 55 */     this.groupId = groupId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 63 */     if (this == other) return true;
/* 64 */     if (other == null) return false;
/* 65 */     if (!(other instanceof UserGroupMap)) return false;
/* 66 */     UserGroupMap castOther = (UserGroupMap)other;
/*    */ 
/* 68 */     return ((getUserid() == castOther.getUserid()) || ((getUserid() != null) && (castOther.getUserid() != null) && (getUserid().equals(castOther.getUserid())))) && ((getGroupId() == castOther.getGroupId()) || ((getGroupId() != null) && (castOther.getGroupId() != null) && (getGroupId().equals(castOther.getGroupId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 74 */     int result = 17;
/*    */ 
/* 76 */     result = 37 * result + (getUserid() == null ? 0 : getUserid().hashCode());
/* 77 */     result = 37 * result + (getGroupId() == null ? 0 : getGroupId().hashCode());
/* 78 */     return result;
/*    */   }
/*    */   public Map toMap() {
/* 81 */     Map map = new HashMap();
/* 82 */     Map infoMap = new HashMap();
/* 83 */     infoMap.put("GROUPID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userGroup") + "ID", getGroupId());
/* 84 */     infoMap.put("USERID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.user") + "ID", getUserid());
/* 85 */     map.put("USERGROUPMAP", infoMap);
/* 86 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserGroupMap
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ public class UserOaMap
/*    */ {
/*    */   private String oaUserId;
/*    */   private String roleType;
/*    */   private String roleId;
/*    */ 
/*    */   public String getOaUserId()
/*    */   {
/* 13 */     return this.oaUserId;
/*    */   }
/*    */ 
/*    */   public void setOaUserId(String oaUserId)
/*    */   {
/* 19 */     this.oaUserId = oaUserId;
/*    */   }
/*    */ 
/*    */   public String getRoleType()
/*    */   {
/* 25 */     return this.roleType;
/*    */   }
/*    */ 
/*    */   public void setRoleType(String roleType)
/*    */   {
/* 31 */     this.roleType = roleType;
/*    */   }
/*    */ 
/*    */   public String getRoleId()
/*    */   {
/* 37 */     return this.roleId;
/*    */   }
/*    */ 
/*    */   public void setRoleId(String roleId)
/*    */   {
/* 43 */     this.roleId = roleId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserOaMap
 * JD-Core Version:    0.6.2
 */
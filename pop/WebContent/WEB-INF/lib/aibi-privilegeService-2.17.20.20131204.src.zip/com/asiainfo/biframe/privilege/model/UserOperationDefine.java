/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class UserOperationDefine
/*    */   implements Serializable
/*    */ {
/*    */   private String operationId;
/*    */   private String operationName;
/*    */   private String operationKey;
/*    */   private String parentId;
/*    */   private int resourceType;
/*    */ 
/*    */   public String getOperationId()
/*    */   {
/* 23 */     return this.operationId;
/*    */   }
/*    */   public void setOperationId(String operationId) {
/* 26 */     this.operationId = operationId;
/*    */   }
/*    */   public String getOperationName() {
/* 29 */     return this.operationName;
/*    */   }
/*    */   public void setOperationName(String operationName) {
/* 32 */     this.operationName = operationName;
/*    */   }
/*    */   public String getOperationKey() {
/* 35 */     return this.operationKey;
/*    */   }
/*    */   public void setOperationKey(String operationKey) {
/* 38 */     this.operationKey = operationKey;
/*    */   }
/*    */   public String getParentId() {
/* 41 */     return this.parentId;
/*    */   }
/*    */   public void setParentId(String parentId) {
/* 44 */     this.parentId = parentId;
/*    */   }
/*    */   public int getResourceType() {
/* 47 */     return this.resourceType;
/*    */   }
/*    */   public void setResourceType(int resourceType) {
/* 50 */     this.resourceType = resourceType;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserOperationDefine
 * JD-Core Version:    0.6.2
 */
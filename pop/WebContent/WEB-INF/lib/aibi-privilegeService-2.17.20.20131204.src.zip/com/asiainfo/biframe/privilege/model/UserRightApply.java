/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserRightApply;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserGroupDefineCache;
/*     */ import com.asiainfo.biframe.privilege.tempright.constants.UserRightApplyConstants;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ public class UserRightApply
/*     */   implements IUserRightApply
/*     */ {
/*     */   private String applyId;
/*     */   private String proposerId;
/*     */   private String proposerName;
/*     */   private Date applyTime;
/*     */   private String state;
/*     */   private Date beginDate;
/*     */   private Date endDate;
/*     */   private Date approvalTime;
/*     */   private String approverId;
/*     */   private String approverName;
/*     */   private String approverPhone;
/*     */   private String electronicCode;
/*     */   private String applySmsMessage;
/*     */   private String proposerGroupId;
/*     */   private String proposerGroupName;
/*     */   private String approverGroupId;
/*     */   private String approverGroupName;
/*     */   private String applyType;
/*     */   private String applyTypeName;
/*     */   private Date queryBeginApplyTime;
/*     */   private Date queryEndApplyTime;
/*     */   private Date queryBeginApprovalTime;
/*     */   private Date queryEndApprovalTime;
/*     */   private String stateDesc;
/*     */ 
/*     */   public String getApplyTypeName()
/*     */   {
/* 108 */     if (this.applyType.equals("0"))
/* 109 */       this.applyTypeName = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.needApplication");
/* 110 */     else if (this.applyType.equals("1"))
/* 111 */       this.applyTypeName = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.needNotApplication");
/* 112 */     return this.applyTypeName;
/*     */   }
/*     */ 
/*     */   public void setApplyTypeName(String applyTypeName) {
/* 116 */     this.applyTypeName = applyTypeName;
/*     */   }
/*     */ 
/*     */   public String getApplyType() {
/* 120 */     return this.applyType;
/*     */   }
/*     */ 
/*     */   public void setApplyType(String applyType) {
/* 124 */     this.applyType = applyType;
/*     */   }
/*     */ 
/*     */   public String getApplyId()
/*     */   {
/* 142 */     return this.applyId;
/*     */   }
/*     */ 
/*     */   public void setApplyId(String applyId) {
/* 146 */     this.applyId = applyId;
/*     */   }
/*     */ 
/*     */   public String getProposerId() {
/* 150 */     return this.proposerId;
/*     */   }
/*     */ 
/*     */   public void setProposerId(String proposerId) {
/* 154 */     this.proposerId = proposerId;
/*     */   }
/*     */ 
/*     */   public String getProposerName() {
/* 158 */     return this.proposerName;
/*     */   }
/*     */ 
/*     */   public void setProposerName(String proposerName) {
/* 162 */     this.proposerName = proposerName;
/*     */   }
/*     */ 
/*     */   public Date getApplyTime() {
/* 166 */     return this.applyTime;
/*     */   }
/*     */ 
/*     */   public void setApplyTime(Date applyTime) {
/* 170 */     this.applyTime = applyTime;
/*     */   }
/*     */ 
/*     */   public String getState() {
/* 174 */     return this.state;
/*     */   }
/*     */ 
/*     */   public void setState(String state) {
/* 178 */     this.state = state;
/*     */   }
/*     */ 
/*     */   public Date getBeginDate() {
/* 182 */     return this.beginDate;
/*     */   }
/*     */ 
/*     */   public void setBeginDate(Date beginDate) {
/* 186 */     this.beginDate = beginDate;
/*     */   }
/*     */ 
/*     */   public Date getEndDate() {
/* 190 */     return this.endDate;
/*     */   }
/*     */ 
/*     */   public void setEndDate(Date endDate) {
/* 194 */     this.endDate = endDate;
/*     */   }
/*     */ 
/*     */   public Date getApprovalTime() {
/* 198 */     return this.approvalTime;
/*     */   }
/*     */ 
/*     */   public void setApprovalTime(Date approvalTime) {
/* 202 */     this.approvalTime = approvalTime;
/*     */   }
/*     */ 
/*     */   public String getApproverId() {
/* 206 */     return this.approverId;
/*     */   }
/*     */ 
/*     */   public void setApproverId(String approverId) {
/* 210 */     this.approverId = approverId;
/*     */   }
/*     */ 
/*     */   public String getApproverName() {
/* 214 */     return this.approverName;
/*     */   }
/*     */ 
/*     */   public void setApproverName(String approverName) {
/* 218 */     this.approverName = approverName;
/*     */   }
/*     */ 
/*     */   public String getApproverPhone() {
/* 222 */     return this.approverPhone;
/*     */   }
/*     */ 
/*     */   public void setApproverPhone(String approverPhone) {
/* 226 */     this.approverPhone = approverPhone;
/*     */   }
/*     */ 
/*     */   public String getElectronicCode() {
/* 230 */     return this.electronicCode;
/*     */   }
/*     */ 
/*     */   public void setElectronicCode(String electronicCode) {
/* 234 */     this.electronicCode = electronicCode;
/*     */   }
/*     */ 
/*     */   public String getApplySmsMessage() {
/* 238 */     return this.applySmsMessage;
/*     */   }
/*     */ 
/*     */   public void setApplySmsMessage(String applySmsMessage) {
/* 242 */     this.applySmsMessage = applySmsMessage;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 254 */     if (!(other instanceof UserRightApply))
/* 255 */       return false;
/* 256 */     UserRightApply castOther = (UserRightApply)other;
/* 257 */     return new EqualsBuilder().append(getApplyId(), castOther.getApplyId()).isEquals();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 263 */     return new HashCodeBuilder().append(getApplyId()).toHashCode();
/*     */   }
/*     */ 
/*     */   public Date getQueryBeginApplyTime() {
/* 267 */     return this.queryBeginApplyTime;
/*     */   }
/*     */ 
/*     */   public void setQueryBeginApplyTime(Date queryBeginApplyTime) {
/* 271 */     this.queryBeginApplyTime = queryBeginApplyTime;
/*     */   }
/*     */ 
/*     */   public Date getQueryEndApplyTime() {
/* 275 */     return this.queryEndApplyTime;
/*     */   }
/*     */ 
/*     */   public void setQueryEndApplyTime(Date queryEndApplyTime) {
/* 279 */     this.queryEndApplyTime = queryEndApplyTime;
/*     */   }
/*     */ 
/*     */   public Date getQueryBeginApprovalTime() {
/* 283 */     return this.queryBeginApprovalTime;
/*     */   }
/*     */ 
/*     */   public void setQueryBeginApprovalTime(Date queryBeginApprovalTime) {
/* 287 */     this.queryBeginApprovalTime = queryBeginApprovalTime;
/*     */   }
/*     */ 
/*     */   public Date getQueryEndApprovalTime() {
/* 291 */     return this.queryEndApprovalTime;
/*     */   }
/*     */ 
/*     */   public void setQueryEndApprovalTime(Date queryEndApprovalTime) {
/* 295 */     this.queryEndApprovalTime = queryEndApprovalTime;
/*     */   }
/*     */ 
/*     */   public String getStateDesc() {
/* 299 */     return UserRightApplyConstants.getStatusDesc(this.state);
/*     */   }
/*     */ 
/*     */   public String getApplyTimeStr()
/*     */   {
/* 308 */     if (this.applyTime != null) {
/* 309 */       return DateUtil.date2String(this.applyTime, "yyyy-MM-dd HH:mm:ss");
/*     */     }
/* 311 */     return "";
/*     */   }
/*     */ 
/*     */   public String getBeginDateStr() {
/* 315 */     if (this.beginDate != null) {
/* 316 */       return DateUtil.date2String(this.beginDate, "yyyy-MM-dd");
/*     */     }
/* 318 */     return "";
/*     */   }
/*     */ 
/*     */   public String getEndDateStr() {
/* 322 */     if (this.endDate != null) {
/* 323 */       return DateUtil.date2String(this.endDate, "yyyy-MM-dd");
/*     */     }
/* 325 */     return "";
/*     */   }
/*     */ 
/*     */   public String getApprovalTimeStr() {
/* 329 */     if (this.approvalTime != null) {
/* 330 */       return DateUtil.date2String(this.approvalTime, "yyyy-MM-dd HH:mm:ss");
/*     */     }
/*     */ 
/* 333 */     return "";
/*     */   }
/*     */ 
/*     */   public String getProposerGroupId() {
/* 337 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(this.proposerId);
/*     */ 
/* 339 */     String groupId = user == null ? "" : user.getGroupId();
/* 340 */     User_Group userGroup = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(groupId);
/*     */ 
/* 342 */     return userGroup == null ? "" : userGroup.getGroupid();
/*     */   }
/*     */ 
/*     */   public String getProposerGroupName() {
/* 346 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(this.proposerId);
/*     */ 
/* 348 */     String groupId = user == null ? "" : user.getGroupId();
/* 349 */     String groupName = UserGroupDefineCache.getInstance().getNameByKey(groupId);
/*     */ 
/* 351 */     return groupName == null ? "" : groupName;
/*     */   }
/*     */ 
/*     */   public String getApproverGroupId() {
/* 355 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(this.approverId);
/*     */ 
/* 357 */     String groupId = user == null ? "" : user.getGroupId();
/* 358 */     User_Group userGroup = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(groupId);
/*     */ 
/* 360 */     return userGroup == null ? "" : userGroup.getGroupid();
/*     */   }
/*     */ 
/*     */   public String getApproverGroupName() {
/* 364 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(this.approverId);
/*     */ 
/* 366 */     String groupId = user == null ? "" : user.getGroupId();
/* 367 */     String groupName = UserGroupDefineCache.getInstance().getNameByKey(groupId);
/*     */ 
/* 369 */     return groupName == null ? "" : groupName;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserRightApply
 * JD-Core Version:    0.6.2
 */
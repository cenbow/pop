/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserRole;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.util.SysManageConstants;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class UserRole
/*     */   implements Serializable, IUserRole
/*     */ {
/*     */   private String roleId;
/*     */   private String roleName;
/*     */   private String parentId;
/*     */   private String createGroup;
/*     */   private String createGroupIds;
/*  26 */   private int roleType = -1;
/*  27 */   private int resourceType = -1;
/*     */   private int status;
/*     */   private Date createTime;
/*     */   private Date beginDate;
/*     */   private Date endDate;
/*     */   private int userLimit;
/*     */   private String deleteTime;
/*     */   private String beginDeleteTime;
/*     */   private String endDeleteTime;
/*     */   private String createGroupName;
/*     */   private String classifyId;
/*     */ 
/*     */   public String getPrimaryKey()
/*     */   {
/*  43 */     return getRoleId();
/*     */   }
/*     */ 
/*     */   public String getCreateGroupIds()
/*     */   {
/*  49 */     return this.createGroupIds;
/*     */   }
/*     */ 
/*     */   public void setCreateGroupIds(String createGroupIds)
/*     */   {
/*  57 */     this.createGroupIds = createGroupIds;
/*     */   }
/*     */ 
/*     */   public String getRoleId()
/*     */   {
/*  68 */     return this.roleId;
/*     */   }
/*     */ 
/*     */   public void setRoleId(String roleId) {
/*  72 */     this.roleId = roleId;
/*     */   }
/*     */ 
/*     */   public String getRoleName() {
/*  76 */     return this.roleName;
/*     */   }
/*     */ 
/*     */   public void setRoleName(String roleName) {
/*  80 */     this.roleName = roleName;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/*  84 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setParentId(String parentId) {
/*  88 */     this.parentId = parentId;
/*     */   }
/*     */ 
/*     */   public Date getCreateTime() {
/*  92 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(Date createTime) {
/*  96 */     this.createTime = createTime;
/*     */   }
/*     */ 
/*     */   public Date getBeginDate() {
/* 100 */     return this.beginDate;
/*     */   }
/*     */ 
/*     */   public void setBeginDate(Date beginDate) {
/* 104 */     this.beginDate = beginDate;
/*     */   }
/*     */ 
/*     */   public Date getEndDate() {
/* 108 */     return this.endDate;
/*     */   }
/*     */ 
/*     */   public void setEndDate(Date endDate) {
/* 112 */     this.endDate = endDate;
/*     */   }
/*     */ 
/*     */   public String getCreateGroup()
/*     */   {
/* 119 */     return this.createGroup;
/*     */   }
/*     */ 
/*     */   public void setCreateGroup(String createGroup)
/*     */   {
/* 125 */     this.createGroup = createGroup;
/*     */   }
/*     */ 
/*     */   public int getResourceType()
/*     */   {
/* 132 */     return this.resourceType;
/*     */   }
/*     */ 
/*     */   public void setResourceType(int resourceType)
/*     */   {
/* 138 */     this.resourceType = resourceType;
/*     */   }
/*     */ 
/*     */   public int getRoleType()
/*     */   {
/* 144 */     return this.roleType;
/*     */   }
/*     */ 
/*     */   public void setRoleType(int roleType)
/*     */   {
/* 150 */     this.roleType = roleType;
/*     */   }
/*     */ 
/*     */   public int getStatus()
/*     */   {
/* 156 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(int status)
/*     */   {
/* 162 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public int getUserLimit()
/*     */   {
/* 168 */     return this.userLimit;
/*     */   }
/*     */ 
/*     */   public void setUserLimit(int userLimit)
/*     */   {
/* 174 */     this.userLimit = userLimit;
/*     */   }
/*     */ 
/*     */   public boolean isAdmin()
/*     */   {
/* 179 */     return "1".equals(getCreateGroup());
/*     */   }
/*     */   public Map toMap() {
/* 182 */     Map map = new HashMap();
/* 183 */     Map infoMap = new HashMap();
/* 184 */     infoMap.put("ROLEID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.role") + "ID", getRoleId());
/* 185 */     infoMap.put("ROLENAME_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleName") + "", getRoleName());
/* 186 */     infoMap.put("PARENTID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parentRole") + "ID", getParentId());
/* 187 */     infoMap.put("STATUS_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleState") + "", String.valueOf(getStatus()));
/* 188 */     infoMap.put("BEGINDATE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleBeginDate") + "", getBeginDate());
/* 189 */     infoMap.put("ENDDATE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleEndDate"), getEndDate());
/* 190 */     infoMap.put("CREATETIME_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleCreateTime") + "", getCreateTime());
/* 191 */     infoMap.put("CREATEGROUP_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleGroup") + "", getCreateGroup());
/* 192 */     infoMap.put("RESOURCETYPE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleResourceType") + "", String.valueOf(getResourceType()));
/* 193 */     infoMap.put("ROLETYPE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleType") + "", String.valueOf(getRoleType()));
/* 194 */     infoMap.put("USERLIMIT_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userLimit") + "", String.valueOf(getUserLimit()));
/* 195 */     infoMap.put("CLASSIFYID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userRoleClassify") + "", String.valueOf(getUserLimit()));
/*     */ 
/* 197 */     map.put("USERROLE", infoMap);
/* 198 */     return map;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 204 */     if (this == other)
/* 205 */       return true;
/* 206 */     if (other == null)
/* 207 */       return false;
/* 208 */     if (!(other instanceof UserRole))
/* 209 */       return false;
/* 210 */     UserRole castOther = (UserRole)other;
/*     */ 
/* 212 */     return new EqualsBuilder().append(getRoleId(), castOther.getRoleId()).isEquals();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 217 */     return new HashCodeBuilder().append(getRoleId()).toHashCode();
/*     */   }
/*     */   public String getDeleteTime() {
/* 220 */     return this.deleteTime;
/*     */   }
/*     */   public void setDeleteTime(String deleteTime) {
/* 223 */     this.deleteTime = deleteTime;
/*     */   }
/*     */   public String getBeginDeleteTime() {
/* 226 */     return this.beginDeleteTime;
/*     */   }
/*     */   public void setBeginDeleteTime(String beginDeleteTime) {
/* 229 */     this.beginDeleteTime = beginDeleteTime;
/*     */   }
/*     */   public String getEndDeleteTime() {
/* 232 */     return this.endDeleteTime;
/*     */   }
/*     */   public void setEndDeleteTime(String endDeleteTime) {
/* 235 */     this.endDeleteTime = endDeleteTime;
/*     */   }
/*     */   public String getStatusDesc() {
/* 238 */     return SysManageConstants.getStatusDesc(String.valueOf(this.status));
/*     */   }
/*     */   public String getCreateGroupName() {
/* 241 */     return this.createGroupName;
/*     */   }
/*     */   public void setCreateGroupName(String createGroupName) {
/* 244 */     this.createGroupName = createGroupName;
/*     */   }
/*     */   public String getRoleTypeName() {
/* 247 */     if (0 == this.roleType) {
/* 248 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cityRole") + "";
/*     */     }
/* 250 */     if (1 == this.roleType) {
/* 251 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourceRole") + "";
/*     */     }
/* 253 */     if (2 == this.roleType) {
/* 254 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.operationRole") + "";
/*     */     }
/* 256 */     return "";
/*     */   }
/*     */   public String getResourceTypeName() {
/* 259 */     if (Integer.parseInt("5") == this.resourceType) {
/* 260 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourceTypeCity") + "";
/*     */     }
/* 262 */     if (Integer.parseInt("3") == this.resourceType) {
/* 263 */       return LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourceTypeReport");
/*     */     }
/* 265 */     if (Integer.parseInt("4") == this.resourceType) {
/* 266 */       return "KPI" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resource") + "";
/*     */     }
/* 268 */     if (Integer.parseInt("34") == this.resourceType) {
/* 269 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourctTypeFileReport") + "";
/*     */     }
/* 271 */     if (Integer.parseInt("50") == this.resourceType) {
/* 272 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourctTypeMenuItem") + "";
/*     */     }
/* 274 */     if (Integer.parseInt("41") == this.resourceType) {
/* 275 */       return "portlet" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resource") + "";
/*     */     }
/* 277 */     if (Integer.parseInt("37") == this.resourceType) {
/* 278 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourctTypeIrindi") + "";
/*     */     }
/* 280 */     if (301 == this.resourceType) {
/* 281 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourceTypeTopic") + "";
/*     */     }
/* 283 */     if (302 == this.resourceType) {
/* 284 */       return LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourctTypeReport2");
/*     */     }
/* 286 */     if (42 == this.resourceType) {
/* 287 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourctTypeOther") + "";
/*     */     }
/* 289 */     if (501 == this.resourceType) {
/* 290 */       return LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourctTypeKpiReport");
/*     */     }
/* 292 */     return "";
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 296 */     StringBuilder sb = new StringBuilder(256);
/* 297 */     sb.append("[roleId=").append(getRoleId()).append("]");
/* 298 */     sb.append("[roleName=").append(getRoleName()).append("]");
/* 299 */     sb.append("[roletype=").append(getRoleType()).append("]");
/* 300 */     sb.append("[resourceType=").append(getResourceType()).append("]");
/* 301 */     sb.append("[resoruceTypeName=").append(getResourceTypeName()).append("]");
/*     */ 
/* 303 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getClassifyId() {
/* 307 */     return this.classifyId;
/*     */   }
/*     */ 
/*     */   public void setClassifyId(String classifyId) {
/* 311 */     this.classifyId = classifyId;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserRole
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class UserRoleClassify
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -3482534774911083953L;
/*     */   private String classifyId;
/*     */   private String parentId;
/*     */   private String classifyName;
/*     */   private String classifyDesc;
/*     */   private String parentName;
/*     */ 
/*     */   public UserRoleClassify()
/*     */   {
/*     */   }
/*     */ 
/*     */   public UserRoleClassify(String classifyId, String parentId, String classifyName)
/*     */   {
/*  51 */     this.classifyId = classifyId;
/*  52 */     this.parentId = parentId;
/*  53 */     this.classifyName = classifyName;
/*     */   }
/*     */ 
/*     */   public UserRoleClassify(String classifyId, String parentId, String classifyName, String classifyDesc)
/*     */   {
/*  59 */     this.classifyId = classifyId;
/*  60 */     this.parentId = parentId;
/*  61 */     this.classifyName = classifyName;
/*  62 */     this.classifyDesc = classifyDesc;
/*     */   }
/*     */ 
/*     */   public String getClassifyId()
/*     */   {
/*  68 */     return this.classifyId;
/*     */   }
/*     */ 
/*     */   public void setClassifyId(String classifyId) {
/*  72 */     this.classifyId = classifyId;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/*  76 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setParentId(String parentId) {
/*  80 */     this.parentId = parentId;
/*     */   }
/*     */ 
/*     */   public String getClassifyName() {
/*  84 */     return this.classifyName;
/*     */   }
/*     */ 
/*     */   public void setClassifyName(String classifyName) {
/*  88 */     this.classifyName = classifyName;
/*     */   }
/*     */ 
/*     */   public String getClassifyDesc() {
/*  92 */     return this.classifyDesc;
/*     */   }
/*     */ 
/*     */   public void setClassifyDesc(String classifyDesc) {
/*  96 */     this.classifyDesc = classifyDesc;
/*     */   }
/*     */ 
/*     */   public String getParentName() {
/* 100 */     return this.parentName;
/*     */   }
/*     */ 
/*     */   public void setParentName(String parentName) {
/* 104 */     this.parentName = parentName;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserRoleClassify
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class UserRoleMap
/*    */   implements Serializable
/*    */ {
/*    */   private String userid;
/*    */   private String roleId;
/*    */ 
/*    */   public UserRoleMap()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UserRoleMap(String userid, String roleId)
/*    */   {
/* 27 */     this.userid = userid;
/* 28 */     this.roleId = roleId;
/*    */   }
/*    */   public UserRoleMap(String userid) {
/* 31 */     this.userid = userid;
/*    */   }
/*    */ 
/*    */   public String getUserid()
/*    */   {
/* 39 */     return this.userid;
/*    */   }
/*    */ 
/*    */   public void setUserid(String userid) {
/* 43 */     this.userid = userid;
/*    */   }
/*    */ 
/*    */   public String getRoleId() {
/* 47 */     return this.roleId;
/*    */   }
/*    */ 
/*    */   public void setRoleId(String roleId) {
/* 51 */     this.roleId = roleId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 56 */     if (this == other)
/* 57 */       return true;
/* 58 */     if (other == null)
/* 59 */       return false;
/* 60 */     if (!(other instanceof UserRoleMap))
/* 61 */       return false;
/* 62 */     UserRoleMap castOther = (UserRoleMap)other;
/*    */ 
/* 64 */     return ((getUserid() == castOther.getUserid()) || ((getUserid() != null) && (castOther.getUserid() != null) && (getUserid().equals(castOther.getUserid())))) && ((getRoleId() == castOther.getRoleId()) || ((getRoleId() != null) && (castOther.getRoleId() != null) && (getRoleId().equals(castOther.getRoleId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 76 */     int result = 17;
/*    */ 
/* 78 */     result = 37 * result + (getUserid() == null ? 0 : getUserid().hashCode());
/*    */ 
/* 80 */     result = 37 * result + (getRoleId() == null ? 0 : getRoleId().hashCode());
/*    */ 
/* 82 */     return result;
/*    */   }
/*    */   public Map toMap() {
/* 85 */     Map map = new HashMap();
/* 86 */     Map infoMap = new HashMap();
/* 87 */     infoMap.put("USERID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.user") + "ID", getUserid());
/* 88 */     infoMap.put("ROLEID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.role") + "ID", getRoleId());
/* 89 */     map.put("USERROLEMAP", infoMap);
/* 90 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserRoleMap
 * JD-Core Version:    0.6.2
 */
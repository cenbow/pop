/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ public class UserSysMap
/*     */   implements Serializable
/*     */ {
/*     */   private Long otherSysId;
/*     */   private String otherUserId;
/*     */   private String localUserId;
/*     */   private String otherSysName;
/*     */   private String localUserName;
/*     */   private String localUserGroupId;
/*     */   private String localUserGroupName;
/*     */   private String localUserCityId;
/*     */   private String localUserCityName;
/*     */   private String otherUserPwd;
/*     */   private String notes;
/*     */   private String param0;
/*     */   private String param1;
/*     */   private String param2;
/*     */   private String param3;
/*     */ 
/*     */   public Long getOtherSysId()
/*     */   {
/*  49 */     return this.otherSysId;
/*     */   }
/*     */ 
/*     */   public void setOtherSysId(Long otherSysId) {
/*  53 */     this.otherSysId = otherSysId;
/*     */   }
/*     */ 
/*     */   public String getOtherUserId() {
/*  57 */     return this.otherUserId;
/*     */   }
/*     */ 
/*     */   public void setOtherUserId(String otherUserId) {
/*  61 */     this.otherUserId = otherUserId;
/*     */   }
/*     */ 
/*     */   public String getLocalUserId() {
/*  65 */     return this.localUserId;
/*     */   }
/*     */ 
/*     */   public void setLocalUserId(String localUserId) {
/*  69 */     this.localUserId = localUserId;
/*     */   }
/*     */ 
/*     */   public String getOtherSysName() {
/*  73 */     return this.otherSysName;
/*     */   }
/*     */ 
/*     */   public void setOtherSysName(String otherSysName) {
/*  77 */     this.otherSysName = otherSysName;
/*     */   }
/*     */ 
/*     */   public String getOtherUserPwd() {
/*  81 */     return this.otherUserPwd;
/*     */   }
/*     */ 
/*     */   public void setOtherUserPwd(String otherUserPwd) {
/*  85 */     this.otherUserPwd = otherUserPwd;
/*     */   }
/*     */ 
/*     */   public String getLocalUserName() {
/*  89 */     return this.localUserName;
/*     */   }
/*     */ 
/*     */   public void setLocalUserName(String localUserName) {
/*  93 */     this.localUserName = localUserName;
/*     */   }
/*     */ 
/*     */   public String getLocalUserGroupId() {
/*  97 */     return this.localUserGroupId;
/*     */   }
/*     */ 
/*     */   public void setLocalUserGroupId(String localUserGroupId) {
/* 101 */     this.localUserGroupId = localUserGroupId;
/*     */   }
/*     */ 
/*     */   public String getLocalUserGroupName() {
/* 105 */     return this.localUserGroupName;
/*     */   }
/*     */ 
/*     */   public void setLocalUserGroupName(String localUserGroupName) {
/* 109 */     this.localUserGroupName = localUserGroupName;
/*     */   }
/*     */ 
/*     */   public String getLocalUserCityId() {
/* 113 */     return this.localUserCityId;
/*     */   }
/*     */ 
/*     */   public void setLocalUserCityId(String localUserCityId) {
/* 117 */     this.localUserCityId = localUserCityId;
/*     */   }
/*     */ 
/*     */   public String getLocalUserCityName() {
/* 121 */     return this.localUserCityName;
/*     */   }
/*     */ 
/*     */   public void setLocalUserCityName(String localUserCityName) {
/* 125 */     this.localUserCityName = localUserCityName;
/*     */   }
/*     */ 
/*     */   public String getNotes() {
/* 129 */     return this.notes;
/*     */   }
/*     */ 
/*     */   public void setNotes(String notes) {
/* 133 */     this.notes = notes;
/*     */   }
/*     */ 
/*     */   public String getParam0() {
/* 137 */     return this.param0;
/*     */   }
/*     */ 
/*     */   public void setParam0(String param0) {
/* 141 */     this.param0 = param0;
/*     */   }
/*     */ 
/*     */   public String getParam1() {
/* 145 */     return this.param1;
/*     */   }
/*     */ 
/*     */   public void setParam1(String param1) {
/* 149 */     this.param1 = param1;
/*     */   }
/*     */ 
/*     */   public String getParam2() {
/* 153 */     return this.param2;
/*     */   }
/*     */ 
/*     */   public String getParam3() {
/* 157 */     return this.param3;
/*     */   }
/*     */ 
/*     */   public void setParam3(String param3) {
/* 161 */     this.param3 = param3;
/*     */   }
/*     */ 
/*     */   public void setParam2(String param2) {
/* 165 */     this.param2 = param2;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 170 */     if (other == null)
/* 171 */       return false;
/* 172 */     if (!(other instanceof UserSysMap))
/* 173 */       return false;
/* 174 */     UserSysMap castOther = (UserSysMap)other;
/* 175 */     return new EqualsBuilder().append(getOtherSysId(), castOther.getOtherSysId()).append(getLocalUserId(), castOther.getLocalUserId()).append(getOtherUserId(), castOther.getOtherUserId()).isEquals();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 182 */     return new HashCodeBuilder().append(getOtherSysId()).append(getLocalUserId()).append(getOtherUserId()).toHashCode();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserSysMap
 * JD-Core Version:    0.6.2
 */
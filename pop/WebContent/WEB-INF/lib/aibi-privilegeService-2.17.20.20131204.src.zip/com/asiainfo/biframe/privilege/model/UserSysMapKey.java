/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.commons.lang.builder.EqualsBuilder;
/*    */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*    */ 
/*    */ public class UserSysMapKey
/*    */   implements Serializable
/*    */ {
/*    */   private Long otherSysId;
/*    */   private String otherUserId;
/*    */   private String localUserId;
/*    */ 
/*    */   public Long getOtherSysId()
/*    */   {
/* 29 */     return this.otherSysId;
/*    */   }
/*    */   public void setOtherSysId(Long otherSysId) {
/* 32 */     this.otherSysId = otherSysId;
/*    */   }
/*    */   public String getOtherUserId() {
/* 35 */     return this.otherUserId;
/*    */   }
/*    */   public void setOtherUserId(String otherUserId) {
/* 38 */     this.otherUserId = otherUserId;
/*    */   }
/*    */   public String getLocalUserId() {
/* 41 */     return this.localUserId;
/*    */   }
/*    */   public void setLocalUserId(String localUserId) {
/* 44 */     this.localUserId = localUserId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other) {
/* 48 */     if (other == null)
/* 49 */       return false;
/* 50 */     if (!(other instanceof UserSysMapKey))
/* 51 */       return false;
/* 52 */     UserSysMapKey castOther = (UserSysMapKey)other;
/* 53 */     return new EqualsBuilder().append(getOtherSysId(), castOther.getOtherSysId()).append(getLocalUserId(), castOther.getLocalUserId()).append(getOtherUserId(), castOther.getOtherUserId()).isEquals();
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 60 */     return new HashCodeBuilder().append(getOtherSysId()).append(getLocalUserId()).append(getOtherUserId()).toHashCode();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserSysMapKey
 * JD-Core Version:    0.6.2
 */
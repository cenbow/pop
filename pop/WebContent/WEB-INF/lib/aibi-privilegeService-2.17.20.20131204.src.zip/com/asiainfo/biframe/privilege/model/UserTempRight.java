/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*    */ import java.util.Date;
/*    */ import org.apache.commons.lang.builder.EqualsBuilder;
/*    */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*    */ 
/*    */ public class UserTempRight extends Right
/*    */ {
/*    */   private String state;
/*    */   private String applyId;
/*    */   private String userId;
/*    */   private Date beginDate;
/*    */   private Date endDate;
/*    */ 
/*    */   public String getApplyId()
/*    */   {
/* 42 */     return this.applyId;
/*    */   }
/*    */ 
/*    */   public void setApplyId(String applyId) {
/* 46 */     this.applyId = applyId;
/*    */   }
/*    */ 
/*    */   public String getUserId() {
/* 50 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public void setUserId(String userId) {
/* 54 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   public Date getBeginDate() {
/* 58 */     return this.beginDate;
/*    */   }
/*    */ 
/*    */   public void setBeginDate(Date beginDate) {
/* 62 */     this.beginDate = beginDate;
/*    */   }
/*    */ 
/*    */   public Date getEndDate() {
/* 66 */     return this.endDate;
/*    */   }
/*    */ 
/*    */   public void setEndDate(Date endDate) {
/* 70 */     this.endDate = endDate;
/*    */   }
/*    */ 
/*    */   public String getState() {
/* 74 */     return this.state;
/*    */   }
/*    */ 
/*    */   public void setState(String state) {
/* 78 */     this.state = state;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 84 */     if (!(other instanceof UserTempRight))
/* 85 */       return false;
/* 86 */     UserTempRight castOther = (UserTempRight)other;
/* 87 */     return new EqualsBuilder().append(getRightId(), castOther.getRightId()).append(getRoleType(), castOther.getRoleType()).append(getResourceType(), castOther.getResourceType()).append(getResourceId(), castOther.getResourceId()).append(getOperationType(), castOther.getOperationType()).isEquals();
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 97 */     return new HashCodeBuilder().append(getRightId()).append(getRoleType()).append(getResourceType()).append(getResourceId()).append(getOperationType()).toHashCode();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserTempRight
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.cache.service.IdAndName;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class UserUserBak
/*     */   implements Serializable, IdAndName
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String userBakId;
/*     */   private String userid;
/*     */   private String cityid;
/*     */   private int departmentid;
/*     */   private String username;
/*     */   private String pwd;
/*     */   private int status;
/*     */   private Date begindate;
/*     */   private Date enddate;
/*     */   private Date createtime;
/*     */   private Date birthday;
/*     */   private String mobilephone;
/*     */   private String mobilephone1;
/*     */   private String mobilephone2;
/*     */   private String homephone;
/*     */   private String officephone;
/*     */   private String officefax;
/*     */   private String email;
/*     */   private String email1;
/*     */   private String email2;
/*     */   private String notes;
/*     */   private Integer dutyid;
/*     */   private String sex;
/*     */   private String age;
/*     */   private String address;
/*     */   private String postalcode;
/*     */   private String nation;
/*     */   private String passportNo;
/*     */   private String director;
/*     */   private String deleteTime;
/*  40 */   private String sensitiveDataLevel = "D";
/*     */   private String domainType;
/*     */ 
/*     */   public String getUserBakId()
/*     */   {
/*  44 */     return this.userBakId;
/*     */   }
/*     */ 
/*     */   public void setUserBakId(String userBakId)
/*     */   {
/*  49 */     this.userBakId = userBakId;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  53 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getPrimaryKey() {
/*  57 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUserid()
/*     */   {
/*  62 */     return this.userid;
/*     */   }
/*     */ 
/*     */   public void setUserid(String userid)
/*     */   {
/*  67 */     this.userid = userid;
/*     */   }
/*     */ 
/*     */   public String getCityid()
/*     */   {
/*  72 */     return this.cityid;
/*     */   }
/*     */ 
/*     */   public void setCityid(String cityid)
/*     */   {
/*  77 */     this.cityid = cityid;
/*     */   }
/*     */ 
/*     */   public int getDepartmentid()
/*     */   {
/*  82 */     return this.departmentid;
/*     */   }
/*     */ 
/*     */   public void setDepartmentid(int departmentid)
/*     */   {
/*  87 */     this.departmentid = departmentid;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/*  92 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/*  97 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public String getPwd()
/*     */   {
/* 102 */     return this.pwd;
/*     */   }
/*     */ 
/*     */   public void setPwd(String pwd)
/*     */   {
/* 107 */     this.pwd = pwd;
/*     */   }
/*     */ 
/*     */   public int getStatus()
/*     */   {
/* 112 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(int status)
/*     */   {
/* 117 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public Date getBegindate()
/*     */   {
/* 122 */     return this.begindate;
/*     */   }
/*     */ 
/*     */   public void setBegindate(Date begindate)
/*     */   {
/* 127 */     this.begindate = begindate;
/*     */   }
/*     */ 
/*     */   public Date getEnddate()
/*     */   {
/* 132 */     return this.enddate;
/*     */   }
/*     */ 
/*     */   public void setEnddate(Date enddate)
/*     */   {
/* 137 */     this.enddate = enddate;
/*     */   }
/*     */ 
/*     */   public Date getCreatetime()
/*     */   {
/* 142 */     return this.createtime;
/*     */   }
/*     */ 
/*     */   public void setCreatetime(Date createtime)
/*     */   {
/* 147 */     this.createtime = createtime;
/*     */   }
/*     */ 
/*     */   public Date getBirthday()
/*     */   {
/* 152 */     return this.birthday;
/*     */   }
/*     */ 
/*     */   public void setBirthday(Date birthday)
/*     */   {
/* 157 */     this.birthday = birthday;
/*     */   }
/*     */ 
/*     */   public String getMobilephone()
/*     */   {
/* 162 */     return this.mobilephone;
/*     */   }
/*     */ 
/*     */   public void setMobilephone(String mobilephone)
/*     */   {
/* 167 */     this.mobilephone = mobilephone;
/*     */   }
/*     */ 
/*     */   public String getMobilephone1()
/*     */   {
/* 172 */     return this.mobilephone1;
/*     */   }
/*     */ 
/*     */   public void setMobilephone1(String mobilephone1)
/*     */   {
/* 177 */     this.mobilephone1 = mobilephone1;
/*     */   }
/*     */ 
/*     */   public String getMobilephone2()
/*     */   {
/* 182 */     return this.mobilephone2;
/*     */   }
/*     */ 
/*     */   public void setMobilephone2(String mobilephone2)
/*     */   {
/* 187 */     this.mobilephone2 = mobilephone2;
/*     */   }
/*     */ 
/*     */   public String getHomephone()
/*     */   {
/* 192 */     return this.homephone;
/*     */   }
/*     */ 
/*     */   public void setHomephone(String homephone)
/*     */   {
/* 197 */     this.homephone = homephone;
/*     */   }
/*     */ 
/*     */   public String getOfficephone()
/*     */   {
/* 202 */     return this.officephone;
/*     */   }
/*     */ 
/*     */   public void setOfficephone(String officephone)
/*     */   {
/* 207 */     this.officephone = officephone;
/*     */   }
/*     */ 
/*     */   public String getOfficefax()
/*     */   {
/* 212 */     return this.officefax;
/*     */   }
/*     */ 
/*     */   public void setOfficefax(String officefax)
/*     */   {
/* 217 */     this.officefax = officefax;
/*     */   }
/*     */ 
/*     */   public String getEmail()
/*     */   {
/* 222 */     return this.email;
/*     */   }
/*     */ 
/*     */   public void setEmail(String email)
/*     */   {
/* 227 */     this.email = email;
/*     */   }
/*     */ 
/*     */   public String getEmail1()
/*     */   {
/* 232 */     return this.email1;
/*     */   }
/*     */ 
/*     */   public void setEmail1(String email1)
/*     */   {
/* 237 */     this.email1 = email1;
/*     */   }
/*     */ 
/*     */   public String getEmail2()
/*     */   {
/* 242 */     return this.email2;
/*     */   }
/*     */ 
/*     */   public void setEmail2(String email2)
/*     */   {
/* 247 */     this.email2 = email2;
/*     */   }
/*     */ 
/*     */   public String getNotes()
/*     */   {
/* 252 */     return this.notes;
/*     */   }
/*     */ 
/*     */   public void setNotes(String notes)
/*     */   {
/* 257 */     this.notes = notes;
/*     */   }
/*     */ 
/*     */   public Integer getDutyid()
/*     */   {
/* 262 */     return this.dutyid;
/*     */   }
/*     */ 
/*     */   public void setDutyid(Integer dutyid)
/*     */   {
/* 267 */     this.dutyid = dutyid;
/*     */   }
/*     */ 
/*     */   public String getSex()
/*     */   {
/* 272 */     return this.sex;
/*     */   }
/*     */ 
/*     */   public void setSex(String sex)
/*     */   {
/* 277 */     this.sex = sex;
/*     */   }
/*     */ 
/*     */   public String getAge()
/*     */   {
/* 282 */     return this.age;
/*     */   }
/*     */ 
/*     */   public void setAge(String age)
/*     */   {
/* 287 */     this.age = age;
/*     */   }
/*     */ 
/*     */   public String getAddress()
/*     */   {
/* 292 */     return this.address;
/*     */   }
/*     */ 
/*     */   public void setAddress(String address)
/*     */   {
/* 297 */     this.address = address;
/*     */   }
/*     */ 
/*     */   public String getPostalcode()
/*     */   {
/* 302 */     return this.postalcode;
/*     */   }
/*     */ 
/*     */   public void setPostalcode(String postalcode)
/*     */   {
/* 307 */     this.postalcode = postalcode;
/*     */   }
/*     */ 
/*     */   public String getNation()
/*     */   {
/* 312 */     return this.nation;
/*     */   }
/*     */ 
/*     */   public void setNation(String nation)
/*     */   {
/* 317 */     this.nation = nation;
/*     */   }
/*     */ 
/*     */   public String getPassportNo()
/*     */   {
/* 322 */     return this.passportNo;
/*     */   }
/*     */ 
/*     */   public void setPassportNo(String passportNo)
/*     */   {
/* 327 */     this.passportNo = passportNo;
/*     */   }
/*     */ 
/*     */   public String getDirector()
/*     */   {
/* 332 */     return this.director;
/*     */   }
/*     */ 
/*     */   public void setDirector(String director)
/*     */   {
/* 337 */     this.director = director;
/*     */   }
/*     */ 
/*     */   public String getDeleteTime()
/*     */   {
/* 342 */     return this.deleteTime;
/*     */   }
/*     */ 
/*     */   public void setDeleteTime(String deleteTime)
/*     */   {
/* 347 */     this.deleteTime = deleteTime;
/*     */   }
/*     */ 
/*     */   public String getSensitiveDataLevel()
/*     */   {
/* 352 */     return this.sensitiveDataLevel;
/*     */   }
/*     */ 
/*     */   public void setSensitiveDataLevel(String sensitiveDataLevel)
/*     */   {
/* 357 */     this.sensitiveDataLevel = sensitiveDataLevel;
/*     */   }
/*     */ 
/*     */   public String getDomainType()
/*     */   {
/* 362 */     return this.domainType;
/*     */   }
/*     */ 
/*     */   public void setDomainType(String domainType)
/*     */   {
/* 367 */     this.domainType = domainType;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 372 */     if (this == other) {
/* 373 */       return true;
/*     */     }
/* 375 */     if (other == null) {
/* 376 */       return false;
/*     */     }
/* 378 */     if (!(other instanceof UserUserBak)) {
/* 379 */       return false;
/*     */     }
/* 381 */     UserUserBak castOther = (UserUserBak)other;
/*     */ 
/* 383 */     return ((getUserid() == castOther.getUserid()) || ((getUserid() != null) && (castOther.getUserid() != null) && (getUserid().equals(castOther.getUserid())))) && ((getDeleteTime() == castOther.getDeleteTime()) || ((getDeleteTime() != null) && (castOther.getDeleteTime() != null) && (getDeleteTime().equals(castOther.getDeleteTime()))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 395 */     int result = 17;
/* 396 */     result = 37 * result + (getUserid() == null ? 0 : getUserid().hashCode());
/*     */ 
/* 398 */     result = 37 * result + (getDeleteTime() == null ? 0 : getDeleteTime().hashCode());
/*     */ 
/* 402 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserUserBak
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserExt;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class UserUserExt
/*     */   implements Serializable, IUserExt
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String userid;
/*     */   private String param0;
/*     */   private String param1;
/*     */   private String param2;
/*     */   private String param3;
/*     */   private String param4;
/*     */   private String param5;
/*     */   private String param6;
/*     */   private String param7;
/*     */   private String loginNum;
/*     */   private String kpiNum;
/*     */   private String kpiName;
/*     */   private String smsKpiName;
/*     */   private String param8;
/*     */   private User_User user;
/*     */ 
/*     */   public User_User getUser()
/*     */   {
/*  47 */     return this.user;
/*     */   }
/*     */ 
/*     */   public void setUser(User_User user) {
/*  51 */     this.user = user;
/*     */   }
/*     */ 
/*     */   public UserUserExt()
/*     */   {
/*     */   }
/*     */ 
/*     */   public UserUserExt(String userid)
/*     */   {
/*  60 */     this.userid = userid;
/*     */   }
/*     */ 
/*     */   public UserUserExt(String userid, String param0, String param1, String param2, String param3, String param4, String param5, String param6, String param7, String loginNum)
/*     */   {
/*  65 */     this.userid = userid;
/*  66 */     this.param0 = param0;
/*  67 */     this.param1 = param1;
/*  68 */     this.param2 = param2;
/*  69 */     this.param3 = param3;
/*  70 */     this.param4 = param4;
/*  71 */     this.param5 = param5;
/*  72 */     this.param6 = param6;
/*  73 */     this.param7 = param7;
/*  74 */     this.loginNum = loginNum;
/*     */   }
/*     */ 
/*     */   public UserUserExt(String userid, String param0, String param1, String param2, String param3, String param4, String param5, String param6, String param7, String param8, String loginNum) {
/*  78 */     this.userid = userid;
/*  79 */     this.param0 = param0;
/*  80 */     this.param1 = param1;
/*  81 */     this.param2 = param2;
/*  82 */     this.param3 = param3;
/*  83 */     this.param4 = param4;
/*  84 */     this.param5 = param5;
/*  85 */     this.param6 = param6;
/*  86 */     this.param7 = param7;
/*  87 */     this.param8 = param8;
/*  88 */     this.loginNum = loginNum;
/*     */   }
/*     */ 
/*     */   public String getUserid()
/*     */   {
/*  95 */     return this.userid;
/*     */   }
/*     */ 
/*     */   public void setUserid(String userid) {
/*  99 */     this.userid = userid;
/*     */   }
/*     */ 
/*     */   public String getParam0() {
/* 103 */     return this.param0;
/*     */   }
/*     */ 
/*     */   public void setParam0(String param0) {
/* 107 */     this.param0 = param0;
/*     */   }
/*     */ 
/*     */   public String getParam1() {
/* 111 */     return this.param1;
/*     */   }
/*     */ 
/*     */   public void setParam1(String param1) {
/* 115 */     this.param1 = param1;
/*     */   }
/*     */ 
/*     */   public String getParam2() {
/* 119 */     return this.param2;
/*     */   }
/*     */ 
/*     */   public void setParam2(String param2) {
/* 123 */     this.param2 = param2;
/*     */   }
/*     */ 
/*     */   public String getParam3() {
/* 127 */     return this.param3;
/*     */   }
/*     */ 
/*     */   public void setParam3(String param3) {
/* 131 */     this.param3 = param3;
/*     */   }
/*     */ 
/*     */   public String getParam4() {
/* 135 */     return this.param4;
/*     */   }
/*     */ 
/*     */   public void setParam4(String param4) {
/* 139 */     this.param4 = param4;
/*     */   }
/*     */ 
/*     */   public String getParam5() {
/* 143 */     return this.param5;
/*     */   }
/*     */ 
/*     */   public void setParam5(String param5) {
/* 147 */     this.param5 = param5;
/*     */   }
/*     */ 
/*     */   public String getParam6() {
/* 151 */     return this.param6;
/*     */   }
/*     */ 
/*     */   public void setParam6(String param6) {
/* 155 */     this.param6 = param6;
/*     */   }
/*     */ 
/*     */   public String getParam7() {
/* 159 */     return this.param7;
/*     */   }
/*     */ 
/*     */   public void setParam7(String param7) {
/* 163 */     this.param7 = param7;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 168 */     return "[userid=" + getUserid() + "]" + "[param1=" + getParam1() + "]" + "[param2=" + getParam2() + "]" + "[param3=" + getParam3() + "]" + "[param4=" + getParam4() + "]" + "[param5=" + getParam5() + "]" + "[param6=" + getParam6() + "]" + "[param7=" + getParam7() + "]" + "[param8=" + getParam8() + "]" + "[loginNum=" + getLoginNum() + "]";
/*     */   }
/*     */ 
/*     */   public Map toMap()
/*     */   {
/* 182 */     Map map = new HashMap();
/* 183 */     Map infoMap = new HashMap();
/*     */ 
/* 185 */     infoMap.put("USERID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userid") + "", getUserid());
/* 186 */     infoMap.put("PARAM0_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.PARAM0") + "", getParam0());
/* 187 */     infoMap.put("PARAM1_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.PARAM1") + "IP", getParam1());
/* 188 */     infoMap.put("PARAM2_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.PARAM2"), getParam2());
/* 189 */     infoMap.put("PARAM3_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.PARAM3") + "", getParam3());
/* 190 */     infoMap.put("PARAM4_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.PARAM4") + "", getParam4());
/* 191 */     infoMap.put("PARAM5_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.PARAM5") + "", getParam5());
/* 192 */     infoMap.put("PARAM6_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.PARAM6") + "", getParam6());
/* 193 */     infoMap.put("PARAM7_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.PARAM7") + "", getParam7());
/* 194 */     infoMap.put("PARAM8_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.PARAM8") + "", getParam8());
/* 195 */     infoMap.put("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.loginCount") + "", getLoginNum());
/*     */ 
/* 197 */     map.put("USER_USER_EXT", infoMap);
/* 198 */     return map;
/*     */   }
/*     */ 
/*     */   public String getKpiName() {
/* 202 */     return this.kpiName;
/*     */   }
/*     */ 
/*     */   public void setKpiName(String kpiName) {
/* 206 */     this.kpiName = kpiName;
/*     */   }
/*     */ 
/*     */   public String getKpiNum() {
/* 210 */     return this.kpiNum;
/*     */   }
/*     */ 
/*     */   public void setKpiNum(String kpiNum) {
/* 214 */     this.kpiNum = kpiNum;
/*     */   }
/*     */ 
/*     */   public String getLoginNum() {
/* 218 */     return this.loginNum;
/*     */   }
/*     */ 
/*     */   public void setLoginNum(String loginNum) {
/* 222 */     this.loginNum = loginNum;
/*     */   }
/*     */ 
/*     */   public String getSmsKpiName() {
/* 226 */     return this.smsKpiName;
/*     */   }
/*     */ 
/*     */   public void setSmsKpiName(String smsKpiName) {
/* 230 */     this.smsKpiName = smsKpiName;
/*     */   }
/*     */ 
/*     */   public String getParam8() {
/* 234 */     return this.param8;
/*     */   }
/*     */ 
/*     */   public void setParam8(String param8) {
/* 238 */     this.param8 = param8;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserUserExt
 * JD-Core Version:    0.6.2
 */
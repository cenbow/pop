/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.lang.builder.EqualsBuilder;
/*    */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*    */ 
/*    */ public class UserUserMap
/*    */   implements Serializable
/*    */ {
/*    */   private String userid;
/*    */   private String userMapId;
/*    */   private long resourcetype;
/*    */   private String relationType;
/*    */ 
/*    */   public UserUserMap()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UserUserMap(String userid, String userMapId, long resourcetype, String relationType)
/*    */   {
/* 27 */     this.userid = userid;
/* 28 */     this.userMapId = userMapId;
/* 29 */     this.resourcetype = resourcetype;
/* 30 */     this.relationType = relationType;
/*    */   }
/*    */ 
/*    */   public String getUserid() {
/* 34 */     return this.userid;
/*    */   }
/*    */ 
/*    */   public void setUserid(String userid) {
/* 38 */     this.userid = userid;
/*    */   }
/*    */ 
/*    */   public String getUserMapId() {
/* 42 */     return this.userMapId;
/*    */   }
/*    */ 
/*    */   public void setUserMapId(String userMapId) {
/* 46 */     this.userMapId = userMapId;
/*    */   }
/*    */ 
/*    */   public long getResourcetype() {
/* 50 */     return this.resourcetype;
/*    */   }
/*    */ 
/*    */   public void setResourcetype(long resourcetype) {
/* 54 */     this.resourcetype = resourcetype;
/*    */   }
/*    */ 
/*    */   public String getRelationType() {
/* 58 */     return this.relationType;
/*    */   }
/*    */ 
/*    */   public void setRelationType(String relationType) {
/* 62 */     this.relationType = relationType;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 67 */     if (!(other instanceof UserUserMap))
/* 68 */       return false;
/* 69 */     UserUserMap castOther = (UserUserMap)other;
/* 70 */     EqualsBuilder eb = new EqualsBuilder();
/* 71 */     eb.append(getUserid(), castOther.getUserid());
/* 72 */     eb.append(getUserMapId(), castOther.getUserMapId());
/* 73 */     eb.append(getResourcetype(), castOther.getResourcetype());
/* 74 */     eb.append(getRelationType(), castOther.getRelationType());
/* 75 */     return eb.isEquals();
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 80 */     HashCodeBuilder hb = new HashCodeBuilder();
/* 81 */     hb.append(getUserid());
/* 82 */     hb.append(getUserMapId());
/* 83 */     hb.append(getResourcetype());
/* 84 */     hb.append(getRelationType());
/* 85 */     return hb.toHashCode();
/*    */   }
/*    */ 
/*    */   public Map toMap() {
/* 89 */     Map map = new HashMap();
/* 90 */     Map infoMap = new HashMap();
/*    */ 
/* 92 */     infoMap.put("USERID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userid") + "", getUserid());
/* 93 */     infoMap.put("USERMAPID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userMapId") + "", getUserMapId());
/* 94 */     infoMap.put("RESOURCETYPE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourceType") + "id", String.valueOf(getResourcetype()));
/* 95 */     infoMap.put("RELATIONTYPE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.relationType") + "", getRelationType());
/*    */ 
/* 97 */     map.put("USER_USER_MAP", infoMap);
/* 98 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserUserMap
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class UserValidate
/*     */   implements Serializable
/*     */ {
/*  18 */   private int hashValue = 0;
/*     */   private UserValidateKey id;
/*     */   private String userId;
/*     */   private String mapUserid;
/*     */   private Long status;
/*     */   private Date opDate;
/*     */   private String param0;
/*     */   private String param1;
/*     */   private String param2;
/*     */   private String param3;
/*     */ 
/*     */   public UserValidate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public UserValidate(UserValidateKey id)
/*     */   {
/*  60 */     setId(id);
/*     */   }
/*     */ 
/*     */   public UserValidateKey getId()
/*     */   {
/*  69 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(UserValidateKey id)
/*     */   {
/*  78 */     this.hashValue = 0;
/*  79 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getUserId()
/*     */   {
/*  88 */     return this.userId;
/*     */   }
/*     */ 
/*     */   public void setUserId(String userId)
/*     */   {
/*  97 */     this.userId = userId;
/*     */   }
/*     */ 
/*     */   public String getMapUserid()
/*     */   {
/* 106 */     return this.mapUserid;
/*     */   }
/*     */ 
/*     */   public void setMapUserid(String mapUserid)
/*     */   {
/* 115 */     this.mapUserid = mapUserid;
/*     */   }
/*     */ 
/*     */   public Long getStatus()
/*     */   {
/* 124 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(Long status)
/*     */   {
/* 133 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public Date getOpDate()
/*     */   {
/* 142 */     return this.opDate;
/*     */   }
/*     */ 
/*     */   public void setOpDate(Date opDate)
/*     */   {
/* 151 */     this.opDate = opDate;
/*     */   }
/*     */ 
/*     */   public String getParam0()
/*     */   {
/* 160 */     return this.param0;
/*     */   }
/*     */ 
/*     */   public void setParam0(String param0)
/*     */   {
/* 169 */     this.param0 = param0;
/*     */   }
/*     */ 
/*     */   public String getParam1()
/*     */   {
/* 178 */     return this.param1;
/*     */   }
/*     */ 
/*     */   public void setParam1(String param1)
/*     */   {
/* 187 */     this.param1 = param1;
/*     */   }
/*     */ 
/*     */   public String getParam2()
/*     */   {
/* 196 */     return this.param2;
/*     */   }
/*     */ 
/*     */   public void setParam2(String param2)
/*     */   {
/* 205 */     this.param2 = param2;
/*     */   }
/*     */ 
/*     */   public String getParam3()
/*     */   {
/* 214 */     return this.param3;
/*     */   }
/*     */ 
/*     */   public void setParam3(String param3)
/*     */   {
/* 223 */     this.param3 = param3;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object rhs)
/*     */   {
/* 234 */     if (rhs == null)
/* 235 */       return false;
/* 236 */     if (!(rhs instanceof UserValidate))
/* 237 */       return false;
/* 238 */     UserValidate that = (UserValidate)rhs;
/* 239 */     if ((getId() == null) || (that.getId() == null))
/* 240 */       return false;
/* 241 */     return getId().equals(that.getId());
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 252 */     if (this.hashValue == 0)
/*     */     {
/* 254 */       int result = 17;
/* 255 */       if (getId() == null)
/*     */       {
/* 257 */         result = super.hashCode();
/*     */       }
/*     */       else
/*     */       {
/* 261 */         result = getId().hashCode();
/*     */       }
/* 263 */       this.hashValue = result;
/*     */     }
/* 265 */     return this.hashValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserValidate
 * JD-Core Version:    0.6.2
 */
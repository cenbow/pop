/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class UserValidateKey
/*     */   implements Serializable
/*     */ {
/*  23 */   private volatile int hashValue = 0;
/*     */   private String sessionId;
/*     */   private String tokenId;
/*     */ 
/*     */   public String getSessionId()
/*     */   {
/*  44 */     return this.sessionId;
/*     */   }
/*     */ 
/*     */   public void setSessionId(String sessionId)
/*     */   {
/*  53 */     this.hashValue = 0;
/*  54 */     this.sessionId = sessionId;
/*     */   }
/*     */ 
/*     */   public String getTokenId()
/*     */   {
/*  63 */     return this.tokenId;
/*     */   }
/*     */ 
/*     */   public void setTokenId(String tokenId)
/*     */   {
/*  72 */     this.hashValue = 0;
/*  73 */     this.tokenId = tokenId;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object rhs)
/*     */   {
/*  84 */     if (rhs == null)
/*  85 */       return false;
/*  86 */     if (!(rhs instanceof UserValidateKey))
/*  87 */       return false;
/*  88 */     UserValidateKey that = (UserValidateKey)rhs;
/*  89 */     if ((getSessionId() == null) || (that.getSessionId() == null))
/*     */     {
/*  91 */       return false;
/*     */     }
/*  93 */     if (!getSessionId().equals(that.getSessionId()))
/*     */     {
/*  95 */       return false;
/*     */     }
/*  97 */     if ((getTokenId() == null) || (that.getTokenId() == null))
/*     */     {
/*  99 */       return false;
/*     */     }
/* 101 */     if (!getTokenId().equals(that.getTokenId()))
/*     */     {
/* 103 */       return false;
/*     */     }
/* 105 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 116 */     if (this.hashValue == 0)
/*     */     {
/* 118 */       int result = 17;
/* 119 */       int sessionIdValue = getSessionId() == null ? 0 : getSessionId().hashCode();
/* 120 */       result = result * 37 + sessionIdValue;
/* 121 */       int tokenIdValue = getTokenId() == null ? 0 : getTokenId().hashCode();
/* 122 */       result = result * 37 + tokenIdValue;
/* 123 */       this.hashValue = result;
/*     */     }
/* 125 */     return this.hashValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.UserValidateKey
 * JD-Core Version:    0.6.2
 */
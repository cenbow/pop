/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.ICity;
/*     */ import com.asiainfo.biframe.privilege.cache.service.IdAndName;
/*     */ import java.io.Serializable;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class User_City
/*     */   implements Serializable, IdAndName, ICity
/*     */ {
/*     */   private String cityId;
/*     */   private String cityName;
/*  29 */   private String parentId = "-1";
/*  30 */   private int sortNum = 0;
/*  31 */   private String dmCityId = "-1";
/*  32 */   private String dmCountyId = "-1";
/*  33 */   private String dmDeptId = "-1";
/*     */   private int resourceType;
/*  36 */   private boolean bAccess = true;
/*     */   private String dmTypeId;
/*     */   private String dmTypeCode;
/*     */ 
/*     */   public String getDmTypeId()
/*     */   {
/*  43 */     return this.dmTypeId;
/*     */   }
/*     */ 
/*     */   public void setDmTypeId(String dmTypeId) {
/*  47 */     this.dmTypeId = dmTypeId;
/*     */   }
/*     */ 
/*     */   public String getDmTypeCode() {
/*  51 */     return this.dmTypeCode;
/*     */   }
/*     */ 
/*     */   public void setDmTypeCode(String dmTypeCode) {
/*  55 */     this.dmTypeCode = dmTypeCode;
/*     */   }
/*     */ 
/*     */   public boolean isAccess()
/*     */   {
/*  69 */     return this.bAccess;
/*     */   }
/*     */ 
/*     */   public void setAccess(boolean bAccess) {
/*  73 */     this.bAccess = bAccess;
/*     */   }
/*     */ 
/*     */   public Object getPrimaryKey() {
/*  77 */     return String.valueOf(this.cityId);
/*     */   }
/*     */   public String getName() {
/*  80 */     return this.cityName;
/*     */   }
/*     */ 
/*     */   public String getCityId()
/*     */   {
/*  88 */     return this.cityId;
/*     */   }
/*     */ 
/*     */   public void setCityId(String cityId)
/*     */   {
/*  96 */     this.cityId = cityId;
/*     */   }
/*     */ 
/*     */   public String getCityName()
/*     */   {
/* 104 */     return this.cityName;
/*     */   }
/*     */ 
/*     */   public void setCityName(String cityName)
/*     */   {
/* 112 */     this.cityName = cityName;
/*     */   }
/*     */ 
/*     */   public String getParentId()
/*     */   {
/* 120 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setParentId(String parentId)
/*     */   {
/* 128 */     this.parentId = parentId;
/*     */   }
/*     */ 
/*     */   public int getSortNum()
/*     */   {
/* 137 */     return this.sortNum;
/*     */   }
/*     */ 
/*     */   public void setSortNum(int nSortNum)
/*     */   {
/* 142 */     this.sortNum = nSortNum;
/*     */   }
/*     */ 
/*     */   public String getDmCityId()
/*     */   {
/* 151 */     return this.dmCityId;
/*     */   }
/*     */ 
/*     */   public void setDmCityId(String dCityid)
/*     */   {
/* 156 */     this.dmCityId = dCityid;
/*     */   }
/*     */ 
/*     */   public String getDmCountyId()
/*     */   {
/* 161 */     return this.dmCountyId;
/*     */   }
/*     */ 
/*     */   public void setDmCountyId(String strCountyid)
/*     */   {
/* 166 */     this.dmCountyId = strCountyid;
/*     */   }
/*     */ 
/*     */   public String getDmDeptId()
/*     */   {
/* 171 */     return this.dmDeptId;
/*     */   }
/*     */ 
/*     */   public void setDmDeptId(String strDeptid)
/*     */   {
/* 176 */     this.dmDeptId = strDeptid;
/*     */   }
/*     */ 
/*     */   public int getResourceType() {
/* 180 */     return this.resourceType;
/*     */   }
/*     */ 
/*     */   public void setResourceType(int resourceType) {
/* 184 */     this.resourceType = resourceType;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 189 */     int prime = 31;
/* 190 */     int result = 1;
/* 191 */     result = 31 * result + (this.cityId == null ? 0 : this.cityId.hashCode());
/* 192 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 197 */     if (this == obj)
/* 198 */       return true;
/* 199 */     if (obj == null)
/* 200 */       return false;
/* 201 */     if (getClass() != obj.getClass())
/* 202 */       return false;
/* 203 */     User_City other = (User_City)obj;
/* 204 */     if (this.cityId == null) {
/* 205 */       if (other.cityId != null)
/* 206 */         return false;
/* 207 */     } else if (!this.cityId.equals(other.cityId))
/* 208 */       return false;
/* 209 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.User_City
 * JD-Core Version:    0.6.2
 */
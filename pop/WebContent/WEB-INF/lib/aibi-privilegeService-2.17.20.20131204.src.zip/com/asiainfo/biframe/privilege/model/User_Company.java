/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.privilege.cache.service.IdAndName;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.util.SysManageConstants;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class User_Company
/*     */   implements Serializable, IdAndName, IUserCompany
/*     */ {
/*     */   private Integer deptid;
/*     */   private Integer parentid;
/*     */   private String title;
/*     */   private String notes;
/*     */   private String serviceCode;
/*     */   private Integer sortNum;
/*     */   private String status;
/*     */   private String deleteTime;
/*     */   private String beginDeleteTime;
/*     */   private String endDeleteTime;
/*     */   private String parentName;
/*  43 */   private Set<String> allParentId = new HashSet();
/*     */   private String cityId;
/*     */ 
/*     */   public Object getPrimaryKey()
/*     */   {
/*  53 */     return String.valueOf(this.deptid);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  57 */     return this.title;
/*     */   }
/*     */ 
/*     */   public Integer getDeptid() {
/*  61 */     return this.deptid;
/*     */   }
/*     */ 
/*     */   public void setDeptid(Integer deptid) {
/*  65 */     this.deptid = deptid;
/*     */   }
/*     */ 
/*     */   public Integer getParentid() {
/*  69 */     return this.parentid;
/*     */   }
/*     */ 
/*     */   public void setParentid(Integer parentid) {
/*  73 */     this.parentid = parentid;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/*  77 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setTitle(String title) {
/*  81 */     this.title = title;
/*     */   }
/*     */ 
/*     */   public String getNotes() {
/*  85 */     return this.notes;
/*     */   }
/*     */ 
/*     */   public void setNotes(String notes) {
/*  89 */     this.notes = notes;
/*     */   }
/*     */ 
/*     */   public String getServiceCode() {
/*  93 */     return this.serviceCode;
/*     */   }
/*     */ 
/*     */   public void setServiceCode(String serviceCode) {
/*  97 */     this.serviceCode = serviceCode;
/*     */   }
/*     */ 
/*     */   public Integer getSortNum() {
/* 101 */     return this.sortNum;
/*     */   }
/*     */ 
/*     */   public void setSortNum(Integer sortNum) {
/* 105 */     this.sortNum = sortNum;
/*     */   }
/*     */ 
/*     */   public String getStatus() {
/* 109 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(String status) {
/* 113 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public String getDeleteTime() {
/* 117 */     return this.deleteTime;
/*     */   }
/*     */ 
/*     */   public void setDeleteTime(String deleteTime) {
/* 121 */     this.deleteTime = deleteTime;
/*     */   }
/*     */ 
/*     */   public String getBeginDeleteTime() {
/* 125 */     return this.beginDeleteTime;
/*     */   }
/*     */ 
/*     */   public void setBeginDeleteTime(String beginDeleteTime) {
/* 129 */     this.beginDeleteTime = beginDeleteTime;
/*     */   }
/*     */ 
/*     */   public String getEndDeleteTime() {
/* 133 */     return this.endDeleteTime;
/*     */   }
/*     */ 
/*     */   public void setEndDeleteTime(String endDeleteTime) {
/* 137 */     this.endDeleteTime = endDeleteTime;
/*     */   }
/*     */ 
/*     */   public String getStatusDesc() {
/* 141 */     return SysManageConstants.getStatusDesc(this.status);
/*     */   }
/*     */ 
/*     */   public String getParentName() {
/* 145 */     return this.parentName;
/*     */   }
/*     */ 
/*     */   public void setParentName(String parentName) {
/* 149 */     this.parentName = parentName;
/*     */   }
/*     */ 
/*     */   public Set<String> getAllParentId() {
/* 153 */     return this.allParentId;
/*     */   }
/*     */ 
/*     */   public void setAllParentId(Set<String> allParentId) {
/* 157 */     this.allParentId = allParentId;
/*     */   }
/*     */ 
/*     */   public String getCityId() {
/* 161 */     return this.cityId;
/*     */   }
/*     */ 
/*     */   public void setCityId(String cityId)
/*     */   {
/* 166 */     this.cityId = cityId;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.User_Company
 * JD-Core Version:    0.6.2
 */
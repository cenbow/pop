/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserDuty;
/*     */ import com.asiainfo.biframe.privilege.cache.service.IdAndName;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.util.SysManageConstants;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class User_Duty
/*     */   implements Serializable, IdAndName, IUserDuty
/*     */ {
/*     */   private int dutyid;
/*  30 */   private int parentid = -1;
/*     */   private String title;
/*     */   private String cityid;
/*     */   private String status;
/*     */   private String deleteTime;
/*     */   private String cityName;
/*     */ 
/*     */   public Object getPrimaryKey()
/*     */   {
/*  43 */     return String.valueOf(this.dutyid);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  47 */     return this.title;
/*     */   }
/*     */ 
/*     */   public int getDutyid()
/*     */   {
/*  55 */     return this.dutyid;
/*     */   }
/*     */ 
/*     */   public int getParentid()
/*     */   {
/*  63 */     return this.parentid;
/*     */   }
/*     */ 
/*     */   public String getTitle()
/*     */   {
/*  70 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setDutyid(int integer)
/*     */   {
/*  77 */     this.dutyid = integer;
/*     */   }
/*     */ 
/*     */   public void setParentid(int integer)
/*     */   {
/*  85 */     this.parentid = integer;
/*     */   }
/*     */ 
/*     */   public void setTitle(String string)
/*     */   {
/*  92 */     this.title = string;
/*     */   }
/*     */ 
/*     */   public String getCityid() {
/*  96 */     return this.cityid;
/*     */   }
/*     */ 
/*     */   public void setCityid(String cityid) {
/* 100 */     this.cityid = cityid;
/*     */   }
/*     */   public String getStatus() {
/* 103 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(String status) {
/* 107 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public Map toMap() {
/* 111 */     Map map = new HashMap();
/* 112 */     Map infoMap = new HashMap();
/*     */ 
/* 114 */     infoMap.put("DUTYID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.duty") + "ID", String.valueOf(getDutyid()));
/* 115 */     infoMap.put("DUTYNAME_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.dutyName") + "", getName());
/* 116 */     infoMap.put("PARENTID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parentDuty") + "ID", String.valueOf(getParentid()));
/* 117 */     infoMap.put("DUTYCITYID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.dutyCity") + "ID", String.valueOf(getCityid()));
/*     */ 
/* 127 */     map.put("USERDUTY", infoMap);
/* 128 */     return map;
/*     */   }
/*     */ 
/*     */   public String getDeleteTime() {
/* 132 */     return this.deleteTime;
/*     */   }
/*     */ 
/*     */   public void setDeleteTime(String deleteTime) {
/* 136 */     this.deleteTime = deleteTime;
/*     */   }
/*     */   public String getStatusDesc() {
/* 139 */     return SysManageConstants.getStatusDesc(this.status);
/*     */   }
/*     */ 
/*     */   public String getCityName() {
/* 143 */     return this.cityName;
/*     */   }
/*     */ 
/*     */   public void setCityName(String cityName) {
/* 147 */     this.cityName = cityName;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.User_Duty
 * JD-Core Version:    0.6.2
 */
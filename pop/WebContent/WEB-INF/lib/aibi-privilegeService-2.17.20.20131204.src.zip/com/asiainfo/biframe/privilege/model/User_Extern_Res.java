/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class User_Extern_Res
/*    */   implements Serializable
/*    */ {
/*    */   private int resid;
/*    */   private int parentId;
/*    */   private String title;
/*    */   private int accesstoken;
/*    */   private String url;
/*    */   private String notes;
/*    */   private String SonReses;
/*    */   private boolean haveSon;
/*    */   private String parentMenuNode;
/*    */   private String target;
/*    */ 
/*    */   public String getPrimaryKey()
/*    */   {
/* 23 */     return String.valueOf(this.resid);
/*    */   }
/*    */ 
/*    */   public void setResid(int resid) {
/* 27 */     this.resid = resid;
/*    */   }
/*    */   public int getParentId() {
/* 30 */     return this.parentId;
/*    */   }
/*    */   public void setParentId(int parentid) {
/* 33 */     this.parentId = parentid;
/*    */   }
/*    */   public String getTitle() {
/* 36 */     return this.title;
/*    */   }
/*    */   public void setTitle(String title) {
/* 39 */     this.title = title;
/*    */   }
/*    */   public int getAccessToken() {
/* 42 */     return this.accesstoken;
/*    */   }
/*    */   public void setAccessToken(int accesstoken) {
/* 45 */     this.accesstoken = accesstoken;
/*    */   }
/*    */   public String getUrl() {
/* 48 */     return this.url;
/*    */   }
/*    */   public void setUrl(String url) {
/* 51 */     this.url = url;
/*    */   }
/*    */   public String getNotes() {
/* 54 */     return this.notes;
/*    */   }
/*    */   public void setNotes(String notes) {
/* 57 */     this.notes = notes;
/*    */   }
/*    */   public String getSons() {
/* 60 */     return this.SonReses;
/*    */   }
/*    */   public void setSons(String sonreses) {
/* 63 */     this.SonReses = sonreses;
/*    */   }
/*    */   public boolean getHaveSon() {
/* 66 */     return this.haveSon;
/*    */   }
/*    */   public void setHaveSon(boolean haveSon) {
/* 69 */     this.haveSon = haveSon;
/*    */   }
/*    */   public String getParentMenuNode() {
/* 72 */     return this.parentMenuNode;
/*    */   }
/*    */   public void setParentMenuNode(String parentMenuNode) {
/* 75 */     this.parentMenuNode = parentMenuNode;
/*    */   }
/*    */   public String getTarget() {
/* 78 */     return this.target;
/*    */   }
/*    */   public void setTarget(String target) {
/* 81 */     this.target = target;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.User_Extern_Res
 * JD-Core Version:    0.6.2
 */
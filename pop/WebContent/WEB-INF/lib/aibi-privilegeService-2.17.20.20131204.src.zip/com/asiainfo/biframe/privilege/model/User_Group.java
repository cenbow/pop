/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserGroup;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.util.SysManageConstants;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class User_Group
/*     */   implements Serializable, IUserGroup
/*     */ {
/*  28 */   private int hashValue = 0;
/*     */   private String groupid;
/*     */   private String groupname;
/*     */   private String parentid;
/*  32 */   private Long status = null;
/*  33 */   private Long userlimit = Long.valueOf(-1L);
/*     */   private String param0;
/*     */   private String param1;
/*     */   private String param2;
/*     */   private String param3;
/*     */   private String param4;
/*     */   private String param5;
/*     */   private String param6;
/*     */   private String param7;
/*     */   private boolean haveSon;
/*  43 */   private int sortnum = 999;
/*     */   private Date createtime;
/*     */   private Date begindate;
/*     */   private Date enddate;
/*     */   private String groupids;
/*     */   private String queryGroupName;
/*     */   private Long queryStatus;
/*  51 */   private Set<String> allParentId = new HashSet();
/*     */   private String deleteTime;
/*     */   private String beginDeleteTime;
/*     */   private String endDeleteTime;
/*     */   private String parentName;
/*     */ 
/*     */   public boolean isHaveSon()
/*     */   {
/*  59 */     return this.haveSon;
/*     */   }
/*     */ 
/*     */   public void setHaveSon(boolean haveSon) {
/*  63 */     this.haveSon = haveSon;
/*     */   }
/*     */ 
/*     */   public String getQueryGroupName() {
/*  67 */     return this.queryGroupName;
/*     */   }
/*     */ 
/*     */   public void setQueryGroupName(String queryGroupName) {
/*  71 */     this.queryGroupName = queryGroupName;
/*     */   }
/*     */ 
/*     */   public String getGroupids() {
/*  75 */     return this.groupids;
/*     */   }
/*     */ 
/*     */   public void setGroupids(String groupids) {
/*  79 */     this.groupids = groupids;
/*     */   }
/*     */ 
/*     */   public String getGroupid()
/*     */   {
/*  88 */     return this.groupid;
/*     */   }
/*     */ 
/*     */   public void setGroupid(String groupid)
/*     */   {
/*  97 */     this.hashValue = 0;
/*  98 */     this.groupid = groupid;
/*     */   }
/*     */ 
/*     */   public String getGroupname()
/*     */   {
/* 107 */     return this.groupname;
/*     */   }
/*     */ 
/*     */   public void setGroupname(String groupname)
/*     */   {
/* 116 */     this.groupname = groupname;
/*     */   }
/*     */ 
/*     */   public String getParentid()
/*     */   {
/* 125 */     return this.parentid;
/*     */   }
/*     */ 
/*     */   public void setParentid(String parentid)
/*     */   {
/* 134 */     this.parentid = parentid;
/*     */   }
/*     */ 
/*     */   public Long getStatus()
/*     */   {
/* 143 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(Long status)
/*     */   {
/* 152 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public Long getUserlimit()
/*     */   {
/* 161 */     return this.userlimit;
/*     */   }
/*     */ 
/*     */   public void setUserlimit(Long userlimit)
/*     */   {
/* 170 */     this.userlimit = userlimit;
/*     */   }
/*     */ 
/*     */   public String getParam0()
/*     */   {
/* 179 */     return this.param0;
/*     */   }
/*     */ 
/*     */   public void setParam0(String param0)
/*     */   {
/* 188 */     this.param0 = param0;
/*     */   }
/*     */ 
/*     */   public String getParam1()
/*     */   {
/* 197 */     return this.param1;
/*     */   }
/*     */ 
/*     */   public void setParam1(String param1)
/*     */   {
/* 206 */     this.param1 = param1;
/*     */   }
/*     */ 
/*     */   public String getParam2()
/*     */   {
/* 215 */     return this.param2;
/*     */   }
/*     */ 
/*     */   public void setParam2(String param2)
/*     */   {
/* 224 */     this.param2 = param2;
/*     */   }
/*     */ 
/*     */   public String getParam3()
/*     */   {
/* 233 */     return this.param3;
/*     */   }
/*     */ 
/*     */   public void setParam3(String param3)
/*     */   {
/* 242 */     this.param3 = param3;
/*     */   }
/*     */ 
/*     */   public String getParam4()
/*     */   {
/* 251 */     return this.param4;
/*     */   }
/*     */ 
/*     */   public void setParam4(String param4)
/*     */   {
/* 260 */     this.param4 = param4;
/*     */   }
/*     */ 
/*     */   public String getParam5()
/*     */   {
/* 269 */     return this.param5;
/*     */   }
/*     */ 
/*     */   public void setParam5(String param5)
/*     */   {
/* 278 */     this.param5 = param5;
/*     */   }
/*     */ 
/*     */   public String getParam6()
/*     */   {
/* 287 */     return this.param6;
/*     */   }
/*     */ 
/*     */   public void setParam6(String param6)
/*     */   {
/* 296 */     this.param6 = param6;
/*     */   }
/*     */ 
/*     */   public String getParam7()
/*     */   {
/* 305 */     return this.param7;
/*     */   }
/*     */ 
/*     */   public void setParam7(String param7)
/*     */   {
/* 314 */     this.param7 = param7;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 320 */     if (!(other instanceof User_Group))
/* 321 */       return false;
/* 322 */     User_Group castOther = (User_Group)other;
/* 323 */     return new EqualsBuilder().append(getGroupid(), castOther.getGroupid()).isEquals();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 328 */     return new HashCodeBuilder().append(getGroupid()).toHashCode();
/*     */   }
/*     */ 
/*     */   public Date getCreatetime() {
/* 332 */     return this.createtime;
/*     */   }
/*     */ 
/*     */   public void setCreatetime(Date createtime) {
/* 336 */     this.createtime = createtime;
/*     */   }
/*     */ 
/*     */   public Date getEnddate() {
/* 340 */     return this.enddate;
/*     */   }
/*     */ 
/*     */   public void setEnddate(Date enddate) {
/* 344 */     this.enddate = enddate;
/*     */   }
/*     */ 
/*     */   public Date getBegindate() {
/* 348 */     return this.begindate;
/*     */   }
/*     */ 
/*     */   public void setBegindate(Date begindate) {
/* 352 */     this.begindate = begindate;
/*     */   }
/*     */ 
/*     */   public Long getQueryStatus() {
/* 356 */     return this.queryStatus;
/*     */   }
/*     */ 
/*     */   public void setQueryStatus(Long queryStatus) {
/* 360 */     this.queryStatus = queryStatus;
/*     */   }
/*     */ 
/*     */   public Map toMap()
/*     */   {
/* 381 */     Map map = new HashMap();
/* 382 */     Map infoMap = new HashMap();
/*     */ 
/* 384 */     infoMap.put("GROUPID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userGroup") + "", getGroupid());
/* 385 */     infoMap.put("GROUPNAME_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupName") + "", getGroupname());
/* 386 */     infoMap.put("STATUS_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupState") + "", String.valueOf(getStatus()));
/*     */ 
/* 389 */     infoMap.put("CREATETIME_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupCreateTime") + "", getCreatetime());
/*     */ 
/* 392 */     map.put("USER_GROUP", infoMap);
/* 393 */     return map;
/*     */   }
/*     */ 
/*     */   public int getSortnum()
/*     */   {
/* 400 */     return this.sortnum;
/*     */   }
/*     */ 
/*     */   public void setSortnum(int sortnum)
/*     */   {
/* 407 */     this.sortnum = sortnum;
/*     */   }
/*     */ 
/*     */   public Set<String> getAllParentId() {
/* 411 */     return this.allParentId;
/*     */   }
/*     */ 
/*     */   public void setAllParentId(Set<String> allParentId) {
/* 415 */     this.allParentId = allParentId;
/*     */   }
/*     */ 
/*     */   public String getDeleteTime() {
/* 419 */     return this.deleteTime;
/*     */   }
/*     */ 
/*     */   public void setDeleteTime(String deleteTime) {
/* 423 */     this.deleteTime = deleteTime;
/*     */   }
/*     */ 
/*     */   public String getBeginDeleteTime() {
/* 427 */     return this.beginDeleteTime;
/*     */   }
/*     */ 
/*     */   public void setBeginDeleteTime(String beginDeleteTime) {
/* 431 */     this.beginDeleteTime = beginDeleteTime;
/*     */   }
/*     */ 
/*     */   public String getEndDeleteTime() {
/* 435 */     return this.endDeleteTime;
/*     */   }
/*     */ 
/*     */   public void setEndDeleteTime(String endDeleteTime) {
/* 439 */     this.endDeleteTime = endDeleteTime;
/*     */   }
/*     */ 
/*     */   public String getStatusDesc() {
/* 443 */     return SysManageConstants.getStatusDesc(String.valueOf(this.status));
/*     */   }
/*     */ 
/*     */   public String getParentName() {
/* 447 */     return this.parentName;
/*     */   }
/*     */ 
/*     */   public void setParentName(String parentName) {
/* 451 */     this.parentName = parentName;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.User_Group
 * JD-Core Version:    0.6.2
 */
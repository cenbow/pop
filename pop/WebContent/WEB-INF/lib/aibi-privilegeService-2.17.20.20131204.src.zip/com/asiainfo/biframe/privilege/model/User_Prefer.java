/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class User_Prefer
/*    */   implements Serializable
/*    */ {
/*    */   private User_PreferId id;
/*    */   private String preferValue;
/*    */   private String preferValuedesc;
/*    */   private String notes;
/*    */ 
/*    */   public User_Prefer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public User_Prefer(User_PreferId id)
/*    */   {
/* 30 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public User_PreferId getId()
/*    */   {
/* 37 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(User_PreferId id) {
/* 41 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getNotes()
/*    */   {
/* 46 */     return this.notes;
/*    */   }
/*    */ 
/*    */   public void setNotes(String notes)
/*    */   {
/* 51 */     this.notes = notes;
/*    */   }
/*    */ 
/*    */   public String getPreferValue()
/*    */   {
/* 56 */     return this.preferValue;
/*    */   }
/*    */ 
/*    */   public void setPreferValue(String preferValue)
/*    */   {
/* 61 */     this.preferValue = preferValue;
/*    */   }
/*    */ 
/*    */   public String getPreferValuedesc()
/*    */   {
/* 66 */     return this.preferValuedesc;
/*    */   }
/*    */ 
/*    */   public void setPreferValuedesc(String preferValuedesc)
/*    */   {
/* 71 */     this.preferValuedesc = preferValuedesc;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.User_Prefer
 * JD-Core Version:    0.6.2
 */
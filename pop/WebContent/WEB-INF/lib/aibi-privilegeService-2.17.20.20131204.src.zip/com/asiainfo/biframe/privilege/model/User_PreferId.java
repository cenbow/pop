/*    */ package com.asiainfo.biframe.privilege.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class User_PreferId
/*    */   implements Serializable
/*    */ {
/*    */   private String userId;
/*    */   private String preferId;
/*    */ 
/*    */   public User_PreferId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public User_PreferId(String userId, String preferId)
/*    */   {
/* 30 */     this.userId = userId;
/* 31 */     this.preferId = preferId;
/*    */   }
/*    */ 
/*    */   public String getUserId()
/*    */   {
/* 38 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public void setUserId(String userId) {
/* 42 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   public String getPreferId() {
/* 46 */     return this.preferId;
/*    */   }
/*    */ 
/*    */   public void setPreferId(String preferId) {
/* 50 */     this.preferId = preferId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 60 */     if (this == other) return true;
/* 61 */     if (other == null) return false;
/* 62 */     if (!(other instanceof User_PreferId)) return false;
/* 63 */     User_PreferId castOther = (User_PreferId)other;
/*    */ 
/* 65 */     return ((getUserId() == castOther.getUserId()) || ((getUserId() != null) && (castOther.getUserId() != null) && (getUserId().equals(castOther.getUserId())))) && ((getPreferId() == castOther.getPreferId()) || ((getPreferId() != null) && (castOther.getPreferId() != null) && (getPreferId().equals(castOther.getPreferId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 71 */     int result = 17;
/*    */ 
/* 73 */     result = 37 * result + (getUserId() == null ? 0 : getUserId().hashCode());
/* 74 */     result = 37 * result + (getPreferId() == null ? 0 : getPreferId().hashCode());
/*    */ 
/* 76 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.User_PreferId
 * JD-Core Version:    0.6.2
 */
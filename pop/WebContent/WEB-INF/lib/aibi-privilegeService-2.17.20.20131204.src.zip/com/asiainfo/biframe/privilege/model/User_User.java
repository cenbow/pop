/*     */ package com.asiainfo.biframe.privilege.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.cache.service.IdAndName;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.constants.UserConstants;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class User_User
/*     */   implements Serializable, IdAndName, IUser
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String userid;
/*     */   private String cityid;
/*     */   private Integer dutyid;
/*     */   private String sex;
/*     */   private String age;
/*     */   private String address;
/*     */   private String postalcode;
/*     */   private String nation;
/*     */   private String passportNo;
/*     */   private String director;
/*     */   private int departmentid;
/*     */   private String username;
/*     */   private String pwd;
/*     */   private String desPwd;
/*     */   private int status;
/*     */   private Date begindate;
/*     */   private Date enddate;
/*     */   private Date createtime;
/*     */   private Date birthday;
/*     */   private String mobilephone;
/*     */   private String mobilephone1;
/*     */   private String mobilephone2;
/*     */   private String homephone;
/*     */   private String officephone;
/*     */   private String officefax;
/*     */   private String email;
/*     */   private String email1;
/*     */   private String email2;
/*     */   private String notes;
/*     */   private UserUserExt ext;
/*     */   private String groupName;
/*     */   private String depName;
/*     */   private String cityName;
/*     */   private String dutyName;
/*     */   private String roleNames;
/*     */   private String groupId;
/*     */   private String deleteTime;
/*  71 */   private String sensitiveDataLevel = "D";
/*     */   private String domainType;
/*     */   List<String> roleidList;
/*     */ 
/*     */   public String getCityName()
/*     */   {
/*  82 */     return this.cityName;
/*     */   }
/*     */ 
/*     */   public void setCityName(String cityName)
/*     */   {
/*  89 */     this.cityName = cityName;
/*     */   }
/*     */ 
/*     */   public String getDepName()
/*     */   {
/*  96 */     return this.depName;
/*     */   }
/*     */ 
/*     */   public void setDepName(String depName)
/*     */   {
/* 103 */     this.depName = depName;
/*     */   }
/*     */ 
/*     */   public String getDutyName()
/*     */   {
/* 110 */     return this.dutyName;
/*     */   }
/*     */ 
/*     */   public void setDutyName(String dutyName)
/*     */   {
/* 117 */     this.dutyName = dutyName;
/*     */   }
/*     */ 
/*     */   public String getGroupName()
/*     */   {
/* 124 */     return this.groupName;
/*     */   }
/*     */ 
/*     */   public void setGroupName(String groupName)
/*     */   {
/* 131 */     this.groupName = groupName;
/*     */   }
/*     */ 
/*     */   public String getRoleNames()
/*     */   {
/* 138 */     return this.roleNames;
/*     */   }
/*     */ 
/*     */   public void setRoleNames(String roleNames)
/*     */   {
/* 145 */     this.roleNames = roleNames;
/*     */   }
/*     */ 
/*     */   public UserUserExt getExt() {
/* 149 */     return this.ext;
/*     */   }
/*     */ 
/*     */   public void setExt(UserUserExt ext) {
/* 153 */     this.ext = ext;
/*     */   }
/*     */ 
/*     */   public User_User()
/*     */   {
/*     */   }
/*     */ 
/*     */   public User_User(String userId) {
/* 161 */     this.userid = userId;
/*     */   }
/*     */ 
/*     */   public User_User(String userId, String cityid, int dutyid, String sex, String age, String address, String postalcode, String nation, String passportNo, String director, String username, String pwd, int status, Date createtime)
/*     */   {
/* 169 */     this.userid = userId;
/* 170 */     this.cityid = cityid;
/*     */ 
/* 172 */     this.dutyid = new Integer(dutyid);
/* 173 */     this.sex = sex;
/* 174 */     this.age = age;
/* 175 */     this.address = address;
/* 176 */     this.postalcode = postalcode;
/* 177 */     this.nation = nation;
/* 178 */     this.passportNo = passportNo;
/* 179 */     this.director = director;
/* 180 */     this.username = username;
/* 181 */     this.pwd = pwd;
/* 182 */     this.status = status;
/* 183 */     this.createtime = createtime;
/*     */   }
/*     */ 
/*     */   public User_User(String userId, String cityid, int dutyid, String sex, String age, String address, String postalcode, String nation, String passportNo, String director, int departmentid, String username, String pwd, int status, Date begindate, Date enddate, Date createtime, Date birthday, String mobilephone, String mobilephone1, String mobilephone2, String homephone, String officephone, String officefax, String email, String email1, String email2, String notes)
/*     */   {
/* 189 */     this.userid = userId;
/* 190 */     this.cityid = cityid;
/*     */ 
/* 192 */     this.dutyid = new Integer(dutyid);
/* 193 */     this.sex = sex;
/* 194 */     this.age = age;
/* 195 */     this.address = address;
/* 196 */     this.postalcode = postalcode;
/* 197 */     this.nation = nation;
/* 198 */     this.passportNo = passportNo;
/* 199 */     this.director = director;
/* 200 */     this.departmentid = departmentid;
/* 201 */     this.username = username;
/* 202 */     this.pwd = pwd;
/* 203 */     this.status = status;
/* 204 */     this.begindate = begindate;
/* 205 */     this.enddate = enddate;
/* 206 */     this.createtime = createtime;
/* 207 */     this.birthday = birthday;
/* 208 */     this.mobilephone = mobilephone;
/* 209 */     this.mobilephone1 = mobilephone1;
/* 210 */     this.mobilephone2 = mobilephone2;
/* 211 */     this.homephone = homephone;
/* 212 */     this.officephone = officephone;
/* 213 */     this.officefax = officefax;
/* 214 */     this.email = email;
/* 215 */     this.email1 = email1;
/* 216 */     this.email2 = email2;
/* 217 */     this.notes = notes;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 225 */     return this.username;
/*     */   }
/*     */ 
/*     */   public String getUserid() {
/* 229 */     return this.userid;
/*     */   }
/*     */ 
/*     */   public void setUserid(String userId) {
/* 233 */     this.userid = userId;
/*     */   }
/*     */ 
/*     */   public String getCityid() {
/* 237 */     return this.cityid;
/*     */   }
/*     */ 
/*     */   public void setCityid(String cityid) {
/* 241 */     this.cityid = cityid;
/*     */   }
/*     */ 
/*     */   public int getDepartmentid() {
/* 245 */     return this.departmentid;
/*     */   }
/*     */ 
/*     */   public void setDepartmentid(int departmentid) {
/* 249 */     this.departmentid = departmentid;
/*     */   }
/*     */ 
/*     */   public String getUsername() {
/* 253 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username) {
/* 257 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public String getPwd() {
/* 261 */     return this.pwd;
/*     */   }
/*     */ 
/*     */   public void setPwd(String pwd) {
/* 265 */     this.pwd = pwd;
/*     */   }
/*     */ 
/*     */   public int getStatus() {
/* 269 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(int status) {
/* 273 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public Date getBegindate() {
/* 277 */     return this.begindate;
/*     */   }
/*     */ 
/*     */   public void setBegindate(Date begindate) {
/* 281 */     this.begindate = begindate;
/*     */   }
/*     */ 
/*     */   public Date getEnddate() {
/* 285 */     return this.enddate;
/*     */   }
/*     */ 
/*     */   public void setEnddate(Date enddate) {
/* 289 */     this.enddate = enddate;
/*     */   }
/*     */ 
/*     */   public Date getCreatetime() {
/* 293 */     return this.createtime;
/*     */   }
/*     */ 
/*     */   public void setCreatetime(Date createtime) {
/* 297 */     this.createtime = createtime;
/*     */   }
/*     */ 
/*     */   public Date getBirthday() {
/* 301 */     return this.birthday;
/*     */   }
/*     */ 
/*     */   public void setBirthday(Date birthday) {
/* 305 */     this.birthday = birthday;
/*     */   }
/*     */ 
/*     */   public String getMobilephone() {
/* 309 */     return this.mobilephone;
/*     */   }
/*     */ 
/*     */   public void setMobilephone(String mobilephone) {
/* 313 */     this.mobilephone = mobilephone;
/*     */   }
/*     */ 
/*     */   public String getMobilephone1() {
/* 317 */     return this.mobilephone1;
/*     */   }
/*     */ 
/*     */   public void setMobilephone1(String mobilephone1) {
/* 321 */     this.mobilephone1 = mobilephone1;
/*     */   }
/*     */ 
/*     */   public String getMobilephone2() {
/* 325 */     return this.mobilephone2;
/*     */   }
/*     */ 
/*     */   public void setMobilephone2(String mobilephone2) {
/* 329 */     this.mobilephone2 = mobilephone2;
/*     */   }
/*     */ 
/*     */   public String getHomephone() {
/* 333 */     return this.homephone;
/*     */   }
/*     */ 
/*     */   public void setHomephone(String homephone) {
/* 337 */     this.homephone = homephone;
/*     */   }
/*     */ 
/*     */   public String getOfficephone() {
/* 341 */     return this.officephone;
/*     */   }
/*     */ 
/*     */   public void setOfficephone(String officephone) {
/* 345 */     this.officephone = officephone;
/*     */   }
/*     */ 
/*     */   public String getOfficefax() {
/* 349 */     return this.officefax;
/*     */   }
/*     */ 
/*     */   public void setOfficefax(String officefax) {
/* 353 */     this.officefax = officefax;
/*     */   }
/*     */ 
/*     */   public String getEmail() {
/* 357 */     return this.email;
/*     */   }
/*     */ 
/*     */   public void setEmail(String email) {
/* 361 */     this.email = email;
/*     */   }
/*     */ 
/*     */   public String getEmail1() {
/* 365 */     return this.email1;
/*     */   }
/*     */ 
/*     */   public void setEmail1(String email1) {
/* 369 */     this.email1 = email1;
/*     */   }
/*     */ 
/*     */   public String getEmail2() {
/* 373 */     return this.email2;
/*     */   }
/*     */ 
/*     */   public void setEmail2(String email2) {
/* 377 */     this.email2 = email2;
/*     */   }
/*     */ 
/*     */   public String getNotes() {
/* 381 */     return this.notes;
/*     */   }
/*     */ 
/*     */   public void setNotes(String notes) {
/* 385 */     this.notes = notes;
/*     */   }
/*     */ 
/*     */   public String getGroupId()
/*     */   {
/* 392 */     return this.groupId;
/*     */   }
/*     */ 
/*     */   public void setGroupId(String groupId) {
/* 396 */     this.groupId = groupId;
/*     */   }
/*     */ 
/*     */   public Object getPrimaryKey() {
/* 400 */     return getUserid();
/*     */   }
/*     */ 
/*     */   public String getEMail() {
/* 404 */     return getEmail();
/*     */   }
/*     */ 
/*     */   public String getMobilePhone() {
/* 408 */     return getMobilephone();
/*     */   }
/*     */ 
/*     */   public String getPassword() {
/* 412 */     return getPwd();
/*     */   }
/*     */ 
/*     */   public void setEMail(String email)
/*     */   {
/* 417 */     setEmail(email);
/*     */   }
/*     */ 
/*     */   public void setMobilePhone(String mobilephome) {
/* 421 */     setMobilephone(mobilephome);
/*     */   }
/*     */ 
/*     */   public void setPassword(String pwd) {
/* 425 */     setPwd(pwd);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 431 */     return "[userid=" + getUserid() + "][username=" + getUsername() + "]" + "[cityid=" + getCityid() + "][departmentid=" + getDepartmentid() + "]" + "[dutyid=" + getDutyid() + "]" + "[sex=" + getSex() + "]" + "[age=" + getAge() + "]" + "[address=" + getAddress() + "]" + "[postalcode=" + getPostalcode() + "]" + "[nation=" + getNation() + "]" + "[passportNo=" + getPassportNo() + "]" + "[director=" + getDirector() + "]" + "[username=" + getUsername() + "][pwd=" + getPwd() + "]" + "[status=" + getStatus() + "][begindate=" + getBegindate() + "]" + "[enddate=" + getEnddate() + "][createtime=" + getCreatetime() + "]" + "[birthday=" + getBirthday() + "][mobilephone=" + getMobilephone() + "]" + "[mobilephone1=" + getMobilephone1() + "][mobilephone2=" + getMobilephone2() + "]" + "[homephone=" + getHomephone() + "][officephone=" + getOfficephone() + "]" + "[officefax=" + getOfficefax() + "][email=" + getEmail() + "]" + "[email1=" + getEmail1() + "][email2=" + getEmail2() + "]" + "[notes=" + getNotes() + "][domainType=" + getDomainType() + "]";
/*     */   }
/*     */ 
/*     */   public Map<String, Map<String, String>> toMap()
/*     */   {
/* 456 */     Map map = new HashMap();
/* 457 */     Map infoMap = new HashMap();
/*     */ 
/* 459 */     infoMap.put("USERID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userid") + "", getUserid());
/* 460 */     infoMap.put("CITYID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cityid") + "id", getCityid());
/*     */ 
/* 462 */     infoMap.put("DUTYID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.dutyid") + "id", getDutyid());
/* 463 */     infoMap.put("sex_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.sex") + "", getSex());
/* 464 */     infoMap.put("age_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.age") + "", getAge());
/* 465 */     infoMap.put("address_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.address") + "", getAddress());
/* 466 */     infoMap.put("postalcode_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.postalCode") + "", getPostalcode());
/* 467 */     infoMap.put("nation_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.nation") + "", getNation());
/* 468 */     infoMap.put("passportNo_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.passportNo") + "", getPassportNo());
/* 469 */     infoMap.put("director_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.director") + "", getDirector());
/*     */ 
/* 471 */     infoMap.put("DEPARTMENTID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.departmentId") + "id", String.valueOf(getDepartmentid()));
/* 472 */     infoMap.put("USERNAME_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userName") + "", getUsername());
/* 473 */     infoMap.put("PWD_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.pwd") + "", getPwd());
/* 474 */     infoMap.put("STATUS_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.status") + "", String.valueOf(getStatus()));
/*     */ 
/* 477 */     infoMap.put("CREATETIME_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.createTime") + "", getCreatetime());
/* 478 */     infoMap.put("BIRTHDAY_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.birthday") + "", getBirthday());
/* 479 */     infoMap.put("MOBILEPHONE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.mobilePhone"), getMobilephone());
/*     */ 
/* 482 */     infoMap.put("HOMEPHONE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.homePhone"), getHomephone());
/* 483 */     infoMap.put("OFFICEPHONE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.officePhone"), getOfficephone());
/* 484 */     infoMap.put("OFFICEFAX_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.officeFax"), getOfficefax());
/* 485 */     infoMap.put("EMAIL_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.email") + "", getEmail());
/*     */ 
/* 488 */     infoMap.put("NOTES_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.notes") + "", getNotes());
/*     */ 
/* 490 */     map.put("USER_USER", infoMap);
/* 491 */     return map;
/*     */   }
/*     */ 
/*     */   public String getDesPwd()
/*     */   {
/* 498 */     return this.desPwd;
/*     */   }
/*     */ 
/*     */   public void setDesPwd(String desPwd)
/*     */   {
/* 505 */     this.desPwd = desPwd;
/*     */   }
/*     */ 
/*     */   public Integer getDutyid() {
/* 509 */     return this.dutyid;
/*     */   }
/*     */ 
/*     */   public void setDutyid(Integer dutyid) {
/* 513 */     this.dutyid = dutyid;
/*     */   }
/*     */ 
/*     */   public String getSex() {
/* 517 */     return this.sex;
/*     */   }
/*     */ 
/*     */   public void setSex(String sex) {
/* 521 */     this.sex = sex;
/*     */   }
/*     */   public String getAge() {
/* 524 */     return this.age;
/*     */   }
/*     */ 
/*     */   public void setAge(String age) {
/* 528 */     this.age = age;
/*     */   }
/*     */   public String getAddress() {
/* 531 */     return this.address;
/*     */   }
/*     */ 
/*     */   public void setAddress(String address) {
/* 535 */     this.address = address;
/*     */   }
/*     */   public String getPostalcode() {
/* 538 */     return this.postalcode;
/*     */   }
/*     */ 
/*     */   public void setPostalcode(String postalcode) {
/* 542 */     this.postalcode = postalcode;
/*     */   }
/*     */   public String getNation() {
/* 545 */     return this.nation;
/*     */   }
/*     */ 
/*     */   public void setNation(String nation) {
/* 549 */     this.nation = nation;
/*     */   }
/*     */   public String getPassportNo() {
/* 552 */     return this.passportNo;
/*     */   }
/*     */ 
/*     */   public void setPassportNo(String passportNo) {
/* 556 */     this.passportNo = passportNo;
/*     */   }
/*     */   public String getDirector() {
/* 559 */     return this.director;
/*     */   }
/*     */ 
/*     */   public void setDirector(String director) {
/* 563 */     this.director = director;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 569 */     if (!(other instanceof User_User))
/* 570 */       return false;
/* 571 */     User_User castOther = (User_User)other;
/* 572 */     return new EqualsBuilder().append(getUserid(), castOther.getUserid()).isEquals();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 577 */     return new HashCodeBuilder().append(getUserid()).toHashCode();
/*     */   }
/*     */ 
/*     */   public String getDeleteTime() {
/* 581 */     return this.deleteTime;
/*     */   }
/*     */ 
/*     */   public void setDeleteTime(String deleteTime) {
/* 585 */     this.deleteTime = deleteTime;
/*     */   }
/*     */ 
/*     */   public String getStatusDesc() {
/* 589 */     return UserConstants.getStatusDesc(String.valueOf(this.status));
/*     */   }
/*     */ 
/*     */   public String getSensitiveDataLevel() {
/* 593 */     return this.sensitiveDataLevel;
/*     */   }
/*     */ 
/*     */   public void setSensitiveDataLevel(String sensitiveDataLevel) {
/* 597 */     this.sensitiveDataLevel = sensitiveDataLevel;
/*     */   }
/*     */ 
/*     */   public String getLoginId()
/*     */   {
/* 602 */     return getUserid();
/*     */   }
/*     */ 
/*     */   public String getDomainType() {
/* 606 */     return this.domainType;
/*     */   }
/*     */ 
/*     */   public void setDomainType(String domainType) {
/* 610 */     this.domainType = domainType;
/*     */   }
/*     */ 
/*     */   public List<String> getRoleidList() {
/* 614 */     return this.roleidList;
/*     */   }
/*     */ 
/*     */   public void setRoleidList(List<String> roleidList) {
/* 618 */     this.roleidList = roleidList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.model.User_User
 * JD-Core Version:    0.6.2
 */
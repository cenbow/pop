package com.asiainfo.biframe.privilege.othersysmanage.service;

import com.asiainfo.biframe.privilege.model.UserSysMap;
import java.util.Collection;
import java.util.Map;

public abstract interface IUserSysMapService
{
  public abstract Collection<UserSysMap> getAllOtherUsers();

  public abstract Map getPagedOtherUsers(UserSysMap paramUserSysMap, int paramInt1, int paramInt2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.othersysmanage.service.IUserSysMapService
 * JD-Core Version:    0.6.2
 */
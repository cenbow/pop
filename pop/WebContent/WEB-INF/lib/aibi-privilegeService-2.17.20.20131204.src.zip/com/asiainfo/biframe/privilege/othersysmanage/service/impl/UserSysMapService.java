/*    */ package com.asiainfo.biframe.privilege.othersysmanage.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.UserSysMap;
/*    */ import com.asiainfo.biframe.privilege.othersysmanage.service.IUserSysMapService;
/*    */ import com.asiainfo.biframe.privilege.uniauth.dao.IUserSysMapDao;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class UserSysMapService
/*    */   implements IUserSysMapService
/*    */ {
/* 21 */   private static Logger log = Logger.getLogger(UserSysMapService.class);
/*    */   private IUserSysMapDao userSysMapDao;
/*    */ 
/*    */   public Collection<UserSysMap> getAllOtherUsers()
/*    */   {
/* 29 */     log.debug("in getAllOtherUsers");
/* 30 */     Collection otherUsers = getUserSysMapDao().getAllOtherUsers();
/* 31 */     log.debug("end getAllOtherUsers");
/* 32 */     return otherUsers;
/*    */   }
/*    */ 
/*    */   public Map getPagedOtherUsers(UserSysMap otherUser, int currPage, int pageSize)
/*    */   {
/* 38 */     return getUserSysMapDao().getPagedOtherUsers(otherUser, currPage, pageSize);
/*    */   }
/*    */ 
/*    */   public IUserSysMapDao getUserSysMapDao()
/*    */   {
/* 43 */     return this.userSysMapDao;
/*    */   }
/*    */ 
/*    */   public void setUserSysMapDao(IUserSysMapDao userSysMapDao)
/*    */   {
/* 48 */     this.userSysMapDao = userSysMapDao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.othersysmanage.service.impl.UserSysMapService
 * JD-Core Version:    0.6.2
 */
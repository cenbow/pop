/*     */ package com.asiainfo.biframe.privilege.pwdpolicy.dao;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.pwdpolicy.model.PwdPolicyInfo;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public final class PwdPolicyDAO
/*     */ {
/*  22 */   private static Logger logger = Logger.getLogger(PwdPolicyDAO.class);
/*     */ 
/*     */   public final int savePwdPolicy(PwdPolicyInfo policyInfo)
/*     */     throws Exception
/*     */   {
/*  32 */     System.out.println("in pwdDAO......");
/*  33 */     if (null == policyInfo) {
/*  34 */       logger.warn("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.inputPolidy") + "null.");
/*  35 */       return -1;
/*     */     }
/*  37 */     int result = -1;
/*  38 */     Sqlca sqlca = null;
/*  39 */     Sqlca sqlcaUpdate = null;
/*  40 */     StringBuffer findSQL = new StringBuffer("");
/*  41 */     StringBuffer updateSQL = new StringBuffer("");
/*     */     try {
/*  43 */       sqlca = new Sqlca(new ConnectionEx());
/*  44 */       sqlcaUpdate = new Sqlca(new ConnectionEx());
/*     */     } catch (Exception e) {
/*  46 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.connectDbFail") + ":" + e.toString());
/*  47 */       if (null != sqlca) {
/*  48 */         sqlca.closeAll();
/*  49 */         sqlca = null;
/*     */       }
/*  51 */       if (null != sqlcaUpdate) {
/*  52 */         sqlcaUpdate.closeAll();
/*  53 */         sqlcaUpdate = null;
/*     */       }
/*  55 */       e.printStackTrace();
/*  56 */       return -1;
/*     */     }
/*  58 */     if (null == policyInfo.getExcludeChars()) {
/*  59 */       policyInfo.setExcludeChars("");
/*     */     }
/*  61 */     if (policyInfo.getLoginRetryCount() == 0) {
/*  62 */       policyInfo.setLoginRetryCount(5);
/*     */     }
/*  64 */     if ((null != sqlca) && (null != sqlcaUpdate)) {
/*     */       try {
/*  66 */         sqlcaUpdate.setAutoCommit(false);
/*     */ 
/*  68 */         findSQL.append("select * from user_pwd_policy");
/*  69 */         sqlca.execute(findSQL.toString());
/*  70 */         if (sqlca.next()) {
/*  71 */           updateSQL.append("update user_pwd_policy set upper_case=" + policyInfo.getUpperCase() + ",");
/*     */ 
/*  73 */           updateSQL.append("lower_case=" + policyInfo.getLowerCase() + ",");
/*     */ 
/*  75 */           updateSQL.append("number_case=" + policyInfo.getNumberCase() + ",");
/*     */ 
/*  77 */           updateSQL.append("special_case = " + policyInfo.getSpecialCase() + ",");
/*     */ 
/*  79 */           updateSQL.append("min_len = " + policyInfo.getPwdMinLen() + ",");
/*     */ 
/*  81 */           updateSQL.append("max_len = " + policyInfo.getPwdMaxLen() + ",");
/*     */ 
/*  83 */           updateSQL.append("expire_days =" + policyInfo.getExpireDays() + ",");
/*     */ 
/*  85 */           updateSQL.append("ahead_days =" + policyInfo.getAheadDays() + ",");
/*     */ 
/*  88 */           updateSQL.append(" login_retry_count = " + policyInfo.getLoginRetryCount() + ",");
/*  89 */           updateSQL.append("pwd_mature_remind=" + policyInfo.getPwdMatureRemind() + ",");
/*     */ 
/*  91 */           updateSQL.append(" exclude_chars = '" + policyInfo.getExcludeChars() + "'");
/*     */ 
/*  93 */           logger.debug("update user_pwd_policy:" + updateSQL.toString());
/*     */ 
/*  95 */           System.out.println("******update user_pwd_policy:" + updateSQL.toString());
/*     */ 
/*  97 */           result = sqlcaUpdate.execute(updateSQL.toString());
/*     */         } else {
/*  99 */           updateSQL.append("insert into user_pwd_policy(upper_case,lower_case,number_case,special_case,min_len,max_len,expire_days,ahead_days,login_retry_count,pwd_mature_remind,exclude_chars) ");
/*     */ 
/* 101 */           updateSQL.append(" values(" + policyInfo.getUpperCase() + ",");
/*     */ 
/* 103 */           updateSQL.append(policyInfo.getLowerCase() + ",");
/* 104 */           updateSQL.append(policyInfo.getNumberCase() + ",");
/* 105 */           updateSQL.append(policyInfo.getSpecialCase() + ",");
/* 106 */           updateSQL.append(policyInfo.getPwdMinLen() + ",");
/* 107 */           updateSQL.append(policyInfo.getPwdMaxLen() + ",");
/* 108 */           updateSQL.append(policyInfo.getExpireDays() + ",");
/* 109 */           updateSQL.append(policyInfo.getAheadDays() + ",");
/* 110 */           updateSQL.append(policyInfo.getLoginRetryCount() + ",");
/* 111 */           updateSQL.append(policyInfo.getPwdMatureRemind() + ",");
/* 112 */           updateSQL.append("'" + policyInfo.getExcludeChars() + "')");
/*     */ 
/* 114 */           logger.debug("insert user_pwd_policy:" + updateSQL.toString());
/*     */ 
/* 117 */           result = sqlcaUpdate.execute(updateSQL.toString());
/* 118 */           logger.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.savePolicy") + ":" + result);
/*     */         }
/*     */ 
/* 124 */         sqlcaUpdate.commit();
/*     */ 
/* 132 */         if (null != sqlca) {
/* 133 */           sqlca.closeAll();
/* 134 */           sqlca = null;
/*     */         }
/* 136 */         if (null != sqlcaUpdate) {
/* 137 */           sqlcaUpdate.closeAll();
/* 138 */           sqlcaUpdate = null;
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 126 */         if (null != sqlcaUpdate) {
/* 127 */           sqlcaUpdate.rollback();
/*     */         }
/*     */ 
/* 130 */         throw e;
/*     */       } finally {
/* 132 */         if (null != sqlca) {
/* 133 */           sqlca.closeAll();
/* 134 */           sqlca = null;
/*     */         }
/* 136 */         if (null != sqlcaUpdate) {
/* 137 */           sqlcaUpdate.closeAll();
/* 138 */           sqlcaUpdate = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 143 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getConnection") + "null.");
/* 144 */       return -1;
/*     */     }
/* 146 */     findSQL = null;
/* 147 */     updateSQL = null;
/* 148 */     return result;
/*     */   }
/*     */ 
/*     */   public final PwdPolicyInfo loadPwdPolicy()
/*     */   {
/* 157 */     PwdPolicyInfo policyInfo = null;
/* 158 */     Sqlca sqlca = null;
/* 159 */     StringBuffer findSQL = new StringBuffer("");
/*     */     try
/*     */     {
/* 162 */       sqlca = new Sqlca(new ConnectionEx());
/*     */     }
/*     */     catch (Exception e) {
/* 165 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.connectDbFail") + ":" + e);
/* 166 */       return null;
/*     */     }
/* 168 */     if (null != sqlca) {
/* 169 */       findSQL.append("select upper_case,lower_case,number_case,special_case,min_len,max_len,expire_days,ahead_days,login_retry_count,exclude_chars,pwd_mature_remind ");
/*     */ 
/* 171 */       findSQL.append(" from user_pwd_policy");
/*     */       try {
/* 173 */         sqlca.execute(findSQL.toString());
/* 174 */         if (sqlca.next()) {
/* 175 */           policyInfo = new PwdPolicyInfo();
/* 176 */           policyInfo.setUpperCase(sqlca.getInt("upper_case"));
/* 177 */           policyInfo.setLowerCase(sqlca.getInt("lower_case"));
/* 178 */           policyInfo.setNumberCase(sqlca.getInt("number_case"));
/* 179 */           policyInfo.setSpecialCase(sqlca.getInt("special_case"));
/* 180 */           policyInfo.setPwdMinLen(sqlca.getInt("min_len"));
/* 181 */           policyInfo.setPwdMaxLen(sqlca.getInt("max_len"));
/* 182 */           policyInfo.setExpireDays(sqlca.getInt("expire_days"));
/* 183 */           policyInfo.setAheadDays(sqlca.getInt("ahead_days"));
/* 184 */           policyInfo.setLoginRetryCount(sqlca.getInt("login_retry_count"));
/* 185 */           policyInfo.setExcludeChars(sqlca.getString("exclude_chars"));
/* 186 */           policyInfo.setPwdMatureRemind(sqlca.getInt("pwd_mature_remind"));
/*     */         }
/*     */ 
/* 192 */         if (null != sqlca) {
/* 193 */           sqlca.closeAll();
/* 194 */           sqlca = null;
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 189 */         logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryPolicyFail") + ":" + e);
/* 190 */         policyInfo = null;
/*     */ 
/* 192 */         if (null != sqlca) {
/* 193 */           sqlca.closeAll();
/* 194 */           sqlca = null;
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 192 */         if (null != sqlca) {
/* 193 */           sqlca.closeAll();
/* 194 */           sqlca = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 199 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getConnection") + "null.");
/* 200 */       return null;
/*     */     }
/* 202 */     findSQL = null;
/* 203 */     return policyInfo;
/*     */   }
/*     */ 
/*     */   private String getHistorySQL(String userID, String commonHistorySQL, Sqlca sqlca)
/*     */     throws Exception
/*     */   {
/* 216 */     StringBuffer allHistorySQL = new StringBuffer();
/*     */ 
/* 218 */     if (sqlca.getDBMSType().equalsIgnoreCase("ORACLE")) {
/* 219 */       allHistorySQL.append("select * from ( ");
/* 220 */       allHistorySQL.append(commonHistorySQL);
/* 221 */       allHistorySQL.append(" where user_id='" + userID + "' order by user_pwd_date desc");
/* 222 */       allHistorySQL.append(" ) where rownum <= 5");
/* 223 */     } else if (sqlca.getDBMSType().equalsIgnoreCase("DB2")) {
/* 224 */       allHistorySQL.append(commonHistorySQL);
/* 225 */       allHistorySQL.append(" where user_id='" + userID + "'  order by user_pwd_date desc fetch first 5 rows only");
/* 226 */     } else if (sqlca.getDBMSType().equalsIgnoreCase("MYSQL")) {
/* 227 */       allHistorySQL.append(commonHistorySQL);
/* 228 */       allHistorySQL.append(" where user_id='" + userID + "' order by user_pwd_date desc limit 0,5");
/* 229 */     } else if (sqlca.getDBMSType().equalsIgnoreCase("SQLSERVER"))
/*     */     {
/* 232 */       commonHistorySQL = "select top 5 user_pwd from user_password_history ";
/* 233 */       allHistorySQL.append(commonHistorySQL).append(" where user_id='" + userID + "' order by user_pwd_date desc)");
/* 234 */     } else if (sqlca.getDBMSType().equalsIgnoreCase("SYBASE")) {
/* 235 */       allHistorySQL.append("select top 5 user_pwd from (");
/* 236 */       allHistorySQL.append(commonHistorySQL).append(" where user_id='" + userID + "' order by user_pwd_date desc) a ");
/*     */     }
/* 238 */     logger.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryHisPwd") + "SQL:" + allHistorySQL.toString());
/* 239 */     return allHistorySQL.toString();
/*     */   }
/*     */ 
/*     */   public final boolean isPwdRepeated(String userID, String userPwd)
/*     */   {
/* 249 */     boolean isRepeated = false;
/*     */ 
/* 251 */     String commonHistorySQL = new String("select user_pwd from user_password_history ");
/* 252 */     String historySQL = null;
/* 253 */     Sqlca sqlca = null;
/*     */     try {
/* 255 */       sqlca = new Sqlca(new ConnectionEx());
/* 256 */       historySQL = getHistorySQL(userID, commonHistorySQL, sqlca);
/*     */ 
/* 258 */       sqlca.execute(historySQL);
/* 259 */       while (sqlca.next()) {
/* 260 */         if (sqlca.getString("user_pwd").trim().equals(userPwd)) {
/* 261 */           isRepeated = true;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 270 */       if (null != sqlca)
/* 271 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 267 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryHisPwdFail") + ":" + e);
/* 268 */       isRepeated = true;
/*     */ 
/* 270 */       if (null != sqlca)
/* 271 */         sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 270 */       if (null != sqlca) {
/* 271 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 274 */     return isRepeated;
/*     */   }
/*     */ 
/*     */   public final int savePwd2History(String userID, String pwd, String operatorId)
/*     */   {
/* 285 */     int aResult = -1;
/* 286 */     Sqlca sqlca = null;
/* 287 */     StringBuffer insertSQL = new StringBuffer("");
/*     */     try
/*     */     {
/* 290 */       sqlca = new Sqlca(new ConnectionEx());
/* 291 */       insertSQL.append("insert into user_password_history(user_id,user_pwd,user_pwd_date,operator_id) ");
/* 292 */       insertSQL.append(" values('" + userID + "','" + pwd + "'," + sqlca.getSql2DateTimeNow() + ",'" + operatorId + "')");
/* 293 */       aResult = sqlca.execute(insertSQL.toString());
/*     */ 
/* 298 */       if (null != sqlca)
/* 299 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 295 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.savePwdToHisFail") + ":" + e);
/* 296 */       aResult = -1;
/*     */ 
/* 298 */       if (null != sqlca)
/* 299 */         sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 298 */       if (null != sqlca) {
/* 299 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 302 */     if (aResult == -1) {
/* 303 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.insertHisPwdFail"));
/*     */     }
/* 305 */     insertSQL = null;
/* 306 */     return aResult;
/*     */   }
/*     */ 
/*     */   public final int updateLatestPwdDate(String userIds)
/*     */   {
/* 315 */     int n = 0;
/* 316 */     logger.debug("need to unlock userIds:" + userIds);
/* 317 */     System.out.println("need to unlock userIds:" + userIds);
/* 318 */     SimpleDateFormat formatter = null;
/* 319 */     String dbType = "";
/* 320 */     userIds = "(" + userIds + ")";
/* 321 */     String userId = "";
/* 322 */     Date lastPwdDate = null;
/*     */ 
/* 324 */     Calendar delayedPwdCal = Calendar.getInstance();
/* 325 */     Date dalayedPwdDate = null;
/*     */ 
/* 327 */     String formttedPwdDate = "";
/* 328 */     String formttedDelayedPwdDate = "";
/* 329 */     Sqlca sqlca = null;
/* 330 */     Sqlca updateSqlca = null;
/* 331 */     PwdPolicyInfo policyInfo = loadPwdPolicy();
/*     */     try {
/* 333 */       sqlca = new Sqlca(new ConnectionEx());
/* 334 */       updateSqlca = new Sqlca(new ConnectionEx());
/* 335 */       updateSqlca.setAutoCommit(false);
/* 336 */       String querySQL = "select user_id,max(user_pwd_date) as lastPwdDate from user_password_history  where user_id in " + userIds;
/* 337 */       querySQL = querySQL + " group by user_id";
/* 338 */       logger.debug("querySQL:" + querySQL);
/* 339 */       System.out.println("querySQL:" + querySQL);
/* 340 */       sqlca.execute(querySQL);
/* 341 */       while (sqlca.next()) {
/* 342 */         userId = sqlca.getString("user_id");
/* 343 */         lastPwdDate = sqlca.getTimestamp("lastPwdDate");
/*     */ 
/* 345 */         delayedPwdCal.add(5, 10 - policyInfo.getExpireDays());
/* 346 */         dalayedPwdDate = delayedPwdCal.getTime();
/* 347 */         String updateSQL = " update user_password_history ";
/* 348 */         dbType = sqlca.getDBMSType();
/* 349 */         if (dbType.equalsIgnoreCase("MYSQL"))
/*     */         {
/* 351 */           formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 352 */           formttedDelayedPwdDate = formatter.format(dalayedPwdDate);
/* 353 */           formttedPwdDate = formatter.format(lastPwdDate);
/* 354 */           updateSQL = updateSQL + "set user_pwd_date= '" + formttedDelayedPwdDate + "'";
/* 355 */           updateSQL = updateSQL + " where user_id='" + userId + "' and Date_Format(user_pwd_date,'%Y-%m-%d %H:%i:%s') ='" + formttedPwdDate + "'";
/* 356 */         } else if (dbType.equalsIgnoreCase("ORACLE"))
/*     */         {
/* 358 */           formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 359 */           formttedDelayedPwdDate = formatter.format(dalayedPwdDate);
/* 360 */           formttedPwdDate = formatter.format(lastPwdDate);
/* 361 */           updateSQL = updateSQL + "set user_pwd_date= to_date('" + formttedDelayedPwdDate + "','YYYY-MM-dd hh24:mi:ss')";
/* 362 */           updateSQL = updateSQL + " where user_id='" + userId + "' and to_char(user_pwd_date,'YYYY-MM-dd hh24:mi:ss') ='" + formttedPwdDate + "'";
/* 363 */         } else if (dbType.equalsIgnoreCase("DB2"))
/*     */         {
/* 365 */           formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 366 */           formttedDelayedPwdDate = formatter.format(dalayedPwdDate);
/* 367 */           formttedPwdDate = formatter.format(lastPwdDate);
/* 368 */           updateSQL = updateSQL + "set user_pwd_date= date('" + formttedDelayedPwdDate + "','yyyy-MM-dd hh:mi:ss')";
/* 369 */           updateSQL = updateSQL + " where user_id='" + userId + "' and ts_fmt(user_pwd_date,'yyyy-MM-dd hh:mi:ss') ='" + formttedPwdDate + "'";
/* 370 */         } else if (dbType.equalsIgnoreCase("SYBASE"))
/*     */         {
/* 372 */           formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 373 */           formttedDelayedPwdDate = formatter.format(dalayedPwdDate);
/* 374 */           formttedPwdDate = formatter.format(lastPwdDate);
/* 375 */           updateSQL = updateSQL + "set user_pwd_date= dateformat('" + formttedDelayedPwdDate + "','yyyy-MM-dd hh:mi:ss')";
/* 376 */           updateSQL = updateSQL + " where user_id='" + userId + "' and CONVERT(Varchar, user_pwd_date ,20) = '" + formttedPwdDate + "'";
/* 377 */         } else if (dbType.equalsIgnoreCase("SQLSERVER"))
/*     */         {
/* 379 */           formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 380 */           formttedDelayedPwdDate = formatter.format(dalayedPwdDate);
/* 381 */           formttedPwdDate = formatter.format(lastPwdDate);
/* 382 */           updateSQL = updateSQL + "set user_pwd_date= CONVERT(Datetime, '" + formttedDelayedPwdDate + "', 20)";
/* 383 */           updateSQL = updateSQL + " where user_id='" + userId + "' and CONVERT(Varchar, user_pwd_date ,20) = '" + formttedPwdDate + "'";
/*     */         }
/*     */ 
/* 386 */         updateSqlca.execute(updateSQL);
/* 387 */         logger.debug("updateSQL:" + updateSQL);
/* 388 */         System.out.println("updateSQL:" + updateSQL);
/*     */       }
/* 390 */       updateSqlca.commit();
/*     */ 
/* 396 */       if (null != sqlca) {
/* 397 */         sqlca.closeAll();
/* 398 */         sqlca = null;
/*     */       }
/* 400 */       if (null != updateSqlca) {
/* 401 */         updateSqlca.closeAll();
/* 402 */         updateSqlca = null;
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 392 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateHisPwdFail") + ":" + e);
/* 393 */       e.printStackTrace();
/* 394 */       n = -1;
/*     */ 
/* 396 */       if (null != sqlca) {
/* 397 */         sqlca.closeAll();
/* 398 */         sqlca = null;
/*     */       }
/* 400 */       if (null != updateSqlca) {
/* 401 */         updateSqlca.closeAll();
/* 402 */         updateSqlca = null;
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 396 */       if (null != sqlca) {
/* 397 */         sqlca.closeAll();
/* 398 */         sqlca = null;
/*     */       }
/* 400 */       if (null != updateSqlca) {
/* 401 */         updateSqlca.closeAll();
/* 402 */         updateSqlca = null;
/*     */       }
/*     */     }
/* 405 */     return n;
/*     */   }
/*     */ 
/*     */   public final int delPwdHistory(String userID)
/*     */   {
/* 413 */     int aResult = -1;
/* 414 */     StringBuffer delSQL = new StringBuffer("delete from user_password_history ");
/* 415 */     delSQL.append(" where user_id = '" + userID + "'");
/* 416 */     Sqlca sqlca = null;
/*     */     try {
/* 418 */       sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 420 */       aResult = sqlca.execute(delSQL.toString());
/*     */ 
/* 425 */       if (null != sqlca)
/* 426 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 422 */       logger.error(userID + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteHisPwdFail") + ":" + e);
/* 423 */       aResult = -1;
/*     */ 
/* 425 */       if (null != sqlca)
/* 426 */         sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 425 */       if (null != sqlca) {
/* 426 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 429 */     if (aResult == -1) {
/* 430 */       logger.error(userID + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteHisPwdFail2"));
/*     */     }
/* 432 */     delSQL = null;
/* 433 */     return aResult;
/*     */   }
/*     */ 
/*     */   public final boolean lockUser(String userID, int userStatus, String clientIP)
/*     */   {
/* 443 */     boolean isSuccess = false;
/* 444 */     String updateSQL = "update user_user set status=" + userStatus + " where UserID='" + userID + "'";
/*     */ 
/* 446 */     StringBuffer insertSQL = new StringBuffer("");
/* 447 */     Sqlca sqlca = null;
/*     */     try {
/* 449 */       sqlca = new Sqlca(new ConnectionEx());
/* 450 */       sqlca.setAutoCommit(false);
/* 451 */       sqlca.execute(updateSQL.toString());
/*     */ 
/* 459 */       sqlca.commit();
/*     */ 
/* 465 */       if (null != sqlca)
/* 466 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 461 */       logger.error(userID + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateStateFail") + ":" + e);
/*     */ 
/* 463 */       return false;
/*     */     } finally {
/* 465 */       if (null != sqlca) {
/* 466 */         sqlca.closeAll();
/*     */       }
/*     */     }
/*     */ 
/* 470 */     updateSQL = null;
/*     */ 
/* 472 */     return true;
/*     */   }
/*     */ 
/*     */   public Date getLastPwdTime(String userID)
/*     */     throws Exception
/*     */   {
/* 482 */     String theLastPwdTime = null;
/* 483 */     Date pwdDate = null;
/* 484 */     StringBuffer selectSQL = new StringBuffer("select max(user_pwd_date) as maxDate from user_password_history");
/* 485 */     selectSQL.append(" where user_id='" + userID + "'");
/* 486 */     Sqlca sqlca = null;
/*     */     try {
/* 488 */       sqlca = new Sqlca(new ConnectionEx());
/* 489 */       sqlca.execute(selectSQL.toString());
/* 490 */       if (sqlca.next()) {
/* 491 */         pwdDate = sqlca.getTimestamp("maxDate");
/*     */       }
/*     */ 
/* 497 */       if (null != sqlca)
/* 498 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 494 */       theLastPwdTime = null;
/* 495 */       throw e;
/*     */     } finally {
/* 497 */       if (null != sqlca) {
/* 498 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 501 */     selectSQL = null;
/* 502 */     return pwdDate;
/*     */   }
/*     */ 
/*     */   public String getLastPwdChanger(String userId)
/*     */   {
/* 511 */     String operatorId = null;
/*     */ 
/* 513 */     String selectSQL = "select operator_id from user_password_history where user_pwd_date = (select max(user_pwd_date) from user_password_history where user_id='" + userId + "') " + "and user_id='" + userId + "'";
/*     */ 
/* 517 */     Sqlca sqlca = null;
/*     */     try {
/* 519 */       sqlca = new Sqlca(new ConnectionEx());
/* 520 */       sqlca.execute(selectSQL);
/* 521 */       if (sqlca.next())
/* 522 */         operatorId = sqlca.getString("operator_id");
/*     */       else {
/* 524 */         operatorId = userId;
/*     */       }
/*     */ 
/* 528 */       if (null != sqlca)
/* 529 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 526 */       e.printStackTrace();
/*     */ 
/* 528 */       if (null != sqlca)
/* 529 */         sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 528 */       if (null != sqlca) {
/* 529 */         sqlca.closeAll();
/*     */       }
/*     */     }
/*     */ 
/* 533 */     return operatorId;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.pwdpolicy.dao.PwdPolicyDAO
 * JD-Core Version:    0.6.2
 */
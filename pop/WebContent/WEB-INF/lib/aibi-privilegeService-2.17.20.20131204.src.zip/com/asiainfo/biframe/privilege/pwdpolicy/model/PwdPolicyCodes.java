package com.asiainfo.biframe.privilege.pwdpolicy.model;

public final class PwdPolicyCodes
{
  public static final int USER_STATUS_NORMAL = 0;
  public static final int USER_STATUS_LOCKED = 1;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.pwdpolicy.model.PwdPolicyCodes
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.pwdpolicy.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class PwdPolicyInfo
/*     */   implements Serializable
/*     */ {
/*     */   private int upperCase;
/*     */   private int lowerCase;
/*     */   private int numberCase;
/*     */   private int specialCase;
/*     */   private int pwdMinLen;
/*     */   private int pwdMaxLen;
/*     */   private int expireDays;
/*     */   private int aheadDays;
/*     */   private int loginRetryCount;
/*     */   private String excludeChars;
/*     */   private int pwdMatureRemind;
/*     */ 
/*     */   public int getUpperCase()
/*     */   {
/*  36 */     return this.upperCase;
/*     */   }
/*     */   public void setUpperCase(int upperCase) {
/*  39 */     this.upperCase = upperCase;
/*     */   }
/*     */   public int getLowerCase() {
/*  42 */     return this.lowerCase;
/*     */   }
/*     */   public void setLowerCase(int lowerCase) {
/*  45 */     this.lowerCase = lowerCase;
/*     */   }
/*     */   public int getNumberCase() {
/*  48 */     return this.numberCase;
/*     */   }
/*     */   public void setNumberCase(int numberCase) {
/*  51 */     this.numberCase = numberCase;
/*     */   }
/*     */   public int getSpecialCase() {
/*  54 */     return this.specialCase;
/*     */   }
/*     */   public void setSpecialCase(int specialCase) {
/*  57 */     this.specialCase = specialCase;
/*     */   }
/*     */   public int getPwdMinLen() {
/*  60 */     return this.pwdMinLen;
/*     */   }
/*     */   public void setPwdMinLen(int pwdMinLen) {
/*  63 */     this.pwdMinLen = pwdMinLen;
/*     */   }
/*     */   public int getPwdMaxLen() {
/*  66 */     return this.pwdMaxLen;
/*     */   }
/*     */   public void setPwdMaxLen(int pwdMaxLen) {
/*  69 */     this.pwdMaxLen = pwdMaxLen;
/*     */   }
/*     */   public int getExpireDays() {
/*  72 */     return this.expireDays;
/*     */   }
/*     */   public void setExpireDays(int expireDays) {
/*  75 */     this.expireDays = expireDays;
/*     */   }
/*     */   public int getAheadDays() {
/*  78 */     return this.aheadDays;
/*     */   }
/*     */   public void setAheadDays(int aheadDays) {
/*  81 */     this.aheadDays = aheadDays;
/*     */   }
/*     */ 
/*     */   public String getExcludeChars() {
/*  85 */     return this.excludeChars;
/*     */   }
/*     */   public void setExcludeChars(String excludeChars) {
/*  88 */     this.excludeChars = excludeChars;
/*     */   }
/*     */   public int getLoginRetryCount() {
/*  91 */     return this.loginRetryCount;
/*     */   }
/*     */   public void setLoginRetryCount(int loginRetryCount) {
/*  94 */     this.loginRetryCount = loginRetryCount;
/*     */   }
/*     */   public int getPwdMatureRemind() {
/*  97 */     return this.pwdMatureRemind;
/*     */   }
/*     */   public void setPwdMatureRemind(int pwdMatureRemind) {
/* 100 */     this.pwdMatureRemind = pwdMatureRemind;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.pwdpolicy.model.PwdPolicyInfo
 * JD-Core Version:    0.6.2
 */
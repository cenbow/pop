/*     */ package com.asiainfo.biframe.privilege.pwdpolicy.service;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.pwdpolicy.dao.PwdPolicyDAO;
/*     */ import com.asiainfo.biframe.privilege.pwdpolicy.model.PwdPolicyInfo;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.DES;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class PwdPolicyService
/*     */ {
/*  21 */   private static Logger logger = Logger.getLogger(PwdPolicyService.class);
/*     */ 
/*     */   public static final PwdPolicyInfo loadPwdPolicy()
/*     */   {
/*  33 */     PwdPolicyInfo policyInfo = null;
/*  34 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/*  35 */     policyInfo = policyDao.loadPwdPolicy();
/*  36 */     if (null == policyInfo) {
/*  37 */       policyInfo = setDefaultPolicy();
/*     */     }
/*  39 */     if (null == policyInfo.getExcludeChars()) {
/*  40 */       policyInfo.setExcludeChars("");
/*     */     }
/*  42 */     return policyInfo;
/*     */   }
/*     */ 
/*     */   public final int savePwdPolicy(PwdPolicyInfo policyInfo) throws Exception
/*     */   {
/*  47 */     System.out.println("in service......");
/*  48 */     int aResult = -1;
/*  49 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/*     */ 
/*  51 */     aResult = policyDao.savePwdPolicy(policyInfo);
/*  52 */     return aResult;
/*     */   }
/*     */ 
/*     */   private static final PwdPolicyInfo setDefaultPolicy()
/*     */   {
/*  62 */     PwdPolicyInfo policyInfo = new PwdPolicyInfo();
/*  63 */     policyInfo.setUpperCase(0);
/*  64 */     policyInfo.setLowerCase(1);
/*  65 */     policyInfo.setNumberCase(1);
/*  66 */     policyInfo.setSpecialCase(0);
/*  67 */     policyInfo.setPwdMinLen(6);
/*  68 */     policyInfo.setPwdMaxLen(24);
/*  69 */     policyInfo.setExpireDays(90);
/*  70 */     policyInfo.setAheadDays(7);
/*  71 */     policyInfo.setLoginRetryCount(5);
/*  72 */     return policyInfo;
/*     */   }
/*     */ 
/*     */   public static final boolean isPwdRepeated(String userID, String userPwd)
/*     */   {
/*  85 */     boolean repeated = false;
/*     */     try {
/*  87 */       userPwd = DES.encrypt(userPwd);
/*     */     } catch (Exception e) {
/*  89 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.encryptFail") + ":" + e);
/*     */ 
/*  92 */       repeated = false;
/*     */     }
/*  94 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/*  95 */     repeated = policyDao.isPwdRepeated(userID, userPwd);
/*  96 */     return repeated;
/*     */   }
/*     */ 
/*     */   public static final int savePwd2History(String userID, String pwd, String operatorId)
/*     */   {
/* 108 */     int aResult = -1;
/* 109 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/*     */     try {
/* 111 */       pwd = DES.encrypt(pwd);
/*     */     } catch (Exception e) {
/* 113 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.encryptFail") + ":" + e);
/*     */ 
/* 116 */       aResult = -1;
/*     */     }
/* 118 */     aResult = policyDao.savePwd2History(userID, pwd, operatorId);
/* 119 */     return aResult;
/*     */   }
/*     */ 
/*     */   public static final int updateLatestPwdDate(String userIds)
/*     */   {
/* 129 */     int n = 0;
/* 130 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/* 131 */     n = policyDao.updateLatestPwdDate(userIds);
/* 132 */     return n;
/*     */   }
/*     */ 
/*     */   public static final int delPwdHistory(String userID)
/*     */   {
/* 143 */     int aResult = -1;
/* 144 */     if (null == userID) {
/* 145 */       logger.warn(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userIdNull"));
/*     */ 
/* 147 */       return aResult;
/*     */     }
/* 149 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/* 150 */     aResult = policyDao.delPwdHistory(userID);
/* 151 */     logger.info(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteHisPwdRecord") + ":[" + userID + ":" + aResult + "]");
/*     */ 
/* 154 */     return aResult;
/*     */   }
/*     */ 
/*     */   public static final boolean lockUser(String userID, String clientIP)
/*     */   {
/* 167 */     boolean isSuccess = false;
/* 168 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/*     */ 
/* 170 */     isSuccess = policyDao.lockUser(userID, 1, clientIP);
/*     */ 
/* 172 */     return isSuccess;
/*     */   }
/*     */ 
/*     */   public static final boolean isPwdExpired(String userID)
/*     */   {
/* 182 */     SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:mm:SSS");
/*     */ 
/* 184 */     boolean isExpired = false;
/* 185 */     Date pwdDate = null;
/* 186 */     Calendar nowTime = Calendar.getInstance();
/* 187 */     PwdPolicyInfo policyInfo = new PwdPolicyInfo();
/* 188 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/* 189 */     policyInfo = policyDao.loadPwdPolicy();
/*     */     try {
/* 191 */       pwdDate = policyDao.getLastPwdTime(userID);
/*     */     } catch (Exception e) {
/* 193 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getSavePwdTimeFail") + ":" + e);
/*     */ 
/* 196 */       isExpired = false;
/*     */     }
/* 198 */     if (null != pwdDate) {
/* 199 */       System.out.println("now Time:" + formatter.format(nowTime.getTime()));
/*     */ 
/* 201 */       Calendar pwdCalendar = Calendar.getInstance();
/* 202 */       pwdCalendar.setTime(pwdDate);
/* 203 */       System.out.println(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.lastPwdUpdateDate") + ":" + formatter.format(pwdCalendar.getTime()));
/*     */ 
/* 206 */       if (policyInfo != null) {
/* 207 */         pwdCalendar.add(5, policyInfo.getExpireDays());
/*     */ 
/* 209 */         System.out.println(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.lastPwdUpdateDate") + "+" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.expireDate") + ":" + formatter.format(pwdCalendar.getTime()));
/*     */ 
/* 217 */         if (nowTime.after(pwdCalendar)) {
/* 218 */           isExpired = true;
/*     */         }
/*     */       }
/*     */     }
/* 222 */     return isExpired;
/*     */   }
/*     */ 
/*     */   public static final boolean isPwdChangedByOthers(String userId)
/*     */   {
/* 232 */     boolean isChangedByOthers = false;
/* 233 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/*     */ 
/* 235 */     String operatorId = policyDao.getLastPwdChanger(userId);
/* 236 */     if (!userId.equals(operatorId)) {
/* 237 */       isChangedByOthers = true;
/*     */     }
/* 239 */     return isChangedByOthers;
/*     */   }
/*     */ 
/*     */   public static final int getPwdRemainDays(String userID)
/*     */   {
/* 251 */     Date pwdDate = null;
/*     */ 
/* 253 */     int remainDays = -1;
/* 254 */     Calendar nowTime = Calendar.getInstance();
/* 255 */     PwdPolicyInfo policyInfo = new PwdPolicyInfo();
/* 256 */     PwdPolicyDAO policyDao = new PwdPolicyDAO();
/* 257 */     policyInfo = policyDao.loadPwdPolicy();
/*     */     try {
/* 259 */       pwdDate = policyDao.getLastPwdTime(userID);
/*     */     } catch (Exception e) {
/* 261 */       logger.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getSavePwdTimeFail") + ":" + e);
/*     */ 
/* 264 */       remainDays = -1;
/*     */     }
/* 266 */     if ((null != pwdDate) && (policyInfo != null))
/*     */     {
/* 271 */       nowTime.add(5, policyInfo.getAheadDays());
/*     */ 
/* 273 */       Calendar upDateCalendar = Calendar.getInstance();
/* 274 */       upDateCalendar.setTime(pwdDate);
/*     */ 
/* 277 */       upDateCalendar.add(5, policyInfo.getExpireDays());
/*     */ 
/* 280 */       if (nowTime.after(upDateCalendar)) {
/* 281 */         remainDays = policyInfo.getAheadDays() - (int)(nowTime.getTimeInMillis() - upDateCalendar.getTimeInMillis()) / 86400000;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 288 */     return remainDays;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.pwdpolicy.service.PwdPolicyService
 * JD-Core Version:    0.6.2
 */
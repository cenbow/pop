/*     */ package com.asiainfo.biframe.privilege.pwdpolicy.task;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.base.util.UniTouchUtil;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.webservice.uniTouch.TaskModel;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class PasswordTask
/*     */ {
/*  21 */   private Sqlca sqlca = null;
/*  22 */   private Sqlca sqlca2 = null;
/*     */ 
/*  24 */   private static Log log = LogFactory.getLog(PasswordTask.class);
/*  25 */   private String message = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.expireTip");
/*  26 */   protected SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*  27 */   public int n = 0;
/*  28 */   public int space = 0;
/*     */ 
/*     */   public void run()
/*     */   {
/*  34 */     System.out.println("========================================password remind in run==============================================");
/*  35 */     System.out.println("============================start run date:" + new Date(System.currentTimeMillis()));
/*     */     try {
/*  37 */       this.sqlca2 = new Sqlca(new ConnectionEx());
/*  38 */       int pwdMatureRemind = 0;
/*  39 */       String sql = "select PWD_MATURE_REMIND from user_pwd_policy";
/*  40 */       this.sqlca2.execute(sql);
/*  41 */       while (this.sqlca2.next()) {
/*  42 */         pwdMatureRemind = this.sqlca2.getInt("PWD_MATURE_REMIND");
/*     */       }
/*  44 */       if (pwdMatureRemind != 1) {
/*  45 */         this.sqlca = new Sqlca(new ConnectionEx());
/*  46 */         log.info(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.scheduleNotExecute"));
/*     */       }
/*     */       else {
/*  49 */         this.sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/*  55 */         String strSql = "select user_id,max(user_pwd_date) user_pwd_date from user_password_history group by user_id";
/*  56 */         this.sqlca.execute(strSql);
/*  57 */         while (this.sqlca.next()) {
/*  58 */           String userId = this.sqlca.getString("user_id");
/*  59 */           Timestamp userPwdDate = this.sqlca.getTimestamp("user_pwd_date");
/*     */ 
/*  62 */           String currentTime = this.sdf.format(userPwdDate);
/*     */ 
/*  65 */           int expirsDays = getExpirsDays() - 1;
/*  66 */           Calendar c1 = Calendar.getInstance();
/*     */ 
/*  68 */           c1.add(5, -expirsDays);
/*  69 */           System.out.println("============================userId:" + userId + " ================================");
/*  70 */           System.out.println("============================userPwdDate:" + userPwdDate);
/*  71 */           System.out.println("============================expirsDays:" + expirsDays);
/*  72 */           System.out.println("============================caculateDate:" + this.sdf.format(c1.getTime()));
/*  73 */           if (currentTime.equals(this.sdf.format(c1.getTime()))) {
/*  74 */             System.out.println("\n****************************user should be remind:" + userId);
/*  75 */             String MobilePhone = getMobilephone(userId);
/*  76 */             System.out.println("****************************user phone number:" + MobilePhone + "\n");
/*  77 */             sendPasswordMatureRemindSms(MobilePhone, userId);
/*     */           }
/*     */         }
/*  80 */         System.out.println("============================end run date:" + new Date(System.currentTimeMillis()));
/*  81 */         System.out.println("================================password remind end run=============================");
/*     */       }
/*     */     } catch (Exception e) { e.printStackTrace();
/*  84 */       log.error("run:" + e.getMessage());
/*     */     } finally {
/*  86 */       if (this.sqlca2 != null) {
/*  87 */         this.sqlca2.closeAll();
/*     */       }
/*  89 */       if (this.sqlca != null)
/*  90 */         this.sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String getMobilephone(String userid) throws SQLException
/*     */   {
/*  96 */     Sqlca m_Sqlca = null;
/*  97 */     String mobilephone = null;
/*     */     try
/*     */     {
/* 100 */       User_User user = (User_User)UserCache.getInstance().getObjectByKey(userid);
/* 101 */       if (user != null)
/* 102 */         mobilephone = user.getMobilePhone();
/*     */     } catch (Exception ex) {
/* 104 */       ex.printStackTrace();
/* 105 */       log.error("getMobilephone:" + ex.getMessage());
/*     */     } finally {
/* 107 */       if (m_Sqlca != null)
/* 108 */         m_Sqlca.closeAll();
/*     */     }
/* 110 */     return mobilephone;
/*     */   }
/*     */ 
/*     */   private void sendPasswordMatureRemindSms(String MobilePhone, String userId) {
/* 114 */     String messages = userId + "," + this.message;
/*     */     try
/*     */     {
/* 117 */       TaskModel model = new TaskModel();
/* 118 */       model.setCreator("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.biComponent") + "");
/* 119 */       model.setSubject("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.pwdExpireTip") + "");
/* 120 */       model.setContent(messages);
/* 121 */       UniTouchUtil.sendSmsMessage(model, MobilePhone);
/*     */     } catch (Exception e2) {
/* 123 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.sendPwdExpireSmsFail") + "", e2);
/*     */     }
/*     */   }
/*     */ 
/*     */   private int getExpirsDays() {
/* 128 */     int expirsDays = 0;
/* 129 */     Sqlca sqlcas = null;
/* 130 */     String sql = "select expire_days from user_pwd_policy";
/*     */     try {
/* 132 */       sqlcas = new Sqlca(new ConnectionEx());
/*     */ 
/* 134 */       sqlcas.execute(sql);
/* 135 */       while (sqlcas.next())
/* 136 */         expirsDays = sqlcas.getInt("expire_days");
/*     */     }
/*     */     catch (Exception e) {
/* 139 */       e.printStackTrace();
/*     */     } finally {
/* 141 */       if (sqlcas != null)
/* 142 */         sqlcas.closeAll();
/*     */     }
/* 144 */     return expirsDays;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.pwdpolicy.task.PasswordTask
 * JD-Core Version:    0.6.2
 */
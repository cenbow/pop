/*    */ package com.asiainfo.biframe.privilege.pwdpolicy.task;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*    */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class UserValidateCodeRefreshTask
/*    */ {
/* 21 */   private static Log log = LogFactory.getLog(UserValidateCodeRefreshTask.class);
/* 22 */   private boolean isContinue = false;
/*    */ 
/*    */   public UserValidateCodeRefreshTask()
/*    */   {
/* 28 */     this.isContinue = true;
/*    */   }
/*    */ 
/*    */   public void cancel()
/*    */   {
/* 35 */     this.isContinue = false;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 42 */     log.debug("in run");
/* 43 */     if (!this.isContinue) {
/* 44 */       return;
/*    */     }
/* 46 */     Sqlca sqlca = null;
/*    */     try {
/* 48 */       sqlca = new Sqlca(new ConnectionEx());
/* 49 */       String sql = "delete from user_validate_code where create_millis is not null and " + System.currentTimeMillis() + " - create_millis > 60 * 5 * 1000";
/* 50 */       log.debug(">>UserValidateCodeRefreshTask SQL: \n" + sql);
/* 51 */       sqlca.execute(sql);
/*    */ 
/* 53 */       log.debug("end run");
/*    */     } catch (Exception e) {
/* 55 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.refreshLoginInfoFail") + "", e);
/*    */     } finally {
/* 57 */       if (sqlca != null)
/* 58 */         sqlca.closeAll();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.pwdpolicy.task.UserValidateCodeRefreshTask
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.roleclassifymanage.dao;

import com.asiainfo.biframe.privilege.model.UserRoleClassify;
import java.util.List;

public abstract interface IUserRoleClassifyDao
{
  public abstract void save(UserRoleClassify paramUserRoleClassify)
    throws Exception;

  public abstract void update(UserRoleClassify paramUserRoleClassify)
    throws Exception;

  public abstract UserRoleClassify getById(String paramString)
    throws Exception;

  public abstract void delete(UserRoleClassify paramUserRoleClassify)
    throws Exception;

  public abstract long getClassifyCountWithSameName(String paramString1, String paramString2)
    throws Exception;

  public abstract long getClassifyCountInUse(String paramString)
    throws Exception;

  public abstract List<UserRoleClassify> getClassifyByName(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract List<UserRoleClassify> getClassifyByParentId(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.roleclassifymanage.dao.IUserRoleClassifyDao
 * JD-Core Version:    0.6.2
 */
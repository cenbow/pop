/*     */ package com.asiainfo.biframe.privilege.roleclassifymanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.model.UserRoleClassify;
/*     */ import com.asiainfo.biframe.privilege.roleclassifymanage.dao.IUserRoleClassifyDao;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import common.Logger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserRoleClassifyDaoImpl extends HibernateDaoSupport
/*     */   implements IUserRoleClassifyDao
/*     */ {
/*  43 */   private Logger log = Logger.getLogger(UserRoleClassifyDaoImpl.class);
/*     */ 
/*     */   public void save(UserRoleClassify roleClassify)
/*     */     throws Exception
/*     */   {
/*  53 */     this.log.debug("in save");
/*  54 */     getHibernateTemplate().save(roleClassify);
/*  55 */     this.log.debug("end save");
/*     */   }
/*     */ 
/*     */   public void update(UserRoleClassify roleClassify)
/*     */     throws Exception
/*     */   {
/*  66 */     this.log.debug("in update");
/*  67 */     getHibernateTemplate().update(roleClassify);
/*  68 */     this.log.debug("end update");
/*     */   }
/*     */ 
/*     */   public UserRoleClassify getById(String classifyId)
/*     */     throws Exception
/*     */   {
/*  79 */     this.log.debug("in getById");
/*  80 */     UserRoleClassify roleClassify = (UserRoleClassify)getHibernateTemplate().get(UserRoleClassify.class, classifyId);
/*     */ 
/*  82 */     this.log.debug("end getById");
/*  83 */     return roleClassify;
/*     */   }
/*     */ 
/*     */   public void delete(UserRoleClassify classify)
/*     */     throws Exception
/*     */   {
/*  94 */     this.log.debug("in delete");
/*  95 */     getHibernateTemplate().delete(classify);
/*  96 */     this.log.debug("end delete");
/*     */   }
/*     */ 
/*     */   public long getClassifyCountWithSameName(String classifyName, String classifyId)
/*     */     throws Exception
/*     */   {
/* 108 */     long retCount = 0L;
/* 109 */     List list = null;
/*     */ 
/* 111 */     if ((StringUtil.isEmpty(classifyName)) && (StringUtil.isEmpty(classifyId))) {
/* 112 */       return retCount;
/*     */     }
/* 114 */     String hql = "from UserRoleClassify a where 1=1 and a.classifyName = ? ";
/* 115 */     List params = new ArrayList();
/* 116 */     params.add(classifyName);
/*     */ 
/* 118 */     if (StringUtil.isNotEmpty(classifyId)) {
/* 119 */       hql = hql + " and classifyId!=? ";
/* 120 */       params.add(classifyId);
/*     */     }
/*     */ 
/* 123 */     list = getHibernateTemplate().find(hql, params.toArray());
/* 124 */     if (list != null) {
/* 125 */       retCount = list.size();
/*     */     }
/* 127 */     return retCount;
/*     */   }
/*     */ 
/*     */   public long getClassifyCountInUse(String classifyId)
/*     */     throws Exception
/*     */   {
/* 138 */     long retCount = 0L;
/* 139 */     List list = null;
/*     */ 
/* 141 */     if (StringUtil.isEmpty(classifyId)) {
/* 142 */       return retCount;
/*     */     }
/* 144 */     String hql = "from UserRole a where 1=1 and a.classifyId = ? ";
/* 145 */     List params = new ArrayList();
/* 146 */     params.add(classifyId);
/*     */ 
/* 148 */     list = getHibernateTemplate().find(hql, params.toArray());
/* 149 */     if (list != null) {
/* 150 */       retCount = list.size();
/*     */     }
/* 152 */     return retCount;
/*     */   }
/*     */ 
/*     */   public List<UserRoleClassify> getClassifyByName(String classifyId, String classifyName, String parentId)
/*     */     throws Exception
/*     */   {
/* 158 */     List list = null;
/*     */ 
/* 160 */     String hql = "from UserRoleClassify a where a.classifyName = ? and a.parentId = ? ";
/* 161 */     List params = new ArrayList();
/* 162 */     params.add(classifyName);
/* 163 */     params.add(parentId);
/*     */ 
/* 165 */     if (StringUtil.isNotEmpty(classifyId)) {
/* 166 */       hql = hql + " and classifyId!=? ";
/* 167 */       params.add(classifyId);
/*     */     }
/*     */ 
/* 170 */     list = getHibernateTemplate().find(hql, params.toArray());
/* 171 */     return list;
/*     */   }
/*     */ 
/*     */   public List<UserRoleClassify> getClassifyByParentId(String parentId) throws Exception
/*     */   {
/* 176 */     List list = null;
/*     */ 
/* 178 */     String hql = "from UserRoleClassify a where a.parentId = ? ";
/* 179 */     List params = new ArrayList();
/* 180 */     params.add(parentId);
/*     */ 
/* 182 */     list = getHibernateTemplate().find(hql, params.toArray());
/* 183 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.roleclassifymanage.dao.impl.UserRoleClassifyDaoImpl
 * JD-Core Version:    0.6.2
 */
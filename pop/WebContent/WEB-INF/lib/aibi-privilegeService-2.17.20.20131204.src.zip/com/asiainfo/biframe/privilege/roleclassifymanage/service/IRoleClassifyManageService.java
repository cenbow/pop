package com.asiainfo.biframe.privilege.roleclassifymanage.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.model.UserRoleClassify;
import com.asiainfo.biframe.privilege.roleclassifymanage.vo.ZTreeNode;
import java.util.List;

public abstract interface IRoleClassifyManageService
{
  public abstract List<ZTreeNode> getRoleClassifyTreeList(String paramString1, String paramString2)
    throws ServiceException;

  public abstract UserRoleClassify getUserRoleClassify(String paramString1, String paramString2)
    throws ServiceException;

  public abstract String chkUserRoelClassifyName(String paramString1, String paramString2)
    throws ServiceException;

  public abstract String chkUserRoleClassifyName(String paramString1, String paramString2, String paramString3)
    throws ServiceException;

  public abstract String saveUserRoelClassify(UserRoleClassify paramUserRoleClassify)
    throws ServiceException;

  public abstract String chkRoleClassifyInUse(String paramString)
    throws ServiceException;

  public abstract String deleteUserRoleClassify(String paramString)
    throws ServiceException;

  public abstract String getClassifyNameById(String paramString)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.roleclassifymanage.service.IRoleClassifyManageService
 * JD-Core Version:    0.6.2
 */
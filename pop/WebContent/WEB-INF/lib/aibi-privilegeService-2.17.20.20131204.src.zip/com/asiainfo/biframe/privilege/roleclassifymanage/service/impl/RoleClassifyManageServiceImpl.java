/*     */ package com.asiainfo.biframe.privilege.roleclassifymanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserRoleClassifyCache;
/*     */ import com.asiainfo.biframe.privilege.model.UserRoleClassify;
/*     */ import com.asiainfo.biframe.privilege.roleclassifymanage.dao.IUserRoleClassifyDao;
/*     */ import com.asiainfo.biframe.privilege.roleclassifymanage.service.IRoleClassifyManageService;
/*     */ import com.asiainfo.biframe.privilege.roleclassifymanage.vo.ZTreeNode;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.xwork.StringUtils;
/*     */ 
/*     */ public class RoleClassifyManageServiceImpl
/*     */   implements IRoleClassifyManageService
/*     */ {
/*     */   private IUserRoleClassifyDao userRoleClassifyDao;
/*     */ 
/*     */   public List<ZTreeNode> getRoleClassifyTreeList(String userId, String parentId)
/*     */     throws ServiceException
/*     */   {
/*  61 */     List treeNodeList = new ArrayList();
/*  62 */     ZTreeNode item = null;
/*     */ 
/*  65 */     if ((parentId == null) || ("".equals(parentId))) {
/*  66 */       parentId = "-1";
/*     */     }
/*     */ 
/*  76 */     List alllist = getRoleClasssifyListFromCache(parentId);
/*     */ 
/*  78 */     if (alllist != null) {
/*  79 */       for (UserRoleClassify roleClassify : alllist) {
/*  80 */         item = new ZTreeNode();
/*  81 */         item.setName(roleClassify.getClassifyName());
/*  82 */         item.setId(roleClassify.getClassifyId());
/*  83 */         item.setPid(roleClassify.getParentId());
/*  84 */         item.setIsParent(isHasChildFromCache(roleClassify.getClassifyId()));
/*     */ 
/*  86 */         treeNodeList.add(item);
/*     */       }
/*     */     }
/*  89 */     return treeNodeList;
/*     */   }
/*     */ 
/*     */   private List<UserRoleClassify> getRoleClasssifyListFromCache(String parentId)
/*     */     throws ServiceException
/*     */   {
/* 101 */     Iterator iterator = UserRoleClassifyCache.getInstance().getAllCachedSortedObject().iterator();
/*     */ 
/* 103 */     List list = new ArrayList();
/* 104 */     while (iterator.hasNext()) {
/* 105 */       UserRoleClassify item = (UserRoleClassify)iterator.next();
/* 106 */       if ((item != null) && (parentId.equalsIgnoreCase(item.getParentId()))) {
/* 107 */         list.add(item);
/*     */       }
/*     */     }
/* 110 */     return list;
/*     */   }
/*     */ 
/*     */   private boolean isHasChildFromCache(String parentId)
/*     */     throws ServiceException
/*     */   {
/* 122 */     boolean isHasChild = false;
/* 123 */     Iterator iterator = UserRoleClassifyCache.getInstance().getAllCachedObject().iterator();
/*     */ 
/* 125 */     while (iterator.hasNext()) {
/* 126 */       UserRoleClassify item = (UserRoleClassify)iterator.next();
/* 127 */       if ((item != null) && (parentId.equalsIgnoreCase(item.getParentId()))) {
/* 128 */         isHasChild = true;
/* 129 */         break;
/*     */       }
/*     */     }
/* 132 */     return isHasChild;
/*     */   }
/*     */ 
/*     */   public UserRoleClassify getUserRoleClassify(String classifyId, String parentId)
/*     */     throws ServiceException
/*     */   {
/* 144 */     UserRoleClassify roleClassify = null;
/* 145 */     if (StringUtil.isEmpty(classifyId)) {
/* 146 */       roleClassify = new UserRoleClassify();
/* 147 */       roleClassify.setParentId(parentId);
/*     */     } else {
/* 149 */       roleClassify = getUserRoleClassifyFormCache(classifyId);
/* 150 */       parentId = roleClassify.getParentId();
/*     */     }
/* 152 */     if ((StringUtil.isNotEmpty(parentId)) && (!"-1".equalsIgnoreCase(parentId))) {
/* 153 */       roleClassify.setParentName(UserRoleClassifyCache.getInstance().getNameByKey(parentId));
/*     */     }
/*     */ 
/* 156 */     return roleClassify;
/*     */   }
/*     */ 
/*     */   private UserRoleClassify getUserRoleClassifyFormCache(String classifyId)
/*     */     throws ServiceException
/*     */   {
/* 168 */     UserRoleClassify roleClassify = (UserRoleClassify)UserRoleClassifyCache.getInstance().getObjectByKey(classifyId);
/*     */ 
/* 170 */     return roleClassify;
/*     */   }
/*     */ 
/*     */   public String chkUserRoelClassifyName(String classifyId, String classifyName)
/*     */     throws ServiceException
/*     */   {
/* 182 */     StringBuffer json = new StringBuffer();
/* 183 */     boolean hasExist = false;
/*     */ 
/* 185 */     if (StringUtil.isNotEmpty(classifyName)) {
/*     */       try {
/* 187 */         if (this.userRoleClassifyDao.getClassifyCountWithSameName(classifyName, classifyId) > 0L)
/*     */         {
/* 189 */           hasExist = true;
/*     */         }
/*     */       } catch (Exception e) {
/* 192 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.exMsg.chkClassifyName"));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 198 */     if (hasExist) {
/* 199 */       json.append("{'success':false,'msg':'" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.classifyNameExist") + "'}");
/*     */     }
/*     */     else
/*     */     {
/* 203 */       json.append("{'success':true,'msg':''}");
/*     */     }
/*     */ 
/* 206 */     return json.toString();
/*     */   }
/*     */ 
/*     */   public String saveUserRoelClassify(UserRoleClassify roleClassify)
/*     */     throws ServiceException
/*     */   {
/* 219 */     String retCode = "0";
/*     */ 
/* 222 */     if (roleClassify == null) {
/* 223 */       return retCode;
/*     */     }
/*     */     try
/*     */     {
/* 227 */       if ("".equals(roleClassify.getClassifyId())) {
/* 228 */         roleClassify.setClassifyId(null);
/* 229 */         if (StringUtil.isEmpty(roleClassify.getParentId())) {
/* 230 */           roleClassify.setParentId("-1");
/*     */         }
/* 232 */         this.userRoleClassifyDao.save(roleClassify);
/* 233 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), roleClassify.getClassifyId(), roleClassify.getClassifyName(), "角色分类管理-->新增角色分类", null, null);
/*     */       }
/*     */       else
/*     */       {
/* 239 */         this.userRoleClassifyDao.update(roleClassify);
/* 240 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), roleClassify.getClassifyId(), roleClassify.getClassifyName(), "角色分类管理-->修改角色分类", null, null);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 248 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.exMsg.saveClassify"));
/*     */     }
/*     */ 
/* 252 */     if (StringUtil.isNotEmpty(roleClassify.getClassifyId()))
/*     */     {
/* 254 */       UserRoleClassifyCache.getInstance().refreshAll();
/*     */ 
/* 256 */       retCode = "1";
/*     */     }
/*     */ 
/* 259 */     return retCode;
/*     */   }
/*     */ 
/*     */   public String chkRoleClassifyInUse(String classifyId)
/*     */     throws ServiceException
/*     */   {
/* 270 */     StringBuffer json = new StringBuffer();
/* 271 */     boolean hasExist = false;
/*     */ 
/* 273 */     if (StringUtil.isNotEmpty(classifyId)) {
/*     */       try {
/* 275 */         if (isHasChildFromCache(classifyId)) {
/* 276 */           hasExist = true;
/*     */         }
/* 278 */         else if (this.userRoleClassifyDao.getClassifyCountInUse(classifyId) > 0L)
/* 279 */           hasExist = true;
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 283 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.exMsg.chkDelClassify"));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 289 */     if (hasExist) {
/* 290 */       json.append("{'success':false,'msg':'" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.jsp.chkClassifyInUse") + "'}");
/*     */     }
/*     */     else
/*     */     {
/* 294 */       json.append("{'success':true,'msg':''}");
/*     */     }
/*     */ 
/* 297 */     return json.toString();
/*     */   }
/*     */ 
/*     */   public String deleteUserRoleClassify(String classifyId)
/*     */     throws ServiceException
/*     */   {
/* 308 */     String retCode = "0";
/* 309 */     UserRoleClassify roleClassify = null;
/*     */ 
/* 311 */     if (StringUtil.isEmpty(classifyId)) {
/* 312 */       return retCode;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 317 */       roleClassify = this.userRoleClassifyDao.getById(classifyId);
/* 318 */       if (roleClassify != null)
/*     */       {
/* 320 */         this.userRoleClassifyDao.delete(roleClassify);
/* 321 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), roleClassify.getClassifyId(), roleClassify.getClassifyName(), "角色分类管理-->删除角色分类", null, null);
/*     */ 
/* 328 */         UserRoleClassifyCache.getInstance().refreshAll();
/*     */ 
/* 330 */         retCode = "1";
/*     */       }
/*     */     } catch (Exception e) {
/* 333 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.exMsg.qryClassify"));
/*     */     }
/*     */ 
/* 337 */     return retCode;
/*     */   }
/*     */ 
/*     */   public String getClassifyNameById(String classifyId)
/*     */     throws ServiceException
/*     */   {
/* 346 */     String classifyName = "";
/* 347 */     if (StringUtil.isEmpty(classifyId))
/* 348 */       return classifyName;
/*     */     try
/*     */     {
/* 351 */       UserRoleClassify roleClassify = this.userRoleClassifyDao.getById(classifyId);
/*     */ 
/* 353 */       if (roleClassify != null)
/* 354 */         classifyName = roleClassify.getClassifyName();
/*     */     }
/*     */     catch (Exception e) {
/* 357 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.exMsg.qryClassify"));
/*     */     }
/*     */ 
/* 360 */     return classifyName;
/*     */   }
/*     */ 
/*     */   public IUserRoleClassifyDao getUserRoleClassifyDao() {
/* 364 */     return this.userRoleClassifyDao;
/*     */   }
/*     */ 
/*     */   public void setUserRoleClassifyDao(IUserRoleClassifyDao userRoleClassifyDao) {
/* 368 */     this.userRoleClassifyDao = userRoleClassifyDao;
/*     */   }
/*     */ 
/*     */   public String chkUserRoleClassifyName(String classifyId, String classifyName, String parentId) throws ServiceException
/*     */   {
/* 373 */     StringBuffer json = new StringBuffer();
/* 374 */     boolean hasExist = false;
/*     */     try {
/* 376 */       if (StringUtils.isNotEmpty(classifyName)) {
/* 377 */         String classifyParent = parentId;
/*     */ 
/* 379 */         while (!"-1".equals(classifyParent)) {
/* 380 */           UserRoleClassify urc = this.userRoleClassifyDao.getById(classifyParent);
/* 381 */           if (classifyName.equals(urc.getClassifyName())) {
/* 382 */             hasExist = true;
/* 383 */             break;
/*     */           }
/* 385 */           classifyParent = urc.getParentId();
/*     */         }
/*     */ 
/* 389 */         if (!hasExist) {
/* 390 */           List urcList = this.userRoleClassifyDao.getClassifyByName(classifyId, classifyName, parentId);
/* 391 */           if ((null != urcList) && (urcList.size() > 0)) {
/* 392 */             hasExist = true;
/*     */           }
/*     */         }
/*     */ 
/* 396 */         if ((!hasExist) && 
/* 397 */           (StringUtils.isNotBlank(classifyId)))
/* 398 */           hasExist = isExistsClassifyName(classifyId, classifyName);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 403 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.exMsg.chkClassifyName"));
/*     */     }
/*     */ 
/* 407 */     if (hasExist) {
/* 408 */       json.append("{'success':false,'msg':'" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.classifyNameExist") + "'}");
/*     */     }
/*     */     else
/*     */     {
/* 412 */       json.append("{'success':true,'msg':''}");
/*     */     }
/*     */ 
/* 415 */     return json.toString();
/*     */   }
/*     */ 
/*     */   private boolean isExistsClassifyName(String parentId, String classifyName) {
/* 419 */     boolean isExists = false;
/*     */     try {
/* 421 */       List urcList = this.userRoleClassifyDao.getClassifyByParentId(parentId);
/* 422 */       if ((null != urcList) && (urcList.size() > 0)) {
/* 423 */         for (UserRoleClassify urc : urcList) {
/* 424 */           if (classifyName.equals(urc.getClassifyName())) {
/* 425 */             return true;
/*     */           }
/* 427 */           isExists = isExistsClassifyName(urc.getClassifyId(), classifyName);
/* 428 */           if (isExists == true)
/*     */             break;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 435 */       throw new RuntimeException(e);
/*     */     }
/* 437 */     return isExists;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.roleclassifymanage.service.impl.RoleClassifyManageServiceImpl
 * JD-Core Version:    0.6.2
 */
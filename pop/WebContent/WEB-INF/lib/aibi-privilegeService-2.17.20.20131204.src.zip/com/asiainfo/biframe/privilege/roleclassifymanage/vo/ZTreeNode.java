/*    */ package com.asiainfo.biframe.privilege.roleclassifymanage.vo;
/*    */ 
/*    */ public class ZTreeNode
/*    */ {
/*    */   private String id;
/*    */   private String name;
/*    */   private String pid;
/*    */   private String url;
/*    */   private String target;
/*    */   private String open;
/*    */   private boolean isParent;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 13 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 16 */     this.id = id;
/*    */   }
/*    */   public String getName() {
/* 19 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 22 */     this.name = name;
/*    */   }
/*    */   public String getPid() {
/* 25 */     return this.pid;
/*    */   }
/*    */   public void setPid(String pid) {
/* 28 */     this.pid = pid;
/*    */   }
/*    */ 
/*    */   public String getUrl()
/*    */   {
/* 34 */     return this.url;
/*    */   }
/*    */ 
/*    */   public void setUrl(String url)
/*    */   {
/* 40 */     this.url = url;
/*    */   }
/*    */ 
/*    */   public String getTarget()
/*    */   {
/* 46 */     return this.target;
/*    */   }
/*    */ 
/*    */   public void setTarget(String target)
/*    */   {
/* 52 */     this.target = target;
/*    */   }
/*    */ 
/*    */   public String getOpen()
/*    */   {
/* 58 */     return this.open;
/*    */   }
/*    */ 
/*    */   public void setOpen(String open)
/*    */   {
/* 64 */     this.open = open;
/*    */   }
/*    */ 
/*    */   public boolean getIsParent()
/*    */   {
/* 71 */     return this.isParent;
/*    */   }
/*    */ 
/*    */   public void setIsParent(boolean isParent)
/*    */   {
/* 77 */     this.isParent = isParent;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.roleclassifymanage.vo.ZTreeNode
 * JD-Core Version:    0.6.2
 */
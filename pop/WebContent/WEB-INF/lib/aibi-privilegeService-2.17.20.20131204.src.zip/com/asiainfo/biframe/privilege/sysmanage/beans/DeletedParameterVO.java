/*    */ package com.asiainfo.biframe.privilege.sysmanage.beans;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*    */ import com.asiainfo.biframe.utils.string.StringUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class DeletedParameterVO extends SearchCondition
/*    */ {
/* 22 */   private Collection<String> ids = new ArrayList();
/*    */ 
/* 24 */   private boolean isIdString = true;
/*    */ 
/*    */   public String getIdString()
/*    */   {
/* 28 */     return StringUtil.list2String(this.ids, ",", this.isIdString);
/*    */   }
/*    */ 
/*    */   public Collection<String> getIds() {
/* 32 */     return this.ids;
/*    */   }
/*    */   public void setIds(Collection<String> ids) {
/* 35 */     this.ids = ids;
/*    */   }
/*    */ 
/*    */   public boolean isIdString() {
/* 39 */     return this.isIdString;
/*    */   }
/*    */   public void setIdString(boolean isIdString) {
/* 42 */     this.isIdString = isIdString;
/*    */   }
/*    */ 
/*    */   public String getWhereHql(String idName, DeletedParameterVO vo, String objectAlias)
/*    */   {
/* 54 */     StringBuilder sql = new StringBuilder(256);
/* 55 */     if (!vo.getIds().isEmpty()) {
/* 56 */       int cnt = 1;
/* 57 */       if (vo.getIds().size() > 1000) {
/* 58 */         int nDeep = 0;
/* 59 */         StringBuilder idValues = new StringBuilder(256);
/* 60 */         for (Iterator it = vo.getIds().iterator(); it.hasNext(); ) {
/* 61 */           if (this.isIdString)
/* 62 */             idValues.append("'").append(it.next()).append("',");
/*    */           else {
/* 64 */             idValues.append(it.next()).append(",");
/*    */           }
/* 66 */           cnt++;
/* 67 */           if (cnt > 1000) {
/* 68 */             if (nDeep == 0)
/* 69 */               sql.append(" and (");
/* 70 */             if (nDeep > 0)
/* 71 */               sql.append(" or ");
/* 72 */             sql.append(objectAlias).append(".").append(idName).append(" in (").append(idValues.substring(0, idValues.lastIndexOf(","))).append(")");
/*    */ 
/* 74 */             idValues = new StringBuilder(256);
/* 75 */             cnt = 1;
/* 76 */             nDeep++;
/*    */           }
/*    */         }
/* 79 */         if (StringUtils.isNotBlank(idValues.toString())) {
/* 80 */           if (nDeep == 0)
/* 81 */             sql.append(" and (");
/* 82 */           if (nDeep > 0)
/* 83 */             sql.append(" or ");
/* 84 */           sql.append(objectAlias).append(".").append(idName).append(" in (").append(idValues.substring(0, idValues.lastIndexOf(","))).append(")");
/*    */         }
/*    */ 
/* 87 */         sql.append(")");
/*    */       } else {
/* 89 */         sql.append(" and ").append(objectAlias).append(".").append(idName).append(" in (").append(vo.getIdString()).append(")");
/*    */       }
/*    */     }
/* 92 */     if ((StringUtils.isNotBlank(vo.getBeginDeleteTime())) && (StringUtils.isNotBlank(vo.getEndDeleteTime()))) {
/* 93 */       sql.append(" and ").append(objectAlias).append(".deleteTime >='").append(vo.getBeginDeleteTime()).append("'");
/* 94 */       sql.append(" and ").append(objectAlias).append(".deleteTime <='").append(vo.getEndDeleteTime()).append("'");
/*    */     }
/*    */ 
/* 97 */     return sql.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.sysmanage.comparator;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.UserRoleClassify;
/*    */ import java.text.Collator;
/*    */ import java.util.Comparator;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class ClassifyComparator
/*    */   implements Comparator<UserRoleClassify>
/*    */ {
/* 11 */   Comparator cmp = Collator.getInstance(Locale.CHINA);
/*    */ 
/*    */   public int compare(UserRoleClassify urc1, UserRoleClassify urc2) {
/* 14 */     if ((urc1 == null) || (urc2 == null)) {
/* 15 */       return -1;
/*    */     }
/* 17 */     return this.cmp.compare(urc1.getClassifyId(), urc2.getClassifyId());
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.comparator.ClassifyComparator
 * JD-Core Version:    0.6.2
 */
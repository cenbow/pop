/*    */ package com.asiainfo.biframe.privilege.sysmanage.comparator;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.User_Group;
/*    */ import java.text.Collator;
/*    */ import java.util.Comparator;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class GroupComparator
/*    */   implements Comparator<User_Group>
/*    */ {
/* 19 */   Comparator cmp = Collator.getInstance(Locale.CHINA);
/*    */ 
/*    */   public int compare(User_Group o1, User_Group o2) {
/* 22 */     if ((o1 == null) || (o2 == null)) {
/* 23 */       return -1;
/*    */     }
/*    */ 
/* 26 */     User_Group group1 = o1;
/* 27 */     User_Group group2 = o2;
/* 28 */     return this.cmp.compare(group1.getGroupname(), group2.getGroupname());
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.comparator.GroupComparator
 * JD-Core Version:    0.6.2
 */
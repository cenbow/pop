/*    */ package com.asiainfo.biframe.privilege.sysmanage.comparator;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.UserCityDmType;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class UserCityDmTypeComparator
/*    */   implements Comparator<UserCityDmType>
/*    */ {
/*    */   public int compare(UserCityDmType o1, UserCityDmType o2)
/*    */   {
/* 19 */     if ((o1 == null) || (o2 == null)) {
/* 20 */       return -1;
/*    */     }
/*    */ 
/* 23 */     UserCityDmType userCityDmType1 = o1;
/* 24 */     UserCityDmType userCityDmType2 = o2;
/* 25 */     return userCityDmType1.getDmLevel() - userCityDmType2.getDmLevel();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.comparator.UserCityDmTypeComparator
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.sysmanage.comparator;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.User_User;
/*    */ import java.text.Collator;
/*    */ import java.util.Comparator;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class UserComparator
/*    */   implements Comparator<User_User>
/*    */ {
/* 19 */   Comparator cmp = Collator.getInstance(Locale.CHINA);
/*    */ 
/*    */   public int compare(User_User o1, User_User o2) {
/* 22 */     if ((o1 == null) || (o2 == null)) {
/* 23 */       return -1;
/*    */     }
/*    */ 
/* 26 */     User_User user1 = o1;
/* 27 */     User_User user2 = o2;
/* 28 */     return this.cmp.compare(user1.getUsername(), user2.getUsername());
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.comparator.UserComparator
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.sysmanage.constants;

import com.asiainfo.biframe.privilege.sysmanage.util.SysManageConstants;

public class CompanyConstants extends SysManageConstants
{
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.constants.CompanyConstants
 * JD-Core Version:    0.6.2
 */
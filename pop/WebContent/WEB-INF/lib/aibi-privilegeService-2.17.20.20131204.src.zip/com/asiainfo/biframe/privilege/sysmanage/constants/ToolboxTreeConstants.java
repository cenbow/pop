package com.asiainfo.biframe.privilege.sysmanage.constants;

public class ToolboxTreeConstants
{
  public static final String GROUP_DIRECT_SUBGROUP = "GROUP_DIRECT_SUBGROUP";
  public static final String QUERY_ALL = "-1";
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.constants.ToolboxTreeConstants
 * JD-Core Version:    0.6.2
 */
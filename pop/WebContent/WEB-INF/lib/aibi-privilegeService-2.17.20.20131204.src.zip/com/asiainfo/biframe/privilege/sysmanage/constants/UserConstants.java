/*    */ package com.asiainfo.biframe.privilege.sysmanage.constants;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.TreeMap;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class UserConstants
/*    */ {
/*    */   public static final String STATUS_NORMAL = "0";
/*    */   public static final String STATUS_LOCKED = "1";
/*    */   public static final String STATUS_DELETE = "2";
/*    */   public static final String DOMAIN_TYPE = "1";
/*    */   public static final String SENSITIVE_LEVEL_A = "A";
/*    */   public static final String SENSITIVE_LEVEL_B = "B";
/*    */   public static final String SENSITIVE_LEVEL_C = "C";
/*    */   public static final String SENSITIVE_LEVEL_D = "D";
/* 54 */   public static Map<String, String> sensitiveDataLevelMap = new TreeMap();
/*    */ 
/*    */   public static Map<String, String> putStatusMap()
/*    */   {
/* 30 */     Map map = new HashMap();
/* 31 */     map.put("0", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.normal") + "");
/* 32 */     map.put("1", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.locked") + "");
/* 33 */     return map;
/*    */   }
/*    */ 
/*    */   public static String getStatusDesc(String status) {
/* 37 */     if (StringUtils.isBlank(status)) {
/* 38 */       return "";
/*    */     }
/* 40 */     if ("0".equals(status))
/* 41 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.normal");
/* 42 */     if ("1".equals(status)) {
/* 43 */       return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.locked");
/*    */     }
/* 45 */     return "";
/*    */   }
/*    */ 
/*    */   private static void putSensitiveLevelMap()
/*    */   {
/* 57 */     sensitiveDataLevelMap.put("A", "A" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.levelA") + "");
/* 58 */     sensitiveDataLevelMap.put("B", "B" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.levelB") + "");
/* 59 */     sensitiveDataLevelMap.put("C", "C" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.levelC") + "");
/* 60 */     sensitiveDataLevelMap.put("D", "D" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.levelD") + "");
/*    */   }
/*    */ 
/*    */   public static String getSensitiveLevelDesc(String senLevel) {
/* 64 */     if (StringUtils.isBlank(senLevel)) {
/* 65 */       return "";
/*    */     }
/* 67 */     String desc = (String)sensitiveDataLevelMap.get(senLevel);
/* 68 */     if (desc == null) {
/* 69 */       return "";
/*    */     }
/* 71 */     return desc;
/*    */   }
/*    */ 
/*    */   public static boolean isSenLevelLegal(String senLevel)
/*    */   {
/* 76 */     if (("A".equals(senLevel)) || ("B".equals(senLevel)) || ("C".equals(senLevel)) || ("D".equals(senLevel)))
/*    */     {
/* 78 */       return true;
/*    */     }
/* 80 */     return false;
/*    */   }
/*    */ 
/*    */   static {
/* 84 */     putStatusMap();
/* 85 */     putSensitiveLevelMap();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.constants.UserConstants
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.sysmanage.constants;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class UserUserMapConstants
/*    */ {
/*    */   public static final String RESOURCETYPE_TEMPRIGHT = "0";
/* 22 */   public static Map<String, String> resourceTypeMap = new HashMap();
/*    */   public static final String RELATIONTYPE_SUPERIOR = "0";
/* 44 */   public static Map<String, String> relationTypeMap = new HashMap();
/*    */ 
/*    */   private static void putResourceTypeMap()
/*    */   {
/* 25 */     resourceTypeMap.put("0", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.tempRight") + "");
/*    */   }
/*    */ 
/*    */   public static String getResourceTypeDesc(String resourceType) {
/* 29 */     if (StringUtils.isBlank(resourceType)) {
/* 30 */       return "";
/*    */     }
/* 32 */     String desc = (String)resourceTypeMap.get(resourceType);
/* 33 */     if (desc == null) {
/* 34 */       return "";
/*    */     }
/* 36 */     return desc;
/*    */   }
/*    */ 
/*    */   private static void putRelationTypeMap()
/*    */   {
/* 47 */     relationTypeMap.put("0", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.superior") + "");
/*    */   }
/*    */ 
/*    */   public static String getRelationTypeDesc(String relationType) {
/* 51 */     if (StringUtils.isBlank(relationType)) {
/* 52 */       return "";
/*    */     }
/* 54 */     String desc = (String)relationTypeMap.get(relationType);
/* 55 */     if (desc == null) {
/* 56 */       return "";
/*    */     }
/* 58 */     return desc;
/*    */   }
/*    */ 
/*    */   static {
/* 62 */     putResourceTypeMap();
/* 63 */     putRelationTypeMap();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.constants.UserUserMapConstants
 * JD-Core Version:    0.6.2
 */
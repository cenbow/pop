package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.exception.DaoException;
import java.util.List;
import org.apache.struts.util.LabelValueBean;

public abstract interface IBusiParametersDao
{
  public abstract List<LabelValueBean> getBusiParametersByType(String paramString)
    throws DaoException;

  public abstract String getParaName(String paramString1, String paramString2)
    throws DaoException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IBusiParametersDao
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.User_Company;
import com.asiainfo.biframe.privilege.model.User_User;
import java.util.List;

public abstract interface IDeptMangerDao
{
  public abstract User_Company getDeptInfo(int paramInt);

  public abstract void saveDeptInfo(User_Company paramUser_Company);

  public abstract void updateDeptInfo(User_Company paramUser_Company);

  public abstract List<User_User> getUserByDeptId(String paramString);

  public abstract List<User_User> getUserByGroupId(String paramString);

  public abstract void updateUserDeptInfo(String paramString1, String paramString2);

  public abstract int getDeptCountWithSameTitle(String paramString1, String paramString2, String paramString3);

  public abstract List<User_Company> getAllTopLevelDept(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IDeptMangerDao
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.FirstpagesetParam;
import java.util.List;

public abstract interface IFirstPageParamDAO
{
  public abstract boolean savePageSet(FirstpagesetParam paramFirstpagesetParam);

  public abstract boolean deletePageSet(String paramString);

  public abstract FirstpagesetParam getPageSet(String paramString);

  public abstract List<FirstpagesetParam> getAllPageSet();

  public abstract boolean isHavePageSet(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IFirstPageParamDAO
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.IGroupRoleMap;
import com.asiainfo.biframe.privilege.model.GroupRoleMap;
import com.asiainfo.biframe.privilege.model.UserRole;
import com.asiainfo.biframe.privilege.model.User_Group;
import com.asiainfo.biframe.privilege.model.User_User;
import java.util.List;

public abstract interface IGroupRoleMapDAO
{
  public abstract void save(GroupRoleMap paramGroupRoleMap);

  public abstract void delete(GroupRoleMap paramGroupRoleMap);

  public abstract void deleteMapByGId(String paramString);

  public abstract void deleteMapByRId(String paramString);

  public abstract GroupRoleMap findById(GroupRoleMap paramGroupRoleMap);

  public abstract List<GroupRoleMap> findAllbyRId(String paramString);

  public abstract List<GroupRoleMap> findGroupRoleMapByGroupId(String paramString);

  public abstract List<String> findRoleIdListByGroupId(String paramString);

  /** @deprecated */
  public abstract List<String> findRoleIdListByGroupId(String paramString, int paramInt1, int paramInt2);

  public abstract List<UserRole> findRoleListByGroupId(String paramString);

  /** @deprecated */
  public abstract List<UserRole> findRoleListByGroupId(String paramString, int paramInt1, int paramInt2);

  public abstract void deleteMapList(List paramList);

  public abstract List<User_Group> findGroupsByRoleId(String paramString);

  public abstract List<User_User> findUsersByRoleId(String paramString);

  public abstract List<IGroupRoleMap> getGroupRoleMapList()
    throws ServiceException;

  public abstract void saveGroupRoleMaps(List<IGroupRoleMap> paramList)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IGroupRoleMapDAO
 * JD-Core Version:    0.6.2
 */
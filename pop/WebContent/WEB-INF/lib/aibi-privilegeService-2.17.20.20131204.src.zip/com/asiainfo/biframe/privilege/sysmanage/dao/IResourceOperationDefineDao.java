package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.exception.DaoException;
import com.asiainfo.biframe.privilege.model.ResourceOperationDefine;
import java.util.List;

public abstract interface IResourceOperationDefineDao
{
  public abstract List<ResourceOperationDefine> getDefineListBy(int paramInt)
    throws DaoException;

  public abstract ResourceOperationDefine getOperationDefineBy(String paramString, int paramInt)
    throws DaoException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IResourceOperationDefineDao
 * JD-Core Version:    0.6.2
 */
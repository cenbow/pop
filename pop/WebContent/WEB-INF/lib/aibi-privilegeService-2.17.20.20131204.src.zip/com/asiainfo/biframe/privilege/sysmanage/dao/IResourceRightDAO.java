package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.sysmanage.model.Right;
import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
import java.util.Collection;
import java.util.List;

public abstract interface IResourceRightDAO
{
  public abstract String getDefineTable();

  public abstract String getIdField();

  public abstract String getDescField();

  public abstract String getResourceName(String paramString);

  public abstract List<String> getAllParentIds(String paramString);

  public abstract void save(RoleRight paramRoleRight);

  public abstract void save(Collection<RoleRight> paramCollection);

  public abstract void delete(String paramString, int paramInt);

  public abstract void delete(Collection<RoleRight> paramCollection);

  public abstract void delete(List<String> paramList, List<Right> paramList1, int paramInt);

  public abstract RoleRight getRoleRight(String paramString1, int paramInt, String paramString2, String paramString3);

  public abstract List<Right> getRightList(String paramString, int paramInt, boolean paramBoolean);

  public abstract List<Right> getRightList(List<String> paramList, int paramInt, boolean paramBoolean);

  public abstract List<Right> getAllRightList(int paramInt1, int paramInt2);

  public abstract List<RoleRight> getRoleRightListByRight(Right paramRight);

  public abstract List<RoleRight> getRoleRightListByRole(String paramString, int paramInt);

  public abstract void updateControlType(String paramString1, int paramInt, String paramString2, String paramString3);

  public abstract List<Right> getAllRightList(String paramString, int paramInt);

  public abstract List<Right> getAllRightList(String paramString);

  public abstract Right getRight(String paramString);

  public abstract boolean isExistRoleRight(String paramString1, String paramString2, int paramInt, String paramString3);

  public abstract List<Right> getUserRightList(String paramString, int paramInt1, int paramInt2, boolean paramBoolean);

  public abstract void deleteRight(String paramString1, int paramInt1, int paramInt2, String paramString2);

  public abstract void initDaoParameter(int paramInt);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.SysMenuItem;
import com.asiainfo.biframe.privilege.model.SysMenuItemRela;
import java.util.List;
import java.util.Map;

public abstract interface ISysMenuItemDao
{
  public abstract SysMenuItem findById(Integer paramInteger);

  public abstract List<SysMenuItem> findByParentId(Integer paramInteger);

  public abstract void deleteById(Integer paramInteger);

  public abstract List<SysMenuItem> findByResId(String paramString);

  public abstract void delete(SysMenuItem paramSysMenuItem);

  public abstract void deleteAll(List<SysMenuItem> paramList);

  public abstract Integer save(SysMenuItem paramSysMenuItem);

  public abstract List<SysMenuItem> findByResId(String paramString, Integer paramInteger);

  public abstract void modify(SysMenuItem paramSysMenuItem);

  public abstract List<SysMenuItem> getMenuItemList(Map<String, String> paramMap);

  public abstract void save(SysMenuItemRela paramSysMenuItemRela);

  public abstract void delSysMenuItemRela(Integer paramInteger);

  public abstract SysMenuItemRela getMenuRela(Integer paramInteger1, Integer paramInteger2);

  public abstract List<SysMenuItemRela> getMenu(Integer paramInteger);

  public abstract SysMenuItem getMenu(Integer paramInteger1, Integer paramInteger2);

  public abstract void deleteMenuRela(SysMenuItemRela paramSysMenuItemRela);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.ISysMenuItemDao
 * JD-Core Version:    0.6.2
 */
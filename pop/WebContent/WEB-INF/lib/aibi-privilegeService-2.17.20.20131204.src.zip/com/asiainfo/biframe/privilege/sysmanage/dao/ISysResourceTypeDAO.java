package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.SysResourceType;
import java.util.List;

public abstract interface ISysResourceTypeDAO
{
  public abstract SysResourceType findById(SysResourceType paramSysResourceType);

  public abstract List<SysResourceType> findAll();

  public abstract String findResourceKey(int paramInt1, int paramInt2);

  public abstract SysResourceType findSysResType(int paramInt1, int paramInt2);

  public abstract List<SysResourceType> findByResourceType(int paramInt);

  public abstract List<SysResourceType> getSysTypeListByName(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.ISysResourceTypeDAO
 * JD-Core Version:    0.6.2
 */
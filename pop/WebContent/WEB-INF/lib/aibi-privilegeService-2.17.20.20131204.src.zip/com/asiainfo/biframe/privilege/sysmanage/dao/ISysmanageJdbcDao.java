package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.sysmanage.model.Right;
import java.util.List;

public abstract interface ISysmanageJdbcDao
{
  public abstract void deleteUserOtherMsg(String paramString);

  public abstract String getRptFileTree(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, String paramString3, List paramList, String paramString4, boolean paramBoolean3, String paramString5);

  public abstract String getIrIndiTree(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, String paramString3, List paramList, String paramString4, boolean paramBoolean3, String paramString5);

  public abstract void saveRptFileRight(String paramString, List paramList1, List paramList2, List paramList3, List paramList4);

  public abstract void saveIndiRight(String paramString, List<String> paramList, List<Right> paramList1, List<Right> paramList2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.ISysmanageJdbcDao
 * JD-Core Version:    0.6.2
 */
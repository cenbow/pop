package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.menu.TreeItem;
import java.util.List;

public abstract interface ITreeItemDao
{
  public abstract List<TreeItem> getTopSysMenuItems();

  public abstract List<TreeItem> getSubSysMenuItems(Integer paramInteger, String paramString);

  public abstract TreeItem getMenuById(Integer paramInteger);

  public abstract List<TreeItem> getAllSysMenuItems(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.ITreeItemDao
 * JD-Core Version:    0.6.2
 */
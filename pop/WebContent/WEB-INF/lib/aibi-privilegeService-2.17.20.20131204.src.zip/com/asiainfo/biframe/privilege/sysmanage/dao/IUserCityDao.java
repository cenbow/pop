package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.ICity;
import com.asiainfo.biframe.privilege.model.User_City;
import java.util.List;

public abstract interface IUserCityDao
{
  public abstract User_City getCityById(String paramString);

  public abstract List<User_City> getCityByName(String paramString);

  public abstract List<ICity> getAllCity();

  public abstract List<User_City> getCityByParentId(String paramString);

  public abstract List<User_City> getParentCityByChildId(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserCityDao
 * JD-Core Version:    0.6.2
 */
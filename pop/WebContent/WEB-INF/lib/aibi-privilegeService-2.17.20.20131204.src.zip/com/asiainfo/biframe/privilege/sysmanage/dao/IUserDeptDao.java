package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.IUserCompany;
import com.asiainfo.biframe.privilege.model.User_Company;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import java.util.List;
import java.util.Map;

public abstract interface IUserDeptDao
{
  public abstract User_Company getDeptById(String paramString)
    throws Exception;

  public abstract List<IUserCompany> getDeptAll()
    throws Exception;

  public abstract List<User_Company> getCompanyByName(String paramString);

  public abstract Map getpagedCompanyList(User_Company paramUser_Company, int paramInt1, int paramInt2);

  public abstract String doRealDelete(DeletedParameterVO paramDeletedParameterVO);

  public abstract String createCompany(IUserCompany paramIUserCompany)
    throws ServiceException;

  public abstract void deleteCompany(String paramString)
    throws ServiceException;

  public abstract void modifyCompany(IUserCompany paramIUserCompany)
    throws ServiceException;

  public abstract List<IUserCompany> getCompanyListByParentId(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserDeptDao
 * JD-Core Version:    0.6.2
 */
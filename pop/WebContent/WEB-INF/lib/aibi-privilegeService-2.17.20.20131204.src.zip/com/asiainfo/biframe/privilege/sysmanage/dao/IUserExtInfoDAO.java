package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.UserExtInfo;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import java.util.Collection;
import java.util.List;

public abstract interface IUserExtInfoDAO
{
  public abstract void save(UserExtInfo paramUserExtInfo)
    throws Exception;

  public abstract void update(UserExtInfo paramUserExtInfo)
    throws Exception;

  public abstract void saveOrUpdateAll(Collection<UserExtInfo> paramCollection)
    throws Exception;

  public abstract void delete(UserExtInfo paramUserExtInfo)
    throws Exception;

  public abstract void delete(DeletedParameterVO paramDeletedParameterVO);

  public abstract List<UserExtInfo> findByUserId(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserExtInfoDAO
 * JD-Core Version:    0.6.2
 */
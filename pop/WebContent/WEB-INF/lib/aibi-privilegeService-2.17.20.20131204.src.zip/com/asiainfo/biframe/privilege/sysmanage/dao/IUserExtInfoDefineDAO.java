package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.UserExtInfoDefine;
import java.util.List;

public abstract interface IUserExtInfoDefineDAO
{
  public abstract void save(UserExtInfoDefine paramUserExtInfoDefine)
    throws Exception;

  public abstract void update(UserExtInfoDefine paramUserExtInfoDefine)
    throws Exception;

  public abstract void delete(UserExtInfoDefine paramUserExtInfoDefine)
    throws Exception;

  public abstract List<UserExtInfoDefine> findAll();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserExtInfoDefineDAO
 * JD-Core Version:    0.6.2
 */
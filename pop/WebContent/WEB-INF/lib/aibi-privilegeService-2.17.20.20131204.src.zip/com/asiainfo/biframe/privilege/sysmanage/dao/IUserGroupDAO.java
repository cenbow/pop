package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.IUserGroup;
import com.asiainfo.biframe.privilege.model.User_Group;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import java.util.List;
import java.util.Map;

public abstract interface IUserGroupDAO
{
  public abstract String save(User_Group paramUser_Group);

  public abstract void update(User_Group paramUser_Group);

  public abstract void delete(User_Group paramUser_Group);

  public abstract User_Group findById(String paramString);

  public abstract List<User_Group> findAll(User_Group paramUser_Group);

  public abstract Map getPagedUserList(User_Group paramUser_Group, int paramInt1, int paramInt2);

  public abstract String getGroupName(String paramString);

  public abstract User_Group getUserGroup(String paramString);

  public abstract List<IUserGroup> getAllUserGroupList();

  public abstract List<User_Group> findAllByGroupIdList(List<String> paramList);

  public abstract List<User_Group> findByGroupName(String paramString);

  public abstract String doRealDelete(DeletedParameterVO paramDeletedParameterVO);

  public abstract List<IUserGroup> getValidChildGroups(String paramString);

  public abstract List getUserGroupByTime(String paramString1, String paramString2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupDAO
 * JD-Core Version:    0.6.2
 */
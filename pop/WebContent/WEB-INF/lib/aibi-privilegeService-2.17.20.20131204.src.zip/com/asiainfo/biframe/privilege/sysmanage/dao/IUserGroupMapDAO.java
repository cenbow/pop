package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.IUserGroup;
import com.asiainfo.biframe.privilege.model.UserGroupMap;
import com.asiainfo.biframe.privilege.model.User_Group;
import com.asiainfo.biframe.privilege.model.User_User;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import java.util.List;

public abstract interface IUserGroupMapDAO
{
  public abstract void save(UserGroupMap paramUserGroupMap);

  public abstract void delete(UserGroupMap paramUserGroupMap);

  public abstract List<User_User> findAllUserByGId(String paramString);

  public abstract List<User_Group> getGroupByUserId(String paramString);

  public abstract void deleteMapByGId(String paramString);

  public abstract void deleteMapByUserId(String paramString);

  public abstract List<User_User> getAllByGroupId(String paramString);

  public abstract void deleteMapList(List paramList);

  public abstract void doRealDelete(DeletedParameterVO paramDeletedParameterVO);

  public abstract List<IUserGroup> getGroupByUserId(List<String> paramList);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupMapDAO
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.UserOperationDefine;
import java.util.List;

public abstract interface IUserOperationDefineDao
{
  public abstract List<String> getUserOperDef(int paramInt);

  public abstract List<UserOperationDefine> getUserOperDefByName(String paramString, int paramInt);

  public abstract List<UserOperationDefine> getAllUserOperDef();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserOperationDefineDao
 * JD-Core Version:    0.6.2
 */
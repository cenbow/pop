package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.IUserRole;
import com.asiainfo.biframe.privilege.model.UserRole;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import java.util.List;
import java.util.Map;

public abstract interface IUserRoleDAO
{
  public abstract String save(UserRole paramUserRole);

  public abstract void update(UserRole paramUserRole);

  public abstract void delete(UserRole paramUserRole);

  public abstract UserRole findById(String paramString);

  public abstract List<UserRole> findByIdList(List<String> paramList);

  public abstract List<UserRole> findAllRoles();

  public abstract List<IUserRole> getAllRoles();

  public abstract List<UserRole> getUserRoleList(UserRole paramUserRole);

  public abstract List<UserRole> getRoleListByName(String paramString);

  public abstract List<UserRole> findByCreateGroup(String paramString);

  /** @deprecated */
  public abstract List<UserRole> findByCreateGroup(String paramString, int paramInt);

  public abstract List<UserRole> findByCreateGroupList(List<String> paramList);

  public abstract Map getPagedRoleList(UserRole paramUserRole, int paramInt1, int paramInt2);

  public abstract void doRealDeleteByCreateGroup(DeletedParameterVO paramDeletedParameterVO);

  public abstract List doRealDelete(DeletedParameterVO paramDeletedParameterVO);

  public abstract List getUserRoleByTime(String paramString1, String paramString2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleDAO
 * JD-Core Version:    0.6.2
 */
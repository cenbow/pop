package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.UserRole;
import com.asiainfo.biframe.privilege.model.UserRoleMap;
import com.asiainfo.biframe.privilege.model.User_User;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import java.util.List;

public abstract interface IUserRoleMapDAO
{
  public abstract void save(UserRoleMap paramUserRoleMap);

  public abstract void delete(UserRoleMap paramUserRoleMap);

  public abstract void deleteMapByRId(String paramString);

  public abstract void deleteMapByUserId(String paramString);

  public abstract void delete(DeletedParameterVO paramDeletedParameterVO);

  public abstract List<UserRoleMap> findAllByRId(String paramString);

  public abstract List<UserRoleMap> getUserRoleMapsByUserId(String paramString);

  public abstract List<UserRole> getRolesByUserId(String paramString);

  public abstract List<User_User> getUsersByRoleId(String paramString);

  public abstract void deleteMapList(List paramList);

  public abstract UserRoleMap getById(UserRoleMap paramUserRoleMap);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleMapDAO
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.exception.DaoException;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.model.User_User;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
import java.util.List;
import java.util.Map;

public abstract interface IUserUserDAO
{
  public abstract void save(User_User paramUser_User)
    throws Exception;

  public abstract void update(User_User paramUser_User)
    throws Exception;

  public abstract void delete(User_User paramUser_User)
    throws Exception;

  public abstract User_User findById(String paramString);

  public abstract List<User_User> findAll(SearchCondition paramSearchCondition);

  public abstract List findByName(String paramString);

  public abstract Map getPagedUserList(SearchCondition paramSearchCondition, int paramInt1, int paramInt2);

  public abstract boolean isSysUser(String paramString);

  public abstract List<IUser> listUsers();

  public abstract User_User getSysUserInfo(String paramString);

  public abstract boolean isSameSysUserName(String paramString);

  public abstract List listUsersOfDepart(int paramInt);

  public abstract String doRealDelete(DeletedParameterVO paramDeletedParameterVO);

  public abstract void updateSensitiveLevel(List<String> paramList, String paramString)
    throws DaoException;

  public abstract void backupUser(String paramString);

  public abstract List getUserByTime(String paramString1, String paramString2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserDAO
 * JD-Core Version:    0.6.2
 */
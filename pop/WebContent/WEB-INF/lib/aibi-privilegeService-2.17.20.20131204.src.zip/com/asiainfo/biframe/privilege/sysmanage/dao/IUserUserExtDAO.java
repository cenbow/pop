package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.UserUserExt;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;

public abstract interface IUserUserExtDAO
{
  public abstract void save(UserUserExt paramUserUserExt)
    throws Exception;

  public abstract void update(UserUserExt paramUserUserExt)
    throws Exception;

  public abstract void delete(UserUserExt paramUserUserExt)
    throws Exception;

  public abstract UserUserExt findById(String paramString);

  public abstract void doRealDelete(DeletedParameterVO paramDeletedParameterVO);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserExtDAO
 * JD-Core Version:    0.6.2
 */
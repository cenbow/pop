package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.exception.DaoException;
import com.asiainfo.biframe.privilege.model.UserUserMap;
import com.asiainfo.biframe.privilege.model.User_User;
import java.util.List;

public abstract interface IUserUserMapDAO
{
  public abstract void save(UserUserMap paramUserUserMap);

  public abstract void delete(UserUserMap paramUserUserMap);

  public abstract void deleteMapByUId(String paramString);

  public abstract void deleteMappedByUId(String paramString);

  public abstract List<UserUserMap> findAllOrById(UserUserMap paramUserUserMap);

  public abstract void deleteMapList(List<UserUserMap> paramList);

  public abstract List getDistinctResourceType(String paramString);

  public abstract List<Long> getDistinctResourceType1(String paramString);

  public abstract UserUserMap getByPK(UserUserMap paramUserUserMap)
    throws DaoException;

  public abstract List<User_User> getUsersByUserMap(String paramString1, int paramInt, String paramString2)
    throws DaoException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserMapDAO
 * JD-Core Version:    0.6.2
 */
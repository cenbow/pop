package com.asiainfo.biframe.privilege.sysmanage.dao;

import com.asiainfo.biframe.privilege.model.Prefer_Define;
import java.util.List;

public abstract interface IUserUserPreferDefineDAO
{
  public abstract void save(Prefer_Define paramPrefer_Define)
    throws Exception;

  public abstract void update(Prefer_Define paramPrefer_Define)
    throws Exception;

  public abstract List findAll();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserPreferDefineDAO
 * JD-Core Version:    0.6.2
 */
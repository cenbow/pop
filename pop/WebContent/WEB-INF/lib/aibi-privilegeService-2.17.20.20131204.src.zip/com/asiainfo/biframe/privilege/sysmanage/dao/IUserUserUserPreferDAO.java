package com.asiainfo.biframe.privilege.sysmanage.dao;

import java.util.List;

public abstract interface IUserUserUserPreferDAO
{
  public abstract List findAll(String paramString1, String paramString2);

  public abstract void save(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract List<String> getPreferDescListByPreferType(String paramString1, String paramString2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserUserPreferDAO
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.DaoException;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IBusiParametersDao;
/*    */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*    */ import com.asiainfo.biframe.utils.database.jdbc.SqlcaPst;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class BusiParametersDaoImpl extends HibernateDaoSupport
/*    */   implements IBusiParametersDao
/*    */ {
/* 21 */   private static final Log log = LogFactory.getLog(BusiParametersDaoImpl.class);
/*    */ 
/*    */   public List<LabelValueBean> getBusiParametersByType(String parameterType)
/*    */     throws DaoException
/*    */   {
/* 26 */     List list = new ArrayList();
/* 27 */     String sql = " select * from BUSI_PARAMETERS where PARAMETER_TYPE = ? ";
/* 28 */     SqlcaPst sqlcaPst = null;
/*    */     try {
/* 30 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/* 31 */       sqlcaPst.setSql(sql);
/* 32 */       sqlcaPst.setString(1, parameterType);
/* 33 */       sqlcaPst.execute();
/* 34 */       while (sqlcaPst.next()) {
/* 35 */         String paraName = sqlcaPst.getString("PARAMETER_NAME");
/* 36 */         String paraValue = sqlcaPst.getString("PARAMETER_VALUE");
/* 37 */         LabelValueBean lvb = new LabelValueBean();
/* 38 */         lvb.setLabel(paraName);
/* 39 */         lvb.setValue(paraValue);
/* 40 */         list.add(lvb);
/*    */       }
/*    */ 
/* 50 */       if (null != sqlcaPst)
/* 51 */         sqlcaPst.closeAll();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 43 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getOperParaFail") + "", e);
/*    */ 
/* 46 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getOperParaFail") + "", e);
/*    */     }
/*    */     finally
/*    */     {
/* 50 */       if (null != sqlcaPst) {
/* 51 */         sqlcaPst.closeAll();
/*    */       }
/*    */     }
/* 54 */     return list;
/*    */   }
/*    */ 
/*    */   public String getParaName(String parameterType, String parameterValue) throws DaoException
/*    */   {
/* 59 */     String sql = " select * from BUSI_PARAMETERS where PARAMETER_TYPE = ? and PARAMETER_VALUE = ?";
/*    */ 
/* 61 */     SqlcaPst sqlcaPst = null;
/*    */     try {
/* 63 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/* 64 */       sqlcaPst.setSql(sql);
/* 65 */       sqlcaPst.setString(1, parameterType);
/* 66 */       sqlcaPst.setString(2, parameterValue);
/* 67 */       sqlcaPst.execute();
/* 68 */       if (sqlcaPst.next()) {
/* 69 */         String paraName = sqlcaPst.getString("PARAMETER_NAME");
/* 70 */         return paraName;
/*    */       }
/*    */ 
/* 80 */       if (null != sqlcaPst)
/* 81 */         sqlcaPst.closeAll();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 73 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getOperParaFail") + "", e);
/*    */ 
/* 76 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getOperParaFail") + "", e);
/*    */     }
/*    */     finally
/*    */     {
/* 80 */       if (null != sqlcaPst) {
/* 81 */         sqlcaPst.closeAll();
/*    */       }
/*    */     }
/* 84 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.BusiParametersDaoImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.model.User_Company;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IDeptMangerDao;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class DeptMangerDaoImpl extends HibernateDaoSupport
/*     */   implements IDeptMangerDao
/*     */ {
/*     */   public User_Company getDeptInfo(int deptId)
/*     */   {
/*  28 */     User_Company user_Company = (User_Company)getHibernateTemplate().get(User_Company.class, Integer.valueOf(deptId));
/*  29 */     return user_Company;
/*     */   }
/*     */ 
/*     */   public void saveDeptInfo(User_Company userCompany)
/*     */   {
/*  37 */     if (userCompany == null) {
/*  38 */       return;
/*     */     }
/*  40 */     if ((userCompany.getDeptid() == null) || ("".equals(userCompany.getDeptid()))) {
/*  41 */       userCompany.setDeptid(Integer.valueOf(getDeptId()));
/*  42 */       userCompany.setStatus("0");
/*  43 */       userCompany.setSortNum(Integer.valueOf(999));
/*  44 */       userCompany.setParentid(Integer.valueOf("0"));
/*     */     }
/*  46 */     getHibernateTemplate().save(userCompany);
/*     */   }
/*     */ 
/*     */   public void updateDeptInfo(User_Company userCompany)
/*     */   {
/*  55 */     getHibernateTemplate().update(userCompany);
/*     */   }
/*     */ 
/*     */   public List<User_User> getUserByDeptId(String deptId)
/*     */   {
/*  65 */     List list = null;
/*  66 */     if ((deptId != null) && (!"".equals(deptId))) {
/*  67 */       list = getHibernateTemplate().find("from User_User a where a.departmentid=?", Integer.valueOf(Integer.parseInt(deptId)));
/*     */     }
/*  69 */     return list;
/*     */   }
/*     */ 
/*     */   public int getDeptCountWithSameTitle(String deptId, String title, String parentid)
/*     */   {
/*  77 */     int retCount = 0;
/*  78 */     List list = null;
/*     */ 
/*  80 */     if ((StringUtil.isEmpty(title)) && (StringUtil.isEmpty(parentid))) {
/*  81 */       return retCount;
/*     */     }
/*  83 */     String hql = "from User_Company a where 1=1 and a.title =? and parentid=? ";
/*  84 */     List params = new ArrayList();
/*  85 */     params.add(title);
/*  86 */     params.add(Integer.valueOf(Integer.parseInt(parentid)));
/*     */ 
/*  88 */     if (StringUtil.isNotEmpty(deptId)) {
/*  89 */       hql = hql + " and a.deptid!=? ";
/*  90 */       params.add(Integer.valueOf(Integer.parseInt(deptId)));
/*     */     }
/*     */ 
/*  93 */     list = getHibernateTemplate().find(hql, params.toArray());
/*  94 */     if (list != null) {
/*  95 */       retCount = list.size();
/*     */     }
/*  97 */     return retCount;
/*     */   }
/*     */ 
/*     */   public List<User_User> getUserByGroupId(String groupId)
/*     */   {
/* 106 */     final String groupIdStr = groupId;
/* 107 */     return (List)getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/* 110 */         String sql = "select a.userid,a.username from user_user a ,user_group_map b where a.userid=b.userid and b.group_id='" + groupIdStr + "'";
/* 111 */         SQLQuery query = session.createSQLQuery(sql);
/* 112 */         List retList = null;
/* 113 */         List list = query.list();
/*     */         User_User user;
/* 114 */         if ((list != null) && (list.size() > 0)) {
/* 115 */           retList = new ArrayList();
/* 116 */           user = null;
/* 117 */           for (Object[] object : list) {
/* 118 */             user = new User_User();
/* 119 */             user.setUserid(object[0].toString());
/* 120 */             user.setUsername(object[1].toString());
/* 121 */             retList.add(user);
/*     */           }
/*     */         }
/* 124 */         session.close();
/* 125 */         return retList;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private int getDeptId()
/*     */   {
/* 135 */     return Integer.parseInt(getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/* 138 */         String sql = "select max(deptid)+1 as deptid from user_company";
/* 139 */         SQLQuery query = session.createSQLQuery(sql).addScalar("deptid", Hibernate.STRING);
/* 140 */         List list = query.list();
/* 141 */         String deptId = "1";
/* 142 */         if ((list != null) && (list.size() > 0)) {
/* 143 */           deptId = list.get(0).toString();
/*     */         }
/* 145 */         session.close();
/* 146 */         return deptId;
/*     */       }
/*     */     }).toString());
/*     */   }
/*     */ 
/*     */   public void updateUserDeptInfo(String deptId, String userStr)
/*     */   {
/* 157 */     if ((deptId == null) || ("".equals(deptId))) {
/* 158 */       return;
/*     */     }
/* 160 */     if ((userStr == null) || ("".equals(userStr)) || (userStr.length() < 1)) {
/* 161 */       return;
/*     */     }
/* 163 */     String[] userIds = userStr.split("!#!");
/* 164 */     StringBuffer tempSql = new StringBuffer();
/* 165 */     for (String itemId : userIds) {
/* 166 */       tempSql = tempSql.append("'").append(itemId).append("'").append(",");
/*     */     }
/* 168 */     StringBuffer sql = new StringBuffer();
/* 169 */     sql.append("update user_user a set a.departmentid =").append(deptId);
/* 170 */     sql.append(" where 1=1 ");
/* 171 */     if (tempSql.length() > 0) {
/* 172 */       sql.append(" and a.userid in (").append(tempSql.substring(0, tempSql.length() - 1)).append(")");
/*     */     }
/* 174 */     final String sqlq = sql.toString();
/* 175 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException
/*     */       {
/* 179 */         SQLQuery query = session.createSQLQuery(sqlq);
/* 180 */         query.executeUpdate();
/* 181 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List<User_Company> getAllTopLevelDept(String topLevelParentId)
/*     */   {
/* 192 */     List list = null;
/* 193 */     if (StringUtil.isNotEmpty(topLevelParentId)) {
/* 194 */       list = getHibernateTemplate().find("from User_Company a where a.parentid=?", Integer.valueOf(Integer.parseInt(topLevelParentId)));
/*     */     }
/* 196 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.DeptMangerDaoImpl
 * JD-Core Version:    0.6.2
 */
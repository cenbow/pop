/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.FirstpagesetParam;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IFirstPageParamDAO;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class FirstPageParamDaoImpl extends HibernateDaoSupport
/*    */   implements IFirstPageParamDAO
/*    */ {
/* 17 */   private Log log = LogFactory.getLog(FirstPageParamDaoImpl.class);
/*    */ 
/*    */   public boolean savePageSet(FirstpagesetParam ps)
/*    */   {
/*    */     try
/*    */     {
/* 27 */       getHibernateTemplate().save(ps);
/* 28 */       return true;
/*    */     } catch (Exception e) {
/* 30 */       this.log.error("", e);
/* 31 */     }return false;
/*    */   }
/*    */ 
/*    */   public boolean deletePageSet(String roleId)
/*    */   {
/*    */     try
/*    */     {
/* 43 */       String hql = "from FirstpagesetParam fs where fs.operatorId='" + roleId + "'";
/* 44 */       Collection list = getHibernateTemplate().find(hql.toString());
/* 45 */       getHibernateTemplate().deleteAll(list);
/* 46 */       return true;
/*    */     } catch (Exception e) {
/* 48 */       this.log.error("", e);
/* 49 */     }return false;
/*    */   }
/*    */ 
/*    */   public FirstpagesetParam getPageSet(String roleId)
/*    */   {
/*    */     try
/*    */     {
/* 61 */       return (FirstpagesetParam)getHibernateTemplate().get(FirstpagesetParam.class, roleId);
/*    */     }
/*    */     catch (Exception e) {
/* 64 */       this.log.error("", e);
/* 65 */     }return null;
/*    */   }
/*    */ 
/*    */   public List<FirstpagesetParam> getAllPageSet()
/*    */   {
/*    */     try
/*    */     {
/* 76 */       return getHibernateTemplate().find(" from FirstpagesetParam ");
/*    */     } catch (Exception e) {
/* 78 */       this.log.error("", e);
/* 79 */     }return new ArrayList();
/*    */   }
/*    */ 
/*    */   public boolean isHavePageSet(String roleId)
/*    */   {
/* 90 */     return getPageSet(roleId) != null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.FirstPageParamDaoImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.IGroupRoleMap;
/*     */ import com.asiainfo.biframe.privilege.model.GroupRoleMap;
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IGroupRoleMapDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class GroupRoleMapDaoImpl extends HibernateDaoSupport
/*     */   implements IGroupRoleMapDAO
/*     */ {
/*  30 */   private static final Log log = LogFactory.getLog(GroupRoleMapDaoImpl.class);
/*     */ 
/*     */   public void save(GroupRoleMap transientInstance) {
/*     */     try {
/*  34 */       log.debug("saving GroupRoleMap instance");
/*  35 */       GroupRoleMap realMap = (GroupRoleMap)getHibernateTemplate().get(GroupRoleMap.class, transientInstance);
/*  36 */       if (realMap == null) getHibernateTemplate().save(transientInstance);
/*  37 */       log.debug("save successful");
/*     */     } catch (DataAccessException e) {
/*  39 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveGroupRoleRelationFail") + "", e);
/*  40 */       throw new SysmanageException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveGroupRoleRelation") + ":" + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(GroupRoleMap mockMop) {
/*  45 */     log.debug("deleting GroupRoleMap instance");
/*  46 */     GroupRoleMap realMap = (GroupRoleMap)getHibernateTemplate().get(GroupRoleMap.class, mockMop);
/*  47 */     if (realMap != null) getHibernateTemplate().delete(realMap);
/*  48 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapByGId(String gid) {
/*  52 */     log.debug("deleting GroupRoleMap instance");
/*     */ 
/*  54 */     List list = findGroupRoleMapByGroupId(gid);
/*  55 */     if ((list != null) && (list.size() > 0)) {
/*  56 */       getHibernateTemplate().deleteAll(list);
/*     */     }
/*  58 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapList(List groupRoleMap) {
/*  62 */     log.debug("deleting GroupRoleMap instance");
/*  63 */     if ((groupRoleMap != null) && (groupRoleMap.size() > 0)) {
/*  64 */       getHibernateTemplate().deleteAll(groupRoleMap);
/*     */     }
/*  66 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapByRId(String rid) {
/*  70 */     log.debug("deleting GroupRoleMap instance");
/*     */ 
/*  72 */     List list = findAllbyRId(rid);
/*  73 */     if ((list != null) && (list.size() > 0)) {
/*  74 */       getHibernateTemplate().deleteAll(list);
/*     */     }
/*  76 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public GroupRoleMap findById(GroupRoleMap key) {
/*  80 */     return (GroupRoleMap)getHibernateTemplate().get(GroupRoleMap.class, key);
/*     */   }
/*     */ 
/*     */   public List<GroupRoleMap> findAllbyRId(String Rid) {
/*  84 */     log.debug("findAllbyRId GroupRoleMap roleId = " + Rid);
/*  85 */     List grmap = getHibernateTemplate().find("from GroupRoleMap urm where urm.roleId = '" + Rid + "'");
/*  86 */     return grmap;
/*     */   }
/*     */ 
/*     */   public List<User_Group> findGroupsByRoleId(String roleId) {
/*  90 */     log.debug("begin GroupRoleMapDaoImpl.findGroupByRoleId...");
/*  91 */     List groupList = getHibernateTemplate().find("select ug from User_Group ug , GroupRoleMap grm where grm.roleId='" + roleId + "' and grm.groupId=ug.groupid");
/*     */ 
/*  93 */     return groupList;
/*     */   }
/*     */ 
/*     */   public List<User_User> findUsersByRoleId(String roleId) {
/*  97 */     log.debug("begin GroupRoleMapDaoImpl.findUserByRoleId...");
/*  98 */     List userList = getHibernateTemplate().find("select uu from User_User uu , UserRoleMap urm where urm.roleId='" + roleId + "' and urm.userid=uu.userid");
/*     */ 
/* 100 */     return userList;
/*     */   }
/*     */ 
/*     */   public List<GroupRoleMap> findGroupRoleMapByGroupId(String groupId) {
/* 104 */     log.debug("findAllById GroupRoleMap groupid=" + groupId);
/* 105 */     List grmap = getHibernateTemplate().find("from GroupRoleMap urm where urm.groupId = '" + groupId + "'");
/* 106 */     return grmap;
/*     */   }
/*     */ 
/*     */   public List<String> findRoleIdListByGroupId(String groupId) {
/* 110 */     List grmap = getHibernateTemplate().find("select urm.roleId from GroupRoleMap urm where urm.groupId = '" + groupId + "'");
/*     */ 
/* 112 */     return grmap;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public List<String> findRoleIdListByGroupId(String groupId, int roleType, int resourceType)
/*     */   {
/* 119 */     String hql = "select urm.roleId from GroupRoleMap urm,UserRole ur where urm.roleId=ur.roleId and  urm.groupId = '" + groupId + "'" + " and ur.roleType=" + roleType + " and ur.resourceType=" + resourceType + " order by ur.roleName";
/*     */ 
/* 122 */     List roleIdList = getHibernateTemplate().find(hql);
/* 123 */     return roleIdList;
/*     */   }
/*     */ 
/*     */   public List<UserRole> findRoleListByGroupId(String groupId) {
/* 127 */     String hql = "select ur from GroupRoleMap urm,UserRole ur where urm.roleId=ur.roleId and  urm.groupId = '" + groupId + "'" + " order by ur.roleName";
/*     */ 
/* 129 */     List grmap = getHibernateTemplate().find(hql);
/* 130 */     return grmap;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public List<UserRole> findRoleListByGroupId(String groupId, int roleType, int resourceType)
/*     */   {
/*     */     try
/*     */     {
/* 138 */       log.debug("in findRoleListByGroupId");
/* 139 */       String hql = "select ur from GroupRoleMap urm,UserRole ur where urm.roleId=ur.roleId and  urm.groupId = '" + groupId + "'" + " and ur.roleType=" + roleType + " and ur.resourceType=" + resourceType + " order by ur.roleName";
/*     */ 
/* 142 */       log.debug("hql:" + hql);
/* 143 */       List roleList = getHibernateTemplate().find(hql);
/* 144 */       log.debug("end findRoleListByGroupId");
/* 145 */       return roleList;
/*     */     } catch (DataAccessException e) {
/* 147 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRoleFail") + "");
/* 148 */     }throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRoleFail") + "");
/*     */   }
/*     */ 
/*     */   public List<IGroupRoleMap> getGroupRoleMapList() throws ServiceException
/*     */   {
/* 153 */     List grmap = getHibernateTemplate().find("from GroupRoleMap urm ");
/* 154 */     return grmap;
/*     */   }
/*     */ 
/*     */   public void saveGroupRoleMaps(List<IGroupRoleMap> list) throws ServiceException {
/* 158 */     getHibernateTemplate().saveOrUpdateAll(list);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.GroupRoleMapDaoImpl
 * JD-Core Version:    0.6.2
 */
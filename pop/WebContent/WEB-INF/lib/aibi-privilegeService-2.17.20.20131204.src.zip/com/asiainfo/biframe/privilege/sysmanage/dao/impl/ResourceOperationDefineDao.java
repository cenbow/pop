/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.DaoException;
/*    */ import com.asiainfo.biframe.privilege.model.ResourceOperationDefine;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceOperationDefineDao;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class ResourceOperationDefineDao extends HibernateDaoSupport
/*    */   implements IResourceOperationDefineDao
/*    */ {
/* 24 */   private static Logger log = Logger.getLogger(ResourceOperationDefineDao.class);
/*    */ 
/*    */   public List<ResourceOperationDefine> getDefineListBy(int resourceType)
/*    */     throws DaoException
/*    */   {
/*    */     try
/*    */     {
/* 31 */       String hql = "from ResourceOperationDefine def where def.resourceType=" + resourceType + " order by def.operationKey";
/* 32 */       return getHibernateTemplate().find(hql);
/*    */     } catch (DataAccessException e) {
/* 34 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findByResourceTypeFail") + "", e);
/* 35 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findByResourceTypeFail") + "", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ResourceOperationDefine getOperationDefineBy(String operationType, int resourceType)
/*    */     throws DaoException
/*    */   {
/*    */     try
/*    */     {
/* 44 */       String hql = "from ResourceOperationDefine def where def.resourceType=" + resourceType + " and def.operationKey='" + operationType + "'";
/* 45 */       log.debug("--getOperationDefineBy--hql:" + hql);
/* 46 */       List list = getHibernateTemplate().find(hql);
/* 47 */       if (list.isEmpty()) {
/* 48 */         return null;
/*    */       }
/* 50 */       return (ResourceOperationDefine)list.get(0);
/*    */     } catch (DataAccessException e) {
/* 52 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findByResourceTypeAndOperationTypeFail") + "", e);
/* 53 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findByResourceTypeAndOperationTypeFail") + "", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.ResourceOperationDefineDao
 * JD-Core Version:    0.6.2
 */
/*      */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.exception.DaoException;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceDsPropCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceDsProp;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.collections.CollectionUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*      */ import org.springframework.jdbc.core.JdbcTemplate;
/*      */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*      */ 
/*      */ public class ResourceRightDaoJdbcImpl extends JdbcDaoSupport
/*      */   implements IResourceRightDAO
/*      */ {
/*   58 */   private Logger log = Logger.getLogger(ResourceRightDaoJdbcImpl.class);
/*      */ 
/*   60 */   private String roleRightTable = "USER_RIGHT";
/*   61 */   private String defineTable = "USER_CITY";
/*   62 */   private String idField = "cityid";
/*   63 */   private String descField = "cityname";
/*   64 */   private String parentFiled = "parentid";
/*   65 */   private String sortField = "";
/*   66 */   private String orderSql = "";
/*   67 */   private String topLevelId = "-1";
/*      */   private String checkFrameField;
/*      */   private String checkFrameValue;
/*   70 */   private boolean idVarchar = true;
/*   71 */   private String isAccessType = "0";
/*      */   private String accessTypeField;
/*      */   private String resourceTypeField;
/*   77 */   private boolean isNeedConvertIdType = false;
/*      */ 
/*      */   public String getResourceName(String resourceId) {
/*   80 */     Sqlca sqlca = null;
/*      */     try {
/*   82 */       sqlca = new Sqlca(new ConnectionEx());
/*      */ 
/*   84 */       String idField = getIdField();
/*   85 */       if (isNeedConvertIdType()) {
/*   86 */         idField = sqlca.getSql_intTochar(getIdField());
/*   87 */         this.log.debug("idField:" + idField);
/*      */       }
/*      */ 
/*   91 */       String sql = "select " + getDescField() + " from " + getDefineTable() + " where " + idField + "='" + resourceId + "'";
/*   92 */       this.log.debug("--sql:" + sql);
/*   93 */       List list = getJdbcTemplate().queryForList(sql);
/*      */       String str1;
/*   94 */       if ((list == null) || (list.isEmpty())) {
/*   95 */         return "";
/*      */       }
/*   97 */       return ((Map)list.get(0)).get(getDescField()).toString();
/*      */     } catch (Exception e) {
/*   99 */       this.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryResourceNameFail"), e);
/*  100 */       throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryResourceNameFail") + ":" + e.getMessage());
/*      */     } finally {
/*  102 */       if (sqlca != null)
/*  103 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void save(RoleRight newRoleRight)
/*      */   {
/*  111 */     this.log.info(" in save............");
/*      */     try {
/*  113 */       List roleRightList = new ArrayList();
/*  114 */       roleRightList.add(newRoleRight);
/*  115 */       save(roleRightList);
/*      */     } catch (Exception ex) {
/*  117 */       ex.printStackTrace();
/*  118 */       throw new RuntimeException(ex.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void save(Collection<RoleRight> roleRightList)
/*      */   {
/*  125 */     this.log.info(" in save............");
/*  126 */     if ((null == roleRightList) || (roleRightList.isEmpty())) {
/*  127 */       return;
/*      */     }
/*  129 */     StringBuffer sql = new StringBuffer(256);
/*  130 */     sql.append("insert into ").append(getRoleRightTable());
/*  131 */     sql.append("(resourceid,resourcetype,operatorid,operatortype,").append(getAccessTypeField()).append(",controltype) ");
/*  132 */     sql.append(" values(?,?,?,?,?,?)");
/*  133 */     final RoleRight[] roleRights = (RoleRight[])roleRightList.toArray(new RoleRight[roleRightList.size()]);
/*  134 */     BatchPreparedStatementSetter setter = new BatchPreparedStatementSetter() {
/*      */       public void setValues(PreparedStatement ps, int i) throws SQLException {
/*  136 */         RoleRight roleRight = roleRights[i];
/*  137 */         Right right = roleRight.getRight();
/*  138 */         ps.setString(1, right.getResourceId());
/*  139 */         ps.setInt(2, right.getResourceType());
/*  140 */         ps.setString(3, roleRight.getRoleId());
/*  141 */         ps.setInt(4, roleRight.getOperatorType());
/*  142 */         ps.setInt(5, Integer.valueOf(right.getOperationType()).intValue());
/*  143 */         ps.setString(6, roleRight.getControlType());
/*      */       }
/*      */       public int getBatchSize() {
/*  146 */         return roleRights.length;
/*      */       }
/*      */     };
/*  149 */     getJdbcTemplate().batchUpdate(sql.toString(), setter);
/*      */   }
/*      */ 
/*      */   public void delete(String operatorId, int resourceType) {
/*  153 */     this.log.info("delete............");
/*  154 */     Connection con = null;
/*  155 */     Statement stmt = null;
/*      */     try {
/*  157 */       con = getConnection();
/*  158 */       stmt = con.createStatement();
/*      */ 
/*  160 */       StringBuffer sql = new StringBuffer(256);
/*  161 */       sql.append("delete from ").append(getRoleRightTable());
/*  162 */       sql.append(" where operatorid='").append(operatorId).append("'");
/*  163 */       sql.append(" and resourcetype=").append(resourceType);
/*      */ 
/*  165 */       this.log.info(sql);
/*  166 */       stmt.executeUpdate(sql.toString());
/*      */     }
/*      */     catch (Exception ex) {
/*  169 */       this.log.error("Error deleting role rights. roleRightTable=" + getRoleRightTable() + ex.getMessage());
/*      */     }
/*      */     finally {
/*  172 */       if (stmt != null)
/*      */         try {
/*  174 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  178 */       if (con != null)
/*  179 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void delete(Collection<RoleRight> roleRightList)
/*      */   {
/*  185 */     this.log.info(" in delete............");
/*  186 */     Connection con = null;
/*  187 */     Statement stmt = null;
/*      */     try {
/*  189 */       con = getConnection();
/*  190 */       stmt = con.createStatement();
/*      */ 
/*  192 */       for (RoleRight roleRight : roleRightList) {
/*  193 */         Right right = roleRight.getRight();
/*  194 */         StringBuffer sql = new StringBuffer(256);
/*  195 */         sql.append("delete from ").append(getRoleRightTable());
/*  196 */         sql.append(" where resourceid='").append(right.getResourceId()).append("'");
/*  197 */         sql.append(" and resourcetype=").append(right.getResourceType());
/*  198 */         sql.append(" and operatorid='").append(roleRight.getRoleId()).append("'");
/*  199 */         sql.append(" and operatortype=0");
/*  200 */         sql.append(" and ").append(getAccessTypeField()).append("=").append(right.getOperationType());
/*      */ 
/*  204 */         this.log.info(sql);
/*  205 */         stmt.execute(sql.toString());
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/*  209 */       ex.printStackTrace();
/*  210 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/*  212 */       if (stmt != null)
/*      */         try {
/*  214 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  218 */       if (con != null)
/*  219 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void delete(List<String> operatorIdList, List<Right> rightList, int resourceType)
/*      */   {
/*  225 */     this.log.info("delete............");
/*  226 */     Connection con = null;
/*  227 */     Statement stmt = null;
/*      */     try {
/*  229 */       con = getConnection();
/*  230 */       stmt = con.createStatement();
/*  231 */       if ((operatorIdList == null) || (operatorIdList.size() == 0)) {
/*      */         return;
/*      */       }
/*  234 */       if ((rightList == null) || (rightList.size() == 0))
/*      */       {
/*      */         return;
/*      */       }
/*  238 */       String operatorIdString = StringUtil.list2String(operatorIdList, ",", true);
/*  239 */       for (Right right : rightList) {
/*  240 */         StringBuffer sql = new StringBuffer(256);
/*  241 */         sql.append("delete from ").append(getRoleRightTable());
/*  242 */         sql.append(" where 1=1 ");
/*  243 */         sql.append(" and operatorid in (").append(operatorIdString).append(")");
/*  244 */         sql.append(" and resourcetype=").append(resourceType);
/*  245 */         sql.append(" and resourceid='").append(right.getResourceId()).append("'");
/*  246 */         sql.append(" and ").append(getAccessTypeField()).append("=").append(right.getOperationType());
/*      */ 
/*  248 */         this.log.info(sql);
/*  249 */         stmt.executeUpdate(sql.toString());
/*      */       }
/*  251 */       stmt.close();
/*      */     } catch (Exception ex) {
/*  253 */       this.log.error("Error deleting role rights. roleRightTable=" + getRoleRightTable() + ex.getMessage());
/*      */     } finally {
/*  255 */       if (stmt != null)
/*      */         try {
/*  257 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  261 */       if (con != null)
/*  262 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  269 */     StringBuffer sb = new StringBuffer();
/*      */ 
/*  271 */     sb.append(super.toString()).append("\n").append("rightTable=" + getRoleRightTable()).append("\n").append("defineTable=" + getDefineTable()).append("\n").append("idField=" + getIdField()).append(",descField=" + getDescField()).append(",parentField=" + getParentFiled()).append(",sortField=" + getSortField()).append("\n").append("orderSql=" + getOrderSql()).append("\n").append("topLevelId=" + getTopLevelId()).append(",idVarchar=" + isIdVarchar());
/*      */ 
/*  277 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public String getCheckFrameField() {
/*  281 */     return this.checkFrameField;
/*      */   }
/*      */ 
/*      */   public void setCheckFrameField(String checkFrameField) {
/*  285 */     this.checkFrameField = checkFrameField;
/*      */   }
/*      */ 
/*      */   public String getCheckFrameValue() {
/*  289 */     return this.checkFrameValue;
/*      */   }
/*      */ 
/*      */   public void setCheckFrameValue(String checkFrameValue) {
/*  293 */     this.checkFrameValue = checkFrameValue;
/*      */   }
/*      */ 
/*      */   public String getTopLevelId() {
/*  297 */     return this.topLevelId;
/*      */   }
/*      */ 
/*      */   public void setTopLevelId(String topLevelId) {
/*  301 */     this.topLevelId = topLevelId;
/*      */   }
/*      */ 
/*      */   public String getRoleRightTable()
/*      */   {
/*  306 */     return this.roleRightTable;
/*      */   }
/*      */ 
/*      */   public String getDefineTable() {
/*  310 */     return this.defineTable;
/*      */   }
/*      */ 
/*      */   public void setDefineTable(String defineTable) {
/*  314 */     this.defineTable = defineTable;
/*      */   }
/*      */ 
/*      */   public String getDescField() {
/*  318 */     return this.descField;
/*      */   }
/*      */ 
/*      */   public void setDescField(String descField) {
/*  322 */     this.descField = descField;
/*      */   }
/*      */ 
/*      */   public String getIdField() {
/*  326 */     return this.idField;
/*      */   }
/*      */ 
/*      */   public void setIdField(String idField) {
/*  330 */     this.idField = idField;
/*      */   }
/*      */ 
/*      */   public boolean isIdVarchar() {
/*  334 */     return this.idVarchar;
/*      */   }
/*      */ 
/*      */   public void setIdVarchar(boolean idVarchar) {
/*  338 */     this.idVarchar = idVarchar;
/*      */   }
/*      */ 
/*      */   public String getOrderSql() {
/*  342 */     return this.orderSql;
/*      */   }
/*      */ 
/*      */   public void setOrderSql(String orderSql) {
/*  346 */     this.orderSql = orderSql;
/*      */   }
/*      */ 
/*      */   public String getParentFiled() {
/*  350 */     return this.parentFiled;
/*      */   }
/*      */ 
/*      */   public void setParentFiled(String parentFiled) {
/*  354 */     this.parentFiled = parentFiled;
/*      */   }
/*      */ 
/*      */   public String getSortField() {
/*  358 */     return this.sortField;
/*      */   }
/*      */ 
/*      */   public void setSortField(String sortField) {
/*  362 */     this.sortField = sortField;
/*      */   }
/*      */ 
/*      */   public void setRoleRightTable(String roleRightTable) {
/*  366 */     this.roleRightTable = roleRightTable;
/*      */   }
/*      */ 
/*      */   public String getIsAccessType() {
/*  370 */     return this.isAccessType;
/*      */   }
/*      */ 
/*      */   public void setIsAccessType(String isAccessType) {
/*  374 */     this.isAccessType = isAccessType;
/*      */   }
/*      */ 
/*      */   public String getAccessTypeField() {
/*  378 */     return this.accessTypeField;
/*      */   }
/*      */ 
/*      */   public void setAccessTypeField(String accessTypeField) {
/*  382 */     this.accessTypeField = accessTypeField;
/*      */   }
/*      */ 
/*      */   public String getResourceTypeField()
/*      */   {
/*  387 */     return this.resourceTypeField;
/*      */   }
/*      */ 
/*      */   public void setResourceTypeField(String resourceTypeField) {
/*  391 */     this.resourceTypeField = resourceTypeField;
/*      */   }
/*      */ 
/*      */   public boolean isNeedConvertIdType() {
/*  395 */     return this.isNeedConvertIdType;
/*      */   }
/*      */ 
/*      */   public void setIsNeedConvertIdType(boolean isNeedConvertIdType) {
/*  399 */     this.isNeedConvertIdType = isNeedConvertIdType;
/*      */   }
/*      */ 
/*      */   protected int getRoleType(String roleId)
/*      */   {
/*  408 */     this.log.debug(" in getRoleType ");
/*  409 */     Connection con = getConnection();
/*  410 */     Statement stmt = null;
/*  411 */     ResultSet rs = null;
/*      */     try {
/*  413 */       stmt = con.createStatement();
/*  414 */       String sql = "select role_type from user_role where role_id='" + roleId + "'";
/*  415 */       this.log.debug("--sql:" + sql);
/*      */ 
/*  417 */       rs = stmt.executeQuery(sql);
/*  418 */       int roleType = -1;
/*  419 */       while (rs.next()) {
/*  420 */         roleType = rs.getInt("ROLE_TYPE");
/*      */       }
/*  422 */       this.log.debug(" end getRoleType ");
/*  423 */       return roleType;
/*      */     } catch (Exception e) {
/*  425 */       throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRoleTypeFail"), e);
/*      */     } finally {
/*      */       try {
/*  428 */         if (rs != null) {
/*  429 */           rs.close();
/*      */         }
/*  431 */         if (stmt != null)
/*  432 */           stmt.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  435 */         e.printStackTrace();
/*      */       }
/*  437 */       if (con != null)
/*  438 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public RoleRight getRoleRight(String roleId, int resourceType, String resourceId, String operationType)
/*      */   {
/*  445 */     this.log.debug(" in getRoleRight...");
/*  446 */     List roleRightList = getRoleRightListByRole(roleId, resourceType);
/*  447 */     for (RoleRight roleRight : roleRightList) {
/*  448 */       Right right = roleRight.getRight();
/*  449 */       if ((resourceId.equals(right.getResourceId())) && (operationType.equals(right.getOperationType()))) {
/*  450 */         return roleRight;
/*      */       }
/*      */     }
/*  453 */     return new RoleRight();
/*      */   }
/*      */ 
/*      */   public List<Right> getRightList(String roleId, int resourceType, boolean isDistinctControlType)
/*      */   {
/*  462 */     List roleIdList = new ArrayList();
/*  463 */     roleIdList.add(roleId);
/*  464 */     return getRightList(roleIdList, resourceType, isDistinctControlType);
/*      */   }
/*      */ 
/*      */   public String getInSqlStr(List<String> valueList, boolean addQuote, StringBuffer sb) {
/*  468 */     String separator = ",";
/*  469 */     if ((null == valueList) || (valueList.isEmpty()))
/*      */     {
/*  471 */       return sb.toString();
/*      */     }
/*      */ 
/*  474 */     int maxLength = 950;
/*  475 */     int i = 0; for (int size = valueList.size(); i < size; i++)
/*      */     {
/*  477 */       if (sb.length() / maxLength > 1) {
/*  478 */         getInSqlStr(valueList.subList(i, size), addQuote, sb);
/*      */       }
/*  480 */       sb.append(addQuote ? "'" : "").append((String)valueList.get(i)).append(addQuote ? "'" : "").append(separator);
/*      */     }
/*      */ 
/*  483 */     return sb.substring(0, sb.length() - 1);
/*      */   }
/*      */ 
/*      */   public List<Right> getRightList(List<String> roleIdList, int resourceType, boolean isDistinctControlType)
/*      */   {
/*  490 */     this.log.debug(" in getRightList...");
/*      */ 
/*  492 */     Sqlca sqlca = null;
/*  493 */     Connection con = null;
/*  494 */     Statement stmt = null;
/*      */     try {
/*  496 */       sqlca = new Sqlca(new ConnectionEx());
/*  497 */       if (((roleIdList == null) || (roleIdList.isEmpty())) && (resourceType != Integer.parseInt("50"))) {
/*  498 */         return new ArrayList();
/*      */       }
/*      */ 
/*  501 */       con = getConnection();
/*  502 */       stmt = con.createStatement();
/*      */ 
/*  504 */       boolean hasCheckFrameField = hasCheckFrameField();
/*      */ 
/*  506 */       roleType = 0;
/*  507 */       roleType = getRoleTypeByResourceType(resourceType);
/*      */ 
/*  509 */       List result = new ArrayList();
/*  510 */       Set rightSet = new HashSet();
/*  511 */       if ((roleIdList != null) && (!roleIdList.isEmpty()))
/*      */       {
/*  513 */         StringBuffer sb = new StringBuffer();
/*  514 */         sb.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/*  515 */         sb.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/*  516 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/*  517 */           sb.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */         }
/*  519 */         sb.append(", rig.").append(getAccessTypeField()).append(" OPERATION_TYPE");
/*  520 */         sb.append(", opdef.operationname OPERATION_NAME");
/*  521 */         sb.append(", rig.controltype CONTROL_TYPE");
/*      */ 
/*  523 */         if (hasCheckFrameField) {
/*  524 */           sb.append(", resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD");
/*      */         }
/*  526 */         sb.append(" from ").append(getDefineTable()).append(" resdef,").append(getRoleRightTable()).append(" rig, ");
/*  527 */         sb.append(" ").append("RESOURCE_OPERATION_DEFINE").append(" opdef ");
/*  528 */         sb.append(" where 1=1 ");
/*      */ 
/*  532 */         String accessTypeStr = sqlca.getSql_intTochar("rig." + getAccessTypeField());
/*      */ 
/*  534 */         String idField = getIdField();
/*  535 */         if (isNeedConvertIdType()) {
/*  536 */           idField = sqlca.getSql_intTochar("resdef." + getIdField());
/*  537 */           this.log.debug("idField:" + idField);
/*      */         }
/*      */ 
/*  540 */         if (isDistinctControlType) {
/*  541 */           sb.append(" and rig.controltype='").append("1").append("'");
/*      */         }
/*  543 */         sb.append(" and ").append(idField).append("=rig.resourceid");
/*  544 */         sb.append(" and opdef.operationkey=").append(accessTypeStr);
/*  545 */         sb.append(" and opdef.resourcetype=").append(resourceType);
/*  546 */         sb.append(" and rig.operatorid in(").append(StringUtil.list2String(roleIdList, ",", true)).append(") ");
/*  547 */         sb.append(" and rig.resourcetype=").append(resourceType);
/*      */ 
/*  549 */         if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  550 */           sb.append(" and resdef.status=0 ");
/*      */         }
/*  552 */         if (StringUtils.isNotBlank(getOrderSql())) {
/*  553 */           sb.append(" ").append(getOrderSql());
/*      */         }
/*      */ 
/*  556 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql:" + sb.toString());
/*      */ 
/*  558 */         ResultSet rs2 = stmt.executeQuery(sb.toString());
/*  559 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeOver") + "");
/*      */ 
/*  561 */         while (rs2.next())
/*      */         {
/*  564 */           Right right = new Right();
/*  565 */           right.setRoleType(roleType);
/*  566 */           right.setResourceId(rs2.getString("ID_FIELD"));
/*  567 */           right.setResourceName(rs2.getString("DESC_FIELD"));
/*  568 */           if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*  569 */             right.setParentId(rs2.getString("PARENT_FIELD"));
/*      */           else {
/*  571 */             right.setParentId("0");
/*      */           }
/*  573 */           right.setOperationType(String.valueOf(rs2.getInt("OPERATION_TYPE")));
/*  574 */           right.setOperationName(rs2.getString("OPERATION_NAME"));
/*  575 */           if (hasCheckFrameField) {
/*  576 */             right.setHasCheckFrame(getCheckFrameValue().equals(rs2.getString("CHECK_FRAME_FIELD")));
/*      */           }
/*  578 */           right.setResourceType(resourceType);
/*  579 */           right.setTopId(getTopLevelId());
/*      */ 
/*  581 */           if (!rightSet.contains(right)) {
/*  582 */             result.add(right);
/*  583 */             rightSet.add(right);
/*      */           }
/*      */         }
/*  586 */         this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuthList") + ":" + result.size());
/*      */ 
/*  588 */         rs2.close();
/*      */       }
/*      */       StringBuffer allSql;
/*  592 */       if (hasCheckFrameField) {
/*  593 */         allSql = new StringBuffer();
/*  594 */         allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*  595 */         allSql.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*  596 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/*  597 */           allSql.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*      */         }
/*  599 */         allSql.append("resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD ");
/*      */ 
/*  601 */         allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*  602 */         allSql.append(" where 1=1 and resdef.").append(getCheckFrameField()).append("=0 ");
/*  603 */         if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  604 */           allSql.append(" and resdef.status=0 ");
/*      */         }
/*      */ 
/*  611 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.shareAuth") + "sql:" + allSql.toString());
/*      */ 
/*  613 */         ResultSet rs1 = stmt.executeQuery(allSql.toString());
/*  614 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryShareAuthOver") + "");
/*      */ 
/*  616 */         boolean isDisOper = isDistinguishOperation(resourceType);
/*      */         String defaultOperationName;
/*      */         String defaultOperationType;
/*      */         String defaultOperationName;
/*  621 */         if (isDisOper) {
/*  622 */           String defaultOperationType = "0";
/*  623 */           defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.view") + "";
/*      */         } else {
/*  625 */           defaultOperationType = "-1";
/*  626 */           defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.noDiffOperationAuth") + "";
/*      */         }
/*      */ 
/*  629 */         while (rs1.next()) {
/*  630 */           Right right = new Right();
/*  631 */           right.setRoleType(roleType);
/*  632 */           right.setResourceId(rs1.getString("ID_FIELD"));
/*  633 */           right.setResourceName(rs1.getString("DESC_FIELD"));
/*  634 */           if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*  635 */             right.setParentId(rs1.getString("PARENT_FIELD"));
/*      */           else {
/*  637 */             right.setParentId("0");
/*      */           }
/*  639 */           right.setHasCheckFrame(getCheckFrameValue().equals(rs1.getString("CHECK_FRAME_FIELD")));
/*  640 */           right.setOperationType(defaultOperationType);
/*  641 */           right.setOperationName(defaultOperationName);
/*  642 */           right.setResourceType(resourceType);
/*  643 */           right.setTopId(getTopLevelId());
/*      */ 
/*  645 */           if (!rightSet.contains(right)) {
/*  646 */             result.add(right);
/*  647 */             rightSet.add(right);
/*      */           }
/*      */         }
/*      */ 
/*  651 */         rs1.close();
/*  652 */         this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.finalAuthList") + ":" + result.size());
/*      */       }
/*      */ 
/*  655 */       this.log.debug(" end getRightList...");
/*  656 */       return result;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       int roleType;
/*  658 */       this.log.debug("getRightList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*  659 */       return new ArrayList();
/*      */     } finally {
/*  661 */       if (sqlca != null) {
/*  662 */         sqlca.closeAll();
/*      */       }
/*  664 */       if (stmt != null)
/*      */         try {
/*  666 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  670 */       if (con != null)
/*  671 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected boolean hasCheckFrameField()
/*      */   {
/*  678 */     return StringUtils.isNotBlank(getCheckFrameField());
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(int roleType, int resourceType) {
/*  682 */     this.log.debug(" in getAllRightList...");
/*  683 */     List result = new ArrayList();
/*      */     try
/*      */     {
/*  686 */       StringBuffer sb = new StringBuffer();
/*  687 */       sb.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*  688 */       sb.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*  689 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/*  690 */         sb.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*      */       }
/*  692 */       sb.append("opdef.operationkey OPERATION_KEY,");
/*  693 */       sb.append("opdef.operationname OPERATION_NAME");
/*  694 */       if (hasCheckFrameField()) {
/*  695 */         sb.append(",resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD");
/*      */       }
/*      */ 
/*  699 */       String defineTable = getDefineTable();
/*  700 */       if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  701 */         defineTable = "(select * from " + getDefineTable() + "  where STATUS=0 ) ";
/*      */       }
/*      */ 
/*  704 */       sb.append(" from ").append(defineTable).append(" resdef left outer join ");
/*  705 */       sb.append("RESOURCE_OPERATION_DEFINE").append(" opdef ");
/*  706 */       sb.append(" on opdef.RESOURCETYPE=").append(resourceType);
/*  707 */       sb.append(" where resdef.").append(getResourceTypeField()).append("=opdef.resourcetype ");
/*      */ 
/*  709 */       if (StringUtils.isNotBlank(getOrderSql())) {
/*  710 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/*  713 */       this.log.info(sb.toString());
/*      */ 
/*  715 */       List list = getJdbcTemplate().queryForList(sb.toString());
/*      */ 
/*  717 */       for (Map map : list) {
/*  718 */         Right right = new Right();
/*  719 */         right.setRoleType(roleType);
/*      */ 
/*  721 */         right.setResourceId(map.get("ID_FIELD").toString());
/*  722 */         right.setResourceName(map.get("DESC_FIELD").toString());
/*  723 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*  724 */           right.setParentId(map.get("PARENT_FIELD").toString());
/*      */         else {
/*  726 */           right.setParentId("0");
/*      */         }
/*  728 */         right.setOperationType(map.get("OPERATION_KEY").toString());
/*  729 */         right.setOperationName(map.get("OPERATION_NAME").toString());
/*  730 */         if (hasCheckFrameField()) {
/*  731 */           right.setHasCheckFrame(getCheckFrameValue().equals(map.get("CHECK_FRAME_FIELD").toString()));
/*      */         }
/*  733 */         right.setResourceType(resourceType);
/*  734 */         right.setTopId(getTopLevelId());
/*      */ 
/*  736 */         result.add(right);
/*      */       }
/*  738 */       return result;
/*      */     } catch (Exception ex) {
/*  740 */       this.log.debug("getRoleRightListByRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*  741 */     }return new ArrayList();
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightListByRight(Right currRight)
/*      */   {
/*  747 */     this.log.debug(" in getRoleRightListByRight...");
/*      */ 
/*  749 */     Connection con = null;
/*  750 */     Statement stmt = null;
/*      */     try {
/*  752 */       con = getConnection();
/*  753 */       stmt = con.createStatement();
/*      */ 
/*  755 */       StringBuffer sb = new StringBuffer();
/*  756 */       sb.append("select operatorid,controltype ");
/*  757 */       sb.append(" from ").append(getRoleRightTable());
/*  758 */       sb.append(" where 1=1");
/*  759 */       sb.append(" and resourceid='").append(currRight.getResourceId()).append("'");
/*  760 */       sb.append(" and resourcetype=").append(currRight.getResourceType());
/*  761 */       sb.append(" and ").append(getAccessTypeField()).append("=").append(currRight.getOperationType());
/*      */ 
/*  763 */       this.log.info(sb.toString());
/*      */ 
/*  765 */       ResultSet rs = stmt.executeQuery(sb.toString());
/*      */ 
/*  767 */       List roleRightList = new ArrayList();
/*      */       RoleRight roleRight;
/*  768 */       while (rs.next()) {
/*  769 */         roleRight = new RoleRight();
/*  770 */         roleRight.setControlType(rs.getString(2));
/*  771 */         roleRight.setRight(currRight);
/*  772 */         roleRight.setRoleId(rs.getString(1));
/*  773 */         roleRightList.add(roleRight);
/*      */       }
/*      */ 
/*  776 */       rs.close();
/*      */ 
/*  779 */       return roleRightList;
/*      */     } catch (Exception ex) {
/*  781 */       ex.printStackTrace();
/*  782 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/*  784 */       if (stmt != null)
/*      */         try {
/*  786 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  790 */       if (con != null)
/*  791 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightListByRole(String roleId, int resourceType)
/*      */   {
/*  797 */     this.log.debug(" in getRoleRightListByRole...");
/*      */     try {
/*  799 */       List roleIdList = new ArrayList();
/*  800 */       roleIdList.add(roleId);
/*  801 */       return getRoleRightListByRoles(roleIdList, resourceType);
/*      */     } catch (Exception ex) {
/*  803 */       this.log.error("getRoleRightListByRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + "", ex);
/*  804 */       throw new RuntimeException(ex.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected List<RoleRight> getRoleRightListByRoles(List<String> roleIdList, int resourceType) {
/*  809 */     this.log.debug(" in getRoleRightListByRoles...");
/*  810 */     Sqlca sqlca = null;
/*  811 */     Connection con = null;
/*  812 */     Statement stmt = null;
/*      */     try {
/*  814 */       con = getConnection();
/*  815 */       stmt = con.createStatement();
/*  816 */       sqlca = new Sqlca(new ConnectionEx());
/*  817 */       if ((roleIdList == null) || (roleIdList.isEmpty())) {
/*  818 */         return new ArrayList();
/*      */       }
/*      */ 
/*  821 */       boolean hasCheckFrameField = hasCheckFrameField();
/*  822 */       result = new ArrayList();
/*      */ 
/*  824 */       int roleType = getRoleTypeByResourceType(resourceType);
/*      */ 
/*  827 */       StringBuffer sb = new StringBuffer();
/*  828 */       sb.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*  829 */       sb.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*  830 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/*  831 */         sb.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*      */       }
/*  833 */       sb.append("rig.").append(getAccessTypeField()).append(" OPERATION_TYPE,");
/*  834 */       sb.append("opdef.operationname OPERATION_NAME,");
/*  835 */       sb.append("rig.controltype CONTROL_TYPE,");
/*  836 */       sb.append("rig.operatorid OPERATOR_ID ");
/*  837 */       if (hasCheckFrameField) {
/*  838 */         sb.append(",resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD");
/*      */       }
/*  840 */       sb.append(" from ").append(getDefineTable()).append(" resdef,").append(getRoleRightTable()).append(" rig, ");
/*  841 */       sb.append(" ").append("RESOURCE_OPERATION_DEFINE").append(" opdef ");
/*  842 */       sb.append(" where 1=1 ");
/*      */ 
/*  845 */       String accessTypeStr = sqlca.getSql_intTochar("rig." + getAccessTypeField());
/*      */ 
/*  847 */       String idField = getIdField();
/*  848 */       if (isNeedConvertIdType()) {
/*  849 */         idField = sqlca.getSql_intTochar("resdef." + getIdField());
/*  850 */         this.log.debug("idField:" + idField);
/*      */       }
/*      */ 
/*  854 */       sb.append(" and ").append(idField).append("=rig.resourceid");
/*  855 */       sb.append(" and opdef.operationkey=").append(accessTypeStr);
/*  856 */       sb.append(" and opdef.resourcetype=").append(resourceType);
/*  857 */       sb.append(" and rig.operatorid in(").append(StringUtil.list2String(roleIdList, ",", true)).append(") ");
/*  858 */       sb.append(" and rig.resourcetype=").append(resourceType);
/*      */ 
/*  860 */       if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  861 */         sb.append(" and resdef.status=0 ");
/*      */       }
/*  863 */       if (StringUtils.isNotBlank(getOrderSql())) {
/*  864 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/*  867 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql:" + sb.toString());
/*      */ 
/*  869 */       ResultSet rs2 = stmt.executeQuery(sb.toString());
/*  870 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeOver") + "");
/*  871 */       Map rightMap = new HashMap();
/*  872 */       while (rs2.next())
/*      */       {
/*  875 */         Right right = new Right();
/*  876 */         right.setRoleType(roleType);
/*  877 */         right.setResourceId(rs2.getString("ID_FIELD"));
/*  878 */         right.setResourceName(rs2.getString("DESC_FIELD"));
/*  879 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*  880 */           right.setParentId(rs2.getString("PARENT_FIELD"));
/*      */         else {
/*  882 */           right.setParentId("0");
/*      */         }
/*  884 */         right.setOperationType(String.valueOf(rs2.getInt("OPERATION_TYPE")));
/*  885 */         right.setOperationName(rs2.getString("OPERATION_NAME"));
/*  886 */         if (hasCheckFrameField) {
/*  887 */           right.setHasCheckFrame(getCheckFrameValue().equals(rs2.getString("CHECK_FRAME_FIELD")));
/*      */         }
/*  889 */         right.setResourceType(resourceType);
/*  890 */         right.setTopId(getTopLevelId());
/*      */ 
/*  892 */         RoleRight roleRight = new RoleRight();
/*  893 */         roleRight.setRoleId(rs2.getString("OPERATOR_ID"));
/*  894 */         roleRight.setRight(right);
/*  895 */         roleRight.setControlType(rs2.getString("CONTROL_TYPE"));
/*  896 */         String mapKey = roleRight.getRoleId() + "|" + roleRight.getRight().getResourceId() + "|" + roleRight.getRight().getResourceType() + "|" + roleRight.getOperatorType() + "|" + roleRight.getRight().getOperationType();
/*      */ 
/*  901 */         rightMap.put(mapKey, roleRight);
/*  902 */         result.add(roleRight);
/*      */       }
/*  904 */       this.log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuthList") + ":" + result.size());
/*      */ 
/*  906 */       rs2.close();
/*      */       StringBuffer allSql;
/*  909 */       if (hasCheckFrameField) {
/*  910 */         allSql = new StringBuffer();
/*  911 */         allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*  912 */         allSql.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*  913 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/*  914 */           allSql.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*      */         }
/*  916 */         allSql.append("resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD ");
/*      */ 
/*  918 */         allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*  919 */         allSql.append(" where 1=1 and resdef.").append(getCheckFrameField()).append("=0 ");
/*  920 */         if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  921 */           allSql.append(" and resdef.status=0 ");
/*      */         }
/*      */ 
/*  928 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.shareAuth") + "sql:" + allSql.toString());
/*      */ 
/*  930 */         ResultSet rs1 = stmt.executeQuery(allSql.toString());
/*  931 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryShareAuthOver") + "");
/*      */ 
/*  933 */         boolean isDisOper = isDistinguishOperation(resourceType);
/*      */         String defaultOperationName;
/*      */         String defaultOperationType;
/*      */         String defaultOperationName;
/*  938 */         if (isDisOper) {
/*  939 */           String defaultOperationType = "0";
/*  940 */           defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.view") + "";
/*      */         } else {
/*  942 */           defaultOperationType = "-1";
/*  943 */           defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.noDiffOperationAuth") + "";
/*      */         }
/*      */         Right right;
/*  946 */         while (rs1.next()) {
/*  947 */           right = new Right();
/*  948 */           right.setRoleType(roleType);
/*  949 */           right.setResourceId(rs1.getString("ID_FIELD"));
/*  950 */           right.setResourceName(rs1.getString("DESC_FIELD"));
/*  951 */           if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*  952 */             right.setParentId(rs1.getString("PARENT_FIELD"));
/*      */           else {
/*  954 */             right.setParentId("0");
/*      */           }
/*  956 */           right.setHasCheckFrame(getCheckFrameValue().equals(rs1.getString("CHECK_FRAME_FIELD")));
/*  957 */           right.setOperationType(defaultOperationType);
/*  958 */           right.setOperationName(defaultOperationName);
/*  959 */           right.setResourceType(resourceType);
/*  960 */           right.setTopId(getTopLevelId());
/*      */ 
/*  964 */           for (String roleId : roleIdList) {
/*  965 */             RoleRight roleRight = new RoleRight();
/*  966 */             roleRight.setRoleId(roleId);
/*  967 */             roleRight.setRight(right);
/*  968 */             roleRight.setControlType("0");
/*  969 */             String mapKey = roleRight.getRoleId() + "|" + roleRight.getRight().getResourceId() + "|" + roleRight.getRight().getResourceType() + "|" + roleRight.getOperatorType() + "|" + roleRight.getRight().getOperationType();
/*      */ 
/*  974 */             if (null == rightMap.get(mapKey)) {
/*  975 */               result.add(roleRight);
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  981 */         rs1.close();
/*  982 */         this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.finalAuthList") + ":" + result.size());
/*      */       }
/*      */ 
/*  985 */       this.log.debug(" end getRoleRightListByRoles...");
/*  986 */       return result;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       List result;
/*  988 */       this.log.debug("getRoleRightListByRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*  989 */       return new ArrayList();
/*      */     } finally {
/*  991 */       if (sqlca != null) {
/*  992 */         sqlca.closeAll();
/*      */       }
/*  994 */       if (stmt != null)
/*      */         try {
/*  996 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/* 1000 */       if (con != null)
/* 1001 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean isDistinguishOperation(int resourceType)
/*      */   {
/* 1007 */     this.log.debug(" in isDistinguishOperation...");
/*      */ 
/* 1009 */     Connection con = null;
/* 1010 */     Statement stmt = null;
/*      */     try {
/* 1012 */       con = getConnection();
/* 1013 */       stmt = con.createStatement();
/* 1014 */       String sql = "select operationkey from RESOURCE_OPERATION_DEFINE where resourcetype=" + resourceType;
/*      */ 
/* 1016 */       List opKeyList = new ArrayList();
/* 1017 */       ResultSet rs = stmt.executeQuery(sql);
/* 1018 */       while (rs.next())
/* 1019 */         opKeyList.add(rs.getString(1));
/*      */       boolean bool;
/* 1021 */       if (opKeyList.size() == 0) {
/* 1022 */         return false;
/*      */       }
/* 1024 */       if ((opKeyList.size() == 1) && ("-1".equals(opKeyList.get(0)))) {
/* 1025 */         return false;
/*      */       }
/* 1027 */       return true;
/*      */     } catch (Exception ex) {
/* 1029 */       ex.printStackTrace();
/* 1030 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/* 1032 */       if (stmt != null)
/*      */         try {
/* 1034 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/* 1038 */       if (con != null)
/* 1039 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<String> getAllParentIds(String resourceId)
/*      */   {
/* 1048 */     List allParnetIdList = new ArrayList();
/*      */ 
/* 1050 */     getAllParentIds(allParnetIdList, resourceId);
/*      */ 
/* 1052 */     return allParnetIdList;
/*      */   }
/*      */ 
/*      */   protected List<String> getAllParentIds(List<String> allParnetIdList, String resourceId)
/*      */   {
/* 1063 */     StringBuffer sql = new StringBuffer(128);
/* 1064 */     sql.append("select ").append(getParentFiled()).append(" from ").append(getDefineTable());
/* 1065 */     sql.append(" where ").append(getIdField());
/* 1066 */     if (isIdVarchar())
/* 1067 */       sql.append("='").append(resourceId).append("'");
/*      */     else
/* 1069 */       sql.append("=").append(resourceId);
/* 1070 */     this.log.debug("--sql:" + sql);
/*      */ 
/* 1072 */     String parentId = (String)getJdbcTemplate().queryForObject(sql.toString(), String.class);
/*      */ 
/* 1075 */     if ((StringUtils.isBlank(parentId)) || ("0".equals(parentId)) || ("-1".equals(parentId)) || ("-2".equals(parentId))) {
/* 1076 */       return allParnetIdList;
/*      */     }
/*      */ 
/* 1079 */     allParnetIdList.add(parentId);
/*      */ 
/* 1081 */     getAllParentIds(allParnetIdList, parentId);
/*      */ 
/* 1083 */     return allParnetIdList;
/*      */   }
/*      */ 
/*      */   public void updateControlType(String roleId, int resourceType, String resourceId, String controlType)
/*      */   {
/* 1090 */     StringBuffer sql = new StringBuffer(128);
/* 1091 */     sql.append("update ").append(getRoleRightTable());
/* 1092 */     sql.append(" set controltype='").append(controlType).append("'");
/* 1093 */     sql.append(" where resourceid='").append(resourceId).append("'");
/* 1094 */     sql.append(" and resourcetype=").append(resourceType);
/* 1095 */     sql.append(" and operatorid='").append(roleId).append("'");
/*      */ 
/* 1097 */     getJdbcTemplate().execute(sql.toString());
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(String resourceName, int resourceType)
/*      */   {
/*      */     try
/*      */     {
/* 1106 */       List result = new ArrayList();
/* 1107 */       StringBuffer allSql = new StringBuffer();
/* 1108 */       allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/* 1109 */       allSql.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/* 1110 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/* 1111 */         allSql.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */       }
/* 1113 */       allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/* 1114 */       allSql.append(" where 1=1 and resdef.").append(getDescField()).append("='").append(resourceName).append("'");
/* 1115 */       allSql.append(" and resdef.").append(getResourceTypeField()).append("=").append(resourceType);
/* 1116 */       this.log.debug("--sql:" + allSql);
/*      */ 
/* 1118 */       List list = getJdbcTemplate().queryForList(allSql.toString());
/* 1119 */       if ((list == null) || (list.isEmpty())) {
/* 1120 */         return null;
/*      */       }
/* 1122 */       for (Map map : list) {
/* 1123 */         Right right = new Right();
/* 1124 */         right.setResourceId(String.valueOf(map.get("ID_FIELD")));
/* 1125 */         right.setParentId(String.valueOf(map.get("PARENT_FIELD")));
/* 1126 */         right.setResourceName(resourceName);
/* 1127 */         right.setResourceType(resourceType);
/* 1128 */         result.add(right);
/*      */       }
/* 1130 */       this.log.debug(" end getAllRightList ");
/* 1131 */       return result;
/*      */     } catch (Exception e) {
/* 1133 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(String resourceName)
/*      */   {
/*      */     try {
/* 1140 */       List result = new ArrayList();
/* 1141 */       StringBuffer allSql = new StringBuffer();
/* 1142 */       allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/* 1143 */       allSql.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/* 1144 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/* 1145 */         allSql.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */       }
/* 1147 */       allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/* 1148 */       allSql.append(" where 1=1 and resdef.").append(getDescField()).append("='").append(resourceName).append("'");
/* 1149 */       this.log.debug("--sql:" + allSql);
/*      */ 
/* 1151 */       List list = getJdbcTemplate().queryForList(allSql.toString());
/* 1152 */       if ((list == null) || (list.isEmpty())) {
/* 1153 */         return null;
/*      */       }
/* 1155 */       for (Map map : list) {
/* 1156 */         Right right = new Right();
/* 1157 */         right.setResourceId(((String)map.get("ID_FIELD")).toString());
/* 1158 */         right.setParentId(((String)map.get("PARENT_FIELD")).toString());
/* 1159 */         right.setResourceName(resourceName);
/*      */ 
/* 1161 */         result.add(right);
/*      */       }
/* 1163 */       this.log.debug(" end getAllRightList ");
/* 1164 */       return result;
/*      */     } catch (Exception e) {
/* 1166 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public Right getRight(String resouceId)
/*      */   {
/*      */     try {
/* 1173 */       Right right = new Right();
/* 1174 */       StringBuffer allSql = new StringBuffer();
/* 1175 */       allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/* 1176 */       allSql.append("resdef.").append(getDescField()).append(" DESC_FIELD ");
/* 1177 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/* 1178 */         allSql.append(",resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */       }
/* 1180 */       allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/* 1181 */       allSql.append(" where 1=1 and resdef.").append(getIdField());
/* 1182 */       if (isIdVarchar())
/* 1183 */         allSql.append("='").append(resouceId).append("'");
/*      */       else
/* 1185 */         allSql.append("=").append(resouceId);
/* 1186 */       this.log.debug("--sql:" + allSql);
/*      */ 
/* 1188 */       List list = getJdbcTemplate().queryForList(allSql.toString());
/* 1189 */       if ((list == null) || (list.isEmpty())) {
/* 1190 */         return null;
/*      */       }
/*      */ 
/* 1193 */       Map map = (Map)list.get(0);
/* 1194 */       right.setResourceId(map.get("ID_FIELD").toString());
/* 1195 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/* 1196 */         right.setParentId(map.get("PARENT_FIELD").toString());
/*      */       }
/* 1198 */       right.setResourceName(map.get("DESC_FIELD").toString());
/*      */ 
/* 1201 */       this.log.debug(" end getAllRightList ");
/* 1202 */       return right;
/*      */     } catch (Exception e) {
/* 1204 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isExistRoleRight(String roleId, String resourceId, int resourceType, String OperationType)
/*      */   {
/*      */     try {
/* 1211 */       StringBuffer allSql = new StringBuffer();
/* 1212 */       allSql.append("select resright.*");
/* 1213 */       allSql.append(" from ").append(getRoleRightTable()).append(" resright ");
/* 1214 */       allSql.append(" where 1=1 and resright.").append("operatorid").append("='").append(roleId).append("' and resourceid").append("=");
/*      */ 
/* 1216 */       allSql.append("'").append(resourceId).append("'");
/* 1217 */       allSql.append(" and resourcetype").append("=").append(resourceType);
/* 1218 */       allSql.append(" and ").append(getAccessTypeField()).append("=").append(OperationType);
/* 1219 */       this.log.debug("--sql:" + allSql);
/*      */ 
/* 1221 */       List list = getJdbcTemplate().queryForList(allSql.toString());
/* 1222 */       if ((list == null) || (list.isEmpty())) {
/* 1223 */         return false;
/*      */       }
/*      */ 
/* 1226 */       return true;
/*      */     }
/*      */     catch (Exception e) {
/* 1229 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<Right> getUserRightList(String userId, int resourceType, int roleType, boolean isDistinctControlType)
/*      */   {
/* 1240 */     this.log.debug(" in getUserRightList...");
/*      */ 
/* 1242 */     Sqlca sqlca = null;
/*      */     try {
/* 1244 */       sqlca = new Sqlca(new ConnectionEx());
/*      */ 
/* 1246 */       List result = new ArrayList();
/* 1247 */       rightSet = new HashSet();
/*      */ 
/* 1249 */       StringBuffer sb = new StringBuffer();
/* 1250 */       sb.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/* 1251 */       sb.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/* 1252 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/* 1253 */         sb.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */       }
/* 1255 */       sb.append(", rig.").append(getAccessTypeField()).append(" OPERATION_TYPE");
/* 1256 */       sb.append(", opdef.operationname OPERATION_NAME");
/* 1257 */       sb.append(", rig.controltype CONTROL_TYPE");
/* 1258 */       sb.append(" from ").append(getDefineTable()).append(" resdef,").append(getRoleRightTable()).append(" rig, ");
/* 1259 */       sb.append(" ").append("RESOURCE_OPERATION_DEFINE").append(" opdef ");
/* 1260 */       sb.append(" where 1=1 ");
/*      */ 
/* 1264 */       String accessTypeStr = sqlca.getSql_intTochar("rig." + getAccessTypeField());
/*      */ 
/* 1266 */       String idField = getIdField();
/* 1267 */       if (isNeedConvertIdType()) {
/* 1268 */         idField = sqlca.getSql_intTochar("resdef." + getIdField());
/* 1269 */         this.log.debug("idField:" + idField);
/*      */       }
/* 1271 */       if (isDistinctControlType) {
/* 1272 */         sb.append(" and rig.controltype='").append("1").append("'");
/*      */       }
/* 1274 */       sb.append(" and ").append(idField).append("=rig.resourceid");
/* 1275 */       sb.append(" and opdef.operationkey=").append(accessTypeStr);
/* 1276 */       sb.append(" and opdef.resourcetype=").append(resourceType);
/* 1277 */       sb.append(" and rig.operatorid in('").append(userId).append("')");
/* 1278 */       sb.append(" and rig.resourcetype=").append(resourceType);
/* 1279 */       sb.append(" and rig.operatortype=").append(1);
/*      */ 
/* 1281 */       if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/* 1282 */         sb.append(" and resdef.status=0 ");
/*      */       }
/* 1284 */       if (StringUtils.isNotBlank(getOrderSql())) {
/* 1285 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/* 1288 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql:" + sb.toString());
/* 1289 */       sqlca.execute(sb.toString());
/* 1290 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeOver") + "");
/*      */       Right right;
/* 1292 */       while (sqlca.next()) {
/* 1293 */         right = new Right();
/* 1294 */         right.setRoleType(roleType);
/* 1295 */         right.setResourceId(sqlca.getString("ID_FIELD"));
/* 1296 */         right.setResourceName(sqlca.getString("DESC_FIELD"));
/* 1297 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/* 1298 */           right.setParentId(sqlca.getString("PARENT_FIELD"));
/*      */         else {
/* 1300 */           right.setParentId("0");
/*      */         }
/* 1302 */         right.setOperationType(String.valueOf(sqlca.getInt("OPERATION_TYPE")));
/* 1303 */         right.setOperationName(sqlca.getString("OPERATION_NAME"));
/* 1304 */         right.setResourceType(resourceType);
/* 1305 */         right.setTopId(getTopLevelId());
/*      */ 
/* 1307 */         if (!rightSet.contains(right)) {
/* 1308 */           result.add(right);
/* 1309 */           rightSet.add(right);
/*      */         }
/*      */       }
/* 1312 */       this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuthList") + ":" + result.size());
/* 1313 */       this.log.debug(" end getRightList...");
/* 1314 */       return result;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       Set rightSet;
/* 1316 */       this.log.debug("getRightList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/* 1317 */       return new ArrayList();
/*      */     } finally {
/* 1319 */       if (sqlca != null)
/* 1320 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteRight(String operatorId, int operatorType, int resourceType, String resourceId)
/*      */   {
/* 1327 */     this.log.info("deleteRight begin ............");
/* 1328 */     Connection con = null;
/* 1329 */     PreparedStatement pStmt = null;
/*      */     try {
/* 1331 */       con = getConnection();
/* 1332 */       StringBuffer sql = new StringBuffer(256);
/* 1333 */       sql.append("delete from ").append(getRoleRightTable()).append(" where operatorid=?").append(" and operatortype=?").append(" and resourcetype=?");
/*      */ 
/* 1336 */       if (StringUtils.isNotBlank(resourceId)) {
/* 1337 */         sql.append(" and resourceid=?");
/*      */       }
/* 1339 */       this.log.debug(sql);
/* 1340 */       pStmt = con.prepareStatement(sql.toString());
/* 1341 */       pStmt.setString(1, operatorId);
/* 1342 */       pStmt.setInt(2, operatorType);
/* 1343 */       pStmt.setInt(3, resourceType);
/* 1344 */       if (StringUtils.isNotBlank(resourceId)) {
/* 1345 */         pStmt.setString(4, resourceId);
/*      */       }
/* 1347 */       pStmt.executeUpdate();
/*      */     } catch (Exception ex) {
/* 1349 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/* 1351 */       if (pStmt != null) {
/*      */         try {
/* 1353 */           pStmt.close();
/*      */         } catch (SQLException e) {
/* 1355 */           throw new RuntimeException(e.getMessage());
/*      */         }
/*      */       }
/* 1358 */       if (con != null) {
/* 1359 */         releaseConnection(con);
/*      */       }
/*      */     }
/* 1362 */     this.log.info("deleteRight end ............");
/*      */   }
/*      */ 
/*      */   public void initDaoParameter(int resourceType)
/*      */   {
/* 1368 */     Collection srdpList = SysResourceDsPropCache.getInstance().getObjectByResourceType(resourceType);
/*      */ 
/* 1370 */     if (CollectionUtils.isEmpty(srdpList)) {
/* 1371 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.initResourceDsPropException") + resourceType);
/*      */     }
/*      */ 
/* 1376 */     Map propMap = new HashMap();
/* 1377 */     Iterator it = srdpList.iterator();
/* 1378 */     while (it.hasNext()) {
/* 1379 */       SysResourceDsProp srdp = (SysResourceDsProp)it.next();
/* 1380 */       propMap.put(srdp.getPropKey(), srdp.getPropValue());
/*      */     }
/*      */ 
/* 1383 */     setRoleRightTable((String)propMap.get("roleRightTable"));
/* 1384 */     setDefineTable((String)propMap.get("defineTable"));
/* 1385 */     setIdField((String)propMap.get("idField"));
/* 1386 */     setDescField((String)propMap.get("descField"));
/* 1387 */     setResourceTypeField((String)propMap.get("resourceTypeField"));
/* 1388 */     setAccessTypeField((String)propMap.get("accessTypeField"));
/* 1389 */     if (StringUtils.isNotBlank((String)propMap.get("parentFiled")))
/* 1390 */       setParentFiled((String)propMap.get("parentFiled"));
/*      */     else {
/* 1392 */       setParentFiled("0");
/*      */     }
/* 1394 */     if (StringUtils.isNotBlank((String)propMap.get("sortField")))
/* 1395 */       setSortField((String)propMap.get("sortField"));
/*      */     else {
/* 1397 */       setSortField("");
/*      */     }
/* 1399 */     if (StringUtils.isNotBlank((String)propMap.get("orderSql")))
/* 1400 */       setOrderSql((String)propMap.get("orderSql"));
/*      */     else {
/* 1402 */       setOrderSql("");
/*      */     }
/* 1404 */     if (StringUtils.isNotBlank((String)propMap.get("topLevelId")))
/* 1405 */       setTopLevelId((String)propMap.get("topLevelId"));
/*      */     else {
/* 1407 */       setTopLevelId("-1");
/*      */     }
/* 1409 */     if (StringUtils.isNotBlank((String)propMap.get("checkFrameField"))) {
/* 1410 */       setCheckFrameField((String)propMap.get("checkFrameField"));
/* 1411 */       setCheckFrameValue((String)propMap.get("checkFrameValue"));
/*      */     } else {
/* 1413 */       setCheckFrameField("");
/* 1414 */       setCheckFrameValue("");
/*      */     }
/* 1416 */     if (StringUtils.isNotBlank((String)propMap.get("isAccessType")))
/* 1417 */       setIsAccessType((String)propMap.get("isAccessType"));
/*      */     else {
/* 1419 */       setIsAccessType("0");
/*      */     }
/* 1421 */     if (StringUtils.isNotBlank((String)propMap.get("idVarchar"))) {
/* 1422 */       setIdVarchar(new Boolean((String)propMap.get("idVarchar")).booleanValue());
/*      */ 
/* 1424 */       setIsNeedConvertIdType(new Boolean((String)propMap.get("isNeedConvertIdType")).booleanValue());
/*      */     }
/*      */     else {
/* 1427 */       setIdVarchar(true);
/* 1428 */       setIsNeedConvertIdType(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected int getRoleTypeByResourceType(int resourceType)
/*      */   {
/* 1440 */     SysResourceType srt = SysResourceTypeCache.getInstance().getSysResourceType(resourceType);
/*      */ 
/* 1442 */     if (null != srt) {
/* 1443 */       return srt.getRoleType();
/*      */     }
/* 1445 */     return -1;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.ResourceRightDaoJdbcImpl
 * JD-Core Version:    0.6.2
 */
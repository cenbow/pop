/*      */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.exception.DaoException;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceDsPropCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceDsProp;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.collections.CollectionUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*      */ import org.springframework.jdbc.core.JdbcTemplate;
/*      */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*      */ 
/*      */ public class ResourceRightDaoJdbcImpl_ForMenuItem extends JdbcDaoSupport
/*      */   implements IResourceRightDAO
/*      */ {
/*   68 */   private Logger log = Logger.getLogger(ResourceRightDaoJdbcImpl.class);
/*      */ 
/*   70 */   private String roleRightTable = "USER_RIGHT";
/*      */ 
/*   72 */   private String defineTable = "USER_CITY";
/*      */ 
/*   74 */   private String idField = "cityid";
/*      */ 
/*   76 */   private String descField = "cityname";
/*      */ 
/*   78 */   private String parentFiled = "parentid";
/*      */ 
/*   80 */   private String sortField = "";
/*      */ 
/*   82 */   private String orderSql = "";
/*      */ 
/*   84 */   private String topLevelId = "-1";
/*      */   private String checkFrameField;
/*      */   private String checkFrameValue;
/*   90 */   private boolean idVarchar = true;
/*      */ 
/*   92 */   private String isAccessType = "0";
/*      */   private String accessTypeField;
/*      */   private String resourceTypeField;
/*   98 */   private boolean isNeedConvertIdType = false;
/*      */ 
/*      */   public String getResourceName(String resourceId) {
/*  101 */     Sqlca sqlca = null;
/*      */     try {
/*  103 */       sqlca = new Sqlca(new ConnectionEx());
/*      */ 
/*  105 */       String idField = getIdField();
/*  106 */       if (isNeedConvertIdType()) {
/*  107 */         idField = sqlca.getSql_intTochar(getIdField());
/*  108 */         this.log.debug("idField:" + idField);
/*      */       }
/*      */ 
/*  112 */       String sql = "select " + getDescField() + " from " + getDefineTable() + " where " + idField + "='" + resourceId + "'";
/*      */ 
/*  115 */       this.log.debug("--sql:" + sql);
/*  116 */       List list = getJdbcTemplate().queryForList(sql);
/*      */       String str1;
/*  117 */       if ((list == null) || (list.isEmpty())) {
/*  118 */         return "";
/*      */       }
/*  120 */       return ((Map)list.get(0)).get(getDescField()).toString();
/*      */     } catch (Exception e) {
/*  122 */       this.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryResourceNameFail"), e);
/*      */ 
/*  124 */       throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryResourceNameFail") + ":" + e.getMessage());
/*      */     }
/*      */     finally
/*      */     {
/*  129 */       if (sqlca != null)
/*  130 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void save(RoleRight newRoleRight)
/*      */   {
/*  138 */     this.log.info(" in save............");
/*      */     try {
/*  140 */       List roleRightList = new ArrayList();
/*  141 */       roleRightList.add(newRoleRight);
/*  142 */       save(roleRightList);
/*      */     } catch (Exception ex) {
/*  144 */       ex.printStackTrace();
/*  145 */       throw new RuntimeException(ex.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void save(Collection<RoleRight> roleRightList)
/*      */   {
/*  151 */     this.log.info(" in save............");
/*  152 */     if ((null == roleRightList) || (roleRightList.isEmpty())) {
/*  153 */       return;
/*      */     }
/*  155 */     StringBuffer sql = new StringBuffer(256);
/*  156 */     sql.append("insert into ").append(getRoleRightTable());
/*  157 */     sql.append("(resourceid,resourcetype,operatorid,operatortype,").append(getAccessTypeField()).append(",controltype) ");
/*  158 */     sql.append(" values(?,?,?,?,?,?)");
/*  159 */     final RoleRight[] roleRights = (RoleRight[])roleRightList.toArray(new RoleRight[roleRightList.size()]);
/*  160 */     BatchPreparedStatementSetter setter = new BatchPreparedStatementSetter() {
/*      */       public void setValues(PreparedStatement ps, int i) throws SQLException {
/*  162 */         RoleRight roleRight = roleRights[i];
/*  163 */         Right right = roleRight.getRight();
/*  164 */         ps.setString(1, right.getResourceId());
/*  165 */         ps.setInt(2, right.getResourceType());
/*  166 */         ps.setString(3, roleRight.getRoleId());
/*  167 */         ps.setInt(4, roleRight.getOperatorType());
/*  168 */         ps.setInt(5, Integer.valueOf(right.getOperationType()).intValue());
/*  169 */         ps.setString(6, roleRight.getControlType());
/*      */       }
/*      */       public int getBatchSize() {
/*  172 */         return roleRights.length;
/*      */       }
/*      */     };
/*  175 */     getJdbcTemplate().batchUpdate(sql.toString(), setter);
/*      */   }
/*      */ 
/*      */   public void delete(String operatorId, int resourceType) {
/*  179 */     this.log.info("delete............");
/*  180 */     Connection con = null;
/*  181 */     Statement stmt = null;
/*      */     try {
/*  183 */       con = getConnection();
/*  184 */       stmt = con.createStatement();
/*      */ 
/*  186 */       StringBuffer sql = new StringBuffer(256);
/*  187 */       sql.append("delete from ").append(getRoleRightTable());
/*  188 */       sql.append(" where operatorid='").append(operatorId).append("'");
/*  189 */       sql.append(" and resourcetype=").append(resourceType);
/*      */ 
/*  191 */       this.log.info(sql);
/*  192 */       stmt.executeUpdate(sql.toString());
/*      */     }
/*      */     catch (Exception ex) {
/*  195 */       this.log.error("Error deleting role rights. roleRightTable=" + getRoleRightTable() + ex.getMessage());
/*      */     }
/*      */     finally {
/*  198 */       if (stmt != null)
/*      */         try {
/*  200 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  204 */       if (con != null)
/*  205 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void delete(Collection<RoleRight> roleRightList)
/*      */   {
/*  211 */     this.log.info(" in delete............");
/*  212 */     Connection con = null;
/*  213 */     Statement stmt = null;
/*      */     try {
/*  215 */       con = getConnection();
/*  216 */       stmt = con.createStatement();
/*      */ 
/*  218 */       for (RoleRight roleRight : roleRightList) {
/*  219 */         Right right = roleRight.getRight();
/*  220 */         StringBuffer sql = new StringBuffer(256);
/*  221 */         sql.append("delete from ").append(getRoleRightTable());
/*  222 */         sql.append(" where resourceid='").append(right.getResourceId()).append("'");
/*      */ 
/*  224 */         sql.append(" and resourcetype=").append(right.getResourceType());
/*      */ 
/*  226 */         sql.append(" and operatorid='").append(roleRight.getRoleId()).append("'");
/*      */ 
/*  228 */         sql.append(" and operatortype=0");
/*  229 */         sql.append(" and ").append(getAccessTypeField()).append("=").append(right.getOperationType());
/*      */ 
/*  234 */         this.log.info(sql);
/*  235 */         stmt.execute(sql.toString());
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/*  239 */       ex.printStackTrace();
/*  240 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/*  242 */       if (stmt != null)
/*      */         try {
/*  244 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  248 */       if (con != null)
/*  249 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void delete(List<String> operatorIdList, List<Right> rightList, int resourceType)
/*      */   {
/*  256 */     this.log.info("delete............");
/*  257 */     Connection con = null;
/*  258 */     Statement stmt = null;
/*      */     try {
/*  260 */       con = getConnection();
/*  261 */       stmt = con.createStatement();
/*  262 */       if ((operatorIdList == null) || (operatorIdList.size() == 0)) {
/*      */         return;
/*      */       }
/*  265 */       if ((rightList == null) || (rightList.size() == 0))
/*      */       {
/*      */         return;
/*      */       }
/*  269 */       String operatorIdString = StringUtil.list2String(operatorIdList, ",", true);
/*      */ 
/*  271 */       for (Right right : rightList) {
/*  272 */         StringBuffer sql = new StringBuffer(256);
/*  273 */         sql.append("delete from ").append(getRoleRightTable());
/*  274 */         sql.append(" where 1=1 ");
/*  275 */         sql.append(" and operatorid in (").append(operatorIdString).append(")");
/*      */ 
/*  277 */         sql.append(" and resourcetype=").append(resourceType);
/*  278 */         sql.append(" and resourceid='").append(right.getResourceId()).append("'");
/*      */ 
/*  280 */         sql.append(" and ").append(getAccessTypeField()).append("=").append(right.getOperationType());
/*      */ 
/*  283 */         this.log.info(sql);
/*  284 */         stmt.executeUpdate(sql.toString());
/*      */       }
/*  286 */       stmt.close();
/*      */     } catch (Exception ex) {
/*  288 */       this.log.error("Error deleting role rights. roleRightTable=" + getRoleRightTable() + ex.getMessage());
/*      */     }
/*      */     finally {
/*  291 */       if (stmt != null)
/*      */         try {
/*  293 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  297 */       if (con != null)
/*  298 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  304 */     StringBuffer sb = new StringBuffer();
/*      */ 
/*  306 */     sb.append(super.toString()).append("\n").append("rightTable=" + getRoleRightTable()).append("\n").append("defineTable=" + getDefineTable()).append("\n").append("idField=" + getIdField()).append(",descField=" + getDescField()).append(",parentField=" + getParentFiled()).append(",sortField=" + getSortField()).append("\n").append("orderSql=" + getOrderSql()).append("\n").append("topLevelId=" + getTopLevelId()).append(",idVarchar=" + isIdVarchar());
/*      */ 
/*  317 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public String getCheckFrameField() {
/*  321 */     return this.checkFrameField;
/*      */   }
/*      */ 
/*      */   public void setCheckFrameField(String checkFrameField) {
/*  325 */     this.checkFrameField = checkFrameField;
/*      */   }
/*      */ 
/*      */   public String getCheckFrameValue() {
/*  329 */     return this.checkFrameValue;
/*      */   }
/*      */ 
/*      */   public void setCheckFrameValue(String checkFrameValue) {
/*  333 */     this.checkFrameValue = checkFrameValue;
/*      */   }
/*      */ 
/*      */   public String getTopLevelId() {
/*  337 */     return this.topLevelId;
/*      */   }
/*      */ 
/*      */   public void setTopLevelId(String topLevelId) {
/*  341 */     this.topLevelId = topLevelId;
/*      */   }
/*      */ 
/*      */   public String getRoleRightTable()
/*      */   {
/*  346 */     return this.roleRightTable;
/*      */   }
/*      */ 
/*      */   public String getDefineTable() {
/*  350 */     return this.defineTable;
/*      */   }
/*      */ 
/*      */   public void setDefineTable(String defineTable) {
/*  354 */     this.defineTable = defineTable;
/*      */   }
/*      */ 
/*      */   public String getDescField() {
/*  358 */     return this.descField;
/*      */   }
/*      */ 
/*      */   public void setDescField(String descField) {
/*  362 */     this.descField = descField;
/*      */   }
/*      */ 
/*      */   public String getIdField() {
/*  366 */     return this.idField;
/*      */   }
/*      */ 
/*      */   public void setIdField(String idField) {
/*  370 */     this.idField = idField;
/*      */   }
/*      */ 
/*      */   public boolean isIdVarchar() {
/*  374 */     return this.idVarchar;
/*      */   }
/*      */ 
/*      */   public void setIdVarchar(boolean idVarchar) {
/*  378 */     this.idVarchar = idVarchar;
/*      */   }
/*      */ 
/*      */   public String getOrderSql() {
/*  382 */     return this.orderSql;
/*      */   }
/*      */ 
/*      */   public void setOrderSql(String orderSql) {
/*  386 */     this.orderSql = orderSql;
/*      */   }
/*      */ 
/*      */   public String getParentFiled() {
/*  390 */     return this.parentFiled;
/*      */   }
/*      */ 
/*      */   public void setParentFiled(String parentFiled) {
/*  394 */     this.parentFiled = parentFiled;
/*      */   }
/*      */ 
/*      */   public String getSortField() {
/*  398 */     return this.sortField;
/*      */   }
/*      */ 
/*      */   public void setSortField(String sortField) {
/*  402 */     this.sortField = sortField;
/*      */   }
/*      */ 
/*      */   public void setRoleRightTable(String roleRightTable) {
/*  406 */     this.roleRightTable = roleRightTable;
/*      */   }
/*      */ 
/*      */   public String getIsAccessType() {
/*  410 */     return this.isAccessType;
/*      */   }
/*      */ 
/*      */   public void setIsAccessType(String isAccessType) {
/*  414 */     this.isAccessType = isAccessType;
/*      */   }
/*      */ 
/*      */   public String getAccessTypeField() {
/*  418 */     return this.accessTypeField;
/*      */   }
/*      */ 
/*      */   public void setAccessTypeField(String accessTypeField) {
/*  422 */     this.accessTypeField = accessTypeField;
/*      */   }
/*      */ 
/*      */   public String getResourceTypeField() {
/*  426 */     return this.resourceTypeField;
/*      */   }
/*      */ 
/*      */   public void setResourceTypeField(String resourceTypeField) {
/*  430 */     this.resourceTypeField = resourceTypeField;
/*      */   }
/*      */ 
/*      */   public boolean isNeedConvertIdType() {
/*  434 */     return this.isNeedConvertIdType;
/*      */   }
/*      */ 
/*      */   public void setIsNeedConvertIdType(boolean isNeedConvertIdType) {
/*  438 */     this.isNeedConvertIdType = isNeedConvertIdType;
/*      */   }
/*      */ 
/*      */   protected int getRoleType(String roleId)
/*      */   {
/*  449 */     this.log.debug(" in getRoleType ");
/*  450 */     Connection con = getConnection();
/*  451 */     Statement stmt = null;
/*  452 */     ResultSet rs = null;
/*      */     try {
/*  454 */       stmt = con.createStatement();
/*  455 */       String sql = "select role_type from user_role where role_id='" + roleId + "'";
/*      */ 
/*  457 */       this.log.debug("--sql:" + sql);
/*      */ 
/*  459 */       rs = stmt.executeQuery(sql);
/*  460 */       int roleType = -1;
/*  461 */       while (rs.next()) {
/*  462 */         roleType = rs.getInt("ROLE_TYPE");
/*      */       }
/*  464 */       this.log.debug(" end getRoleType ");
/*  465 */       return roleType;
/*      */     } catch (Exception e) {
/*  467 */       throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRoleTypeFail"), e);
/*      */     }
/*      */     finally
/*      */     {
/*      */       try {
/*  472 */         if (rs != null) {
/*  473 */           rs.close();
/*      */         }
/*  475 */         if (stmt != null)
/*  476 */           stmt.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  479 */         e.printStackTrace();
/*      */       }
/*  481 */       if (con != null)
/*  482 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public RoleRight getRoleRight(String roleId, int resourceType, String resourceId, String operationType)
/*      */   {
/*  490 */     this.log.debug(" in getRoleRight...");
/*  491 */     List roleRightList = getRoleRightListByRole(roleId, resourceType);
/*      */ 
/*  493 */     for (RoleRight roleRight : roleRightList) {
/*  494 */       Right right = roleRight.getRight();
/*  495 */       if ((resourceId.equals(right.getResourceId())) && (operationType.equals(right.getOperationType())))
/*      */       {
/*  497 */         return roleRight;
/*      */       }
/*      */     }
/*  500 */     return new RoleRight();
/*      */   }
/*      */ 
/*      */   public List<Right> getRightList(String roleId, int resourceType, boolean isDistinctControlType)
/*      */   {
/*  509 */     List roleIdList = new ArrayList();
/*  510 */     roleIdList.add(roleId);
/*  511 */     return getRightList(roleIdList, resourceType, isDistinctControlType);
/*      */   }
/*      */ 
/*      */   public String getInSqlStr(List<String> valueList, boolean addQuote, StringBuffer sb)
/*      */   {
/*  516 */     String separator = ",";
/*  517 */     if ((null == valueList) || (valueList.isEmpty())) {
/*  518 */       return sb.toString();
/*      */     }
/*      */ 
/*  521 */     int maxLength = 950;
/*  522 */     int i = 0; for (int size = valueList.size(); i < size; i++) {
/*  523 */       if (sb.length() / maxLength > 1) {
/*  524 */         getInSqlStr(valueList.subList(i, size), addQuote, sb);
/*      */       }
/*  526 */       sb.append(addQuote ? "'" : "").append((String)valueList.get(i)).append(addQuote ? "'" : "").append(separator);
/*      */     }
/*      */ 
/*  530 */     return sb.substring(0, sb.length() - 1);
/*      */   }
/*      */ 
/*      */   public List<Right> getRightList(List<String> roleIdList, int resourceType, boolean isDistinctControlType)
/*      */   {
/*  539 */     this.log.debug(" in getRightList...");
/*  540 */     Sqlca sqlca = null;
/*  541 */     Connection con = null;
/*  542 */     Statement stmt2 = null;
/*  543 */     ResultSet rs2 = null;
/*      */     try {
/*  545 */       sqlca = new Sqlca(new ConnectionEx());
/*  546 */       if (((roleIdList == null) || (roleIdList.isEmpty())) && (resourceType != Integer.parseInt("50")))
/*      */       {
/*  549 */         return new ArrayList();
/*      */       }
/*      */ 
/*  552 */       con = getConnection();
/*  553 */       stmt2 = con.createStatement();
/*  554 */       boolean hasCheckFrameField = hasCheckFrameField();
/*      */ 
/*  556 */       roleType = 0;
/*  557 */       roleType = getRoleTypeByResourceType(resourceType);
/*      */ 
/*  559 */       List result = new ArrayList();
/*  560 */       Set rightSet = new HashSet();
/*  561 */       if ((roleIdList != null) && (!roleIdList.isEmpty()))
/*      */       {
/*  563 */         StringBuffer sb = new StringBuffer();
/*  564 */         sb.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/*      */ 
/*  566 */         sb.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/*      */ 
/*  568 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */         {
/*  570 */           sb.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */         }
/*      */ 
/*  573 */         sb.append(", rig.").append(getAccessTypeField()).append(" OPERATION_TYPE");
/*      */ 
/*  575 */         sb.append(", opdef.operationname OPERATION_NAME");
/*  576 */         sb.append(", rig.controltype CONTROL_TYPE");
/*      */ 
/*  578 */         if (hasCheckFrameField) {
/*  579 */           sb.append(", resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD");
/*      */         }
/*      */ 
/*  582 */         sb.append(" from ").append(getDefineTable()).append(" resdef,");
/*      */ 
/*  586 */         String as = "";
/*  587 */         if (!sqlca.getDBMSType().equalsIgnoreCase("ORACLE")) {
/*  588 */           as = "as";
/*      */         }
/*  590 */         sb.append(" (");
/*  591 */         sb.append(" select resourceid,accesstype,controltype from (");
/*  592 */         sb.append(" select * from ").append(getRoleRightTable()).append(" smr where smr.resourcetype=").append(resourceType).append(" and smr.operatorid in (").append(StringUtil.list2String(roleIdList, ",", true)).append(")");
/*      */ 
/*  597 */         sb.append(") ").append(as).append(" a group by resourceid,accesstype,controltype ");
/*  598 */         sb.append(") ").append(as).append(" rig, ");
/*      */ 
/*  603 */         sb.append(" (");
/*  604 */         sb.append(" select * from ").append("RESOURCE_OPERATION_DEFINE").append(" where resourcetype=").append(resourceType);
/*      */ 
/*  607 */         sb.append(") ").append(as).append(" opdef ");
/*      */ 
/*  609 */         sb.append(" where 1=1 ");
/*      */ 
/*  613 */         String accessTypeStr = sqlca.getSql_intTochar("rig." + getAccessTypeField());
/*      */ 
/*  616 */         if (isDistinctControlType) {
/*  617 */           sb.append(" and rig.controltype='").append("1").append("'");
/*      */         }
/*      */ 
/*  621 */         String idField = getIdField();
/*  622 */         String dbType = sqlca.getDBMSType();
/*  623 */         if (isNeedConvertIdType()) {
/*  624 */           if (dbType.equalsIgnoreCase("DB2")) {
/*  625 */             sb.append(" and ").append("resdef." + idField).append("=int(rig.resourceid)");
/*      */           } else {
/*  627 */             idField = sqlca.getSql_intTochar("resdef." + getIdField());
/*  628 */             sb.append(" and ").append(idField).append("=rig.resourceid");
/*      */           }
/*  630 */           this.log.debug("idField:" + idField);
/*      */         } else {
/*  632 */           sb.append(" and ").append("resdef." + idField).append("=rig.resourceid");
/*      */         }
/*  634 */         if (dbType.equalsIgnoreCase("DB2")) {
/*  635 */           sb.append(" and int(opdef.operationkey)=").append("rig." + getAccessTypeField());
/*      */         }
/*      */         else {
/*  638 */           sb.append(" and opdef.operationkey=").append(accessTypeStr);
/*      */         }
/*      */ 
/*  645 */         if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  646 */           sb.append(" and resdef.status=0 ");
/*      */         }
/*  648 */         if (StringUtils.isNotBlank(getOrderSql())) {
/*  649 */           sb.append(" ").append(getOrderSql());
/*      */         }
/*      */ 
/*  653 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql:" + sb.toString());
/*      */ 
/*  658 */         rs2 = stmt2.executeQuery(sb.toString());
/*  659 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeOver") + "");
/*      */ 
/*  666 */         while (rs2.next())
/*      */         {
/*  669 */           Right right = new Right();
/*  670 */           right.setRoleType(roleType);
/*  671 */           right.setResourceId(rs2.getString("ID_FIELD"));
/*  672 */           right.setResourceName(rs2.getString("DESC_FIELD"));
/*  673 */           if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */           {
/*  675 */             right.setParentId(rs2.getString("PARENT_FIELD"));
/*      */           }
/*  677 */           else right.setParentId("0");
/*      */ 
/*  679 */           right.setOperationType(String.valueOf(rs2.getInt("OPERATION_TYPE")));
/*      */ 
/*  681 */           right.setOperationName(rs2.getString("OPERATION_NAME"));
/*  682 */           if (hasCheckFrameField) {
/*  683 */             right.setHasCheckFrame(getCheckFrameValue().equals(rs2.getString("CHECK_FRAME_FIELD")));
/*      */           }
/*      */ 
/*  686 */           right.setResourceType(resourceType);
/*  687 */           right.setTopId(getTopLevelId());
/*      */ 
/*  689 */           if (!rightSet.contains(right)) {
/*  690 */             result.add(right);
/*  691 */             rightSet.add(right);
/*      */           }
/*      */         }
/*  694 */         this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuthList") + ":" + result.size());
/*      */       }
/*      */       StringBuffer allSql;
/*  702 */       if (hasCheckFrameField) {
/*  703 */         allSql = new StringBuffer();
/*  704 */         allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*      */ 
/*  706 */         allSql.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*      */ 
/*  708 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */         {
/*  710 */           allSql.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*      */         }
/*      */ 
/*  713 */         allSql.append("resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD ");
/*      */ 
/*  716 */         allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*      */ 
/*  718 */         allSql.append(" where 1=1 and resdef.").append(getCheckFrameField()).append("=0 ");
/*      */ 
/*  720 */         if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  721 */           allSql.append(" and resdef.status=0 ");
/*      */         }
/*      */ 
/*  729 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.shareAuth") + "sql:" + allSql.toString());
/*      */ 
/*  734 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryShareAuthOver") + "");
/*      */ 
/*  737 */         boolean isDisOper = isDistinguishOperation(resourceType);
/*  738 */         List list = getJdbcTemplate().queryForList(allSql.toString());
/*      */         String defaultOperationName;
/*      */         String defaultOperationType;
/*      */         String defaultOperationName;
/*  742 */         if (isDisOper) {
/*  743 */           String defaultOperationType = "0";
/*  744 */           defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.view") + "";
/*      */         }
/*      */         else
/*      */         {
/*  748 */           defaultOperationType = "-1";
/*  749 */           defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.noDiffOperationAuth") + "";
/*      */         }
/*      */ 
/*  754 */         for (int i = 0; i < list.size(); i++) {
/*  755 */           String resId = ((Map)list.get(i)).get("ID_FIELD").toString();
/*  756 */           String resName = ((Map)list.get(i)).get("DESC_FIELD").toString();
/*  757 */           String pId = ((Map)list.get(i)).get("PARENT_FIELD").toString();
/*  758 */           String hasCheckFrame = ((Map)list.get(i)).get("CHECK_FRAME_FIELD").toString();
/*  759 */           Right right = new Right();
/*  760 */           right.setRoleType(roleType);
/*  761 */           right.setResourceId(resId);
/*  762 */           right.setResourceName(resName);
/*  763 */           if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */           {
/*  765 */             right.setParentId(pId);
/*      */           }
/*  767 */           else right.setParentId("0");
/*      */ 
/*  769 */           right.setHasCheckFrame(getCheckFrameValue().equals(hasCheckFrame));
/*      */ 
/*  771 */           right.setOperationType(defaultOperationType);
/*  772 */           right.setOperationName(defaultOperationName);
/*  773 */           right.setResourceType(resourceType);
/*  774 */           right.setTopId(getTopLevelId());
/*      */ 
/*  776 */           if (!rightSet.contains(right)) {
/*  777 */             result.add(right);
/*  778 */             rightSet.add(right);
/*      */           }
/*      */         }
/*  781 */         this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.finalAuthList") + ":" + result.size());
/*      */       }
/*      */ 
/*  787 */       this.log.debug(" end getRightList...");
/*  788 */       return result;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       int roleType;
/*  790 */       ex.printStackTrace();
/*  791 */       this.log.debug("getRightList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*      */ 
/*  794 */       return new ArrayList();
/*      */     } finally {
/*  796 */       if (sqlca != null) {
/*  797 */         sqlca.closeAll();
/*      */       }
/*  799 */       if (rs2 != null) {
/*      */         try {
/*  801 */           rs2.close();
/*      */         } catch (SQLException e) {
/*  803 */           e.printStackTrace();
/*      */         }
/*      */       }
/*  806 */       if (stmt2 != null) {
/*      */         try {
/*  808 */           stmt2.close();
/*      */         } catch (SQLException e) {
/*  810 */           e.printStackTrace();
/*      */         }
/*      */       }
/*  813 */       if (con != null)
/*  814 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected boolean hasCheckFrameField()
/*      */   {
/*  821 */     return StringUtils.isNotBlank(getCheckFrameField());
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(int roleType, int resourceType) {
/*  825 */     this.log.debug(" in getAllRightList...");
/*  826 */     List result = new ArrayList();
/*      */     try
/*      */     {
/*  829 */       StringBuffer sb = new StringBuffer();
/*  830 */       sb.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*      */ 
/*  832 */       sb.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*  833 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */       {
/*  835 */         sb.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*      */       }
/*      */ 
/*  838 */       sb.append("opdef.operationkey OPERATION_KEY,");
/*  839 */       sb.append("opdef.operationname OPERATION_NAME");
/*  840 */       if (hasCheckFrameField()) {
/*  841 */         sb.append(",resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD");
/*      */       }
/*      */ 
/*  846 */       String defineTable = getDefineTable();
/*  847 */       if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  848 */         defineTable = "(select * from " + getDefineTable() + "  where STATUS=0 ) ";
/*      */       }
/*      */ 
/*  852 */       sb.append(" from ").append(defineTable).append(" resdef left outer join ");
/*      */ 
/*  854 */       sb.append("RESOURCE_OPERATION_DEFINE").append(" opdef ");
/*      */ 
/*  856 */       sb.append(" on opdef.RESOURCETYPE=").append(resourceType);
/*  857 */       sb.append(" where resdef.").append(getResourceTypeField()).append("=opdef.resourcetype ");
/*      */ 
/*  860 */       if (StringUtils.isNotBlank(getOrderSql())) {
/*  861 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/*  864 */       this.log.info(sb.toString());
/*      */ 
/*  866 */       List list = getJdbcTemplate().queryForList(sb.toString());
/*      */ 
/*  868 */       for (Map map : list) {
/*  869 */         Right right = new Right();
/*  870 */         right.setRoleType(roleType);
/*      */ 
/*  872 */         right.setResourceId(map.get("ID_FIELD").toString());
/*  873 */         right.setResourceName(map.get("DESC_FIELD").toString());
/*  874 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */         {
/*  876 */           right.setParentId(map.get("PARENT_FIELD").toString());
/*      */         }
/*  878 */         else right.setParentId("0");
/*      */ 
/*  880 */         right.setOperationType(map.get("OPERATION_KEY").toString());
/*  881 */         right.setOperationName(map.get("OPERATION_NAME").toString());
/*  882 */         if (hasCheckFrameField()) {
/*  883 */           right.setHasCheckFrame(getCheckFrameValue().equals(map.get("CHECK_FRAME_FIELD").toString()));
/*      */         }
/*      */ 
/*  886 */         right.setResourceType(resourceType);
/*  887 */         right.setTopId(getTopLevelId());
/*      */ 
/*  889 */         result.add(right);
/*      */       }
/*  891 */       return result;
/*      */     } catch (Exception ex) {
/*  893 */       this.log.debug("getRoleRightListByRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*      */     }
/*      */ 
/*  896 */     return new ArrayList();
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightListByRight(Right currRight)
/*      */   {
/*  902 */     this.log.debug(" in getRoleRightListByRight...");
/*      */ 
/*  904 */     Connection con = null;
/*  905 */     Statement stmt = null;
/*      */     try {
/*  907 */       con = getConnection();
/*  908 */       stmt = con.createStatement();
/*      */ 
/*  910 */       StringBuffer sb = new StringBuffer();
/*  911 */       sb.append("select operatorid,controltype ");
/*  912 */       sb.append(" from ").append(getRoleRightTable());
/*  913 */       sb.append(" where 1=1");
/*  914 */       sb.append(" and resourceid='").append(currRight.getResourceId()).append("'");
/*      */ 
/*  916 */       sb.append(" and resourcetype=").append(currRight.getResourceType());
/*  917 */       sb.append(" and ").append(getAccessTypeField()).append("=").append(currRight.getOperationType());
/*      */ 
/*  920 */       this.log.info(sb.toString());
/*      */ 
/*  922 */       ResultSet rs = stmt.executeQuery(sb.toString());
/*      */ 
/*  924 */       List roleRightList = new ArrayList();
/*      */       RoleRight roleRight;
/*  925 */       while (rs.next()) {
/*  926 */         roleRight = new RoleRight();
/*  927 */         roleRight.setControlType(rs.getString(2));
/*  928 */         roleRight.setRight(currRight);
/*  929 */         roleRight.setRoleId(rs.getString(1));
/*  930 */         roleRightList.add(roleRight);
/*      */       }
/*      */ 
/*  933 */       rs.close();
/*      */ 
/*  935 */       return roleRightList;
/*      */     } catch (Exception ex) {
/*  937 */       ex.printStackTrace();
/*  938 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/*  940 */       if (stmt != null)
/*      */         try {
/*  942 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  946 */       if (con != null)
/*  947 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightListByRole(String roleId, int resourceType)
/*      */   {
/*  954 */     this.log.debug(" in getRoleRightListByRole...");
/*      */     try {
/*  956 */       List roleIdList = new ArrayList();
/*  957 */       roleIdList.add(roleId);
/*  958 */       return getRoleRightListByRoles(roleIdList, resourceType);
/*      */     } catch (Exception ex) {
/*  960 */       this.log.error("getRoleRightListByRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + "", ex);
/*      */ 
/*  963 */       throw new RuntimeException(ex.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected List<RoleRight> getRoleRightListByRoles(List<String> roleIdList, int resourceType)
/*      */   {
/*  969 */     this.log.debug(" in getRoleRightListByRoles...");
/*  970 */     Sqlca sqlca = null;
/*  971 */     Connection con = null;
/*  972 */     Statement stmt = null;
/*      */     try {
/*  974 */       con = getConnection();
/*  975 */       stmt = con.createStatement();
/*  976 */       sqlca = new Sqlca(new ConnectionEx());
/*  977 */       if ((roleIdList == null) || (roleIdList.isEmpty())) {
/*  978 */         return new ArrayList();
/*      */       }
/*      */ 
/*  981 */       boolean hasCheckFrameField = hasCheckFrameField();
/*  982 */       result = new ArrayList();
/*      */ 
/*  984 */       int roleType = getRoleTypeByResourceType(resourceType);
/*      */ 
/*  987 */       StringBuffer sb = new StringBuffer();
/*  988 */       sb.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*      */ 
/*  990 */       sb.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*  991 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */       {
/*  993 */         sb.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*      */       }
/*      */ 
/*  996 */       sb.append("rig.").append(getAccessTypeField()).append(" OPERATION_TYPE,");
/*      */ 
/*  998 */       sb.append("opdef.operationname OPERATION_NAME,");
/*  999 */       sb.append("rig.controltype CONTROL_TYPE,");
/* 1000 */       sb.append("rig.operatorid OPERATOR_ID ");
/* 1001 */       if (hasCheckFrameField) {
/* 1002 */         sb.append(",resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD");
/*      */       }
/*      */ 
/* 1005 */       sb.append(" from ").append(getDefineTable()).append(" resdef,").append(getRoleRightTable()).append(" rig, ");
/*      */ 
/* 1007 */       sb.append(" ").append("RESOURCE_OPERATION_DEFINE").append(" opdef ");
/*      */ 
/* 1009 */       sb.append(" where 1=1 ");
/*      */ 
/* 1012 */       String accessTypeStr = sqlca.getSql_intTochar("rig." + getAccessTypeField());
/*      */ 
/* 1016 */       String idField = getIdField();
/* 1017 */       String dbType = sqlca.getDBMSType();
/* 1018 */       if (isNeedConvertIdType()) {
/* 1019 */         if (dbType.equalsIgnoreCase("DB2")) {
/* 1020 */           sb.append(" and ").append("resdef." + idField).append("=int(rig.resourceid)");
/*      */         } else {
/* 1022 */           idField = sqlca.getSql_intTochar("resdef." + getIdField());
/* 1023 */           sb.append(" and ").append(idField).append("=rig.resourceid");
/*      */         }
/* 1025 */         this.log.debug("idField:" + idField);
/*      */       } else {
/* 1027 */         sb.append(" and ").append("resdef." + idField).append("=rig.resourceid");
/*      */       }
/* 1029 */       if (dbType.equalsIgnoreCase("DB2"))
/* 1030 */         sb.append(" and int(opdef.operationkey)=").append("rig." + getAccessTypeField());
/*      */       else {
/* 1032 */         sb.append(" and opdef.operationkey=").append(accessTypeStr);
/*      */       }
/* 1034 */       sb.append(" and opdef.resourcetype=").append(resourceType);
/* 1035 */       sb.append(" and rig.operatorid in(").append(StringUtil.list2String(roleIdList, ",", true)).append(") ");
/*      */ 
/* 1037 */       sb.append(" and rig.resourcetype=").append(resourceType);
/*      */ 
/* 1039 */       if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/* 1040 */         sb.append(" and resdef.status=0 ");
/*      */       }
/* 1042 */       if (StringUtils.isNotBlank(getOrderSql())) {
/* 1043 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/* 1046 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql:" + sb.toString());
/*      */ 
/* 1051 */       ResultSet rs2 = stmt.executeQuery(sb.toString());
/* 1052 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeOver") + "");
/*      */ 
/* 1058 */       Map rightMap = new HashMap();
/* 1059 */       while (rs2.next())
/*      */       {
/* 1062 */         Right right = new Right();
/* 1063 */         right.setRoleType(roleType);
/* 1064 */         right.setResourceId(rs2.getString("ID_FIELD"));
/* 1065 */         right.setResourceName(rs2.getString("DESC_FIELD"));
/* 1066 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */         {
/* 1068 */           right.setParentId(rs2.getString("PARENT_FIELD"));
/*      */         }
/* 1070 */         else right.setParentId("0");
/*      */ 
/* 1072 */         right.setOperationType(String.valueOf(rs2.getInt("OPERATION_TYPE")));
/*      */ 
/* 1074 */         right.setOperationName(rs2.getString("OPERATION_NAME"));
/* 1075 */         if (hasCheckFrameField) {
/* 1076 */           right.setHasCheckFrame(getCheckFrameValue().equals(rs2.getString("CHECK_FRAME_FIELD")));
/*      */         }
/*      */ 
/* 1079 */         right.setResourceType(resourceType);
/* 1080 */         right.setTopId(getTopLevelId());
/*      */ 
/* 1082 */         RoleRight roleRight = new RoleRight();
/* 1083 */         roleRight.setRoleId(rs2.getString("OPERATOR_ID"));
/* 1084 */         roleRight.setRight(right);
/* 1085 */         roleRight.setControlType(rs2.getString("CONTROL_TYPE"));
/* 1086 */         String mapKey = roleRight.getRoleId() + "|" + roleRight.getRight().getResourceId() + "|" + roleRight.getRight().getResourceType() + "|" + roleRight.getOperatorType() + "|" + roleRight.getRight().getOperationType();
/*      */ 
/* 1091 */         rightMap.put(mapKey, roleRight);
/* 1092 */         result.add(roleRight);
/*      */       }
/* 1094 */       this.log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuthList") + ":" + result.size());
/*      */ 
/* 1098 */       rs2.close();
/*      */       StringBuffer allSql;
/* 1101 */       if (hasCheckFrameField) {
/* 1102 */         allSql = new StringBuffer();
/* 1103 */         allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*      */ 
/* 1105 */         allSql.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*      */ 
/* 1107 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */         {
/* 1109 */           allSql.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*      */         }
/*      */ 
/* 1112 */         allSql.append("resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD ");
/*      */ 
/* 1115 */         allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*      */ 
/* 1117 */         allSql.append(" where 1=1 and resdef.").append(getCheckFrameField()).append("=0 ");
/*      */ 
/* 1119 */         if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/* 1120 */           allSql.append(" and resdef.status=0 ");
/*      */         }
/*      */ 
/* 1128 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.shareAuth") + "sql:" + allSql.toString());
/*      */ 
/* 1133 */         ResultSet rs1 = stmt.executeQuery(allSql.toString());
/* 1134 */         this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryShareAuthOver") + "");
/*      */ 
/* 1138 */         boolean isDisOper = isDistinguishOperation(resourceType);
/*      */         String defaultOperationName;
/*      */         String defaultOperationType;
/*      */         String defaultOperationName;
/* 1143 */         if (isDisOper) {
/* 1144 */           String defaultOperationType = "0";
/* 1145 */           defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.view") + "";
/*      */         }
/*      */         else
/*      */         {
/* 1149 */           defaultOperationType = "-1";
/* 1150 */           defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.noDiffOperationAuth") + "";
/*      */         }
/*      */         Right right;
/* 1156 */         while (rs1.next()) {
/* 1157 */           right = new Right();
/* 1158 */           right.setRoleType(roleType);
/* 1159 */           right.setResourceId(rs1.getString("ID_FIELD"));
/* 1160 */           right.setResourceName(rs1.getString("DESC_FIELD"));
/* 1161 */           if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */           {
/* 1163 */             right.setParentId(rs1.getString("PARENT_FIELD"));
/*      */           }
/* 1165 */           else right.setParentId("0");
/*      */ 
/* 1167 */           right.setHasCheckFrame(getCheckFrameValue().equals(rs1.getString("CHECK_FRAME_FIELD")));
/*      */ 
/* 1169 */           right.setOperationType(defaultOperationType);
/* 1170 */           right.setOperationName(defaultOperationName);
/* 1171 */           right.setResourceType(resourceType);
/* 1172 */           right.setTopId(getTopLevelId());
/*      */ 
/* 1175 */           for (String roleId : roleIdList) {
/* 1176 */             RoleRight roleRight = new RoleRight();
/* 1177 */             roleRight.setRoleId(roleId);
/* 1178 */             roleRight.setRight(right);
/* 1179 */             roleRight.setControlType("0");
/* 1180 */             String mapKey = roleRight.getRoleId() + "|" + roleRight.getRight().getResourceId() + "|" + roleRight.getRight().getResourceType() + "|" + roleRight.getOperatorType() + "|" + roleRight.getRight().getOperationType();
/*      */ 
/* 1185 */             if (null == rightMap.get(mapKey)) {
/* 1186 */               result.add(roleRight);
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1192 */         rs1.close();
/* 1193 */         this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.finalAuthList") + ":" + result.size());
/*      */       }
/*      */ 
/* 1199 */       this.log.debug(" end getRoleRightListByRoles...");
/* 1200 */       return result;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       List result;
/* 1202 */       this.log.debug("getRoleRightListByRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*      */ 
/* 1205 */       return new ArrayList();
/*      */     } finally {
/* 1207 */       if (sqlca != null) {
/* 1208 */         sqlca.closeAll();
/*      */       }
/* 1210 */       if (stmt != null)
/*      */         try {
/* 1212 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/* 1216 */       if (con != null)
/* 1217 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean isDistinguishOperation(int resourceType)
/*      */   {
/* 1223 */     this.log.debug(" in isDistinguishOperation...");
/*      */ 
/* 1225 */     Connection con = null;
/* 1226 */     Statement stmt = null;
/*      */     try {
/* 1228 */       con = getConnection();
/* 1229 */       stmt = con.createStatement();
/* 1230 */       String sql = "select operationkey from RESOURCE_OPERATION_DEFINE where resourcetype=" + resourceType;
/*      */ 
/* 1234 */       List opKeyList = new ArrayList();
/* 1235 */       ResultSet rs = stmt.executeQuery(sql);
/* 1236 */       while (rs.next())
/* 1237 */         opKeyList.add(rs.getString(1));
/*      */       boolean bool;
/* 1239 */       if (opKeyList.size() == 0) {
/* 1240 */         return false;
/*      */       }
/* 1242 */       if ((opKeyList.size() == 1) && ("-1".equals(opKeyList.get(0))))
/*      */       {
/* 1245 */         return false;
/*      */       }
/* 1247 */       return true;
/*      */     } catch (Exception ex) {
/* 1249 */       ex.printStackTrace();
/* 1250 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/* 1252 */       if (stmt != null)
/*      */         try {
/* 1254 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/* 1258 */       if (con != null)
/* 1259 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<String> getAllParentIds(String resourceId)
/*      */   {
/* 1268 */     List allParnetIdList = new ArrayList();
/*      */ 
/* 1270 */     getAllParentIds(allParnetIdList, resourceId);
/*      */ 
/* 1272 */     return allParnetIdList;
/*      */   }
/*      */ 
/*      */   protected List<String> getAllParentIds(List<String> allParnetIdList, String resourceId)
/*      */   {
/* 1284 */     StringBuffer sql = new StringBuffer(128);
/* 1285 */     sql.append("select ").append(getParentFiled()).append(" from ").append(getDefineTable());
/*      */ 
/* 1287 */     sql.append(" where ").append(getIdField());
/* 1288 */     if (isIdVarchar())
/* 1289 */       sql.append("='").append(resourceId).append("'");
/*      */     else {
/* 1291 */       sql.append("=").append(resourceId);
/*      */     }
/* 1293 */     this.log.debug("--sql:" + sql);
/*      */ 
/* 1295 */     String parentId = (String)getJdbcTemplate().queryForObject(sql.toString(), String.class);
/*      */ 
/* 1299 */     if ((StringUtils.isBlank(parentId)) || ("0".equals(parentId)) || ("-1".equals(parentId)) || ("-2".equals(parentId)))
/*      */     {
/* 1301 */       return allParnetIdList;
/*      */     }
/*      */ 
/* 1304 */     allParnetIdList.add(parentId);
/*      */ 
/* 1306 */     getAllParentIds(allParnetIdList, parentId);
/*      */ 
/* 1308 */     return allParnetIdList;
/*      */   }
/*      */ 
/*      */   public void updateControlType(String roleId, int resourceType, String resourceId, String controlType)
/*      */   {
/* 1317 */     StringBuffer sql = new StringBuffer(128);
/* 1318 */     sql.append("update ").append(getRoleRightTable());
/* 1319 */     sql.append(" set controltype='").append(controlType).append("'");
/* 1320 */     sql.append(" where resourceid='").append(resourceId).append("'");
/* 1321 */     sql.append(" and resourcetype=").append(resourceType);
/* 1322 */     sql.append(" and operatorid='").append(roleId).append("'");
/*      */ 
/* 1324 */     getJdbcTemplate().execute(sql.toString());
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(String resourceName, int resourceType)
/*      */   {
/*      */     try
/*      */     {
/* 1332 */       List result = new ArrayList();
/* 1333 */       StringBuffer allSql = new StringBuffer();
/* 1334 */       allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/*      */ 
/* 1336 */       allSql.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/*      */ 
/* 1338 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */       {
/* 1340 */         allSql.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */       }
/*      */ 
/* 1343 */       allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*      */ 
/* 1345 */       allSql.append(" where 1=1 and resdef.").append(getDescField()).append("='").append(resourceName).append("'");
/*      */ 
/* 1347 */       allSql.append(" and resdef.").append(getResourceTypeField()).append("=").append(resourceType);
/*      */ 
/* 1349 */       this.log.debug("--sql:" + allSql);
/*      */ 
/* 1351 */       List list = getJdbcTemplate().queryForList(allSql.toString());
/*      */ 
/* 1353 */       if ((list == null) || (list.isEmpty())) {
/* 1354 */         return null;
/*      */       }
/* 1356 */       for (Map map : list) {
/* 1357 */         Right right = new Right();
/* 1358 */         right.setResourceId(String.valueOf(map.get("ID_FIELD")));
/* 1359 */         right.setParentId(String.valueOf(map.get("PARENT_FIELD")));
/* 1360 */         right.setResourceName(resourceName);
/* 1361 */         right.setResourceType(resourceType);
/* 1362 */         result.add(right);
/*      */       }
/* 1364 */       this.log.debug(" end getAllRightList ");
/* 1365 */       return result;
/*      */     } catch (Exception e) {
/* 1367 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(String resourceName)
/*      */   {
/*      */     try {
/* 1374 */       List result = new ArrayList();
/* 1375 */       StringBuffer allSql = new StringBuffer();
/* 1376 */       allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*      */ 
/* 1378 */       allSql.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*      */ 
/* 1380 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */       {
/* 1382 */         allSql.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */       }
/*      */ 
/* 1385 */       allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*      */ 
/* 1387 */       allSql.append(" where 1=1 and resdef.").append(getDescField()).append("='").append(resourceName).append("'");
/*      */ 
/* 1389 */       this.log.debug("--sql:" + allSql);
/*      */ 
/* 1391 */       List list = getJdbcTemplate().queryForList(allSql.toString());
/*      */ 
/* 1393 */       if ((list == null) || (list.isEmpty())) {
/* 1394 */         return null;
/*      */       }
/* 1396 */       for (Map map : list) {
/* 1397 */         Right right = new Right();
/* 1398 */         right.setResourceId(((String)map.get("ID_FIELD")).toString());
/* 1399 */         right.setParentId(((String)map.get("PARENT_FIELD")).toString());
/* 1400 */         right.setResourceName(resourceName);
/*      */ 
/* 1402 */         result.add(right);
/*      */       }
/* 1404 */       this.log.debug(" end getAllRightList ");
/* 1405 */       return result;
/*      */     } catch (Exception e) {
/* 1407 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public Right getRight(String resouceId)
/*      */   {
/*      */     try {
/* 1414 */       Right right = new Right();
/* 1415 */       StringBuffer allSql = new StringBuffer();
/* 1416 */       allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*      */ 
/* 1418 */       allSql.append("resdef.").append(getDescField()).append(" DESC_FIELD ");
/*      */ 
/* 1420 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */       {
/* 1422 */         allSql.append(",resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */       }
/*      */ 
/* 1425 */       allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*      */ 
/* 1427 */       allSql.append(" where 1=1 and resdef.").append(getIdField());
/* 1428 */       if (isIdVarchar())
/* 1429 */         allSql.append("='").append(resouceId).append("'");
/*      */       else {
/* 1431 */         allSql.append("=").append(resouceId);
/*      */       }
/* 1433 */       this.log.debug("--sql:" + allSql);
/*      */ 
/* 1435 */       List list = getJdbcTemplate().queryForList(allSql.toString());
/* 1436 */       if ((list == null) || (list.isEmpty())) {
/* 1437 */         return null;
/*      */       }
/*      */ 
/* 1440 */       Map map = (Map)list.get(0);
/* 1441 */       right.setResourceId(map.get("ID_FIELD").toString());
/* 1442 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */       {
/* 1444 */         right.setParentId(map.get("PARENT_FIELD").toString());
/*      */       }
/* 1446 */       right.setResourceName(map.get("DESC_FIELD").toString());
/*      */ 
/* 1448 */       this.log.debug(" end getAllRightList ");
/* 1449 */       return right;
/*      */     } catch (Exception e) {
/* 1451 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isExistRoleRight(String roleId, String resourceId, int resourceType, String OperationType)
/*      */   {
/*      */     try
/*      */     {
/* 1459 */       StringBuffer allSql = new StringBuffer();
/* 1460 */       allSql.append("select resright.*");
/* 1461 */       allSql.append(" from ").append(getRoleRightTable()).append(" resright ");
/*      */ 
/* 1463 */       allSql.append(" where 1=1 and resright.").append("operatorid").append("='").append(roleId).append("' and resourceid").append("=");
/*      */ 
/* 1466 */       allSql.append("'").append(resourceId).append("'");
/* 1467 */       allSql.append(" and resourcetype").append("=").append(resourceType);
/* 1468 */       allSql.append(" and ").append(getAccessTypeField()).append("=").append(OperationType);
/*      */ 
/* 1470 */       this.log.debug("--sql:" + allSql);
/*      */ 
/* 1472 */       List list = getJdbcTemplate().queryForList(allSql.toString());
/*      */ 
/* 1474 */       if ((list == null) || (list.isEmpty())) {
/* 1475 */         return false;
/*      */       }
/* 1477 */       return true;
/*      */     }
/*      */     catch (Exception e) {
/* 1480 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<Right> getUserRightList(String userId, int resourceType, int roleType, boolean isDistinctControlType)
/*      */   {
/* 1494 */     this.log.debug(" in getUserRightList...");
/*      */ 
/* 1496 */     Sqlca sqlca = null;
/*      */     try {
/* 1498 */       sqlca = new Sqlca(new ConnectionEx());
/*      */ 
/* 1500 */       List result = new ArrayList();
/* 1501 */       rightSet = new HashSet();
/*      */ 
/* 1503 */       StringBuffer sb = new StringBuffer();
/* 1504 */       sb.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/*      */ 
/* 1506 */       sb.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/* 1507 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */       {
/* 1509 */         sb.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */       }
/*      */ 
/* 1512 */       sb.append(", rig.").append(getAccessTypeField()).append(" OPERATION_TYPE");
/*      */ 
/* 1514 */       sb.append(", opdef.operationname OPERATION_NAME");
/* 1515 */       sb.append(", rig.controltype CONTROL_TYPE");
/* 1516 */       sb.append(" from ").append(getDefineTable()).append(" resdef,").append(getRoleRightTable()).append(" rig, ");
/*      */ 
/* 1518 */       sb.append(" ").append("RESOURCE_OPERATION_DEFINE").append(" opdef ");
/*      */ 
/* 1520 */       sb.append(" where 1=1 ");
/*      */ 
/* 1524 */       String accessTypeStr = sqlca.getSql_intTochar("rig." + getAccessTypeField());
/*      */ 
/* 1527 */       if (isDistinctControlType) {
/* 1528 */         sb.append(" and rig.controltype='").append("1").append("'");
/*      */       }
/*      */ 
/* 1533 */       String idField = getIdField();
/* 1534 */       String dbType = sqlca.getDBMSType();
/* 1535 */       if (isNeedConvertIdType()) {
/* 1536 */         if (dbType.equalsIgnoreCase("DB2")) {
/* 1537 */           sb.append(" and ").append("resdef." + idField).append("=int(rig.resourceid)");
/*      */         } else {
/* 1539 */           idField = sqlca.getSql_intTochar("resdef." + getIdField());
/* 1540 */           sb.append(" and ").append(idField).append("=rig.resourceid");
/*      */         }
/* 1542 */         this.log.debug("idField:" + idField);
/*      */       } else {
/* 1544 */         sb.append(" and ").append("resdef." + idField).append("=rig.resourceid");
/*      */       }
/* 1546 */       if (dbType.equalsIgnoreCase("DB2"))
/* 1547 */         sb.append(" and int(opdef.operationkey)=").append("rig." + getAccessTypeField());
/*      */       else {
/* 1549 */         sb.append(" and opdef.operationkey=").append(accessTypeStr);
/*      */       }
/* 1551 */       sb.append(" and opdef.resourcetype=").append(resourceType);
/* 1552 */       sb.append(" and rig.operatorid in('").append(userId).append("')");
/* 1553 */       sb.append(" and rig.resourcetype=").append(resourceType);
/* 1554 */       sb.append(" and rig.operatortype=").append(1);
/*      */ 
/* 1556 */       if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/* 1557 */         sb.append(" and resdef.status=0 ");
/*      */       }
/* 1559 */       if (StringUtils.isNotBlank(getOrderSql())) {
/* 1560 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/* 1563 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql:" + sb.toString());
/*      */ 
/* 1567 */       sqlca.execute(sb.toString());
/* 1568 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeOver") + "");
/*      */       Right right;
/* 1575 */       while (sqlca.next()) {
/* 1576 */         right = new Right();
/* 1577 */         right.setRoleType(roleType);
/* 1578 */         right.setResourceId(sqlca.getString("ID_FIELD"));
/* 1579 */         right.setResourceName(sqlca.getString("DESC_FIELD"));
/* 1580 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */         {
/* 1582 */           right.setParentId(sqlca.getString("PARENT_FIELD"));
/*      */         }
/* 1584 */         else right.setParentId("0");
/*      */ 
/* 1586 */         right.setOperationType(String.valueOf(sqlca.getInt("OPERATION_TYPE")));
/*      */ 
/* 1588 */         right.setOperationName(sqlca.getString("OPERATION_NAME"));
/* 1589 */         right.setResourceType(resourceType);
/* 1590 */         right.setTopId(getTopLevelId());
/*      */ 
/* 1592 */         if (!rightSet.contains(right)) {
/* 1593 */           result.add(right);
/* 1594 */           rightSet.add(right);
/*      */         }
/*      */       }
/* 1597 */       this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuthList") + ":" + result.size());
/*      */ 
/* 1601 */       this.log.debug(" end getRightList...");
/* 1602 */       return result;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       Set rightSet;
/* 1604 */       this.log.debug("getRightList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*      */ 
/* 1607 */       return new ArrayList();
/*      */     } finally {
/* 1609 */       if (sqlca != null)
/* 1610 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteRight(String operatorId, int operatorType, int resourceType, String resourceId)
/*      */   {
/* 1617 */     this.log.info("deleteRight begin ............");
/* 1618 */     Connection con = null;
/* 1619 */     PreparedStatement pStmt = null;
/*      */     try {
/* 1621 */       con = getConnection();
/* 1622 */       StringBuffer sql = new StringBuffer(256);
/* 1623 */       sql.append("delete from ").append(getRoleRightTable()).append(" where operatorid=?").append(" and operatortype=?").append(" and resourcetype=?");
/*      */ 
/* 1626 */       if (StringUtils.isNotBlank(resourceId)) {
/* 1627 */         sql.append(" and resourceid=?");
/*      */       }
/* 1629 */       this.log.debug(sql);
/* 1630 */       pStmt = con.prepareStatement(sql.toString());
/* 1631 */       pStmt.setString(1, operatorId);
/* 1632 */       pStmt.setInt(2, operatorType);
/* 1633 */       pStmt.setInt(3, resourceType);
/* 1634 */       if (StringUtils.isNotBlank(resourceId)) {
/* 1635 */         pStmt.setString(4, resourceId);
/*      */       }
/* 1637 */       pStmt.executeUpdate();
/*      */     } catch (Exception ex) {
/* 1639 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/* 1641 */       if (pStmt != null) {
/*      */         try {
/* 1643 */           pStmt.close();
/*      */         } catch (SQLException e) {
/* 1645 */           throw new RuntimeException(e.getMessage());
/*      */         }
/*      */       }
/* 1648 */       if (con != null) {
/* 1649 */         releaseConnection(con);
/*      */       }
/*      */     }
/* 1652 */     this.log.info("deleteRight end ............");
/*      */   }
/*      */ 
/*      */   public void initDaoParameter(int resourceType)
/*      */   {
/* 1658 */     Collection srdpList = SysResourceDsPropCache.getInstance().getObjectByResourceType(resourceType);
/*      */ 
/* 1660 */     if (CollectionUtils.isEmpty(srdpList)) {
/* 1661 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.initResourceDsPropException") + resourceType);
/*      */     }
/*      */ 
/* 1666 */     Map propMap = new HashMap();
/* 1667 */     Iterator it = srdpList.iterator();
/* 1668 */     while (it.hasNext()) {
/* 1669 */       SysResourceDsProp srdp = (SysResourceDsProp)it.next();
/* 1670 */       propMap.put(srdp.getPropKey(), srdp.getPropValue());
/*      */     }
/*      */ 
/* 1673 */     setRoleRightTable((String)propMap.get("roleRightTable"));
/* 1674 */     setDefineTable((String)propMap.get("defineTable"));
/* 1675 */     setIdField((String)propMap.get("idField"));
/* 1676 */     setDescField((String)propMap.get("descField"));
/* 1677 */     setResourceTypeField((String)propMap.get("resourceTypeField"));
/* 1678 */     setAccessTypeField((String)propMap.get("accessTypeField"));
/* 1679 */     if (StringUtils.isNotBlank((String)propMap.get("parentFiled")))
/* 1680 */       setParentFiled((String)propMap.get("parentFiled"));
/*      */     else {
/* 1682 */       setParentFiled("0");
/*      */     }
/* 1684 */     if (StringUtils.isNotBlank((String)propMap.get("sortField")))
/* 1685 */       setSortField((String)propMap.get("sortField"));
/*      */     else {
/* 1687 */       setSortField("");
/*      */     }
/* 1689 */     if (StringUtils.isNotBlank((String)propMap.get("orderSql")))
/* 1690 */       setOrderSql((String)propMap.get("orderSql"));
/*      */     else {
/* 1692 */       setOrderSql("");
/*      */     }
/* 1694 */     if (StringUtils.isNotBlank((String)propMap.get("topLevelId")))
/* 1695 */       setTopLevelId((String)propMap.get("topLevelId"));
/*      */     else {
/* 1697 */       setTopLevelId("-1");
/*      */     }
/* 1699 */     if (StringUtils.isNotBlank((String)propMap.get("checkFrameField"))) {
/* 1700 */       setCheckFrameField((String)propMap.get("checkFrameField"));
/* 1701 */       setCheckFrameValue((String)propMap.get("checkFrameValue"));
/*      */     } else {
/* 1703 */       setCheckFrameField("");
/* 1704 */       setCheckFrameValue("");
/*      */     }
/* 1706 */     if (StringUtils.isNotBlank((String)propMap.get("isAccessType")))
/* 1707 */       setIsAccessType((String)propMap.get("isAccessType"));
/*      */     else {
/* 1709 */       setIsAccessType("0");
/*      */     }
/* 1711 */     if (StringUtils.isNotBlank((String)propMap.get("idVarchar"))) {
/* 1712 */       setIdVarchar(new Boolean((String)propMap.get("idVarchar")).booleanValue());
/*      */ 
/* 1714 */       setIsNeedConvertIdType(new Boolean((String)propMap.get("isNeedConvertIdType")).booleanValue());
/*      */     }
/*      */     else {
/* 1717 */       setIdVarchar(true);
/* 1718 */       setIsNeedConvertIdType(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected int getRoleTypeByResourceType(int resourceType)
/*      */   {
/* 1730 */     SysResourceType srt = SysResourceTypeCache.getInstance().getSysResourceType(resourceType);
/*      */ 
/* 1732 */     return srt.getRoleType();
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.ResourceRightDaoJdbcImpl_ForMenuItem
 * JD-Core Version:    0.6.2
 */
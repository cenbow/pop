/*      */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceDsPropCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceDsProp;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.SqlcaPst;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.naming.Context;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.naming.NamingException;
/*      */ import javax.sql.DataSource;
/*      */ import org.apache.commons.collections.CollectionUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*      */ import org.springframework.jdbc.core.JdbcTemplate;
/*      */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*      */ 
/*      */ public class ResourceRightDaoJdbcImpl_JNDI extends JdbcDaoSupport
/*      */   implements IResourceRightDAO
/*      */ {
/*   75 */   private Logger log = Logger.getLogger(ResourceRightDaoJdbcImpl_JNDI.class);
/*      */ 
/*   80 */   private String jndiName = "";
/*      */ 
/*   85 */   private String roleRightTable = "";
/*      */ 
/*   90 */   private String defineTable = "";
/*      */ 
/*   95 */   private String idField = "";
/*      */ 
/*  100 */   private String descField = "";
/*      */ 
/*  105 */   private String parentFiled = "";
/*      */   private String resourceTypeField;
/*  115 */   private String accessTypeField = "";
/*      */ 
/*  120 */   private String topLevelId = "-1";
/*      */ 
/*  125 */   private String sortField = "";
/*      */ 
/*  130 */   private String orderSql = "";
/*      */ 
/*  135 */   private String checkFrameField = "";
/*      */ 
/*  140 */   private String checkFrameValue = "";
/*      */ 
/*  145 */   private boolean idVarchar = true;
/*      */ 
/*  150 */   private boolean isNeedConvertIdType = false;
/*      */ 
/*  155 */   private String isAccessType = "0";
/*      */ 
/*  157 */   private DataSource jndiDataSource = null;
/*      */ 
/*      */   public String getJndiName()
/*      */   {
/*  164 */     return this.jndiName;
/*      */   }
/*      */ 
/*      */   public void setJndiName(String jndiName) {
/*  168 */     this.jndiName = jndiName;
/*      */   }
/*      */ 
/*      */   public String getRoleRightTable() {
/*  172 */     return this.roleRightTable;
/*      */   }
/*      */ 
/*      */   public void setRoleRightTable(String roleRightTable) {
/*  176 */     this.roleRightTable = roleRightTable;
/*      */   }
/*      */ 
/*      */   public String getParentFiled() {
/*  180 */     return this.parentFiled;
/*      */   }
/*      */ 
/*      */   public void setParentFiled(String parentFiled) {
/*  184 */     this.parentFiled = parentFiled;
/*      */   }
/*      */ 
/*      */   public String getResourceTypeField() {
/*  188 */     return this.resourceTypeField;
/*      */   }
/*      */ 
/*      */   public void setResourceTypeField(String resourceTypeField) {
/*  192 */     this.resourceTypeField = resourceTypeField;
/*      */   }
/*      */ 
/*      */   public String getAccessTypeField() {
/*  196 */     return this.accessTypeField;
/*      */   }
/*      */ 
/*      */   public void setAccessTypeField(String accessTypeField) {
/*  200 */     this.accessTypeField = accessTypeField;
/*      */   }
/*      */ 
/*      */   public String getTopLevelId() {
/*  204 */     return this.topLevelId;
/*      */   }
/*      */ 
/*      */   public void setTopLevelId(String topLevelId) {
/*  208 */     this.topLevelId = topLevelId;
/*      */   }
/*      */ 
/*      */   public String getSortField() {
/*  212 */     return this.sortField;
/*      */   }
/*      */ 
/*      */   public void setSortField(String sortField) {
/*  216 */     this.sortField = sortField;
/*      */   }
/*      */ 
/*      */   public String getOrderSql() {
/*  220 */     return this.orderSql;
/*      */   }
/*      */ 
/*      */   public void setOrderSql(String orderSql) {
/*  224 */     this.orderSql = orderSql;
/*      */   }
/*      */ 
/*      */   public String getCheckFrameField() {
/*  228 */     return this.checkFrameField;
/*      */   }
/*      */ 
/*      */   public void setCheckFrameField(String checkFrameField) {
/*  232 */     this.checkFrameField = checkFrameField;
/*      */   }
/*      */ 
/*      */   public String getCheckFrameValue() {
/*  236 */     return this.checkFrameValue;
/*      */   }
/*      */ 
/*      */   public void setCheckFrameValue(String checkFrameValue) {
/*  240 */     this.checkFrameValue = checkFrameValue;
/*      */   }
/*      */ 
/*      */   public boolean isIdVarchar() {
/*  244 */     return this.idVarchar;
/*      */   }
/*      */ 
/*      */   public void setIdVarchar(boolean idVarchar) {
/*  248 */     this.idVarchar = idVarchar;
/*      */   }
/*      */ 
/*      */   public boolean isNeedConvertIdType() {
/*  252 */     return this.isNeedConvertIdType;
/*      */   }
/*      */ 
/*      */   public void setNeedConvertIdType(boolean isNeedConvertIdType) {
/*  256 */     this.isNeedConvertIdType = isNeedConvertIdType;
/*      */   }
/*      */ 
/*      */   public String getIsAccessType() {
/*  260 */     return this.isAccessType;
/*      */   }
/*      */ 
/*      */   public void setIsAccessType(String isAccessType) {
/*  264 */     this.isAccessType = isAccessType;
/*      */   }
/*      */ 
/*      */   public void setDefineTable(String defineTable) {
/*  268 */     this.defineTable = defineTable;
/*      */   }
/*      */ 
/*      */   public void setIdField(String idField) {
/*  272 */     this.idField = idField;
/*      */   }
/*      */ 
/*      */   public void setDescField(String descField) {
/*  276 */     this.descField = descField;
/*      */   }
/*      */ 
/*      */   public void delete(String roleId, int resourceType)
/*      */   {
/*  286 */     this.log.debug("delete............");
/*  287 */     Connection con = null;
/*  288 */     Statement stmt = null;
/*      */     try {
/*  290 */       con = getConnection();
/*  291 */       stmt = con.createStatement();
/*  292 */       StringBuffer sql = new StringBuffer(256);
/*  293 */       sql.append("delete from ").append(getRoleRightTable());
/*  294 */       sql.append(" where operatorid='").append(roleId).append("'");
/*  295 */       sql.append(" and resourcetype=").append(resourceType);
/*  296 */       sql.append(" and operatortype=0");
/*  297 */       this.log.debug("-------sql=" + sql);
/*  298 */       stmt.executeUpdate(sql.toString());
/*      */ 
/*  303 */       if (null != stmt)
/*      */         try {
/*  305 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  309 */       if (null != con)
/*  310 */         releaseConnection(con);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  300 */       this.log.error("Error deleting role rights. roleRightTable=" + getRoleRightTable() + ex.getMessage());
/*      */ 
/*  303 */       if (null != stmt)
/*      */         try {
/*  305 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  309 */       if (null != con)
/*  310 */         releaseConnection(con);
/*      */     }
/*      */     finally
/*      */     {
/*  303 */       if (null != stmt)
/*      */         try {
/*  305 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  309 */       if (null != con)
/*  310 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void delete(Collection<RoleRight> roleRightList)
/*      */   {
/*  321 */     this.log.debug(" in delete(Collection<RoleRight> roleRightList)");
/*  322 */     Connection con = null;
/*  323 */     Statement stmt = null;
/*      */     try {
/*  325 */       con = getConnection();
/*  326 */       stmt = con.createStatement();
/*  327 */       for (RoleRight roleRight : roleRightList) {
/*  328 */         Right right = roleRight.getRight();
/*  329 */         StringBuffer sql = new StringBuffer(256);
/*  330 */         sql.append("delete from ").append(getRoleRightTable());
/*  331 */         sql.append(" where resourceid='").append(right.getResourceId()).append("'");
/*      */ 
/*  333 */         sql.append(" and resourcetype=").append(right.getResourceType());
/*      */ 
/*  335 */         sql.append(" and operatorid='").append(roleRight.getRoleId()).append("'");
/*      */ 
/*  337 */         sql.append(" and operatortype=").append(roleRight.getOperatorType());
/*      */ 
/*  339 */         sql.append(" and ").append(getAccessTypeField()).append("=").append(right.getOperationType());
/*      */ 
/*  341 */         this.log.debug("-----sql=" + sql);
/*  342 */         stmt.execute(sql.toString());
/*      */       }
/*      */ 
/*  347 */       if (null != stmt)
/*      */         try {
/*  349 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  353 */       if (null != con)
/*  354 */         releaseConnection(con);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  345 */       throw new RuntimeException(ex.getMessage(), ex);
/*      */     } finally {
/*  347 */       if (null != stmt)
/*      */         try {
/*  349 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  353 */       if (null != con)
/*  354 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void delete(List<String> roleIdList, List<Right> rightList, int resourceType)
/*      */   {
/*  367 */     this.log.debug("delete(List<String> roleIdList............");
/*  368 */     if (CollectionUtils.isEmpty(roleIdList)) {
/*  369 */       return;
/*      */     }
/*  371 */     if (CollectionUtils.isEmpty(rightList)) {
/*  372 */       return;
/*      */     }
/*  374 */     Connection con = null;
/*  375 */     Statement stmt = null;
/*      */     try {
/*  377 */       con = getConnection();
/*  378 */       stmt = con.createStatement();
/*      */ 
/*  380 */       String operatorIdString = StringUtil.list2String(roleIdList, ",", true);
/*      */ 
/*  382 */       for (Right right : rightList) {
/*  383 */         StringBuffer sql = new StringBuffer(256);
/*  384 */         sql.append(" delete from ").append(getRoleRightTable());
/*  385 */         sql.append(" where 1=1 ");
/*  386 */         sql.append(" and operatorid in (").append(operatorIdString).append(")");
/*      */ 
/*  388 */         sql.append(" and resourcetype=").append(resourceType);
/*  389 */         sql.append(" and resourceid='").append(right.getResourceId()).append("'");
/*      */ 
/*  391 */         sql.append(" and ").append(getAccessTypeField()).append("=").append(right.getOperationType());
/*      */ 
/*  393 */         this.log.debug("-----sql=" + sql);
/*  394 */         stmt.executeUpdate(sql.toString());
/*      */       }
/*      */ 
/*  399 */       if (null != stmt)
/*      */         try {
/*  401 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  405 */       if (null != con)
/*  406 */         releaseConnection(con);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  397 */       this.log.error("Error deleting role rights. roleRightTable=" + getRoleRightTable() + ex.getMessage());
/*      */ 
/*  399 */       if (null != stmt)
/*      */         try {
/*  401 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  405 */       if (null != con)
/*  406 */         releaseConnection(con);
/*      */     }
/*      */     finally
/*      */     {
/*  399 */       if (null != stmt)
/*      */         try {
/*  401 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  405 */       if (null != con)
/*  406 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteRight(String operatorId, int operatorType, int resourceType, String resourceId)
/*      */   {
/*  419 */     this.log.info("deleteRight begin ............");
/*  420 */     Connection con = null;
/*  421 */     PreparedStatement pStmt = null;
/*      */     try {
/*  423 */       con = getConnection();
/*  424 */       StringBuffer sql = new StringBuffer(256);
/*  425 */       sql.append("delete from ").append(getRoleRightTable()).append(" where operatorid=?").append(" and operatortype=?").append(" and resourcetype=?");
/*      */ 
/*  428 */       if (StringUtils.isNotBlank(resourceId)) {
/*  429 */         sql.append(" and resourceid=?");
/*      */       }
/*  431 */       this.log.debug(sql);
/*  432 */       pStmt = con.prepareStatement(sql.toString());
/*  433 */       pStmt.setString(1, operatorId);
/*  434 */       pStmt.setInt(2, operatorType);
/*  435 */       pStmt.setInt(3, resourceType);
/*  436 */       if (StringUtils.isNotBlank(resourceId)) {
/*  437 */         pStmt.setString(4, resourceId);
/*      */       }
/*  439 */       pStmt.executeUpdate();
/*      */     } catch (Exception ex) {
/*  441 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/*  443 */       if (pStmt != null) {
/*      */         try {
/*  445 */           pStmt.close();
/*      */         } catch (SQLException e) {
/*  447 */           throw new RuntimeException(e.getMessage());
/*      */         }
/*      */       }
/*  450 */       if (con != null) {
/*  451 */         releaseConnection(con);
/*      */       }
/*      */     }
/*  454 */     this.log.info("deleteRight end ............");
/*      */   }
/*      */ 
/*      */   public List<String> getAllParentIds(String resourceId)
/*      */   {
/*  463 */     List allParnetIdList = new ArrayList();
/*  464 */     getAllParentIds(allParnetIdList, resourceId);
/*  465 */     return allParnetIdList;
/*      */   }
/*      */ 
/*      */   private List<String> getAllParentIds(List<String> allParnetIdList, String resourceId)
/*      */   {
/*  477 */     StringBuffer sql = new StringBuffer(128);
/*  478 */     sql.append("select ").append(getParentFiled()).append(" PARENT_FIELD");
/*  479 */     sql.append(" from ").append(getDefineTable());
/*  480 */     sql.append(" where ").append(getIdField()).append("=?");
/*      */ 
/*  482 */     String parentId = "-1";
/*      */ 
/*  484 */     SqlcaPst sqlcaPst = null;
/*      */     try {
/*  486 */       sqlcaPst = new SqlcaPst(this.jndiDataSource.getConnection());
/*  487 */       sqlcaPst.setSql(sql.toString());
/*  488 */       if (isIdVarchar())
/*  489 */         sqlcaPst.setString(1, resourceId);
/*      */       else {
/*  491 */         sqlcaPst.setInteger(1, resourceId);
/*      */       }
/*  493 */       sqlcaPst.execute();
/*  494 */       if (sqlcaPst.next()) {
/*  495 */         if (isIdVarchar())
/*  496 */           parentId = sqlcaPst.getInteger("PARENT_FIELD").toString();
/*      */         else {
/*  498 */           parentId = sqlcaPst.getString("PARENT_FIELD");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  506 */       if (null != sqlcaPst)
/*  507 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  503 */       throw new RuntimeException("---getAllParentIds error. " + e.getMessage(), e);
/*      */     }
/*      */     finally {
/*  506 */       if (null != sqlcaPst) {
/*  507 */         sqlcaPst.closeAll();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  512 */     if ((StringUtils.isBlank(parentId)) || ("0".equals(parentId)) || ("-1".equals(parentId)) || ("-2".equals(parentId)))
/*      */     {
/*  514 */       return allParnetIdList;
/*      */     }
/*  516 */     allParnetIdList.add(parentId);
/*  517 */     getAllParentIds(allParnetIdList, parentId);
/*  518 */     return allParnetIdList;
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(int roleType, int resourceType)
/*      */   {
/*  528 */     this.log.debug(" in getAllRightList...");
/*      */ 
/*  530 */     StringBuffer sb = new StringBuffer();
/*  531 */     sb.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/*  532 */     sb.append(" ,resdef.").append(getDescField()).append(" DESC_FIELD");
/*  533 */     if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */     {
/*  535 */       sb.append(" ,resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */     }
/*      */ 
/*  538 */     if (hasCheckFrameField()) {
/*  539 */       sb.append(" ,resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD");
/*      */     }
/*      */ 
/*  542 */     sb.append(" from ").append(getDefineTable()).append(" resdef");
/*  543 */     sb.append(" where ").append(getResourceTypeField()).append("=?");
/*  544 */     if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  545 */       sb.append(" and STATUS=?");
/*      */     }
/*  547 */     if (StringUtils.isNotBlank(getOrderSql())) {
/*  548 */       sb.append(" ").append(getOrderSql());
/*      */     }
/*  550 */     this.log.debug("-----sql=" + sb.toString());
/*      */ 
/*  552 */     SqlcaPst sqlcaPst = null;
/*      */     try {
/*  554 */       sqlcaPst = new SqlcaPst(this.jndiDataSource.getConnection());
/*  555 */       sqlcaPst.setSql(sb.toString());
/*  556 */       sqlcaPst.setInteger(1, Integer.valueOf(resourceType));
/*  557 */       if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  558 */         sqlcaPst.setInteger(2, Integer.valueOf(0));
/*      */       }
/*  560 */       sqlcaPst.execute();
/*      */     } catch (Exception e) {
/*  562 */       this.log.debug(e.getMessage());
/*  563 */       return new ArrayList();
/*      */     }
/*      */ 
/*  566 */     StringBuffer operationSql = new StringBuffer();
/*  567 */     operationSql.append(" select rod.operationkey OPERATION_KEY ");
/*  568 */     operationSql.append(" ,rod.operationname OPERATION_NAME");
/*  569 */     operationSql.append(" from ").append("RESOURCE_OPERATION_DEFINE").append(" rod");
/*      */ 
/*  571 */     operationSql.append(" where rod.resourcetype=?");
/*  572 */     List list = getJdbcTemplate().queryForList(operationSql.toString(), new Integer[] { Integer.valueOf(resourceType) });
/*      */ 
/*  575 */     List rightList = new ArrayList();
/*      */     try
/*      */     {
/*      */       Iterator i$;
/*  577 */       while (sqlcaPst.next()) {
/*  578 */         for (i$ = list.iterator(); i$.hasNext(); ) { map = (Map)i$.next();
/*  579 */           Right right = new Right();
/*  580 */           right.setRoleType(roleType);
/*  581 */           if (isIdVarchar())
/*  582 */             right.setResourceId(sqlcaPst.getString("ID_FIELD"));
/*      */           else {
/*  584 */             right.setResourceId(sqlcaPst.getInteger("ID_FIELD").toString());
/*      */           }
/*      */ 
/*  587 */           right.setResourceName(sqlcaPst.getString("DESC_FIELD"));
/*  588 */           if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */           {
/*  590 */             right.setParentId(sqlcaPst.getString("PARENT_FIELD"));
/*      */           }
/*  592 */           else right.setParentId("0");
/*      */ 
/*  594 */           right.setOperationType(map.get("OPERATION_KEY").toString());
/*  595 */           right.setOperationName(map.get("OPERATION_NAME").toString());
/*      */ 
/*  597 */           if (hasCheckFrameField()) {
/*  598 */             right.setHasCheckFrame(getCheckFrameValue().equals(sqlcaPst.getString("CHECK_FRAME_FIELD")));
/*      */           }
/*      */ 
/*  601 */           right.setResourceType(resourceType);
/*  602 */           right.setTopId(getTopLevelId());
/*  603 */           rightList.add(right);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  611 */       if (null != sqlcaPst)
/*  612 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       Map map;
/*  607 */       this.log.debug(e.getMessage());
/*  608 */       return new ArrayList();
/*      */     }
/*      */     finally {
/*  611 */       if (null != sqlcaPst) {
/*  612 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  615 */     return rightList;
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(String resourceName, int resourceType)
/*      */   {
/*  625 */     List resultList = new ArrayList();
/*  626 */     StringBuffer allSql = new StringBuffer();
/*  627 */     allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/*      */ 
/*  629 */     allSql.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/*      */ 
/*  631 */     if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */     {
/*  633 */       allSql.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */     }
/*      */     else {
/*  636 */       allSql.append(", '0' PARENT_FIELD");
/*      */     }
/*  638 */     allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*      */ 
/*  640 */     allSql.append(" where resdef.").append(getDescField()).append("=?");
/*  641 */     allSql.append(" and resdef.").append(getResourceTypeField()).append("=?");
/*      */ 
/*  643 */     this.log.debug("-----sql:" + allSql.toString());
/*      */ 
/*  645 */     SqlcaPst sqlcaPst = null;
/*      */     try {
/*  647 */       sqlcaPst = new SqlcaPst(this.jndiDataSource.getConnection());
/*  648 */       sqlcaPst.setSql(allSql.toString());
/*  649 */       sqlcaPst.setString(1, resourceName);
/*  650 */       sqlcaPst.setInteger(2, Integer.valueOf(resourceType));
/*  651 */       sqlcaPst.execute();
/*  652 */       while (sqlcaPst.next()) {
/*  653 */         Right right = new Right();
/*  654 */         resourceId = "";
/*  655 */         if (isIdVarchar())
/*  656 */           resourceId = sqlcaPst.getString("ID_FIELD");
/*      */         else {
/*  658 */           resourceId = sqlcaPst.getInteger("ID_FIELD").toString();
/*      */         }
/*  660 */         right.setResourceId(resourceId);
/*  661 */         right.setParentId(sqlcaPst.getString("PARENT_FIELD"));
/*  662 */         right.setResourceName(resourceName);
/*  663 */         right.setResourceType(resourceType);
/*  664 */         resultList.add(right);
/*      */       }
/*      */ 
/*  670 */       if (null != sqlcaPst)
/*  671 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       String resourceId;
/*  667 */       this.log.debug(e.getMessage());
/*  668 */       return new ArrayList();
/*      */     } finally {
/*  670 */       if (null != sqlcaPst) {
/*  671 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  674 */     return resultList;
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(String resourceName)
/*      */   {
/*  683 */     List resultList = new ArrayList();
/*  684 */     StringBuffer allSql = new StringBuffer();
/*  685 */     allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/*      */ 
/*  687 */     allSql.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/*      */ 
/*  689 */     if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */     {
/*  691 */       allSql.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */     }
/*      */     else {
/*  694 */       allSql.append(", '0' PARENT_FIELD");
/*      */     }
/*  696 */     allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*      */ 
/*  698 */     allSql.append(" where resdef.").append(getDescField()).append("=?");
/*  699 */     this.log.debug("-----sql:" + allSql.toString());
/*      */ 
/*  701 */     SqlcaPst sqlcaPst = null;
/*      */     try {
/*  703 */       sqlcaPst = new SqlcaPst(this.jndiDataSource.getConnection());
/*  704 */       sqlcaPst.setSql(allSql.toString());
/*  705 */       sqlcaPst.setString(1, resourceName);
/*  706 */       sqlcaPst.execute();
/*  707 */       while (sqlcaPst.next()) {
/*  708 */         Right right = new Right();
/*  709 */         resourceId = "";
/*  710 */         if (isIdVarchar())
/*  711 */           resourceId = sqlcaPst.getString("ID_FIELD");
/*      */         else {
/*  713 */           resourceId = sqlcaPst.getInteger("ID_FIELD").toString();
/*      */         }
/*  715 */         right.setResourceId(resourceId);
/*  716 */         right.setParentId(sqlcaPst.getString("PARENT_FIELD"));
/*  717 */         right.setResourceName(resourceName);
/*  718 */         resultList.add(right);
/*      */       }
/*      */ 
/*  724 */       if (null != sqlcaPst)
/*  725 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       String resourceId;
/*  721 */       this.log.debug(e.getMessage());
/*  722 */       return new ArrayList();
/*      */     } finally {
/*  724 */       if (null != sqlcaPst) {
/*  725 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  728 */     return resultList;
/*      */   }
/*      */ 
/*      */   public String getDefineTable()
/*      */   {
/*  737 */     return this.defineTable;
/*      */   }
/*      */ 
/*      */   public String getDescField()
/*      */   {
/*  746 */     return this.descField;
/*      */   }
/*      */ 
/*      */   public String getIdField() {
/*  750 */     return this.idField;
/*      */   }
/*      */ 
/*      */   public String getResourceName(String resourceId)
/*      */   {
/*  759 */     String resourceName = "";
/*  760 */     SqlcaPst sqlcaPst = null;
/*      */     try {
/*  762 */       sqlcaPst = new SqlcaPst(this.jndiDataSource.getConnection());
/*  763 */       String sql = " select " + getDescField() + " from " + getDefineTable() + " where " + getIdField() + "=? ";
/*      */ 
/*  766 */       this.log.debug("--sql:" + sql);
/*  767 */       sqlcaPst.setSql(sql);
/*  768 */       if (this.idVarchar == true)
/*  769 */         sqlcaPst.setString(1, resourceId);
/*      */       else {
/*  771 */         sqlcaPst.setInteger(1, resourceId);
/*      */       }
/*  773 */       sqlcaPst.execute();
/*  774 */       if (sqlcaPst.next()) {
/*  775 */         resourceName = sqlcaPst.getString(getDescField());
/*      */       }
/*      */ 
/*  783 */       if (null != sqlcaPst)
/*  784 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  778 */       throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryResourceNameFail") + ":" + e.getMessage(), e);
/*      */     }
/*      */     finally
/*      */     {
/*  783 */       if (null != sqlcaPst) {
/*  784 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  787 */     return resourceName;
/*      */   }
/*      */ 
/*      */   public Right getRight(String resouceId)
/*      */   {
/*  796 */     StringBuffer allSql = new StringBuffer();
/*  797 */     allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/*      */ 
/*  799 */     allSql.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/*      */ 
/*  801 */     if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */     {
/*  803 */       allSql.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */     }
/*      */ 
/*  806 */     allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*      */ 
/*  808 */     allSql.append(" where resdef.").append(getIdField()).append("=?");
/*  809 */     this.log.debug("-----sql:" + allSql.toString());
/*      */ 
/*  811 */     SqlcaPst sqlcaPst = null;
/*      */     try {
/*  813 */       sqlcaPst = new SqlcaPst(this.jndiDataSource.getConnection());
/*  814 */       sqlcaPst.setSql(allSql.toString());
/*  815 */       if (isIdVarchar())
/*  816 */         sqlcaPst.setString(1, resouceId);
/*      */       else {
/*  818 */         sqlcaPst.setInteger(1, resouceId);
/*      */       }
/*  820 */       sqlcaPst.execute();
/*  821 */       if (sqlcaPst.next()) {
/*  822 */         Right right = new Right();
/*  823 */         String resourceId = "";
/*  824 */         if (isIdVarchar())
/*  825 */           resourceId = sqlcaPst.getString("ID_FIELD");
/*      */         else {
/*  827 */           resourceId = sqlcaPst.getInteger("ID_FIELD").toString();
/*      */         }
/*  829 */         right.setResourceId(resourceId);
/*  830 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */         {
/*  832 */           right.setParentId(sqlcaPst.getString("PARENT_FIELD"));
/*      */         }
/*  834 */         right.setResourceName(sqlcaPst.getString("DESC_FIELD"));
/*  835 */         return right;
/*      */       }
/*      */ 
/*  840 */       if (null != sqlcaPst)
/*  841 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  838 */       throw new RuntimeException("" + e.getMessage(), e);
/*      */     } finally {
/*  840 */       if (null != sqlcaPst) {
/*  841 */         sqlcaPst.closeAll();
/*      */       }
/*      */     }
/*  844 */     return null;
/*      */   }
/*      */ 
/*      */   public List<Right> getRightList(String roleId, int resourceType, boolean isDistinctControlType)
/*      */   {
/*  855 */     List roleIdList = new ArrayList();
/*  856 */     roleIdList.add(roleId);
/*  857 */     return getRightList(roleIdList, resourceType, isDistinctControlType);
/*      */   }
/*      */ 
/*      */   public List<Right> getRightList(List<String> roleIdList, int resourceType, boolean isDistinctControlType)
/*      */   {
/*  868 */     if ((CollectionUtils.isEmpty(roleIdList)) && (resourceType != Integer.parseInt("50")))
/*      */     {
/*  871 */       return new ArrayList();
/*      */     }
/*      */ 
/*  874 */     Sqlca sqlca = null;
/*  875 */     String accessTypeStr = getAccessTypeField();
/*      */     try {
/*  877 */       sqlca = new Sqlca(new ConnectionEx());
/*  878 */       accessTypeStr = sqlca.getSql_intTochar("rij." + getAccessTypeField());
/*      */ 
/*  884 */       if (null != sqlca)
/*  885 */         sqlca.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  881 */       this.log.debug(e.getMessage());
/*  882 */       return new ArrayList();
/*      */     } finally {
/*  884 */       if (null != sqlca) {
/*  885 */         sqlca.closeAll();
/*      */       }
/*      */     }
/*      */ 
/*  889 */     StringBuffer rightSql = new StringBuffer();
/*  890 */     rightSql.append(" select rij.resourceid ID_FIELD,");
/*  891 */     rightSql.append(" rij.").append(getAccessTypeField()).append(" ACCESS_TYPE,");
/*      */ 
/*  893 */     rightSql.append(" rij.controltype CONTROL_TYPE, rod.operationname OPERATION_NAME");
/*      */ 
/*  895 */     rightSql.append(" from ").append(getRoleRightTable()).append(" rij, ");
/*      */ 
/*  897 */     rightSql.append("RESOURCE_OPERATION_DEFINE").append(" rod ");
/*      */ 
/*  899 */     rightSql.append(" where 1=1");
/*  900 */     rightSql.append(" and rij.resourcetype=").append(resourceType);
/*  901 */     rightSql.append(" and rij.resourcetype=rod.resourcetype");
/*  902 */     rightSql.append(" and rod.operationkey=").append(accessTypeStr);
/*  903 */     rightSql.append(" and rij.operatorid in(").append(StringUtil.list2String(roleIdList, ",", true)).append(")");
/*      */ 
/*  905 */     if (isDistinctControlType == true) {
/*  906 */       rightSql.append(" and rij.controltype='").append("1").append("'");
/*      */     }
/*      */ 
/*  909 */     this.log.debug("-------sql=" + rightSql.toString());
/*  910 */     Object list = new ArrayList();
/*      */     try {
/*  912 */       list = getJdbcTemplate().queryForList(rightSql.toString());
/*      */     }
/*      */     catch (Exception e) {
/*  915 */       this.log.error("getRightList:" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + e.getMessage());
/*      */     }
/*      */ 
/*  920 */     if (CollectionUtils.isEmpty((Collection)list)) {
/*  921 */       return new ArrayList();
/*      */     }
/*      */ 
/*  925 */     StringBuffer sqlDefineBuffer = new StringBuffer();
/*  926 */     sqlDefineBuffer.append(" select ").append(getDescField());
/*  927 */     sqlDefineBuffer.append(" DESC_FIELD");
/*  928 */     sqlDefineBuffer.append(" ,").append(getIdField());
/*  929 */     sqlDefineBuffer.append(" ID_FIELD");
/*  930 */     if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */     {
/*  932 */       sqlDefineBuffer.append(" ,").append(getParentFiled());
/*  933 */       sqlDefineBuffer.append(" PARENT_FIELD");
/*      */     } else {
/*  935 */       sqlDefineBuffer.append(" ,").append("'0'").append(" PARENT_FIELD");
/*      */     }
/*  937 */     if (hasCheckFrameField()) {
/*  938 */       sqlDefineBuffer.append(" ,").append(getCheckFrameField());
/*  939 */       sqlDefineBuffer.append(" CHECK_FRAME_FIELD");
/*      */     }
/*  941 */     sqlDefineBuffer.append(" from ").append(getDefineTable());
/*  942 */     sqlDefineBuffer.append(" where ").append(getResourceTypeField());
/*  943 */     sqlDefineBuffer.append(" =").append(resourceType);
/*  944 */     List resourceIdList = new ArrayList();
/*  945 */     for (Map map : (List)list) {
/*  946 */       resourceIdList.add(map.get("ID_FIELD").toString());
/*      */     }
/*  948 */     List idList = new ArrayList();
/*  949 */     if (isIdVarchar())
/*  950 */       idList = getInSqlStr(resourceIdList, true);
/*      */     else {
/*  952 */       idList = getInSqlStr(resourceIdList, false);
/*      */     }
/*  954 */     sqlDefineBuffer.append(" and (");
/*  955 */     for (int i = 0; i < idList.size(); i++) {
/*  956 */       if (i != 0) {
/*  957 */         sqlDefineBuffer.append(" or ");
/*      */       }
/*  959 */       sqlDefineBuffer.append(" ").append(getIdField());
/*  960 */       sqlDefineBuffer.append(" in(").append(idList.get(i));
/*  961 */       sqlDefineBuffer.append(")");
/*      */     }
/*  963 */     sqlDefineBuffer.append(" )");
/*      */ 
/*  965 */     this.log.debug("-----sql=" + sqlDefineBuffer.toString());
/*      */ 
/*  968 */     Map titleMap = new HashMap();
/*  969 */     Map parentMap = new HashMap();
/*  970 */     Map checkFrameMap = new HashMap();
/*  971 */     SqlcaPst sqlcaPst = null;
/*      */     try {
/*  973 */       sqlcaPst = new SqlcaPst(this.jndiDataSource.getConnection());
/*  974 */       sqlcaPst.setSql(sqlDefineBuffer.toString());
/*  975 */       sqlcaPst.execute();
/*  976 */       while (sqlcaPst.next()) {
/*  977 */         String resourceId = "";
/*  978 */         if (isIdVarchar())
/*  979 */           resourceId = sqlcaPst.getString("ID_FIELD");
/*      */         else {
/*  981 */           resourceId = sqlcaPst.getInteger("ID_FIELD").toString();
/*      */         }
/*  983 */         titleMap.put(resourceId, sqlcaPst.getString("DESC_FIELD"));
/*  984 */         parentMap.put(resourceId, sqlcaPst.getString("PARENT_FIELD"));
/*  985 */         if (hasCheckFrameField()) {
/*  986 */           checkFrame = getCheckFrameValue().equals(sqlcaPst.getString("CHECK_FRAME_FIELD"));
/*      */ 
/*  988 */           checkFrameMap.put(resourceId, Boolean.valueOf(checkFrame));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  995 */       if (null != sqlcaPst)
/*  996 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       boolean checkFrame;
/*  992 */       this.log.debug(e.getMessage());
/*  993 */       return new ArrayList();
/*      */     } finally {
/*  995 */       if (null != sqlcaPst) {
/*  996 */         sqlcaPst.closeAll();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1001 */     List result = new ArrayList();
/* 1002 */     Set rightSet = new HashSet();
/* 1003 */     int roleType = getRoleType(resourceType);
/* 1004 */     for (Map map : (List)list) {
/* 1005 */       Right right = new Right();
/* 1006 */       right.setResourceType(resourceType);
/* 1007 */       String idField = map.get("ID_FIELD").toString();
/* 1008 */       right.setResourceId(idField);
/* 1009 */       right.setOperationType(String.valueOf(map.get("ACCESS_TYPE")));
/* 1010 */       right.setOperationName(map.get("OPERATION_NAME").toString());
/* 1011 */       right.setTopId(getTopLevelId());
/* 1012 */       right.setRoleType(roleType);
/* 1013 */       right.setResourceName((String)titleMap.get(idField));
/* 1014 */       right.setParentId((String)parentMap.get(idField));
/* 1015 */       if (hasCheckFrameField()) {
/* 1016 */         right.setHasCheckFrame(((Boolean)checkFrameMap.get(idField)).booleanValue());
/*      */       }
/* 1018 */       if (rightSet.add(idField + "-" + right.getOperationType())) {
/* 1019 */         result.add(right);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1024 */     List checkFrameRights = getCheckFrameRight(resourceType, roleType);
/*      */ 
/* 1026 */     for (Right right : checkFrameRights) {
/* 1027 */       if (rightSet.add(right.getResourceId() + "-" + right.getOperationType()))
/*      */       {
/* 1029 */         result.add(right);
/*      */       }
/*      */     }
/* 1032 */     this.log.debug("-----result size=" + result.size());
/* 1033 */     return result;
/*      */   }
/*      */ 
/*      */   private int getRoleType(int resourceType)
/*      */   {
/* 1043 */     this.log.debug(" in getRoleType ");
/* 1044 */     int roleType = -1;
/* 1045 */     SysResourceType srt = SysResourceTypeCache.getInstance().getSysResourceType(resourceType);
/* 1046 */     if (null != srt) {
/* 1047 */       roleType = srt.getRoleType();
/*      */     } else {
/* 1049 */       String sql = "select t.role_type from sys_resource_type t where t.resourcetype=?";
/* 1050 */       this.log.debug("-----sql=" + sql);
/* 1051 */       List list = getJdbcTemplate().queryForList(sql, new Integer[] { Integer.valueOf(resourceType) });
/*      */ 
/* 1053 */       if (CollectionUtils.isNotEmpty(list)) {
/* 1054 */         Map map = (Map)list.get(0);
/* 1055 */         roleType = Integer.parseInt(map.get("ROLE_TYPE").toString());
/*      */       }
/*      */     }
/* 1058 */     return roleType;
/*      */   }
/*      */ 
/*      */   private boolean hasCheckFrameField()
/*      */   {
/* 1063 */     return StringUtils.isNotBlank(getCheckFrameField());
/*      */   }
/*      */ 
/*      */   private List<Right> getCheckFrameRight(int resourceType, int roleType)
/*      */   {
/* 1072 */     if (!hasCheckFrameField()) {
/* 1073 */       return new ArrayList();
/*      */     }
/* 1075 */     StringBuffer allSql = new StringBuffer();
/* 1076 */     allSql.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*      */ 
/* 1078 */     allSql.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/*      */ 
/* 1080 */     if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */     {
/* 1082 */       allSql.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*      */     }
/*      */ 
/* 1085 */     allSql.append("resdef.").append(getCheckFrameField()).append(" CHECK_FRAME_FIELD ");
/*      */ 
/* 1087 */     allSql.append(" from ").append(getDefineTable()).append(" resdef ");
/*      */ 
/* 1089 */     allSql.append(" where 1=1 and resdef.").append(getCheckFrameField()).append("=0 ");
/*      */ 
/* 1091 */     if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/* 1092 */       allSql.append(" and resdef.status=0 ");
/*      */     }
/* 1094 */     this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.shareAuth") + "sql=" + allSql.toString());
/*      */ 
/* 1099 */     Sqlca sqlca = null;
/*      */     try {
/* 1101 */       sqlca = new Sqlca(this.jndiDataSource.getConnection());
/* 1102 */       sqlca.execute(allSql.toString());
/*      */     } catch (Exception e) {
/* 1104 */       throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + e.getMessage(), e);
/*      */     }
/*      */ 
/* 1109 */     boolean isDisOper = isDistinguishOperation(resourceType);
/*      */ 
/* 1111 */     String defaultOperationType = "";
/* 1112 */     String defaultOperationName = "";
/* 1113 */     if (isDisOper) {
/* 1114 */       defaultOperationType = "0";
/* 1115 */       defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.view") + "";
/*      */     }
/*      */     else
/*      */     {
/* 1119 */       defaultOperationType = "-1";
/* 1120 */       defaultOperationName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.noDiffOperationAuth") + "";
/*      */     }
/*      */ 
/* 1125 */     List result = new ArrayList();
/*      */     try {
/* 1127 */       while (sqlca.next()) {
/* 1128 */         Right right = new Right();
/* 1129 */         right.setRoleType(roleType);
/* 1130 */         right.setResourceId(sqlca.getString("ID_FIELD"));
/* 1131 */         right.setResourceName(sqlca.getString("DESC_FIELD"));
/* 1132 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */         {
/* 1134 */           right.setParentId(sqlca.getString("PARENT_FIELD"));
/*      */         }
/* 1136 */         else right.setParentId("0");
/*      */ 
/* 1138 */         right.setHasCheckFrame(getCheckFrameValue().equals(sqlca.getString("CHECK_FRAME_FIELD")));
/*      */ 
/* 1140 */         right.setOperationType(defaultOperationType);
/* 1141 */         right.setOperationName(defaultOperationName);
/* 1142 */         right.setResourceType(resourceType);
/* 1143 */         right.setTopId(getTopLevelId());
/* 1144 */         result.add(right);
/*      */       }
/*      */ 
/* 1150 */       if (null != sqlca)
/* 1151 */         sqlca.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1147 */       this.log.debug(e.getMessage());
/* 1148 */       return new ArrayList();
/*      */     } finally {
/* 1150 */       if (null != sqlca) {
/* 1151 */         sqlca.closeAll();
/*      */       }
/*      */     }
/* 1154 */     return result;
/*      */   }
/*      */ 
/*      */   private boolean isDistinguishOperation(int resourceType)
/*      */   {
/* 1164 */     this.log.debug(" in isDistinguishOperation...");
/* 1165 */     String sql = "select operationkey from RESOURCE_OPERATION_DEFINE where resourcetype=?";
/*      */ 
/* 1168 */     List list = getJdbcTemplate().queryForList(sql, new Integer[] { Integer.valueOf(resourceType) });
/*      */ 
/* 1170 */     if ((null == list) || (list.size() <= 0)) {
/* 1171 */       return false;
/*      */     }
/* 1173 */     if ((null != list) && (list.size() == 1)) {
/* 1174 */       String operationkey = ((Map)list.get(0)).get("OPERATIONKEY").toString();
/* 1175 */       if (operationkey.equals("-1")) {
/* 1176 */         return false;
/*      */       }
/*      */     }
/* 1179 */     return true;
/*      */   }
/*      */ 
/*      */   public RoleRight getRoleRight(String roleId, int resourceType, String resourceId, String operationType)
/*      */   {
/* 1190 */     this.log.debug(" in getRoleRight...");
/* 1191 */     List roleRightList = getRoleRightListByRole(roleId, resourceType);
/*      */ 
/* 1193 */     for (RoleRight roleRight : roleRightList) {
/* 1194 */       Right right = roleRight.getRight();
/* 1195 */       if ((resourceId.equals(right.getResourceId())) && (operationType.equals(right.getOperationType())))
/*      */       {
/* 1197 */         return roleRight;
/*      */       }
/*      */     }
/* 1200 */     return new RoleRight();
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightListByRight(Right currRight)
/*      */   {
/* 1209 */     this.log.debug(" in getRoleRightListByRight...");
/*      */ 
/* 1211 */     Connection con = null;
/* 1212 */     Statement stmt = null;
/*      */     try {
/* 1214 */       con = getConnection();
/* 1215 */       stmt = con.createStatement();
/*      */ 
/* 1217 */       StringBuffer sb = new StringBuffer();
/* 1218 */       sb.append("select operatorid,controltype ");
/* 1219 */       sb.append(" from ").append(getRoleRightTable());
/* 1220 */       sb.append(" where 1=1");
/* 1221 */       sb.append(" and resourceid='").append(currRight.getResourceId()).append("'");
/*      */ 
/* 1223 */       sb.append(" and resourcetype=").append(currRight.getResourceType());
/* 1224 */       sb.append(" and ").append(getAccessTypeField()).append("=").append(currRight.getOperationType());
/*      */ 
/* 1226 */       sb.append(" and operatortype=0");
/*      */ 
/* 1228 */       this.log.debug(sb.toString());
/*      */ 
/* 1230 */       ResultSet rs = stmt.executeQuery(sb.toString());
/*      */ 
/* 1232 */       List roleRightList = new ArrayList();
/*      */       RoleRight roleRight;
/* 1233 */       while (rs.next()) {
/* 1234 */         roleRight = new RoleRight();
/* 1235 */         roleRight.setControlType(rs.getString(2));
/* 1236 */         roleRight.setRight(currRight);
/* 1237 */         roleRight.setRoleId(rs.getString(1));
/* 1238 */         roleRightList.add(roleRight);
/*      */       }
/* 1240 */       rs.close();
/* 1241 */       return roleRightList;
/*      */     } catch (Exception ex) {
/* 1243 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/* 1245 */       if (stmt != null)
/*      */         try {
/* 1247 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/* 1251 */       if (con != null)
/* 1252 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightListByRole(String roleId, int resourceType)
/*      */   {
/* 1265 */     this.log.debug(" in getRoleRightListByRole...");
/*      */     try {
/* 1267 */       List roleIdList = new ArrayList();
/* 1268 */       roleIdList.add(roleId);
/* 1269 */       return getRoleRightListByRoles(roleIdList, resourceType);
/*      */     } catch (Exception ex) {
/* 1271 */       this.log.error("getRoleRightListByRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + "", ex);
/*      */ 
/* 1274 */       throw new RuntimeException(ex.getMessage(), ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private List<RoleRight> getRoleRightListByRoles(List<String> roleIdList, int resourceType)
/*      */   {
/* 1280 */     this.log.debug(" in getRoleRightListByRoles...");
/* 1281 */     if (CollectionUtils.isEmpty(roleIdList)) {
/* 1282 */       return new ArrayList();
/*      */     }
/*      */ 
/* 1286 */     Sqlca sqlca = null;
/* 1287 */     String accessTypeStr = getAccessTypeField();
/*      */     try {
/* 1289 */       sqlca = new Sqlca(new ConnectionEx());
/* 1290 */       accessTypeStr = sqlca.getSql_intTochar("rij." + getAccessTypeField());
/*      */ 
/* 1296 */       if (null != sqlca)
/* 1297 */         sqlca.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1293 */       this.log.debug(e.getMessage());
/* 1294 */       return new ArrayList();
/*      */     } finally {
/* 1296 */       if (null != sqlca) {
/* 1297 */         sqlca.closeAll();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1302 */     StringBuffer rightSql = new StringBuffer();
/* 1303 */     rightSql.append(" select rij.resourceid ID_FIELD,");
/* 1304 */     rightSql.append(" rij.operatorid OPERATOR_ID,");
/* 1305 */     rightSql.append(" rij.").append(getAccessTypeField());
/* 1306 */     rightSql.append(" ACCESS_TYPE,");
/* 1307 */     rightSql.append(" rij.controltype CONTROL_TYPE");
/* 1308 */     rightSql.append(" , rod.operationname OPERATION_NAME");
/* 1309 */     rightSql.append(" from ").append(getRoleRightTable());
/* 1310 */     rightSql.append(" rij, ");
/* 1311 */     rightSql.append("RESOURCE_OPERATION_DEFINE");
/* 1312 */     rightSql.append(" rod ");
/* 1313 */     rightSql.append(" where 1=1");
/* 1314 */     rightSql.append(" and rij.resourcetype=").append(resourceType);
/* 1315 */     rightSql.append(" and rij.resourcetype=rod.resourcetype");
/* 1316 */     rightSql.append(" and rod.operationkey=").append(accessTypeStr);
/* 1317 */     rightSql.append(" and rij.operatorid in(");
/* 1318 */     rightSql.append(StringUtil.list2String(roleIdList, ",", true));
/* 1319 */     rightSql.append(")");
/* 1320 */     this.log.debug("-------sql=" + rightSql.toString());
/* 1321 */     List list = getJdbcTemplate().queryForList(rightSql.toString());
/*      */ 
/* 1325 */     if (CollectionUtils.isEmpty(list)) {
/* 1326 */       return new ArrayList();
/*      */     }
/*      */ 
/* 1330 */     StringBuffer sqlDefineBuffer = new StringBuffer();
/* 1331 */     sqlDefineBuffer.append(" select ").append(getDescField());
/* 1332 */     sqlDefineBuffer.append(" DESC_FIELD");
/* 1333 */     sqlDefineBuffer.append(" ,").append(getIdField());
/* 1334 */     sqlDefineBuffer.append(" ID_FIELD");
/* 1335 */     if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */     {
/* 1337 */       sqlDefineBuffer.append(" ,").append(getParentFiled());
/* 1338 */       sqlDefineBuffer.append(" PARENT_FIELD");
/*      */     } else {
/* 1340 */       sqlDefineBuffer.append(" ,").append("'0'").append(" PARENT_FIELD");
/*      */     }
/* 1342 */     if (hasCheckFrameField()) {
/* 1343 */       sqlDefineBuffer.append(" ,").append(getCheckFrameField());
/* 1344 */       sqlDefineBuffer.append(" CHECK_FRAME_FIELD");
/*      */     }
/* 1346 */     sqlDefineBuffer.append(" from ").append(getDefineTable());
/* 1347 */     sqlDefineBuffer.append(" where ").append(getResourceTypeField());
/* 1348 */     sqlDefineBuffer.append(" =").append(resourceType);
/* 1349 */     List resourceIdList = new ArrayList();
/* 1350 */     for (Map map : list) {
/* 1351 */       resourceIdList.add(map.get("ID_FIELD").toString());
/*      */     }
/* 1353 */     List idList = new ArrayList();
/* 1354 */     if (isIdVarchar())
/* 1355 */       idList = getInSqlStr(resourceIdList, true);
/*      */     else {
/* 1357 */       idList = getInSqlStr(resourceIdList, false);
/*      */     }
/* 1359 */     sqlDefineBuffer.append(" and (");
/* 1360 */     for (int i = 0; i < idList.size(); i++) {
/* 1361 */       if (i != 0) {
/* 1362 */         sqlDefineBuffer.append(" or ");
/*      */       }
/* 1364 */       sqlDefineBuffer.append(" ").append(getIdField());
/* 1365 */       sqlDefineBuffer.append(" in(").append(idList.get(i));
/* 1366 */       sqlDefineBuffer.append(")");
/*      */     }
/* 1368 */     sqlDefineBuffer.append(" )");
/*      */ 
/* 1370 */     this.log.debug("-----sql=" + sqlDefineBuffer.toString());
/*      */ 
/* 1373 */     Map titleMap = new HashMap();
/* 1374 */     Map parentMap = new HashMap();
/* 1375 */     Map checkFrameMap = new HashMap();
/* 1376 */     SqlcaPst sqlcaPst = null;
/*      */     try {
/* 1378 */       sqlcaPst = new SqlcaPst(this.jndiDataSource.getConnection());
/* 1379 */       sqlcaPst.setSql(sqlDefineBuffer.toString());
/* 1380 */       sqlcaPst.execute();
/* 1381 */       while (sqlcaPst.next()) {
/* 1382 */         String resourceId = "";
/* 1383 */         if (isIdVarchar())
/* 1384 */           resourceId = sqlcaPst.getString("ID_FIELD");
/*      */         else {
/* 1386 */           resourceId = sqlcaPst.getInteger("ID_FIELD").toString();
/*      */         }
/* 1388 */         titleMap.put(resourceId, sqlcaPst.getString("DESC_FIELD"));
/* 1389 */         parentMap.put(resourceId, sqlcaPst.getString("PARENT_FIELD"));
/* 1390 */         if (hasCheckFrameField()) {
/* 1391 */           checkFrame = getCheckFrameValue().equals(sqlcaPst.getString("CHECK_FRAME_FIELD"));
/*      */ 
/* 1393 */           checkFrameMap.put(resourceId, Boolean.valueOf(checkFrame));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1400 */       if (null != sqlcaPst)
/* 1401 */         sqlcaPst.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       boolean checkFrame;
/* 1397 */       this.log.debug(e.getMessage());
/* 1398 */       return new ArrayList();
/*      */     } finally {
/* 1400 */       if (null != sqlcaPst) {
/* 1401 */         sqlcaPst.closeAll();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1406 */     List resultList = new ArrayList();
/* 1407 */     Set resultSet = new HashSet();
/* 1408 */     int roleType = getRoleType(resourceType);
/* 1409 */     for (Map map : list) {
/* 1410 */       Right right = new Right();
/* 1411 */       right.setResourceType(resourceType);
/* 1412 */       String resourceId = map.get("ID_FIELD").toString();
/* 1413 */       right.setResourceId(resourceId);
/* 1414 */       right.setOperationType(String.valueOf(map.get("ACCESS_TYPE")));
/* 1415 */       right.setOperationName(map.get("OPERATION_NAME").toString());
/* 1416 */       right.setTopId(getTopLevelId());
/* 1417 */       right.setRoleType(roleType);
/* 1418 */       right.setResourceName((String)titleMap.get(resourceId));
/* 1419 */       right.setParentId((String)parentMap.get(resourceId));
/* 1420 */       if (hasCheckFrameField()) {
/* 1421 */         right.setHasCheckFrame(((Boolean)checkFrameMap.get(resourceId)).booleanValue());
/*      */       }
/* 1423 */       RoleRight roleRight = new RoleRight();
/* 1424 */       roleRight.setRoleId(map.get("OPERATOR_ID").toString());
/* 1425 */       roleRight.setRight(right);
/* 1426 */       roleRight.setControlType(map.get("CONTROL_TYPE").toString());
/* 1427 */       resultList.add(roleRight);
/* 1428 */       resultSet.add(roleRight.getRoleId() + "-" + roleRight.getRight().getResourceId() + "-" + roleRight.getRight().getOperationType());
/*      */     }
/*      */ 
/* 1434 */     List rightList = getCheckFrameRight(resourceType, roleType);
/* 1435 */     for (Iterator i$ = rightList.iterator(); i$.hasNext(); ) { right = (Right)i$.next();
/* 1436 */       for (String roleId : roleIdList) {
/* 1437 */         boolean isExist = resultSet.add(roleId + "-" + right.getResourceId() + "-" + right.getOperationType());
/*      */ 
/* 1440 */         if (isExist) {
/* 1441 */           RoleRight roleRight = new RoleRight();
/* 1442 */           roleRight.setRoleId(roleId);
/* 1443 */           roleRight.setRight(right);
/* 1444 */           roleRight.setControlType("0");
/* 1445 */           resultList.add(roleRight);
/*      */         }
/*      */       }
/*      */     }
/*      */     Right right;
/* 1449 */     return resultList;
/*      */   }
/*      */ 
/*      */   public List<Right> getUserRightList(String userId, int resourceType, int roleType, boolean isDistinctControlType)
/*      */   {
/* 1460 */     this.log.debug(" in getUserRightList...");
/*      */ 
/* 1463 */     Sqlca sqlca = null;
/* 1464 */     String accessTypeStr = getAccessTypeField();
/*      */     try {
/* 1466 */       sqlca = new Sqlca(new ConnectionEx());
/* 1467 */       accessTypeStr = sqlca.getSql_intTochar("rij." + getAccessTypeField());
/*      */ 
/* 1473 */       if (null != sqlca)
/* 1474 */         sqlca.closeAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1470 */       this.log.debug(e.getMessage());
/* 1471 */       return new ArrayList();
/*      */     } finally {
/* 1473 */       if (null != sqlca) {
/* 1474 */         sqlca.closeAll();
/*      */       }
/*      */     }
/*      */ 
/* 1478 */     StringBuffer rightSql = new StringBuffer();
/* 1479 */     rightSql.append(" select rij.resourceid ID_FIELD,");
/* 1480 */     rightSql.append(" rij.").append(getAccessTypeField()).append(" ACCESS_TYPE,");
/*      */ 
/* 1482 */     rightSql.append(" rij.controltype CONTROL_TYPE, rod.operationname OPERATION_NAME");
/*      */ 
/* 1484 */     rightSql.append(" from ").append(getRoleRightTable()).append(" rij, ");
/*      */ 
/* 1486 */     rightSql.append("RESOURCE_OPERATION_DEFINE").append(" rod ");
/*      */ 
/* 1488 */     rightSql.append(" where 1=1");
/* 1489 */     rightSql.append(" and rij.resourcetype=").append(resourceType);
/* 1490 */     rightSql.append(" and rij.resourcetype=rod.resourcetype");
/* 1491 */     rightSql.append(" and rod.operationkey=").append(accessTypeStr);
/* 1492 */     rightSql.append(" and rij.operatorid='").append(userId).append("'");
/* 1493 */     rightSql.append(" and rij.operatortype=1");
/* 1494 */     if (isDistinctControlType == true) {
/* 1495 */       rightSql.append(" and rij.controltype='").append("1").append("'");
/*      */     }
/*      */ 
/* 1498 */     this.log.debug("-------sql=" + rightSql.toString());
/*      */ 
/* 1501 */     Object result = new ArrayList();
/* 1502 */     Object rightSet = new HashSet();
/* 1503 */     List list = getJdbcTemplate().queryForList(rightSql.toString());
/*      */ 
/* 1505 */     if (CollectionUtils.isNotEmpty(list)) {
/* 1506 */       for (Map map : list) {
/* 1507 */         Right right = new Right();
/* 1508 */         right.setResourceType(resourceType);
/* 1509 */         right.setResourceId(map.get("ID_FIELD").toString());
/* 1510 */         right.setOperationType(String.valueOf(map.get("ACCESS_TYPE")));
/* 1511 */         right.setOperationName(map.get("OPERATION_NAME").toString());
/* 1512 */         right.setTopId(getTopLevelId());
/* 1513 */         right.setRoleType(roleType);
/*      */ 
/* 1515 */         StringBuffer sqlDefineBuffer = new StringBuffer();
/* 1516 */         sqlDefineBuffer.append(" select ").append(getDescField()).append(" DESC_FIELD");
/*      */ 
/* 1518 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*      */         {
/* 1520 */           sqlDefineBuffer.append(" ,").append(getParentFiled()).append(" PARENT_FIELD");
/*      */         }
/*      */         else {
/* 1523 */           sqlDefineBuffer.append(" ,").append("'0'").append(" PARENT_FIELD");
/*      */         }
/*      */ 
/* 1526 */         sqlDefineBuffer.append(" where ").append(getIdField()).append("=?  ");
/*      */ 
/* 1528 */         sqlDefineBuffer.append(" and ").append(getResourceTypeField()).append("=? ");
/*      */ 
/* 1530 */         this.log.debug("-----sql=" + sqlDefineBuffer.toString());
/*      */ 
/* 1532 */         SqlcaPst sqlcaPst = null;
/*      */         try {
/* 1534 */           sqlcaPst = new SqlcaPst(this.jndiDataSource.getConnection());
/* 1535 */           sqlcaPst.setSql(sqlDefineBuffer.toString());
/* 1536 */           if (isIdVarchar())
/* 1537 */             sqlcaPst.setString(1, map.get("ID_FIELD").toString());
/*      */           else {
/* 1539 */             sqlcaPst.setInteger(1, map.get("ID_FIELD").toString());
/*      */           }
/* 1541 */           sqlcaPst.setInteger(2, Integer.valueOf(resourceType));
/* 1542 */           sqlcaPst.execute();
/* 1543 */           if (sqlcaPst.next()) {
/* 1544 */             right.setResourceName(sqlcaPst.getString("DESC_FIELD"));
/* 1545 */             right.setParentId(sqlcaPst.getString("PARENT_FIELD"));
/*      */           }
/* 1547 */           if (((Set)rightSet).add(right.getResourceId() + "-" + right.getOperationType()))
/*      */           {
/* 1549 */             ((List)result).add(right);
/*      */           }
/*      */ 
/* 1555 */           if (null != sqlcaPst)
/* 1556 */             sqlcaPst.closeAll();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1552 */           this.log.debug(e.getMessage());
/* 1553 */           return new ArrayList();
/*      */         } finally {
/* 1555 */           if (null != sqlcaPst) {
/* 1556 */             sqlcaPst.closeAll();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1562 */     return result;
/*      */   }
/*      */ 
/*      */   public void initDaoParameter(int resourceType)
/*      */   {
/* 1572 */     Collection srdpList = SysResourceDsPropCache.getInstance().getObjectByResourceType(resourceType);
/*      */ 
/* 1574 */     if (CollectionUtils.isEmpty(srdpList)) {
/* 1575 */       throw new RuntimeException("The SysResourceDsProp record does not exist when resourcetype equal to " + resourceType);
/*      */     }
/*      */ 
/* 1579 */     Map propMap = new HashMap();
/* 1580 */     Iterator it = srdpList.iterator();
/* 1581 */     while (it.hasNext()) {
/* 1582 */       SysResourceDsProp srdp = (SysResourceDsProp)it.next();
/* 1583 */       propMap.put(srdp.getPropKey(), srdp.getPropValue());
/*      */     }
/*      */ 
/* 1586 */     setJndiName((String)propMap.get("jndiName"));
/* 1587 */     String initialContextFactory = (String)propMap.get("initialContextFactory");
/* 1588 */     String providerUrl = (String)propMap.get("providerUrl");
/* 1589 */     String securityPrincipal = (String)propMap.get("securityPrincipal");
/* 1590 */     String securityCrendentials = (String)propMap.get("securityCrendentials");
/* 1591 */     lookUpJNDI(initialContextFactory, providerUrl, securityPrincipal, securityCrendentials);
/*      */ 
/* 1594 */     setRoleRightTable((String)propMap.get("roleRightTable"));
/* 1595 */     setDefineTable((String)propMap.get("defineTable"));
/* 1596 */     setIdField((String)propMap.get("idField"));
/* 1597 */     setDescField((String)propMap.get("descField"));
/* 1598 */     setResourceTypeField((String)propMap.get("resourceTypeField"));
/* 1599 */     setAccessTypeField((String)propMap.get("accessTypeField"));
/* 1600 */     setParentFiled((String)propMap.get("parentFiled"));
/* 1601 */     if (StringUtils.isNotBlank((String)propMap.get("sortField")))
/* 1602 */       setSortField((String)propMap.get("sortField"));
/*      */     else {
/* 1604 */       setSortField("");
/*      */     }
/* 1606 */     if (StringUtils.isNotBlank((String)propMap.get("orderSql")))
/* 1607 */       setOrderSql((String)propMap.get("orderSql"));
/*      */     else {
/* 1609 */       setOrderSql("");
/*      */     }
/* 1611 */     if (StringUtils.isNotBlank((String)propMap.get("topLevelId")))
/* 1612 */       setTopLevelId((String)propMap.get("topLevelId"));
/*      */     else {
/* 1614 */       setTopLevelId("-1");
/*      */     }
/* 1616 */     if (StringUtils.isNotBlank((String)propMap.get("checkFrameField"))) {
/* 1617 */       setCheckFrameField((String)propMap.get("checkFrameField"));
/* 1618 */       setCheckFrameValue((String)propMap.get("checkFrameValue"));
/*      */     } else {
/* 1620 */       setCheckFrameField("");
/* 1621 */       setCheckFrameValue("");
/*      */     }
/* 1623 */     if (StringUtils.isNotBlank((String)propMap.get("isAccessType")))
/* 1624 */       setIsAccessType((String)propMap.get("isAccessType"));
/*      */     else {
/* 1626 */       setIsAccessType("0");
/*      */     }
/* 1628 */     if (StringUtils.isNotBlank((String)propMap.get("idVarchar"))) {
/* 1629 */       setIdVarchar(new Boolean((String)propMap.get("idVarchar")).booleanValue());
/*      */ 
/* 1631 */       setNeedConvertIdType(new Boolean((String)propMap.get("isNeedConvertIdType")).booleanValue());
/*      */     }
/*      */     else {
/* 1634 */       setIdVarchar(true);
/* 1635 */       setNeedConvertIdType(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void lookUpJNDI(String initialContextFactory, String providerUrl, String securityPrincipal, String securityCrendentials)
/*      */   {
/* 1653 */     if (StringUtils.isBlank(getJndiName())) {
/* 1654 */       throw new RuntimeException("The jndiName is empty.");
/*      */     }
/* 1656 */     String prefix = Configure.getInstance().getProperty("JNDI_PREFIX");
/* 1657 */     Context ctx = null;
/*      */     try {
/* 1659 */       Hashtable ht = new Hashtable();
/* 1660 */       if (StringUtils.isNotBlank(initialContextFactory)) {
/* 1661 */         ht.put("java.naming.factory.initial", initialContextFactory);
/*      */       }
/* 1663 */       if (StringUtils.isNotBlank(providerUrl)) {
/* 1664 */         ht.put("java.naming.provider.url", providerUrl);
/*      */       }
/* 1666 */       if (StringUtils.isNotBlank(securityPrincipal)) {
/* 1667 */         ht.put("java.naming.security.principal", securityPrincipal);
/*      */       }
/* 1669 */       if (StringUtils.isNotBlank(securityCrendentials)) {
/* 1670 */         ht.put("java.naming.security.credentials", securityCrendentials);
/*      */       }
/* 1672 */       if (!ht.isEmpty())
/* 1673 */         ctx = new InitialContext(ht);
/*      */       else {
/* 1675 */         ctx = new InitialContext();
/*      */       }
/* 1677 */       DataSource ds = (DataSource)ctx.lookup(prefix + getJndiName());
/*      */ 
/* 1680 */       if (ds != null)
/* 1681 */         this.jndiDataSource = ds;
/*      */       else {
/* 1683 */         throw new RuntimeException("JNDI lookup error." + getJndiName());
/*      */       }
/*      */ 
/* 1689 */       if (null != ctx)
/*      */         try {
/* 1691 */           ctx.close();
/*      */         }
/*      */         catch (NamingException e)
/*      */         {
/*      */           throw new RuntimeException("Context close error." + e.getMessage(), e);
/*      */         }
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/* 1687 */       throw new RuntimeException("JNDI lookup error." + e.getMessage(), e);
/*      */     } finally {
/* 1689 */       if (null != ctx)
/*      */         try {
/* 1691 */           ctx.close();
/*      */         } catch (NamingException e) {
/* 1693 */           throw new RuntimeException("Context close error." + e.getMessage(), e);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isExistRoleRight(String roleId, String resourceId, int resourceType, String operationType)
/*      */   {
/* 1708 */     StringBuffer allSql = new StringBuffer();
/* 1709 */     allSql.append("select resright.*");
/* 1710 */     allSql.append(" from ").append(getRoleRightTable()).append(" resright ");
/*      */ 
/* 1712 */     allSql.append(" where 1=1");
/* 1713 */     allSql.append(" and resright.").append("operatorid").append("='").append(roleId).append("'");
/*      */ 
/* 1715 */     allSql.append(" and resourceid").append("=").append("'").append(resourceId).append("'");
/*      */ 
/* 1717 */     allSql.append(" and resourcetype").append("=").append(resourceType);
/* 1718 */     allSql.append(" and ").append(getAccessTypeField()).append("=").append(operationType);
/*      */ 
/* 1720 */     this.log.debug("-----sql=" + allSql);
/*      */ 
/* 1722 */     List list = getJdbcTemplate().queryForList(allSql.toString());
/*      */ 
/* 1724 */     if (CollectionUtils.isEmpty(list)) {
/* 1725 */       return false;
/*      */     }
/* 1727 */     return true;
/*      */   }
/*      */ 
/*      */   public void save(RoleRight newRoleRight)
/*      */   {
/* 1737 */     this.log.debug(" in save(RoleRight newRoleRight)............");
/*      */     try {
/* 1739 */       List roleRightList = new ArrayList();
/* 1740 */       roleRightList.add(newRoleRight);
/* 1741 */       save(roleRightList);
/*      */     } catch (Exception ex) {
/* 1743 */       throw new RuntimeException(ex.getMessage(), ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void save(Collection<RoleRight> roleRightList)
/*      */   {
/* 1753 */     this.log.info(" in save............");
/* 1754 */     if ((null == roleRightList) || (roleRightList.isEmpty())) {
/* 1755 */       return;
/*      */     }
/* 1757 */     StringBuffer sql = new StringBuffer(256);
/* 1758 */     sql.append("insert into ").append(getRoleRightTable());
/* 1759 */     sql.append("(resourceid,resourcetype,operatorid,operatortype,").append(getAccessTypeField()).append(",controltype) ");
/* 1760 */     sql.append(" values(?,?,?,?,?,?)");
/* 1761 */     final RoleRight[] roleRights = (RoleRight[])roleRightList.toArray(new RoleRight[roleRightList.size()]);
/* 1762 */     BatchPreparedStatementSetter setter = new BatchPreparedStatementSetter() {
/*      */       public void setValues(PreparedStatement ps, int i) throws SQLException {
/* 1764 */         RoleRight roleRight = roleRights[i];
/* 1765 */         Right right = roleRight.getRight();
/* 1766 */         ps.setString(1, right.getResourceId());
/* 1767 */         ps.setInt(2, right.getResourceType());
/* 1768 */         ps.setString(3, roleRight.getRoleId());
/* 1769 */         ps.setInt(4, roleRight.getOperatorType());
/* 1770 */         ps.setInt(5, Integer.valueOf(right.getOperationType()).intValue());
/* 1771 */         ps.setString(6, roleRight.getControlType());
/*      */       }
/*      */       public int getBatchSize() {
/* 1774 */         return roleRights.length;
/*      */       }
/*      */     };
/* 1777 */     getJdbcTemplate().batchUpdate(sql.toString(), setter);
/*      */   }
/*      */ 
/*      */   public void updateControlType(String roleId, int resourceType, String resourceId, String controlType)
/*      */   {
/* 1788 */     StringBuffer sql = new StringBuffer(128);
/* 1789 */     sql.append("update ").append(getRoleRightTable());
/* 1790 */     sql.append(" set controltype='").append(controlType).append("'");
/* 1791 */     sql.append(" where resourceid='").append(resourceId).append("'");
/* 1792 */     sql.append(" and resourcetype=").append(resourceType);
/* 1793 */     sql.append(" and operatorid='").append(roleId).append("'");
/*      */ 
/* 1795 */     getJdbcTemplate().execute(sql.toString());
/*      */   }
/*      */ 
/*      */   private List getInSqlStr(List<String> valueList, boolean addQuote)
/*      */   {
/* 1808 */     List result = new ArrayList();
/* 1809 */     if (CollectionUtils.isEmpty(valueList)) {
/* 1810 */       return result;
/*      */     }
/* 1812 */     int maxLength = 1000;
/* 1813 */     int division = valueList.size() / maxLength;
/* 1814 */     int remainder = valueList.size() % maxLength;
/*      */ 
/* 1816 */     for (int i = 0; i < division; i++) {
/* 1817 */       List list = valueList.subList(i * maxLength, (i + 1) * maxLength);
/*      */ 
/* 1819 */       String str = StringUtil.list2String(list, ",", addQuote);
/* 1820 */       result.add(str);
/*      */     }
/*      */ 
/* 1823 */     if (remainder != 0) {
/* 1824 */       List list = valueList.subList(division * maxLength, valueList.size());
/*      */ 
/* 1826 */       String str = StringUtil.list2String(list, ",", addQuote);
/* 1827 */       result.add(str);
/*      */     }
/* 1829 */     return result;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.ResourceRightDaoJdbcImpl_JNDI
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ 
/*     */ public class ResourceRightDaoJdbcImpl_Plat4_Operation extends ResourceRightDaoJdbcImpl
/*     */ {
/*  45 */   private Log log = LogFactory.getLog(ResourceRightDaoJdbcImpl_Plat4_Operation.class);
/*     */ 
/*     */   public void delete(List<RoleRight> roleRightList)
/*     */   {
/*  49 */     this.log.info(" in delete............");
/*  50 */     Connection con = null;
/*  51 */     Statement stmt = null;
/*     */     try {
/*  53 */       con = getConnection();
/*  54 */       stmt = con.createStatement();
/*     */ 
/*  56 */       for (RoleRight roleRight : roleRightList) {
/*  57 */         Right right = roleRight.getRight();
/*  58 */         StringBuffer sql = new StringBuffer(256);
/*  59 */         sql.append("delete from ").append(getRoleRightTable());
/*  60 */         sql.append(" where resourceid='").append(right.getResourceId()).append("'");
/*     */ 
/*  62 */         sql.append(" and resourcetype=").append(right.getResourceType());
/*     */ 
/*  64 */         sql.append(" and operatorid='").append(roleRight.getRoleId()).append("'");
/*     */ 
/*  66 */         sql.append(" and operatortype=0");
/*     */ 
/*  68 */         this.log.info(sql);
/*  69 */         stmt.execute(sql.toString());
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/*  73 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRoleAuthRelationFail") + "", ex);
/*     */ 
/*  77 */       throw new RuntimeException(ex.getMessage());
/*     */     } finally {
/*  79 */       if (stmt != null)
/*     */         try {
/*  81 */           stmt.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/*  85 */       if (con != null)
/*  86 */         releaseConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(List<String> roleIdList, List<Right> rightList, int resourceType)
/*     */   {
/*  93 */     this.log.info("delete............");
/*  94 */     Connection con = null;
/*  95 */     Statement stmt = null;
/*     */     try {
/*  97 */       if ((roleIdList == null) || (roleIdList.size() == 0))
/*     */       {
/*     */         return;
/*     */       }
/* 101 */       if ((rightList == null) || (rightList.size() == 0))
/*     */       {
/*     */         return;
/*     */       }
/* 105 */       con = getConnection();
/* 106 */       stmt = con.createStatement();
/*     */ 
/* 109 */       operatorIdString = StringUtil.list2String(roleIdList, ",", true);
/*     */ 
/* 111 */       for (Right right : rightList) {
/* 112 */         StringBuffer sql = new StringBuffer(256);
/* 113 */         sql.append("delete from ").append(getRoleRightTable());
/* 114 */         sql.append(" where 1=1 ");
/* 115 */         sql.append(" and operatorid in (").append(operatorIdString).append(")");
/*     */ 
/* 117 */         sql.append(" and resourcetype=").append(resourceType);
/* 118 */         sql.append(" and resourceid='").append(right.getResourceId()).append("'");
/*     */ 
/* 121 */         this.log.info(sql);
/* 122 */         stmt.executeUpdate(sql.toString());
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */       String operatorIdString;
/* 126 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRoleAuthFail") + "", ex);
/*     */ 
/* 129 */       throw new RuntimeException(ex.getMessage());
/*     */     } finally {
/* 131 */       if (stmt != null)
/*     */         try {
/* 133 */           stmt.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 137 */       if (con != null)
/* 138 */         releaseConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Right> getAllRightList(int roleType, int resourceType)
/*     */   {
/* 144 */     StringBuffer sb = new StringBuffer();
/* 145 */     sb.append("select operationid ,operationname ,operationkey,parentid ");
/* 146 */     sb.append(" from ").append(getDefineTable());
/* 147 */     sb.append(" where resourcetype=").append(resourceType);
/* 148 */     Connection con = null;
/* 149 */     Statement stmt = null;
/*     */     try {
/* 151 */       con = getConnection();
/* 152 */       stmt = con.createStatement();
/* 153 */       this.log.info(sb.toString());
/*     */ 
/* 155 */       ResultSet rs = stmt.executeQuery(sb.toString());
/* 156 */       result = new ArrayList();
/*     */       Right right;
/* 157 */       while (rs.next()) {
/* 158 */         right = new Right();
/* 159 */         right.setRoleType(roleType);
/*     */ 
/* 161 */         right.setResourceId(rs.getString("operationid"));
/* 162 */         right.setResourceName(rs.getString("operationname"));
/* 163 */         right.setParentId(rs.getString("parentid"));
/* 164 */         right.setOperationType("-1");
/*     */ 
/* 167 */         right.setResourceType(resourceType);
/*     */ 
/* 170 */         result.add(right);
/*     */       }
/*     */ 
/* 173 */       rs.close();
/*     */ 
/* 175 */       return result;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       List result;
/* 177 */       this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllAuthFail") + e.getMessage());
/*     */ 
/* 180 */       return new ArrayList();
/*     */     } finally {
/* 182 */       if (stmt != null)
/*     */         try {
/* 184 */           stmt.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 188 */       if (con != null)
/* 189 */         releaseConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Right> getRightList(List<String> roleIdList, int resourceType, boolean isDistinctControlType)
/*     */   {
/* 200 */     this.log.debug(" in getRightList...");
/* 201 */     Sqlca sqlca = null;
/*     */     try {
/* 203 */       sqlca = new Sqlca(new ConnectionEx());
/* 204 */       if ((roleIdList == null) || (roleIdList.isEmpty())) {
/* 205 */         return new ArrayList();
/*     */       }
/*     */ 
/* 209 */       StringBuffer sb = new StringBuffer();
/* 210 */       sb.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*     */ 
/* 212 */       sb.append("resdef.").append(getDescField()).append(" DESC_FIELD");
/* 213 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*     */       {
/* 215 */         sb.append(",resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*     */       }
/*     */ 
/* 218 */       sb.append(" from ").append(getDefineTable()).append(" resdef,").append(getRoleRightTable()).append(" rig ");
/*     */ 
/* 220 */       sb.append(" where 1=1 ");
/*     */ 
/* 223 */       idField = sqlca.getSql_intTochar("resdef." + getIdField());
/* 224 */       this.log.debug("idField:" + idField);
/*     */ 
/* 227 */       if (isDistinctControlType) {
/* 228 */         sb.append(" and rig.controltype='").append("1").append("'");
/*     */       }
/*     */ 
/* 231 */       sb.append(" and ").append(idField).append("=rig.resourceid");
/* 232 */       sb.append(" and rig.operatorid in(").append(StringUtil.list2String(roleIdList, ",", true)).append(") ");
/*     */ 
/* 234 */       sb.append(" and rig.resourcetype=").append(resourceType);
/*     */ 
/* 236 */       if (StringUtils.isNotBlank(getOrderSql())) {
/* 237 */         sb.append(" ").append(getOrderSql());
/*     */       }
/*     */ 
/* 240 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql:" + sb.toString());
/*     */ 
/* 244 */       sqlca.execute(sb.toString());
/* 245 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeOver") + "");
/*     */ 
/* 252 */       List result = new ArrayList();
/* 253 */       int roleType = getRoleTypeByResourceType(resourceType);
/*     */       Right right;
/* 254 */       while (sqlca.next())
/*     */       {
/* 257 */         right = new Right();
/* 258 */         right.setRoleType(roleType);
/* 259 */         right.setResourceId(sqlca.getString("ID_FIELD"));
/* 260 */         right.setResourceName(sqlca.getString("DESC_FIELD"));
/* 261 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*     */         {
/* 263 */           right.setParentId(sqlca.getString("PARENT_FIELD"));
/*     */         }
/* 265 */         else right.setParentId("0");
/*     */ 
/* 267 */         right.setOperationType("-1");
/*     */ 
/* 269 */         right.setOperationName("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.manage") + "");
/*     */ 
/* 272 */         right.setResourceType(resourceType);
/* 273 */         right.setTopId(getTopLevelId());
/*     */ 
/* 275 */         if (!result.contains(right)) {
/* 276 */           result.add(right);
/*     */         }
/*     */       }
/* 279 */       this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuthList") + ":" + result.size());
/*     */ 
/* 283 */       this.log.debug(" end getRightList...");
/* 284 */       return result;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */       String idField;
/* 286 */       this.log.debug("getRightList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*     */ 
/* 290 */       return new ArrayList();
/*     */     } finally {
/* 292 */       if (sqlca != null)
/* 293 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<RoleRight> getRoleRightListByRight(Right currRight)
/*     */   {
/* 299 */     this.log.debug(" in getRoleRightListByRight...");
/* 300 */     Connection con = null;
/* 301 */     Statement stmt = null;
/*     */     try {
/* 303 */       con = getConnection();
/* 304 */       stmt = con.createStatement();
/*     */ 
/* 306 */       StringBuffer sb = new StringBuffer();
/* 307 */       sb.append("select operatorid,controltype");
/* 308 */       sb.append(" from ").append(getRoleRightTable());
/* 309 */       sb.append(" where 1=1");
/* 310 */       sb.append(" and resourceid='").append(currRight.getResourceId()).append("'");
/*     */ 
/* 312 */       sb.append(" and resourcetype=").append(currRight.getResourceType());
/*     */ 
/* 314 */       this.log.info(sb.toString());
/*     */ 
/* 316 */       rs = stmt.executeQuery(sb.toString());
/*     */ 
/* 318 */       List roleRightList = new ArrayList();
/*     */       RoleRight roleRight;
/* 319 */       while (rs.next()) {
/* 320 */         roleRight = new RoleRight();
/* 321 */         roleRight.setControlType(rs.getString(2));
/* 322 */         roleRight.setRight(currRight);
/* 323 */         roleRight.setRoleId(rs.getString(1));
/* 324 */         roleRightList.add(roleRight);
/*     */       }
/*     */ 
/* 327 */       rs.close();
/*     */ 
/* 329 */       return roleRightList;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */       ResultSet rs;
/* 331 */       this.log.debug(ex.getMessage());
/* 332 */       return new ArrayList();
/*     */     } finally {
/* 334 */       if (stmt != null)
/*     */         try {
/* 336 */           stmt.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 340 */       if (con != null)
/* 341 */         releaseConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<RoleRight> getRoleRightListByRoles(List<String> roleIdList, int resourceType)
/*     */   {
/* 348 */     this.log.debug(" in getRoleRightListByRoles...");
/* 349 */     Sqlca sqlca = null;
/* 350 */     Connection con = null;
/* 351 */     Statement stmt = null;
/*     */     try {
/* 353 */       sqlca = new Sqlca(new ConnectionEx());
/* 354 */       if ((roleIdList == null) || (roleIdList.isEmpty())) {
/* 355 */         return new ArrayList();
/*     */       }
/*     */ 
/* 358 */       con = getConnection();
/* 359 */       stmt = con.createStatement();
/*     */ 
/* 361 */       Object result = new ArrayList();
/*     */ 
/* 363 */       roleType = getRoleTypeByResourceType(resourceType);
/*     */ 
/* 366 */       StringBuffer sb = new StringBuffer();
/* 367 */       sb.append("select resdef.").append(getIdField()).append(" ID_FIELD,");
/*     */ 
/* 369 */       sb.append("resdef.").append(getDescField()).append(" DESC_FIELD,");
/* 370 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*     */       {
/* 372 */         sb.append("resdef.").append(getParentFiled()).append(" PARENT_FIELD,");
/*     */       }
/*     */ 
/* 375 */       sb.append("rig.operatorid OPERATOR_ID,rig.controltype CONTROL_TYPE ");
/*     */ 
/* 377 */       sb.append(" from ").append(getDefineTable()).append(" resdef,").append(getRoleRightTable()).append(" rig ");
/*     */ 
/* 379 */       sb.append(" where 1=1 ");
/*     */ 
/* 382 */       String idField = sqlca.getSql_intTochar("resdef." + getIdField());
/* 383 */       this.log.debug("idField:" + idField);
/*     */ 
/* 386 */       sb.append(" and ").append(idField).append("=rig.resourceid");
/* 387 */       sb.append(" and rig.operatorid in(").append(StringUtil.list2String(roleIdList, ",", true)).append(") ");
/*     */ 
/* 389 */       sb.append(" and rig.resourcetype=").append(resourceType);
/*     */ 
/* 391 */       if (StringUtils.isNotBlank(getOrderSql())) {
/* 392 */         sb.append(" ").append(getOrderSql());
/*     */       }
/*     */ 
/* 395 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql:" + sb.toString());
/*     */ 
/* 400 */       ResultSet rs2 = stmt.executeQuery(sb.toString());
/* 401 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeOver") + "");
/*     */       Right right;
/* 407 */       while (rs2.next())
/*     */       {
/* 410 */         right = new Right();
/* 411 */         right.setRoleType(roleType);
/* 412 */         right.setResourceId(rs2.getString("ID_FIELD"));
/* 413 */         right.setResourceName(rs2.getString("DESC_FIELD"));
/* 414 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*     */         {
/* 416 */           right.setParentId(rs2.getString("PARENT_FIELD"));
/*     */         }
/* 418 */         else right.setParentId("0");
/*     */ 
/* 420 */         right.setOperationType("-1");
/*     */ 
/* 422 */         right.setResourceType(resourceType);
/* 423 */         right.setTopId(getTopLevelId());
/*     */ 
/* 425 */         RoleRight roleRight = new RoleRight();
/* 426 */         roleRight.setRoleId(rs2.getString("OPERATOR_ID"));
/* 427 */         roleRight.setRight(right);
/* 428 */         roleRight.setControlType(rs2.getString("CONTROL_TYPE"));
/*     */ 
/* 430 */         ((List)result).add(roleRight);
/*     */       }
/* 432 */       this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuthList") + ":" + ((List)result).size());
/*     */ 
/* 437 */       rs2.close();
/*     */ 
/* 439 */       this.log.debug(" end getRoleRightListByRoles...");
/* 440 */       return (Right)result;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */       int roleType;
/* 442 */       this.log.debug("getRoleRightListByRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*     */ 
/* 445 */       return new ArrayList();
/*     */     } finally {
/* 447 */       if (stmt != null)
/*     */         try {
/* 449 */           stmt.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 453 */       if (con != null) {
/* 454 */         releaseConnection(con);
/*     */       }
/* 456 */       if (sqlca != null)
/* 457 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void save(Collection<RoleRight> roleRightList)
/*     */   {
/* 464 */     this.log.info(" in save............");
/* 465 */     Connection con = null;
/* 466 */     Statement stmt = null;
/*     */     try {
/* 468 */       con = getConnection();
/* 469 */       stmt = con.createStatement();
/*     */ 
/* 471 */       for (RoleRight roleRight : roleRightList) {
/* 472 */         Right right = roleRight.getRight();
/* 473 */         StringBuffer sql = new StringBuffer(256);
/* 474 */         sql.append("insert into ").append(getRoleRightTable());
/* 475 */         sql.append("(resourceid,resourcetype,operatorid,operatortype,").append(getAccessTypeField()).append(",controltype) ");
/*     */ 
/* 477 */         sql.append(" values('").append(right.getResourceId()).append("',");
/*     */ 
/* 479 */         sql.append("").append(right.getResourceType()).append(",");
/* 480 */         sql.append("'").append(roleRight.getRoleId()).append("',");
/* 481 */         sql.append(roleRight.getOperatorType()).append(",");
/* 482 */         sql.append(Integer.valueOf(right.getOperationType())).append(",");
/*     */ 
/* 484 */         sql.append("'").append(roleRight.getControlType()).append("'");
/* 485 */         sql.append(")");
/*     */ 
/* 487 */         this.log.info(sql);
/* 488 */         stmt.execute(sql.toString());
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 492 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveRoleAuthRelationList") + "save" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.methodFail") + "", ex);
/*     */ 
/* 498 */       throw new RuntimeException(ex.getMessage());
/*     */     } finally {
/* 500 */       if (stmt != null)
/*     */         try {
/* 502 */           stmt.close();
/*     */         }
/*     */         catch (SQLException e) {
/*     */         }
/* 506 */       if (con != null)
/* 507 */         releaseConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateControlType(String roleId, int resourceType, String resourceId, String controlType)
/*     */   {
/* 515 */     StringBuffer sql = new StringBuffer(128);
/* 516 */     sql.append("update ").append(getRoleRightTable());
/* 517 */     sql.append(" set controltype='").append(controlType).append("'");
/* 518 */     sql.append(" where resourceid='").append(resourceId).append("'");
/* 519 */     sql.append(" and resourcetype=").append(resourceType);
/* 520 */     sql.append(" and operatorid='").append(roleId).append("'");
/*     */ 
/* 522 */     getJdbcTemplate().execute(sql.toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.ResourceRightDaoJdbcImpl_Plat4_Operation
 * JD-Core Version:    0.6.2
 */
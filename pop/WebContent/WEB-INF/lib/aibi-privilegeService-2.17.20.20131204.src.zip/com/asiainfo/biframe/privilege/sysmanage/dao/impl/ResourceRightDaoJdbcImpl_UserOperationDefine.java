/*      */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.exception.DaoException;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceDsPropCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.jdbc.core.JdbcTemplate;
/*      */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*      */ 
/*      */ public class ResourceRightDaoJdbcImpl_UserOperationDefine extends JdbcDaoSupport
/*      */   implements IResourceRightDAO
/*      */ {
/*   56 */   private Log log = LogFactory.getLog(ResourceRightDaoJdbcImpl_UserOperationDefine.class);
/*      */   private String rightTable;
/*      */   private String defineTable;
/*      */   private String idField;
/*      */   private String descField;
/*      */   private String parentFiled;
/*   69 */   private String sortField = "";
/*      */ 
/*   71 */   private String orderSql = "";
/*      */ 
/*   73 */   private String topLevelId = "-1";
/*      */   private String checkFrameField;
/*      */   private String checkFrameValue;
/*   79 */   private boolean idVarchar = true;
/*      */ 
/*   81 */   private String isAccessType = "0";
/*      */   private String accessTypeField;
/*      */   private String roleRightTable;
/*      */   private String resourceTypeField;
/*      */ 
/*      */   public String getResourceName(String resourceId)
/*      */   {
/*   90 */     String sql = "select " + getDescField() + " from " + getDefineTable() + " where " + getIdField() + "='" + resourceId + "'";
/*      */ 
/*   92 */     this.log.debug("--sql:" + sql);
/*   93 */     List list = getJdbcTemplate().queryForList(sql);
/*   94 */     if ((list == null) || (list.isEmpty())) {
/*   95 */       return "";
/*      */     }
/*   97 */     return ((Map)list.get(0)).get(getDescField()).toString();
/*      */   }
/*      */ 
/*      */   public void save(RoleRight newRoleRight)
/*      */   {
/*  104 */     this.log.info("save............");
/*      */     try {
/*  106 */       List roleRightList = new ArrayList();
/*  107 */       roleRightList.add(newRoleRight);
/*  108 */       save(roleRightList);
/*      */     } catch (Exception ex) {
/*  110 */       ex.printStackTrace();
/*  111 */       throw new RuntimeException(ex.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void save(Collection<RoleRight> roleRightList)
/*      */   {
/*  117 */     this.log.info("save............");
/*  118 */     Connection con = null;
/*  119 */     Statement stmt = null;
/*      */     try {
/*  121 */       con = getConnection();
/*  122 */       stmt = con.createStatement();
/*      */ 
/*  124 */       for (RoleRight roleRight : roleRightList) {
/*  125 */         StringBuffer sql = new StringBuffer(256);
/*  126 */         sql.append("insert into ").append(getRoleRightTable());
/*  127 */         sql.append(" (operator_id,operator_type,action_id,resource_type,control_type)");
/*      */ 
/*  129 */         sql.append(" values(");
/*  130 */         sql.append("'").append(roleRight.getRoleId()).append("',");
/*  131 */         sql.append(roleRight.getOperatorType()).append(",");
/*  132 */         sql.append("'").append(roleRight.getRight().getRightId()).append("',");
/*      */ 
/*  134 */         sql.append(roleRight.getRight().getResourceType()).append(",");
/*  135 */         sql.append("'").append(roleRight.getControlType()).append("'");
/*  136 */         sql.append(")");
/*      */ 
/*  138 */         this.log.info(sql);
/*  139 */         stmt.executeUpdate(sql.toString());
/*      */       }
/*      */     } catch (Exception ex) {
/*  142 */       ex.printStackTrace();
/*  143 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/*  145 */       if (stmt != null)
/*      */         try {
/*  147 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  151 */       if (con != null)
/*  152 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void delete(Collection<RoleRight> roleRightList)
/*      */   {
/*  158 */     this.log.info("delete............");
/*  159 */     Connection con = null;
/*  160 */     Statement stmt = null;
/*      */     try {
/*  162 */       con = getConnection();
/*  163 */       stmt = con.createStatement();
/*      */ 
/*  165 */       for (RoleRight roleRight : roleRightList) {
/*  166 */         StringBuffer sql = new StringBuffer(256);
/*  167 */         sql.append("delete from ").append(getRoleRightTable());
/*  168 */         sql.append(" where operator_id='").append(roleRight.getRoleId()).append("'");
/*      */ 
/*  170 */         sql.append(" and action_id='").append(roleRight.getRight().getRightId()).append("'");
/*      */ 
/*  172 */         sql.append(" and resource_type=").append(roleRight.getRight().getResourceType());
/*      */ 
/*  177 */         this.log.info(sql);
/*  178 */         stmt.executeUpdate(sql.toString());
/*      */       }
/*      */     } catch (Exception ex) {
/*  181 */       ex.printStackTrace();
/*  182 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/*  184 */       if (stmt != null)
/*      */         try {
/*  186 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  190 */       if (con != null)
/*  191 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void delete(String operatorId, int resourceType)
/*      */   {
/*  197 */     this.log.info("delete............");
/*  198 */     Connection con = null;
/*  199 */     Statement stmt = null;
/*      */     try {
/*  201 */       con = getConnection();
/*  202 */       stmt = con.createStatement();
/*      */ 
/*  204 */       StringBuffer sql = new StringBuffer(256);
/*  205 */       sql.append("delete from ").append(getRoleRightTable());
/*  206 */       sql.append(" where operator_id='").append(operatorId).append("'");
/*  207 */       sql.append(" and resource_type=").append(resourceType);
/*      */ 
/*  209 */       this.log.info(sql);
/*  210 */       stmt.executeUpdate(sql.toString());
/*      */     } catch (Exception ex) {
/*  212 */       this.log.error("Error deleting role rights. roleRightTable=" + getRoleRightTable() + ex.getMessage());
/*      */     }
/*      */     finally {
/*  215 */       if (stmt != null)
/*      */         try {
/*  217 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  221 */       if (con != null)
/*  222 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void delete(List<String> operatorIdList, List<Right> rightList, int resourceType)
/*      */   {
/*  230 */     this.log.info("delete............");
/*  231 */     Connection con = null;
/*  232 */     Statement stmt = null;
/*      */     try
/*      */     {
/*  235 */       if ((operatorIdList == null) || (operatorIdList.size() == 0))
/*      */       {
/*      */         return;
/*      */       }
/*  239 */       if ((rightList == null) || (rightList.size() == 0))
/*      */       {
/*      */         return;
/*      */       }
/*  243 */       con = getConnection();
/*  244 */       stmt = con.createStatement();
/*      */ 
/*  247 */       operatorIdString = StringUtil.list2String(operatorIdList, ",", true);
/*      */ 
/*  249 */       for (Right right : rightList) {
/*  250 */         StringBuffer sql = new StringBuffer(256);
/*  251 */         sql.append("delete from ").append(getRoleRightTable());
/*  252 */         sql.append(" where 1=1 ");
/*  253 */         sql.append(" and operator_id in (").append(operatorIdString).append(")");
/*      */ 
/*  255 */         sql.append(" and action_id='").append(right.getRightId()).append("'");
/*      */ 
/*  257 */         sql.append(" and resource_type=").append(resourceType);
/*      */ 
/*  259 */         this.log.info(sql);
/*  260 */         stmt.executeUpdate(sql.toString());
/*      */       }
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       String operatorIdString;
/*  264 */       this.log.error("Error deleting role rights. roleRightTable=" + getRoleRightTable() + ex.getMessage());
/*      */     } finally {
/*  266 */       if (stmt != null)
/*      */         try {
/*  268 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  272 */       if (con != null)
/*  273 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private int getRoleType(String roleId)
/*      */   {
/*  287 */     Sqlca sqlca = null;
/*      */     try {
/*  289 */       sqlca = new Sqlca(new ConnectionEx());
/*  290 */       String sql = "select role_type from user_role where role_id='" + roleId + "'";
/*      */ 
/*  292 */       this.log.debug("--sql:" + sql);
/*  293 */       sqlca.execute(sql);
/*  294 */       int roleType = -1;
/*  295 */       while (sqlca.next()) {
/*  296 */         roleType = sqlca.getInt("ROLE_TYPE");
/*      */       }
/*  298 */       return roleType;
/*      */     } catch (Exception e) {
/*  300 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.byRole") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRoleTypeFail") + "", e);
/*      */     }
/*      */     finally
/*      */     {
/*  307 */       if (sqlca != null)
/*  308 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public RoleRight getRoleRight(String roleId, int resourceType, String resourceId, String operationType)
/*      */   {
/*  315 */     Connection con = null;
/*  316 */     Statement stmt = null;
/*      */     try {
/*  318 */       con = getConnection();
/*  319 */       stmt = con.createStatement();
/*      */ 
/*  322 */       StringBuffer sb = new StringBuffer();
/*  323 */       sb.append("select resdef.").append(getIdField());
/*  324 */       sb.append(", resdef.").append(getDescField());
/*  325 */       sb.append(", resdef.").append(getParentFiled());
/*  326 */       sb.append(", rig.action_id");
/*  327 */       sb.append(", rig.operation_type");
/*  328 */       sb.append(", rig.operation_name");
/*  329 */       sb.append(", roleright.control_type");
/*  330 */       sb.append(" from ").append(getDefineTable()).append(" resdef,");
/*  331 */       sb.append(getRightTable()).append(" rig,").append(getRoleRightTable()).append(" roleright ");
/*      */ 
/*  333 */       sb.append(" where 1=1 ");
/*  334 */       sb.append(" and resdef.").append(getIdField()).append("=rig.resource_id");
/*      */ 
/*  336 */       sb.append(" and rig.action_id=roleright.action_id");
/*  337 */       sb.append(" and roleright.operator_id='").append(roleId).append("'");
/*      */ 
/*  339 */       sb.append(" and rig.resource_id='").append(resourceId).append("'");
/*  340 */       sb.append(" and rig.resource_type=").append(resourceType);
/*  341 */       sb.append(" and rig.operation_type='").append(operationType).append("'");
/*      */ 
/*  344 */       if (StringUtils.isNotBlank(getOrderSql())) {
/*  345 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/*  348 */       this.log.info(sb.toString());
/*      */ 
/*  350 */       ResultSet rs = stmt.executeQuery(sb.toString());
/*  351 */       RoleRight roleRight = new RoleRight();
/*  352 */       Right right = new Right();
/*  353 */       int roleType = getRoleTypeByResourceType(resourceType);
/*  354 */       while (rs.next()) {
/*  355 */         right.setRoleType(roleType);
/*  356 */         right.setResourceId(rs.getString(1));
/*  357 */         right.setResourceName(rs.getString(2));
/*  358 */         right.setParentId(rs.getString(3));
/*  359 */         right.setRightId(rs.getString(4));
/*  360 */         right.setOperationType(rs.getString(5));
/*  361 */         right.setOperationName(rs.getString(6));
/*  362 */         right.setResourceType(resourceType);
/*  363 */         right.setTopId(getTopLevelId());
/*      */ 
/*  365 */         roleRight.setRoleId(roleId);
/*  366 */         roleRight.setRight(right);
/*  367 */         roleRight.setControlType(rs.getString(7));
/*      */       }
/*      */ 
/*  370 */       rs.close();
/*  371 */       return roleRight;
/*      */     }
/*      */     catch (Exception ex) {
/*  374 */       ex.printStackTrace();
/*  375 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/*  377 */       if (stmt != null)
/*      */         try {
/*  379 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  383 */       if (con != null)
/*  384 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightListByRole(String roleId, int resourceType)
/*      */   {
/*  391 */     this.log.info("in getRoleRightListByRole............");
/*  392 */     Connection con = null;
/*  393 */     Statement stmt = null;
/*      */     try {
/*  395 */       if (StringUtils.isBlank(roleId)) {
/*  396 */         return new ArrayList();
/*      */       }
/*      */ 
/*  399 */       con = getConnection();
/*  400 */       stmt = con.createStatement();
/*      */ 
/*  403 */       StringBuffer sb = new StringBuffer();
/*  404 */       sb.append("select resdef.").append(getIdField());
/*  405 */       sb.append(", resdef.").append(getDescField());
/*  406 */       sb.append(", resdef.").append(getParentFiled());
/*  407 */       sb.append(", rig.action_id");
/*  408 */       sb.append(", rig.operation_type");
/*  409 */       sb.append(", rig.operation_name");
/*  410 */       sb.append(", roleright.control_type");
/*  411 */       sb.append(" from ").append(getDefineTable()).append(" resdef,");
/*  412 */       sb.append(getRightTable()).append(" rig,").append(getRoleRightTable()).append(" roleright ");
/*      */ 
/*  414 */       sb.append(" where 1=1 ");
/*  415 */       sb.append(" and resdef.").append(getIdField()).append("=rig.resource_id");
/*      */ 
/*  417 */       sb.append(" and rig.action_id=roleright.action_id");
/*  418 */       sb.append(" and roleright.operator_id='").append(roleId).append("'");
/*      */ 
/*  420 */       sb.append(" and rig.resource_type=").append(resourceType);
/*      */ 
/*  422 */       if (StringUtils.isNotBlank(getOrderSql())) {
/*  423 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/*  426 */       this.log.info(sb.toString());
/*      */ 
/*  428 */       rs = stmt.executeQuery(sb.toString());
/*      */ 
/*  430 */       List roleRightList = new ArrayList();
/*  431 */       int roleType = getRoleTypeByResourceType(resourceType);
/*      */       RoleRight roleRight;
/*  432 */       while (rs.next()) {
/*  433 */         roleRight = new RoleRight();
/*  434 */         Right right = new Right();
/*  435 */         right.setRoleType(roleType);
/*  436 */         right.setResourceId(rs.getString(1));
/*  437 */         right.setResourceName(rs.getString(2));
/*  438 */         right.setParentId(rs.getString(3));
/*  439 */         right.setRightId(rs.getString(4));
/*  440 */         right.setOperationType(rs.getString(5));
/*  441 */         right.setOperationName(rs.getString(6));
/*  442 */         right.setResourceType(resourceType);
/*  443 */         right.setTopId(getTopLevelId());
/*      */ 
/*  445 */         roleRight.setRoleId(roleId);
/*  446 */         roleRight.setRight(right);
/*  447 */         roleRight.setControlType(rs.getString(7));
/*      */ 
/*  449 */         roleRightList.add(roleRight);
/*      */       }
/*      */ 
/*  452 */       rs.close();
/*      */ 
/*  454 */       return roleRightList;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       ResultSet rs;
/*  456 */       this.log.debug(ex.getMessage());
/*  457 */       return new ArrayList();
/*      */     } finally {
/*  459 */       if (stmt != null)
/*      */         try {
/*  461 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  465 */       if (con != null)
/*  466 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightListByRight(Right currRight)
/*      */   {
/*  472 */     this.log.info("getRoleListByRight............");
/*  473 */     Connection con = null;
/*  474 */     Statement stmt = null;
/*      */     try {
/*  476 */       con = getConnection();
/*  477 */       stmt = con.createStatement();
/*      */ 
/*  479 */       StringBuffer sb = new StringBuffer();
/*  480 */       sb.append("select operator_id,control_type ");
/*  481 */       sb.append(" from ").append(getRoleRightTable());
/*  482 */       sb.append(" where 1=1");
/*  483 */       sb.append(" and action_id='").append(currRight.getRightId()).append("'");
/*      */ 
/*  487 */       this.log.info(sb.toString());
/*      */ 
/*  489 */       ResultSet rs = stmt.executeQuery(sb.toString());
/*      */ 
/*  491 */       List roleRightList = new ArrayList();
/*      */       RoleRight roleRight;
/*  492 */       while (rs.next()) {
/*  493 */         roleRight = new RoleRight();
/*  494 */         roleRight.setControlType(rs.getString(2));
/*  495 */         roleRight.setRight(currRight);
/*  496 */         roleRight.setRoleId(rs.getString(1));
/*      */ 
/*  498 */         roleRightList.add(roleRight);
/*      */       }
/*      */ 
/*  501 */       rs.close();
/*      */ 
/*  503 */       return roleRightList;
/*      */     } catch (Exception ex) {
/*  505 */       ex.printStackTrace();
/*  506 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/*  508 */       if (stmt != null)
/*      */         try {
/*  510 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  514 */       if (con != null)
/*  515 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<Right> getRightList(String roleId, int resourceType, boolean isDistinctControlType)
/*      */   {
/*  522 */     List roleIdList = new ArrayList();
/*  523 */     roleIdList.add(roleId);
/*  524 */     return getRightList(roleIdList, resourceType, isDistinctControlType);
/*      */   }
/*      */ 
/*      */   public List<Right> getRightList(List<String> roleIdList, int resourceType, boolean isDistinctControlType)
/*      */   {
/*  529 */     Connection con = null;
/*  530 */     Statement stmt = null;
/*      */     try {
/*  532 */       if ((roleIdList == null) || (roleIdList.isEmpty())) {
/*  533 */         return new ArrayList();
/*      */       }
/*      */ 
/*  536 */       con = getConnection();
/*  537 */       stmt = con.createStatement();
/*      */ 
/*  540 */       StringBuffer sb = new StringBuffer();
/*  541 */       sb.append("select resdef.").append(getIdField());
/*  542 */       sb.append(", resdef.").append(getDescField());
/*  543 */       sb.append(", resdef.").append(getParentFiled());
/*  544 */       sb.append(", rig.action_id");
/*  545 */       sb.append(", rig.operation_type");
/*  546 */       sb.append(", rig.operation_name");
/*  547 */       sb.append(", roleright.control_type");
/*  548 */       sb.append(" from ").append(getDefineTable()).append(" resdef,");
/*  549 */       sb.append(getRightTable()).append(" rig,").append(getRoleRightTable()).append(" roleright ");
/*      */ 
/*  551 */       sb.append(" where 1=1 ");
/*  552 */       if (isDistinctControlType) {
/*  553 */         sb.append(" and roleright.control_type='").append("1").append("'");
/*      */       }
/*      */ 
/*  556 */       sb.append(" and resdef.").append(getIdField()).append("=rig.resource_id");
/*      */ 
/*  558 */       sb.append(" and rig.action_id=roleright.action_id");
/*  559 */       sb.append(" and roleright.operator_id in(").append(StringUtil.list2String(roleIdList, ",", true)).append(")");
/*      */ 
/*  561 */       sb.append(" and roleright.resource_type=").append(resourceType);
/*      */ 
/*  563 */       if (StringUtils.isNotBlank(getOrderSql())) {
/*  564 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/*  567 */       this.log.info(sb.toString());
/*      */ 
/*  569 */       result = new ArrayList();
/*      */ 
/*  571 */       ResultSet rs = stmt.executeQuery(sb.toString());
/*  572 */       int roleType = getRoleTypeByResourceType(resourceType);
/*      */       Right rdBean;
/*  573 */       while (rs.next()) {
/*  574 */         rdBean = new Right();
/*  575 */         rdBean.setRoleType(roleType);
/*  576 */         rdBean.setResourceId(rs.getString(1));
/*  577 */         rdBean.setResourceName(rs.getString(2));
/*  578 */         rdBean.setParentId(rs.getString(3));
/*  579 */         rdBean.setRightId(rs.getString(4));
/*  580 */         rdBean.setOperationType(rs.getString(5));
/*  581 */         rdBean.setOperationName(rs.getString(6));
/*      */ 
/*  583 */         rdBean.setResourceType(resourceType);
/*  584 */         rdBean.setTopId(getTopLevelId());
/*      */ 
/*  586 */         if (!result.contains(rdBean))
/*      */         {
/*  590 */           result.add(rdBean);
/*      */         }
/*      */       }
/*  593 */       rs.close();
/*      */ 
/*  595 */       return result;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       List result;
/*  597 */       this.log.debug("getRightList:" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + ex.getMessage());
/*      */ 
/*  600 */       return new ArrayList();
/*      */     } finally {
/*  602 */       if (stmt != null)
/*      */         try {
/*  604 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  608 */       if (con != null)
/*  609 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(int roleType, int resourceType)
/*      */   {
/*  615 */     this.log.info("queryAllResourceDefineList............");
/*  616 */     List result = new ArrayList();
/*  617 */     Connection con = null;
/*  618 */     Statement stmt = null;
/*      */     try
/*      */     {
/*  621 */       con = getConnection();
/*      */ 
/*  623 */       stmt = con.createStatement();
/*      */ 
/*  626 */       StringBuffer sb = new StringBuffer();
/*  627 */       sb.append("select resdef.").append(getIdField());
/*  628 */       sb.append(", resdef.").append(getDescField());
/*  629 */       sb.append(", resdef.").append(getParentFiled());
/*  630 */       sb.append(", rig.action_id");
/*  631 */       sb.append(", rig.operation_type");
/*  632 */       sb.append(", rig.operation_name");
/*  633 */       sb.append(" from ").append(getDefineTable()).append(" resdef left outer join ").append(getRightTable()).append(" rig ");
/*      */ 
/*  636 */       sb.append(" on  resdef.").append(getIdField()).append("=rig.resource_id");
/*      */ 
/*  641 */       sb.append(" where 1=1 ");
/*  642 */       sb.append(" and resdef.resource_type=").append(resourceType);
/*      */ 
/*  644 */       if (StringUtils.isNotBlank(getOrderSql())) {
/*  645 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/*  648 */       this.log.info(sb.toString());
/*      */ 
/*  650 */       rs = stmt.executeQuery(sb.toString());
/*      */       Right rdBean;
/*  652 */       while (rs.next()) {
/*  653 */         rdBean = new Right();
/*  654 */         rdBean.setRoleType(roleType);
/*  655 */         rdBean.setResourceId(rs.getString(1));
/*  656 */         rdBean.setResourceName(rs.getString(2));
/*  657 */         rdBean.setParentId(rs.getString(3));
/*  658 */         rdBean.setRightId(rs.getString(4));
/*  659 */         rdBean.setOperationType(rs.getString(5));
/*  660 */         rdBean.setOperationName(rs.getString(6));
/*  661 */         rdBean.setResourceType(resourceType);
/*  662 */         rdBean.setTopId(getTopLevelId());
/*      */ 
/*  664 */         result.add(rdBean);
/*      */       }
/*      */ 
/*  667 */       rs.close();
/*      */ 
/*  669 */       return result;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       ResultSet rs;
/*  671 */       this.log.debug("getRoleRightListByRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*      */ 
/*  674 */       return new ArrayList();
/*      */     } finally {
/*  676 */       if (stmt != null)
/*      */         try {
/*  678 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*  682 */       if (con != null)
/*  683 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<String> getAllParentIds(String resourceId)
/*      */   {
/*  692 */     List allParnetIdList = new ArrayList();
/*      */ 
/*  694 */     getAllParentIds(allParnetIdList, resourceId);
/*      */ 
/*  696 */     return allParnetIdList;
/*      */   }
/*      */ 
/*      */   private List<String> getAllParentIds(List<String> allParnetIdList, String resourceId)
/*      */   {
/*  708 */     StringBuffer sql = new StringBuffer(128);
/*  709 */     sql.append("select ").append(getParentFiled()).append(" from ").append(getDefineTable());
/*      */ 
/*  711 */     sql.append(" where ").append(getIdField()).append("='").append(resourceId).append("'");
/*      */ 
/*  714 */     String parentId = (String)getJdbcTemplate().queryForObject(sql.toString(), String.class);
/*      */ 
/*  718 */     if ((StringUtils.isBlank(parentId)) || ("0".equals(parentId)) || ("-1".equals(parentId)) || ("-2".equals(parentId)))
/*      */     {
/*  720 */       return allParnetIdList;
/*      */     }
/*      */ 
/*  723 */     allParnetIdList.add(parentId);
/*      */ 
/*  725 */     getAllParentIds(allParnetIdList, parentId);
/*      */ 
/*  727 */     return allParnetIdList;
/*      */   }
/*      */ 
/*      */   public void updateControlType(String roleId, int resourceType, String resourceId, String controlType)
/*      */   {
/*  736 */     StringBuilder selectActionId = new StringBuilder(256);
/*  737 */     selectActionId.append("select rt.action_id from ").append(getRoleRightTable()).append(" rrt,");
/*      */ 
/*  739 */     selectActionId.append(getRightTable()).append(" rt");
/*  740 */     selectActionId.append(" where rrt.action_id=rt.action_id ");
/*  741 */     selectActionId.append(" and rt.resource_id='").append(resourceId).append("'");
/*      */ 
/*  744 */     StringBuffer sql = new StringBuffer(128);
/*  745 */     sql.append("update ").append(getRoleRightTable());
/*  746 */     sql.append(" set control_type='").append(controlType).append("'");
/*  747 */     sql.append(" where action_id in(").append(selectActionId).append(")");
/*  748 */     sql.append(" and resource_type=").append(resourceType);
/*  749 */     sql.append(" and operator_id='").append(roleId).append("'");
/*      */ 
/*  751 */     this.log.debug("updateControlType--sql:" + sql);
/*  752 */     getJdbcTemplate().execute(sql.toString());
/*      */   }
/*      */ 
/*      */   public String getRoleRightTable() {
/*  756 */     return this.roleRightTable;
/*      */   }
/*      */ 
/*      */   public void setRoleRightTable(String roleRightTable) {
/*  760 */     this.roleRightTable = roleRightTable;
/*      */   }
/*      */ 
/*      */   public String getRightTable() {
/*  764 */     return this.rightTable;
/*      */   }
/*      */ 
/*      */   public void setRightTable(String rightTable) {
/*  768 */     this.rightTable = rightTable;
/*      */   }
/*      */ 
/*      */   public String getDefineTable() {
/*  772 */     return this.defineTable;
/*      */   }
/*      */ 
/*      */   public void setDefineTable(String defineTable) {
/*  776 */     this.defineTable = defineTable;
/*      */   }
/*      */ 
/*      */   public String getIdField() {
/*  780 */     return this.idField;
/*      */   }
/*      */ 
/*      */   public void setIdField(String idField) {
/*  784 */     this.idField = idField;
/*      */   }
/*      */ 
/*      */   public String getDescField() {
/*  788 */     return this.descField;
/*      */   }
/*      */ 
/*      */   public void setDescField(String descField) {
/*  792 */     this.descField = descField;
/*      */   }
/*      */ 
/*      */   public String getParentFiled() {
/*  796 */     return this.parentFiled;
/*      */   }
/*      */ 
/*      */   public void setParentFiled(String parentFiled) {
/*  800 */     this.parentFiled = parentFiled;
/*      */   }
/*      */ 
/*      */   public String getSortField() {
/*  804 */     return this.sortField;
/*      */   }
/*      */ 
/*      */   public void setSortField(String sortField) {
/*  808 */     this.sortField = sortField;
/*      */   }
/*      */ 
/*      */   public String getOrderSql() {
/*  812 */     return this.orderSql;
/*      */   }
/*      */ 
/*      */   public void setOrderSql(String orderSql) {
/*  816 */     this.orderSql = orderSql;
/*      */   }
/*      */ 
/*      */   public String getTopLevelId() {
/*  820 */     return this.topLevelId;
/*      */   }
/*      */ 
/*      */   public void setTopLevelId(String topLevelId) {
/*  824 */     this.topLevelId = topLevelId;
/*      */   }
/*      */ 
/*      */   public String getCheckFrameField() {
/*  828 */     return this.checkFrameField;
/*      */   }
/*      */ 
/*      */   public void setCheckFrameField(String checkFrameField) {
/*  832 */     this.checkFrameField = checkFrameField;
/*      */   }
/*      */ 
/*      */   public String getCheckFrameValue() {
/*  836 */     return this.checkFrameValue;
/*      */   }
/*      */ 
/*      */   public void setCheckFrameValue(String checkFrameValue) {
/*  840 */     this.checkFrameValue = checkFrameValue;
/*      */   }
/*      */ 
/*      */   public boolean isIdVarchar() {
/*  844 */     return this.idVarchar;
/*      */   }
/*      */ 
/*      */   public void setIdVarchar(boolean idVarchar) {
/*  848 */     this.idVarchar = idVarchar;
/*      */   }
/*      */ 
/*      */   public String getIsAccessType() {
/*  852 */     return this.isAccessType;
/*      */   }
/*      */ 
/*      */   public void setIsAccessType(String isAccessType) {
/*  856 */     this.isAccessType = isAccessType;
/*      */   }
/*      */ 
/*      */   public String getAccessTypeField() {
/*  860 */     return this.accessTypeField;
/*      */   }
/*      */ 
/*      */   public void setAccessTypeField(String accessTypeField) {
/*  864 */     this.accessTypeField = accessTypeField;
/*      */   }
/*      */ 
/*      */   public String getResourceTypeField() {
/*  868 */     return this.resourceTypeField;
/*      */   }
/*      */ 
/*      */   public void setResourceTypeField(String resourceTypeField) {
/*  872 */     this.resourceTypeField = resourceTypeField;
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(String resourceName, int resourceType)
/*      */   {
/*  877 */     return null;
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRightList(String resourceName)
/*      */   {
/*  882 */     return null;
/*      */   }
/*      */ 
/*      */   public Right getRight(String resouceId)
/*      */   {
/*  887 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isExistRoleRight(String roleId, String resourceId, int resourceType, String OperationTyp)
/*      */   {
/*  893 */     return false;
/*      */   }
/*      */ 
/*      */   public List<Right> getUserRightList(String userId, int resourceType, int roleType, boolean isDistinctControlType)
/*      */   {
/*  902 */     this.log.debug(" in getUserRightList...");
/*      */ 
/*  904 */     Sqlca sqlca = null;
/*      */     try {
/*  906 */       sqlca = new Sqlca(new ConnectionEx());
/*      */ 
/*  908 */       List result = new ArrayList();
/*  909 */       rightSet = new HashSet();
/*      */ 
/*  911 */       StringBuffer sb = new StringBuffer();
/*  912 */       sb.append("select resdef.").append(getIdField()).append(" ID_FIELD");
/*  913 */       sb.append(", resdef.").append(getDescField()).append(" DESC_FIELD");
/*  914 */       if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled()))) {
/*  915 */         sb.append(", resdef.").append(getParentFiled()).append(" PARENT_FIELD");
/*      */       }
/*  917 */       sb.append(", rig.").append(getAccessTypeField()).append(" OPERATION_TYPE");
/*  918 */       sb.append(", opdef.operationname OPERATION_NAME");
/*  919 */       sb.append(", rig.controltype CONTROL_TYPE");
/*  920 */       sb.append(" from ").append(getDefineTable()).append(" resdef,").append(getRoleRightTable()).append(" rig, ");
/*  921 */       sb.append(" ").append("RESOURCE_OPERATION_DEFINE").append(" opdef ");
/*  922 */       sb.append(" where 1=1 ");
/*      */ 
/*  926 */       String accessTypeStr = sqlca.getSql_intTochar("rig." + getAccessTypeField());
/*      */ 
/*  928 */       String idField = getIdField();
/*  929 */       if (isDistinctControlType) {
/*  930 */         sb.append(" and rig.controltype='").append("1").append("'");
/*      */       }
/*  932 */       sb.append(" and ").append(idField).append("=rig.resourceid");
/*  933 */       sb.append(" and opdef.operationkey=").append(accessTypeStr);
/*  934 */       sb.append(" and opdef.resourcetype=").append(resourceType);
/*  935 */       sb.append(" and rig.operatorid in('").append(userId).append("')");
/*  936 */       sb.append(" and rig.resourcetype=").append(resourceType);
/*  937 */       sb.append(" and rig.operatortype=").append(1);
/*      */ 
/*  939 */       if (getDefineTable().equalsIgnoreCase("KPI_DEFINE")) {
/*  940 */         sb.append(" and resdef.status=0 ");
/*      */       }
/*  942 */       if (StringUtils.isNotBlank(getOrderSql())) {
/*  943 */         sb.append(" ").append(getOrderSql());
/*      */       }
/*      */ 
/*  946 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql:" + sb.toString());
/*  947 */       sqlca.execute(sb.toString());
/*  948 */       this.log.info("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuth") + "sql" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeOver") + "");
/*      */       Right right;
/*  950 */       while (sqlca.next()) {
/*  951 */         right = new Right();
/*  952 */         right.setRoleType(roleType);
/*  953 */         right.setResourceId(sqlca.getString("ID_FIELD"));
/*  954 */         right.setResourceName(sqlca.getString("DESC_FIELD"));
/*  955 */         if ((StringUtils.isNotBlank(getParentFiled())) && (!StringUtils.equals("0", getParentFiled())))
/*  956 */           right.setParentId(sqlca.getString("PARENT_FIELD"));
/*      */         else {
/*  958 */           right.setParentId("0");
/*      */         }
/*  960 */         right.setOperationType(String.valueOf(sqlca.getInt("OPERATION_TYPE")));
/*  961 */         right.setOperationName(sqlca.getString("OPERATION_NAME"));
/*  962 */         right.setResourceType(resourceType);
/*  963 */         right.setTopId(getTopLevelId());
/*      */ 
/*  965 */         if (!rightSet.contains(right)) {
/*  966 */           result.add(right);
/*  967 */           rightSet.add(right);
/*      */         }
/*      */       }
/*  970 */       this.log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAuthList") + ":" + result.size());
/*  971 */       this.log.debug(" end getRightList...");
/*  972 */       return result;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       Set rightSet;
/*  974 */       this.log.debug("getRightList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.Exception") + ex.getMessage());
/*      */ 
/*  977 */       return new ArrayList();
/*      */     } finally {
/*  979 */       if (sqlca != null)
/*  980 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteRight(String operatorId, int operatorType, int resourceType, String resourceId)
/*      */   {
/*  987 */     this.log.info("deleteRight begin ............");
/*  988 */     Connection con = null;
/*  989 */     Statement stmt = null;
/*      */     try {
/*  991 */       con = getConnection();
/*  992 */       stmt = con.createStatement();
/*      */ 
/*  994 */       StringBuffer sql = new StringBuffer(256);
/*  995 */       sql.append("delete from ").append(getRoleRightTable()).append(" where operator_id='").append(operatorId).append("'").append(" and operator_type=").append(operatorType).append(" and resource_type=").append(resourceType);
/*      */ 
/*  999 */       if (StringUtils.isNotBlank(resourceId)) {
/* 1000 */         sql.append(" and action_id='").append(resourceId).append("'");
/*      */       }
/* 1002 */       this.log.info(sql);
/* 1003 */       stmt.executeUpdate(sql.toString());
/*      */     } catch (Exception ex) {
/* 1005 */       throw new RuntimeException(ex.getMessage());
/*      */     } finally {
/* 1007 */       if (stmt != null) {
/*      */         try {
/* 1009 */           stmt.close();
/*      */         } catch (SQLException e) {
/* 1011 */           throw new RuntimeException(e.getMessage());
/*      */         }
/*      */       }
/* 1014 */       if (con != null) {
/* 1015 */         releaseConnection(con);
/*      */       }
/*      */     }
/* 1018 */     this.log.info("deleteRight end ............");
/*      */   }
/*      */ 
/*      */   public void initDaoParameter(int resourceType) {
/*      */     try {
/* 1023 */       String propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "roleRightTable");
/* 1024 */       if (StringUtils.isNotBlank(propValue)) {
/* 1025 */         this.roleRightTable = propValue;
/*      */       }
/* 1027 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "rightTable");
/* 1028 */       if (StringUtils.isNotBlank(propValue)) {
/* 1029 */         this.rightTable = propValue;
/*      */       }
/* 1031 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "defineTable");
/* 1032 */       if (StringUtils.isNotBlank(propValue)) {
/* 1033 */         this.defineTable = propValue;
/*      */       }
/* 1035 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "idField");
/* 1036 */       if (StringUtils.isNotBlank(propValue)) {
/* 1037 */         this.idField = propValue;
/*      */       }
/* 1039 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "descField");
/* 1040 */       if (StringUtils.isNotBlank(propValue)) {
/* 1041 */         this.descField = propValue;
/*      */       }
/* 1043 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "resourceTypeField");
/* 1044 */       if (StringUtils.isNotBlank(propValue)) {
/* 1045 */         this.resourceTypeField = propValue;
/*      */       }
/* 1047 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "accessTypeField");
/* 1048 */       if (StringUtils.isNotBlank(propValue))
/* 1049 */         this.accessTypeField = propValue;
/*      */       else {
/* 1051 */         this.accessTypeField = "ACCESSTYPE";
/*      */       }
/* 1053 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "parentFiled");
/* 1054 */       if (StringUtils.isNotBlank(propValue))
/* 1055 */         this.parentFiled = propValue;
/*      */       else {
/* 1057 */         this.parentFiled = "0";
/*      */       }
/* 1059 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "sortField");
/* 1060 */       if (StringUtils.isNotBlank(propValue))
/* 1061 */         this.sortField = propValue;
/*      */       else {
/* 1063 */         this.sortField = "";
/*      */       }
/* 1065 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "orderSql");
/* 1066 */       if (StringUtils.isNotBlank(propValue))
/* 1067 */         this.orderSql = propValue;
/*      */       else {
/* 1069 */         this.orderSql = "";
/*      */       }
/* 1071 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "topLevelId");
/* 1072 */       if (StringUtils.isNotBlank(propValue))
/* 1073 */         this.topLevelId = propValue;
/*      */       else {
/* 1075 */         this.topLevelId = "-1";
/*      */       }
/* 1077 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "checkFrameField");
/* 1078 */       if (StringUtils.isNotBlank(propValue))
/* 1079 */         this.checkFrameField = propValue;
/*      */       else {
/* 1081 */         this.checkFrameField = "";
/*      */       }
/* 1083 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "checkFrameValue");
/* 1084 */       if (StringUtils.isNotBlank(propValue))
/* 1085 */         this.checkFrameValue = propValue;
/*      */       else {
/* 1087 */         this.checkFrameValue = "";
/*      */       }
/* 1089 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "isAccessType");
/* 1090 */       if (StringUtils.isNotBlank(propValue))
/* 1091 */         this.isAccessType = propValue;
/*      */       else {
/* 1093 */         this.isAccessType = "0";
/*      */       }
/* 1095 */       propValue = SysResourceDsPropCache.getInstance().getPropValue(resourceType, "idVarchar");
/* 1096 */       if (StringUtils.isNotBlank(propValue))
/* 1097 */         this.idVarchar = new Boolean(propValue).booleanValue();
/*      */       else
/* 1099 */         this.idVarchar = true;
/*      */     }
/*      */     catch (Exception e) {
/* 1102 */       this.log.error("initDaoParameter" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.initResourceDsPropException") + "", e);
/* 1103 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.initResourceDsPropException"), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected int getRoleTypeByResourceType(int resourceType)
/*      */   {
/* 1115 */     SysResourceType srt = SysResourceTypeCache.getInstance().getSysResourceType(resourceType);
/*      */ 
/* 1117 */     if (null != srt) {
/* 1118 */       return srt.getRoleType();
/*      */     }
/* 1120 */     return -1;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.ResourceRightDaoJdbcImpl_UserOperationDefine
 * JD-Core Version:    0.6.2
 */
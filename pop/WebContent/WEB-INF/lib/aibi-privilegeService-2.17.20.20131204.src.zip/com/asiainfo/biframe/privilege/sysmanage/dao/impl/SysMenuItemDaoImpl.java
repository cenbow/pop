/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.model.SysMenuItem;
/*     */ import com.asiainfo.biframe.privilege.model.SysMenuItemRela;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.ISysMenuItemDao;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.SqlcaPst;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class SysMenuItemDaoImpl extends HibernateDaoSupport
/*     */   implements ISysMenuItemDao
/*     */ {
/*     */   public SysMenuItem findById(Integer menuItemId)
/*     */   {
/*  26 */     SysMenuItem smi = (SysMenuItem)getHibernateTemplate().get(SysMenuItem.class, menuItemId);
/*  27 */     if ((null != smi) && 
/*  28 */       (StringUtils.isNotBlank(smi.getUrl()))) {
/*  29 */       smi.setFolderOrNot(false);
/*     */     }
/*     */ 
/*  32 */     return smi;
/*     */   }
/*     */ 
/*     */   public List<SysMenuItem> findByResId(String resId) {
/*  36 */     List smiList = getHibernateTemplate().find("from SysMenuItem smi where smi.resId=?", resId);
/*  37 */     return smiList;
/*     */   }
/*     */ 
/*     */   public List<SysMenuItem> findByParentId(Integer parentId) {
/*  41 */     List smiList = getHibernateTemplate().find("from SysMenuItem smi where smi.parentId=? and (url is null or url='')", parentId);
/*  42 */     return smiList;
/*     */   }
/*     */ 
/*     */   public void deleteById(Integer menuItemId) {
/*  46 */     getHibernateTemplate().delete(findById(menuItemId));
/*     */   }
/*     */ 
/*     */   public void delete(SysMenuItem sysMenuItem) {
/*  50 */     getHibernateTemplate().delete(sysMenuItem);
/*     */   }
/*     */ 
/*     */   public Integer save(SysMenuItem sysMenuItem) {
/*  54 */     Integer menuItemId = null;
/*  55 */     if (null != sysMenuItem.getMenuItemId()) {
/*  56 */       getHibernateTemplate().save(sysMenuItem);
/*  57 */       menuItemId = sysMenuItem.getMenuItemId();
/*     */     } else {
/*  59 */       menuItemId = getMenuItemId();
/*  60 */       sysMenuItem.setMenuItemId(menuItemId);
/*  61 */       getHibernateTemplate().save(sysMenuItem);
/*     */     }
/*  63 */     return menuItemId;
/*     */   }
/*     */ 
/*     */   private Integer getMenuItemId() {
/*  67 */     return Integer.valueOf(Integer.parseInt(getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/*  70 */         String sql = "select max(MENUITEMID)+1 as MENUITEMID from SYS_MENU_ITEM";
/*  71 */         SQLQuery query = session.createSQLQuery(sql).addScalar("MENUITEMID", Hibernate.INTEGER);
/*  72 */         List list = query.list();
/*  73 */         Integer MENUITEMID = null;
/*  74 */         if ((list != null) && (list.size() > 0)) {
/*  75 */           MENUITEMID = Integer.valueOf(Integer.parseInt(list.get(0).toString()));
/*     */         }
/*  77 */         session.close();
/*  78 */         return MENUITEMID;
/*     */       }
/*     */     }).toString()));
/*     */   }
/*     */ 
/*     */   public void deleteAll(List<SysMenuItem> smiList)
/*     */   {
/*  84 */     getHibernateTemplate().deleteAll(smiList);
/*     */   }
/*     */ 
/*     */   public List<SysMenuItem> findByResId(String resId, Integer resType) {
/*  88 */     List smiList = getHibernateTemplate().find("from SysMenuItem smi where smi.resId=? and resType=?", new Object[] { resId, resType });
/*  89 */     return smiList;
/*     */   }
/*     */ 
/*     */   public void modify(SysMenuItem sysMenuItem) {
/*  93 */     getHibernateTemplate().update(sysMenuItem);
/*     */   }
/*     */ 
/*     */   public List<SysMenuItem> getMenuItemList(Map<String, String> menuItem) {
/*  97 */     SqlcaPst sqlcaPst = null;
/*  98 */     List smiList = new ArrayList();
/*     */     try {
/* 100 */       sqlcaPst = new SqlcaPst(new ConnectionEx());
/* 101 */       StringBuffer querySql = new StringBuffer();
/* 102 */       querySql.append(" select smi.MENUITEMID,smi.MENUITEMTITLE,smi.PARENTID,smi.SORTNUM, smi.URL,smi.RESID,smi.RESTYPE,");
/*     */ 
/* 104 */       querySql.append(" smi.ACCESSTOKEN,smi.RESOURCE_TYPE,smi.MENUTYPE, smi.APPLICATION_ID  from V_SYS_MENU_ITEM smi where 1=1 ");
/*     */ 
/* 106 */       if (null != menuItem) {
/* 107 */         if (StringUtils.isNotBlank((String)menuItem.get("menuItemId"))) {
/* 108 */           querySql.append(" and MENUITEMID = ? ");
/*     */         }
/* 110 */         if (StringUtils.isNotBlank((String)menuItem.get("menuItemTitle"))) {
/* 111 */           querySql.append(" and MENUITEMTITLE like ? ");
/*     */         }
/* 113 */         if (StringUtils.isNotBlank((String)menuItem.get("parentId"))) {
/* 114 */           querySql.append(" and PARENTID = ? ");
/*     */         }
/* 116 */         if (StringUtils.isNotBlank((String)menuItem.get("resType"))) {
/* 117 */           querySql.append(" and RESTYPE = ? ");
/*     */         }
/* 119 */         if (StringUtils.isNotBlank((String)menuItem.get("resId"))) {
/* 120 */           querySql.append(" and RESID = ? ");
/*     */         }
/* 122 */         if (StringUtils.isNotBlank((String)menuItem.get("applicationId"))) {
/* 123 */           querySql.append(" and APPLICATION_ID = ? ");
/*     */         }
/* 125 */         if (StringUtils.isNotBlank((String)menuItem.get("accessToken"))) {
/* 126 */           querySql.append(" and ACCESSTOKEN = ? ");
/*     */         }
/* 128 */         if (StringUtils.isNotBlank((String)menuItem.get("resourceType"))) {
/* 129 */           querySql.append(" and RESOURCE_TYPE = ? ");
/*     */         }
/* 131 */         if (StringUtils.isNotBlank((String)menuItem.get("menuType"))) {
/* 132 */           querySql.append(" and MENUTYPE = ? ");
/*     */         }
/*     */       }
/* 135 */       sqlcaPst.setSql(querySql.toString());
/* 136 */       if (null != menuItem) {
/* 137 */         int index = 0;
/* 138 */         if (StringUtils.isNotBlank((String)menuItem.get("menuItemId"))) {
/* 139 */           index += 1;
/* 140 */           sqlcaPst.setInteger(index, Integer.valueOf(Integer.parseInt((String)menuItem.get("menuItemId"))));
/*     */         }
/*     */ 
/* 143 */         if (StringUtils.isNotBlank((String)menuItem.get("menuItemTitle"))) {
/* 144 */           index += 1;
/* 145 */           sqlcaPst.setString(index, "%" + (String)menuItem.get("menuItemTitle") + "%");
/*     */         }
/*     */ 
/* 148 */         if (StringUtils.isNotBlank((String)menuItem.get("parentId"))) {
/* 149 */           index += 1;
/* 150 */           sqlcaPst.setInteger(index, Integer.valueOf(Integer.parseInt((String)menuItem.get("parentId"))));
/*     */         }
/*     */ 
/* 153 */         if (StringUtils.isNotBlank((String)menuItem.get("resType"))) {
/* 154 */           index += 1;
/* 155 */           sqlcaPst.setInteger(index, Integer.valueOf(Integer.parseInt((String)menuItem.get("resType"))));
/*     */         }
/*     */ 
/* 158 */         if (StringUtils.isNotBlank((String)menuItem.get("resId"))) {
/* 159 */           index += 1;
/* 160 */           sqlcaPst.setString(index, (String)menuItem.get("resId"));
/*     */         }
/* 162 */         if (StringUtils.isNotBlank((String)menuItem.get("applicationId"))) {
/* 163 */           index += 1;
/* 164 */           sqlcaPst.setString(index, (String)menuItem.get("applicationId"));
/*     */         }
/* 166 */         if (StringUtils.isNotBlank((String)menuItem.get("accessToken"))) {
/* 167 */           index += 1;
/* 168 */           sqlcaPst.setInteger(index, Integer.valueOf(Integer.parseInt((String)menuItem.get("accessToken"))));
/*     */         }
/*     */ 
/* 171 */         if (StringUtils.isNotBlank((String)menuItem.get("resourceType"))) {
/* 172 */           index += 1;
/* 173 */           sqlcaPst.setInteger(index, Integer.valueOf(Integer.parseInt((String)menuItem.get("resourceType"))));
/*     */         }
/*     */ 
/* 176 */         if (StringUtils.isNotBlank((String)menuItem.get("menuType"))) {
/* 177 */           sqlcaPst.setInteger(index, Integer.valueOf(Integer.parseInt((String)menuItem.get("menuType"))));
/*     */         }
/*     */       }
/*     */ 
/* 181 */       sqlcaPst.execute();
/* 182 */       while (sqlcaPst.next()) {
/* 183 */         SysMenuItem smi = new SysMenuItem();
/* 184 */         smi.setMenuItemId(sqlcaPst.getInteger("MENUITEMID"));
/* 185 */         smi.setMenuItemTitle(sqlcaPst.getString("MENUITEMTITLE"));
/* 186 */         smi.setParentId(sqlcaPst.getInteger("PARENTID"));
/* 187 */         smi.setSortNum(sqlcaPst.getInteger("SORTNUM"));
/* 188 */         smi.setUrl(sqlcaPst.getString("URL"));
/* 189 */         smi.setResId(sqlcaPst.getString("RESID"));
/* 190 */         smi.setResType(sqlcaPst.getInteger("RESTYPE"));
/* 191 */         smi.setAccessToken(sqlcaPst.getInteger("ACCESSTOKEN"));
/* 192 */         smi.setResourceType(sqlcaPst.getInteger("RESOURCE_TYPE"));
/* 193 */         smi.setMenuType(sqlcaPst.getInteger("MENUTYPE"));
/* 194 */         smi.setApplicationId(sqlcaPst.getString("APPLICATION_ID"));
/* 195 */         smiList.add(smi);
/*     */       }
/*     */ 
/* 200 */       if (null != sqlcaPst)
/* 201 */         sqlcaPst.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 198 */       throw new RuntimeException(e);
/*     */     } finally {
/* 200 */       if (null != sqlcaPst) {
/* 201 */         sqlcaPst.closeAll();
/*     */       }
/*     */     }
/* 204 */     return smiList;
/*     */   }
/*     */ 
/*     */   public void save(SysMenuItemRela smir) {
/* 208 */     getHibernateTemplate().save(smir);
/*     */   }
/*     */ 
/*     */   public void delSysMenuItemRela(Integer menuitemid) {
/* 212 */     List list = getHibernateTemplate().find("from SysMenuItemRela where menuitemId = ?", menuitemid);
/* 213 */     getHibernateTemplate().deleteAll(list);
/*     */   }
/*     */ 
/*     */   public void deleteMenuRela(SysMenuItemRela smir) {
/* 217 */     getHibernateTemplate().delete(smir);
/*     */   }
/*     */ 
/*     */   public List<SysMenuItemRela> getMenu(Integer menuitemid) {
/* 221 */     return getHibernateTemplate().find("from SysMenuItemRela where menuitemId = ?", menuitemid);
/*     */   }
/*     */ 
/*     */   public SysMenuItem getMenu(Integer menuitemid, Integer parentId) {
/* 225 */     List smiList = getHibernateTemplate().find("from SysMenuItem smi where smi.menuItemId = ? and smi.parentId = ?", new Integer[] { menuitemid, parentId });
/*     */ 
/* 228 */     if ((null != smiList) && (smiList.size() > 0)) {
/* 229 */       return (SysMenuItem)smiList.get(0);
/*     */     }
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */   public SysMenuItemRela getMenuRela(Integer menuitemid, Integer parentId) {
/* 235 */     List list = getHibernateTemplate().find("from SysMenuItemRela where menuitemId = ? and parentId = ?", new Integer[] { menuitemid, parentId });
/*     */ 
/* 238 */     if ((null != list) && (list.size() > 0)) {
/* 239 */       return (SysMenuItemRela)list.get(0);
/*     */     }
/* 241 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.SysMenuItemDaoImpl
 * JD-Core Version:    0.6.2
 */
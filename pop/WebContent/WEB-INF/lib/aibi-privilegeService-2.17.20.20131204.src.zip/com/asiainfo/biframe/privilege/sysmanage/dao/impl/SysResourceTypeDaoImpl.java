/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.DaoException;
/*    */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.ISysResourceTypeDAO;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class SysResourceTypeDaoImpl extends HibernateDaoSupport
/*    */   implements ISysResourceTypeDAO
/*    */ {
/* 26 */   private Log log = LogFactory.getLog(SysResourceTypeDaoImpl.class);
/*    */ 
/*    */   public SysResourceType findById(SysResourceType key) {
/* 29 */     return (SysResourceType)getHibernateTemplate().get(SysResourceType.class, key);
/*    */   }
/*    */ 
/*    */   public List<SysResourceType> findAll() {
/* 33 */     return getHibernateTemplate().find("from SysResourceType ");
/*    */   }
/*    */ 
/*    */   public String findResourceKey(int roleType, int resourceType) {
/* 37 */     List resKeyList = getHibernateTemplate().find("select resType.resourceKey from SysResourceType resType where resType.roleType=" + roleType + " and resType.resourceType=" + resourceType);
/*    */ 
/* 40 */     if (resKeyList.size() > 1) {
/* 41 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourceTypeIs") + "[" + resourceType + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.policyCountMoreThanOne") + "");
/*    */     }
/* 43 */     if (resKeyList.isEmpty()) {
/* 44 */       return "";
/*    */     }
/* 46 */     return (String)resKeyList.get(0);
/*    */   }
/*    */ 
/*    */   public SysResourceType findSysResType(int roleType, int resourceType) {
/* 50 */     List resKeyList = getHibernateTemplate().find("select resType from SysResourceType resType where resType.roleType = " + roleType + " and resType.resourceType=" + resourceType);
/*    */ 
/* 53 */     if (resKeyList.size() > 1) {
/* 54 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourceTypeIs") + "[" + resourceType + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.policyCountMoreThanOne") + "");
/*    */     }
/* 56 */     if (resKeyList.isEmpty()) {
/* 57 */       return null;
/*    */     }
/* 59 */     return (SysResourceType)resKeyList.get(0);
/*    */   }
/*    */ 
/*    */   public List<SysResourceType> findByResourceType(int resourceType) {
/* 63 */     List resTypeList = getHibernateTemplate().find("select resType from SysResourceType resType where  resType.resourceType=" + resourceType);
/*    */ 
/* 65 */     return resTypeList;
/*    */   }
/*    */ 
/*    */   public List<SysResourceType> getSysTypeListByName(String resourceTypeName) {
/* 69 */     List resTypeList = getHibernateTemplate().find("from SysResourceType resType where  resType.resourcetypeName='" + resourceTypeName + "'");
/*    */ 
/* 71 */     return resTypeList;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.SysResourceTypeDaoImpl
 * JD-Core Version:    0.6.2
 */
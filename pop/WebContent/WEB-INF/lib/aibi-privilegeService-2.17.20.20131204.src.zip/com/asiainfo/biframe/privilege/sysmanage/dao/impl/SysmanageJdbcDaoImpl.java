/*      */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.privilege.base.constants.PrivilegeCodes;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.ISysmanageJdbcDao;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.AiomniConnectionFactory;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*      */ 
/*      */ public class SysmanageJdbcDaoImpl extends JdbcDaoSupport
/*      */   implements ISysmanageJdbcDao
/*      */ {
/*   38 */   private static Log log = LogFactory.getLog(SysmanageJdbcDaoImpl.class);
/*      */ 
/*      */   public void deleteUserOtherMsg(String userId)
/*      */   {
/*   46 */     Connection con = null;
/*   47 */     Statement stmt = null;
/*      */     try {
/*   49 */       con = getConnection();
/*   50 */       stmt = con.createStatement();
/*      */ 
/*   52 */       String sql = "delete from mobile_user where userid='" + userId + "'";
/*      */ 
/*   54 */       stmt.addBatch(sql);
/*   55 */       sql = "delete from kpi_user_define where operatorid='" + userId + "' " + " and operatorType=" + "1";
/*      */ 
/*   58 */       stmt.addBatch(sql);
/*   59 */       sql = "delete from user_favor where userid='" + userId + "'";
/*   60 */       stmt.addBatch(sql);
/*      */ 
/*   62 */       stmt.executeBatch();
/*      */ 
/*   64 */       log.info(sql);
/*      */     }
/*      */     catch (Exception e) {
/*   67 */       log.error("", e);
/*   68 */       e.printStackTrace();
/*   69 */       throw new RuntimeException(e.getMessage());
/*      */     } finally {
/*   71 */       if (stmt != null)
/*      */         try {
/*   73 */           stmt.close();
/*      */         }
/*      */         catch (SQLException e) {
/*      */         }
/*   77 */       if (con != null)
/*   78 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getRptFileTree(String roleId, String strParentID, int nDeep, boolean bShow, boolean bOpen, String strPID, List roleIdList, String strLoginUserID, boolean bAdmin, String formatHtml)
/*      */   {
/*   89 */     Sqlca sqlca = null;
/*   90 */     Connection con = null;
/*      */     try {
/*   92 */       con = getConnection();
/*   93 */       sqlca = new Sqlca(con);
/*   94 */       HashMap selected = getRoleRightRptFiles(sqlca, roleId);
/*   95 */       HashMap select = getSelectRptFiles(sqlca, StringUtil.list2String(roleIdList, ",", true));
/*      */ 
/*   97 */       return getRptFileSection(sqlca, strParentID, nDeep, bShow, bOpen, strPID, selected, select, roleIdList, strLoginUserID, bAdmin, formatHtml);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  101 */       log.error("", e);
/*  102 */       e.printStackTrace();
/*  103 */       throw new RuntimeException(e.getMessage());
/*      */     } finally {
/*  105 */       if (null != sqlca) {
/*  106 */         sqlca.close();
/*      */       }
/*  108 */       if (null != con)
/*  109 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getRptFileSection(Sqlca sqlca, String strParentID, int nDeep, boolean bShow, boolean bOpen, String strPID, HashMap selected, HashMap select, List roleIdList, String strLoginUserID, boolean bAdmin, String formatHtml)
/*      */     throws Exception
/*      */   {
/*  135 */     String rightTableName = "user_rptfile_right";
/*      */ 
/*  139 */     String strDisplayTable = bShow ? "" : "style='display:none'";
/*      */ 
/*  141 */     StringBuffer ret = new StringBuffer();
/*  142 */     ret.append("<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='100%' id='TABLE_RPTFILE_");
/*      */ 
/*  144 */     if (nDeep == 0)
/*  145 */       ret.append("0");
/*      */     else {
/*  147 */       ret.append(strParentID);
/*      */     }
/*  149 */     ret.append("' ");
/*  150 */     ret.append(strDisplayTable);
/*  151 */     ret.append(">\r\n");
/*      */ 
/*  153 */     StringBuffer sqlBuf = new StringBuffer();
/*      */ 
/*  156 */     if (bAdmin) {
/*  157 */       sqlBuf.append("select rptNo,rptName,parentId,isRptFolder from rpt_define where parentid ='" + strParentID + "'");
/*      */     }
/*      */     else
/*      */     {
/*  161 */       String roleIds = StringUtil.list2String(roleIdList, ",", true);
/*  162 */       if (roleIds.length() < 1) {
/*  163 */         roleIds = "'-9999'";
/*      */       }
/*  165 */       sqlBuf.append(" select distinct t1.rptNo, t1.rptName, t1.parentId, t1.isRptFolder ");
/*      */ 
/*  167 */       sqlBuf.append(" from rpt_define t1, ");
/*  168 */       sqlBuf.append(rightTableName);
/*  169 */       sqlBuf.append(" t2 ");
/*  170 */       sqlBuf.append(" where t1.parentid = '" + strParentID + "'").append(" and t1.rptNo = t2.resourceid ").append(" and t2.resourcetype = 34").append(" and ( (t2.operatorid in (" + roleIds + ") and t2.operatorType=" + "0" + ") or \n").append(" (t2.operatorid = '" + strLoginUserID + "' and t2.operatorType=" + "1" + ") )");
/*      */     }
/*      */ 
/*  188 */     String sql = sqlBuf.toString();
/*      */ 
/*  190 */     sqlca.execute(sql);
/*      */ 
/*  193 */     List canViewIds = new ArrayList();
/*  194 */     List canUploadIds = new ArrayList();
/*  195 */     List canAuditIds = new ArrayList();
/*  196 */     List selectViewIds = new ArrayList();
/*  197 */     List selectUploadIds = new ArrayList();
/*  198 */     List selectAuditIds = new ArrayList();
/*  199 */     if (null != selected) {
/*  200 */       canViewIds = (ArrayList)selected.get("1");
/*      */ 
/*  202 */       canUploadIds = (ArrayList)selected.get("2");
/*      */ 
/*  204 */       canAuditIds = (ArrayList)selected.get("3");
/*      */     }
/*      */ 
/*  207 */     if (null != select) {
/*  208 */       selectViewIds = (ArrayList)select.get("1");
/*      */ 
/*  210 */       selectUploadIds = (ArrayList)select.get("2");
/*      */ 
/*  212 */       selectAuditIds = (ArrayList)select.get("3");
/*      */     }
/*      */ 
/*  215 */     boolean bFirst = true;
/*  216 */     List resultList = new ArrayList();
/*  217 */     while (sqlca.next()) {
/*  218 */       String strTopic = sqlca.getString("rptName");
/*  219 */       String strID = sqlca.getString("rptNo");
/*  220 */       int isRptFolder = sqlca.getInt("isRptFolder");
/*      */ 
/*  222 */       List beanList = new ArrayList();
/*  223 */       beanList.add(strTopic);
/*  224 */       beanList.add(strID);
/*  225 */       beanList.add(String.valueOf(isRptFolder));
/*      */ 
/*  227 */       resultList.add(beanList);
/*      */     }
/*      */ 
/*  230 */     for (int j = 0; j < resultList.size(); j++) {
/*  231 */       List beanList = (List)resultList.get(j);
/*  232 */       String strTopic = (String)beanList.get(0);
/*  233 */       String strID = (String)beanList.get(1);
/*  234 */       int isRptFolder = Integer.parseInt((String)beanList.get(2));
/*      */ 
/*  236 */       boolean bLast = false;
/*  237 */       if (j == resultList.size() - 1) {
/*  238 */         bLast = true;
/*      */       }
/*      */ 
/*  241 */       boolean bFolder = isRptFolder == 1;
/*      */       int strType;
/*      */       int strType;
/*  243 */       if (bFolder)
/*  244 */         strType = 0;
/*      */       else {
/*  246 */         strType = 5;
/*      */       }
/*  248 */       String strChkID = strID;
/*  249 */       if ((strPID != null) && (strPID.length() > 0)) {
/*  250 */         strChkID = strPID + "|" + strID;
/*      */       }
/*      */ 
/*  253 */       boolean bHaveSub = hasSubRptFileDefine(sqlca, strID);
/*      */ 
/*  255 */       ret.append("<tr>\r\n<td nowrap id='TD_RPTFILE_");
/*  256 */       ret.append(strID);
/*  257 */       ret.append("'>\r\n");
/*      */ 
/*  260 */       for (int i = 0; i < 2; i++) {
/*  261 */         ret.append("&nbsp;&nbsp;&nbsp;&nbsp;");
/*      */       }
/*      */ 
/*  264 */       ret.append(formatHtml);
/*  265 */       String _formatHtml = formatHtml + (bLast ? "<img src='/images/treeimg/empty.gif' ALIGN='texttop'>" : "<img src='/images/treeimg/line.gif' ALIGN='texttop'>");
/*      */ 
/*  270 */       if (bHaveSub) {
/*  271 */         String str = "1";
/*  272 */         if (bFirst) {
/*  273 */           str = "0";
/*      */         }
/*  275 */         strType = 0;
/*  276 */         if (bOpen) {
/*  277 */           if (!bLast) {
/*  278 */             ret.append("<img src='/images/treeimg/minus.gif' LASTM='0' ALIGN='texttop' name='IMG_RPTFILE_");
/*      */           }
/*      */           else {
/*  281 */             ret.append("<img src='/images/treeimg/minusbottom.gif' LASTM='1' ALIGN='texttop' name='IMG_RPTFILE_");
/*      */           }
/*      */ 
/*      */         }
/*  285 */         else if (!bLast) {
/*  286 */           ret.append("<img src='/images/treeimg/plus.gif' LASTM='0' ALIGN='texttop' name='IMG_RPTFILE_");
/*      */         }
/*      */         else {
/*  289 */           ret.append("<img src='/images/treeimg/plusbottom.gif' LASTM='1' ALIGN='texttop' name='IMG_RPTFILE_");
/*      */         }
/*      */ 
/*  293 */         ret.append(strID);
/*  294 */         ret.append("' onClick='showTable(this)' ");
/*  295 */         ret.append("ShowFlag=");
/*  296 */         ret.append(str);
/*  297 */         ret.append(" style='cursor:hand' title='" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.iconDisplay") + "/" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.hide") + "'>");
/*      */       }
/*  304 */       else if (!bLast) {
/*  305 */         ret.append("<img src='/images/treeimg/join.gif' ALIGN='texttop'>");
/*      */       }
/*      */       else {
/*  308 */         ret.append("<img src='/images/treeimg/joinbottom.gif' ALIGN='texttop'>");
/*      */       }
/*      */ 
/*  313 */       String strSel = "";
/*  314 */       String strRoleDisable = " disabled ";
/*  315 */       if ((selectViewIds != null) && (selectViewIds.contains(strID)) && (!bAdmin))
/*      */       {
/*  317 */         strRoleDisable = "";
/*      */       }
/*  319 */       if (bAdmin) {
/*  320 */         strRoleDisable = "";
/*      */       }
/*  322 */       if ((canViewIds != null) && (canViewIds.contains(strID))) {
/*  323 */         strSel = "checked";
/*      */       }
/*  325 */       ret.append("\r\n<input type='checkbox' style='height:14px' ALIGN='texttop' onClick='onClickChk(this,TD_RPTFILE_");
/*      */ 
/*  327 */       ret.append(strID);
/*  328 */       ret.append(")' name='");
/*  329 */       ret.append("viewIdList");
/*  330 */       ret.append("' value='");
/*  331 */       ret.append(strChkID);
/*  332 */       ret.append("' GTYPE=");
/*  333 */       ret.append(strType);
/*  334 */       ret.append(" ");
/*  335 */       ret.append(strSel);
/*  336 */       ret.append(" ");
/*  337 */       ret.append(strRoleDisable);
/*  338 */       ret.append(">");
/*  339 */       ret.append("<font size =2 title ='rptNo =");
/*  340 */       ret.append(strID);
/*  341 */       ret.append("'>");
/*  342 */       ret.append(strTopic);
/*  343 */       ret.append("</font>");
/*      */ 
/*  346 */       strSel = "";
/*  347 */       strRoleDisable = " disabled ";
/*  348 */       if ((selectUploadIds != null) && (selectUploadIds.contains(strID)) && (!bAdmin))
/*      */       {
/*  350 */         strRoleDisable = "";
/*      */       }
/*  352 */       if (bAdmin) {
/*  353 */         strRoleDisable = "";
/*      */       }
/*  355 */       if ((canUploadIds != null) && (canUploadIds.contains(strID))) {
/*  356 */         strSel = "checked";
/*      */       }
/*  358 */       ret.append("&nbsp;&nbsp;&nbsp;");
/*  359 */       ret.append("\r\n<input type='checkbox' style='height:14px' ALIGN='texttop' onClick='onClickChk(this,TD_RPTFILE_");
/*      */ 
/*  361 */       ret.append(strID);
/*      */ 
/*  365 */       ret.append(")' name='");
/*  366 */       ret.append("uploadIdList");
/*  367 */       ret.append("' value='");
/*  368 */       ret.append(strChkID);
/*  369 */       ret.append("' GTYPE=");
/*  370 */       ret.append(strType);
/*  371 */       ret.append(" ");
/*  372 */       ret.append(strSel);
/*  373 */       ret.append(" ");
/*  374 */       ret.append(strRoleDisable);
/*  375 */       ret.append(">");
/*  376 */       ret.append("<font size=2  color='#0000FF'>" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.uploadReport") + "</font>");
/*      */ 
/*  381 */       strSel = "";
/*  382 */       strRoleDisable = " disabled ";
/*  383 */       if ((selectAuditIds != null) && (selectAuditIds.contains(strID)) && (!bAdmin))
/*      */       {
/*  385 */         strRoleDisable = "";
/*      */       }
/*  387 */       if (bAdmin) {
/*  388 */         strRoleDisable = "";
/*      */       }
/*  390 */       if ((canAuditIds != null) && (canAuditIds.contains(strID))) {
/*  391 */         strSel = "checked";
/*      */       }
/*  393 */       ret.append("&nbsp;&nbsp;&nbsp;");
/*  394 */       ret.append("\r\n<input type='checkbox' style='height:14px' ALIGN='texttop' onClick='onClickChk(this,TD_RPTFILE_");
/*      */ 
/*  396 */       ret.append(strID);
/*      */ 
/*  400 */       ret.append(")' name='");
/*  401 */       ret.append("auditIdList");
/*  402 */       ret.append("' value='");
/*  403 */       ret.append(strChkID);
/*  404 */       ret.append("' GTYPE=");
/*  405 */       ret.append(strType);
/*  406 */       ret.append(" ");
/*  407 */       ret.append(strSel);
/*  408 */       ret.append(" ");
/*  409 */       ret.append(strRoleDisable);
/*  410 */       ret.append(">");
/*  411 */       ret.append("<font size=2  color='#0000FF'>" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.auditReport") + "</font>");
/*      */ 
/*  414 */       if (bHaveSub) {
/*  415 */         Sqlca sqlcaSub = null;
/*  416 */         boolean childShow = false;
/*  417 */         if ((bShow) && (bOpen))
/*  418 */           childShow = true;
/*      */         try
/*      */         {
/*  421 */           sqlcaSub = new Sqlca(sqlca.getConnection());
/*  422 */           ret.append(getRptFileSection(sqlcaSub, strID, nDeep + 1, childShow, bOpen, strChkID, selected, select, roleIdList, strLoginUserID, bAdmin, _formatHtml));
/*      */         }
/*      */         finally
/*      */         {
/*  426 */           if (sqlcaSub != null) {
/*  427 */             sqlcaSub.close();
/*      */           }
/*      */         }
/*      */       }
/*  431 */       ret.append("\r\n</td>\r\n</tr>\r\n");
/*  432 */       bFirst = false;
/*      */     }
/*  434 */     ret.append("</Table>\r\n");
/*  435 */     return ret.toString();
/*      */   }
/*      */ 
/*      */   private boolean hasSubRptFileDefine(Sqlca sqlcaSouce, String parentId)
/*      */     throws Exception
/*      */   {
/*  448 */     if ((parentId == null) || (parentId.length() < 1)) {
/*  449 */       return false;
/*      */     }
/*      */ 
/*  453 */     Sqlca sqlca = null;
/*      */     try {
/*  455 */       sqlca = new Sqlca(sqlcaSouce.getConnection());
/*  456 */       String strSql = "select rptNo from rpt_define where parentid = '" + parentId + "'";
/*      */ 
/*  458 */       sqlca.execute(strSql);
/*  459 */       return sqlca.next();
/*      */     } finally {
/*  461 */       if (sqlca != null)
/*  462 */         sqlca.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   private HashMap getRoleRightRptFiles(Sqlca sqlca, String roleId)
/*      */     throws Exception
/*      */   {
/*  479 */     StringBuffer buf = new StringBuffer();
/*  480 */     buf.append("select resourceid,accessType  from user_rptfile_right ");
/*  481 */     buf.append("where operatorid='");
/*  482 */     buf.append(roleId);
/*  483 */     buf.append("' and operatortype=");
/*  484 */     buf.append("0");
/*  485 */     buf.append(" and resourcetype=");
/*  486 */     buf.append("34");
/*  487 */     sqlca.execute(buf.toString());
/*      */ 
/*  489 */     List canViewIds = new ArrayList();
/*  490 */     List canUploadIds = new ArrayList();
/*  491 */     List canAuditIds = new ArrayList();
/*      */ 
/*  493 */     while (sqlca.next()) {
/*  494 */       String externResId = sqlca.getString("resourceid");
/*  495 */       String accessType = sqlca.getString("accessType");
/*      */ 
/*  497 */       if (accessType.equals("1"))
/*  498 */         canViewIds.add(externResId);
/*  499 */       else if (accessType.equals("2"))
/*      */       {
/*  501 */         canUploadIds.add(externResId);
/*  502 */       } else if (accessType.equals("3")) {
/*  503 */         canAuditIds.add(externResId);
/*      */       }
/*      */     }
/*  506 */     HashMap tmpMap = new HashMap();
/*  507 */     tmpMap.put("1", canViewIds);
/*  508 */     tmpMap.put("2", canUploadIds);
/*  509 */     tmpMap.put("3", canAuditIds);
/*  510 */     return tmpMap;
/*      */   }
/*      */ 
/*      */   private HashMap getSelectRptFiles(Sqlca sqlca, String roleIds)
/*      */     throws Exception
/*      */   {
/*  517 */     if (roleIds.length() < 1) {
/*  518 */       roleIds = "'-9999'";
/*      */     }
/*  520 */     StringBuffer buf = new StringBuffer();
/*  521 */     buf.append("select resourceid,accessType  from user_rptfile_right ");
/*  522 */     buf.append("where operatorid in(");
/*  523 */     buf.append(roleIds);
/*  524 */     buf.append(") and operatortype=");
/*  525 */     buf.append("0");
/*  526 */     buf.append(" and resourcetype=");
/*  527 */     buf.append("34");
/*  528 */     sqlca.execute(buf.toString());
/*      */ 
/*  530 */     List canViewIds = new ArrayList();
/*  531 */     List canUploadIds = new ArrayList();
/*  532 */     List canAuditIds = new ArrayList();
/*      */ 
/*  534 */     while (sqlca.next()) {
/*  535 */       String externResId = sqlca.getString("resourceid");
/*  536 */       String accessType = sqlca.getString("accessType");
/*      */ 
/*  538 */       if (accessType.equals("1"))
/*  539 */         canViewIds.add(externResId);
/*  540 */       else if (accessType.equals("2"))
/*      */       {
/*  542 */         canUploadIds.add(externResId);
/*  543 */       } else if (accessType.equals("3")) {
/*  544 */         canAuditIds.add(externResId);
/*      */       }
/*      */     }
/*  547 */     HashMap tmpMap = new HashMap();
/*  548 */     tmpMap.put("1", canViewIds);
/*  549 */     tmpMap.put("2", canUploadIds);
/*  550 */     tmpMap.put("3", canAuditIds);
/*  551 */     return tmpMap;
/*      */   }
/*      */ 
/*      */   public String getIrIndiTree(String roleId, String strParentID, int nDeep, boolean bShow, boolean bOpen, String strPID, List roleIdList, String strLoginUserID, boolean bAdmin, String formatHtml)
/*      */   {
/*  571 */     Sqlca sqlca = null;
/*  572 */     Connection con = null;
/*      */     try {
/*  574 */       con = getConnection();
/*  575 */       sqlca = new Sqlca(con);
/*  576 */       HashMap selected = getRoleRightIrIndis(sqlca, roleId);
/*  577 */       HashMap select = getSelectIrIndis(sqlca, StringUtil.list2String(roleIdList, ",", true));
/*      */ 
/*  579 */       return getIrIndiSection(sqlca, strParentID, nDeep, bShow, bOpen, strPID, selected, select, roleIdList, strLoginUserID, bAdmin, formatHtml);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  583 */       log.error("", e);
/*  584 */       e.printStackTrace();
/*  585 */       throw new RuntimeException(e.getMessage());
/*      */     } finally {
/*  587 */       if (null != sqlca) {
/*  588 */         sqlca.close();
/*      */       }
/*  590 */       if (null != con)
/*  591 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getIrIndiSection(Sqlca sqlca, String strParentID, int nDeep, boolean bShow, boolean bOpen, String strPID, HashMap selected, HashMap select, List roleIdList, String strLoginUserID, boolean bAdmin, String formatHtml)
/*      */     throws Exception
/*      */   {
/*  616 */     String rightTableName = "user_irindi_right";
/*      */ 
/*  618 */     String strDisplayTable = bShow ? "" : "style='display:none'";
/*      */ 
/*  620 */     StringBuffer ret = new StringBuffer();
/*  621 */     ret.append("<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='100%' id='TABLE_IRINDI_");
/*      */ 
/*  623 */     if (nDeep == 0)
/*  624 */       ret.append("0");
/*      */     else {
/*  626 */       ret.append(strParentID);
/*      */     }
/*  628 */     ret.append("' ");
/*  629 */     ret.append(strDisplayTable);
/*  630 */     ret.append(">\r\n");
/*      */ 
/*  632 */     StringBuffer sqlBuf = new StringBuffer();
/*  633 */     StringBuffer sqlBufAio = new StringBuffer();
/*  634 */     sqlBuf.append("select id_indi,name_indi,id_parent from ir_indi_view ");
/*  635 */     sqlBuf.append(" where id_parent ='" + strParentID + "'");
/*      */ 
/*  638 */     ArrayList indiRightList = new ArrayList();
/*  639 */     if (!bAdmin) {
/*  640 */       String roleIds = StringUtil.list2String(roleIdList, ",", true);
/*  641 */       if (roleIds.length() < 1) {
/*  642 */         roleIds = "'-9999'";
/*      */       }
/*  644 */       sqlBufAio.append("select t2.resourceid from ");
/*  645 */       sqlBufAio.append(rightTableName);
/*  646 */       sqlBufAio.append(" t2 ");
/*  647 */       sqlBufAio.append(" where t2.resourcetype=37");
/*      */ 
/*  649 */       sqlBufAio.append(" and t2.accesstype = " + PrivilegeCodes.INDI_ADMIN_RIGHT);
/*      */ 
/*  651 */       sqlBufAio.append(" and (t2.operatorid in (" + roleIds);
/*  652 */       sqlBufAio.append(") and t2.operatorType=0) \n");
/*      */ 
/*  655 */       String sql = sqlBufAio.toString();
/*      */ 
/*  657 */       sqlca.execute(sql);
/*  658 */       while (sqlca.next()) {
/*  659 */         String strID = sqlca.getString("resourid");
/*  660 */         indiRightList.add(strID);
/*      */       }
/*      */     }
/*      */ 
/*  664 */     String sql = sqlBuf.toString();
/*      */ 
/*  667 */     ArrayList indiList = new ArrayList();
/*      */ 
/*  670 */     String jdbcIndi = Configure.getInstance().getProperty("JDBC_INDI");
/*      */     Connection indi_con;
/*      */     Connection indi_con;
/*  673 */     if ((null == jdbcIndi) || (jdbcIndi.length() < 1))
/*      */     {
/*  675 */       indi_con = AiomniConnectionFactory.getInstance().getConnection();
/*      */     }
/*  677 */     else indi_con = AiomniConnectionFactory.getInstance(jdbcIndi).getConnection();
/*      */ 
/*  680 */     Statement st = null;
/*  681 */     ResultSet rs = null;
/*      */     try
/*      */     {
/*  684 */       st = indi_con.createStatement();
/*  685 */       rs = st.executeQuery(sql);
/*      */ 
/*  687 */       while (rs.next()) {
/*  688 */         String strTopic = rs.getString("name_indi");
/*  689 */         String strID = rs.getString("id_indi");
/*  690 */         boolean bHaveSub = false;
/*      */ 
/*  692 */         String[] result = new String[3];
/*  693 */         result[0] = strID;
/*  694 */         result[1] = strTopic;
/*  695 */         result[2] = String.valueOf(bHaveSub);
/*  696 */         indiList.add(result);
/*      */       }
/*  698 */       rs.close();
/*  699 */       st.close();
/*  700 */       st = indi_con.createStatement();
/*  701 */       for (int i = 0; i < indiList.size(); i++) {
/*  702 */         String[] result = (String[])indiList.get(i);
/*  703 */         String strID = result[0];
/*  704 */         boolean bHaveSub = Boolean.valueOf(result[2]).booleanValue();
/*  705 */         String strSql = "select id_indi from ir_indi_view where id_parent = '" + strID + "'";
/*      */ 
/*  707 */         rs = st.executeQuery(strSql);
/*  708 */         if (rs.next()) {
/*  709 */           bHaveSub = true;
/*      */         }
/*  711 */         if (bHaveSub) {
/*  712 */           result[2] = String.valueOf(bHaveSub);
/*  713 */           indiList.set(i, result);
/*      */         }
/*  715 */         rs.close();
/*      */       }
/*  717 */       st.close();
/*      */     }
/*      */     catch (Exception ex) {
/*  720 */       log.error(ex);
/*  721 */       ex.printStackTrace();
/*      */     } finally {
/*  723 */       if (rs != null) {
/*  724 */         rs.close();
/*      */       }
/*  726 */       if (st != null) {
/*  727 */         st.close();
/*      */       }
/*  729 */       if (indi_con != null) {
/*  730 */         indi_con.close();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  735 */     List canAdminIds = (ArrayList)selected.get(PrivilegeCodes.INDI_ADMIN_RIGHT);
/*      */ 
/*  737 */     List canViewIds = (ArrayList)selected.get(PrivilegeCodes.INDI_VIEW_RIGHT);
/*      */ 
/*  739 */     List selectAdminIds = (ArrayList)select.get(PrivilegeCodes.INDI_ADMIN_RIGHT);
/*      */ 
/*  741 */     List selectViewIds = (ArrayList)select.get(PrivilegeCodes.INDI_VIEW_RIGHT);
/*      */ 
/*  744 */     boolean bFirst = true;
/*      */ 
/*  746 */     for (int i = 0; i < indiList.size(); i++) {
/*  747 */       String[] result = (String[])indiList.get(i);
/*  748 */       String strID = result[0];
/*  749 */       String strTopic = result[1];
/*  750 */       boolean bHaveSub = Boolean.valueOf(result[2]).booleanValue();
/*  751 */       if ((bAdmin) || (indiRightList.contains(strID)))
/*      */       {
/*  755 */         boolean bLast = false;
/*  756 */         if (i == indiList.size() - 1) {
/*  757 */           bLast = true;
/*      */         }
/*      */ 
/*  761 */         String strChkID = strID;
/*  762 */         if ((strPID != null) && (strPID.length() > 0))
/*  763 */           strChkID = strPID + "|" + strID;
/*      */         int strType;
/*      */         int strType;
/*  766 */         if (bHaveSub)
/*  767 */           strType = 0;
/*      */         else {
/*  769 */           strType = 5;
/*      */         }
/*      */ 
/*  773 */         ret.append("<tr>\r\n<td nowrap id='TD_IR_");
/*  774 */         ret.append(strID);
/*  775 */         ret.append("'>\r\n");
/*      */ 
/*  778 */         for (int j = 0; j < 2; j++) {
/*  779 */           ret.append("&nbsp;&nbsp;&nbsp;&nbsp;");
/*      */         }
/*      */ 
/*  782 */         ret.append(formatHtml);
/*  783 */         String _formatHtml = formatHtml + (bLast ? "<img src='/images/treeimg/empty.gif' ALIGN='texttop'>" : "<img src='/images/treeimg/line.gif' ALIGN='texttop'>");
/*      */ 
/*  788 */         if (bHaveSub) {
/*  789 */           String str = "1";
/*  790 */           if (bFirst) {
/*  791 */             str = "0";
/*      */           }
/*  793 */           strType = 0;
/*  794 */           if (bOpen) {
/*  795 */             if (!bLast) {
/*  796 */               ret.append("<img src='/images/treeimg/minus.gif' LASTM='0' ALIGN='texttop' name='IMG_IRINDI_");
/*      */             }
/*      */             else {
/*  799 */               ret.append("<img src='/images/treeimg/minusbottom.gif' LASTM='1' ALIGN='texttop' name='IMG_IRINDI_");
/*      */             }
/*      */ 
/*      */           }
/*  803 */           else if (!bLast) {
/*  804 */             ret.append("<img src='/images/treeimg/plus.gif' LASTM='0' ALIGN='texttop' name='IMG_IRINDI_");
/*      */           }
/*      */           else {
/*  807 */             ret.append("<img src='/images/treeimg/plusbottom.gif' LASTM='1' ALIGN='texttop' name='IMG_IRINDI_");
/*      */           }
/*      */ 
/*  811 */           ret.append(strID);
/*  812 */           ret.append("' onClick='showTable(this)' ");
/*  813 */           ret.append("ShowFlag=");
/*  814 */           ret.append(str);
/*  815 */           ret.append(" style='cursor:hand' title='" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.iconDisplay") + "/" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.hide") + "'>");
/*      */         }
/*  822 */         else if (!bLast) {
/*  823 */           ret.append("<img src='/images/treeimg/join.gif' ALIGN='texttop'>");
/*      */         }
/*      */         else {
/*  826 */           ret.append("<img src='/images/treeimg/joinbottom.gif' ALIGN='texttop'>");
/*      */         }
/*      */ 
/*  832 */         String strSel = "";
/*  833 */         String strRoleDisable = " disabled ";
/*  834 */         if ((selectViewIds != null) && (selectViewIds.contains(strID)) && (!bAdmin))
/*      */         {
/*  836 */           strRoleDisable = "";
/*      */         }
/*  838 */         if (bAdmin) {
/*  839 */           strRoleDisable = "";
/*      */         }
/*  841 */         if ((canViewIds != null) && (canViewIds.contains(strID))) {
/*  842 */           strSel = "checked";
/*      */         }
/*      */ 
/*  845 */         ret.append("\r\n<input type='checkbox' style='height:14px' ALIGN='texttop' onClick='onClickChk(this,TD_IR_");
/*      */ 
/*  847 */         ret.append(strID);
/*      */ 
/*  851 */         ret.append(")' name='");
/*  852 */         ret.append("viewIdList");
/*  853 */         ret.append("' value='");
/*  854 */         ret.append(strChkID);
/*  855 */         ret.append("' GTYPE=");
/*  856 */         ret.append(strType);
/*  857 */         ret.append(" ");
/*  858 */         ret.append(strSel);
/*  859 */         ret.append(" ");
/*  860 */         ret.append(strRoleDisable);
/*  861 */         ret.append(">");
/*  862 */         ret.append("<font size =2 title ='id_indi =");
/*  863 */         ret.append(strID);
/*  864 */         ret.append("'>");
/*  865 */         ret.append(strTopic);
/*  866 */         ret.append("</font>");
/*      */ 
/*  869 */         strSel = "";
/*  870 */         strRoleDisable = " disabled ";
/*  871 */         if ((selectAdminIds != null) && (selectAdminIds.contains(strID)) && (!bAdmin))
/*      */         {
/*  873 */           strRoleDisable = "";
/*      */         }
/*  875 */         if (bAdmin) {
/*  876 */           strRoleDisable = "";
/*      */         }
/*  878 */         if ((canAdminIds != null) && (canAdminIds.contains(strID))) {
/*  879 */           strSel = "checked";
/*      */         }
/*  881 */         ret.append("&nbsp;&nbsp;&nbsp;");
/*      */ 
/*  883 */         ret.append("\r\n<input type='checkbox' style='height:14px' ALIGN='texttop' onClick='onClickChk(this,TD_IR_");
/*      */ 
/*  885 */         ret.append(strID);
/*      */ 
/*  889 */         ret.append(")' name='");
/*  890 */         ret.append("adminIdList");
/*  891 */         ret.append("' value='");
/*  892 */         ret.append(strChkID);
/*  893 */         ret.append("' GTYPE=");
/*  894 */         ret.append(strType);
/*  895 */         ret.append(" ");
/*  896 */         ret.append(strSel);
/*  897 */         ret.append(" ");
/*  898 */         ret.append(strRoleDisable);
/*  899 */         ret.append(">");
/*  900 */         ret.append("<font size=2  color='#0000FF'>" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.irindiMaintain") + "</font>");
/*      */ 
/*  903 */         if (bHaveSub) {
/*  904 */           boolean childShow = false;
/*  905 */           if ((bShow) && (bOpen)) {
/*  906 */             childShow = true;
/*      */           }
/*  908 */           ret.append(getSubIrIndiSection(strID, nDeep + 1, childShow, bOpen, strChkID, indiRightList, selected, select, roleIdList, strLoginUserID, bAdmin, _formatHtml));
/*      */         }
/*      */ 
/*  912 */         ret.append("\r\n</td>\r\n</tr>\r\n");
/*  913 */         bFirst = false;
/*      */       }
/*      */     }
/*  915 */     ret.append("</Table>\r\n");
/*  916 */     return ret.toString();
/*      */   }
/*      */ 
/*      */   private String getSubIrIndiSection(String strParentID, int nDeep, boolean bShow, boolean bOpen, String strPID, List limits, HashMap selected, HashMap select, List roleIdList, String strLoginUserID, boolean bAdmin, String formatHtml)
/*      */     throws Exception
/*      */   {
/*  925 */     String strDisplayTable = bShow ? "" : "style='display:none'";
/*      */ 
/*  927 */     StringBuffer ret = new StringBuffer();
/*  928 */     ret.append("<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='100%' id='TABLE_IRINDI_");
/*      */ 
/*  930 */     if (nDeep == 0)
/*  931 */       ret.append("0");
/*      */     else {
/*  933 */       ret.append(strParentID);
/*      */     }
/*  935 */     ret.append("' ");
/*  936 */     ret.append(strDisplayTable);
/*  937 */     ret.append(">\r\n");
/*      */ 
/*  939 */     StringBuffer sqlBuf = new StringBuffer();
/*  940 */     sqlBuf.append("select id_indi,name_indi,id_parent from ir_indi_view ");
/*  941 */     sqlBuf.append(" where id_parent ='" + strParentID + "'");
/*      */ 
/*  944 */     String sql = sqlBuf.toString();
/*      */ 
/*  948 */     ArrayList indiList = new ArrayList();
/*      */ 
/*  951 */     String jdbcIndi = Configure.getInstance().getProperty("JDBC_INDI");
/*      */     Connection indi_con;
/*      */     Connection indi_con;
/*  954 */     if ((null == jdbcIndi) || (jdbcIndi.length() < 1))
/*      */     {
/*  956 */       indi_con = AiomniConnectionFactory.getInstance().getConnection();
/*      */     }
/*  958 */     else indi_con = AiomniConnectionFactory.getInstance(jdbcIndi).getConnection();
/*      */ 
/*  961 */     Statement st = null;
/*  962 */     ResultSet rs = null;
/*      */     try
/*      */     {
/*  965 */       st = indi_con.createStatement();
/*  966 */       rs = st.executeQuery(sql);
/*      */ 
/*  968 */       while (rs.next()) {
/*  969 */         String strTopic = rs.getString("name_indi");
/*  970 */         String strID = rs.getString("id_indi");
/*  971 */         boolean bHaveSub = false;
/*      */ 
/*  973 */         String[] result = new String[3];
/*  974 */         result[0] = strID;
/*  975 */         result[1] = strTopic;
/*  976 */         result[2] = String.valueOf(bHaveSub);
/*  977 */         indiList.add(result);
/*      */       }
/*      */ 
/*  980 */       rs.close();
/*  981 */       st.close();
/*  982 */       st = indi_con.createStatement();
/*  983 */       for (int i = 0; i < indiList.size(); i++) {
/*  984 */         String[] result = (String[])indiList.get(i);
/*  985 */         String strID = result[0];
/*  986 */         boolean bHaveSub = Boolean.valueOf(result[2]).booleanValue();
/*  987 */         String strSql = "select id_indi from ir_indi_view where id_parent = '" + strID + "'";
/*      */ 
/*  989 */         rs = st.executeQuery(strSql);
/*  990 */         if (rs.next()) {
/*  991 */           bHaveSub = true;
/*      */         }
/*  993 */         if (bHaveSub) {
/*  994 */           result[2] = String.valueOf(bHaveSub);
/*  995 */           indiList.set(i, result);
/*      */         }
/*  997 */         rs.close();
/*      */       }
/*  999 */       st.close();
/*      */     }
/*      */     catch (Exception ex) {
/* 1002 */       log.error(ex);
/* 1003 */       ex.printStackTrace();
/*      */     } finally {
/* 1005 */       if (rs != null) {
/* 1006 */         rs.close();
/*      */       }
/* 1008 */       if (st != null) {
/* 1009 */         st.close();
/*      */       }
/* 1011 */       if (indi_con != null) {
/* 1012 */         indi_con.close();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1017 */     List canAdminIds = (ArrayList)selected.get(PrivilegeCodes.INDI_ADMIN_RIGHT);
/*      */ 
/* 1019 */     List canViewIds = (ArrayList)selected.get(PrivilegeCodes.INDI_VIEW_RIGHT);
/*      */ 
/* 1021 */     List selectAdminIds = (ArrayList)select.get(PrivilegeCodes.INDI_ADMIN_RIGHT);
/*      */ 
/* 1023 */     List selectViewIds = (ArrayList)select.get(PrivilegeCodes.INDI_VIEW_RIGHT);
/*      */ 
/* 1026 */     boolean bFirst = true;
/*      */ 
/* 1028 */     for (int i = 0; i < indiList.size(); i++) {
/* 1029 */       String[] result = (String[])indiList.get(i);
/* 1030 */       String strID = result[0];
/* 1031 */       String strTopic = result[1];
/* 1032 */       boolean bHaveSub = Boolean.valueOf(result[2]).booleanValue();
/* 1033 */       if ((bAdmin) || (limits.contains(strID)))
/*      */       {
/* 1037 */         boolean bLast = false;
/* 1038 */         if (i == indiList.size() - 1) {
/* 1039 */           bLast = true;
/*      */         }
/*      */ 
/* 1043 */         String strChkID = strID;
/* 1044 */         if ((strPID != null) && (strPID.length() > 0))
/* 1045 */           strChkID = strPID + "|" + strID;
/*      */         int strType;
/*      */         int strType;
/* 1048 */         if (bHaveSub)
/* 1049 */           strType = 0;
/*      */         else {
/* 1051 */           strType = 5;
/*      */         }
/*      */ 
/* 1055 */         ret.append("<tr>\r\n<td nowrap id='TD_IR_");
/* 1056 */         ret.append(strID);
/* 1057 */         ret.append("'>\r\n");
/* 1058 */         for (int j = 0; j < 2; j++) {
/* 1059 */           ret.append("&nbsp;&nbsp;&nbsp;&nbsp;");
/*      */         }
/*      */ 
/* 1062 */         ret.append(formatHtml);
/* 1063 */         String _formatHtml = formatHtml + (bLast ? "<img src='/images/treeimg/empty.gif' ALIGN='texttop'>" : "<img src='/images/treeimg/line.gif' ALIGN='texttop'>");
/*      */ 
/* 1068 */         if (bHaveSub) {
/* 1069 */           String str = "1";
/* 1070 */           if (bFirst) {
/* 1071 */             str = "0";
/*      */           }
/* 1073 */           strType = 0;
/* 1074 */           if (bOpen) {
/* 1075 */             if (!bLast) {
/* 1076 */               ret.append("<img src='/images/treeimg/minus.gif' LASTM='0' ALIGN='texttop' name='IMG_IRINDI_");
/*      */             }
/*      */             else {
/* 1079 */               ret.append("<img src='/images/treeimg/minusbottom.gif' LASTM='1' ALIGN='texttop' name='IMG_IRINDI_");
/*      */             }
/*      */ 
/*      */           }
/* 1083 */           else if (!bLast) {
/* 1084 */             ret.append("<img src='/images/treeimg/plus.gif' LASTM='0' ALIGN='texttop' name='IMG_IRINDI_");
/*      */           }
/*      */           else {
/* 1087 */             ret.append("<img src='/images/treeimg/plusbottom.gif' LASTM='1' ALIGN='texttop' name='IMG_IRINDI_");
/*      */           }
/*      */ 
/* 1091 */           ret.append(strID);
/* 1092 */           ret.append("' onClick='showTable(this)' ");
/* 1093 */           ret.append("ShowFlag=");
/* 1094 */           ret.append(str);
/* 1095 */           ret.append(" style='cursor:hand' title='" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.iconDisplay") + "/" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.hide") + "'>");
/*      */         }
/* 1102 */         else if (!bLast) {
/* 1103 */           ret.append("<img src='/images/treeimg/join.gif' ALIGN='texttop'>");
/*      */         }
/*      */         else {
/* 1106 */           ret.append("<img src='/images/treeimg/joinbottom.gif' ALIGN='texttop'>");
/*      */         }
/*      */ 
/* 1112 */         String strSel = "";
/* 1113 */         String strRoleDisable = " disabled ";
/* 1114 */         if ((selectViewIds != null) && (selectViewIds.contains(strID)) && (!bAdmin))
/*      */         {
/* 1116 */           strRoleDisable = "";
/*      */         }
/* 1118 */         if (bAdmin) {
/* 1119 */           strRoleDisable = "";
/*      */         }
/* 1121 */         if ((canViewIds != null) && (canViewIds.contains(strID))) {
/* 1122 */           strSel = "checked";
/*      */         }
/*      */ 
/* 1125 */         ret.append("\r\n<input type='checkbox' style='height:14px' ALIGN='texttop' onClick='onClickChk(this,TD_IR_");
/*      */ 
/* 1127 */         ret.append(strID);
/*      */ 
/* 1129 */         ret.append(")' name='");
/* 1130 */         ret.append("viewIdList");
/* 1131 */         ret.append("' value='");
/* 1132 */         ret.append(strChkID);
/* 1133 */         ret.append("' GTYPE=");
/* 1134 */         ret.append(strType);
/* 1135 */         ret.append(" ");
/* 1136 */         ret.append(strSel);
/* 1137 */         ret.append(" ");
/* 1138 */         ret.append(strRoleDisable);
/* 1139 */         ret.append(">");
/* 1140 */         ret.append("<font size =2 title ='id_indi =");
/* 1141 */         ret.append(strID);
/* 1142 */         ret.append("'>");
/* 1143 */         ret.append(strTopic);
/* 1144 */         ret.append("</font>");
/*      */ 
/* 1147 */         strSel = "";
/* 1148 */         strRoleDisable = " disabled ";
/* 1149 */         if ((selectAdminIds != null) && (selectAdminIds.contains(strID)) && (!bAdmin))
/*      */         {
/* 1151 */           strRoleDisable = "";
/*      */         }
/* 1153 */         if (bAdmin) {
/* 1154 */           strRoleDisable = "";
/*      */         }
/* 1156 */         if ((canAdminIds != null) && (canAdminIds.contains(strID))) {
/* 1157 */           strSel = "checked";
/*      */         }
/* 1159 */         ret.append("&nbsp;&nbsp;&nbsp;");
/*      */ 
/* 1161 */         ret.append("\r\n<input type='checkbox' style='height:14px' ALIGN='texttop' onClick='onClickChk(this,TD_IR_");
/*      */ 
/* 1163 */         ret.append(strID);
/*      */ 
/* 1165 */         ret.append(")' name='");
/* 1166 */         ret.append("adminIdList");
/* 1167 */         ret.append("' value='");
/* 1168 */         ret.append(strChkID);
/* 1169 */         ret.append("' GTYPE=");
/* 1170 */         ret.append(strType);
/* 1171 */         ret.append(" ");
/* 1172 */         ret.append(strSel);
/* 1173 */         ret.append(" ");
/* 1174 */         ret.append(strRoleDisable);
/* 1175 */         ret.append(">");
/* 1176 */         ret.append("<font size=2  color='#0000FF'>" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.irindiMaintain") + "</font>");
/*      */ 
/* 1180 */         if (bHaveSub) {
/* 1181 */           boolean childShow = false;
/* 1182 */           if ((bShow) && (bOpen)) {
/* 1183 */             childShow = true;
/*      */           }
/* 1185 */           ret.append(getSubIrIndiSection(strID, nDeep + 1, childShow, bOpen, strChkID, limits, selected, select, roleIdList, strLoginUserID, bAdmin, _formatHtml));
/*      */         }
/*      */ 
/* 1189 */         ret.append("\r\n</td>\r\n</tr>\r\n");
/* 1190 */         bFirst = false;
/*      */       }
/*      */     }
/* 1192 */     ret.append("</Table>\r\n");
/* 1193 */     return ret.toString();
/*      */   }
/*      */ 
/*      */   private HashMap getRoleRightIrIndis(Sqlca sqlca, String roleId)
/*      */     throws Exception
/*      */   {
/* 1208 */     StringBuffer buf = new StringBuffer();
/* 1209 */     buf.append("select resourceid,accessType  from user_irindi_right ");
/* 1210 */     buf.append("where operatorid='");
/* 1211 */     buf.append(roleId);
/* 1212 */     buf.append("' and operatortype=");
/* 1213 */     buf.append("0");
/* 1214 */     buf.append(" and resourcetype=");
/* 1215 */     buf.append("37");
/* 1216 */     sqlca.execute(buf.toString());
/* 1217 */     List canViewIds = new ArrayList();
/* 1218 */     List canAdminIds = new ArrayList();
/*      */ 
/* 1220 */     while (sqlca.next()) {
/* 1221 */       String externResId = sqlca.getString("resourceid");
/* 1222 */       String accessType = sqlca.getString("accessType");
/*      */ 
/* 1224 */       if (accessType.equals(PrivilegeCodes.INDI_VIEW_RIGHT))
/* 1225 */         canViewIds.add(externResId);
/* 1226 */       else if (accessType.equals(PrivilegeCodes.INDI_ADMIN_RIGHT)) {
/* 1227 */         canAdminIds.add(externResId);
/*      */       }
/*      */     }
/* 1230 */     HashMap tmpMap = new HashMap();
/* 1231 */     tmpMap.put(PrivilegeCodes.INDI_VIEW_RIGHT, canViewIds);
/* 1232 */     tmpMap.put(PrivilegeCodes.INDI_ADMIN_RIGHT, canAdminIds);
/* 1233 */     return tmpMap;
/*      */   }
/*      */ 
/*      */   private HashMap getSelectIrIndis(Sqlca sqlca, String roleIds)
/*      */     throws Exception
/*      */   {
/* 1240 */     if (roleIds.length() < 1) {
/* 1241 */       roleIds = "'-9999'";
/*      */     }
/* 1243 */     StringBuffer buf = new StringBuffer();
/* 1244 */     buf.append("select resourceid,accessType  from user_irindi_right ");
/* 1245 */     buf.append("where operatorid in(");
/* 1246 */     buf.append(roleIds);
/* 1247 */     buf.append(") and operatortype=");
/* 1248 */     buf.append("0");
/* 1249 */     buf.append(" and resourcetype=");
/* 1250 */     buf.append("37");
/* 1251 */     sqlca.execute(buf.toString());
/* 1252 */     List canViewIds = new ArrayList();
/* 1253 */     List canAdminIds = new ArrayList();
/*      */ 
/* 1255 */     while (sqlca.next()) {
/* 1256 */       String externResId = sqlca.getString("resourceid");
/* 1257 */       String accessType = sqlca.getString("accessType");
/*      */ 
/* 1259 */       if (accessType.equals(PrivilegeCodes.INDI_VIEW_RIGHT))
/* 1260 */         canViewIds.add(externResId);
/* 1261 */       else if (accessType.equals(PrivilegeCodes.INDI_ADMIN_RIGHT)) {
/* 1262 */         canAdminIds.add(externResId);
/*      */       }
/*      */     }
/* 1265 */     HashMap tmpMap = new HashMap();
/* 1266 */     tmpMap.put(PrivilegeCodes.INDI_VIEW_RIGHT, canViewIds);
/* 1267 */     tmpMap.put(PrivilegeCodes.INDI_ADMIN_RIGHT, canAdminIds);
/* 1268 */     return tmpMap;
/*      */   }
/*      */ 
/*      */   public void saveRptFileRight(String roleId, List roleIdList, List viewIdList, List uploadIdList, List auditIdList)
/*      */   {
/* 1282 */     Sqlca sqlca = null;
/* 1283 */     Sqlca sqlcaInsert = null;
/* 1284 */     String rightTable = "user_rptfile_right";
/* 1285 */     Connection con = null;
/*      */     try {
/* 1287 */       con = getConnection();
/* 1288 */       sqlca = new Sqlca(con);
/*      */ 
/* 1291 */       HashMap rptFileRight = getRoleRightRptFiles(sqlca, roleId);
/* 1292 */       List canViewIds = new ArrayList();
/* 1293 */       List canUploadIds = new ArrayList();
/* 1294 */       List canAuditIds = new ArrayList();
/* 1295 */       if (null != rptFileRight) {
/* 1296 */         canViewIds = (ArrayList)rptFileRight.get("1");
/*      */ 
/* 1298 */         canUploadIds = (ArrayList)rptFileRight.get("2");
/*      */ 
/* 1300 */         canAuditIds = (ArrayList)rptFileRight.get("3");
/*      */       }
/*      */ 
/* 1304 */       canViewIds.removeAll(viewIdList);
/* 1305 */       canUploadIds.removeAll(uploadIdList);
/* 1306 */       canAuditIds.removeAll(auditIdList);
/*      */ 
/* 1308 */       String deleteSql = "";
/* 1309 */       if ((null != roleIdList) && (roleIdList.size() > 0)) {
/* 1310 */         String subRoleIds = StringUtil.list2String(roleIdList, ",", true);
/*      */ 
/* 1312 */         if ((null != canViewIds) && (canViewIds.size() > 0)) {
/* 1313 */           String deleteViewIds = StringUtil.list2String(canViewIds, ",", true);
/*      */ 
/* 1315 */           deleteSql = "delete from " + rightTable + " where operatorid in (" + subRoleIds + ")" + " and operatortype = " + "0" + " and resourceType= " + "34" + " and resourceId in(" + deleteViewIds + ")" + " and accessType=" + "1";
/*      */ 
/* 1324 */           sqlca.execute(deleteSql);
/*      */         }
/* 1326 */         if ((null != canUploadIds) && (canUploadIds.size() > 0)) {
/* 1327 */           String deleteUploadIds = StringUtil.list2String(canUploadIds, ",", true);
/*      */ 
/* 1329 */           deleteSql = "delete from " + rightTable + " where operatorid in (" + subRoleIds + ")" + " and operatortype = " + "0" + " and resourceType= " + "34" + " and resourceId in(" + deleteUploadIds + ")" + " and accessType=" + "2";
/*      */ 
/* 1338 */           sqlca.execute(deleteSql);
/*      */         }
/* 1340 */         if ((null != canAuditIds) && (canAuditIds.size() > 0)) {
/* 1341 */           String deleteAuditIds = StringUtil.list2String(canAuditIds, ",", true);
/*      */ 
/* 1343 */           deleteSql = "delete from " + rightTable + " where operatorid in (" + subRoleIds + ")" + " and operatortype = " + "0" + " and resourceType= " + "34" + " and resourceId in(" + deleteAuditIds + ")" + " and accessType=" + "3";
/*      */ 
/* 1352 */           sqlca.execute(deleteSql);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1357 */       String sql = "delete from " + rightTable + " where operatorid='" + roleId + "' " + " and operatortype =" + "0" + " and resourceType=" + "34";
/*      */ 
/* 1362 */       sqlca.execute(sql);
/*      */ 
/* 1365 */       String strSql = "";
/* 1366 */       sqlcaInsert = new Sqlca(sqlca.getConnection());
/* 1367 */       if ((null != viewIdList) && (viewIdList.size() > 0)) {
/* 1368 */         String strAllR = StringUtil.list2String(viewIdList, ",", true);
/* 1369 */         sqlca.execute("select rptNo from rpt_define where rptNo in(" + strAllR + ")");
/*      */ 
/* 1371 */         while (sqlca.next()) {
/* 1372 */           strSql = "insert into user_rptfile_right(operatorid,operatortype,resourcetype,resourceid,accessType) values('" + roleId + "',0," + "34" + ",'" + sqlca.getString("rptNo") + "'," + "1" + ")";
/*      */ 
/* 1382 */           sqlcaInsert.execute(strSql);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1387 */       if ((null != uploadIdList) && (uploadIdList.size() > 0)) {
/* 1388 */         String strAllR2 = StringUtil.list2String(uploadIdList, ",", true);
/*      */ 
/* 1390 */         sqlca.execute("select rptNo from rpt_define where rptNo in(" + strAllR2 + ")");
/*      */ 
/* 1392 */         while (sqlca.next()) {
/* 1393 */           strSql = "insert into user_rptfile_right(operatorid,operatortype,resourcetype,resourceid,accessType) values('" + roleId + "',0," + "34" + ",'" + sqlca.getString("rptNo") + "'," + "2" + ")";
/*      */ 
/* 1403 */           sqlcaInsert.execute(strSql);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1408 */       if ((null != auditIdList) && (auditIdList.size() > 0)) {
/* 1409 */         String strAllR3 = StringUtil.list2String(auditIdList, ",", true);
/*      */ 
/* 1411 */         sqlca.execute("select rptNo from rpt_define where rptNo in(" + strAllR3 + ")");
/*      */ 
/* 1413 */         while (sqlca.next()) {
/* 1414 */           strSql = "insert into user_rptfile_right(operatorid,operatortype,resourcetype,resourceid,accessType) values('" + roleId + "',0," + "34" + ",'" + sqlca.getString("rptNo") + "'," + "3" + ")";
/*      */ 
/* 1424 */           sqlcaInsert.execute(strSql);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1433 */       if (null != sqlca) {
/* 1434 */         sqlca.close();
/*      */       }
/* 1436 */       if (null != sqlcaInsert) {
/* 1437 */         sqlcaInsert.close();
/*      */       }
/* 1439 */       if (null != con)
/* 1440 */         releaseConnection(con);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1429 */       log.error("", e);
/* 1430 */       e.printStackTrace();
/* 1431 */       throw new RuntimeException(e.getMessage());
/*      */     } finally {
/* 1433 */       if (null != sqlca) {
/* 1434 */         sqlca.close();
/*      */       }
/* 1436 */       if (null != sqlcaInsert) {
/* 1437 */         sqlcaInsert.close();
/*      */       }
/* 1439 */       if (null != con)
/* 1440 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveIndiRight(String roleId, List<String> roleIdList, List<Right> viewIdList, List<Right> adminIdList)
/*      */   {
/* 1455 */     Sqlca sqlca = null;
/* 1456 */     Sqlca sqlcaInsert = null;
/* 1457 */     String rightTable = "user_irindi_right";
/* 1458 */     Connection con = null;
/*      */     try {
/* 1460 */       con = getConnection();
/* 1461 */       sqlca = new Sqlca(con);
/*      */ 
/* 1464 */       HashMap indiRight = getRoleRightIrIndis(sqlca, roleId);
/* 1465 */       List canViewIds = new ArrayList();
/* 1466 */       List canAdminIds = new ArrayList();
/* 1467 */       if (null != indiRight) {
/* 1468 */         canViewIds = (ArrayList)indiRight.get(PrivilegeCodes.INDI_VIEW_RIGHT);
/*      */ 
/* 1470 */         canAdminIds = (ArrayList)indiRight.get(PrivilegeCodes.INDI_ADMIN_RIGHT);
/*      */       }
/*      */ 
/* 1474 */       canViewIds.removeAll(viewIdList);
/* 1475 */       canAdminIds.removeAll(adminIdList);
/*      */ 
/* 1477 */       String deleteSql = "";
/* 1478 */       if ((null != roleIdList) && (roleIdList.size() > 0)) {
/* 1479 */         String subRoleIds = StringUtil.list2String(roleIdList, ",", true);
/*      */ 
/* 1481 */         if ((null != canViewIds) && (canViewIds.size() > 0)) {
/* 1482 */           String deleteViewIds = StringUtil.list2String(canViewIds, ",", true);
/*      */ 
/* 1484 */           deleteSql = "delete from " + rightTable + " where operatorid in (" + subRoleIds + ")" + " and operatortype = " + "0" + " and resourceType= " + "37" + " and resourceId in(" + deleteViewIds + ")" + " and accessType=" + PrivilegeCodes.INDI_VIEW_RIGHT;
/*      */ 
/* 1493 */           sqlca.execute(deleteSql);
/*      */         }
/* 1495 */         if ((null != canAdminIds) && (canAdminIds.size() > 0)) {
/* 1496 */           String deleteAdminIds = StringUtil.list2String(canAdminIds, ",", true);
/*      */ 
/* 1498 */           deleteSql = "delete from " + rightTable + " where operatorid in (" + subRoleIds + ")" + " and operatortype = " + "0" + " and resourceType= " + "37" + " and resourceId in(" + deleteAdminIds + ")" + " and accessType=" + PrivilegeCodes.INDI_ADMIN_RIGHT;
/*      */ 
/* 1507 */           sqlca.execute(deleteSql);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1512 */       String sql = "delete from " + rightTable + " where operatorid='" + roleId + "' " + " and operatortype =" + "0" + " and resourceType=" + "37";
/*      */ 
/* 1516 */       sqlca.execute(sql);
/*      */ 
/* 1519 */       String strSql = "";
/* 1520 */       sqlcaInsert = new Sqlca(sqlca.getConnection());
/* 1521 */       if ((null != viewIdList) && (viewIdList.size() > 0)) {
/* 1522 */         for (int i = 0; i < viewIdList.size(); i++) {
/* 1523 */           strSql = "insert into user_irindi_right(operatorid,operatortype,resourcetype,resourceid,accessType) values('" + roleId + "',0," + "37" + ",'" + viewIdList.get(i) + "'," + PrivilegeCodes.INDI_VIEW_RIGHT + ")";
/*      */ 
/* 1532 */           sqlcaInsert.addBatch(strSql);
/*      */         }
/* 1534 */         sqlcaInsert.executeBatch();
/*      */       }
/*      */ 
/* 1537 */       if ((null != adminIdList) && (adminIdList.size() > 0)) {
/* 1538 */         for (int i = 0; i < adminIdList.size(); i++) {
/* 1539 */           strSql = "insert into user_irindi_right(operatorid,operatortype,resourcetype,resourceid,accessType) values('" + roleId + "',0," + "37" + ",'" + adminIdList.get(i) + "'," + PrivilegeCodes.INDI_ADMIN_RIGHT + ")";
/*      */ 
/* 1548 */           sqlcaInsert.addBatch(strSql);
/*      */         }
/* 1550 */         sqlcaInsert.executeBatch();
/*      */       }
/*      */ 
/* 1558 */       if (null != sqlcaInsert) {
/* 1559 */         sqlcaInsert.close();
/*      */       }
/* 1561 */       if (null != sqlca)
/*      */       {
/* 1563 */         sqlca.closeAll();
/*      */       }
/* 1565 */       if (null != con)
/* 1566 */         releaseConnection(con);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1554 */       log.error("", e);
/* 1555 */       e.printStackTrace();
/* 1556 */       throw new RuntimeException(e.getMessage());
/*      */     } finally {
/* 1558 */       if (null != sqlcaInsert) {
/* 1559 */         sqlcaInsert.close();
/*      */       }
/* 1561 */       if (null != sqlca)
/*      */       {
/* 1563 */         sqlca.closeAll();
/*      */       }
/* 1565 */       if (null != con)
/* 1566 */         releaseConnection(con);
/*      */     }
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.SysmanageJdbcDaoImpl
 * JD-Core Version:    0.6.2
 */
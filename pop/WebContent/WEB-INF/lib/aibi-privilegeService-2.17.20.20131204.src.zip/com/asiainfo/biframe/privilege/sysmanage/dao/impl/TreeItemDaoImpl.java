/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.menu.TreeItem;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.ITreeItemDao;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.springframework.jdbc.core.JdbcTemplate;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*    */ 
/*    */ public class TreeItemDaoImpl extends JdbcDaoSupport
/*    */   implements ITreeItemDao
/*    */ {
/*    */   public List<TreeItem> getTopSysMenuItems()
/*    */   {
/* 41 */     String sql = "select s.menuitemid,s.menuitemtitle,s.parentid,s.url,t.childnum,s.sortnum  from sys_menu_item s left join (select distinct parentid,count(menuitemid) childnum from sys_menu_item group by parentid) t on s.menuitemid=t.parentid where s.parentid=0 order by s.sortnum asc";
/* 42 */     return super.getJdbcTemplate().query(sql, new SysMenuItemMapper());
/*    */   }
/*    */ 
/*    */   public List<TreeItem> getAllSysMenuItems(String keyword)
/*    */   {
/* 49 */     String sql = "select s.menuitemid, s.menuitemtitle, s.parentid, s.url, t.childnum, s.sortnum  from sys_menu_item s left join (select distinct parentid, count(menuitemid)  childnum from sys_menu_item group by parentid) t on s.menuitemid = t.parentid  where s.menuitemtitle like '%" + keyword + "%' order by s.sortnum asc ";
/* 50 */     if (null == keyword) {
/* 51 */       sql = "select s.menuitemid, s.menuitemtitle, s.parentid, s.url, t.childnum, s.sortnum  from sys_menu_item s left join (select distinct parentid, count(menuitemid)  childnum from sys_menu_item group by parentid) t on s.menuitemid = t.parentid order by s.sortnum asc ";
/*    */     }
/* 53 */     return super.getJdbcTemplate().query(sql, new SysMenuItemMapper());
/*    */   }
/*    */ 
/*    */   public List<TreeItem> getSubSysMenuItems(Integer menuId, String keyword)
/*    */   {
/* 64 */     String sql = "select s.menuitemid,s.menuitemtitle,s.parentid,s.url,t.childnum,s.sortnum  from sys_menu_item s left join (select distinct parentid,count(menuitemid) childnum from sys_menu_item group by parentid) t on s.menuitemid=t.parentid where s.parentid=? order by s.sortnum asc";
/* 65 */     Object[] params = { menuId };
/* 66 */     if ((keyword != null) && (keyword.length() > 0)) {
/* 67 */       sql = "select s.menuitemid,s.menuitemtitle,s.parentid,s.url,t.childnum,s.sortnum  from sys_menu_item s left join (select distinct parentid,count(menuitemid) childnum from sys_menu_item group by parentid) t on s.menuitemid=t.parentid where s.parentid=? and s.menuitemtitle like '%?%' order by s.sortnum asc";
/* 68 */       params = new Object[] { menuId, keyword };
/*    */     }
/* 70 */     return super.getJdbcTemplate().query(sql, params, new SysMenuItemMapper());
/*    */   }
/*    */ 
/*    */   public TreeItem getMenuById(Integer menuId)
/*    */   {
/* 78 */     String sql = "select s.menuitemid,s.menuitemtitle,s.parentid,s.url,s.sortnum childnum from sys_menu_item s where menuitemid=" + menuId;
/* 79 */     return (TreeItem)super.getJdbcTemplate().queryForObject(sql, new SysMenuItemMapper());
/*    */   }
/*    */   class SysMenuItemMapper implements RowMapper {
/*    */     SysMenuItemMapper() {
/*    */     }
/* 84 */     public Object mapRow(ResultSet rs, int arg1) throws SQLException { TreeItem menu = new TreeItem();
/* 85 */       menu.setMenuItemId(Integer.valueOf(rs.getInt("menuitemid")));
/* 86 */       menu.setMenuItemTitle(StringUtils.trim(rs.getString("menuitemtitle")));
/* 87 */       menu.setParentId(Integer.valueOf(rs.getInt("parentid")));
/* 88 */       menu.setUrl(StringUtils.trim(rs.getString("url")));
/* 89 */       menu.setChildNum(Integer.valueOf(rs.getInt("childnum")));
/* 90 */       return menu;
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.TreeItemDaoImpl
 * JD-Core Version:    0.6.2
 */
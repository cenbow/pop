/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.ICity;
/*    */ import com.asiainfo.biframe.privilege.cache.object.UserCityCache;
/*    */ import com.asiainfo.biframe.privilege.model.User_City;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserCityDao;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserCityDaoImpl extends HibernateDaoSupport
/*    */   implements IUserCityDao
/*    */ {
/*    */   public User_City getCityById(String cityId)
/*    */   {
/* 25 */     User_City city = (User_City)getHibernateTemplate().get(User_City.class, cityId);
/* 26 */     return city;
/*    */   }
/*    */ 
/*    */   public List<User_City> getCityByName(String cityName)
/*    */   {
/* 33 */     List cityList = getHibernateTemplate().find("from User_City uc where uc.cityName='" + cityName + "'");
/* 34 */     return cityList;
/*    */   }
/*    */ 
/*    */   public List<ICity> getAllCity() {
/* 38 */     List cityList = getHibernateTemplate().find("from User_City ");
/* 39 */     return cityList;
/*    */   }
/*    */ 
/*    */   public List<User_City> getCityByParentId(String parentCityId) {
/* 43 */     List cityList = getHibernateTemplate().find("from User_City uc where uc.parentId='" + parentCityId + "'");
/* 44 */     return cityList;
/*    */   }
/*    */ 
/*    */   public List<User_City> getParentCityByChildId(String cityId)
/*    */   {
/* 49 */     if ((cityId == null) || ("".equals(cityId))) {
/* 50 */       return null;
/*    */     }
/* 52 */     return UserCityCache.getInstance().getParentListById(cityId);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserCityDaoImpl
 * JD-Core Version:    0.6.2
 */
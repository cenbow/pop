/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.privilege.model.User_Company;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserDeptDao;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserDeptDaoImpl extends HibernateDaoSupport
/*     */   implements IUserDeptDao
/*     */ {
/*  39 */   private Log log = LogFactory.getLog(UserDeptDaoImpl.class);
/*     */ 
/*     */   public User_Company getDeptById(String deptId) throws Exception {
/*  42 */     User_Company com = (User_Company)getHibernateTemplate().get(User_Company.class, new Integer(deptId));
/*  43 */     return com;
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getDeptAll() throws Exception {
/*  47 */     String hql = " from User_Company uc where uc.status='0'";
/*  48 */     List list = getHibernateTemplate().find(hql);
/*  49 */     return list;
/*     */   }
/*     */ 
/*     */   public List<User_Company> getCompanyByName(String title)
/*     */   {
/*  56 */     List list = getHibernateTemplate().find(" from User_Company uc where uc.title='" + title + "'");
/*  57 */     return list;
/*     */   }
/*     */ 
/*     */   public Map getpagedCompanyList(User_Company company, final int currpage, final int pagesize)
/*     */   {
/*  64 */     this.log.debug("in getPagedUserList........");
/*  65 */     HashMap map = new HashMap();
/*     */     try {
/*  67 */       final String strCond = getConditionSql(company);
/*     */ 
/*  69 */       String countSql = "select count(company) from User_Company company" + strCond;
/*  70 */       this.log.info("----totals:" + countSql);
/*  71 */       List list = getHibernateTemplate().find(countSql);
/*  72 */       int totals = 0;
/*  73 */       if ((list != null) && (list.size() > 0)) {
/*  74 */         totals = ((Long)list.get(0)).intValue();
/*     */       }
/*  76 */       list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  79 */           String listSql = "from User_Company company" + strCond + " order by company.title ";
/*     */ 
/*  81 */           UserDeptDaoImpl.this.log.info("----listSql=" + listSql);
/*  82 */           Query query = s.createQuery(listSql);
/*  83 */           int firstResult = currpage * pagesize;
/*  84 */           int maxResult = pagesize;
/*  85 */           query.setFirstResult(firstResult);
/*  86 */           query.setMaxResults(maxResult);
/*  87 */           List tmpList = query.list();
/*  88 */           return tmpList;
/*     */         }
/*     */       });
/*  91 */       map.put("total", new Integer(totals));
/*  92 */       map.put("result", list);
/*     */     } catch (RuntimeException ex) {
/*  94 */       map.put("total", new Integer(0));
/*  95 */       map.put("result", new ArrayList());
/*  96 */       throw ex;
/*     */     }
/*  98 */     return map;
/*     */   }
/*     */ 
/*     */   private String getConditionSql(User_Company company) {
/* 102 */     StringBuilder where = new StringBuilder(256);
/* 103 */     where.append(" where 1=1");
/* 104 */     if (StringUtils.isNotBlank(company.getStatus())) {
/* 105 */       where.append(" and company.status='").append(company.getStatus()).append("'");
/*     */     }
/* 107 */     if ((StringUtils.isNotBlank(company.getBeginDeleteTime())) && (StringUtils.isNotBlank(company.getEndDeleteTime()))) {
/* 108 */       where.append(" and company.deleteTime >= '").append(company.getBeginDeleteTime()).append("'");
/* 109 */       where.append(" and company.deleteTime <= '").append(company.getEndDeleteTime()).append("'");
/*     */     }
/* 111 */     if (company.getParentid() != null) {
/* 112 */       where.append(" and company.parentid=").append(company.getParentid());
/*     */     }
/* 114 */     return where.toString();
/*     */   }
/*     */ 
/*     */   public String doRealDelete(DeletedParameterVO paraObject) {
/* 118 */     this.log.debug("in doRealDelete ");
/*     */     try {
/* 120 */       StringBuilder hql = new StringBuilder(256);
/* 121 */       hql.append("from User_Company company ");
/* 122 */       hql.append(" where 1=1 and company.status='").append("2").append("' ");
/* 123 */       hql.append(paraObject.getWhereHql("deptid", paraObject, "company"));
/*     */ 
/* 125 */       this.log.debug("--deleteHql:" + hql);
/*     */ 
/* 127 */       List companyList = getHibernateTemplate().find(hql.toString());
/*     */ 
/* 130 */       Set resultCompanySet = new HashSet();
/* 131 */       resultCompanySet.addAll(companyList);
/* 132 */       getAllSubCompnay(companyList, resultCompanySet);
/* 133 */       List deptNames = new ArrayList();
/* 134 */       for (User_Company company : resultCompanySet) {
/* 135 */         deptNames.add(company.getName());
/* 136 */         getHibernateTemplate().delete(company);
/*     */       }
/*     */ 
/* 139 */       this.log.debug("end doRealDelete ");
/* 140 */       return StringUtils.join(deptNames.iterator(), ",");
/*     */     } catch (DataAccessException e) {
/* 142 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteDeptFail") + "", e);
/* 143 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteDeptFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void getAllSubCompnay(List<User_Company> parentCompanyList, Set<User_Company> resultCompanySet)
/*     */   {
/* 149 */     for (User_Company parentCompany : parentCompanyList) {
/* 150 */       User_Company conditionCompany = new User_Company();
/* 151 */       conditionCompany.setParentid(parentCompany.getDeptid());
/* 152 */       List subCompanyList = findAll(conditionCompany);
/* 153 */       resultCompanySet.addAll(subCompanyList);
/* 154 */       getAllSubCompnay(subCompanyList, resultCompanySet);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void realDeleteSubCompanyCascade(List<User_Company> companyList)
/*     */   {
/* 161 */     for (User_Company company : companyList)
/*     */     {
/* 163 */       User_Company conditionCompany = new User_Company();
/* 164 */       conditionCompany.setParentid(company.getDeptid());
/* 165 */       List subCompanyList = findAll(conditionCompany);
/* 166 */       realDeleteSubCompanyCascade(subCompanyList);
/*     */ 
/* 168 */       getHibernateTemplate().delete(company);
/*     */     }
/*     */   }
/*     */ 
/*     */   private List<User_Company> findAll(User_Company company) {
/* 173 */     this.log.debug("getting all list");
/* 174 */     String hql = "from User_Company  company " + getConditionSql(company);
/* 175 */     this.log.debug("--findAllHql:" + hql);
/* 176 */     List list = getHibernateTemplate().find(hql);
/* 177 */     return list;
/*     */   }
/*     */ 
/*     */   public String createCompany(IUserCompany company) throws ServiceException {
/* 181 */     User_Company companyTemp = (User_Company)company;
/* 182 */     List result = getHibernateTemplate().find("select max(uc.deptid)+1 from User_Company uc");
/* 183 */     if ((result != null) && (result.size() > 0)) {
/* 184 */       companyTemp.setDeptid((Integer)result.get(0));
/*     */     }
/*     */     else
/* 187 */       companyTemp.setDeptid(Integer.valueOf(1));
/* 188 */     getHibernateTemplate().save(company);
/* 189 */     return String.valueOf(company.getDeptid());
/*     */   }
/*     */ 
/*     */   public void deleteCompany(String companyId) throws ServiceException {
/* 193 */     User_Company company = null;
/*     */     try {
/* 195 */       company = getDeptById(companyId);
/*     */     } catch (Exception e) {
/* 197 */       throw new ServiceException(e);
/*     */     }
/* 199 */     company.setStatus("2");
/* 200 */     getHibernateTemplate().update(company);
/*     */   }
/*     */ 
/*     */   public void modifyCompany(IUserCompany company) throws ServiceException
/*     */   {
/* 205 */     getHibernateTemplate().update(company);
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getCompanyListByParentId(String parentDeptId) {
/* 209 */     List deptList = getHibernateTemplate().find("from User_Company uc where uc.parentid=" + parentDeptId);
/* 210 */     return deptList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserDeptDaoImpl
 * JD-Core Version:    0.6.2
 */
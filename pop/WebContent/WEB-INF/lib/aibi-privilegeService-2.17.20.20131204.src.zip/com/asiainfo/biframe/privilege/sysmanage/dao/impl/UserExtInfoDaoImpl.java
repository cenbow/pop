/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.model.UserExtInfo;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserExtInfoDAO;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserExtInfoDaoImpl extends HibernateDaoSupport
/*     */   implements IUserExtInfoDAO
/*     */ {
/*  53 */   private Log log = LogFactory.getLog(UserExtInfoDaoImpl.class);
/*     */ 
/*     */   public void save(UserExtInfo extInfo)
/*     */     throws Exception
/*     */   {
/*  60 */     this.log.debug("save UserExtInfo instance");
/*     */     try {
/*  62 */       getHibernateTemplate().save(extInfo);
/*  63 */       this.log.debug("save UserExtInfo successful");
/*     */     } catch (Exception e) {
/*  65 */       this.log.error("save UserExtInfo failed", e);
/*  66 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void update(UserExtInfo extInfo)
/*     */     throws Exception
/*     */   {
/*  75 */     this.log.debug("update UserExtInfo instance");
/*     */     try {
/*  77 */       getHibernateTemplate().update(extInfo);
/*  78 */       this.log.debug("udpate UserExtInfo successful");
/*     */     } catch (Exception e) {
/*  80 */       this.log.error("udpate UserExtInfo failed", e);
/*  81 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveOrUpdateAll(Collection<UserExtInfo> extInfos)
/*     */     throws Exception
/*     */   {
/*  90 */     this.log.debug("saveOrUpdateAll UserExtInfo instance");
/*     */     try {
/*  92 */       getHibernateTemplate().saveOrUpdateAll(extInfos);
/*  93 */       this.log.debug("udpate UserExtInfo successful");
/*     */     } catch (Exception e) {
/*  95 */       this.log.error("saveOrUpdateAll UserExtInfo failed", e);
/*  96 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(UserExtInfo extInfo)
/*     */     throws Exception
/*     */   {
/* 105 */     this.log.debug("delete UserExtInfo instance");
/*     */     try
/*     */     {
/* 108 */       getHibernateTemplate().delete(extInfo);
/*     */ 
/* 110 */       this.log.debug("delete UserExtInfo successful");
/*     */     } catch (Exception e) {
/* 112 */       this.log.error("delete UserExtInfo failed", e);
/* 113 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(DeletedParameterVO paraObject)
/*     */   {
/* 121 */     this.log.debug("delete UserExtInfos instance");
/*     */     try {
/* 123 */       StringBuilder hql = new StringBuilder(256);
/* 124 */       hql.append("from UserExtInfo info where 1=1 ");
/* 125 */       hql.append(paraObject.getWhereHql("userId", paraObject, "info"));
/*     */ 
/* 127 */       this.log.debug("--deleteHql:" + hql);
/* 128 */       Collection infos = getHibernateTemplate().find(hql.toString());
/*     */ 
/* 130 */       getHibernateTemplate().deleteAll(infos);
/* 131 */       this.log.debug("delete UserExtInfos successful");
/*     */     } catch (DataAccessException e) {
/* 133 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserInfoFail") + "", e);
/* 134 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserInfoFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<UserExtInfo> findByUserId(final String userId)
/*     */   {
/* 142 */     this.log.debug("get UserExtInfo instance with userId: " + userId);
/* 143 */     String queryString = "from UserExtInfo this where this.userId=:userId ";
/*     */     try {
/* 145 */       return (List)getHibernateTemplate().execute(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session session) throws HibernateException, SQLException
/*     */         {
/* 149 */           Query query = session.createQuery("from UserExtInfo this where this.userId=:userId ").setString("userId", userId);
/*     */ 
/* 151 */           return query.list();
/*     */         }
/*     */ 
/*     */       });
/*     */     }
/*     */     catch (RuntimeException re)
/*     */     {
/* 158 */       this.log.error("get UserExtInfo failed", re);
/* 159 */       throw re;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserExtInfoDaoImpl
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.UserExtInfoDefine;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserExtInfoDefineDAO;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserExtInfoDefineDaoImpl extends HibernateDaoSupport
/*    */   implements IUserExtInfoDefineDAO
/*    */ {
/* 41 */   private Log log = LogFactory.getLog(UserExtInfoDefineDaoImpl.class);
/*    */ 
/*    */   public void save(UserExtInfoDefine extInfoDefine)
/*    */     throws Exception
/*    */   {
/* 48 */     this.log.debug("save UserExtInfoDefine instance");
/*    */     try {
/* 50 */       getHibernateTemplate().save(extInfoDefine);
/* 51 */       this.log.debug("save UserExtInfoDefine successful");
/*    */     } catch (Exception e) {
/* 53 */       this.log.error("save UserExtInfoDefine failed", e);
/* 54 */       throw e;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void update(UserExtInfoDefine extInfoDefine)
/*    */     throws Exception
/*    */   {
/* 63 */     this.log.debug("update UserExtInfoDefine instance");
/*    */     try {
/* 65 */       getHibernateTemplate().update(extInfoDefine);
/* 66 */       this.log.debug("udpate UserExtInfoDefine successful");
/*    */     } catch (Exception e) {
/* 68 */       this.log.error("udpate UserExtInfoDefine failed", e);
/* 69 */       throw e;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void delete(UserExtInfoDefine extInfoDefine)
/*    */     throws Exception
/*    */   {
/* 78 */     this.log.debug("delete UserExtInfoDefine instance");
/*    */     try
/*    */     {
/* 81 */       getHibernateTemplate().delete(extInfoDefine);
/*    */ 
/* 83 */       this.log.debug("delete UserExtInfoDefine successful");
/*    */     } catch (Exception e) {
/* 85 */       this.log.error("delete UserExtInfoDefine failed", e);
/* 86 */       throw e;
/*    */     }
/*    */   }
/*    */ 
/*    */   public List<UserExtInfoDefine> findAll()
/*    */   {
/* 94 */     this.log.debug("get all UserExtInfoDefine instance ");
/* 95 */     String queryString = "from UserExtInfoDefine";
/*    */     try {
/* 97 */       return getHibernateTemplate().find("from UserExtInfoDefine");
/*    */     }
/*    */     catch (RuntimeException re)
/*    */     {
/* 101 */       this.log.error("get UserExtInfoDefine failed", re);
/* 102 */       throw re;
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserExtInfoDefineDaoImpl
 * JD-Core Version:    0.6.2
 */
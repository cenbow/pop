/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.IUserGroup;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupDAO;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserGroupDaoImpl extends HibernateDaoSupport
/*     */   implements IUserGroupDAO
/*     */ {
/*  36 */   private Log log = LogFactory.getLog(UserGroupDaoImpl.class);
/*     */ 
/*     */   public String getGroupName(String groupId)
/*     */   {
/*  45 */     User_Group userG = getUserGroup(groupId);
/*  46 */     if (userG != null) {
/*  47 */       return userG.getGroupname();
/*     */     }
/*  49 */     return "";
/*     */   }
/*     */ 
/*     */   public User_Group getUserGroup(String groupId)
/*     */   {
/*  59 */     User_Group role = (User_Group)getHibernateTemplate().get(User_Group.class, groupId);
/*  60 */     return role;
/*     */   }
/*     */ 
/*     */   public List<IUserGroup> getAllUserGroupList()
/*     */   {
/*  68 */     String hql = " from User_Group ug where ug.status=0 order by ug.sortnum,ug.groupname";
/*  69 */     List list = getHibernateTemplate().find(hql);
/*  70 */     return list;
/*     */   }
/*     */ 
/*     */   public String save(User_Group transientInstance)
/*     */   {
/*  75 */     this.log.debug("in save");
/*     */ 
/*  77 */     return (String)getHibernateTemplate().save(transientInstance);
/*     */   }
/*     */ 
/*     */   public void update(User_Group transientInstance) {
/*  81 */     this.log.debug("saving User_Group instance");
/*     */ 
/*  83 */     getHibernateTemplate().update(transientInstance);
/*  84 */     this.log.debug("save successful");
/*     */   }
/*     */ 
/*     */   public void delete(User_Group persistentInstance)
/*     */   {
/*  89 */     this.log.debug("deleting User_Group instance");
/*     */ 
/*  91 */     getHibernateTemplate().delete(persistentInstance);
/*  92 */     this.log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public User_Group findById(String id)
/*     */   {
/*  97 */     this.log.debug("getting User_Group instance with id: " + id);
/*     */ 
/*  99 */     User_Group instance = (User_Group)getHibernateTemplate().get(User_Group.class, id);
/* 100 */     return instance;
/*     */   }
/*     */ 
/*     */   public List<User_Group> findAllByGroupIdList(List<String> groupIdList)
/*     */   {
/* 106 */     this.log.debug("findAllByGroupIdList  ");
/* 107 */     List usetGList = new ArrayList();
/* 108 */     if ((groupIdList != null) && (groupIdList.size() > 0)) {
/* 109 */       User_Group userG = new User_Group();
/* 110 */       String groupids = StringUtil.list2String(groupIdList, ",", true);
/* 111 */       userG.setGroupids(groupids);
/* 112 */       usetGList = findAll(userG);
/*     */     }
/* 114 */     return usetGList;
/*     */   }
/*     */ 
/*     */   public List<User_Group> findAll(User_Group group)
/*     */   {
/* 119 */     this.log.debug("getting all list");
/* 120 */     String hql = "from User_Group  ug  ";
/* 121 */     String hql1 = getConditionSql(group);
/* 122 */     String orderSql = " order by ug.sortnum,ug.groupname";
/* 123 */     List ug = getHibernateTemplate().find(hql + hql1 + orderSql);
/* 124 */     return ug;
/*     */   }
/*     */ 
/*     */   public Map getPagedUserList(User_Group group, final int currpage, final int pagesize) {
/* 128 */     this.log.debug("in getPagedUserList........");
/* 129 */     HashMap map = new HashMap();
/* 130 */     final String hql = getConditionSql1(group);
/* 131 */     String totalHql = "select count(*) from User_Group ug  " + hql;
/* 132 */     List list = getHibernateTemplate().find(totalHql);
/* 133 */     int totals = ((Long)list.get(0)).intValue();
/*     */ 
/* 135 */     this.log.debug("totalHql:" + totalHql);
/* 136 */     this.log.debug("totals:" + totals);
/*     */ 
/* 138 */     list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 140 */         String hql2 = "from User_Group ug  " + hql + " order by ug.groupname ";
/* 141 */         UserGroupDaoImpl.this.log.debug("--hql2:" + hql2);
/*     */ 
/* 143 */         Query query = s.createQuery(hql2);
/* 144 */         int firstResult = (currpage - 1) * pagesize;
/* 145 */         int maxResult = pagesize;
/* 146 */         query.setFirstResult(firstResult);
/* 147 */         query.setMaxResults(maxResult);
/* 148 */         List tmpList = query.list();
/* 149 */         return tmpList;
/*     */       }
/*     */     });
/* 153 */     map.put("total", new Integer(totals));
/* 154 */     map.put("result", list);
/*     */ 
/* 156 */     return map;
/*     */   }
/*     */ 
/*     */   private String getConditionSql(User_Group group) {
/* 160 */     this.log.debug("in UsergroupDAoimpl.getConditionSql........");
/*     */ 
/* 162 */     String hql = " where 1=1 ";
/* 163 */     if (group.getDeleteTime() != null) {
/* 164 */       hql = hql + " and ug.delete_time=" + group.getDeleteTime();
/*     */     }
/* 166 */     if ((group.getGroupid() != null) && (group.getGroupid().length() > 0))
/* 167 */       hql = hql + " and ug.groupid='" + group.getGroupid() + "' ";
/* 168 */     if ((group.getGroupname() != null) && (group.getGroupname().length() > 0))
/* 169 */       hql = hql + " and ug.groupname = '" + group.getGroupname() + "' ";
/* 170 */     if (group.getCreatetime() != null)
/* 171 */       hql = hql + " and ug.createtime=" + group.getCreatetime();
/* 172 */     if (group.getEnddate() != null)
/* 173 */       hql = hql + " and ug.enddate=" + group.getEnddate();
/* 174 */     if (group.getBegindate() != null)
/* 175 */       hql = hql + " and ug.begindate=" + group.getBegindate();
/* 176 */     if ((group.getParentid() != null) && (group.getParentid().length() > 0))
/* 177 */       hql = hql + " and ug.parentid='" + group.getParentid() + "'";
/* 178 */     if ((group.getStatus() != null) && (group.getStatus().intValue() != -1))
/* 179 */       hql = hql + " and ug.status=" + group.getStatus();
/* 180 */     if ((group.getQueryStatus() != null) && (group.getQueryStatus().intValue() != -1))
/* 181 */       hql = hql + " and ug.status=" + group.getQueryStatus();
/* 182 */     if ((group.getUserlimit() != null) && (group.getUserlimit().intValue() != -1))
/* 183 */       hql = hql + " and ug.userlimit=" + group.getUserlimit();
/* 184 */     if ((group.getQueryGroupName() != null) && (group.getQueryGroupName().length() > 0))
/* 185 */       hql = hql + " and ug.groupname like '%" + group.getQueryGroupName() + "%' ";
/* 186 */     if ((group.getGroupids() != null) && (group.getGroupids().length() > 0)) {
/* 187 */       String sqlin = "";
/* 188 */       String roles = "";
/* 189 */       String[] strRolesArry = group.getGroupids().split(",");
/* 190 */       int cnt = 1;
/* 191 */       if (strRolesArry.length > 1000) {
/* 192 */         int nDeep = 0;
/* 193 */         for (int i = 0; i < strRolesArry.length; i++) {
/* 194 */           roles = roles + strRolesArry[i] + ",";
/* 195 */           cnt++;
/* 196 */           if (cnt > 1000) {
/* 197 */             if (nDeep == 0)
/* 198 */               sqlin = sqlin + " and (";
/*     */             else {
/* 200 */               sqlin = sqlin + " or ";
/*     */             }
/* 202 */             sqlin = sqlin + " ug.groupid in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/* 203 */             roles = "";
/* 204 */             cnt = 1;
/* 205 */             nDeep++;
/*     */           }
/*     */         }
/* 208 */         if (roles.length() > 0) {
/* 209 */           sqlin = sqlin + " or ug.groupid in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/*     */         }
/* 211 */         sqlin = sqlin + ")";
/*     */       } else {
/* 213 */         sqlin = " and ug.groupid in (" + group.getGroupids() + ") ";
/*     */       }
/*     */ 
/* 216 */       hql = hql + sqlin;
/*     */     }
/* 218 */     return hql;
/*     */   }
/*     */ 
/*     */   private String getConditionSql1(User_Group group) {
/* 222 */     this.log.debug("in UsergroupDAoimpl.getConditionSql........");
/*     */ 
/* 224 */     String hql = " where 1=1 ";
/* 225 */     if (group.getDeleteTime() != null) {
/* 226 */       hql = hql + " and ug.delete_time=" + group.getDeleteTime();
/*     */     }
/* 228 */     if ((group.getGroupid() != null) && (group.getGroupid().length() > 0))
/* 229 */       hql = hql + " and ug.groupid='" + group.getGroupid() + "' ";
/* 230 */     if ((group.getGroupname() != null) && (group.getGroupname().length() > 0))
/* 231 */       hql = hql + " and ug.groupname = '" + group.getGroupname() + "' ";
/* 232 */     if (group.getCreatetime() != null)
/* 233 */       hql = hql + " and ug.createtime=" + group.getCreatetime();
/* 234 */     if (group.getEnddate() != null)
/* 235 */       hql = hql + " and ug.enddate=" + group.getEnddate();
/* 236 */     if (group.getBegindate() != null)
/* 237 */       hql = hql + " and ug.begindate=" + group.getBegindate();
/* 238 */     if ((group.getParentid() != null) && (group.getParentid().length() > 0)) {
/* 239 */       if (group.getParentid().equals("1"))
/* 240 */         hql = hql + " and (ug.parentid='" + group.getParentid() + "' or ug.groupid='1') ";
/*     */       else
/* 242 */         hql = hql + " and ug.parentid='" + group.getParentid() + "' ";
/*     */     }
/* 244 */     if ((group.getStatus() != null) && (group.getStatus().intValue() != -1))
/* 245 */       hql = hql + " and ug.status=" + group.getStatus();
/* 246 */     if ((group.getQueryStatus() != null) && (group.getQueryStatus().intValue() != -1))
/* 247 */       hql = hql + " and ug.status=" + group.getQueryStatus();
/* 248 */     if ((group.getUserlimit() != null) && (group.getUserlimit().intValue() != -1))
/* 249 */       hql = hql + " and ug.userlimit=" + group.getUserlimit();
/* 250 */     if ((group.getQueryGroupName() != null) && (group.getQueryGroupName().length() > 0))
/* 251 */       hql = hql + " and ug.groupname like '%" + group.getQueryGroupName() + "%' ";
/* 252 */     if ((group.getGroupids() != null) && (group.getGroupids().length() > 0)) {
/* 253 */       String sqlin = "";
/* 254 */       String roles = "";
/* 255 */       String[] strRolesArry = group.getGroupids().split(",");
/* 256 */       int cnt = 1;
/* 257 */       if (strRolesArry.length > 1000) {
/* 258 */         int nDeep = 0;
/* 259 */         for (int i = 0; i < strRolesArry.length; i++) {
/* 260 */           roles = roles + strRolesArry[i] + ",";
/* 261 */           cnt++;
/* 262 */           if (cnt > 1000) {
/* 263 */             if (nDeep == 0)
/* 264 */               sqlin = sqlin + " and (";
/*     */             else {
/* 266 */               sqlin = sqlin + " or ";
/*     */             }
/* 268 */             sqlin = sqlin + " ug.groupid in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/* 269 */             roles = "";
/* 270 */             cnt = 1;
/* 271 */             nDeep++;
/*     */           }
/*     */         }
/* 274 */         if (roles.length() > 0) {
/* 275 */           sqlin = sqlin + " or ug.groupid in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/*     */         }
/* 277 */         sqlin = sqlin + ")";
/*     */       } else {
/* 279 */         sqlin = " and ug.groupid in (" + group.getGroupids() + ") ";
/*     */       }
/*     */ 
/* 282 */       hql = hql + sqlin;
/*     */     }
/* 284 */     if ((StringUtils.isNotBlank(group.getBeginDeleteTime())) && (StringUtils.isNotBlank(group.getEndDeleteTime()))) {
/* 285 */       hql = hql + " and ug.deleteTime >= '" + group.getBeginDeleteTime() + "'";
/* 286 */       hql = hql + " and ug.deleteTime <= '" + group.getEndDeleteTime() + "'";
/*     */     }
/* 288 */     return hql;
/*     */   }
/*     */ 
/*     */   public List<User_Group> findByGroupName(String groupName) {
/* 292 */     List list = getHibernateTemplate().find(" from User_Group ug where ug.groupname='" + groupName + "'");
/* 293 */     return list;
/*     */   }
/*     */ 
/*     */   public String doRealDelete(DeletedParameterVO paraObject)
/*     */   {
/* 300 */     this.log.debug("in doRealDelete ");
/*     */     try {
/* 302 */       StringBuilder hql = new StringBuilder(256);
/* 303 */       hql.append("from User_Group userGroup ");
/* 304 */       hql.append(" where 1=1 and userGroup.status=").append("2").append(" ");
/* 305 */       hql.append(paraObject.getWhereHql("groupid", paraObject, "userGroup"));
/*     */ 
/* 307 */       this.log.debug("--deleteHql:" + hql);
/*     */ 
/* 309 */       List groupList = getHibernateTemplate().find(hql.toString());
/*     */ 
/* 311 */       List groupNameList = new ArrayList();
/* 312 */       realDeleteSubGroupCascade(groupList, groupNameList);
/* 313 */       this.log.debug("end doRealDelete ");
/* 314 */       return StringUtils.join(groupNameList.iterator(), ",");
/*     */     }
/*     */     catch (DataAccessException e) {
/* 317 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupFail") + "", e);
/* 318 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void realDeleteSubGroupCascade(List<User_Group> groupList, List<String> groupNameList)
/*     */   {
/* 324 */     for (User_Group group : groupList) {
/* 325 */       groupNameList.add(group.getGroupname());
/* 326 */       delete(group);
/*     */ 
/* 328 */       User_Group uGroup = new User_Group();
/* 329 */       uGroup.setParentid(group.getGroupid());
/* 330 */       List subGroupList = findAll(uGroup);
/* 331 */       realDeleteSubGroupCascade(subGroupList, groupNameList);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<IUserGroup> getValidChildGroups(String groupId) {
/* 336 */     List list = new ArrayList();
/* 337 */     getValidChildGroups("'" + groupId + "'", list);
/* 338 */     return list;
/*     */   }
/*     */   private void getValidChildGroups(String groupIds, List<IUserGroup> groupList) {
/* 341 */     String hsql = " from User_Group ug where ug.parentid in (" + groupIds + ")";
/* 342 */     List list = getHibernateTemplate().find(hsql);
/* 343 */     String groupIdsSqlIn = "";
/* 344 */     for (IUserGroup userGroup : list) {
/* 345 */       groupIdsSqlIn = groupIdsSqlIn + "'" + userGroup.getGroupid() + "',";
/*     */     }
/* 347 */     if (list.size() > 0) {
/* 348 */       groupIdsSqlIn = groupIdsSqlIn.substring(0, groupIdsSqlIn.length() - 1);
/* 349 */       groupList.addAll(list);
/* 350 */       getValidChildGroups(groupIdsSqlIn, groupList);
/*     */     }
/*     */   }
/*     */ 
/* 354 */   public List getUserGroupByTime(String startTime, String endTime) { String strCond = "";
/* 355 */     String hSql = "from User_Group userGroup where 1=1" + strCond;
/*     */ 
/* 357 */     if (StringUtils.isNotEmpty(startTime)) {
/* 358 */       hSql = hSql + " and userGroup.createtime >= ?";
/*     */     }
/* 360 */     if (StringUtils.isNotEmpty(endTime)) {
/* 361 */       hSql = hSql + " and userGroup.createtime <= ?";
/*     */     }
/*     */ 
/* 364 */     List groupList = getHibernateTemplate().find(hSql, new Object[] { DateUtil.string2Date(startTime), DateUtil.string2Date(endTime) });
/* 365 */     return groupList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserGroupDaoImpl
 * JD-Core Version:    0.6.2
 */
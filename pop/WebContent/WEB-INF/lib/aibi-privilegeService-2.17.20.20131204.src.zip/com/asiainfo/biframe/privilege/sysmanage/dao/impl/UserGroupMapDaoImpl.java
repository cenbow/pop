/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.IUserGroup;
/*     */ import com.asiainfo.biframe.privilege.model.UserGroupMap;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupMapDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserGroupMapDaoImpl extends HibernateDaoSupport
/*     */   implements IUserGroupMapDAO
/*     */ {
/*  22 */   private static final Log log = LogFactory.getLog(UserUserMapDaoImpl.class);
/*     */ 
/*     */   public void save(UserGroupMap transientInstance) {
/*     */     try {
/*  26 */       log.debug("saving UserGroupMap instance");
/*  27 */       UserGroupMap realMap = (UserGroupMap)getHibernateTemplate().get(UserGroupMap.class, transientInstance);
/*  28 */       if (realMap == null) getHibernateTemplate().save(transientInstance);
/*  29 */       log.debug("save successful");
/*     */     } catch (DataAccessException e) {
/*  31 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveUserAndGroupRelationFail") + "", e);
/*  32 */       throw new SysmanageException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveUserAndGroupRelationFail") + ":" + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(UserGroupMap persistentInstance) {
/*  37 */     log.debug("delete UserGroupMap instance");
/*  38 */     UserGroupMap realMap = (UserGroupMap)getHibernateTemplate().get(UserGroupMap.class, persistentInstance);
/*  39 */     if (realMap != null) getHibernateTemplate().delete(persistentInstance);
/*  40 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapByGId(String groupId) {
/*  44 */     log.debug("delete UserGroupMap groupId=" + groupId);
/*  45 */     String hql = "from UserGroupMap map where map.groupId='" + groupId + "'";
/*  46 */     List list = getHibernateTemplate().find(hql);
/*  47 */     getHibernateTemplate().deleteAll(list);
/*  48 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapByUserId(String userId) {
/*  52 */     log.debug("delete UserGroupMap userId=" + userId);
/*  53 */     String hql = "from UserGroupMap map where map.userid='" + userId + "'";
/*  54 */     List list = getHibernateTemplate().find(hql);
/*  55 */     getHibernateTemplate().deleteAll(list);
/*  56 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapList(List userGroupList) {
/*  60 */     log.debug("delete UserGroupMap List=" + userGroupList);
/*     */ 
/*  62 */     if ((userGroupList != null) && (userGroupList.size() > 0)) {
/*  63 */       getHibernateTemplate().deleteAll(userGroupList);
/*     */     }
/*  65 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public List<User_User> findAllUserByGId(String gid)
/*     */   {
/*  73 */     log.debug("findAllUserByGId UserGroupMap groupid = " + gid);
/*  74 */     String hql = "select us from UserGroupMap ugm,User_User us where us.userid=ugm.userid and us.status=0 and ugm.groupId = '" + gid + "'";
/*     */ 
/*  76 */     List userList = getHibernateTemplate().find(hql);
/*  77 */     return userList;
/*     */   }
/*     */ 
/*     */   public List<User_Group> getGroupByUserId(String uid)
/*     */   {
/*  84 */     log.debug("findByUserId UserGroupMap userId=" + uid);
/*  85 */     List list = null;
/*  86 */     String hql = "select ug from UserGroupMap ugm,User_Group ug where ugm.groupId=ug.groupid and ug.status=0 and ugm.userid = '" + uid + "'";
/*     */ 
/*  88 */     list = getHibernateTemplate().find(hql);
/*  89 */     return list;
/*     */   }
/*     */ 
/*     */   public List<User_User> getAllByGroupId(String Gids)
/*     */   {
/*  96 */     log.debug("getAllByGroupId UserGroupMap Gids=" + Gids);
/*  97 */     List list = null;
/*  98 */     String sqlin = "";
/*  99 */     String roles = "";
/* 100 */     String[] strRolesArry = Gids.split(",");
/* 101 */     int cnt = 1;
/* 102 */     if (strRolesArry.length > 1000)
/* 103 */       for (int i = 0; i < strRolesArry.length; i++) {
/* 104 */         roles = roles + strRolesArry[i] + ",";
/* 105 */         cnt++;
/* 106 */         if (cnt > 1000) {
/* 107 */           sqlin = sqlin + " and ugm.groupId in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/* 108 */           roles = "";
/* 109 */           cnt = 1;
/*     */         }
/*     */       }
/*     */     else {
/* 113 */       sqlin = " and ugm.groupId in (" + Gids + ") ";
/*     */     }
/* 115 */     String hql = "select us from UserGroupMap ugm,User_User us where 1=1 and us.userid=ugm.userid and us.status=0" + sqlin;
/*     */ 
/* 117 */     list = getHibernateTemplate().find(hql);
/* 118 */     return list;
/*     */   }
/*     */ 
/*     */   public void doRealDelete(DeletedParameterVO paraObject)
/*     */   {
/* 124 */     log.debug("in doRealDelete ");
/*     */     try {
/* 126 */       StringBuilder hql = new StringBuilder(256);
/* 127 */       hql.append("select groupMap from User_User user,UserGroupMap groupMap ");
/* 128 */       hql.append(" where user.userid=groupMap.userid ");
/* 129 */       hql.append(" and user.status=").append("2");
/* 130 */       hql.append(paraObject.getWhereHql("userid", paraObject, "user"));
/*     */ 
/* 132 */       log.debug("--deleteHql:" + hql);
/* 133 */       List list = getHibernateTemplate().find(hql.toString());
/* 134 */       getHibernateTemplate().deleteAll(list);
/* 135 */       log.debug("end doRealDelete ");
/*     */     } catch (DataAccessException e) {
/* 137 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserAndGroupRelationFail") + "", e);
/* 138 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserAndGroupRelationFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<IUserGroup> getGroupByUserId(List<String> uids)
/*     */   {
/* 146 */     log.debug("findByUserId UserGroupMap userId=" + uids);
/* 147 */     List list = null;
/* 148 */     String uidsw = "";
/* 149 */     for (String uid : uids) {
/* 150 */       uidsw = uidsw + "'" + uid + "',";
/*     */     }
/* 152 */     uidsw = uidsw.substring(0, uidsw.length() - 1);
/* 153 */     String hql = "select ug from UserGroupMap ugm,User_Group ug where ugm.groupId=ug.groupid and ug.status=0 and ugm.userid in (" + uidsw + ")";
/*     */ 
/* 157 */     list = getHibernateTemplate().find(hql);
/* 158 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserGroupMapDaoImpl
 * JD-Core Version:    0.6.2
 */
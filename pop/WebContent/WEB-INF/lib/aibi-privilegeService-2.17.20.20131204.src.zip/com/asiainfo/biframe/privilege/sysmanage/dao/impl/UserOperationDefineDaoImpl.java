/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.UserOperationDefine;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserOperationDefineDao;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.jdbc.core.JdbcTemplate;
/*    */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*    */ 
/*    */ public class UserOperationDefineDaoImpl extends JdbcDaoSupport
/*    */   implements IUserOperationDefineDao
/*    */ {
/*    */   public List<String> getUserOperDef(int resourceType)
/*    */   {
/* 27 */     String sql = "select operationkey from RESOURCE_OPERATION_DEFINE where resourcetype=" + resourceType;
/* 28 */     List list = getJdbcTemplate().queryForList(sql);
/* 29 */     List keyList = new ArrayList();
/* 30 */     for (Map map : list) {
/* 31 */       keyList.add(map.get("operationkey"));
/*    */     }
/* 33 */     return keyList;
/*    */   }
/*    */ 
/*    */   public List<UserOperationDefine> getUserOperDefByName(String operationName, int resourceType)
/*    */   {
/* 38 */     String sql = "select * from RESOURCE_OPERATION_DEFINE where resourcetype=" + resourceType + " and operationname='" + operationName + "'";
/* 39 */     List list = getJdbcTemplate().queryForList(sql);
/* 40 */     List operDefineList = new ArrayList();
/* 41 */     for (Map map : list) {
/* 42 */       UserOperationDefine operDefine = new UserOperationDefine();
/* 43 */       operDefine.setOperationKey((String)map.get("operationkey"));
/* 44 */       operDefine.setOperationId((String)map.get("operationid"));
/* 45 */       operDefine.setOperationName(operationName);
/* 46 */       operDefine.setResourceType(resourceType);
/* 47 */       operDefineList.add(operDefine);
/*    */     }
/* 49 */     return operDefineList;
/*    */   }
/*    */ 
/*    */   public List<UserOperationDefine> getAllUserOperDef() {
/* 53 */     String sql = "select operationid,operationname, operationkey,resourcetype from RESOURCE_OPERATION_DEFINE";
/* 54 */     List list = getJdbcTemplate().queryForList(sql);
/* 55 */     List operDefineList = new ArrayList();
/* 56 */     for (Map map : list) {
/* 57 */       UserOperationDefine operDefine = new UserOperationDefine();
/* 58 */       operDefine.setOperationKey(map.get("operationkey").toString());
/* 59 */       operDefine.setOperationId(map.get("operationid").toString());
/* 60 */       operDefine.setOperationName(map.get("operationname").toString());
/* 61 */       String resourceTypeString = map.get("resourcetype").toString();
/* 62 */       operDefine.setResourceType(Integer.parseInt(resourceTypeString));
/* 63 */       operDefineList.add(operDefine);
/*    */     }
/* 65 */     return operDefineList;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserOperationDefineDaoImpl
 * JD-Core Version:    0.6.2
 */
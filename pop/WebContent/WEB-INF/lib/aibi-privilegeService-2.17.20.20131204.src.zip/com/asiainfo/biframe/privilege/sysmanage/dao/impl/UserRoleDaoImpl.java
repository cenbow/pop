/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.IUserRole;
/*     */ import com.asiainfo.biframe.privilege.base.util.SqlUtil;
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleDAO;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserRoleDaoImpl extends HibernateDaoSupport
/*     */   implements IUserRoleDAO
/*     */ {
/*  39 */   private Log log = LogFactory.getLog(UserRoleDaoImpl.class);
/*     */ 
/*     */   public String save(UserRole transientInstance)
/*     */   {
/*  47 */     this.log.debug("save UserRole instance");
/*  48 */     String roleId = (String)getHibernateTemplate().save(transientInstance);
/*  49 */     this.log.debug("save UserRole successful");
/*  50 */     return roleId;
/*     */   }
/*     */ 
/*     */   public void update(UserRole transientInstance)
/*     */   {
/*  59 */     this.log.debug("update UserRole instance");
/*  60 */     getHibernateTemplate().update(transientInstance);
/*  61 */     this.log.debug("udpate UserRole successful");
/*     */   }
/*     */ 
/*     */   public void delete(UserRole persistentInstance)
/*     */   {
/*  70 */     this.log.debug("delete UserRole instance");
/*  71 */     getHibernateTemplate().delete(persistentInstance);
/*  72 */     this.log.debug("delete UserRole successful");
/*     */   }
/*     */ 
/*     */   public UserRole findById(String id)
/*     */   {
/*  82 */     this.log.debug("get UserRole instance with id: " + id);
/*     */ 
/*  84 */     UserRole instance = (UserRole)getHibernateTemplate().get(UserRole.class, id);
/*     */ 
/*  86 */     return instance;
/*     */   }
/*     */ 
/*     */   public List<UserRole> findByCreateGroup(String groupId)
/*     */   {
/*  91 */     StringBuffer sb = new StringBuffer();
/*  92 */     sb.append("where userRole.createGroup='" + groupId + "' ");
/*  93 */     sb.append(" and userRole.status=").append("0");
/*  94 */     sb.append(" order by userRole.roleName");
/*     */ 
/*  96 */     return getHibernateTemplate().find("from UserRole userRole " + sb.toString());
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public List<UserRole> findByCreateGroup(String groupId, int resourceType)
/*     */   {
/* 108 */     StringBuffer sb = new StringBuffer();
/* 109 */     sb.append("from UserRole userRole");
/* 110 */     sb.append(" where userRole.createGroup='").append(groupId).append("'");
/* 111 */     sb.append(" and userRole.resourceType=").append(resourceType);
/* 112 */     sb.append(" and userRole.status=").append("0");
/* 113 */     sb.append(" order by userRole.roleName");
/*     */ 
/* 115 */     return getHibernateTemplate().find(sb.toString());
/*     */   }
/*     */ 
/*     */   public List<UserRole> findByIdList(List<String> roleIdList)
/*     */   {
/* 122 */     String sqlin = "";
/* 123 */     String roles = "";
/* 124 */     String[] strRolesArry = StringUtil.list2String(roleIdList, ",", true).split(",");
/* 125 */     int cnt = 1;
/* 126 */     if (strRolesArry.length > 1000) {
/* 127 */       int nDeep = 0;
/* 128 */       for (int i = 0; i < strRolesArry.length; i++) {
/* 129 */         roles = roles + strRolesArry[i] + ",";
/* 130 */         cnt++;
/* 131 */         if (cnt > 1000) {
/* 132 */           if (nDeep == 0)
/* 133 */             sqlin = sqlin + " and (";
/*     */           else {
/* 135 */             sqlin = sqlin + " or ";
/*     */           }
/*     */ 
/* 138 */           sqlin = sqlin + "(" + SqlUtil.getSqlIn(roles.substring(0, roles.lastIndexOf(",")), "userRole.roleId") + ")";
/*     */ 
/* 140 */           roles = "";
/* 141 */           cnt = 1;
/* 142 */           nDeep++;
/*     */         }
/*     */       }
/* 145 */       if (roles.length() > 0)
/*     */       {
/* 147 */         sqlin = sqlin + " or (" + SqlUtil.getSqlIn(roles.substring(0, roles.lastIndexOf(",")), "userRole.roleId") + ")";
/*     */       }
/*     */ 
/* 150 */       sqlin = sqlin + ")";
/*     */     }
/*     */     else {
/* 153 */       sqlin = sqlin + " and (" + SqlUtil.getSqlIn(StringUtil.list2String(roleIdList, ",", true), "userRole.roleId") + ")";
/*     */     }
/*     */ 
/* 156 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 160 */     sb.append("where 1=1 " + sqlin);
/* 161 */     return getHibernateTemplate().find("from UserRole userRole " + sb.toString() + " order by userRole.roleName");
/*     */   }
/*     */ 
/*     */   public List<UserRole> findByCreateGroupList(List<String> createGroupIdList) {
/* 165 */     String sqlin = "";
/* 166 */     String roles = "";
/* 167 */     String[] strRolesArry = StringUtil.list2String(createGroupIdList, ",", true).split(",");
/* 168 */     int cnt = 1;
/* 169 */     if (strRolesArry.length > 1000) {
/* 170 */       int nDeep = 0;
/* 171 */       for (int i = 0; i < strRolesArry.length; i++) {
/* 172 */         roles = roles + strRolesArry[i] + ",";
/* 173 */         cnt++;
/* 174 */         if (cnt > 1000) {
/* 175 */           if (nDeep == 0)
/* 176 */             sqlin = sqlin + " and (";
/*     */           else {
/* 178 */             sqlin = sqlin + " or ";
/*     */           }
/*     */ 
/* 181 */           sqlin = sqlin + "(" + SqlUtil.getSqlIn(roles.substring(0, roles.lastIndexOf(",")), "userRole.createGroup") + ")";
/*     */ 
/* 183 */           roles = "";
/* 184 */           cnt = 1;
/* 185 */           nDeep++;
/*     */         }
/*     */       }
/* 188 */       if (roles.length() > 0)
/*     */       {
/* 190 */         sqlin = sqlin + " or (" + SqlUtil.getSqlIn(roles.substring(0, roles.lastIndexOf(",")), "userRole.createGroup") + ")";
/*     */       }
/*     */ 
/* 193 */       sqlin = sqlin + ")";
/*     */     }
/*     */     else {
/* 196 */       sqlin = sqlin + " and (" + SqlUtil.getSqlIn(StringUtil.list2String(createGroupIdList, ",", true), "userRole.createGroup") + ")";
/*     */     }
/*     */ 
/* 199 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 203 */     sb.append("where 1=1" + sqlin);
/* 204 */     sb.append(" and userRole.status=").append("0");
/* 205 */     sb.append(" order by userRole.roleName");
/*     */ 
/* 207 */     this.log.debug("--where:" + sb.toString());
/* 208 */     return getHibernateTemplate().find("from UserRole userRole " + sb.toString());
/*     */   }
/*     */   public List<UserRole> findAllRoles() {
/* 211 */     this.log.debug("get all UserRole list");
/*     */ 
/* 213 */     String sql = "from UserRole role where role.status=0 order by role.roleName ";
/* 214 */     List list = getHibernateTemplate().find(sql);
/*     */ 
/* 216 */     this.log.debug("list.size=" + list.size());
/* 217 */     return list;
/*     */   }
/*     */   public List<IUserRole> getAllRoles() {
/* 220 */     this.log.debug("get all UserRole list");
/*     */ 
/* 222 */     String sql = "from UserRole role where role.status=0 order by role.roleName ";
/* 223 */     List list = getHibernateTemplate().find(sql);
/*     */ 
/* 225 */     this.log.debug("list.size=" + list.size());
/* 226 */     return list;
/*     */   }
/*     */ 
/*     */   public Map getPagedRoleList(UserRole userRole, final int currpage, final int pagesize)
/*     */   {
/* 237 */     this.log.debug("getPagedRoleList...............");
/* 238 */     HashMap map = new HashMap();
/*     */ 
/* 240 */     final StringBuffer sb = getWhereSql(userRole);
/*     */ 
/* 242 */     List list = getHibernateTemplate().find("select count(*) from UserRole role " + sb.toString());
/* 243 */     int totals = ((Long)list.get(0)).intValue();
/* 244 */     this.log.debug("totals:" + totals);
/*     */ 
/* 246 */     list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 249 */         sb.append(" order by role.createTime desc");
/*     */ 
/* 251 */         System.out.println(sb.toString());
/*     */ 
/* 253 */         Query query = s.createQuery(" from UserRole role " + sb.toString());
/*     */ 
/* 255 */         int firstResult = (currpage - 1) * pagesize;
/* 256 */         int maxResult = pagesize;
/* 257 */         query.setFirstResult(firstResult);
/* 258 */         query.setMaxResults(maxResult);
/* 259 */         UserRoleDaoImpl.this.log.debug("--sql:" + query.getQueryString());
/* 260 */         List tmpList = query.list();
/*     */ 
/* 262 */         return tmpList;
/*     */       }
/*     */     });
/* 266 */     map.put("total", new Integer(totals));
/* 267 */     map.put("result", list);
/*     */ 
/* 269 */     return map;
/*     */   }
/*     */ 
/*     */   public List<UserRole> getUserRoleList(UserRole aUserRole) {
/* 273 */     StringBuffer whereSql = getWhereSql(aUserRole);
/* 274 */     List list = getHibernateTemplate().find("from UserRole role " + whereSql.toString() + " order by role.createTime desc");
/*     */ 
/* 276 */     return list;
/*     */   }
/*     */ 
/*     */   private StringBuffer getWhereSql(UserRole userRole) {
/* 280 */     StringBuffer sb = new StringBuffer();
/* 281 */     sb.append(" where 1=1 ");
/* 282 */     if ((userRole.getRoleName() != null) && (userRole.getRoleName().length() > 0))
/* 283 */       sb.append(" and role.roleName like '%" + userRole.getRoleName() + "%' ");
/* 284 */     if (userRole.getRoleType() >= 0)
/* 285 */       sb.append(" and role.roleType = " + userRole.getRoleType() + " ");
/* 286 */     if (userRole.getResourceType() >= 0)
/* 287 */       sb.append(" and role.resourceType = " + userRole.getResourceType() + " ");
/* 288 */     if ((userRole.getCreateGroup() != null) && (userRole.getCreateGroup().length() > 0))
/* 289 */       sb.append(" and role.createGroup = '" + userRole.getCreateGroup() + "' ");
/* 290 */     if (userRole.getStatus() != -1) {
/* 291 */       sb.append(" and role.status=").append(userRole.getStatus());
/*     */     }
/* 293 */     if ((userRole.getCreateGroupIds() != null) && (userRole.getCreateGroupIds().length() > 0)) {
/* 294 */       String sqlin = "";
/* 295 */       String roles = "";
/* 296 */       String[] strRolesArry = userRole.getCreateGroupIds().split(",");
/* 297 */       int cnt = 1;
/* 298 */       if (strRolesArry.length > 1000) {
/* 299 */         int nDeep = 0;
/* 300 */         for (int i = 0; i < strRolesArry.length; i++) {
/* 301 */           roles = roles + strRolesArry[i] + ",";
/* 302 */           cnt++;
/* 303 */           if (cnt > 1000) {
/* 304 */             if (nDeep == 0)
/* 305 */               sqlin = sqlin + " and (";
/*     */             else {
/* 307 */               sqlin = sqlin + " or ";
/*     */             }
/*     */ 
/* 310 */             sqlin = sqlin + "(" + SqlUtil.getSqlIn(roles.substring(0, roles.lastIndexOf(",")), "role.createGroup") + ")";
/*     */ 
/* 312 */             roles = "";
/* 313 */             cnt = 1;
/* 314 */             nDeep++;
/*     */           }
/*     */         }
/* 317 */         if (roles.length() > 0)
/*     */         {
/* 319 */           sqlin = sqlin + " or (" + SqlUtil.getSqlIn(roles.substring(0, roles.lastIndexOf(",")), "role.createGroup") + ")";
/*     */         }
/*     */ 
/* 322 */         sqlin = sqlin + ")";
/*     */       }
/*     */       else {
/* 325 */         sqlin = sqlin + " and (" + SqlUtil.getSqlIn(userRole.getCreateGroupIds(), "role.createGroup") + ")";
/*     */       }
/*     */ 
/* 328 */       sb.append(sqlin);
/*     */     }
/* 330 */     if ((StringUtils.isNotBlank(userRole.getBeginDeleteTime())) && (StringUtils.isNotBlank(userRole.getEndDeleteTime()))) {
/* 331 */       sb.append(" and role.deleteTime >= '").append(userRole.getBeginDeleteTime()).append("'");
/* 332 */       sb.append(" and role.deleteTime <= '").append(userRole.getEndDeleteTime()).append("'");
/*     */     }
/* 334 */     return sb;
/*     */   }
/*     */ 
/*     */   public List<UserRole> getRoleListByName(String roleName) {
/* 338 */     List list = getHibernateTemplate().find(" from UserRole ur where ur.roleName='" + roleName + "'");
/* 339 */     return list;
/*     */   }
/*     */ 
/*     */   public void doRealDeleteByCreateGroup(DeletedParameterVO paraObject) {
/* 343 */     this.log.debug("in doRealDeleteByCreateGroup ");
/*     */     try {
/* 345 */       StringBuilder hql = new StringBuilder(256);
/* 346 */       hql.append("select role from UserRole role ,User_Group userGroup");
/* 347 */       hql.append(" where userGroup.groupid=role.createGroup ");
/* 348 */       hql.append(paraObject.getWhereHql("groupid", paraObject, "userGroup"));
/*     */ 
/* 350 */       this.log.debug("--deleteHql:" + hql);
/*     */ 
/* 352 */       List list = getHibernateTemplate().find(hql.toString());
/* 353 */       getHibernateTemplate().deleteAll(list);
/* 354 */       this.log.debug("end doRealDeleteByCreateGroup ");
/*     */     } catch (DataAccessException e) {
/* 356 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupRoleFail") + "", e);
/* 357 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupRoleFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List doRealDelete(DeletedParameterVO vo)
/*     */   {
/* 365 */     this.log.debug("in doRealDelete ");
/*     */     try {
/* 367 */       StringBuilder hql = new StringBuilder(256);
/* 368 */       hql.append("from UserRole role where 1=1 and role.status=").append("2").append(" ");
/* 369 */       hql.append(vo.getWhereHql("roleId", vo, "role"));
/*     */ 
/* 371 */       this.log.debug("--deleteHql:" + hql);
/* 372 */       Collection roles = getHibernateTemplate().find(hql.toString());
/* 373 */       StringBuilder roleIds = new StringBuilder(256);
/* 374 */       StringBuilder roleNames = new StringBuilder(256);
/* 375 */       for (UserRole role : roles) {
/* 376 */         roleIds.append(role.getRoleId()).append(",");
/* 377 */         roleNames.append(role.getRoleName()).append(",");
/*     */       }
/*     */ 
/* 381 */       if (roleIds.length() > 0) roleIds.deleteCharAt(roleIds.lastIndexOf(","));
/* 382 */       if (roleNames.length() > 0) roleNames.deleteCharAt(roleNames.lastIndexOf(","));
/*     */ 
/* 384 */       List roleList = getHibernateTemplate().find(hql.toString());
/* 385 */       getHibernateTemplate().deleteAll(roleList);
/* 386 */       this.log.debug("end doRealDelete ");
/* 387 */       List list = new ArrayList();
/* 388 */       list.add(roleIds);
/* 389 */       list.add(roleNames);
/* 390 */       return list;
/*     */     } catch (DataAccessException e) {
/* 392 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRoleFail") + "", e);
/* 393 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRoleFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/* 397 */   public List getUserRoleByTime(String startTime, String endTime) { String strCond = "";
/* 398 */     String hSql = "from UserRole userrole where 1=1" + strCond;
/*     */ 
/* 400 */     if (StringUtils.isNotEmpty(startTime)) {
/* 401 */       hSql = hSql + " and userrole.createTime >= ?";
/*     */     }
/* 403 */     if (StringUtils.isNotEmpty(endTime)) {
/* 404 */       hSql = hSql + " and userrole.createTime <= ?";
/*     */     }
/*     */ 
/* 407 */     List roleList = getHibernateTemplate().find(hSql, new Object[] { DateUtil.string2Date(startTime), DateUtil.string2Date(endTime) });
/* 408 */     return roleList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserRoleDaoImpl
 * JD-Core Version:    0.6.2
 */
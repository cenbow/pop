/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.model.UserRoleMap;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleMapDAO;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserRoleMapDaoImpl extends HibernateDaoSupport
/*     */   implements IUserRoleMapDAO
/*     */ {
/*  19 */   private static final Log log = LogFactory.getLog(UserRoleMapDaoImpl.class);
/*     */ 
/*     */   public void save(UserRoleMap transientInstance) {
/*  22 */     log.debug("saving UserRoleMap instance");
/*  23 */     UserRoleMap realMap = (UserRoleMap)getHibernateTemplate().get(UserRoleMap.class, transientInstance);
/*  24 */     if (realMap == null) getHibernateTemplate().save(transientInstance);
/*  25 */     log.debug("save successful");
/*     */   }
/*     */ 
/*     */   public void delete(UserRoleMap mockMap)
/*     */   {
/*  30 */     log.debug("delete UserRoleMap instance");
/*  31 */     UserRoleMap realMap = (UserRoleMap)getHibernateTemplate().get(UserRoleMap.class, mockMap);
/*  32 */     if (realMap != null) getHibernateTemplate().delete(realMap);
/*  33 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapByRId(String Rid)
/*     */   {
/*  39 */     log.debug("delete UserRoleMap instance");
/*     */ 
/*  41 */     List list = findAllByRId(Rid);
/*  42 */     if ((list != null) && (list.size() > 0)) {
/*  43 */       getHibernateTemplate().deleteAll(list);
/*     */     }
/*  45 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapByUserId(String userId)
/*     */   {
/*  51 */     log.debug("delete UserGroupMap userId=" + userId);
/*     */ 
/*  53 */     List list = getUserRoleMapsByUserId(userId);
/*  54 */     if ((list != null) && (list.size() > 0)) {
/*  55 */       getHibernateTemplate().deleteAll(list);
/*     */     }
/*  57 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapList(List userGroupMap)
/*     */   {
/*  62 */     log.debug("delete UserGroupMap List=" + userGroupMap);
/*     */ 
/*  65 */     if ((userGroupMap != null) && (userGroupMap.size() > 0)) {
/*  66 */       getHibernateTemplate().deleteAll(userGroupMap);
/*     */     }
/*  68 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public List<UserRoleMap> findAllByRId(String Rid)
/*     */   {
/*  73 */     log.debug("findAllByRId UserRoleMap groupid = " + Rid);
/*  74 */     List urmap = getHibernateTemplate().find("from UserRoleMap urm where urm.roleId = '" + Rid + "'");
/*  75 */     return urmap;
/*     */   }
/*     */ 
/*     */   public List<UserRoleMap> getUserRoleMapsByUserId(String userId) {
/*  79 */     log.debug("findAllByRId UserRoleMap userid = " + userId);
/*  80 */     List urmap = getHibernateTemplate().find("from UserRoleMap urm where urm.userid = '" + userId + "'");
/*  81 */     return urmap;
/*     */   }
/*     */ 
/*     */   public List<UserRole> getRolesByUserId(String userId) {
/*  85 */     String sql = "select ur from UserRoleMap urm,UserRole ur where ur.status=0 and urm.roleId=ur.roleId and urm.userid = '" + userId + "'";
/*     */ 
/*  87 */     List urmap = getHibernateTemplate().find(sql);
/*  88 */     return urmap;
/*     */   }
/*     */   public List<User_User> getUsersByRoleId(String roleId) {
/*  91 */     String sql = "select us from UserRoleMap urm,User_User us where us.status<>2 and urm.userid=us.userid and urm.roleId = '" + roleId + "'";
/*     */ 
/*  93 */     List urmap = getHibernateTemplate().find(sql);
/*  94 */     return urmap;
/*     */   }
/*     */ 
/*     */   public UserRoleMap getById(UserRoleMap key)
/*     */   {
/* 101 */     return (UserRoleMap)getHibernateTemplate().get(UserRoleMap.class, key);
/*     */   }
/*     */ 
/*     */   public void delete(DeletedParameterVO paraObject)
/*     */   {
/* 110 */     log.debug("in delete(DeletedParameterVO paraObject)");
/*     */     try {
/* 112 */       StringBuilder hql = new StringBuilder(256);
/* 113 */       hql.append(" from UserRoleMap roleMap where 1=1 ");
/* 114 */       hql.append(paraObject.getWhereHql("userid", paraObject, "roleMap"));
/* 115 */       log.debug("--deleteHql:" + hql);
/* 116 */       List list = getHibernateTemplate().find(hql.toString());
/* 117 */       getHibernateTemplate().deleteAll(list);
/* 118 */       log.debug("end delete(DeletedParameterVO paraObject)");
/*     */     } catch (DataAccessException e) {
/* 120 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRoleUserMapFail") + "", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserRoleMapDaoImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.model.UserUserBak;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.DES;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserUserDaoImpl extends HibernateDaoSupport
/*     */   implements IUserUserDAO
/*     */ {
/*  42 */   private static final Log log = LogFactory.getLog(UserUserDaoImpl.class);
/*     */ 
/*     */   public void save(User_User user) throws Exception {
/*  45 */     log.debug("saving User_User instance");
/*  46 */     getHibernateTemplate().save(user);
/*  47 */     log.debug("save successful");
/*     */   }
/*     */ 
/*     */   public void update(User_User user) throws Exception {
/*  51 */     log.debug("saving User_User instance");
/*  52 */     log.debug("**********dao update:" + user.getUserid() + " cityid:" + user.getCityid());
/*  53 */     getHibernateTemplate().update(user);
/*  54 */     log.debug("save successful");
/*     */   }
/*     */ 
/*     */   public void delete(User_User user) throws Exception {
/*  58 */     log.debug("deleting User_User instance");
/*  59 */     getHibernateTemplate().delete(findById(user.getUserid()));
/*  60 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public User_User findById(String id) {
/*  64 */     log.debug("getting User_User instance with id: " + id);
/*  65 */     if (id == null) {
/*  66 */       return null;
/*     */     }
/*  68 */     User_User instance = (User_User)getHibernateTemplate().get(User_User.class, id);
/*  69 */     if (null != instance) {
/*  70 */       log.debug("**** findById11:" + instance.getUserid() + " pwd:" + instance.getPwd());
/*  71 */       if (StringUtils.isNotBlank(instance.getPwd())) {
/*     */         try {
/*  73 */           instance.setDesPwd(DES.decrypt(instance.getPwd()));
/*     */         } catch (Exception e) {
/*  75 */           instance.setDesPwd("");
/*     */         }
/*     */       }
/*  78 */       log.debug("**** findById:" + instance.getUserid() + " pwd:" + instance.getPwd());
/*     */     }
/*  80 */     return instance;
/*     */   }
/*     */ 
/*     */   public List findByName(String userName) {
/*  84 */     log.debug("findByName........");
/*  85 */     List list = getHibernateTemplate().find("from User_User user where user.username='" + userName + "'");
/*  86 */     log.debug("list.size=" + list.size());
/*  87 */     return list;
/*     */   }
/*     */ 
/*     */   public List findByDutyId(int dutyid)
/*     */   {
/*  92 */     log.debug("findByDutyId........");
/*  93 */     String sql = "from User_User user where user.dutyid= " + dutyid + " and user.status=" + "0";
/*  94 */     List list = getHibernateTemplate().find(sql);
/*  95 */     log.debug("list.size=" + list.size());
/*  96 */     return list;
/*     */   }
/*     */ 
/*     */   public List<User_User> findAll(final SearchCondition condition) {
/* 100 */     log.debug("--------------in UserUserDaoImpl.findAll()..........");
/* 101 */     List list = new ArrayList();
/*     */     try {
/* 103 */       String strCondSql = getConditionSql(condition);
/* 104 */       final String strCond = getConditionSqlAdd(condition, strCondSql);
/*     */ 
/* 106 */       final String groupIds = condition.getQueryGroupids();
/* 107 */       String listSql = "from User_User as user" + strCond;
/* 108 */       if ((groupIds != null) && (groupIds.trim().length() > 0)) {
/* 109 */         listSql = "select user from User_User user, UserGroupMap groupMap " + strCond;
/*     */       }
/* 111 */       log.debug("--findAll:sql:" + listSql);
/*     */ 
/* 113 */       List resultList = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session s)
/*     */           throws HibernateException, SQLException
/*     */         {
/* 118 */           String listSql = "from User_User as user" + strCond + " order by user.username ";
/*     */ 
/* 121 */           if ((groupIds != null) && (groupIds.trim().length() > 0)) {
/* 122 */             listSql = "select user from User_User user, UserGroupMap groupMap " + strCond + " order by user.username ";
/*     */           }
/*     */ 
/* 125 */           UserUserDaoImpl.log.info("----listSql=" + listSql);
/* 126 */           Query query = s.createQuery(listSql);
/* 127 */           UserUserDaoImpl.this.setQueryParameter(condition, query);
/* 128 */           List tmpList = query.list();
/* 129 */           return tmpList;
/*     */         }
/*     */       });
/* 132 */       for (i$ = resultList.iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 133 */         list.add((User_User)o);
/*     */       }
/*     */     }
/*     */     catch (RuntimeException ex)
/*     */     {
/*     */       Iterator i$;
/* 136 */       throw ex;
/*     */     }
/*     */ 
/* 139 */     log.debug("-----------------list.size=" + list.size());
/* 140 */     return list;
/*     */   }
/*     */ 
/*     */   public Map getPagedUserList(final SearchCondition condition, final int currpage, final int pagesize) {
/* 144 */     log.debug("in getPagedUserList........");
/* 145 */     HashMap map = new HashMap();
/*     */     try {
/* 147 */       String strCondSql = getConditionSql(condition);
/* 148 */       final String strCond = getConditionSqlAdd(condition, strCondSql);
/*     */ 
/* 151 */       final String groupIds = condition.getQueryGroupids();
/* 152 */       Long totals = (Long)getHibernateTemplate().execute(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session s)
/*     */           throws HibernateException, SQLException
/*     */         {
/* 157 */           String countSql = "select count(user) from User_User user" + strCond;
/*     */ 
/* 159 */           if ((groupIds != null) && (groupIds.trim().length() > 0)) {
/* 160 */             countSql = "select count(user) from User_User user, UserGroupMap groupMap " + strCond;
/*     */           }
/*     */ 
/* 163 */           UserUserDaoImpl.log.info("----totals:" + countSql);
/* 164 */           Query query = s.createQuery(countSql);
/* 165 */           UserUserDaoImpl.this.setQueryParameter(condition, query);
/* 166 */           List list = query.list();
/* 167 */           if (CollectionUtils.isNotEmpty(list)) {
/* 168 */             return (Long)list.get(0);
/*     */           }
/* 170 */           return Integer.valueOf(0);
/*     */         }
/*     */       });
/* 176 */       List list = getHibernateTemplate().executeFind(new HibernateCallback()
/*     */       {
/*     */         public Object doInHibernate(Session s)
/*     */           throws HibernateException, SQLException
/*     */         {
/* 181 */           String listSql = "from User_User as user" + strCond + " order by user.username ";
/*     */ 
/* 184 */           if ((groupIds != null) && (groupIds.trim().length() > 0)) {
/* 185 */             listSql = "select user from User_User user, UserGroupMap groupMap " + strCond + " order by user.username ";
/*     */           }
/*     */ 
/* 188 */           UserUserDaoImpl.log.info("----listSql=" + listSql);
/* 189 */           Query query = s.createQuery(listSql);
/* 190 */           UserUserDaoImpl.this.setQueryParameter(condition, query);
/* 191 */           int firstResult = (currpage - 1) * pagesize;
/* 192 */           int maxResult = pagesize;
/* 193 */           query.setFirstResult(firstResult);
/* 194 */           query.setMaxResults(maxResult);
/* 195 */           List tmpList = query.list();
/* 196 */           return tmpList;
/*     */         }
/*     */       });
/* 199 */       map.put("total", totals);
/* 200 */       map.put("result", list);
/*     */     } catch (RuntimeException ex) {
/* 202 */       map.put("total", new Integer(0));
/* 203 */       map.put("result", new ArrayList());
/* 204 */       throw ex;
/*     */     }
/* 206 */     return map;
/*     */   }
/*     */ 
/*     */   private String getConditionSql(SearchCondition condition)
/*     */   {
/* 215 */     String sql = " where 1=1";
/* 216 */     if ((condition.getQueryUserid() != null) && (condition.getQueryUserid().trim().length() > 0)) {
/* 217 */       sql = sql + " and user.userid like '%" + condition.getQueryUserid() + "%'";
/*     */     }
/* 219 */     if ((condition.getQueryUsername() != null) && (condition.getQueryUsername().trim().length() > 0)) {
/* 220 */       sql = sql + " and user.username like '%" + condition.getQueryUsername() + "%'";
/*     */     }
/* 222 */     if ((StringUtils.isNotBlank(condition.getQueryCityid())) && (!"-1".equalsIgnoreCase(condition.getQueryCityid()))) {
/* 223 */       sql = sql + " and user.cityid='" + condition.getQueryCityid() + "'";
/*     */     }
/*     */ 
/* 226 */     if ((condition.getQueryDutyid() != null) && (condition.getQueryDutyid().intValue() > 0)) {
/* 227 */       sql = sql + " and user.dutyid=" + condition.getQueryDutyid() + "";
/*     */     }
/*     */ 
/* 231 */     if (condition.getQueryDepartmentid() > 0) {
/* 232 */       sql = sql + " and user.departmentid=" + condition.getQueryDepartmentid();
/*     */     }
/* 234 */     if (condition.getQueryStatus() != -1) {
/* 235 */       sql = sql + " and user.status=" + condition.getQueryStatus();
/*     */     }
/* 237 */     if ((condition.getQueryUserids() != null) && (condition.getQueryUserids().trim().length() > 0)) {
/* 238 */       String sqlin = "";
/* 239 */       String roles = "";
/* 240 */       String[] strRolesArry = condition.getQueryUserids().split(",");
/* 241 */       int cnt = 1;
/* 242 */       if (strRolesArry.length > 1000) {
/* 243 */         int nDeep = 0;
/* 244 */         for (int i = 0; i < strRolesArry.length; i++) {
/* 245 */           roles = roles + strRolesArry[i] + ",";
/* 246 */           cnt++;
/* 247 */           if (cnt > 1000) {
/* 248 */             if (nDeep == 0)
/* 249 */               sqlin = sqlin + " and (";
/* 250 */             if (nDeep > 0)
/* 251 */               sqlin = sqlin + " or ";
/* 252 */             sqlin = sqlin + "  user.userid in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/* 253 */             roles = "";
/* 254 */             cnt = 1;
/* 255 */             nDeep++;
/*     */           }
/*     */         }
/* 258 */         if (roles.length() > 0) {
/* 259 */           if (nDeep == 0)
/* 260 */             sqlin = sqlin + " and (";
/* 261 */           if (nDeep > 0)
/* 262 */             sqlin = sqlin + " or ";
/* 263 */           sqlin = sqlin + " user.userid in(" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/*     */         }
/* 265 */         sqlin = sqlin + ")";
/*     */       }
/*     */       else {
/* 268 */         sqlin = " and user.userid in (" + condition.getQueryUserids() + ") ";
/*     */       }
/*     */ 
/* 271 */       sql = sql + sqlin;
/*     */     }
/*     */ 
/* 274 */     if ((condition.getQueryGroupids() != null) && (condition.getQueryGroupids().trim().length() > 0)) {
/* 275 */       String sqlin = "";
/* 276 */       String roles = "";
/* 277 */       String[] strRolesArry = condition.getQueryGroupids().split(",");
/* 278 */       int cnt = 1;
/* 279 */       if (strRolesArry.length > 1000) {
/* 280 */         int nDeep = 0;
/* 281 */         for (int i = 0; i < strRolesArry.length; i++) {
/* 282 */           roles = roles + strRolesArry[i] + ",";
/* 283 */           cnt++;
/* 284 */           if (cnt > 1000) {
/* 285 */             if (nDeep == 0)
/* 286 */               sqlin = sqlin + " and (";
/* 287 */             if (nDeep > 0)
/* 288 */               sqlin = sqlin + " or ";
/* 289 */             sqlin = sqlin + "  groupMap.groupId in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/* 290 */             roles = "";
/* 291 */             cnt = 1;
/* 292 */             nDeep++;
/*     */           }
/*     */         }
/* 295 */         if (roles.length() > 0) {
/* 296 */           if (nDeep == 0)
/* 297 */             sqlin = sqlin + " and (";
/* 298 */           if (nDeep > 0)
/* 299 */             sqlin = sqlin + " or ";
/* 300 */           sqlin = sqlin + " groupMap.groupId in(" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/*     */         }
/* 302 */         sqlin = sqlin + ")";
/*     */       }
/*     */       else {
/* 305 */         sqlin = " and groupMap.groupId in (" + condition.getQueryGroupids() + ") ";
/*     */       }
/* 307 */       sql = sql + " and user.userid=groupMap.userid " + sqlin;
/*     */     }
/*     */ 
/* 310 */     if ((condition.getBeginDeleteTime() != null) && (condition.getEndDeleteTime() == null)) {
/* 311 */       sql = sql + " and user.deleteTime >= '" + condition.getBeginDeleteTime() + "'";
/*     */     }
/* 313 */     if ((condition.getBeginDeleteTime() == null) && (condition.getEndDeleteTime() != null)) {
/* 314 */       sql = sql + " and user.deleteTime <= '" + condition.getEndDeleteTime() + "'";
/*     */     }
/*     */ 
/* 318 */     if ((condition.getBeginDeleteTime() != null) && (condition.getEndDeleteTime() != null)) {
/* 319 */       sql = sql + " and user.deleteTime >= '" + condition.getBeginDeleteTime() + "'";
/* 320 */       sql = sql + " and user.deleteTime <= '" + condition.getEndDeleteTime() + "'";
/*     */     }
/*     */ 
/* 323 */     return sql;
/*     */   }
/*     */ 
/*     */   private String getConditionSqlAdd(SearchCondition condition, String sql) {
/* 327 */     if (StringUtils.isNotEmpty(condition.getBeginCreateTime())) {
/* 328 */       sql = sql + " and user.createtime >= ?";
/*     */     }
/* 330 */     if (StringUtils.isNotEmpty(condition.getEndCreateTime())) {
/* 331 */       sql = sql + " and user.createtime <= ?";
/*     */     }
/* 333 */     return sql;
/*     */   }
/*     */ 
/*     */   private void setQueryParameter(SearchCondition condition, Query query) {
/* 337 */     int index = -1;
/* 338 */     if (StringUtils.isNotEmpty(condition.getBeginCreateTime())) {
/* 339 */       index += 1;
/* 340 */       query.setTimestamp(index, DateUtil.string2Date(condition.getBeginCreateTime() + " 00:00:00"));
/*     */     }
/* 342 */     if (StringUtils.isNotEmpty(condition.getEndCreateTime())) {
/* 343 */       index += 1;
/* 344 */       query.setTimestamp(index, DateUtil.string2Date(condition.getEndCreateTime() + " 23:59:59"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isSysUser(String userId)
/*     */   {
/* 356 */     User_User user = getSysUserInfo(userId);
/* 357 */     if (user == null) {
/* 358 */       return false;
/*     */     }
/* 360 */     return true;
/*     */   }
/*     */ 
/*     */   public List<IUser> listUsers()
/*     */   {
/* 369 */     String sql = "from User_User user where user.status=0 order by user.username";
/* 370 */     List _users = getHibernateTemplate().find(sql);
/* 371 */     return _users;
/*     */   }
/*     */ 
/*     */   public User_User getSysUserInfo(String userId)
/*     */   {
/* 381 */     if (userId == null) {
/* 382 */       return null;
/*     */     }
/* 384 */     return (User_User)getHibernateTemplate().get(User_User.class, userId);
/*     */   }
/*     */ 
/*     */   public boolean isSameSysUserName(String userName)
/*     */   {
/*     */     try
/*     */     {
/* 395 */       List userlist = getHibernateTemplate().find("from User_User user where user.username='" + userName + "'");
/* 396 */       if ((userlist != null) && (userlist.size() > 0)) {
/* 397 */         return true;
/*     */       }
/* 399 */       return false;
/*     */     } catch (Exception e) {
/* 401 */       log.error("", e);
/* 402 */     }return false;
/*     */   }
/*     */ 
/*     */   public List listUsersOfDepart(int departId)
/*     */   {
/* 413 */     String sql = "from User_User user  where user.departmentid=" + departId + " and user.status=" + "0";
/* 414 */     List _users = getHibernateTemplate().find(sql);
/* 415 */     return _users;
/*     */   }
/*     */ 
/*     */   public String doRealDelete(DeletedParameterVO paraObject) {
/* 419 */     log.debug("in doRealDelete ");
/*     */     try {
/* 421 */       StringBuilder hql = new StringBuilder(256);
/* 422 */       hql.append("from User_User user where 1=1 ");
/* 423 */       hql.append(" and user.status=").append("2");
/* 424 */       hql.append(paraObject.getWhereHql("userid", paraObject, "user"));
/*     */ 
/* 426 */       log.debug("--deleteHql:" + hql);
/* 427 */       Collection users = getHibernateTemplate().find(hql.toString());
/* 428 */       StringBuilder userNames = new StringBuilder(256);
/* 429 */       for (User_User user : users) {
/* 430 */         userNames.append(user.getName()).append(",");
/*     */       }
/*     */ 
/* 433 */       if (userNames.length() > 0) userNames.deleteCharAt(userNames.lastIndexOf(","));
/*     */ 
/* 435 */       getHibernateTemplate().deleteAll(users);
/* 436 */       log.debug("end doRealDelete ");
/* 437 */       return userNames.toString();
/*     */     } catch (DataAccessException e) {
/* 439 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserInfoFail") + "", e);
/* 440 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserInfoFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateSensitiveLevel(List<String> userIdList, String sensitiveLevel)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/* 449 */       log.debug("in updateSensitiveLevel");
/* 450 */       for (String userId : userIdList) {
/* 451 */         User_User user = findById(userId);
/* 452 */         user.setSensitiveDataLevel(sensitiveLevel);
/* 453 */         getHibernateTemplate().update(user);
/*     */       }
/*     */ 
/* 456 */       log.debug("end updateSensitiveLevel");
/*     */     } catch (DataAccessException e) {
/* 458 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateUserSensitiveLevelFail") + "", e);
/* 459 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateUserSensitiveLevelFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void backupUser(String userid)
/*     */   {
/*     */     try {
/* 466 */       log.debug("in backupUser");
/* 467 */       User_User user = (User_User)getHibernateTemplate().get(User_User.class, userid);
/* 468 */       if (null != user) {
/* 469 */         UserUserBak uub = new UserUserBak();
/* 470 */         BeanUtils.copyProperties(uub, user);
/* 471 */         uub.setDeleteTime(DateUtil.getFormatCurrentTime("yyyy-MM-dd HH:mm:ss"));
/* 472 */         getHibernateTemplate().save(uub);
/*     */       }
/* 474 */       log.debug("end backupUser");
/*     */     } catch (Exception e) {
/* 476 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/* 480 */   public List getUserByTime(String startTime, String endTime) { String strCond = "";
/* 481 */     String hSql = "from User_User user where 1=1" + strCond;
/*     */ 
/* 483 */     if (StringUtils.isNotEmpty(startTime)) {
/* 484 */       hSql = hSql + " and user.createtime >= ?";
/*     */     }
/* 486 */     if (StringUtils.isNotEmpty(endTime)) {
/* 487 */       hSql = hSql + " and user.createtime <= ?";
/*     */     }
/*     */ 
/* 490 */     List userList = getHibernateTemplate().find(hSql, new Object[] { DateUtil.string2Date(startTime), DateUtil.string2Date(endTime) });
/* 491 */     return userList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserUserDaoImpl
 * JD-Core Version:    0.6.2
 */
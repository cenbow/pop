/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.model.UserUserExt;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserExtDAO;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserUserExtDaoImpl extends HibernateDaoSupport
/*     */   implements IUserUserExtDAO
/*     */ {
/*  34 */   private Log log = LogFactory.getLog(UserUserExtDaoImpl.class);
/*     */ 
/*     */   public void save(UserUserExt ext)
/*     */     throws Exception
/*     */   {
/*  41 */     this.log.debug("save UserUserExt instance");
/*     */     try {
/*  43 */       getHibernateTemplate().save(ext);
/*  44 */       this.log.debug("save UserUserExt successful");
/*     */     } catch (Exception e) {
/*  46 */       this.log.error("save UserUserExt failed", e);
/*  47 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void update(UserUserExt ext)
/*     */     throws Exception
/*     */   {
/*  56 */     this.log.debug("update UserUserExt instance");
/*     */     try {
/*  58 */       getHibernateTemplate().update(ext);
/*  59 */       this.log.debug("udpate UserUserExt successful");
/*     */     } catch (Exception e) {
/*  61 */       this.log.error("udpate UserUserExt failed", e);
/*  62 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete(UserUserExt ext)
/*     */     throws Exception
/*     */   {
/*  71 */     this.log.debug("delete UserUserExt instance");
/*     */     try
/*     */     {
/*  74 */       getHibernateTemplate().delete(ext);
/*     */ 
/*  76 */       this.log.debug("delete UserUserExt successful");
/*     */     } catch (Exception e) {
/*  78 */       this.log.error("delete UserUserExt failed", e);
/*  79 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public UserUserExt findById(String id)
/*     */   {
/*  88 */     this.log.debug("get UserUserExt instance with id: " + id);
/*     */     try
/*     */     {
/*  91 */       return (UserUserExt)getHibernateTemplate().get(UserUserExt.class, id);
/*     */     }
/*     */     catch (RuntimeException re)
/*     */     {
/*  97 */       this.log.error("get UserUserExt failed", re);
/*  98 */       throw re;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doRealDelete(DeletedParameterVO paraObject) {
/* 103 */     this.log.debug("in doRealDelete ");
/*     */     try {
/* 105 */       StringBuilder hql = new StringBuilder(256);
/* 106 */       hql.append("select ext from User_User user,UserUserExt ext ");
/* 107 */       hql.append(" where user.userid=ext.userid ");
/*     */ 
/* 109 */       hql.append(paraObject.getWhereHql("userid", paraObject, "user"));
/*     */ 
/* 111 */       this.log.debug("--deleteHql:" + hql);
/*     */ 
/* 113 */       List list = getHibernateTemplate().find(hql.toString());
/* 114 */       getHibernateTemplate().deleteAll(list);
/* 115 */       this.log.debug("end doRealDelete ");
/*     */     } catch (DataAccessException e) {
/* 117 */       this.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserExtFail"), e);
/* 118 */       throw new DaoException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserExtFail"), e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserUserExtDaoImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.model.UserUserMap;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserMapDAO;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserUserMapDaoImpl extends HibernateDaoSupport
/*     */   implements IUserUserMapDAO
/*     */ {
/*  27 */   private static final Log log = LogFactory.getLog(UserUserMapDaoImpl.class);
/*     */ 
/*     */   public void save(UserUserMap transientInstance) {
/*  30 */     log.debug("saving UserUserMap instance");
/*     */ 
/*  32 */     getHibernateTemplate().save(transientInstance);
/*  33 */     log.debug("save successful");
/*     */   }
/*     */ 
/*     */   public void delete(UserUserMap persistentInstance)
/*     */   {
/*  39 */     log.debug("delete UserUserMap instance");
/*     */ 
/*  41 */     getHibernateTemplate().delete(persistentInstance);
/*  42 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapByUId(String userId)
/*     */   {
/*  48 */     log.debug("delete UserUserMap instance");
/*     */ 
/*  50 */     UserUserMap uum = new UserUserMap();
/*  51 */     uum.setUserid(userId);
/*     */ 
/*  53 */     List list = findAllOrById(uum);
/*  54 */     if ((list != null) && (list.size() > 0)) {
/*  55 */       getHibernateTemplate().deleteAll(list);
/*     */     }
/*  57 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMappedByUId(String userId)
/*     */   {
/*  63 */     log.debug("delete UserUserMap Mapped instance");
/*     */ 
/*  65 */     UserUserMap uum = new UserUserMap();
/*  66 */     uum.setUserMapId(userId);
/*     */ 
/*  68 */     List list = findAllOrById(uum);
/*  69 */     if ((list != null) && (list.size() > 0)) {
/*  70 */       getHibernateTemplate().deleteAll(list);
/*     */     }
/*  72 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public void deleteMapList(List userUserMap)
/*     */   {
/*  77 */     log.debug("delete UserUserMap instance ");
/*     */ 
/*  79 */     if ((userUserMap != null) && (userUserMap.size() > 0)) {
/*  80 */       getHibernateTemplate().deleteAll(userUserMap);
/*     */     }
/*  82 */     log.debug("delete successful");
/*     */   }
/*     */ 
/*     */   public List<UserUserMap> findAllOrById(UserUserMap map)
/*     */   {
/*  87 */     log.debug("getting UserUserMap instance " + map.toString());
/*  88 */     String hql = " from UserUserMap uum where 1=1 ";
/*  89 */     if ((map.getUserid() != null) && (map.getUserid().length() > 0))
/*  90 */       hql = hql + " and uum.userid= '" + map.getUserid() + "'";
/*  91 */     if ((map.getUserMapId() != null) && (map.getUserMapId().length() > 0))
/*  92 */       hql = hql + " and uum.userMapId='" + map.getUserMapId() + "'";
/*  93 */     if (map.getResourcetype() > 0L)
/*  94 */       hql = hql + " and uum.resourcetype=" + map.getResourcetype();
/*  95 */     if (StringUtils.isNotBlank(map.getRelationType())) {
/*  96 */       hql = hql + " and uum.relationType='" + map.getRelationType() + "'";
/*     */     }
/*  98 */     log.debug("--hql:" + hql);
/*  99 */     List uumap = getHibernateTemplate().find(hql);
/* 100 */     return uumap;
/*     */   }
/*     */ 
/*     */   public List getDistinctResourceType(String userid) {
/* 104 */     String hql = "";
/* 105 */     if ((userid != null) && (userid.trim().length() > 0))
/* 106 */       hql = "select distinct map.resourcetype from UserUserMap map where userid='" + userid + "'";
/*     */     else {
/* 108 */       return new ArrayList();
/*     */     }
/*     */ 
/* 111 */     List uumap = getHibernateTemplate().find(hql);
/* 112 */     return uumap;
/*     */   }
/*     */ 
/*     */   public List<Long> getDistinctResourceType1(String userid)
/*     */   {
/* 119 */     String hql = "";
/* 120 */     if ((userid != null) && (userid.trim().length() > 0))
/* 121 */       hql = "select distinct map.resourcetype from UserUserMap map where userid='" + userid + "' or user_map_id='" + userid + "'";
/*     */     else {
/* 123 */       return new ArrayList();
/*     */     }
/*     */ 
/* 126 */     List uumap = getHibernateTemplate().find(hql);
/* 127 */     return uumap;
/*     */   }
/*     */ 
/*     */   public UserUserMap getByPK(UserUserMap map) {
/* 131 */     Object obj = getHibernateTemplate().get(UserUserMap.class, map);
/* 132 */     if (obj == null) {
/* 133 */       return null;
/*     */     }
/* 135 */     return (UserUserMap)obj;
/*     */   }
/*     */ 
/*     */   public List<User_User> getUsersByUserMap(String userId, int resourceType, String relationType)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/* 143 */       log.debug("in getUsersByUserMap");
/* 144 */       StringBuilder hql = new StringBuilder(256);
/* 145 */       hql.append("select uu from User_User uu,UserUserMap uum ");
/* 146 */       hql.append(" where uu.userid=uum.userMapId");
/* 147 */       hql.append(" and uum.userid='").append(userId).append("'");
/* 148 */       hql.append(" and uum.resourcetype=").append(resourceType);
/* 149 */       hql.append(" and uum.relationType='").append(relationType).append("'");
/*     */ 
/* 151 */       log.debug("--hql:" + hql);
/* 152 */       return getHibernateTemplate().find(hql.toString());
/*     */     } catch (DataAccessException e) {
/* 154 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryUserRelationFail") + "", e);
/* 155 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryUserRelationFail") + "", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserUserMapDaoImpl
 * JD-Core Version:    0.6.2
 */
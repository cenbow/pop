/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.Prefer_Define;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserPreferDefineDAO;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserUserPreferDefineDaoImpl extends HibernateDaoSupport
/*    */   implements IUserUserPreferDefineDAO
/*    */ {
/* 23 */   private static final Log log = LogFactory.getLog(Prefer_Define.class);
/*    */ 
/*    */   protected void initDao()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void save(Prefer_Define preferDefine) throws Exception
/*    */   {
/* 31 */     log.debug("saving User_Prefer instance");
/* 32 */     getHibernateTemplate().save(preferDefine);
/*    */   }
/*    */ 
/*    */   public void update(Prefer_Define preferDefine) throws Exception {
/* 36 */     log.debug("updating User_Prefer instance");
/* 37 */     getHibernateTemplate().update(preferDefine);
/*    */   }
/*    */ 
/*    */   public List findAll()
/*    */   {
/* 47 */     log.debug("findAll UserPrefer instance");
/* 48 */     List preferList = new ArrayList();
/* 49 */     preferList = getHibernateTemplate().find("from Prefer_Define pd order by  pd.sortNum asc");
/*    */ 
/* 51 */     return preferList;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserUserPreferDefineDaoImpl
 * JD-Core Version:    0.6.2
 */
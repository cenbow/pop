/*    */ package com.asiainfo.biframe.privilege.sysmanage.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.Prefer_Define;
/*    */ import com.asiainfo.biframe.privilege.model.User_Prefer;
/*    */ import com.asiainfo.biframe.privilege.model.User_PreferId;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserUserPreferDAO;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserUserUserPreferDaoImpl extends HibernateDaoSupport
/*    */   implements IUserUserUserPreferDAO
/*    */ {
/* 26 */   private static final Log log = LogFactory.getLog(User_Prefer.class);
/*    */ 
/*    */   public void save(String userId, String preferId, String preferValuedesc) throws Exception {
/* 29 */     log.debug("saving User_Prefer instance");
/* 30 */     String sql = " from User_Prefer pd where pd.id.userId='" + userId + "' and pd.id.preferId='" + preferId + "'";
/*    */ 
/* 32 */     List l = getHibernateTemplate().find(sql);
/* 33 */     if (l.size() > 0)
/*    */     {
/* 35 */       User_Prefer userPrefer = (User_Prefer)getHibernateTemplate().find(sql).get(0);
/*    */ 
/* 37 */       userPrefer.setPreferValuedesc(preferValuedesc);
/* 38 */       getHibernateTemplate().update(userPrefer);
/*    */     }
/*    */     else {
/* 41 */       String sql1 = " from Prefer_Define pd where pd.preferId='" + preferId + "'";
/* 42 */       Prefer_Define userPrefer = (Prefer_Define)getHibernateTemplate().find(sql1).get(0);
/*    */ 
/* 44 */       String preferName = userPrefer.getPreferName();
/* 45 */       String notes = userPrefer.getNotes();
/*    */ 
/* 47 */       User_Prefer up = new User_Prefer();
/* 48 */       User_PreferId upid = new User_PreferId();
/* 49 */       upid.setPreferId(preferId);
/* 50 */       upid.setUserId(userId);
/* 51 */       up.setId(upid);
/* 52 */       up.setPreferValue(preferName);
/* 53 */       up.setPreferValuedesc(preferValuedesc);
/* 54 */       up.setNotes(notes);
/*    */ 
/* 56 */       getHibernateTemplate().save(up);
/*    */     }
/*    */   }
/*    */ 
/*    */   public List findAll(String userID, String upID)
/*    */   {
/* 62 */     log.debug("findAll UserPrefer instance");
/* 63 */     return getHibernateTemplate().find("from User_Prefer pd where pd.id.userId='" + userID + "' and pd.id.preferId='" + upID + "'");
/*    */   }
/*    */ 
/*    */   public List<String> getPreferDescListByPreferType(String userID, String preferId)
/*    */   {
/* 69 */     log.debug("findAll UserPrefer instance");
/* 70 */     List preferList = getHibernateTemplate().find("from User_Prefer pd where pd.id.userId='" + userID + "' and pd.id.preferId='" + preferId + "'");
/* 71 */     Iterator iterator = preferList.iterator();
/* 72 */     List returnList = new ArrayList();
/* 73 */     User_Prefer userPrefer = null;
/* 74 */     while (iterator.hasNext()) {
/* 75 */       userPrefer = (User_Prefer)iterator.next();
/*    */     }
/*    */ 
/* 78 */     String[] strs = userPrefer.getPreferValuedesc().split(",");
/* 79 */     for (int i = 0; i < strs.length; i++) {
/* 80 */       returnList.add(strs[i]);
/*    */     }
/*    */ 
/* 83 */     return returnList;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.dao.impl.UserUserUserPreferDaoImpl
 * JD-Core Version:    0.6.2
 */
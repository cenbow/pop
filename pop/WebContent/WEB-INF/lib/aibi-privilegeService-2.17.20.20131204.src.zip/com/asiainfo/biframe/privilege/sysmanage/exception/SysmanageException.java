/*    */ package com.asiainfo.biframe.privilege.sysmanage.exception;
/*    */ 
/*    */ public class SysmanageException extends RuntimeException
/*    */ {
/*    */   public SysmanageException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SysmanageException(String arg0)
/*    */   {
/* 16 */     super(arg0);
/*    */   }
/*    */ 
/*    */   public SysmanageException(Throwable arg0) {
/* 20 */     super(arg0);
/*    */   }
/*    */ 
/*    */   public SysmanageException(String arg0, Throwable arg1) {
/* 24 */     super(arg0, arg1);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.sysmanage.form;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.IUserPreferForm;
/*    */ import org.apache.struts.action.ActionForm;
/*    */ 
/*    */ public class UserPreferForm extends ActionForm
/*    */   implements IUserPreferForm
/*    */ {
/*    */   private String userId;
/*    */   private String preferId;
/*    */   private String preferValue;
/*    */   private String preferValuedesc;
/*    */   private String notes;
/*    */   private String preferName;
/*    */   private String preferKey;
/*    */   private String preferKeyId;
/*    */   private String preferKeyValue;
/*    */   private long havePrivilege;
/*    */   private long sortNum;
/*    */   private String db;
/*    */ 
/*    */   public String getDb()
/*    */   {
/* 21 */     return this.db;
/*    */   }
/*    */   public void setDb(String db) {
/* 24 */     this.db = db;
/*    */   }
/*    */   public long getHavePrivilege() {
/* 27 */     return this.havePrivilege;
/*    */   }
/*    */   public void setHavePrivilege(long havePrivilege) {
/* 30 */     this.havePrivilege = havePrivilege;
/*    */   }
/*    */   public String getNotes() {
/* 33 */     return this.notes;
/*    */   }
/*    */   public void setNotes(String notes) {
/* 36 */     this.notes = notes;
/*    */   }
/*    */   public String getPreferId() {
/* 39 */     return this.preferId;
/*    */   }
/*    */   public void setPreferId(String preferId) {
/* 42 */     this.preferId = preferId;
/*    */   }
/*    */   public String getPreferKey() {
/* 45 */     return this.preferKey;
/*    */   }
/*    */   public void setPreferKey(String preferKey) {
/* 48 */     this.preferKey = preferKey;
/*    */   }
/*    */   public String getPreferKeyId() {
/* 51 */     return this.preferKeyId;
/*    */   }
/*    */   public void setPreferKeyId(String preferKeyId) {
/* 54 */     this.preferKeyId = preferKeyId;
/*    */   }
/*    */   public String getPreferKeyValue() {
/* 57 */     return this.preferKeyValue;
/*    */   }
/*    */   public void setPreferKeyValue(String preferKeyValue) {
/* 60 */     this.preferKeyValue = preferKeyValue;
/*    */   }
/*    */   public String getPreferName() {
/* 63 */     return this.preferName;
/*    */   }
/*    */   public void setPreferName(String preferName) {
/* 66 */     this.preferName = preferName;
/*    */   }
/*    */   public String getPreferValue() {
/* 69 */     return this.preferValue;
/*    */   }
/*    */   public void setPreferValue(String preferValue) {
/* 72 */     this.preferValue = preferValue;
/*    */   }
/*    */   public String getPreferValuedesc() {
/* 75 */     return this.preferValuedesc;
/*    */   }
/*    */   public void setPreferValuedesc(String preferValuedesc) {
/* 78 */     this.preferValuedesc = preferValuedesc;
/*    */   }
/*    */   public long getSortNum() {
/* 81 */     return this.sortNum;
/*    */   }
/*    */   public void setSortNum(long sortNum) {
/* 84 */     this.sortNum = sortNum;
/*    */   }
/*    */   public String getUserId() {
/* 87 */     return this.userId;
/*    */   }
/*    */   public void setUserId(String userId) {
/* 90 */     this.userId = userId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.form.UserPreferForm
 * JD-Core Version:    0.6.2
 */
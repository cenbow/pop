package com.asiainfo.biframe.privilege.sysmanage.model;

import com.asiainfo.biframe.privilege.base.vo.ReturnMsg;

public abstract interface IAuthPolicy
{
  public abstract ReturnMsg execute(LoginInfo paramLoginInfo);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.model.IAuthPolicy
 * JD-Core Version:    0.6.2
 */
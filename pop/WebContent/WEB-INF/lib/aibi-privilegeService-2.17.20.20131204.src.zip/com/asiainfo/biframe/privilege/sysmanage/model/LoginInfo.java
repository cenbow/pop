/*    */ package com.asiainfo.biframe.privilege.sysmanage.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class LoginInfo
/*    */   implements Serializable
/*    */ {
/*    */   private String userId;
/*    */   private String clientIp;
/*    */   private String userPwd;
/*    */ 
/*    */   public String getClientIp()
/*    */   {
/* 26 */     return this.clientIp;
/*    */   }
/*    */ 
/*    */   public void setClientIp(String clientIp) {
/* 30 */     this.clientIp = clientIp;
/*    */   }
/*    */ 
/*    */   public String getUserId() {
/* 34 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public void setUserId(String userId) {
/* 38 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   public String getUserPwd() {
/* 42 */     return this.userPwd;
/*    */   }
/*    */ 
/*    */   public void setUserPwd(String userPwd) {
/* 46 */     this.userPwd = userPwd;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.model.LoginInfo
 * JD-Core Version:    0.6.2
 */
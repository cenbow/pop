/*    */ package com.asiainfo.biframe.privilege.sysmanage.model;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.base.vo.ReturnMsg;
/*    */ import com.asiainfo.biframe.privilege.model.User_User;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class PasswordPolicy
/*    */   implements IAuthPolicy
/*    */ {
/* 15 */   private static Logger log = Logger.getLogger(PasswordPolicy.class);
/*    */ 
/*    */   public ReturnMsg execute(LoginInfo request) {
/* 18 */     log.info("in passwordPolicy");
/* 19 */     String userId = request.getUserId();
/* 20 */     String password = request.getUserPwd();
/*    */     try
/*    */     {
/* 23 */       IUserAdminService userService = (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/* 24 */       User_User user = userService.getUser(userId);
/* 25 */       if (user == null) {
/* 26 */         return new ReturnMsg(false, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.user") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.inputAgain"));
/*    */       }
/* 28 */       if (Integer.valueOf("0").intValue() != user.getStatus()) {
/* 29 */         return new ReturnMsg(false, LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.stateError"));
/*    */       }
/* 31 */       if (!userService.isSysUser(userId)) {
/* 32 */         return new ReturnMsg(false, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userOrPwdFail") + "");
/*    */       }
/* 34 */       if (!userService.isUserLegal(userId, password))
/* 35 */         return new ReturnMsg(false, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userOrPwdFail") + "");
/*    */     }
/*    */     catch (Exception e) {
/* 38 */       e.printStackTrace();
/*    */     }
/* 40 */     return new ReturnMsg(true, LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.pwdPass"));
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.model.PasswordPolicy
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.model;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserRight;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ @XmlRootElement
/*     */ public class Right
/*     */   implements Serializable, IUserRight
/*     */ {
/*     */   private String resourceId;
/*     */   private int resourceType;
/*     */   private String resourceName;
/*     */   private String parentId;
/*  31 */   private String topId = "-1";
/*  32 */   private boolean checked = false;
/*  33 */   private boolean hasCheckFrame = true;
/*     */   private boolean accessTypeChecked;
/*     */   private String operationType;
/*     */   private String operationName;
/*  38 */   private String rightId = "";
/*     */   private int roleType;
/*     */   private String parentIds;
/*  44 */   private boolean hasChildren = false;
/*     */ 
/*     */   public boolean isHasCheckFrame()
/*     */   {
/*  50 */     return this.hasCheckFrame;
/*     */   }
/*     */ 
/*     */   public void setHasCheckFrame(boolean hasCheckFrame)
/*     */   {
/*  57 */     this.hasCheckFrame = hasCheckFrame;
/*     */   }
/*     */ 
/*     */   public boolean isChecked()
/*     */   {
/*  64 */     return this.checked;
/*     */   }
/*     */ 
/*     */   public void setChecked(boolean checked)
/*     */   {
/*  71 */     this.checked = checked;
/*     */   }
/*     */ 
/*     */   public String getParentId()
/*     */   {
/*  78 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setParentId(String parentId)
/*     */   {
/*  85 */     this.parentId = parentId;
/*     */   }
/*     */ 
/*     */   public String getResourceId()
/*     */   {
/*  92 */     return this.resourceId;
/*     */   }
/*     */ 
/*     */   public void setResourceId(String resourceId)
/*     */   {
/*  99 */     this.resourceId = resourceId;
/*     */   }
/*     */ 
/*     */   public String getResourceName()
/*     */   {
/* 106 */     return this.resourceName;
/*     */   }
/*     */ 
/*     */   public void setResourceName(String resourceName)
/*     */   {
/* 113 */     this.resourceName = resourceName;
/*     */   }
/*     */ 
/*     */   public int getResourceType()
/*     */   {
/* 120 */     return this.resourceType;
/*     */   }
/*     */ 
/*     */   public void setResourceType(int resourceType)
/*     */   {
/* 127 */     this.resourceType = resourceType;
/*     */   }
/*     */ 
/*     */   public String getTopId()
/*     */   {
/* 134 */     return this.topId;
/*     */   }
/*     */ 
/*     */   public void setTopId(String topId)
/*     */   {
/* 141 */     this.topId = topId;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/*     */   }
/*     */ 
/*     */   public boolean isAccessTypeChecked() {
/* 148 */     return this.accessTypeChecked;
/*     */   }
/*     */ 
/*     */   public void setAccessTypeChecked(boolean accessTypeChecked) {
/* 152 */     this.accessTypeChecked = accessTypeChecked;
/*     */   }
/*     */ 
/*     */   public String getOperationType() {
/* 156 */     return this.operationType;
/*     */   }
/*     */ 
/*     */   public void setOperationType(String operationType) {
/* 160 */     this.operationType = operationType;
/*     */   }
/*     */ 
/*     */   public String getRightId() {
/* 164 */     return this.rightId;
/*     */   }
/*     */ 
/*     */   public void setRightId(String rightId) {
/* 168 */     this.rightId = rightId;
/*     */   }
/*     */ 
/*     */   public String getOperationName() {
/* 172 */     return this.operationName;
/*     */   }
/*     */ 
/*     */   public void setOperationName(String operationName) {
/* 176 */     this.operationName = operationName;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 182 */     if (this == other)
/* 183 */       return true;
/* 184 */     if (other == null)
/* 185 */       return false;
/* 186 */     if (!(other instanceof Right))
/* 187 */       return false;
/* 188 */     Right castOther = (Right)other;
/*     */ 
/* 190 */     EqualsBuilder eb = new EqualsBuilder();
/*     */ 
/* 193 */     eb.append(new Integer(getResourceType()), new Integer(castOther.getResourceType()));
/* 194 */     if (StringUtils.isNotBlank(getRightId())) {
/* 195 */       eb.append(getRightId(), castOther.getRightId());
/*     */     } else {
/* 197 */       eb.append(getResourceId(), castOther.getResourceId());
/* 198 */       eb.append(getOperationType(), castOther.getOperationType());
/*     */     }
/* 200 */     return eb.isEquals();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 206 */     HashCodeBuilder hb = new HashCodeBuilder();
/* 207 */     hb.append(new Integer(getResourceType()));
/* 208 */     if (StringUtils.isNotBlank(getRightId())) {
/* 209 */       hb.append(getRightId());
/*     */     } else {
/* 211 */       hb.append(getResourceId());
/* 212 */       hb.append(getOperationType());
/*     */     }
/* 214 */     return hb.toHashCode();
/*     */   }
/*     */ 
/*     */   public int getRoleType()
/*     */   {
/* 219 */     return this.roleType;
/*     */   }
/*     */ 
/*     */   public void setRoleType(int roleType) {
/* 223 */     this.roleType = roleType;
/*     */   }
/*     */ 
/*     */   public String getParentIds() {
/* 227 */     return this.parentIds;
/*     */   }
/*     */ 
/*     */   public void setParentIds(String parentIds) {
/* 231 */     this.parentIds = parentIds;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 236 */     StringBuilder sb = new StringBuilder(256);
/* 237 */     sb.append("[rightId=").append(getRightId()).append("]");
/* 238 */     sb.append("[resourceType=").append(getResourceType()).append("]");
/* 239 */     sb.append("[resourceId=").append(getResourceId()).append("]");
/* 240 */     sb.append("[resourceName=").append(getResourceName()).append("]");
/* 241 */     sb.append("[operationType=").append(getOperationType()).append("]");
/* 242 */     sb.append("[operationName=").append(getOperationName()).append("]");
/*     */ 
/* 244 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean isHasChildren() {
/* 248 */     return this.hasChildren;
/*     */   }
/*     */ 
/*     */   public void setHasChildren(boolean hasChildren) {
/* 252 */     this.hasChildren = hasChildren;
/*     */   }
/*     */   public Map toMap() {
/* 255 */     Map map = new HashMap();
/* 256 */     Map infoMap = new HashMap();
/* 257 */     infoMap.put("RIGHT_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.right") + "ID&" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleType") + "&" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resourceType") + "&" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resource") + "id&" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.operationType") + "", getRightId() + "&" + getRoleType() + "&" + getResourceType() + "&" + getResourceId() + "&" + getOperationType());
/*     */ 
/* 259 */     map.put("RIGHT", infoMap);
/* 260 */     return map;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.model.Right
 * JD-Core Version:    0.6.2
 */
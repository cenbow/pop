/*     */ package com.asiainfo.biframe.privilege.sysmanage.model;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ public class RoleRight
/*     */   implements Serializable
/*     */ {
/*     */   private String roleId;
/*     */   private Right right;
/*     */   private String controlType;
/*  28 */   private int operatorType = 0;
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  34 */     if (this == other)
/*  35 */       return true;
/*  36 */     if (other == null)
/*  37 */       return false;
/*  38 */     if (!(other instanceof RoleRight))
/*  39 */       return false;
/*  40 */     RoleRight castOther = (RoleRight)other;
/*     */ 
/*  43 */     return new EqualsBuilder().append(getRoleId(), castOther.getRoleId()).append(getRight(), castOther.getRight()).isEquals();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  53 */     return new HashCodeBuilder().append(getRoleId()).append(getRight()).toHashCode();
/*     */   }
/*     */ 
/*     */   public Map<String, Map<String, String>> toMap()
/*     */   {
/*  58 */     Map map = new HashMap();
/*  59 */     Map infoMap = new HashMap();
/*  60 */     infoMap.put("RESOURCEID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.resource") + "ID", getRight().getResourceId());
/*  61 */     infoMap.put("OPERATORID_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.role") + "ID", getRoleId());
/*  62 */     infoMap.put("RESOURCETYPE_" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleType") + "ID", String.valueOf(getRight().getResourceType()));
/*  63 */     map.put("RESOURCERIGHT", infoMap);
/*  64 */     return map;
/*     */   }
/*     */ 
/*     */   public String getRoleId() {
/*  68 */     return this.roleId;
/*     */   }
/*     */ 
/*     */   public void setRoleId(String roleId) {
/*  72 */     this.roleId = roleId;
/*     */   }
/*     */ 
/*     */   public Right getRight() {
/*  76 */     return this.right;
/*     */   }
/*     */ 
/*     */   public void setRight(Right right) {
/*  80 */     this.right = right;
/*     */   }
/*     */ 
/*     */   public String getControlType() {
/*  84 */     return this.controlType;
/*     */   }
/*     */ 
/*     */   public void setControlType(String controlType) {
/*  88 */     this.controlType = controlType;
/*     */   }
/*     */ 
/*     */   public int getOperatorType()
/*     */   {
/*  99 */     return this.operatorType;
/*     */   }
/*     */ 
/*     */   public void setOperatorType(int operatorType)
/*     */   {
/* 110 */     this.operatorType = operatorType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.model.RoleRight
 * JD-Core Version:    0.6.2
 */
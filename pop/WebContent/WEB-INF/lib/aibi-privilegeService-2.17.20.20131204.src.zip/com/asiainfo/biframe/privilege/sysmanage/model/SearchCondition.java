/*     */ package com.asiainfo.biframe.privilege.sysmanage.model;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public class SearchCondition
/*     */ {
/*     */   private String queryUserid;
/*     */   private String queryCityid;
/*     */   private Integer queryDutyid;
/*     */   private int queryDepartmentid;
/*     */   private String queryUsername;
/*     */   private String queryGroupId;
/*     */   private String queryGroupname;
/*     */   private String queryParentid;
/*     */   private String queryParentname;
/*  22 */   private int queryStatus = -1;
/*     */   private String queryRoleid;
/*  24 */   private String queryUserids = "";
/*     */   private Long queryGroupStatus;
/*     */   private Long queryGroupUserlimit;
/*     */   private Date queryGroupCreatetime;
/*     */   private Date queryGroupBegindate;
/*     */   private Date queryGroupEnddate;
/*     */   private String queryGroupids;
/*     */   private String beginDeleteTime;
/*     */   private String endDeleteTime;
/*     */   private String queryDutyName;
/*     */   private String queryCityIds;
/*     */   private String beginCreateTime;
/*     */   private String endCreateTime;
/*     */ 
/*     */   public String getQueryGroupids()
/*     */   {
/*  47 */     return this.queryGroupids;
/*     */   }
/*     */ 
/*     */   public void setQueryGroupids(String queryGroupids) {
/*  51 */     this.queryGroupids = queryGroupids;
/*     */   }
/*     */ 
/*     */   public String getQueryCityid() {
/*  55 */     return this.queryCityid;
/*     */   }
/*     */ 
/*     */   public void setQueryCityid(String queryCityid) {
/*  59 */     this.queryCityid = queryCityid;
/*     */   }
/*     */ 
/*     */   public int getQueryDepartmentid() {
/*  63 */     return this.queryDepartmentid;
/*     */   }
/*     */ 
/*     */   public void setQueryDepartmentid(int queryDepartmentid) {
/*  67 */     this.queryDepartmentid = queryDepartmentid;
/*     */   }
/*     */ 
/*     */   public String getQueryGroupId() {
/*  71 */     return this.queryGroupId;
/*     */   }
/*     */ 
/*     */   public void setQueryGroupId(String queryGroupId) {
/*  75 */     this.queryGroupId = queryGroupId;
/*     */   }
/*     */ 
/*     */   public String getQueryGroupname() {
/*  79 */     return this.queryGroupname;
/*     */   }
/*     */ 
/*     */   public void setQueryGroupname(String queryGroupname) {
/*  83 */     this.queryGroupname = queryGroupname;
/*     */   }
/*     */ 
/*     */   public String getQueryParentid() {
/*  87 */     return this.queryParentid;
/*     */   }
/*     */ 
/*     */   public void setQueryParentid(String queryParentid) {
/*  91 */     this.queryParentid = queryParentid;
/*     */   }
/*     */ 
/*     */   public String getQueryParentname() {
/*  95 */     return this.queryParentname;
/*     */   }
/*     */ 
/*     */   public void setQueryParentname(String queryParentname) {
/*  99 */     this.queryParentname = queryParentname;
/*     */   }
/*     */ 
/*     */   public int getQueryStatus() {
/* 103 */     return this.queryStatus;
/*     */   }
/*     */ 
/*     */   public void setQueryStatus(int queryStatus) {
/* 107 */     this.queryStatus = queryStatus;
/*     */   }
/*     */ 
/*     */   public String getQueryUserid() {
/* 111 */     return this.queryUserid;
/*     */   }
/*     */ 
/*     */   public void setQueryUserid(String queryUserid) {
/* 115 */     this.queryUserid = queryUserid;
/*     */   }
/*     */ 
/*     */   public String getQueryUserids() {
/* 119 */     return this.queryUserids;
/*     */   }
/*     */ 
/*     */   public void setQueryUserids(String queryUserids) {
/* 123 */     this.queryUserids = queryUserids;
/*     */   }
/*     */ 
/*     */   public String getQueryUsername() {
/* 127 */     return this.queryUsername;
/*     */   }
/*     */ 
/*     */   public void setQueryUsername(String queryUsername) {
/* 131 */     this.queryUsername = queryUsername;
/*     */   }
/*     */ 
/*     */   public String getQueryRoleid() {
/* 135 */     return this.queryRoleid;
/*     */   }
/*     */ 
/*     */   public void setQueryRoleid(String queryRoleid) {
/* 139 */     this.queryRoleid = queryRoleid;
/*     */   }
/*     */ 
/*     */   public Date getQueryGroupBegindate() {
/* 143 */     return this.queryGroupBegindate;
/*     */   }
/*     */ 
/*     */   public void setQueryGroupBegindate(Date queryGroupBegindate) {
/* 147 */     this.queryGroupBegindate = queryGroupBegindate;
/*     */   }
/*     */ 
/*     */   public Date getQueryGroupCreatetime() {
/* 151 */     return this.queryGroupCreatetime;
/*     */   }
/*     */ 
/*     */   public void setQueryGroupCreatetime(Date queryGroupCreatetime) {
/* 155 */     this.queryGroupCreatetime = queryGroupCreatetime;
/*     */   }
/*     */ 
/*     */   public Date getQueryGroupEnddate() {
/* 159 */     return this.queryGroupEnddate;
/*     */   }
/*     */ 
/*     */   public void setQueryGroupEnddate(Date queryGroupEnddate) {
/* 163 */     this.queryGroupEnddate = queryGroupEnddate;
/*     */   }
/*     */ 
/*     */   public Long getQueryGroupStatus()
/*     */   {
/* 169 */     return this.queryGroupStatus;
/*     */   }
/*     */ 
/*     */   public void setQueryGroupStatus(Long queryGroupStatus) {
/* 173 */     this.queryGroupStatus = queryGroupStatus;
/*     */   }
/*     */ 
/*     */   public Long getQueryGroupUserlimit() {
/* 177 */     return this.queryGroupUserlimit;
/*     */   }
/*     */ 
/*     */   public void setQueryGroupUserlimit(Long queryGroupUserlimit) {
/* 181 */     this.queryGroupUserlimit = queryGroupUserlimit;
/*     */   }
/*     */ 
/*     */   public Integer getQueryDutyid() {
/* 185 */     return this.queryDutyid;
/*     */   }
/*     */ 
/*     */   public void setQueryDutyid(Integer queryDutyid) {
/* 189 */     this.queryDutyid = queryDutyid;
/*     */   }
/*     */ 
/*     */   public String getBeginDeleteTime() {
/* 193 */     return this.beginDeleteTime;
/*     */   }
/*     */ 
/*     */   public void setBeginDeleteTime(String beginDeleteTime) {
/* 197 */     this.beginDeleteTime = beginDeleteTime;
/*     */   }
/*     */ 
/*     */   public String getEndDeleteTime() {
/* 201 */     return this.endDeleteTime;
/*     */   }
/*     */ 
/*     */   public void setEndDeleteTime(String endDeleteTime) {
/* 205 */     this.endDeleteTime = endDeleteTime;
/*     */   }
/*     */ 
/*     */   public String getQueryDutyName() {
/* 209 */     return this.queryDutyName;
/*     */   }
/*     */ 
/*     */   public void setQueryDutyName(String queryDutyName) {
/* 213 */     this.queryDutyName = queryDutyName;
/*     */   }
/*     */ 
/*     */   public String getQueryCityIds() {
/* 217 */     return this.queryCityIds;
/*     */   }
/*     */ 
/*     */   public void setQueryCityIds(String queryCityIds) {
/* 221 */     this.queryCityIds = queryCityIds;
/*     */   }
/*     */ 
/*     */   public String getBeginCreateTime()
/*     */   {
/* 226 */     return this.beginCreateTime;
/*     */   }
/*     */ 
/*     */   public void setBeginCreateTime(String beginCreateTime)
/*     */   {
/* 231 */     this.beginCreateTime = beginCreateTime;
/*     */   }
/*     */ 
/*     */   public String getEndCreateTime()
/*     */   {
/* 236 */     return this.endCreateTime;
/*     */   }
/*     */ 
/*     */   public void setEndCreateTime(String endCreateTime)
/*     */   {
/* 241 */     this.endCreateTime = endCreateTime;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition
 * JD-Core Version:    0.6.2
 */
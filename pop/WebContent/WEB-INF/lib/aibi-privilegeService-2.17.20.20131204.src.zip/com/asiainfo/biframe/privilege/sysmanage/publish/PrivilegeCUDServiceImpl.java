/*     */ package com.asiainfo.biframe.privilege.sysmanage.publish;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.IGroupRoleMap;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.privilege.IUserExt;
/*     */ import com.asiainfo.biframe.privilege.IUserGroup;
/*     */ import com.asiainfo.biframe.privilege.IUserPrivilegeCUDService;
/*     */ import com.asiainfo.biframe.privilege.IUserRole;
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.model.UserUserExt;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IFileDataImportService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IFileExportService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCompanyService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PrivilegeCUDServiceImpl
/*     */   implements IUserPrivilegeCUDService
/*     */ {
/*     */   private IUserAdminService userAdminService;
/*     */   private IUserGroupAdminService userGroupAdminService;
/*     */   private IRoleAdminService roleAdminService;
/*     */   private IUserCompanyService userCompanyService;
/*     */   private IFileDataImportService fileDataImportService;
/*     */   private IFileExportService fileExportService;
/*     */ 
/*     */   public void setFileExportService(IFileExportService fileExportService)
/*     */   {
/*  38 */     this.fileExportService = fileExportService;
/*     */   }
/*     */ 
/*     */   public void setFileDataImportService(IFileDataImportService fileDataImportService)
/*     */   {
/*  43 */     this.fileDataImportService = fileDataImportService;
/*     */   }
/*     */ 
/*     */   public void setUserCompanyService(IUserCompanyService userCompanyService)
/*     */   {
/*  48 */     this.userCompanyService = userCompanyService;
/*     */   }
/*     */ 
/*     */   public void setUserAdminService(IUserAdminService userAdminService)
/*     */   {
/*  53 */     this.userAdminService = userAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserGroupAdminService(IUserGroupAdminService userGroupAdminService)
/*     */   {
/*  58 */     this.userGroupAdminService = userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public void setRoleAdminService(IRoleAdminService roleAdminService) {
/*  62 */     this.roleAdminService = roleAdminService;
/*     */   }
/*     */ 
/*     */   public String createUser(IUser user, IUserExt userExt)
/*     */     throws ServiceException
/*     */   {
/*  76 */     User_User user_user = new User_User();
/*  77 */     if ((user instanceof User_User)) { user_user = (User_User)user;
/*     */     } else {
/*  79 */       user_user.setCityid(user.getCityid());
/*  80 */       user_user.setDepartmentid(user.getDepartmentid());
/*  81 */       user_user.setEmail(user.getEmail());
/*  82 */       user_user.setGroupId(user.getGroupId());
/*  83 */       user_user.setMobilePhone(user.getMobilePhone());
/*  84 */       user_user.setUsername(user.getUsername());
/*  85 */       user_user.setUserid(user.getUserid());
/*  86 */       user_user.setDutyid(user.getDutyid());
/*     */     }
/*     */ 
/*  89 */     String[] groupList = { user_user.getGroupId() };
/*  90 */     String param0 = userExt.getParam0();
/*  91 */     this.userAdminService.addUser(user_user, groupList, "" + user_user.getDepartmentid(), param0);
/*     */ 
/*  93 */     return user.getUserid();
/*     */   }
/*     */ 
/*     */   public void modifyUser(IUser user)
/*     */     throws ServiceException
/*     */   {
/* 102 */     this.userAdminService.updateUser((User_User)user);
/*     */   }
/*     */ 
/*     */   public void modifyUserExt(IUserExt userExt)
/*     */     throws ServiceException
/*     */   {
/* 110 */     this.userAdminService.updateUserExt((UserUserExt)userExt);
/*     */   }
/*     */ 
/*     */   public void deleteUser(String userId)
/*     */     throws ServiceException
/*     */   {
/* 117 */     User_User user = this.userAdminService.getUser(userId);
/* 118 */     this.userAdminService.deleteUser(user);
/*     */   }
/*     */ 
/*     */   public void realDeleteUser(String userId)
/*     */     throws ServiceException
/*     */   {
/* 126 */     DeletedParameterVO vo = new DeletedParameterVO();
/* 127 */     List idList = new ArrayList();
/* 128 */     idList.add(userId);
/* 129 */     vo.setIds(idList);
/* 130 */     vo.setIdString(true);
/* 131 */     this.userAdminService.doRealDeleteUser(vo);
/*     */   }
/*     */ 
/*     */   public void lockUser(String userId)
/*     */     throws ServiceException
/*     */   {
/* 139 */     User_User user = this.userAdminService.getUser(userId);
/* 140 */     user.setStatus(Integer.valueOf("1").intValue());
/* 141 */     this.userAdminService.updateUser(user);
/*     */   }
/*     */ 
/*     */   public void unlockUser(String userId)
/*     */     throws ServiceException
/*     */   {
/* 149 */     User_User user = this.userAdminService.getUser(userId);
/* 150 */     user.setStatus(Integer.valueOf("0").intValue());
/* 151 */     this.userAdminService.updateUser(user);
/*     */   }
/*     */ 
/*     */   public void modifyUserPw(IUser user, String param0)
/*     */     throws ServiceException
/*     */   {
/* 160 */     User_User newUser = (User_User)user;
/* 161 */     User_User u = this.userAdminService.getUser(newUser.getUserid());
/* 162 */     u.setDesPwd(newUser.getDesPwd());
/* 163 */     this.userAdminService.updateUserPwd(u, param0);
/*     */   }
/*     */ 
/*     */   public void modifyUserPwd(IUser user, String isRandomPwd, String operatorId)
/*     */     throws ServiceException
/*     */   {
/* 173 */     User_User newUser = (User_User)user;
/* 174 */     User_User u = this.userAdminService.getUser(newUser.getUserid());
/* 175 */     u.setDesPwd(newUser.getDesPwd());
/* 176 */     this.userAdminService.updateUserPwd(u, isRandomPwd, operatorId);
/*     */   }
/*     */ 
/*     */   public String createRole(IUserRole role)
/*     */     throws ServiceException
/*     */   {
/* 186 */     UserRole userRole = new UserRole();
/* 187 */     if ((role instanceof UserRole)) { userRole = (UserRole)role;
/*     */     } else {
/* 189 */       userRole.setRoleName(role.getRoleName());
/* 190 */       userRole.setRoleId(role.getRoleId());
/* 191 */       userRole.setParentId(role.getParentId());
/*     */     }
/* 193 */     return this.roleAdminService.addRole(userRole);
/*     */   }
/*     */ 
/*     */   public void modifyRole(IUserRole role)
/*     */     throws ServiceException
/*     */   {
/* 200 */     UserRole userRole = new UserRole();
/* 201 */     if ((role instanceof UserRole)) { userRole = (UserRole)role;
/*     */     } else {
/* 203 */       userRole.setRoleName(role.getRoleName());
/* 204 */       userRole.setRoleId(role.getRoleId());
/* 205 */       userRole.setParentId(role.getParentId());
/*     */     }
/* 207 */     this.roleAdminService.updateRole(userRole);
/*     */   }
/*     */ 
/*     */   public void deleteRole(String roleId)
/*     */     throws ServiceException
/*     */   {
/* 215 */     UserRole userRole = this.roleAdminService.getRoleById(roleId);
/* 216 */     this.roleAdminService.deleteRole(userRole);
/*     */   }
/*     */ 
/*     */   public void realDeleteRole(String roleId)
/*     */     throws ServiceException
/*     */   {
/* 224 */     DeletedParameterVO vo = new DeletedParameterVO();
/* 225 */     List idList = new ArrayList();
/* 226 */     idList.add(roleId);
/* 227 */     vo.setIds(idList);
/* 228 */     vo.setIdString(true);
/* 229 */     this.roleAdminService.doRealDeleteGroup(vo);
/*     */   }
/*     */ 
/*     */   public String createGroup(IUserGroup group)
/*     */     throws ServiceException
/*     */   {
/* 240 */     User_Group userGroup = new User_Group();
/* 241 */     if ((group instanceof User_Group)) { userGroup = (User_Group)group;
/*     */     } else {
/* 243 */       userGroup.setGroupname(group.getGroupname());
/* 244 */       userGroup.setParentid(group.getParentid());
/*     */     }
/* 246 */     return this.userGroupAdminService.addUserGroup(userGroup);
/*     */   }
/*     */ 
/*     */   public void modifyGroup(IUserGroup group)
/*     */     throws ServiceException
/*     */   {
/* 254 */     User_Group userGroup = new User_Group();
/* 255 */     if ((group instanceof User_Group)) { userGroup = (User_Group)group;
/*     */     } else {
/* 257 */       userGroup.setGroupname(group.getGroupname());
/* 258 */       userGroup.setParentid(group.getParentid());
/*     */     }
/* 260 */     this.userGroupAdminService.updateUserGroup(userGroup);
/*     */   }
/*     */ 
/*     */   public void deleteGroup(String groupId)
/*     */     throws ServiceException
/*     */   {
/* 268 */     User_Group usergroup = this.userGroupAdminService.getUserGroup(groupId);
/* 269 */     this.userGroupAdminService.deleteUserGroup(usergroup);
/*     */   }
/*     */ 
/*     */   public void realDeleteGroup(String groupId)
/*     */     throws ServiceException
/*     */   {
/* 277 */     DeletedParameterVO vo = new DeletedParameterVO();
/* 278 */     List idList = new ArrayList();
/* 279 */     idList.add(groupId);
/* 280 */     vo.setIds(idList);
/* 281 */     vo.setIdString(true);
/* 282 */     this.userGroupAdminService.doRealDeleteGroup(vo);
/*     */   }
/*     */ 
/*     */   public void saveGroupRoleMaps(List<IGroupRoleMap> list)
/*     */     throws ServiceException
/*     */   {
/* 292 */     this.userAdminService.saveGroupRoleMaps(list);
/*     */   }
/*     */ 
/*     */   public String createCompany(IUserCompany company)
/*     */     throws ServiceException
/*     */   {
/* 303 */     return this.userCompanyService.createCompany(company);
/*     */   }
/*     */ 
/*     */   public void modifyCompany(IUserCompany company)
/*     */     throws ServiceException
/*     */   {
/* 310 */     this.userCompanyService.modifyCompany(company);
/*     */   }
/*     */ 
/*     */   public void deleteCompany(String companyId)
/*     */     throws ServiceException
/*     */   {
/* 318 */     this.userCompanyService.deleteCompany(companyId);
/*     */   }
/*     */ 
/*     */   public void realDeleteCompany(String companyId)
/*     */     throws ServiceException
/*     */   {
/* 326 */     DeletedParameterVO vo = new DeletedParameterVO();
/* 327 */     List idList = new ArrayList();
/* 328 */     idList.add(companyId);
/* 329 */     vo.setIds(idList);
/* 330 */     vo.setIdString(false);
/* 331 */     this.userCompanyService.doRealDeleteGroup(vo);
/*     */   }
/*     */ 
/*     */   public void importUser(String filePath)
/*     */     throws ServiceException
/*     */   {
/* 342 */     this.fileDataImportService.doImportUserData(filePath);
/*     */   }
/*     */ 
/*     */   public void importGroup(String filePath)
/*     */     throws ServiceException
/*     */   {
/* 351 */     this.fileDataImportService.doImportGroupData(filePath);
/*     */   }
/*     */ 
/*     */   public void importRole(String filePath)
/*     */     throws ServiceException
/*     */   {
/* 360 */     this.fileDataImportService.doImportRoleData(filePath);
/*     */   }
/*     */ 
/*     */   public void importRight(String filePath)
/*     */     throws ServiceException
/*     */   {
/* 369 */     this.fileDataImportService.doImportRightsData(filePath);
/*     */   }
/*     */ 
/*     */   public void exportRightsData(PrintWriter pw, List<String> resourceTypeList)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 379 */       List tempList = new ArrayList();
/* 380 */       for (String typeStr : resourceTypeList) {
/* 381 */         int seperatorIndex = typeStr.indexOf("|");
/* 382 */         tempList.add(typeStr.substring(seperatorIndex + 1, typeStr.length()).trim() + "|" + typeStr.substring(0, seperatorIndex).trim());
/*     */       }
/* 384 */       this.fileExportService.exportRightsData(pw, tempList);
/*     */     } catch (Exception e) {
/* 386 */       throw new ServiceException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportMatrixMenuData(PrintWriter pw)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 396 */       this.fileExportService.exportMatrixMenuData(pw);
/*     */     } catch (Exception e) {
/* 398 */       throw new ServiceException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveUserRoleMap(String userId, List<String> addedRoleIdList, List<String> deletedRoleIdList) throws ServiceException
/*     */   {
/*     */     try {
/* 405 */       this.userAdminService.saveUserRoleMap(userId, addedRoleIdList, deletedRoleIdList);
/*     */     } catch (Exception e) {
/* 407 */       throw new ServiceException(e.getMessage());
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.publish.PrivilegeCUDServiceImpl
 * JD-Core Version:    0.6.2
 */
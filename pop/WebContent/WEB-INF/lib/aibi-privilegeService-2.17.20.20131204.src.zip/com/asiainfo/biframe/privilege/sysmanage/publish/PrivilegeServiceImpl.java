/*      */ package com.asiainfo.biframe.privilege.sysmanage.publish;
/*      */ 
/*      */ import com.asiainfo.biframe.exception.ServiceException;
/*      */ import com.asiainfo.biframe.log.LogInfo;
/*      */ import com.asiainfo.biframe.privilege.ICity;
/*      */ import com.asiainfo.biframe.privilege.IGroupRoleMap;
/*      */ import com.asiainfo.biframe.privilege.IMenuItem;
/*      */ import com.asiainfo.biframe.privilege.ISysResourceType;
/*      */ import com.asiainfo.biframe.privilege.IUser;
/*      */ import com.asiainfo.biframe.privilege.IUserApplication;
/*      */ import com.asiainfo.biframe.privilege.IUserCompany;
/*      */ import com.asiainfo.biframe.privilege.IUserDuty;
/*      */ import com.asiainfo.biframe.privilege.IUserGroup;
/*      */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*      */ import com.asiainfo.biframe.privilege.IUserRight;
/*      */ import com.asiainfo.biframe.privilege.IUserRightApply;
/*      */ import com.asiainfo.biframe.privilege.IUserRole;
/*      */ import com.asiainfo.biframe.privilege.base.constants.UserManager;
/*      */ import com.asiainfo.biframe.privilege.base.util.SpringUtil;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysMenuItemCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysMenuItemViewCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCompanyCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserGroupDefineCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserRoleCache;
/*      */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*      */ import com.asiainfo.biframe.privilege.menu.serivce.IUserApplicationService;
/*      */ import com.asiainfo.biframe.privilege.model.ResourceOperationDefine;
/*      */ import com.asiainfo.biframe.privilege.model.SysMenuItem;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*      */ import com.asiainfo.biframe.privilege.model.UserRightApply;
/*      */ import com.asiainfo.biframe.privilege.model.UserRole;
/*      */ import com.asiainfo.biframe.privilege.model.UserTempRight;
/*      */ import com.asiainfo.biframe.privilege.model.UserUserExt;
/*      */ import com.asiainfo.biframe.privilege.model.User_Company;
/*      */ import com.asiainfo.biframe.privilege.model.User_Group;
/*      */ import com.asiainfo.biframe.privilege.model.User_User;
/*      */ import com.asiainfo.biframe.privilege.pwdpolicy.service.PwdPolicyService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IFileDataImportService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IFileExportService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IResourceOperationDefineService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.ISysMenuItemService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.ISysResourceTypeService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCityService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCompanyService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserExtInfoService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.impl.ListService;
/*      */ import com.asiainfo.biframe.privilege.tempright.service.IUserTempRightService;
/*      */ import com.asiainfo.biframe.privilege.uniauth.service.IUserRightService;
/*      */ import com.asiainfo.biframe.utils.date.DateUtil;
/*      */ import com.asiainfo.biframe.utils.string.DES;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.collections.CollectionUtils;
/*      */ import org.apache.commons.lang.xwork.StringUtils;
/*      */ import org.apache.struts.util.LabelValueBean;
/*      */ 
/*      */ public class PrivilegeServiceImpl
/*      */   implements IUserPrivilegeService
/*      */ {
/*      */   private IUserAdminService userAdminService;
/*      */   private IUserGroupAdminService userGroupAdminService;
/*      */   private IRoleAdminService roleAdminService;
/*      */   private IUserApplicationService userApplicationService;
/*      */   private IUserRightService userRightService;
/*      */   private ISysMenuItemService sysMenuItemService;
/*      */   private IUserCityService userCityService;
/*      */   private IUserTempRightService userTempRightService;
/*      */   private IUserExtInfoService userExtInfoService;
/*      */   private IResourceOperationDefineService resourceOperationDefineService;
/*      */   private IFileDataImportService fileDataImportService;
/*      */   private IFileExportService fileExportService;
/*      */   private IUserCompanyService userCompanyService;
/*      */ 
/*      */   public IUserCityService getUserCityService()
/*      */   {
/*  151 */     return this.userCityService;
/*      */   }
/*      */ 
/*      */   public IFileDataImportService getFileDataImportService()
/*      */   {
/*  165 */     return this.fileDataImportService;
/*      */   }
/*      */   public IFileExportService getFileExportService() {
/*  168 */     return this.fileExportService;
/*      */   }
/*      */   public IUserCompanyService getUserCompanyService() {
/*  171 */     return this.userCompanyService;
/*      */   }
/*      */ 
/*      */   public void setFileDataImportService(IFileDataImportService fileDataImportService)
/*      */   {
/*  180 */     this.fileDataImportService = fileDataImportService;
/*      */   }
/*      */   public void setFileExportService(IFileExportService fileExportService) {
/*  183 */     this.fileExportService = fileExportService;
/*      */   }
/*      */   public void setUserCompanyService(IUserCompanyService userCompanyService) {
/*  186 */     this.userCompanyService = userCompanyService;
/*      */   }
/*      */   public void setUserCityService(IUserCityService userCityService) {
/*  189 */     this.userCityService = userCityService;
/*      */   }
/*      */   public ISysMenuItemService getSysMenuItemService() {
/*  192 */     return this.sysMenuItemService;
/*      */   }
/*      */   public void setSysMenuItemService(ISysMenuItemService sysMenuItemService) {
/*  195 */     this.sysMenuItemService = sysMenuItemService;
/*      */   }
/*      */   public IUserAdminService getUserAdminService() {
/*  198 */     return this.userAdminService;
/*      */   }
/*      */   public void setUserAdminService(IUserAdminService userAdminService) {
/*  201 */     this.userAdminService = userAdminService;
/*      */   }
/*      */   public IUserGroupAdminService getUserGroupAdminService() {
/*  204 */     return this.userGroupAdminService;
/*      */   }
/*      */   public void setUserGroupAdminService(IUserGroupAdminService userGroupAdminService) {
/*  207 */     this.userGroupAdminService = userGroupAdminService;
/*      */   }
/*      */   public IRoleAdminService getRoleAdminService() {
/*  210 */     return this.roleAdminService;
/*      */   }
/*      */   public void setRoleAdminService(IRoleAdminService roleAdminService) {
/*  213 */     this.roleAdminService = roleAdminService;
/*      */   }
/*      */   public IUserApplicationService getUserApplicationService() {
/*  216 */     return this.userApplicationService;
/*      */   }
/*      */   public void setUserApplicationService(IUserApplicationService userApplicationService) {
/*  219 */     this.userApplicationService = userApplicationService;
/*      */   }
/*      */   public void setUserRightService(IUserRightService userRightService) {
/*  222 */     this.userRightService = userRightService;
/*      */   }
/*      */   public IUserRightService getUserRightService() {
/*  225 */     return this.userRightService;
/*      */   }
/*      */   public IUserExtInfoService getUserExtInfoService() {
/*  228 */     return this.userExtInfoService;
/*      */   }
/*      */   public void setUserExtInfoService(IUserExtInfoService userExtInfoService) {
/*  231 */     this.userExtInfoService = userExtInfoService;
/*      */   }
/*      */ 
/*      */   public IUserTempRightService getUserTempRightService()
/*      */   {
/*  240 */     return this.userTempRightService;
/*      */   }
/*      */ 
/*      */   public void setUserTempRightService(IUserTempRightService userTempRightService)
/*      */   {
/*  250 */     this.userTempRightService = userTempRightService;
/*      */   }
/*      */ 
/*      */   public IResourceOperationDefineService getResourceOperationDefineService() {
/*  254 */     return this.resourceOperationDefineService;
/*      */   }
/*      */ 
/*      */   public void setResourceOperationDefineService(IResourceOperationDefineService resourceOperationDefineService) {
/*  258 */     this.resourceOperationDefineService = resourceOperationDefineService;
/*      */   }
/*      */ 
/*      */   public List<IUser> getMapUsers(String userId, int resourceType, String relationType) {
/*  262 */     return getUserAdminService().getUsersByUserMap(userId, resourceType, relationType);
/*      */   }
/*      */ 
/*      */   public List<IUserRight> getRight(String userId, int roleType, int resourceType)
/*      */   {
/*  269 */     return getUserAdminService().getRight(userId, roleType, resourceType, false);
/*      */   }
/*      */ 
/*      */   public List<IUserRight> getRightByOperation(String userId, int roleType, int resourceType, String operationType)
/*      */   {
/*  276 */     List rights = getUserAdminService().getRight(userId, roleType, resourceType, false);
/*  277 */     List returnRights = new ArrayList();
/*  278 */     if (StringUtil.isNotEmpty(operationType))
/*  279 */       for (IUserRight right : rights)
/*  280 */         if (operationType.equals(right.getOperationType()))
/*  281 */           returnRights.add(right);
/*      */     else
/*  283 */       returnRights = rights;
/*  284 */     return returnRights;
/*      */   }
/*      */ 
/*      */   public User_User getUser(String userId)
/*      */   {
/*  290 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(userId);
/*  291 */     if (user == null) {
/*  292 */       return getUserAdminService().getUser(userId);
/*      */     }
/*  294 */     return user;
/*      */   }
/*      */   public String getUserCurrentCity(String userid) {
/*  297 */     return getUserAdminService().getUserCurrentCity(userid);
/*      */   }
/*      */ 
/*      */   public String getUserDmCity(String userId, String dmType)
/*      */   {
/*  303 */     User_User user = getUser(userId);
/*  304 */     String userDmCity = getUserCityService().getDmCity(user.getCityid(), dmType);
/*  305 */     if (StringUtils.isNotBlank(userDmCity)) {
/*  306 */       return userDmCity;
/*      */     }
/*  308 */     return getUserAdminService().getUserDmCity(userId, dmType);
/*      */   }
/*      */ 
/*      */   public ICity getCityByDmCity(String dm_city_id, String dmType) throws ServiceException
/*      */   {
/*  313 */     ICity city = getUserCityService().getCityByDmCity(dm_city_id, dmType);
/*  314 */     return city;
/*      */   }
/*      */ 
/*      */   public UserUserExt getUserExt(String userid)
/*      */   {
/*  321 */     return getUserAdminService().getUserExt(userid);
/*      */   }
/*      */ 
/*      */   public List<IUser> getUsersByGroupId(String groupId)
/*      */   {
/*  327 */     return getUserGroupAdminService().getUsersByGroupIdByCache(groupId, Integer.valueOf("0").intValue());
/*      */   }
/*      */   public List<IUser> getUsersOfDepartment(int departmentId) {
/*  330 */     return getUserAdminService().getUsersOfDepartmentByCache(departmentId);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public boolean haveRightByUserId(String userid, int roleType, int resourceType, String resourceId)
/*      */   {
/*  336 */     return getUserAdminService().haveRight(userid, roleType, resourceType, resourceId);
/*      */   }
/*      */   public boolean haveRightByUserId(String userId, IUserRight right) {
/*  339 */     return getUserAdminService().haveRight(userId, (Right)right);
/*      */   }
/*      */   public boolean isAdminUser(String userid) {
/*  342 */     return getUserAdminService().isAdminUser(userid);
/*      */   }
/*      */   public String getDmCity(String userId, String resourceId, String dmType, String dbType) {
/*  345 */     return getUserAdminService().getDmCity(userId, resourceId, dmType, dbType, true);
/*      */   }
/*      */ 
/*      */   public String getShowDmCity(String userId, String resourceId, String dmType, String dbType) {
/*  349 */     return getUserAdminService().getDmCity(userId, resourceId, dmType, dbType, false);
/*      */   }
/*      */ 
/*      */   public String getUserSensitiveLevel(String userId)
/*      */   {
/*  354 */     return getUserAdminService().getSensitiveLevelByCache(userId);
/*      */   }
/*      */ 
/*      */   public User_Group getGroupObject(String userId) {
/*  358 */     return getUserAdminService().getGroupObject(userId);
/*      */   }
/*      */ 
/*      */   public List<IUserGroup> getAllSubGroupsByUserId(String userId) {
/*  362 */     return getUserAdminService().getAllSubGroupByCache(userId);
/*      */   }
/*      */   public List<IUser> getAllSubUsersByUserId(String userId) {
/*  365 */     return getUserAdminService().getSubUsersByUseridByCache(userId);
/*      */   }
/*      */   public List<IUserRole> getAllRoles(String userId, int roleType, int resourceType) {
/*  368 */     List allRolesList = null;
/*  369 */     if ((roleType == -1) && (resourceType == -1))
/*  370 */       allRolesList = getUserAdminService().getAllRoles(userId);
/*      */     else {
/*  372 */       allRolesList = getUserAdminService().getAllRoles(userId, roleType, resourceType);
/*      */     }
/*      */ 
/*  375 */     return allRolesList;
/*      */   }
/*      */ 
/*      */   public List getUserPreferList(String userID) {
/*  379 */     return getUserAdminService().getUserPreferList(userID);
/*      */   }
/*      */   public void saveUserPrefer(String userId, String preferid, String preferValuedesc) {
/*  382 */     getUserAdminService().saveUserPrefer(userId, preferid, preferValuedesc);
/*      */   }
/*      */   public List getPreferDescListByPreferType(String userID, String preferId) {
/*  385 */     return getUserAdminService().getPreferDescListByPreferType(userID, preferId);
/*      */   }
/*      */ 
/*      */   public String getResourceName(int roleType, int resourceType, String resourceId)
/*      */   {
/*  393 */     IResourceRightDAO resourceRightDAO = getRoleAdminService().getResourceRightDAO(roleType, resourceType);
/*  394 */     if (null != resourceRightDAO) {
/*  395 */       return resourceRightDAO.getResourceName(resourceId);
/*      */     }
/*  397 */     return "";
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getResourceTypeByRoleType(int roleType)
/*      */   {
/*  403 */     return ListService.getSysResourceBeanList(roleType);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public List<LabelValueBean> getRoleType()
/*      */   {
/*  410 */     return ListService.getRoleTypeBeanList();
/*      */   }
/*      */ 
/*      */   public Collection<IUserApplication> getAllApplications() throws ServiceException {
/*  414 */     return getUserApplicationService().getAllApplications();
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public List getResourceIdListOfRight(String userId, String resourceType)
/*      */   {
/*  422 */     return getUserRightService().getResourceIdListOfRight(userId, resourceType);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public List getResourceIdListOfRight(String parentId, boolean boo, String str)
/*      */   {
/*  428 */     return getUserRightService().getResourceIdListOfRight(parentId, boo, str);
/*      */   }
/*      */ 
/*      */   public List<ICity> getAllCity() throws ServiceException {
/*  432 */     return getUserAdminService().getAllCity();
/*      */   }
/*      */   public List<IUser> getAllUsers() throws ServiceException {
/*  435 */     return getUserAdminService().getAllUser();
/*      */   }
/*      */   public List<IUserCompany> getAllUserCompany() throws ServiceException {
/*  438 */     return getUserAdminService().getAllUserCompany();
/*      */   }
/*      */   public List<IUserRole> getAllUserRole() throws ServiceException {
/*  441 */     return getUserAdminService().getAllUserRole();
/*      */   }
/*      */ 
/*      */   public List<IUserRole> getUserRole(String userId, String scope) throws ServiceException {
/*  445 */     List returnValue = new ArrayList();
/*      */ 
/*  447 */     Collection userRolelist = null;
/*  448 */     Collection userGroupRolelist = null;
/*  449 */     Collection userGroupAssignedRolelist = null;
/*  450 */     Collection userGroupCreatedRolelist = null;
/*      */ 
/*  452 */     if (("-1".equals(scope)) || ("USER".equals(scope))) {
/*  453 */       userRolelist = getUserAdminService().getRolesByUserId(userId);
/*      */     }
/*      */ 
/*  456 */     if (("-1".equals(scope)) || ("USER_GROUP".equals(scope))) {
/*  457 */       String groupId = getUser(userId).getGroupId();
/*  458 */       userGroupAssignedRolelist = getUserGroupAdminService().getRoleListByGroupId(groupId);
/*  459 */       userGroupCreatedRolelist = getUserGroupAdminService().getUserRoleByCreateGroupId(groupId);
/*  460 */       userGroupRolelist = CollectionUtils.union(userGroupAssignedRolelist, userGroupCreatedRolelist);
/*      */     }
/*  462 */     if (userRolelist == null) userRolelist = new ArrayList();
/*  463 */     if (userGroupRolelist == null) userGroupRolelist = new ArrayList();
/*  464 */     Iterator it = CollectionUtils.union(userRolelist, userGroupRolelist).iterator();
/*      */ 
/*  467 */     while (it.hasNext()) {
/*  468 */       returnValue.add((IUserRole)it.next());
/*      */     }
/*  470 */     return returnValue;
/*      */   }
/*      */   public ICity getCityByCityID(String cityId) throws ServiceException {
/*  473 */     return getUserAdminService().getCityById(cityId);
/*      */   }
/*      */   public List<IGroupRoleMap> getGroupRoleMapList() throws ServiceException {
/*  476 */     return getUserAdminService().getGroupRoleMapList();
/*      */   }
/*      */   public IMenuItem getMeunItemById(Integer memuItemId) throws ServiceException {
/*  479 */     SysMenuItemBean smib = (SysMenuItemBean)SysMenuItemCache.getInstance().getObjectByKey(String.valueOf(memuItemId));
/*  480 */     if (smib == null) {
/*  481 */       return null;
/*      */     }
/*  483 */     SysMenuItem menuItem = new SysMenuItem();
/*  484 */     menuItem.setMenuItemId(Integer.valueOf(smib.getMENUITEMID()));
/*  485 */     menuItem.setMenuItemTitle(smib.getMENUITEMTITLE());
/*  486 */     menuItem.setParentId(Integer.valueOf(smib.getPARENTID()));
/*  487 */     menuItem.setMenuType(Integer.valueOf(smib.getMENUTYPE()));
/*  488 */     menuItem.setUrl(smib.getURL());
/*  489 */     menuItem.setAccessToken(Integer.valueOf(smib.getACCESSTOKEN()));
/*  490 */     menuItem.setApplicationId(smib.getApplicationId());
/*  491 */     menuItem.setUrlPort(smib.getURLPORT());
/*  492 */     menuItem.setUrlTarget(smib.getURLTARGET());
/*  493 */     menuItem.setResourceType(Integer.valueOf(smib.getRESTYPE()));
/*  494 */     menuItem.setResId(smib.getRESID());
/*  495 */     menuItem.setSortNum(Integer.valueOf(smib.getSORTNUM()));
/*  496 */     menuItem.setFolderOrNot(StringUtil.isEmpty(smib.getURL()));
/*      */ 
/*  498 */     return menuItem;
/*      */   }
/*      */ 
/*      */   public ISysResourceType getResourceTypeByRoleRes(int roleType, int resourceType) throws ServiceException {
/*  502 */     return getUserAdminService().getResourceTypeByRoleRes(roleType, resourceType);
/*      */   }
/*      */ 
/*      */   public IUserCompany getUserCompanyById(String companyId)
/*      */     throws ServiceException
/*      */   {
/*  509 */     IUserCompany userCompany = (IUserCompany)UserCompanyCache.getInstance().getObjectByKey(companyId);
/*  510 */     if (userCompany == null) {
/*  511 */       return getUserAdminService().getUserCompanyById(companyId);
/*      */     }
/*  513 */     return userCompany;
/*      */   }
/*      */ 
/*      */   public List<IUserCompany> getUserCompanyByName(String companyName)
/*      */     throws ServiceException
/*      */   {
/*  521 */     List result = new ArrayList();
/*  522 */     Collection collection = UserCompanyCache.getInstance().getAllCachedObject();
/*  523 */     for (User_Company company : collection) {
/*  524 */       if (companyName.equals(company.getTitle())) {
/*  525 */         result.add(company);
/*      */       }
/*      */     }
/*  528 */     return result;
/*      */   }
/*      */ 
/*      */   public IUserDuty getUserDutyById(String dutyId)
/*      */     throws ServiceException
/*      */   {
/*  535 */     return getUserAdminService().getUserDutyById(dutyId);
/*      */   }
/*      */   public IUserGroup getUserGroupById(String groupId) throws ServiceException {
/*  538 */     return getUserAdminService().getUserGroupById(groupId);
/*      */   }
/*      */   public List<IUserGroup> getAllUserGroup() throws ServiceException {
/*  541 */     return getUserAdminService().getAllUserGroup();
/*      */   }
/*      */ 
/*      */   public List<IUserGroup> getUserGroupByUserId(List<String> userIds) throws ServiceException {
/*  545 */     return getUserAdminService().getUserGroupByUserId(userIds);
/*      */   }
/*      */   public IUserRole getUserRoleById(String roleId) throws ServiceException {
/*  548 */     return getUserAdminService().getUserRoleById(roleId);
/*      */   }
/*      */ 
/*      */   public List<IUserGroup> getValidChildGroups(String groupId) throws ServiceException {
/*  552 */     return getUserAdminService().getValidChildGroups(groupId);
/*      */   }
/*      */   public List<ICity> getCityByUser(String userId) throws ServiceException {
/*  555 */     return this.userAdminService.getCityByUser(userId);
/*      */   }
/*      */ 
/*      */   public String getAllCityID(String strRoles, boolean bTopLevel) throws ServiceException {
/*  559 */     return UserManager.getAllCityID(null, strRoles, bTopLevel);
/*      */   }
/*      */   public List<IMenuItem> getAllMenuItem(String userId) throws ServiceException {
/*  562 */     List result = new ArrayList();
/*      */     Set idSet;
/*  563 */     if (StringUtils.isBlank(userId)) {
/*  564 */       Collection collection = SysMenuItemViewCache.getInstance().getAllCachedObject();
/*  565 */       if ((null != collection) && (!collection.isEmpty())) {
/*  566 */         Iterator it = collection.iterator();
/*  567 */         while (it.hasNext()) {
/*  568 */           SysMenuItem smi = (SysMenuItem)it.next();
/*  569 */           result.add(smi);
/*      */         }
/*      */       }
/*      */     } else {
/*  573 */       List resourceList = getUserAdminService().getRight(userId, 1, Integer.parseInt("50"), false);
/*  574 */       idSet = new HashSet();
/*  575 */       if ((null != resourceList) && (resourceList.size() > 0)) {
/*  576 */         for (Right right : resourceList) {
/*  577 */           boolean flag = idSet.add(right.getResourceId());
/*  578 */           if (flag == true) {
/*  579 */             List smiList = SysMenuItemViewCache.getInstance().getMenuItemListById(Integer.parseInt(right.getResourceId()));
/*  580 */             result.addAll(smiList);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  585 */     return result;
/*      */   }
/*      */ 
/*      */   public List<ICity> getSubCitysById(String parentCityId)
/*      */     throws ServiceException
/*      */   {
/*  592 */     return this.userAdminService.getSubCitysById(parentCityId);
/*      */   }
/*      */   public List<IUserCompany> getSubCompanyById(String deptId) throws ServiceException {
/*  595 */     return this.userAdminService.getSubCompanyById(deptId);
/*      */   }
/*      */ 
/*      */   public List<IMenuItem> getSubMenuItemById(Integer menuItemId, String userId, boolean isCascade)
/*      */   {
/*  605 */     List result = new ArrayList();
/*  606 */     List smiList = new ArrayList();
/*  607 */     smiList = SysMenuItemViewCache.getInstance().getSubMenuItemById(menuItemId.intValue(), smiList, isCascade);
/*      */     String operationType;
/*      */     Map rightOperationMap;
/*  608 */     if (StringUtils.isBlank(userId))
/*      */     {
/*  610 */       List rodList = getResourceOperationDefineService().getDefineListBy(Integer.parseInt("50"));
/*  611 */       operationType = "";
/*  612 */       for (ResourceOperationDefine rod : rodList) {
/*  613 */         operationType = operationType + rod.getOperationKey() + ",";
/*      */       }
/*  615 */       if (StringUtils.isNotBlank(operationType)) {
/*  616 */         operationType = operationType.substring(0, operationType.length() - 1);
/*      */       }
/*  618 */       for (SysMenuItem smi : smiList) {
/*  619 */         smi.setOperationType(operationType);
/*  620 */         result.add(smi);
/*      */       }
/*      */     } else {
/*  623 */       if (null == UserCache.getInstance().getObjectByKey(userId)) {
/*  624 */         return result;
/*      */       }
/*  626 */       rightOperationMap = new HashMap();
/*  627 */       List resourceList = getUserAdminService().getRight(userId, 1, Integer.parseInt("50"), false);
/*  628 */       if (CollectionUtils.isNotEmpty(resourceList)) {
/*  629 */         for (Right right : resourceList) {
/*  630 */           if (rightOperationMap.containsKey(right.getResourceId())) {
/*  631 */             String value = (String)rightOperationMap.get(right.getResourceId()) + "," + right.getOperationType();
/*  632 */             rightOperationMap.put(right.getResourceId(), value);
/*      */           } else {
/*  634 */             rightOperationMap.put(right.getResourceId(), right.getOperationType());
/*      */           }
/*      */         }
/*      */       }
/*  638 */       for (SysMenuItem smi : smiList) {
/*  639 */         if (null != rightOperationMap.get(smi.getMenuItemId().toString())) {
/*  640 */           smi.setOperationType((String)rightOperationMap.get(smi.getMenuItemId().toString()));
/*  641 */           result.add(smi);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  646 */     Collections.sort(result, new Comparator() {
/*      */       public int compare(IMenuItem menuItem1, IMenuItem menuItem2) {
/*  648 */         if (menuItem1.getParentId().equals(menuItem2.getParentId())) {
/*  649 */           return menuItem1.getSortNum().compareTo(menuItem2.getSortNum());
/*      */         }
/*  651 */         return menuItem1.getParentId().compareTo(menuItem2.getParentId());
/*      */       }
/*      */     });
/*  656 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean isPwdChangedByOthers(String userId)
/*      */   {
/*  662 */     return PwdPolicyService.isPwdChangedByOthers(userId);
/*      */   }
/*      */ 
/*      */   public boolean isPwdNeedChange(String userId)
/*      */   {
/*  668 */     if (PwdPolicyService.isPwdExpired(userId)) return true;
/*  669 */     int remainDays = PwdPolicyService.getPwdRemainDays(userId);
/*  670 */     if (remainDays > 0)
/*  671 */       return true;
/*  672 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isUserLegal(String userId, String password)
/*      */   {
/*  678 */     return getUserAdminService().isUserLegal(userId, password);
/*      */   }
/*      */ 
/*      */   public long getUserAmount()
/*      */   {
/*  687 */     return UserCache.getInstance().getAllCachedObject().size();
/*      */   }
/*      */ 
/*      */   public List<IUser> getUsersByPage(String pageSize, String pageNum)
/*      */   {
/*  695 */     List result = null;
/*      */     try {
/*  697 */       Integer pageSizeValue = Integer.valueOf(pageSize);
/*  698 */       Integer pageNumValue = Integer.valueOf(Integer.parseInt(pageNum) - 1);
/*      */ 
/*  700 */       SearchCondition condition = new SearchCondition();
/*  701 */       result = (List)getUserAdminService().getPagedUserList(condition, pageNumValue, pageSizeValue).get("result");
/*      */     } catch (Exception e) {
/*  703 */       throw new ServiceException(e.getMessage());
/*      */     }
/*  705 */     return result;
/*      */   }
/*      */ 
/*      */   public IUserCompany getUserDept(String userId)
/*      */     throws ServiceException
/*      */   {
/*  712 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(userId);
/*  713 */     IUserCompany userCompany = (IUserCompany)UserCompanyCache.getInstance().getObjectByKey(String.valueOf(user.getDepartmentid()));
/*  714 */     return userCompany;
/*      */   }
/*      */ 
/*      */   public List<IUserRight> getRight(String userId, int resourceType)
/*      */   {
/*  721 */     return getUserAdminService().getRight(userId, 1, resourceType, false);
/*      */   }
/*      */ 
/*      */   public boolean haveOperRight(String userId, String functionId, String actionId)
/*      */   {
/*  728 */     Right right = new Right();
/*  729 */     right.setRightId(actionId);
/*  730 */     right.setRoleType(2);
/*  731 */     right.setResourceType(Integer.parseInt("1001"));
/*  732 */     right.setResourceId(functionId);
/*      */ 
/*  734 */     return getUserAdminService().haveRight(userId, right);
/*      */   }
/*      */ 
/*      */   public List<IUserRight> getPrivacyRights(String userId)
/*      */   {
/*  744 */     return getUserAdminService().getRight(userId, 1, Integer.parseInt("1005"), false);
/*      */   }
/*      */ 
/*      */   public boolean haveRightByUserId(String userid, int resourceType, String resourceId) {
/*  748 */     return getUserAdminService().haveRight(userid, 1, resourceType, resourceId);
/*      */   }
/*      */ 
/*      */   public boolean haveOperateRight(String userId, int resourceType, String resourceId, String operationKey)
/*      */     throws ServiceException
/*      */   {
/*  756 */     return getUserAdminService().haveOperateRight(userId, resourceType, resourceId, operationKey);
/*      */   }
/*      */ 
/*      */   public List getUserList(List<String> userIds)
/*      */     throws ServiceException
/*      */   {
/*  762 */     return getUserAdminService().getByUserIds(userIds);
/*      */   }
/*      */ 
/*      */   public void saveRight(String operatorId, int operatorType, int resourceType, String resourceId, int accessType, String controlType)
/*      */     throws ServiceException
/*      */   {
/*  771 */     getRoleAdminService().saveRight(operatorId, operatorType, resourceType, resourceId, accessType, controlType);
/*      */   }
/*      */ 
/*      */   public String doCreateApply(String proposerId, String beginDate, String endDate, String applyType, List<IUserRight> rightList)
/*      */     throws ServiceException
/*      */   {
/*  781 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(proposerId);
/*  782 */     UserRightApply apply = new UserRightApply();
/*  783 */     apply.setProposerId(proposerId);
/*  784 */     apply.setProposerName(user.getUsername());
/*  785 */     apply.setBeginDate(DateUtil.string2Date(beginDate));
/*  786 */     apply.setEndDate(DateUtil.string2Date(endDate));
/*  787 */     apply.setApplyType(applyType);
/*  788 */     List superiorUserList = getUserAdminService().getUsersByUserMap(proposerId, 0, "0");
/*  789 */     if ((null != superiorUserList) && (superiorUserList.size() > 0)) {
/*  790 */       apply.setApproverId(((User_User)superiorUserList.get(0)).getUserid());
/*  791 */       apply.setApproverName(((User_User)superiorUserList.get(0)).getUsername());
/*  792 */       apply.setApproverPhone(((User_User)superiorUserList.get(0)).getMobilephone());
/*      */     } else {
/*  794 */       return null;
/*      */     }
/*  796 */     List tempRightList = new ArrayList();
/*  797 */     for (IUserRight userRight : rightList) {
/*  798 */       UserTempRight right = new UserTempRight();
/*  799 */       right.setUserId(proposerId);
/*  800 */       right.setRoleType(userRight.getRoleType());
/*  801 */       right.setResourceType(userRight.getResourceType());
/*  802 */       right.setResourceId(userRight.getResourceId());
/*  803 */       String resourceName = getRoleAdminService().getResourceRightDAO(userRight.getRoleType(), userRight.getResourceType()).getResourceName(userRight.getResourceId());
/*      */ 
/*  806 */       right.setResourceName(resourceName);
/*  807 */       right.setOperationType(userRight.getOperationType());
/*  808 */       right.setOperationName(userRight.getOperationName());
/*  809 */       right.setBeginDate(DateUtil.string2Date(beginDate));
/*  810 */       right.setEndDate(DateUtil.string2Date(endDate));
/*  811 */       tempRightList.add(right);
/*      */     }
/*  813 */     return getUserTempRightService().doCreateApply(apply, tempRightList);
/*      */   }
/*      */ 
/*      */   public void doAffirmApply(String applyId, String code)
/*      */     throws ServiceException
/*      */   {
/*  821 */     getUserTempRightService().doAffirmApply(applyId, code);
/*      */   }
/*      */ 
/*      */   public Collection getTempRightsByApplyId(String applyId)
/*      */     throws ServiceException
/*      */   {
/*  829 */     return getUserTempRightService().getTempRightsByApplyId(applyId);
/*      */   }
/*      */ 
/*      */   public IUserRightApply getApplyById(String applyId)
/*      */     throws ServiceException
/*      */   {
/*  836 */     return getUserTempRightService().getRightApply(applyId);
/*      */   }
/*      */   public List getUserExtInfo(String userId) throws Exception {
/*  839 */     return this.userExtInfoService.findUserExtInfo(userId);
/*      */   }
/*      */ 
/*      */   public String decryption(String string)
/*      */   {
/*      */     try
/*      */     {
/*  847 */       return DES.decrypt(string);
/*      */     } catch (Exception e) {
/*  849 */       e.printStackTrace();
/*  850 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public String encryption(String string)
/*      */   {
/*      */     try
/*      */     {
/*  859 */       return DES.encrypt(string);
/*      */     } catch (Exception e) {
/*  861 */       e.printStackTrace();
/*  862 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<IUserRight> getShowTreeRight(String userId, int resourceType)
/*      */   {
/*  871 */     ISysResourceTypeService sysResourceTypeService = (ISysResourceTypeService)SpringUtil.getBean("right_sysResourceTypeService");
/*  872 */     List typeList = sysResourceTypeService.findByResourceType(resourceType);
/*  873 */     if ((typeList == null) || (typeList.size() <= 0)) {
/*  874 */       return null;
/*      */     }
/*  876 */     int roleType = ((SysResourceType)typeList.get(0)).getRoleType();
/*  877 */     List list = getUserAdminService().getRight(userId, roleType, resourceType, false);
/*  878 */     Set set = new HashSet();
/*      */ 
/*  880 */     List retList = null;
/*  881 */     if ((list != null) && (list.size() > 0)) {
/*  882 */       for (IUserRight item : list) {
/*  883 */         if (set.add(item.getResourceId())) {
/*  884 */           if (retList == null) {
/*  885 */             retList = new ArrayList();
/*      */           }
/*  887 */           retList.add(item);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  892 */     if (resourceType != Integer.parseInt("5")) {
/*  893 */       return retList;
/*      */     }
/*      */ 
/*  897 */     List itemList = null;
/*  898 */     Right right = null;
/*  899 */     if ((list != null) && (list.size() > 0)) {
/*  900 */       for (IUserRight item : list) {
/*  901 */         itemList = getUserCityService().getParentCitys(item.getResourceId());
/*  902 */         if ((itemList != null) && (itemList.size() >= 0))
/*      */         {
/*  905 */           for (ICity iCity : itemList) {
/*  906 */             if (set.add(iCity.getCityId())) {
/*  907 */               right = new Right();
/*  908 */               right.setResourceId(iCity.getCityId());
/*  909 */               right.setResourceName(iCity.getCityName());
/*  910 */               right.setParentId(iCity.getParentId());
/*  911 */               if (retList == null) {
/*  912 */                 retList = new ArrayList();
/*      */               }
/*  914 */               retList.add(right);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  920 */     return retList;
/*      */   }
/*      */ 
/*      */   public IUserDuty getUserDutyByUser(IUser user) throws ServiceException {
/*  924 */     IUserDuty duty = null;
/*  925 */     if (user == null) {
/*  926 */       return duty;
/*      */     }
/*  928 */     User_User userUser = getUser(user.getUserid());
/*  929 */     if ((userUser != null) && (userUser.getDutyid() != null)) {
/*  930 */       duty = getUserAdminService().getUserDutyById(userUser.getDutyid().toString());
/*      */     }
/*  932 */     return duty;
/*      */   }
/*      */ 
/*      */   public boolean addPublishMenu(int pMenuId, String resType, String resId, String menuName, String menuUrl, String userId, String[] roleIds)
/*      */   {
/*      */     try {
/*  938 */       User_User user = getUser(userId);
/*  939 */       if (null != user) {
/*  940 */         LogInfo.setOperatorID(user.getUserid());
/*  941 */         LogInfo.setOperatorName(user.getUsername());
/*      */       }
/*  943 */       Integer menuItemId = this.sysMenuItemService.addPublishMenu(pMenuId, resType, resId, menuName, menuUrl);
/*      */ 
/*  945 */       if (null == menuItemId) {
/*  946 */         return false;
/*      */       }
/*  948 */       if ((null != roleIds) && (roleIds.length > 0)) {
/*  949 */         for (String roleId : roleIds) {
/*  950 */           if (StringUtils.isNotBlank(roleId)) {
/*  951 */             saveRight(roleId, 0, Integer.parseInt("50"), menuItemId.toString(), -1, "1");
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  958 */       return false;
/*      */     }
/*  960 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean deletePublishMenu(String resType, String resId) {
/*      */     try {
/*  965 */       List smiList = this.sysMenuItemService.deletePublishMenu(resType, resId);
/*      */ 
/*  968 */       for (i$ = smiList.iterator(); i$.hasNext(); ) { smi = (SysMenuItem)i$.next();
/*  969 */         Right right = new Right();
/*  970 */         right.setResourceId(smi.getMenuItemId().toString());
/*  971 */         right.setResourceType(Integer.parseInt("50"));
/*      */ 
/*  973 */         right.setOperationType("-1");
/*  974 */         List roleRightList = getRoleAdminService().getRoleRightListByRight(right);
/*      */ 
/*  976 */         for (RoleRight rr : roleRightList)
/*  977 */           getRoleAdminService().deleteRight(rr.getRoleId(), 0, Integer.parseInt("50"), smi.getMenuItemId().toString());
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       Iterator i$;
/*      */       SysMenuItem smi;
/*  983 */       return false;
/*      */     }
/*  985 */     return true;
/*      */   }
/*      */ 
/*      */   public String queryFolderList(int menuItemId)
/*      */   {
/*  990 */     return this.sysMenuItemService.queryFolderList(menuItemId);
/*      */   }
/*      */ 
/*      */   public boolean modPublishMenu(int pMenuId, String resType, String resId, String menuName, String menuUrl, String userId, String[] roleIds)
/*      */   {
/*      */     try {
/*  996 */       User_User user = getUser(userId);
/*  997 */       if (null != user) {
/*  998 */         LogInfo.setOperatorID(user.getUserid());
/*  999 */         LogInfo.setOperatorName(user.getUsername());
/*      */       }
/*      */ 
/* 1002 */       Integer menuItemId = this.sysMenuItemService.modPublishMenu(pMenuId, resType, resId, menuName, menuUrl);
/* 1003 */       if (null == menuItemId) {
/* 1004 */         return false;
/*      */       }
/*      */ 
/* 1007 */       Right right = new Right();
/* 1008 */       right.setResourceId(menuItemId.toString());
/* 1009 */       right.setResourceType(Integer.parseInt("50"));
/*      */ 
/* 1011 */       right.setOperationType("-1");
/* 1012 */       List roleRightList = getRoleAdminService().getRoleRightListByRight(right);
/*      */ 
/* 1014 */       for (RoleRight rr : roleRightList) {
/* 1015 */         getRoleAdminService().deleteRight(rr.getRoleId(), 0, Integer.parseInt("50"), menuItemId.toString());
/*      */       }
/*      */ 
/* 1020 */       if ((null != roleIds) && (roleIds.length > 0)) {
/* 1021 */         for (String roleId : roleIds) {
/* 1022 */           if (StringUtils.isNotBlank(roleId)) {
/* 1023 */             saveRight(roleId, 0, Integer.parseInt("50"), menuItemId.toString(), -1, "1");
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1030 */       return false;
/*      */     }
/* 1032 */     return true;
/*      */   }
/*      */ 
/*      */   public List<IMenuItem> getMenuItemList(String userId, Map<String, String> menuItem) throws ServiceException
/*      */   {
/* 1037 */     List menuItemList = new ArrayList();
/*      */ 
/* 1039 */     List smiList = getSysMenuItemService().getMenuItemList(menuItem);
/*      */     List resourceIdList;
/* 1041 */     if (StringUtils.isBlank(userId)) {
/* 1042 */       for (SysMenuItem smi : smiList) {
/* 1043 */         SysMenuItem sm = (SysMenuItem)SysMenuItemViewCache.getInstance().getObjectByKey(smi.getMenuItemId() + "|" + smi.getParentId());
/* 1044 */         menuItemList.add(sm);
/*      */       }
/*      */     }
/*      */     else {
/* 1048 */       List resourceList = getUserAdminService().getRight(userId, 1, Integer.parseInt("50"), false);
/* 1049 */       resourceIdList = new ArrayList();
/* 1050 */       for (Right right : resourceList) {
/* 1051 */         resourceIdList.add(right.getResourceId());
/*      */       }
/* 1053 */       for (SysMenuItem smi : smiList) {
/* 1054 */         SysMenuItem sm = (SysMenuItem)SysMenuItemViewCache.getInstance().getObjectByKey(smi.getMenuItemId() + "|" + smi.getParentId());
/* 1055 */         if (resourceIdList.contains(sm.getMenuItemId().toString())) {
/* 1056 */           menuItemList.add(sm);
/*      */         }
/*      */       }
/*      */     }
/* 1060 */     if (null != menuItem)
/*      */     {
/* 1062 */       String isFolderOrNot = (String)menuItem.get("isFolderOrNot");
/* 1063 */       if (StringUtils.isNotBlank(isFolderOrNot)) {
/* 1064 */         List result = new ArrayList();
/* 1065 */         for (IMenuItem smi : menuItemList) {
/* 1066 */           if (smi.isFolderOrNot() == Boolean.valueOf(isFolderOrNot).booleanValue()) {
/* 1067 */             result.add(smi);
/*      */           }
/*      */         }
/* 1070 */         return result;
/*      */       }
/*      */     }
/* 1073 */     return menuItemList;
/*      */   }
/*      */ 
/*      */   public long getUserGroupAmount()
/*      */   {
/* 1080 */     return UserGroupDefineCache.getInstance().getAllCachedObject().size();
/*      */   }
/*      */ 
/*      */   public long getUserRoleAmount()
/*      */   {
/* 1087 */     return UserRoleCache.getInstance().getAllCachedObject().size();
/*      */   }
/*      */ 
/*      */   public List getUserGroupByTime(String startTime, String endTime)
/*      */   {
/* 1094 */     List group = null;
/* 1095 */     group = getUserGroupAdminService().getUserGroupByTime(startTime, endTime);
/* 1096 */     return group;
/*      */   }
/*      */ 
/*      */   public List getUserRoleByTime(String startTime, String endTime)
/*      */   {
/* 1102 */     List role = null;
/* 1103 */     role = getRoleAdminService().getUserRoleByTime(startTime, endTime);
/* 1104 */     return role;
/*      */   }
/*      */ 
/*      */   public List getUserByTime(String startTime, String endTime)
/*      */   {
/* 1110 */     List role = null;
/* 1111 */     role = getUserAdminService().getUserByTime(startTime, endTime);
/* 1112 */     return role;
/*      */   }
/*      */ 
/*      */   public List getRightsByRes(int roleType, int resourceType)
/*      */   {
/* 1118 */     List rights = null;
/* 1119 */     rights = getRoleAdminService().getAllRights(roleType, resourceType);
/* 1120 */     return rights;
/*      */   }
/*      */   public IUserGroup getUserGroup(String groupId, String groupName) {
/* 1123 */     User_Group group = null;
/* 1124 */     if (StringUtils.isNotBlank(groupId)) {
/* 1125 */       group = getUserGroupAdminService().getUserGroup(groupId);
/* 1126 */     } else if (StringUtils.isNotBlank(groupName)) {
/* 1127 */       List groupList = getUserGroupAdminService().getUserGroupByName(groupName);
/* 1128 */       if (CollectionUtils.isNotEmpty(groupList)) {
/* 1129 */         group = (User_Group)groupList.get(0);
/*      */       }
/*      */     }
/* 1132 */     return group;
/*      */   }
/*      */   public List<IUserGroup> getPagedUserGroup(int currentPage, int pageSize) {
/* 1135 */     User_Group group = new User_Group();
/* 1136 */     Map map = getUserGroupAdminService().getPagedUserGroupList(group, Integer.valueOf(currentPage), Integer.valueOf(pageSize));
/* 1137 */     return (List)map.get("result");
/*      */   }
/*      */   public List<IUser> getPagedUser(int currentPage, int pageSize) {
/* 1140 */     SearchCondition condition = new SearchCondition();
/* 1141 */     Map map = getUserAdminService().getPagedUserList(condition, Integer.valueOf(currentPage), Integer.valueOf(pageSize));
/* 1142 */     return (List)map.get("result");
/*      */   }
/*      */   public List<IUserRole> getPagedUserRole(int currentPage, int pageSize) {
/* 1145 */     UserRole role = new UserRole();
/* 1146 */     Map map = getRoleAdminService().getPagedRoleList(role, Integer.valueOf(currentPage), Integer.valueOf(pageSize));
/* 1147 */     return (List)map.get("result");
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.publish.PrivilegeServiceImpl
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.sysmanage.publish;
/*    */ 
/*    */ import com.asiainfo.biframe.log.LogInfo;
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.cxf.interceptor.Fault;
/*    */ import org.apache.cxf.message.Message;
/*    */ import org.apache.cxf.phase.AbstractPhaseInterceptor;
/*    */ 
/*    */ public class WSInInterceptors extends AbstractPhaseInterceptor<Message>
/*    */ {
/*    */   public WSInInterceptors()
/*    */   {
/* 19 */     super("receive");
/*    */   }
/*    */ 
/*    */   public void handleMessage(Message message) throws Fault {
/* 23 */     HttpServletRequest request = (HttpServletRequest)message.get("HTTP.REQUEST");
/* 24 */     String ipAddress = request.getRemoteAddr();
/* 25 */     LogInfo.setClientAddress(ipAddress);
/* 26 */     LogInfo.setOperatorID("WebService");
/* 27 */     LogInfo.setOperatorName("WebService");
/* 28 */     LogInfo.setSessionID(request.getSession().getId());
/* 29 */     LogInfo.setHostAddress(Configure.getInstance().getProperty("HOST_ADDRESS"));
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.publish.WSInInterceptors
 * JD-Core Version:    0.6.2
 */
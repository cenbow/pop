package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.privilege.model.User_Company;

public abstract interface IDeptMangerService
{
  public abstract void saveDeptInfo(User_Company paramUser_Company);

  public abstract User_Company initDeptInof(User_Company paramUser_Company);

  public abstract String getUserByDeptId(String paramString);

  public abstract String getUserByGroupId(String paramString);

  public abstract void updateUserDeptInfo(String paramString1, String paramString2);

  public abstract String chkDeptTitleExist(String paramString1, String paramString2, String paramString3);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IDeptMangerService
 * JD-Core Version:    0.6.2
 */
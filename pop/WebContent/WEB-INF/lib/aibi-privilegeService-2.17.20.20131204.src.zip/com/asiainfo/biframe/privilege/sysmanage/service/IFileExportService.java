package com.asiainfo.biframe.privilege.sysmanage.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public abstract interface IFileExportService
{
  public abstract void exportMatrixMenuData(PrintWriter paramPrintWriter)
    throws IOException;

  public abstract void exportRightsData(PrintWriter paramPrintWriter, List<String> paramList)
    throws Exception;

  public abstract void exportMatrixMenuDataNew(PrintWriter paramPrintWriter)
    throws IOException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IFileExportService
 * JD-Core Version:    0.6.2
 */
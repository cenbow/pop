package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.privilege.model.FirstpagesetParam;
import java.util.List;
import org.apache.struts.util.LabelValueBean;

public abstract interface IFirstPageSetService
{
  public static final String SYS_DEFAULT_HOMEPAGE_PATH = "/kpi/daily.jsp";

  public abstract String saveFirstPageSet(FirstpagesetParam paramFirstpagesetParam)
    throws Exception;

  public abstract String deleteFirstPageSet(String paramString);

  public abstract List<FirstpagesetParam> getAllPageSet();

  public abstract String getRoleName(String paramString);

  public abstract List<LabelValueBean> getAllRoles();

  public abstract FirstpagesetParam getPageSet(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IFirstPageSetService
 * JD-Core Version:    0.6.2
 */
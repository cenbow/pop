package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.model.ResourceOperationDefine;
import java.util.List;

public abstract interface IResourceOperationDefineService
{
  public abstract List<ResourceOperationDefine> getDefineListBy(int paramInt)
    throws ServiceException;

  public abstract String getOperNameBy(String paramString, int paramInt)
    throws ServiceException;

  public abstract ResourceOperationDefine getOperationDefineBy(String paramString, int paramInt)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IResourceOperationDefineService
 * JD-Core Version:    0.6.2
 */
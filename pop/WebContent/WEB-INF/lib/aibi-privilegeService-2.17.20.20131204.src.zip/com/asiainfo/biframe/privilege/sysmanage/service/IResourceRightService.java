package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.privilege.sysmanage.model.Right;
import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
import java.util.List;

public abstract interface IResourceRightService
{
  public abstract void save(List<RoleRight> paramList);

  public abstract void delete(List<RoleRight> paramList);

  public abstract void delete(List<String> paramList, List<Right> paramList1, int paramInt);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IResourceRightService
 * JD-Core Version:    0.6.2
 */
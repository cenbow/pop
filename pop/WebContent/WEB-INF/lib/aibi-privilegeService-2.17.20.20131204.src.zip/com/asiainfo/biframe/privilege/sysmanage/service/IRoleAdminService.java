package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.model.UserRole;
import com.asiainfo.biframe.privilege.model.User_Group;
import com.asiainfo.biframe.privilege.model.User_User;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
import com.asiainfo.biframe.privilege.sysmanage.model.Right;
import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.util.LabelValueBean;

public abstract interface IRoleAdminService
{
  public abstract String addRole(UserRole paramUserRole);

  public abstract void updateRole(UserRole paramUserRole);

  /** @deprecated */
  public abstract String cloneRole(UserRole paramUserRole, String paramString);

  public abstract String cloneRoleNew(UserRole paramUserRole, String paramString);

  public abstract void deleteRole(UserRole paramUserRole);

  public abstract void saveUserRoleMap(String paramString, List<String> paramList);

  public abstract void saveGroupRoleMap(String paramString, List<String> paramList);

  /** @deprecated */
  public abstract void saveRoleRightByForce(Collection<RoleRight> paramCollection1, Collection<RoleRight> paramCollection2, String paramString);

  public abstract void saveRoleRightByForce(Collection<RoleRight> paramCollection1, Collection<RoleRight> paramCollection2, String paramString, int paramInt);

  public abstract void doAssignRolesToRight(Right paramRight, List<RoleRight> paramList1, List<RoleRight> paramList2, List<RoleRight> paramList3);

  public abstract void doAssignRolesToRight(Right paramRight, List<RoleRight> paramList1, List<RoleRight> paramList2);

  public abstract void deleteResourceRightByForce(List<Right> paramList1, List<Right> paramList2, String paramString, UserRole paramUserRole);

  public abstract UserRole getRoleById(String paramString);

  public abstract String getRoleName(String paramString);

  /** @deprecated */
  public abstract String getRoleType(String paramString);

  public abstract UserRole findRoleByName(String paramString);

  public abstract List<UserRole> findAll();

  public abstract boolean isExistRole(String paramString);

  public abstract Map getPagedRoleList(UserRole paramUserRole, Integer paramInteger1, Integer paramInteger2);

  public abstract List<UserRole> getUserRoleList(UserRole paramUserRole);

  /** @deprecated */
  public abstract List<String> getCityRoleIdList(List<String> paramList);

  public abstract List<UserRole> getRoleListByRoleIds(List<String> paramList);

  public abstract List<UserRole> getRoleListByName(String paramString);

  public abstract List<String> getUserIDsByRoleId(String paramString);

  public abstract List<User_User> getUsersByRoleId(String paramString);

  public abstract List<String> getGroupIDsByRoleId(String paramString);

  public abstract List<User_Group> getGroupsByRoleId(String paramString);

  public abstract String getAllCreatedGroupId(String paramString);

  public abstract String getCreatedGroupId(String paramString);

  public abstract boolean hasRight(String paramString1, String paramString2, String paramString3);

  public abstract boolean hasAnyRight(String paramString);

  public abstract List<Right> getRightsByRoleId(String paramString);

  public abstract List<Right> getRightsByRoleId(String paramString, int paramInt1, int paramInt2);

  public abstract List<Right> getRightsByRoleIdList(List<String> paramList, int paramInt1, int paramInt2, boolean paramBoolean);

  public abstract List<Right> getAllRights(int paramInt1, int paramInt2);

  public abstract List<RoleRight> getRoleRightsByRoleId(String paramString);

  public abstract List<RoleRight> getRoleRightsByRoleId(String paramString, int paramInt);

  public abstract List<String> getParentIds(List<Right> paramList, String paramString1, String paramString2);

  public abstract List<RoleRight> getRoleRightListByRight(Right paramRight);

  public abstract boolean ifCanDeleteRole(String paramString);

  /** @deprecated */
  public abstract boolean ifCanDeleteRoleByForce(String paramString);

  public abstract boolean isCreatedRoleByGroup(String paramString1, String paramString2, String paramString3);

  public abstract boolean ifCanModifyRoleResourceRight(List<Right> paramList, String paramString);

  /** @deprecated */
  public abstract boolean ifCanModifyRoleResourceRightByForce(List<Right> paramList, String paramString);

  public abstract boolean ifResourceRightUsedByGroups(List<Right> paramList, List<String> paramList1, String paramString);

  public abstract boolean ifResourceRightUsedByGroup(List<Right> paramList, String paramString1, String paramString2);

  public abstract boolean ifResourceRightUsedByCreateRole(List<Right> paramList, String paramString, UserRole paramUserRole);

  public abstract boolean ifResourceRightUsedByGroupUser(List<Right> paramList, String paramString, UserRole paramUserRole);

  public abstract boolean ifResourceRightUsedBySubGroup(List<Right> paramList, String paramString, UserRole paramUserRole);

  public abstract boolean ifRoleUsedByGroup(String paramString1, String paramString2);

  public abstract boolean ifRoleUsedByGroups(String paramString, List<String> paramList);

  public abstract boolean ifRoleUsedByGroup(UserRole paramUserRole, String paramString);

  public abstract boolean ifRoleUsedByCreateRole(UserRole paramUserRole, String paramString);

  public abstract boolean ifRoleUsedByGroupUser(UserRole paramUserRole, String paramString);

  public abstract boolean ifRoleUsedBySubGroup(UserRole paramUserRole, String paramString);

  /** @deprecated */
  public abstract boolean isRoleTheOnlyCityRole(UserRole paramUserRole, String paramString);

  public abstract boolean isRoleInGroup(String paramString1, String paramString2);

  public abstract boolean isDistinguishOperation(int paramInt1, int paramInt2);

  public abstract IResourceRightDAO getResourceRightDAO(int paramInt1, int paramInt2);

  public abstract Map getResourceRightDaoMap();

  public abstract List<String> Right2IdList(List<Right> paramList);

  public abstract boolean containResource(List<Right> paramList, String paramString);

  /** @deprecated */
  public abstract List<UserRole> filterRoleByType(List<UserRole> paramList, int paramInt1, int paramInt2);

  /** @deprecated */
  public abstract void doAssignRightsToRole(String paramString, Collection<RoleRight> paramCollection1, Collection<RoleRight> paramCollection2, Collection<String> paramCollection);

  public abstract void doAssignRightsToRole(String paramString, int paramInt, Collection<RoleRight> paramCollection1, Collection<RoleRight> paramCollection2, Collection<String> paramCollection);

  public abstract void doAssignUsersToRole(String paramString, List<String> paramList1, List<String> paramList2, List<String> paramList3, List<String> paramList4)
    throws ServiceException;

  public abstract void doAssignRightsToRoles(List<RoleRight> paramList);

  public abstract void doRealDeleteGroup(DeletedParameterVO paramDeletedParameterVO);

  public abstract String exportActionStatus(HttpServletRequest paramHttpServletRequest);

  public abstract Right getRight(String paramString, int paramInt1, int paramInt2);

  public abstract void saveRight(String paramString1, int paramInt1, int paramInt2, String paramString2, int paramInt3, String paramString3)
    throws ServiceException;

  public abstract void saveRight(int paramInt, List<RoleRight> paramList)
    throws ServiceException;

  public abstract void deleteRight(String paramString1, int paramInt1, int paramInt2, String paramString2)
    throws ServiceException;

  public abstract List<LabelValueBean> getAssignedResourceTypeList(String paramString);

  public abstract List<LabelValueBean> getUpdateResourceTypeList(String paramString);

  public abstract List<LabelValueBean> getAllResourceTypeList();

  public abstract List<String> getAllParentResourceIds(String paramString, int paramInt1, int paramInt2);

  public abstract List getUserRoleByTime(String paramString1, String paramString2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService
 * JD-Core Version:    0.6.2
 */
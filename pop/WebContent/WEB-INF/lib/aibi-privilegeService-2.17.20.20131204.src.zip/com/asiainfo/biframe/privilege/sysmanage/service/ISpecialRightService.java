package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.privilege.sysmanage.model.Right;
import java.util.List;

public abstract interface ISpecialRightService
{
  public abstract String getRptFileTree(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
    throws Exception;

  public abstract String getIrIndiTree(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
    throws Exception;

  public abstract void saveRoleRptFileRight(String paramString, List<Right> paramList1, List<Right> paramList2, List<Right> paramList3);

  public abstract void saveRoleIndiRight(String paramString, List<Right> paramList1, List<Right> paramList2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.ISpecialRightService
 * JD-Core Version:    0.6.2
 */
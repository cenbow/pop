package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.privilege.IMenuItem;
import com.asiainfo.biframe.privilege.model.SysMenuItem;
import com.asiainfo.biframe.privilege.model.SysMenuItemRela;
import java.util.List;
import java.util.Map;

public abstract interface ISysMenuItemService
{
  public abstract IMenuItem findById(Integer paramInteger);

  public abstract Integer addPublishMenu(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract List<SysMenuItem> deletePublishMenu(String paramString1, String paramString2);

  public abstract String queryFolderList(int paramInt);

  public abstract Integer modPublishMenu(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract List getMenuItemList(Map<String, String> paramMap);

  public abstract void save(SysMenuItemRela paramSysMenuItemRela);

  public abstract void deleteSysMenuItemRela(Integer paramInteger);

  public abstract void deleteSysMenuItem(Integer paramInteger1, Integer paramInteger2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.ISysMenuItemService
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.privilege.model.SysResourceType;
import java.util.List;

public abstract interface ISysResourceTypeService
{
  public abstract List<SysResourceType> findByRoleType(int paramInt);

  public abstract List<SysResourceType> findAll();

  public abstract SysResourceType findBy(int paramInt1, int paramInt2);

  public abstract List<SysResourceType> getSysTypeListByName(String paramString);

  public abstract List<SysResourceType> findByResourceType(int paramInt);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.ISysResourceTypeService
 * JD-Core Version:    0.6.2
 */
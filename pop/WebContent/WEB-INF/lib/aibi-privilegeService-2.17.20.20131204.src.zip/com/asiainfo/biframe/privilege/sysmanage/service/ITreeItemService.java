package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.privilege.menu.TreeItem;
import java.util.List;

public abstract interface ITreeItemService
{
  public abstract List<TreeItem> getTopSysMenuItems(String paramString);

  public abstract List<TreeItem> getSubSysMenuItems(String paramString1, Integer paramInteger, String paramString2);

  public abstract TreeItem getMenuById(Integer paramInteger);

  public abstract List<TreeItem> getRootSysMenuItems(String paramString, Integer paramInteger);

  public abstract List<TreeItem> getSysMenuItems(String paramString);

  public abstract List<TreeItem> getSysMenuItems(String paramString, Integer paramInteger);

  public abstract List<TreeItem> getAllSysMenuItems(String paramString1, String paramString2);

  public abstract List<TreeItem> getAllSysMenuItemsWithoutLeafAndPreservation(String paramString1, String paramString2);

  public abstract List<TreeItem> getSysMenuItemsWithoutPreservation(String paramString);

  public abstract List<List<TreeItem>> constructxBreadCrumbs(String paramString, Integer paramInteger)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.ITreeItemService
 * JD-Core Version:    0.6.2
 */
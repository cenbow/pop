package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.ICity;
import com.asiainfo.biframe.privilege.IGroupRoleMap;
import com.asiainfo.biframe.privilege.ISysResourceType;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.IUserCompany;
import com.asiainfo.biframe.privilege.IUserDuty;
import com.asiainfo.biframe.privilege.IUserGroup;
import com.asiainfo.biframe.privilege.IUserRole;
import com.asiainfo.biframe.privilege.base.vo.ReturnMsg;
import com.asiainfo.biframe.privilege.model.SysResourceType;
import com.asiainfo.biframe.privilege.model.UserRole;
import com.asiainfo.biframe.privilege.model.UserTempRight;
import com.asiainfo.biframe.privilege.model.UserUserExt;
import com.asiainfo.biframe.privilege.model.UserUserMap;
import com.asiainfo.biframe.privilege.model.User_City;
import com.asiainfo.biframe.privilege.model.User_Group;
import com.asiainfo.biframe.privilege.model.User_User;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import com.asiainfo.biframe.privilege.sysmanage.model.Right;
import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.util.LabelValueBean;

public abstract interface IUserAdminService
{
  public abstract void addUser(User_User paramUser_User)
    throws RuntimeException;

  public abstract void saveUserExt(String paramString1, String paramString2)
    throws Exception;

  public abstract void addUser(User_User paramUser_User, String[] paramArrayOfString, String paramString1, String paramString2);

  public abstract void updateUser(User_User paramUser_User);

  public abstract void updateUser(User_User paramUser_User, String[] paramArrayOfString, String paramString1, String paramString2);

  @Deprecated
  public abstract void updateUserPwd(User_User paramUser_User, String paramString);

  public abstract void updateUserPwd(User_User paramUser_User, String paramString1, String paramString2);

  public abstract void deleteUser(User_User paramUser_User);

  public abstract void doRealDeleteUser(DeletedParameterVO paramDeletedParameterVO)
    throws ServiceException;

  public abstract void updateUserExt(UserUserExt paramUserUserExt);

  public abstract void saveUserRoleMap(String paramString, List<String> paramList1, List<String> paramList2);

  public abstract void saveUserGroupMap(String paramString, String[] paramArrayOfString);

  public abstract User_User getUser(String paramString);

  public abstract Map getPagedUserList(SearchCondition paramSearchCondition, Integer paramInteger1, Integer paramInteger2);

  public abstract List<User_User> getUserList(SearchCondition paramSearchCondition);

  public abstract List<User_User> getUserListByName(String paramString);

  public abstract String getDmCity(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean);

  public abstract String getUserName(String paramString);

  public abstract String getUserId(String paramString);

  public abstract String getUserCity(String paramString);

  public abstract String getUserCurrentCity(String paramString);

  public abstract int getUserDept(String paramString);

  public abstract String getUserDmCity(String paramString1, String paramString2);

  public abstract UserUserExt getUserExt(String paramString);

  public abstract String getUserMobile(String paramString);

  public abstract List getUsersOfDepartment(int paramInt);

  public abstract List getUsersOfDepartmentByCache(int paramInt);

  public abstract List<User_User> getUsersOfCity(String paramString);

  public abstract List<User_User> getByUserIds(List<String> paramList);

  public abstract boolean haveSubGroup(String paramString);

  public abstract List getAllSubGroupByCache(String paramString);

  public abstract List<User_User> getSubUsersByUserid(String paramString);

  public abstract List getSubUsersByUseridByCache(String paramString);

  public abstract boolean isSysUser(String paramString);

  public abstract boolean isAdminUser(String paramString);

  public abstract boolean isUserLegal(String paramString1, String paramString2);

  public abstract boolean isUserLocked(String paramString);

  public abstract boolean isUserExists(String paramString1, String paramString2, boolean paramBoolean);

  public abstract ReturnMsg canLogin(HttpServletRequest paramHttpServletRequest);

  public abstract List<UserRole> getRolesByUserId(String paramString);

  public abstract String getMapRoleIds(String paramString);

  public abstract List<LabelValueBean> getMapRoleBeans(String paramString);

  public abstract List<UserRole> getAllRoles(String paramString);

  /** @deprecated */
  public abstract List getAllRoles(String paramString, int paramInt1, int paramInt2);

  public abstract String getAllRoleNames(String paramString);

  public abstract List<LabelValueBean> getAllRoleBeans(String paramString);

  public abstract List<LabelValueBean> getNotHaveRoleBeans(String paramString1, String paramString2);

  public abstract String getGroup(String paramString);

  public abstract User_Group getGroupObject(String paramString);

  public abstract List getRight(String paramString, int paramInt1, int paramInt2, boolean paramBoolean);

  public abstract List<Right> getAllRight(String paramString);

  public abstract boolean haveRight(String paramString1, int paramInt1, int paramInt2, String paramString2);

  public abstract boolean haveRight(String paramString, Right paramRight);

  public abstract boolean isPwdRepeated(String paramString1, String paramString2);

  public abstract int savePwd2History(String paramString1, String paramString2, String paramString3);

  public abstract int savePwd2History(String paramString1, String paramString2);

  public abstract void saveIncrementUserMaps(List<UserUserMap> paramList1, List<UserUserMap> paramList2);

  public abstract List getUsersByUserMap(String paramString1, int paramInt, String paramString2);

  public abstract List<Right> getSuperiorRightList(String paramString1, String paramString2);

  /** @deprecated */
  public abstract List<UserTempRight> getTempRightList(String paramString, Date paramDate);

  public abstract void updateSensitiveLevel(List<String> paramList, String paramString)
    throws ServiceException;

  public abstract String getSensitiveLevel(String paramString)
    throws ServiceException;

  public abstract String getSensitiveLevelByCache(String paramString)
    throws ServiceException;

  public abstract List getUserPreferList(String paramString);

  public abstract void saveUserPrefer(String paramString1, String paramString2, String paramString3);

  public abstract List<String> getPreferDescListByPreferType(String paramString1, String paramString2);

  public abstract List<IUser> getAllUser()
    throws ServiceException;

  public abstract List<ICity> getAllCity()
    throws ServiceException;

  public abstract List<IUserCompany> getAllUserCompany()
    throws ServiceException;

  public abstract List<IUserRole> getAllUserRole()
    throws ServiceException;

  public abstract ICity getCityById(String paramString)
    throws ServiceException;

  public abstract List<IGroupRoleMap> getGroupRoleMapList()
    throws ServiceException;

  public abstract ISysResourceType getResourceTypeByRoleRes(int paramInt1, int paramInt2)
    throws ServiceException;

  public abstract IUserCompany getUserCompanyById(String paramString)
    throws ServiceException;

  public abstract IUserDuty getUserDutyById(String paramString)
    throws ServiceException;

  public abstract IUserGroup getUserGroupById(String paramString)
    throws ServiceException;

  public abstract List<IUserGroup> getAllUserGroup()
    throws ServiceException;

  public abstract List<IUserGroup> getUserGroupByUserId(List<String> paramList)
    throws ServiceException;

  public abstract IUserRole getUserRoleById(String paramString)
    throws ServiceException;

  public abstract List<IUserGroup> getValidChildGroups(String paramString);

  public abstract List<ICity> getCityByUser(String paramString)
    throws ServiceException;

  public abstract void saveGroupRoleMaps(List<IGroupRoleMap> paramList)
    throws ServiceException;

  public abstract List<ICity> getSubCitysById(String paramString)
    throws ServiceException;

  public abstract List<IUserCompany> getSubCompanyById(String paramString)
    throws ServiceException;

  public abstract List getRightExceptTempRight(String paramString, int paramInt1, int paramInt2, boolean paramBoolean);

  public abstract List<SysResourceType> getSuperiorResTypeList(String paramString1, String paramString2);

  public abstract List<Right> getSuperiorRightList(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract boolean haveOperateRight(String paramString1, int paramInt, String paramString2, String paramString3);

  public abstract List<User_City> getSubUserCtiyById(String paramString1, String paramString2, boolean paramBoolean);

  public abstract List<Right> getUserRightList(String paramString, int paramInt1, int paramInt2, boolean paramBoolean);

  public abstract List<Right> getCityRoleRight(String paramString, boolean paramBoolean);

  public abstract void saveUserRights(String paramString1, int paramInt1, List<String> paramList, int paramInt2, String paramString2)
    throws ServiceException;

  public abstract List getUserByTime(String paramString1, String paramString2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService
 * JD-Core Version:    0.6.2
 */
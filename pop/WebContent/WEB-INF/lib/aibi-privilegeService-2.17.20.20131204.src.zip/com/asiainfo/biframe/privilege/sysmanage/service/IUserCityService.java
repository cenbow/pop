package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.ICity;
import com.asiainfo.biframe.privilege.model.User_City;
import java.util.List;

public abstract interface IUserCityService
{
  public abstract User_City getCityById(String paramString);

  public abstract List<User_City> getCityByName(String paramString);

  public abstract String getDmCity(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean);

  public abstract String getDmCity(String paramString1, String paramString2);

  public abstract List<ICity> getAllCity()
    throws ServiceException;

  public abstract List<ICity> getSubCitysById(String paramString)
    throws ServiceException;

  public abstract List<ICity> getParentCitys(String paramString)
    throws ServiceException;

  public abstract ICity getCityByDmCity(String paramString1, String paramString2)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IUserCityService
 * JD-Core Version:    0.6.2
 */
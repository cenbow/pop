package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.IUserCompany;
import com.asiainfo.biframe.privilege.model.User_Company;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import java.util.List;
import java.util.Map;

public abstract interface IUserCompanyService
{
  public abstract User_Company getUserCompany(String paramString);

  public abstract List<IUserCompany> getAllDept();

  public abstract List<IUserCompany> getUserCompanyByCityId(String paramString);

  public abstract List<User_Company> getCompanyByName(String paramString);

  public abstract String getUserCompanyName(String paramString);

  public abstract Map getPagedCompanyList(User_Company paramUser_Company, Integer paramInteger1, Integer paramInteger2);

  public abstract void doRealDeleteGroup(DeletedParameterVO paramDeletedParameterVO);

  public abstract String createCompany(IUserCompany paramIUserCompany)
    throws ServiceException;

  public abstract void modifyCompany(IUserCompany paramIUserCompany)
    throws ServiceException;

  public abstract void deleteCompany(String paramString)
    throws ServiceException;

  public abstract List<IUserCompany> getCompanyListByParentId(String paramString)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IUserCompanyService
 * JD-Core Version:    0.6.2
 */
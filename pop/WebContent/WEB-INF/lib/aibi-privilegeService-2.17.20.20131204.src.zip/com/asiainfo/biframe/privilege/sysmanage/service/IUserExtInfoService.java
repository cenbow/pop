package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.privilege.model.UserExtInfo;
import java.util.List;

public abstract interface IUserExtInfoService
{
  public abstract void update(String paramString, List<UserExtInfo> paramList)
    throws Exception;

  public abstract List<UserExtInfo> findUserExtInfo(String paramString)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IUserExtInfoService
 * JD-Core Version:    0.6.2
 */
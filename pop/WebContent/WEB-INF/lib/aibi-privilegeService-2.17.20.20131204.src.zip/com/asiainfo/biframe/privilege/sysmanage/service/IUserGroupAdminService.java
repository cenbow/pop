package com.asiainfo.biframe.privilege.sysmanage.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.model.UserRole;
import com.asiainfo.biframe.privilege.model.User_Group;
import com.asiainfo.biframe.privilege.model.User_User;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import com.asiainfo.biframe.privilege.sysmanage.model.Right;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public abstract interface IUserGroupAdminService
{
  public abstract String addUserGroup(User_Group paramUser_Group);

  public abstract void updateUserGroup(User_Group paramUser_Group);

  public abstract String cloneUserGroup(User_Group paramUser_Group, String paramString);

  public abstract void deleteUserGroup(User_Group paramUser_Group);

  public abstract void doAssignRoleToGroup(String paramString, List<String> paramList1, List<String> paramList2);

  public abstract void saveGroupUserMap(String paramString, List<String> paramList);

  public abstract void doAssignUsersToGroup(String paramString, Collection<String> paramCollection1, Collection<String> paramCollection2);

  public abstract User_Group getUserGroup(String paramString);

  public abstract List<User_Group> getUserGroupByName(String paramString);

  public abstract List<User_Group> getUserGroupByIds(List<String> paramList);

  public abstract List<User_Group> getAllUserGroup(User_Group paramUser_Group);

  public abstract Map getPagedUserGroupList(User_Group paramUser_Group, Integer paramInteger1, Integer paramInteger2);

  public abstract String getGroupName(String paramString);

  public abstract User_Group getParentGroup(String paramString);

  public abstract List<User_Group> getParentGroups(String paramString);

  public abstract List<User_Group> getAllSubGroup(String paramString);

  public abstract List<User_Group> getAllSubGroup2(String paramString);

  public abstract List<User_Group> getAllSubGroupByCache(String paramString);

  public abstract List<String> getAllSubGroupIds(String paramString);

  public abstract String getSubGroupids(String paramString);

  public abstract List<User_Group> getSubGroup(String paramString);

  public abstract List<User_Group> getSubGroupByCache(String paramString);

  public abstract boolean isUserGroupExists(String paramString);

  public abstract boolean isAdminGroup(String paramString);

  public abstract boolean isParentGroupByCache(String paramString1, String paramString2);

  public abstract Collection<User_Group> getBrotherGroups(String paramString);

  public abstract List<UserRole> getRoleListByGroupId(String paramString);

  /** @deprecated */
  public abstract List<String> getRoleIdListByGroupId(String paramString, int paramInt1, int paramInt2);

  public abstract List<String> getRoleIdListByGroupId(String paramString);

  /** @deprecated */
  public abstract boolean haveRole(String paramString, int paramInt);

  public abstract boolean haveCityRight(String paramString);

  public abstract List<UserRole> getUserRoleByCreateGroupId(String paramString);

  public abstract Collection<UserRole> getUserRolesByCreateGroupIds(Collection<String> paramCollection);

  public abstract List<UserRole> getAllRolesByCreateGroupId(String paramString);

  public abstract List<UserRole> getAllUserRoleByGroupId(String paramString);

  public abstract Collection<UserRole> getAllUserRoles(List<User_Group> paramList);

  public abstract boolean roleByGroupUsed(String paramString);

  public abstract List getUsersByGroupId(String paramString);

  public abstract List getUsersByGroupIdByCache(String paramString, int paramInt);

  public abstract List<User_User> getUsersByGroupIdByCache(String paramString);

  public abstract List<User_User> getAllSubUsersByGroupId(String paramString);

  public abstract List<User_User> getAllSubUsersByGroupIdByCache(String paramString);

  public abstract List<User_User> getDirectSubUsersByGroupId(String paramString);

  public abstract List<User_User> getDirectSubUsersByGroupIdByCache(String paramString);

  public abstract List<Right> getRightByGroup(String paramString, int paramInt1, int paramInt2, boolean paramBoolean);

  public abstract void doRealDeleteGroup(DeletedParameterVO paramDeletedParameterVO)
    throws ServiceException;

  public abstract List getUserGroupByTime(String paramString1, String paramString2);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService
 * JD-Core Version:    0.6.2
 */
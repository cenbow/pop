/*    */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.DaoException;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IBusiParametersDao;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.service.IBusiParametersService;
/*    */ import java.util.List;
/*    */ import org.apache.struts.util.LabelValueBean;
/*    */ 
/*    */ public class BusiParametersServiceImpl
/*    */   implements IBusiParametersService
/*    */ {
/*    */   private IBusiParametersDao busiParametersDao;
/*    */ 
/*    */   public IBusiParametersDao getBusiParametersDao()
/*    */   {
/* 17 */     return this.busiParametersDao;
/*    */   }
/*    */ 
/*    */   public void setBusiParametersDao(IBusiParametersDao busiParametersDao) {
/* 21 */     this.busiParametersDao = busiParametersDao;
/*    */   }
/*    */ 
/*    */   public List<LabelValueBean> getBusiParametersByType(String parameterType) {
/* 25 */     return this.busiParametersDao.getBusiParametersByType(parameterType);
/*    */   }
/*    */ 
/*    */   public String getParaName(String parameterType, String parameterValue) throws DaoException
/*    */   {
/* 30 */     return this.busiParametersDao.getParaName(parameterType, parameterValue);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.BusiParametersServiceImpl
 * JD-Core Version:    0.6.2
 */
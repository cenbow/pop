/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.cache.object.CacheUtils;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCompanyCache;
/*     */ import com.asiainfo.biframe.privilege.model.User_Company;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IDeptMangerDao;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IDeptMangerService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.json.JsonUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import common.Logger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DeptMangerServiceImpl
/*     */   implements IDeptMangerService
/*     */ {
/*  25 */   private static Logger log = Logger.getLogger(DeptMangerServiceImpl.class);
/*     */ 
/*  27 */   private String topLevelCompanyParentId = "0";
/*     */   private IDeptMangerDao deptMangerDao;
/*     */ 
/*     */   public void saveDeptInfo(User_Company userComPany)
/*     */   {
/*  38 */     Integer deptId = userComPany.getDeptid();
/*  39 */     if (deptId == null) {
/*  40 */       this.deptMangerDao.saveDeptInfo(userComPany);
/*     */ 
/*  42 */       CacheUtils.refreshCompanyCache();
/*  43 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGECONPANY"), String.valueOf(userComPany.getDeptid()), userComPany.getTitle(), "公司层次-->新建部门信息", null, null);
/*     */     }
/*     */     else
/*     */     {
/*  51 */       this.deptMangerDao.updateDeptInfo(userComPany);
/*  52 */       CacheUtils.refreshCompanyCache();
/*  53 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGECONPANY"), String.valueOf(userComPany.getDeptid()), userComPany.getTitle(), "公司层次-->修改部门信息", null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public User_Company initDeptInof(User_Company userComPany)
/*     */   {
/*  71 */     userComPany = this.deptMangerDao.getDeptInfo(userComPany.getDeptid().intValue());
/*  72 */     return userComPany;
/*     */   }
/*     */ 
/*     */   public String getUserByDeptId(String deptId)
/*     */   {
/*  81 */     List list = this.deptMangerDao.getUserByDeptId(deptId);
/*  82 */     return JsonUtil.Object2JsonString(list);
/*     */   }
/*     */ 
/*     */   public String getUserByGroupId(String groupId)
/*     */   {
/*  91 */     List list = this.deptMangerDao.getUserByGroupId(groupId);
/*  92 */     return JsonUtil.Object2JsonString(list);
/*     */   }
/*     */ 
/*     */   public void updateUserDeptInfo(String deptId, String userStr)
/*     */   {
/* 102 */     if ((deptId == null) || ("".equals(deptId))) {
/* 103 */       return;
/*     */     }
/* 105 */     if ((userStr == null) || ("".equals(userStr)) || (userStr.length() < 1)) {
/* 106 */       return;
/*     */     }
/* 108 */     this.deptMangerDao.updateUserDeptInfo(deptId, userStr);
/*     */ 
/* 111 */     String[] userIds = userStr.split("!#!");
/* 112 */     for (int i = 0; i < userIds.length; i++)
/* 113 */       CacheUtils.refreshUserCacheByKey(userIds[i]);
/*     */   }
/*     */ 
/*     */   public String chkDeptTitleExist(String deptId, String title, String parentid)
/*     */   {
/* 125 */     boolean hasExist = false;
/* 126 */     if ((StringUtil.isNotEmpty(title)) && (StringUtil.isNotEmpty(parentid)))
/*     */     {
/* 128 */       if (this.topLevelCompanyParentId.equalsIgnoreCase(parentid)) {
/* 129 */         if (this.deptMangerDao.getDeptCountWithSameTitle(deptId, title, parentid) > 0)
/*     */         {
/* 131 */           hasExist = true;
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 138 */         User_Company userCompany = new User_Company();
/* 139 */         userCompany.setParentid(Integer.valueOf(parentid));
/*     */ 
/* 141 */         addParentId(userCompany, parentid);
/* 142 */         Set allParentId = userCompany.getAllParentId();
/* 143 */         int level = allParentId.size();
/*     */ 
/* 146 */         List topLevelCompanyList = this.deptMangerDao.getAllTopLevelDept(this.topLevelCompanyParentId);
/*     */ 
/* 148 */         List allSameLevelCompany = new ArrayList();
/* 149 */         for (User_Company company : topLevelCompanyList) {
/* 150 */           if (company.getDeptid().toString().equals("8")) {
/* 151 */             log.debug(company.getDeptid().toString());
/*     */           }
/* 153 */           List subCompanyList = getSubCompanyWithLevel(company, level);
/*     */ 
/* 156 */           if ((subCompanyList != null) && (subCompanyList.size() > 0)) {
/* 157 */             allSameLevelCompany.addAll(subCompanyList);
/*     */           }
/*     */         }
/*     */ 
/* 161 */         for (User_Company company : allSameLevelCompany) {
/* 162 */           if ((!deptId.equals(company.getDeptid())) && (title.equals(company.getTitle())))
/*     */           {
/* 164 */             hasExist = true;
/* 165 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 170 */     StringBuffer json = new StringBuffer();
/* 171 */     if (hasExist) {
/* 172 */       json.append("{'success':false,'msg':'" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.detpNameExist") + "'}");
/*     */     }
/*     */     else
/*     */     {
/* 176 */       json.append("{'success':true,'msg':''}");
/*     */     }
/*     */ 
/* 179 */     return json.toString();
/*     */   }
/*     */ 
/*     */   private void addParentId(User_Company userCompany, String parentId)
/*     */   {
/* 189 */     userCompany.getAllParentId().add(parentId);
/*     */ 
/* 191 */     if (!"0".equals(parentId)) {
/* 192 */       Object parentObj = UserCompanyCache.getInstance().getObjectByKey(parentId);
/*     */ 
/* 194 */       if (parentObj == null) {
/* 195 */         log.warn("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parentUserGroupNotExist") + "deptId:" + userCompany.getDeptid().toString() + ",parentId:" + parentId);
/*     */       }
/*     */       else
/*     */       {
/* 201 */         User_Company parentCompany = (User_Company)parentObj;
/* 202 */         addParentId(userCompany, parentCompany.getParentid().toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private List<User_Company> getSubCompanyWithLevel(User_Company parentCompany, int level)
/*     */   {
/* 216 */     List parentCompanyList = new ArrayList();
/* 217 */     parentCompanyList.add(parentCompany);
/* 218 */     List temp = getSubCompany(parentCompanyList);
/* 219 */     if (temp.size() < 1) {
/* 220 */       return temp;
/*     */     }
/* 222 */     for (int i = 1; (i < level - 1) && 
/* 223 */       (temp.size() > 0); i++)
/*     */     {
/* 224 */       temp = getSubCompany(temp);
/*     */     }
/*     */ 
/* 229 */     return temp;
/*     */   }
/*     */ 
/*     */   private List<User_Company> getSubCompany(List<User_Company> parentCompanyList)
/*     */   {
/* 241 */     List result = new ArrayList();
/* 242 */     Collection allCompany = UserCompanyCache.getInstance().getAllCachedSortedObject();
/*     */ 
/* 244 */     for (Iterator it = allCompany.iterator(); it.hasNext(); ) {
/* 245 */       temp = (User_Company)it.next();
/* 246 */       for (User_Company dept : parentCompanyList)
/* 247 */         if (temp.getParentid().equals(dept.getDeptid()))
/* 248 */           result.add(temp);
/*     */     }
/*     */     User_Company temp;
/* 252 */     return result;
/*     */   }
/*     */ 
/*     */   public IDeptMangerDao getDeptMangerDao()
/*     */   {
/* 259 */     return this.deptMangerDao;
/*     */   }
/*     */ 
/*     */   public void setDeptMangerDao(IDeptMangerDao deptMangerDao)
/*     */   {
/* 267 */     this.deptMangerDao = deptMangerDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.DeptMangerServiceImpl
 * JD-Core Version:    0.6.2
 */
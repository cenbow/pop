/*      */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.common.cache.CacheFilter;
/*      */ import com.asiainfo.biframe.exception.CacheBaseException;
/*      */ import com.asiainfo.biframe.exception.ValidateException;
/*      */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*      */ import com.asiainfo.biframe.privilege.base.util.ValidateUtil;
/*      */ import com.asiainfo.biframe.privilege.cache.object.CacheUtils;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCityCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCompanyCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserDutyCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserGroupDefineCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserRoleCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserRoleClassifyCache;
/*      */ import com.asiainfo.biframe.privilege.dutyMaintain.service.IDutyAdminService;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*      */ import com.asiainfo.biframe.privilege.model.UserOperationDefine;
/*      */ import com.asiainfo.biframe.privilege.model.UserRole;
/*      */ import com.asiainfo.biframe.privilege.model.UserRoleClassify;
/*      */ import com.asiainfo.biframe.privilege.model.User_City;
/*      */ import com.asiainfo.biframe.privilege.model.User_Company;
/*      */ import com.asiainfo.biframe.privilege.model.User_Duty;
/*      */ import com.asiainfo.biframe.privilege.model.User_Group;
/*      */ import com.asiainfo.biframe.privilege.model.User_User;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IFileDataImportService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.ISysResourceTypeService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCityService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCompanyService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserOperationDefineService;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.PrintStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Queue;
/*      */ import org.apache.commons.collections.CollectionUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.orm.hibernate3.HibernateTransactionManager;
/*      */ import org.springframework.transaction.TransactionException;
/*      */ import org.springframework.transaction.TransactionStatus;
/*      */ import org.springframework.transaction.support.DefaultTransactionDefinition;
/*      */ 
/*      */ public class FileDataImportServiceImpl
/*      */   implements IFileDataImportService
/*      */ {
/*   88 */   private static Log log = LogFactory.getLog(FileDataImportServiceImpl.class);
/*      */   private IUserGroupAdminService userGroupAdminService;
/*      */   private IRoleAdminService roleAdminService;
/*      */   private IUserAdminService userAdminService;
/*      */   private IUserCityService userCityService;
/*      */   private IDutyAdminService dutyAdminService;
/*      */   private ISysResourceTypeService sysResourceTypeService;
/*      */   private IUserCompanyService userCompanyService;
/*      */   private IUserOperationDefineService userOperationDefineService;
/*      */   private final String GROUP_ADD;
/*      */   private final String GROUP_UPDATE;
/*      */   private final String GROUP_DELETE;
/*      */   private final String USER_ADD;
/*      */   private final String USER_UPDATE;
/*      */   private final String USER_DELETE;
/*      */   private final String USER_UNLOCK;
/*      */   private final String ROLE_ADD;
/*      */   private final String ROLE_DELETE;
/*      */   private final String RIGHT_ADD;
/*      */   private final String RIGHT_DELETE;
/*      */ 
/*      */   public FileDataImportServiceImpl()
/*      */   {
/*  107 */     this.GROUP_ADD = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.add") + "");
/*      */ 
/*  111 */     this.GROUP_UPDATE = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.mod") + "");
/*      */ 
/*  115 */     this.GROUP_DELETE = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cancel") + "");
/*      */ 
/*  120 */     this.USER_ADD = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.new") + "");
/*      */ 
/*  124 */     this.USER_UPDATE = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.mod") + "");
/*      */ 
/*  128 */     this.USER_DELETE = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delete") + "");
/*      */ 
/*  132 */     this.USER_UNLOCK = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unlock") + "");
/*      */ 
/*  137 */     this.ROLE_ADD = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.add") + "");
/*      */ 
/*  142 */     this.ROLE_DELETE = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cancel") + "");
/*      */ 
/*  147 */     this.RIGHT_ADD = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.add") + "");
/*      */ 
/*  152 */     this.RIGHT_DELETE = ("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cancel") + "");
/*      */   }
/*      */ 
/*      */   public void doImportGroupData(String filePath)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: new 31	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$1
/*      */     //   3: dup
/*      */     //   4: aload_0
/*      */     //   5: aload_1
/*      */     //   6: ldc 22
/*      */     //   8: ldc 32
/*      */     //   10: invokestatic 24	com/asiainfo/biframe/utils/i18n/LocaleUtil:getLocaleMessage	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   13: invokespecial 33	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$1:<init>	(Lcom/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   16: invokevirtual 34	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$1:doProcessFile	()V
/*      */     //   19: return
/*      */   }
/*      */ 
/*      */   public void doImportRoleData(String filePath)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: new 35	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$2
/*      */     //   3: dup
/*      */     //   4: aload_0
/*      */     //   5: aload_1
/*      */     //   6: ldc 22
/*      */     //   8: ldc 36
/*      */     //   10: invokestatic 24	com/asiainfo/biframe/utils/i18n/LocaleUtil:getLocaleMessage	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   13: invokespecial 37	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$2:<init>	(Lcom/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   16: invokevirtual 38	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$2:doProcessFile	()V
/*      */     //   19: return
/*      */   }
/*      */ 
/*      */   public void doImportRoleDataNew(String filePath)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: new 39	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$3
/*      */     //   3: dup
/*      */     //   4: aload_0
/*      */     //   5: aload_1
/*      */     //   6: ldc 22
/*      */     //   8: ldc 36
/*      */     //   10: invokestatic 24	com/asiainfo/biframe/utils/i18n/LocaleUtil:getLocaleMessage	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   13: invokespecial 40	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$3:<init>	(Lcom/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   16: invokevirtual 41	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$3:doProcessFile	()V
/*      */     //   19: return
/*      */   }
/*      */ 
/*      */   public void doImportUserData(String filePath)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: new 42	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$4
/*      */     //   3: dup
/*      */     //   4: aload_0
/*      */     //   5: aload_1
/*      */     //   6: ldc 22
/*      */     //   8: ldc 43
/*      */     //   10: invokestatic 24	com/asiainfo/biframe/utils/i18n/LocaleUtil:getLocaleMessage	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   13: invokespecial 44	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$4:<init>	(Lcom/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   16: invokevirtual 45	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$4:doProcessFile	()V
/*      */     //   19: return
/*      */   }
/*      */ 
/*      */   private TransactionStatus startTransaction()
/*      */     throws TransactionException
/*      */   {
/* 1876 */     log.debug("--begin--startTransaction");
/* 1877 */     DefaultTransactionDefinition def = new DefaultTransactionDefinition();
/* 1878 */     def.setPropagationBehavior(0);
/* 1879 */     return getTransactionManager().getTransaction(def);
/*      */   }
/*      */ 
/*      */   private void commitTransaction(TransactionStatus status)
/*      */     throws TransactionException
/*      */   {
/* 1889 */     log.debug("--begin--commitTransaction");
/* 1890 */     getTransactionManager().commit(status);
/* 1891 */     log.debug("--end--commitTransaction");
/*      */   }
/*      */ 
/*      */   private HibernateTransactionManager getTransactionManager() {
/*      */     try {
/* 1896 */       return (HibernateTransactionManager)SystemServiceLocator.getInstance().getService("transactionManager");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1900 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getTransactionBeanFail"));
/*      */ 
/* 1902 */       throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getTransactionBeanFail"), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public IUserGroupAdminService getUserGroupAdminService()
/*      */   {
/* 1909 */     return this.userGroupAdminService;
/*      */   }
/*      */ 
/*      */   public void setUserGroupAdminService(IUserGroupAdminService userGroupAdminService)
/*      */   {
/* 1914 */     this.userGroupAdminService = userGroupAdminService;
/*      */   }
/*      */ 
/*      */   public IRoleAdminService getRoleAdminService() {
/* 1918 */     return this.roleAdminService;
/*      */   }
/*      */ 
/*      */   public void setRoleAdminService(IRoleAdminService roleAdminService) {
/* 1922 */     this.roleAdminService = roleAdminService;
/*      */   }
/*      */ 
/*      */   public IUserAdminService getUserAdminService() {
/* 1926 */     return this.userAdminService;
/*      */   }
/*      */ 
/*      */   public void setUserAdminService(IUserAdminService userAdminService) {
/* 1930 */     this.userAdminService = userAdminService;
/*      */   }
/*      */ 
/*      */   public IUserCityService getUserCityService() {
/* 1934 */     return this.userCityService;
/*      */   }
/*      */ 
/*      */   public void setUserCityService(IUserCityService userCityService) {
/* 1938 */     this.userCityService = userCityService;
/*      */   }
/*      */ 
/*      */   public IDutyAdminService getDutyAdminService() {
/* 1942 */     return this.dutyAdminService;
/*      */   }
/*      */ 
/*      */   public void setDutyAdminService(IDutyAdminService dutyAdminService) {
/* 1946 */     this.dutyAdminService = dutyAdminService;
/*      */   }
/*      */ 
/*      */   public ISysResourceTypeService getSysResourceTypeService() {
/* 1950 */     return this.sysResourceTypeService;
/*      */   }
/*      */ 
/*      */   public void setSysResourceTypeService(ISysResourceTypeService sysResourceTypeService)
/*      */   {
/* 1955 */     this.sysResourceTypeService = sysResourceTypeService;
/*      */   }
/*      */ 
/*      */   public IUserCompanyService getUserCompanyService() {
/* 1959 */     return this.userCompanyService;
/*      */   }
/*      */ 
/*      */   public void setUserCompanyService(IUserCompanyService userCompanyService) {
/* 1963 */     this.userCompanyService = userCompanyService;
/*      */   }
/*      */ 
/*      */   public IUserOperationDefineService getUserOperationDefineService() {
/* 1967 */     return this.userOperationDefineService;
/*      */   }
/*      */ 
/*      */   public void setUserOperationDefineService(IUserOperationDefineService userOperationDefineService)
/*      */   {
/* 1972 */     this.userOperationDefineService = userOperationDefineService;
/*      */   }
/*      */ 
/*      */   public void doImportRightsData(String filePath)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: new 71	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$5
/*      */     //   3: dup
/*      */     //   4: aload_0
/*      */     //   5: aload_1
/*      */     //   6: ldc 22
/*      */     //   8: ldc 72
/*      */     //   10: invokestatic 24	com/asiainfo/biframe/utils/i18n/LocaleUtil:getLocaleMessage	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   13: invokespecial 73	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$5:<init>	(Lcom/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   16: invokevirtual 74	com/asiainfo/biframe/privilege/sysmanage/service/impl/FileDataImportServiceImpl$5:doProcessFile	()V
/*      */     //   19: return
/*      */   }
/*      */ 
/*      */   private abstract class AbstractFileImportTemplate
/*      */   {
/* 1627 */     private StringBuffer checkMsg = new StringBuffer();
/*      */ 
/* 1629 */     private Queue<String> checkMsgQ = new LinkedList();
/*      */     private String filePath;
/*      */     private String resourceName;
/*      */ 
/*      */     public AbstractFileImportTemplate()
/*      */     {
/*      */     }
/*      */ 
/*      */     public AbstractFileImportTemplate(String filePath)
/*      */     {
/* 1639 */       this.filePath = filePath;
/*      */     }
/*      */ 
/*      */     public AbstractFileImportTemplate(String filePath, String resourceName) {
/* 1643 */       this.filePath = filePath;
/* 1644 */       this.resourceName = resourceName;
/*      */     }
/*      */ 
/*      */     public final void doProcessFile() {
/* 1648 */       BufferedReader readerValidate = null;
/* 1649 */       BufferedReader readerProcess = null;
/* 1650 */       int num = 1;
/* 1651 */       int totalCount = 0; int wrongCount = 0;
/* 1652 */       TransactionStatus status = FileDataImportServiceImpl.this.startTransaction();
/*      */       try {
/* 1654 */         readerValidate = new BufferedReader(new InputStreamReader(new FileInputStream(this.filePath), "UTF-8"));
/*      */ 
/* 1664 */         String line = "";
/*      */ 
/* 1666 */         while ((line = readerValidate.readLine()) != null)
/* 1667 */           if (num == 1) {
/* 1668 */             num++;
/*      */           }
/*      */           else {
/* 1671 */             totalCount++;
/* 1672 */             if (StringUtils.isBlank(line)) {
/* 1673 */               num++;
/*      */             }
/*      */             else
/*      */             {
/*      */               try {
/* 1678 */                 validateData(line);
/*      */               } catch (Exception e) {
/* 1680 */                 String msg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail1") + "[" + num + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail2") + e.getMessage();
/*      */ 
/* 1690 */                 if (this.checkMsgQ.size() != 0)
/* 1691 */                   this.checkMsgQ.add(msg);
/*      */                 else {
/* 1693 */                   this.checkMsgQ.offer(msg);
/*      */                 }
/*      */               }
/* 1696 */               num++;
/*      */             }
/*      */           }
/* 1699 */         if (this.checkMsgQ.size() == 0)
/*      */         {
/* 1701 */           num = 1;
/*      */ 
/* 1705 */           readerProcess = new BufferedReader(new InputStreamReader(new FileInputStream(this.filePath), "UTF-8"));
/*      */ 
/* 1709 */           while ((line = readerProcess.readLine()) != null)
/* 1710 */             if (num == 1) {
/* 1711 */               num++;
/*      */             }
/* 1714 */             else if (StringUtils.isBlank(line)) {
/* 1715 */               num++;
/*      */             }
/*      */             else {
/*      */               try {
/* 1719 */                 doProcessLine(line);
/*      */               } catch (Exception e) {
/* 1721 */                 String msg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail1") + "[" + num + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail2") + e.getMessage();
/*      */ 
/* 1731 */                 if (this.checkMsgQ.size() != 0)
/* 1732 */                   this.checkMsgQ.add(msg);
/*      */                 else {
/* 1734 */                   this.checkMsgQ.offer(msg);
/*      */                 }
/*      */               }
/* 1737 */               num++;
/*      */             }
/*      */         }
/* 1740 */         wrongCount = this.checkMsgQ.size();
/*      */ 
/* 1742 */         if (this.checkMsgQ.size() > 0) {
/* 1743 */           String msg = "";
/* 1744 */           while ((msg = (String)this.checkMsgQ.poll()) != null) {
/* 1745 */             this.checkMsg.append("<ul>");
/* 1746 */             this.checkMsg.append("<li>" + msg + "</li>");
/* 1747 */             this.checkMsg.append("</ul>");
/*      */           }
/* 1749 */           throw new RuntimeException(this.checkMsg.toString());
/*      */         }
/*      */ 
/* 1753 */         FileDataImportServiceImpl.this.commitTransaction(status);
/* 1754 */         System.out.println(status);
/* 1755 */         doRefreshCache();
/*      */       } catch (FileNotFoundException e1) {
/* 1757 */         FileDataImportServiceImpl.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.fileNotFound") + "", e1);
/*      */ 
/* 1760 */         FileDataImportServiceImpl.this.getTransactionManager().rollback(status);
/* 1761 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.fileNotFound") + "" + e1.getMessage(), e1);
/*      */       }
/*      */       catch (IOException e2)
/*      */       {
/* 1766 */         FileDataImportServiceImpl.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.fileIOException"), e2);
/*      */ 
/* 1768 */         FileDataImportServiceImpl.this.getTransactionManager().rollback(status);
/* 1769 */         throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.fileIOException") + e2.getMessage(), e2);
/*      */       }
/*      */       catch (ValidateException e3)
/*      */       {
/* 1774 */         FileDataImportServiceImpl.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail1") + "[" + num + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail2") + "", e3);
/*      */ 
/* 1782 */         FileDataImportServiceImpl.this.getTransactionManager().rollback(status);
/* 1783 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail1") + "[" + num + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail2") + "" + e3.getMessage(), e3);
/*      */       }
/*      */       catch (CacheBaseException e4)
/*      */       {
/* 1793 */         FileDataImportServiceImpl.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.refreshCacheFail") + "", e4);
/*      */ 
/* 1796 */         FileDataImportServiceImpl.this.getTransactionManager().rollback(status);
/* 1797 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.refreshCacheFail") + ":" + e4.getMessage(), e4);
/*      */       }
/*      */       catch (Exception e5)
/*      */       {
/* 1802 */         FileDataImportServiceImpl.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail1") + "[" + num + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.importFileFail2") + "", e5);
/*      */ 
/* 1810 */         FileDataImportServiceImpl.this.getTransactionManager().rollback(status);
/*      */ 
/* 1814 */         throw new RuntimeException(e5.getMessage(), e5);
/*      */       } finally {
/*      */         try {
/* 1817 */           TransactionStatus log_status = FileDataImportServiceImpl.this.startTransaction();
/*      */ 
/* 1819 */           LogDetailUtil.log("13", "999", "用户，用户组，角色ID", this.resourceName, "导入数据" + totalCount + "条，合法数据" + (totalCount - wrongCount) + "条，非法数据" + wrongCount + "条，导入" + (wrongCount == 0 ? "成功" : "失败") + "!", null, null);
/*      */ 
/* 1825 */           FileDataImportServiceImpl.this.commitTransaction(log_status);
/* 1826 */           if (readerValidate != null) {
/* 1827 */             readerValidate.close();
/*      */           }
/* 1829 */           if (readerProcess != null)
/* 1830 */             readerProcess.close();
/*      */         }
/*      */         catch (Exception ie) {
/* 1833 */           throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.closeFileStreamFail") + "" + ie.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     protected abstract void validateData(String paramString)
/*      */       throws ValidateException;
/*      */ 
/*      */     protected abstract void doProcessLine(String paramString);
/*      */ 
/*      */     protected abstract void doRefreshCache()
/*      */       throws CacheBaseException;
/*      */ 
/*      */     protected void validateFlag(String flag, String msg)
/*      */       throws ValidateException
/*      */     {
/* 1854 */       if (StringUtils.isBlank(flag))
/* 1855 */         return;
/*      */       try
/*      */       {
/* 1858 */         ValidateUtil.assertRegEx(flag, "^(" + FileDataImportServiceImpl.this.USER_ADD + "|" + FileDataImportServiceImpl.this.USER_UPDATE + "|" + FileDataImportServiceImpl.this.USER_DELETE + "|" + FileDataImportServiceImpl.this.GROUP_ADD + "|" + FileDataImportServiceImpl.this.GROUP_DELETE + "|" + FileDataImportServiceImpl.this.GROUP_DELETE + "|" + FileDataImportServiceImpl.this.RIGHT_ADD + "|" + FileDataImportServiceImpl.this.RIGHT_DELETE + "|" + FileDataImportServiceImpl.this.GROUP_ADD + "|" + FileDataImportServiceImpl.this.ROLE_ADD + "|" + FileDataImportServiceImpl.this.ROLE_DELETE + ")$", msg);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 1864 */         System.out.println(e.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.FileDataImportServiceImpl
 * JD-Core Version:    0.6.2
 */
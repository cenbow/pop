/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.cache.object.SysMenuItemCache;
/*     */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*     */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IFileExportService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.ISysResourceTypeService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.util.ExportUtil;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class FileExportServiceImpl
/*     */   implements IFileExportService
/*     */ {
/*  38 */   private static Log log = LogFactory.getLog(FileExportServiceImpl.class);
/*     */   private IRoleAdminService roleAdminService;
/*     */   private ISysResourceTypeService sysResourceTypeService;
/*     */   private static final int MENU_ROLE_TYPE = 1;
/*     */   private static final int MENU_RESOURCE_TYPE = 50;
/*     */ 
/*     */   public void exportMatrixMenuData(PrintWriter pw)
/*     */     throws IOException
/*     */   {
/*  45 */     List headerList = new ArrayList();
/*  46 */     headerList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenuRightsExport"));
/*  47 */     String[][] resultArr = getMatrixMenuData4Exprot("old");
/*  48 */     ExportUtil.exportXls4MatrixRights(headerList, resultArr, pw);
/*     */   }
/*     */ 
/*     */   public void exportMatrixMenuDataNew(PrintWriter pw) throws IOException {
/*  52 */     List headerList = new ArrayList();
/*  53 */     headerList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenuRightsExport"));
/*  54 */     String[][] resultArr = getMatrixMenuData4Exprot("new");
/*  55 */     ExportUtil.exportXls4MatrixRights(headerList, resultArr, pw);
/*     */   }
/*     */ 
/*     */   public void exportRightsData(PrintWriter pw, List<String> resourceTypeList) throws Exception {
/*  59 */     Vector dataVector = processExportRightsList(resourceTypeList);
/*  60 */     dataVector.add(processExportTitle());
/*  61 */     ExportUtil.exportCSVFile(dataVector, pw);
/*     */   }
/*     */ 
/*     */   private List<String> getMenuLevelDescList()
/*     */   {
/*  68 */     List menuLevelList = new ArrayList();
/*  69 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu1"));
/*  70 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu2"));
/*  71 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu3"));
/*  72 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu4"));
/*  73 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu5"));
/*  74 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu6"));
/*  75 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu7"));
/*  76 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu8"));
/*  77 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu9"));
/*  78 */     menuLevelList.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriMenu10"));
/*  79 */     return menuLevelList;
/*     */   }
/*     */ 
/*     */   private int getMaxMenuLevel(Map<String, Right> menuMap, String menuId, int level)
/*     */   {
/*  92 */     if (menuMap.get(menuId) != null) {
/*  93 */       level++;
/*  94 */       level = getMaxMenuLevel(menuMap, ((Right)menuMap.get(menuId)).getParentId(), level);
/*     */     } else {
/*  96 */       return level;
/*     */     }
/*  98 */     return level;
/*     */   }
/*     */ 
/*     */   private Map<String, Right> rightList2Map(List<Right> rightList)
/*     */   {
/* 111 */     Map resultMap = new HashMap();
/* 112 */     for (Right right : rightList) {
/* 113 */       resultMap.put(right.getResourceId(), right);
/*     */     }
/* 115 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private Vector<String> processExportTitle()
/*     */   {
/* 127 */     Vector titleVector = new Vector();
/* 128 */     titleVector.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.operationType"));
/* 129 */     titleVector.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriUpRightName"));
/* 130 */     titleVector.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriRelativeMenuName"));
/* 131 */     titleVector.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleName"));
/* 132 */     titleVector.add(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exportPriFuncType"));
/* 133 */     return titleVector;
/*     */   }
/*     */ 
/*     */   private String[][] getMatrixMenuData4Exprot(String rightType)
/*     */   {
/* 146 */     List rightList = new ArrayList();
/*     */     try {
/* 148 */       rightList = getRoleAdminService().getAllRights(1, 50);
/*     */     } catch (Exception e) {
/* 150 */       log.error("Failed to getAllRights by roleType:[1] and resourceType:[50]");
/* 151 */       return getErrorInfoArr("Failed to get menus rights!");
/*     */     }
/*     */ 
/* 154 */     Map resultMap = rightList2Map(rightList);
/*     */ 
/* 156 */     int menuLevel = 1;
/* 157 */     for (Right right : rightList)
/*     */     {
/* 159 */       int level = getMaxMenuLevel(resultMap, right.getParentId(), 1);
/* 160 */       if (level > menuLevel) {
/* 161 */         menuLevel = level;
/*     */       }
/*     */     }
/* 164 */     log.debug("---menu level---:" + menuLevel);
/*     */ 
/* 167 */     List userRoleList = new ArrayList();
/* 168 */     if ("old".equals(rightType)) {
/* 169 */       UserRole paramRole = new UserRole();
/* 170 */       paramRole.setResourceType(50);
/* 171 */       userRoleList = getRoleAdminService().getUserRoleList(paramRole);
/*     */     } else {
/* 173 */       userRoleList = getRoleAdminService().findAll();
/*     */     }
/* 175 */     int rowLength = rightList.size() + 1;
/* 176 */     int columnLen = userRoleList.size() + menuLevel;
/*     */ 
/* 178 */     String[][] resultArr = new String[rowLength][columnLen];
/* 179 */     List rightIdList = new ArrayList();
/* 180 */     Map roleIndexMap = new HashMap();
/* 181 */     Map shareMenuMap = new HashMap();
/* 182 */     int resultRow = 1;
/*     */ 
/* 184 */     for (Right right : rightList) {
/* 185 */       SysMenuItemBean item = (SysMenuItemBean)SysMenuItemCache.getInstance().getObjectByKey(right.getResourceId());
/* 186 */       if ((item != null) && (item.getURL() != null) && (item.getURL().trim().length() >= 1))
/*     */       {
/* 189 */         if (item.getACCESSTOKEN() == 0) {
/* 190 */           shareMenuMap.put(right.getResourceId(), right.getResourceId());
/*     */         }
/* 192 */         rightIdList.add(right.getResourceId());
/* 193 */         int level = getMaxMenuLevel(resultMap, right.getParentId(), 0);
/* 194 */         String currentRightId = right.getResourceId();
/* 195 */         for (int m = level; m >= 0; m--) {
/* 196 */           resultArr[resultRow][m] = ((Right)resultMap.get(currentRightId)).getResourceName();
/* 197 */           currentRightId = right.getParentId();
/*     */         }
/* 199 */         resultRow++;
/*     */       }
/*     */     }
/* 201 */     log.debug("---export ---rows--:" + resultRow);
/* 202 */     log.debug("---export ---columns--:" + columnLen);
/*     */ 
/* 205 */     int k = menuLevel;
/*     */ 
/* 207 */     List menuLevelDescList = getMenuLevelDescList();
/* 208 */     for (int m = 0; m < menuLevel; m++) {
/* 209 */       resultArr[0][m] = ((String)menuLevelDescList.get(m));
/*     */     }
/*     */ 
/* 212 */     for (UserRole userRole : userRoleList) {
/* 213 */       roleIndexMap.put(userRole.getRoleId(), Integer.valueOf(k));
/* 214 */       resultArr[0][k] = userRole.getRoleName();
/* 215 */       k++;
/*     */     }
/*     */ 
/* 218 */     int rowCount = rightIdList.size();
/* 219 */     for (int n = 0; n < rowCount; n++) {
/* 220 */       String rightId = (String)rightIdList.get(n);
/*     */ 
/* 222 */       if (shareMenuMap.get(rightId) != null) {
/* 223 */         for (int allRow = menuLevel; allRow < columnLen; allRow++)
/* 224 */           resultArr[(n + 1)][allRow] = "*";
/*     */       }
/*     */       else {
/* 227 */         List roleRightList = getRoleAdminService().getRoleRightListByRight((Right)resultMap.get(rightId));
/*     */ 
/* 229 */         for (RoleRight roleRight : roleRightList) {
/* 230 */           if ((roleRight != null) && (roleRight.getRoleId() != null) && (roleIndexMap.get(roleRight.getRoleId()) != null)) {
/* 231 */             resultArr[(n + 1)][((Integer)roleIndexMap.get(roleRight.getRoleId())).intValue()] = "*";
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 236 */     String[][] dataArr = new String[resultRow][columnLen];
/* 237 */     for (int m = 0; m < resultRow; m++) {
/* 238 */       for (int n = 0; n < columnLen; n++) {
/* 239 */         dataArr[m][n] = resultArr[m][n];
/*     */       }
/*     */     }
/*     */ 
/* 243 */     return dataArr;
/*     */   }
/*     */ 
/*     */   private String[][] getErrorInfoArr(String errorInfo)
/*     */   {
/* 256 */     String[][] error = new String[1][1];
/* 257 */     error[0][0] = errorInfo;
/* 258 */     return error;
/*     */   }
/*     */ 
/*     */   private Vector<Vector<String>> processExportRightsList(List<String> resourceTypeList)
/*     */   {
/* 269 */     Vector dataList = new Vector();
/* 270 */     Vector detailDataList = null;
/* 271 */     Map errorDataMap = new HashMap();
/* 272 */     for (String typeStr : resourceTypeList) {
/* 273 */       int seperatorIndex = typeStr.indexOf("|");
/*     */ 
/* 275 */       sysResourceType = this.sysResourceTypeService.findBy(Integer.parseInt(typeStr.substring(seperatorIndex + 1, typeStr.length()).trim()), Integer.parseInt(typeStr.substring(0, seperatorIndex).trim()));
/*     */ 
/* 281 */       if (sysResourceType == null) break;
/* 282 */       log.debug("--sysResourceType---[" + sysResourceType.getResourceType() + "]:[" + sysResourceType.getResourcetypeName() + "]");
/*     */ 
/* 285 */       List rightList = new ArrayList();
/*     */       try {
/* 287 */         rightList = getRoleAdminService().getAllRights(sysResourceType.getRoleType(), sysResourceType.getResourceType());
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 291 */         String errorInfo = "ERROR: Filed to get rights by roleType:[" + sysResourceType.getRoleType() + "] and resourceType:[" + sysResourceType.getResourceType() + "]";
/*     */ 
/* 295 */         log.error(errorInfo);
/* 296 */         errorDataMap.put(errorInfo, errorInfo);
/* 297 */       }continue;
/*     */ 
/* 299 */       for (i$ = rightList.iterator(); i$.hasNext(); ) { right = (Right)i$.next();
/*     */ 
/* 301 */         IResourceRightDAO resourceRightDAO = null;
/*     */         try {
/* 303 */           resourceRightDAO = getRoleAdminService().getResourceRightDAO(sysResourceType.getRoleType(), sysResourceType.getResourceType());
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 308 */           log.error(e.getMessage());
/* 309 */           errorDataMap.put(e.getMessage(), e.getMessage());
/*     */         }
/* 311 */         parentName = "";
/*     */         try
/*     */         {
/* 314 */           if (resourceRightDAO != null) {
/* 315 */             Right parentRight = resourceRightDAO.getRight(right.getParentId());
/*     */ 
/* 317 */             if (parentRight != null) {
/* 318 */               parentName = parentRight.getResourceName();
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 324 */           String errorInfo = "ERROR: Failed to get resourceName by id:[" + right.getParentId() + "] in table:[" + sysResourceType.getResDefineTable() + "]";
/*     */ 
/* 329 */           log.error(errorInfo);
/* 330 */           errorDataMap.put(errorInfo, errorInfo);
/*     */         }
/* 332 */         List roleRightList = getRoleAdminService().getRoleRightListByRight(right);
/*     */ 
/* 334 */         if ((roleRightList != null) && (roleRightList.size() >= 1))
/*     */         {
/* 338 */           for (RoleRight roleRight : roleRightList) {
/* 339 */             UserRole userRole = null;
/*     */             try {
/* 341 */               userRole = getRoleAdminService().getRoleById(roleRight.getRoleId());
/*     */             }
/*     */             catch (Exception e)
/*     */             {
/* 345 */               log.error("getRoleById:", e);
/*     */             }
/* 347 */             if (userRole == null) {
/* 348 */               String errorInfo = "Failed to get UserRole by id " + roleRight.getRoleId() + " in table user_role";
/* 349 */               errorDataMap.put(errorInfo, errorInfo);
/*     */             }
/*     */             else {
/* 352 */               detailDataList = new Vector();
/* 353 */               detailDataList.add(sysResourceType.getResourcetypeName());
/*     */ 
/* 355 */               detailDataList.add(parentName);
/* 356 */               detailDataList.add(right.getResourceName());
/* 357 */               detailDataList.add(userRole.getRoleName());
/* 358 */               detailDataList.add(right.getOperationName());
/* 359 */               dataList.add(detailDataList);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     SysResourceType sysResourceType;
/*     */     Iterator i$;
/*     */     Right right;
/*     */     String parentName;
/* 368 */     return dataList;
/*     */   }
/*     */ 
/*     */   public IRoleAdminService getRoleAdminService() {
/* 372 */     return this.roleAdminService;
/*     */   }
/*     */ 
/*     */   public void setRoleAdminService(IRoleAdminService roleAdminService) {
/* 376 */     this.roleAdminService = roleAdminService;
/*     */   }
/*     */ 
/*     */   public void setSysResourceTypeService(ISysResourceTypeService sysResourceTypeService) {
/* 380 */     this.sysResourceTypeService = sysResourceTypeService;
/*     */   }
/*     */ 
/*     */   public ISysResourceTypeService getSysResourceTypeService() {
/* 384 */     return this.sysResourceTypeService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.FileExportServiceImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserGroup;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.model.FirstpagesetParam;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IFirstPageParamDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IFirstPageSetService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ 
/*     */ public class FirstPageSetServiceImpl
/*     */   implements IFirstPageSetService
/*     */ {
/*     */   private IFirstPageParamDAO firstpageDao;
/*     */   private IUserGroupDAO roleDao;
/*  31 */   private Log log = LogFactory.getLog("FirstPageSetServiceImpl.class");
/*     */ 
/*     */   public String saveFirstPageSet(FirstpagesetParam ps)
/*     */     throws Exception
/*     */   {
/*  41 */     String remsg = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveSuccess") + "";
/*  42 */     String errormsg = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveFailure") + "";
/*     */     try
/*     */     {
/*  45 */       String roleId = ps.getOperatorId();
/*  46 */       if (this.firstpageDao.getPageSet(roleId) != null)
/*     */       {
/*  48 */         if (!this.firstpageDao.deletePageSet(roleId))
/*     */         {
/*  50 */           remsg = errormsg;
/*     */         }
/*     */       }
/*  53 */       if (!this.firstpageDao.savePageSet(ps))
/*     */       {
/*  55 */         remsg = errormsg;
/*     */       }
/*     */ 
/*  67 */       return remsg;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  58 */       e = 
/*  67 */         e;
/*     */ 
/*  60 */       this.log.error("", e);
/*  61 */       remsg = errormsg;
/*  62 */       throw new Exception();
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*  67 */     return remsg;
/*     */   }
/*     */ 
/*     */   public String deleteFirstPageSet(String roleId)
/*     */   {
/*  78 */     String msg = "";
/*  79 */     if ((null == roleId) || (roleId.length() < 1))
/*     */     {
/*  81 */       msg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleNotExist");
/*  82 */       return msg;
/*     */     }
/*     */ 
/*  85 */     if (this.firstpageDao.deletePageSet(roleId))
/*     */     {
/*  87 */       msg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteSuccess");
/*     */     }
/*     */     else
/*     */     {
/*  91 */       msg = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteFail") + "";
/*     */     }
/*  93 */     LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), roleId, roleId, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupFirstPageSet") + "", null, null);
/*     */ 
/*  96 */     return msg;
/*     */   }
/*     */ 
/*     */   public List<FirstpagesetParam> getAllPageSet()
/*     */   {
/* 105 */     return this.firstpageDao.getAllPageSet();
/*     */   }
/*     */ 
/*     */   public String getRoleName(String roleId)
/*     */   {
/* 114 */     String rolename = this.roleDao.getGroupName(roleId);
/*     */ 
/* 119 */     return rolename;
/*     */   }
/*     */ 
/*     */   public List<LabelValueBean> getAllRoles()
/*     */   {
/* 127 */     List reList = new ArrayList();
/* 128 */     List list = this.roleDao.getAllUserGroupList();
/* 129 */     if ((list != null) && (list.size() > 0))
/*     */     {
/* 131 */       Iterator i = list.iterator();
/* 132 */       while (i.hasNext()) {
/* 133 */         IUserGroup role = (IUserGroup)i.next();
/* 134 */         String groupname = role.getGroupname();
/*     */ 
/* 139 */         reList.add(new LabelValueBean(groupname, role.getGroupid()));
/*     */       }
/*     */     }
/* 142 */     return reList;
/*     */   }
/*     */ 
/*     */   public FirstpagesetParam getPageSet(String roleId)
/*     */   {
/* 152 */     return this.firstpageDao.getPageSet(roleId);
/*     */   }
/*     */ 
/*     */   public IFirstPageParamDAO getFirstpageDao() {
/* 156 */     return this.firstpageDao;
/*     */   }
/*     */ 
/*     */   public void setFirstpageDao(IFirstPageParamDAO firstpageDao) {
/* 160 */     this.firstpageDao = firstpageDao;
/*     */   }
/*     */ 
/*     */   public IUserGroupDAO getRoleDao() {
/* 164 */     return this.roleDao;
/*     */   }
/*     */ 
/*     */   public void setRoleDao(IUserGroupDAO roleDao) {
/* 168 */     this.roleDao = roleDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.FirstPageSetServiceImpl
 * JD-Core Version:    0.6.2
 */
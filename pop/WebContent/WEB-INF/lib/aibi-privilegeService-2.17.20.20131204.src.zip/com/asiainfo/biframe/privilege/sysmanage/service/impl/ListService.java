/*      */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.common.cache.CacheFilter;
/*      */ import com.asiainfo.biframe.exception.ServiceException;
/*      */ import com.asiainfo.biframe.privilege.base.constants.PrivilegeCodes;
/*      */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCityCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserDutyCache;
/*      */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*      */ import com.asiainfo.biframe.privilege.model.UserRole;
/*      */ import com.asiainfo.biframe.privilege.model.User_City;
/*      */ import com.asiainfo.biframe.privilege.model.User_Company;
/*      */ import com.asiainfo.biframe.privilege.model.User_Duty;
/*      */ import com.asiainfo.biframe.privilege.model.User_Group;
/*      */ import com.asiainfo.biframe.privilege.model.User_User;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.constants.GroupConstants;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.constants.RoleConstants;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.constants.UserConstants;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.ISysResourceTypeService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCompanyService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.apache.struts.util.LabelValueBean;
/*      */ 
/*      */ public class ListService
/*      */ {
/*   58 */   private static Logger log = Logger.getLogger(ListService.class);
/*      */ 
/*      */   private static IUserAdminService getUserAdminService() {
/*      */     try {
/*   62 */       return (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/*      */     } catch (Exception e) {
/*   64 */       log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*   65 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static IUserGroupAdminService getUserGroupAdminService() {
/*      */     try {
/*   71 */       return (IUserGroupAdminService)SystemServiceLocator.getInstance().getService("right_userGroupAdminService");
/*      */     } catch (Exception e) {
/*   73 */       log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*   74 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected static final IUserCompanyService getUserCompanyService() {
/*      */     try {
/*   80 */       return (IUserCompanyService)SystemServiceLocator.getInstance().getService("right_userCompanyService");
/*      */     } catch (Exception e) {
/*   82 */       log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*   83 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static List getAllCityList()
/*      */   {
/*   93 */     List cityList = new ArrayList();
/*   94 */     Iterator it = UserCityCache.getInstance().getAllCachedObject().iterator();
/*   95 */     while (it.hasNext()) {
/*   96 */       cityList.add(it.next());
/*      */     }
/*   98 */     return cityList;
/*      */   }
/*      */ 
/*      */   public static void getCityList(String cityId, List cityList)
/*      */   {
/*  124 */     List selCity = UserCityCache.getInstance().getCityListByFilter(new CacheFilter()
/*      */     {
/*      */       public boolean match(Object obj)
/*      */       {
/*  116 */         if (obj == null) {
/*  117 */           return false;
/*      */         }
/*  119 */         return ((User_City)obj).getParentId().equals(ListService.this);
/*      */       }
/*      */     });
/*  125 */     for (int i = 0; i < selCity.size(); i++) {
/*  126 */       Object obj = selCity.get(i);
/*  127 */       if (obj != null)
/*      */       {
/*  130 */         cityList.add(obj);
/*  131 */         getCityList(((User_City)obj).getCityId(), cityList);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static List<User_City> getAuthCityList(String userId, String resourceType)
/*      */   {
/*  146 */     Sqlca m_Sqlca = null;
/*  147 */     List list = new ArrayList();
/*      */     try {
/*  149 */       m_Sqlca = new Sqlca(new ConnectionEx());
/*      */ 
/*  151 */       List cities = new ArrayList();
/*  152 */       if (resourceType.equals("0"))
/*  153 */         cities = getUserGroupAdminService().getRightByGroup(userId, 0, Integer.parseInt("5"), false);
/*      */       else {
/*  155 */         cities = getUserAdminService().getRight(userId, 0, Integer.parseInt("5"), false);
/*      */       }
/*      */ 
/*  159 */       List cityIds = convertToNewList(cities, "ResourceId");
/*  160 */       if ((cityIds != null) && (cityIds.size() > 0))
/*      */       {
/*  162 */         citySet = new HashSet();
/*  163 */         for (String cityId : cityIds) {
/*  164 */           User_City tmpObj = (User_City)UserCityCache.getInstance().getObjectByKey(cityId);
/*  165 */           if (!citySet.contains(tmpObj)) {
/*  166 */             list.add(tmpObj);
/*  167 */             citySet.add(tmpObj);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       Set citySet;
/*  172 */       log.error("getAuthCityList " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */     finally
/*      */     {
/*  176 */       if (m_Sqlca != null)
/*  177 */         m_Sqlca.closeAll();
/*      */     }
/*  179 */     return list;
/*      */   }
/*      */ 
/*      */   public static List<User_Duty> getAuthDutyList(String id, String type)
/*      */   {
/*  193 */     List list = new ArrayList();
/*      */     try {
/*  195 */       List cities = new ArrayList();
/*  196 */       List cityIds = convertToNewList(cities, "ResourceId");
/*  197 */       if (type.equals("0")) {
/*  198 */         cities = getUserGroupAdminService().getRightByGroup(id, 0, Integer.parseInt("5"), false);
/*  199 */         cityIds = convertToNewList(cities, "ResourceId");
/*  200 */       } else if (type.equals("1")) {
/*  201 */         cities = getUserAdminService().getRight(id, 0, Integer.parseInt("5"), false);
/*  202 */         cityIds = convertToNewList(cities, "ResourceId");
/*      */       } else {
/*  204 */         User_User user = (User_User)UserCache.getInstance().getObjectByKey(id);
/*  205 */         String cityId = user.getCityid();
/*  206 */         List userCities = null;
/*      */ 
/*  208 */         if ((getUserAdminService().isAdminUser(id)) || (cityId.equals(Configure.getInstance().getProperty("CENTER_CITYID"))))
/*  209 */           userCities = getUserAdminService().getRight(id, 0, Integer.parseInt("5"), false);
/*      */         else {
/*  211 */           userCities = getUserAdminService().getUserRightList(id, Integer.parseInt("5"), 0, false);
/*      */         }
/*  213 */         cityIds = convertToNewList(userCities, "ResourceId");
/*      */       }
/*      */ 
/*  216 */       String strCitys = StringUtil.list2String(cityIds, ",", true);
/*      */ 
/*  218 */       Collection collection = UserDutyCache.getInstance().getAllCachedObject();
/*  219 */       Iterator it = collection.iterator();
/*  220 */       while (it.hasNext()) {
/*  221 */         User_Duty duty = (User_Duty)it.next();
/*  222 */         String cityId = duty.getCityid();
/*  223 */         if (("-1".equals(cityId)) || (strCitys.indexOf("'" + cityId + "'") != -1))
/*  224 */           list.add(duty);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  228 */       log.error("getAuthDutyList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  232 */     return list;
/*      */   }
/*      */ 
/*      */   public static List getAuthCityBeanList(String userId, String type)
/*      */   {
/*  243 */     List list = getAuthCityList(userId, type);
/*      */ 
/*  245 */     List returnList = new ArrayList();
/*  246 */     if (list != null) {
/*  247 */       for (int i = 0; i < list.size(); i++) {
/*  248 */         User_City uc = (User_City)list.get(i);
/*  249 */         returnList.add(new LabelValueBean(uc.getCityName(), "" + uc.getCityId()));
/*      */       }
/*      */     }
/*  252 */     return returnList;
/*      */   }
/*      */ 
/*      */   public static List getCityBeanList(String cityId)
/*      */   {
/*  262 */     List list = new ArrayList();
/*  263 */     getCityList(cityId, list);
/*      */ 
/*  265 */     List returnList = new ArrayList();
/*  266 */     if (list != null) {
/*  267 */       for (int i = 0; i < list.size(); i++) {
/*  268 */         User_City uc = (User_City)list.get(i);
/*  269 */         returnList.add(new LabelValueBean(uc.getCityName(), "" + uc.getCityId()));
/*      */       }
/*      */     }
/*  272 */     return returnList;
/*      */   }
/*      */ 
/*      */   public static List getAllDepartmentBeanList()
/*      */   {
/*  312 */     List list = getUserCompanyService().getAllDept();
/*  313 */     List returnList = new ArrayList();
/*  314 */     if (list != null) {
/*  315 */       for (int i = 0; i < list.size(); i++) {
/*  316 */         User_Company uc = (User_Company)list.get(i);
/*  317 */         returnList.add(new LabelValueBean(uc.getTitle(), "" + uc.getDeptid()));
/*      */       }
/*      */     }
/*  320 */     return returnList;
/*      */   }
/*      */ 
/*      */   public static List<User_Group> getSubGroup(String userid)
/*      */   {
/*      */     try
/*      */     {
/*  331 */       String groupId = getUserAdminService().getGroup(userid);
/*  332 */       List groupList = new ArrayList();
/*  333 */       if (groupId != null);
/*  334 */       return getUserGroupAdminService().getAllSubGroup(groupId);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  338 */       log.error("getSubGroup" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  341 */     throw new SysmanageException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getSubGroupFail") + ":" + userid);
/*      */   }
/*      */ 
/*      */   public static List getSubGroupBeans(String userid)
/*      */   {
/*  346 */     List list = getSubGroup(userid);
/*  347 */     List returnList = new ArrayList();
/*  348 */     if (list != null) {
/*  349 */       for (int i = 0; i < list.size(); i++) {
/*  350 */         User_Group ug = (User_Group)list.get(i);
/*  351 */         returnList.add(new LabelValueBean(ug.getGroupname(), ug.getGroupid()));
/*      */       }
/*      */     }
/*  354 */     return returnList;
/*      */   }
/*      */ 
/*      */   public static List getResourceStatusBeanList()
/*      */   {
/*  364 */     List list = new ArrayList();
/*  365 */     Vector vect = PrivilegeCodes.getDictIDs(Integer.parseInt("0"));
/*  366 */     if (null == vect) {
/*  367 */       return list;
/*      */     }
/*  369 */     for (int i = 0; i < vect.size(); i++) {
/*  370 */       String strID = (String)vect.elementAt(i);
/*  371 */       String strName = PrivilegeCodes.getDictName(Integer.parseInt("0"), Integer.parseInt(strID));
/*  372 */       if (null != strName)
/*      */       {
/*  375 */         list.add(new LabelValueBean(strName, strID));
/*      */       }
/*      */     }
/*  378 */     return list;
/*      */   }
/*      */ 
/*      */   public static List getSimpleResourceStatusBeanList()
/*      */   {
/*  387 */     List list = new ArrayList();
/*  388 */     list.add(new LabelValueBean("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.normal") + "", "0"));
/*  389 */     list.add(new LabelValueBean("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.illegal") + "", "1"));
/*  390 */     return list;
/*      */   }
/*      */ 
/*      */   public static List<LabelValueBean> getRoleTypeBeanList()
/*      */   {
/*  399 */     List list = PrivilegeCodes.getDictList(106);
/*  400 */     return list;
/*      */   }
/*      */ 
/*      */   private static List<LabelValueBean> getStatusBeanList(Map<String, String> statusMap)
/*      */   {
/*  405 */     log.debug(" in getStatusBeanList");
/*  406 */     List list = new ArrayList();
/*  407 */     for (Map.Entry entry : statusMap.entrySet()) {
/*  408 */       list.add(new LabelValueBean((String)entry.getValue(), (String)entry.getKey()));
/*      */     }
/*  410 */     log.debug(" end getStatusBeanList");
/*  411 */     return list;
/*      */   }
/*      */ 
/*      */   public static List getUserStatusBeanList()
/*      */   {
/*  419 */     return getStatusBeanList(UserConstants.putStatusMap());
/*      */   }
/*      */ 
/*      */   public static List<LabelValueBean> getUserGroupStatusBeanList()
/*      */   {
/*  428 */     return getStatusBeanList(GroupConstants.statusMap);
/*      */   }
/*      */ 
/*      */   public static List<LabelValueBean> getRoleStatusBeanList()
/*      */   {
/*  439 */     return getStatusBeanList(RoleConstants.statusMap);
/*      */   }
/*      */ 
/*      */   public static List getRoleBeanList()
/*      */   {
/*  448 */     List list = new ArrayList();
/*      */     try {
/*  450 */       IRoleAdminService roleService = (IRoleAdminService)SystemServiceLocator.getInstance().getService("right_roleAdminService");
/*  451 */       List rList = roleService.findAll();
/*  452 */       if (rList != null)
/*  453 */         for (int i = 0; i < rList.size(); i++) {
/*  454 */           UserRole ur = (UserRole)rList.get(i);
/*  455 */           list.add(new LabelValueBean(ur.getRoleName(), ur.getRoleId()));
/*      */         }
/*      */     }
/*      */     catch (Exception e) {
/*  459 */       log.error("getRoleBeanList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  463 */     return list;
/*      */   }
/*      */ 
/*      */   public static String getSysResourceTypeArray(String arrayName, boolean addScriptHead)
/*      */   {
/*  475 */     StringBuffer scriptSB = new StringBuffer();
/*      */     try {
/*  477 */       ISysResourceTypeService resourceTypeService = (ISysResourceTypeService)SystemServiceLocator.getInstance().getService("right_sysResourceTypeService");
/*      */ 
/*  479 */       List list = resourceTypeService.findAll();
/*  480 */       if ((null == list) || (list.size() < 1)) {
/*  481 */         return "";
/*      */       }
/*  483 */       if (addScriptHead) {
/*  484 */         scriptSB.append("<script language=\"javascript\" >\n");
/*      */       }
/*      */ 
/*  487 */       scriptSB.append("var " + arrayName + " = new Array();\n");
/*      */ 
/*  489 */       for (int i = 0; i < list.size(); i++) {
/*  490 */         SysResourceType resourceType = (SysResourceType)list.get(i);
/*  491 */         scriptSB.append("" + arrayName + "[" + (i + 1) + "] = new Array('" + resourceType.getResourcetypeName() + "','" + resourceType.getResourceType() + "','" + resourceType.getRoleType() + "');\n");
/*      */       }
/*      */ 
/*  503 */       if (addScriptHead)
/*  504 */         scriptSB.append("</script>\n");
/*      */     }
/*      */     catch (Exception e) {
/*  507 */       log.error("getSysResourceTypeArray" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  512 */     return scriptSB.toString();
/*      */   }
/*      */ 
/*      */   public static List<LabelValueBean> getSysResourceBeanList(int roleType)
/*      */   {
/*  522 */     log.debug(" in getSysResourceBeanList");
/*  523 */     List list = new ArrayList();
/*      */     try
/*      */     {
/*  526 */       Collection resTypes = SysResourceTypeCache.getInstance().getAllCachedSortedObject();
/*  527 */       if ((null == resTypes) || (resTypes.size() < 1)) {
/*  528 */         return list;
/*      */       }
/*  530 */       for (SysResourceType resType : resTypes)
/*  531 */         if (roleType == resType.getRoleType())
/*      */         {
/*  534 */           list.add(new LabelValueBean(resType.getResourcetypeName(), String.valueOf(resType.getResourceType())));
/*      */         }
/*      */     } catch (Exception e) {
/*  537 */       log.error("getSysResourceBeanList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  542 */     return list;
/*      */   }
/*      */ 
/*      */   public static List changeUserGroup2LabelValueBean(List list)
/*      */   {
/*  553 */     List result = new ArrayList();
/*      */ 
/*  555 */     if ((list == null) || (list.size() == 0)) {
/*  556 */       return result;
/*      */     }
/*  558 */     for (int i = 0; i < list.size(); i++)
/*      */     {
/*  560 */       User_Group ug = (User_Group)list.get(i);
/*  561 */       result.add(new LabelValueBean(ug.getGroupname(), ug.getGroupid()));
/*      */     }
/*      */ 
/*  564 */     return result;
/*      */   }
/*      */ 
/*      */   public static List changeUserUser2LabelValueBean(List list)
/*      */   {
/*  575 */     List result = new ArrayList();
/*      */ 
/*  577 */     if ((list == null) || (list.size() == 0)) {
/*  578 */       return result;
/*      */     }
/*  580 */     for (int i = 0; i < list.size(); i++)
/*      */     {
/*  582 */       User_User uu = (User_User)list.get(i);
/*  583 */       result.add(new LabelValueBean(uu.getUsername(), uu.getUserid()));
/*      */     }
/*      */ 
/*  586 */     return result;
/*      */   }
/*      */ 
/*      */   public static List changeUserRole2LabelValueBean(List list)
/*      */   {
/*  597 */     List result = new ArrayList();
/*      */ 
/*  599 */     if ((list == null) || (list.size() == 0)) {
/*  600 */       return result;
/*      */     }
/*  602 */     for (int i = 0; i < list.size(); i++)
/*      */     {
/*  604 */       UserRole ur = (UserRole)list.get(i);
/*  605 */       result.add(new LabelValueBean(ur.getRoleName(), ur.getRoleId()));
/*      */     }
/*      */ 
/*  608 */     return result;
/*      */   }
/*      */ 
/*      */   public static List filterSelectedObjList(List objList, List selectedList)
/*      */   {
/*  620 */     List result = new ArrayList();
/*      */ 
/*  622 */     if ((objList == null) || (objList.size() == 0)) {
/*  623 */       return result;
/*      */     }
/*  625 */     if ((selectedList == null) || (selectedList.size() == 0)) {
/*  626 */       return objList;
/*      */     }
/*  628 */     objList.removeAll(selectedList);
/*      */ 
/*  630 */     return objList;
/*      */   }
/*      */ 
/*      */   public static List interactSelectedObjList(List objList, List selectedList)
/*      */   {
/*  642 */     List result = new ArrayList();
/*      */ 
/*  644 */     if ((objList == null) || (objList.size() == 0)) {
/*  645 */       return result;
/*      */     }
/*  647 */     if ((selectedList == null) || (selectedList.size() == 0)) {
/*  648 */       return result;
/*      */     }
/*  650 */     objList.retainAll(selectedList);
/*      */ 
/*  652 */     return objList;
/*      */   }
/*      */ 
/*      */   public static String getUserGroupArray(String loginGroupId, String arrayName, boolean addScriptHead)
/*      */   {
/*  665 */     StringBuffer scriptSB = new StringBuffer();
/*      */     try
/*      */     {
/*  668 */       IUserGroupAdminService groupService = getUserGroupAdminService();
/*  669 */       List list = null;
/*  670 */       if (loginGroupId.equals("0"))
/*  671 */         list = groupService.getAllSubGroup("1");
/*      */       else
/*  673 */         list = groupService.getSubGroup(loginGroupId);
/*  674 */       if ((null == list) || (list.size() < 1)) {
/*  675 */         return "";
/*      */       }
/*      */ 
/*  678 */       if (addScriptHead) {
/*  679 */         scriptSB.append("<script language=\"javascript\" >\n");
/*      */       }
/*  681 */       scriptSB.append("var " + arrayName + " = new Array();\n");
/*  682 */       int n = 0;
/*  683 */       for (int i = 0; i < list.size(); i++) {
/*  684 */         User_Group group = (User_Group)list.get(i);
/*  685 */         String groupId = group.getGroupid();
/*  686 */         List userList = getUserGroupAdminService().getUsersByGroupId(groupId);
/*  687 */         if ((null != userList) && (userList.size() >= 1))
/*      */         {
/*  690 */           for (int j = 0; j < userList.size(); j++) {
/*  691 */             n++;
/*  692 */             User_User user = (User_User)userList.get(j);
/*  693 */             scriptSB.append("" + arrayName + "[" + n + "] = new Array('" + user.getUsername() + "','" + user.getUserid() + "','" + groupId + "');\n");
/*      */           }
/*      */         }
/*      */       }
/*  697 */       if (addScriptHead)
/*  698 */         scriptSB.append("</script>\n");
/*      */     }
/*      */     catch (Exception e) {
/*  701 */       log.error("getUserGroupArray" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  706 */     return scriptSB.toString();
/*      */   }
/*      */ 
/*      */   public static List<String> convertToNewList(List list, String fieldName)
/*      */     throws Exception
/*      */   {
/*  718 */     List returnList = new ArrayList();
/*  719 */     if ((list == null) || (list.size() == 0))
/*  720 */       return returnList;
/*      */     try
/*      */     {
/*  723 */       Class cls = null;
/*  724 */       Method method = null;
/*  725 */       Object retObj = null;
/*  726 */       for (int i = 0; i < list.size(); i++) {
/*  727 */         cls = list.get(i).getClass();
/*  728 */         method = cls.getMethod("get" + fieldName, null);
/*  729 */         retObj = method.invoke(list.get(i), null);
/*  730 */         if (retObj != null)
/*      */         {
/*  733 */           String id = String.valueOf(retObj);
/*  734 */           returnList.add(id);
/*      */         }
/*      */       }
/*      */     } catch (Exception e) { log.error("convertToNewList" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  740 */       throw e;
/*      */     }
/*  742 */     return returnList;
/*      */   }
/*      */ 
/*      */   public static List getMenu(Sqlca sqlcaInit, List idList)
/*      */     throws Exception
/*      */   {
/*  818 */     return getMenu(sqlcaInit, idList, false);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public static List getMenu(Sqlca sqlcaInit, List idList, boolean isContainEmptyDir)
/*      */     throws Exception
/*      */   {
/*  832 */     List returnList = new ArrayList();
/*  833 */     if ((idList == null) || (idList.size() == 0)) {
/*  834 */       return returnList;
/*      */     }
/*      */ 
/*  837 */     String ids = StringUtil.list2String(idList, ",", false);
/*  838 */     String sql = "select menuitemid, menuitemtitle, parentid, url, pic1, pic2,urltarget,MENUTYPE,ACCESSTOKEN,RESID,URLPORT,APPLICATION_ID,sortnum  from sys_menu_item  order by parentid, sortnum";
/*      */ 
/*  841 */     log.info("----sql=" + sql);
/*  842 */     Sqlca sqlca = new Sqlca(sqlcaInit.getConnection());
/*  843 */     Sqlca sqlca2 = new Sqlca(sqlca.getConnection());
/*      */     try {
/*  845 */       sqlca.execute(sql);
/*  846 */       List smiList = new ArrayList();
/*  847 */       List parentList = new ArrayList();
/*  848 */       while (sqlca.next()) {
/*  849 */         SysMenuItemBean smi = new SysMenuItemBean();
/*  850 */         int id = sqlca.getInt("menuitemid");
/*  851 */         if (idList.contains(String.valueOf(id)))
/*      */         {
/*  853 */           smi.setMENUITEMID(id);
/*  854 */           smi.setMENUITEMTITLE(sqlca.getString("menuitemtitle"));
/*  855 */           smi.setPARENTID(sqlca.getInt("parentid"));
/*  856 */           smi.setURL(sqlca.getString("url"));
/*  857 */           smi.setPIC1(sqlca.getString("pic1"));
/*  858 */           smi.setPIC2(sqlca.getString("pic2"));
/*  859 */           smi.setURLTARGET(sqlca.getString("urltarget"));
/*      */ 
/*  861 */           smi.setMENUTYPE(sqlca.getInt("MENUTYPE"));
/*  862 */           smi.setACCESSTOKEN(sqlca.getInt("ACCESSTOKEN"));
/*  863 */           smi.setRESID(sqlca.getString("RESID"));
/*  864 */           smi.setURLPORT(sqlca.getString("URLPORT"));
/*  865 */           smi.setApplicationId(sqlca.getString("APPLICATION_ID"));
/*  866 */           smi.setSORTNUM(sqlca.getInt("sortnum"));
/*      */ 
/*  868 */           smiList.add(smi);
/*  869 */           returnList.add(smi);
/*  870 */           parentList.add(Integer.valueOf(sqlca.getInt("parentid")));
/*      */         }
/*      */       }
/*  872 */       if (!isContainEmptyDir)
/*  873 */         for (int i = 0; i < smiList.size(); i++) {
/*  874 */           SysMenuItemBean sMenuItem = (SysMenuItemBean)smiList.get(i);
/*  875 */           if ((sMenuItem.getPARENTID() == 0) && (!parentList.contains(Integer.valueOf(sMenuItem.getMENUITEMID()))))
/*  876 */             returnList.remove(sMenuItem);
/*      */         }
/*      */     } catch (Exception e) {
/*  879 */       log.error("getMenu" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  882 */       throw e;
/*      */     } finally {
/*  884 */       if (sqlca != null) {
/*  885 */         sqlca2.close();
/*  886 */         sqlca.closeAll();
/*      */       }
/*      */     }
/*      */ 
/*  890 */     return returnList;
/*      */   }
/*      */ 
/*      */   public static List getFields(List idList, boolean addComma, String idName, String fieldName, String tableName)
/*      */     throws Exception
/*      */   {
/*  904 */     List returnList = new ArrayList();
/*  905 */     if ((idList == null) || (idList.size() == 0)) {
/*  906 */       return returnList;
/*      */     }
/*      */ 
/*  909 */     String ids = StringUtil.list2String(idList, ",", addComma);
/*  910 */     String sql = "select " + fieldName + " from " + tableName + " where " + idName + " in(" + ids + ")";
/*  911 */     log.info("----sql=" + sql);
/*  912 */     Sqlca sqlca = new Sqlca(new ConnectionEx());
/*      */     try {
/*  914 */       sqlca.execute(sql);
/*  915 */       while (sqlca.next())
/*  916 */         returnList.add(sqlca.getString(1));
/*      */     }
/*      */     catch (Exception e) {
/*  919 */       log.error("getFields" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  922 */       throw e;
/*      */     } finally {
/*  924 */       if (sqlca != null) {
/*  925 */         sqlca.closeAll();
/*      */       }
/*      */     }
/*      */ 
/*  929 */     return returnList;
/*      */   }
/*      */ 
/*      */   public static void deleteBalanceServerRole(String gid, String groupName) {
/*  933 */     Sqlca sqlca = null;
/*      */ 
/*  935 */     boolean flag = true;
/*      */ 
/*  937 */     if (gid.contains("!!")) {
/*  938 */       gid = gid.split("!!")[0];
/*  939 */       flag = false;
/*      */     }try {
/*  941 */       sqlca = new Sqlca(new ConnectionEx());
/*      */ 
/*  943 */       String sql = "delete from balance_server_role where groupid='" + gid + "'";
/*  944 */       log.debug("--sql:" + sql);
/*  945 */       sqlca.execute(sql);
/*  946 */       if (flag) {
/*  947 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), gid, groupName, " " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupBalance") + "", null, null);
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  953 */       log.error("deleteBalanceServerRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */     finally
/*      */     {
/*  957 */       if (sqlca != null)
/*  958 */         sqlca.closeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static List getParentIds(List list, String topId, String id)
/*      */   {
/*  965 */     List result = new ArrayList();
/*  966 */     User_City rdBean = getById(list, id);
/*  967 */     while ((rdBean != null) && 
/*  968 */       (!rdBean.getParentId().equals(topId)))
/*      */     {
/*  970 */       result.add(rdBean.getParentId());
/*  971 */       rdBean = getById(list, rdBean.getParentId());
/*      */     }
/*  973 */     return result;
/*      */   }
/*      */ 
/*      */   public static User_City getById(List list, String id)
/*      */   {
/*  978 */     for (int i = 0; i < list.size(); i++) {
/*  979 */       User_City rdBean = (User_City)list.get(i);
/*  980 */       if (rdBean.getCityId().equals(id)) {
/*  981 */         return rdBean;
/*      */       }
/*      */     }
/*  984 */     return null;
/*      */   }
/*      */ 
/*      */   public static List<User_City> getDirectChildCityList(String cityId)
/*      */   {
/* 1007 */     List cityList = UserCityCache.getInstance().getCityListByFilter(new CacheFilter()
/*      */     {
/*      */       public boolean match(Object obj)
/*      */       {
/* 1000 */         if (obj == null) {
/* 1001 */           return false;
/*      */         }
/* 1003 */         return ((User_City)obj).getParentId().equals(ListService.this);
/*      */       }
/*      */     });
/* 1008 */     return cityList;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.ListService
 * JD-Core Version:    0.6.2
 */
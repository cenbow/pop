/*    */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.exception.DaoException;
/*    */ import com.asiainfo.biframe.exception.ServiceException;
/*    */ import com.asiainfo.biframe.privilege.model.ResourceOperationDefine;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceOperationDefineDao;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.service.IResourceOperationDefineService;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ResourceOperationDefineService
/*    */   implements IResourceOperationDefineService
/*    */ {
/* 25 */   private static Logger log = Logger.getLogger(ResourceOperationDefineService.class);
/*    */   private IResourceOperationDefineDao resourceOperationDefineDao;
/*    */ 
/*    */   public List<ResourceOperationDefine> getDefineListBy(int resourceType)
/*    */     throws ServiceException
/*    */   {
/*    */     try
/*    */     {
/* 34 */       log.debug("in getDefinListBy");
/* 35 */       return getResourceOperationDefineDao().getDefineListBy(resourceType);
/*    */     } catch (DaoException e) {
/* 37 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.findByResourceTypeFail") + "", e);
/* 38 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.findByResourceTypeFail") + "", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ResourceOperationDefine getOperationDefineBy(String operationType, int resourceType)
/*    */     throws ServiceException
/*    */   {
/* 46 */     log.debug("in getOperationDefineBy");
/* 47 */     return getResourceOperationDefineDao().getOperationDefineBy(operationType, resourceType);
/*    */   }
/*    */ 
/*    */   public String getOperNameBy(String operationType, int resourceType)
/*    */     throws ServiceException
/*    */   {
/* 54 */     ResourceOperationDefine def = getOperationDefineBy(operationType, resourceType);
/* 55 */     if (def == null) {
/* 56 */       return "";
/*    */     }
/* 58 */     return def.getOperationName();
/*    */   }
/*    */ 
/*    */   public IResourceOperationDefineDao getResourceOperationDefineDao() {
/* 62 */     return this.resourceOperationDefineDao;
/*    */   }
/*    */ 
/*    */   public void setResourceOperationDefineDao(IResourceOperationDefineDao resourceOperationDefineDao) {
/* 66 */     this.resourceOperationDefineDao = resourceOperationDefineDao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.ResourceOperationDefineService
 * JD-Core Version:    0.6.2
 */
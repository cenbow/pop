/*    */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.service.IResourceRightService;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ResourceRightServiceImpl
/*    */   implements IResourceRightService
/*    */ {
/*    */   private IResourceRightDAO resourceRightDao;
/*    */ 
/*    */   public ResourceRightServiceImpl()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ResourceRightServiceImpl(IResourceRightDAO dao)
/*    */   {
/* 25 */     this.resourceRightDao = dao;
/*    */   }
/*    */ 
/*    */   public void save(List<RoleRight> roleRightList) {
/* 29 */     getResourceRightDao().save(roleRightList);
/*    */   }
/*    */ 
/*    */   public void delete(List<RoleRight> roleRightList) {
/* 33 */     getResourceRightDao().delete(roleRightList);
/*    */   }
/*    */ 
/*    */   public void delete(List<String> roleIdList, List<Right> rightList, int resourceType) {
/* 37 */     getResourceRightDao().delete(roleIdList, rightList, resourceType);
/*    */   }
/*    */   public IResourceRightDAO getResourceRightDao() {
/* 40 */     return this.resourceRightDao;
/*    */   }
/*    */   public void setResourceRightDao(IResourceRightDAO resourceRightDao) {
/* 43 */     this.resourceRightDao = resourceRightDao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.ResourceRightServiceImpl
 * JD-Core Version:    0.6.2
 */
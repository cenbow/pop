/*      */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.exception.DaoException;
/*      */ import com.asiainfo.biframe.exception.ServiceException;
/*      */ import com.asiainfo.biframe.privilege.base.util.BeanUtils;
/*      */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserGroupDefineCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserRoleCache;
/*      */ import com.asiainfo.biframe.privilege.model.GroupRoleMap;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*      */ import com.asiainfo.biframe.privilege.model.UserRole;
/*      */ import com.asiainfo.biframe.privilege.model.UserRoleMap;
/*      */ import com.asiainfo.biframe.privilege.model.User_Group;
/*      */ import com.asiainfo.biframe.privilege.model.User_User;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IGroupRoleMapDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.ISysResourceTypeDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserOperationDefineDao;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleMapDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*      */ import com.asiainfo.biframe.utils.date.DateUtil;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import org.apache.commons.collections.CollectionUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.struts.util.LabelValueBean;
/*      */ 
/*      */ public class RoleAdminServiceImpl
/*      */   implements IRoleAdminService
/*      */ {
/*   74 */   private Log log = LogFactory.getLog(RoleAdminServiceImpl.class);
/*      */   private IUserRoleDAO userRoleDao;
/*      */   private IUserGroupDAO userGroupDao;
/*      */   private IGroupRoleMapDAO groupRoleMapDao;
/*      */   private IUserRoleMapDAO userRoleMapDao;
/*      */   private ISysResourceTypeDAO sysResourceTypeDao;
/*      */   private IUserOperationDefineDao userOperationDefineDao;
/*      */   private Map resourceRightDaoMap;
/*      */ 
/*      */   public String addRole(UserRole userRole)
/*      */   {
/*   94 */     this.log.info("addRole...... ");
/*      */     try {
/*   96 */       if (userRole == null) {
/*   97 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleEmpty") + "!");
/*      */       }
/*      */ 
/*  101 */       if (existRoleByName(userRole.getRoleName())) {
/*  102 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleAlreadyExist") + "!");
/*      */       }
/*      */ 
/*  106 */       if (userRole.getCreateTime() == null) {
/*  107 */         userRole.setCreateTime(new Date());
/*      */       }
/*  109 */       String roleId = this.userRoleDao.save(userRole);
/*      */ 
/*  111 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"), userRole.getRoleId(), userRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addRole") + "", null, userRole.toMap());
/*      */ 
/*  120 */       return roleId;
/*      */     } catch (Exception e) {
/*  122 */       this.log.error("addRole " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  125 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addRoleFail") + "" + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateRole(UserRole newRole)
/*      */   {
/*  140 */     this.log.info("updateRole...... ");
/*      */     try {
/*  142 */       if (newRole == null) {
/*  143 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleToModifyEmpty") + "!");
/*      */       }
/*      */ 
/*  147 */       UserRole realRole = getRoleById(newRole.getRoleId());
/*  148 */       if (realRole == null) {
/*  149 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleCannotModify") + "");
/*      */       }
/*      */ 
/*  153 */       if (!newRole.getRoleName().equals(realRole.getRoleName())) {
/*  154 */         UserRole role = findRoleByName(newRole.getRoleName());
/*  155 */         if (role != null) {
/*  156 */           throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleAlreadyExist") + "!");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  161 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"), realRole.getRoleId(), realRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyRole") + "", realRole.toMap(), newRole.toMap());
/*      */ 
/*  170 */       BeanUtils.copyProperties(realRole, newRole);
/*      */ 
/*  172 */       this.userRoleDao.update(realRole);
/*      */     } catch (Exception e) {
/*  174 */       this.log.error("updateRole " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  177 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateRoleError") + ":" + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String cloneRole(UserRole newRole, String srcRoleId)
/*      */   {
/*  190 */     this.log.info("in cloneRole...... ");
/*      */     try {
/*  192 */       String roleId = addRole(newRole);
/*      */ 
/*  194 */       IResourceRightDAO resourceRightDAO = getResourceRightDAO(newRole.getRoleType(), newRole.getResourceType());
/*      */ 
/*  196 */       List roleRightList = resourceRightDAO.getRoleRightListByRole(srcRoleId, newRole.getResourceType());
/*      */ 
/*  198 */       for (RoleRight roleRight : roleRightList) {
/*  199 */         roleRight.setRoleId(roleId);
/*      */       }
/*  201 */       resourceRightDAO.save(roleRightList);
/*      */ 
/*  203 */       this.log.info("end cloneRole...... ");
/*  204 */       return roleId;
/*      */     } catch (Exception e) {
/*  206 */       this.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyRole") + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  210 */       throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyRoleFail") + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String cloneRoleNew(UserRole newRole, String srcRoleId)
/*      */   {
/*  222 */     this.log.info("in cloneRole...... ");
/*      */     try {
/*  224 */       String roleId = addRole(newRole);
/*      */ 
/*  229 */       Collection srtList = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/*  231 */       for (SysResourceType srt : srtList) {
/*  232 */         IResourceRightDAO resourceRightDAO = getResourceRightDAO(srt.getRoleType(), srt.getResourceType());
/*      */ 
/*  234 */         if (null != resourceRightDAO) {
/*  235 */           List roleRightList = resourceRightDAO.getRoleRightListByRole(srcRoleId, srt.getResourceType());
/*      */ 
/*  238 */           for (RoleRight roleRight : roleRightList) {
/*  239 */             roleRight.setRoleId(roleId);
/*      */           }
/*  241 */           resourceRightDAO.save(roleRightList);
/*      */         }
/*      */       }
/*      */ 
/*  245 */       this.log.info("end cloneRole...... ");
/*  246 */       return roleId;
/*      */     } catch (Exception e) {
/*  248 */       this.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyRole") + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  252 */       throw new RuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyRoleFail") + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteRole(UserRole userRole)
/*      */   {
/*  267 */     this.log.info("deleteRole...... ");
/*      */     try
/*      */     {
/*  272 */       List rightList = getRightsByRoleId(userRole.getRoleId());
/*      */ 
/*  274 */       List subGroupList = getUserGroupAdminService().getSubGroup(userRole.getCreateGroup());
/*      */ 
/*  278 */       if ((subGroupList != null) && (rightList.size() > 0)) {
/*  279 */         for (User_Group ug : subGroupList) {
/*  280 */           if (isRoleInGroup(ug.getGroupid(), userRole.getRoleId()))
/*      */           {
/*  282 */             deleteResourceRightByForce(new ArrayList(), rightList, ug.getGroupid(), userRole);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  288 */       Collection srtList = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/*  290 */       for (SysResourceType srt : srtList) {
/*  291 */         IResourceRightDAO resourceRightDao = getResourceRightDAO(srt.getRoleType(), srt.getResourceType());
/*      */ 
/*  293 */         if (null != resourceRightDao)
/*      */         {
/*  295 */           resourceRightDao.delete(userRole.getRoleId(), srt.getResourceType());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  301 */       this.userRoleMapDao.deleteMapByRId(userRole.getRoleId());
/*      */ 
/*  304 */       this.groupRoleMapDao.deleteMapByRId(userRole.getRoleId());
/*      */ 
/*  307 */       UserRole realRole = this.userRoleDao.findById(userRole.getRoleId());
/*  308 */       realRole.setStatus(Integer.valueOf("2").intValue());
/*  309 */       realRole.setDeleteTime(DateUtil.date2String(new Date(), "yyyy-MM-dd HH:mm:ss"));
/*      */ 
/*  311 */       this.userRoleDao.update(realRole);
/*      */     } catch (Exception e) {
/*  313 */       this.log.error("deleteRole " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  316 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRoleError") + "");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveGroupRoleMap(String roleId, List<String> groupList)
/*      */   {
/*  326 */     this.log.info("saveGroupRoleMap...... ");
/*      */     try {
/*  328 */       if ((roleId == null) || (roleId.length() == 0)) {
/*  329 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.role") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.isEmpty") + "");
/*      */       }
/*      */ 
/*  336 */       UserRole userRole = this.userRoleDao.findById(roleId);
/*      */ 
/*  339 */       List groupIdList = getGroupIDsByRoleId(roleId);
/*  340 */       List subGroupList = getUserGroupAdminService().getSubGroup(userRole.getCreateGroup());
/*      */ 
/*  342 */       List subGroupIdList = UserGroup2IdList(subGroupList);
/*  343 */       groupIdList.retainAll(subGroupIdList);
/*      */ 
/*  346 */       List selectedList = new ArrayList();
/*  347 */       selectedList.addAll(groupIdList);
/*      */ 
/*  350 */       groupIdList.removeAll(groupList);
/*      */ 
/*  352 */       if (ifRoleUsedByGroups(roleId, groupIdList)) {
/*  353 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleCannotRemove") + "");
/*      */       }
/*      */ 
/*  357 */       if (!changeUserCityOfGroup(userRole, groupIdList)) {
/*  358 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleCannotRemove") + "");
/*      */       }
/*      */ 
/*  364 */       if (groupIdList.size() > 0)
/*      */       {
/*  366 */         List deleteList = new ArrayList();
/*  367 */         for (int i = 0; i < groupIdList.size(); i++)
/*      */         {
/*  369 */           GroupRoleMap groupRoleMap = new GroupRoleMap((String)groupIdList.get(i), roleId);
/*      */ 
/*  371 */           deleteList.add(this.groupRoleMapDao.findById(groupRoleMap));
/*      */         }
/*  373 */         this.groupRoleMapDao.deleteMapList(deleteList);
/*      */       }
/*      */ 
/*  377 */       groupList.removeAll(selectedList);
/*  378 */       if ((groupList == null) || (groupList.size() == 0)) {
/*  379 */         return;
/*      */       }
/*  381 */       for (int i = 0; i < groupList.size(); i++)
/*      */       {
/*  383 */         GroupRoleMap groupRoleMap = new GroupRoleMap((String)groupList.get(i), roleId);
/*      */ 
/*  385 */         this.groupRoleMapDao.save(groupRoleMap);
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  390 */       e.printStackTrace();
/*  391 */       this.log.error("saveGroupRoleMap " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  394 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public boolean changeUserCityOfGroup(UserRole userRole, List<String> groupIdList)
/*      */   {
/*  408 */     if (userRole.getRoleType() != 0)
/*  409 */       return false;
/*      */     List cityListOfRole;
/*      */     String newCityId;
/*  411 */     for (int i = 0; i < groupIdList.size(); i++) {
/*  412 */       String groupId = (String)groupIdList.get(i);
/*  413 */       List roleIdList = getUserGroupAdminService().getRoleIdListByGroupId(groupId, userRole.getRoleType(), userRole.getResourceType());
/*      */ 
/*  416 */       roleIdList.remove(userRole.getRoleId());
/*  417 */       if (roleIdList.size() < 1) {
/*  418 */         return false;
/*      */       }
/*      */ 
/*  421 */       List cityCurrList = getRightsByRoleIdList(roleIdList, userRole.getRoleType(), userRole.getResourceType(), false);
/*      */ 
/*  424 */       cityListOfRole = getRightsByRoleId(userRole.getRoleId(), userRole.getRoleType(), userRole.getResourceType());
/*      */ 
/*  428 */       cityListOfRole.removeAll(cityCurrList);
/*  429 */       if (cityListOfRole.size() < 1) {
/*  430 */         return true;
/*      */       }
/*  432 */       List userList = getUserGroupAdminService().getUsersByGroupId(groupId);
/*      */ 
/*  435 */       newCityId = ((Right)cityCurrList.get(0)).getResourceId();
/*  436 */       for (User_User uu : userList)
/*      */       {
/*  438 */         if (cityListOfRole.contains(uu.getCityid())) {
/*  439 */           uu.setCityid(newCityId);
/*  440 */           getUserAdminService().updateUser(uu);
/*      */         }
/*      */       }
/*      */     }
/*  444 */     return true;
/*      */   }
/*      */ 
/*      */   public void saveUserRoleMap(String roleId, List<String> userList)
/*      */   {
/*  452 */     this.log.info("saveUserRoleMap...... ");
/*      */     try
/*      */     {
/*  455 */       if ((roleId == null) || (roleId.length() == 0)) {
/*  456 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.role") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.isEmpty") + "");
/*      */       }
/*      */ 
/*  463 */       UserRole userRole = this.userRoleDao.findById(roleId);
/*      */ 
/*  465 */       List userRoleMaplist = this.userRoleMapDao.findAllByRId(roleId);
/*      */ 
/*  468 */       List directList = getUserGroupAdminService().getDirectSubUsersByGroupId(userRole.getCreateGroup());
/*      */ 
/*  471 */       List directUseridList = new ArrayList();
/*      */ 
/*  473 */       if (directList != null)
/*      */       {
/*  475 */         for (int i = 0; i < directList.size(); i++)
/*      */         {
/*  477 */           User_User user = (User_User)directList.get(i);
/*  478 */           directUseridList.add(user.getUserid());
/*      */         }
/*      */       }
/*      */ 
/*  482 */       List removeList = new ArrayList();
/*  483 */       for (int j = 0; j < userRoleMaplist.size(); j++)
/*      */       {
/*  485 */         UserRoleMap map = (UserRoleMap)userRoleMaplist.get(j);
/*  486 */         if (directUseridList.contains(map.getUserid())) {
/*  487 */           removeList.add(map);
/*      */         }
/*      */       }
/*  490 */       if (removeList.size() > 0) {
/*  491 */         this.userRoleMapDao.deleteMapList(removeList);
/*      */       }
/*  493 */       if ((userList == null) || (userList.size() == 0)) {
/*  494 */         return;
/*      */       }
/*  496 */       for (int i = 0; i < userList.size(); i++)
/*      */       {
/*  498 */         UserRoleMap userRoleMap = new UserRoleMap((String)userList.get(i), roleId);
/*      */ 
/*  501 */         this.userRoleMapDao.save(userRoleMap);
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  506 */       e.printStackTrace();
/*  507 */       this.log.error("saveUserRoleMap " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  510 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveUserRoleMapFail") + "");
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean hasRight(String roleId, String resourceId, String operationType)
/*      */   {
/*  521 */     this.log.info("hasRight...... ");
/*      */     try {
/*  523 */       UserRole userRole = this.userRoleDao.findById(roleId);
/*  524 */       int resourceType = userRole.getResourceType();
/*  525 */       int roleType = userRole.getRoleType();
/*  526 */       IResourceRightDAO resourceRightDao = getResourceRightDAO(roleType, resourceType);
/*      */ 
/*  530 */       String realOperType = operationType;
/*  531 */       if (StringUtils.isBlank(realOperType)) {
/*  532 */         if (isDistinguishOperation(roleType, resourceType))
/*  533 */           realOperType = "0";
/*      */         else {
/*  535 */           realOperType = "-1";
/*      */         }
/*      */       }
/*      */ 
/*  539 */       RoleRight roleRight = resourceRightDao.getRoleRight(roleId, resourceType, resourceId, realOperType);
/*      */ 
/*  542 */       return roleRight != null;
/*      */     } catch (Exception e) {
/*  544 */       this.log.error("hasRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  547 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.checkRoleAuthFail") + "");
/*      */   }
/*      */ 
/*      */   public boolean hasAnyRight(String roleId)
/*      */   {
/*  557 */     this.log.debug(" in hasAnyRight");
/*  558 */     List rightList = getRightsByRoleId(roleId);
/*  559 */     if ((rightList == null) || (rightList.isEmpty())) {
/*  560 */       return false;
/*      */     }
/*  562 */     return true;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void saveRoleRightByForce(Collection<RoleRight> addedRoleRightList, Collection<RoleRight> deletedRoleRightList, String roleId)
/*      */   {
/*  572 */     this.log.info(" in saveRoleRightByForce...... ");
/*      */     try {
/*  574 */       UserRole userRole = this.userRoleDao.findById(roleId);
/*      */ 
/*  583 */       IResourceRightDAO resourceRightDao = getResourceRightDAO(userRole.getRoleType(), userRole.getResourceType());
/*      */ 
/*  587 */       resourceRightDao.save(addedRoleRightList);
/*      */ 
/*  590 */       List addedRightList = new ArrayList();
/*  591 */       for (RoleRight roleRight : addedRoleRightList) {
/*  592 */         addedRightList.add(roleRight.getRight());
/*      */       }
/*      */ 
/*  595 */       List deletedRightList = new ArrayList();
/*  596 */       for (RoleRight roleRight : deletedRoleRightList) {
/*  597 */         deletedRightList.add(roleRight.getRight());
/*      */       }
/*      */ 
/*  601 */       List subGroupList = getUserGroupAdminService().getSubGroup(userRole.getCreateGroup());
/*      */ 
/*  603 */       if ((subGroupList != null) && (deletedRoleRightList.size() > 0))
/*      */       {
/*  605 */         for (int i = 0; i < subGroupList.size(); i++)
/*      */         {
/*  607 */           User_Group ug = (User_Group)subGroupList.get(i);
/*  608 */           if (isRoleInGroup(ug.getGroupid(), roleId)) {
/*  609 */             deleteResourceRightByForce(addedRightList, deletedRightList, ug.getGroupid(), userRole);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  616 */       resourceRightDao.delete(deletedRoleRightList);
/*      */ 
/*  618 */       this.log.info(" end saveRoleRightByForce...... ");
/*      */     }
/*      */     catch (Exception e) {
/*  621 */       this.log.error("saveRoleResourceRightByForce " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  624 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveRoleAuthFail") + "");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveRoleRightByForce(Collection<RoleRight> addedRoleRightList, Collection<RoleRight> deletedRoleRightList, String roleId, int resourceType)
/*      */   {
/*  640 */     this.log.info(" in saveRoleRightByForce...... ");
/*      */     try {
/*  642 */       UserRole userRole = this.userRoleDao.findById(roleId);
/*  643 */       IResourceRightDAO resourceRightDao = getResourceRightDAO(-1, resourceType);
/*      */ 
/*  646 */       if (resourceRightDao != null)
/*      */       {
/*  648 */         resourceRightDao.save(addedRoleRightList);
/*      */ 
/*  650 */         List addedRightList = new ArrayList();
/*  651 */         for (RoleRight roleRight : addedRoleRightList) {
/*  652 */           addedRightList.add(roleRight.getRight());
/*      */         }
/*      */ 
/*  655 */         List deletedRightList = new ArrayList();
/*  656 */         for (RoleRight roleRight : deletedRoleRightList) {
/*  657 */           deletedRightList.add(roleRight.getRight());
/*      */         }
/*      */ 
/*  661 */         List subGroupList = getUserGroupAdminService().getSubGroup(userRole.getCreateGroup());
/*      */ 
/*  663 */         if ((subGroupList != null) && (deletedRoleRightList.size() > 0))
/*      */         {
/*  665 */           for (int i = 0; i < subGroupList.size(); i++)
/*      */           {
/*  667 */             User_Group ug = (User_Group)subGroupList.get(i);
/*  668 */             if (isRoleInGroup(ug.getGroupid(), roleId)) {
/*  669 */               deleteResourceRightByForce(addedRightList, deletedRightList, ug.getGroupid(), userRole);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  676 */         resourceRightDao.delete(deletedRoleRightList);
/*      */       }
/*  678 */       this.log.info(" end saveRoleRightByForce...... ");
/*      */     }
/*      */     catch (Exception e) {
/*  681 */       this.log.error("saveRoleResourceRightByForce " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  684 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveRoleAuthFail") + "");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteResourceRightByForce(List<Right> newRightList, List<Right> rightList, String groupId, UserRole role)
/*      */   {
/*  695 */     this.log.debug(" in deleteResourceRightByForce");
/*  696 */     List rightDeleteList = new ArrayList();
/*  697 */     rightDeleteList.addAll(rightList);
/*      */ 
/*  700 */     List excludeRoleIdList = getUserGroupAdminService().getRoleIdListByGroupId(groupId);
/*      */ 
/*  702 */     excludeRoleIdList.remove(role.getRoleId());
/*      */ 
/*  705 */     Collection srtList = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/*  707 */     for (SysResourceType srt : srtList) {
/*  708 */       List excludeRight = getRightsByRoleIdList(excludeRoleIdList, srt.getRoleType(), srt.getResourceType(), false);
/*      */ 
/*  710 */       rightDeleteList.removeAll(excludeRight);
/*      */     }
/*      */ 
/*  713 */     if (rightDeleteList.size() == 0) {
/*  714 */       return;
/*      */     }
/*      */ 
/*  720 */     List allSubGroupIdList = UserGroup2IdList(getUserGroupAdminService().getAllSubGroup(groupId));
/*      */ 
/*  724 */     allSubGroupIdList.add(groupId);
/*      */ 
/*  727 */     List userRoleList = this.userRoleDao.findByCreateGroupList(allSubGroupIdList);
/*      */ 
/*  730 */     List userRoleIdList = UserRole2IdList(userRoleList);
/*      */ 
/*  732 */     for (SysResourceType srt : srtList) {
/*  733 */       IResourceRightDAO resourceRightDAO = getResourceRightDAO(srt.getRoleType(), srt.getResourceType());
/*      */ 
/*  735 */       if (null != resourceRightDAO) {
/*  736 */         resourceRightDAO.delete(userRoleIdList, rightDeleteList, srt.getResourceType());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  756 */     this.log.debug(" end deleteResourceRightByForce");
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void alterUserLoginCity(List<Right> newRightList, List<Right> deleteRightList, String userId, UserRole userRole)
/*      */   {
/*  771 */     User_Group ug = getUserAdminService().getGroupObject(userId);
/*      */ 
/*  773 */     User_User uu = getUserAdminService().getUser(userId);
/*      */ 
/*  776 */     if ((isRoleInGroup(ug.getGroupid(), userRole.getRoleId())) && (newRightList != null) && (newRightList.size() > 0))
/*      */     {
/*  779 */       uu.setCityid(((Right)newRightList.get(0)).getResourceId());
/*      */     }
/*      */     else
/*      */     {
/*  783 */       List groupRoleIdList = getUserGroupAdminService().getRoleIdListByGroupId(ug.getGroupid(), userRole.getRoleType(), userRole.getResourceType());
/*      */ 
/*  786 */       groupRoleIdList.remove(userRole.getRoleId());
/*      */ 
/*  788 */       if ((groupRoleIdList == null) || (groupRoleIdList.size() == 0)) {
/*  789 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifySubUserCityFail") + "");
/*      */       }
/*      */ 
/*  793 */       List cityList = getRightsByRoleIdList(groupRoleIdList, userRole.getRoleType(), userRole.getResourceType(), false);
/*      */ 
/*  796 */       cityList.removeAll(deleteRightList);
/*      */ 
/*  798 */       if ((cityList == null) || (cityList.size() == 0)) {
/*  799 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifySubUserCityFail") + "");
/*      */       }
/*      */ 
/*  803 */       uu.setCityid(((Right)cityList.get(0)).getResourceId());
/*      */     }
/*      */ 
/*  806 */     getUserAdminService().updateUser(uu);
/*      */   }
/*      */ 
/*      */   public boolean ifCanDeleteRole(String roleId)
/*      */   {
/*  816 */     return (ifCanModifyRoleResourceRight(new ArrayList(), roleId)) && (getUserIDsByRoleId(roleId).size() == 0);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public boolean ifCanDeleteRoleByForce(String roleId)
/*      */   {
/*  827 */     return ifCanModifyRoleResourceRightByForce(new ArrayList(), roleId);
/*      */   }
/*      */ 
/*      */   public boolean isCreatedRoleByGroup(String operatorUserId, String groupId, String roleId)
/*      */   {
/*  837 */     this.log.debug("in isCreatedRoleByGroup");
/*  838 */     if (getUserAdminService().isAdminUser(operatorUserId)) {
/*  839 */       return true;
/*      */     }
/*  841 */     if (hasSpecialRight(operatorUserId)) {
/*  842 */       return true;
/*      */     }
/*  844 */     List createdRoleList = getUserGroupAdminService().getAllRolesByCreateGroupId(groupId);
/*      */ 
/*  846 */     UserRole role = new UserRole();
/*  847 */     role.setRoleId(roleId);
/*  848 */     if (createdRoleList.contains(role)) {
/*  849 */       return true;
/*      */     }
/*  851 */     return false;
/*      */   }
/*      */ 
/*      */   protected boolean hasSpecialRight(String operatorUserId)
/*      */   {
/*  856 */     Right right = new Right();
/*  857 */     right.setRoleType(1);
/*  858 */     right.setResourceType(Integer.valueOf("1003").intValue());
/*      */ 
/*  860 */     right.setResourceId("1");
/*  861 */     right.setOperationType("-1");
/*  862 */     return getUserAdminService().haveRight(operatorUserId, right);
/*      */   }
/*      */ 
/*      */   public boolean ifCanModifyRoleResourceRight(List<Right> newRightList, String roleId)
/*      */   {
/*  871 */     this.log.info("ifCanModifyRoleResourceRight...... ");
/*      */     try
/*      */     {
/*  875 */       UserRole userRole = this.userRoleDao.findById(roleId);
/*      */ 
/*  879 */       List oldRightList = getRightsByRoleId(roleId);
/*  880 */       oldRightList.removeAll(newRightList);
/*  881 */       if (oldRightList.size() == 0) {
/*  882 */         return true;
/*      */       }
/*      */ 
/*  887 */       List subGroupList = getUserGroupAdminService().getSubGroup(userRole.getCreateGroup());
/*      */ 
/*  889 */       List subGroupidList = UserGroup2IdList(subGroupList);
/*      */ 
/*  891 */       if (ifResourceRightUsedByGroups(oldRightList, subGroupidList, roleId))
/*      */       {
/*  893 */         return false;
/*      */       }
/*      */     } catch (Exception e) { this.log.error("ifCanModifyRoleResourceRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  898 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.checkCanRemoveResource") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.errorAndContact") + "");
/*      */     }
/*      */ 
/*  906 */     return true;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public boolean ifCanModifyRoleResourceRightByForce(List<Right> newRightList, String roleId)
/*      */   {
/*  916 */     UserRole userRole = this.userRoleDao.findById(roleId);
/*      */ 
/*  919 */     if (userRole.getRoleType() != 0) {
/*  920 */       return true;
/*      */     }
/*  922 */     List roleDeletedList = getRightsByRoleId(roleId);
/*      */ 
/*  925 */     roleDeletedList.removeAll(newRightList);
/*      */ 
/*  928 */     List subGroupList = getUserGroupAdminService().getSubGroup(userRole.getCreateGroup());
/*      */ 
/*  930 */     if ((subGroupList != null) && (roleDeletedList.size() > 0)) {
/*  931 */       for (int i = 0; i < subGroupList.size(); i++) {
/*  932 */         User_Group ug = (User_Group)subGroupList.get(i);
/*      */ 
/*  934 */         if ((isRoleInGroup(ug.getGroupid(), roleId)) && (!checkGroupResourceRight(newRightList, roleDeletedList, ug.getGroupid(), userRole)))
/*      */         {
/*  937 */           return false;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  942 */     return true;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public boolean checkGroupResourceRight(List<Right> newRightList, List<Right> deleteRightList, String groupId, UserRole userRole)
/*      */   {
/*  958 */     List groupDeleteList = new ArrayList();
/*  959 */     groupDeleteList.addAll(deleteRightList);
/*      */ 
/*  963 */     List roleIdList = getUserGroupAdminService().getRoleIdListByGroupId(groupId, userRole.getRoleType(), userRole.getResourceType());
/*      */ 
/*  966 */     roleIdList.remove(userRole.getRoleId());
/*  967 */     List groupRight = getRightsByRoleIdList(roleIdList, userRole.getRoleType(), userRole.getResourceType(), false);
/*      */ 
/*  971 */     groupDeleteList.removeAll(groupRight);
/*      */ 
/*  973 */     if (groupDeleteList.size() == 0) {
/*  974 */       return true;
/*      */     }
/*      */ 
/*  977 */     List allUserList = getAllUsersOfGroup(groupId);
/*  978 */     for (int i = 0; i < allUserList.size(); i++) {
/*  979 */       User_User uu = (User_User)allUserList.get(i);
/*      */ 
/*  981 */       if ((groupDeleteList.contains(uu.getCityid())) && (!ifUserCanChangeLoginCity(newRightList, groupDeleteList, uu.getUserid(), userRole)))
/*      */       {
/*  984 */         return false;
/*      */       }
/*      */     }
/*      */ 
/*  988 */     return true;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public boolean ifUserCanChangeLoginCity(List<Right> newRightList, List<Right> deleteRightList, String userId, UserRole userRole)
/*      */   {
/* 1004 */     User_Group ug = getUserAdminService().getGroupObject(userId);
/*      */ 
/* 1007 */     if ((isRoleInGroup(ug.getGroupid(), userRole.getRoleId())) && (newRightList != null) && (newRightList.size() > 0))
/*      */     {
/* 1009 */       return true;
/*      */     }
/*      */ 
/* 1012 */     List roleIdList = getUserGroupAdminService().getRoleIdListByGroupId(ug.getGroupid(), userRole.getRoleType(), userRole.getResourceType());
/*      */ 
/* 1015 */     roleIdList.remove(userRole.getRoleId());
/*      */ 
/* 1017 */     if ((roleIdList == null) || (roleIdList.size() == 0)) {
/* 1018 */       return false;
/*      */     }
/* 1020 */     List cityList = getRightsByRoleIdList(roleIdList, userRole.getRoleType(), userRole.getResourceType(), false);
/*      */ 
/* 1023 */     cityList.removeAll(deleteRightList);
/*      */ 
/* 1025 */     if ((cityList == null) || (cityList.size() == 0)) {
/* 1026 */       return false;
/*      */     }
/* 1028 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean ifResourceRightUsedByGroups(List<Right> rightList, List<String> groupIdList, String roleId)
/*      */   {
/* 1040 */     this.log.info("ifResourceRightUsedByGroups...... ");
/*      */ 
/* 1042 */     if ((rightList == null) || (rightList.size() == 0)) {
/* 1043 */       return false;
/*      */     }
/* 1045 */     if ((groupIdList == null) || (groupIdList.size() == 0)) {
/* 1046 */       return false;
/*      */     }
/* 1048 */     for (int i = 0; i < groupIdList.size(); i++)
/* 1049 */       if (ifResourceRightUsedByGroup(rightList, (String)groupIdList.get(i), roleId))
/*      */       {
/* 1051 */         return true;
/*      */       }
/* 1053 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean ifResourceRightUsedByGroup(List<Right> rightList, String groupId, String roleId)
/*      */   {
/* 1062 */     this.log.info("ifResourceRightUsedByGroup...... ");
/*      */     try
/*      */     {
/* 1065 */       UserRole userRole = this.userRoleDao.findById(roleId);
/*      */ 
/* 1068 */       if (!isRoleInGroup(groupId, roleId)) {
/* 1069 */         return false;
/*      */       }
/*      */ 
/* 1072 */       if (ifResourceRightUsedByCreateRole(rightList, groupId, userRole))
/*      */       {
/* 1074 */         return true;
/*      */       }
/*      */ 
/* 1077 */       if (ifResourceRightUsedByGroupUser(rightList, groupId, userRole))
/*      */       {
/* 1079 */         return true;
/*      */       }
/*      */ 
/* 1082 */       if (ifResourceRightUsedBySubGroup(rightList, groupId, userRole))
/*      */       {
/* 1084 */         return true;
/*      */       }
/*      */     } catch (Exception e) {
/* 1087 */       this.log.error("ifResourceRightUsedByGroup " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 1090 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.checkResourceCanRemoveFail") + "");
/*      */     }
/*      */ 
/* 1096 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean ifResourceRightUsedByCreateRole(List<Right> rightList, String groupId, UserRole userRole)
/*      */   {
/* 1104 */     int roleType = -1;
/* 1105 */     int resourceType = -1;
/*      */ 
/* 1108 */     List createRoleList = this.userRoleDao.findByCreateGroup(groupId);
/*      */ 
/* 1115 */     List createRoleIdList = UserRole2IdList(createRoleList);
/* 1116 */     List rightOfCreateRole = new ArrayList();
/* 1117 */     Collection srtList = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/* 1119 */     for (SysResourceType srt : srtList) {
/* 1120 */       rightOfCreateRole.addAll(getRightsByRoleIdList(createRoleIdList, roleType, srt.getResourceType(), false));
/*      */     }
/*      */ 
/* 1125 */     List roleIdList = getUserGroupAdminService().getRoleIdListByGroupId(groupId);
/*      */ 
/* 1127 */     roleIdList.remove(userRole.getRoleId());
/* 1128 */     List rightOfGroup = new ArrayList();
/* 1129 */     for (SysResourceType srt : srtList) {
/* 1130 */       rightOfGroup.addAll(getRightsByRoleIdList(roleIdList, roleType, srt.getResourceType(), false));
/*      */     }
/*      */ 
/* 1135 */     rightOfCreateRole.removeAll(rightOfGroup);
/* 1136 */     rightOfCreateRole.retainAll(rightList);
/*      */ 
/* 1138 */     return rightOfCreateRole.size() > 0;
/*      */   }
/*      */ 
/*      */   public boolean ifResourceRightUsedByGroupUser(List<Right> rightList, String groupId, UserRole userRole)
/*      */   {
/* 1152 */     List userList = getUserGroupAdminService().getUsersByGroupId(groupId);
/*      */ 
/* 1154 */     if ((userList == null) || (userList.size() == 0))
/* 1155 */       return false;
/* 1156 */     List cityList = new ArrayList();
/* 1157 */     for (int i = 0; i < userList.size(); i++) {
/* 1158 */       User_User uu = (User_User)userList.get(i);
/* 1159 */       cityList.add(uu.getCityid());
/*      */     }
/*      */ 
/* 1163 */     List roleIdList = getUserGroupAdminService().getRoleIdListByGroupId(groupId);
/*      */ 
/* 1165 */     roleIdList.remove(userRole.getRoleId());
/* 1166 */     Collection srtList = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/* 1169 */     List rightListOfGroup = new ArrayList();
/* 1170 */     for (SysResourceType srt : srtList) {
/* 1171 */       rightListOfGroup.addAll(getRightsByRoleIdList(roleIdList, srt.getRoleType(), srt.getResourceType(), false));
/*      */     }
/*      */ 
/* 1176 */     cityList.removeAll(rightListOfGroup);
/* 1177 */     cityList.retainAll(rightList);
/*      */ 
/* 1179 */     return cityList.size() > 0;
/*      */   }
/*      */ 
/*      */   public boolean ifResourceRightUsedBySubGroup(List<Right> rightList, String groupId, UserRole userRole)
/*      */   {
/* 1188 */     List subGroupList = getUserGroupAdminService().getSubGroup(groupId);
/*      */ 
/* 1190 */     if ((subGroupList == null) || (subGroupList.size() == 0)) {
/* 1191 */       return false;
/*      */     }
/* 1193 */     List subGroupidList = UserGroup2IdList(subGroupList);
/*      */ 
/* 1196 */     return ifResourceRightUsedByGroups(rightList, subGroupidList, userRole.getRoleId());
/*      */   }
/*      */ 
/*      */   public boolean ifRoleUsedByGroups(String roleId, List<String> groupidList)
/*      */   {
/* 1207 */     if ((groupidList == null) || (groupidList.size() == 0)) {
/* 1208 */       return false;
/*      */     }
/* 1210 */     for (int i = 0; i < groupidList.size(); i++) {
/* 1211 */       String groupId = (String)groupidList.get(i);
/* 1212 */       if (ifRoleUsedByGroup(roleId, groupId))
/* 1213 */         return true;
/*      */     }
/* 1215 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean ifRoleUsedByGroup(String roleId, String groupId)
/*      */   {
/*      */     try
/*      */     {
/* 1223 */       return ifRoleUsedByGroup(this.userRoleDao.findById(roleId), groupId);
/*      */     } catch (Exception e) {
/* 1225 */       this.log.error("ifRoleCanMoveOutFromGroup " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1228 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.checkRoleCanRemoveFail") + "");
/*      */   }
/*      */ 
/*      */   public boolean ifRoleUsedByGroup(UserRole userRole, String groupId)
/*      */   {
/* 1244 */     if (!isRoleInGroup(groupId, userRole.getRoleId())) {
/* 1245 */       return false;
/*      */     }
/*      */ 
/* 1248 */     if (ifRoleUsedByCreateRole(userRole, groupId)) {
/* 1249 */       return true;
/*      */     }
/*      */ 
/* 1258 */     if (ifRoleUsedBySubGroup(userRole, groupId)) {
/* 1259 */       return true;
/*      */     }
/* 1261 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean ifRoleUsedByCreateRole(UserRole userRole, String groupId)
/*      */   {
/* 1273 */     List createRoleList = this.userRoleDao.findByCreateGroup(groupId);
/* 1274 */     if (CollectionUtils.isEmpty(createRoleList)) {
/* 1275 */       return false;
/*      */     }
/* 1277 */     List createRoleIdList = UserRole2IdList(createRoleList);
/*      */ 
/* 1280 */     List userRoleList = getUserGroupAdminService().getRoleListByGroupId(groupId);
/*      */ 
/* 1282 */     List roleIdList = UserRole2IdList(userRoleList);
/* 1283 */     roleIdList.remove(userRole.getRoleId());
/*      */ 
/* 1285 */     return ifRoleRightUsedByCreateRole(userRole.getRoleId(), createRoleIdList, roleIdList);
/*      */   }
/*      */ 
/*      */   public boolean ifRoleUsedByGroupUser(UserRole userRole, String groupId)
/*      */   {
/* 1297 */     List rightList = getRightsByRoleId(userRole.getRoleId(), userRole.getRoleType(), userRole.getResourceType());
/*      */ 
/* 1299 */     return ifResourceRightUsedByGroupUser(rightList, groupId, userRole);
/*      */   }
/*      */ 
/*      */   public boolean ifRoleUsedBySubGroup(UserRole userRole, String groupId)
/*      */   {
/* 1311 */     List subGroupList = getUserGroupAdminService().getSubGroup(groupId);
/*      */ 
/* 1313 */     if ((subGroupList == null) || (subGroupList.size() == 0)) {
/* 1314 */       return false;
/*      */     }
/* 1316 */     for (int i = 0; i < subGroupList.size(); i++) {
/* 1317 */       User_Group ug = (User_Group)subGroupList.get(i);
/*      */ 
/* 1320 */       if (isRoleInGroup(ug.getGroupid(), userRole.getRoleId())) {
/* 1321 */         return true;
/*      */       }
/*      */     }
/* 1324 */     return false;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public boolean isRoleTheOnlyCityRole(UserRole userRole, String groupId)
/*      */   {
/* 1336 */     if (userRole.getRoleType() != 0) {
/* 1337 */       return false;
/*      */     }
/*      */ 
/* 1340 */     List roleIdList = getUserGroupAdminService().getRoleIdListByGroupId(groupId, userRole.getRoleType(), userRole.getResourceType());
/*      */ 
/* 1344 */     if ((null != roleIdList) && (roleIdList.size() == 1)) {
/* 1345 */       return true;
/*      */     }
/* 1347 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isRoleInGroup(String groupId, String roleId)
/*      */   {
/* 1354 */     List groupRoleMapList = this.groupRoleMapDao.findGroupRoleMapByGroupId(groupId);
/*      */ 
/* 1356 */     if ((groupRoleMapList == null) || (!groupRoleMapList.contains(new GroupRoleMap(groupId, roleId))))
/*      */     {
/* 1359 */       return false;
/*      */     }
/* 1361 */     return true;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public List<UserRole> filterRoleByType(List<UserRole> roleList, int roleType, int resourceType)
/*      */   {
/* 1371 */     List result = new ArrayList();
/*      */ 
/* 1373 */     if ((roleList == null) || (roleList.size() == 0)) {
/* 1374 */       return result;
/*      */     }
/* 1376 */     for (int i = 0; i < roleList.size(); i++) {
/* 1377 */       UserRole userRole = (UserRole)roleList.get(i);
/* 1378 */       if (userRole.getResourceType() == resourceType)
/* 1379 */         result.add(userRole);
/*      */     }
/* 1381 */     return result;
/*      */   }
/*      */ 
/*      */   public UserRole getRoleById(String roleId)
/*      */   {
/* 1393 */     this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + "getRoleById" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.method") + "roleId=" + roleId);
/*      */     try
/*      */     {
/* 1400 */       return this.userRoleDao.findById(roleId);
/*      */     } catch (Exception e) {
/* 1402 */       this.log.error("findRole " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1405 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRoleFail") + "");
/*      */   }
/*      */ 
/*      */   protected boolean existRoleByName(String roleName)
/*      */   {
/* 1416 */     this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + " existRoleByName " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.method") + "roleName=" + roleName);
/*      */     try
/*      */     {
/* 1424 */       List roleList = this.userRoleDao.getRoleListByName(roleName);
/*      */ 
/* 1426 */       if ((roleList != null) && (roleList.size() > 0)) {
/* 1427 */         return true;
/*      */       }
/*      */ 
/* 1430 */       return false;
/*      */     } catch (Exception e) {
/* 1432 */       this.log.error("existRoleByName " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1435 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRoleNameFail") + "");
/*      */   }
/*      */ 
/*      */   public UserRole findRoleByName(String roleName)
/*      */   {
/* 1443 */     this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + " findRoleByName " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.method") + "roleName=" + roleName);
/*      */     try
/*      */     {
/* 1452 */       List allRole = findAll();
/*      */ 
/* 1454 */       if ((allRole == null) || (allRole.size() == 0)) {
/* 1455 */         return null;
/*      */       }
/* 1457 */       for (int i = 0; i < allRole.size(); i++)
/*      */       {
/* 1459 */         UserRole role = (UserRole)allRole.get(i);
/*      */ 
/* 1461 */         if (role.getRoleName().equals(roleName))
/*      */         {
/* 1463 */           return role;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1468 */       return null;
/*      */     } catch (Exception e) {
/* 1470 */       this.log.error("findRoleByName " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1473 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRoleByNameFail") + "");
/*      */   }
/*      */ 
/*      */   public boolean isExistRole(String roleId)
/*      */   {
/* 1484 */     this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + "isExistRole" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.method") + "roleId=" + roleId);
/*      */     try
/*      */     {
/* 1493 */       if ((roleId == null) || (roleId.length() == 0)) {
/* 1494 */         return false;
/*      */       }
/* 1496 */       UserRole role = getRoleById(roleId);
/*      */ 
/* 1498 */       if (role == null) {
/* 1499 */         return false;
/*      */       }
/* 1501 */       return true;
/*      */     } catch (Exception e) {
/* 1503 */       this.log.error("isExistRole " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1506 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.judgeRoleExistFail") + "");
/*      */   }
/*      */ 
/*      */   public String getRoleName(String roleId)
/*      */   {
/* 1516 */     this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + "getRoleName" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.method") + "roleId=" + roleId);
/*      */     try
/*      */     {
/* 1524 */       UserRole role = getRoleById(roleId);
/*      */ 
/* 1526 */       if (role == null) {
/* 1527 */         return null;
/*      */       }
/* 1529 */       return role.getRoleName();
/*      */     } catch (Exception e) {
/* 1531 */       this.log.error("getRoleName " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1534 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleNameFail") + "");
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public String getRoleType(String roleId)
/*      */   {
/* 1548 */     this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + " getRoleType " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.method") + "roleId=" + roleId);
/*      */     try
/*      */     {
/* 1555 */       UserRole role = getRoleById(roleId);
/*      */ 
/* 1557 */       if (role == null) {
/* 1558 */         return "";
/*      */       }
/* 1560 */       return String.valueOf(role.getRoleType());
/*      */     } catch (Exception e) {
/* 1562 */       this.log.error("getRoleType " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1565 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRoleTypeFail") + "");
/*      */   }
/*      */ 
/*      */   public List<String> getGroupIDsByRoleId(String roleId)
/*      */   {
/* 1576 */     List result = new ArrayList();
/*      */     try
/*      */     {
/* 1580 */       if ((roleId == null) || (roleId.length() == 0)) {
/* 1581 */         return result;
/*      */       }
/* 1583 */       if (!isExistRole(roleId)) {
/* 1584 */         return result;
/*      */       }
/* 1586 */       List list = this.groupRoleMapDao.findAllbyRId(roleId);
/* 1587 */       if ((list == null) || (list.size() == 0)) {
/* 1588 */         return result;
/*      */       }
/* 1590 */       for (int i = 0; i < list.size(); i++)
/*      */       {
/* 1592 */         GroupRoleMap groupRole = (GroupRoleMap)list.get(i);
/* 1593 */         result.add(groupRole.getGroupId());
/*      */       }
/*      */ 
/* 1596 */       return result;
/*      */     } catch (Exception e) {
/* 1598 */       this.log.error("getGroupIDsByRoleId " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1601 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRoleGroupFail") + "");
/*      */   }
/*      */ 
/*      */   public List<User_Group> getGroupsByRoleId(String roleId)
/*      */   {
/* 1608 */     return this.groupRoleMapDao.findGroupsByRoleId(roleId);
/*      */   }
/*      */ 
/*      */   public String getCreatedGroupId(String roleId)
/*      */   {
/* 1615 */     UserRole userRole = getRoleById(roleId);
/* 1616 */     if (userRole == null) {
/* 1617 */       return "";
/*      */     }
/* 1619 */     return userRole.getCreateGroup();
/*      */   }
/*      */ 
/*      */   public String getAllCreatedGroupId(String roleId)
/*      */   {
/* 1626 */     this.log.error(" in getAllCreatedGroupId,roleId:" + roleId);
/* 1627 */     UserRole userRole = getRoleById(roleId);
/* 1628 */     if (userRole == null) {
/* 1629 */       this.log.error("getAllCreatedGroupId:" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRoleIsEmpty") + "");
/*      */ 
/* 1632 */       return "";
/*      */     }
/* 1634 */     String createGroupId = userRole.getCreateGroup();
/* 1635 */     StringBuffer allCreatedGroupId = new StringBuffer(64);
/* 1636 */     addParentGroup(createGroupId, allCreatedGroupId);
/* 1637 */     this.log.error("--allCreatedGroupId:" + allCreatedGroupId);
/* 1638 */     this.log.error("end getAllCreatedGroupId");
/* 1639 */     return allCreatedGroupId.toString();
/*      */   }
/*      */ 
/*      */   private void addParentGroup(String parentGroupId, StringBuffer allParentGroupId)
/*      */   {
/* 1644 */     allParentGroupId.append(parentGroupId).append(",");
/* 1645 */     User_Group parentGroup = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(parentGroupId);
/*      */ 
/* 1648 */     if (!parentGroup.getParentid().equals("0"))
/* 1649 */       addParentGroup(parentGroup.getParentid(), allParentGroupId);
/*      */   }
/*      */ 
/*      */   public List<User_User> getUsersByRoleId(String roleId)
/*      */   {
/* 1654 */     return this.userRoleMapDao.getUsersByRoleId(roleId);
/*      */   }
/*      */ 
/*      */   public List<String> getUserIDsByRoleId(String roleId)
/*      */   {
/* 1662 */     List result = new ArrayList();
/*      */     try
/*      */     {
/* 1666 */       if ((roleId == null) || (roleId.length() == 0)) {
/* 1667 */         return result;
/*      */       }
/* 1669 */       if (!isExistRole(roleId)) {
/* 1670 */         return result;
/*      */       }
/* 1672 */       List list = this.userRoleMapDao.findAllByRId(roleId);
/* 1673 */       if ((list == null) || (list.size() == 0)) {
/* 1674 */         return result;
/*      */       }
/* 1676 */       for (int i = 0; i < list.size(); i++)
/*      */       {
/* 1678 */         UserRoleMap userRole = (UserRoleMap)list.get(i);
/* 1679 */         result.add(userRole.getUserid());
/*      */       }
/*      */ 
/* 1682 */       return result;
/*      */     } catch (Exception e) {
/* 1684 */       this.log.error("getUserIDsByRoleId " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1687 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRoleUserFail") + "");
/*      */   }
/*      */ 
/*      */   private List<String> UserRole2IdList(List<UserRole> roleList)
/*      */   {
/* 1729 */     List result = new ArrayList();
/*      */ 
/* 1731 */     if ((roleList == null) || (roleList.size() == 0)) {
/* 1732 */       return result;
/*      */     }
/* 1734 */     for (int i = 0; i < roleList.size(); i++)
/*      */     {
/* 1736 */       UserRole userRole = (UserRole)roleList.get(i);
/* 1737 */       result.add(userRole.getRoleId());
/*      */     }
/* 1739 */     return result;
/*      */   }
/*      */ 
/*      */   private List<String> UserGroup2IdList(List objList)
/*      */   {
/* 1750 */     List result = new ArrayList();
/*      */ 
/* 1752 */     if ((objList == null) || (objList.size() == 0)) {
/* 1753 */       return result;
/*      */     }
/* 1755 */     for (int i = 0; i < objList.size(); i++)
/*      */     {
/* 1757 */       User_Group tmp = (User_Group)objList.get(i);
/* 1758 */       result.add(tmp.getGroupid());
/*      */     }
/* 1760 */     return result;
/*      */   }
/*      */ 
/*      */   private IUserAdminService getUserAdminService() {
/*      */     try {
/* 1765 */       return (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/*      */     }
/*      */     catch (Exception e) {
/* 1768 */       this.log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*      */ 
/* 1770 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List getAllUsersOfGroup(String groupId)
/*      */   {
/* 1783 */     List result = new ArrayList();
/*      */ 
/* 1786 */     result.addAll(getUserGroupAdminService().getAllSubUsersByGroupId(groupId));
/*      */ 
/* 1789 */     result.addAll(getUserGroupAdminService().getUsersByGroupId(groupId));
/*      */ 
/* 1791 */     return result;
/*      */   }
/*      */ 
/*      */   public List<UserRole> findAll()
/*      */   {
/* 1798 */     this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + "findAll");
/*      */     try
/*      */     {
/* 1802 */       return this.userRoleDao.findAllRoles();
/*      */     } catch (Exception e) {
/* 1804 */       this.log.error("findAll " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1807 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllRoleFail") + "");
/*      */   }
/*      */ 
/*      */   public Map getPagedRoleList(UserRole userRole, Integer currpage, Integer pagesize)
/*      */   {
/* 1822 */     this.log.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invoke") + "getPagedRoleList,currpage=" + currpage + ",pagesize=" + pagesize);
/*      */     try
/*      */     {
/* 1829 */       Map map = new HashMap();
/* 1830 */       map = this.userRoleDao.getPagedRoleList(userRole, currpage.intValue(), pagesize.intValue());
/*      */ 
/* 1833 */       Iterator iter = ((List)map.get("result")).iterator();
/* 1834 */       List list = new ArrayList();
/* 1835 */       while (iter.hasNext()) {
/* 1836 */         UserRole newRole = (UserRole)iter.next();
/*      */ 
/* 1838 */         String createGroupName = UserGroupDefineCache.getInstance().getNameByKey(newRole.getCreateGroup());
/*      */ 
/* 1840 */         if (StringUtils.isBlank(createGroupName)) {
/* 1841 */           createGroupName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */         }
/*      */ 
/* 1845 */         newRole.setCreateGroupName(createGroupName);
/* 1846 */         list.add(newRole);
/*      */       }
/* 1848 */       map.remove("result");
/* 1849 */       map.put("result", list);
/* 1850 */       return map;
/*      */     } catch (Exception e) {
/* 1852 */       this.log.error("getPagedRoleList " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1855 */     throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRoleListFail") + "");
/*      */   }
/*      */ 
/*      */   public List<UserRole> getUserRoleList(UserRole aUserRole)
/*      */   {
/* 1865 */     return this.userRoleDao.getUserRoleList(aUserRole);
/*      */   }
/*      */ 
/*      */   public List<String> getParentIds(List<Right> rightList, String topId, String resourceId)
/*      */   {
/* 1871 */     List result = new ArrayList();
/* 1872 */     Right rdBean = getById(rightList, resourceId);
/* 1873 */     while (rdBean != null) {
/* 1874 */       if ((rdBean.getParentId() == null ? "" : rdBean.getParentId()).equals(topId)) {
/*      */         break;
/*      */       }
/* 1877 */       result.add(rdBean.getParentId());
/* 1878 */       rdBean = getById(rightList, rdBean.getParentId());
/*      */     }
/* 1880 */     return result;
/*      */   }
/*      */ 
/*      */   private Right getById(List<Right> rightList, String resourceId)
/*      */   {
/* 1885 */     for (int i = 0; i < rightList.size(); i++) {
/* 1886 */       Right rdBean = (Right)rightList.get(i);
/* 1887 */       if (rdBean.getResourceId().equals(resourceId)) {
/* 1888 */         return rdBean;
/*      */       }
/*      */     }
/* 1891 */     return null;
/*      */   }
/*      */ 
/*      */   public void setUserGroupDao(IUserGroupDAO userGroupDao) {
/* 1895 */     this.userGroupDao = userGroupDao;
/*      */   }
/*      */ 
/*      */   public void setGroupRoleMapDao(IGroupRoleMapDAO groupRoleMapDao) {
/* 1899 */     this.groupRoleMapDao = groupRoleMapDao;
/*      */   }
/*      */ 
/*      */   public void setUserRoleDao(IUserRoleDAO userRoleDao) {
/* 1903 */     this.userRoleDao = userRoleDao;
/*      */   }
/*      */ 
/*      */   public void setUserRoleMapDao(IUserRoleMapDAO userRoleMapDao) {
/* 1907 */     this.userRoleMapDao = userRoleMapDao;
/*      */   }
/*      */ 
/*      */   public void setSysResourceTypeDao(ISysResourceTypeDAO sysResourceTypeDao) {
/* 1911 */     this.sysResourceTypeDao = sysResourceTypeDao;
/*      */   }
/*      */ 
/*      */   public Map getResourceRightDaoMap() {
/* 1915 */     return this.resourceRightDaoMap;
/*      */   }
/*      */ 
/*      */   public void setResourceRightDaoMap(Map resourceRightDaoMap) {
/* 1919 */     this.resourceRightDaoMap = resourceRightDaoMap;
/*      */   }
/*      */ 
/*      */   private IUserGroupAdminService getUserGroupAdminService() {
/*      */     try {
/* 1924 */       return (IUserGroupAdminService)SystemServiceLocator.getInstance().getService("right_userGroupAdminService");
/*      */     }
/*      */     catch (Exception e) {
/* 1927 */       this.log.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*      */ 
/* 1929 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public IResourceRightDAO getResourceRightDAO(int roleType, int resourceType)
/*      */   {
/* 1936 */     SysResourceType type = SysResourceTypeCache.getInstance().getSysResourceType(resourceType);
/*      */ 
/* 1938 */     String resourceKey = type == null ? "" : type.getResourceKey();
/* 1939 */     int dsType = type == null ? 0 : type.getDsType();
/* 1940 */     IResourceRightDAO resourceRightDao = null;
/* 1941 */     if (this.resourceRightDaoMap.containsKey(resourceKey)) {
/* 1942 */       resourceRightDao = (IResourceRightDAO)this.resourceRightDaoMap.get(resourceKey);
/*      */ 
/* 1945 */       if (dsType != 0) {
/*      */         try {
/* 1947 */           resourceRightDao.initDaoParameter(resourceType);
/*      */         } catch (Exception e) {
/* 1949 */           resourceRightDao = null;
/* 1950 */           this.log.error("init SysResourceType param error" + e.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1955 */     return resourceRightDao;
/*      */   }
/*      */ 
/*      */   public List<String> Right2IdList(List<Right> objList)
/*      */   {
/* 1960 */     List result = new ArrayList();
/*      */ 
/* 1962 */     if ((objList == null) || (objList.size() == 0)) {
/* 1963 */       return result;
/*      */     }
/* 1965 */     for (int i = 0; i < objList.size(); i++)
/*      */     {
/* 1967 */       Right tmp = (Right)objList.get(i);
/* 1968 */       result.add(tmp.getResourceId());
/*      */     }
/* 1970 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean containResource(List<Right> rightList, String resourceId) {
/* 1974 */     List resourceIdList = Right2IdList(rightList);
/* 1975 */     return resourceIdList.contains(resourceId);
/*      */   }
/*      */ 
/*      */   public List<Right> getRightsByRoleId(String roleId)
/*      */   {
/* 1980 */     UserRole role = getRoleById(roleId);
/* 1981 */     if (role == null) {
/* 1982 */       return null;
/*      */     }
/* 1984 */     Collection srtList = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/* 1986 */     List result = new ArrayList();
/* 1987 */     for (SysResourceType srt : srtList) {
/* 1988 */       List rightList = getRightsByRoleId(roleId, srt.getRoleType(), srt.getResourceType());
/*      */ 
/* 1990 */       result.addAll(rightList);
/*      */     }
/* 1992 */     return result;
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightsByRoleId(String roleId)
/*      */   {
/* 1997 */     UserRole role = getRoleById(roleId);
/* 1998 */     if (role == null) {
/* 1999 */       return new ArrayList();
/*      */     }
/* 2001 */     List roleRight = new ArrayList();
/* 2002 */     Collection srtList = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/* 2004 */     for (SysResourceType srt : srtList) {
/* 2005 */       IResourceRightDAO resRightDao = getResourceRightDAO(-1, srt.getResourceType());
/* 2006 */       if (resRightDao != null) {
/* 2007 */         roleRight.addAll(resRightDao.getRoleRightListByRole(roleId, srt.getResourceType()));
/*      */       }
/*      */     }
/* 2010 */     return roleRight;
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightsByRoleId(String roleId, int resourceType)
/*      */   {
/* 2015 */     List rightList = new ArrayList();
/* 2016 */     if (StringUtils.isEmpty(roleId)) {
/* 2017 */       return rightList;
/*      */     }
/* 2019 */     SysResourceType type = SysResourceTypeCache.getInstance().getSysResourceType(resourceType);
/*      */ 
/* 2022 */     if (type == null) {
/* 2023 */       return rightList;
/*      */     }
/* 2025 */     IResourceRightDAO resourceDao = getResourceRightDAO(type.getRoleType(), type.getResourceType());
/*      */ 
/* 2028 */     if (resourceDao != null) {
/* 2029 */       rightList = resourceDao.getRoleRightListByRole(roleId, type.getResourceType());
/*      */     }
/*      */ 
/* 2032 */     return rightList;
/*      */   }
/*      */ 
/*      */   public List<Right> getRightsByRoleId(String roleId, int roleType, int resourceType)
/*      */   {
/*      */     try
/*      */     {
/* 2039 */       List roleIdList = new ArrayList();
/* 2040 */       roleIdList.add(roleId);
/* 2041 */       return getRightsByRoleIdList(roleIdList, roleType, resourceType, false);
/*      */     }
/*      */     catch (Exception e) {
/* 2044 */       this.log.error("getRightsByRoleId " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 2047 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail"));
/*      */   }
/*      */ 
/*      */   public List<Right> getRightsByRoleIdList(List<String> roleIdList, int roleType, int resourceType, boolean isDistinctControlType)
/*      */   {
/*      */     try
/*      */     {
/* 2057 */       if (((roleIdList == null) || (roleIdList.isEmpty())) && (resourceType != Integer.parseInt("50")))
/*      */       {
/* 2060 */         return new ArrayList();
/*      */       }
/* 2062 */       IResourceRightDAO resourceRightDAO = getResourceRightDAO(roleType, resourceType);
/*      */ 
/* 2064 */       if (null == resourceRightDAO) {
/* 2065 */         return new ArrayList();
/*      */       }
/* 2067 */       return resourceRightDAO.getRightList(roleIdList, resourceType, isDistinctControlType);
/*      */     }
/*      */     catch (Exception e) {
/* 2070 */       this.log.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 2073 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail"));
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRights(int roleType, int resourceType)
/*      */   {
/*      */     try
/*      */     {
/* 2082 */       IResourceRightDAO resourceRightDAO = getResourceRightDAO(roleType, resourceType);
/*      */ 
/* 2084 */       if (resourceRightDAO == null) {
/* 2085 */         return new ArrayList();
/*      */       }
/* 2087 */       return resourceRightDAO.getAllRightList(roleType, resourceType);
/*      */     } catch (Exception e) {
/* 2089 */       this.log.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 2092 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<RoleRight> getRoleRightListByRight(Right right)
/*      */   {
/* 2101 */     return getResourceRightDAO(right.getRoleType(), right.getResourceType()).getRoleRightListByRight(right);
/*      */   }
/*      */ 
/*      */   public List<UserRole> getRoleListByRoleIds(List<String> roleIdList)
/*      */   {
/* 2107 */     return this.userRoleDao.findByIdList(roleIdList);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public List<String> getCityRoleIdList(List<String> roleidList)
/*      */   {
/* 2118 */     List cityRoleIdList = new ArrayList();
/* 2119 */     for (int i = 0; i < roleidList.size(); i++) {
/* 2120 */       UserRole role = this.userRoleDao.findById((String)roleidList.get(i));
/* 2121 */       if (role.getRoleType() == 0) {
/* 2122 */         cityRoleIdList.add(role.getRoleId());
/*      */       }
/*      */     }
/* 2125 */     return cityRoleIdList;
/*      */   }
/*      */ 
/*      */   public boolean isDistinguishOperation(int roleType, int resourceType)
/*      */   {
/* 2133 */     SysResourceType resType = SysResourceTypeCache.getInstance().getSysResourceType(resourceType);
/*      */ 
/* 2135 */     return resType.getIsDistinguishOperation();
/*      */   }
/*      */ 
/*      */   public IUserOperationDefineDao getUserOperationDefineDao() {
/* 2139 */     return this.userOperationDefineDao;
/*      */   }
/*      */ 
/*      */   public void setUserOperationDefineDao(IUserOperationDefineDao userOperationDefineDao)
/*      */   {
/* 2144 */     this.userOperationDefineDao = userOperationDefineDao;
/*      */   }
/*      */ 
/*      */   public void doAssignRolesToRight(Right right, List<RoleRight> addedRoleRightList, List<RoleRight> deletedRoleRightList)
/*      */   {
/* 2156 */     this.log.debug("in  doAssignRolesToRight...");
/*      */ 
/* 2159 */     IResourceRightDAO resouceDao = getResourceRightDAO(right.getRoleType(), right.getResourceType());
/*      */ 
/* 2162 */     resouceDao.delete(deletedRoleRightList);
/* 2163 */     if (CollectionUtils.isNotEmpty(deletedRoleRightList)) {
/* 2164 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_UPLOAD_OPER_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGERESOURCE"), right.getResourceId(), right.getResourceName(), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrDeleteRole"), null, null);
/*      */     }
/*      */ 
/* 2176 */     resouceDao.save(addedRoleRightList);
/* 2177 */     if (CollectionUtils.isNotEmpty(addedRoleRightList)) {
/* 2178 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGERESOURCE"), right.getResourceId(), right.getResourceName(), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrAddRole"), null, null);
/*      */     }
/*      */ 
/* 2188 */     this.log.debug("end  doAssignRolesToRight...");
/*      */   }
/*      */ 
/*      */   public void doAssignRolesToRight(Right right, List<RoleRight> addedRoleRightList, List<RoleRight> deletedRoleRightList, List<RoleRight> updatedOperTypeList)
/*      */   {
/* 2197 */     this.log.debug("in  doAssignRolesToRight...");
/*      */ 
/* 2200 */     getResourceRightDAO(right.getRoleType(), right.getResourceType()).save(addedRoleRightList);
/*      */ 
/* 2203 */     deleteRoleRights(right, deletedRoleRightList);
/*      */ 
/* 2207 */     deleteRoleRights(right, updatedOperTypeList);
/*      */ 
/* 2210 */     getResourceRightDAO(right.getRoleType(), right.getResourceType()).save(updatedOperTypeList);
/*      */ 
/* 2213 */     if (CollectionUtils.isNotEmpty(deletedRoleRightList)) {
/* 2214 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_UPLOAD_OPER_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGERESOURCE"), right.getResourceId(), right.getResourceName(), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrDeleteRole"), null, null);
/*      */     }
/*      */ 
/* 2225 */     if (CollectionUtils.isNotEmpty(addedRoleRightList)) {
/* 2226 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGERESOURCE"), right.getResourceId(), right.getResourceName(), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrAddRole"), null, null);
/*      */     }
/*      */ 
/* 2236 */     this.log.debug("end  doAssignRolesToRight...");
/*      */   }
/*      */ 
/*      */   private void batchDeleteRoleRight()
/*      */   {
/*      */   }
/*      */ 
/*      */   private void deleteRoleRights(Right right, List<RoleRight> deletedRoleRightList)
/*      */   {
/* 2248 */     int resourceType = right.getResourceType();
/* 2249 */     int roleType = right.getRoleType();
/* 2250 */     List rightList = new ArrayList();
/* 2251 */     rightList.add(right);
/*      */ 
/* 2253 */     for (RoleRight roleRight : deletedRoleRightList) {
/* 2254 */       String deletedRoleId = roleRight.getRoleId();
/* 2255 */       List removeRoleIdListByGroup = new ArrayList();
/* 2256 */       removeRoleIdListByGroup.add(deletedRoleId);
/*      */ 
/* 2259 */       UserRole role = getRoleById(deletedRoleId);
/*      */ 
/* 2262 */       Collection allGroupList = UserGroupDefineCache.getInstance().getAllCachedObject();
/*      */ 
/* 2264 */       List allSubGroupIdList = new ArrayList();
/* 2265 */       for (User_Group group : allGroupList) {
/* 2266 */         if (group.getParentid().contains(role.getCreateGroup())) {
/* 2267 */           allSubGroupIdList.add(group.getGroupid());
/*      */         }
/* 2269 */         if (group.getAllParentId().contains(role.getCreateGroup())) {
/* 2270 */           allSubGroupIdList.add(group.getGroupid());
/*      */         }
/*      */       }
/* 2273 */       for (Iterator i$ = allSubGroupIdList.iterator(); i$.hasNext(); ) { groupId = (String)i$.next();
/*      */ 
/* 2276 */         Collection allRoleList = UserRoleCache.getInstance().getAllCachedObject();
/*      */ 
/* 2278 */         for (UserRole roleObj : allRoleList)
/* 2279 */           if ((groupId.equals(roleObj.getCreateGroup())) && 
/* 2280 */             (resourceType == roleObj.getResourceType()) && (roleType == roleObj.getRoleType()))
/*      */           {
/* 2282 */             removeRoleIdListByGroup.add(roleObj.getRoleId());
/*      */           }
/*      */       }
/*      */       String groupId;
/* 2293 */       getResourceRightDAO(right.getRoleType(), right.getResourceType()).delete(removeRoleIdListByGroup, rightList, resourceType);
/*      */     }
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void doAssignRightsToRole(String roleId, Collection<RoleRight> addedRoleRightList, Collection<RoleRight> deletedRoleRightList, Collection<String> updatedResourceIdList)
/*      */   {
/* 2307 */     this.log.debug(" in doAssignRightsToRole");
/*      */ 
/* 2309 */     saveRoleRightByForce(addedRoleRightList, deletedRoleRightList, roleId);
/*      */ 
/* 2311 */     UserRole userRole = this.userRoleDao.findById(roleId);
/* 2312 */     IResourceRightDAO rightDao = getResourceRightDAO(userRole.getRoleType(), userRole.getResourceType());
/*      */ 
/* 2316 */     for (String updatedControlTypeStr : updatedResourceIdList) {
/* 2317 */       String[] updateStrArr = updatedControlTypeStr.split("\\|", -1);
/* 2318 */       if (updateStrArr.length == 2)
/*      */       {
/* 2321 */         rightDao.updateControlType(roleId, userRole.getResourceType(), updateStrArr[0], updateStrArr[1]);
/*      */       }
/*      */     }
/*      */ 
/* 2325 */     for (RoleRight roleRight : deletedRoleRightList) {
/* 2326 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"), roleId, userRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrDeleteRoleAuth") + "", roleRight.getRight().toMap(), null);
/*      */     }
/*      */ 
/* 2335 */     for (RoleRight roleRight : addedRoleRightList) {
/* 2336 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"), roleId, userRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrAddRoleAuth") + "", null, roleRight.getRight().toMap());
/*      */     }
/*      */ 
/* 2345 */     this.log.debug(" end doAssignRightsToRole");
/*      */   }
/*      */ 
/*      */   public void doAssignRightsToRole(String roleId, int resourceType, Collection<RoleRight> addedRoleRightList, Collection<RoleRight> deletedRoleRightList, Collection<String> updatedResourceIdList)
/*      */   {
/* 2359 */     this.log.debug(" in doAssignRightsToRole");
/*      */ 
/* 2361 */     saveRoleRightByForce(addedRoleRightList, deletedRoleRightList, roleId, resourceType);
/*      */ 
/* 2364 */     UserRole userRole = this.userRoleDao.findById(roleId);
/* 2365 */     IResourceRightDAO rightDao = getResourceRightDAO(-1, resourceType);
/* 2366 */     if (rightDao == null) {
/* 2367 */       return;
/*      */     }
/*      */ 
/* 2371 */     for (String updatedControlTypeStr : updatedResourceIdList) {
/* 2372 */       String[] updateStrArr = updatedControlTypeStr.split("\\|", -1);
/* 2373 */       if (updateStrArr.length == 2)
/*      */       {
/* 2376 */         rightDao.updateControlType(roleId, resourceType, updateStrArr[0], updateStrArr[1]);
/*      */       }
/*      */     }
/* 2379 */     if (CollectionUtils.isNotEmpty(deletedRoleRightList)) {
/* 2380 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"), roleId, userRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrDeleteRoleAuth") + "", null, null);
/*      */     }
/*      */ 
/* 2389 */     if (CollectionUtils.isNotEmpty(addedRoleRightList)) {
/* 2390 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"), roleId, userRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrAddRoleAuth") + "", null, null);
/*      */     }
/*      */ 
/* 2400 */     this.log.debug(" end doAssignRightsToRole");
/*      */   }
/*      */ 
/*      */   public void doAssignUsersToRole(String roleId, List<String> addedGroupIdList, List<String> deletedGroupIdList, List<String> addedUserIdList, List<String> deletedUserIdList)
/*      */     throws ServiceException
/*      */   {
/*      */     try
/*      */     {
/* 2408 */       userRole = this.userRoleDao.findById(roleId);
/*      */ 
/* 2411 */       for (String groupId : addedGroupIdList) {
/* 2412 */         GroupRoleMap groupRoleMap = new GroupRoleMap(groupId, roleId);
/* 2413 */         this.groupRoleMapDao.save(groupRoleMap);
/*      */ 
/* 2415 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), roleId, userRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrAddGroup") + "", null, groupRoleMap.toMap());
/*      */       }
/*      */ 
/* 2426 */       if (ifRoleUsedByGroups(roleId, deletedGroupIdList)) {
/* 2427 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleCannotRemove") + "");
/*      */       }
/*      */ 
/* 2431 */       for (String groupId : deletedGroupIdList) {
/* 2432 */         GroupRoleMap realMap = this.groupRoleMapDao.findById(new GroupRoleMap(groupId, roleId));
/*      */ 
/* 2434 */         if (realMap != null) {
/* 2435 */           LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), roleId, userRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrDeleteGroup") + "", realMap.toMap(), null);
/*      */ 
/* 2445 */           this.groupRoleMapDao.delete(realMap);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2450 */       for (String userId : addedUserIdList) {
/* 2451 */         UserRoleMap userRoleMap = new UserRoleMap(userId, roleId);
/* 2452 */         this.userRoleMapDao.save(userRoleMap);
/*      */ 
/* 2454 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), roleId, userRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrAddRoleUser") + "", null, userRoleMap.toMap());
/*      */       }
/*      */ 
/* 2465 */       for (String userId : deletedUserIdList) {
/* 2466 */         UserRoleMap realMap = this.userRoleMapDao.getById(new UserRoleMap(userId, roleId));
/*      */ 
/* 2468 */         if (realMap != null) {
/* 2469 */           LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), roleId, userRole.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrDeleteRoleUser") + "", realMap.toMap(), null);
/*      */ 
/* 2478 */           this.userRoleMapDao.delete(realMap);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/*      */       UserRole userRole;
/* 2482 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.assignRoleUserFail") + "", e);
/*      */ 
/* 2485 */       throw new ServiceException(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void doAssignRightsToRoles(List<RoleRight> addedRoleRightList)
/*      */   {
/* 2493 */     this.log.debug(" in doAssignRightsToRoles");
/*      */     try {
/* 2495 */       RoleRight firstRoleRight = (RoleRight)addedRoleRightList.iterator().next();
/* 2496 */       int roleType = firstRoleRight.getRight().getRoleType();
/* 2497 */       int resourceType = firstRoleRight.getRight().getResourceType();
/*      */ 
/* 2499 */       IResourceRightDAO rightDao = getResourceRightDAO(roleType, resourceType);
/*      */ 
/* 2501 */       for (RoleRight newRoleRight : addedRoleRightList) {
/* 2502 */         String roleId = newRoleRight.getRoleId();
/* 2503 */         Right right = newRoleRight.getRight();
/* 2504 */         RoleRight realRoleRight = rightDao.getRoleRight(roleId, resourceType, right.getResourceId(), right.getOperationType());
/*      */ 
/* 2507 */         if (realRoleRight.getRight() == null)
/*      */         {
/* 2510 */           rightDao.save(newRoleRight);
/*      */ 
/* 2512 */           UserRole role = (UserRole)UserRoleCache.getInstance().getObjectByKey(roleId);
/*      */ 
/* 2514 */           LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_ROLE"), roleId, role.getRoleName(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrAddRoleAuth") + "", null, right.toMap());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2523 */       this.log.debug(" end doAssignRightsToRoles");
/*      */     } catch (Exception e) {
/* 2525 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleAuthMapFail") + "", e);
/*      */ 
/* 2528 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleAuthMapFail") + ":" + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<UserRole> getRoleListByName(String roleName)
/*      */   {
/* 2536 */     return this.userRoleDao.getRoleListByName(roleName);
/*      */   }
/*      */ 
/*      */   public void doRealDeleteGroup(DeletedParameterVO vo)
/*      */   {
/*      */     try
/*      */     {
/* 2545 */       List list = this.userRoleDao.doRealDelete(vo);
/*      */ 
/* 2547 */       String logResourceId = vo.getIdString();
/* 2548 */       if (StringUtils.isBlank(logResourceId)) {
/* 2549 */         logResourceId = "resourceId";
/*      */       }
/* 2551 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), list.get(0).toString(), list.get(1).toString(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRole") + "", null, null);
/*      */ 
/* 2559 */       this.log.debug(" end doRealDeleteUser");
/*      */     } catch (DaoException e) {
/* 2561 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRoleFail") + "", e);
/*      */ 
/* 2564 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRoleFail") + "", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String exportActionStatus(HttpServletRequest request)
/*      */   {
/* 2577 */     String resultString = "doing";
/* 2578 */     if ("success".equals(request.getSession().getAttribute("ExportListRight")))
/*      */     {
/* 2580 */       resultString = "success";
/*      */     }
/* 2582 */     else resultString = "doing";
/*      */ 
/* 2584 */     request.getSession().setAttribute("ExportListRight", null);
/* 2585 */     return resultString;
/*      */   }
/*      */ 
/*      */   public Right getRight(String resourceId, int roleType, int resourceType)
/*      */   {
/* 2595 */     this.log.debug("in getRight");
/*      */     try {
/* 2597 */       return getResourceRightDAO(roleType, resourceType).getRight(resourceId);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2601 */       this.log.error("getRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 2604 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + resourceId + "," + roleType + "," + resourceType);
/*      */   }
/*      */ 
/*      */   public void saveRight(String operatorId, int operatorType, int resourceType, String resourceId, int accessType, String controlType)
/*      */     throws ServiceException
/*      */   {
/* 2621 */     IResourceRightDAO resourceRightDAO = getResourceRightDAO(-1, resourceType);
/* 2622 */     if (resourceRightDAO != null) {
/* 2623 */       Right right = new Right();
/* 2624 */       right.setResourceId(resourceId);
/* 2625 */       right.setResourceType(resourceType);
/* 2626 */       right.setOperationType(String.valueOf(accessType));
/* 2627 */       RoleRight roleRight = new RoleRight();
/* 2628 */       roleRight.setRoleId(operatorId);
/* 2629 */       roleRight.setControlType(controlType);
/* 2630 */       roleRight.setOperatorType(operatorType);
/* 2631 */       roleRight.setRight(right);
/* 2632 */       resourceRightDAO.save(roleRight);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveRight(int resourceType, List<RoleRight> roleRightList)
/*      */     throws ServiceException
/*      */   {
/* 2643 */     IResourceRightDAO resourceRightDAO = getResourceRightDAO(-1, resourceType);
/*      */ 
/* 2645 */     if (null != resourceRightDAO)
/* 2646 */       resourceRightDAO.save(roleRightList);
/*      */   }
/*      */ 
/*      */   public void deleteRight(String operatorId, int operatorType, int resourceType, String resourceId)
/*      */     throws ServiceException
/*      */   {
/* 2653 */     boolean flag = true;
/* 2654 */     if (operatorId.contains("!!")) {
/* 2655 */       operatorId = operatorId.split("!!")[0];
/* 2656 */       flag = false;
/* 2657 */     }IResourceRightDAO resourceRightDAO = getResourceRightDAO(-1, resourceType);
/* 2658 */     if (resourceRightDAO != null) {
/* 2659 */       resourceRightDAO.deleteRight(operatorId, operatorType, resourceType, resourceId);
/*      */     }
/*      */ 
/* 2662 */     String resourceName = operatorId;
/* 2663 */     if (operatorType == 0) {
/* 2664 */       UserRole role = (UserRole)UserRoleCache.getInstance().getObjectByKey(operatorId);
/* 2665 */       if (null != role)
/* 2666 */         resourceName = role.getRoleName();
/*      */     }
/* 2668 */     else if (operatorType == 1) {
/* 2669 */       User_User user = (User_User)UserCache.getInstance().getObjectByKey(operatorId);
/* 2670 */       if (null != user) {
/* 2671 */         resourceName = user.getUsername();
/*      */       }
/*      */     }
/* 2674 */     if (flag)
/* 2675 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), operatorId, resourceName, LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteRight"), null, null);
/*      */   }
/*      */ 
/*      */   private boolean ifRoleRightUsedByCreateRole(String roleId, List<String> createRoleIds, List<String> assignRoleIds)
/*      */   {
/* 2699 */     Collection srtList = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/* 2701 */     for (SysResourceType srt : srtList)
/*      */     {
/* 2703 */       int roleType = srt.getRoleType();
/* 2704 */       int resourceType = srt.getResourceType();
/*      */ 
/* 2707 */       List rightList = getRightsByRoleId(roleId, roleType, resourceType);
/*      */ 
/* 2709 */       if (!CollectionUtils.isEmpty(rightList))
/*      */       {
/* 2714 */         List rightOfCreateRole = getRightsByRoleIdList(createRoleIds, roleType, resourceType, false);
/*      */ 
/* 2716 */         if (!CollectionUtils.isEmpty(rightOfCreateRole))
/*      */         {
/* 2721 */           List rightOfGroup = getRightsByRoleIdList(assignRoleIds, roleType, resourceType, false);
/*      */ 
/* 2724 */           rightOfCreateRole.removeAll(rightOfGroup);
/* 2725 */           rightOfCreateRole.retainAll(rightList);
/* 2726 */           if (rightOfCreateRole.size() > 0)
/* 2727 */             return true; 
/*      */         }
/*      */       }
/*      */     }
/* 2730 */     return false;
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getAssignedResourceTypeList(String roleId)
/*      */   {
/* 2740 */     List lvbList = new ArrayList();
/*      */ 
/* 2742 */     Collection allTypeList = SysResourceTypeCache.getInstance().getAllSysResourceTypeByName();
/*      */ 
/* 2744 */     for (SysResourceType type : allTypeList) {
/* 2745 */       List rightList = getRoleRightsByRoleId(roleId, type.getResourceType());
/*      */ 
/* 2747 */       List assignedRightList = new ArrayList();
/*      */ 
/* 2749 */       if ((rightList != null) && (rightList.size() > 0))
/*      */       {
/*      */         Map rightMap;
/* 2752 */         if ((type.getResourceType() == Integer.parseInt("5")) || (type.getResourceType() == Integer.parseInt("1001")))
/*      */         {
/* 2756 */           assignedRightList.addAll(rightList);
/*      */         } else {
/* 2758 */           rightMap = new HashMap();
/* 2759 */           for (RoleRight roleRight : rightList) {
/* 2760 */             rightMap.put(roleRight.getRight().getResourceId(), roleRight.getRight());
/*      */           }
/*      */ 
/* 2763 */           for (RoleRight roleRight : rightList) {
/* 2764 */             Right right = roleRight.getRight();
/* 2765 */             boolean exsitParent = exsitParent(right, rightMap);
/* 2766 */             if (exsitParent)
/*      */             {
/* 2769 */               assignedRightList.add(roleRight);
/*      */             }
/*      */           }
/*      */         }
/* 2773 */         if ((assignedRightList != null) && (assignedRightList.size() > 0)) {
/* 2774 */           LabelValueBean lvb = new LabelValueBean();
/* 2775 */           lvb.setLabel(type.getResourcetypeName());
/* 2776 */           lvb.setValue(Integer.valueOf(type.getResourceType()).toString());
/*      */ 
/* 2778 */           lvbList.add(lvb);
/*      */         }
/*      */       }
/*      */     }
/* 2782 */     return lvbList;
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getUpdateResourceTypeList(String roleId)
/*      */   {
/* 2794 */     List lvbList = new ArrayList();
/* 2795 */     UserRole role = getRoleById(roleId);
/* 2796 */     if (role == null) {
/* 2797 */       return new ArrayList();
/*      */     }
/*      */ 
/* 2801 */     if (getUserGroupAdminService().isAdminGroup(role.getCreateGroup())) {
/* 2802 */       return getAllResourceTypeList();
/*      */     }
/*      */ 
/* 2806 */     Collection allTypeList = SysResourceTypeCache.getInstance().getAllSysResourceTypeByName();
/*      */ 
/* 2808 */     for (SysResourceType type : allTypeList) {
/* 2809 */       List rightList = getUserGroupAdminService().getRightByGroup(role.getCreateGroup(), -1, type.getResourceType(), true);
/*      */ 
/* 2812 */       if ((rightList != null) && (rightList.size() > 0)) {
/* 2813 */         lvbList.add(new LabelValueBean(type.getResourcetypeName(), String.valueOf(type.getResourceType())));
/*      */       }
/*      */     }
/*      */ 
/* 2817 */     return lvbList;
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getAllResourceTypeList()
/*      */   {
/* 2828 */     List lvbList = new ArrayList();
/* 2829 */     Collection allTypeList = SysResourceTypeCache.getInstance().getAllSysResourceTypeByName();
/*      */ 
/* 2831 */     for (SysResourceType srt : allTypeList) {
/* 2832 */       List rightList = getAllRights(Integer.valueOf(srt.getRoleType()).intValue(), Integer.valueOf(srt.getResourceType()).intValue());
/*      */ 
/* 2834 */       if ((rightList != null) && (rightList.size() > 0)) {
/* 2835 */         lvbList.add(new LabelValueBean(srt.getResourcetypeName(), String.valueOf(srt.getResourceType())));
/*      */       }
/*      */     }
/*      */ 
/* 2839 */     return lvbList;
/*      */   }
/*      */ 
/*      */   private boolean exsitParent(Right right, Map<String, Right> rightMap)
/*      */   {
/* 2850 */     String parentId = right.getParentId();
/* 2851 */     if (("0".equals(parentId)) || ("-1".equals(parentId)) || ("-2".equals(parentId)))
/*      */     {
/* 2853 */       return true;
/*      */     }
/* 2855 */     Right parentRight = (Right)rightMap.get(parentId);
/* 2856 */     if (parentRight == null) {
/* 2857 */       return false;
/*      */     }
/* 2859 */     return exsitParent(parentRight, rightMap);
/*      */   }
/*      */ 
/*      */   public List<String> getAllParentResourceIds(String resourceId, int roleType, int resourceType)
/*      */   {
/*      */     try
/*      */     {
/* 2868 */       IResourceRightDAO resourceRightDAO = getResourceRightDAO(roleType, resourceType);
/*      */ 
/* 2870 */       if (resourceRightDAO == null) {
/* 2871 */         return new ArrayList();
/*      */       }
/* 2873 */       return resourceRightDAO.getAllParentIds(resourceId);
/*      */     } catch (Exception e) {
/* 2875 */       this.log.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 2878 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List getUserRoleByTime(String startTime, String endTime)
/*      */   {
/* 2885 */     List list = new ArrayList();
/*      */     try {
/* 2887 */       list = this.userRoleDao.getUserRoleByTime(startTime, endTime);
/*      */     } catch (Exception e) {
/* 2889 */       this.log.error("getUserRoleByTime " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 2892 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserRoleByTime") + "");
/*      */     }
/* 2894 */     return list;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.RoleAdminServiceImpl
 * JD-Core Version:    0.6.2
 */
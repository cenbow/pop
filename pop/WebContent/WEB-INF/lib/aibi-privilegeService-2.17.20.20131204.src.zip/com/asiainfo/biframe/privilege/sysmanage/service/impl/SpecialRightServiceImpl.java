/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.ISysmanageJdbcDao;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.ISpecialRightService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SpecialRightServiceImpl
/*     */   implements ISpecialRightService
/*     */ {
/*  32 */   private Log log = LogFactory.getLog(SpecialRightServiceImpl.class);
/*     */   private IUserRoleDAO userRoleDao;
/*     */   private IResourceRightDAO resourceRightDao;
/*     */   private ISysmanageJdbcDao sysmanageJdbcDao;
/*     */   private IRoleAdminService roleAdminService;
/*     */   private IUserGroupAdminService userGroupAdminService;
/*     */ 
/*     */   public String getRptFileTree(String roleid, String loginUserId, boolean bShow, boolean bOpen)
/*     */     throws Exception
/*     */   {
/*  58 */     IUserGroupAdminService userGroupService = (IUserGroupAdminService)SystemServiceLocator.getInstance().getService("right_userGroupAdminService");
/*     */ 
/*  60 */     IRoleAdminService userRoleService = (IRoleAdminService)SystemServiceLocator.getInstance().getService("right_roleAdminService");
/*  61 */     UserRole userRole = this.userRoleDao.findById(roleid);
/*     */ 
/*  64 */     String groupId = userRole.getCreateGroup();
/*  65 */     boolean bAdmin = groupId.equals("1");
/*  66 */     List roleIdList = new ArrayList();
/*     */ 
/*  68 */     if (!bAdmin) {
/*  69 */       List roleList = userGroupService.getRoleListByGroupId(groupId);
/*  70 */       this.log.info("roleList.size=" + roleList.size());
/*  71 */       roleList = userRoleService.filterRoleByType(roleList, userRole.getRoleType(), userRole.getResourceType());
/*  72 */       this.log.info("after roleList.size=" + roleList.size());
/*  73 */       roleIdList = ListService.convertToNewList(roleList, "RoleId");
/*     */     }
/*     */ 
/*  76 */     String treeHtml = this.sysmanageJdbcDao.getRptFileTree(roleid, "-2", 0, bShow, bOpen, "0", roleIdList, loginUserId, bAdmin, new String());
/*     */ 
/*  79 */     return treeHtml;
/*     */   }
/*     */ 
/*     */   public String getIrIndiTree(String roleid, String loginUserId, boolean bShow, boolean bOpen)
/*     */     throws Exception
/*     */   {
/*  91 */     IUserGroupAdminService userGroupService = (IUserGroupAdminService)SystemServiceLocator.getInstance().getService("right_userGroupAdminService");
/*     */ 
/*  93 */     IRoleAdminService userRoleService = (IRoleAdminService)SystemServiceLocator.getInstance().getService("right_roleAdminService");
/*  94 */     UserRole userRole = this.userRoleDao.findById(roleid);
/*     */ 
/*  97 */     String groupId = userRole.getCreateGroup();
/*  98 */     boolean bAdmin = groupId.equals("1");
/*  99 */     List roleIdList = new ArrayList();
/*     */ 
/* 101 */     if (!bAdmin) {
/* 102 */       List roleList = userGroupService.getRoleListByGroupId(groupId);
/* 103 */       this.log.info("roleList.size=" + roleList.size());
/* 104 */       roleList = userRoleService.filterRoleByType(roleList, userRole.getRoleType(), userRole.getResourceType());
/* 105 */       this.log.info("after roleList.size=" + roleList.size());
/* 106 */       roleIdList = ListService.convertToNewList(roleList, "RoleId");
/*     */     }
/*     */ 
/* 109 */     String treeHtml = this.sysmanageJdbcDao.getIrIndiTree(roleid, "0", 0, bShow, bOpen, "0", roleIdList, loginUserId, bAdmin, new String());
/*     */ 
/* 111 */     return treeHtml;
/*     */   }
/*     */ 
/*     */   public void saveRoleRptFileRight(String roleId, List<Right> viewIdList, List<Right> uploadIdList, List<Right> auditIdList)
/*     */   {
/* 120 */     this.log.info("saveRoleRptFileRight...... ");
/*     */     try
/*     */     {
/* 123 */       UserRole userRole = this.userRoleDao.findById(roleId);
/* 124 */       List deleteRoleIdList = null;
/*     */ 
/* 126 */       com.asiainfo.biframe.common.SysCodes.accessType = "1";
/* 127 */       List roleDeletedList = getRoleAdminService().getRightsByRoleId(roleId);
/*     */ 
/* 129 */       roleDeletedList.removeAll(viewIdList);
/*     */ 
/* 131 */       List subGroupList = getUserGroupAdminService().getSubGroup(userRole.getCreateGroup());
/* 132 */       if ((subGroupList != null) && (roleDeletedList.size() > 0)) {
/* 133 */         for (int i = 0; i < subGroupList.size(); i++) {
/* 134 */           User_Group ug = (User_Group)subGroupList.get(i);
/* 135 */           if (getRoleAdminService().isRoleInGroup(ug.getGroupid(), roleId)) {
/* 136 */             getRoleAdminService().deleteResourceRightByForce(viewIdList, roleDeletedList, ug.getGroupid(), userRole);
/*     */           }
/*     */         }
/*     */       }
/* 140 */       this.resourceRightDao.delete(roleId, userRole.getResourceType());
/*     */ 
/* 142 */       com.asiainfo.biframe.common.SysCodes.accessType = "2";
/* 143 */       roleDeletedList = getRoleAdminService().getRightsByRoleId(roleId);
/*     */ 
/* 145 */       roleDeletedList.removeAll(uploadIdList);
/*     */ 
/* 147 */       subGroupList = getUserGroupAdminService().getSubGroup(userRole.getCreateGroup());
/* 148 */       if ((subGroupList != null) && (roleDeletedList.size() > 0)) {
/* 149 */         for (int i = 0; i < subGroupList.size(); i++) {
/* 150 */           User_Group ug = (User_Group)subGroupList.get(i);
/* 151 */           if (getRoleAdminService().isRoleInGroup(ug.getGroupid(), roleId)) {
/* 152 */             getRoleAdminService().deleteResourceRightByForce(uploadIdList, roleDeletedList, ug.getGroupid(), userRole);
/*     */           }
/*     */         }
/*     */       }
/* 156 */       this.resourceRightDao.delete(roleId, userRole.getResourceType());
/*     */ 
/* 158 */       com.asiainfo.biframe.common.SysCodes.accessType = "3";
/* 159 */       roleDeletedList = getRoleAdminService().getRightsByRoleId(roleId);
/*     */ 
/* 161 */       roleDeletedList.removeAll(auditIdList);
/*     */ 
/* 163 */       subGroupList = getUserGroupAdminService().getSubGroup(userRole.getCreateGroup());
/* 164 */       if ((subGroupList != null) && (roleDeletedList.size() > 0)) {
/* 165 */         for (int i = 0; i < subGroupList.size(); i++) {
/* 166 */           User_Group ug = (User_Group)subGroupList.get(i);
/* 167 */           if (getRoleAdminService().isRoleInGroup(ug.getGroupid(), roleId)) {
/* 168 */             getRoleAdminService().deleteResourceRightByForce(auditIdList, roleDeletedList, ug.getGroupid(), userRole);
/*     */           }
/*     */         }
/*     */       }
/* 172 */       this.resourceRightDao.delete(roleId, userRole.getResourceType());
/*     */ 
/* 175 */       this.sysmanageJdbcDao.saveRptFileRight(roleId, deleteRoleIdList, viewIdList, uploadIdList, auditIdList);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 179 */       e.printStackTrace();
/* 180 */       this.log.error("saveRoleRptFileRight " + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.exceptionOccur") + "", e);
/* 181 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.saveRoleResourceRightFail") + "");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveRoleIndiRight(String roleId, List<Right> viewIdList, List<Right> adminIdList)
/*     */   {
/* 193 */     this.log.info("saveRoleIndiRight...... ");
/*     */     try
/*     */     {
/* 196 */       List deleteRoleIdList = null;
/*     */ 
/* 199 */       this.sysmanageJdbcDao.saveIndiRight(roleId, deleteRoleIdList, viewIdList, adminIdList);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 203 */       e.printStackTrace();
/* 204 */       this.log.error("saveRoleIndiRight " + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.exceptionOccur") + "", e);
/* 205 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.saveRoleResourceRightFail") + "");
/*     */     }
/*     */   }
/*     */ 
/*     */   public IRoleAdminService getRoleAdminService()
/*     */   {
/* 211 */     return this.roleAdminService;
/*     */   }
/*     */ 
/*     */   public void setRoleAdminService(IRoleAdminService roleAdminService) {
/* 215 */     this.roleAdminService = roleAdminService;
/*     */   }
/*     */ 
/*     */   public IUserGroupAdminService getUserGroupAdminService() {
/* 219 */     return this.userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserGroupAdminService(IUserGroupAdminService userGroupAdminService) {
/* 223 */     this.userGroupAdminService = userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public IUserRoleDAO getUserRoleDao() {
/* 227 */     return this.userRoleDao;
/*     */   }
/*     */ 
/*     */   public void setUserRoleDao(IUserRoleDAO userRoleDao) {
/* 231 */     this.userRoleDao = userRoleDao;
/*     */   }
/*     */ 
/*     */   public IResourceRightDAO getResourceRightDao() {
/* 235 */     return this.resourceRightDao;
/*     */   }
/*     */ 
/*     */   public void setResourceRightDao(IResourceRightDAO resourceRightDao) {
/* 239 */     this.resourceRightDao = resourceRightDao;
/*     */   }
/*     */ 
/*     */   public ISysmanageJdbcDao getSysmanageJdbcDao() {
/* 243 */     return this.sysmanageJdbcDao;
/*     */   }
/*     */ 
/*     */   public void setSysmanageJdbcDao(ISysmanageJdbcDao sysmanageJdbcDao) {
/* 247 */     this.sysmanageJdbcDao = sysmanageJdbcDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.SpecialRightServiceImpl
 * JD-Core Version:    0.6.2
 */
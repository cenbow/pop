/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.cache.object.SysMenuItemViewCache;
/*     */ import com.asiainfo.biframe.privilege.model.SysMenuItem;
/*     */ import com.asiainfo.biframe.privilege.model.SysMenuItemRela;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.ISysMenuItemDao;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.ISysMenuItemService;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.sf.json.JSONArray;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SysMenuItemServiceImpl
/*     */   implements ISysMenuItemService
/*     */ {
/*  31 */   private static final Logger logger = Logger.getLogger(SysMenuItemServiceImpl.class);
/*     */   private ISysMenuItemDao sysMenuItemDao;
/*     */ 
/*     */   public ISysMenuItemDao getSysMenuItemDao()
/*     */   {
/*  35 */     return this.sysMenuItemDao;
/*     */   }
/*     */ 
/*     */   public void setSysMenuItemDao(ISysMenuItemDao sysMenuItemDao) {
/*  39 */     this.sysMenuItemDao = sysMenuItemDao;
/*     */   }
/*     */ 
/*     */   public IMenuItem findById(Integer menuItemId) {
/*  43 */     return this.sysMenuItemDao.findById(menuItemId);
/*     */   }
/*     */ 
/*     */   public Integer addPublishMenu(int pMenuId, String resType, String resId, String menuName, String menuUrl)
/*     */   {
/*  48 */     Integer menuItemId = null;
/*     */     try {
/*  50 */       SysMenuItem parentSmi = this.sysMenuItemDao.findById(Integer.valueOf(pMenuId));
/*  51 */       if (null == parentSmi) {
/*  52 */         logger.info("Did not find the parent menu. pMenuId=" + pMenuId);
/*  53 */         return null;
/*     */       }
/*  55 */       if (!"1".equals(resType)) {
/*  56 */         List smiList = this.sysMenuItemDao.findByResId(resId, Integer.valueOf(Integer.parseInt(resType)));
/*  57 */         if ((null != smiList) && (smiList.size() > 0)) {
/*  58 */           logger.info("Existing resource ID of the menu. resId=" + resId);
/*  59 */           return null;
/*     */         }
/*     */       }
/*  62 */       SysMenuItem smi = new SysMenuItem();
/*  63 */       smi.setResourceType(Integer.valueOf(Integer.parseInt("50")));
/*  64 */       smi.setAccessToken(Integer.valueOf(1));
/*  65 */       smi.setUrl(menuUrl);
/*  66 */       smi.setParentId(Integer.valueOf(pMenuId));
/*  67 */       smi.setMenuItemTitle(menuName);
/*  68 */       smi.setResType(Integer.valueOf(Integer.parseInt(resType)));
/*  69 */       if ("1".equals(resType)) {
/*  70 */         if (StringUtils.isNotBlank(resId))
/*  71 */           smi.setMenuItemId(Integer.valueOf(Integer.parseInt(resId)));
/*     */       }
/*     */       else {
/*  74 */         smi.setResId(resId);
/*     */       }
/*  76 */       menuItemId = this.sysMenuItemDao.save(smi);
/*  77 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MENUMAINTAIN"), menuItemId.toString(), menuName, LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.newMenu"), null, null);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  84 */       throw new RuntimeException(e);
/*     */     }
/*  86 */     return menuItemId;
/*     */   }
/*     */ 
/*     */   public List<SysMenuItem> deletePublishMenu(String resType, String resId) {
/*  90 */     List smiList = new ArrayList();
/*     */     try {
/*  92 */       if ("1".equals(resType)) {
/*  93 */         smiList.add(this.sysMenuItemDao.findById(Integer.valueOf(Integer.parseInt(resId))));
/*  94 */         this.sysMenuItemDao.deleteById(Integer.valueOf(Integer.parseInt(resId)));
/*     */       } else {
/*  96 */         smiList = this.sysMenuItemDao.findByResId(resId, Integer.valueOf(Integer.parseInt(resType)));
/*  97 */         this.sysMenuItemDao.deleteAll(smiList);
/*     */       }
/*     */     } catch (Exception e) {
/* 100 */       throw new RuntimeException(e);
/*     */     }
/* 102 */     return smiList;
/*     */   }
/*     */ 
/*     */   public String queryFolderList(int menuItemId) {
/* 106 */     List smList = this.sysMenuItemDao.findByParentId(Integer.valueOf(menuItemId));
/* 107 */     JSONArray json = new JSONArray();
/* 108 */     for (SysMenuItem smi : smList) {
/* 109 */       Map map = new HashMap();
/* 110 */       map.put("id", smi.getMenuItemId().toString());
/* 111 */       map.put("name", smi.getMenuItemTitle());
/* 112 */       json.add(map);
/*     */     }
/* 114 */     if (json.isEmpty()) {
/* 115 */       return null;
/*     */     }
/* 117 */     return json.toString();
/*     */   }
/*     */ 
/*     */   public Integer modPublishMenu(int pMenuId, String resType, String resId, String menuName, String menuUrl)
/*     */   {
/* 122 */     Integer menuItemId = null;
/*     */     try {
/* 124 */       SysMenuItem parentSmi = this.sysMenuItemDao.findById(Integer.valueOf(pMenuId));
/* 125 */       if (null == parentSmi) {
/* 126 */         logger.info("Did not find the parent menu. pMenuId=" + pMenuId);
/* 127 */         return null;
/*     */       }
/* 129 */       SysMenuItem smi = null;
/* 130 */       if ("1".equals(resType)) {
/* 131 */         smi = this.sysMenuItemDao.findById(Integer.valueOf(Integer.parseInt(resId)));
/*     */       } else {
/* 133 */         List smiList = this.sysMenuItemDao.findByResId(resId, Integer.valueOf(Integer.parseInt(resType)));
/* 134 */         if ((null != smiList) && (smiList.size() > 0)) {
/* 135 */           smi = (SysMenuItem)smiList.get(0);
/*     */         }
/*     */       }
/* 138 */       if (null == smi) {
/* 139 */         logger.info("Did not find the  menu. resId=" + resId);
/* 140 */         return null;
/*     */       }
/* 142 */       smi.setParentId(Integer.valueOf(pMenuId));
/* 143 */       smi.setMenuItemTitle(menuName);
/* 144 */       smi.setUrl(menuUrl);
/* 145 */       this.sysMenuItemDao.modify(smi);
/* 146 */       menuItemId = smi.getMenuItemId();
/* 147 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MENUMAINTAIN"), smi.getMenuItemId().toString(), menuName, LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.newMenu"), null, null);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 154 */       throw new RuntimeException(e);
/*     */     }
/* 156 */     return menuItemId;
/*     */   }
/*     */ 
/*     */   public List getMenuItemList(Map<String, String> menuItem) {
/* 160 */     List smiList = new ArrayList();
/* 161 */     Collection collection = SysMenuItemViewCache.getInstance().getAllCachedObject();
/*     */ 
/* 163 */     Iterator it = collection.iterator();
/* 164 */     while (it.hasNext()) {
/* 165 */       SysMenuItem smi = (SysMenuItem)it.next();
/* 166 */       boolean flag = true;
/* 167 */       if (StringUtils.isNotBlank((String)menuItem.get("menuItemId"))) {
/* 168 */         if (null == smi.getMenuItemId()) {
/* 169 */           flag = false;
/*     */         }
/* 171 */         else if (!((String)menuItem.get("menuItemId")).equals(smi.getMenuItemId().toString()))
/*     */         {
/* 173 */           flag = false;
/*     */         }
/*     */ 
/*     */       }
/* 177 */       else if (StringUtils.isNotBlank((String)menuItem.get("menuItemTitle"))) {
/* 178 */         if (StringUtils.isBlank(smi.getMenuItemTitle())) {
/* 179 */           flag = false;
/*     */         }
/* 181 */         else if (smi.getMenuItemTitle().indexOf((String)menuItem.get("menuItemTitle")) == -1)
/*     */         {
/* 183 */           flag = false;
/*     */         }
/*     */ 
/*     */       }
/* 187 */       else if (StringUtils.isNotBlank((String)menuItem.get("parentId"))) {
/* 188 */         if (null == smi.getParentId()) {
/* 189 */           flag = false;
/*     */         }
/* 191 */         else if (!((String)menuItem.get("parentId")).equals(smi.getParentId().toString()))
/*     */         {
/* 193 */           flag = false;
/*     */         }
/*     */ 
/*     */       }
/* 197 */       else if (StringUtils.isNotBlank((String)menuItem.get("resourceType"))) {
/* 198 */         if (null == smi.getResourceType()) {
/* 199 */           flag = false;
/*     */         }
/* 201 */         else if (!((String)menuItem.get("resourceType")).equals(smi.getResourceType().toString()))
/*     */         {
/* 203 */           flag = false;
/*     */         }
/*     */ 
/*     */       }
/* 207 */       else if (StringUtils.isNotBlank((String)menuItem.get("applicationId"))) {
/* 208 */         if (StringUtils.isBlank(smi.getApplicationId())) {
/* 209 */           flag = false;
/*     */         }
/* 211 */         else if (!((String)menuItem.get("applicationId")).equals(smi.getApplicationId()))
/*     */         {
/* 213 */           flag = false;
/*     */         }
/*     */ 
/*     */       }
/* 217 */       else if (StringUtils.isNotBlank((String)menuItem.get("resType"))) {
/* 218 */         if (null == smi.getResType()) {
/* 219 */           flag = false;
/*     */         }
/* 221 */         else if (!((String)menuItem.get("resType")).equals(smi.getResType().toString()))
/*     */         {
/* 223 */           flag = false;
/*     */         }
/*     */ 
/*     */       }
/* 227 */       else if (StringUtils.isNotBlank((String)menuItem.get("resId"))) {
/* 228 */         if (StringUtils.isBlank(smi.getResId())) {
/* 229 */           flag = false;
/*     */         }
/* 231 */         else if (!((String)menuItem.get("resId")).equals(smi.getResId())) {
/* 232 */           flag = false;
/*     */         }
/*     */ 
/*     */       }
/* 236 */       else if (StringUtils.isNotBlank((String)menuItem.get("accessToken"))) {
/* 237 */         if (null == smi.getAccessToken()) {
/* 238 */           flag = false;
/*     */         }
/* 240 */         else if (!((String)menuItem.get("accessToken")).equals(smi.getAccessToken().toString()))
/*     */         {
/* 242 */           flag = false;
/*     */         }
/*     */ 
/*     */       }
/* 246 */       else if (StringUtils.isNotBlank((String)menuItem.get("menuType"))) {
/* 247 */         if (null == smi.getMenuType()) {
/* 248 */           flag = false;
/*     */         }
/* 250 */         else if (!((String)menuItem.get("menuType")).equals(smi.getMenuType().toString()))
/*     */         {
/* 252 */           flag = false;
/*     */         }
/*     */ 
/*     */       }
/* 256 */       else if (flag == true) {
/* 257 */         smiList.add(smi);
/*     */       }
/*     */     }
/* 260 */     return smiList;
/*     */   }
/*     */ 
/*     */   public void deleteSysMenuItemRela(Integer menuitemid) {
/*     */     try {
/* 265 */       this.sysMenuItemDao.delSysMenuItemRela(menuitemid);
/*     */     } catch (Exception e) {
/* 267 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void save(SysMenuItemRela smir) {
/*     */     try {
/* 273 */       this.sysMenuItemDao.save(smir);
/*     */     } catch (Exception e) {
/* 275 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteSysMenuItem(Integer menuitemid, Integer parentId) {
/* 280 */     List menuItemIdList = new ArrayList();
/*     */ 
/* 282 */     deleteMenus(menuitemid, parentId, menuItemIdList);
/*     */ 
/* 284 */     deleteMenuRight(menuItemIdList);
/*     */   }
/*     */ 
/*     */   private void deleteMenus(Integer menuitemid, Integer parentId, List<Integer> menuItemIdList)
/*     */   {
/* 289 */     SysMenuItemRela smir = this.sysMenuItemDao.getMenuRela(menuitemid, parentId);
/* 290 */     if (null != smir)
/*     */     {
/* 292 */       this.sysMenuItemDao.deleteMenuRela(smir);
/* 293 */       return;
/*     */     }
/*     */ 
/* 296 */     SysMenuItem smi = this.sysMenuItemDao.getMenu(menuitemid, parentId);
/* 297 */     if (null == smi) {
/* 298 */       return;
/*     */     }
/*     */ 
/* 301 */     List smirList = this.sysMenuItemDao.getMenu(menuitemid);
/* 302 */     if ((null != smirList) && (smirList.size() > 0))
/*     */     {
/* 304 */       SysMenuItemRela rela = (SysMenuItemRela)smirList.get(0);
/* 305 */       smi.setParentId(rela.getParentId());
/* 306 */       this.sysMenuItemDao.modify(smi);
/* 307 */       this.sysMenuItemDao.deleteMenuRela(rela);
/*     */     } else {
/* 309 */       menuItemIdList.add(menuitemid);
/* 310 */       this.sysMenuItemDao.delete(smi);
/* 311 */       Map map = new HashMap();
/* 312 */       map.put("parentId", menuitemid.toString());
/* 313 */       List menuList = this.sysMenuItemDao.getMenuItemList(map);
/* 314 */       for (SysMenuItem menu : menuList)
/* 315 */         deleteMenus(menu.getMenuItemId(), menu.getParentId(), menuItemIdList);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void deleteMenuRight(List<Integer> menuItemIdList)
/*     */   {
/* 322 */     String ids = "";
/* 323 */     for (Integer id : menuItemIdList) {
/* 324 */       ids = id + ",";
/*     */     }
/* 326 */     if (StringUtils.isNotBlank(ids)) {
/* 327 */       ids = ids.substring(0, ids.length() - 1);
/* 328 */       StringBuffer strSqlbuf = new StringBuffer();
/* 329 */       Sqlca mSqlca = null;
/*     */       try
/*     */       {
/* 332 */         mSqlca = new Sqlca(new ConnectionEx());
/* 333 */         strSqlbuf.append("delete from sys_menuitem_right ");
/* 334 */         strSqlbuf.append("where resourcetype=");
/* 335 */         strSqlbuf.append("50");
/* 336 */         strSqlbuf.append(" and resourceid in(");
/* 337 */         strSqlbuf.append(StringUtil.addInvertedComma(ids));
/* 338 */         strSqlbuf.append(")");
/* 339 */         mSqlca.execute(strSqlbuf.toString());
/*     */ 
/* 343 */         if (null != mSqlca)
/* 344 */           mSqlca.closeAll();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 341 */         throw new RuntimeException(e);
/*     */       } finally {
/* 343 */         if (null != mSqlca)
/* 344 */           mSqlca.closeAll();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.SysMenuItemServiceImpl
 * JD-Core Version:    0.6.2
 */
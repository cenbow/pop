/*    */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.ISysResourceTypeDAO;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.service.ISysResourceTypeService;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class SysResourceTypeService
/*    */   implements ISysResourceTypeService
/*    */ {
/* 23 */   private Log log = LogFactory.getLog(SysResourceTypeService.class);
/*    */   private ISysResourceTypeDAO sysResourceTypeDao;
/*    */ 
/*    */   public List<SysResourceType> findByRoleType(int roleType)
/*    */   {
/* 28 */     this.log.info("findByRoleType...... ");
/* 29 */     List result = new ArrayList();
/*    */     try {
/* 31 */       List list = this.sysResourceTypeDao.findAll();
/*    */ 
/* 33 */       if ((list == null) || (list.size() == 0)) {
/* 34 */         return result;
/*    */       }
/*    */ 
/* 37 */       if (roleType == -1) {
/* 38 */         return list;
/*    */       }
/* 40 */       for (int i = 0; i < list.size(); i++) {
/* 41 */         SysResourceType resourceType = (SysResourceType)list.get(i);
/* 42 */         if (resourceType.getRoleType() == roleType)
/* 43 */           result.add(resourceType);
/*    */       }
/* 45 */       return result;
/*    */     }
/*    */     catch (Exception e) {
/* 48 */       this.log.error("findByRoleType " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/* 49 */     }throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryResourceTypeFail") + "");
/*    */   }
/*    */ 
/*    */   public List<SysResourceType> findAll()
/*    */   {
/* 54 */     this.log.info("findAll...... ");
/*    */     try {
/* 56 */       return this.sysResourceTypeDao.findAll();
/*    */     } catch (Exception e) {
/* 58 */       this.log.error("findAll " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/* 59 */     }throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryResourceTypeFail") + "");
/*    */   }
/*    */ 
/*    */   public SysResourceType findBy(int roleType, int resourceType)
/*    */   {
/* 64 */     return this.sysResourceTypeDao.findSysResType(roleType, resourceType);
/*    */   }
/*    */   public List<SysResourceType> findByResourceType(int resourceType) {
/* 67 */     return this.sysResourceTypeDao.findByResourceType(resourceType);
/*    */   }
/*    */ 
/*    */   public List<SysResourceType> getSysTypeListByName(String resourceTypeName) {
/* 71 */     return this.sysResourceTypeDao.getSysTypeListByName(resourceTypeName);
/*    */   }
/*    */ 
/*    */   public void setSysResourceTypeDao(ISysResourceTypeDAO sysResourceTypeDao)
/*    */   {
/* 76 */     this.sysResourceTypeDao = sysResourceTypeDao;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.SysResourceTypeService
 * JD-Core Version:    0.6.2
 */
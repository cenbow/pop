/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*     */ import com.asiainfo.biframe.privilege.menu.TreeItem;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.ITreeItemDao;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.ITreeItemService;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TreeItemServiceImpl
/*     */   implements ITreeItemService
/*     */ {
/*  40 */   private Log log = LogFactory.getLog(TreeItemServiceImpl.class);
/*     */   private ITreeItemDao treeItemDao;
/*     */ 
/*     */   public TreeItem getMenuById(Integer menuId)
/*     */   {
/*  45 */     return this.treeItemDao.getMenuById(menuId);
/*     */   }
/*     */ 
/*     */   private TreeItem getBreadTreeItem(String userId, Integer menuId) {
/*  49 */     List alllist = getResourceIdListOfRight(userId, "50");
/*  50 */     TreeItem item = getMenuById(menuId);
/*  51 */     if (alllist.contains(String.valueOf(item.getMenuItemId()))) {
/*  52 */       return item;
/*     */     }
/*  54 */     return null;
/*     */   }
/*     */ 
/*     */   private List<TreeItem> getBreadSubSysMenuItems(String userId, Integer menuId)
/*     */   {
/*  59 */     List alllist = getResourceIdListOfRight(userId, "50");
/*  60 */     List menus = this.treeItemDao.getSubSysMenuItems(menuId, null);
/*  61 */     List ret = new ArrayList();
/*  62 */     for (TreeItem menu : menus) {
/*  63 */       if (alllist.contains(String.valueOf(menu.getMenuItemId()))) {
/*  64 */         ret.add(menu);
/*     */       }
/*     */     }
/*  67 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<List<TreeItem>> constructxBreadCrumbs(String userId, Integer menuId)
/*     */     throws Exception
/*     */   {
/*  74 */     List alllist = getResourceIdListOfRight(userId, "50");
/*  75 */     Stack result = new Stack();
/*     */ 
/*  78 */     List last = new ArrayList();
/*     */     TreeItem currentMenu;
/*     */     TreeItem currentMenu;
/*  80 */     if (menuId.intValue() == 0)
/*  81 */       currentMenu = (TreeItem)getBreadSubSysMenuItems(userId, menuId).get(0);
/*     */     else {
/*  83 */       currentMenu = getBreadTreeItem(userId, menuId);
/*     */     }
/*  85 */     if (currentMenu == null)
/*     */     {
/*  87 */       throw new Exception("No privilege for  " + currentMenu.getMenuItemTitle() + " or It is null");
/*     */     }
/*  89 */     last.add(currentMenu);
/*  90 */     last.addAll(getBreadSubSysMenuItems(userId, currentMenu.getMenuItemId()));
/*  91 */     result.push(last);
/*     */ 
/*  93 */     TreeItem temp = currentMenu;
/*     */ 
/*  95 */     while (temp.getParentId().intValue() > 0) {
/*  96 */       List subMenu = new ArrayList();
/*  97 */       temp = this.treeItemDao.getMenuById(temp.getParentId());
/*     */ 
/*  99 */       result.push(subMenu);
/*     */ 
/* 101 */       subMenu.add(temp);
/* 102 */       this.log.debug(Integer.valueOf(subMenu.hashCode()));
/* 103 */       if (!alllist.contains(String.valueOf(temp.getMenuItemId())))
/* 104 */         return stack2List(result);
/* 105 */       this.log.debug(Integer.valueOf(subMenu.size()));
/* 106 */       subMenu.addAll(getBreadSubSysMenuItems(userId, temp.getMenuItemId()));
/* 107 */       for (Iterator iter = subMenu.iterator(); iter.hasNext(); ) {
/* 108 */         TreeItem treeItem = (TreeItem)iter.next();
/* 109 */         if (!alllist.contains(String.valueOf(treeItem.getMenuItemId())))
/* 110 */           iter.remove();
/*     */       }
/* 112 */       this.log.debug(Integer.valueOf(subMenu.size()));
/*     */     }
/*     */ 
/* 115 */     result.push(getBreadSubSysMenuItems(userId, Integer.valueOf(0)));
/*     */ 
/* 117 */     return stack2List(result);
/*     */   }
/*     */ 
/*     */   private List<List<TreeItem>> stack2List(Stack<List<TreeItem>> stack)
/*     */   {
/* 126 */     List result = new ArrayList();
/* 127 */     while (!stack.isEmpty()) {
/* 128 */       result.add(stack.pop());
/*     */     }
/* 130 */     return result;
/*     */   }
/*     */ 
/*     */   public List<TreeItem> getTopSysMenuItems(String userId)
/*     */   {
/* 137 */     List alllist = getResourceIdListOfRight(userId, "50");
/* 138 */     List menus = this.treeItemDao.getTopSysMenuItems();
/* 139 */     List ret = new ArrayList();
/* 140 */     for (TreeItem menu : menus) {
/* 141 */       if (alllist.contains(String.valueOf(menu.getMenuItemId()))) {
/* 142 */         if ((menu.getUrl() != null) && (!"".equals(menu.getUrl().trim()))) {
/* 143 */           menu.setNodeTitle(menu.getMenuItemTitle() + "<label class='portal_tree_label'><input class='portal_btn_icon_favorites' title='加入收藏' type='button' value=' ' onclick='onSaveMenuToFavorites(" + menu.getMenuItemId() + ")'/></label>");
/*     */         }
/*     */         else
/*     */         {
/* 147 */           menu.setNodeTitle(menu.getMenuItemTitle());
/*     */         }
/* 149 */         ret.add(menu);
/*     */       }
/*     */     }
/*     */ 
/* 153 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<TreeItem> getSysMenuItems(String userId, Integer menuId)
/*     */   {
/* 160 */     List alllist = getResourceIdListOfRight(userId, "50");
/* 161 */     List menus = this.treeItemDao.getSubSysMenuItems(menuId, null);
/* 162 */     List ret = new ArrayList();
/* 163 */     for (TreeItem menu : menus) {
/* 164 */       if (alllist.contains(String.valueOf(menu.getMenuItemId()))) {
/* 165 */         if ((menu.getUrl() != null) && (!"".equals(menu.getUrl().trim()))) {
/* 166 */           menu.setNodeTitle(menu.getMenuItemTitle() + "<label class='portal_tree_label'><input class='portal_btn_icon_favorites' title='加入收藏' type='button' value=' ' onclick='onSaveMenuToFavorites(" + menu.getMenuItemId() + ")'/></label>");
/*     */         }
/*     */         else
/*     */         {
/* 170 */           menu.setNodeTitle(menu.getMenuItemTitle());
/*     */         }
/* 172 */         ret.add(menu);
/*     */       }
/*     */     }
/* 175 */     for (TreeItem child : ret) {
/* 176 */       getAllSubMenuItems(child, userId, null);
/*     */     }
/*     */ 
/* 179 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<TreeItem> getSysMenuItems(String userId)
/*     */   {
/* 186 */     List alllist = getResourceIdListOfRight(userId, "50");
/* 187 */     List menus = this.treeItemDao.getTopSysMenuItems();
/* 188 */     List ret = new ArrayList();
/* 189 */     for (TreeItem menu : menus) {
/* 190 */       if (alllist.contains(String.valueOf(menu.getMenuItemId()))) {
/* 191 */         if ((menu.getUrl() != null) && (!"".equals(menu.getUrl().trim()))) {
/* 192 */           menu.setNodeTitle(menu.getMenuItemTitle() + "<label class='portal_tree_label'><input class='portal_btn_icon_favorites' title='加入收藏' type='button' value=' ' onclick='onSaveMenuToFavorites(" + menu.getMenuItemId() + ")'/></label>");
/*     */         }
/*     */         else
/*     */         {
/* 196 */           menu.setNodeTitle(menu.getMenuItemTitle());
/*     */         }
/* 198 */         ret.add(menu);
/*     */       }
/*     */     }
/* 201 */     for (TreeItem child : ret) {
/* 202 */       getAllSubMenuItems(child, userId, null);
/*     */     }
/*     */ 
/* 205 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<TreeItem> getAllSysMenuItems(String userId, String keyword)
/*     */   {
/* 212 */     List alllist = getResourceIdListOfRight(userId, "50");
/* 213 */     List menus = this.treeItemDao.getAllSysMenuItems(keyword);
/* 214 */     List ret = new ArrayList();
/* 215 */     for (TreeItem menu : menus) {
/* 216 */       if (alllist.contains(String.valueOf(menu.getMenuItemId()))) {
/* 217 */         if ((menu.getUrl() != null) && (!"".equals(menu.getUrl().trim()))) {
/* 218 */           menu.setNodeTitle(menu.getMenuItemTitle() + "<label class='portal_tree_label'><input class='portal_btn_icon_favorites' title='加入收藏' type='button' value=' ' onclick='onSaveMenuToFavorites(" + menu.getMenuItemId() + ")'/></label>");
/*     */         }
/*     */         else
/*     */         {
/* 222 */           menu.setNodeTitle(menu.getMenuItemTitle());
/*     */         }
/* 224 */         ret.add(menu);
/*     */       }
/*     */     }
/* 227 */     return ret;
/*     */   }
/*     */ 
/*     */   private void getAllSubMenuItems(TreeItem menu, String userId, String keyword)
/*     */   {
/* 232 */     if (menu.getChildNum().intValue() > 0) {
/* 233 */       List children = getSubSysMenuItems(userId, menu.getMenuItemId(), keyword);
/* 234 */       menu.setChildren(children);
/* 235 */       for (TreeItem child : children)
/* 236 */         getAllSubMenuItems(child, userId, keyword);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<TreeItem> getSubSysMenuItems(String userId, Integer menuId, String keyword)
/*     */   {
/* 245 */     List alllist = getResourceIdListOfRight(userId, "50");
/* 246 */     List menus = this.treeItemDao.getSubSysMenuItems(menuId, keyword);
/* 247 */     List ret = new ArrayList();
/*     */ 
/* 249 */     for (TreeItem menu : menus) {
/* 250 */       if (alllist.contains(String.valueOf(menu.getMenuItemId()))) {
/* 251 */         if ((menu.getUrl() != null) && (!"".equals(menu.getUrl().trim()))) {
/* 252 */           menu.setNodeTitle(menu.getMenuItemTitle() + "<label class='portal_tree_label'><input class='portal_btn_icon_favorites' title='加入收藏' type='button' value=' ' onclick='onSaveMenuToFavorites(" + menu.getMenuItemId() + ")'/></label>");
/*     */         }
/*     */         else
/*     */         {
/* 256 */           menu.setNodeTitle(menu.getMenuItemTitle());
/*     */         }
/* 258 */         ret.add(menu);
/*     */       }
/*     */     }
/* 261 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<TreeItem> getRootSysMenuItems(String userId, Integer pId)
/*     */   {
/* 268 */     List alllist = getResourceIdListOfRight(userId, "50");
/* 269 */     List menus = this.treeItemDao.getSubSysMenuItems(pId, null);
/* 270 */     List ret = new ArrayList();
/* 271 */     for (TreeItem menu : menus) {
/* 272 */       if ((alllist.contains(String.valueOf(menu.getMenuItemId()))) && 
/* 273 */         (menu.getChildNum().intValue() > 0))
/*     */       {
/* 275 */         List tempList = this.treeItemDao.getSubSysMenuItems(menu.getMenuItemId(), null);
/* 276 */         menu.setNodeTitle("minus");
/* 277 */         for (TreeItem item : tempList) {
/* 278 */           if (item.getChildNum().intValue() > 0) {
/* 279 */             menu.setNodeTitle("plus");
/*     */           }
/*     */         }
/* 282 */         ret.add(menu);
/*     */       }
/*     */     }
/*     */ 
/* 286 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<TreeItem> getAllSysMenuItemsWithoutLeafAndPreservation(String userId, String keyword)
/*     */   {
/* 293 */     List alllist = getResourceIdListOfRight(userId, "50");
/* 294 */     List menus = this.treeItemDao.getAllSysMenuItems(keyword);
/* 295 */     List ret = new ArrayList();
/* 296 */     for (TreeItem menu : menus) {
/* 297 */       if ((alllist.contains(String.valueOf(menu.getMenuItemId()))) && (menu.getChildNum().intValue() > 0)) {
/* 298 */         menu.setNodeTitle(menu.getMenuItemTitle());
/* 299 */         ret.add(menu);
/*     */       }
/*     */     }
/* 302 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<TreeItem> getSysMenuItemsWithoutPreservation(String userId)
/*     */   {
/* 309 */     List alllist = getResourceIdListOfRight(userId, "50");
/* 310 */     List menus = this.treeItemDao.getTopSysMenuItems();
/* 311 */     List ret = new ArrayList();
/* 312 */     for (TreeItem menu : menus) {
/* 313 */       if (alllist.contains(String.valueOf(menu.getMenuItemId()))) {
/* 314 */         menu.setNodeTitle(menu.getMenuItemTitle());
/* 315 */         ret.add(menu);
/*     */       }
/*     */     }
/* 318 */     for (TreeItem child : ret) {
/* 319 */       getAllSubMenuItems(child, userId, null);
/*     */     }
/*     */ 
/* 322 */     return ret;
/*     */   }
/*     */ 
/*     */   public List getResourceIdListOfRight(String userId, String resourceType)
/*     */   {
/* 327 */     List resIdList = new ArrayList();
/*     */     try {
/* 329 */       IUserPrivilegeService privilegeService = (IUserPrivilegeService)SystemServiceLocator.getInstance().getService("userPrivilegeService");
/* 330 */       int roleType = 1;
/*     */ 
/* 332 */       if (resourceType.equals("5")) {
/* 333 */         roleType = 0;
/*     */       }
/* 335 */       List list = privilegeService.getRight(userId, roleType, Integer.parseInt(resourceType));
/* 336 */       resIdList = ListService.convertToNewList(list, "ResourceId");
/*     */     } catch (Exception e) {
/* 338 */       this.log.error("", e);
/* 339 */       throw new RuntimeException();
/*     */     }
/* 341 */     return resIdList;
/*     */   }
/*     */ 
/*     */   public ITreeItemDao getTreeItemDao() {
/* 345 */     return this.treeItemDao;
/*     */   }
/*     */ 
/*     */   public void setTreeItemDao(ITreeItemDao treeItemDao) {
/* 349 */     this.treeItemDao = treeItemDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.TreeItemServiceImpl
 * JD-Core Version:    0.6.2
 */
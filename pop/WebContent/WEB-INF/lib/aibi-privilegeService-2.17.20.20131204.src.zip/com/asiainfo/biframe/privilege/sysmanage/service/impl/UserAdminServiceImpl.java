/*      */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.exception.DaoException;
/*      */ import com.asiainfo.biframe.exception.ServiceException;
/*      */ import com.asiainfo.biframe.exception.ValidateException;
/*      */ import com.asiainfo.biframe.privilege.ICity;
/*      */ import com.asiainfo.biframe.privilege.IGroupRoleMap;
/*      */ import com.asiainfo.biframe.privilege.ISysResourceType;
/*      */ import com.asiainfo.biframe.privilege.IUser;
/*      */ import com.asiainfo.biframe.privilege.IUserCompany;
/*      */ import com.asiainfo.biframe.privilege.IUserDuty;
/*      */ import com.asiainfo.biframe.privilege.IUserGroup;
/*      */ import com.asiainfo.biframe.privilege.IUserRole;
/*      */ import com.asiainfo.biframe.privilege.base.util.BeanUtils;
/*      */ import com.asiainfo.biframe.privilege.base.util.DateConverter;
/*      */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*      */ import com.asiainfo.biframe.privilege.base.vo.ReturnMsg;
/*      */ import com.asiainfo.biframe.privilege.cache.object.SysResourceTypeCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCityCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCompanyCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserDutyCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserGroupDefineCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserRoleCache;
/*      */ import com.asiainfo.biframe.privilege.dutyMaintain.dao.IUserDutyDAO;
/*      */ import com.asiainfo.biframe.privilege.model.Prefer_Define;
/*      */ import com.asiainfo.biframe.privilege.model.SysResourceType;
/*      */ import com.asiainfo.biframe.privilege.model.UserExtInfo;
/*      */ import com.asiainfo.biframe.privilege.model.UserExtInfoDefine;
/*      */ import com.asiainfo.biframe.privilege.model.UserGroupMap;
/*      */ import com.asiainfo.biframe.privilege.model.UserRole;
/*      */ import com.asiainfo.biframe.privilege.model.UserRoleMap;
/*      */ import com.asiainfo.biframe.privilege.model.UserTempRight;
/*      */ import com.asiainfo.biframe.privilege.model.UserUserExt;
/*      */ import com.asiainfo.biframe.privilege.model.UserUserMap;
/*      */ import com.asiainfo.biframe.privilege.model.User_City;
/*      */ import com.asiainfo.biframe.privilege.model.User_Group;
/*      */ import com.asiainfo.biframe.privilege.model.User_Prefer;
/*      */ import com.asiainfo.biframe.privilege.model.User_User;
/*      */ import com.asiainfo.biframe.privilege.pwdpolicy.service.PwdPolicyService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.constants.UserConstants;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IBusiParametersDao;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IGroupRoleMapDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.ISysResourceTypeDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.ISysmanageJdbcDao;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserExtInfoDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserExtInfoDefineDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupMapDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleMapDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserExtDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserMapDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserPreferDefineDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserUserPreferDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.form.UserPreferForm;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.IAuthPolicy;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.LoginInfo;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.RoleRight;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCityService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCompanyService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*      */ import com.asiainfo.biframe.privilege.tempright.service.IUserTempRightService;
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.date.DateUtil;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.string.DES;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import org.apache.commons.beanutils.ConvertUtils;
/*      */ import org.apache.commons.collections.CollectionUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.apache.struts.util.LabelValueBean;
/*      */ 
/*      */ public class UserAdminServiceImpl
/*      */   implements IUserAdminService
/*      */ {
/*  123 */   private static final Logger logger = Logger.getLogger(UserAdminServiceImpl.class);
/*      */   private ISysmanageJdbcDao sysmanageJdbcDao;
/*      */   private IUserUserDAO userUserDao;
/*      */   private IUserUserExtDAO userUserExtDao;
/*      */   private IUserRoleDAO userRoleDao;
/*      */   private IUserGroupDAO userGroupDao;
/*      */   private IUserGroupMapDAO userGroupMapDao;
/*      */   private IGroupRoleMapDAO groupRoleMapDao;
/*      */   private IUserRoleMapDAO userRoleMapDao;
/*      */   private IUserUserMapDAO userUserMapDao;
/*      */   private ISysResourceTypeDAO sysResourceTypeDao;
/*      */   private IUserCityService userCityService;
/*      */   private IUserTempRightService userTempRightService;
/*      */   private IUserUserPreferDefineDAO userUserPreferDefineDao;
/*      */   private IUserUserUserPreferDAO userUserUserPreferDao;
/*      */   private IUserCompanyService userCompanyService;
/*      */   private IUserDutyDAO userDutyDao;
/*      */   private IUserGroupAdminService userGroupAdminService;
/*      */   private IRoleAdminService roleAdminService;
/*      */   private IUserExtInfoDAO userExtInfoDao;
/*      */   private IUserExtInfoDefineDAO userExtInfoDefineDao;
/*      */   private IBusiParametersDao iBusiParametersDao;
/*      */   private List policyList;
/*      */ 
/*      */   public void setiBusiParametersDao(IBusiParametersDao iBusiParametersDao)
/*      */   {
/*  171 */     this.iBusiParametersDao = iBusiParametersDao;
/*      */   }
/*      */ 
/*      */   public void setUserExtInfoDefineDao(IUserExtInfoDefineDAO userExtInfoDefineDao)
/*      */   {
/*  176 */     this.userExtInfoDefineDao = userExtInfoDefineDao;
/*      */   }
/*      */ 
/*      */   public void setUserExtInfoDao(IUserExtInfoDAO userExtInfoDao) {
/*  180 */     this.userExtInfoDao = userExtInfoDao;
/*      */   }
/*      */ 
/*      */   public List getPolicyList()
/*      */   {
/*  186 */     return this.policyList;
/*      */   }
/*      */ 
/*      */   public void setPolicyList(List policyList) {
/*  190 */     this.policyList = policyList;
/*      */   }
/*      */ 
/*      */   public User_User getUser(String userId)
/*      */   {
/*  195 */     logger.debug("in findUser");
/*  196 */     User_User user = this.userUserDao.findById(userId);
/*  197 */     return user;
/*      */   }
/*      */ 
/*      */   public void addUser(User_User user) {
/*  201 */     logger.debug("in addUser");
/*      */     try {
/*  203 */       if (user == null) {
/*  204 */         return;
/*      */       }
/*      */ 
/*  207 */       if (isUserExists(user.getUserid(), user.getUsername(), true)) {
/*  208 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userAlreadyExist"));
/*      */       }
/*      */ 
/*  214 */       user.setStatus(0);
/*  215 */       user.setCreatetime(Calendar.getInstance().getTime());
/*  216 */       if (StringUtils.isBlank(user.getDesPwd()))
/*  217 */         user.setPwd(DES.encrypt("asiainfo"));
/*      */       else {
/*  219 */         user.setPwd(DES.encrypt(user.getDesPwd()));
/*      */       }
/*      */ 
/*  223 */       List userCityList = new ArrayList();
/*  224 */       ListService.getCityList(user.getCityid(), userCityList);
/*  225 */       User_City uc = new User_City();
/*  226 */       uc.setCityId(user.getCityid());
/*  227 */       userCityList.add(uc);
/*  228 */       List roleRightList = new ArrayList();
/*  229 */       for (User_City city : userCityList) {
/*  230 */         Right right = new Right();
/*  231 */         right.setResourceId(city.getCityId());
/*  232 */         right.setResourceType(Integer.parseInt("5"));
/*      */ 
/*  234 */         right.setOperationType("-1");
/*  235 */         RoleRight roleRight = new RoleRight();
/*  236 */         roleRight.setRoleId(user.getUserid());
/*  237 */         roleRight.setControlType("0");
/*  238 */         roleRight.setOperatorType(1);
/*  239 */         roleRight.setRight(right);
/*  240 */         roleRightList.add(roleRight);
/*      */       }
/*  242 */       this.roleAdminService.saveRight(Integer.parseInt("5"), roleRightList);
/*      */ 
/*  246 */       this.userUserDao.save(user);
/*      */ 
/*  249 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), user.getUserid(), user.getUsername(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addUser") + "", null, user.toMap());
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  259 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addUserFail") + ":", e);
/*      */ 
/*  262 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addUserFail") + ":" + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateUser(User_User newUser)
/*      */   {
/*  275 */     ConvertUtils.register(new DateConverter(), Date.class);
/*  276 */     ConvertUtils.register(new DateConverter(), Timestamp.class);
/*  277 */     logger.debug("in updateUser");
/*      */     try {
/*  279 */       if (newUser == null) {
/*  280 */         return;
/*      */       }
/*      */ 
/*  283 */       if (isUserExists(newUser.getUserid(), newUser.getUsername(), false)) {
/*  284 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.name") + "[" + newUser.getUsername() + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.alreadyExist"));
/*      */       }
/*      */ 
/*  294 */       if (!StringUtils.isBlank(newUser.getDesPwd()))
/*      */       {
/*  299 */         newUser.setPwd(DES.encrypt(newUser.getDesPwd()));
/*      */       }
/*  301 */       logger.debug("********* userid:" + newUser.getUserid() + " pwd:" + newUser.getPwd());
/*      */ 
/*  304 */       User_User realUser = getUser(newUser.getUserid());
/*      */ 
/*  307 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), newUser.getUserid(), newUser.getUsername(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUser") + "", realUser.toMap(), newUser.toMap());
/*      */ 
/*  317 */       if (newUser.getDomainType() == null) newUser.setDomainType("-1");
/*  318 */       if (!newUser.getDomainType().equals(realUser.getDomainType())) {
/*  319 */         String realUserDomain = this.iBusiParametersDao.getParaName("1", realUser.getDomainType() == null ? "-1" : realUser.getDomainType());
/*  320 */         String newUserDomain = this.iBusiParametersDao.getParaName("1", newUser.getDomainType());
/*      */ 
/*  322 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), newUser.getUserid(), newUser.getUsername(), newUserDomain + "]", null, null);
/*      */       }
/*      */ 
/*  334 */       if (!newUser.getCityid().equals(realUser.getCityid()))
/*      */       {
/*  337 */         this.roleAdminService.deleteRight(newUser.getUserid() + "!!updateUser", 1, Integer.parseInt("5"), null);
/*      */ 
/*  340 */         List userCityList = new ArrayList();
/*  341 */         ListService.getCityList(newUser.getCityid(), userCityList);
/*  342 */         User_City uc = new User_City();
/*  343 */         uc.setCityId(newUser.getCityid());
/*  344 */         userCityList.add(uc);
/*  345 */         List roleRightList = new ArrayList();
/*  346 */         for (User_City city : userCityList) {
/*  347 */           Right right = new Right();
/*  348 */           right.setResourceId(city.getCityId());
/*  349 */           right.setResourceType(Integer.parseInt("5"));
/*      */ 
/*  351 */           right.setOperationType("-1");
/*  352 */           RoleRight roleRight = new RoleRight();
/*  353 */           roleRight.setRoleId(newUser.getUserid());
/*  354 */           roleRight.setControlType("0");
/*  355 */           roleRight.setOperatorType(1);
/*  356 */           roleRight.setRight(right);
/*  357 */           roleRightList.add(roleRight);
/*      */         }
/*  359 */         this.roleAdminService.saveRight(Integer.parseInt("5"), roleRightList);
/*      */       }
/*      */ 
/*  364 */       BeanUtils.copyProperties(realUser, newUser);
/*  365 */       this.userUserDao.update(realUser);
/*      */     } catch (Exception e) {
/*  367 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + ":" + e);
/*      */ 
/*  370 */       if ((e instanceof SysmanageException)) {
/*  371 */         throw ((SysmanageException)e);
/*      */       }
/*  373 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + "!");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteUser(User_User user)
/*      */   {
/*  380 */     logger.debug("in deleteUser");
/*      */     try {
/*  382 */       if (user == null) {
/*  383 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExist2") + "!");
/*      */       }
/*      */ 
/*  403 */       User_User realUser = getUser(user.getUserid());
/*  404 */       String userid = realUser.getUserid();
/*      */ 
/*  407 */       this.userRoleMapDao.deleteMapByUserId(userid);
/*      */ 
/*  409 */       this.userUserMapDao.deleteMapByUId(userid);
/*  410 */       this.userUserMapDao.deleteMappedByUId(userid);
/*      */ 
/*  413 */       this.roleAdminService.deleteRight(userid + "!!deleteUser", 1, Integer.parseInt("5"), null);
/*      */ 
/*  419 */       realUser.setStatus(Integer.valueOf("2").intValue());
/*  420 */       realUser.setDeleteTime(DateUtil.date2String(new Date(), "yyyy-MM-dd HH:mm:ss"));
/*      */ 
/*  422 */       this.userUserDao.update(realUser);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  432 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserFail") + ":" + e);
/*      */ 
/*  435 */       if ((e instanceof SysmanageException)) {
/*  436 */         throw ((SysmanageException)e);
/*      */       }
/*  438 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserFail") + "!");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void doRealDeleteUser(DeletedParameterVO paraObject)
/*      */     throws ServiceException
/*      */   {
/*      */     try
/*      */     {
/*  450 */       logger.debug(" in doRealDeleteUser");
/*      */ 
/*  452 */       this.userGroupMapDao.doRealDelete(paraObject);
/*      */ 
/*  455 */       this.userUserExtDao.doRealDelete(paraObject);
/*      */ 
/*  458 */       this.userRoleMapDao.delete(paraObject);
/*      */ 
/*  461 */       this.userTempRightService.deleteTempRights(paraObject);
/*      */ 
/*  464 */       this.userExtInfoDao.delete(paraObject);
/*      */ 
/*  467 */       Collection userIds = paraObject.getIds();
/*  468 */       Iterator it = userIds.iterator();
/*  469 */       while (it.hasNext()) {
/*  470 */         String userId = (String)it.next();
/*  471 */         this.userUserDao.backupUser(userId);
/*      */       }
/*      */ 
/*  475 */       String deletedUserNames = this.userUserDao.doRealDelete(paraObject);
/*      */ 
/*  478 */       PwdPolicyService.delPwdHistory(paraObject.getIdString());
/*      */ 
/*  480 */       String logResourceId = paraObject.getIdString();
/*  481 */       if (StringUtils.isBlank(logResourceId))
/*  482 */         logResourceId = "resourceId";
/*      */       else {
/*  484 */         logResourceId = StringUtil.replaceAll(logResourceId, "'", "");
/*      */       }
/*  486 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), logResourceId, deletedUserNames, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUser") + "", null, null);
/*      */ 
/*  494 */       logger.debug(" end doRealDeleteUser");
/*      */     } catch (DaoException e) {
/*  496 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserFail") + "", e);
/*      */ 
/*  499 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserFail") + "", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveUserExt(String userId, String param0)
/*      */     throws Exception
/*      */   {
/*  508 */     boolean flag = true;
/*      */ 
/*  510 */     if (userId.contains("!!")) {
/*  511 */       userId = userId.split("!!")[0];
/*  512 */       flag = false;
/*      */     }
/*  514 */     UserUserExt ext = new UserUserExt();
/*  515 */     ext.setUserid(userId);
/*  516 */     ext.setParam0(param0 == null ? "0" : param0);
/*  517 */     this.userUserExtDao.save(ext);
/*  518 */     if (flag)
/*  519 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER_EXT"), userId, getUserName(userId), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveUserExt") + "", null, ext.toMap());
/*      */   }
/*      */ 
/*      */   public void createUserExtInfo(String userId)
/*      */     throws Exception
/*      */   {
/*  539 */     List extInfoDefineList = this.userExtInfoDefineDao.findAll();
/*      */ 
/*  541 */     List extInfoList = new ArrayList();
/*  542 */     UserExtInfo extInfo = null;
/*  543 */     for (UserExtInfoDefine extInfoDefine : extInfoDefineList) {
/*  544 */       extInfo = new UserExtInfo(extInfoDefine.getExtId(), userId, extInfoDefine.getExtName(), "");
/*      */ 
/*  546 */       extInfoList.add(extInfo);
/*      */     }
/*  548 */     this.userExtInfoDao.saveOrUpdateAll(extInfoList);
/*      */   }
/*      */ 
/*      */   public void updateUserExt(UserUserExt newUserExt)
/*      */   {
/*  553 */     logger.debug("in updateUserExt");
/*      */ 
/*  555 */     boolean flag = true;
/*  556 */     String param5 = newUserExt.getParam5();
/*  557 */     if (param5.contains("!!"))
/*  558 */       flag = false;
/*      */     try
/*      */     {
/*  561 */       if (newUserExt == null) {
/*  562 */         return;
/*      */       }
/*  564 */       UserUserExt realUserExt = getUserExt(newUserExt.getUserid());
/*  565 */       if (flag) LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER_EXT"), newUserExt.getUserid(), getUserName(newUserExt.getUserid()), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserExt") + "", null, null);
/*      */ 
/*  573 */       BeanUtils.copyProperties(realUserExt, newUserExt);
/*  574 */       realUserExt.setParam0(realUserExt.getParam0() == null ? "0" : newUserExt.getParam0());
/*      */ 
/*  576 */       this.userUserExtDao.update(realUserExt);
/*      */     } catch (Exception e) {
/*  578 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserExtFail") + ":" + e);
/*      */ 
/*  581 */       if ((e instanceof SysmanageException)) {
/*  582 */         throw ((SysmanageException)e);
/*      */       }
/*  584 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserExtFail") + "!");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addUser(User_User user, String[] groupList, String deptId, String param0)
/*      */   {
/*      */     try
/*      */     {
/*  594 */       addUser(user);
/*  595 */       saveUserGroupMap(user.getUserid() + "!!addUser", groupList);
/*  596 */       saveUserExt(user.getUserid() + "!!addUser", param0);
/*  597 */       createUserExtInfo(user.getUserid());
/*  598 */       logger.debug("-------userUserExt " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveComplete") + "");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  602 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addUserFail") + ":", e);
/*      */ 
/*  605 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addUserFail") + ":" + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateUser(User_User user, String[] groupList, String deptId, String param0)
/*      */   {
/*      */     try
/*      */     {
/*  615 */       User_User orgUser = getUser(user.getUserid());
/*  616 */       String cityId = orgUser.getCityid();
/*      */ 
/*  618 */       updateUser(user);
/*      */ 
/*  620 */       saveUserGroupMap(user.getUserid() + "!!updateUser", groupList);
/*      */ 
/*  622 */       UserUserExt ext = this.userUserExtDao.findById(user.getUserid());
/*  623 */       if (ext == null) {
/*  624 */         saveUserExt(user.getUserid() + "!!updateUser", param0);
/*      */       } else {
/*  626 */         ext.setParam0(param0 == null ? "0" : param0);
/*  627 */         if (!cityId.equals(user.getCityid())) {
/*  628 */           ext.setParam7(null);
/*      */         }
/*  630 */         ext.setParam5("param5!!updateUser");
/*  631 */         updateUserExt(ext);
/*      */       }
/*      */     } catch (Exception e) {
/*  634 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + ":" + e);
/*      */ 
/*  637 */       if ((e instanceof SysmanageException)) {
/*  638 */         throw ((SysmanageException)e);
/*      */       }
/*  640 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + "!");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateUserPwd(User_User user, String param0)
/*      */   {
/*      */     try
/*      */     {
/*  648 */       String desPwd = user.getDesPwd();
/*  649 */       if ((param0 == null) || (param0.equals("0"))) {
/*  650 */         User_User realUser = getUser(user.getUserid());
/*  651 */         realUser.setPwd(DES.encrypt(desPwd));
/*  652 */         this.userUserDao.update(realUser);
/*      */ 
/*  654 */         savePwd2History(user.getUserid(), desPwd, "");
/*      */       }
/*      */ 
/*  657 */       UserUserExt ext = this.userUserExtDao.findById(user.getUserid());
/*  658 */       if (ext == null) {
/*  659 */         saveUserExt(user.getUserid(), param0);
/*      */       } else {
/*  661 */         ext.setParam0(param0 == null ? "0" : param0);
/*  662 */         updateUserExt(ext);
/*  663 */         logger.debug("getParam0:" + ext.getParam0() + "---" + ext.getParam1() + "---" + ext.getParam2() + "---" + ext.getParam3() + "---" + ext.getParam4() + "---" + ext.getParam5() + "---" + ext.getParam6() + "---" + ext.getParam7() + "---" + ext.getUserid());
/*      */       }
/*      */ 
/*  669 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), user.getUserid(), user.getUsername(), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyPwd"), null, null);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  677 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + ":" + e);
/*      */ 
/*  680 */       if ((e instanceof SysmanageException)) {
/*  681 */         throw ((SysmanageException)e);
/*      */       }
/*  683 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + "!");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateUserPwd(User_User user, String isRandomPwd, String operatorId)
/*      */   {
/*      */     try
/*      */     {
/*  696 */       String desPwd = user.getDesPwd();
/*  697 */       if ((isRandomPwd == null) || (isRandomPwd.equals("0"))) {
/*  698 */         User_User realUser = getUser(user.getUserid());
/*  699 */         realUser.setPwd(DES.encrypt(desPwd));
/*  700 */         this.userUserDao.update(realUser);
/*      */ 
/*  702 */         savePwd2History(user.getUserid(), desPwd, operatorId);
/*      */       } else {
/*  704 */         User_User realUser = getUser(user.getUserid());
/*  705 */         realUser.setPwd(desPwd + "!!isRandomPwd==1");
/*  706 */         this.userUserDao.update(realUser);
/*      */       }
/*      */ 
/*  709 */       UserUserExt ext = this.userUserExtDao.findById(user.getUserid());
/*  710 */       if (ext == null) {
/*  711 */         saveUserExt(user.getUserid(), isRandomPwd);
/*      */       } else {
/*  713 */         ext.setParam0(isRandomPwd == null ? "0" : isRandomPwd);
/*  714 */         ext.setParam5("param5!!updateUser");
/*  715 */         updateUserExt(ext);
/*      */       }
/*  717 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), user.getUserid(), user.getUsername(), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyPwd"), null, null);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  725 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + ":" + e);
/*      */ 
/*  728 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + "!");
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isUserLegal(String userid, String password)
/*      */   {
/*  737 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(userid);
/*  738 */     if (user == null)
/*  739 */       return false;
/*      */     try
/*      */     {
/*  742 */       password = DES.encrypt(password);
/*      */     } catch (Exception e) {
/*  744 */       logger.error("" + LocaleUtil.getLocaleMessage("isUserLegal", "privilegeService.java.exceptionOccur") + ":" + e);
/*      */     }
/*      */ 
/*  748 */     if (user.getPassword().equals(password)) {
/*  749 */       return true;
/*      */     }
/*  751 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isUserLocked(String userid) {
/*  755 */     User_User user = this.userUserDao.findById(userid);
/*  756 */     if (user == null) {
/*  757 */       return false;
/*      */     }
/*  759 */     if (user.getStatus() == Integer.valueOf("1").intValue()) {
/*  760 */       return true;
/*      */     }
/*  762 */     return false;
/*      */   }
/*      */ 
/*      */   public Map getPagedUserList(SearchCondition condition, Integer currpage, Integer pagesize)
/*      */   {
/*  767 */     Map map = new HashMap();
/*  768 */     map = this.userUserDao.getPagedUserList(condition, currpage.intValue(), pagesize.intValue());
/*      */ 
/*  770 */     Iterator iter = ((List)map.get("result")).iterator();
/*  771 */     List list = new ArrayList();
/*  772 */     while (iter.hasNext()) {
/*  773 */       User_User user = (User_User)iter.next();
/*  774 */       String currentUserid = user.getUserid();
/*  775 */       String cityId = user.getCityid();
/*  776 */       String depId = String.valueOf(user.getDepartmentid());
/*      */ 
/*  778 */       int dutyId = user.getDutyid() == null ? 0 : user.getDutyid().intValue();
/*      */ 
/*  780 */       User_Group group = getGroupObject(currentUserid);
/*  781 */       String groupName = "";
/*  782 */       String groupId = "";
/*  783 */       if (group == null) {
/*  784 */         groupName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */       }
/*      */       else
/*      */       {
/*  788 */         groupName = group.getGroupname();
/*  789 */         groupId = group.getGroupid();
/*      */       }
/*      */ 
/*  792 */       String depName = UserCompanyCache.getInstance().getNameByKey(depId);
/*  793 */       if (depName == null) {
/*  794 */         depName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */       }
/*      */ 
/*  799 */       String cityName = UserCityCache.getInstance().getNameByKey(cityId);
/*  800 */       if (cityName == null) {
/*  801 */         cityName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */       }
/*      */ 
/*  805 */       String dutyName = "";
/*  806 */       dutyName = UserDutyCache.getInstance().getNameByKey(String.valueOf(dutyId));
/*      */ 
/*  808 */       if (dutyName == null) {
/*  809 */         dutyName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */       }
/*      */ 
/*  814 */       String roleNames = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.haveAllRole") + "";
/*      */ 
/*  817 */       if (!groupId.equals("1"))
/*  818 */         roleNames = getAllRoleNames(currentUserid);
/*  819 */       user.setGroupName(groupName);
/*  820 */       user.setDepName(depName);
/*  821 */       user.setCityName(cityName);
/*  822 */       user.setDutyName(dutyName);
/*  823 */       user.setRoleNames(roleNames);
/*  824 */       user.setGroupId(groupId);
/*  825 */       list.add(user);
/*      */     }
/*  827 */     map.remove("result");
/*  828 */     map.put("result", list);
/*  829 */     return map;
/*      */   }
/*      */ 
/*      */   public List<User_User> getUserList(SearchCondition condition) {
/*  833 */     Iterator iter = this.userUserDao.findAll(condition).iterator();
/*  834 */     List list = new ArrayList();
/*  835 */     while (iter.hasNext()) {
/*  836 */       User_User user = (User_User)iter.next();
/*  837 */       String currentUserid = user.getUserid();
/*      */ 
/*  839 */       User_User cacheUser = (User_User)UserCache.getInstance().getObjectByKey(currentUserid);
/*      */ 
/*  841 */       String groupName = UserGroupDefineCache.getInstance().getNameByKey(cacheUser.getGroupId());
/*      */ 
/*  843 */       if (StringUtils.isBlank(groupName)) {
/*  844 */         groupName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */       }
/*      */ 
/*  849 */       String depId = String.valueOf(user.getDepartmentid());
/*  850 */       String depName = UserCompanyCache.getInstance().getNameByKey(depId);
/*  851 */       if (StringUtils.isBlank(depName)) {
/*  852 */         depName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */       }
/*      */ 
/*  857 */       String cityId = user.getCityid();
/*  858 */       String cityName = UserCityCache.getInstance().getNameByKey(cityId);
/*  859 */       if (StringUtils.isBlank(cityName)) {
/*  860 */         cityName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */       }
/*      */ 
/*  864 */       int dutyId = user.getDutyid() == null ? 0 : user.getDutyid().intValue();
/*      */ 
/*  866 */       String dutyName = UserDutyCache.getInstance().getNameByKey(String.valueOf(dutyId));
/*      */ 
/*  868 */       if (StringUtils.isBlank(dutyName)) {
/*  869 */         dutyName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */       }
/*      */ 
/*  874 */       user.setGroupName(groupName);
/*  875 */       user.setDepName(depName);
/*  876 */       user.setCityName(cityName);
/*  877 */       user.setDutyName(dutyName);
/*  878 */       list.add(user);
/*      */     }
/*  880 */     return list;
/*      */   }
/*      */ 
/*      */   public List<User_User> getUserListByName(String userName)
/*      */   {
/*  887 */     return this.userUserDao.findByName(userName);
/*      */   }
/*      */ 
/*      */   public String getDmCity(String userId, String resourceId, String dmType, String dbType, boolean isShow)
/*      */   {
/*  896 */     logger.debug(" in getDmCity");
/*      */ 
/*  898 */     List cityRightList = getRight(userId, 0, Integer.valueOf("5").intValue(), false);
/*      */ 
/*  903 */     Set dmValueSet = new HashSet();
/*  904 */     for (Right right : cityRightList) {
/*  905 */       String dmValue = getUserCityService().getDmCity(right.getResourceId().trim(), resourceId, dmType, dbType, isShow);
/*      */ 
/*  908 */       if (!StringUtils.isBlank(dmValue))
/*      */       {
/*  911 */         dmValueSet.add(dmValue);
/*      */       }
/*      */     }
/*  913 */     logger.debug("--cityRightList.size:" + cityRightList.size());
/*  914 */     logger.debug("--dmValueSet.size:" + dmValueSet.size());
/*  915 */     return StringUtils.join(dmValueSet.iterator(), ",").toString();
/*      */   }
/*      */ 
/*      */   public String getUserName(String userid) {
/*  919 */     User_User user = getUser(userid);
/*  920 */     if (user == null) {
/*  921 */       return "";
/*      */     }
/*  923 */     return user.getUsername();
/*      */   }
/*      */ 
/*      */   public String getUserId(String userName) {
/*  927 */     SearchCondition condition = new SearchCondition();
/*  928 */     if ((userName == null) || (userName.trim().length() == 0)) {
/*  929 */       return "";
/*      */     }
/*  931 */     condition.setQueryUsername(userName);
/*  932 */     List list = this.userUserDao.findAll(condition);
/*  933 */     if ((list.size() < 0) || (list.size() > 1)) {
/*  934 */       logger.warn("get userId from userName exception ...");
/*  935 */       return null;
/*      */     }
/*  937 */     User_User user = (User_User)list.get(0);
/*  938 */     return user.getUserid();
/*      */   }
/*      */ 
/*      */   public String getUserCity(String userid) {
/*  942 */     User_User user = getUser(userid);
/*  943 */     if (user == null) {
/*  944 */       return "";
/*      */     }
/*  946 */     return user.getCityid();
/*      */   }
/*      */ 
/*      */   public String getUserCityByCache(String userid) {
/*  950 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(userid);
/*  951 */     if (user == null) {
/*  952 */       return "";
/*      */     }
/*  954 */     return user.getCityid();
/*      */   }
/*      */   public String getUserCurrentCity(String userid) {
/*  957 */     String cityId = "";
/*  958 */     UserUserExt ext = getUserExt(userid);
/*  959 */     if (ext == null) {
/*  960 */       return getUserCity(userid);
/*      */     }
/*  962 */     cityId = ext.getParam7();
/*  963 */     if ((cityId == null) || (cityId.trim().length() == 0)) {
/*  964 */       return getUserCityByCache(userid);
/*      */     }
/*  966 */     return cityId;
/*      */   }
/*      */ 
/*      */   public int getUserDept(String userid) {
/*  970 */     User_User user = getUser(userid);
/*  971 */     if (user == null) {
/*  972 */       return -1;
/*      */     }
/*  974 */     return user.getDepartmentid();
/*      */   }
/*      */ 
/*      */   public String getUserDmCity(String userId, String dmType)
/*      */   {
/*  982 */     String cityid = getUserCity(userId);
/*  983 */     if (StringUtils.isBlank(cityid)) {
/*  984 */       return "";
/*      */     }
/*  986 */     return getUserCityService().getDmCity(cityid, dmType);
/*      */   }
/*      */ 
/*      */   public String getUserMobile(String userid) {
/*  990 */     User_User user = getUser(userid);
/*  991 */     if (user == null) {
/*  992 */       return "";
/*      */     }
/*  994 */     return user.getMobilephone();
/*      */   }
/*      */ 
/*      */   public UserUserExt getUserExt(String userid) {
/*  998 */     return this.userUserExtDao.findById(userid);
/*      */   }
/*      */ 
/*      */   public List<UserRole> getRolesByUserId(String userId)
/*      */   {
/* 1005 */     if (isAdminUser(userId))
/*      */     {
/* 1007 */       Collection allRoles = UserRoleCache.getInstance().getAllRolesSortedByName();
/* 1008 */       if (allRoles != null) {
/* 1009 */         List allRolesList = new ArrayList();
/* 1010 */         for (UserRole userRole : allRoles) {
/* 1011 */           allRolesList.add(userRole);
/*      */         }
/* 1013 */         return allRolesList;
/*      */       }
/*      */ 
/* 1016 */       return this.userRoleDao.findAllRoles();
/*      */     }
/*      */ 
/* 1020 */     return this.userRoleMapDao.getRolesByUserId(userId);
/*      */   }
/*      */ 
/*      */   public String getMapRoleIds(String userid) {
/* 1024 */     List roleList = getRolesByUserId(userid);
/* 1025 */     List roleIdList = new ArrayList();
/*      */     try {
/* 1027 */       roleIdList = ListService.convertToNewList(roleList, "RoleId");
/*      */     } catch (Exception e) {
/* 1029 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserRoleFail") + ":" + e);
/*      */ 
/* 1032 */       if ((e instanceof SysmanageException)) {
/* 1033 */         throw ((SysmanageException)e);
/*      */       }
/* 1035 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserRoleFail") + "!");
/*      */     }
/*      */ 
/* 1039 */     String roleIds = StringUtil.list2String(roleIdList, ",", false);
/* 1040 */     logger.debug("roleIds=[" + roleIds + "]");
/* 1041 */     return roleIds;
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getMapRoleBeans(String userid) {
/* 1045 */     List list = getRolesByUserId(userid);
/* 1046 */     List returnList = new ArrayList();
/* 1047 */     for (int i = 0; i < list.size(); i++) {
/* 1048 */       UserRole role = (UserRole)list.get(i);
/* 1049 */       returnList.add(new LabelValueBean(role.getRoleName(), role.getRoleId()));
/*      */     }
/*      */ 
/* 1052 */     return returnList;
/*      */   }
/*      */ 
/*      */   public List<UserRole> getAllRoles(String userId) {
/* 1056 */     logger.debug("in getAllRoles");
/* 1057 */     if (isAdminUser(userId))
/*      */     {
/* 1059 */       Collection allRoles = UserRoleCache.getInstance().getAllRolesSortedByName();
/* 1060 */       if (allRoles != null) {
/* 1061 */         List allRolesList = new ArrayList();
/* 1062 */         for (UserRole userRole : allRoles) {
/* 1063 */           allRolesList.add(userRole);
/*      */         }
/* 1065 */         return allRolesList;
/*      */       }
/*      */ 
/* 1068 */       return this.userRoleDao.findAllRoles();
/*      */     }
/*      */ 
/* 1073 */     List roleListByGroup = getRolesByGroupId(getGroup(userId));
/*      */ 
/* 1076 */     List roleListByUser = getRolesByUserId(userId);
/*      */ 
/* 1079 */     List list = StringUtil.getDistinctList(new List[] { roleListByGroup, roleListByUser });
/*      */ 
/* 1081 */     logger.debug("----------last role size=" + list.size());
/* 1082 */     logger.debug("end getAllRoles");
/* 1083 */     return list;
/*      */   }
/*      */ 
/*      */   private List<UserRole> getRolesByGroupId(String groupId)
/*      */   {
/* 1088 */     return this.groupRoleMapDao.findRoleListByGroupId(groupId);
/*      */   }
/*      */ 
/*      */   public String getAllRoleNames(String userid) {
/* 1092 */     List roleList = getAllRoles(userid);
/* 1093 */     if ((roleList == null) || (roleList.size() == 0)) {
/* 1094 */       return "";
/*      */     }
/*      */ 
/* 1097 */     String roleNames = "";
/* 1098 */     for (int i = 0; i < roleList.size(); i++) {
/* 1099 */       roleNames = roleNames + ((UserRole)roleList.get(i)).getRoleName() + ",";
/*      */     }
/* 1101 */     if (roleNames.trim().length() > 0) {
/* 1102 */       roleNames = roleNames.substring(0, roleNames.length() - 1);
/*      */     }
/*      */ 
/* 1105 */     return roleNames;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public List<UserRole> getAllRoles(String userId, int roleType, int resourceType)
/*      */   {
/* 1115 */     List allRoleList = getAllRoles(userId);
/*      */ 
/* 1117 */     return getRoleAdminService().filterRoleByType(allRoleList, roleType, resourceType);
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getAllRoleBeans(String userid)
/*      */   {
/* 1123 */     List list = getAllRoles(userid);
/* 1124 */     logger.debug("----------list.size=" + list.size() + ",list=" + list);
/* 1125 */     List returnList = new ArrayList();
/* 1126 */     for (int i = 0; i < list.size(); i++) {
/* 1127 */       UserRole role = (UserRole)list.get(i);
/* 1128 */       returnList.add(new LabelValueBean(role.getRoleName(), role.getRoleId()));
/*      */     }
/*      */ 
/* 1131 */     return returnList;
/*      */   }
/*      */ 
/*      */   public String getGroup(String userid) {
/*      */     try {
/* 1136 */       User_Group group = getGroupObject(userid);
/* 1137 */       if (group == null) {
/* 1138 */         return null;
/*      */       }
/* 1140 */       return group.getGroupid();
/*      */     } catch (Exception e) {
/* 1142 */       logger.error("" + LocaleUtil.getLocaleMessage("getGroup", "privilegeService.java.exceptionOccur") + ":" + e);
/*      */     }
/*      */ 
/* 1145 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserGroupFail"));
/*      */   }
/*      */ 
/*      */   public User_Group getGroupObject(String userid)
/*      */   {
/*      */     try
/*      */     {
/* 1153 */       List list = this.userGroupMapDao.getGroupByUserId(userid);
/* 1154 */       if ((list != null) && (list.size() > 0)) {
/* 1155 */         return (User_Group)list.get(0);
/*      */       }
/* 1157 */       return null;
/*      */     } catch (Exception e) {
/* 1159 */       logger.error("" + LocaleUtil.getLocaleMessage("getGroupObject", "privilegeService.java.exceptionOccur") + ":" + e);
/*      */     }
/*      */ 
/* 1162 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserGroupFail"));
/*      */   }
/*      */ 
/*      */   public boolean isSysUser(String userid)
/*      */   {
/* 1169 */     return this.userUserDao.isSysUser(userid);
/*      */   }
/*      */ 
/*      */   public boolean isAdminUser(String userid) {
/* 1173 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(userid);
/* 1174 */     if (user == null) {
/* 1175 */       return false;
/*      */     }
/* 1177 */     String groupid = user.getGroupId();
/* 1178 */     if ((groupid != null) && (groupid.equals("1"))) {
/* 1179 */       return true;
/*      */     }
/* 1181 */     return false;
/*      */   }
/*      */ 
/*      */   public List<User_User> getUsersOfDepartment(int departmentid)
/*      */   {
/* 1196 */     SearchCondition condition = new SearchCondition();
/* 1197 */     condition.setQueryDepartmentid(departmentid);
/* 1198 */     condition.setQueryStatus(Integer.valueOf("0").intValue());
/* 1199 */     return this.userUserDao.findAll(condition);
/*      */   }
/*      */   public List<User_User> getUsersOfDepartmentByCache(int departmentid) {
/* 1202 */     List findUsersList = new ArrayList();
/* 1203 */     Collection usersList = UserCache.getInstance().getAllCachedSortedObject();
/* 1204 */     for (User_User user : usersList) {
/* 1205 */       if ((departmentid == user.getDepartmentid()) && (Integer.valueOf("0").intValue() == user.getStatus())) {
/* 1206 */         findUsersList.add(user);
/*      */       }
/*      */     }
/* 1209 */     return findUsersList;
/*      */   }
/*      */ 
/*      */   public List<User_User> getUsersOfCity(String cityid) {
/* 1213 */     SearchCondition condition = new SearchCondition();
/* 1214 */     if ((cityid == null) || (cityid.trim().length() == 0)) {
/* 1215 */       return new ArrayList();
/*      */     }
/* 1217 */     condition.setQueryCityid(cityid);
/* 1218 */     condition.setQueryStatus(Integer.valueOf("0").intValue());
/* 1219 */     return this.userUserDao.findAll(condition);
/*      */   }
/*      */ 
/*      */   public boolean isUserExists(String userid, String username, boolean newUser) {
/* 1223 */     logger.debug("*************newUser=" + newUser + ", userid=[" + userid + "]");
/*      */ 
/* 1225 */     if ((newUser) && 
/* 1226 */       (this.userUserDao.findById(userid) != null)) {
/* 1227 */       return true;
/*      */     }
/*      */ 
/* 1249 */     return false;
/*      */   }
/*      */ 
/*      */   public ReturnMsg canLogin(HttpServletRequest request)
/*      */   {
/* 1254 */     logger.debug("policyList.size=" + this.policyList.size());
/* 1255 */     if ((this.policyList != null) && (this.policyList.size() > 0))
/*      */     {
/* 1258 */       LoginInfo info = new LoginInfo();
/* 1259 */       info.setUserId(request.getParameter("Username"));
/* 1260 */       info.setClientIp(request.getRemoteAddr());
/* 1261 */       info.setUserPwd(request.getParameter("Password"));
/*      */ 
/* 1263 */       for (int i = 0; i < this.policyList.size(); i++) {
/* 1264 */         IAuthPolicy ap = (IAuthPolicy)this.policyList.get(i);
/*      */         try {
/* 1266 */           ReturnMsg rtnMsg = ap.execute(info);
/* 1267 */           if (rtnMsg == null) {
/* 1268 */             return new ReturnMsg(false, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.validateError"));
/*      */           }
/*      */ 
/* 1272 */           if (!rtnMsg.isResult())
/* 1273 */             return rtnMsg;
/*      */         }
/*      */         catch (Exception e) {
/* 1276 */           logger.error("" + LocaleUtil.getLocaleMessage("canLogin", "privilegeService.java.exceptionOccur") + ":" + e);
/*      */ 
/* 1279 */           return new ReturnMsg(false, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getPolicyFail") + "!");
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1285 */     return new ReturnMsg(true, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.validatePass"));
/*      */   }
/*      */ 
/*      */   public List<User_Group> getAuthGroupList(String loginUserid, String toUserId)
/*      */   {
/* 1298 */     String fromGroupId = getGroup(loginUserid);
/* 1299 */     String toGroupId = getGroup(toUserId);
/*      */ 
/* 1301 */     List excludeIdList = new ArrayList();
/* 1302 */     excludeIdList.add(toGroupId);
/*      */ 
/* 1304 */     List allGroup = new ArrayList();
/* 1305 */     allGroup = getGroupList(fromGroupId, toGroupId, allGroup, excludeIdList);
/* 1306 */     return allGroup;
/*      */   }
/*      */ 
/*      */   public List<User_Group> getGroupList(String parentGroupId, String groupId, List<User_Group> groupList, List<String> excludeIdList)
/*      */   {
/* 1320 */     User_Group parentGroup = this.userGroupDao.findById(parentGroupId);
/* 1321 */     User_Group group = this.userGroupDao.findById(groupId);
/* 1322 */     logger.debug("******groupId:" + groupId + " parentid:" + parentGroupId);
/* 1323 */     if (!excludeIdList.contains(groupId))
/* 1324 */       groupList.add(group);
/* 1325 */     if (!group.getParentid().equals(parentGroupId)) {
/* 1326 */       getGroupList(parentGroupId, group.getParentid(), groupList, excludeIdList);
/*      */     }
/* 1329 */     else if (!excludeIdList.contains(parentGroupId)) {
/* 1330 */       groupList.add(parentGroup);
/*      */     }
/* 1332 */     return groupList;
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getAuthRoleBeans(String loginUserid, String toUserId)
/*      */   {
/* 1337 */     List groupList = getAuthGroupList(loginUserid, toUserId);
/* 1338 */     List returnList = new ArrayList();
/* 1339 */     Collection coll = getUserGroupAdminService().getAllUserRoles(groupList);
/*      */ 
/* 1341 */     logger.debug("coll.size=" + coll.size());
/* 1342 */     for (UserRole role : coll) {
/* 1343 */       returnList.add(new LabelValueBean(role.getRoleName(), role.getRoleId()));
/*      */     }
/*      */ 
/* 1346 */     return returnList;
/*      */   }
/*      */ 
/*      */   public List<LabelValueBean> getNotHaveRoleBeans(String fromUser, String toUser)
/*      */   {
/* 1351 */     logger.debug("from user=" + fromUser + ",toUser=" + toUser);
/*      */ 
/* 1354 */     List allRoleList = getAuthRoleBeans(fromUser, toUser);
/* 1355 */     logger.debug("allRoleList.size=" + allRoleList.size());
/* 1356 */     List haveRoleList = getAllRoleBeans(toUser);
/* 1357 */     allRoleList.removeAll(haveRoleList);
/* 1358 */     return allRoleList;
/*      */   }
/*      */ 
/*      */   public void saveUserRoleMap(String userId, List<String> addedRoleIdList, List<String> deletedRoleIdList)
/*      */   {
/* 1368 */     logger.debug("saveUserRoleMap...... ");
/*      */ 
/* 1370 */     String userName = getUserName(userId);
/*      */     try {
/* 1372 */       if (StringUtils.isBlank(userId)) {
/* 1373 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.user") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.isEmpty") + "");
/*      */       }
/*      */ 
/* 1381 */       StringBuffer deletedRoleIds = new StringBuffer(256);
/* 1382 */       if (deletedRoleIdList != null) {
/* 1383 */         for (int i = 0; i < deletedRoleIdList.size(); i++) {
/* 1384 */           UserRoleMap userRoleMap = new UserRoleMap(userId, (String)deletedRoleIdList.get(i));
/*      */ 
/* 1386 */           this.userRoleMapDao.delete(userRoleMap);
/* 1387 */           deletedRoleIds.append((String)deletedRoleIdList.get(i)).append(",");
/*      */         }
/*      */       }
/*      */ 
/* 1391 */       StringBuffer addedRoleIds = new StringBuffer(256);
/* 1392 */       if (addedRoleIdList != null) {
/* 1393 */         for (int i = 0; i < addedRoleIdList.size(); i++) {
/* 1394 */           String roleId = (String)addedRoleIdList.get(i);
/*      */ 
/* 1412 */           UserRoleMap userRoleMap = new UserRoleMap(userId, roleId);
/* 1413 */           this.userRoleMapDao.save(userRoleMap);
/* 1414 */           addedRoleIds.append(roleId).append(",");
/*      */         }
/*      */       }
/*      */ 
/* 1418 */       if (CollectionUtils.isNotEmpty(deletedRoleIdList)) {
/* 1419 */         UserRoleMap deletedUserRoleMap = new UserRoleMap(userId, deletedRoleIds.toString());
/*      */ 
/* 1421 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), userId, getUserName(userId), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrDeleteRoleUserMap") + "", null, deletedUserRoleMap.toMap());
/*      */       }
/*      */ 
/* 1430 */       if (CollectionUtils.isNotEmpty(addedRoleIdList)) {
/* 1431 */         UserRoleMap addedUserRoleMap = new UserRoleMap(userId, addedRoleIds.toString());
/*      */ 
/* 1433 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), userId, getUserName(userId), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrSaveUserRoleMap") + "", null, addedUserRoleMap.toMap());
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1445 */       logger.error("saveUserRoleMap " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 1448 */       throw new SysmanageException("" + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveUserGroupMap(String userId, String[] groupList)
/*      */   {
/* 1457 */     logger.debug("saveUserGroupMap...... ");
/*      */ 
/* 1459 */     boolean flag = true;
/*      */ 
/* 1461 */     if (userId.contains("!!")) {
/* 1462 */       userId = userId.split("!!")[0];
/* 1463 */       flag = false;
/*      */     }
/*      */     try {
/* 1466 */       if ((userId == null) || (userId.trim().length() == 0)) {
/* 1467 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.user") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.isEmpty") + "");
/*      */       }
/*      */ 
/* 1474 */       if ((groupList == null) || (groupList.length == 0)) {
/* 1475 */         return;
/*      */       }
/* 1477 */       logger.debug("groupList.size=" + groupList.length);
/* 1478 */       this.userGroupMapDao.deleteMapByUserId(userId);
/*      */ 
/* 1480 */       StringBuffer groupIds = new StringBuffer(256);
/* 1481 */       for (int i = 0; i < groupList.length; i++) {
/* 1482 */         UserGroupMap userGroupMap = new UserGroupMap(userId, groupList[i]);
/*      */ 
/* 1484 */         this.userGroupMapDao.save(userGroupMap);
/* 1485 */         groupIds.append(groupList[i]).append(",");
/*      */       }
/*      */ 
/* 1488 */       UserGroupMap userGroupMap = new UserGroupMap(userId, groupIds.toString());
/*      */ 
/* 1490 */       if (flag) {
/* 1491 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), userId, getUserName(userId), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserGroupRelation") + "", null, userGroupMap.toMap());
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1502 */       logger.error("saveUserGroupMap " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 1505 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveUserGroupMapFail") + ":" + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<User_Group> getAllSubGroupByCache(String userId)
/*      */   {
/*      */     try
/*      */     {
/* 1517 */       logger.debug(" in getAllSubGroupByCache");
/* 1518 */       String groupId = getGroup(userId);
/* 1519 */       List groupList = getUserGroupAdminService().getAllSubGroupByCache(groupId);
/*      */ 
/* 1521 */       logger.debug(" end getAllSubGroupByCache");
/* 1522 */       return groupList;
/*      */     } catch (Exception e) {
/* 1524 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllSubGroupFail") + ":", e);
/*      */ 
/* 1527 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryAllSubGroupFail") + ":" + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<User_User> getSubUsersByUserid(String userid)
/*      */   {
/* 1535 */     if (isAdminUser(userid)) {
/* 1536 */       return this.userUserDao.findAll(new SearchCondition());
/*      */     }
/* 1538 */     return getUserGroupAdminService().getAllSubUsersByGroupId(getGroup(userid));
/*      */   }
/*      */ 
/*      */   public List<User_User> getSubUsersByUseridByCache(String userid)
/*      */   {
/* 1547 */     Collection allUserList = UserCache.getInstance().getAllCachedObject();
/*      */ 
/* 1549 */     List userList = new ArrayList();
/* 1550 */     if (isAdminUser(userid)) {
/* 1551 */       CollectionUtils.addAll(userList, allUserList.iterator());
/* 1552 */       return userList;
/*      */     }
/*      */ 
/* 1555 */     User_User currentUser = (User_User)UserCache.getInstance().getObjectByKey(userid);
/*      */ 
/* 1557 */     User_Group currentGroup = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(currentUser.getGroupId());
/*      */ 
/* 1559 */     for (User_User user : allUserList) {
/* 1560 */       User_Group group = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(user.getGroupId());
/*      */ 
/* 1562 */       if (group != null)
/*      */       {
/* 1565 */         if (group.getAllParentId().contains(currentGroup.getGroupid()))
/* 1566 */           userList.add(user);
/*      */       }
/*      */     }
/* 1569 */     return userList;
/*      */   }
/*      */ 
/*      */   public List<Right> getRight(String userId, int roleType, int resourceType, boolean isDistinctControlType)
/*      */   {
/* 1579 */     logger.debug("in getRight");
/*      */     try
/*      */     {
/* 1582 */       if (isAdminUser(userId)) {
/* 1583 */         logger.debug("is adminUser");
/* 1584 */         return getRoleAdminService().getAllRights(roleType, resourceType);
/*      */       }
/*      */ 
/* 1589 */       List roleList = getAllRoles(userId);
/* 1590 */       List roleIdList = ListService.convertToNewList(roleList, "RoleId");
/*      */ 
/* 1592 */       List rightList = getRoleAdminService().getRightsByRoleIdList(roleIdList, roleType, resourceType, isDistinctControlType);
/*      */ 
/* 1597 */       Collection tempRightList = getUserTempRightService().getCurrentTempRights(userId, new Date(), resourceType);
/*      */ 
/* 1599 */       rightList.addAll(tempRightList);
/*      */ 
/* 1603 */       if (resourceType == Integer.parseInt("5"))
/*      */       {
/* 1606 */         String centerId = Configure.getInstance().getProperty("CENTER_CITYID");
/*      */ 
/* 1608 */         boolean centerCityFlag = false;
/*      */ 
/* 1611 */         Map map = new HashMap();
/* 1612 */         for (Right right : rightList) {
/* 1613 */           if (right.getResourceId().equals(centerId)) {
/* 1614 */             centerCityFlag = true;
/* 1615 */             break;
/*      */           }
/* 1617 */           map.put(right.getResourceId(), right);
/*      */         }
/*      */ 
/* 1621 */         if (!centerCityFlag) {
/* 1622 */           List cityRightList = getUserRightList(userId, resourceType, roleType, false);
/*      */ 
/* 1624 */           if ((null == cityRightList) || (cityRightList.size() <= 0)) {
/* 1625 */             return rightList;
/*      */           }
/* 1627 */           for (Right right : cityRightList) {
/* 1628 */             if (right.getResourceId().equals(centerId)) {
/* 1629 */               centerCityFlag = true;
/* 1630 */               break;
/*      */             }
/* 1632 */             if (null == map.get(right.getResourceId())) {
/* 1633 */               rightList.add(right);
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/* 1638 */         if (centerCityFlag == true) {
/* 1639 */           return getRoleAdminService().getAllRights(roleType, resourceType);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1644 */       logger.debug("end getRight");
/* 1645 */       return rightList;
/*      */     } catch (Exception e) {
/* 1647 */       logger.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 1650 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + userId);
/*      */   }
/*      */ 
/*      */   public List<Right> getAllRight(String userId)
/*      */   {
/* 1657 */     List allRightList = new ArrayList();
/*      */ 
/* 1659 */     List allSysResType = getSysResourceTypeDao().findAll();
/*      */ 
/* 1661 */     boolean isAdminUser = isAdminUser(userId);
/*      */ 
/* 1663 */     for (SysResourceType sysResType : allSysResType) {
/* 1664 */       List rightList = new ArrayList();
/*      */ 
/* 1666 */       if (isAdminUser) {
/* 1667 */         rightList = getRoleAdminService().getAllRights(sysResType.getRoleType(), sysResType.getResourceType());
/*      */       }
/*      */       else {
/* 1670 */         rightList = getRight(userId, sysResType.getRoleType(), sysResType.getResourceType(), false);
/*      */       }
/*      */ 
/* 1674 */       allRightList.addAll(rightList);
/*      */     }
/* 1676 */     return allRightList;
/*      */   }
/*      */ 
/*      */   public boolean haveRight(String userid, int roleType, int resourceType, String resourceId)
/*      */   {
/*      */     try
/*      */     {
/* 1683 */       List resourceIdList = ListService.convertToNewList(getRight(userid, roleType, resourceType, false), "ResourceId");
/*      */ 
/* 1686 */       if ((resourceIdList == null) || (resourceIdList.size() == 0)) {
/* 1687 */         return false;
/*      */       }
/*      */ 
/* 1691 */       if (2 == roleType)
/*      */       {
/* 1693 */         SysResourceType resType = SysResourceTypeCache.getInstance().getSysResourceType(roleType, resourceType);
/*      */ 
/* 1695 */         if (StringUtils.isBlank(resType.getRoleRightTable())) {
/* 1696 */           resourceIdList = ListService.getFields(resourceIdList, true, "operationid", "operationKey", "user_operation_define");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1701 */       return resourceIdList.contains(resourceId);
/*      */     } catch (Exception e) {
/* 1703 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.judgeUserAuthFail") + "", e);
/*      */     }
/*      */ 
/* 1706 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserGroupFail") + ":" + userid);
/*      */   }
/*      */ 
/*      */   public boolean haveRight(String userId, Right right)
/*      */   {
/* 1717 */     List rightList = getRight(userId, right.getRoleType(), right.getResourceType(), false);
/*      */ 
/* 1719 */     if (rightList.contains(right)) {
/* 1720 */       return true;
/*      */     }
/* 1722 */     return false;
/*      */   }
/*      */ 
/*      */   public List<User_User> getByUserIds(List<String> list) {
/* 1726 */     List result = new ArrayList();
/* 1727 */     if ((list == null) || (list.size() == 0)) {
/* 1728 */       return result;
/*      */     }
/* 1730 */     for (int i = 0; i < list.size(); i++) {
/* 1731 */       result.add((User_User)UserCache.getInstance().getObjectByKey(list.get(i)));
/*      */     }
/* 1733 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean haveSubGroup(String userid)
/*      */   {
/* 1741 */     if (isAdminUser(userid)) {
/* 1742 */       return true;
/*      */     }
/* 1744 */     String groupid = getGroup(userid);
/* 1745 */     if ((groupid == null) || (groupid.trim().length() == 0)) {
/* 1746 */       throw new SysmanageException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserGroupFail"));
/*      */     }
/*      */ 
/* 1749 */     List list = getUserGroupAdminService().getAllSubGroup(groupid);
/* 1750 */     if ((list == null) || (list.size() == 0)) {
/* 1751 */       return false;
/*      */     }
/* 1753 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean isPwdRepeated(String userid, String newPwd) {
/* 1757 */     return PwdPolicyService.isPwdRepeated(userid, newPwd);
/*      */   }
/*      */ 
/*      */   public int savePwd2History(String userid, String pwd, String operatorId)
/*      */   {
/* 1765 */     return PwdPolicyService.savePwd2History(userid, pwd, operatorId);
/*      */   }
/*      */ 
/*      */   public int savePwd2History(String userId, String pwd)
/*      */   {
/* 1773 */     return PwdPolicyService.savePwd2History(userId, pwd, userId);
/*      */   }
/*      */ 
/*      */   public String getSensitiveLevel(String userId)
/*      */     throws ServiceException
/*      */   {
/*      */     try
/*      */     {
/* 1781 */       logger.debug("in getSensitiveLevel");
/* 1782 */       if (StringUtils.isBlank(userId)) {
/* 1783 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.user") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotQuerySensitiveLevel") + "!");
/*      */       }
/*      */ 
/* 1791 */       User_User user = getUser(userId);
/* 1792 */       if (user == null) {
/* 1793 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExistNoLevel") + "!");
/*      */       }
/*      */ 
/* 1798 */       logger.debug("end getSensitiveLevel");
/* 1799 */       return user.getSensitiveDataLevel();
/*      */     } catch (Exception e) {
/* 1801 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryLevelFail") + "", e);
/*      */     }
/*      */ 
/* 1804 */     throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryLevelFail") + "");
/*      */   }
/*      */ 
/*      */   public String getSensitiveLevelByCache(String userId) throws ServiceException
/*      */   {
/*      */     try
/*      */     {
/* 1811 */       logger.debug("in getSensitiveLevel");
/* 1812 */       if (StringUtils.isBlank(userId)) {
/* 1813 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.user") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotQuerySensitiveLevel") + "!");
/*      */       }
/*      */ 
/* 1821 */       User_User user = (User_User)UserCache.getInstance().getObjectByKey(userId);
/* 1822 */       if (user == null) {
/* 1823 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExistNoLevel") + "!");
/*      */       }
/*      */ 
/* 1828 */       logger.debug("end getSensitiveLevel");
/* 1829 */       return user.getSensitiveDataLevel();
/*      */     } catch (Exception e) {
/* 1831 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryLevelFail") + "", e);
/*      */     }
/*      */ 
/* 1834 */     throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryLevelFail") + "");
/*      */   }
/*      */ 
/*      */   public void updateSensitiveLevel(List<String> userIdList, String sensitiveLevel)
/*      */     throws ServiceException
/*      */   {
/*      */     try
/*      */     {
/* 1847 */       logger.debug("in updateSensitiveLevel");
/* 1848 */       if ((userIdList == null) || (userIdList.isEmpty())) {
/* 1849 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.user") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotUpdateLevel") + "!");
/*      */       }
/*      */ 
/* 1856 */       if (!UserConstants.isSenLevelLegal(sensitiveLevel)) {
/* 1857 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.levelErrorNoUpdate") + "!");
/*      */       }
/*      */ 
/* 1861 */       getUserUserDao().updateSensitiveLevel(userIdList, sensitiveLevel);
/*      */ 
/* 1864 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), sensitiveLevel, "用户及用户组", "用户-->修改用户敏感级别", null, null);
/*      */ 
/* 1870 */       logger.debug("end updateSensitiveLevel");
/*      */     } catch (DaoException e) {
/* 1872 */       logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateUserSensitiveLevelFail") + "", e);
/*      */ 
/* 1876 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateUserSensitiveLevelFail") + "");
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<Right> getSuperiorRightList(String userId, String superiorUserId)
/*      */   {
/* 1889 */     Collection allSysResType = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/* 1892 */     List finalList = new ArrayList();
/* 1893 */     for (SysResourceType resType : allSysResType) {
/* 1894 */       finalList.addAll(getSuperiorRightList(userId, superiorUserId, Integer.valueOf(resType.getResourceType()).toString(), Integer.valueOf(resType.getRoleType()).toString()));
/*      */     }
/*      */ 
/* 1897 */     return finalList;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public List<UserTempRight> getTempRightList(String userId, Date currDate)
/*      */   {
/* 1905 */     return null;
/*      */   }
/*      */ 
/*      */   public List<User_User> getUsersByUserMap(String userId, int resourceType, String relationType)
/*      */   {
/*      */     try {
/* 1911 */       logger.debug("in getUsersByUserMap");
/* 1912 */       List userList = new ArrayList();
/* 1913 */       userList = getUserUserMapDao().getUsersByUserMap(userId, resourceType, relationType);
/*      */ 
/* 1915 */       logger.debug("end getUsersByUserMap");
/* 1916 */       return userList;
/*      */     } catch (DaoException e) {
/* 1918 */       logger.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryUserRelationFail2") + "", e);
/*      */ 
/* 1923 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryUserRelationFail2") + "", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveIncrementUserMaps(List<UserUserMap> addedUserMaps, List<UserUserMap> deletedUserMaps)
/*      */   {
/* 1935 */     logger.debug("begin saveIncrementUserMap");
/*      */     try
/*      */     {
/* 1938 */       String userId = "";
/* 1939 */       Long resourceType = new Long(0L);
/* 1940 */       String relationType = "";
/* 1941 */       String userName = "";
/*      */ 
/* 1943 */       if (addedUserMaps != null) {
/* 1944 */         for (UserUserMap map : addedUserMaps) {
/* 1945 */           userId = map.getUserid();
/* 1946 */           resourceType = Long.valueOf(map.getResourcetype());
/* 1947 */           relationType = map.getRelationType();
/* 1948 */           this.userUserMapDao.save(map);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1953 */       if (deletedUserMaps != null) {
/* 1954 */         for (UserUserMap map : deletedUserMaps) {
/* 1955 */           userId = map.getUserid();
/* 1956 */           resourceType = Long.valueOf(map.getResourcetype());
/* 1957 */           relationType = map.getRelationType();
/* 1958 */           UserUserMap realMap = this.userUserMapDao.getByPK(map);
/* 1959 */           this.userUserMapDao.delete(realMap);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1964 */       if ("0".equals(resourceType.toString()))
/*      */       {
/* 1966 */         if ("0".equals(relationType))
/*      */         {
/* 1968 */           List userList = getUsersByUserMap(userId, resourceType.intValue(), relationType);
/*      */ 
/* 1970 */           if (userList.size() > 1) {
/* 1971 */             throw new ValidateException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.oneTempRightSuperiro") + "!");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1982 */       if (addedUserMaps != null) {
/* 1983 */         for (UserUserMap map : addedUserMaps) {
/* 1984 */           userId = map.getUserid();
/* 1985 */           userName = getUserName(userId);
/* 1986 */           LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), userId, userName, "用户管理-->用户关系-->修改用户上级", null, null);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1998 */       logger.debug("end saveIncrementUserMap");
/*      */     } catch (DaoException e) {
/* 2000 */       logger.debug("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrSaveUserRelationFail") + "", e);
/*      */ 
/* 2004 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrSaveUserRelationFail") + "", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public IUserUserExtDAO getUserUserExtDao()
/*      */   {
/* 2012 */     return this.userUserExtDao;
/*      */   }
/*      */ 
/*      */   public void setUserUserExtDao(IUserUserExtDAO userUserExtDao) {
/* 2016 */     this.userUserExtDao = userUserExtDao;
/*      */   }
/*      */ 
/*      */   public IUserGroupDAO getUserGroupDao() {
/* 2020 */     return this.userGroupDao;
/*      */   }
/*      */ 
/*      */   public void setUserGroupDao(IUserGroupDAO userGroupDao) {
/* 2024 */     this.userGroupDao = userGroupDao;
/*      */   }
/*      */ 
/*      */   public IUserRoleDAO getUserRoleDao() {
/* 2028 */     return this.userRoleDao;
/*      */   }
/*      */ 
/*      */   public void setUserRoleDao(IUserRoleDAO userRoleDao) {
/* 2032 */     this.userRoleDao = userRoleDao;
/*      */   }
/*      */ 
/*      */   public IUserUserDAO getUserUserDao() {
/* 2036 */     return this.userUserDao;
/*      */   }
/*      */ 
/*      */   public void setUserUserDao(IUserUserDAO userUserDao) {
/* 2040 */     this.userUserDao = userUserDao;
/*      */   }
/*      */ 
/*      */   public IGroupRoleMapDAO getGroupRoleMapDao() {
/* 2044 */     return this.groupRoleMapDao;
/*      */   }
/*      */ 
/*      */   public void setGroupRoleMapDao(IGroupRoleMapDAO groupRoleMapDao) {
/* 2048 */     this.groupRoleMapDao = groupRoleMapDao;
/*      */   }
/*      */ 
/*      */   public IUserGroupMapDAO getUserGroupMapDao() {
/* 2052 */     return this.userGroupMapDao;
/*      */   }
/*      */ 
/*      */   public void setUserGroupMapDao(IUserGroupMapDAO userGroupMapDao) {
/* 2056 */     this.userGroupMapDao = userGroupMapDao;
/*      */   }
/*      */ 
/*      */   public IUserRoleMapDAO getUserRoleMapDao() {
/* 2060 */     return this.userRoleMapDao;
/*      */   }
/*      */ 
/*      */   public void setUserRoleMapDao(IUserRoleMapDAO userRoleMapDao) {
/* 2064 */     this.userRoleMapDao = userRoleMapDao;
/*      */   }
/*      */ 
/*      */   public IUserUserMapDAO getUserUserMapDao() {
/* 2068 */     return this.userUserMapDao;
/*      */   }
/*      */ 
/*      */   public void setUserUserMapDao(IUserUserMapDAO userUserMapDao) {
/* 2072 */     this.userUserMapDao = userUserMapDao;
/*      */   }
/*      */ 
/*      */   public ISysResourceTypeDAO getSysResourceTypeDao() {
/* 2076 */     return this.sysResourceTypeDao;
/*      */   }
/*      */ 
/*      */   public void setSysResourceTypeDao(ISysResourceTypeDAO sysResourceTypeDao) {
/* 2080 */     this.sysResourceTypeDao = sysResourceTypeDao;
/*      */   }
/*      */ 
/*      */   public ISysmanageJdbcDao getSysmanageJdbcDao()
/*      */   {
/* 2087 */     return this.sysmanageJdbcDao;
/*      */   }
/*      */ 
/*      */   public void setSysmanageJdbcDao(ISysmanageJdbcDao jdbcDao)
/*      */   {
/* 2095 */     this.sysmanageJdbcDao = jdbcDao;
/*      */   }
/*      */ 
/*      */   public void setUserGroupAdminService(IUserGroupAdminService userGroupAdminService)
/*      */   {
/* 2100 */     this.userGroupAdminService = userGroupAdminService;
/*      */   }
/*      */ 
/*      */   private IUserGroupAdminService getUserGroupAdminService() {
/* 2104 */     return this.userGroupAdminService;
/*      */   }
/*      */ 
/*      */   public void setRoleAdminService(IRoleAdminService roleAdminService)
/*      */   {
/* 2109 */     this.roleAdminService = roleAdminService;
/*      */   }
/*      */ 
/*      */   private IRoleAdminService getRoleAdminService() {
/* 2113 */     return this.roleAdminService;
/*      */   }
/*      */ 
/*      */   public IUserCityService getUserCityService()
/*      */   {
/* 2118 */     return this.userCityService;
/*      */   }
/*      */ 
/*      */   public void setUserCityService(IUserCityService userCityService) {
/* 2122 */     this.userCityService = userCityService;
/*      */   }
/*      */ 
/*      */   public IUserTempRightService getUserTempRightService() {
/* 2126 */     return this.userTempRightService;
/*      */   }
/*      */ 
/*      */   public void setUserTempRightService(IUserTempRightService userTempRightService)
/*      */   {
/* 2131 */     this.userTempRightService = userTempRightService;
/*      */   }
/*      */ 
/*      */   public IUserUserPreferDefineDAO getUserUserPreferDefineDao() {
/* 2135 */     return this.userUserPreferDefineDao;
/*      */   }
/*      */ 
/*      */   public void setUserUserPreferDefineDao(IUserUserPreferDefineDAO userUserPreferDefineDao)
/*      */   {
/* 2140 */     this.userUserPreferDefineDao = userUserPreferDefineDao;
/*      */   }
/*      */ 
/*      */   public IUserUserUserPreferDAO getUserUserUserPreferDao() {
/* 2144 */     return this.userUserUserPreferDao;
/*      */   }
/*      */ 
/*      */   public void setUserUserUserPreferDao(IUserUserUserPreferDAO userUserUserPreferDao)
/*      */   {
/* 2149 */     this.userUserUserPreferDao = userUserUserPreferDao;
/*      */   }
/*      */ 
/*      */   public IUserCompanyService getUserCompanyService() {
/* 2153 */     return this.userCompanyService;
/*      */   }
/*      */ 
/*      */   public void setUserCompanyService(IUserCompanyService userCompanyService) {
/* 2157 */     this.userCompanyService = userCompanyService;
/*      */   }
/*      */ 
/*      */   public IUserDutyDAO getUserDutyDao() {
/* 2161 */     return this.userDutyDao;
/*      */   }
/*      */ 
/*      */   public void setUserDutyDao(IUserDutyDAO userDutyDao) {
/* 2165 */     this.userDutyDao = userDutyDao;
/*      */   }
/*      */ 
/*      */   public List getUserPreferList(String userID) {
/* 2169 */     List returnList = new ArrayList();
/*      */ 
/* 2173 */     List preferDefineList = this.userUserPreferDefineDao.findAll();
/*      */ 
/* 2175 */     List usrPreferList = new ArrayList();
/*      */ 
/* 2180 */     Iterator pdIter = preferDefineList.iterator();
/*      */ 
/* 2182 */     User_Prefer userPrefer = new User_Prefer();
/* 2183 */     Prefer_Define preferDefine = new Prefer_Define();
/* 2184 */     while (pdIter.hasNext()) {
/* 2185 */       UserPreferForm userPreferForm = new UserPreferForm();
/* 2186 */       preferDefine = (Prefer_Define)pdIter.next();
/* 2187 */       usrPreferList = this.userUserUserPreferDao.findAll(userID, preferDefine.getPreferId());
/*      */ 
/* 2190 */       if (usrPreferList.size() == 0) {
/* 2191 */         userPreferForm.setPreferId(preferDefine.getPreferId());
/* 2192 */         userPreferForm.setPreferName(preferDefine.getPreferName());
/* 2193 */         userPreferForm.setPreferValuedesc("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.no") + "");
/*      */ 
/* 2196 */         userPreferForm.setPreferKey(preferDefine.getPreferKey());
/* 2197 */         returnList.add(userPreferForm);
/*      */       } else {
/* 2199 */         Iterator upIter = usrPreferList.iterator();
/* 2200 */         while (upIter.hasNext()) {
/* 2201 */           userPrefer = (User_Prefer)upIter.next();
/* 2202 */           userPreferForm.setPreferId(preferDefine.getPreferId());
/* 2203 */           userPreferForm.setPreferName(preferDefine.getPreferName());
/* 2204 */           userPreferForm.setPreferValuedesc(userPrefer.getPreferValuedesc());
/*      */ 
/* 2206 */           userPreferForm.setPreferKey(preferDefine.getPreferKey());
/*      */         }
/* 2208 */         returnList.add(userPreferForm);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2213 */     return returnList;
/*      */   }
/*      */ 
/*      */   public void saveUserPrefer(String userId, String preferid, String preferValuedesc)
/*      */   {
/*      */     try {
/* 2219 */       this.userUserUserPreferDao.save(userId, preferid, preferValuedesc);
/*      */     } catch (Exception e) {
/* 2221 */       logger.error("saveUserPrefer " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 2224 */       throw new SysmanageException("" + e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<String> getPreferDescListByPreferType(String userID, String preferId)
/*      */   {
/* 2234 */     List list = new ArrayList();
/*      */     try {
/* 2236 */       list = this.userUserUserPreferDao.getPreferDescListByPreferType(userID, preferId);
/*      */     }
/*      */     catch (Exception e) {
/* 2239 */       logger.error("getPreferDescListByPreferType " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 2242 */       throw new SysmanageException("" + e.getMessage(), e);
/*      */     }
/* 2244 */     return list;
/*      */   }
/*      */ 
/*      */   public List<IUser> getAllUser()
/*      */     throws ServiceException
/*      */   {
/* 2250 */     List userList = new ArrayList();
/* 2251 */     Collection collection = UserCache.getInstance().getAllCachedObject();
/* 2252 */     Iterator it = collection.iterator();
/* 2253 */     while (it.hasNext()) {
/* 2254 */       User_User user = (User_User)it.next();
/* 2255 */       if (Integer.parseInt("0") == user.getStatus()) {
/* 2256 */         userList.add(user);
/*      */       }
/*      */     }
/* 2259 */     return userList;
/*      */   }
/*      */ 
/*      */   public List<ICity> getAllCity() throws ServiceException {
/* 2263 */     return getUserCityService().getAllCity();
/*      */   }
/*      */ 
/*      */   public List<IUserCompany> getAllUserCompany() throws ServiceException {
/* 2267 */     return getUserCompanyService().getAllDept();
/*      */   }
/*      */ 
/*      */   public List<IUserRole> getAllUserRole() throws ServiceException {
/* 2271 */     List roleList = new ArrayList();
/* 2272 */     Collection collection = UserRoleCache.getInstance().getAllRolesSortedByName();
/* 2273 */     for (UserRole role : collection) {
/* 2274 */       roleList.add(role);
/*      */     }
/* 2276 */     return roleList;
/*      */   }
/*      */ 
/*      */   public ICity getCityById(String cityId) throws ServiceException {
/* 2280 */     User_City city = (User_City)UserCityCache.getInstance().getObjectByKey(cityId);
/* 2281 */     return city;
/*      */   }
/*      */ 
/*      */   public List<IGroupRoleMap> getGroupRoleMapList() throws ServiceException {
/* 2285 */     return getGroupRoleMapDao().getGroupRoleMapList();
/*      */   }
/*      */ 
/*      */   public ISysResourceType getResourceTypeByRoleRes(int roleType, int resourceType) throws ServiceException
/*      */   {
/* 2290 */     return SysResourceTypeCache.getInstance().getSysResourceType(roleType, resourceType);
/*      */   }
/*      */ 
/*      */   public IUserCompany getUserCompanyById(String companyId) throws ServiceException
/*      */   {
/* 2295 */     return getUserCompanyService().getUserCompany(companyId);
/*      */   }
/*      */ 
/*      */   public IUserDuty getUserDutyById(String id) throws ServiceException {
/* 2299 */     return getUserDutyDao().findById(id);
/*      */   }
/*      */ 
/*      */   public IUserGroup getUserGroupById(String groupId) throws ServiceException {
/* 2303 */     User_Group group = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(groupId);
/*      */ 
/* 2305 */     return group;
/*      */   }
/*      */ 
/*      */   public List<IUserGroup> getAllUserGroup() throws ServiceException {
/* 2309 */     List groupList = new ArrayList();
/* 2310 */     Collection collection = UserGroupDefineCache.getInstance().getAllGroupsSortedByName();
/*      */ 
/* 2312 */     Iterator it = collection.iterator();
/* 2313 */     while (it.hasNext()) {
/* 2314 */       User_Group group = (User_Group)it.next();
/* 2315 */       groupList.add(group);
/*      */     }
/* 2317 */     return groupList;
/*      */   }
/*      */ 
/*      */   public List<IUserGroup> getUserGroupByUserId(List<String> userIds)
/*      */   {
/* 2322 */     List groupList = new ArrayList();
/* 2323 */     Set groupIds = new HashSet();
/* 2324 */     for (String userId : userIds) {
/* 2325 */       User_User user = (User_User)UserCache.getInstance().getObjectByKey(userId);
/*      */ 
/* 2327 */       groupIds.add(user.getGroupId());
/*      */     }
/* 2329 */     for (String groupId : groupIds) {
/* 2330 */       User_Group group = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(groupId);
/*      */ 
/* 2332 */       groupList.add(group);
/*      */     }
/* 2334 */     return groupList;
/*      */   }
/*      */ 
/*      */   public IUserRole getUserRoleById(String roleId) throws ServiceException {
/* 2338 */     return (IUserRole)UserRoleCache.getInstance().getObjectByKey(roleId);
/*      */   }
/*      */ 
/*      */   public List<IUserGroup> getValidChildGroups(String groupId) {
/* 2342 */     List result = new ArrayList();
/* 2343 */     Collection groupList = UserGroupDefineCache.getInstance().getAllCachedObject();
/*      */ 
/* 2345 */     getValidChildGroups(groupId, groupList, result);
/* 2346 */     return result;
/*      */   }
/*      */ 
/*      */   private void getValidChildGroups(String groupId, Collection<User_Group> groupList, List<IUserGroup> result)
/*      */   {
/* 2351 */     for (User_Group group : groupList)
/* 2352 */       if (group.getParentid().equals(groupId)) {
/* 2353 */         result.add(group);
/* 2354 */         getValidChildGroups(group.getGroupid(), groupList, result);
/*      */       }
/*      */   }
/*      */ 
/*      */   public List<ICity> getCityByUser(String userId)
/*      */     throws ServiceException
/*      */   {
/* 2361 */     List returnCitys = new ArrayList();
/* 2362 */     List citys = ListService.getAuthCityList(userId, "5");
/*      */ 
/* 2364 */     for (ICity user_City : citys) {
/* 2365 */       returnCitys.add(user_City);
/*      */     }
/* 2367 */     return returnCitys;
/*      */   }
/*      */ 
/*      */   public void saveGroupRoleMaps(List<IGroupRoleMap> list) throws ServiceException
/*      */   {
/* 2372 */     getGroupRoleMapDao().saveGroupRoleMaps(list);
/*      */   }
/*      */ 
/*      */   public List<ICity> getSubCitysById(String parentCityId)
/*      */     throws ServiceException
/*      */   {
/* 2381 */     return getUserCityService().getSubCitysById(parentCityId);
/*      */   }
/*      */ 
/*      */   public List<IUserCompany> getSubCompanyById(String deptId)
/*      */     throws ServiceException
/*      */   {
/* 2387 */     return this.userCompanyService.getCompanyListByParentId(deptId);
/*      */   }
/*      */ 
/*      */   public List getRightExceptTempRight(String userId, int roleType, int resourceType, boolean isDistinctControlType)
/*      */   {
/* 2402 */     logger.debug("in getRightExceptTempRight");
/*      */     try
/*      */     {
/* 2405 */       if (isAdminUser(userId)) {
/* 2406 */         logger.debug("is adminUser");
/* 2407 */         return getRoleAdminService().getAllRights(roleType, resourceType);
/*      */       }
/*      */ 
/* 2410 */       List roleList = new ArrayList();
/*      */ 
/* 2412 */       roleList = getAllRoles(userId);
/* 2413 */       List roleIdList = ListService.convertToNewList(roleList, "RoleId");
/*      */ 
/* 2415 */       List rightList = getRoleAdminService().getRightsByRoleIdList(roleIdList, roleType, resourceType, isDistinctControlType);
/*      */ 
/* 2418 */       logger.debug("end getRightExceptTempRight");
/* 2419 */       return rightList;
/*      */     } catch (Exception e) {
/* 2421 */       logger.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 2424 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + userId);
/*      */   }
/*      */ 
/*      */   public List<SysResourceType> getSuperiorResTypeList(String userId, String superiorUserId)
/*      */   {
/* 2438 */     List srtList = new ArrayList();
/* 2439 */     Collection allSysResType = SysResourceTypeCache.getInstance().getAllCachedObject();
/*      */ 
/* 2441 */     for (SysResourceType resType : allSysResType) {
/* 2442 */       List rightList = getRight(userId, resType.getRoleType(), resType.getResourceType(), false);
/*      */ 
/* 2444 */       List superiorRightList = getRight(superiorUserId, resType.getRoleType(), resType.getResourceType(), true);
/*      */ 
/* 2446 */       Collection co = CollectionUtils.subtract(superiorRightList, rightList);
/*      */ 
/* 2448 */       if (CollectionUtils.isNotEmpty(co)) {
/* 2449 */         srtList.add(resType);
/*      */       }
/*      */     }
/*      */ 
/* 2453 */     return srtList;
/*      */   }
/*      */ 
/*      */   public List<Right> getSuperiorRightList(String userId, String superiorUserId, String resourceType, String roleType)
/*      */   {
/* 2458 */     List finalList = new ArrayList();
/* 2459 */     List rightList = getRight(userId, Integer.parseInt(roleType), Integer.parseInt(resourceType), false);
/*      */ 
/* 2461 */     List superiorRightList = getRight(superiorUserId, Integer.parseInt(roleType), Integer.parseInt(resourceType), true);
/*      */ 
/* 2463 */     finalList.addAll(CollectionUtils.subtract(superiorRightList, rightList));
/*      */ 
/* 2465 */     return finalList;
/*      */   }
/*      */ 
/*      */   public boolean haveOperateRight(String userId, int resourceType, String resourceId, String operationKey)
/*      */   {
/* 2470 */     if (isAdminUser(userId)) {
/* 2471 */       return true;
/*      */     }
/*      */ 
/* 2475 */     List roleList = getAllRoles(userId);
/* 2476 */     for (UserRole ur : roleList) {
/* 2477 */       IResourceRightDAO rightDao = getRoleAdminService().getResourceRightDAO(-1, resourceType);
/*      */ 
/* 2479 */       if (rightDao != null) {
/* 2480 */         boolean flag = rightDao.isExistRoleRight(ur.getRoleId(), resourceId, resourceType, operationKey);
/*      */ 
/* 2482 */         if (flag == true) {
/* 2483 */           return true;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2490 */     return false;
/*      */   }
/*      */ 
/*      */   public List<User_City> getSubUserCtiyById(String parentCityId, String userId, boolean isCascade)
/*      */   {
/* 2499 */     List result = new ArrayList();
/* 2500 */     List subCitysOfPID = new ArrayList();
/* 2501 */     if (isCascade)
/* 2502 */       ListService.getCityList(parentCityId, subCitysOfPID);
/*      */     else {
/* 2504 */       subCitysOfPID = ListService.getDirectChildCityList(parentCityId);
/*      */     }
/* 2506 */     Map subCitysOfPIDMap = new HashMap();
/* 2507 */     for (User_City city : subCitysOfPID) {
/* 2508 */       subCitysOfPIDMap.put(city.getCityId(), city);
/*      */     }
/*      */ 
/* 2511 */     if (StringUtil.isNotEmpty(userId)) {
/* 2512 */       if (UserCache.getInstance().getObjectByKey(userId) == null)
/* 2513 */         return new ArrayList();
/* 2514 */       List resourceList = getRight(userId, 0, Integer.parseInt("5"), false);
/*      */ 
/* 2517 */       for (Right right : resourceList) {
/* 2518 */         User_City userCity = (User_City)subCitysOfPIDMap.get(right.getResourceId());
/*      */ 
/* 2520 */         if (userCity != null) {
/* 2521 */           result.add(userCity);
/*      */         }
/*      */       }
/*      */     }
/* 2525 */     return result;
/*      */   }
/*      */ 
/*      */   public List<Right> getUserRightList(String userId, int resourceType, int roleType, boolean isDistinctControlType)
/*      */   {
/* 2531 */     IResourceRightDAO resourceRightDAO = getRoleAdminService().getResourceRightDAO(roleType, resourceType);
/*      */ 
/* 2533 */     if (null != resourceRightDAO) {
/* 2534 */       List list = resourceRightDAO.getUserRightList(userId, resourceType, roleType, isDistinctControlType);
/*      */ 
/* 2536 */       return list;
/*      */     }
/* 2538 */     return null;
/*      */   }
/*      */ 
/*      */   public List getCityRoleRight(String userId, boolean isDistinctControlType)
/*      */   {
/* 2543 */     logger.debug("-------in getCityRoleRight-------");
/*      */     try
/*      */     {
/* 2546 */       if (isAdminUser(userId)) {
/* 2547 */         logger.debug("is adminUser");
/* 2548 */         return getRoleAdminService().getAllRights(0, Integer.parseInt("5"));
/*      */       }
/*      */ 
/* 2556 */       List roleList = getAllRoles(userId);
/* 2557 */       List roleIdList = ListService.convertToNewList(roleList, "RoleId");
/*      */ 
/* 2560 */       List rightList = getRoleAdminService().getRightsByRoleIdList(roleIdList, 0, Integer.parseInt("5"), isDistinctControlType);
/*      */ 
/* 2566 */       logger.debug("-------end getCityRoleRight-------");
/* 2567 */       return rightList;
/*      */     } catch (Exception e) {
/* 2569 */       logger.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/* 2572 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + userId);
/*      */   }
/*      */ 
/*      */   public void saveUserRights(String userId, int resourceType, List<String> resourceIds, int accessType, String controlType)
/*      */     throws ServiceException
/*      */   {
/* 2581 */     for (String resId : resourceIds) {
/* 2582 */       this.roleAdminService.saveRight(userId, 1, resourceType, resId, accessType, controlType);
/*      */     }
/*      */ 
/* 2585 */     LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), userId, getUser(userId).getUsername(), LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.updateJurisdiction"), null, null);
/*      */   }
/*      */ 
/*      */   public List getUserByTime(String startTime, String endTime)
/*      */   {
/* 2593 */     List list = new ArrayList();
/*      */     try {
/* 2595 */       list = this.userUserDao.getUserByTime(startTime, endTime);
/*      */     } catch (Exception e) {
/* 2597 */       logger.error("getUserByTime " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 2600 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserByTime") + "");
/*      */     }
/* 2602 */     return list;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.UserAdminServiceImpl
 * JD-Core Version:    0.6.2
 */
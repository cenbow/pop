/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.ICity;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCityCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCityDmTypeCache;
/*     */ import com.asiainfo.biframe.privilege.model.UserCityDmType;
/*     */ import com.asiainfo.biframe.privilege.model.User_City;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserCityDao;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCityService;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class UserCityServiceImpl
/*     */   implements IUserCityService
/*     */ {
/*     */   private IUserCityDao userCityDao;
/*     */ 
/*     */   public User_City getCityById(String cityId)
/*     */   {
/*  44 */     return getUserCityDao().getCityById(cityId);
/*     */   }
/*     */ 
/*     */   public List<User_City> getCityByName(String cityName)
/*     */   {
/*  51 */     return getUserCityDao().getCityByName(cityName);
/*     */   }
/*     */ 
/*     */   public String getDmCity(String cityId, String resourceId, String dmType, String dbType, boolean isShow)
/*     */   {
/*  60 */     if (StringUtils.isBlank(dmType)) {
/*  61 */       return "";
/*     */     }
/*  63 */     if (StringUtils.isBlank(dbType)) {
/*  64 */       return "";
/*     */     }
/*     */ 
/*  67 */     User_City city = (User_City)UserCityCache.getInstance().getObjectByKey(cityId);
/*     */ 
/*  70 */     if (city == null) {
/*  71 */       return "";
/*     */     }
/*     */ 
/*  74 */     if ("DBTYPE_APP".equals(dbType)) {
/*  75 */       return city.getCityId();
/*     */     }
/*     */ 
/*  78 */     String noFlag = "-1";
/*  79 */     if ("-1".equals(dmType)) {
/*  80 */       if (StringUtil.isNotEmpty(city.getDmTypeCode())) {
/*  81 */         String returnValue = "";
/*  82 */         List list = UserCityDmTypeCache.getInstance().getObjectSortedList();
/*     */ 
/*  84 */         String dmTypeCode = "";
/*     */ 
/*  87 */         String lastDmTypeId = null;
/*  88 */         String thisDmTypeId = null;
/*  89 */         for (int i = 0; i < list.size(); i++) {
/*  90 */           thisDmTypeId = getDmCity(city.getCityId(), ((UserCityDmType)list.get(i)).getDmTypeCode());
/*     */ 
/*  92 */           if (i > 0)
/*  93 */             if (((UserCityDmType)list.get(i)).getDmLevel() != ((UserCityDmType)list.get(i - 1)).getDmLevel())
/*     */             {
/*  95 */               if ("-1".equals(lastDmTypeId))
/*     */                 break;
/*  97 */               returnValue = returnValue + "|" + lastDmTypeId; } else {
/*  98 */               if ("-1".equals(thisDmTypeId))
/*     */                 continue;
/*     */             }
/* 101 */           lastDmTypeId = thisDmTypeId;
/*     */         }
/* 103 */         if (!"-1".equals(lastDmTypeId))
/* 104 */           returnValue = returnValue + "|" + lastDmTypeId;
/* 105 */         returnValue = returnValue.replaceFirst("\\|", "");
/* 106 */         return returnValue;
/*     */       }
/*     */ 
/* 110 */       String returnValue = city.getDmCityId();
/* 111 */       if (!noFlag.equals(city.getDmCountyId())) {
/* 112 */         returnValue = returnValue + "|" + city.getDmCountyId();
/*     */       }
/* 114 */       if (!noFlag.equals(city.getDmDeptId())) {
/* 115 */         returnValue = returnValue + "|" + city.getDmDeptId();
/*     */       }
/* 117 */       return returnValue;
/*     */     }
/*     */ 
/* 121 */     if (isShow) {
/* 122 */       String level = getDmLevle(city);
/* 123 */       if (!level.equals(dmType)) {
/* 124 */         return "";
/*     */       }
/*     */     }
/* 127 */     if (StringUtil.isNotEmpty(city.getDmTypeCode()))
/*     */     {
/* 130 */       if (StringUtil.isEmpty(resourceId)) {
/* 131 */         String returnValue = getDmCity(cityId, dmType);
/* 132 */         return noFlag.equals(returnValue) ? "" : returnValue;
/*     */       }
/*     */ 
/* 135 */       String allParentId = getDmCity(city.getParentId(), null, "-1", dbType, isShow);
/*     */ 
/* 137 */       if (!resourceId.equals(allParentId))
/* 138 */         return "";
/* 139 */       String returnValue = getDmCity(cityId, dmType);
/* 140 */       return noFlag.equals(returnValue) ? "" : returnValue;
/*     */     }
/*     */ 
/* 143 */     if ("CITY".equals(dmType)) {
/* 144 */       return noFlag.equals(city.getDmCityId()) ? "" : city.getDmCityId();
/*     */     }
/* 146 */     if ("COUNTY".equals(dmType)) {
/* 147 */       if ((StringUtils.isBlank(resourceId)) || (StringUtils.equals(city.getDmCityId(), resourceId)))
/*     */       {
/* 149 */         return noFlag.equals(city.getDmCountyId()) ? "" : city.getDmCountyId();
/*     */       }
/*     */ 
/* 152 */       return "";
/*     */     }
/* 154 */     if ("DEPT".equals(dmType)) {
/* 155 */       if (StringUtils.isBlank(resourceId)) {
/* 156 */         return noFlag.equals(city.getDmDeptId()) ? "" : city.getDmDeptId();
/*     */       }
/*     */ 
/* 160 */       String[] arr = resourceId.split("\\|", -1);
/* 161 */       if (arr.length != 2) {
/* 162 */         return "";
/*     */       }
/* 164 */       if ((StringUtils.equals(city.getDmCityId(), arr[0])) && (StringUtils.equals(city.getDmCountyId(), arr[1])))
/*     */       {
/* 166 */         return noFlag.equals(city.getDmDeptId()) ? "" : city.getDmDeptId();
/*     */       }
/*     */ 
/* 169 */       return "";
/*     */     }
/* 171 */     return "";
/*     */   }
/*     */ 
/*     */   private String getDmLevle(User_City city)
/*     */   {
/* 184 */     if (city == null) {
/* 185 */       return "";
/*     */     }
/*     */ 
/* 188 */     if (StringUtil.isNotEmpty(city.getDmTypeCode())) {
/* 189 */       return city.getDmTypeCode();
/*     */     }
/*     */ 
/* 192 */     String noFlag = "-1";
/* 193 */     if (!noFlag.equals(city.getDmDeptId())) {
/* 194 */       return "DEPT";
/*     */     }
/* 196 */     if (!noFlag.equals(city.getDmCountyId())) {
/* 197 */       return "COUNTY";
/*     */     }
/* 199 */     if (!noFlag.equals(city.getDmCityId())) {
/* 200 */       return "CITY";
/*     */     }
/* 202 */     return "";
/*     */   }
/*     */ 
/*     */   public String getDmCity(String cityId, String dmType)
/*     */   {
/* 211 */     User_City city = (User_City)UserCityCache.getInstance().getObjectByKey(cityId);
/*     */ 
/* 214 */     if (city == null) {
/* 215 */       return "";
/*     */     }
/* 217 */     String returnValue = "";
/*     */ 
/* 221 */     UserCityDmType userCityDmTypePara = (UserCityDmType)UserCityDmTypeCache.getInstance().getObjectByKey(dmType);
/*     */ 
/* 223 */     if ((StringUtil.isNotEmpty(city.getDmTypeCode())) && ((userCityDmTypePara != null) || ("-1".equals(dmType))))
/*     */     {
/* 227 */       UserCityDmType userCityDmType = (UserCityDmType)UserCityDmTypeCache.getInstance().getObjectByKey(city.getDmTypeCode());
/*     */ 
/* 229 */       if (userCityDmType == null) {
/* 230 */         return "";
/*     */       }
/* 232 */       if ("-1".equals(dmType)) {
/* 233 */         List list = UserCityDmTypeCache.getInstance().getObjectSortedList();
/*     */ 
/* 236 */         String lastDmTypeId = null;
/* 237 */         String thisDmTypeId = null;
/* 238 */         for (int i = 0; i < list.size(); i++) {
/* 239 */           thisDmTypeId = getDmCity(city.getCityId(), ((UserCityDmType)list.get(i)).getDmTypeCode());
/*     */ 
/* 241 */           if (i > 0) {
/* 242 */             if (((UserCityDmType)list.get(i)).getDmLevel() != ((UserCityDmType)list.get(i - 1)).getDmLevel())
/*     */             {
/* 244 */               returnValue = returnValue + lastDmTypeId + "|";
/*     */             } else if ("-1".equals(thisDmTypeId))
/*     */                 continue;
/*     */           }
/* 248 */           lastDmTypeId = thisDmTypeId;
/*     */         }
/* 250 */         returnValue = returnValue + lastDmTypeId;
/* 251 */         return returnValue;
/*     */       }
/*     */ 
/* 254 */       if ((userCityDmTypePara.getDmLevel() == userCityDmType.getDmLevel()) && (dmType.equals(userCityDmType.getDmTypeCode())))
/*     */       {
/* 256 */         returnValue = city.getDmTypeId();
/* 257 */       } else if (userCityDmTypePara.getDmLevel() < userCityDmType.getDmLevel())
/*     */       {
/* 259 */         returnValue = getDmCity(city.getParentId(), dmType);
/*     */       }
/* 261 */       else returnValue = "-1";
/*     */ 
/* 263 */       return returnValue;
/*     */     }
/*     */ 
/* 266 */     if ("CITY".equals(dmType))
/* 267 */       returnValue = city.getDmCityId();
/* 268 */     else if ("COUNTY".equals(dmType))
/* 269 */       returnValue = city.getDmCountyId();
/* 270 */     else if ("DEPT".equals(dmType))
/* 271 */       returnValue = city.getDmDeptId();
/* 272 */     else if ("-1".equals(dmType)) {
/* 273 */       returnValue = city.getDmCityId() + "|" + city.getDmCountyId() + "|" + city.getDmDeptId();
/*     */     }
/*     */ 
/* 276 */     return returnValue;
/*     */   }
/*     */ 
/*     */   public IUserCityDao getUserCityDao() {
/* 280 */     return this.userCityDao;
/*     */   }
/*     */ 
/*     */   public void setUserCityDao(IUserCityDao userCityDao) {
/* 284 */     this.userCityDao = userCityDao;
/*     */   }
/*     */ 
/*     */   public List<ICity> getAllCity()
/*     */     throws ServiceException
/*     */   {
/* 290 */     List cityList = new ArrayList();
/* 291 */     Collection collection = UserCityCache.getInstance().getAllCachedObject();
/*     */ 
/* 293 */     for (User_City city : collection) {
/* 294 */       cityList.add(city);
/*     */     }
/* 296 */     return cityList;
/*     */   }
/*     */ 
/*     */   public List<ICity> getSubCitysById(String parentCityId)
/*     */     throws ServiceException
/*     */   {
/* 305 */     List returnList = new ArrayList();
/* 306 */     Collection collection = UserCityCache.getInstance().getAllCachedObject();
/*     */ 
/* 308 */     for (User_City city : collection) {
/* 309 */       if (parentCityId.equals(city.getParentId())) {
/* 310 */         returnList.add(city);
/*     */       }
/*     */     }
/* 313 */     return returnList;
/*     */   }
/*     */ 
/*     */   public List<ICity> getParentCitys(String childCityId)
/*     */     throws ServiceException
/*     */   {
/* 321 */     List list = getUserCityDao().getParentCityByChildId(childCityId);
/*     */ 
/* 323 */     if ((list == null) || (list.size() == 0)) {
/* 324 */       return null;
/*     */     }
/*     */ 
/* 327 */     List returnList = null;
/* 328 */     for (User_City user_City : list) {
/* 329 */       ICity city = user_City;
/* 330 */       if (returnList == null) {
/* 331 */         returnList = new ArrayList();
/*     */       }
/* 333 */       returnList.add(city);
/*     */     }
/* 335 */     return returnList;
/*     */   }
/*     */ 
/*     */   public User_City getCityByDmCity(String dm_city_id, String dmType)
/*     */     throws ServiceException
/*     */   {
/* 341 */     User_City returnCity = null;
/*     */ 
/* 344 */     if ((StringUtil.isEmpty(dm_city_id)) || (StringUtil.isEmpty(dmType))) {
/* 345 */       return null;
/*     */     }
/*     */ 
/* 349 */     String[] dmCityIdArr = dm_city_id.split("\\|", -1);
/* 350 */     int dmLevelIndex = dmCityIdArr.length - 1;
/* 351 */     UserCityDmType userCityDmTypePara = (UserCityDmType)UserCityDmTypeCache.getInstance().getObjectByKey(dmType);
/*     */ 
/* 355 */     Collection allUserCity = UserCityCache.getInstance().getAllCachedObject();
/*     */ 
/* 357 */     if ((allUserCity == null) || (allUserCity.size() <= 0)) {
/* 358 */       return null;
/*     */     }
/*     */ 
/* 362 */     for (User_City city : allUserCity)
/*     */     {
/* 364 */       if ((StringUtil.isNotEmpty(city.getDmTypeCode())) && (userCityDmTypePara != null))
/*     */       {
/* 366 */         if ((dmType.equals(city.getDmTypeCode())) && (dmCityIdArr[dmLevelIndex].equals(city.getDmTypeId())))
/*     */         {
/* 368 */           returnCity = city;
/*     */ 
/* 371 */           List dmTypeList = UserCityDmTypeCache.getInstance().getObjectSortedList();
/* 372 */           if (!dmType.equals(((UserCityDmType)dmTypeList.get(dmLevelIndex)).getDmTypeCode())) {
/* 373 */             returnCity = null;
/*     */           }
/*     */           else
/*     */           {
/* 378 */             User_City parentCity = city;
/* 379 */             for (int i = dmLevelIndex - 1; i > -1; i--) {
/* 380 */               parentCity = (User_City)UserCityCache.getInstance().getObjectByKey(parentCity.getParentId());
/* 381 */               if ((parentCity == null) || (!parentCity.getDmTypeId().equals(dmCityIdArr[i])))
/*     */               {
/* 383 */                 returnCity = null;
/* 384 */                 break;
/*     */               }
/*     */             }
/*     */ 
/* 388 */             if (returnCity != null) break;
/*     */           }
/*     */         }
/*     */       } else {
/* 392 */         if (("CITY".equals(dmType)) && (city.getDmCityId().equals(dm_city_id)) && ("-1".equals(city.getDmCountyId())) && ("-1".equals(city.getDmDeptId())))
/*     */         {
/* 396 */           returnCity = city;
/* 397 */           break;
/* 398 */         }if (("COUNTY".equals(dmType)) && (city.getDmCityId().equals(dmCityIdArr[0])) && (city.getDmCountyId().equals(dmCityIdArr[1])) && ("-1".equals(city.getDmDeptId())))
/*     */         {
/* 402 */           returnCity = city;
/* 403 */           break;
/* 404 */         }if (("DEPT".equals(dmType)) && (city.getDmCityId().equals(dmCityIdArr[0])) && (city.getDmCountyId().equals(dmCityIdArr[1])) && (city.getDmDeptId().equals(dmCityIdArr[2])))
/*     */         {
/* 408 */           returnCity = city;
/* 409 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 413 */     return returnCity;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.UserCityServiceImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheFilter;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCompanyCache;
/*     */ import com.asiainfo.biframe.privilege.model.User_Company;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UserCompanyAdmin
/*     */ {
/*  24 */   private Logger log = Logger.getLogger(UserCompanyAdmin.class);
/*     */   private static UserCompanyAdmin _instance;
/*     */ 
/*     */   public static UserCompanyAdmin getInstance()
/*     */   {
/*  33 */     if (_instance == null) _instance = new UserCompanyAdmin();
/*  34 */     return _instance;
/*     */   }
/*     */ 
/*     */   public String delCompany(Sqlca sqlca, int DeptId, String strUserId, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/*  45 */     StringBuffer ret = new StringBuffer();
/*  46 */     Vector v = new Vector();
/*     */ 
/*  64 */     delCompanyTree(DeptId, v);
/*     */ 
/*  66 */     Iterator iter = v.iterator();
/*  67 */     StringBuffer strDeptIds = new StringBuffer();
/*  68 */     int hasUsersCount = 0;
/*  69 */     while (iter.hasNext())
/*     */     {
/*  71 */       String strDeptid = iter.next().toString();
/*  72 */       strDeptIds.append(strDeptid);
/*  73 */       strDeptIds.append(",");
/*  74 */       int deptid = Integer.parseInt(strDeptid);
/*  75 */       Map tmp = UserCache.getInstance().getObjectByCondition(new CacheFilter()
/*     */       {
/*     */         int deptid;
/*     */ 
/*     */         public boolean match(Object obj)
/*     */         {
/*  58 */           if (obj == null) return false;
/*  59 */           return ((User_User)obj).getDepartmentid() == this.deptid;
/*     */         }
/*     */       });
/*  76 */       if (!tmp.isEmpty())
/*     */       {
/*  78 */         if ((hasUsersCount > 0) && (hasUsersCount < 3)) ret.append("/");
/*  79 */         if (hasUsersCount < 3)
/*  80 */           ret.append(UserCompanyCache.getInstance().getNameByKey(strDeptid));
/*  81 */         else ret.append("...");
/*  82 */         hasUsersCount++;
/*     */       }
/*     */     }
/*  85 */     strDeptIds.deleteCharAt(strDeptIds.lastIndexOf(","));
/*     */ 
/*  87 */     if (ret.length() != 0)
/*     */     {
/*  89 */       return ret.toString();
/*     */     }
/*     */ 
/*  92 */     StringBuffer strSqlbuf = new StringBuffer();
/*  93 */     Sqlca mSqlca = null;
/*     */     try
/*     */     {
/*  97 */       mSqlca = new Sqlca(sqlca.getConnection());
/*     */ 
/* 101 */       strSqlbuf.append("update user_company set status='").append("2").append("'");
/* 102 */       strSqlbuf.append(",delete_time='").append(DateUtil.date2String(new Date(), "yyyy-MM-dd HH:mm:ss")).append("'");
/* 103 */       strSqlbuf.append(" where  deptid in (").append(strDeptIds).append(")");
/*     */ 
/* 105 */       this.log.debug("--sql:" + strSqlbuf);
/* 106 */       mSqlca.execute(strSqlbuf.toString());
/*     */ 
/* 108 */       strSqlbuf = null;
/*     */ 
/* 110 */       iter = v.iterator();
/* 111 */       while (iter.hasNext())
/*     */       {
/* 113 */         Object obj = iter.next();
/* 114 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_MANAGECONPANY"), obj.toString(), UserCompanyCache.getInstance().getNameByKey(obj), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.company") + "-->" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delDept") + "", null, null);
/*     */ 
/* 117 */         UserCompanyCache.getInstance().refreshByKey(obj);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 123 */       throw e;
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 128 */         if (mSqlca != null)
/* 129 */           mSqlca.close();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 133 */         throw e;
/*     */       }
/*     */     }
/* 136 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   private void delCompanyTree(int DeptId, Vector v)
/*     */   {
/* 163 */     Map selCompany = UserCompanyCache.getInstance().getObjectByCondition(new CacheFilter()
/*     */     {
/*     */       int deptid;
/*     */ 
/*     */       public boolean match(Object obj)
/*     */       {
/* 158 */         if (obj == null) return false;
/* 159 */         return ((User_Company)obj).getParentid().intValue() == this.deptid;
/*     */       }
/*     */     });
/* 164 */     v.add("" + DeptId);
/* 165 */     Iterator it = selCompany.keySet().iterator();
/* 166 */     while (it.hasNext())
/*     */     {
/* 168 */       Object obj = selCompany.get(it.next());
/* 169 */       if (obj != null)
/*     */       {
/* 172 */         delCompanyTree(((User_Company)obj).getDeptid().intValue(), v);
/*     */       }
/*     */     }
/* 175 */     selCompany = null;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.UserCompanyAdmin
 * JD-Core Version:    0.6.2
 */
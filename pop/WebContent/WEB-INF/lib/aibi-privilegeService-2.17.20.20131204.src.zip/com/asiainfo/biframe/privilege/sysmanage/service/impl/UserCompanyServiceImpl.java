/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.common.cache.CacheFilter;
/*     */ import com.asiainfo.biframe.exception.BaseRuntimeException;
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.privilege.base.util.BeanUtils;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCompanyCache;
/*     */ import com.asiainfo.biframe.privilege.model.User_Company;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserDeptDao;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserCompanyService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserCompanyServiceImpl
/*     */   implements IUserCompanyService
/*     */ {
/*  36 */   private Log log = LogFactory.getLog(UserCompanyServiceImpl.class);
/*     */   private IUserDeptDao userDeptDao;
/*     */ 
/*     */   public List<IUserCompany> getAllDept()
/*     */   {
/*     */     try
/*     */     {
/*  42 */       List ucList = new ArrayList();
/*  43 */       Collection collection = UserCompanyCache.getInstance().getAllCachedObject();
/*     */ 
/*  45 */       for (User_Company company : collection) {
/*  46 */         ucList.add(company);
/*     */       }
/*  48 */       return ucList;
/*     */     } catch (Exception e) {
/*  50 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getAllDeptFail") + "", e);
/*     */ 
/*  53 */       throw new BaseRuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getAllDeptFail") + ":" + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getUserCompanyByCityId(String cityId)
/*     */   {
/*     */     try
/*     */     {
/*  61 */       List ucList = new ArrayList();
/*  62 */       Collection collection = UserCompanyCache.getInstance().getAllCachedObject();
/*     */ 
/*  64 */       for (User_Company company : collection) {
/*  65 */         if (cityId.endsWith(company.getCityId())) {
/*  66 */           ucList.add(company);
/*     */         }
/*     */       }
/*  69 */       return ucList;
/*     */     } catch (Exception e) {
/*  71 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getAllDeptFail") + "", e);
/*     */ 
/*  74 */       throw new BaseRuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getAllDeptFail") + ":" + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public User_Company getUserCompany(String deptId)
/*     */   {
/*     */     try
/*     */     {
/*  82 */       return getUserDeptDao().getDeptById(deptId);
/*     */     } catch (Exception e) {
/*  84 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.byDept") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getDeptFail") + "", e);
/*  85 */       throw new BaseRuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.byDept") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getDeptFail") + ":" + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getUserCompanyName(String deptId)
/*     */   {
/*  93 */     User_Company company = getUserCompany(deptId);
/*  94 */     if (company == null) {
/*  95 */       return "";
/*     */     }
/*  97 */     return company.getName();
/*     */   }
/*     */ 
/*     */   public void doRealDeleteGroup(DeletedParameterVO vo)
/*     */   {
/*     */     try
/*     */     {
/* 105 */       this.log.debug(" in doRealDeleteGroup");
/*     */ 
/* 107 */       getUserDeptDao().doRealDelete(vo);
/*     */ 
/* 109 */       String logResourceId = vo.getIdString();
/* 110 */       if (StringUtils.isBlank(logResourceId)) {
/* 111 */         logResourceId = "resourceId";
/*     */       }
/*     */ 
/* 116 */       this.log.debug(" end doRealDeleteGroup");
/*     */     } catch (DaoException e) {
/* 118 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteDeptFail") + "", e);
/* 119 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteDeptFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<User_Company> getCompanyByName(String title)
/*     */   {
/* 127 */     return getUserDeptDao().getCompanyByName(title);
/*     */   }
/*     */ 
/*     */   public Map getPagedCompanyList(User_Company company, Integer currpage, Integer pagesize) {
/* 131 */     return getUserDeptDao().getpagedCompanyList(company, currpage.intValue(), pagesize.intValue());
/*     */   }
/*     */ 
/*     */   public IUserDeptDao getUserDeptDao() {
/* 135 */     return this.userDeptDao;
/*     */   }
/*     */ 
/*     */   public void setUserDeptDao(IUserDeptDao userDeptDao) {
/* 139 */     this.userDeptDao = userDeptDao;
/*     */   }
/*     */ 
/*     */   public String createCompany(IUserCompany company) throws ServiceException {
/* 143 */     User_Company userCompany = (User_Company)company;
/* 144 */     userCompany.setStatus("0");
/* 145 */     return getUserDeptDao().createCompany(userCompany);
/*     */   }
/*     */ 
/*     */   public void deleteCompany(String companyId) throws ServiceException {
/* 149 */     getUserDeptDao().deleteCompany(companyId);
/*     */   }
/*     */ 
/*     */   public void modifyCompany(IUserCompany newUserCompany) throws ServiceException
/*     */   {
/* 154 */     this.log.debug("in modifyCompany");
/*     */     try
/*     */     {
/* 157 */       if (newUserCompany == null) {
/* 158 */         return;
/*     */       }
/* 160 */       User_Company company = (User_Company)newUserCompany;
/* 161 */       User_Company userCompany = getUserCompany(newUserCompany.getDeptid().toString());
/*     */ 
/* 163 */       BeanUtils.copyProperties(userCompany, company);
/* 164 */       getUserDeptDao().modifyCompany(userCompany);
/*     */     } catch (Exception e) {
/* 166 */       e.printStackTrace();
/* 167 */       this.log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + ":" + e);
/* 168 */       if ((e instanceof SysmanageException)) {
/* 169 */         throw ((SysmanageException)e);
/*     */       }
/* 171 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyUserFail") + "!");
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getCompanyListByParentId(String parentDeptId)
/*     */     throws ServiceException
/*     */   {
/* 197 */     return new ArrayList(UserCompanyCache.getInstance().getObjectByCondition(new CacheFilter()
/*     */     {
/*     */       String deptId;
/*     */ 
/*     */       public boolean match(Object obj)
/*     */       {
/* 190 */         if (obj == null) return false;
/*     */ 
/* 192 */         String parentId = Integer.valueOf(((User_Company)obj).getParentid().intValue()).toString();
/* 193 */         return parentId.equals(this.deptId);
/*     */       }
/*     */     }).values());
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.UserCompanyServiceImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.model.UserExtInfo;
/*     */ import com.asiainfo.biframe.privilege.model.UserExtInfoDefine;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserExtInfoDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserExtInfoDefineDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserExtInfoService;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ public class UserExtInfoServiceImpl
/*     */   implements IUserExtInfoService
/*     */ {
/*     */   private IUserExtInfoDAO userExtInfoDao;
/*     */   private IUserExtInfoDefineDAO userExtInfoDefineDao;
/*     */ 
/*     */   public void setUserExtInfoDefineDao(IUserExtInfoDefineDAO userExtInfoDefineDao)
/*     */   {
/*  49 */     this.userExtInfoDefineDao = userExtInfoDefineDao;
/*     */   }
/*     */ 
/*     */   public void setUserExtInfoDao(IUserExtInfoDAO userExtInfoDao) {
/*  53 */     this.userExtInfoDao = userExtInfoDao;
/*     */   }
/*     */ 
/*     */   public void update(String userId, List<UserExtInfo> newExtInfoList)
/*     */     throws Exception
/*     */   {
/*  69 */     List originExtInfolist = findUserExtInfo(userId);
/*  70 */     HashMap infoValueMap = new HashMap();
/*  71 */     for (UserExtInfo extInfo : originExtInfolist) {
/*  72 */       infoValueMap.put(extInfo.getExtId(), extInfo);
/*     */     }
/*     */ 
/*  75 */     if ((newExtInfoList != null) && (newExtInfoList.size() > 0)) {
/*  76 */       for (UserExtInfo extInfo : newExtInfoList) {
/*  77 */         UserExtInfo oldExtInfo = (UserExtInfo)infoValueMap.get(extInfo.getExtId());
/*     */ 
/*  79 */         if (oldExtInfo != null) {
/*  80 */           String newExtInfoValue = extInfo.getExtValue();
/*  81 */           oldExtInfo.setExtValue(newExtInfoValue);
/*     */         }
/*     */       }
/*  83 */       if (infoValueMap.size() > 0)
/*  84 */         this.userExtInfoDao.saveOrUpdateAll(infoValueMap.values());
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<UserExtInfo> findUserExtInfo(String userId)
/*     */     throws Exception
/*     */   {
/* 100 */     List userInfoDefineList = this.userExtInfoDefineDao.findAll();
/* 101 */     List originInfolist = this.userExtInfoDao.findByUserId(userId);
/* 102 */     List infoList = new ArrayList();
/*     */ 
/* 104 */     HashMap infoValueMap = new HashMap();
/* 105 */     for (UserExtInfo extInfo : originInfolist) {
/* 106 */       infoValueMap.put(extInfo.getExtId(), extInfo);
/*     */     }
/* 108 */     for (UserExtInfoDefine extInfoDefine : userInfoDefineList) {
/* 109 */       UserExtInfo extInfo = (UserExtInfo)infoValueMap.get(extInfoDefine.getExtId());
/*     */ 
/* 111 */       if (extInfo != null) {
/* 112 */         extInfo.setDescription(extInfoDefine.getDescription());
/* 113 */         infoList.add(extInfo);
/*     */       }
/*     */       else {
/* 116 */         extInfo = new UserExtInfo(extInfoDefine.getExtId(), userId, extInfoDefine.getExtName(), "", extInfoDefine.getDescription());
/* 117 */         infoList.add(extInfo);
/*     */       }
/*     */     }
/* 120 */     return infoList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.UserExtInfoServiceImpl
 * JD-Core Version:    0.6.2
 */
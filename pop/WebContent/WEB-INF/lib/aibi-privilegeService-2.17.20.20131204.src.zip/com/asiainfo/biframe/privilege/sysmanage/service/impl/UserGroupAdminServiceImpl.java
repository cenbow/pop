/*      */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*      */ 
/*      */ import com.asiainfo.biframe.common.cache.CacheFilter;
/*      */ import com.asiainfo.biframe.exception.BaseRuntimeException;
/*      */ import com.asiainfo.biframe.exception.DaoException;
/*      */ import com.asiainfo.biframe.exception.ServiceException;
/*      */ import com.asiainfo.biframe.privilege.base.util.BeanUtils;
/*      */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*      */ import com.asiainfo.biframe.privilege.base.util.SpringUtil;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*      */ import com.asiainfo.biframe.privilege.cache.object.UserGroupDefineCache;
/*      */ import com.asiainfo.biframe.privilege.model.GroupRoleMap;
/*      */ import com.asiainfo.biframe.privilege.model.UserGroupMap;
/*      */ import com.asiainfo.biframe.privilege.model.UserRole;
/*      */ import com.asiainfo.biframe.privilege.model.User_Group;
/*      */ import com.asiainfo.biframe.privilege.model.User_User;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.comparator.RoleComparator;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IGroupRoleMapDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupMapDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserRoleDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserDAO;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*      */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*      */ import com.asiainfo.biframe.utils.date.DateUtil;
/*      */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import org.apache.commons.collections.CollectionUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class UserGroupAdminServiceImpl
/*      */   implements IUserGroupAdminService
/*      */ {
/*   61 */   protected Logger logger = Logger.getLogger(getClass());
/*      */   private IUserGroupDAO userGroupDao;
/*      */   private IUserUserDAO userUserDao;
/*      */   private IUserRoleDAO userRoleDao;
/*      */   private IUserGroupMapDAO userGroupMapDao;
/*      */   private IGroupRoleMapDAO groupRoleMapDao;
/*      */ 
/*      */   public String addUserGroup(User_Group userGroup)
/*      */   {
/*   70 */     this.logger.debug("in addUserGroup");
/*   71 */     if (userGroup == null) {
/*   72 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userGroupToSaveIsEmpty") + "!");
/*      */     }
/*   74 */     if (isUserGroupExists(userGroup.getGroupname())) {
/*   75 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupExist") + "!");
/*      */     }
/*      */ 
/*   78 */     userGroup.setCreatetime(Calendar.getInstance().getTime());
/*   79 */     if (userGroup.getStatus() == null) {
/*   80 */       userGroup.setStatus(Long.valueOf(0L));
/*      */     }
/*      */ 
/*   83 */     String userGroupId = this.userGroupDao.save(userGroup);
/*      */ 
/*   85 */     LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), userGroup.getGroupid(), userGroup.getGroupname(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.addGroup") + "", null, userGroup.toMap());
/*      */ 
/*   90 */     this.logger.debug("end addUserGroup,userGroupId:" + userGroupId);
/*   91 */     return userGroupId;
/*      */   }
/*      */ 
/*      */   public void updateUserGroup(User_Group newGroup) {
/*   95 */     this.logger.debug("in updateUserGroup");
/*   96 */     if (newGroup == null) {
/*   97 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userGroupIsEmpty") + "!");
/*      */     }
/*   99 */     User_Group realGroup = getUserGroup(newGroup.getGroupid());
/*  100 */     if (realGroup == null) {
/*  101 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userGroupCannotModify") + "");
/*      */     }
/*  103 */     if ((!newGroup.getGroupname().equals(realGroup.getGroupname())) && (isUserGroupExists(newGroup.getGroupname()))) {
/*  104 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupExist") + "!");
/*      */     }
/*      */ 
/*  107 */     LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), newGroup.getGroupid(), newGroup.getGroupname(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyGroup") + "", realGroup.toMap(), newGroup.toMap());
/*      */ 
/*  111 */     BeanUtils.copyProperties(realGroup, newGroup);
/*  112 */     realGroup.setCreatetime(Calendar.getInstance().getTime());
/*  113 */     this.userGroupDao.update(realGroup);
/*      */   }
/*      */ 
/*      */   public String cloneUserGroup(User_Group newGroup, String srcGroupId)
/*      */   {
/*  120 */     this.logger.debug("in cloneUserGroup");
/*      */     try {
/*  122 */       String groupId = addUserGroup(newGroup);
/*      */ 
/*  125 */       StringBuffer addedRoleIds = new StringBuffer(256);
/*  126 */       List srcGroupRoleMap = getGroupRoleMapDao().findGroupRoleMapByGroupId(srcGroupId);
/*  127 */       for (GroupRoleMap groupRoleMap : srcGroupRoleMap) {
/*  128 */         GroupRoleMap newMap = new GroupRoleMap(groupId, groupRoleMap.getRoleId());
/*  129 */         getGroupRoleMapDao().save(newMap);
/*      */ 
/*  131 */         addedRoleIds.append(groupRoleMap.getRoleId()).append(",");
/*      */       }
/*      */ 
/*  134 */       GroupRoleMap addedMap = new GroupRoleMap(groupId, addedRoleIds.toString());
/*  135 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), groupId, newGroup.getGroupname(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyGroup") + "", null, addedMap.toMap());
/*      */ 
/*  139 */       this.logger.debug("end cloneUserGroup");
/*  140 */       return groupId;
/*      */     } catch (Exception e) {
/*  142 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyGroupFail") + "", e);
/*  143 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.copyGroupFail") + ":" + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteUserGroup(User_Group userGroup)
/*      */   {
/*  152 */     this.logger.debug("in deleteUserGroup");
/*      */     try {
/*  154 */       if (userGroup == null) {
/*  155 */         throw new BaseRuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupIs") + "null");
/*      */       }
/*  157 */       String groupId = userGroup.getGroupid();
/*  158 */       if (StringUtils.isBlank(groupId)) {
/*  159 */         throw new BaseRuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userGroup") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.isEmpty2") + "");
/*      */       }
/*  161 */       if (groupId.equals("1")) {
/*  162 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.reservedGroupDeleteFail") + "");
/*      */       }
/*  164 */       boolean roleByUsed = roleByGroupUsed(groupId);
/*  165 */       if (roleByUsed) {
/*  166 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.roleCannotDelete") + "");
/*      */       }
/*  168 */       List subUserList = getUsersByGroupId(groupId);
/*  169 */       if ((subUserList != null) && (subUserList.size() > 0)) {
/*  170 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupHasUser") + "");
/*      */       }
/*  172 */       List subList = getAllSubUsersByGroupId(groupId);
/*  173 */       if ((subList != null) && (subList.size() > 0)) {
/*  174 */         throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.subGroupHasUser") + "");
/*      */       }
/*      */ 
/*  178 */       this.userGroupMapDao.deleteMapByGId(groupId);
/*  179 */       this.groupRoleMapDao.deleteMapByGId(groupId);
/*      */ 
/*  182 */       List subGroupList = getSubGroup(groupId);
/*  183 */       for (User_Group subGroup : subGroupList) {
/*  184 */         deleteUserGroup(subGroup);
/*      */       }
/*      */ 
/*  188 */       List createdRoleList = getUserRoleByCreateGroupId(groupId);
/*  189 */       for (UserRole role : createdRoleList) {
/*  190 */         getRoleAdminService().deleteRole(role);
/*      */       }
/*      */ 
/*  194 */       ListService.deleteBalanceServerRole(groupId + "!!deleteUserGroup", userGroup.getGroupname());
/*      */ 
/*  198 */       User_Group realGroup = getUserGroup(groupId);
/*  199 */       realGroup.setStatus(Long.valueOf("2"));
/*  200 */       realGroup.setDeleteTime(DateUtil.date2String(new Date(), "yyyy-MM-dd HH:mm:ss"));
/*  201 */       this.userGroupDao.update(realGroup);
/*      */ 
/*  208 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), userGroup.getGroupid(), userGroup.getGroupname(), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupUserRelation") + "", null, null);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  215 */       this.logger.error("deleteUserGroup " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*  216 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupFail2") + ":" + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void doAssignRoleToGroup(String groupId, List<String> addedRoleIdList, List<String> deletedRoleIdList) {
/*  221 */     this.logger.debug("in the doAssignRoleToGroup");
/*      */     try {
/*  223 */       if ((groupId == null) || (groupId.length() == 0)) {
/*  224 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.group") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.isEmpty") + "");
/*      */       }
/*      */ 
/*  228 */       StringBuffer deletedRoleIds = new StringBuffer(256);
/*  229 */       if (deletedRoleIdList != null) {
/*  230 */         for (String roleId : deletedRoleIdList) {
/*  231 */           UserRole userRole = getRoleAdminService().getRoleById(roleId);
/*      */ 
/*  234 */           if (getRoleAdminService().ifRoleUsedByCreateRole(userRole, groupId)) {
/*  235 */             throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.role") + "[" + userRole.getRoleName() + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.alreadyRefrenceByRole") + "!" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotDelete") + "");
/*      */           }
/*      */ 
/*  238 */           if (getRoleAdminService().ifRoleUsedBySubGroup(userRole, groupId)) {
/*  239 */             throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.role") + "[" + userRole.getRoleName() + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.alreadyRefrenceBySubGroup") + "!" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotDelete") + "");
/*      */           }
/*      */ 
/*  242 */           deleteGroupRoleMap(groupId, roleId);
/*  243 */           deletedRoleIds.append(roleId).append(",");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  248 */       StringBuffer addedRoleIds = new StringBuffer(256);
/*  249 */       if (addedRoleIdList != null) {
/*  250 */         for (int i = 0; i < addedRoleIdList.size(); i++)
/*      */         {
/*  252 */           String roleId = (String)addedRoleIdList.get(i);
/*      */ 
/*  259 */           saveGroupRoleMap(groupId, roleId);
/*  260 */           addedRoleIds.append(roleId).append(",");
/*      */         }
/*      */       }
/*  263 */       String groupName = getGroupName(groupId);
/*  264 */       if ((deletedRoleIdList != null) && (!deletedRoleIdList.isEmpty())) {
/*  265 */         GroupRoleMap deletedMap = new GroupRoleMap(groupId, deletedRoleIds.toString());
/*  266 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), groupId, groupName, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrDeleteGroupRoleRelation") + "", null, deletedMap.toMap());
/*      */       }
/*      */ 
/*  270 */       if ((addedRoleIdList != null) && (!addedRoleIdList.isEmpty())) {
/*  271 */         GroupRoleMap addedMap = new GroupRoleMap(groupId, addedRoleIds.toString());
/*  272 */         LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), groupId, groupName, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrAddGroupRoleRelation") + "", null, addedMap.toMap());
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  278 */       this.logger.debug("doAssignRoleToGroup " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*  279 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveGroupRoleMapFail") + "" + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*  283 */   private void saveGroupRoleMap(String groupId, String roleId) { GroupRoleMap groupRoleMap = new GroupRoleMap(groupId, roleId);
/*  284 */     getGroupRoleMapDao().save(groupRoleMap); }
/*      */ 
/*      */   private void deleteGroupRoleMap(String groupId, String roleId)
/*      */   {
/*  288 */     GroupRoleMap groupRoleMap = new GroupRoleMap(groupId, roleId);
/*  289 */     getGroupRoleMapDao().delete(groupRoleMap);
/*      */   }
/*      */ 
/*      */   public void saveGroupUserMap(String groupId, List<String> useridList) {
/*  293 */     this.logger.debug("in the saveGroupUserMap");
/*      */     try {
/*  295 */       if ((groupId == null) || (groupId.length() == 0)) {
/*  296 */         throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.group") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.isEmpty") + "");
/*      */       }
/*  298 */       this.userGroupMapDao.deleteMapByGId(groupId);
/*      */ 
/*  300 */       if ((useridList == null) || (useridList.size() == 0)) {
/*  301 */         return;
/*      */       }
/*  303 */       StringBuffer userIds = new StringBuffer(256);
/*  304 */       for (int i = 0; i < useridList.size(); i++) {
/*  305 */         String userId = (String)useridList.get(i);
/*  306 */         this.userGroupMapDao.deleteMapByUserId(userId);
/*      */ 
/*  308 */         UserGroupMap userGroupMap = new UserGroupMap(userId, groupId);
/*  309 */         this.userGroupMapDao.save(userGroupMap);
/*  310 */         userIds.append(userId).append(",");
/*      */       }
/*  312 */       UserGroupMap map = new UserGroupMap(userIds.toString(), groupId);
/*  313 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_UPDATE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), groupId, getGroupName(groupId), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyGroupUserMap") + "", null, map.toMap());
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  317 */       this.logger.debug("saveGroupUserMap " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*  318 */       throw new RuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveGroupUserMapFail") + ":" + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void doAssignUsersToGroup(String groupId, Collection<String> addedUserIds, Collection<String> deletedUserIds)
/*      */   {
/*  326 */     this.logger.debug("--in doAssignUsersToGroup");
/*      */ 
/*  328 */     if ((deletedUserIds != null) && (!deletedUserIds.isEmpty())) {
/*  329 */       for (String userId : deletedUserIds) {
/*  330 */         getUserGroupMapDao().deleteMapByUserId(userId);
/*      */       }
/*      */ 
/*  333 */       UserGroupMap deletedMap = new UserGroupMap(StringUtils.join(deletedUserIds.iterator(), ","), groupId);
/*  334 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), groupId, getGroupName(groupId), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrDeleteGroupRoleRelation"), null, deletedMap.toMap());
/*      */     }
/*      */ 
/*  338 */     if ((addedUserIds != null) && (!addedUserIds.isEmpty())) {
/*  339 */       for (String userId : addedUserIds)
/*      */       {
/*  341 */         getUserGroupMapDao().deleteMapByUserId(userId);
/*  342 */         UserGroupMap map = new UserGroupMap(userId, groupId);
/*  343 */         getUserGroupMapDao().save(map);
/*      */       }
/*  345 */       UserGroupMap addedMap = new UserGroupMap(StringUtils.join(addedUserIds.iterator(), ","), groupId);
/*  346 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_ADD"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USERGROUP"), groupId, getGroupName(groupId), "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.incrAddGroupUserMap") + "", null, addedMap.toMap());
/*      */     }
/*      */ 
/*  350 */     this.logger.debug("--end doAssignUsersToGroup");
/*      */   }
/*      */ 
/*      */   public User_Group getUserGroup(String groupId) {
/*  354 */     this.logger.debug("in getUserGroup");
/*  355 */     User_Group userG = new User_Group();
/*      */     try {
/*  357 */       userG = this.userGroupDao.findById(groupId);
/*      */     } catch (Exception e) {
/*  359 */       this.logger.debug(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getGroupByIdFail"), e);
/*  360 */       throw new SysmanageException();
/*      */     }
/*  362 */     return userG;
/*      */   }
/*      */   public List<User_Group> getUserGroupByName(String groupName) {
/*  365 */     return this.userGroupDao.findByGroupName(groupName);
/*      */   }
/*      */ 
/*      */   public boolean isUserGroupExists(String userGroupname)
/*      */   {
/*  371 */     this.logger.debug("in isUserGroupExists userGroupname:" + userGroupname);
/*  372 */     User_Group ug = new User_Group();
/*      */     try {
/*  374 */       ug.setGroupname(userGroupname);
/*  375 */       List list = this.userGroupDao.findAll(ug);
/*  376 */       if ((list.size() > 0) && (list != null))
/*  377 */         return true;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  381 */       this.logger.error("isUserGroupExists " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  384 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.judgeUserExistFail") + "");
/*      */     }
/*  386 */     return false;
/*      */   }
/*      */ 
/*      */   public List<UserRole> getAllUserRoleByGroupId(String groupId)
/*      */   {
/*      */     try
/*      */     {
/*  394 */       Set roleSet = new HashSet();
/*  395 */       roleSet.addAll(getUserRoleByCreateGroupId(groupId));
/*  396 */       roleSet.addAll(getRoleListByGroupId(groupId));
/*      */ 
/*  398 */       List roleList = new ArrayList();
/*  399 */       CollectionUtils.addAll(roleList, roleSet.iterator());
/*  400 */       return roleList;
/*      */     } catch (Exception e) {
/*  402 */       this.logger.error("getAllUserRoleByGroupId " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  405 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getGroupAllRoleFail") + "");
/*      */   }
/*      */ 
/*      */   public Collection<UserRole> getAllUserRoles(List<User_Group> groupList)
/*      */   {
/*  410 */     Set roleSet = new HashSet();
/*      */     try {
/*  412 */       if ((groupList != null) && (groupList.size() > 0))
/*  413 */         for (int j = 0; j < groupList.size(); j++) {
/*  414 */           List roleList = getAllUserRoleByGroupId(((User_Group)groupList.get(j)).getGroupid());
/*  415 */           roleSet.addAll(roleList);
/*      */         }
/*      */     }
/*      */     catch (Exception e) {
/*  419 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserGroupFail") + ",:" + e);
/*  420 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserGroupFail") + "");
/*      */     }
/*  422 */     return roleSet;
/*      */   }
/*      */ 
/*      */   public List<UserRole> getUserRoleByCreateGroupId(String groupid) {
/*  426 */     this.logger.debug("in getUserRoleByCreateGroupId");
/*  427 */     List list = new ArrayList();
/*      */     try {
/*  429 */       list = this.userRoleDao.findByCreateGroup(groupid);
/*      */     } catch (Exception e) {
/*  431 */       this.logger.error("getUserRoleByCreateGroupId " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*  432 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getGroupRoleFail") + "");
/*      */     }
/*  434 */     return list;
/*      */   }
/*      */ 
/*      */   public Collection<UserRole> getUserRolesByCreateGroupIds(Collection<String> groupIdList)
/*      */   {
/*  442 */     Collection roleSet = new TreeSet(new RoleComparator());
/*  443 */     for (String groupId : groupIdList) {
/*  444 */       roleSet.addAll(getUserRoleByCreateGroupId(groupId));
/*      */     }
/*  446 */     return roleSet;
/*      */   }
/*      */ 
/*      */   public List<UserRole> getAllRolesByCreateGroupId(String groupId)
/*      */   {
/*  453 */     this.logger.debug("in getAllRolesByCreateGroupId");
/*      */     try
/*      */     {
/*  456 */       List allSubGroup = getAllSubGroupIds(groupId);
/*  457 */       allSubGroup.add(groupId);
/*      */ 
/*  459 */       List roleList = this.userRoleDao.findByCreateGroupList(allSubGroup);
/*  460 */       this.logger.debug("end getAllRolesByCreateGroupId");
/*  461 */       return roleList;
/*      */     } catch (Exception e) {
/*  463 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRoleOfGroupsFail") + ":" + e);
/*  464 */     }throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRoleOfGroupsFail") + "!");
/*      */   }
/*      */ 
/*      */   public List<String> getRoleIdListByCreateGroupId(String groupid)
/*      */   {
/*  471 */     this.logger.debug("in getUserRoleByGroupId");
/*  472 */     List idList = new ArrayList();
/*  473 */     List list = new ArrayList();
/*      */     try {
/*  475 */       list = this.userRoleDao.findByCreateGroup(groupid);
/*  476 */       if ((list == null) || (list.size() == 0)) {
/*  477 */         return new ArrayList();
/*      */       }
/*      */ 
/*  480 */       for (int i = 0; i < list.size(); i++)
/*  481 */         idList.add(((UserRole)list.get(i)).getRoleId());
/*      */     }
/*      */     catch (Exception e) {
/*  484 */       this.logger.debug("getUserRoleByGroupId " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*  485 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getGroupRoleFail") + "");
/*      */     }
/*  487 */     return idList;
/*      */   }
/*      */ 
/*      */   public List<UserRole> getRoleListByGroupId(String groupId) {
/*  491 */     if (isAdminGroup(groupId)) {
/*  492 */       return getUserRoleDao().findAllRoles();
/*      */     }
/*  494 */     return this.groupRoleMapDao.findRoleListByGroupId(groupId);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public boolean haveRole(String groupid, int roleType)
/*      */   {
/*  503 */     if (groupid.equals("1")) {
/*  504 */       return true;
/*      */     }
/*      */ 
/*  507 */     List list = getRoleListByGroupId(groupid);
/*  508 */     if ((list == null) || (list.size() == 0)) {
/*  509 */       return false;
/*      */     }
/*      */ 
/*  512 */     for (int i = 0; i < list.size(); i++) {
/*  513 */       UserRole role = (UserRole)list.get(i);
/*  514 */       if (role.getRoleType() == roleType) {
/*  515 */         return true;
/*      */       }
/*      */     }
/*  518 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean haveCityRight(String groupId) {
/*  522 */     List cityRightList = getRightByGroup(groupId, 0, Integer.valueOf("5").intValue(), false);
/*  523 */     if ((cityRightList == null) || (cityRightList.isEmpty())) {
/*  524 */       return false;
/*      */     }
/*  526 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean roleByGroupUsed(String groupId)
/*      */   {
/*      */     try
/*      */     {
/*  534 */       List cretatRoleList = getUserRoleByCreateGroupId(groupId);
/*      */ 
/*  536 */       for (UserRole role : cretatRoleList) {
/*  537 */         List userList = getRoleAdminService().getUsersByRoleId(role.getRoleId());
/*  538 */         if (!userList.isEmpty()) {
/*  539 */           return true;
/*      */         }
/*  541 */         List groupList = getRoleAdminService().getGroupsByRoleId(role.getRoleId());
/*  542 */         if (!groupList.isEmpty()) {
/*  543 */           return true;
/*      */         }
/*      */       }
/*  546 */       return false;
/*      */     } catch (Exception e) {
/*  548 */       this.logger.error("roleByGroupUsed " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  551 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.judgeGroupRoleInUserFail") + "");
/*      */   }
/*      */ 
/*      */   public Map getPagedUserGroupList(User_Group group, Integer currpage, Integer pagesize)
/*      */   {
/*  560 */     this.logger.debug("in getPagedUserGroupList");
/*      */ 
/*  562 */     Map map = new HashMap();
/*      */     try {
/*  564 */       map = this.userGroupDao.getPagedUserList(group, currpage.intValue(), pagesize.intValue());
/*      */ 
/*  566 */       Iterator iter = ((List)map.get("result")).iterator();
/*  567 */       List list = new ArrayList();
/*  568 */       while (iter.hasNext()) {
/*  569 */         User_Group newGroup = (User_Group)iter.next();
/*      */ 
/*  571 */         String parentName = UserGroupDefineCache.getInstance().getNameByKey(newGroup.getParentid());
/*  572 */         if (StringUtils.isBlank(parentName)) {
/*  573 */           parentName = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.unknown") + "";
/*      */         }
/*  575 */         newGroup.setParentName(parentName);
/*  576 */         list.add(newGroup);
/*      */       }
/*  578 */       map.remove("result");
/*  579 */       map.put("result", list);
/*      */     } catch (Exception e) {
/*  581 */       this.logger.debug("getPagedUserGroupList " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*  582 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getPageDataFail") + "");
/*      */     }
/*  584 */     return map;
/*      */   }
/*      */ 
/*      */   public List<User_Group> getAllUserGroup(User_Group group) {
/*  588 */     this.logger.debug("in getAllUserGroup");
/*  589 */     List ugList = null;
/*      */     try {
/*  591 */       ugList = this.userGroupDao.findAll(group);
/*      */     } catch (Exception e) {
/*  593 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getGroupByConditionFail") + "");
/*      */     }
/*  595 */     return ugList;
/*      */   }
/*      */ 
/*      */   public List<User_Group> getUserGroupByIds(List<String> groupIds)
/*      */   {
/*  600 */     List list = null;
/*  601 */     User_Group group = new User_Group();
/*  602 */     if ((groupIds != null) && (groupIds.size() > 0)) {
/*  603 */       String queryGroupids = StringUtil.list2String(groupIds, ",", true);
/*  604 */       group.setGroupids(queryGroupids);
/*      */ 
/*  606 */       list = getAllUserGroup(group);
/*      */     }
/*      */ 
/*  609 */     return list;
/*      */   }
/*      */ 
/*      */   public String getGroupName(String groupid)
/*      */   {
/*  614 */     String groupName = "";
/*  615 */     User_Group ug = getUserGroup(groupid);
/*  616 */     if (ug != null) {
/*  617 */       groupName = ug.getGroupname();
/*      */     }
/*  619 */     return groupName;
/*      */   }
/*      */ 
/*      */   public User_Group getParentGroup(String groupid) {
/*  623 */     String parentId = "";
/*  624 */     User_Group ug = getUserGroup(groupid);
/*  625 */     if (ug != null) {
/*  626 */       parentId = ug.getParentid();
/*      */     }
/*  628 */     return getUserGroup(parentId);
/*      */   }
/*      */ 
/*      */   public List<User_Group> getParentGroups(String groupid) {
/*  632 */     List list = new ArrayList();
/*  633 */     User_Group ug = getUserGroup(groupid);
/*  634 */     while ((ug != null) && (!ug.getParentid().trim().equals("0"))) {
/*  635 */       ug = getParentGroup(ug.getGroupid());
/*  636 */       list.add(ug);
/*      */     }
/*  638 */     return list;
/*      */   }
/*      */ 
/*      */   public List<User_Group> getAllSubGroup(String groupid)
/*      */   {
/*  645 */     this.logger.debug("in getAllSubGroup");
/*  646 */     User_Group searchGroup = new User_Group();
/*  647 */     searchGroup.setStatus(Long.valueOf("0"));
/*      */ 
/*  649 */     return getGroupByGroupObject(groupid, searchGroup);
/*      */   }
/*      */ 
/*      */   private List<User_Group> getGroupByGroupObject(String groupid, User_Group searchGroup) {
/*  653 */     List allGroupList = this.userGroupDao.findAll(searchGroup);
/*      */ 
/*  655 */     List subGroupList = new ArrayList();
/*  656 */     if ((allGroupList != null) && (allGroupList.size() > 0)) {
/*  657 */       for (int i = 0; i < allGroupList.size(); i++) {
/*  658 */         User_Group ug = (User_Group)allGroupList.get(i);
/*  659 */         List parentIds = getParentIds(allGroupList, "0", ug.getGroupid());
/*  660 */         if (parentIds.contains(groupid)) {
/*  661 */           subGroupList.add(ug);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  666 */     return subGroupList;
/*      */   }
/*      */ 
/*      */   public List<User_Group> getAllSubGroup2(String groupid) {
/*  670 */     this.logger.debug("in getAllSubGroup");
/*      */ 
/*  672 */     return getGroupByGroupObject(groupid, new User_Group());
/*      */   }
/*      */ 
/*      */   public List<User_Group> getAllSubGroupByCache(String groupId)
/*      */   {
/*  679 */     Collection allGroupList = UserGroupDefineCache.getInstance().getAllGroupsSortedByName();
/*  680 */     List groupList = new ArrayList();
/*  681 */     if (isAdminGroup(groupId)) {
/*  682 */       for (User_Group group : allGroupList)
/*  683 */         if (Long.parseLong("0") == group.getStatus().longValue())
/*      */         {
/*  686 */           groupList.add(group);
/*      */         }
/*  688 */       return groupList;
/*      */     }
/*  690 */     for (User_Group group : allGroupList) {
/*  691 */       if (Long.parseLong("0") == group.getStatus().longValue())
/*      */       {
/*  694 */         if (group.getAllParentId().contains(groupId)) {
/*  695 */           groupList.add(group);
/*      */         }
/*      */       }
/*      */     }
/*  699 */     return groupList;
/*      */   }
/*      */ 
/*      */   public List<String> getAllSubGroupIds(String groupid) {
/*  703 */     List list = new ArrayList();
/*  704 */     List allUg = getAllSubGroup(groupid);
/*  705 */     if ((allUg != null) && (allUg.size() > 0)) {
/*  706 */       for (int i = 0; i < allUg.size(); i++) {
/*  707 */         User_Group ug = (User_Group)allUg.get(i);
/*  708 */         list.add(ug.getGroupid());
/*      */       }
/*      */     }
/*  711 */     return list;
/*      */   }
/*      */ 
/*      */   public List<User_Group> getSubGroup(String groupid) {
/*  715 */     this.logger.debug("in getSubGroup");
/*  716 */     List list = new ArrayList();
/*  717 */     User_Group uGroup = new User_Group();
/*  718 */     uGroup.setParentid(groupid);
/*  719 */     uGroup.setStatus(Long.valueOf("0"));
/*      */     try {
/*  721 */       list = this.userGroupDao.findAll(uGroup);
/*      */     } catch (Exception e) {
/*  723 */       this.logger.error("getSubGroup " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/*  726 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getGroupByConditionFail") + "");
/*      */     }
/*  728 */     return list;
/*      */   }
/*      */ 
/*      */   public List<User_Group> getSubGroupByCache(String groupId)
/*      */   {
/*  735 */     Collection allGroupList = UserGroupDefineCache.getInstance().getAllGroupsSortedByName();
/*  736 */     List groupList = new ArrayList();
/*  737 */     for (User_Group group : allGroupList) {
/*  738 */       if (Long.parseLong("0") == group.getStatus().longValue())
/*      */       {
/*  741 */         if (group.getParentid().equals(groupId))
/*  742 */           groupList.add(group);
/*      */       }
/*      */     }
/*  745 */     return groupList;
/*      */   }
/*      */ 
/*      */   public List<User_User> getUsersByGroupId(String groupId) {
/*  749 */     this.logger.debug("in getUserByGrouoId");
/*      */     try {
/*  751 */       return this.userGroupMapDao.findAllUserByGId(groupId);
/*      */     } catch (Exception e) {
/*  753 */       this.logger.error("getUsersByGroupId " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */     }
/*      */ 
/*  756 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserByConditionFail") + "");
/*      */   }
/*      */ 
/*      */   public List<User_User> getUsersByGroupIdByCache(String groupId)
/*      */   {
/*  763 */     Collection allUserList = UserCache.getInstance().getAllUsersSortedByName();
/*  764 */     List userList = new ArrayList();
/*  765 */     for (User_User user : allUserList) {
/*  766 */       if (Integer.parseInt("2") != user.getStatus())
/*      */       {
/*  769 */         if (groupId.equals(user.getGroupId()))
/*  770 */           userList.add(user);
/*      */       }
/*      */     }
/*  773 */     return userList;
/*      */   }
/*      */ 
/*      */   public List<User_User> getUsersByGroupIdByCache(String groupId, int userStatus)
/*      */   {
/*  781 */     Collection allUserList = UserCache.getInstance().getAllUsersSortedByName();
/*  782 */     List userList = new ArrayList();
/*  783 */     for (User_User user : allUserList) {
/*  784 */       if (userStatus == user.getStatus())
/*      */       {
/*  787 */         if (groupId.equals(user.getGroupId()))
/*  788 */           userList.add(user);
/*      */       }
/*      */     }
/*  791 */     return userList;
/*      */   }
/*      */ 
/*      */   public List<String> getParentIds(List<User_Group> list, String topId, String id)
/*      */   {
/*  797 */     List result = new ArrayList();
/*  798 */     User_Group ugBean = getById(list, id);
/*  799 */     while ((ugBean != null) && 
/*  800 */       (!ugBean.getParentid().equals(topId)))
/*      */     {
/*  802 */       result.add(ugBean.getParentid());
/*  803 */       ugBean = getById(list, ugBean.getParentid());
/*      */     }
/*  805 */     return result;
/*      */   }
/*      */ 
/*      */   public User_Group getById(List<User_Group> list, String id)
/*      */   {
/*  810 */     for (int i = 0; i < list.size(); i++) {
/*  811 */       User_Group ugBean = (User_Group)list.get(i);
/*  812 */       if (ugBean.getGroupid().equals(id)) {
/*  813 */         return ugBean;
/*      */       }
/*      */     }
/*  816 */     return null;
/*      */   }
/*      */ 
/*      */   public List<User_Group> getAllParentGroup(String groupid, List<User_Group> parentList, Map<String, User_Group> allGroup)
/*      */   {
/*  829 */     User_Group currGroup = this.userGroupDao.getUserGroup(groupid);
/*      */     List list;
/*  831 */     if ((null != currGroup.getParentid()) && (!currGroup.getParentid().equals("0"))) {
/*  832 */       parentList.add(allGroup.get(currGroup.getParentid()));
/*  833 */       list = getAllParentGroup(currGroup.getParentid(), parentList, allGroup);
/*      */     }
/*  835 */     return parentList;
/*      */   }
/*      */ 
/*      */   public List<User_Group> getAllNeighbourGroup(String groupid, List<User_Group> allGroup)
/*      */   {
/*  846 */     User_Group currGroup = this.userGroupDao.getUserGroup(groupid);
/*  847 */     List list = new ArrayList();
/*  848 */     if ((null != allGroup) && (allGroup.size() > 0)) {
/*  849 */       for (int i = 0; i < allGroup.size(); i++) {
/*  850 */         User_Group group = (User_Group)allGroup.get(i);
/*  851 */         if ((currGroup.getParentid().equals(group.getParentid())) && (!currGroup.getGroupid().equals(group.getGroupid()))) {
/*  852 */           list.add(group);
/*      */         }
/*      */       }
/*      */     }
/*  856 */     return list;
/*      */   }
/*      */ 
/*      */   public List<User_User> getAllSubUsersByGroupId(String groupId)
/*      */   {
/*  864 */     if (groupId.equals("1"))
/*  865 */       return this.userUserDao.findAll(new SearchCondition());
/*      */     try
/*      */     {
/*  868 */       List userList = new ArrayList();
/*      */ 
/*  870 */       List subGroupIdList = getAllSubGroupIds(groupId);
/*      */       String groupids;
/*  871 */       if ((subGroupIdList != null) && (subGroupIdList.size() > 0))
/*  872 */         groupids = StringUtil.list2String(subGroupIdList, ",", true);
/*  873 */       return this.userGroupMapDao.getAllByGroupId(groupids);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  877 */       this.logger.error("getSubUsersByGroupId " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*  878 */     }throw new SysmanageException(groupId + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getSubUserFail") + "");
/*      */   }
/*      */ 
/*      */   public List<User_User> getAllSubUsersByGroupIdByCache(String groupid)
/*      */   {
/*  886 */     Map allUserTable = UserCache.getInstance().getObjectByCondition(new CacheFilter()
/*      */     {
/*      */       public boolean match(Object obj) {
/*  889 */         if (Integer.parseInt("2") != ((User_User)obj).getStatus()) {
/*  890 */           return true;
/*      */         }
/*  892 */         return false;
/*      */       }
/*      */     });
/*  896 */     Collection allUserList = allUserTable.values();
/*      */ 
/*  898 */     List userList = new ArrayList();
/*  899 */     if (isAdminGroup(groupid)) {
/*  900 */       CollectionUtils.addAll(userList, allUserList.iterator());
/*  901 */       return userList;
/*      */     }
/*      */ 
/*  904 */     User_Group currentGroup = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(groupid);
/*  905 */     for (User_User user : allUserList)
/*  906 */       if (user.getStatus() != Integer.parseInt("2"))
/*      */       {
/*  909 */         User_Group group = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(user.getGroupId());
/*  910 */         if (group != null)
/*      */         {
/*  913 */           if (group.getAllParentId().contains(currentGroup.getGroupid()))
/*  914 */             userList.add(user);
/*      */         }
/*      */       }
/*  917 */     return userList;
/*      */   }
/*      */ 
/*      */   public List<User_User> getDirectSubUsersByGroupId(String groupId)
/*      */   {
/*      */     try
/*      */     {
/*  925 */       List userList = new ArrayList();
/*      */ 
/*  927 */       List subGroupList = getSubGroup(groupId);
/*  928 */       List subGroupIdList = new ArrayList();
/*  929 */       for (User_Group group : subGroupList)
/*  930 */         subGroupIdList.add(group.getGroupid());
/*      */       String groupids;
/*  932 */       if ((subGroupIdList != null) && (subGroupIdList.size() > 0))
/*  933 */         groupids = StringUtil.list2String(subGroupIdList, ",", true);
/*  934 */       return this.userGroupMapDao.getAllByGroupId(groupids);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  938 */       this.logger.error("getSubUsersByGroupId " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*  939 */     }throw new SysmanageException(groupId + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getSubUserFail") + "");
/*      */   }
/*      */ 
/*      */   public List<User_User> getDirectSubUsersByGroupIdByCache(String groupid)
/*      */   {
/*  947 */     Collection allUserList = UserCache.getInstance().getAllUsersSortedByName();
/*  948 */     List userList = new ArrayList();
/*  949 */     for (User_User user : allUserList)
/*  950 */       if (Integer.parseInt("0") == user.getStatus())
/*      */       {
/*  953 */         User_Group group = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(user.getGroupId());
/*  954 */         if (group != null)
/*      */         {
/*  957 */           if (group.getParentid().equals(groupid))
/*  958 */             userList.add(user);
/*      */         }
/*      */       }
/*  961 */     return userList;
/*      */   }
/*      */ 
/*      */   public String getSubGroupids(String groupId) {
/*      */     try {
/*  966 */       String groupIds = "";
/*  967 */       if ((groupId == null) || (groupId.trim().length() == 0)) {
/*  968 */         return "'-99999'";
/*      */       }
/*  970 */       List subList = getAllSubGroup(groupId);
/*  971 */       if ((subList != null) && (subList.size() > 0)) {
/*  972 */         for (int i = 0; i < subList.size(); i++) {
/*  973 */           User_Group ug = (User_Group)subList.get(i);
/*  974 */           groupIds = groupIds + "'" + ug.getGroupid() + "',";
/*      */         }
/*  976 */         groupIds = groupIds.substring(0, groupIds.length() - 1);
/*      */       }
/*      */ 
/*  979 */       if ((groupIds == null) || (groupIds.trim().length() == 0));
/*  980 */       return "'-99999'";
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  984 */       this.logger.error("getSubGroupids " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*  985 */     }throw new SysmanageException(groupId + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getSubGroupFail") + "");
/*      */   }
/*      */ 
/*      */   public List<Right> getRightByGroup(String groupId, int roleType, int resourceType, boolean isDistinctControlType)
/*      */   {
/*      */     try
/*      */     {
/*  996 */       if (isAdminGroup(groupId)) {
/*  997 */         return getRoleAdminService().getAllRights(roleType, resourceType);
/*      */       }
/*      */ 
/* 1001 */       List roleList = getRoleListByGroupId(groupId);
/* 1002 */       if ((roleList == null) || (roleList.size() == 0)) {
/* 1003 */         return new ArrayList();
/*      */       }
/*      */ 
/* 1006 */       List roleIdList = ListService.convertToNewList(roleList, "RoleId");
/*      */ 
/* 1008 */       return getRoleAdminService().getRightsByRoleIdList(roleIdList, roleType, resourceType, isDistinctControlType);
/*      */     } catch (Exception e) {
/* 1010 */       this.logger.error("getRightByGroup " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/* 1011 */     }throw new SysmanageException(groupId + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getGroupRightFail") + "");
/*      */   }
/*      */ 
/*      */   public boolean isAdminGroup(String groupId)
/*      */   {
/* 1016 */     if ("1".equals(groupId)) {
/* 1017 */       return true;
/*      */     }
/* 1019 */     return false;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public List<String> getRoleIdListByGroupId(String groupId, int roleType, int resourceType)
/*      */   {
/* 1026 */     return getGroupRoleMapDao().findRoleIdListByGroupId(groupId, roleType, resourceType);
/*      */   }
/*      */ 
/*      */   public List<String> getRoleIdListByGroupId(String groupId) {
/* 1030 */     return getGroupRoleMapDao().findRoleIdListByGroupId(groupId);
/*      */   }
/*      */ 
/*      */   public List<UserRole> getRoleListByGroupId(String groupId, int roleType, int resourceType)
/*      */   {
/* 1042 */     this.logger.debug("in getRoleListByGroupId");
/* 1043 */     return getGroupRoleMapDao().findRoleListByGroupId(groupId, roleType, resourceType);
/*      */   }
/*      */ 
/*      */   public boolean isParentGroupByCache(String parentGroupId, String groupId)
/*      */   {
/* 1050 */     User_Group group = (User_Group)UserGroupDefineCache.getInstance().getObjectByKey(groupId);
/* 1051 */     if (group == null) {
/* 1052 */       return false;
/*      */     }
/* 1054 */     return group.getAllParentId().contains(parentGroupId);
/*      */   }
/*      */ 
/*      */   public Collection<User_Group> getBrotherGroups(String groupId)
/*      */   {
/* 1062 */     User_Group parentGroup = getParentGroup(groupId);
/* 1063 */     List brotherGroupList = getSubGroup(parentGroup.getGroupid());
/* 1064 */     for (Iterator it = brotherGroupList.iterator(); it.hasNext(); ) {
/* 1065 */       User_Group group = (User_Group)it.next();
/* 1066 */       if (group.getGroupid().equals(groupId)) {
/* 1067 */         it.remove();
/* 1068 */         break;
/*      */       }
/*      */     }
/*      */ 
/* 1072 */     return brotherGroupList;
/*      */   }
/*      */ 
/*      */   public IUserGroupDAO getUserGroupDao() {
/* 1076 */     return this.userGroupDao;
/*      */   }
/*      */ 
/*      */   public void setUserGroupDao(IUserGroupDAO userGroupDao) {
/* 1080 */     this.userGroupDao = userGroupDao;
/*      */   }
/*      */ 
/*      */   public IUserGroupMapDAO getUserGroupMapDao() {
/* 1084 */     return this.userGroupMapDao;
/*      */   }
/*      */ 
/*      */   public void setUserGroupMapDao(IUserGroupMapDAO userGroupMapDao) {
/* 1088 */     this.userGroupMapDao = userGroupMapDao;
/*      */   }
/*      */ 
/*      */   public IGroupRoleMapDAO getGroupRoleMapDao() {
/* 1092 */     return this.groupRoleMapDao;
/*      */   }
/*      */ 
/*      */   public void setGroupRoleMapDao(IGroupRoleMapDAO groupRoleMapDao) {
/* 1096 */     this.groupRoleMapDao = groupRoleMapDao;
/*      */   }
/*      */ 
/*      */   public IUserRoleDAO getUserRoleDao() {
/* 1100 */     return this.userRoleDao;
/*      */   }
/*      */ 
/*      */   public void setUserRoleDao(IUserRoleDAO userRoleDao) {
/* 1104 */     this.userRoleDao = userRoleDao;
/*      */   }
/*      */ 
/*      */   public IUserUserDAO getUserUserDao() {
/* 1108 */     return this.userUserDao;
/*      */   }
/*      */ 
/*      */   public void setUserUserDao(IUserUserDAO userUserDao) {
/* 1112 */     this.userUserDao = userUserDao;
/*      */   }
/*      */ 
/*      */   private IRoleAdminService getRoleAdminService() {
/* 1116 */     return (IRoleAdminService)SpringUtil.getBean("right_roleAdminService");
/*      */   }
/*      */   private IUserAdminService getUserAdminService() {
/* 1119 */     return (IUserAdminService)SpringUtil.getBean("right_userAdminService");
/*      */   }
/*      */ 
/*      */   public void doRealDeleteGroup(DeletedParameterVO paraObject) throws ServiceException {
/*      */     try {
/* 1124 */       this.logger.debug(" in doRealDeleteGroup");
/*      */ 
/* 1129 */       this.userRoleDao.doRealDeleteByCreateGroup(paraObject);
/*      */ 
/* 1132 */       String groupName = this.userGroupDao.doRealDelete(paraObject);
/*      */ 
/* 1137 */       String logResourceId = "resourceId";
/* 1138 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_DELETE"), LogDetailUtil.getLogDefineValue(2, "LOGTYPE_USER"), logResourceId, groupName, "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteUserGroup") + "", null, null);
/*      */ 
/* 1141 */       this.logger.debug(" end doRealDeleteGroup");
/*      */     } catch (DaoException e) {
/* 1143 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupFail") + "", e);
/* 1144 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteGroupFail") + "", e);
/*      */     }
/*      */   }
/*      */ 
/* 1148 */   public List getUserGroupByTime(String startTime, String endTime) throws ServiceException { List list = new ArrayList();
/*      */     try {
/* 1150 */       list = this.userGroupDao.getUserGroupByTime(startTime, endTime);
/*      */     } catch (Exception e) {
/* 1152 */       this.logger.error("getUserGroupByTime " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*      */ 
/* 1155 */       throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserGroupByTime") + "");
/*      */     }
/* 1157 */     return list;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.UserGroupAdminServiceImpl
 * JD-Core Version:    0.6.2
 */
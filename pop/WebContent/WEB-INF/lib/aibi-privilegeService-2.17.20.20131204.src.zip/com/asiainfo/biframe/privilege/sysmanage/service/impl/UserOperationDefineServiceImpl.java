/*    */ package com.asiainfo.biframe.privilege.sysmanage.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.UserOperationDefine;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserOperationDefineDao;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserOperationDefineService;
/*    */ import java.util.List;
/*    */ 
/*    */ public class UserOperationDefineServiceImpl
/*    */   implements IUserOperationDefineService
/*    */ {
/*    */   private IUserOperationDefineDao userOperationDefineDao;
/*    */ 
/*    */   public IUserOperationDefineDao getUserOperationDefineDao()
/*    */   {
/* 17 */     return this.userOperationDefineDao;
/*    */   }
/*    */ 
/*    */   public void setUserOperationDefineDao(IUserOperationDefineDao userOperationDefineDao)
/*    */   {
/* 22 */     this.userOperationDefineDao = userOperationDefineDao;
/*    */   }
/*    */ 
/*    */   public List<UserOperationDefine> getUserOperDefByName(String defineName, int resouceType) {
/* 26 */     return this.userOperationDefineDao.getUserOperDefByName(defineName, resouceType);
/*    */   }
/*    */ 
/*    */   public List<UserOperationDefine> getAllUserOperDef()
/*    */   {
/* 31 */     return this.userOperationDefineDao.getAllUserOperDef();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.service.impl.UserOperationDefineServiceImpl
 * JD-Core Version:    0.6.2
 */
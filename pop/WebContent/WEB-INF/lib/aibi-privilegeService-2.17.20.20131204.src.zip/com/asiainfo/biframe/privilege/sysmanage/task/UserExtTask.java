/*     */ package com.asiainfo.biframe.privilege.sysmanage.task;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.base.util.PrivilegeConfigure;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserExtTask
/*     */ {
/*  23 */   private static Log log = LogFactory.getLog(UserExtTask.class);
/*     */ 
/*  25 */   public void run() { log.debug("in run");
/*  26 */     Boolean ableUserExt = new Boolean(PrivilegeConfigure.getInstance().getProperty("USEREXT_ISABLE"));
/*  27 */     log.debug("--ableUserExt:" + ableUserExt);
/*  28 */     if (!ableUserExt.booleanValue()) {
/*  29 */       log.info(" --USEREXT_ISABLE" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.paramIs") + "false," + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.noNeedExecuteTask") + "");
/*  30 */       return;
/*     */     }
/*  32 */     Sqlca m_Sqlca1 = null;
/*  33 */     Sqlca m_Sqlca2 = null;
/*  34 */     Sqlca m_Sqlca3 = null;
/*  35 */     Sqlca m_Sqlca4 = null;
/*     */     try
/*     */     {
/*  38 */       m_Sqlca1 = new Sqlca(new ConnectionEx());
/*  39 */       m_Sqlca2 = new Sqlca(new ConnectionEx());
/*  40 */       m_Sqlca3 = new Sqlca(new ConnectionEx());
/*  41 */       m_Sqlca4 = new Sqlca(new ConnectionEx());
/*  42 */       loginNum(m_Sqlca1, m_Sqlca2);
/*     */ 
/*  50 */       log.debug("end run");
/*     */     } catch (Exception e) {
/*  52 */       e.printStackTrace();
/*     */     } finally {
/*  54 */       if (m_Sqlca1 != null)
/*  55 */         m_Sqlca1.closeAll();
/*  56 */       if (m_Sqlca2 != null)
/*  57 */         m_Sqlca2.closeAll();
/*  58 */       if (m_Sqlca3 != null)
/*  59 */         m_Sqlca3.closeAll();
/*  60 */       if (m_Sqlca4 != null)
/*  61 */         m_Sqlca4.closeAll();
/*     */     } }
/*     */ 
/*     */   private void loginNum(Sqlca m_Sqlca1, Sqlca m_Sqlca2)
/*     */   {
/*  66 */     String userId = "";
/*  67 */     String loginnum = "";
/*  68 */     String strSql = "select userid,count( * ) from user_login_history group by userid";
/*  69 */     String strSql2 = "";
/*     */     try {
/*  71 */       m_Sqlca1.execute(strSql);
/*  72 */       while (m_Sqlca1.next()) {
/*  73 */         userId = m_Sqlca1.getString(1);
/*  74 */         loginnum = m_Sqlca1.getString(2);
/*  75 */         strSql2 = "update user_user_ext set loginnum='" + loginnum + "' where userid='" + userId + "'";
/*  76 */         m_Sqlca2.execute(strSql2);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  80 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void kpiNum(Sqlca m_Sqlca1, Sqlca m_Sqlca2) {
/*  85 */     String userId = "";
/*  86 */     String kpinum = "";
/*  87 */     String strSql = "select userid,count(*) from user_hitrate_log where resourcetype=4 group by userid";
/*  88 */     String strSql2 = "";
/*     */     try {
/*  90 */       m_Sqlca1.execute(strSql);
/*  91 */       while (m_Sqlca1.next()) {
/*  92 */         userId = m_Sqlca1.getString(1);
/*  93 */         kpinum = m_Sqlca1.getString(2);
/*  94 */         strSql2 = "update user_user_ext set kpinum='" + kpinum + "' where userid='" + userId + "'";
/*  95 */         m_Sqlca2.execute(strSql2);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  99 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/* 103 */   private void kpiName(Sqlca m_Sqlca1, Sqlca m_Sqlca2, Sqlca m_Sqlca3) { String userId = "";
/* 104 */     String tempuserid = "";
/*     */ 
/* 106 */     String uniqueid = "";
/* 107 */     String tempuniqueid = "";
/* 108 */     int maxUniqueid = 0;
/* 109 */     int count = 0;
/*     */ 
/* 111 */     String strSql = "select userid,uniqueid,count(*) from user_hitrate_log where resourcetype=4 group by userid,uniqueid";
/* 112 */     String strSql2 = "";
/*     */     try {
/* 114 */       m_Sqlca1.execute(strSql);
/* 115 */       while (m_Sqlca1.next()) {
/* 116 */         userId = m_Sqlca1.getString(1);
/* 117 */         uniqueid = m_Sqlca1.getString(2);
/* 118 */         count = m_Sqlca1.getInt(3);
/* 119 */         if (tempuserid.equals(userId)) {
/* 120 */           if (maxUniqueid < count) {
/* 121 */             maxUniqueid = count;
/* 122 */             tempuniqueid = uniqueid;
/*     */           }
/*     */         } else {
/* 125 */           if ((null != tempuserid) && (tempuserid.length() > 0)) {
/* 126 */             strSql2 = "select topic from kpi_define where kpiid=" + Integer.parseInt(tempuniqueid);
/* 127 */             m_Sqlca2.execute(strSql2);
/* 128 */             while (m_Sqlca2.next()) {
/* 129 */               String topic = m_Sqlca2.getString(1);
/* 130 */               String strSql3 = "update user_user_ext set kpiname='" + topic + "' where userid='" + tempuserid + "'";
/* 131 */               m_Sqlca3.execute(strSql3);
/*     */             }
/*     */           }
/* 134 */           maxUniqueid = count;
/* 135 */           tempuniqueid = uniqueid;
/*     */         }
/* 137 */         tempuserid = userId;
/*     */       }
/* 139 */       if ((null != tempuserid) && (tempuserid.length() > 0)) {
/* 140 */         strSql2 = "select topic from kpi_define where kpiid=" + tempuniqueid;
/* 141 */         m_Sqlca2.execute(strSql2);
/* 142 */         while (m_Sqlca2.next()) {
/* 143 */           String topic = m_Sqlca2.getString(1);
/* 144 */           String strSql3 = "update user_user_ext set kpiname='" + topic + "' where userid='" + tempuserid + "'";
/* 145 */           m_Sqlca3.execute(strSql3);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 150 */       e.printStackTrace();
/*     */     } }
/*     */ 
/*     */   private void smsKpiName(Sqlca m_Sqlca1, Sqlca m_Sqlca2, Sqlca m_Sqlca3, Sqlca m_Sqlca4) {
/* 154 */     String userId = "";
/* 155 */     String tempuserid = "";
/* 156 */     String resource_id = "";
/* 157 */     String topic = "";
/* 158 */     String str = "";
/*     */     try
/*     */     {
/* 162 */       m_Sqlca3.execute("update user_user_ext set smskpiname=''");
/*     */     }
/*     */     catch (Exception e1) {
/* 165 */       e1.printStackTrace();
/*     */     }
/*     */ 
/* 168 */     String strSql = "select operator_id,resource_id from sms_order where resource_type=6 group by operator_id,resource_id ";
/* 169 */     String strSql1 = "";
/*     */     try {
/* 171 */       m_Sqlca1.execute(strSql);
/* 172 */       while (m_Sqlca1.next()) {
/* 173 */         userId = m_Sqlca1.getString(1);
/* 174 */         resource_id = m_Sqlca1.getString(2);
/* 175 */         if (tempuserid.equals(userId))
/*     */         {
/* 177 */           strSql1 = "select topic from kpi_define where kpiid=" + resource_id;
/* 178 */           m_Sqlca2.execute(strSql1);
/* 179 */           while (m_Sqlca2.next()) {
/* 180 */             topic = m_Sqlca2.getString("topic");
/* 181 */             str = str + "," + topic;
/*     */           }
/*     */         }
/* 184 */         if ((null != tempuserid) && (tempuserid.length() > 0)) {
/* 185 */           strSql1 = "select topic from kpi_define where kpiid=" + resource_id;
/* 186 */           m_Sqlca2.execute(strSql1);
/* 187 */           while (m_Sqlca2.next()) {
/* 188 */             topic = m_Sqlca2.getString("topic");
/* 189 */             str = topic;
/*     */           }
/* 191 */           tempuserid = userId;
/*     */         } else {
/* 193 */           tempuserid = userId;
/* 194 */           strSql1 = "select topic from kpi_define where kpiid=" + resource_id;
/* 195 */           m_Sqlca2.execute(strSql1);
/* 196 */           while (m_Sqlca2.next()) {
/* 197 */             topic = m_Sqlca2.getString("topic");
/* 198 */             str = topic;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 203 */         String strSql2 = "select userid from user_group_map where group_id='" + userId + "'";
/* 204 */         m_Sqlca3.execute(strSql2);
/* 205 */         while (m_Sqlca3.next()) {
/* 206 */           String userid = m_Sqlca3.getString("userid");
/* 207 */           strSql2 = "update user_user_ext set smskpiname='" + str + "' where userid='" + userid + "'";
/*     */ 
/* 209 */           m_Sqlca4.execute(strSql2);
/*     */         }
/*     */ 
/* 212 */         strSql2 = "update user_user_ext set smskpiname='" + str + "' where userid='" + userId + "'";
/*     */ 
/* 214 */         m_Sqlca4.execute(strSql2);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 219 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void cancel()
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.task.UserExtTask
 * JD-Core Version:    0.6.2
 */
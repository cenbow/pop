/*     */ package com.asiainfo.biframe.privilege.sysmanage.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ public class ExportUtil
/*     */ {
/*     */   public static void exportXls4Rights(OutputStream stream, Collection<String> headList, Collection<List<String>> dataList)
/*     */     throws IOException
/*     */   {
/*  31 */     HSSFWorkbook book = new HSSFWorkbook();
/*     */ 
/*  33 */     HSSFSheet sheet = book.createSheet();
/*     */ 
/*  37 */     book.setSheetName(0, "data sheet");
/*     */ 
/*  40 */     HSSFRow row = sheet.createRow(0);
/*     */ 
/*  42 */     int rows = 0;
/*     */ 
/*  44 */     for (String header : headList)
/*     */     {
/*  46 */       HSSFCell cell = row.createCell((short)rows++);
/*     */ 
/*  50 */       cell.setCellValue(header == null ? "" : header.trim());
/*     */     }
/*     */ 
/*  54 */     int count = 1;
/*     */ 
/*  56 */     for (Collection valueList : dataList)
/*     */     {
/*  58 */       row = sheet.createRow(count++);
/*     */ 
/*  60 */       rows = 0;
/*  61 */       for (String valueStr : valueList)
/*     */       {
/*  63 */         HSSFCell cell = row.createCell((short)rows++);
/*     */ 
/*  67 */         cell.setCellValue(valueStr == null ? "" : valueStr.trim());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  72 */     book.write(stream);
/*     */   }
/*     */ 
/*     */   public static void exportXls4MatrixRights(Collection<String> headList, String[][] dataList, PrintWriter pw)
/*     */     throws IOException
/*     */   {
/*  88 */     HSSFWorkbook book = new HSSFWorkbook();
/*     */ 
/*  90 */     HSSFSheet sheet = book.createSheet();
/*     */ 
/*  93 */     book.setSheetName(0, "data sheet");
/*     */ 
/*  95 */     HSSFRow row = sheet.createRow(0);
/*     */ 
/*  97 */     int rows = 0;
/*  98 */     boolean firstFlag = true;
/*  99 */     for (String header : headList) {
/* 100 */       pw.print(String.valueOf(header));
/* 101 */       pw.print(",");
/*     */     }
/* 103 */     pw.println();
/*     */ 
/* 106 */     int count = 1;
/*     */ 
/* 108 */     for (String[] valueArr : dataList) {
/* 109 */       for (String valueStr : valueArr) {
/* 110 */         pw.print(valueStr == null ? "" : valueStr.trim());
/* 111 */         pw.print(",");
/*     */       }
/* 113 */       pw.println();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void exportXls4MatrixRights(OutputStream stream, Collection<String> headList, String[][] dataList) throws IOException
/*     */   {
/* 119 */     HSSFWorkbook book = new HSSFWorkbook();
/*     */ 
/* 121 */     HSSFSheet sheet = book.createSheet();
/*     */ 
/* 124 */     book.setSheetName(0, "data sheet");
/*     */ 
/* 127 */     HSSFRow row = sheet.createRow(0);
/*     */ 
/* 129 */     int rows = 0;
/*     */ 
/* 131 */     for (String header : headList)
/*     */     {
/* 133 */       HSSFCell cell = row.createCell((short)rows++);
/*     */ 
/* 137 */       cell.setCellValue(header == null ? "" : header.trim());
/*     */     }
/*     */ 
/* 141 */     int count = 1;
/*     */ 
/* 143 */     for (String[] valueArr : dataList)
/*     */     {
/* 145 */       row = sheet.createRow(count++);
/*     */ 
/* 147 */       rows = 0;
/* 148 */       for (String valueStr : valueArr)
/*     */       {
/* 150 */         HSSFCell cell = row.createCell((short)rows++);
/*     */ 
/* 154 */         cell.setCellValue(valueStr == null ? "" : valueStr.trim());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 159 */     book.write(stream);
/*     */   }
/*     */ 
/*     */   public static synchronized void exportCSVFile(Vector arrayData, PrintWriter pw) throws Exception
/*     */   {
/* 164 */     Vector vectdata = (Vector)arrayData.get(arrayData.size() - 1);
/* 165 */     for (int j = 0; j < vectdata.size(); j++) {
/* 166 */       pw.print(String.valueOf(vectdata.elementAt(j)));
/* 167 */       if (j == vectdata.size() - 1)
/* 168 */         pw.println();
/*     */       else {
/* 170 */         pw.print(",");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 175 */     for (int i = 0; i < arrayData.size() - 1; i++) {
/* 176 */       vectdata = (Vector)arrayData.get(i);
/* 177 */       for (int j = 0; j < vectdata.size(); j++) {
/* 178 */         Object tmpObj = vectdata.elementAt(j);
/* 179 */         String tmpStr = tmpObj == null ? "" : String.valueOf(tmpObj);
/* 180 */         pw.print(tmpStr);
/* 181 */         if (j == vectdata.size() - 1)
/* 182 */           pw.println();
/*     */         else
/* 184 */           pw.print(",");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void exportXlsByPage(OutputStream stream, Map header, List list, int pageSize)
/*     */     throws IOException
/*     */   {
/* 193 */     HSSFWorkbook book = new HSSFWorkbook();
/*     */ 
/* 196 */     int dataSize = list.size();
/* 197 */     int moreSize = dataSize % pageSize;
/* 198 */     int sheetSize = dataSize / pageSize;
/* 199 */     int startIndex = 0;
/* 200 */     int endIndex = 0;
/* 201 */     if (moreSize != 0)
/*     */     {
/* 203 */       sheetSize++;
/*     */     }
/* 205 */     for (int i = 0; i < sheetSize; i++)
/*     */     {
/* 207 */       HSSFSheet sheet = book.createSheet();
/*     */ 
/* 210 */       book.setSheetName(i, "data sheet" + i);
/*     */ 
/* 213 */       HSSFRow row = sheet.createRow(0);
/*     */ 
/* 215 */       int rows = 0;
/*     */ 
/* 217 */       for (Iterator head = header.keySet().iterator(); head.hasNext(); )
/*     */       {
/* 219 */         String colName = (String)head.next();
/*     */ 
/* 221 */         HSSFCell cell = row.createCell((short)rows++);
/*     */ 
/* 225 */         cell.setCellValue((String)header.get(colName));
/*     */       }
/*     */ 
/* 229 */       int count = 1;
/*     */ 
/* 233 */       startIndex = pageSize * i;
/* 234 */       endIndex = pageSize * (i + 1) >= dataSize ? dataSize : pageSize * (i + 1);
/*     */       Map data;
/*     */       Iterator head;
/* 236 */       for (int n = startIndex; n < endIndex; n++)
/*     */       {
/* 238 */         data = (Map)list.get(n);
/* 239 */         row = sheet.createRow(count++);
/* 240 */         rows = 0;
/* 241 */         for (head = header.keySet().iterator(); head.hasNext(); ) {
/* 242 */           String colName = (String)head.next();
/* 243 */           HSSFCell cell = row.createCell((short)rows++);
/*     */ 
/* 245 */           cell.setCellValue(data.get(colName) == null ? "" : data.get(colName).toString());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 252 */     book.write(stream);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.util.ExportUtil
 * JD-Core Version:    0.6.2
 */
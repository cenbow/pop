/*    */ package com.asiainfo.biframe.privilege.sysmanage.util;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class SysManageConstants
/*    */ {
/*    */   public static final String CONTROL_TYPE_MANAGER = "1";
/*    */   public static final String CONTROL_TYPE_READ_ONLY = "0";
/*    */   public static final String USER_OPERATION_DEFINE = "RESOURCE_OPERATION_DEFINE";
/*    */   public static final String NO_DISTINGUISH_OPERATION = "-1";
/*    */   public static final String DM_CITY = "CITY";
/*    */   public static final String DM_COUNTY = "COUNTY";
/*    */   public static final String DM_DEPT = "DEPT";
/*    */   public static final String DM_ALL = "-1";
/*    */   public static final String DBTYPE_DW = "DBTYPE_DW";
/*    */   public static final String DBTYPE_APP = "DBTYPE_APP";
/*    */   public static final int USER_TAB_BASIC = 0;
/*    */   public static final int USER_TAB_EXT = 1;
/*    */   public static final int USER_TAB_PWD = 2;
/*    */   public static final int USER_TAB_EXT_INFO = 4;
/*    */   public static final String STATUS_NORMAL = "0";
/*    */   public static final String STATUS_UNUSED = "1";
/*    */   public static final String STATUS_DELETE = "2";
/* 53 */   public static Map<String, String> statusMap = new HashMap();
/*    */ 
/*    */   private static void putStatusMap() {
/* 56 */     statusMap.put("0", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.normal") + "");
/* 57 */     statusMap.put("1", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.reserve") + "");
/*    */   }
/*    */ 
/*    */   public static String getStatusDesc(String status)
/*    */   {
/* 62 */     if (StringUtils.isBlank(status)) {
/* 63 */       return "";
/*    */     }
/* 65 */     String desc = (String)statusMap.get(status);
/* 66 */     if (desc == null) {
/* 67 */       return "";
/*    */     }
/* 69 */     return desc;
/*    */   }
/*    */ 
/*    */   static {
/* 73 */     putStatusMap();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.util.SysManageConstants
 * JD-Core Version:    0.6.2
 */
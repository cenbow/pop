/*     */ package com.asiainfo.biframe.privilege.taglib;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.IUserSession;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import java.io.IOException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public abstract class BaseBodyTag extends BodyTagSupport
/*     */ {
/*  32 */   protected Log log = LogFactory.getLog(getClass());
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*  40 */     return doEndBITag();
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*  49 */     return doStartBITag();
/*     */   }
/*     */ 
/*     */   public abstract int doStartBITag() throws JspException;
/*     */ 
/*     */   public abstract int doEndBITag() throws JspException;
/*     */ 
/*     */   protected void pageWriter(String str)
/*     */   {
/*  58 */     JspWriter out = getPageContext().getOut();
/*     */     try
/*     */     {
/*  61 */       out.println(str);
/*     */     }
/*     */     catch (IOException exp)
/*     */     {
/*  65 */       this.log.error("Jsp output error.", exp);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected PageContext getPageContext()
/*     */   {
/*  71 */     return this.pageContext;
/*     */   }
/*     */ 
/*     */   protected ServletRequest getServletRequest()
/*     */   {
/*  76 */     return getPageContext().getRequest();
/*     */   }
/*     */ 
/*     */   protected ServletResponse getServletResponse()
/*     */   {
/*  81 */     return getPageContext().getResponse();
/*     */   }
/*     */ 
/*     */   protected HttpServletRequest getHttpServletRequest()
/*     */   {
/*  86 */     return (HttpServletRequest)getServletRequest();
/*     */   }
/*     */ 
/*     */   protected HttpServletResponse getHttpServletResponse()
/*     */   {
/*  91 */     return (HttpServletResponse)getServletResponse();
/*     */   }
/*     */ 
/*     */   protected String getContextPath()
/*     */   {
/*  96 */     return getHttpServletRequest().getContextPath();
/*     */   }
/*     */ 
/*     */   protected IUserSession getSessionListener() {
/* 100 */     IUserSession userSession = (IUserSession)getPageContext().getSession().getAttribute("biplatform_user");
/* 101 */     return userSession;
/*     */   }
/*     */ 
/*     */   protected String getUserId() {
/*     */     try {
/* 106 */       return getSessionListener().getUserID();
/*     */     } catch (Exception e) {
/*     */     }
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object getSpringBean(String beanId)
/*     */   {
/*     */     try {
/* 115 */       return SystemServiceLocator.getInstance().getService(beanId);
/*     */     } catch (Exception e) {
/* 117 */       this.log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/* 118 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getBeansFail"), e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.taglib.BaseBodyTag
 * JD-Core Version:    0.6.2
 */
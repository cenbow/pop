/*     */ package com.asiainfo.biframe.privilege.taglib;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class CommandButtonTag extends BaseBodyTag
/*     */ {
/*     */   private String onMouseOut;
/*     */   private String onMouseOver;
/*     */   private String onclick;
/*     */   private String roleType;
/*     */   private String resourceType;
/*     */   private String rightId;
/*     */   private String resourceId;
/*     */   private String operationType;
/*     */ 
/*     */   public int doStartBITag()
/*     */     throws JspException
/*     */   {
/*  40 */     if (!haveRight()) {
/*  41 */       return 0;
/*     */     }
/*  43 */     StringBuffer start = new StringBuffer(256);
/*  44 */     start.append("<a href='#'  ");
/*  45 */     if (StringUtils.isNotBlank(getOnMouseOut())) {
/*  46 */       start.append("onMouseOut='").append(getOnMouseOut()).append("' ");
/*     */     }
/*  48 */     if (StringUtils.isNotBlank(getOnMouseOver())) {
/*  49 */       start.append("onMouseOver='").append(getOnMouseOver()).append("' ");
/*     */     }
/*  51 */     if (StringUtils.isNotBlank(getOnclick())) {
/*  52 */       start.append("onclick='").append(getOnclick()).append("' ");
/*     */     }
/*  54 */     start.append(">");
/*     */ 
/*  56 */     pageWriter(start.toString());
/*  57 */     return 1;
/*     */   }
/*     */ 
/*     */   public int doEndBITag() throws JspException
/*     */   {
/*  62 */     if (!haveRight()) {
/*  63 */       return 6;
/*     */     }
/*  65 */     StringBuffer end = new StringBuffer(256);
/*  66 */     end.append("</a>");
/*     */ 
/*  68 */     pageWriter(end.toString());
/*  69 */     return 6;
/*     */   }
/*     */ 
/*     */   private boolean haveRight() {
/*  73 */     String userId = getUserId();
/*     */ 
/*  75 */     IUserPrivilegeService userService = (IUserPrivilegeService)getSpringBean("right_privilegeService");
/*     */ 
/*  77 */     Right right = new Right();
/*  78 */     right.setRightId(getRightId());
/*  79 */     right.setRoleType(Integer.valueOf(getRoleType()).intValue());
/*  80 */     right.setResourceType(Integer.valueOf(getResourceType()).intValue());
/*  81 */     right.setResourceId(getResourceId());
/*  82 */     right.setOperationType(getOperationType());
/*     */ 
/*  84 */     return userService.haveRightByUserId(userId, right);
/*     */   }
/*     */ 
/*     */   public String getOnMouseOut()
/*     */   {
/*  91 */     return this.onMouseOut;
/*     */   }
/*     */   public void setOnMouseOut(String onMouseOut) {
/*  94 */     this.onMouseOut = onMouseOut;
/*     */   }
/*     */   public String getOnMouseOver() {
/*  97 */     return this.onMouseOver;
/*     */   }
/*     */   public void setOnMouseOver(String onMouseOver) {
/* 100 */     this.onMouseOver = onMouseOver;
/*     */   }
/*     */   public String getOnclick() {
/* 103 */     return this.onclick;
/*     */   }
/*     */   public void setOnclick(String onclick) {
/* 106 */     this.onclick = onclick;
/*     */   }
/*     */   public String getResourceType() {
/* 109 */     return this.resourceType;
/*     */   }
/*     */   public void setResourceType(String resourceType) {
/* 112 */     this.resourceType = resourceType;
/*     */   }
/*     */   public String getResourceId() {
/* 115 */     return this.resourceId;
/*     */   }
/*     */   public void setResourceId(String resourceId) {
/* 118 */     this.resourceId = resourceId;
/*     */   }
/*     */   public String getOperationType() {
/* 121 */     return this.operationType;
/*     */   }
/*     */   public void setOperationType(String operationType) {
/* 124 */     this.operationType = operationType;
/*     */   }
/*     */   public String getRightId() {
/* 127 */     return this.rightId;
/*     */   }
/*     */   public void setRightId(String rightId) {
/* 130 */     this.rightId = rightId;
/*     */   }
/*     */   public String getRoleType() {
/* 133 */     return this.roleType;
/*     */   }
/*     */   public void setRoleType(String roleType) {
/* 136 */     this.roleType = roleType;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.taglib.CommandButtonTag
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.taglib;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*    */ import javax.servlet.jsp.JspException;
/*    */ 
/*    */ public class RightPresent extends BaseBodyTag
/*    */ {
/*    */   private int roleType;
/*    */   private String resourceType;
/*    */   private String actionId;
/*    */   private String resourceId;
/*    */   private String operationType;
/*    */ 
/*    */   public int doStartBITag()
/*    */     throws JspException
/*    */   {
/* 28 */     if (haveRight()) {
/* 29 */       return 1;
/*    */     }
/* 31 */     return 0;
/*    */   }
/*    */ 
/*    */   public int doEndBITag() throws JspException {
/* 35 */     return 6;
/*    */   }
/*    */ 
/*    */   private boolean haveRight() {
/* 39 */     String userId = getUserId();
/*    */ 
/* 41 */     IUserPrivilegeService userService = (IUserPrivilegeService)getSpringBean("right_privilegeService");
/*    */ 
/* 43 */     Right right = new Right();
/* 44 */     right.setRightId(getActionId());
/* 45 */     right.setRoleType(getRoleType());
/* 46 */     right.setResourceType(Integer.valueOf(getResourceType()).intValue());
/* 47 */     right.setResourceId(getResourceId());
/* 48 */     right.setOperationType(getOperationType());
/*    */ 
/* 50 */     return userService.haveRightByUserId(userId, right);
/*    */   }
/*    */   public int getRoleType() {
/* 53 */     return this.roleType;
/*    */   }
/*    */   public void setRoleType(int roleType) {
/* 56 */     this.roleType = roleType;
/*    */   }
/*    */   public String getResourceType() {
/* 59 */     return this.resourceType;
/*    */   }
/*    */   public void setResourceType(String resourceType) {
/* 62 */     this.resourceType = resourceType;
/*    */   }
/*    */   public String getActionId() {
/* 65 */     return this.actionId;
/*    */   }
/*    */   public void setActionId(String actionId) {
/* 68 */     this.actionId = actionId;
/*    */   }
/*    */   public String getResourceId() {
/* 71 */     return this.resourceId;
/*    */   }
/*    */   public void setResourceId(String resourceId) {
/* 74 */     this.resourceId = resourceId;
/*    */   }
/*    */   public String getOperationType() {
/* 77 */     return this.operationType;
/*    */   }
/*    */   public void setOperationType(String operationType) {
/* 80 */     this.operationType = operationType;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.taglib.RightPresent
 * JD-Core Version:    0.6.2
 */
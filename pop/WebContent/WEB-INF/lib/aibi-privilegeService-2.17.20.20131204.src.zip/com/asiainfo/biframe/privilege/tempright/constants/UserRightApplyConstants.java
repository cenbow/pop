/*    */ package com.asiainfo.biframe.privilege.tempright.constants;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class UserRightApplyConstants
/*    */ {
/*    */   public static final String STATUS_WITHEROUTAPPROVAL = "0";
/*    */   public static final String STATUS_APPROVED = "1";
/* 25 */   public static Map<String, String> statusMap = null;
/*    */ 
/*    */   public static Map<String, String> putStatusMap() {
/* 28 */     statusMap = new HashMap();
/* 29 */     statusMap.put("0", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.withoutApproval") + "");
/* 30 */     statusMap.put("1", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.approved") + "");
/* 31 */     return statusMap;
/*    */   }
/*    */ 
/*    */   public static String getStatusDesc(String status) {
/* 35 */     if (StringUtils.isBlank(status)) {
/* 36 */       return "";
/*    */     }
/* 38 */     String desc = (String)statusMap.get(status);
/* 39 */     if (desc == null) {
/* 40 */       return "";
/*    */     }
/* 42 */     return desc;
/*    */   }
/*    */ 
/*    */   static {
/* 46 */     putStatusMap();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.tempright.constants.UserRightApplyConstants
 * JD-Core Version:    0.6.2
 */
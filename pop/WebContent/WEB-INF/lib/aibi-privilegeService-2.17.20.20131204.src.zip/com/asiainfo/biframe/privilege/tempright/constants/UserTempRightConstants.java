/*    */ package com.asiainfo.biframe.privilege.tempright.constants;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class UserTempRightConstants
/*    */ {
/*    */   public static final String STATUS_INVALID = "0";
/*    */   public static final String STATUS_VALID = "1";
/* 23 */   public static Map<String, String> statusMap = new HashMap();
/*    */ 
/*    */   private static void putStatusMap() {
/* 26 */     statusMap.put("0", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.invalid") + "");
/* 27 */     statusMap.put("1", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.valid") + "");
/*    */   }
/*    */ 
/*    */   public static String getStatusDesc(String status) {
/* 31 */     if (StringUtils.isBlank(status)) {
/* 32 */       return "";
/*    */     }
/* 34 */     String desc = (String)statusMap.get(status);
/* 35 */     if (desc == null) {
/* 36 */       return "";
/*    */     }
/* 38 */     return desc;
/*    */   }
/*    */ 
/*    */   static {
/* 42 */     putStatusMap();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.tempright.constants.UserTempRightConstants
 * JD-Core Version:    0.6.2
 */
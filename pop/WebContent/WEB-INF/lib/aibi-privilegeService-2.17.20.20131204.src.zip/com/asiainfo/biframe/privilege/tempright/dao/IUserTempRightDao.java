package com.asiainfo.biframe.privilege.tempright.dao;

import com.asiainfo.biframe.exception.DaoException;
import com.asiainfo.biframe.privilege.model.UserRightApply;
import com.asiainfo.biframe.privilege.model.UserTempRight;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public abstract interface IUserTempRightDao
{
  public abstract List<UserTempRight> getTempRights(String paramString, Date paramDate)
    throws DaoException;

  public abstract Collection<UserTempRight> getTempRightsByApplyId(String paramString)
    throws DaoException;

  public abstract void saveTempRights(Collection<UserTempRight> paramCollection)
    throws DaoException;

  public abstract void updateTempRights(Collection<UserTempRight> paramCollection)
    throws DaoException;

  public abstract void deleteTempRights(Collection<UserTempRight> paramCollection)
    throws DaoException;

  public abstract void deleteTempRights(DeletedParameterVO paramDeletedParameterVO)
    throws DaoException;

  public abstract String saveRightApply(UserRightApply paramUserRightApply)
    throws DaoException;

  public abstract UserRightApply findApplyById(String paramString)
    throws DaoException;

  public abstract String updateApply(UserRightApply paramUserRightApply)
    throws DaoException;

  public abstract List<UserTempRight> getTempRightList(String paramString, Date paramDate, int paramInt)
    throws DaoException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.tempright.dao.IUserTempRightDao
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.tempright.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.model.UserRightApply;
/*     */ import com.asiainfo.biframe.privilege.tempright.dao.IUserRightApplyDao;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserRightApplyDao extends HibernateDaoSupport
/*     */   implements IUserRightApplyDao
/*     */ {
/*  34 */   private static final Log log = LogFactory.getLog(UserRightApplyDao.class);
/*     */ 
/*     */   public String save(UserRightApply apply) throws DaoException {
/*     */     try {
/*  38 */       log.debug("in save");
/*  39 */       String applyId = (String)getHibernateTemplate().save(apply);
/*  40 */       log.debug("end save");
/*  41 */       return applyId;
/*     */     } catch (Exception e) {
/*  43 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveTemprightFail") + "", e);
/*  44 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveTemprightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String update(UserRightApply apply) throws DaoException {
/*     */     try {
/*  50 */       log.debug("in update");
/*  51 */       getHibernateTemplate().update(apply);
/*  52 */       log.debug("end update");
/*  53 */       return apply.getApplyId();
/*     */     } catch (Exception e) {
/*  55 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateTempRightFail") + "", e);
/*  56 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String delete(UserRightApply apply) throws DaoException {
/*     */     try { log.debug("in delete");
/*  62 */       String applyId = apply.getApplyId();
/*  63 */       getHibernateTemplate().delete(apply);
/*  64 */       log.debug("end delete");
/*  65 */       return applyId;
/*     */     } catch (DataAccessException e) {
/*  67 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delTempRightFail") + "", e);
/*  68 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.delTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public UserRightApply findById(String applyId) throws DaoException {
/*     */     try {
/*  74 */       log.debug("in findById");
/*  75 */       UserRightApply ura = (UserRightApply)getHibernateTemplate().get(UserRightApply.class, applyId);
/*  76 */       log.debug("end findById");
/*  77 */       return ura;
/*     */     } catch (DataAccessException e) {
/*  79 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/*  80 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*  84 */   public Map getPagedApplys(final String operatorId, final UserRightApply apply, final int currPage, final int pageSize) throws DaoException { log.debug(" in getPagedApplys");
/*  85 */     HashMap map = new HashMap();
/*     */     try {
/*  87 */       List list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */         public Object doInHibernate(Session s) throws HibernateException, SQLException {
/*  89 */           String listSql = "";
/*     */ 
/*  91 */           listSql = "select count(*) from UserRightApply app " + UserRightApplyDao.this.getWhereSql(operatorId, apply);
/*  92 */           UserRightApplyDao.log.info("----listSql=" + listSql);
/*  93 */           Query query = s.createQuery(listSql);
/*  94 */           UserRightApplyDao.this.setQueryParameter(operatorId, apply, query);
/*  95 */           return query.list();
/*     */         }
/*     */       });
/*  98 */       int totals = 0;
/*  99 */       if ((list != null) && (list.size() > 0)) {
/* 100 */         totals = ((Long)list.get(0)).intValue();
/*     */       }
/*     */ 
/* 103 */       list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */         public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 105 */           String listSql = "from UserRightApply app " + UserRightApplyDao.this.getWhereSql(operatorId, apply) + " order by app.applyTime desc";
/* 106 */           UserRightApplyDao.log.info("----listSql=" + listSql);
/* 107 */           Query query = s.createQuery(listSql);
/* 108 */           UserRightApplyDao.this.setQueryParameter(operatorId, apply, query);
/*     */ 
/* 110 */           int firstResult = currPage * pageSize;
/* 111 */           int maxResult = pageSize;
/* 112 */           query.setFirstResult(firstResult);
/* 113 */           query.setMaxResults(maxResult);
/* 114 */           List tmpList = query.list();
/* 115 */           return tmpList;
/*     */         }
/*     */       });
/* 118 */       map.put("total", new Integer(totals));
/* 119 */       map.put("result", list);
/* 120 */       log.debug(" end getPagedApplys");
/*     */     } catch (RuntimeException ex) {
/* 122 */       map.put("total", new Integer(0));
/* 123 */       map.put("result", new ArrayList());
/* 124 */       throw ex;
/*     */     }
/* 126 */     return map; }
/*     */ 
/*     */   private String getWhereSql(String operatorId, UserRightApply apply)
/*     */   {
/* 130 */     StringBuilder whereHql = new StringBuilder(256).append(" where 1=1");
/* 131 */     if (StringUtils.isNotBlank(operatorId)) {
/* 132 */       whereHql.append(" and (app.proposerId=? or app.approverId=?) ");
/*     */     }
/* 134 */     if ((StringUtils.isNotBlank(apply.getProposerId())) && (!apply.getProposerId().equals("-1"))) {
/* 135 */       whereHql.append(" and app.proposerId=?");
/*     */     }
/* 137 */     if ((StringUtils.isNotBlank(apply.getApproverId())) && (!apply.getApproverId().equals("-1"))) {
/* 138 */       whereHql.append(" and app.approverId=?");
/*     */     }
/*     */ 
/* 141 */     if ((apply.getQueryBeginApplyTime() != null) && (apply.getQueryEndApplyTime() == null)) {
/* 142 */       whereHql.append(" and app.applyTime>=? ");
/*     */     }
/* 144 */     if ((apply.getQueryBeginApplyTime() == null) && (apply.getQueryEndApplyTime() != null)) {
/* 145 */       whereHql.append(" and app.applyTime<=? ");
/*     */     }
/*     */ 
/* 148 */     if ((apply.getQueryBeginApplyTime() != null) && (apply.getQueryEndApplyTime() != null)) {
/* 149 */       whereHql.append(" and app.applyTime>=? and app.applyTime<=?");
/*     */     }
/* 151 */     String state = apply.getState();
/* 152 */     if ((StringUtils.isNotBlank(state)) && (!"-1".equals(state))) {
/* 153 */       whereHql.append(" and app.state=?");
/*     */     }
/* 155 */     String applyType = apply.getApplyType();
/* 156 */     if ((StringUtils.isNotBlank(applyType)) && (!"-1".equals(applyType))) {
/* 157 */       whereHql.append(" and app.applyType=?");
/*     */     }
/*     */ 
/* 160 */     if ((apply.getQueryBeginApprovalTime() != null) && (apply.getQueryEndApprovalTime() == null)) {
/* 161 */       whereHql.append(" and app.approvalTime>=? ");
/*     */     }
/* 163 */     if ((apply.getQueryBeginApprovalTime() == null) && (apply.getQueryEndApprovalTime() != null)) {
/* 164 */       whereHql.append(" and app.approvalTime<=? ");
/*     */     }
/*     */ 
/* 167 */     if ((apply.getQueryBeginApprovalTime() != null) && (apply.getQueryEndApprovalTime() != null)) {
/* 168 */       whereHql.append(" and app.approvalTime>=? and app.approvalTime<=?");
/*     */     }
/* 170 */     return whereHql.toString();
/*     */   }
/*     */ 
/*     */   private void setQueryParameter(String operatorId, UserRightApply apply, Query query) {
/* 174 */     int index = 0;
/* 175 */     if (StringUtils.isNotBlank(operatorId)) {
/* 176 */       query.setString(index++, operatorId);
/* 177 */       query.setString(index++, operatorId);
/*     */     }
/* 179 */     if ((StringUtils.isNotBlank(apply.getProposerId())) && (!apply.getProposerId().equals("-1"))) {
/* 180 */       query.setString(index++, apply.getProposerId());
/*     */     }
/* 182 */     if ((StringUtils.isNotBlank(apply.getApproverId())) && (!apply.getApproverId().equals("-1"))) {
/* 183 */       query.setString(index++, apply.getApproverId());
/*     */     }
/*     */ 
/* 186 */     if ((apply.getQueryBeginApplyTime() != null) && (apply.getQueryEndApplyTime() == null)) {
/* 187 */       query.setTimestamp(index++, apply.getQueryBeginApplyTime());
/*     */     }
/* 189 */     if ((apply.getQueryBeginApplyTime() == null) && (apply.getQueryEndApplyTime() != null)) {
/* 190 */       query.setTimestamp(index++, apply.getQueryEndApplyTime());
/*     */     }
/*     */ 
/* 193 */     if ((apply.getQueryBeginApplyTime() != null) && (apply.getQueryEndApplyTime() != null)) {
/* 194 */       query.setTimestamp(index++, apply.getQueryBeginApplyTime());
/* 195 */       query.setTimestamp(index++, apply.getQueryEndApplyTime());
/*     */     }
/* 197 */     String state = apply.getState();
/* 198 */     if ((StringUtils.isNotBlank(state)) && (!"-1".equals(state))) {
/* 199 */       query.setString(index++, state);
/*     */     }
/* 201 */     String applyType = apply.getApplyType();
/* 202 */     if ((StringUtils.isNotBlank(applyType)) && (!"-1".equals(applyType))) {
/* 203 */       query.setString(index++, applyType);
/*     */     }
/*     */ 
/* 206 */     if ((apply.getQueryBeginApprovalTime() != null) && (apply.getQueryEndApprovalTime() == null)) {
/* 207 */       query.setTimestamp(index++, apply.getQueryBeginApprovalTime());
/*     */     }
/* 209 */     if ((apply.getQueryBeginApprovalTime() == null) && (apply.getQueryEndApprovalTime() != null)) {
/* 210 */       query.setTimestamp(index++, apply.getQueryEndApprovalTime());
/*     */     }
/*     */ 
/* 213 */     if ((apply.getQueryBeginApprovalTime() != null) && (apply.getQueryEndApprovalTime() != null)) {
/* 214 */       query.setTimestamp(index++, apply.getQueryBeginApprovalTime());
/* 215 */       query.setTimestamp(index++, apply.getQueryEndApprovalTime());
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<UserRightApply> getCurrentAndFutureApplys(String userId)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/* 224 */       log.debug("in getCurrentAndFutureApplys");
/* 225 */       String hql = "from UserRightApply apply where apply.state=? and apply.endDate>=? and apply.proposerId=?";
/* 226 */       List list = getHibernateTemplate().find(hql, new Object[] { "1", new Date(), userId });
/* 227 */       log.debug("end getCurrentAndFutureApplys");
/* 228 */       return list;
/*     */     } catch (DataAccessException e) {
/* 230 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryApplyFail") + "", e);
/* 231 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryApplyFail") + "", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.tempright.dao.impl.UserRightApplyDao
 * JD-Core Version:    0.6.2
 */
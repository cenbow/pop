/*     */ package com.asiainfo.biframe.privilege.tempright.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.privilege.model.UserRightApply;
/*     */ import com.asiainfo.biframe.privilege.model.UserTempRight;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.tempright.dao.IUserTempRightDao;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserTempRightDao extends HibernateDaoSupport
/*     */   implements IUserTempRightDao
/*     */ {
/*  26 */   private static final Log log = LogFactory.getLog(UserTempRightDao.class);
/*     */ 
/*     */   public List<UserTempRight> getTempRights(String userId, Date currDate) throws DaoException {
/*     */     try {
/*  30 */       log.debug("in getTempRights");
/*  31 */       String hql = "from UserTempRight rig where rig.state=? and rig.userId=? and rig.beginDate<=? and rig.endDate>=?";
/*  32 */       List rightList = getHibernateTemplate().find(hql, new Object[] { "1", userId, currDate, currDate });
/*     */ 
/*  34 */       log.debug("end getTempRights");
/*  35 */       return rightList;
/*     */     } catch (DataAccessException e) {
/*  37 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/*  38 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteTempRights(Collection<UserTempRight> rights)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/*  47 */       log.debug("in deleteTempRights");
/*  48 */       getHibernateTemplate().deleteAll(rights);
/*  49 */       log.debug("end deleteTempRights");
/*     */     } catch (DataAccessException e) {
/*  51 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteTempRightFail") + "", e);
/*  52 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Collection<UserTempRight> getTempRightsByApplyId(String applyId)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/*  61 */       log.debug("in getTempRightsByApplyId");
/*  62 */       String hql = "from UserTempRight rig where rig.applyId='" + applyId + "'";
/*  63 */       log.debug("--hql:" + hql);
/*  64 */       List rightList = getHibernateTemplate().find(hql);
/*  65 */       log.debug("end getTempRightsByApplyId");
/*  66 */       return rightList;
/*     */     } catch (DataAccessException e) {
/*  68 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.byApply") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail2") + "", e);
/*  69 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.byApply") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail2") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveTempRights(Collection<UserTempRight> rights)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/*  78 */       log.debug("in saveTempRights");
/*  79 */       for (UserTempRight right : rights) {
/*  80 */         getHibernateTemplate().save(right);
/*     */       }
/*  82 */       log.debug("end saveTempRights");
/*     */     } catch (DataAccessException e) {
/*  84 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveTempRightFail") + "", e);
/*  85 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateTempRights(Collection<UserTempRight> rights)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/*  94 */       log.debug("in updateTempRights");
/*  95 */       for (UserTempRight right : rights) {
/*  96 */         getHibernateTemplate().update(right);
/*     */       }
/*  98 */       log.debug("end updateTempRights");
/*     */     } catch (DataAccessException e) {
/* 100 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyTempRightFail") + "", e);
/* 101 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteTempRights(DeletedParameterVO paraObject)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/* 112 */       log.debug("in deleteTempRights(DeletedParameterVO paraObject)");
/* 113 */       StringBuilder hql = new StringBuilder(256);
/* 114 */       hql.append(" from UserTempRight userTempRight where 1=1 ");
/* 115 */       hql.append(paraObject.getWhereHql("userId", paraObject, "userTempRight"));
/* 116 */       log.debug("--deleteHql:" + hql);
/* 117 */       List list = getHibernateTemplate().find(hql.toString());
/* 118 */       getHibernateTemplate().deleteAll(list);
/* 119 */       log.debug("end deleteTempRights(DeletedParameterVO paraObject)");
/*     */     } catch (DataAccessException e) {
/* 121 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteTempRightFail") + "", e);
/* 122 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String saveRightApply(UserRightApply apply)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/* 132 */       log.debug("in save");
/* 133 */       String applyId = (String)getHibernateTemplate().save(apply);
/* 134 */       log.debug("end save");
/* 135 */       return applyId;
/*     */     } catch (Exception e) {
/* 137 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveTempRightFail") + "", e);
/* 138 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public UserRightApply findApplyById(String applyId)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/* 148 */       log.debug("in findById");
/* 149 */       UserRightApply ura = (UserRightApply)getHibernateTemplate().get(UserRightApply.class, applyId);
/* 150 */       log.debug("end findById");
/* 151 */       return ura;
/*     */     } catch (DataAccessException e) {
/* 153 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRightApplyFail") + "", e);
/* 154 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryRightApplyFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String updateApply(UserRightApply apply)
/*     */     throws DaoException
/*     */   {
/*     */     try
/*     */     {
/* 164 */       log.debug("in update");
/* 165 */       getHibernateTemplate().update(apply);
/* 166 */       log.debug("end update");
/* 167 */       return apply.getApplyId();
/*     */     } catch (Exception e) {
/* 169 */       this.logger.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateTempRightFail") + "", e);
/* 170 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.updateTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<UserTempRight> getTempRightList(String userId, Date currDate, int resourceType) throws DaoException
/*     */   {
/*     */     try {
/* 177 */       log.debug("in getTempRights");
/* 178 */       String hql = "from UserTempRight rig where rig.state=? and  rig.userId=? and rig.beginDate<=? and rig.endDate>=?  and rig.resourceType=?";
/*     */ 
/* 181 */       List rightList = getHibernateTemplate().find(hql, new Object[] { "1", userId, currDate, currDate, Integer.valueOf(resourceType) });
/*     */ 
/* 185 */       log.debug("end getTempRights");
/* 186 */       return rightList;
/*     */     } catch (DataAccessException e) {
/* 188 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/*     */ 
/* 191 */       throw new DaoException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.tempright.dao.impl.UserTempRightDao
 * JD-Core Version:    0.6.2
 */
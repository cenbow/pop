package com.asiainfo.biframe.privilege.tempright.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.base.exception.MessageException;
import com.asiainfo.biframe.privilege.model.UserRightApply;
import com.asiainfo.biframe.privilege.model.UserTempRight;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public abstract interface IUserRightApplyService
{
  public abstract UserRightApply getApplyById(String paramString)
    throws ServiceException;

  public abstract Map getPagedApplys(String paramString, UserRightApply paramUserRightApply, int paramInt1, int paramInt2)
    throws ServiceException;

  public abstract String doCreateApply(UserRightApply paramUserRightApply, List<UserTempRight> paramList)
    throws MessageException, ServiceException;

  public abstract void doAffirmApply(String paramString1, String paramString2)
    throws ServiceException;

  public abstract Collection<UserRightApply> getCurrentAndFutureApplys(String paramString)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.tempright.service.IUserRightApplyService
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.tempright.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.base.exception.MessageException;
import com.asiainfo.biframe.privilege.model.UserRightApply;
import com.asiainfo.biframe.privilege.model.UserTempRight;
import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public abstract interface IUserTempRightService
{
  public abstract Collection<UserTempRight> getCurrentTempRights(String paramString, Date paramDate)
    throws ServiceException;

  public abstract Collection<UserTempRight> getTempRightsByApplyId(String paramString)
    throws ServiceException;

  public abstract void saveTempRights(Collection<UserTempRight> paramCollection)
    throws ServiceException;

  public abstract void updateTempRights(Collection<UserTempRight> paramCollection)
    throws ServiceException;

  public abstract void deleteTempRights(Collection<UserTempRight> paramCollection)
    throws ServiceException;

  public abstract void deleteTempRights(DeletedParameterVO paramDeletedParameterVO)
    throws ServiceException;

  public abstract String doCreateApply(UserRightApply paramUserRightApply, List<UserTempRight> paramList)
    throws MessageException, ServiceException;

  public abstract void doAffirmApply(String paramString1, String paramString2)
    throws ServiceException;

  public abstract UserRightApply getRightApply(String paramString)
    throws ServiceException;

  public abstract List<UserTempRight> getCurrentTempRights(String paramString, Date paramDate, int paramInt)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.tempright.service.IUserTempRightService
 * JD-Core Version:    0.6.2
 */
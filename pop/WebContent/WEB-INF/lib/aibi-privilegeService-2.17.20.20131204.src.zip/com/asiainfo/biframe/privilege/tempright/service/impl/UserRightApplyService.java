/*     */ package com.asiainfo.biframe.privilege.tempright.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.exception.ValidateException;
/*     */ import com.asiainfo.biframe.privilege.base.exception.MessageException;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.base.util.UniTouchUtil;
/*     */ import com.asiainfo.biframe.privilege.model.UserRightApply;
/*     */ import com.asiainfo.biframe.privilege.model.UserTempRight;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.privilege.tempright.dao.IUserRightApplyDao;
/*     */ import com.asiainfo.biframe.privilege.tempright.service.IUserRightApplyService;
/*     */ import com.asiainfo.biframe.privilege.tempright.service.IUserTempRightService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringRandom;
/*     */ import com.asiainfo.biframe.utils.webservice.uniTouch.TaskModel;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserRightApplyService
/*     */   implements IUserRightApplyService
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(UserRightApplyService.class);
/*     */   private IUserRightApplyDao userRightApplyDao;
/*     */   private IUserTempRightService userTempRightService;
/*     */   private IUserAdminService userAdminService;
/*     */ 
/*     */   public UserRightApply getApplyById(String applyId)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/*  47 */       log.debug("in getApplyById");
/*  48 */       return this.userRightApplyDao.findById(applyId);
/*     */     } catch (DaoException e) {
/*  50 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findApplyByIdFail"), e);
/*  51 */       throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findApplyByIdFail"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map getPagedApplys(String operatorId, UserRightApply apply, int currPage, int pageSize) throws ServiceException {
/*     */     try {
/*  57 */       log.debug("in getPagedApplys");
/*     */ 
/*  60 */       if (this.userAdminService.isAdminUser(operatorId)) {
/*  61 */         operatorId = "";
/*     */       }
/*  63 */       return this.userRightApplyDao.getPagedApplys(operatorId, apply, currPage, pageSize);
/*     */     } catch (DaoException e) {
/*  65 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findApplyByConditonFail") + "", e);
/*  66 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.findApplyByConditonFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String doCreateApply(UserRightApply apply, List<UserTempRight> rightList)
/*     */     throws MessageException, ServiceException
/*     */   {
/*  75 */     log.debug("in doCreateApply");
/*  76 */     if ((rightList == null) || (rightList.isEmpty())) {
/*  77 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.noTempRightChosen") + "!");
/*     */     }
/*     */     String code;
/*     */     try
/*     */     {
/*  82 */       StringRandom gen = new StringRandom();
/*  83 */       gen.setCharset("0-9");
/*  84 */       gen.setLength(4);
/*  85 */       code = gen.getRandom();
/*     */     } catch (Exception e1) {
/*  87 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRandomCodeFail") + "", e1);
/*  88 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.createApplyFail") + ":" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRandomCodeFail") + "", e1);
/*     */     }
/*     */     try
/*     */     {
/*  92 */       String rightState = "0";
/*  93 */       apply.setElectronicCode(code);
/*  94 */       if ("0".equals(apply.getApplyType())) {
/*  95 */         apply.setState("0");
/*  96 */       } else if ("1".equals(apply.getApplyType())) {
/*  97 */         apply.setState("1");
/*  98 */         rightState = "1";
/*     */       }
/* 100 */       apply.setApplyTime(new Date());
/* 101 */       String applyId = this.userRightApplyDao.save(apply);
/*     */ 
/* 103 */       for (UserTempRight right : rightList) {
/* 104 */         right.setApplyId(applyId);
/* 105 */         right.setState(rightState);
/*     */       }
/* 107 */       getUserTempRightService().saveTempRights(rightList);
/*     */ 
/* 109 */       sendSmsMessage(apply, rightList);
/*     */ 
/* 112 */       String msg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.tempRightApply");
/*     */ 
/* 114 */       LogDetailUtil.log(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_APPLY"), "999", apply.getProposerId(), apply.getProposerName(), msg, null, null);
/*     */ 
/* 117 */       log.debug("end doCreateApply");
/* 118 */       return applyId;
/*     */     } catch (ServiceException e) {
/* 120 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.createApplyFail") + "", e);
/* 121 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.createApplyFail") + ":" + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void sendSmsMessage(UserRightApply apply, List<UserTempRight> rightList)
/*     */     throws MessageException, ServiceException
/*     */   {
/* 130 */     User_User proposerUser = getUserAdminService().getUser(apply.getProposerId());
/*     */ 
/* 132 */     String proposerPhone = proposerUser.getMobilephone();
/* 133 */     if ((proposerUser == null) || (StringUtils.isBlank(proposerPhone))) {
/* 134 */       throw new ValidateException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.notGetApplyerPhone"));
/*     */     }
/* 136 */     String approverPhone = apply.getApproverPhone();
/* 137 */     if (StringUtils.isBlank(approverPhone)) {
/* 138 */       throw new ValidateException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.sendSmsToAuditFail") + "");
/*     */     }
/* 140 */     log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.applyMobilePhone") + "" + proposerPhone);
/* 141 */     log.debug("--" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.auditMobilePhone") + "" + approverPhone);
/*     */     try
/*     */     {
/* 144 */       TaskModel model = new TaskModel();
/* 145 */       model.setCreator(proposerPhone);
/* 146 */       String content = null;
/* 147 */       if ("0".equals(apply.getApplyType())) {
/* 148 */         model.setSubject(proposerUser.getUsername() + "-" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.tempRightApply") + "-" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.electronicCode") + ":" + apply.getElectronicCode());
/*     */ 
/* 157 */         content = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.needApplication") + ":";
/*     */       }
/* 160 */       else if ("1".equals(apply.getApplyType())) {
/* 161 */         model.setSubject(proposerUser.getUsername() + "-" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.tempRightApply"));
/*     */ 
/* 165 */         content = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.needNotApplication") + ":";
/*     */       }
/*     */ 
/* 168 */       content = content + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.biUser") + "[" + proposerUser.getUsername() + "]" + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.applyTempRight") + "";
/*     */ 
/* 176 */       for (UserTempRight right : rightList) {
/* 177 */         content = content + right.getResourceName();
/* 178 */         if (!right.getOperationType().equals("-1")) {
/* 179 */           content = content + "-" + right.getOperationName();
/*     */         }
/* 181 */         content = content + ",";
/*     */       }
/* 183 */       content = content.substring(0, content.length() - 1) + ";" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.effectDate") + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.from") + "" + apply.getBeginDateStr() + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.to") + "" + apply.getEndDateStr() + ".";
/*     */ 
/* 198 */       if ("0".equals(apply.getApplyType())) {
/* 199 */         content = content + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.transmitCode") + "[" + apply.getElectronicCode() + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.to2") + "" + proposerPhone;
/*     */       }
/*     */ 
/* 211 */       log.debug("--content:" + content);
/* 212 */       model.setContent(content);
/* 213 */       UniTouchUtil.sendSmsMessage(model, approverPhone);
/*     */     } catch (ServiceException e) {
/* 215 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.auditSendSmsFail") + "", e);
/*     */ 
/* 217 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.auditSendSmsFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doAffirmApply(String applyId, String code) throws ServiceException
/*     */   {
/*     */     try {
/* 224 */       log.debug("in doAffirmApply");
/*     */ 
/* 226 */       UserRightApply apply = getApplyById(applyId);
/* 227 */       if (apply == null) {
/* 228 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.applyNotExist") + "!");
/*     */       }
/* 230 */       if (!apply.getState().equals("0")) {
/* 231 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotConfirmApplyPass"));
/*     */       }
/*     */ 
/* 234 */       if (!StringUtils.equals(code, apply.getElectronicCode())) {
/* 235 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.codeNotRight") + "!");
/*     */       }
/*     */ 
/* 238 */       apply.setApprovalTime(new Date());
/* 239 */       apply.setState("1");
/* 240 */       this.userRightApplyDao.update(apply);
/*     */ 
/* 242 */       Collection rightList = getUserTempRightService().getTempRightsByApplyId(applyId);
/* 243 */       for (UserTempRight right : rightList) {
/* 244 */         right.setState("1");
/*     */       }
/* 246 */       getUserTempRightService().updateTempRights(rightList);
/*     */ 
/* 250 */       log.debug("end doAffirmApply");
/*     */     } catch (DaoException e) {
/* 252 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.confirmApplyFail") + "", e);
/* 253 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.confirmApplyFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Collection<UserRightApply> getCurrentAndFutureApplys(String userId)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 262 */       log.debug("in getCurrentAndFutureApplys");
/* 263 */       return getUserRightApplyDao().getCurrentAndFutureApplys(userId);
/*     */     } catch (DaoException e) {
/* 265 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryApplyFail") + "", e);
/* 266 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryApplyFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public IUserRightApplyDao getUserRightApplyDao() {
/* 271 */     return this.userRightApplyDao;
/*     */   }
/*     */ 
/*     */   public void setUserRightApplyDao(IUserRightApplyDao userRightApplyDao) {
/* 275 */     this.userRightApplyDao = userRightApplyDao;
/*     */   }
/*     */ 
/*     */   public IUserTempRightService getUserTempRightService() {
/* 279 */     return this.userTempRightService;
/*     */   }
/*     */ 
/*     */   public void setUserTempRightService(IUserTempRightService userTempRightService) {
/* 283 */     this.userTempRightService = userTempRightService;
/*     */   }
/*     */ 
/*     */   public IUserAdminService getUserAdminService() {
/* 287 */     return this.userAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserAdminService(IUserAdminService userAdminService) {
/* 291 */     this.userAdminService = userAdminService;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.tempright.service.impl.UserRightApplyService
 * JD-Core Version:    0.6.2
 */
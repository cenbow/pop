/*     */ package com.asiainfo.biframe.privilege.tempright.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.DaoException;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.exception.ValidateException;
/*     */ import com.asiainfo.biframe.privilege.base.exception.MessageException;
/*     */ import com.asiainfo.biframe.privilege.base.util.UniTouchUtil;
/*     */ import com.asiainfo.biframe.privilege.model.UserRightApply;
/*     */ import com.asiainfo.biframe.privilege.model.UserTempRight;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserUserDAO;
/*     */ import com.asiainfo.biframe.privilege.tempright.dao.IUserTempRightDao;
/*     */ import com.asiainfo.biframe.privilege.tempright.service.IUserTempRightService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringRandom;
/*     */ import com.asiainfo.biframe.utils.webservice.uniTouch.TaskModel;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserTempRightService
/*     */   implements IUserTempRightService
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(UserTempRightService.class);
/*     */   private IUserTempRightDao userTempRightDao;
/*     */   private IUserUserDAO userUserDao;
/*     */ 
/*     */   public IUserUserDAO getUserUserDao()
/*     */   {
/*  53 */     return this.userUserDao;
/*     */   }
/*     */ 
/*     */   public void setUserUserDao(IUserUserDAO userUserDao)
/*     */   {
/*  64 */     this.userUserDao = userUserDao;
/*     */   }
/*     */ 
/*     */   public Collection<UserTempRight> getCurrentTempRights(String userId, Date currDate) throws ServiceException {
/*     */     try {
/*  69 */       log.debug(" in getTempRighgs");
/*  70 */       return getUserTempRightDao().getTempRights(userId, currDate);
/*     */     } catch (DaoException e) {
/*  72 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/*  73 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteTempRights(Collection<UserTempRight> rights)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/*  82 */       log.debug("in deleteTempRights");
/*  83 */       getUserTempRightDao().deleteTempRights(rights);
/*     */     } catch (DaoException e) {
/*  85 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteTempRightFail") + "", e);
/*  86 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Collection<UserTempRight> getTempRightsByApplyId(String applyId)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/*  95 */       log.debug("in getTempRightsByApplyId");
/*  96 */       return getUserTempRightDao().getTempRightsByApplyId(applyId);
/*     */     } catch (DaoException e) {
/*  98 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.byApply") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail2") + "", e);
/*  99 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.byApply") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail2") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveTempRights(Collection<UserTempRight> rights)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 108 */       log.debug("in saveTempRights");
/* 109 */       getUserTempRightDao().saveTempRights(rights);
/*     */     } catch (DaoException e) {
/* 111 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveTempRightFail") + "", e);
/* 112 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.saveTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateTempRights(Collection<UserTempRight> rights)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 121 */       log.debug("in updateTempRights");
/* 122 */       getUserTempRightDao().updateTempRights(rights);
/*     */     } catch (DaoException e) {
/* 124 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyTempRightFail") + "", e);
/* 125 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.modifyTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public IUserTempRightDao getUserTempRightDao() {
/* 130 */     return this.userTempRightDao;
/*     */   }
/*     */ 
/*     */   public void setUserTempRightDao(IUserTempRightDao userTempRightDao) {
/* 134 */     this.userTempRightDao = userTempRightDao;
/*     */   }
/*     */ 
/*     */   public void deleteTempRights(DeletedParameterVO paraObject)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 144 */       log.debug("in deleteTempRights");
/* 145 */       getUserTempRightDao().deleteTempRights(paraObject);
/*     */     } catch (DaoException e) {
/* 147 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteTempRightFail") + "", e);
/* 148 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.deleteTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String doCreateApply(UserRightApply apply, List<UserTempRight> rightList)
/*     */     throws MessageException, ServiceException
/*     */   {
/* 159 */     log.debug("in doCreateApply");
/* 160 */     if ((rightList == null) || (rightList.isEmpty())) {
/* 161 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.noTempRightChosen") + "!");
/*     */     }
/*     */     String code;
/*     */     try
/*     */     {
/* 166 */       StringRandom gen = new StringRandom();
/* 167 */       gen.setCharset("0-9");
/* 168 */       gen.setLength(4);
/* 169 */       code = gen.getRandom();
/*     */     } catch (Exception e1) {
/* 171 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRandomCodeFail") + "", e1);
/* 172 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.createApplyFail") + ":" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getRandomCodeFail") + "", e1);
/*     */     }
/*     */     try
/*     */     {
/* 176 */       String rightState = "0";
/* 177 */       apply.setElectronicCode(code);
/* 178 */       if ("0".equals(apply.getApplyType())) {
/* 179 */         apply.setState("0");
/* 180 */       } else if ("1".equals(apply.getApplyType())) {
/* 181 */         apply.setState("1");
/* 182 */         rightState = "1";
/*     */       }
/* 184 */       apply.setApplyTime(new Date());
/* 185 */       String applyId = this.userTempRightDao.saveRightApply(apply);
/*     */ 
/* 187 */       for (UserTempRight right : rightList) {
/* 188 */         right.setApplyId(applyId);
/* 189 */         right.setState(rightState);
/*     */       }
/* 191 */       saveTempRights(rightList);
/*     */ 
/* 193 */       sendSmsMessage(apply, rightList);
/*     */ 
/* 197 */       log.debug("end doCreateApply");
/* 198 */       return applyId;
/*     */     } catch (ServiceException e) {
/* 200 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.createApplyFail") + "", e);
/* 201 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.createApplyFail") + ":" + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void sendSmsMessage(UserRightApply apply, List<UserTempRight> rightList)
/*     */     throws MessageException, ServiceException
/*     */   {
/* 209 */     User_User proposerUser = getUserUserDao().findById(apply.getProposerId());
/* 210 */     String proposerPhone = proposerUser.getMobilephone();
/* 211 */     if ((proposerUser == null) || (StringUtils.isBlank(proposerPhone))) {
/* 212 */       throw new ValidateException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.notGetApplyerPhone"));
/*     */     }
/* 214 */     String approverPhone = apply.getApproverPhone();
/* 215 */     if (StringUtils.isBlank(approverPhone)) {
/* 216 */       throw new ValidateException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.sendSmsFail2") + "");
/*     */     }
/*     */     try
/*     */     {
/* 220 */       TaskModel model = new TaskModel();
/* 221 */       model.setCreator(proposerPhone);
/* 222 */       String content = null;
/* 223 */       if ("0".equals(apply.getApplyType())) {
/* 224 */         model.setSubject(proposerUser.getUsername() + "-" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.tempRightApply") + "-" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.electronicCode") + ":" + apply.getElectronicCode());
/*     */ 
/* 233 */         content = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.needApplication") + ":";
/*     */       }
/* 236 */       else if ("1".equals(apply.getApplyType())) {
/* 237 */         model.setSubject(proposerUser.getUsername() + "-" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.tempRightApply"));
/*     */ 
/* 241 */         content = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.needNotApplication") + ":";
/*     */       }
/*     */ 
/* 244 */       content = content + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.biUser") + "[" + proposerUser.getUsername() + "]" + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.applyTempRight") + "";
/*     */ 
/* 252 */       for (UserTempRight right : rightList) {
/* 253 */         content = content + right.getResourceName();
/* 254 */         if (!right.getOperationType().equals("-1")) {
/* 255 */           content = content + "-" + right.getOperationName();
/*     */         }
/* 257 */         content = content + ",";
/*     */       }
/* 259 */       content = content.substring(0, content.length() - 1) + ";" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.effectDate") + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.from") + "" + apply.getBeginDateStr() + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.to") + "" + apply.getEndDateStr() + ".";
/*     */ 
/* 274 */       if ("0".equals(apply.getApplyType())) {
/* 275 */         content = content + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.transmitCode") + "[" + apply.getElectronicCode() + "]" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.to2") + "" + proposerPhone;
/*     */       }
/*     */ 
/* 287 */       log.debug("--content:" + content);
/* 288 */       model.setContent(content);
/* 289 */       UniTouchUtil.sendSmsMessage(model, approverPhone);
/*     */     } catch (ServiceException e) {
/* 291 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.auditSendSmsFail") + "", e);
/*     */ 
/* 293 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.auditSendSmsFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doAffirmApply(String applyId, String code)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 306 */       log.debug("in doAffirmApply");
/*     */ 
/* 308 */       UserRightApply apply = getUserTempRightDao().findApplyById(applyId);
/* 309 */       if (apply == null) {
/* 310 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.applyNotExist") + "!");
/*     */       }
/* 312 */       if (!apply.getState().equals("0")) {
/* 313 */         throw new ServiceException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotConfirmApplyPass"));
/*     */       }
/*     */ 
/* 316 */       if (!StringUtils.equals(code, apply.getElectronicCode())) {
/* 317 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.codeNotRight") + "!");
/*     */       }
/*     */ 
/* 320 */       apply.setApprovalTime(new Date());
/* 321 */       apply.setState("1");
/* 322 */       getUserTempRightDao().updateApply(apply);
/*     */ 
/* 324 */       Collection rightList = getTempRightsByApplyId(applyId);
/* 325 */       for (UserTempRight right : rightList) {
/* 326 */         right.setState("1");
/*     */       }
/* 328 */       updateTempRights(rightList);
/*     */ 
/* 332 */       log.debug("end doAffirmApply");
/*     */     } catch (DaoException e) {
/* 334 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.confirmApplyFail") + "", e);
/* 335 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.confirmApplyFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public UserRightApply getRightApply(String applyId)
/*     */     throws ServiceException
/*     */   {
/* 346 */     return getUserTempRightDao().findApplyById(applyId);
/*     */   }
/*     */ 
/*     */   public List<UserTempRight> getCurrentTempRights(String userId, Date currDate, int resourceType)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/* 354 */       log.debug(" in getTempRighgs");
/* 355 */       return getUserTempRightDao().getTempRightList(userId, currDate, resourceType);
/*     */     } catch (DaoException e) {
/* 357 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/* 358 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryTempRightFail") + "", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.tempright.service.impl.UserTempRightService
 * JD-Core Version:    0.6.2
 */
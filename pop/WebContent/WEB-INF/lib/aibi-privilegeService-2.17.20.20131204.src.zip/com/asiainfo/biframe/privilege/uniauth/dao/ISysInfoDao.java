package com.asiainfo.biframe.privilege.uniauth.dao;

import com.asiainfo.biframe.privilege.model.SysInfo;
import java.util.List;

public abstract interface ISysInfoDao
{
  public abstract SysInfo getSysInfoById(String paramString)
    throws Exception;

  public abstract void save(SysInfo paramSysInfo)
    throws Exception;

  public abstract void update(SysInfo paramSysInfo)
    throws Exception;

  public abstract void delete(SysInfo paramSysInfo)
    throws Exception;

  public abstract List findAllSysInfoList();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.dao.ISysInfoDao
 * JD-Core Version:    0.6.2
 */
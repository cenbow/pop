package com.asiainfo.biframe.privilege.uniauth.dao;

import com.asiainfo.biframe.privilege.model.UniauthUserParam;
import java.util.List;

public abstract interface IUniauthUserParamDao
{
  public abstract UniauthUserParam getParamObj(String paramString1, int paramInt, String paramString2);

  public abstract List findParamByPortletId(String paramString);

  public abstract void saveParam(UniauthUserParam paramUniauthUserParam);

  public abstract void updateParam(UniauthUserParam paramUniauthUserParam);

  public abstract void deleteParam(UniauthUserParam paramUniauthUserParam);

  public abstract void deleteParamByPortletId(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.dao.IUniauthUserParamDao
 * JD-Core Version:    0.6.2
 */
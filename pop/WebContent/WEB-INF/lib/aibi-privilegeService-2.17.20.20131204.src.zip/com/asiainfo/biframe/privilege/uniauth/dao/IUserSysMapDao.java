package com.asiainfo.biframe.privilege.uniauth.dao;

import com.asiainfo.biframe.privilege.model.UserSysMap;
import java.util.Collection;
import java.util.Map;

public abstract interface IUserSysMapDao
{
  public abstract String getMapUserId(String paramString1, String paramString2);

  public abstract UserSysMap getUserSysMap(String paramString1, String paramString2);

  public abstract void save(UserSysMap paramUserSysMap)
    throws Exception;

  public abstract void update(UserSysMap paramUserSysMap)
    throws Exception;

  public abstract void delete(UserSysMap paramUserSysMap)
    throws Exception;

  public abstract Map getPagedOtherUsers(UserSysMap paramUserSysMap, int paramInt1, int paramInt2);

  public abstract Collection<UserSysMap> getAllOtherUsers();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.dao.IUserSysMapDao
 * JD-Core Version:    0.6.2
 */
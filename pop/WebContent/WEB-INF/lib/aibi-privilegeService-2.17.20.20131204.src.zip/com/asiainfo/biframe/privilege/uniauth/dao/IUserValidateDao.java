package com.asiainfo.biframe.privilege.uniauth.dao;

import com.asiainfo.biframe.privilege.model.UserValidate;

public abstract interface IUserValidateDao
{
  public abstract UserValidate getUserValidateById(String paramString1, String paramString2);

  public abstract String getMapUserId(String paramString1, String paramString2);

  public abstract void save(UserValidate paramUserValidate)
    throws Exception;

  public abstract void update(UserValidate paramUserValidate)
    throws Exception;

  public abstract void delete(UserValidate paramUserValidate)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.dao.IUserValidateDao
 * JD-Core Version:    0.6.2
 */
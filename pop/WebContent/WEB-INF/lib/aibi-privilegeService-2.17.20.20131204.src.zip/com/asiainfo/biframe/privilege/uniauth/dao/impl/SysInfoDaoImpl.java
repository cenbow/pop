/*    */ package com.asiainfo.biframe.privilege.uniauth.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.SysInfo;
/*    */ import com.asiainfo.biframe.privilege.uniauth.dao.ISysInfoDao;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class SysInfoDaoImpl extends HibernateDaoSupport
/*    */   implements ISysInfoDao
/*    */ {
/* 21 */   private static Logger log = Logger.getLogger(SysInfoDaoImpl.class);
/*    */ 
/*    */   public SysInfo getSysInfoById(String SysId)
/*    */     throws Exception
/*    */   {
/* 33 */     return (SysInfo)getHibernateTemplate().get(SysInfo.class, new Long(SysId));
/*    */   }
/*    */ 
/*    */   public void save(SysInfo sysInfo)
/*    */     throws Exception
/*    */   {
/* 40 */     getHibernateTemplate().save(sysInfo);
/*    */   }
/*    */ 
/*    */   public void update(SysInfo sysInfo)
/*    */     throws Exception
/*    */   {
/* 47 */     getHibernateTemplate().update(sysInfo);
/*    */   }
/*    */ 
/*    */   public void delete(SysInfo sysInfo)
/*    */     throws Exception
/*    */   {
/* 54 */     getHibernateTemplate().delete(sysInfo);
/*    */   }
/*    */ 
/*    */   public List findAllSysInfoList()
/*    */   {
/* 61 */     log.debug(" in findAllSysInfoList");
/* 62 */     return getHibernateTemplate().find(" from SysInfo sys order by sys.sysId");
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.dao.impl.SysInfoDaoImpl
 * JD-Core Version:    0.6.2
 */
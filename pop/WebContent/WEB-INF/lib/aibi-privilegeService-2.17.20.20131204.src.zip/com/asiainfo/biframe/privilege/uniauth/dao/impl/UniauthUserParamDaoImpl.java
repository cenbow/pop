/*    */ package com.asiainfo.biframe.privilege.uniauth.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.UniauthUserParam;
/*    */ import com.asiainfo.biframe.privilege.uniauth.dao.IUniauthUserParamDao;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UniauthUserParamDaoImpl extends HibernateDaoSupport
/*    */   implements IUniauthUserParamDao
/*    */ {
/*    */   public UniauthUserParam getParamObj(String userid, int portletId, String param)
/*    */   {
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   public void saveParam(UniauthUserParam param)
/*    */   {
/* 44 */     getHibernateTemplate().save(param);
/*    */   }
/*    */ 
/*    */   public void updateParam(UniauthUserParam param)
/*    */   {
/* 52 */     getHibernateTemplate().update(param);
/*    */   }
/*    */ 
/*    */   public void deleteParam(UniauthUserParam param)
/*    */   {
/* 61 */     getHibernateTemplate().delete(param);
/*    */   }
/*    */ 
/*    */   public List findParamByPortletId(String portletId)
/*    */   {
/* 66 */     List paramList = getHibernateTemplate().find("from UniauthUserParam uup where uup.id.portletId = '" + portletId + "'");
/*    */ 
/* 68 */     return paramList;
/*    */   }
/*    */ 
/*    */   public void deleteParamByPortletId(String portletId)
/*    */   {
/* 76 */     List paramList = findParamByPortletId(portletId);
/* 77 */     getHibernateTemplate().deleteAll(paramList);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.dao.impl.UniauthUserParamDaoImpl
 * JD-Core Version:    0.6.2
 */
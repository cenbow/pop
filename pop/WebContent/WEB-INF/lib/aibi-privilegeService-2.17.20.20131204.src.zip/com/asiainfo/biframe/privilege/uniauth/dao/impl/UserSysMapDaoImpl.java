/*     */ package com.asiainfo.biframe.privilege.uniauth.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.base.util.SqlUtil;
/*     */ import com.asiainfo.biframe.privilege.model.UserSysMap;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IUserGroupMapDAO;
/*     */ import com.asiainfo.biframe.privilege.uniauth.dao.IUserSysMapDao;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserSysMapDaoImpl extends HibernateDaoSupport
/*     */   implements IUserSysMapDao
/*     */ {
/*  38 */   private static Logger log = Logger.getLogger(UserSysMapDaoImpl.class);
/*     */   private IUserGroupMapDAO userGroupMapDao;
/*     */ 
/*     */   public String getMapUserId(String userId, String sysId)
/*     */   {
/*  45 */     List list = getHibernateTemplate().find("from UserSysMap ugm where ugm.id.localUserId = '" + userId + "' " + " and ugm.id.otherSysId=" + sysId);
/*     */ 
/*  47 */     String mapUserId = "";
/*  48 */     if ((null != list) && (list.size() > 0)) {
/*  49 */       mapUserId = ((UserSysMap)list.get(0)).getOtherUserId();
/*     */     }
/*  51 */     return mapUserId;
/*     */   }
/*     */ 
/*     */   public UserSysMap getUserSysMap(String userId, String sysId)
/*     */   {
/*  57 */     List list = getHibernateTemplate().find("from UserSysMap ugm where ugm.id.localUserId = '" + userId + "' " + " and ugm.id.otherSysId=" + sysId);
/*     */ 
/*  59 */     UserSysMap userSysMap = null;
/*  60 */     if ((null != list) && (list.size() > 0)) {
/*  61 */       userSysMap = (UserSysMap)list.get(0);
/*     */     }
/*  63 */     return userSysMap;
/*     */   }
/*     */ 
/*     */   public void save(UserSysMap userSysMap) throws Exception {
/*  67 */     getHibernateTemplate().save(userSysMap);
/*     */   }
/*     */ 
/*     */   public void update(UserSysMap userSysMap) throws Exception {
/*  71 */     getHibernateTemplate().update(userSysMap);
/*     */   }
/*     */   public void delete(UserSysMap userSysMap) throws Exception {
/*  74 */     getHibernateTemplate().delete(userSysMap);
/*     */   }
/*     */ 
/*     */   public Collection<UserSysMap> getAllOtherUsers() {
/*  78 */     log.debug("in getAllOtherUsers");
/*  79 */     String sql = "from UserSysMap usermap order by usermap.otherSysId,usermap.otherUserId";
/*  80 */     List list = getHibernateTemplate().find(sql);
/*     */ 
/*  82 */     Collection otherUsers = populateOtherUserList(list);
/*     */ 
/*  84 */     log.debug("otherUsers.size:" + otherUsers.size());
/*  85 */     log.debug("end getAllOtherUsers");
/*  86 */     return otherUsers;
/*     */   }
/*     */ 
/*     */   public Map getPagedOtherUsers(UserSysMap userSysMap, int currPage, int pageSize)
/*     */   {
/*  93 */     log.debug("in getPagedOtherUsers");
/*     */ 
/*  95 */     String selectSql = "select usermap ";
/*  96 */     String fromSql = " from UserSysMap usermap ";
/*  97 */     String whereSql = getWhereSql(userSysMap);
/*  98 */     String orderbySql = " order by usermap.otherSysId,usermap.otherUserId";
/*     */ 
/* 100 */     String localUserCityId = userSysMap.getLocalUserCityId();
/* 101 */     if ((StringUtils.isNotBlank(localUserCityId)) && (!"-1".equals(localUserCityId))) {
/* 102 */       fromSql = fromSql + ",User_City uc,User_User uu ";
/* 103 */       localUserCityId = SqlUtil.getSqlIn(localUserCityId, "uc.cityId");
/* 104 */       whereSql = whereSql + " and usermap.localUserId=uu.userid and uu.cityid=uc.cityId and (" + localUserCityId + ")";
/*     */     }
/*     */ 
/* 107 */     String localUserGroupId = userSysMap.getLocalUserGroupId();
/* 108 */     if ((StringUtils.isNotBlank(localUserGroupId)) && (!"-1".equals(localUserGroupId))) {
/* 109 */       fromSql = fromSql + ",UserGroupMap ugm  ";
/* 110 */       localUserGroupId = SqlUtil.getSqlIn(localUserGroupId, "ugm.groupId");
/* 111 */       whereSql = whereSql + " and usermap.localUserId=ugm.userid and (" + localUserGroupId + ")";
/*     */     }
/*     */ 
/* 114 */     String countSql = "select count(*) " + fromSql + whereSql;
/* 115 */     log.debug("-countSql:" + countSql);
/* 116 */     List countList = getHibernateTemplate().find(countSql);
/* 117 */     Long total = (Long)countList.get(0);
/*     */ 
/* 119 */     String querySql = selectSql + fromSql + whereSql + orderbySql;
/* 120 */     log.debug("-querySql:" + querySql);
/* 121 */     List list = getPagedList(currPage, pageSize, querySql);
/*     */ 
/* 123 */     Collection otherUsers = populateOtherUserList(list);
/*     */ 
/* 125 */     Map map = new HashMap();
/* 126 */     map.put("total", total);
/* 127 */     map.put("result", otherUsers);
/*     */ 
/* 129 */     log.debug("end getPagedOtherUsers");
/* 130 */     return map;
/*     */   }
/*     */   private List getPagedList(final int currPage, final int pageSize, final String querySql) {
/* 133 */     List list = getHibernateTemplate().executeFind(new HibernateCallback() {
/*     */       public Object doInHibernate(Session s) throws HibernateException, SQLException {
/* 135 */         Query query = s.createQuery(querySql);
/* 136 */         int firstResult = currPage * pageSize;
/* 137 */         int maxResult = pageSize;
/* 138 */         query.setFirstResult(firstResult);
/* 139 */         query.setMaxResults(maxResult);
/* 140 */         List tmpList = query.list();
/* 141 */         return tmpList;
/*     */       }
/*     */     });
/* 144 */     return list;
/*     */   }
/*     */ 
/*     */   private String getWhereSql(UserSysMap userSysMap)
/*     */   {
/* 149 */     StringBuilder whereSql = new StringBuilder(256).append(" where 1=1 ");
/* 150 */     Long otherSysId = userSysMap.getOtherSysId();
/* 151 */     if ((otherSysId != null) && (otherSysId.longValue() != Long.parseLong("-1"))) {
/* 152 */       whereSql.append(" and usermap.otherSysId=").append(otherSysId);
/*     */     }
/* 154 */     String otherUserId = userSysMap.getOtherUserId();
/* 155 */     if (StringUtils.isNotBlank(otherUserId)) {
/* 156 */       whereSql.append(" and usermap.otherUserId like '%").append(otherUserId).append("%'");
/*     */     }
/* 158 */     String localUserId = userSysMap.getLocalUserId();
/* 159 */     if ((StringUtils.isNotBlank(localUserId)) && (!"-1".equals(localUserId))) {
/* 160 */       whereSql.append(" and usermap.localUserId ='").append(localUserId).append("'");
/*     */     }
/* 162 */     return whereSql.toString();
/*     */   }
/*     */ 
/*     */   private Collection<UserSysMap> populateOtherUserList(List<UserSysMap> list)
/*     */   {
/* 167 */     Collection otherUsers = new ArrayList();
/* 168 */     for (UserSysMap map : list) {
/* 169 */       String localUserId = map.getLocalUserId();
/* 170 */       Long sysId = map.getOtherSysId();
/* 171 */       String otherUserId = map.getOtherUserId();
/* 172 */       String otherUserPwd = map.getOtherUserPwd();
/* 173 */       String notes = map.getNotes();
/* 174 */       String param0 = map.getParam0();
/* 175 */       String param1 = map.getParam1();
/* 176 */       String param2 = map.getParam2();
/* 177 */       String param3 = map.getParam3();
/*     */ 
/* 180 */       String sysName = "";
/* 181 */       String sysInfoSql = "select si.sysName from SysInfo si where si.sysId=" + sysId;
/* 182 */       List sysInfoMap = getHibernateTemplate().find(sysInfoSql);
/* 183 */       if (!sysInfoMap.isEmpty()) {
/* 184 */         sysName = (String)sysInfoMap.get(0);
/*     */       }
/*     */ 
/* 188 */       String localUserName = "";
/* 189 */       String localUserCityId = "";
/* 190 */       String localUserCityName = "";
/* 191 */       String localUserSql = "select uu.username,uc.cityId,uc.cityName from User_User uu,User_City uc where uu.userid = '" + localUserId + "' and uc.cityId = uu.cityid ";
/* 192 */       List localUsers = getHibernateTemplate().find(localUserSql);
/* 193 */       if (!localUsers.isEmpty()) {
/* 194 */         localUserName = (String)((Object[])localUsers.get(0))[0];
/* 195 */         localUserCityId = (String)((Object[])localUsers.get(0))[1];
/* 196 */         localUserCityName = (String)((Object[])localUsers.get(0))[2];
/*     */       } else {
/* 198 */         localUserId = "" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.userNotExist") + "";
/* 199 */         localUserName = "" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.userNotExist") + "";
/*     */       }
/*     */ 
/* 203 */       String localUserGroupId = "" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.userHasNoGroup") + "";
/* 204 */       String localUserGroupName = "" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.userHasNoGroup") + "";
/* 205 */       List groupList = getUserGroupMapDao().getGroupByUserId(localUserId);
/* 206 */       if ((groupList != null) && (groupList.size() > 0)) {
/* 207 */         User_Group group = (User_Group)groupList.get(0);
/* 208 */         if (group != null) {
/* 209 */           localUserGroupId = group.getGroupid();
/* 210 */           localUserGroupName = group.getGroupname();
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 215 */       UserSysMap userSysMap = new UserSysMap();
/*     */ 
/* 221 */       userSysMap.setLocalUserId(localUserId);
/* 222 */       userSysMap.setOtherSysId(Long.valueOf(sysId.toString()));
/* 223 */       userSysMap.setOtherUserId(otherUserId);
/*     */ 
/* 225 */       userSysMap.setOtherSysName(sysName);
/* 226 */       userSysMap.setOtherUserPwd(otherUserPwd);
/* 227 */       userSysMap.setLocalUserName(localUserName);
/* 228 */       userSysMap.setLocalUserGroupId(localUserGroupId);
/* 229 */       userSysMap.setLocalUserGroupName(localUserGroupName);
/* 230 */       userSysMap.setLocalUserCityId(localUserCityId);
/* 231 */       userSysMap.setLocalUserCityName(localUserCityName);
/*     */ 
/* 233 */       otherUsers.add(userSysMap);
/*     */     }
/* 235 */     return otherUsers;
/*     */   }
/*     */   public IUserGroupMapDAO getUserGroupMapDao() {
/* 238 */     return this.userGroupMapDao;
/*     */   }
/*     */   public void setUserGroupMapDao(IUserGroupMapDAO userGroupMapDao) {
/* 241 */     this.userGroupMapDao = userGroupMapDao;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.dao.impl.UserSysMapDaoImpl
 * JD-Core Version:    0.6.2
 */
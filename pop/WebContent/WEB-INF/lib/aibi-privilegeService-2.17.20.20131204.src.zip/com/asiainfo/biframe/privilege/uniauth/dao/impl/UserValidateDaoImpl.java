/*    */ package com.asiainfo.biframe.privilege.uniauth.dao.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.model.UserValidate;
/*    */ import com.asiainfo.biframe.privilege.uniauth.dao.IUserValidateDao;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserValidateDaoImpl extends HibernateDaoSupport
/*    */   implements IUserValidateDao
/*    */ {
/*    */   protected void initDao()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UserValidate getUserValidateById(String sessionId, String tokenId)
/*    */   {
/* 39 */     List list = getHibernateTemplate().find("from UserValidate ugm where ugm.id.sessionId = '" + sessionId + "' " + " and ugm.id.tokenId='" + tokenId + "'");
/*    */ 
/* 42 */     UserValidate userValidate = null;
/* 43 */     if ((null != list) && (list.size() > 0)) {
/* 44 */       userValidate = (UserValidate)list.get(0);
/*    */     }
/* 46 */     return userValidate;
/*    */   }
/*    */ 
/*    */   public String getMapUserId(String sessionId, String tokenId)
/*    */   {
/* 54 */     String mapUserId = "";
/* 55 */     UserValidate userValidate = getUserValidateById(sessionId, tokenId);
/* 56 */     if ((null != userValidate) && (userValidate.getStatus().intValue() == 0))
/* 57 */       mapUserId = userValidate.getMapUserid();
/* 58 */     return mapUserId;
/*    */   }
/*    */ 
/*    */   public void save(UserValidate userValidate)
/*    */     throws Exception
/*    */   {
/* 66 */     getHibernateTemplate().save(userValidate);
/*    */   }
/*    */ 
/*    */   public void update(UserValidate userValidate)
/*    */     throws Exception
/*    */   {
/* 74 */     getHibernateTemplate().update(userValidate);
/*    */   }
/*    */ 
/*    */   public void delete(UserValidate userValidate)
/*    */     throws Exception
/*    */   {
/* 82 */     getHibernateTemplate().delete(userValidate);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.dao.impl.UserValidateDaoImpl
 * JD-Core Version:    0.6.2
 */
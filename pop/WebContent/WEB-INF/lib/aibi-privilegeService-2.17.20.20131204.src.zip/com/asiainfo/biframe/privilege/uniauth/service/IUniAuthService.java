package com.asiainfo.biframe.privilege.uniauth.service;

import com.asiainfo.biframe.privilege.model.SysInfo;
import com.asiainfo.biframe.privilege.model.UserValidate;
import java.util.List;

public abstract interface IUniAuthService
{
  public abstract void saveUserValidate(UserValidate paramUserValidate)
    throws Exception;

  public abstract void updateUserValidate(UserValidate paramUserValidate)
    throws Exception;

  public abstract String generateForward(String paramString1, String paramString2, String paramString3);

  public abstract String getMapUserId(String paramString1, String paramString2);

  public abstract SysInfo getSysInfo(String paramString);

  public abstract void saveUserParam(String paramString1, String paramString2, List paramList);

  public abstract List getAllSysInfoList();

  public abstract void deleteUserParam(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.service.IUniAuthService
 * JD-Core Version:    0.6.2
 */
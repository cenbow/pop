package com.asiainfo.biframe.privilege.uniauth.service;

import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
import com.asiainfo.biframe.privilege.model.User_Group;
import com.asiainfo.biframe.privilege.model.User_User;
import java.util.List;
import java.util.Map;

public abstract interface IUserRightService
{
  public abstract List getResourceIdListOfRight(String paramString1, String paramString2);

  public abstract List getResourceIdListOfRight(String paramString1, boolean paramBoolean, String paramString2);

  public abstract List getRoleIdListOfUser(String paramString1, String paramString2);

  public abstract List getAllRoleMapList(String paramString);

  public abstract List getAuthCityList(String paramString1, String paramString2);

  public abstract String getRootCityId();

  public abstract boolean isAdminUser(String paramString);

  public abstract List getMenuObjList(List paramList);

  public abstract String getUserCurrentCity(String paramString);

  public abstract User_User getUser(String paramString);

  public abstract User_Group getGroupObj(String paramString);

  public abstract String getGroupId(String paramString);

  public abstract Map getUserMap(String paramString);

  public abstract void updateUser(User_User paramUser_User);

  public abstract int savePwd2History(String paramString1, String paramString2, String paramString3);

  public abstract int savePwd2History(String paramString1, String paramString2);

  public abstract List getUserGroupByIds(List paramList);

  public abstract List getSubGroup(String paramString);

  public abstract Map userToMap(User_User paramUser_User);

  public abstract boolean isPwdRepeated(String paramString1, String paramString2);

  public abstract String genXTreeQuerySql(String paramString1, boolean paramBoolean, String paramString2, String paramString3);

  public abstract List getSystemMenuResourceListOfRight(String paramString);

  public abstract List getUserSubGroupList(String paramString);

  public abstract List<SysMenuItemBean> getSystemMenuResourceListByName(String paramString);

  public abstract List<SysMenuItemBean> getAllParentSystemMenuResouceList(int paramInt);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.service.IUserRightService
 * JD-Core Version:    0.6.2
 */
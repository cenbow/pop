/*     */ package com.asiainfo.biframe.privilege.uniauth.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.pwdpolicy.model.PwdPolicyInfo;
/*     */ import com.asiainfo.biframe.privilege.pwdpolicy.service.PwdPolicyService;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class NewPswd
/*     */ {
/*  28 */   private String UPPER_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
/*  29 */   private String LOWER_CHARS = "abcdefghijklmnopqrstuvwxyz";
/*  30 */   private String NUMBER_CHARS = "0123456789";
/*  31 */   private String SPECIAL_CHARS = "!@#$%&*";
/*     */ 
/*     */   public String getNewPassword()
/*     */   {
/*  39 */     String strPswd = "";
/*     */ 
/*  51 */     StringBuffer seeds = new StringBuffer();
/*  52 */     PwdPolicyInfo policyInfo = getPolicyInfo();
/*  53 */     int needUpperCase = policyInfo.getUpperCase();
/*  54 */     int needLowerCase = policyInfo.getLowerCase();
/*  55 */     int needNumberCase = policyInfo.getNumberCase();
/*  56 */     int needSpecialCase = policyInfo.getSpecialCase();
/*  57 */     int pwdMinLen = policyInfo.getPwdMinLen();
/*  58 */     int loginRetryCount = policyInfo.getLoginRetryCount();
/*  59 */     String excludeChars = policyInfo.getExcludeChars();
/*  60 */     if (1 == needUpperCase)
/*     */     {
/*  63 */       this.UPPER_CHARS = excludeSomeChars(new StringBuffer(this.UPPER_CHARS), new StringBuffer(excludeChars)).toString();
/*     */ 
/*  65 */       strPswd = strPswd + generateRandom(this.UPPER_CHARS, 1);
/*     */     }
/*  67 */     if (1 == needNumberCase)
/*     */     {
/*  70 */       this.NUMBER_CHARS = excludeSomeChars(new StringBuffer(this.NUMBER_CHARS), new StringBuffer(excludeChars)).toString();
/*  71 */       strPswd = strPswd + generateRandom(this.NUMBER_CHARS, 1);
/*  72 */       this.NUMBER_CHARS = excludeSomeChars(new StringBuffer(this.NUMBER_CHARS), new StringBuffer(strPswd)).toString();
/*  73 */       strPswd = strPswd + generateRandom(this.NUMBER_CHARS, 1);
/*     */     }
/*     */ 
/*  76 */     if (1 == needSpecialCase)
/*     */     {
/*  78 */       this.SPECIAL_CHARS = excludeSomeChars(new StringBuffer(this.SPECIAL_CHARS), new StringBuffer(excludeChars)).toString();
/*  79 */       strPswd = strPswd + generateRandom(this.SPECIAL_CHARS, 1);
/*     */     }
/*     */ 
/*  83 */     if (1 == needLowerCase)
/*     */     {
/*  85 */       this.LOWER_CHARS = excludeSomeChars(new StringBuffer(this.LOWER_CHARS), new StringBuffer(excludeChars)).toString();
/*  86 */       strPswd = strPswd + generateRandom(this.LOWER_CHARS, 1);
/*  87 */       this.LOWER_CHARS = excludeSomeChars(new StringBuffer(this.LOWER_CHARS), new StringBuffer(strPswd)).toString();
/*  88 */       strPswd = strPswd + generateRandom(this.LOWER_CHARS, 1);
/*     */     }
/*  90 */     if (strPswd.trim().length() < pwdMinLen) {
/*  91 */       for (int i = 0; i <= pwdMinLen - strPswd.trim().length(); i++) {
/*  92 */         this.LOWER_CHARS = excludeSomeChars(new StringBuffer(this.LOWER_CHARS), new StringBuffer(strPswd)).toString();
/*  93 */         strPswd = strPswd + generateRandom(excludeSomeChars(new StringBuffer(this.LOWER_CHARS), new StringBuffer(strPswd)).toString(), 1);
/*     */       }
/*     */     }
/*     */ 
/*  97 */     String finallyPwd = "";
/*     */ 
/*  99 */     System.out.println(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.randomPwd") + ":" + strPswd);
/* 100 */     String dynaPwd = strPswd;
/* 101 */     for (int i = 0; i < strPswd.trim().length(); i++) {
/* 102 */       dynaPwd = excludeSomeChars(new StringBuffer(dynaPwd), new StringBuffer(finallyPwd)).toString();
/* 103 */       finallyPwd = finallyPwd + generateRandom(dynaPwd.trim(), 1);
/*     */     }
/*     */ 
/* 108 */     return finallyPwd;
/*     */   }
/*     */ 
/*     */   private StringBuffer excludeSomeChars(StringBuffer src, StringBuffer exclude)
/*     */   {
/* 120 */     for (int i = 0; i < exclude.length(); i++) {
/* 121 */       String ch = exclude.substring(i, i + 1);
/* 122 */       if (src.indexOf(ch) >= 0) {
/* 123 */         src.replace(src.indexOf(ch), src.indexOf(ch) + 1, "");
/*     */       }
/*     */     }
/*     */ 
/* 127 */     return src;
/*     */   }
/*     */ 
/*     */   private String generateRandom(String seed, int n)
/*     */   {
/* 138 */     String strPswd = "";
/* 139 */     for (int i = 0; i < n; i++) {
/* 140 */       strPswd = strPswd + seed.charAt((int)(Math.random() * seed.length()));
/*     */     }
/* 142 */     return strPswd;
/*     */   }
/*     */ 
/*     */   private PwdPolicyInfo getPolicyInfo()
/*     */   {
/* 151 */     PwdPolicyInfo policyInfo = null;
/* 152 */     PwdPolicyService policyService = new PwdPolicyService();
/* 153 */     policyInfo = PwdPolicyService.loadPwdPolicy();
/* 154 */     return policyInfo;
/*     */   }
/*     */ 
/*     */   public String setNewPassword(String strUserId)
/*     */   {
/* 160 */     Sqlca sqlca = null;
/* 161 */     String strSql = "";
/* 162 */     String strNewPassword = "";
/* 163 */     String cityID = null;
/* 164 */     String cityName = null;
/*     */     try
/*     */     {
/* 167 */       sqlca = new Sqlca(new ConnectionEx());
/*     */ 
/* 170 */       strNewPassword = getNewPassword();
/*     */ 
/* 172 */       strSql = "update user_user set pwd=" + sqlca.getSqlEncrypt(strNewPassword) + " where UserId = '" + strUserId + "'";
/* 173 */       sqlca.execute(strSql);
/* 174 */       strSql = "select cityid from user_user where userid='" + strUserId + "'";
/* 175 */       sqlca.execute(strSql);
/* 176 */       if (sqlca.next()) {
/* 177 */         cityID = sqlca.getString("cityid");
/*     */       }
/*     */ 
/* 180 */       strSql = "select cityname from user_city where cityid = '" + cityID + "'";
/* 181 */       if (sqlca.next()) {
/* 182 */         cityName = sqlca.getString("cityname");
/*     */       }
/*     */ 
/* 192 */       return strNewPassword;
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/* 188 */       excep.printStackTrace();
/*     */ 
/* 192 */       return strNewPassword;
/*     */     }
/*     */     finally
/*     */     {
/* 191 */       sqlca.closeAll();
/* 192 */     }return strNewPassword;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.service.impl.NewPswd
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.uniauth.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.model.SysInfo;
/*     */ import com.asiainfo.biframe.privilege.model.UniauthUserParam;
/*     */ import com.asiainfo.biframe.privilege.model.UniauthUserParamKey;
/*     */ import com.asiainfo.biframe.privilege.model.UserSysMap;
/*     */ import com.asiainfo.biframe.privilege.model.UserValidate;
/*     */ import com.asiainfo.biframe.privilege.model.UserValidateKey;
/*     */ import com.asiainfo.biframe.privilege.uniauth.dao.ISysInfoDao;
/*     */ import com.asiainfo.biframe.privilege.uniauth.dao.IUniauthUserParamDao;
/*     */ import com.asiainfo.biframe.privilege.uniauth.dao.IUserSysMapDao;
/*     */ import com.asiainfo.biframe.privilege.uniauth.dao.IUserValidateDao;
/*     */ import com.asiainfo.biframe.privilege.uniauth.service.IUniAuthService;
/*     */ import com.asiainfo.biframe.privilege.uniauth.service.IUserRightService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.DES;
/*     */ import com.asiainfo.biframe.utils.string.StringRandom;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UniAuthServiceImpl
/*     */   implements IUniAuthService
/*     */ {
/*  38 */   private static final Log log = LogFactory.getLog(UniAuthServiceImpl.class);
/*     */   private ISysInfoDao sysInfoDao;
/*     */   private IUserSysMapDao userSysMapDao;
/*     */   private IUserValidateDao userValidateDao;
/*     */   private IUniauthUserParamDao uniauthUserParamDao;
/*     */   private IUserRightService userRightService;
/*     */ 
/*     */   public void saveUserValidate(UserValidate uv)
/*     */     throws Exception
/*     */   {
/*  59 */     this.userValidateDao.save(uv);
/*     */   }
/*     */ 
/*     */   public void updateUserValidate(UserValidate uv)
/*     */     throws Exception
/*     */   {
/*  67 */     this.userValidateDao.update(uv);
/*     */   }
/*     */ 
/*     */   public String getMapUserId(String SessionId, String tokenId)
/*     */   {
/*  75 */     String mapUserId = "";
/*     */     try {
/*  77 */       UserValidate userValidate = this.userValidateDao.getUserValidateById(SessionId, tokenId);
/*  78 */       if (userValidate.getStatus().intValue() == 0) {
/*  79 */         mapUserId = userValidate.getMapUserid();
/*     */       }
/*  81 */       userValidate.setStatus(new Long(1L));
/*  82 */       this.userValidateDao.update(userValidate);
/*     */     }
/*     */     catch (Exception e) {
/*  85 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  88 */     return mapUserId;
/*     */   }
/*     */ 
/*     */   public SysInfo getSysInfo(String sysId)
/*     */   {
/*     */     try
/*     */     {
/*  97 */       return this.sysInfoDao.getSysInfoById(sysId);
/*     */     }
/*     */     catch (Exception e) {
/* 100 */       e.printStackTrace();
/* 101 */     }return null;
/*     */   }
/*     */ 
/*     */   public String generateForward(String sessionId, String userId, String sysId)
/*     */   {
/* 111 */     String mapUserId = getSysMapUserId(sysId, userId);
/*     */ 
/* 114 */     String tokenId = generateUserValidate(sessionId, userId, mapUserId);
/*     */ 
/* 116 */     String forwardUrl = "";
/*     */ 
/* 118 */     if ((null != sysId) && (sysId.length() > 0))
/*     */     {
/* 120 */       SysInfo sysInfo = getSysInfo(sysId);
/*     */ 
/* 122 */       String interfaceUrl = sysInfo.getInterfaceUrl();
/* 123 */       interfaceUrl = parseInterfaceUrl(interfaceUrl, userId, mapUserId, null, sysId);
/*     */ 
/* 125 */       forwardUrl = generateUrl(sessionId, tokenId, interfaceUrl);
/*     */     }
/*     */ 
/* 128 */     return forwardUrl;
/*     */   }
/*     */ 
/*     */   private String getSysMapUserId(String sysId, String userId)
/*     */   {
/* 137 */     String mapUserId = userId;
/*     */ 
/* 140 */     if ((null != sysId) && (sysId.length() > 0)) {
/* 141 */       SysInfo sysInfo = getSysInfo(sysId);
/* 142 */       int mapFlag = sysInfo.getMapFlag().intValue();
/* 143 */       if (mapFlag == 1) {
/* 144 */         mapUserId = this.userSysMapDao.getMapUserId(userId, sysId);
/*     */       }
/* 146 */       if ((null == mapUserId) || (mapUserId.length() < 1)) {
/* 147 */         mapUserId = userId;
/*     */       }
/*     */     }
/* 150 */     return mapUserId;
/*     */   }
/*     */ 
/*     */   private String generateUserValidate(String sessionId, String userId, String mapUserId)
/*     */   {
/* 161 */     String tokenId = generateToken();
/* 162 */     UserValidate userValidate = new UserValidate();
/* 163 */     UserValidateKey id = new UserValidateKey();
/* 164 */     id.setSessionId(sessionId);
/* 165 */     id.setTokenId(tokenId);
/*     */ 
/* 167 */     userValidate.setId(id);
/*     */ 
/* 169 */     userValidate.setMapUserid(mapUserId);
/* 170 */     userValidate.setUserId(userId);
/* 171 */     userValidate.setStatus(new Long(0L));
/* 172 */     userValidate.setOpDate(new Date());
/*     */     try
/*     */     {
/* 176 */       this.userValidateDao.save(userValidate);
/*     */     }
/*     */     catch (Exception e) {
/* 179 */       e.printStackTrace();
/*     */     }
/* 181 */     return tokenId;
/*     */   }
/*     */ 
/*     */   private String generateUrl(String SessionId, String tokenId, String url)
/*     */   {
/* 192 */     if (url.indexOf("?") > 0) {
/* 193 */       url = url + "&";
/*     */     }
/*     */     else {
/* 196 */       url = url + "?";
/*     */     }
/* 198 */     url = url + "sessionId=" + SessionId + "&tokenId=" + tokenId;
/* 199 */     return url;
/*     */   }
/*     */ 
/*     */   private String parseInterfaceUrl(String url, String userId, String mapUserId, Map userParamMap, String sysId)
/*     */   {
/* 210 */     String desUrl = "";
/* 211 */     while ((url.indexOf("[") >= 0) && (url.indexOf("]") >= 0)) {
/* 212 */       int nBeginPos = url.indexOf("[");
/* 213 */       int nEndPos = url.indexOf("]");
/*     */ 
/* 215 */       desUrl = desUrl + url.substring(0, nBeginPos);
/* 216 */       String keyWord = url.substring(nBeginPos + 1, nEndPos);
/* 217 */       String keyValue = getKeyValue(keyWord, userId, mapUserId, userParamMap, sysId);
/* 218 */       desUrl = desUrl + keyValue;
/*     */ 
/* 220 */       url = url.substring(nEndPos + 1);
/*     */     }
/*     */ 
/* 223 */     desUrl = desUrl + url;
/* 224 */     return desUrl;
/*     */   }
/*     */ 
/*     */   private Map getUserParamValueMap(List userParamList, String portletId)
/*     */   {
/* 234 */     Map valueMap = new HashMap();
/* 235 */     if ((null != portletId) && (portletId.length() > 0)) {
/* 236 */       List paramList = this.uniauthUserParamDao.findParamByPortletId(portletId);
/* 237 */       if (null != paramList) {
/* 238 */         for (int i = 0; i < paramList.size(); i++) {
/* 239 */           UniauthUserParam param = (UniauthUserParam)paramList.get(i);
/* 240 */           String paramName = param.getId().getParam();
/* 241 */           String paramValue = param.getValue();
/* 242 */           valueMap.put(paramName, paramValue);
/*     */         }
/*     */       }
/*     */     }
/* 246 */     return valueMap;
/*     */   }
/*     */ 
/*     */   private String getKeyValue(String keyWord, String userId, String mapUserId, Map userParamMap, String sysId) {
/* 250 */     String keyValue = "";
/*     */ 
/* 252 */     if (keyWord.indexOf("USERPARA_") == 0) {
/* 253 */       if (null != userParamMap) {
/* 254 */         keyValue = (String)userParamMap.get(keyWord);
/*     */       }
/*     */     }
/*     */     else {
/* 258 */       keyValue = getSysKeyValue(keyWord, userId, mapUserId, sysId);
/*     */     }
/* 260 */     return keyValue;
/*     */   }
/*     */ 
/*     */   private String getSysKeyValue(String keyWord, String userId, String mapUserId, String sysId)
/*     */   {
/* 270 */     String keyValue = "";
/*     */     try
/*     */     {
/* 273 */       if (keyWord.equals("UID"))
/*     */       {
/* 275 */         keyValue = DES.encrypt(userId);
/*     */       }
/* 277 */       else if (keyWord.equals("MUID"))
/*     */       {
/* 279 */         keyValue = DES.encrypt(mapUserId);
/*     */       }
/* 281 */       else if (keyWord.equals("PWD")) {
/* 282 */         System.out.println("--PWD");
/* 283 */         UserSysMap userSysMap = getUserSysMapDao().getUserSysMap(userId, sysId);
/* 284 */         if (userSysMap == null)
/* 285 */           keyValue = "";
/*     */         else {
/* 287 */           keyValue = userSysMap.getOtherUserPwd();
/*     */         }
/* 289 */         System.out.println("--pwd:" + keyValue);
/*     */       }
/* 291 */       else if (keyWord.equals("GID"))
/*     */       {
/* 293 */         keyValue = this.userRightService.getGroupId(userId);
/*     */       }
/* 295 */       else if (keyWord.equals("CID"))
/*     */       {
/* 297 */         keyValue = this.userRightService.getUserCurrentCity(userId);
/*     */       }
/* 299 */       else if (keyWord.equals("RKIDS"))
/*     */       {
/* 301 */         List kpiIdList = this.userRightService.getResourceIdListOfRight(userId, "4");
/*     */ 
/* 303 */         String kpiIds = StringUtil.list2String(kpiIdList, ",", false);
/* 304 */         keyValue = kpiIds;
/*     */       }
/* 306 */       else if (keyWord.equals("RCIDS"))
/*     */       {
/* 308 */         List cityIdList = this.userRightService.getResourceIdListOfRight(userId, "5");
/*     */ 
/* 310 */         String cityIds = StringUtil.list2String(cityIdList, ",", false);
/* 311 */         keyValue = cityIds;
/*     */       }
/* 313 */       else if (keyWord.equals("RRIDS"))
/*     */       {
/* 315 */         List rptIdList = this.userRightService.getResourceIdListOfRight(userId, "3");
/*     */ 
/* 317 */         String rptIds = StringUtil.list2String(rptIdList, ",", false);
/* 318 */         keyValue = rptIds;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 322 */       e.printStackTrace();
/*     */     }
/* 324 */     return keyValue;
/*     */   }
/*     */ 
/*     */   private String generateToken()
/*     */   {
/* 331 */     SimpleDateFormat dFormatS = new SimpleDateFormat("yyyyMMddHHmmss");
/* 332 */     Calendar ca = Calendar.getInstance();
/* 333 */     String currTime = dFormatS.format(ca.getTime());
/* 334 */     String rand = generateRandom(6);
/*     */ 
/* 336 */     String token = rand + currTime;
/* 337 */     return token;
/*     */   }
/*     */ 
/*     */   private String generateRandom(int n)
/*     */   {
/*     */     try
/*     */     {
/* 348 */       StringRandom gen = new StringRandom();
/* 349 */       gen.setCharset("0-9");
/* 350 */       gen.setLength(4);
/* 351 */       return gen.getRandom();
/*     */     }
/*     */     catch (Exception e) {
/* 354 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.createApplyFail") + "", e);
/* 355 */       throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeAdmin", "privilegeAdmin.java.createApplyFail") + "", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ISysInfoDao getSysInfoDao()
/*     */   {
/* 363 */     return this.sysInfoDao;
/*     */   }
/*     */ 
/*     */   public void setSysInfoDao(ISysInfoDao sysInfoDao)
/*     */   {
/* 370 */     this.sysInfoDao = sysInfoDao;
/*     */   }
/*     */ 
/*     */   public IUserSysMapDao getUserSysMapDao()
/*     */   {
/* 377 */     return this.userSysMapDao;
/*     */   }
/*     */ 
/*     */   public void setUserSysMapDao(IUserSysMapDao userSysMapDao)
/*     */   {
/* 384 */     this.userSysMapDao = userSysMapDao;
/*     */   }
/*     */ 
/*     */   public IUserValidateDao getUserValidateDao()
/*     */   {
/* 391 */     return this.userValidateDao;
/*     */   }
/*     */ 
/*     */   public void setUserValidateDao(IUserValidateDao userValidateDao)
/*     */   {
/* 398 */     this.userValidateDao = userValidateDao;
/*     */   }
/*     */ 
/*     */   public IUserRightService getUserRightService()
/*     */   {
/* 405 */     return this.userRightService;
/*     */   }
/*     */ 
/*     */   public void setUserRightService(IUserRightService userRightService)
/*     */   {
/* 412 */     this.userRightService = userRightService;
/*     */   }
/*     */ 
/*     */   public IUniauthUserParamDao getUniauthUserParamDao()
/*     */   {
/* 419 */     return this.uniauthUserParamDao;
/*     */   }
/*     */ 
/*     */   public void setUniauthUserParamDao(IUniauthUserParamDao uniauthUserParamDao)
/*     */   {
/* 426 */     this.uniauthUserParamDao = uniauthUserParamDao;
/*     */   }
/*     */ 
/*     */   public void saveUserParam(String userId, String portletId, List paramList)
/*     */   {
/* 435 */     this.uniauthUserParamDao.deleteParamByPortletId(portletId);
/*     */ 
/* 437 */     if ((null != paramList) && (paramList.size() > 0))
/* 438 */       for (int i = 0; i < paramList.size(); i++) {
/* 439 */         String param = (String)paramList.get(i);
/* 440 */         UniauthUserParam userParam = new UniauthUserParam();
/* 441 */         UniauthUserParamKey key = new UniauthUserParamKey();
/* 442 */         key.setParam(param);
/* 443 */         key.setUserId(userId);
/* 444 */         key.setPortletId(Integer.valueOf(portletId));
/* 445 */         userParam.setId(key);
/* 446 */         userParam.setOpDate(new Date());
/* 447 */         this.uniauthUserParamDao.saveParam(userParam);
/*     */       }
/*     */   }
/*     */ 
/*     */   public List getAllSysInfoList()
/*     */   {
/* 457 */     return this.sysInfoDao.findAllSysInfoList();
/*     */   }
/*     */ 
/*     */   public void deleteUserParam(String portletId)
/*     */   {
/* 463 */     this.uniauthUserParamDao.deleteParamByPortletId(portletId);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.service.impl.UniAuthServiceImpl
 * JD-Core Version:    0.6.2
 */
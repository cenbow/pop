/*     */ package com.asiainfo.biframe.privilege.uniauth.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.cache.object.SysMenuItemCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCityCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCompanyCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserDutyCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserGroupDefineCache;
/*     */ import com.asiainfo.biframe.privilege.menu.SysMenuMaintain;
/*     */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.model.User_Company;
/*     */ import com.asiainfo.biframe.privilege.model.User_Duty;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.pwdpolicy.service.PwdPolicyService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.IResourceRightDAO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.dao.impl.ResourceRightDaoJdbcImpl;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IRoleAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.impl.ListService;
/*     */ import com.asiainfo.biframe.privilege.uniauth.service.IUserRightService;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UserRightServiceImpl
/*     */   implements IUserRightService
/*     */ {
/*  62 */   private Log log = LogFactory.getLog(UserRightServiceImpl.class);
/*     */ 
/*     */   private IUserAdminService getUserAdminService() throws Exception {
/*  65 */     IUserAdminService userService = (IUserAdminService)SystemServiceLocator.getInstance().getService("right_userAdminService");
/*  66 */     return userService;
/*     */   }
/*     */   private IUserGroupAdminService getUserGroupAdminService() throws Exception {
/*  69 */     IUserGroupAdminService groupService = (IUserGroupAdminService)SystemServiceLocator.getInstance().getService("right_userGroupAdminService");
/*     */ 
/*  71 */     return groupService;
/*     */   }
/*     */   private IRoleAdminService getRoleAdminService() throws Exception {
/*  74 */     IRoleAdminService roleService = (IRoleAdminService)SystemServiceLocator.getInstance().getService("right_roleAdminService");
/*  75 */     return roleService;
/*     */   }
/*     */   private IResourceRightDAO getResourceRightDao() throws Exception {
/*  78 */     IResourceRightDAO userRightDaoUserCity = (IResourceRightDAO)SystemServiceLocator.getInstance().getService("right_userRightDaoUserCity");
/*     */ 
/*  80 */     return userRightDaoUserCity;
/*     */   }
/*     */ 
/*     */   public List getResourceIdListOfRight(String userId, String resourceType)
/*     */   {
/*  89 */     List resIdList = new ArrayList();
/*     */     try {
/*  91 */       int roleType = 1;
/*     */ 
/*  93 */       if (resourceType.equals("5")) {
/*  94 */         roleType = 0;
/*     */       }
/*  96 */       List list = getUserAdminService().getRight(userId, roleType, Integer.parseInt(resourceType), false);
/*  97 */       resIdList = ListService.convertToNewList(list, "ResourceId");
/*     */     }
/*     */     catch (Exception e) {
/* 100 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 103 */     return resIdList;
/*     */   }
/*     */ 
/*     */   public List getRoleIdListOfUser(String userId, String resourceType)
/*     */   {
/* 112 */     List resIdList = new ArrayList();
/*     */     try {
/* 114 */       int roleType = 1;
/* 115 */       if (resourceType.equals("5")) {
/* 116 */         roleType = 0;
/*     */       }
/*     */ 
/* 119 */       List roleList = getUserAdminService().getAllRoles(userId, roleType, Integer.parseInt(resourceType));
/* 120 */       if (null != roleList)
/* 121 */         for (int i = 0; i < roleList.size(); i++) {
/* 122 */           UserRole role = (UserRole)roleList.get(i);
/* 123 */           resIdList.add(role.getRoleId());
/*     */         }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 128 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 132 */     return resIdList;
/*     */   }
/*     */ 
/*     */   public List getAllRoleMapList(String resourceType)
/*     */   {
/* 142 */     List resList = new ArrayList();
/*     */     try {
/* 144 */       int roleType = 1;
/* 145 */       if (resourceType.equals("5")) {
/* 146 */         roleType = 0;
/*     */       }
/*     */ 
/* 149 */       List roleList = getRoleAdminService().findAll();
/*     */ 
/* 151 */       roleList = getRoleAdminService().filterRoleByType(roleList, roleType, Integer.parseInt(resourceType));
/*     */ 
/* 153 */       if (null != roleList)
/* 154 */         for (int i = 0; i < roleList.size(); i++) {
/* 155 */           UserRole role = (UserRole)roleList.get(i);
/* 156 */           Map roleMap = new HashMap();
/* 157 */           roleMap.put("roleId", role.getRoleId());
/* 158 */           roleMap.put("roleName", role.getRoleName());
/* 159 */           resList.add(roleMap);
/*     */         }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 164 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 168 */     return resList;
/*     */   }
/*     */ 
/*     */   public List getAuthCityList(String operatorId, String operatorType)
/*     */   {
/* 179 */     List resList = new ArrayList();
/*     */     try
/*     */     {
/* 182 */       resList = ListService.getAuthCityList(operatorId, operatorType);
/*     */     }
/*     */     catch (Exception e) {
/* 185 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 189 */     return resList;
/*     */   }
/*     */ 
/*     */   public String getRootCityId()
/*     */   {
/* 194 */     String rootCityId = "-1";
/*     */     try {
/* 196 */       rootCityId = ((ResourceRightDaoJdbcImpl)getResourceRightDao()).getTopLevelId();
/*     */     }
/*     */     catch (Exception e) {
/* 199 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 202 */     return rootCityId;
/*     */   }
/*     */ 
/*     */   public boolean isAdminUser(String userId)
/*     */   {
/*     */     try
/*     */     {
/* 213 */       IUserAdminService userService = getUserAdminService();
/* 214 */       return userService.isAdminUser(userId);
/*     */     }
/*     */     catch (Exception e) {
/* 217 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 220 */     return false;
/*     */   }
/*     */ 
/*     */   public List getMenuObjList(List menuitemIds)
/*     */   {
/* 229 */     List resList = new ArrayList();
/*     */     try
/*     */     {
/* 232 */       if ((null != menuitemIds) && (menuitemIds.size() > 0)) {
/* 233 */         List allMenuList = SysMenuMaintain.getAllMenu();
/* 234 */         for (int i = 0; i < allMenuList.size(); i++) {
/* 235 */           SysMenuItemBean menuItem = (SysMenuItemBean)allMenuList.get(i);
/* 236 */           if (menuitemIds.contains(String.valueOf(menuItem.getMENUITEMID()))) {
/* 237 */             resList.add(menuItem);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 244 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 247 */     return resList;
/*     */   }
/*     */ 
/*     */   public String getUserCurrentCity(String userid)
/*     */   {
/*     */     try
/*     */     {
/* 257 */       IUserAdminService userService = getUserAdminService();
/* 258 */       return userService.getUserCurrentCity(userid);
/*     */     }
/*     */     catch (Exception e) {
/* 261 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 264 */     return "";
/*     */   }
/*     */ 
/*     */   public User_User getUser(String userid) {
/*     */     try {
/* 269 */       IUserAdminService userService = getUserAdminService();
/* 270 */       return userService.getUser(userid);
/*     */     }
/*     */     catch (Exception e) {
/* 273 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 276 */     return null;
/*     */   }
/*     */ 
/*     */   public User_Group getGroupObj(String userid)
/*     */   {
/*     */     try {
/* 282 */       return getUserAdminService().getGroupObject(userid);
/*     */     }
/*     */     catch (Exception e) {
/* 285 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 288 */     return null;
/*     */   }
/*     */ 
/*     */   public String getGroupId(String userid)
/*     */   {
/*     */     try
/*     */     {
/* 299 */       return getUserAdminService().getGroup(userid);
/*     */     }
/*     */     catch (Exception e) {
/* 302 */       this.log.error("", e);
/*     */     }
/*     */ 
/* 305 */     return "";
/*     */   }
/*     */ 
/*     */   public Map getUserMap(String userId)
/*     */   {
/* 310 */     Map map = new HashMap();
/* 311 */     User_User user = getUser(userId);
/* 312 */     User_Group ug = getGroupObj(userId);
/*     */ 
/* 314 */     map.put("groupId", ug.getGroupid());
/* 315 */     if (null != ug)
/* 316 */       map.put("groupName", ug.getGroupname());
/* 317 */     map.put("userId", user.getUserid());
/* 318 */     map.put("userName", user.getName());
/* 319 */     map.put("cityId", user.getCityid());
/* 320 */     map.put("cityName", UserCityCache.getInstance().getNameByKey(user.getCityid()));
/* 321 */     map.put("departmentId", String.valueOf(user.getDepartmentid()));
/* 322 */     map.put("departmentTitle", UserCompanyCache.getInstance().getNameByKey(new Integer(user.getDepartmentid()).toString()));
/* 323 */     map.put("email", user.getEmail());
/*     */ 
/* 326 */     map.put("homePhone", user.getHomephone());
/* 327 */     map.put("mobilePhone", user.getMobilePhone());
/* 328 */     map.put("notes", user.getNotes());
/* 329 */     map.put("officeFax", user.getOfficefax());
/* 330 */     map.put("officePhone", user.getOfficephone());
/*     */ 
/* 340 */     return map;
/*     */   }
/*     */ 
/*     */   public void updateUser(User_User user)
/*     */   {
/*     */     try
/*     */     {
/* 347 */       IUserAdminService userService = getUserAdminService();
/* 348 */       userService.updateUser(user);
/*     */     }
/*     */     catch (Exception e) {
/* 351 */       this.log.error("", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int savePwd2History(String userId, String pwd, String operatorId)
/*     */   {
/*     */     try
/*     */     {
/* 360 */       IUserAdminService userService = getUserAdminService();
/* 361 */       return userService.savePwd2History(userId, pwd, operatorId);
/*     */     }
/*     */     catch (Exception e) {
/* 364 */       this.log.error("", e);
/* 365 */     }return -1;
/*     */   }
/*     */ 
/*     */   public int savePwd2History(String userId, String pwd)
/*     */   {
/*     */     try
/*     */     {
/* 372 */       IUserAdminService userService = getUserAdminService();
/* 373 */       return userService.savePwd2History(userId, pwd);
/*     */     }
/*     */     catch (Exception e) {
/* 376 */       this.log.error("", e);
/* 377 */     }return -1;
/*     */   }
/*     */ 
/*     */   public List getUserGroupByIds(List groupIds)
/*     */   {
/*     */     try
/*     */     {
/* 385 */       IUserGroupAdminService groupService = getUserGroupAdminService();
/* 386 */       return groupService.getUserGroupByIds(groupIds);
/*     */     }
/*     */     catch (Exception e) {
/* 389 */       this.log.error("", e);
/* 390 */     }return null;
/*     */   }
/*     */ 
/*     */   public List getSubGroup(String userId)
/*     */   {
/*     */     try
/*     */     {
/* 400 */       return ListService.getSubGroup(userId);
/*     */     }
/*     */     catch (Exception e) {
/* 403 */       this.log.error("", e);
/* 404 */     }return null;
/*     */   }
/*     */ 
/*     */   public void saveGroupUserMap(String groupId, List userList)
/*     */   {
/*     */     try
/*     */     {
/* 438 */       IUserGroupAdminService groupService = getUserGroupAdminService();
/* 439 */       groupService.saveGroupUserMap(groupId, userList);
/*     */     }
/*     */     catch (Exception e) {
/* 442 */       this.log.error("", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map userToMap(User_User user)
/*     */   {
/* 448 */     Map userMap = new HashMap();
/* 449 */     if (null != user) {
/* 450 */       userMap.put("userid", user.getUserid());
/* 451 */       userMap.put("username", user.getUsername());
/* 452 */       userMap.put("departmentid", String.valueOf(user.getDepartmentid()));
/*     */     }
/* 454 */     return userMap;
/*     */   }
/*     */ 
/*     */   public boolean isPwdRepeated(String userid, String newPwd)
/*     */   {
/* 459 */     return PwdPolicyService.isPwdRepeated(userid, newPwd);
/*     */   }
/*     */ 
/*     */   public String genXTreeQuerySql(String userId, boolean isAdmin, String resourceType, String resourceParentId)
/*     */   {
/* 464 */     StringBuffer sb = new StringBuffer();
/* 465 */     if (isAdmin) {
/* 466 */       sb.append("select t1.uniqueid,t1.title,t1.rpttype \n").append("from rpt_catalog t1 where 1=1 \n");
/*     */     }
/*     */     else {
/* 469 */       sb.append("select t1.uniqueid,t1.title,t1.rpttype \n").append("from rpt_catalog t1,user_rpt_right t2,user_role_map t3 \n").append("where t1.uniqueid = t2.resourceid and t3.role_id = t2.operatorid and t3.userid = '" + userId + "'\n").append("union\n").append("select t1.uniqueid,t1.title,t1.rpttype \n").append("from rpt_catalog t1,user_rpt_right t2,user_group_map t3,group_role_map t4 \n").append("where t1.uniqueid = t2.resourceid and t4.role_id = t2.operatorid \n").append("and t4.group_id=t3.group_id and t3.userid = '" + userId + "' \n");
/*     */ 
/* 483 */       if ((resourceType != null) && (resourceType.length() > 0))
/* 484 */         sb.append(" and t2.resourceType=" + resourceType);
/*     */     }
/* 486 */     if ((resourceParentId != null) && (resourceParentId.length() > 0)) {
/* 487 */       if (resourceParentId.indexOf(",") < 0)
/* 488 */         sb.append(" and t1.parentid=" + resourceParentId);
/*     */       else {
/* 490 */         sb.append(" and t1.parentid in (" + resourceParentId + ")");
/*     */       }
/*     */     }
/* 493 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public List getResourceIdListOfRight(String parentId, boolean boo, String str)
/*     */   {
/* 499 */     List list = new ArrayList();
/* 500 */     String parentsTemp = parentId.replaceAll("'", "");
/*     */     try {
/* 502 */       if (str.equals("company")) {
/* 503 */         String[] parents = parentsTemp.split(",");
/* 504 */         Iterator iterator = UserCompanyCache.getInstance().getAllCachedObject().iterator();
/* 505 */         while (iterator.hasNext()) {
/* 506 */           User_Company temp = (User_Company)iterator.next();
/* 507 */           for (int i = 0; i < parents.length; i++) {
/* 508 */             if (temp.getParentid().intValue() == new Integer(parents[i].trim()).intValue())
/* 509 */               list.add(temp.getDeptid());
/*     */           }
/*     */         }
/*     */       }
/* 513 */       if (str.equals("user"))
/*     */       {
/* 515 */         String[] parents = parentsTemp.split(",");
/* 516 */         Iterator iterator = UserCache.getInstance().getAllCachedObject().iterator();
/* 517 */         while (iterator.hasNext()) {
/* 518 */           User_User temp = (User_User)iterator.next();
/* 519 */           for (int i = 0; i < parents.length; i++) {
/* 520 */             if (temp.getDepartmentid() == new Integer(parents[i].trim()).intValue())
/* 521 */               list.add(temp.getUserid());
/*     */           }
/*     */         }
/*     */       }
/* 525 */       if (str.equals("tailorStyleUser"))
/*     */       {
/* 527 */         String[] parents = parentsTemp.split(",");
/* 528 */         Iterator iterator = UserCache.getInstance().getAllCachedObject().iterator();
/* 529 */         while (iterator.hasNext()) {
/* 530 */           User_User temp = (User_User)iterator.next();
/* 531 */           for (int i = 0; i < parents.length; i++) {
/* 532 */             if (temp.getGroupId().equals(parents[i]))
/* 533 */               list.add(temp.getUserid());
/*     */           }
/*     */         }
/*     */       }
/* 537 */       if (str.equals("userGroup")) {
/* 538 */         String[] parents = parentsTemp.split(",");
/* 539 */         Iterator iterator = UserGroupDefineCache.getInstance().getAllCachedObject().iterator();
/* 540 */         while (iterator.hasNext()) {
/* 541 */           User_Group temp = (User_Group)iterator.next();
/* 542 */           for (int i = 0; i < parents.length; i++) {
/* 543 */             if (temp.getParentid().equals(parents[i]))
/* 544 */               list.add(temp.getGroupid());
/*     */           }
/*     */         }
/*     */       }
/* 548 */       if (str.equals("duty")) {
/* 549 */         String[] parents = parentsTemp.split(",");
/* 550 */         Iterator iterator = UserDutyCache.getInstance().getAllCachedObject().iterator();
/* 551 */         while (iterator.hasNext()) {
/* 552 */           User_Duty temp = (User_Duty)iterator.next();
/* 553 */           for (int i = 0; i < parents.length; i++)
/* 554 */             if (temp.getCityid().equals(parents[i]))
/* 555 */               list.add(Integer.valueOf(temp.getDutyid()));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/* 561 */       excep.printStackTrace();
/*     */     }
/* 563 */     return list;
/*     */   }
/*     */ 
/*     */   public List getSystemMenuResourceListOfRight(String parentId) {
/* 567 */     Iterator iterator = SysMenuItemCache.getInstance().getAllCachedObject().iterator();
/* 568 */     List list = new ArrayList();
/* 569 */     while (iterator.hasNext()) {
/* 570 */       SysMenuItemBean item = (SysMenuItemBean)iterator.next();
/* 571 */       if ((item != null) && (item.getPARENTID() == new Integer(parentId.trim()).intValue())) {
/* 572 */         list.add(item);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 591 */     return list;
/*     */   }
/*     */ 
/*     */   public List<SysMenuItemBean> getSystemMenuResourceListByName(String menuItemTitle)
/*     */   {
/* 599 */     Iterator iterator = SysMenuItemCache.getInstance().getAllCachedObject().iterator();
/* 600 */     List list = new ArrayList();
/* 601 */     while (iterator.hasNext()) {
/* 602 */       SysMenuItemBean item = (SysMenuItemBean)iterator.next();
/* 603 */       if ((item != null) && (StringUtil.isNotEmpty(item.getMENUITEMTITLE())) && (item.getMENUITEMTITLE().contains(menuItemTitle))) {
/* 604 */         list.add(item);
/*     */       }
/*     */     }
/* 607 */     return list;
/*     */   }
/*     */ 
/*     */   public List<SysMenuItemBean> getAllParentSystemMenuResouceList(int menuItemId)
/*     */   {
/* 615 */     List parentList = new ArrayList();
/*     */     try {
/* 617 */       List allParentResourceIds = getRoleAdminService().getAllParentResourceIds(Integer.valueOf(menuItemId).toString(), -1, Integer.valueOf("50").intValue());
/* 618 */       Iterator iterator = SysMenuItemCache.getInstance().getAllCachedObject().iterator();
/*     */ 
/* 620 */       while (iterator.hasNext()) {
/* 621 */         SysMenuItemBean item = (SysMenuItemBean)iterator.next();
/* 622 */         if ((item != null) && (allParentResourceIds.contains(item.getMENUITEMID())))
/* 623 */           parentList.add(item);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 627 */       this.log.error("getAllParentSystemMenuResouceList " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*     */     }
/*     */ 
/* 631 */     return parentList;
/*     */   }
/*     */ 
/*     */   public List getUserSubGroupList(String parentid)
/*     */   {
/* 636 */     List list = new ArrayList();
/* 637 */     Iterator iterator = UserGroupDefineCache.getInstance().getAllCachedObject().iterator();
/* 638 */     while (iterator.hasNext()) {
/* 639 */       User_Group temp = (User_Group)iterator.next();
/* 640 */       if (temp.getParentid().equals(parentid)) {
/* 641 */         Map map = new HashMap();
/* 642 */         map.put("group_id", temp.getGroupid());
/* 643 */         map.put("group_name", temp.getGroupname());
/* 644 */         list.add(map);
/*     */       }
/*     */     }
/*     */ 
/* 648 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.service.impl.UserRightServiceImpl
 * JD-Core Version:    0.6.2
 */
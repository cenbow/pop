/*     */ package com.asiainfo.biframe.privilege.uniauth.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ParseUrl
/*     */ {
/*     */   private static final String DEFAULT_FILTERED_CHAR = "`~\\:;\"'<,>./";
/*  14 */   private static final String[] DEFAULT_INVALID_STR = { "'", "script", "and ", "or ", "union ", "between ", "\"", "\\", "=", "\\t", "insert|values", "select|from", "update|set", "delete|from", "drop", "where", "alter" };
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static Map getParamMixInfo(String url)
/*     */   {
/*  27 */     Map paramInfo = new HashMap();
/*  28 */     Map paramMap = new HashMap();
/*  29 */     List paramList = new ArrayList();
/*  30 */     String parseSrc = url;
/*  31 */     while ((parseSrc.indexOf("?") >= 0) || (parseSrc.indexOf("&") >= 0)) {
/*  32 */       int nPos = parseSrc.indexOf("?");
/*  33 */       if (nPos < 0) {
/*  34 */         nPos = parseSrc.indexOf("&");
/*     */       }
/*  36 */       parseSrc = parseSrc.substring(nPos + 1);
/*  37 */       int nParaEnd = parseSrc.indexOf("=");
/*  38 */       int nValueEnd = parseSrc.indexOf("&");
/*  39 */       if (nValueEnd < 0)
/*  40 */         nValueEnd = parseSrc.length();
/*  41 */       String param = parseSrc.substring(0, nParaEnd);
/*  42 */       String paramValue = parseSrc.substring(nParaEnd + 1, nValueEnd);
/*  43 */       if (nValueEnd == parseSrc.length())
/*  44 */         parseSrc = "";
/*     */       else {
/*  46 */         parseSrc = parseSrc.substring(nValueEnd);
/*     */       }
/*     */ 
/*  49 */       paramMap.put(param, paramValue);
/*     */ 
/*  51 */       Map paramObj = new HashMap();
/*  52 */       paramObj.put("key", param);
/*  53 */       paramObj.put("value", paramValue);
/*  54 */       paramList.add(paramObj);
/*     */     }
/*  56 */     if ((null != paramMap) && (!paramMap.isEmpty())) {
/*  57 */       paramInfo.put("mapInfo", paramMap);
/*  58 */       paramInfo.put("listInfo", paramList);
/*     */     }
/*  60 */     return paramInfo;
/*     */   }
/*     */ 
/*     */   public static Map getParamMap(String url)
/*     */   {
/*  69 */     Map paramMap = new HashMap();
/*  70 */     List paramList = new ArrayList();
/*  71 */     String parseSrc = url;
/*  72 */     while ((parseSrc.indexOf("?") >= 0) || (parseSrc.indexOf("&") >= 0)) {
/*  73 */       int nPos = parseSrc.indexOf("?");
/*  74 */       if (nPos < 0) {
/*  75 */         nPos = parseSrc.indexOf("&");
/*     */       }
/*  77 */       parseSrc = parseSrc.substring(nPos + 1);
/*  78 */       int nParaEnd = parseSrc.indexOf("=");
/*  79 */       int nValueEnd = parseSrc.indexOf("&");
/*  80 */       if (nValueEnd < 0)
/*  81 */         nValueEnd = parseSrc.length();
/*  82 */       String param = parseSrc.substring(0, nParaEnd);
/*  83 */       String paramValue = parseSrc.substring(nParaEnd + 1, nValueEnd);
/*  84 */       if (nValueEnd == parseSrc.length())
/*  85 */         parseSrc = "";
/*     */       else {
/*  87 */         parseSrc = parseSrc.substring(nValueEnd);
/*     */       }
/*     */ 
/*  90 */       paramMap.put(param, paramValue);
/*     */ 
/*  92 */       Map paramObj = new HashMap();
/*  93 */       paramObj.put("key", param);
/*  94 */       paramObj.put("value", paramValue);
/*  95 */       paramList.add(paramObj);
/*     */     }
/*  97 */     return paramMap;
/*     */   }
/*     */ 
/*     */   public static List getParamList(String url)
/*     */   {
/* 106 */     List paramList = new ArrayList();
/* 107 */     String parseSrc = url;
/* 108 */     while ((parseSrc.indexOf("?") >= 0) || (parseSrc.indexOf("&") >= 0)) {
/* 109 */       int nPos = parseSrc.indexOf("?");
/* 110 */       if (nPos < 0) {
/* 111 */         nPos = parseSrc.indexOf("&");
/*     */       }
/* 113 */       parseSrc = parseSrc.substring(nPos + 1);
/* 114 */       int nParaEnd = parseSrc.indexOf("=");
/* 115 */       int nValueEnd = parseSrc.indexOf("&");
/* 116 */       if (nValueEnd < 0)
/* 117 */         nValueEnd = parseSrc.length();
/* 118 */       String param = parseSrc.substring(0, nParaEnd);
/* 119 */       String paramValue = parseSrc.substring(nParaEnd + 1, nValueEnd);
/* 120 */       if (nValueEnd == parseSrc.length())
/* 121 */         parseSrc = "";
/*     */       else {
/* 123 */         parseSrc = parseSrc.substring(nValueEnd);
/*     */       }
/* 125 */       Map paramObj = new HashMap();
/* 126 */       paramObj.put("key", param);
/* 127 */       paramObj.put("value", paramValue);
/* 128 */       paramList.add(paramObj);
/*     */     }
/* 130 */     return paramList;
/*     */   }
/*     */ 
/*     */   public static List getUserParam(List paramList)
/*     */   {
/* 140 */     List userParamList = new ArrayList();
/* 141 */     if ((null != paramList) && (!paramList.isEmpty())) {
/* 142 */       for (int i = 0; i < paramList.size(); i++) {
/* 143 */         Map paramObj = (Map)paramList.get(i);
/* 144 */         if (null != paramObj) {
/* 145 */           String paramValue = (String)paramObj.get("value");
/* 146 */           if ((null != paramValue) && (paramValue.indexOf("[") >= 0) && (paramValue.indexOf("]") >= 0))
/*     */           {
/* 148 */             paramValue = paramValue.substring(1, paramValue.length() - 1);
/* 149 */             if (paramValue.indexOf("USERPARA_") == 0) {
/* 150 */               userParamList.add(paramValue);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 156 */     return userParamList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.uniauth.util.ParseUrl
 * JD-Core Version:    0.6.2
 */
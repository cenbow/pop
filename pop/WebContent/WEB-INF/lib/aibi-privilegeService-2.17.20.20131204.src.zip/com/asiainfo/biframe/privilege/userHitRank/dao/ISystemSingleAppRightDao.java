package com.asiainfo.biframe.privilege.userHitRank.dao;

import com.asiainfo.biframe.privilege.userHitRank.po.AppRightUserInfo;
import com.asiainfo.biframe.privilege.userHitRank.po.Pagination;
import java.util.List;

public abstract interface ISystemSingleAppRightDao
{
  public abstract List<AppRightUserInfo> getPagedSingleAppUserVisit(Integer paramInteger, Pagination paramPagination);

  public abstract Integer getSingleAppUserVisitCount(Integer paramInteger);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.userHitRank.dao.ISystemSingleAppRightDao
 * JD-Core Version:    0.6.2
 */
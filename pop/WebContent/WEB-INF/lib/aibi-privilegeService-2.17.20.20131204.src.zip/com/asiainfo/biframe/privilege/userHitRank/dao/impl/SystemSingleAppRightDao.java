/*     */ package com.asiainfo.biframe.privilege.userHitRank.dao.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.userHitRank.dao.ISystemSingleAppRightDao;
/*     */ import com.asiainfo.biframe.privilege.userHitRank.po.AppRightUserInfo;
/*     */ import com.asiainfo.biframe.privilege.userHitRank.po.Pagination;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class SystemSingleAppRightDao
/*     */   implements ISystemSingleAppRightDao
/*     */ {
/*  36 */   static Logger log = Logger.getLogger(SystemSingleAppRightDao.class);
/*     */ 
/*     */   public List<AppRightUserInfo> getPagedSingleAppUserVisit(Integer menuItemId, Pagination pager)
/*     */   {
/*  43 */     List list = new ArrayList();
/*  44 */     Sqlca m_Sqlca = null;
/*     */     try {
/*  46 */       m_Sqlca = new Sqlca(new ConnectionEx("privilegeAdmin", "config/aibi_privilegeAdmin/privilegeAdmin.properties", "JDBC_AIOMNI_PRIVILEGEADMIN"));
/*  47 */       String sql = "";
/*  48 */       AppRightUserInfo info = null;
/*  49 */       StringBuilder sqlBuf = new StringBuilder();
/*  50 */       sqlBuf.append("select distinct '").append(menuItemId).append("' menuItemId,r.userid userid,r.username username,r.departmentid departmentid,r.email email,r.mobilephone mobilephone").append(",c.title departmentname from (").append("select u.userid userid from sys_menuitem_right s join user_role_map u on s.operatorid = u.role_id").append(" where s.resourceId = '").append(menuItemId).append("' union select u.userid userid from sys_menuitem_right s join group_role_map g on s.operatorid = g.role_id").append(" join user_group_map u on g.group_id = u.group_id where s.resourceId = '").append(menuItemId).append("' union select u.userid from user_group_map u where u.group_id = '1') m").append(" join user_user r on m.userid = r.userid left join user_company c on r.departmentid = c.deptid").append(" order by r.username,r.userid");
/*     */ 
/*  63 */       sql = m_Sqlca.getPagedSql(sqlBuf.toString(), pager.getPageNum(), pager.getPageSize());
/*  64 */       log.debug(sql);
/*  65 */       m_Sqlca.execute(sql);
/*  66 */       while (m_Sqlca.next()) {
/*  67 */         info = new AppRightUserInfo();
/*  68 */         info.setMenuItemId(m_Sqlca.getInteger("menuItemId"));
/*  69 */         info.setUserid(m_Sqlca.getString("userid"));
/*  70 */         info.setUsername(m_Sqlca.getString("username"));
/*  71 */         info.setEmail(m_Sqlca.getString("email"));
/*  72 */         info.setMobilephone(m_Sqlca.getString("mobilephone"));
/*  73 */         info.setDepartmentid(m_Sqlca.getInteger("departmentid"));
/*  74 */         info.setDepartmentname(m_Sqlca.getString("departmentname"));
/*  75 */         list.add(info);
/*     */       }
/*     */ 
/*  80 */       if (null != m_Sqlca)
/*  81 */         m_Sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  78 */       e.printStackTrace();
/*     */ 
/*  80 */       if (null != m_Sqlca)
/*  81 */         m_Sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/*  80 */       if (null != m_Sqlca) {
/*  81 */         m_Sqlca.closeAll();
/*     */       }
/*     */     }
/*  84 */     return list;
/*     */   }
/*     */ 
/*     */   public Integer getSingleAppUserVisitCount(Integer menuItemId)
/*     */   {
/*  91 */     int usercount = 0;
/*  92 */     Sqlca m_Sqlca = null;
/*     */     try {
/*  94 */       m_Sqlca = new Sqlca(new ConnectionEx("privilegeAdmin", "config/aibi_privilegeAdmin/privilegeAdmin.properties", "JDBC_AIOMNI_PRIVILEGEADMIN"));
/*  95 */       StringBuilder sqlBuf = new StringBuilder();
/*  96 */       sqlBuf.append("select count(distinct m.userid) usercount from (").append("select u.userid userid from sys_menuitem_right s join user_role_map u on s.operatorid = u.role_id").append(" where s.resourceId = '").append(menuItemId).append("' union select u.userid userid from sys_menuitem_right s join group_role_map g on s.operatorid = g.role_id").append(" join user_group_map u on g.group_id = u.group_id where s.resourceId = '").append(menuItemId).append("' union select u.userid from user_group_map u where u.group_id = '1') m").append(" join user_user r on m.userid = r.userid left join user_company c on r.departmentid = c.deptid");
/*     */ 
/* 105 */       log.debug(sqlBuf.toString());
/* 106 */       m_Sqlca.execute(sqlBuf.toString());
/* 107 */       if (m_Sqlca.next()) {
/* 108 */         usercount = m_Sqlca.getInteger("usercount").intValue();
/*     */       }
/*     */ 
/* 113 */       if (null != m_Sqlca)
/* 114 */         m_Sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 111 */       e.printStackTrace();
/*     */ 
/* 113 */       if (null != m_Sqlca)
/* 114 */         m_Sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 113 */       if (null != m_Sqlca) {
/* 114 */         m_Sqlca.closeAll();
/*     */       }
/*     */     }
/* 117 */     return Integer.valueOf(usercount);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.userHitRank.dao.impl.SystemSingleAppRightDao
 * JD-Core Version:    0.6.2
 */
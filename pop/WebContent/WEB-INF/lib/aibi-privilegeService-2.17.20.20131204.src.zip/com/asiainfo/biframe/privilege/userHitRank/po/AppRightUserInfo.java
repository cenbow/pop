/*    */ package com.asiainfo.biframe.privilege.userHitRank.po;
/*    */ 
/*    */ public class AppRightUserInfo
/*    */ {
/*    */   private Integer menuItemId;
/*    */   private String userid;
/*    */   private String username;
/*    */   private String mobilephone;
/*    */   private String email;
/*    */   private Integer departmentid;
/*    */   private String departmentname;
/*    */ 
/*    */   public Integer getMenuItemId()
/*    */   {
/* 33 */     return this.menuItemId;
/*    */   }
/*    */   public void setMenuItemId(Integer menuItemId) {
/* 36 */     this.menuItemId = menuItemId;
/*    */   }
/*    */   public String getUserid() {
/* 39 */     return this.userid;
/*    */   }
/*    */   public void setUserid(String userid) {
/* 42 */     this.userid = userid;
/*    */   }
/*    */   public String getUsername() {
/* 45 */     return this.username;
/*    */   }
/*    */   public void setUsername(String username) {
/* 48 */     this.username = username;
/*    */   }
/*    */   public String getMobilephone() {
/* 51 */     return this.mobilephone;
/*    */   }
/*    */   public void setMobilephone(String mobilephone) {
/* 54 */     this.mobilephone = mobilephone;
/*    */   }
/*    */   public String getEmail() {
/* 57 */     return this.email;
/*    */   }
/*    */   public void setEmail(String email) {
/* 60 */     this.email = email;
/*    */   }
/*    */   public Integer getDepartmentid() {
/* 63 */     return this.departmentid;
/*    */   }
/*    */   public void setDepartmentid(Integer departmentid) {
/* 66 */     this.departmentid = departmentid;
/*    */   }
/*    */   public String getDepartmentname() {
/* 69 */     return this.departmentname;
/*    */   }
/*    */   public void setDepartmentname(String departmentname) {
/* 72 */     this.departmentname = departmentname;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.userHitRank.po.AppRightUserInfo
 * JD-Core Version:    0.6.2
 */
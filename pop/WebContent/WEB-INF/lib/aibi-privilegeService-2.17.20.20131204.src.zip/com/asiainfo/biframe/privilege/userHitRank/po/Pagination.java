/*     */ package com.asiainfo.biframe.privilege.userHitRank.po;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Pagination
/*     */ {
/*  28 */   private List result = new ArrayList();
/*     */ 
/*  30 */   private int totalPage = 0;
/*     */ 
/*  32 */   private long totalSize = 0L;
/*     */ 
/*  34 */   private int pageSize = 10;
/*     */ 
/*  36 */   private int pageNum = 1;
/*     */ 
/*  38 */   private boolean firstPage = false;
/*     */ 
/*  40 */   private boolean lastPage = false;
/*     */ 
/*  42 */   private boolean hasPrevPage = false;
/*     */ 
/*  44 */   private boolean hasNextPage = false;
/*     */ 
/*  46 */   private boolean goPage = false;
/*     */ 
/*  48 */   private int pageStart = 0;
/*     */ 
/*     */   public Pagination() {
/*     */   }
/*     */   public Pagination(long totalSize) {
/*  53 */     this.totalSize = totalSize;
/*  54 */     this.totalPage = ((int)Math.ceil(totalSize / this.pageSize));
/*  55 */     handlePage();
/*     */   }
/*     */ 
/*     */   public Pagination nextPage()
/*     */   {
/*  60 */     Pagination pager = new Pagination();
/*  61 */     pager.setTotalPage(this.totalPage);
/*  62 */     pager.setTotalSize(this.totalSize);
/*  63 */     pager.setPageSize(this.pageSize);
/*  64 */     pager.setPageNum(++this.pageNum);
/*  65 */     pager.handlePage();
/*  66 */     return pager;
/*     */   }
/*     */ 
/*     */   public Pagination prevPage()
/*     */   {
/*  72 */     Pagination pager = new Pagination();
/*  73 */     pager.setTotalPage(this.totalPage);
/*  74 */     pager.setTotalSize(this.totalSize);
/*  75 */     pager.setPageSize(this.pageSize);
/*  76 */     pager.setPageNum(--this.pageNum);
/*  77 */     pager.handlePage();
/*  78 */     return pager;
/*     */   }
/*     */ 
/*     */   public Pagination firstPage()
/*     */   {
/*  83 */     Pagination pager = new Pagination();
/*  84 */     pager.setTotalPage(this.totalPage);
/*  85 */     pager.setTotalSize(this.totalSize);
/*  86 */     pager.setPageSize(this.pageSize);
/*  87 */     pager.setPageNum(1);
/*  88 */     pager.handlePage();
/*  89 */     return pager;
/*     */   }
/*     */ 
/*     */   public Pagination lastPage()
/*     */   {
/*  94 */     Pagination pager = new Pagination();
/*  95 */     pager.setTotalPage(this.totalPage);
/*  96 */     pager.setTotalSize(this.totalSize);
/*  97 */     pager.setPageSize(this.pageSize);
/*  98 */     pager.setPageNum(this.totalPage);
/*  99 */     pager.handlePage();
/* 100 */     return pager;
/*     */   }
/*     */ 
/*     */   public Pagination goPage()
/*     */   {
/* 105 */     Pagination pager = new Pagination();
/* 106 */     pager.setTotalPage(this.totalPage);
/* 107 */     pager.setTotalSize(this.totalSize);
/* 108 */     pager.setPageSize(this.pageSize);
/* 109 */     pager.setPageNum(this.pageNum);
/* 110 */     pager.handlePage();
/* 111 */     return pager;
/*     */   }
/*     */ 
/*     */   private void handlePage()
/*     */   {
/* 116 */     if ((this.pageNum > 1) && (this.totalPage > 1)) {
/* 117 */       this.hasPrevPage = true;
/*     */     }
/* 119 */     if ((this.pageNum < this.totalPage) && (this.totalPage > 1)) {
/* 120 */       this.hasNextPage = true;
/*     */     }
/* 122 */     if ((this.pageNum != 1) && (this.totalPage > 1)) {
/* 123 */       this.firstPage = true;
/*     */     }
/* 125 */     if ((this.pageNum != this.totalPage) && (this.totalPage > 1)) {
/* 126 */       this.lastPage = true;
/*     */     }
/* 128 */     if (this.totalPage > 1)
/* 129 */       this.goPage = true;
/*     */   }
/*     */ 
/*     */   public int getPageStart()
/*     */   {
/* 134 */     return this.pageStart;
/*     */   }
/*     */ 
/*     */   public void setPageStart(int pageStart) {
/* 138 */     this.pageStart = pageStart;
/*     */   }
/*     */ 
/*     */   public List getResult() {
/* 142 */     return this.result;
/*     */   }
/*     */   public void setResult(List result) {
/* 145 */     this.result = result;
/*     */   }
/*     */ 
/*     */   public void setTotalPage(int totalPage) {
/* 149 */     this.totalPage = totalPage;
/*     */   }
/*     */ 
/*     */   public void setTotalSize(long totalSize) {
/* 153 */     this.totalSize = totalSize;
/*     */   }
/*     */ 
/*     */   public void setPageSize(int pageSize) {
/* 157 */     this.pageSize = pageSize;
/*     */   }
/*     */ 
/*     */   public void setPageNum(int pageNum) {
/* 161 */     this.pageNum = pageNum;
/*     */   }
/*     */ 
/*     */   public void setHasPrevPage(boolean hasPrevPage) {
/* 165 */     this.hasPrevPage = hasPrevPage;
/*     */   }
/*     */ 
/*     */   public void setHasNextPage(boolean hasNextPage) {
/* 169 */     this.hasNextPage = hasNextPage;
/*     */   }
/*     */ 
/*     */   public int getTotalPage() {
/* 173 */     return this.totalPage;
/*     */   }
/*     */ 
/*     */   public boolean isFirstPage()
/*     */   {
/* 179 */     return this.firstPage;
/*     */   }
/*     */ 
/*     */   public void setFirstPage(boolean firstPage) {
/* 183 */     this.firstPage = firstPage;
/*     */   }
/*     */ 
/*     */   public boolean isLastPage() {
/* 187 */     return this.lastPage;
/*     */   }
/*     */ 
/*     */   public void setLastPage(boolean lastPage) {
/* 191 */     this.lastPage = lastPage;
/*     */   }
/*     */ 
/*     */   public long getTotalSize() {
/* 195 */     return this.totalSize;
/*     */   }
/*     */ 
/*     */   public int getPageSize() {
/* 199 */     return this.pageSize;
/*     */   }
/*     */ 
/*     */   public int getPageNum() {
/* 203 */     return this.pageNum;
/*     */   }
/*     */ 
/*     */   public boolean isHasPrevPage() {
/* 207 */     return this.hasPrevPage;
/*     */   }
/*     */ 
/*     */   public boolean isHasNextPage() {
/* 211 */     return this.hasNextPage;
/*     */   }
/*     */ 
/*     */   public boolean isGoPage() {
/* 215 */     return this.goPage;
/*     */   }
/*     */ 
/*     */   public void setGoPage(boolean goPage) {
/* 219 */     this.goPage = goPage;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.userHitRank.po.Pagination
 * JD-Core Version:    0.6.2
 */
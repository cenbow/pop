package com.asiainfo.biframe.privilege.userHitRank.service;

import com.asiainfo.biframe.privilege.userHitRank.po.Pagination;

public abstract interface ISystemSingleAppRightService
{
  public abstract Pagination getPagedSingleAppUserVisit(Integer paramInteger, Pagination paramPagination);

  public abstract Integer getSingleAppUserVisitCount(Integer paramInteger);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.userHitRank.service.ISystemSingleAppRightService
 * JD-Core Version:    0.6.2
 */
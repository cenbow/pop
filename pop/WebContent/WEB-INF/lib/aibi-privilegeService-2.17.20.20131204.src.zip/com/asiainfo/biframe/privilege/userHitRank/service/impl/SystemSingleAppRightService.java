/*    */ package com.asiainfo.biframe.privilege.userHitRank.service.impl;
/*    */ 
/*    */ import com.asiainfo.biframe.privilege.userHitRank.dao.ISystemSingleAppRightDao;
/*    */ import com.asiainfo.biframe.privilege.userHitRank.po.Pagination;
/*    */ import com.asiainfo.biframe.privilege.userHitRank.service.ISystemSingleAppRightService;
/*    */ 
/*    */ public class SystemSingleAppRightService
/*    */   implements ISystemSingleAppRightService
/*    */ {
/*    */   private ISystemSingleAppRightDao systemSingleAppRightDao;
/*    */ 
/*    */   public void setSystemSingleAppRightDao(ISystemSingleAppRightDao systemSingleAppRightDao)
/*    */   {
/* 32 */     this.systemSingleAppRightDao = systemSingleAppRightDao;
/*    */   }
/*    */ 
/*    */   public Pagination getPagedSingleAppUserVisit(Integer menuItemId, Pagination pager)
/*    */   {
/* 39 */     pager.setResult(this.systemSingleAppRightDao.getPagedSingleAppUserVisit(menuItemId, pager));
/* 40 */     return pager;
/*    */   }
/*    */ 
/*    */   public Integer getSingleAppUserVisitCount(Integer menuItemId)
/*    */   {
/* 47 */     return this.systemSingleAppRightDao.getSingleAppUserVisitCount(menuItemId);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.userHitRank.service.impl.SystemSingleAppRightService
 * JD-Core Version:    0.6.2
 */
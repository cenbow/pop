package com.asiainfo.biframe.privilege.webservices.service;

import com.asiainfo.biframe.privilege.model.UserRole;
import com.asiainfo.biframe.privilege.model.User_Group;
import com.asiainfo.biframe.privilege.model.User_User;
import java.util.List;

public abstract interface IWsPrivilege4AReverseService
{
  public abstract String modifyOrgs(String paramString1, String paramString2, List<User_Group> paramList);

  public abstract String modifyRoles(String paramString1, String paramString2, List<UserRole> paramList);

  public abstract String modifyAccounts(String paramString1, String paramString2, List<User_User> paramList);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.service.IWsPrivilege4AReverseService
 * JD-Core Version:    0.6.2
 */
package com.asiainfo.biframe.privilege.webservices.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public abstract interface IWsPrivilege4AService
{
  @WebMethod
  public abstract String UpdateAppAcctSoap(@WebParam(name="RequestInfo") String paramString);

  @WebMethod
  public abstract String UpdateBatchAppAcctSoap(@WebParam(name="RequestInfo") String paramString);

  @WebMethod(exclude=true)
  public abstract String UpdateAppAcctRoleServices(String paramString1, String paramString2, String paramString3);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.service.IWsPrivilege4AService
 * JD-Core Version:    0.6.2
 */
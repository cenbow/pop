package com.asiainfo.biframe.privilege.webservices.service;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public abstract interface IWsPrivilegeService
{
  @WebMethod
  public abstract String QueryUserInfoSoap(String paramString);

  @WebMethod
  public abstract boolean isUserLegal(String paramString1, String paramString2);

  @WebMethod
  public abstract String getUserExt(String paramString);

  @WebMethod
  public abstract boolean haveRightByUserId(String paramString1, int paramInt1, int paramInt2, String paramString2);

  @WebMethod
  public abstract String isUserHasDataLevel(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.service.IWsPrivilegeService
 * JD-Core Version:    0.6.2
 */
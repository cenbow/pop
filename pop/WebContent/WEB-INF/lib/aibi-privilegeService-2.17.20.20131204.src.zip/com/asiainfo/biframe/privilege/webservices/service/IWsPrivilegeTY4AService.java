package com.asiainfo.biframe.privilege.webservices.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public abstract interface IWsPrivilegeTY4AService
{
  @WebMethod
  public abstract String findUser(@WebParam(name="userID") String paramString);

  @WebMethod
  public abstract String getUserAmount();

  @WebMethod
  public abstract String queryUsers();

  @WebMethod
  public abstract String queryUsersByPage(@WebParam(name="pageSize") String paramString1, @WebParam(name="pageNum") String paramString2);

  @WebMethod
  public abstract String queryOrgs();

  @WebMethod
  public abstract String addUserInfo(@WebParam(name="userInfos") String paramString);

  @WebMethod
  public abstract String modifyUserInfo(@WebParam(name="userInfos") String paramString);

  @WebMethod
  public abstract String delUser(@WebParam(name="userInfos") String paramString);

  public abstract String qryAccById(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.service.IWsPrivilegeTY4AService
 * JD-Core Version:    0.6.2
 */
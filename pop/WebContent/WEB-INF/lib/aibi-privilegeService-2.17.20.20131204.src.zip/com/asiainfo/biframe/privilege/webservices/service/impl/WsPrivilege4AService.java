/*     */ package com.asiainfo.biframe.privilege.webservices.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.log.LogInfo;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*     */ import com.asiainfo.biframe.privilege.base.constants.PrivilegeCodes;
/*     */ import com.asiainfo.biframe.privilege.base.constants.UserManager;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.cache.object.CacheUtils;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.beans.DeletedParameterVO;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*     */ import com.asiainfo.biframe.privilege.webservices.service.IWsPrivilege4AService;
/*     */ import com.asiainfo.biframe.privilege.webservices.util.WsPrivilege4AUtil;
/*     */ import com.asiainfo.biframe.privilege.webservices.util.foura.des.EncryptInterface;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import com.asiainfo.biframe.utils.db.PkeyUtil;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.ws.Dispatch;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.Service.Mode;
/*     */ import org.apache.commons.lang.xwork.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jdom.Element;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class WsPrivilege4AService
/*     */   implements IWsPrivilege4AService
/*     */ {
/*  86 */   private static Logger log = Logger.getLogger(WsPrivilege4AService.class);
/*     */   private IUserAdminService userAdminService;
/*     */   private IUserGroupAdminService userGroupAdminService;
/*     */   private IUserPrivilegeService userPrvilegeService;
/*     */ 
/*     */   public IUserPrivilegeService getUserPrvilegeService()
/*     */   {
/* 109 */     return this.userPrvilegeService;
/*     */   }
/*     */ 
/*     */   public void setUserPrvilegeService(IUserPrivilegeService userPrvilegeService)
/*     */   {
/* 118 */     this.userPrvilegeService = userPrvilegeService;
/*     */   }
/*     */ 
/*     */   public IUserAdminService getUserAdminService()
/*     */   {
/* 128 */     return this.userAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserAdminService(IUserAdminService userAdminService)
/*     */   {
/* 138 */     this.userAdminService = userAdminService;
/*     */   }
/*     */ 
/*     */   public IUserGroupAdminService getUserGroupAdminService()
/*     */   {
/* 148 */     return this.userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserGroupAdminService(IUserGroupAdminService userGroupAdminService)
/*     */   {
/* 159 */     this.userGroupAdminService = userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public String UpdateAppAcctSoap(String RequestInfo)
/*     */   {
/* 169 */     log.debug(" in UpdateAppAcctSoap RequestInfo=" + RequestInfo);
/*     */ 
/* 171 */     String rspHead = "";
/* 172 */     Map reqBodyMap = new HashMap();
/* 173 */     String errMsg = "";
/*     */     try {
/* 175 */       rspHead = WsPrivilege4AUtil.genRspHead(RequestInfo);
/* 176 */       reqBodyMap = WsPrivilege4AUtil.parseSimpleBodyXml(RequestInfo);
/*     */     } catch (Exception e) {
/* 178 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError");
/*     */ 
/* 180 */       return WsPrivilege4AUtil.genErrorMsg("USERMODIFYRSP", rspHead, (String)reqBodyMap.get("OPERATORID"), "", errMsg);
/*     */     }
/*     */ 
/* 184 */     String operatorID = (String)reqBodyMap.get("OPERATORID");
/* 185 */     String modifyMode = (String)reqBodyMap.get("MODIFYMODE");
/*     */ 
/* 194 */     String operatorIP = WsPrivilege4AUtil.getBodyElement(RequestInfo, "OPERATORIP").getText();
/*     */ 
/* 196 */     String operatorName = this.userAdminService.getUserName(operatorID);
/* 197 */     initLogInfo(operatorID, operatorIP, operatorName);
/*     */ 
/* 199 */     Map resultMap = new HashMap();
/* 200 */     if (modifyMode.equals("add"))
/* 201 */       resultMap.putAll(addAppAcct(reqBodyMap, operatorID));
/* 202 */     else if (modifyMode.equals("delete"))
/* 203 */       resultMap.putAll(deleteAppAcct(reqBodyMap, operatorID));
/* 204 */     else if (modifyMode.equals("change"))
/* 205 */       resultMap.putAll(changeAppAcct(reqBodyMap, operatorID));
/* 206 */     else if (modifyMode.equals("chgstatus"))
/* 207 */       resultMap.putAll(chgstatusAppAcct(reqBodyMap, operatorID));
/* 208 */     else if (modifyMode.equals("resetpwd"))
/* 209 */       resultMap.putAll(resetpwdAppAcct(reqBodyMap, operatorID));
/*     */     else {
/* 211 */       resultMap.put(reqBodyMap.get("USERID"), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.ModeError") + modifyMode);
/*     */     }
/*     */ 
/* 216 */     log.debug(" end UpdateAppAcctSoap");
/* 217 */     return WsPrivilege4AUtil.createUpdateAppAcctSoapRsp(rspHead, modifyMode, resultMap);
/*     */   }
/*     */ 
/*     */   public String UpdateBatchAppAcctSoap(String RequestInfo)
/*     */   {
/* 227 */     log.debug(" in UpdateAppAcctSoap1 RequestInfo=" + RequestInfo);
/*     */ 
/* 229 */     String rspHead = "";
/* 230 */     String errMsg = "";
/*     */     try {
/* 232 */       rspHead = WsPrivilege4AUtil.genRspHead(RequestInfo);
/*     */     } catch (Exception e) {
/* 234 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError");
/*     */ 
/* 236 */       return WsPrivilege4AUtil.genErrorMsg("USERMODIFYRSP", rspHead, "", "", errMsg);
/*     */     }
/*     */ 
/* 240 */     String operatorID = WsPrivilege4AUtil.getBodyElement(RequestInfo, "OPERATORID").getText();
/*     */ 
/* 253 */     String operatorIP = WsPrivilege4AUtil.getBodyElement(RequestInfo, "OPERATORIP").getText();
/*     */ 
/* 255 */     String operatorName = this.userAdminService.getUserName(operatorID);
/* 256 */     initLogInfo(operatorID, operatorIP, operatorName);
/*     */ 
/* 258 */     Element userList = WsPrivilege4AUtil.getBodyElement(RequestInfo, "USERLIST");
/*     */ 
/* 260 */     String modifyMode = userList.getChildText("MODIFYMODE");
/* 261 */     List userInfoList = userList.getChildren("USERINFO");
/* 262 */     Map resultMap = new HashMap();
/* 263 */     for (Element element : userInfoList) {
/* 264 */       Map parseMap = new HashMap();
/* 265 */       WsPrivilege4AUtil.getElement(element, parseMap);
/* 266 */       if (modifyMode.equals("add"))
/* 267 */         resultMap.putAll(addAppAcct(parseMap, operatorID));
/* 268 */       else if (modifyMode.equals("delete"))
/* 269 */         resultMap.putAll(deleteAppAcct(parseMap, operatorID));
/* 270 */       else if (modifyMode.equals("change"))
/* 271 */         resultMap.putAll(changeAppAcct(parseMap, operatorID));
/* 272 */       else if (modifyMode.equals("chgstatus"))
/* 273 */         resultMap.putAll(chgstatusAppAcct(parseMap, operatorID));
/* 274 */       else if (modifyMode.equals("resetpwd"))
/* 275 */         resultMap.putAll(resetpwdAppAcct(parseMap, operatorID));
/*     */       else {
/* 277 */         resultMap.put(element.getChildText("USERID"), LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.ModeError") + modifyMode);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 283 */     return WsPrivilege4AUtil.createUpdateBatchAppAcctRsp(rspHead, modifyMode, resultMap);
/*     */   }
/*     */ 
/*     */   private Map<String, String> addAppAcct(Map<String, String> parseMap, String operatorID)
/*     */   {
/* 298 */     Map resultMap = new HashMap();
/* 299 */     String errMsg = "";
/* 300 */     String userID = (String)parseMap.get("USERID");
/* 301 */     User_User user = this.userAdminService.getUser(userID);
/* 302 */     if (null != user) {
/* 303 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userAlreadyExist");
/*     */ 
/* 305 */       resultMap.put(userID, errMsg);
/* 306 */       return resultMap;
/*     */     }
/*     */ 
/* 309 */     errMsg = WsPrivilege4AUtil.validateUpdateAppAcctSoap(parseMap);
/* 310 */     if (StringUtils.isNotBlank(errMsg)) {
/* 311 */       resultMap.put(userID, errMsg);
/* 312 */       return resultMap;
/*     */     }
/*     */ 
/* 315 */     User_Group ug = getUserGroupAdminService().getUserGroup((String)parseMap.get("ORGID"));
/*     */ 
/* 317 */     if (null == ug) {
/* 318 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupNotExistFail");
/*     */ 
/* 320 */       resultMap.put(userID, errMsg);
/* 321 */       return resultMap;
/*     */     }
/*     */ 
/* 324 */     if (!this.userAdminService.isAdminUser(operatorID)) {
/* 325 */       boolean isParent = getUserGroupAdminService().isParentGroupByCache(this.userAdminService.getGroup(operatorID), (String)parseMap.get("ORGID"));
/*     */ 
/* 328 */       if (!isParent) {
/* 329 */         errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotUpate");
/*     */ 
/* 331 */         resultMap.put(userID, errMsg);
/* 332 */         return resultMap;
/*     */       }
/*     */     }
/* 335 */     user = new User_User();
/* 336 */     user.setUserid(userID);
/* 337 */     user.setUsername((String)parseMap.get("USERNAME"));
/* 338 */     user.setGroupId((String)parseMap.get("ORGID"));
/* 339 */     user.setCityid((String)parseMap.get("CITYID"));
/* 340 */     user.setDutyid(Integer.valueOf(Integer.parseInt((String)parseMap.get("DUTYID"))));
/* 341 */     user.setDepartmentid(Integer.parseInt((String)parseMap.get("DEPARTMENTID")));
/* 342 */     user.setMobilephone((String)parseMap.get("MOBILE"));
/* 343 */     user.setDomainType((String)parseMap.get("DOMAINTYPE"));
/* 344 */     user.setEmail((String)parseMap.get("EMAIL"));
/* 345 */     String effectdate = (String)parseMap.get("EFFECTDATE");
/* 346 */     if (StringUtils.isNotBlank(effectdate)) {
/* 347 */       user.setBegindate(DateUtil.string2Date(effectdate, "yyyy-MM-dd HH:mm:ss"));
/*     */     }
/* 349 */     String expiredate = (String)parseMap.get("EXPIREDATE");
/* 350 */     if (StringUtils.isNotBlank(expiredate)) {
/* 351 */       user.setEnddate(DateUtil.string2Date(expiredate, "yyyy-MM-dd HH:mm:ss"));
/*     */     }
/* 353 */     user.setNotes((String)parseMap.get("REMARK"));
/* 354 */     String password = (String)parseMap.get("PASSWORD");
/* 355 */     password = EncryptInterface.desUnEncryptData(password);
/* 356 */     user.setDesPwd(password);
/* 357 */     String[] groupList = { (String)parseMap.get("ORGID") };
/* 358 */     getUserAdminService().addUser(user, groupList, "" + user.getDepartmentid(), "0");
/*     */ 
/* 360 */     refreshUserCacheByKey(userID);
/* 361 */     resultMap.put(userID, errMsg);
/* 362 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private Map<String, String> deleteAppAcct(Map<String, String> parseMap, String operatorID)
/*     */   {
/* 376 */     Map resultMap = new HashMap();
/* 377 */     String errMsg = "";
/* 378 */     String userID = (String)parseMap.get("USERID");
/* 379 */     User_User user = this.userAdminService.getUser(userID);
/* 380 */     if (null == user) {
/* 381 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExist");
/*     */ 
/* 383 */       resultMap.put(userID, errMsg);
/* 384 */       return resultMap;
/*     */     }
/* 386 */     if (!this.userAdminService.isAdminUser(operatorID)) {
/* 387 */       boolean isParent = getUserGroupAdminService().isParentGroupByCache(this.userAdminService.getGroup(operatorID), this.userAdminService.getGroup(userID));
/*     */ 
/* 390 */       if (!isParent) {
/* 391 */         errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotUpate");
/*     */ 
/* 393 */         resultMap.put(userID, errMsg);
/* 394 */         return resultMap;
/*     */       }
/*     */     }
/* 397 */     getUserAdminService().deleteUser(user);
/* 398 */     DeletedParameterVO vo = new DeletedParameterVO();
/* 399 */     List idList = new ArrayList();
/* 400 */     idList.add(userID);
/* 401 */     vo.setIds(idList);
/* 402 */     vo.setIdString(true);
/* 403 */     getUserAdminService().doRealDeleteUser(vo);
/* 404 */     refreshCaches();
/* 405 */     resultMap.put(userID, errMsg);
/* 406 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private Map<String, String> changeAppAcct(Map<String, String> parseMap, String operatorID)
/*     */   {
/* 420 */     Map resultMap = new HashMap();
/* 421 */     String errMsg = "";
/* 422 */     String userID = (String)parseMap.get("USERID");
/* 423 */     User_User user = this.userAdminService.getUser(userID);
/* 424 */     if (null == user) {
/* 425 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExist");
/*     */ 
/* 427 */       resultMap.put(userID, errMsg);
/* 428 */       return resultMap;
/*     */     }
/*     */ 
/* 431 */     String orgID = (String)parseMap.get("ORGID");
/* 432 */     if (StringUtils.isNotBlank(orgID)) {
/* 433 */       User_Group ug = getUserGroupAdminService().getUserGroup(orgID);
/* 434 */       if (null == ug) {
/* 435 */         errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupNotExistFail");
/*     */ 
/* 437 */         resultMap.put(userID, errMsg);
/* 438 */         return resultMap;
/*     */       }
/*     */     } else {
/* 441 */       orgID = this.userAdminService.getGroup(userID);
/*     */     }
/*     */ 
/* 444 */     if (!this.userAdminService.isAdminUser(operatorID)) {
/* 445 */       boolean isParent = getUserGroupAdminService().isParentGroupByCache(this.userAdminService.getGroup(operatorID), orgID);
/*     */ 
/* 448 */       if (!isParent) {
/* 449 */         errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotUpate");
/*     */ 
/* 451 */         resultMap.put(userID, errMsg);
/* 452 */         return resultMap;
/*     */       }
/*     */     }
/* 455 */     user.setGroupId(orgID);
/* 456 */     if (StringUtils.isNotBlank((String)parseMap.get("USERNAME"))) {
/* 457 */       user.setUsername((String)parseMap.get("USERNAME"));
/*     */     }
/* 459 */     if (StringUtils.isNotBlank((String)parseMap.get("CITYID"))) {
/* 460 */       user.setCityid((String)parseMap.get("CITYID"));
/*     */     }
/* 462 */     if (StringUtils.isNotBlank((String)parseMap.get("DUTYID"))) {
/* 463 */       user.setDutyid(Integer.valueOf(Integer.parseInt((String)parseMap.get("DUTYID"))));
/*     */     }
/* 465 */     if (StringUtils.isNotBlank((String)parseMap.get("DEPARTMENTID"))) {
/* 466 */       user.setDepartmentid(Integer.parseInt((String)parseMap.get("DEPARTMENTID")));
/*     */     }
/* 468 */     if (StringUtils.isNotBlank((String)parseMap.get("MOBILE"))) {
/* 469 */       user.setMobilephone((String)parseMap.get("MOBILE"));
/*     */     }
/* 471 */     user.setDomainType((String)parseMap.get("DOMAINTYPE"));
/* 472 */     user.setEmail((String)parseMap.get("EMAIL"));
/* 473 */     String effectdate = (String)parseMap.get("EFFECTDATE");
/* 474 */     if (StringUtils.isNotBlank(effectdate)) {
/* 475 */       user.setBegindate(DateUtil.string2Date(effectdate, "yyyy-MM-dd HH:mm:ss"));
/*     */     }
/* 477 */     String expiredate = (String)parseMap.get("EXPIREDATE");
/* 478 */     if (StringUtils.isNotBlank(expiredate)) {
/* 479 */       user.setEnddate(DateUtil.string2Date(expiredate, "yyyy-MM-dd HH:mm:ss"));
/*     */     }
/* 481 */     user.setNotes((String)parseMap.get("REMARK"));
/* 482 */     String[] groupList = { user.getGroupId() };
/* 483 */     getUserAdminService().updateUser(user, groupList, "" + user.getDepartmentid(), "0");
/*     */ 
/* 485 */     refreshUserCacheByKey(userID);
/* 486 */     resultMap.put(userID, errMsg);
/* 487 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private Map<String, String> chgstatusAppAcct(Map<String, String> parseMap, String operatorID)
/*     */   {
/* 501 */     Map resultMap = new HashMap();
/* 502 */     String errMsg = "";
/* 503 */     String userID = (String)parseMap.get("USERID");
/* 504 */     User_User user = this.userAdminService.getUser(userID);
/* 505 */     if (null == user) {
/* 506 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExist");
/*     */ 
/* 508 */       resultMap.put(userID, errMsg);
/* 509 */       return resultMap;
/*     */     }
/* 511 */     String status = (String)parseMap.get("STATUS");
/* 512 */     if ("0".equals(status))
/* 513 */       user.setStatus(0);
/*     */     else {
/* 515 */       user.setStatus(1);
/*     */     }
/* 517 */     getUserAdminService().updateUser(user);
/* 518 */     refreshUserCacheByKey(userID);
/* 519 */     resultMap.put(userID, errMsg);
/* 520 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private Map<String, String> resetpwdAppAcct(Map<String, String> parseMap, String operatorID)
/*     */   {
/* 534 */     Map resultMap = new HashMap();
/* 535 */     String errMsg = "";
/* 536 */     String userID = (String)parseMap.get("USERID");
/* 537 */     User_User user = this.userAdminService.getUser(userID);
/* 538 */     if (null == user) {
/* 539 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExist");
/*     */ 
/* 541 */       resultMap.put(userID, errMsg);
/* 542 */       return resultMap;
/*     */     }
/* 544 */     if (!this.userAdminService.isAdminUser(operatorID)) {
/* 545 */       boolean isParent = getUserGroupAdminService().isParentGroupByCache(this.userAdminService.getGroup(operatorID), this.userAdminService.getGroup(userID));
/*     */ 
/* 548 */       if (!isParent) {
/* 549 */         errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotUpate");
/*     */ 
/* 551 */         resultMap.put(userID, errMsg);
/* 552 */         return resultMap;
/*     */       }
/*     */     }
/* 555 */     String password = (String)parseMap.get("PASSWORD");
/* 556 */     password = EncryptInterface.desUnEncryptData(password);
/* 557 */     user.setDesPwd(password);
/* 558 */     getUserAdminService().updateUserPwd(user, "0");
/* 559 */     refreshUserCacheByKey(userID);
/* 560 */     resultMap.put(userID, errMsg);
/* 561 */     return resultMap;
/*     */   }
/*     */ 
/*     */   public void initLogInfo(String operatorID, String clientIp, String operatorName)
/*     */   {
/* 574 */     LogInfo info = new LogInfo();
/* 575 */     LogInfo.setSessionID(PkeyUtil.generateHexUUID());
/* 576 */     LogInfo.setClientAddress(clientIp);
/* 577 */     LogInfo.setHostAddress(UserManager.getHostAddress());
/* 578 */     LogInfo.setOperatorID(operatorID);
/* 579 */     LogInfo.setOperatorName(operatorName);
/* 580 */     info.setResourceType(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_LOGONFAILURE"));
/*     */ 
/* 582 */     info.setOperaterType(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_LOGON"));
/*     */   }
/*     */ 
/*     */   public void refreshUserCacheByKey(String userId)
/*     */   {
/* 592 */     CacheUtils.refreshUserCacheByKey(userId);
/*     */   }
/*     */ 
/*     */   public void refreshCaches()
/*     */   {
/* 599 */     CacheUtils.refreshGroupCache();
/* 600 */     CacheUtils.refreshUserCache();
/* 601 */     CacheUtils.refreshRoleCache();
/*     */   }
/*     */ 
/*     */   public static String UpdateAppOrgServices(String operatorId, String modifyMode, List<User_Group> groups)
/*     */   {
/* 613 */     StringBuffer body = new StringBuffer();
/* 614 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(operatorId);
/* 615 */     if (user == null) return null;
/* 616 */     body.append("<BODY>");
/* 617 */     body.append("<OPERATORID>").append(operatorId).append("</OPERATORID>");
/* 618 */     body.append("<OPERATORPWD>").append(user.getPwd()).append("</OPERATORPWD>");
/* 619 */     body.append("<ORGINFOS>");
/* 620 */     for (User_Group group : groups) {
/* 621 */       body.append("<ORGINFO>");
/* 622 */       body.append("<MODIFYMODE>").append(modifyMode).append("</MODIFYMODE>");
/* 623 */       body.append("<ORGID>").append(group.getGroupid()).append("</ORGID>");
/* 624 */       body.append("<ORGNAME>").append(group.getGroupname()).append("</ORGNAME>");
/* 625 */       body.append("<PARENTORGID>").append(group.getParentid()).append("</PARENTORGID>");
/* 626 */       body.append("</ORGINFO>");
/*     */     }
/* 628 */     body.append("</ORGINFOS>");
/* 629 */     body.append("</BODY>");
/* 630 */     String reqXml = WsPrivilege4AUtil.genReqXml("ORGINFOMODIFYREQ", body.toString());
/*     */ 
/* 633 */     QName serviceName = new QName("CommonWebServiceService");
/* 634 */     QName portName = new QName("UpdateAppOrgServices");
/* 635 */     String endpointAddress = PrivilegeCodes.getWsUrl4A() + "UpdateAppOrgServices";
/*     */ 
/* 637 */     Service service = Service.create(serviceName);
/* 638 */     service.addPort(portName, "http://schemas.xmlsoap.org/wsdl/soap/http", endpointAddress);
/* 639 */     Dispatch dispatcher = service.createDispatch(portName, Source.class, Service.Mode.PAYLOAD);
/*     */ 
/* 641 */     Map requestContext = dispatcher.getRequestContext();
/* 642 */     StringBuffer reqBuffer = new StringBuffer();
/* 643 */     reqBuffer.append("<UpdateAppOrgServices>");
/* 644 */     reqBuffer.append("<RequestInfo type='string'><![CDATA[" + reqXml + "]]></RequestInfo>");
/* 645 */     reqBuffer.append("</UpdateAppOrgServices>");
/* 646 */     Document doc = null;
/*     */     try {
/* 648 */       StringReader sr = new StringReader(reqBuffer.toString());
/* 649 */       InputSource is = new InputSource(sr);
/* 650 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 651 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 652 */       doc = builder.parse(is);
/*     */ 
/* 654 */       DOMSource reqMsg = new DOMSource(doc);
/* 655 */       requestContext.put("javax.xml.ws.soap.http.soapaction.use", Boolean.TRUE);
/* 656 */       requestContext.put("javax.xml.ws.soap.http.soapaction.uri", "");
/* 657 */       requestContext.put("javax.xml.ws.http.request.method", "POST");
/* 658 */       result = (Source)dispatcher.invoke(reqMsg);
/*     */     }
/*     */     catch (ParserConfigurationException e)
/*     */     {
/*     */       Source result;
/* 660 */       log.debug(e);
/*     */     } catch (SAXException e) {
/* 662 */       log.debug(e);
/*     */     } catch (IOException e) {
/* 664 */       log.debug(e);
/*     */     } catch (Exception e) {
/* 666 */       log.debug(e);
/*     */     }
/*     */ 
/* 669 */     return "";
/*     */   }
/*     */ 
/*     */   public static String UpdateAppRoleServices(String operatorId, String modifyMode, List<UserRole> roles)
/*     */   {
/* 681 */     StringBuffer body = new StringBuffer();
/* 682 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(operatorId);
/* 683 */     if (user == null) return null;
/* 684 */     body.append("<BODY>");
/* 685 */     body.append("<OPERATORID>").append(operatorId).append("</OPERATORID>");
/* 686 */     body.append("<OPERATORPWD>").append(user.getPwd()).append("</OPERATORPWD>");
/* 687 */     body.append("<ROLEINFOS>");
/* 688 */     for (UserRole role : roles) {
/* 689 */       body.append("<ROLEINFO>");
/* 690 */       body.append("<MODIFYMODE>").append(modifyMode).append("</MODIFYMODE>");
/* 691 */       body.append("<ROLEID>").append(role.getRoleId()).append("</ROLEID>");
/* 692 */       body.append("<ROLENAME>").append(role.getRoleName()).append("</ROLENAME>");
/* 693 */       body.append("<PARENTID>").append(role.getParentId() == null ? "" : role.getParentId()).append("</PARENTID>");
/* 694 */       body.append("</ROLEINFO>");
/*     */     }
/* 696 */     body.append("</ROLEINFOS>");
/* 697 */     body.append("</BODY>");
/* 698 */     String reqXml = WsPrivilege4AUtil.genReqXml("ROLEMODIFYREQ", body.toString());
/*     */ 
/* 701 */     QName serviceName = new QName("CommonWebServiceService");
/* 702 */     QName portName = new QName("UpdateAppRoleServices");
/* 703 */     String endpointAddress = PrivilegeCodes.getWsUrl4A() + "UpdateAppRoleServices";
/*     */ 
/* 705 */     Service service = Service.create(serviceName);
/* 706 */     service.addPort(portName, "http://schemas.xmlsoap.org/wsdl/soap/http", endpointAddress);
/* 707 */     Dispatch dispatcher = service.createDispatch(portName, Source.class, Service.Mode.PAYLOAD);
/*     */ 
/* 709 */     Map requestContext = dispatcher.getRequestContext();
/* 710 */     StringBuffer reqBuffer = new StringBuffer();
/*     */ 
/* 712 */     reqBuffer.append("<UpdateAppRoleServices>");
/* 713 */     reqBuffer.append("<RequestInfo type='string'><![CDATA[" + reqXml + "]]></RequestInfo>");
/* 714 */     reqBuffer.append("</UpdateAppRoleServices>");
/* 715 */     Document doc = null;
/*     */     try {
/* 717 */       StringReader sr = new StringReader(reqBuffer.toString());
/* 718 */       InputSource is = new InputSource(sr);
/* 719 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 720 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 721 */       doc = builder.parse(is);
/*     */ 
/* 723 */       DOMSource reqMsg = new DOMSource(doc);
/* 724 */       requestContext.put("javax.xml.ws.soap.http.soapaction.use", Boolean.TRUE);
/* 725 */       requestContext.put("javax.xml.ws.soap.http.soapaction.uri", "");
/* 726 */       requestContext.put("javax.xml.ws.http.request.method", "POST");
/* 727 */       result = (Source)dispatcher.invoke(reqMsg);
/*     */     }
/*     */     catch (ParserConfigurationException e)
/*     */     {
/*     */       Source result;
/* 729 */       log.debug(e);
/*     */     } catch (SAXException e) {
/* 731 */       log.debug(e);
/*     */     } catch (IOException e) {
/* 733 */       log.debug(e);
/*     */     } catch (Exception e) {
/* 735 */       log.debug(e);
/*     */     }
/*     */ 
/* 738 */     return "";
/*     */   }
/*     */ 
/*     */   public String UpdateAppAcctRoleServices(String operatorId, String groupId, String userId)
/*     */   {
/* 750 */     StringBuffer body = new StringBuffer();
/* 751 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(operatorId);
/* 752 */     if (user == null) return null;
/* 753 */     body.append("<BODY>");
/* 754 */     body.append("<OPERATORID>").append(operatorId).append("</OPERATORID>");
/* 755 */     body.append("<OPERATORPWD>").append(user.getPwd()).append("</OPERATORPWD>");
/* 756 */     body.append("<OPERATORIP>").append("ip").append("</OPERATORIP>");
/* 757 */     body.append("<USERLIST>");
/* 758 */     if (StringUtil.isNotEmpty(groupId)) {
/* 759 */       List users = getUserPrvilegeService().getUsersByGroupId(groupId);
/*     */ 
/* 761 */       for (IUser u : users) {
/* 762 */         body.append("<USERINFO>");
/* 763 */         body.append("<USERID>").append(u.getUserid()).append("</USERID>");
/* 764 */         List userRoles = getUserAdminService().getRolesByUserId(u.getUserid());
/* 765 */         body.append("<ROLELIST>");
/* 766 */         for (UserRole role : userRoles) {
/* 767 */           body.append("<ROLE>");
/* 768 */           body.append("<ID>" + role.getRoleId() + "</ID>");
/* 769 */           body.append("<NAME>" + role.getRoleName() + "</NAME>");
/* 770 */           body.append("<ORGID>" + role.getCreateGroup() + "</ORGID>");
/* 771 */           body.append("<EFFECTDATE>" + role.getBeginDate() + "</EFFECTDATE>");
/* 772 */           body.append("<EXPIREDATE>" + role.getEndDate() + "失效时间</EXPIREDATE>");
/* 773 */           body.append("</ROLE>");
/*     */         }
/* 775 */         body.append("</ROLELIST>");
/* 776 */         body.append("</USERINFO>");
/*     */       }
/* 778 */     } else if (StringUtil.isNotEmpty(userId)) {
/* 779 */       body.append("<USERINFO>");
/* 780 */       body.append("<USERID>").append(userId).append("</USERID>");
/* 781 */       List userRoles = getUserAdminService().getRolesByUserId(userId);
/* 782 */       body.append("<ROLELIST>");
/* 783 */       for (UserRole role : userRoles) {
/* 784 */         body.append("<ROLE>");
/* 785 */         body.append("<ID>" + role.getRoleId() + "</ID>");
/* 786 */         body.append("<NAME>" + role.getRoleName() + "</NAME>");
/* 787 */         body.append("<ORGID>" + role.getCreateGroup() + "</ORGID>");
/* 788 */         body.append("<EFFECTDATE>" + role.getBeginDate() + "</EFFECTDATE>");
/* 789 */         body.append("<EXPIREDATE>" + role.getEndDate() + "失效时间</EXPIREDATE>");
/* 790 */         body.append("</ROLE>");
/*     */       }
/* 792 */       body.append("</ROLELIST>");
/* 793 */       body.append("</USERINFO>");
/*     */     }
/*     */ 
/* 796 */     body.append("</USERLIST>");
/* 797 */     body.append("</BODY>");
/* 798 */     String reqXml = WsPrivilege4AUtil.genReqXml("USERROLEMODIFYREQ", body.toString());
/*     */ 
/* 801 */     QName serviceName = new QName("CommonWebServiceService");
/* 802 */     QName portName = new QName("UpdateAppAcctRoleServices");
/* 803 */     String endpointAddress = PrivilegeCodes.getWsUrl4A() + "UpdateAppAcctRoleServices";
/*     */ 
/* 805 */     Service service = Service.create(serviceName);
/* 806 */     service.addPort(portName, "http://schemas.xmlsoap.org/wsdl/soap/http", endpointAddress);
/* 807 */     Dispatch dispatcher = service.createDispatch(portName, Source.class, Service.Mode.PAYLOAD);
/*     */ 
/* 809 */     Map requestContext = dispatcher.getRequestContext();
/* 810 */     StringBuffer reqBuffer = new StringBuffer();
/* 811 */     reqBuffer.append("<UpdateAppAcctRoleServices>");
/* 812 */     reqBuffer.append("<RequestInfo type='string'><![CDATA[" + reqXml + "]]></RequestInfo>");
/* 813 */     reqBuffer.append("</UpdateAppAcctRoleServices>");
/* 814 */     Document doc = null;
/*     */     try {
/* 816 */       StringReader sr = new StringReader(reqBuffer.toString());
/* 817 */       InputSource is = new InputSource(sr);
/* 818 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 819 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 820 */       doc = builder.parse(is);
/*     */ 
/* 822 */       DOMSource reqMsg = new DOMSource(doc);
/* 823 */       requestContext.put("javax.xml.ws.soap.http.soapaction.use", Boolean.TRUE);
/* 824 */       requestContext.put("javax.xml.ws.soap.http.soapaction.uri", "");
/* 825 */       requestContext.put("javax.xml.ws.http.request.method", "POST");
/* 826 */       result = (Source)dispatcher.invoke(reqMsg);
/*     */     }
/*     */     catch (ParserConfigurationException e)
/*     */     {
/*     */       Source result;
/* 828 */       log.debug(e);
/*     */     } catch (SAXException e) {
/* 830 */       log.debug(e);
/*     */     } catch (IOException e) {
/* 832 */       log.debug(e);
/*     */     } catch (Exception e) {
/* 834 */       log.debug(e);
/*     */     }
/*     */ 
/* 837 */     return "";
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.service.impl.WsPrivilege4AService
 * JD-Core Version:    0.6.2
 */
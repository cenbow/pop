/*     */ package com.asiainfo.biframe.privilege.webservices.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.base.constants.PrivilegeCodes;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*     */ import com.asiainfo.biframe.privilege.model.UserRole;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.webservices.service.IWsPrivilege4AReverseService;
/*     */ import com.asiainfo.biframe.privilege.webservices.util.WsPrivilege4AUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.ws.Dispatch;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.Service.Mode;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class WsPrivilege4AServiceNew
/*     */   implements IWsPrivilege4AReverseService
/*     */ {
/*  37 */   private static Logger log = Logger.getLogger(WsPrivilege4AService.class);
/*     */ 
/*     */   public String modifyOrgs(String operatorId, String modifyMode, List<User_Group> groups)
/*     */   {
/*  48 */     StringBuffer body = new StringBuffer();
/*  49 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(operatorId);
/*  50 */     if (user == null) return null;
/*  51 */     body.append("<modifyParams>");
/*  52 */     body.append("<resID>").append(operatorId).append("</resID>");
/*  53 */     body.append("<resPassword>").append(user.getPwd()).append("</resPassword>");
/*  54 */     body.append("<operations>");
/*  55 */     for (User_Group group : groups) {
/*  56 */       body.append("<operation>");
/*  57 */       body.append("<operType>").append(modifyMode).append("</operType>");
/*  58 */       body.append("<org>");
/*  59 */       body.append("<orgID>").append(group.getGroupid()).append("</orgID>");
/*  60 */       body.append("<orgName>").append(group.getGroupname()).append("</orgName>");
/*  61 */       body.append("<parentOrgID>").append(group.getParentid()).append("</parentOrgID>");
/*  62 */       body.append("<org>");
/*  63 */       body.append("</operation>");
/*     */     }
/*  65 */     body.append("</operations>");
/*  66 */     body.append("</modifyParams>");
/*  67 */     String reqXml = WsPrivilege4AUtil.genReqXml("ORGINFOMODIFYREQ", body.toString());
/*     */ 
/*  70 */     QName serviceName = new QName("CommonWebServiceService");
/*  71 */     QName portName = new QName("modifyOrgs");
/*  72 */     String endpointAddress = PrivilegeCodes.getWsUrl4A() + "modifyOrgs";
/*     */ 
/*  74 */     Service service = Service.create(serviceName);
/*  75 */     service.addPort(portName, "http://schemas.xmlsoap.org/wsdl/soap/http", endpointAddress);
/*  76 */     Dispatch dispatcher = service.createDispatch(portName, Source.class, Service.Mode.PAYLOAD);
/*     */ 
/*  78 */     Map requestContext = dispatcher.getRequestContext();
/*  79 */     StringBuffer reqBuffer = new StringBuffer();
/*  80 */     reqBuffer.append("<modifyOrgs>");
/*  81 */     reqBuffer.append("<RequestInfo type='string'><![CDATA[" + reqXml + "]]></RequestInfo>");
/*  82 */     reqBuffer.append("</modifyOrgs>");
/*  83 */     Document doc = null;
/*     */     try {
/*  85 */       StringReader sr = new StringReader(reqBuffer.toString());
/*  86 */       InputSource is = new InputSource(sr);
/*  87 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*  88 */       DocumentBuilder builder = factory.newDocumentBuilder();
/*  89 */       doc = builder.parse(is);
/*     */ 
/*  91 */       DOMSource reqMsg = new DOMSource(doc);
/*  92 */       requestContext.put("javax.xml.ws.soap.http.soapaction.use", Boolean.TRUE);
/*  93 */       requestContext.put("javax.xml.ws.soap.http.soapaction.uri", "");
/*  94 */       requestContext.put("javax.xml.ws.http.request.method", "POST");
/*  95 */       result = (Source)dispatcher.invoke(reqMsg);
/*     */     }
/*     */     catch (ParserConfigurationException e)
/*     */     {
/*     */       Source result;
/*  97 */       log.debug(e);
/*     */     } catch (SAXException e) {
/*  99 */       log.debug(e);
/*     */     } catch (IOException e) {
/* 101 */       log.debug(e);
/*     */     } catch (Exception e) {
/* 103 */       log.debug(e);
/*     */     }
/*     */ 
/* 106 */     return "";
/*     */   }
/*     */ 
/*     */   public String modifyRoles(String operatorId, String modifyMode, List<UserRole> roles)
/*     */   {
/* 118 */     StringBuffer body = new StringBuffer();
/* 119 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(operatorId);
/* 120 */     if (user == null) return null;
/* 121 */     body.append("<modifyParams>");
/* 122 */     body.append("<resID>").append(operatorId).append("</resID>");
/* 123 */     body.append("<resPassword>").append(user.getPwd()).append("</resPassword>");
/* 124 */     body.append("<operations>");
/* 125 */     for (UserRole role : roles) {
/* 126 */       body.append("<operation>");
/* 127 */       body.append("<operType>").append(modifyMode).append("</operType>");
/* 128 */       body.append("<role>");
/* 129 */       body.append("<roleID>").append(role.getRoleId()).append("</roleID>");
/* 130 */       body.append("<roleName>").append(role.getRoleName()).append("</roleName>");
/* 131 */       body.append("<parentRoleID>").append(role.getParentId() == null ? "" : role.getParentId()).append("</parentRoleID>");
/* 132 */       body.append("<role>");
/* 133 */       body.append("</operation>");
/*     */     }
/* 135 */     body.append("</operations>");
/* 136 */     body.append("</modifyParams>");
/* 137 */     String reqXml = WsPrivilege4AUtil.genReqXml("ROLEMODIFYREQ", body.toString());
/*     */ 
/* 140 */     QName serviceName = new QName("CommonWebServiceService");
/* 141 */     QName portName = new QName("modifyRoles");
/* 142 */     String endpointAddress = PrivilegeCodes.getWsUrl4A() + "modifyRoles";
/*     */ 
/* 144 */     Service service = Service.create(serviceName);
/* 145 */     service.addPort(portName, "http://schemas.xmlsoap.org/wsdl/soap/http", endpointAddress);
/* 146 */     Dispatch dispatcher = service.createDispatch(portName, Source.class, Service.Mode.PAYLOAD);
/*     */ 
/* 148 */     Map requestContext = dispatcher.getRequestContext();
/* 149 */     StringBuffer reqBuffer = new StringBuffer();
/*     */ 
/* 151 */     reqBuffer.append("<modifyRoles>");
/* 152 */     reqBuffer.append("<RequestInfo type='string'><![CDATA[" + reqXml + "]]></RequestInfo>");
/* 153 */     reqBuffer.append("</modifyRoles>");
/* 154 */     Document doc = null;
/*     */     try {
/* 156 */       StringReader sr = new StringReader(reqBuffer.toString());
/* 157 */       InputSource is = new InputSource(sr);
/* 158 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 159 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 160 */       doc = builder.parse(is);
/*     */ 
/* 162 */       DOMSource reqMsg = new DOMSource(doc);
/* 163 */       requestContext.put("javax.xml.ws.soap.http.soapaction.use", Boolean.TRUE);
/* 164 */       requestContext.put("javax.xml.ws.soap.http.soapaction.uri", "");
/* 165 */       requestContext.put("javax.xml.ws.http.request.method", "POST");
/* 166 */       result = (Source)dispatcher.invoke(reqMsg);
/*     */     }
/*     */     catch (ParserConfigurationException e)
/*     */     {
/*     */       Source result;
/* 168 */       log.debug(e);
/*     */     } catch (SAXException e) {
/* 170 */       log.debug(e);
/*     */     } catch (IOException e) {
/* 172 */       log.debug(e);
/*     */     } catch (Exception e) {
/* 174 */       log.debug(e);
/*     */     }
/*     */ 
/* 177 */     return "";
/*     */   }
/*     */ 
/*     */   public String modifyAccounts(String operatorId, String modifyMode, List<User_User> users)
/*     */   {
/* 190 */     StringBuffer body = new StringBuffer();
/* 191 */     User_User user = (User_User)UserCache.getInstance().getObjectByKey(operatorId);
/* 192 */     if (user == null) return null;
/* 193 */     body.append("<modifyParams>");
/* 194 */     body.append("<resID>").append(operatorId).append("</resID>");
/* 195 */     body.append("<resPassword>").append(user.getPwd()).append("</resPassword>");
/* 196 */     body.append("<operations>");
/* 197 */     for (User_User us : users) {
/* 198 */       body.append("<operation>");
/* 199 */       body.append("<operType>").append(modifyMode).append("</operType>");
/* 200 */       body.append("<account>");
/* 201 */       body.append("<accID>").append(us.getUserid()).append("</accID>");
/* 202 */       body.append("<accountPasswordSHA1>").append(us.getPassword()).append("</accountPasswordSHA1>");
/* 203 */       body.append("<name>").append(us.getUsername()).append("</name>");
/* 204 */       body.append("<email>").append(us.getEmail()).append("</email>");
/* 205 */       body.append("<mobile>").append(us.getMobilephone()).append("</mobile>");
/* 206 */       body.append("<account>");
/* 207 */       body.append("</operation>");
/*     */     }
/* 209 */     body.append("</operations>");
/* 210 */     body.append("</modifyParams>");
/* 211 */     String reqXml = WsPrivilege4AUtil.genReqXml("ACCMODIFYREQ", body.toString());
/*     */ 
/* 214 */     QName serviceName = new QName("CommonWebServiceService");
/* 215 */     QName portName = new QName("modifyAccounts");
/* 216 */     String endpointAddress = PrivilegeCodes.getWsUrl4A() + "modifyAccounts";
/*     */ 
/* 218 */     Service service = Service.create(serviceName);
/* 219 */     service.addPort(portName, "http://schemas.xmlsoap.org/wsdl/soap/http", endpointAddress);
/* 220 */     Dispatch dispatcher = service.createDispatch(portName, Source.class, Service.Mode.PAYLOAD);
/*     */ 
/* 222 */     Map requestContext = dispatcher.getRequestContext();
/* 223 */     StringBuffer reqBuffer = new StringBuffer();
/*     */ 
/* 225 */     reqBuffer.append("<modifyAccounts>");
/* 226 */     reqBuffer.append("<RequestInfo type='string'><![CDATA[" + reqXml + "]]></RequestInfo>");
/* 227 */     reqBuffer.append("</modifyAccounts>");
/* 228 */     Document doc = null;
/*     */     try {
/* 230 */       StringReader sr = new StringReader(reqBuffer.toString());
/* 231 */       InputSource is = new InputSource(sr);
/* 232 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 233 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 234 */       doc = builder.parse(is);
/*     */ 
/* 236 */       DOMSource reqMsg = new DOMSource(doc);
/* 237 */       requestContext.put("javax.xml.ws.soap.http.soapaction.use", Boolean.TRUE);
/* 238 */       requestContext.put("javax.xml.ws.soap.http.soapaction.uri", "");
/* 239 */       requestContext.put("javax.xml.ws.http.request.method", "POST");
/* 240 */       result = (Source)dispatcher.invoke(reqMsg);
/*     */     }
/*     */     catch (ParserConfigurationException e)
/*     */     {
/*     */       Source result;
/* 242 */       log.debug(e);
/*     */     } catch (SAXException e) {
/* 244 */       log.debug(e);
/*     */     } catch (IOException e) {
/* 246 */       log.debug(e);
/*     */     } catch (Exception e) {
/* 248 */       log.debug(e);
/*     */     }
/*     */ 
/* 251 */     return "";
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.service.impl.WsPrivilege4AServiceNew
 * JD-Core Version:    0.6.2
 */
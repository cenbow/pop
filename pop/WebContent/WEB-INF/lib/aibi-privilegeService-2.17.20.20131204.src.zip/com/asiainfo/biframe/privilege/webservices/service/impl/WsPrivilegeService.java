/*     */ package com.asiainfo.biframe.privilege.webservices.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*     */ import com.asiainfo.biframe.privilege.model.UserUserExt;
/*     */ import com.asiainfo.biframe.privilege.model.User_Group;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.privilege.webservices.service.IWsPrivilegeService;
/*     */ import com.asiainfo.biframe.privilege.webservices.util.Result;
/*     */ import com.asiainfo.biframe.privilege.webservices.util.Results;
/*     */ import com.asiainfo.biframe.privilege.webservices.util.SensitiveData;
/*     */ import com.asiainfo.biframe.service.impl.WSDynamicClient;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import com.asiainfo.biframe.utils.webservice.HeaderResp;
/*     */ import com.asiainfo.biframe.utils.webservice.Parameter;
/*     */ import com.asiainfo.biframe.utils.webservice.Parameters;
/*     */ import com.asiainfo.biframe.utils.webservice.ReqData;
/*     */ import com.asiainfo.biframe.utils.webservice.RequestContent;
/*     */ import com.asiainfo.biframe.utils.webservice.RequestMessageBuilder;
/*     */ import com.asiainfo.biframe.utils.webservice.RespData;
/*     */ import com.asiainfo.biframe.utils.webservice.ResponseContent;
/*     */ import com.asiainfo.biframe.utils.webservice.ResponseMessage;
/*     */ import com.asiainfo.biframe.utils.webservice.ResponseMessageParser;
/*     */ import com.asiainfo.biframe.utils.webservice.WebServiceServerCallback;
/*     */ import com.asiainfo.biframe.utils.webservice.WebServiceTemplate;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ public class WsPrivilegeService
/*     */   implements IWsPrivilegeService
/*     */ {
/*  79 */   private static Logger log = Logger.getLogger(WsPrivilegeService.class);
/*     */   private IUserAdminService userAdminService;
/*  83 */   private WebServiceTemplate wsTemplate = new WebServiceTemplate();
/*     */ 
/*     */   public String QueryUserInfoSoap(String requestInfo) {
/*  86 */     log.debug(" in QueryUserInfoSoap");
/*     */ 
/*  88 */     Map xmlMap = parseXml(requestInfo);
/*  89 */     if (StringUtils.isNotBlank((String)xmlMap.get("ERROR"))) {
/*  90 */       return (String)xmlMap.get("ERROR");
/*     */     }
/*     */ 
/*  94 */     String userId = (String)xmlMap.get("USER_ID");
/*     */     try {
/*  96 */       User_User user = getUserAdminService().getUser(userId);
/*  97 */       if (user == null) {
/*  98 */         log.warn(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userInfoNotFound") + ":" + userId);
/*     */ 
/* 101 */         return genErrorMsg(userId, "", userId + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userInfoNotExist") + "");
/*     */       }
/*     */ 
/* 107 */       UserUserExt userExt = getUserAdminService().getUserExt(userId);
/* 108 */       if (userExt == null) {
/* 109 */         log.warn(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userInfoNotFound") + ":" + userId);
/*     */ 
/* 112 */         return genErrorMsg(userId, "", userId + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userInfoNotExist") + "");
/*     */       }
/*     */ 
/* 118 */       User_Group group = getUserAdminService().getGroupObject(userId);
/* 119 */       if (group == null) {
/* 120 */         log.warn(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userInfoNotFound") + ":" + userId);
/*     */ 
/* 123 */         return genErrorMsg(userId, "", userId + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userInfoNotExist") + "");
/*     */       }
/*     */ 
/* 129 */       String responseXml = populateResponseXml(user, userExt, group);
/*     */ 
/* 131 */       log.debug(" end QueryUserInfoSoap");
/* 132 */       return responseXml;
/*     */     } catch (Exception e) {
/* 134 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.QueryUserInfoSoapFail"), e);
/*     */ 
/* 136 */       return genErrorMsg(userId, "", LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryUserInfoFail") + ":" + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private String populateResponseXml(User_User user, UserUserExt userExt, User_Group group)
/*     */   {
/* 155 */     StringBuilder userInfo = new StringBuilder(512);
/* 156 */     userInfo.append("<BASE_INFO>");
/* 157 */     userInfo.append("\t<USER_ID>").append(user.getUserid()).append("</USER_ID>");
/*     */ 
/* 159 */     userInfo.append("\t<USER_NAME>").append(user.getUsername()).append("</USER_NAME>");
/*     */ 
/* 161 */     userInfo.append("\t<USER_PWD>").append(user.getPwd()).append("</USER_PWD>");
/*     */ 
/* 163 */     userInfo.append("\t<USER_STATUS>").append(user.getStatus()).append("</USER_STATUS>");
/*     */ 
/* 165 */     userInfo.append("\t<CITY_ID>").append(user.getCityid()).append("</CITY_ID>");
/*     */ 
/* 167 */     userInfo.append("\t<DEPARTMENT_ID>").append(user.getDepartmentid()).append("</DEPARTMENT_ID>");
/*     */ 
/* 169 */     userInfo.append("\t<DUTY_ID>").append(user.getDutyid()).append("</DUTY_ID>");
/*     */ 
/* 171 */     userInfo.append("\t<CREATE_TIME>").append(user.getCreatetime()).append("</CREATE_TIME>");
/*     */ 
/* 173 */     userInfo.append("\t<MOBILE_PHONE>").append(user.getMobilephone()).append("</MOBILE_PHONE>");
/*     */ 
/* 175 */     userInfo.append("\t<HOME_PHONE>").append(user.getHomephone()).append("</HOME_PHONE>");
/*     */ 
/* 177 */     userInfo.append("\t<OFFICE_PHONE>").append(user.getOfficephone()).append("</OFFICE_PHONE>");
/*     */ 
/* 179 */     userInfo.append("\t<OFFICE_FEX>").append(user.getOfficefax()).append("</OFFICE_FEX>");
/*     */ 
/* 181 */     userInfo.append("\t<EMAIL>").append(user.getEmail()).append("</EMAIL>");
/* 182 */     userInfo.append("\t<NOTES>").append(user.getNotes()).append("</NOTES>");
/* 183 */     userInfo.append("\t<SEX>").append(user.getSex()).append("</SEX>");
/* 184 */     userInfo.append("\t<AGE>").append(user.getAge()).append("</AGE>");
/* 185 */     userInfo.append("\t<ADDRESS>").append(user.getAddress()).append("</ADDRESS>");
/*     */ 
/* 187 */     userInfo.append("\t<POSTAL_CODE>").append(user.getPostalcode()).append("</POSTAL_CODE>");
/*     */ 
/* 189 */     userInfo.append("\t<NATION>").append(user.getNation()).append("</NATION>");
/*     */ 
/* 191 */     userInfo.append("\t<PASSPORT_NO>").append(user.getPassportNo()).append("</PASSPORT_NO>");
/*     */ 
/* 193 */     userInfo.append("\t<DIRECTOR>").append(user.getDirector()).append("</DIRECTOR>");
/*     */ 
/* 195 */     userInfo.append("\t<GROUP_ID>").append(group.getGroupid()).append("</GROUP_ID>");
/*     */ 
/* 197 */     userInfo.append("</BASE_INFO>");
/* 198 */     userInfo.append("<EXTEND_INFO>");
/* 199 */     userInfo.append("\t<PARAM0>").append(userExt.getParam0()).append("</PARAM0>");
/*     */ 
/* 201 */     userInfo.append("\t<PARAM1>").append(userExt.getParam0()).append("</PARAM1>");
/*     */ 
/* 203 */     userInfo.append("\t<PARAM2>").append(userExt.getParam0()).append("</PARAM2>");
/*     */ 
/* 205 */     userInfo.append("\t<PARAM3>").append(userExt.getParam0()).append("</PARAM3>");
/*     */ 
/* 207 */     userInfo.append("\t<PARAM4>").append(userExt.getParam0()).append("</PARAM4>");
/*     */ 
/* 209 */     userInfo.append("\t<PARAM5>").append(userExt.getParam0()).append("</PARAM5>");
/*     */ 
/* 211 */     userInfo.append("\t<PARAM6>").append(userExt.getParam0()).append("</PARAM6>");
/*     */ 
/* 213 */     userInfo.append("\t<PARAM7>").append(userExt.getParam0()).append("</PARAM7>");
/*     */ 
/* 215 */     userInfo.append("\t<LOGIN_NUM>").append(userExt.getLoginNum()).append("</LOGIN_NUM>");
/*     */ 
/* 217 */     userInfo.append("\t<KPI_NUM>").append(userExt.getKpiNum()).append("</KPI_NUM>");
/*     */ 
/* 219 */     userInfo.append("\t<KPI_NAME>").append(userExt.getKpiName()).append("</KPI_NAME>");
/*     */ 
/* 221 */     userInfo.append("\t<SMS_KPI_NAME>").append(userExt.getSmsKpiName()).append("</SMS_KPI_NAME>");
/*     */ 
/* 223 */     userInfo.append("</EXTEND_INFO>");
/*     */ 
/* 225 */     StringBuilder returnXml = new StringBuilder(512);
/* 226 */     returnXml.append("<?xml version='1.0' encoding='UTF-8'?>");
/* 227 */     returnXml.append("<QueryUserInfoSoap>");
/* 228 */     returnXml.append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>queryUserId</SERVICEID></HEAD>");
/*     */ 
/* 230 */     returnXml.append("<BODY>");
/* 231 */     returnXml.append(userInfo);
/* 232 */     returnXml.append("</BODY>");
/* 233 */     returnXml.append("</QueryUserInfoSoap>");
/*     */ 
/* 235 */     log.debug("--userInfoXml:" + returnXml);
/* 236 */     return returnXml.toString();
/*     */   }
/*     */ 
/*     */   private Map<String, String> parseXml(String requestInfo)
/*     */   {
/* 246 */     Map resultMap = new HashMap();
/*     */     try
/*     */     {
/* 249 */       SAXBuilder builder = new SAXBuilder(false);
/* 250 */       ByteArrayInputStream is = new ByteArrayInputStream(requestInfo.getBytes());
/*     */ 
/* 253 */       Document doc = builder.build(is);
/* 254 */       Element body = doc.getRootElement();
/*     */ 
/* 256 */       List body_list = body.getChildren("BODY");
/* 257 */       Element e2 = (Element)body_list.get(0);
/* 258 */       String userId = e2.getChildText("USER_ID");
/*     */ 
/* 260 */       resultMap.put("USER_ID", userId);
/*     */     }
/*     */     catch (Exception e) {
/* 263 */       e.printStackTrace();
/* 264 */       String errorInfo = genErrorMsg("", "", "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + "" + e.getMessage());
/*     */ 
/* 268 */       resultMap.put("ERROR", errorInfo);
/*     */     }
/* 270 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private String genErrorMsg(String key, String errCode, String errDesc) {
/* 274 */     if (StringUtils.isBlank(key)) {
/* 275 */       key = "ERROR";
/*     */     }
/* 277 */     if (StringUtils.isBlank(errCode)) {
/* 278 */       errCode = "errorcode";
/*     */     }
/* 280 */     if (StringUtils.isBlank(errDesc)) {
/* 281 */       errDesc = "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.executeError") + "";
/*     */     }
/*     */ 
/* 286 */     StringBuffer errorInfo = new StringBuffer().append("<?xml version='1.0' encoding='UTF-8'?>").append("<QueryUserInfoSoap>").append("<HEAD><CODE>1</CODE><SID>1</SID><TIMESTAMP>1</TIMESTAMP><SERVICEID>mapUserId</SERVICEID></HEAD>").append("<BODY><KEY>" + key + "</KEY>").append("<ERRCODE>" + errCode + "</ERRCODE>").append("<ERRDES>" + errDesc + "</ERRDES>").append("</BODY></QueryUserInfoSoap>");
/*     */ 
/* 295 */     return errorInfo.toString();
/*     */   }
/*     */ 
/*     */   public IUserAdminService getUserAdminService() {
/* 299 */     return this.userAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserAdminService(IUserAdminService userAdminService) {
/* 303 */     this.userAdminService = userAdminService;
/*     */   }
/*     */ 
/*     */   public boolean isUserLegal(String userName, String password) {
/* 307 */     return this.userAdminService.isUserLegal(userName, password);
/*     */   }
/*     */ 
/*     */   public String getUserExt(String userid) {
/* 311 */     UserUserExt userExt = getUserAdminService().getUserExt(userid);
/* 312 */     if (userExt != null) return userExt.getParam8();
/* 313 */     return "";
/*     */   }
/*     */ 
/*     */   public boolean haveRightByUserId(String userid, int roleType, int resourceType, String resourceId)
/*     */   {
/* 318 */     return getUserAdminService().haveRight(userid, roleType, resourceType, resourceId);
/*     */   }
/*     */ 
/*     */   public String isUserHasDataLevel(String xmlRequest)
/*     */   {
/* 323 */     WebServiceServerCallback callback = new WebServiceServerCallback()
/*     */     {
/*     */       public Class<RequestContent>[] getRequestContentType() {
/* 326 */         Class[] aa = { Parameters.class };
/* 327 */         return (Class[])aa;
/*     */       }
/*     */ 
/*     */       public ResponseContent[] process(ReqData reqData) throws Exception
/*     */       {
/* 332 */         List rcl = reqData.getRequestContent();
/* 333 */         Parameters prams = null;
/* 334 */         Results results = null;
/* 335 */         Result result = new Result();
/* 336 */         String dataLevel = "";
/* 337 */         if ((rcl != null) && (rcl.size() > 0)) {
/* 338 */           User_User user = null;
/* 339 */           prams = (Parameters)rcl.get(0);
/* 340 */           List pl = prams.getParameter();
/* 341 */           if ((pl != null) && (pl.size() == 3)) {
/* 342 */             String userId = ((Parameter)pl.get(0)).getValue();
/* 343 */             String tableName = ((Parameter)pl.get(1)).getValue();
/* 344 */             String columnName = ((Parameter)pl.get(2)).getValue();
/* 345 */             WsPrivilegeService.log.debug("userId = " + userId);
/* 346 */             WsPrivilegeService.log.debug("tableName = " + tableName);
/* 347 */             WsPrivilegeService.log.debug("columnName = " + columnName);
/* 348 */             user = (User_User)UserCache.getInstance().getObjectByKey(userId);
/*     */ 
/* 350 */             if (user == null)
/* 351 */               throw new JAXBException("Can not find user : " + userId + " !");
/* 352 */             if (StringUtil.isEmpty(tableName))
/* 353 */               throw new JAXBException("Table name can not be empty!");
/* 354 */             if (StringUtil.isEmpty(columnName))
/* 355 */               throw new JAXBException("Column name can not be empty !");
/*     */           }
/*     */           else
/*     */           {
/* 359 */             throw new JAXBException("Number of Parameters is not enough!");
/*     */           }
/* 361 */           pl.remove(0);
/* 362 */           ((Parameter)pl.get(0)).setName("T_Name");
/* 363 */           ((Parameter)pl.get(1)).setName("C_Name");
/*     */ 
/* 366 */           Parameters dataLevelParameters = new Parameters();
/* 367 */           dataLevelParameters.setParameter(pl);
/* 368 */           RequestContent[] dataLevelRequestContent = { dataLevelParameters };
/* 369 */           RequestMessageBuilder rmb = new RequestMessageBuilder(dataLevelRequestContent);
/*     */ 
/* 371 */           String dataLevelResult = WSDynamicClient.invokeWSByURL(Configure.getInstance().getProperty("AIBI_PRIVILEGE_PROPERTIES", "SENSITIVE_DATA_LEVEL_URL"), "getSensitiveDataLevel", rmb.createRequestMessage());
/*     */ 
/* 375 */           ResponseMessageParser dataLevelResultPaser = new ResponseMessageParser();
/* 376 */           ResponseMessage responseMessage = dataLevelResultPaser.parseResponseMessage(dataLevelResult);
/* 377 */           if (responseMessage.getHeaderResp().getRespResult() == 0) {
/* 378 */             RespData respData = dataLevelResultPaser.parseResponseData(dataLevelResult, new Class[] { SensitiveData.class });
/* 379 */             SensitiveData sd = (SensitiveData)respData.getResponseContent().get(0);
/* 380 */             if (null != sd)
/* 381 */               dataLevel = sd.getDataLevel();
/*     */           }
/*     */           else {
/* 384 */             throw new JAXBException(responseMessage.getRespDesc());
/*     */           }
/*     */ 
/* 388 */           results = new Results();
/* 389 */           if (user.getSensitiveDataLevel().equals(dataLevel))
/* 390 */             result.setValue("true");
/*     */           else {
/* 392 */             result.setValue("false");
/*     */           }
/* 394 */           List resultList = new ArrayList();
/* 395 */           resultList.add(result);
/* 396 */           results.setResult(resultList);
/*     */         }
/*     */ 
/* 399 */         ResponseContent[] ret = { results };
/* 400 */         return ret;
/*     */       }
/*     */     };
/* 404 */     return this.wsTemplate.execute(xmlRequest, callback);
/*     */   }
/*     */ 
/*     */   public String isUserPrivateDataLevel(String xmlRequest) {
/* 408 */     WebServiceServerCallback callback = new WebServiceServerCallback()
/*     */     {
/*     */       public Class<RequestContent>[] getRequestContentType() {
/* 411 */         Class[] aa = { Parameters.class };
/* 412 */         return (Class[])aa;
/*     */       }
/*     */ 
/*     */       public ResponseContent[] process(ReqData reqData) throws Exception {
/* 416 */         List rcl = reqData.getRequestContent();
/* 417 */         Parameters prams = null;
/* 418 */         Results results = null;
/*     */         List rightList;
/* 419 */         if ((rcl != null) && (rcl.size() > 0)) {
/* 420 */           User_User user = null;
/* 421 */           prams = (Parameters)rcl.get(0);
/* 422 */           List pl = prams.getParameter();
/* 423 */           if ((pl != null) && (pl.size() == 3)) {
/* 424 */             String userId = ((Parameter)pl.get(0)).getValue();
/* 425 */             String roleType = ((Parameter)pl.get(1)).getValue();
/* 426 */             String resourceType = ((Parameter)pl.get(2)).getValue();
/* 427 */             WsPrivilegeService.log.debug("userId = " + userId);
/* 428 */             WsPrivilegeService.log.debug("roleType = " + roleType);
/* 429 */             WsPrivilegeService.log.debug("resourceType = " + resourceType);
/*     */ 
/* 431 */             if ((StringUtil.isNotEmpty(roleType)) && (StringUtil.isNotEmpty(resourceType)))
/*     */             {
/* 433 */               rightList = WsPrivilegeService.this.userAdminService.getRight(userId, Integer.parseInt(roleType), Integer.parseInt(resourceType), false);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 441 */         ResponseContent[] ret = { results };
/* 442 */         return ret;
/*     */       }
/*     */     };
/* 446 */     return this.wsTemplate.execute(xmlRequest, callback);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.service.impl.WsPrivilegeService
 * JD-Core Version:    0.6.2
 */
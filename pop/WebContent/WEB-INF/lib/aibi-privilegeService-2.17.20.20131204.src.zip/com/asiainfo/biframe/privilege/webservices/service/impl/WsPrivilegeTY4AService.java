/*     */ package com.asiainfo.biframe.privilege.webservices.service.impl;
/*     */ 
/*     */ import com.asiainfo.biframe.log.LogInfo;
/*     */ import com.asiainfo.biframe.privilege.IUserGroup;
/*     */ import com.asiainfo.biframe.privilege.IUserPrivilegeCUDService;
/*     */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*     */ import com.asiainfo.biframe.privilege.base.constants.PrivilegeCodes;
/*     */ import com.asiainfo.biframe.privilege.base.constants.UserManager;
/*     */ import com.asiainfo.biframe.privilege.base.util.LogDetailUtil;
/*     */ import com.asiainfo.biframe.privilege.cache.object.CacheUtils;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserCityCache;
/*     */ import com.asiainfo.biframe.privilege.cache.object.UserDutyCache;
/*     */ import com.asiainfo.biframe.privilege.model.User_User;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserAdminService;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.IUserGroupAdminService;
/*     */ import com.asiainfo.biframe.privilege.webservices.service.IWsPrivilegeTY4AService;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import com.asiainfo.biframe.utils.db.PkeyUtil;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.ws.Dispatch;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.Service.Mode;
/*     */ import org.apache.commons.lang.xwork.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class WsPrivilegeTY4AService
/*     */   implements IWsPrivilegeTY4AService
/*     */ {
/*  83 */   private static Logger log = Logger.getLogger(WsPrivilegeTY4AService.class);
/*     */   private IUserAdminService userAdminService;
/*     */   private IUserPrivilegeService userPrvilegeService;
/*     */   private IUserGroupAdminService userGroupAdminService;
/*     */   private IUserPrivilegeCUDService userPrivilegeCUDService;
/*     */ 
/*     */   public IUserGroupAdminService getUserGroupAdminService()
/*     */   {
/* 102 */     return this.userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserGroupAdminService(IUserGroupAdminService userGroupAdminService)
/*     */   {
/* 108 */     this.userGroupAdminService = userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public IUserAdminService getUserAdminService()
/*     */   {
/* 123 */     return this.userAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserAdminService(IUserAdminService userAdminService)
/*     */   {
/* 133 */     this.userAdminService = userAdminService;
/*     */   }
/*     */ 
/*     */   public IUserPrivilegeCUDService getUserPrivilegeCUDService()
/*     */   {
/* 141 */     return this.userPrivilegeCUDService;
/*     */   }
/*     */ 
/*     */   public void setUserPrivilegeCUDService(IUserPrivilegeCUDService userPrivilegeCUDService)
/*     */   {
/* 150 */     this.userPrivilegeCUDService = userPrivilegeCUDService;
/*     */   }
/*     */ 
/*     */   public IUserPrivilegeService getUserPrvilegeService()
/*     */   {
/* 159 */     return this.userPrvilegeService;
/*     */   }
/*     */ 
/*     */   public void setUserPrvilegeService(IUserPrivilegeService userPrvilegeService)
/*     */   {
/* 168 */     this.userPrvilegeService = userPrvilegeService;
/*     */   }
/*     */ 
/*     */   public void initLogInfo(String operatorID, String clientIp, String operatorName)
/*     */   {
/* 181 */     LogInfo info = new LogInfo();
/* 182 */     LogInfo.setSessionID(PkeyUtil.generateHexUUID());
/* 183 */     LogInfo.setClientAddress(clientIp);
/* 184 */     LogInfo.setHostAddress(UserManager.getHostAddress());
/* 185 */     LogInfo.setOperatorID(operatorID);
/* 186 */     LogInfo.setOperatorName(operatorName);
/* 187 */     info.setResourceType(LogDetailUtil.getLogDefineValue(2, "LOGTYPE_LOGONFAILURE"));
/*     */ 
/* 189 */     info.setOperaterType(LogDetailUtil.getLogDefineValue(1, "LOG_OPERATION_LOGON"));
/*     */   }
/*     */ 
/*     */   public void refreshUserCacheByKey(String userId)
/*     */   {
/* 199 */     CacheUtils.refreshUserCacheByKey(userId);
/*     */   }
/*     */ 
/*     */   public void refreshCaches()
/*     */   {
/* 206 */     CacheUtils.refreshGroupCache();
/* 207 */     CacheUtils.refreshUserCache();
/* 208 */     CacheUtils.refreshRoleCache();
/*     */   }
/*     */ 
/*     */   public String addUserInfo(String userInfos)
/*     */   {
/* 216 */     log.debug(" in addUserInfo userInfos=" + userInfos);
/* 217 */     StringBuffer resultString = new StringBuffer("");
/*     */ 
/* 220 */     boolean sucessOrNot = true;
/* 221 */     SAXBuilder builder = new SAXBuilder(false);
/* 222 */     StringReader in = new StringReader(userInfos);
/* 223 */     Element root = null;
/*     */     try {
/* 225 */       org.jdom.Document doc = builder.build(in);
/* 226 */       root = doc.getRootElement();
/*     */     } catch (Exception e) {
/* 228 */       sucessOrNot = !sucessOrNot;
/* 229 */       throw new RuntimeException("xml解析时出错！" + e.getMessage(), e);
/*     */     } finally {
/* 231 */       in.close();
/*     */     }
/*     */ 
/* 235 */     if (sucessOrNot)
/*     */     {
/* 237 */       List sucessList = new ArrayList();
/* 238 */       Object failList = new ArrayList();
/*     */ 
/* 240 */       List userElementList = root.getChildren("account");
/* 241 */       for (Element element : userElementList) {
/* 242 */         String userID = element.getChild("accId").getText();
/* 243 */         User_User userTest = this.userAdminService.getUser(userID);
/*     */ 
/* 245 */         String errMsg = "";
/*     */ 
/* 247 */         if (null != userTest) {
/* 248 */           errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userAlreadyExist");
/*     */ 
/* 250 */           log.debug(errMsg);
/* 251 */           ((List)failList).add(userID);
/*     */         }
/*     */         else
/*     */         {
/* 255 */           errMsg = validateUpdateAppAcctSoap(element);
/* 256 */           if (StringUtils.isNotBlank(errMsg)) {
/* 257 */             log.debug(errMsg);
/* 258 */             ((List)failList).add(userID);
/*     */           }
/*     */           else
/*     */           {
/* 262 */             IUserGroup ug = getUserPrvilegeService().getUserGroupById(element.getChildText("workOrg"));
/* 263 */             if (null == ug) {
/* 264 */               errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupNotExistFail");
/*     */ 
/* 266 */               log.debug(errMsg);
/* 267 */               ((List)failList).add(userID);
/*     */             }
/*     */             else
/*     */             {
/* 284 */               User_User user = new User_User();
/* 285 */               user.setUserid(userID);
/* 286 */               user.setUsername(element.getChildText("name"));
/* 287 */               user.setGroupId(element.getChildText("workOrg"));
/* 288 */               user.setCityid(element.getChildText("L"));
/* 289 */               user.setDutyid(Integer.valueOf(Integer.parseInt(element.getChildText("levelName"))));
/* 290 */               user.setDepartmentid(Integer.parseInt(element.getChildText("supporterDept")));
/* 291 */               user.setMobilephone(element.getChildText("mobile"));
/* 292 */               user.setDomainType(element.getChildText("domainType"));
/* 293 */               user.setEmail(element.getChildText("email"));
/* 294 */               user.setEmail(element.getChildText("status"));
/* 295 */               String effectdate = element.getChildText("startTime");
/* 296 */               if (StringUtils.isNotBlank(effectdate)) {
/* 297 */                 user.setBegindate(DateUtil.string2Date(effectdate, "yyyyMMddHHmmssZ"));
/*     */               }
/* 299 */               String expiredate = element.getChildText("endTime");
/* 300 */               if (StringUtils.isNotBlank(expiredate)) {
/* 301 */                 user.setEnddate(DateUtil.string2Date(expiredate, "yyyyMMddHHmmssZ"));
/*     */               }
/* 303 */               user.setNotes(element.getChildText("description"));
/* 304 */               String password = element.getChildText("userPassword");
/*     */ 
/* 306 */               user.setDesPwd(password);
/* 307 */               String[] groupList = { element.getChildText("workOrg") };
/*     */ 
/* 309 */               initLogInfo(userID, "127.0.0.1", element.getChildText("name"));
/* 310 */               getUserAdminService().addUser(user, groupList, "" + user.getDepartmentid(), "0");
/*     */ 
/* 312 */               refreshUserCacheByKey(userID);
/* 313 */               sucessList.add(userID);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 318 */       resultString.append("<?xml version='1.0' encoding='UTF-8'>").append("<delresults>").append("<result returncode='1300'>");
/*     */ 
/* 321 */       for (String accId : sucessList)
/* 322 */         resultString.append("<accId>").append(accId).append("</accId>");
/* 323 */       resultString.append("</result>").append("<result returncode='1301'>");
/*     */ 
/* 325 */       for (String accId : (List)failList)
/* 326 */         resultString.append("<accId>").append(accId).append("</accId>");
/* 327 */       resultString.append("</result>").append("</delresults>");
/*     */     }
/*     */ 
/* 335 */     return resultString.toString();
/*     */   }
/*     */ 
/*     */   public String delUser(String userIDs)
/*     */   {
/* 342 */     log.debug(" in delUser userIDs=" + userIDs);
/* 343 */     StringBuffer resultString = new StringBuffer("");
/*     */ 
/* 346 */     boolean sucessOrNot = true;
/* 347 */     SAXBuilder builder = new SAXBuilder(false);
/* 348 */     StringReader in = new StringReader(userIDs);
/* 349 */     Element root = null;
/*     */     try {
/* 351 */       org.jdom.Document doc = builder.build(in);
/* 352 */       root = doc.getRootElement();
/*     */     } catch (Exception e) {
/* 354 */       sucessOrNot = !sucessOrNot;
/* 355 */       throw new RuntimeException("xml解析时出错！" + e.getMessage(), e);
/*     */     } finally {
/* 357 */       in.close();
/*     */     }
/*     */ 
/* 361 */     if (sucessOrNot)
/*     */     {
/* 363 */       Element userElements = root.getChild("account");
/* 364 */       Object sucessList = new ArrayList();
/* 365 */       List failList = new ArrayList();
/*     */ 
/* 367 */       List userElementList = userElements.getChildren("accId");
/* 368 */       for (Element element : userElementList) {
/* 369 */         String userId = element.getText();
/*     */         try {
/* 371 */           initLogInfo(userId, "127.0.0.1", userId);
/* 372 */           getUserPrivilegeCUDService().deleteUser(userId);
/* 373 */           getUserPrivilegeCUDService().realDeleteUser(userId);
/* 374 */           ((List)sucessList).add(userId);
/*     */         } catch (Exception e) {
/* 376 */           log.debug(e);
/* 377 */           failList.add(userId);
/*     */         }
/*     */       }
/* 380 */       refreshCaches();
/*     */ 
/* 384 */       resultString.append("<?xml version='1.0' encoding='UTF-8'>").append("<delresults>").append("<result returncode='1304'>");
/*     */ 
/* 387 */       for (String accId : (List)sucessList)
/* 388 */         resultString.append("<accId>").append(accId).append("</accId>");
/* 389 */       resultString.append("</result>").append("<result returncode='1305'>");
/*     */ 
/* 391 */       for (String accId : failList)
/* 392 */         resultString.append("<accId>").append(accId).append("</accId>");
/* 393 */       resultString.append("</result>").append("</delresults>");
/*     */     }
/*     */ 
/* 400 */     return resultString.toString();
/*     */   }
/*     */ 
/*     */   public String findUser(String userID)
/*     */   {
/* 407 */     StringBuffer resultString = new StringBuffer("<?xml version='1.0' encoding='UTF-8'>");
/* 408 */     resultString.append("<accounts>");
/* 409 */     if (StringUtil.isNotEmpty(userID)) {
/* 410 */       User_User user = this.userAdminService.getUser(userID);
/* 411 */       if (user != null) {
/* 412 */         resultString.append("<account>").append("<accId>" + user.getUserid() + "</accId>").append("<name>" + user.getUsername() + "</name>").append("<workOrg>" + user.getGroupId() + " </workOrg>").append("<L>" + UserCityCache.getInstance().getNameByKey(user.getCityid()) + "</L>").append("<levelName>" + UserDutyCache.getInstance().getNameByKey(user.getDutyid()) + "</levelName>").append("<supporterDept>" + user.getDepartmentid() + "</supporterDept>").append("<mobile>" + user.getMobilePhone() + "</mobile>").append("<status>" + user.getStatus() + "</status>").append("<email>" + user.getEmail() + " </email>").append("<startTime>" + user.getCreatetime() + "</startTime>").append("<endTime>" + user.getEnddate() + "</endTime>").append("<description>" + user.getNotes() + "</description>").append("</account>");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 428 */     resultString.append("</accounts>");
/* 429 */     return resultString.toString();
/*     */   }
/*     */ 
/*     */   public String getUserAmount()
/*     */   {
/* 436 */     String resultString = new String("-1");
/* 437 */     long userAmount = getUserPrvilegeService().getUserAmount();
/* 438 */     if (userAmount > 0L)
/* 439 */       resultString = String.valueOf(userAmount);
/* 440 */     return resultString.toString();
/*     */   }
/*     */ 
/*     */   public String modifyUserInfo(String userInfos)
/*     */   {
/* 447 */     log.debug(" in modifyUserInfo userInfos=" + userInfos);
/* 448 */     StringBuffer resultString = new StringBuffer("");
/*     */ 
/* 451 */     boolean sucessOrNot = true;
/* 452 */     SAXBuilder builder = new SAXBuilder(false);
/* 453 */     StringReader in = new StringReader(userInfos);
/* 454 */     Element root = null;
/*     */     try {
/* 456 */       org.jdom.Document doc = builder.build(in);
/* 457 */       root = doc.getRootElement();
/*     */     } catch (Exception e) {
/* 459 */       sucessOrNot = !sucessOrNot;
/* 460 */       throw new RuntimeException("xml解析时出错！" + e.getMessage(), e);
/*     */     } finally {
/* 462 */       in.close();
/*     */     }
/*     */ 
/* 466 */     if (sucessOrNot)
/*     */     {
/* 469 */       List sucessList = new ArrayList();
/* 470 */       Object failList = new ArrayList();
/*     */ 
/* 472 */       List userElementList = root.getChildren("account");
/* 473 */       for (Element element : userElementList) {
/* 474 */         String userID = element.getChild("accId").getText();
/* 475 */         User_User userTest = this.userAdminService.getUser(userID);
/*     */ 
/* 477 */         String errMsg = "";
/*     */ 
/* 479 */         if (null == userTest) {
/* 480 */           errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userAlreadyExist");
/*     */ 
/* 482 */           log.debug(errMsg);
/* 483 */           ((List)failList).add(userID);
/*     */         }
/*     */         else
/*     */         {
/* 487 */           errMsg = validateUpdateAppAcctSoap(element);
/* 488 */           if (StringUtils.isNotBlank(errMsg)) {
/* 489 */             log.debug(errMsg);
/* 490 */             ((List)failList).add(userID);
/*     */           }
/*     */           else
/*     */           {
/* 494 */             IUserGroup ug = getUserPrvilegeService().getUserGroupById(element.getChildText("workOrg"));
/* 495 */             if (null == ug) {
/* 496 */               errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.groupNotExistFail");
/*     */ 
/* 498 */               log.debug(errMsg);
/* 499 */               ((List)failList).add(userID);
/*     */             }
/*     */             else
/*     */             {
/* 516 */               User_User user = userTest;
/* 517 */               user.setUserid(userID);
/* 518 */               user.setUsername(element.getChildText("name"));
/* 519 */               user.setGroupId(element.getChildText("workOrg"));
/* 520 */               user.setCityid(element.getChildText("L"));
/* 521 */               user.setDutyid(Integer.valueOf(Integer.parseInt(element.getChildText("levelName"))));
/* 522 */               user.setDepartmentid(Integer.parseInt(element.getChildText("supporterDept")));
/* 523 */               user.setMobilephone(element.getChildText("mobile"));
/* 524 */               user.setDomainType(element.getChildText("domainType"));
/* 525 */               user.setEmail(element.getChildText("email"));
/* 526 */               user.setEmail(element.getChildText("status"));
/* 527 */               String effectdate = element.getChildText("startTime");
/* 528 */               if (StringUtils.isNotBlank(effectdate)) {
/* 529 */                 user.setBegindate(DateUtil.string2Date(effectdate, "yyyyMMddHHmmssZ"));
/*     */               }
/* 531 */               String expiredate = element.getChildText("endTime");
/* 532 */               if (StringUtils.isNotBlank(expiredate)) {
/* 533 */                 user.setEnddate(DateUtil.string2Date(expiredate, "yyyyMMddHHmmssZ"));
/*     */               }
/* 535 */               user.setNotes(element.getChildText("description"));
/* 536 */               String password = element.getChildText("userPassword");
/*     */ 
/* 538 */               user.setDesPwd(password);
/* 539 */               String[] groupList = { element.getChildText("workOrg") };
/*     */ 
/* 541 */               initLogInfo(userID, "127.0.0.1", element.getChildText("name"));
/* 542 */               getUserAdminService().updateUser(user, groupList, "" + user.getDepartmentid(), "0");
/*     */ 
/* 544 */               refreshUserCacheByKey(userID);
/* 545 */               sucessList.add(userID);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 550 */       resultString.append("<?xml version='1.0' encoding='UTF-8'>").append("<delresults>").append("<result returncode='1300'>");
/*     */ 
/* 553 */       for (String accId : sucessList)
/* 554 */         resultString.append("<accId>").append(accId).append("</accId>");
/* 555 */       resultString.append("</result>").append("<result returncode='1301'>");
/*     */ 
/* 557 */       for (String accId : (List)failList)
/* 558 */         resultString.append("<accId>").append(accId).append("</accId>");
/* 559 */       resultString.append("</result>").append("</delresults>");
/*     */     }
/*     */ 
/* 567 */     return resultString.toString();
/*     */   }
/*     */ 
/*     */   public String qryAccById(String accId)
/*     */   {
/* 577 */     QName serviceName = new QName("CommonWebServiceService");
/* 578 */     QName portName = new QName("UpdateAppOrgServices");
/* 579 */     String endpointAddress = PrivilegeCodes.getWsUrl4A() + "UpdateAppOrgServices";
/*     */ 
/* 581 */     Service service = Service.create(serviceName);
/* 582 */     service.addPort(portName, "http://schemas.xmlsoap.org/wsdl/soap/http", endpointAddress);
/* 583 */     Dispatch dispatcher = service.createDispatch(portName, Source.class, Service.Mode.PAYLOAD);
/*     */ 
/* 585 */     Map requestContext = dispatcher.getRequestContext();
/* 586 */     StringBuffer reqBuffer = new StringBuffer();
/* 587 */     reqBuffer.append("<UpdateAppOrgServices>");
/* 588 */     reqBuffer.append(accId);
/* 589 */     reqBuffer.append("</UpdateAppOrgServices>");
/* 590 */     org.w3c.dom.Document doc = null;
/*     */     try {
/* 592 */       StringReader sr = new StringReader(reqBuffer.toString());
/* 593 */       InputSource is = new InputSource(sr);
/* 594 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 595 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 596 */       doc = builder.parse(is);
/*     */ 
/* 598 */       DOMSource reqMsg = new DOMSource(doc);
/* 599 */       requestContext.put("javax.xml.ws.soap.http.soapaction.use", Boolean.TRUE);
/* 600 */       requestContext.put("javax.xml.ws.soap.http.soapaction.uri", "");
/* 601 */       requestContext.put("javax.xml.ws.http.request.method", "POST");
/* 602 */       result = (Source)dispatcher.invoke(reqMsg);
/*     */     }
/*     */     catch (ParserConfigurationException e)
/*     */     {
/*     */       Source result;
/* 604 */       log.debug(e);
/*     */     } catch (SAXException e) {
/* 606 */       log.debug(e);
/*     */     } catch (IOException e) {
/* 608 */       log.debug(e);
/*     */     } catch (Exception e) {
/* 610 */       log.debug(e);
/*     */     }
/*     */ 
/* 613 */     return null;
/*     */   }
/*     */ 
/*     */   public String queryOrgs()
/*     */   {
/* 620 */     StringBuffer resultString = new StringBuffer("<?xml version='1.0' encoding='UTF-8'>");
/* 621 */     resultString.append("<orgs>");
/* 622 */     List groupList = getUserPrvilegeService().getAllUserGroup();
/* 623 */     for (IUserGroup group : groupList) {
/* 624 */       resultString.append("<org>").append("<orgId>").append(group.getGroupid()).append("</orgId>").append("<name>").append(group.getGroupname()).append("</name>").append("<parentOrgId>").append(group.getParentid()).append("</parentOrgId>").append("<initials></initials>").append("</org>");
/*     */     }
/*     */ 
/* 637 */     resultString.append("</orgs>");
/* 638 */     return resultString.toString();
/*     */   }
/*     */ 
/*     */   public String queryUsers()
/*     */   {
/* 645 */     StringBuffer resultString = new StringBuffer("<?xml version='1.0' encoding='UTF-8'>");
/* 646 */     resultString.append("<accounts>");
/* 647 */     Collection userCollection = UserCache.getInstance().getAllCachedObject();
/* 648 */     User_User user = null;
/* 649 */     for (Iterator i$ = userCollection.iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 650 */       user = (User_User)o;
/* 651 */       resultString.append("<account>").append("<accId>" + user.getUserid() + "</accId>").append("<name>" + user.getUsername() + "</name>").append("<workOrg>" + user.getGroupId() + " </workOrg>").append("<L>" + UserCityCache.getInstance().getNameByKey(user.getCityid()) + "</L>").append("<levelName>" + UserDutyCache.getInstance().getNameByKey(user.getDutyid()) + "</levelName>").append("<supporterDept>" + user.getDepartmentid() + "</supporterDept>").append("<mobile>" + user.getMobilePhone() + "</mobile>").append("<status>" + user.getStatus() + "</status>").append("<email>" + user.getEmail() + " </email>").append("<startTime>" + user.getCreatetime() + "</startTime>").append("<endTime>" + user.getEnddate() + "</endTime>").append("<description>" + user.getNotes() + "</description>").append("</account>");
/*     */     }
/*     */ 
/* 666 */     resultString.append("</accounts>");
/* 667 */     return resultString.toString();
/*     */   }
/*     */ 
/*     */   public String queryUsersByPage(String pageSize, String pageNum)
/*     */   {
/* 675 */     SearchCondition condition = new SearchCondition();
/* 676 */     Map resultMap = getUserAdminService().getPagedUserList(condition, Integer.valueOf(pageNum), Integer.valueOf(pageSize));
/* 677 */     List resultList = (List)resultMap.get("result");
/*     */ 
/* 679 */     StringBuffer resultString = new StringBuffer("<?xml version='1.0' encoding='UTF-8'>");
/* 680 */     resultString.append("<accounts>");
/* 681 */     User_User user = null;
/* 682 */     for (Iterator i$ = resultList.iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 683 */       user = (User_User)o;
/* 684 */       resultString.append("<account>").append("<accId>" + user.getUserid() + "</accId>").append("<name>" + user.getUsername() + "</name>").append("<workOrg>" + user.getGroupId() + " </workOrg>").append("<L>" + UserCityCache.getInstance().getNameByKey(user.getCityid()) + "</L>").append("<levelName>" + UserDutyCache.getInstance().getNameByKey(user.getDutyid()) + "</levelName>").append("<supporterDept>" + user.getDepartmentid() + "</supporterDept>").append("<mobile>" + user.getMobilePhone() + "</mobile>").append("<status>" + user.getStatus() + "</status>").append("<email>" + user.getEmail() + " </email>").append("<startTime>" + user.getCreatetime() + "</startTime>").append("<endTime>" + user.getEnddate() + "</endTime>").append("<description>" + user.getNotes() + "</description>").append("</account>");
/*     */     }
/*     */ 
/* 699 */     resultString.append("</accounts>");
/* 700 */     return resultString.toString();
/*     */   }
/*     */ 
/*     */   public static final Map<String, String> parseSimpleBodyXml(String xml, String bodyTag)
/*     */     throws Exception
/*     */   {
/* 713 */     SAXBuilder builder = new SAXBuilder(false);
/* 714 */     ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
/*     */ 
/* 716 */     Map parseMap = new HashMap();
/*     */     try {
/* 718 */       org.jdom.Document doc = builder.build(is);
/* 719 */       Element root = doc.getRootElement();
/* 720 */       List bodyList = root.getChildren(bodyTag);
/* 721 */       Element body = (Element)bodyList.get(0);
/* 722 */       List elementList = body.getChildren();
/* 723 */       for (int i = 0; i < elementList.size(); i++) {
/* 724 */         getElement((Element)elementList.get(i), parseMap);
/*     */       }
/* 726 */       is.close();
/*     */     } catch (Exception e) {
/* 728 */       log.info(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + e.getMessage());
/*     */ 
/* 731 */       throw e;
/*     */     } finally {
/* 733 */       is.close();
/*     */     }
/*     */ 
/* 736 */     return parseMap;
/*     */   }
/*     */ 
/*     */   public static void getElement(Element element, Map<String, String> parseMap)
/*     */   {
/* 747 */     List elementList = element.getChildren();
/* 748 */     if (elementList.size() > 0) {
/* 749 */       for (int i = 0; i < elementList.size(); i++)
/* 750 */         getElement((Element)elementList.get(i), parseMap);
/*     */     }
/*     */     else
/* 753 */       parseMap.put(element.getName(), element.getText());
/*     */   }
/*     */ 
/*     */   public static Element getRootElement(String xml)
/*     */   {
/* 767 */     SAXBuilder builder = new SAXBuilder(false);
/* 768 */     StringReader in = new StringReader(xml);
/* 769 */     Element root = null;
/*     */     try {
/* 771 */       org.jdom.Document doc = builder.build(in);
/* 772 */       root = doc.getRootElement();
/*     */     } catch (Exception e) {
/* 774 */       throw new RuntimeException("xml解析时出错！" + e.getMessage(), e);
/*     */     } finally {
/* 776 */       in.close();
/*     */     }
/* 778 */     return root;
/*     */   }
/*     */ 
/*     */   public static String validateUpdateAppAcctSoap(Element element)
/*     */   {
/* 789 */     String errMsg = "";
/* 790 */     if (StringUtils.isBlank(element.getChildText("name"))) {
/* 791 */       errMsg = errMsg + "name,";
/*     */     }
/* 793 */     if (StringUtils.isBlank(element.getChildText("workOrg"))) {
/* 794 */       errMsg = errMsg + "workOrg,";
/*     */     }
/* 796 */     if (StringUtils.isBlank(element.getChildText("L"))) {
/* 797 */       errMsg = errMsg + "L,";
/*     */     }
/* 799 */     if (StringUtils.isBlank(element.getChildText("levelName"))) {
/* 800 */       errMsg = errMsg + "levelName,";
/*     */     }
/* 802 */     if (StringUtils.isBlank(element.getChildText("supporterDept"))) {
/* 803 */       errMsg = errMsg + "supporterDept,";
/*     */     }
/* 805 */     if (StringUtils.isBlank(element.getChildText("mobile"))) {
/* 806 */       errMsg = errMsg + "mobile,";
/*     */     }
/* 808 */     if (StringUtils.isNotBlank(errMsg)) {
/* 809 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userInfoNotComplete") + ":" + errMsg;
/*     */     }
/*     */ 
/* 813 */     return errMsg;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.service.impl.WsPrivilegeTY4AService
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.webservices.util;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.webservice.XmlMapAdapter;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlElementWrapper;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ 
/*     */ @XmlRootElement
/*     */ @XmlType(name="", propOrder={"name", "value", "mapValue", "listValue", "listMapValue"})
/*     */ public class Result
/*     */ {
/*     */   private String name;
/*     */   private String value;
/*     */   private Map<String, String> mapValue;
/*     */   private List<String> listValue;
/*     */   private List<Map<String, String>> listMapValue;
/*     */ 
/*     */   public Result()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Result(String name)
/*     */   {
/*  55 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  59 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  63 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getValue() {
/*  67 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(String value) {
/*  71 */     this.value = value;
/*     */   }
/*     */   @XmlElement(name="map")
/*     */   @XmlJavaTypeAdapter(XmlMapAdapter.class)
/*     */   public Map<String, String> getMapValue() {
/*  77 */     return this.mapValue;
/*     */   }
/*     */ 
/*     */   public void setMapValue(Map<String, String> mapValue) {
/*  81 */     this.mapValue = mapValue;
/*     */   }
/*     */   @XmlElementWrapper(name="list")
/*     */   @XmlElement(name="value")
/*     */   public List<String> getListValue() {
/*  87 */     return this.listValue;
/*     */   }
/*     */ 
/*     */   public void setListValue(List<String> listValue) {
/*  91 */     this.listValue = listValue;
/*     */   }
/*  98 */   @XmlElementWrapper(name="list")
/*     */   @XmlElement(name="map")
/*     */   @XmlJavaTypeAdapter(XmlMapAdapter.class)
/*     */   public List<Map<String, String>> getListMapValue() { return this.listMapValue; }
/*     */ 
/*     */   public void setListMapValue(List<Map<String, String>> listMapValue)
/*     */   {
/* 102 */     this.listMapValue = listMapValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.Result
 * JD-Core Version:    0.6.2
 */
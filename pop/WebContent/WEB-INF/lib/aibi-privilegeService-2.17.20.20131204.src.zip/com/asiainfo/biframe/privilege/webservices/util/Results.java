/*    */ package com.asiainfo.biframe.privilege.webservices.util;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.webservice.ResponseContent;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ public class Results
/*    */   implements ResponseContent
/*    */ {
/*    */   private List<Result> Result;
/*    */ 
/*    */   public List<Result> getResult()
/*    */   {
/* 38 */     return this.Result;
/*    */   }
/*    */ 
/*    */   public void setResult(List<Result> result)
/*    */   {
/* 43 */     this.Result = result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.Results
 * JD-Core Version:    0.6.2
 */
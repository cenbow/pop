/*    */ package com.asiainfo.biframe.privilege.webservices.util;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.webservice.RequestContent;
/*    */ import com.asiainfo.biframe.utils.webservice.ResponseContent;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ public class SensitiveData
/*    */   implements RequestContent, ResponseContent
/*    */ {
/*    */   private String dataLevel;
/*    */ 
/*    */   public String getDataLevel()
/*    */   {
/* 46 */     return this.dataLevel;
/*    */   }
/*    */ 
/*    */   public void setDataLevel(String dataLevel)
/*    */   {
/* 56 */     this.dataLevel = dataLevel;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.SensitiveData
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.webservices.util;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.base.constants.PrivilegeCodes;
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.StringReader;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ public class WsPrivilege4AUtil
/*     */ {
/*  52 */   private static Logger log = Logger.getLogger(WsPrivilege4AUtil.class);
/*     */ 
/*     */   public static final Map<String, String> parseSimpleBodyXml(String xml)
/*     */     throws Exception
/*     */   {
/*  64 */     SAXBuilder builder = new SAXBuilder(false);
/*  65 */     ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
/*     */ 
/*  67 */     Map parseMap = new HashMap();
/*     */     try {
/*  69 */       Document doc = builder.build(is);
/*  70 */       Element root = doc.getRootElement();
/*  71 */       List bodyList = root.getChildren("BODY");
/*  72 */       Element body = (Element)bodyList.get(0);
/*  73 */       List elementList = body.getChildren();
/*  74 */       for (int i = 0; i < elementList.size(); i++) {
/*  75 */         getElement((Element)elementList.get(i), parseMap);
/*     */       }
/*  77 */       is.close();
/*     */     } catch (Exception e) {
/*  79 */       log.info(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + e.getMessage());
/*     */ 
/*  82 */       throw e;
/*     */     } finally {
/*  84 */       is.close();
/*     */     }
/*     */ 
/*  87 */     return parseMap;
/*     */   }
/*     */ 
/*     */   public static void getElement(Element element, Map<String, String> parseMap)
/*     */   {
/*  98 */     List elementList = element.getChildren();
/*  99 */     if (elementList.size() > 0) {
/* 100 */       for (int i = 0; i < elementList.size(); i++)
/* 101 */         getElement((Element)elementList.get(i), parseMap);
/*     */     }
/*     */     else
/* 104 */       parseMap.put(element.getName(), element.getText());
/*     */   }
/*     */ 
/*     */   public static final String genRspHead(String reqXml)
/*     */     throws Exception
/*     */   {
/* 117 */     SAXBuilder builder = new SAXBuilder(false);
/* 118 */     ByteArrayInputStream is = new ByteArrayInputStream(reqXml.getBytes("UTF-8"));
/*     */ 
/* 120 */     StringBuffer rspHead = new StringBuffer();
/* 121 */     rspHead.append("<HEAD>");
/*     */     try {
/* 123 */       Document doc = builder.build(is);
/* 124 */       Element root = doc.getRootElement();
/* 125 */       List headList = root.getChildren("HEAD");
/* 126 */       Element head = (Element)headList.get(0);
/* 127 */       rspHead.append("<CODE>").append(head.getChildText("CODE")).append("</CODE>");
/*     */ 
/* 129 */       rspHead.append("<SID>").append(head.getChildText("SID")).append("</SID>");
/*     */ 
/* 131 */       rspHead.append("<TIMESTAMP>").append(DateUtil.getFormatCurrentTime("yyyyMMddhhmmssSSS")).append("</TIMESTAMP>");
/*     */ 
/* 134 */       rspHead.append("<SERVICEID>").append(head.getChildText("SERVICEID")).append("</SERVICEID>");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 138 */       log.info(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.parsePackageError") + e.getMessage());
/*     */ 
/* 141 */       throw e;
/*     */     } finally {
/* 143 */       is.close();
/*     */     }
/* 145 */     rspHead.append("</HEAD>");
/* 146 */     return rspHead.toString();
/*     */   }
/*     */ 
/*     */   public static final String genReqXml(String reqName, String bodyXml)
/*     */   {
/* 159 */     StringBuffer reqHead = new StringBuffer();
/* 160 */     reqHead.append("<?xml version='1.0' encoding='UTF-8'?>");
/* 161 */     reqHead.append("<").append(reqName).append(">");
/* 162 */     reqHead.append("<HEAD>");
/* 163 */     reqHead.append("<CODE>").append("").append("</CODE>");
/* 164 */     reqHead.append("<SID>").append("").append("</SID>");
/* 165 */     reqHead.append("<TIMESTAMP>").append(DateUtil.getFormatCurrentTime("yyyyMMddhhmmssSSS")).append("</TIMESTAMP>");
/*     */ 
/* 168 */     reqHead.append("<SERVICEID>").append(PrivilegeCodes.get4A_SERVICEID()).append("</SERVICEID>");
/*     */ 
/* 170 */     reqHead.append("</HEAD>");
/* 171 */     reqHead.append(bodyXml);
/* 172 */     reqHead.append("</").append(reqName).append(">");
/* 173 */     return reqHead.toString();
/*     */   }
/*     */ 
/*     */   public static String genErrorMsg(String root, String head, String key, String errorCode, String errDesc)
/*     */   {
/* 193 */     StringBuffer sb = new StringBuffer();
/* 194 */     sb.append("<?xml version='1.0' encoding='UTF-8'?>");
/* 195 */     sb.append("<").append(root).append(">");
/* 196 */     if (StringUtils.isBlank(head)) {
/* 197 */       sb.append("<HEAD>");
/* 198 */       sb.append("<CODE>").append("").append("</CODE>");
/* 199 */       sb.append("<SID>").append("").append("</SID>");
/* 200 */       sb.append("<TIMESTAMP>").append(DateUtil.getFormatCurrentTime("yyyyMMddhhmmssSSS")).append("</TIMESTAMP>");
/*     */ 
/* 203 */       sb.append("<SERVICEID>").append("").append("</SERVICEID>");
/*     */ 
/* 205 */       sb.append("</HEAD>");
/*     */     } else {
/* 207 */       sb.append(head);
/*     */     }
/* 209 */     sb.append("<BODY>");
/* 210 */     sb.append("<KEY>").append(key).append("</KEY>");
/* 211 */     sb.append("<ERRCODE>").append(errorCode).append("</ERRCODE>");
/* 212 */     sb.append("<ERRDESC>").append(errDesc).append("</ERRDESC>");
/* 213 */     sb.append("</BODY>");
/* 214 */     sb.append("</").append(root).append(">");
/* 215 */     log.debug("ErrRsp=" + sb.toString());
/* 216 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static Element getBodyElement(String xml, String elementName)
/*     */   {
/* 229 */     SAXBuilder builder = new SAXBuilder(false);
/* 230 */     StringReader in = new StringReader(xml);
/* 231 */     Element root = null;
/*     */     try {
/* 233 */       Document doc = builder.build(in);
/* 234 */       root = doc.getRootElement();
/*     */     } catch (Exception e) {
/* 236 */       throw new RuntimeException("xml解析时出错！" + e.getMessage(), e);
/*     */     } finally {
/* 238 */       in.close();
/*     */     }
/* 240 */     Element body = root.getChild("BODY");
/* 241 */     return body.getChild(elementName);
/*     */   }
/*     */ 
/*     */   public static String createUpdateAppAcctSoapRsp(String headXml, String modifyMode, Map<String, String> resultMap)
/*     */   {
/* 257 */     StringBuffer resultXml = new StringBuffer();
/* 258 */     resultXml.append("<?xml version='1.0' encoding='UTF-8'?>");
/* 259 */     resultXml.append("<USERMODIFYRSP>");
/* 260 */     resultXml.append(headXml);
/* 261 */     resultXml.append("<BODY>");
/* 262 */     resultXml.append("<MODIFYMODE>").append(modifyMode).append("</MODIFYMODE>");
/*     */ 
/* 264 */     Iterator it = resultMap.entrySet().iterator();
/* 265 */     String userID = "";
/* 266 */     String errMsg = "";
/* 267 */     while (it.hasNext()) {
/* 268 */       Map.Entry entry = (Map.Entry)it.next();
/*     */ 
/* 270 */       userID = (String)entry.getKey();
/* 271 */       errMsg = (String)entry.getValue();
/*     */     }
/* 273 */     resultXml.append("<USERID>").append(userID).append("</USERID>");
/* 274 */     resultXml.append("<LOGINNO>").append(userID).append("</LOGINNO>");
/* 275 */     if (StringUtils.isBlank(errMsg))
/* 276 */       resultXml.append("<RSP>").append("0").append("</RSP>");
/*     */     else {
/* 278 */       resultXml.append("<RSP>").append("1").append("</RSP>");
/*     */     }
/* 280 */     resultXml.append("<ERRDESC>").append(errMsg).append("</ERRDESC>");
/* 281 */     resultXml.append("</BODY>");
/* 282 */     resultXml.append("</USERMODIFYRSP>");
/* 283 */     log.debug("USERMODIFYRSP=" + resultXml.toString());
/* 284 */     return resultXml.toString();
/*     */   }
/*     */ 
/*     */   public static String validateUpdateAppAcctSoap(Map<String, String> reqBodyMap)
/*     */   {
/* 295 */     String errMsg = "";
/* 296 */     if (StringUtils.isBlank((String)reqBodyMap.get("USERNAME"))) {
/* 297 */       errMsg = errMsg + "USERNAME,";
/*     */     }
/* 299 */     if (StringUtils.isBlank((String)reqBodyMap.get("ORGID"))) {
/* 300 */       errMsg = errMsg + "ORGID,";
/*     */     }
/* 302 */     if (StringUtils.isBlank((String)reqBodyMap.get("CITYID"))) {
/* 303 */       errMsg = errMsg + "CITYID,";
/*     */     }
/* 305 */     if (StringUtils.isBlank((String)reqBodyMap.get("DUTYID"))) {
/* 306 */       errMsg = errMsg + "DUTYID,";
/*     */     }
/* 308 */     if (StringUtils.isBlank((String)reqBodyMap.get("DEPARTMENTID"))) {
/* 309 */       errMsg = errMsg + "DEPARTMENTID,";
/*     */     }
/* 311 */     if (StringUtils.isBlank((String)reqBodyMap.get("MOBILE"))) {
/* 312 */       errMsg = errMsg + "MOBILE,";
/*     */     }
/* 314 */     if (StringUtils.isNotBlank(errMsg)) {
/* 315 */       errMsg = LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userInfoNotComplete") + ":" + errMsg;
/*     */     }
/*     */ 
/* 319 */     return errMsg;
/*     */   }
/*     */ 
/*     */   public static String createUpdateBatchAppAcctRsp(String headXml, String modifyMode, Map<String, String> resultMap)
/*     */   {
/* 335 */     StringBuffer resultXml = new StringBuffer();
/* 336 */     resultXml.append("<?xml version='1.0' encoding='UTF-8'?>");
/* 337 */     resultXml.append("<USERMODIFYRSP>");
/* 338 */     resultXml.append(headXml);
/* 339 */     resultXml.append("<BODY>");
/* 340 */     resultXml.append("<MODIFYMODE>").append(modifyMode).append("</MODIFYMODE>");
/*     */ 
/* 342 */     resultXml.append("<USERLIST>");
/* 343 */     Iterator it = resultMap.entrySet().iterator();
/* 344 */     while (it.hasNext()) {
/* 345 */       Map.Entry entry = (Map.Entry)it.next();
/*     */ 
/* 347 */       String userID = (String)entry.getKey();
/* 348 */       String errMsg = (String)entry.getValue();
/* 349 */       resultXml.append("<USERINFO>");
/* 350 */       resultXml.append("<USERID>").append(userID).append("</USERID>");
/* 351 */       resultXml.append("<LOGINNO>").append(userID).append("</LOGINNO>");
/* 352 */       if (StringUtils.isBlank(errMsg))
/* 353 */         resultXml.append("<RSP>").append("0").append("</RSP>");
/*     */       else {
/* 355 */         resultXml.append("<RSP>").append("1").append("</RSP>");
/*     */       }
/*     */ 
/* 358 */       resultXml.append("<ERRDESC>").append(errMsg).append("</ERRDESC>");
/* 359 */       resultXml.append("</USERINFO>");
/*     */     }
/* 361 */     resultXml.append("</USERLIST>");
/* 362 */     resultXml.append("</BODY>");
/* 363 */     resultXml.append("</USERMODIFYRSP>");
/* 364 */     log.debug("QUERYAPPROLERSP=" + resultXml.toString());
/* 365 */     return resultXml.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.WsPrivilege4AUtil
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.privilege.webservices.util.foura.des;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URISyntaxException;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.security.SecureRandom;
/*    */ import javax.crypto.KeyGenerator;
/*    */ import javax.crypto.SecretKey;
/*    */ 
/*    */ public class CreateKey
/*    */ {
/* 12 */   String filename = "";
/*    */   public static byte[] keybyte;
/* 19 */   static SecretKey key = null;
/*    */ 
/*    */   public byte[] getKeyByte()
/*    */     throws IOException, URISyntaxException
/*    */   {
/* 27 */     byte[] bytes = Util.readFile(this.filename);
/* 28 */     return bytes;
/*    */   }
/*    */ 
/*    */   public void CreateKeyFile(String filename) throws IOException, NoSuchAlgorithmException
/*    */   {
/* 33 */     this.filename = filename;
/* 34 */     if ((filename == null) || (filename.equals("")))
/*    */     {
/* 36 */       throw new NullPointerException("chaimj:valid file path!!!");
/*    */     }
/* 38 */     createKey();
/*    */   }
/*    */ 
/*    */   private void createKey()
/*    */     throws NoSuchAlgorithmException, IOException
/*    */   {
/* 47 */     SecureRandom secureRandom = new SecureRandom();
/*    */ 
/* 49 */     KeyGenerator kg = KeyGenerator.getInstance("DES");
/* 50 */     kg.init(secureRandom);
/*    */ 
/* 52 */     SecretKey key = kg.generateKey();
/*    */ 
/* 54 */     Util.writeFile(key.getEncoded(), this.filename);
/*    */   }
/*    */ 
/*    */   public static byte[] createKey1(String algorithm)
/*    */     throws NoSuchAlgorithmException, IOException
/*    */   {
/* 64 */     SecureRandom secureRandom = new SecureRandom();
/*    */ 
/* 68 */     KeyGenerator kg = KeyGenerator.getInstance("DES");
/* 69 */     kg.init(secureRandom);
/*    */ 
/* 72 */     if (key == null) {
/* 73 */       key = kg.generateKey();
/* 74 */       keybyte = key.getEncoded();
/*    */     }
/*    */ 
/* 79 */     return keybyte;
/*    */   }
/*    */ 
/*    */   public String getKeyFilePath()
/*    */   {
/* 89 */     return this.filename;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.foura.des.CreateKey
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.webservices.util.foura.des;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.KeySpec;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ 
/*     */ public class EncryptData
/*     */ {
/*  23 */   private String keyfile = null;
/*     */ 
/*     */   public EncryptData() {
/*     */   }
/*     */ 
/*     */   public EncryptData(String keyfile) {
/*  29 */     this.keyfile = keyfile;
/*     */   }
/*     */ 
/*     */   public void createEncryptData(String filename, String filenamekey)
/*     */     throws IllegalStateException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException, IOException, InstantiationException, URISyntaxException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalStateException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException, IOException
/*     */   {
/*  47 */     if ((this.keyfile == null) || (this.keyfile.equals("")))
/*     */     {
/*  49 */       throw new NullPointerException("无效的key文件路径");
/*     */     }
/*     */ 
/*  52 */     encryptData(filename, filenamekey);
/*     */   }
/*     */ 
/*     */   private void encryptData(String filename, String encryptfile)
/*     */     throws IOException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, URISyntaxException, NoSuchAlgorithmException, BadPaddingException, IllegalBlockSizeException, IllegalStateException, ClassNotFoundException, SecurityException, NoSuchMethodException, InvocationTargetException, IllegalArgumentException, IllegalAccessException, InstantiationException
/*     */   {
/*  76 */     byte[] data = Util.readFile(filename);
/*     */ 
/*  78 */     byte[] encryptedClassData = getencryptData(data, "file");
/*     */ 
/*  80 */     Util.writeFile(encryptedClassData, encryptfile);
/*     */   }
/*     */ 
/*     */   public byte[] createEncryptData(byte[] bytes, String algorithm)
/*     */     throws IllegalStateException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, URISyntaxException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException, IOException
/*     */   {
/* 108 */     bytes = getencryptData(bytes, algorithm);
/* 109 */     return bytes;
/*     */   }
/*     */ 
/*     */   private byte[] getencryptData(byte[] bytes, String algorithm)
/*     */     throws IOException, ClassNotFoundException, SecurityException, NoSuchMethodException, InvocationTargetException, IllegalArgumentException, URISyntaxException, IllegalAccessException, InstantiationException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, IllegalStateException
/*     */   {
/* 120 */     SecureRandom sr = new SecureRandom();
/*     */ 
/* 122 */     byte[] rawKeyData = Util.readFile("DES.properties");
/*     */     Class classkeyspec;
/*     */     Class classkeyspec;
/* 129 */     if (algorithm.equals("DES"))
/*     */     {
/* 131 */       classkeyspec = Class.forName("javax.crypto.spec.DESKeySpec");
/*     */     }
/*     */     else
/*     */     {
/*     */       Class classkeyspec;
/* 133 */       if (algorithm.equals("PBE"))
/*     */       {
/* 135 */         classkeyspec = Class.forName("javax.crypto.spec.PBEKeySpec");
/*     */       }
/* 137 */       else classkeyspec = Class.forName("javax.crypto.spec.DESKeySpec");
/*     */     }
/*     */ 
/* 140 */     Constructor constructor = classkeyspec.getConstructor(new Class[] { [B.class });
/* 141 */     KeySpec dks = (KeySpec)constructor.newInstance(new Object[] { rawKeyData });
/*     */ 
/* 143 */     SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algorithm);
/* 144 */     SecretKey key = keyFactory.generateSecret(dks);
/*     */ 
/* 146 */     Cipher cipher = Cipher.getInstance(algorithm);
/*     */ 
/* 148 */     cipher.init(1, key, sr);
/*     */ 
/* 150 */     bytes = cipher.doFinal(bytes);
/*     */ 
/* 152 */     return bytes;
/*     */   }
/*     */ 
/*     */   public void setKeyFile(String keyfile)
/*     */   {
/* 160 */     this.keyfile = keyfile;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.foura.des.EncryptData
 * JD-Core Version:    0.6.2
 */
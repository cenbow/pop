/*     */ package com.asiainfo.biframe.privilege.webservices.util.foura.des;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ 
/*     */ public class EncryptInterface
/*     */ {
/*     */   public static String desEncryptData(String str)
/*     */   {
/*  25 */     EncryptData ed = new EncryptData();
/*  26 */     StringBuffer sb = new StringBuffer();
/*     */ 
/*  28 */     String result = "";
/*  29 */     byte[] date_byte = str.getBytes();
/*     */     try {
/*  31 */       byte[] bss = ed.createEncryptData(date_byte, "DES");
/*     */ 
/*  34 */       sb.append(bss.length + "|");
/*     */ 
/*  36 */       for (int i = 0; i < bss.length; i++) {
/*  37 */         sb.append(bss[i] + "|");
/*     */       }
/*  39 */       result = sb.toString();
/*  40 */       result = result.substring(0, result.length() - 1);
/*     */     }
/*     */     catch (InvalidKeyException e)
/*     */     {
/*  44 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalStateException e) {
/*  47 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalBlockSizeException e) {
/*  50 */       e.printStackTrace();
/*     */     }
/*     */     catch (URISyntaxException e) {
/*  53 */       e.printStackTrace();
/*     */     }
/*     */     catch (BadPaddingException e) {
/*  56 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchPaddingException e) {
/*  59 */       e.printStackTrace();
/*     */     }
/*     */     catch (InvalidKeySpecException e) {
/*  62 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchAlgorithmException e) {
/*  65 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/*  68 */       e.printStackTrace();
/*     */     }
/*     */     catch (SecurityException e) {
/*  71 */       e.printStackTrace();
/*     */     }
/*     */     catch (InstantiationException e) {
/*  74 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalAccessException e) {
/*  77 */       e.printStackTrace();
/*     */     }
/*     */     catch (InvocationTargetException e) {
/*  80 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchMethodException e) {
/*  83 */       e.printStackTrace();
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/*  86 */       e.printStackTrace();
/*     */     }
/*     */     catch (IOException e) {
/*  89 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  92 */     return result;
/*     */   }
/*     */ 
/*     */   public static String desUnEncryptData(String str)
/*     */   {
/* 104 */     UnEncryptData ud = new UnEncryptData();
/* 105 */     String ss = "";
/*     */     try
/*     */     {
/* 109 */       int byte_i = Integer.parseInt(str.substring(0, str.indexOf("|")));
/* 110 */       byte[] date_byte = new byte[byte_i];
/* 111 */       str = str.substring(str.indexOf("|") + 1);
/* 112 */       StringTokenizer st = new StringTokenizer(str, "|");
/*     */ 
/* 114 */       int i = 0;
/*     */ 
/* 116 */       while (st.hasMoreTokens()) {
/* 117 */         byte_i = Integer.parseInt(st.nextToken());
/* 118 */         date_byte[i] = ((byte)byte_i);
/* 119 */         i++;
/*     */       }
/*     */ 
/* 122 */       byte[] bss = ud.createUnEncryptData(date_byte, "DES");
/* 123 */       ss = new String(bss);
/*     */     } catch (Exception e) {
/* 125 */       e.printStackTrace();
/*     */     }
/* 127 */     return ss;
/*     */   }
/*     */ 
/*     */   public static String desEncryptData1(String str)
/*     */   {
/* 139 */     EncryptData ed = new EncryptData();
/* 140 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 142 */     String result = "";
/* 143 */     byte[] date_byte = str.getBytes();
/*     */     try {
/* 145 */       byte[] bss = ed.createEncryptData(date_byte, "DES");
/*     */ 
/* 147 */       System.out.println("bss.length = " + bss.length);
/* 148 */       sb.append(bss.length + "%");
/*     */ 
/* 150 */       for (int i = 0; i < bss.length; i++) {
/* 151 */         sb.append(bss[i] + "%");
/*     */       }
/* 153 */       result = sb.toString();
/* 154 */       result = result.substring(0, result.length() - 1);
/*     */     }
/*     */     catch (URISyntaxException e)
/*     */     {
/* 158 */       e.printStackTrace();
/*     */     }
/*     */     catch (InvalidKeyException e) {
/* 161 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalStateException e) {
/* 164 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalBlockSizeException e) {
/* 167 */       e.printStackTrace();
/*     */     }
/*     */     catch (BadPaddingException e) {
/* 170 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchPaddingException e) {
/* 173 */       e.printStackTrace();
/*     */     }
/*     */     catch (InvalidKeySpecException e) {
/* 176 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchAlgorithmException e) {
/* 179 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/* 182 */       e.printStackTrace();
/*     */     }
/*     */     catch (SecurityException e) {
/* 185 */       e.printStackTrace();
/*     */     }
/*     */     catch (InstantiationException e) {
/* 188 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 191 */       e.printStackTrace();
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 194 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchMethodException e) {
/* 197 */       e.printStackTrace();
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 200 */       e.printStackTrace();
/*     */     }
/*     */     catch (IOException e) {
/* 203 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 206 */     return result;
/*     */   }
/*     */ 
/*     */   public static String desUnEncryptData1(String str)
/*     */   {
/* 218 */     UnEncryptData ud = new UnEncryptData();
/* 219 */     String ss = "";
/*     */     try
/*     */     {
/* 223 */       int byte_i = Integer.parseInt(str.substring(0, str.indexOf("%")));
/* 224 */       byte[] date_byte = new byte[byte_i];
/* 225 */       str = str.substring(str.indexOf("%") + 1);
/* 226 */       StringTokenizer st = new StringTokenizer(str, "%");
/*     */ 
/* 228 */       int i = 0;
/*     */ 
/* 230 */       while (st.hasMoreTokens()) {
/* 231 */         byte_i = Integer.parseInt(st.nextToken());
/* 232 */         date_byte[i] = ((byte)byte_i);
/* 233 */         i++;
/*     */       }
/*     */ 
/* 236 */       byte[] bss = ud.createUnEncryptData(date_byte, "DES");
/* 237 */       ss = new String(bss);
/*     */     }
/*     */     catch (Exception e) {
/* 240 */       e.printStackTrace();
/*     */     }
/* 242 */     return ss;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.foura.des.EncryptInterface
 * JD-Core Version:    0.6.2
 */
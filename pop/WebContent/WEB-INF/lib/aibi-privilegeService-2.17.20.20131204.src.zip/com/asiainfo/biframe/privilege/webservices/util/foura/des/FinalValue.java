package com.asiainfo.biframe.privilege.webservices.util.foura.des;

public class FinalValue
{
  public static final String DELETE_ERROR = "ɾ���������ϵͳ����Աjϵ��";
  public static final String ALGORITHM_DES = "DES";
  public static final String ALGORITHM_DES_CLASS = "javax.crypto.spec.DESKeySpec";
  public static final String ALGORITHM_PBE = "PBE";
  public static final String ALGORITHM_PBE_CLASS = "javax.crypto.spec.PBEKeySpec";
  public static final String KEY_FILE_NAME = "DES.properties";
  public static final String ADD = "add";
  public static final String CHANGE = "change";
  public static final String DELETE = "delete";
  public static final String ERROR = "error";
  public static final String BATCH = "batch";
  public static final String SINGLE = "single";
  public static final String FASERVICECODE = "AAAA";
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.foura.des.FinalValue
 * JD-Core Version:    0.6.2
 */
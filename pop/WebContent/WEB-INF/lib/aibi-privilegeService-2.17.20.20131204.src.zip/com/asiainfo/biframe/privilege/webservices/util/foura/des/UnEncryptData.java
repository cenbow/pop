/*     */ package com.asiainfo.biframe.privilege.webservices.util.foura.des;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.KeySpec;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ 
/*     */ public class UnEncryptData
/*     */ {
/*  22 */   private String keyfile = "";
/*     */ 
/*     */   public UnEncryptData() {
/*     */   }
/*     */ 
/*     */   public UnEncryptData(String keyfile) {
/*  28 */     this.keyfile = keyfile;
/*     */   }
/*     */ 
/*     */   public void createUnEncryptData(String encryptfile, String filename)
/*     */     throws IllegalStateException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException, IOException, NoSuchMethodException, URISyntaxException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, ClassNotFoundException, IllegalStateException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException, IOException
/*     */   {
/*  41 */     if ((this.keyfile == null) || (this.keyfile.equals("")))
/*     */     {
/*  43 */       throw new NullPointerException("无效的key文件路径");
/*     */     }
/*     */ 
/*  46 */     unEncryptData(encryptfile, filename);
/*     */   }
/*     */ 
/*     */   private void unEncryptData(String encryptfile, String filename)
/*     */     throws IOException, IllegalStateException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException, IOException, URISyntaxException
/*     */   {
/*  71 */     byte[] data = Util.readFile(encryptfile);
/*     */ 
/*  73 */     byte[] decryptedData = getunEncryptData(data, "file");
/*     */ 
/*  75 */     Util.writeFile(decryptedData, filename);
/*     */   }
/*     */ 
/*     */   public byte[] createUnEncryptData(byte[] bytes, String algorithm)
/*     */     throws IllegalStateException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, URISyntaxException, NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException, IOException
/*     */   {
/* 104 */     bytes = getunEncryptData(bytes, algorithm);
/* 105 */     return bytes;
/*     */   }
/*     */ 
/*     */   private byte[] getunEncryptData(byte[] bytes, String algorithm)
/*     */     throws IOException, ClassNotFoundException, SecurityException, NoSuchMethodException, URISyntaxException, InvocationTargetException, IllegalArgumentException, IllegalAccessException, InstantiationException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, IllegalStateException
/*     */   {
/* 136 */     SecureRandom sr = new SecureRandom();
/*     */ 
/* 138 */     byte[] rawKeyData = Util.readFile("DES.properties");
/*     */     Class classkeyspec;
/*     */     Class classkeyspec;
/* 145 */     if (algorithm.equals("DES"))
/*     */     {
/* 147 */       classkeyspec = Class.forName("javax.crypto.spec.DESKeySpec");
/*     */     }
/*     */     else
/*     */     {
/*     */       Class classkeyspec;
/* 149 */       if (algorithm.equals("PBE"))
/*     */       {
/* 151 */         classkeyspec = Class.forName("javax.crypto.spec.PBEKeySpec");
/*     */       }
/* 153 */       else classkeyspec = Class.forName("javax.crypto.spec.DESKeySpec");
/*     */     }
/*     */ 
/* 156 */     Constructor constructor = classkeyspec.getConstructor(new Class[] { [B.class });
/* 157 */     KeySpec dks = (KeySpec)constructor.newInstance(new Object[] { rawKeyData });
/*     */ 
/* 159 */     SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algorithm);
/* 160 */     SecretKey key = keyFactory.generateSecret(dks);
/*     */ 
/* 162 */     Cipher cipher = Cipher.getInstance(algorithm);
/*     */ 
/* 164 */     cipher.init(2, key, sr);
/*     */ 
/* 167 */     bytes = cipher.doFinal(bytes);
/*     */ 
/* 169 */     return bytes;
/*     */   }
/*     */ 
/*     */   public void setKeyFile(String keyfile)
/*     */   {
/* 174 */     this.keyfile = keyfile;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.foura.des.UnEncryptData
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.webservices.util.foura.des;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ public class Util
/*     */ {
/*  16 */   private static ResourceBundle resources = null;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/*  34 */       byte[] b = readFile("DES.properties");
/*  35 */       System.out.println(b);
/*     */     }
/*     */     catch (IOException e) {
/*  38 */       e.printStackTrace();
/*     */     }
/*     */     catch (URISyntaxException e) {
/*  41 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static byte[] readFile(String filename)
/*     */     throws IOException, URISyntaxException
/*     */   {
/*  54 */     byte[] buffer = new byte[1024];
/*  55 */     InputStream is = null;
/*     */     try {
/*  57 */       is = Thread.currentThread().getContextClassLoader().getResourceAsStream(filename);
/*  58 */       is.read(buffer);
/*     */     } finally {
/*  60 */       is.close();
/*     */     }
/*     */ 
/*  63 */     return buffer;
/*     */   }
/*     */ 
/*     */   public static void writeFile(byte[] data, String filename)
/*     */     throws IOException
/*     */   {
/*  75 */     File file = new File(filename);
/*  76 */     file.getParentFile().mkdirs();
/*  77 */     BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(file));
/*     */ 
/*  79 */     bufferedOutputStream.write(data);
/*  80 */     bufferedOutputStream.close();
/*     */   }
/*     */ 
/*     */   public byte[] readFileJar(String filename)
/*     */     throws IOException
/*     */   {
/*  93 */     BufferedInputStream bufferedInputStream = new BufferedInputStream(getClass().getResource(filename).openStream());
/*     */ 
/*  95 */     int len = bufferedInputStream.available();
/*  96 */     byte[] bytes = new byte[len];
/*  97 */     int r = bufferedInputStream.read(bytes);
/*  98 */     if (len != r) {
/*  99 */       bytes = null;
/* 100 */       throw new IOException("读取文件不正确");
/*     */     }
/* 102 */     bufferedInputStream.close();
/* 103 */     return bytes;
/*     */   }
/*     */ 
/*     */   public static String getAlgorithm()
/*     */   {
/* 113 */     return "DES";
/*     */   }
/*     */ 
/*     */   public static String getValue(String skey)
/*     */   {
/* 124 */     return resources.getString(skey);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  21 */     new Util();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeService-2.17.20.20131204.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.webservices.util.foura.des.Util
 * JD-Core Version:    0.6.2
 */
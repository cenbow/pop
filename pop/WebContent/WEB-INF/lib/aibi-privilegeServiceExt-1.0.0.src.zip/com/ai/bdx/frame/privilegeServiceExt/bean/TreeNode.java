/*     */ package com.ai.bdx.frame.privilegeServiceExt.bean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class TreeNode
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6556236585689446446L;
/*     */   private String id;
/*     */   private String text;
/*     */   private String href;
/*     */   private String qtip;
/*     */   private boolean expanded;
/*     */   private String pid;
/*     */   private String name;
/*     */   private String url;
/*     */   private String title;
/*     */   private String target;
/*     */   private String icon;
/*     */   private String iconOpen;
/*     */   private String open;
/*     */ 
/*     */   public String getIcon()
/*     */   {
/*  38 */     return this.icon;
/*     */   }
/*     */ 
/*     */   public void setIcon(String icon) {
/*  42 */     this.icon = icon;
/*     */   }
/*     */ 
/*     */   public String getIconOpen() {
/*  46 */     return this.iconOpen;
/*     */   }
/*     */ 
/*     */   public void setIconOpen(String iconOpen) {
/*  50 */     this.iconOpen = iconOpen;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  54 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String id) {
/*  58 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  62 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  66 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getOpen() {
/*  70 */     return this.open;
/*     */   }
/*     */ 
/*     */   public void setOpen(String open) {
/*  74 */     this.open = open;
/*     */   }
/*     */ 
/*     */   public String getPid() {
/*  78 */     return this.pid;
/*     */   }
/*     */ 
/*     */   public void setPid(String pid) {
/*  82 */     this.pid = pid;
/*     */   }
/*     */ 
/*     */   public String getTarget() {
/*  86 */     return this.target;
/*     */   }
/*     */ 
/*     */   public void setTarget(String target) {
/*  90 */     this.target = target;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/*  94 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setTitle(String title) {
/*  98 */     this.title = title;
/*     */   }
/*     */ 
/*     */   public String getUrl() {
/* 102 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setUrl(String url) {
/* 106 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public String getText() {
/* 110 */     return this.text;
/*     */   }
/*     */ 
/*     */   public void setText(String text) {
/* 114 */     this.text = text;
/*     */   }
/*     */ 
/*     */   public String getHref() {
/* 118 */     return this.href;
/*     */   }
/*     */ 
/*     */   public void setHref(String href) {
/* 122 */     this.href = href;
/*     */   }
/*     */ 
/*     */   public String getQtip() {
/* 126 */     return this.qtip;
/*     */   }
/*     */ 
/*     */   public void setQtip(String qtip) {
/* 130 */     this.qtip = qtip;
/*     */   }
/*     */ 
/*     */   public boolean isExpanded() {
/* 134 */     return this.expanded;
/*     */   }
/*     */ 
/*     */   public void setExpanded(boolean expanded) {
/* 138 */     this.expanded = expanded;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.bean.TreeNode
 * JD-Core Version:    0.6.2
 */
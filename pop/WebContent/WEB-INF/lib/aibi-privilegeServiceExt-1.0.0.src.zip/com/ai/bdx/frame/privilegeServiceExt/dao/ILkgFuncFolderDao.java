package com.ai.bdx.frame.privilegeServiceExt.dao;

import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgFuncFolder;
import com.asiainfo.biframe.privilege.IUserRole;
import java.util.List;

public abstract interface ILkgFuncFolderDao
{
  public abstract LkgFuncFolder findById(String paramString);

  public abstract List<LkgFuncFolder> findSubFolders(String paramString);

  public abstract List<LkgFuncFolder> findByTopIdAndRoles(List<String> paramList, List<IUserRole> paramList1);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.ILkgFuncFolderDao
 * JD-Core Version:    0.6.2
 */
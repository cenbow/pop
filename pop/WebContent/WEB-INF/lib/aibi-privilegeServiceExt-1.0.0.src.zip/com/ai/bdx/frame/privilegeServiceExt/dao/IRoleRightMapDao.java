package com.ai.bdx.frame.privilegeServiceExt.dao;

import com.asiainfo.biframe.privilege.IMenuItem;
import com.asiainfo.biframe.privilege.IUserRight;
import java.util.List;

public abstract interface IRoleRightMapDao
{
  public abstract List<IUserRight> getRightsByRoles(List paramList);

  public abstract List<IUserRight> getMenuItems();

  public abstract IMenuItem getMenuItemById(String paramString);

  public abstract List getAllMenu();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.IRoleRightMapDao
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.privilegeServiceExt.dao;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.ICity;
import java.util.List;
import java.util.Map;

public abstract interface IUserCityDao
{
  public abstract List<ICity> getAllCity();

  public abstract List<ICity> getAllCounty();

  public abstract ICity getCityById(String paramString);

  public abstract ICity getCityByOldId(String paramString);

  public abstract List<ICity> getCityByParentId(String paramString);

  public abstract IUserScope getUserScope(String paramString)
    throws ServiceException;

  public abstract List<ICity> getCitysByUserId(Map paramMap)
    throws ServiceException;

  public abstract List<ICity> getRecommendCitysByUserId(Map paramMap)
    throws ServiceException;

  public abstract String getCountryIdByOldId(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.IUserCityDao
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.privilegeServiceExt.dao;

import com.asiainfo.biframe.privilege.IUserCompany;
import java.util.List;

public abstract interface IUserDeptDao
{
  public abstract List<IUserCompany> getDeptAll()
    throws Exception;

  public abstract IUserCompany getDeptById(String paramString)
    throws Exception;

  public abstract List<IUserCompany> getSubCompanyById(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.IUserDeptDao
 * JD-Core Version:    0.6.2
 */
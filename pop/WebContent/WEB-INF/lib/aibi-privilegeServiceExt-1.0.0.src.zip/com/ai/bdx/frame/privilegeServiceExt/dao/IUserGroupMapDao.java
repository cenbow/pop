package com.ai.bdx.frame.privilegeServiceExt.dao;

import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.IUserGroup;
import java.util.List;

public abstract interface IUserGroupMapDao
{
  public abstract List<IUser> findAllUserByGId(String paramString);

  public abstract List<IUserGroup> getGroupByUserId(List<String> paramList);

  public abstract List<IUserGroup> getGroupByUserId(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.IUserGroupMapDao
 * JD-Core Version:    0.6.2
 */
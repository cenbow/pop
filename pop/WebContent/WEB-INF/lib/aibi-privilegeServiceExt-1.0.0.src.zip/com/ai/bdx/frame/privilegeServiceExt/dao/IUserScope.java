package com.ai.bdx.frame.privilegeServiceExt.dao;

public abstract interface IUserScope
{
  public abstract String getStaffId();

  public abstract String getProvScope();

  public abstract String getCityScope();

  public abstract String getCountryScope();

  public abstract String getAreaScope();

  public abstract String getSub1AreaScope();

  public abstract String getSub2AreaScope();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.IUserScope
 * JD-Core Version:    0.6.2
 */
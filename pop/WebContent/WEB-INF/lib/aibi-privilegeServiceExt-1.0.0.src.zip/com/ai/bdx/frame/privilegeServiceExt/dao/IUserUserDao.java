package com.ai.bdx.frame.privilegeServiceExt.dao;

import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaff;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
import java.util.List;

public abstract interface IUserUserDao
{
  public abstract List<IUser> listUsers();

  public abstract IUser findById(String paramString);

  public abstract LkgStaff findEntityById(String paramString);

  public abstract List<IUser> findAll(SearchCondition paramSearchCondition);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.IUserUserDao
 * JD-Core Version:    0.6.2
 */
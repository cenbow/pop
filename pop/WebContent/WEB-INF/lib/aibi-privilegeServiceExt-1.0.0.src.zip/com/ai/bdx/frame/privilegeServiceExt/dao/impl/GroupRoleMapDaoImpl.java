/*    */ package com.ai.bdx.frame.privilegeServiceExt.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.IGroupRoleMapDao;
/*    */ import com.asiainfo.biframe.privilege.IUserRole;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class GroupRoleMapDaoImpl extends HibernateDaoSupport
/*    */   implements IGroupRoleMapDao
/*    */ {
/*    */   public List<IUserRole> findRoleListByGroupId(String groupId)
/*    */   {
/* 19 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.impl.GroupRoleMapDaoImpl
 * JD-Core Version:    0.6.2
 */
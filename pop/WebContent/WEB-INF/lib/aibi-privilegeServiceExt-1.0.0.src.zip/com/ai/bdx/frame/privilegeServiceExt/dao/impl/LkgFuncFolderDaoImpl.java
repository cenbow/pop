/*    */ package com.ai.bdx.frame.privilegeServiceExt.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.ILkgFuncFolderDao;
/*    */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgFunc;
/*    */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgFuncFolder;
/*    */ import com.asiainfo.biframe.privilege.IUserRole;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.criterion.Order;
/*    */ import org.hibernate.criterion.Projections;
/*    */ import org.hibernate.criterion.Restrictions;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class LkgFuncFolderDaoImpl extends HibernateDaoSupport
/*    */   implements ILkgFuncFolderDao
/*    */ {
/*    */   public List<LkgFuncFolder> findSubFolders(String parentId)
/*    */   {
/* 38 */     Criteria criteria = getSession().createCriteria(LkgFuncFolder.class).add(Restrictions.eq("parentId", parentId));
/*    */ 
/* 40 */     return criteria.list();
/*    */   }
/*    */ 
/*    */   public LkgFuncFolder findById(String folderId)
/*    */   {
/* 45 */     Criteria criteria = getSession().createCriteria(LkgFuncFolder.class).add(Restrictions.eq("folderId", folderId));
/*    */ 
/* 47 */     return (LkgFuncFolder)criteria.uniqueResult();
/*    */   }
/*    */ 
/*    */   public List<LkgFuncFolder> findByTopIdAndRoles(List<String> folderIds, List<IUserRole> allRoleList)
/*    */   {
/* 54 */     List resultList = new ArrayList();
/* 55 */     String roleIds = "";
/* 56 */     for (IUserRole userRole : allRoleList)
/* 57 */       roleIds = roleIds + "'" + userRole.getRoleId() + "',";
/* 58 */     if (!roleIds.equals("")) {
/* 59 */       roleIds = roleIds.substring(0, roleIds.length() - 1);
/* 60 */       Criteria criteria = getSession().createCriteria(LkgFunc.class).add(Restrictions.in("folderId", folderIds)).add(Restrictions.sqlRestriction("FUNC_ID IN (select FUNC_ID from LKG_JOB_FUNC WHERE JOB_ID IN(" + roleIds + "))")).addOrder(Order.asc("funcId"));
/*    */ 
/* 65 */       List functions = criteria.list();
/* 66 */       criteria = getSession().createCriteria(LkgFunc.class).setProjection(Projections.groupProperty("funcFolder")).add(Restrictions.in("folderId", folderIds)).add(Restrictions.sqlRestriction("FUNC_ID IN (select FUNC_ID from LKG_JOB_FUNC WHERE JOB_ID IN(" + roleIds + "))"));
/*    */ 
/* 71 */       resultList = criteria.list();
/* 72 */       addToFuncFolders(resultList, functions);
/*    */     }
/* 74 */     return resultList;
/*    */   }
/*    */ 
/*    */   private void addToFuncFolders(List<LkgFuncFolder> folderList, List<LkgFunc> functions)
/*    */   {
/* 79 */     for (Iterator i$ = folderList.iterator(); i$.hasNext(); ) { folder = (LkgFuncFolder)i$.next();
/* 80 */       for (LkgFunc lkgFunc : functions)
/* 81 */         if (lkgFunc.getFolderId().equals(folder.getFolderId())) {
/* 82 */           Set funcs = folder.getFunctions();
/* 83 */           if (funcs == null)
/* 84 */             funcs = new TreeSet();
/* 85 */           funcs.add(lkgFunc);
/* 86 */           folder.setFunctions(funcs);
/*    */         }
/*    */     }
/*    */     LkgFuncFolder folder;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.impl.LkgFuncFolderDaoImpl
 * JD-Core Version:    0.6.2
 */
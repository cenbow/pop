/*     */ package com.ai.bdx.frame.privilegeServiceExt.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IRoleRightMapDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgFunc;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgFuncFolder;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import com.asiainfo.biframe.privilege.IUserRight;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.Right;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class RoleRightMapDaoImpl extends HibernateDaoSupport
/*     */   implements IRoleRightMapDao
/*     */ {
/*  25 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   private List<String> getAllFolderIds(Sqlca sqlca, Integer folderId)
/*     */   {
/*  33 */     List folderIdList = new ArrayList();
/*     */     try {
/*  35 */       String topMenuId = Configure.getInstance().getProperty("TOP_MENU_ID");
/*  36 */       sqlca = new Sqlca(sqlca.getConnection());
/*  37 */       StringBuilder sql = new StringBuilder();
/*  38 */       sql.append("  WITH                                           ");
/*  39 */       sql.append("      tmptab                                     ");
/*  40 */       sql.append("      (                                          ");
/*  41 */       sql.append("          folder_id,                             ");
/*  42 */       sql.append("          folder_name,                           ");
/*  43 */       sql.append("          parent_id                              ");
/*  44 */       sql.append("      ) AS                                       ");
/*  45 */       sql.append("      (                                          ");
/*  46 */       sql.append("          SELECT                                 ");
/*  47 */       sql.append("              ctg.folder_id,                     ");
/*  48 */       sql.append("              ctg.folder_name,                   ");
/*  49 */       sql.append("              ctg.parent_id                      ");
/*  50 */       sql.append("          FROM                                   ");
/*  51 */       sql.append("              lkg_func_folder ctg                ");
/*  52 */       sql.append("          WHERE                                  ");
/*  53 */       sql.append(new StringBuilder().append("              ctg.folder_id = '").append(folderId).append("'           ").toString());
/*  54 */       sql.append("          UNION ALL                              ");
/*  55 */       sql.append("          SELECT                                 ");
/*  56 */       sql.append("              sub.folder_id,                     ");
/*  57 */       sql.append("              sub.folder_name,                   ");
/*  58 */       sql.append("              sub.parent_id                      ");
/*  59 */       sql.append("          FROM                                   ");
/*  60 */       sql.append("              lkg_func_folder sub ,              ");
/*  61 */       sql.append("              tmptab super                       ");
/*  62 */       sql.append("          WHERE                                  ");
/*  63 */       sql.append("              sub.folder_id = super.parent_id    ");
/*  64 */       sql.append("      )                                          ");
/*  65 */       sql.append("  SELECT                                         ");
/*  66 */       sql.append("      *                                          ");
/*  67 */       sql.append("  FROM                                           ");
/*  68 */       sql.append("      tmptab                                     ");
/*  69 */       sql.append("  WHERE                                          ");
/*  70 */       sql.append(new StringBuilder().append("      folder_id != '").append(topMenuId).append("'                          ").toString());
/*  71 */       sqlca.execute(sql.toString());
/*     */ 
/*  73 */       while (sqlca.next()) {
/*  74 */         folderIdList.add(sqlca.getString("folder_id"));
/*     */       }
/*  76 */       if (null != sqlca) {
/*  77 */         sqlca.close();
/*     */       }
/*     */ 
/*  86 */       if (null != sqlca)
/*  87 */         sqlca.close();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  80 */       ex.printStackTrace();
/*     */ 
/*  82 */       if (null != sqlca) {
/*  83 */         sqlca.close();
/*     */       }
/*     */ 
/*  86 */       if (null != sqlca)
/*  87 */         sqlca.close();
/*     */     }
/*     */     finally
/*     */     {
/*  86 */       if (null != sqlca) {
/*  87 */         sqlca.close();
/*     */       }
/*     */     }
/*  90 */     return folderIdList;
/*     */   }
/*     */ 
/*     */   private List<IMenuItem> getAllfolders(Set<String> sets)
/*     */   {
/*  99 */     List folderList = new ArrayList();
/* 100 */     for (String str : sets) {
/* 101 */       IMenuItem menuItem = (IMenuItem)getHibernateTemplate().get(LkgFuncFolder.class, str);
/* 102 */       folderList.add(menuItem);
/*     */     }
/* 104 */     return folderList;
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getRightsByRoles(List roleIdList) {
/* 108 */     log.debug(" in getRightsByRoles(List roleIdList)...");
/* 109 */     String topMenuId = Configure.getInstance().getProperty("TOP_MENU_ID");
/* 110 */     List result = new ArrayList();
/*     */ 
/* 112 */     StringBuilder sql = new StringBuilder();
/* 113 */     sql.append("      SELECT F                                                                 ");
/* 114 */     sql.append("        FROM LkgFunc F                                                         ");
/* 115 */     sql.append("       WHERE EXISTS (SELECT 1                                                  ");
/* 116 */     sql.append("                FROM LkgJobFunc JF                                             ");
/* 117 */     sql.append("               WHERE F.funcId = JF.id.funcId                                   ");
/* 118 */     sql.append(new StringBuilder().append("                 AND JF.id.jobId IN (").append(list2String(roleIdList)).append("))             ").toString());
/* 119 */     sql.append(new StringBuilder().append("      AND F.funcId like '").append(topMenuId).append("%'                                                  ").toString());
/* 120 */     sql.append("      ORDER BY F.folderId,F.remark                                             ");
/* 121 */     List funcList = getHibernateTemplate().find(sql.toString());
/* 122 */     Set folderIdsSet = new HashSet();
/*     */ 
/* 125 */     if ((funcList != null) && (!funcList.isEmpty())) {
/* 126 */       Sqlca sqlca = null;
/*     */       try {
/* 128 */         sqlca = new Sqlca(new ConnectionEx());
/* 129 */         for (IMenuItem func : funcList) {
/* 130 */           Integer folder_id = func.getParentId();
/* 131 */           List folderIds = getAllFolderIds(sqlca, folder_id);
/* 132 */           for (String folderId : folderIds)
/* 133 */             folderIdsSet.add(folderId);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 137 */         e.printStackTrace();
/* 138 */         throw new ServiceException(e.getMessage());
/*     */       } finally {
/* 140 */         if (sqlca != null) {
/* 141 */           sqlca.closeAll();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 146 */     funcList.addAll(getAllfolders(folderIdsSet));
/*     */ 
/* 148 */     if (funcList != null) {
/* 149 */       for (IMenuItem func : funcList) {
/* 150 */         Right right = new Right();
/* 151 */         right.setRoleType(1);
/* 152 */         right.setResourceId(func.getMenuItemId().toString());
/* 153 */         right.setResourceName(func.getMenuItemTitle());
/* 154 */         right.setParentId(func.getParentId().toString());
/* 155 */         right.setRightId(func.getUrl());
/* 156 */         right.setOperationType("-1");
/* 157 */         right.setOperationName(func.getMenuItemTitle());
/* 158 */         right.setHasCheckFrame(false);
/* 159 */         right.setResourceType(func.getParentId().intValue());
/* 160 */         right.setTopId("0");
/*     */ 
/* 162 */         result.add(right);
/*     */       }
/*     */     }
/* 165 */     return result;
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getMenuItems() {
/* 169 */     log.debug(" in getMenuItems()...");
/* 170 */     List result = new ArrayList();
/* 171 */     String topMenuId = Configure.getInstance().getProperty("TOP_MENU_ID");
/* 172 */     StringBuilder sql = new StringBuilder();
/* 173 */     sql.append("      SELECT F                                                               ");
/* 174 */     sql.append("      FROM LkgFunc F                                                         ");
/* 175 */     sql.append(new StringBuilder().append("      WHERE F.funcId like '").append(topMenuId).append("%'                                            ").toString());
/* 176 */     sql.append("      ORDER BY F.folderId,F.remark                                           ");
/*     */ 
/* 178 */     List funcList = getHibernateTemplate().find(sql.toString());
/* 179 */     Set folderIdsSet = new HashSet();
/*     */ 
/* 182 */     if ((funcList != null) && (!funcList.isEmpty())) {
/* 183 */       Sqlca sqlca = null;
/*     */       try {
/* 185 */         sqlca = new Sqlca(new ConnectionEx());
/* 186 */         for (IMenuItem func : funcList) {
/* 187 */           Integer folder_id = func.getParentId();
/* 188 */           List folderIds = getAllFolderIds(sqlca, folder_id);
/* 189 */           for (String folderId : folderIds)
/* 190 */             folderIdsSet.add(folderId);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 194 */         e.printStackTrace();
/* 195 */         throw new ServiceException(e.getMessage());
/*     */       } finally {
/* 197 */         if (sqlca != null) {
/* 198 */           sqlca.closeAll();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 203 */     funcList.addAll(getAllfolders(folderIdsSet));
/*     */ 
/* 205 */     if (funcList != null) {
/* 206 */       for (IMenuItem func : funcList) {
/* 207 */         Right right = new Right();
/* 208 */         right.setRoleType(1);
/* 209 */         right.setResourceId(func.getMenuItemId().toString());
/* 210 */         right.setResourceName(func.getMenuItemTitle());
/* 211 */         right.setParentId(func.getParentId().toString());
/* 212 */         right.setRightId(func.getUrl());
/* 213 */         right.setOperationType("-1");
/* 214 */         right.setOperationName(func.getMenuItemTitle());
/* 215 */         right.setHasCheckFrame(false);
/* 216 */         right.setResourceType(func.getParentId().intValue());
/* 217 */         right.setTopId("0");
/*     */ 
/* 219 */         result.add(right);
/*     */       }
/*     */     }
/* 222 */     return result;
/*     */   }
/*     */ 
/*     */   private String list2String(List<String> strList) {
/* 226 */     StringBuilder b = new StringBuilder();
/* 227 */     if ((strList != null) && (!strList.isEmpty())) {
/* 228 */       for (String str : strList) {
/* 229 */         b.append("'").append(str).append("',");
/*     */       }
/* 231 */       return b.substring(0, b.length() - 1);
/*     */     }
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */   public IMenuItem getMenuItemById(String memuItemId) {
/* 237 */     return (IMenuItem)getHibernateTemplate().get(LkgFunc.class, memuItemId);
/*     */   }
/*     */ 
/*     */   public List getAllMenu() {
/* 241 */     String topMenuId = Configure.getInstance().getProperty("TOP_MENU_ID");
/*     */ 
/* 243 */     StringBuilder sql = new StringBuilder();
/* 244 */     sql.append("      SELECT F                                                               ");
/* 245 */     sql.append("      FROM LkgFunc F                                                         ");
/* 246 */     sql.append(new StringBuilder().append("      WHERE F.funcId like '").append(topMenuId).append("%'                                            ").toString());
/* 247 */     sql.append("      ORDER BY F.folderId,F.remark                                           ");
/*     */ 
/* 249 */     List funcList = getHibernateTemplate().find(sql.toString());
/*     */ 
/* 251 */     return funcList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.impl.RoleRightMapDaoImpl
 * JD-Core Version:    0.6.2
 */
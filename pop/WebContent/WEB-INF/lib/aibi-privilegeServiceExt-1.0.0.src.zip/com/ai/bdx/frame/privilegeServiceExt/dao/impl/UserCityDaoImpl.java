/*    */ package com.ai.bdx.frame.privilegeServiceExt.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserCityDao;
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserScope;
/*    */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgParamArea;
/*    */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaffScope;
/*    */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.TdEparchyCityMcd;
/*    */ import com.asiainfo.biframe.exception.ServiceException;
/*    */ import com.asiainfo.biframe.privilege.ICity;
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserCityDaoImpl extends HibernateDaoSupport
/*    */   implements IUserCityDao
/*    */ {
/*    */   public List<ICity> getAllCity()
/*    */   {
/* 22 */     List cityList = getHibernateTemplate().find("from TdEparchyCityMcd order by orderId");
/* 23 */     return cityList;
/*    */   }
/*    */ 
/*    */   public List<ICity> getAllCounty()
/*    */   {
/* 28 */     List cityList = getHibernateTemplate().find("from TdCitycode order by orderId");
/* 29 */     return cityList;
/*    */   }
/*    */ 
/*    */   public ICity getCityById(String cityId)
/*    */   {
/* 34 */     ICity city = (ICity)getHibernateTemplate().get(TdEparchyCityMcd.class, cityId);
/* 35 */     return city;
/*    */   }
/*    */ 
/*    */   public ICity getCityByOldId(String cityId)
/*    */   {
/* 40 */     List city = getHibernateTemplate().find("from TdEparchyCityMcd where remark= '" + cityId + "'");
/* 41 */     return (ICity)city.get(0);
/*    */   }
/*    */ 
/*    */   public String getCountryIdByOldId(String countryId) {
/* 45 */     List list = getHibernateTemplate().find("from LkgParamArea where countryId= ?", new Object[] { countryId });
/*    */ 
/* 47 */     return ((LkgParamArea)list.get(0)).getCountryIdNew();
/*    */   }
/*    */ 
/*    */   public List<ICity> getCityByParentId(String parentCityId)
/*    */   {
/* 53 */     List cityList = getHibernateTemplate().find("from TdCitycode uc where uc.eparchyId='" + parentCityId + "' order by orderId");
/*    */ 
/* 55 */     return cityList;
/*    */   }
/*    */ 
/*    */   public IUserScope getUserScope(String userId) throws ServiceException {
/* 59 */     IUserScope userScope = (IUserScope)getHibernateTemplate().get(LkgStaffScope.class, userId);
/* 60 */     return userScope;
/*    */   }
/*    */ 
/*    */   public List<ICity> getCitysByUserId(Map queryMap) throws ServiceException {
/* 64 */     List result = null;
/* 65 */     if (queryMap.containsKey("prov"))
/* 66 */       result = getAllCity();
/* 67 */     else if (queryMap.containsKey("city")) {
/* 68 */       result = getCityByParentId(queryMap.get("city").toString());
/*    */     }
/* 70 */     return result;
/*    */   }
/*    */ 
/*    */   public List<ICity> getRecommendCitysByUserId(Map queryMap) throws ServiceException {
/* 74 */     List result = null;
/* 75 */     if (queryMap.containsKey("prov")) {
/* 76 */       result = getAllCity();
/* 77 */     } else if (queryMap.containsKey("city")) {
/* 78 */       result = new ArrayList();
/* 79 */       ICity city = getCityById(queryMap.get("city").toString());
/* 80 */       result.add(city);
/*    */ 
/* 82 */       ICity cityProvince = getCityById(Configure.getInstance().getProperty("CENTER_CITYID"));
/* 83 */       result.add(cityProvince);
/*    */     }
/* 85 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.impl.UserCityDaoImpl
 * JD-Core Version:    0.6.2
 */
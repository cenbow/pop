/*    */ package com.ai.bdx.frame.privilegeServiceExt.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserDeptDao;
/*    */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaffCompany;
/*    */ import com.asiainfo.biframe.privilege.IUserCompany;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserDeptDaoImpl extends HibernateDaoSupport
/*    */   implements IUserDeptDao
/*    */ {
/*    */   public List<IUserCompany> getDeptAll()
/*    */     throws Exception
/*    */   {
/* 15 */     String hql = " from LkgStaffCompany uc where uc.status='0'";
/* 16 */     List list = getHibernateTemplate().find(hql);
/* 17 */     return list;
/*    */   }
/*    */ 
/*    */   public IUserCompany getDeptById(String deptId) throws Exception
/*    */   {
/* 22 */     IUserCompany com = (IUserCompany)getHibernateTemplate().get(LkgStaffCompany.class, new Integer(deptId));
/* 23 */     return com;
/*    */   }
/*    */ 
/*    */   public List<IUserCompany> getSubCompanyById(String companyId)
/*    */   {
/* 28 */     String hql = " from LkgStaffCompany uc where uc.status='0' and uc.parentid=?";
/* 29 */     List list = getHibernateTemplate().find(hql, new Object[] { companyId });
/* 30 */     return list;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.impl.UserDeptDaoImpl
 * JD-Core Version:    0.6.2
 */
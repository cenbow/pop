/*    */ package com.ai.bdx.frame.privilegeServiceExt.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserGroupMapDao;
/*    */ import com.asiainfo.biframe.privilege.IUser;
/*    */ import com.asiainfo.biframe.privilege.IUserGroup;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserGroupMapDaoImpl extends HibernateDaoSupport
/*    */   implements IUserGroupMapDao
/*    */ {
/* 14 */   private static Logger log = LogManager.getLogger();
/*    */ 
/*    */   public List<IUser> findAllUserByGId(String gid) {
/* 17 */     log.debug("findAllUserByGId UserGroupMap groupid = " + gid);
/*    */ 
/* 20 */     StringBuffer hql = new StringBuffer();
/* 21 */     hql.append("select us from LkgStaff us where us.groupId = '").append(gid).append("'");
/*    */ 
/* 24 */     List userList = getHibernateTemplate().find(hql.toString());
/* 25 */     return userList;
/*    */   }
/*    */ 
/*    */   public List<IUserGroup> getGroupByUserId(List<String> uids)
/*    */   {
/* 35 */     log.debug("findByUserId UserGroupMap userId=" + uids);
/* 36 */     List list = null;
/* 37 */     String uidsw = "";
/* 38 */     for (String uid : uids) {
/* 39 */       uidsw = uidsw + "'" + uid + "',";
/*    */     }
/* 41 */     uidsw = uidsw.substring(0, uidsw.length() - 1);
/*    */ 
/* 44 */     String hql = "select ugm from LkgUserGroup ugm,LkgStaff ug where ugm.groupId=ug.groupId and ug.staffId in (" + uidsw + ")";
/*    */ 
/* 47 */     list = getHibernateTemplate().find(hql);
/* 48 */     return list;
/*    */   }
/*    */ 
/*    */   public List<IUserGroup> getGroupByUserId(String uid) {
/* 52 */     log.debug("findByUserId UserGroupMap userId=" + uid);
/* 53 */     List list = null;
/*    */ 
/* 56 */     String hql = "select ugm from LkgUserGroup ugm,LkgStaff ug where ugm.groupId=ug.groupId and ug.staffId = '" + uid + "'";
/*    */ 
/* 59 */     list = getHibernateTemplate().find(hql);
/* 60 */     return list;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.impl.UserGroupMapDaoImpl
 * JD-Core Version:    0.6.2
 */
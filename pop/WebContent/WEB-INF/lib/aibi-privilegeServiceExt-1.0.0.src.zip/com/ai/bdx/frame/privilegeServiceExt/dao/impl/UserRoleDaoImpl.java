/*    */ package com.ai.bdx.frame.privilegeServiceExt.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserRoleDao;
/*    */ import com.asiainfo.biframe.privilege.IUserRole;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserRoleDaoImpl extends HibernateDaoSupport
/*    */   implements IUserRoleDao
/*    */ {
/* 13 */   private static Logger log = LogManager.getLogger();
/*    */ 
/*    */   public List<IUserRole> findAllRoles() {
/* 16 */     log.debug("get all UserRole list");
/*    */ 
/* 19 */     String sql = "from LkgJob role order by role.jobName ";
/* 20 */     List list = getHibernateTemplate().find(sql);
/*    */ 
/* 22 */     log.debug("list.size=" + list.size());
/* 23 */     return list;
/*    */   }
/*    */ 
/*    */   public List<IUserRole> findRoleListByGroupId(String groupId)
/*    */   {
/* 31 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.impl.UserRoleDaoImpl
 * JD-Core Version:    0.6.2
 */
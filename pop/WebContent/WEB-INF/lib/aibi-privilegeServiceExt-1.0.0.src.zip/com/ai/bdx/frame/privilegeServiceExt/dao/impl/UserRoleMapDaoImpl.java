/*    */ package com.ai.bdx.frame.privilegeServiceExt.dao.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserRoleMapDao;
/*    */ import com.asiainfo.biframe.privilege.IUserRole;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*    */ 
/*    */ public class UserRoleMapDaoImpl extends HibernateDaoSupport
/*    */   implements IUserRoleMapDao
/*    */ {
/*    */   public List<IUserRole> getRolesByUserId(String userId)
/*    */   {
/* 18 */     StringBuffer sql = new StringBuffer();
/* 19 */     sql.append("select ur from LkgStaffJob urm,LkgJob ur where urm.id.jobId=ur.jobId and urm.id.staffId = '").append(userId).append("'");
/*    */ 
/* 23 */     List urmap = getHibernateTemplate().find(sql.toString());
/* 24 */     return urmap;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.impl.UserRoleMapDaoImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.privilegeServiceExt.dao.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserUserDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaff;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.string.DES;
/*     */ import java.util.List;
/*     */ import org.apache.commons.collections.CollectionUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ 
/*     */ public class UserUserDaoImpl extends HibernateDaoSupport
/*     */   implements IUserUserDao
/*     */ {
/*  21 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public List<IUser> listUsers()
/*     */   {
/*  25 */     String sql = "from LkgStaff user order by user.staffName";
/*  26 */     List _users = getHibernateTemplate().find(sql);
/*  27 */     return _users;
/*     */   }
/*     */ 
/*     */   public IUser findById(String id)
/*     */   {
/*  49 */     if (id == null) {
/*  50 */       return null;
/*     */     }
/*  52 */     LkgStaff instance = (LkgStaff)getHibernateTemplate().get(LkgStaff.class, id);
/*  53 */     LkgStaff user = new LkgStaff();
/*  54 */     if (null != instance) {
/*  55 */       BeanUtils.copyProperties(instance, user);
/*     */ 
/*  57 */       if (StringUtils.isNotBlank(instance.getStaffPwd())) {
/*     */         try {
/*  59 */           user.setStaffPwd(DES.decrypt(instance.getStaffPwd()));
/*     */         }
/*     */         catch (Exception e) {
/*  62 */           user.setStaffPwd(instance.getStaffPwd());
/*     */         }
/*     */       }
/*  65 */       if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/*  66 */         List list = getHibernateTemplate().find("select eparchyCode from TdEparchyCityMcd where remark = ?", instance.getCityId());
/*     */ 
/*  68 */         if (CollectionUtils.isNotEmpty(list)) {
/*  69 */           user.setCityId((String)list.get(0));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  74 */     return user;
/*     */   }
/*     */ 
/*     */   public List<IUser> findAll(SearchCondition condition) {
/*  78 */     log.debug("--------------in UserUserDaoImpl.findAll()..........");
/*  79 */     long userDaoTime1 = System.currentTimeMillis();
/*     */ 
/*  81 */     String strCond = getConditionSql(condition);
/*  82 */     String groupIds = condition.getQueryGroupids();
/*     */ 
/*  84 */     StringBuffer listSql = new StringBuffer();
/*  85 */     listSql.append("from LkgStaff as user").append(strCond);
/*     */ 
/*  87 */     if ((groupIds != null) && (groupIds.trim().length() > 0))
/*     */     {
/*  89 */       listSql.append("select user from LkgStaff user, UserGroupMap groupMap ").append(strCond);
/*     */     }
/*     */ 
/*  92 */     log.debug("--findAll:sql:" + listSql);
/*     */ 
/*  94 */     long userDaoTime2 = System.currentTimeMillis();
/*     */ 
/*  96 */     log.debug(new StringBuilder(64).append("userDaoTime2-userDaoTime1=").append(userDaoTime2 - userDaoTime1));
/*  97 */     List list = getHibernateTemplate().find(listSql.toString());
/*  98 */     log.debug("-----------------list.size=" + list.size());
/*     */ 
/* 100 */     long userDaoTime3 = System.currentTimeMillis();
/* 101 */     log.debug(new StringBuilder(64).append("userDaoTime3-userDaoTime2=").append(userDaoTime3 - userDaoTime2));
/*     */ 
/* 103 */     return list;
/*     */   }
/*     */ 
/*     */   private String getConditionSql(SearchCondition condition) {
/* 107 */     String sql = " where 1=1";
/* 108 */     if ((condition.getQueryUserid() != null) && (condition.getQueryUserid().trim().length() > 0))
/*     */     {
/* 111 */       sql = sql + " and user.staffId like '%" + condition.getQueryUserid() + "%'";
/*     */     }
/* 113 */     if ((condition.getQueryUsername() != null) && (condition.getQueryUsername().trim().length() > 0))
/*     */     {
/* 116 */       sql = sql + " and user.staffName like '%" + condition.getQueryUsername() + "%'";
/*     */     }
/* 118 */     if ((StringUtils.isNotBlank(condition.getQueryCityid())) && (!"-1".equalsIgnoreCase(condition.getQueryCityid())))
/*     */     {
/* 121 */       sql = sql + " and user.cityId='" + condition.getQueryCityid() + "'";
/*     */     }
/*     */ 
/* 124 */     if ((condition.getQueryDutyid() != null) && (condition.getQueryDutyid().intValue() > 0))
/*     */     {
/* 126 */       sql = sql + " and user.dutyid=" + condition.getQueryDutyid() + "";
/*     */     }
/*     */ 
/* 129 */     if (condition.getQueryDepartmentid() > 0)
/*     */     {
/* 131 */       sql = sql + " and user.depId='" + condition.getQueryDepartmentid() + "'";
/*     */     }
/* 133 */     if (condition.getQueryStatus() != -1)
/*     */     {
/* 135 */       sql = sql + " and user.status='" + condition.getQueryStatus() + "'";
/*     */     }
/* 137 */     if ((condition.getQueryUserids() != null) && (condition.getQueryUserids().trim().length() > 0)) {
/* 138 */       String sqlin = "";
/* 139 */       String roles = "";
/* 140 */       String[] strRolesArry = condition.getQueryUserids().split(",");
/* 141 */       int cnt = 1;
/* 142 */       if (strRolesArry.length > 1000) {
/* 143 */         int nDeep = 0;
/* 144 */         for (int i = 0; i < strRolesArry.length; i++) {
/* 145 */           roles = roles + strRolesArry[i] + ",";
/* 146 */           cnt++;
/* 147 */           if (cnt > 1000) {
/* 148 */             if (nDeep == 0) {
/* 149 */               sqlin = sqlin + " and (";
/*     */             }
/* 151 */             if (nDeep > 0) {
/* 152 */               sqlin = sqlin + " or ";
/*     */             }
/*     */ 
/* 157 */             sqlin = sqlin + "  user.staffId in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/* 158 */             roles = "";
/* 159 */             cnt = 1;
/* 160 */             nDeep++;
/*     */           }
/*     */         }
/* 163 */         if (roles.length() > 0) {
/* 164 */           if (nDeep == 0) {
/* 165 */             sqlin = sqlin + " and (";
/*     */           }
/* 167 */           if (nDeep > 0) {
/* 168 */             sqlin = sqlin + " or ";
/*     */           }
/*     */ 
/* 171 */           sqlin = sqlin + " user.staffId in(" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/*     */         }
/* 173 */         sqlin = sqlin + ")";
/*     */       }
/*     */       else {
/* 176 */         sqlin = " and user.staffId in (" + condition.getQueryUserids() + ") ";
/*     */       }
/*     */ 
/* 179 */       sql = sql + sqlin;
/*     */     }
/*     */ 
/* 182 */     if ((condition.getQueryGroupids() != null) && (condition.getQueryGroupids().trim().length() > 0)) {
/* 183 */       String sqlin = "";
/* 184 */       String roles = "";
/* 185 */       String[] strRolesArry = condition.getQueryGroupids().split(",");
/* 186 */       int cnt = 1;
/* 187 */       if (strRolesArry.length > 1000) {
/* 188 */         int nDeep = 0;
/* 189 */         for (int i = 0; i < strRolesArry.length; i++) {
/* 190 */           roles = roles + strRolesArry[i] + ",";
/* 191 */           cnt++;
/* 192 */           if (cnt > 1000) {
/* 193 */             if (nDeep == 0) {
/* 194 */               sqlin = sqlin + " and (";
/*     */             }
/* 196 */             if (nDeep > 0) {
/* 197 */               sqlin = sqlin + " or ";
/*     */             }
/*     */ 
/* 202 */             sqlin = sqlin + "  groupMap.groupId in (" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/* 203 */             roles = "";
/* 204 */             cnt = 1;
/* 205 */             nDeep++;
/*     */           }
/*     */         }
/* 208 */         if (roles.length() > 0) {
/* 209 */           if (nDeep == 0) {
/* 210 */             sqlin = sqlin + " and (";
/*     */           }
/* 212 */           if (nDeep > 0) {
/* 213 */             sqlin = sqlin + " or ";
/*     */           }
/*     */ 
/* 217 */           sqlin = sqlin + " groupMap.groupId in(" + roles.substring(0, roles.lastIndexOf(",")) + ") ";
/*     */         }
/* 219 */         sqlin = sqlin + ")";
/*     */       }
/*     */       else {
/* 222 */         sqlin = " and groupMap.groupId in (" + condition.getQueryGroupids() + ") ";
/*     */       }
/*     */ 
/* 225 */       sql = sql + " and user.staffId=groupMap.userid " + sqlin;
/*     */     }
/*     */ 
/* 228 */     if ((condition.getBeginDeleteTime() != null) && (condition.getEndDeleteTime() == null))
/*     */     {
/* 231 */       sql = sql + " and user.deleteTime >= '" + condition.getBeginDeleteTime() + "'";
/*     */     }
/* 233 */     if ((condition.getBeginDeleteTime() == null) && (condition.getEndDeleteTime() != null))
/*     */     {
/* 236 */       sql = sql + " and user.deleteTime <= '" + condition.getEndDeleteTime() + "'";
/*     */     }
/*     */ 
/* 239 */     if ((condition.getBeginDeleteTime() != null) && (condition.getEndDeleteTime() != null))
/*     */     {
/* 244 */       sql = sql + " and user.deleteTime >= '" + condition.getBeginDeleteTime() + "'";
/* 245 */       sql = sql + " and user.deleteTime <= '" + condition.getEndDeleteTime() + "'";
/*     */     }
/*     */ 
/* 248 */     return sql;
/*     */   }
/*     */ 
/*     */   public LkgStaff findEntityById(String id) {
/* 252 */     log.debug("getting LkgStaff instance with id: " + id);
/* 253 */     if (id == null) {
/* 254 */       return null;
/*     */     }
/* 256 */     LkgStaff instance = (LkgStaff)getHibernateTemplate().get(LkgStaff.class, id);
/* 257 */     return instance;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.dao.impl.UserUserDaoImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.privilegeServiceExt.listener;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.base.constants.UserManager;
/*     */ import com.asiainfo.biframe.privilege.base.vo.PrivilegeUserSession;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.spring.SystemServiceLocator;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.Serializable;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionBindingEvent;
/*     */ import javax.servlet.http.HttpSessionBindingListener;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class SessionListener
/*     */   implements HttpSessionBindingListener, Serializable
/*     */ {
/*  28 */   private static Logger log = LogManager.getLogger();
/*     */   private static final long serialVersionUID = -1334939621828913344L;
/*  30 */   private IUser m_User = null;
/*  31 */   private String m_strLoginOAUser = "";
/*  32 */   private String m_strSessionID = null;
/*  33 */   private String m_strClientIP = null;
/*  34 */   private String m_strServerAddress = "";
/*  35 */   private String m_browser_version = "";
/*     */   public static final String LOGOUTTYPE_ZHUDONG = "1";
/*     */   public static final String LOGOUTTYPE_BEIDONG = "2";
/*     */ 
/*     */   public static String getIpAddr(HttpServletRequest request)
/*     */   {
/*  46 */     String ip = request.getHeader("x-forwarded-for");
/*  47 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  48 */       ip = request.getHeader("Proxy-Client-IP");
/*     */     }
/*  50 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  51 */       ip = request.getHeader("WL-Proxy-Client-IP");
/*     */     }
/*  53 */     if ((ip == null) || (ip.length() == 0) || ("unknown".equalsIgnoreCase(ip))) {
/*  54 */       ip = request.getRemoteAddr();
/*     */     }
/*  56 */     String[] ips = null;
/*  57 */     if (StringUtil.isNotEmpty(ip)) {
/*  58 */       ips = ip.split(",");
/*  59 */       return ips[0];
/*     */     }
/*  61 */     return ip;
/*     */   }
/*     */ 
/*     */   public static SessionListener login(HttpServletRequest request, String strUserID, String strOaUser)
/*     */     throws Exception
/*     */   {
/*  74 */     SessionListener session = new SessionListener();
/*  75 */     session.m_strClientIP = getIpAddr(request);
/*     */ 
/*  77 */     session.m_strSessionID = request.getSession().getId();
/*  78 */     session.m_strLoginOAUser = strOaUser;
/*  79 */     session.m_browser_version = getBrowserVersion(request.getHeader("user-agent"));
/*  80 */     log.info("[SessionListener] login sessionid=====" + session.m_strSessionID);
/*     */     try {
/*  82 */       session.m_strServerAddress = UserManager.getHostAddress();
/*     */     } catch (Exception exceo) {
/*  84 */       session.m_strServerAddress = "127.0.0.1";
/*     */     }
/*     */ 
/*  87 */     Sqlca sqlca = null;
/*     */     try {
/*  89 */       IUserPrivilegeCommonService userService = (IUserPrivilegeCommonService)SystemServiceLocator.getInstance().getService("userPrivilegeCommonService");
/*     */ 
/*  91 */       session.m_User = userService.getUser(strUserID);
/*     */ 
/*  96 */       if (null != sqlca)
/*  97 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/*  93 */       excep.printStackTrace();
/*  94 */       throw excep;
/*     */     } finally {
/*  96 */       if (null != sqlca) {
/*  97 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 100 */     return session;
/*     */   }
/*     */ 
/*     */   public String getUserID() throws Exception {
/* 104 */     return this.m_User.getUserid();
/*     */   }
/*     */ 
/*     */   public IUser getUser() throws Exception {
/* 108 */     return this.m_User;
/*     */   }
/*     */ 
/*     */   public String getUserName() throws Exception {
/* 112 */     return this.m_User.getUsername();
/*     */   }
/*     */ 
/*     */   public String getUserRoles()
/*     */     throws Exception
/*     */   {
/* 121 */     return this.m_User.getGroupId();
/*     */   }
/*     */ 
/*     */   public void valueBound(HttpSessionBindingEvent event)
/*     */   {
/* 129 */     Sqlca sqlca = null;
/*     */     try {
/* 131 */       sqlca = new Sqlca(new ConnectionEx());
/* 132 */       sqlca.setAutoCommit(false);
/*     */ 
/* 148 */       String oaUserId = "";
/* 149 */       PrivilegeUserSession sessionUser = new PrivilegeUserSession();
/* 150 */       sessionUser.setUser(this.m_User);
/* 151 */       sessionUser.setClientIp(this.m_strClientIP);
/* 152 */       sessionUser.setSessionId(this.m_strSessionID);
/* 153 */       sessionUser.setOaUserId(this.m_strLoginOAUser);
/* 154 */       sessionUser.setGroupId(this.m_User.getGroupId() == null ? "" : this.m_User.getGroupId());
/* 155 */       IUserPrivilegeCommonService privilegeService = (IUserPrivilegeCommonService)SystemServiceLocator.getInstance().getService("userPrivilegeCommonService");
/*     */ 
/* 157 */       if (privilegeService.isAdminUser(this.m_User.getUserid()))
/* 158 */         sessionUser.setGroupId("1");
/*     */       else {
/* 160 */         sessionUser.setGroupId("0");
/*     */       }
/*     */ 
/* 163 */       event.getSession().setAttribute("biplatform_user", sessionUser);
/* 164 */       log.info("[SessionListener] --valueBound put PrivilegeUserSession into \"biplatform_user\"");
/*     */ 
/* 168 */       if (null != sqlca)
/* 169 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 166 */       e.printStackTrace();
/*     */ 
/* 168 */       if (null != sqlca)
/* 169 */         sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 168 */       if (null != sqlca)
/* 169 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void valueUnbound(HttpSessionBindingEvent event)
/*     */   {
/* 178 */     Sqlca sqlca = null;
/*     */     try {
/* 180 */       sqlca = new Sqlca(new ConnectionEx());
/* 181 */       sqlca.setAutoCommit(false);
/*     */ 
/* 197 */       if (null != sqlca)
/* 198 */         sqlca.closeAll();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 195 */       e.printStackTrace();
/*     */ 
/* 197 */       if (null != sqlca)
/* 198 */         sqlca.closeAll();
/*     */     }
/*     */     finally
/*     */     {
/* 197 */       if (null != sqlca)
/* 198 */         sqlca.closeAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getBrowserVersion(String user_agent)
/*     */   {
/* 209 */     if (user_agent.indexOf("MSIE 6.0") > 0) {
/* 210 */       return "IE 6.0";
/*     */     }
/* 212 */     if (user_agent.indexOf("MSIE 8.0") > 0) {
/* 213 */       return "IE 8.0";
/*     */     }
/* 215 */     if (user_agent.indexOf("MSIE 7.0") > 0) {
/* 216 */       return "IE 7.0";
/*     */     }
/* 218 */     if (user_agent.indexOf("MSIE 5.5") > 0) {
/* 219 */       return "IE 5.5";
/*     */     }
/* 221 */     if (user_agent.indexOf("MSIE 5.01") > 0) {
/* 222 */       return "IE 5.01";
/*     */     }
/* 224 */     if (user_agent.indexOf("MSIE 5.0") > 0) {
/* 225 */       return "IE 5.0";
/*     */     }
/* 227 */     if (user_agent.indexOf("MSIE 4.0") > 0) {
/* 228 */       return "IE 4.0";
/*     */     }
/* 230 */     if (user_agent.indexOf("Firefox") > 0) {
/* 231 */       return "Firefox";
/*     */     }
/* 233 */     if (user_agent.indexOf("Netscape") > 0) {
/* 234 */       return "Netscape";
/*     */     }
/* 236 */     if (user_agent.indexOf("Opera") > 0) {
/* 237 */       return "Opera";
/*     */     }
/* 239 */     return "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.other") + "";
/*     */   }
/*     */ 
/*     */   public String getM_strLoginOAUser() {
/* 243 */     return this.m_strLoginOAUser;
/*     */   }
/*     */ 
/*     */   public void setM_strLoginOAUser(String mStrLoginOAUser) {
/* 247 */     this.m_strLoginOAUser = mStrLoginOAUser;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.listener.SessionListener
 * JD-Core Version:    0.6.2
 */
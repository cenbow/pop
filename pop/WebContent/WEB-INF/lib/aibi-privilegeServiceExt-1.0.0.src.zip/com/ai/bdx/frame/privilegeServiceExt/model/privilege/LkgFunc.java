/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LkgFunc
/*     */   implements Serializable, IMenuItem, Comparable<LkgFunc>
/*     */ {
/*     */   private static final long serialVersionUID = 6928748296574655412L;
/*     */   private String funcId;
/*     */   private String sysId;
/*     */   private String funcName;
/*     */   private String pageUrl;
/*     */   private String folderId;
/*     */   private String remark;
/*     */   private String back1NameFlag;
/*     */   private String back2NameFlag;
/*     */   private String back3NameFlag;
/*     */   private String back4NameFlag;
/*     */   private String back5NameFlag;
/*     */   private String back6NameFlag;
/*     */   private String startDate;
/*     */   private String endDate;
/*     */   private String adminId;
/*     */   private String adminName;
/*     */   private String adminTime;
/*     */   private String dealState;
/*     */   private String useState;
/*     */   private String placeState;
/*     */   private String dsType;
/*     */   private String operType;
/*     */   private String operSubType;
/*     */   private String funcOrder;
/*     */   private LkgFuncFolder funcFolder;
/*     */ 
/*     */   public String getFuncId()
/*     */   {
/*  49 */     return this.funcId;
/*     */   }
/*     */ 
/*     */   public void setFuncId(String funcId) {
/*  53 */     this.funcId = funcId;
/*     */   }
/*     */ 
/*     */   public String getSysId() {
/*  57 */     return this.sysId;
/*     */   }
/*     */ 
/*     */   public void setSysId(String sysId) {
/*  61 */     this.sysId = sysId;
/*     */   }
/*     */ 
/*     */   public String getFuncName() {
/*  65 */     return this.funcName;
/*     */   }
/*     */ 
/*     */   public void setFuncName(String funcName) {
/*  69 */     this.funcName = funcName;
/*     */   }
/*     */ 
/*     */   public String getPageUrl() {
/*  73 */     return this.pageUrl;
/*     */   }
/*     */ 
/*     */   public void setPageUrl(String pageUrl) {
/*  77 */     this.pageUrl = pageUrl;
/*     */   }
/*     */ 
/*     */   public String getFolderId() {
/*  81 */     return this.folderId;
/*     */   }
/*     */ 
/*     */   public void setFolderId(String folderId) {
/*  85 */     this.folderId = folderId;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/*  89 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/*  93 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getBack1NameFlag() {
/*  97 */     return this.back1NameFlag;
/*     */   }
/*     */ 
/*     */   public void setBack1NameFlag(String back1NameFlag) {
/* 101 */     this.back1NameFlag = back1NameFlag;
/*     */   }
/*     */ 
/*     */   public String getBack2NameFlag() {
/* 105 */     return this.back2NameFlag;
/*     */   }
/*     */ 
/*     */   public void setBack2NameFlag(String back2NameFlag) {
/* 109 */     this.back2NameFlag = back2NameFlag;
/*     */   }
/*     */ 
/*     */   public String getBack3NameFlag() {
/* 113 */     return this.back3NameFlag;
/*     */   }
/*     */ 
/*     */   public void setBack3NameFlag(String back3NameFlag) {
/* 117 */     this.back3NameFlag = back3NameFlag;
/*     */   }
/*     */ 
/*     */   public String getBack4NameFlag() {
/* 121 */     return this.back4NameFlag;
/*     */   }
/*     */ 
/*     */   public void setBack4NameFlag(String back4NameFlag) {
/* 125 */     this.back4NameFlag = back4NameFlag;
/*     */   }
/*     */ 
/*     */   public String getBack5NameFlag() {
/* 129 */     return this.back5NameFlag;
/*     */   }
/*     */ 
/*     */   public void setBack5NameFlag(String back5NameFlag) {
/* 133 */     this.back5NameFlag = back5NameFlag;
/*     */   }
/*     */ 
/*     */   public String getBack6NameFlag() {
/* 137 */     return this.back6NameFlag;
/*     */   }
/*     */ 
/*     */   public void setBack6NameFlag(String back6NameFlag) {
/* 141 */     this.back6NameFlag = back6NameFlag;
/*     */   }
/*     */ 
/*     */   public String getStartDate() {
/* 145 */     return this.startDate;
/*     */   }
/*     */ 
/*     */   public void setStartDate(String startDate) {
/* 149 */     this.startDate = startDate;
/*     */   }
/*     */ 
/*     */   public String getEndDate() {
/* 153 */     return this.endDate;
/*     */   }
/*     */ 
/*     */   public void setEndDate(String endDate) {
/* 157 */     this.endDate = endDate;
/*     */   }
/*     */ 
/*     */   public String getAdminId() {
/* 161 */     return this.adminId;
/*     */   }
/*     */ 
/*     */   public void setAdminId(String adminId) {
/* 165 */     this.adminId = adminId;
/*     */   }
/*     */ 
/*     */   public String getAdminName() {
/* 169 */     return this.adminName;
/*     */   }
/*     */ 
/*     */   public void setAdminName(String adminName) {
/* 173 */     this.adminName = adminName;
/*     */   }
/*     */ 
/*     */   public String getAdminTime() {
/* 177 */     return this.adminTime;
/*     */   }
/*     */ 
/*     */   public void setAdminTime(String adminTime) {
/* 181 */     this.adminTime = adminTime;
/*     */   }
/*     */ 
/*     */   public String getDealState() {
/* 185 */     return this.dealState;
/*     */   }
/*     */ 
/*     */   public void setDealState(String dealState) {
/* 189 */     this.dealState = dealState;
/*     */   }
/*     */ 
/*     */   public String getUseState() {
/* 193 */     return this.useState;
/*     */   }
/*     */ 
/*     */   public void setUseState(String useState) {
/* 197 */     this.useState = useState;
/*     */   }
/*     */ 
/*     */   public String getPlaceState() {
/* 201 */     return this.placeState;
/*     */   }
/*     */ 
/*     */   public void setPlaceState(String placeState) {
/* 205 */     this.placeState = placeState;
/*     */   }
/*     */ 
/*     */   public String getDsType() {
/* 209 */     return this.dsType;
/*     */   }
/*     */ 
/*     */   public void setDsType(String dsType) {
/* 213 */     this.dsType = dsType;
/*     */   }
/*     */ 
/*     */   public String getOperType() {
/* 217 */     return this.operType;
/*     */   }
/*     */ 
/*     */   public void setOperType(String operType) {
/* 221 */     this.operType = operType;
/*     */   }
/*     */ 
/*     */   public String getOperSubType() {
/* 225 */     return this.operSubType;
/*     */   }
/*     */ 
/*     */   public void setOperSubType(String operSubType) {
/* 229 */     this.operSubType = operSubType;
/*     */   }
/*     */ 
/*     */   public Integer getAccessToken() {
/* 233 */     return Integer.valueOf(0);
/*     */   }
/*     */ 
/*     */   public String getApplicationId() {
/* 237 */     return this.sysId;
/*     */   }
/*     */ 
/*     */   public Integer getMenuItemId() {
/* 241 */     return Integer.valueOf(Integer.parseInt(getFuncId()));
/*     */   }
/*     */ 
/*     */   public String getMenuItemTitle() {
/* 245 */     return getFuncName();
/*     */   }
/*     */ 
/*     */   public Integer getMenuType() {
/* 249 */     return Integer.valueOf(0);
/*     */   }
/*     */ 
/*     */   public String getOperationType() {
/* 253 */     return null;
/*     */   }
/*     */ 
/*     */   public Integer getParentId() {
/* 257 */     return Integer.valueOf(Integer.parseInt(getFolderId()));
/*     */   }
/*     */ 
/*     */   public String getResId() {
/* 261 */     return null;
/*     */   }
/*     */ 
/*     */   public Integer getResourceType() {
/* 265 */     return Integer.valueOf(0);
/*     */   }
/*     */ 
/*     */   public Integer getSortNum() {
/* 269 */     return Integer.valueOf(Integer.parseInt(getRemark()));
/*     */   }
/*     */ 
/*     */   public String getUrl() {
/* 273 */     return getPageUrl();
/*     */   }
/*     */ 
/*     */   public String getUrlPort() {
/* 277 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUrlTarget() {
/* 281 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isFolderOrNot() {
/* 285 */     return false;
/*     */   }
/*     */ 
/*     */   public String getPic1()
/*     */   {
/* 290 */     return null;
/*     */   }
/*     */ 
/*     */   public String getPic2()
/*     */   {
/* 295 */     return null;
/*     */   }
/*     */ 
/*     */   public LkgFuncFolder getFuncFolder() {
/* 299 */     return this.funcFolder;
/*     */   }
/*     */ 
/*     */   public void setFuncFolder(LkgFuncFolder funcFolder) {
/* 303 */     this.funcFolder = funcFolder;
/*     */   }
/*     */ 
/*     */   public String getFuncOrder() {
/* 307 */     return this.funcOrder;
/*     */   }
/*     */ 
/*     */   public void setFuncOrder(String funcOrder) {
/* 311 */     this.funcOrder = funcOrder;
/*     */   }
/*     */ 
/*     */   public int compareTo(LkgFunc o)
/*     */   {
/* 316 */     return getFuncId().compareTo(o.getFuncId());
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgFunc
 * JD-Core Version:    0.6.2
 */
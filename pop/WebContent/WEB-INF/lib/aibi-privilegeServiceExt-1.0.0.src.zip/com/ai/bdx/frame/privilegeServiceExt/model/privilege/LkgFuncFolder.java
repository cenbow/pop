/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class LkgFuncFolder
/*     */   implements Serializable
/*     */ {
/*     */   private String folderId;
/*     */   private String sysId;
/*     */   private String folderName;
/*     */   private String levelId;
/*     */   private String parentId;
/*     */   private String priorId;
/*     */   private String remark;
/*     */   private String adminId;
/*     */   private String adminName;
/*     */   private String adminTime;
/*     */   private String menuUrl;
/*     */   private String mainUrl;
/*     */   private String noValidateUrl;
/*     */   private String menuWidth;
/*     */   private String menuOrder;
/*     */   private LkgFuncFolder parentFolder;
/*     */   private Set<LkgFunc> functions;
/*     */ 
/*     */   public LkgFuncFolder()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgFuncFolder(String folderId)
/*     */   {
/*  50 */     this.folderId = folderId;
/*     */   }
/*     */ 
/*     */   public String getFolderId()
/*     */   {
/*  56 */     return this.folderId;
/*     */   }
/*     */ 
/*     */   public void setFolderId(String folderId) {
/*  60 */     this.folderId = folderId;
/*     */   }
/*     */ 
/*     */   public String getSysId() {
/*  64 */     return this.sysId;
/*     */   }
/*     */ 
/*     */   public void setSysId(String sysId) {
/*  68 */     this.sysId = sysId;
/*     */   }
/*     */ 
/*     */   public String getFolderName() {
/*  72 */     return this.folderName;
/*     */   }
/*     */ 
/*     */   public void setFolderName(String folderName) {
/*  76 */     this.folderName = folderName;
/*     */   }
/*     */ 
/*     */   public String getLevelId() {
/*  80 */     return this.levelId;
/*     */   }
/*     */ 
/*     */   public void setLevelId(String levelId) {
/*  84 */     this.levelId = levelId;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/*  88 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setParentId(String parentId) {
/*  92 */     this.parentId = parentId;
/*     */   }
/*     */ 
/*     */   public String getPriorId() {
/*  96 */     return this.priorId;
/*     */   }
/*     */ 
/*     */   public void setPriorId(String priorId) {
/* 100 */     this.priorId = priorId;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 104 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/* 108 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getAdminId() {
/* 112 */     return this.adminId;
/*     */   }
/*     */ 
/*     */   public void setAdminId(String adminId) {
/* 116 */     this.adminId = adminId;
/*     */   }
/*     */ 
/*     */   public String getAdminName() {
/* 120 */     return this.adminName;
/*     */   }
/*     */ 
/*     */   public void setAdminName(String adminName) {
/* 124 */     this.adminName = adminName;
/*     */   }
/*     */ 
/*     */   public String getAdminTime() {
/* 128 */     return this.adminTime;
/*     */   }
/*     */ 
/*     */   public void setAdminTime(String adminTime) {
/* 132 */     this.adminTime = adminTime;
/*     */   }
/*     */ 
/*     */   public String getMenuUrl() {
/* 136 */     return this.menuUrl;
/*     */   }
/*     */ 
/*     */   public void setMenuUrl(String menuUrl) {
/* 140 */     this.menuUrl = menuUrl;
/*     */   }
/*     */ 
/*     */   public String getMainUrl() {
/* 144 */     return this.mainUrl;
/*     */   }
/*     */ 
/*     */   public void setMainUrl(String mainUrl) {
/* 148 */     this.mainUrl = mainUrl;
/*     */   }
/*     */ 
/*     */   public String getNoValidateUrl() {
/* 152 */     return this.noValidateUrl;
/*     */   }
/*     */ 
/*     */   public void setNoValidateUrl(String noValidateUrl) {
/* 156 */     this.noValidateUrl = noValidateUrl;
/*     */   }
/*     */ 
/*     */   public String getMenuWidth() {
/* 160 */     return this.menuWidth;
/*     */   }
/*     */ 
/*     */   public void setMenuWidth(String menuWidth) {
/* 164 */     this.menuWidth = menuWidth;
/*     */   }
/*     */ 
/*     */   public String getMenuOrder() {
/* 168 */     return this.menuOrder;
/*     */   }
/*     */ 
/*     */   public void setMenuOrder(String menuOrder) {
/* 172 */     this.menuOrder = menuOrder;
/*     */   }
/*     */ 
/*     */   public Integer getAccessToken()
/*     */   {
/* 177 */     return Integer.valueOf(0);
/*     */   }
/*     */ 
/*     */   public String getApplicationId()
/*     */   {
/* 182 */     return this.sysId;
/*     */   }
/*     */ 
/*     */   public Integer getMenuItemId()
/*     */   {
/* 187 */     return Integer.valueOf(Integer.parseInt(getFolderId()));
/*     */   }
/*     */ 
/*     */   public String getMenuItemTitle()
/*     */   {
/* 192 */     return getFolderName();
/*     */   }
/*     */ 
/*     */   public Integer getMenuType()
/*     */   {
/* 197 */     return Integer.valueOf(0);
/*     */   }
/*     */ 
/*     */   public String getOperationType()
/*     */   {
/* 202 */     return null;
/*     */   }
/*     */ 
/*     */   public String getResId()
/*     */   {
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */   public Integer getResourceType()
/*     */   {
/* 212 */     return Integer.valueOf(0);
/*     */   }
/*     */ 
/*     */   public Integer getSortNum()
/*     */   {
/* 217 */     return Integer.valueOf(Integer.parseInt(getMenuOrder()));
/*     */   }
/*     */ 
/*     */   public String getUrl()
/*     */   {
/* 222 */     return getMainUrl();
/*     */   }
/*     */ 
/*     */   public String getUrlPort()
/*     */   {
/* 227 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUrlTarget()
/*     */   {
/* 232 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isFolderOrNot()
/*     */   {
/* 237 */     return true;
/*     */   }
/*     */ 
/*     */   public String getPic1()
/*     */   {
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */   public String getPic2()
/*     */   {
/* 247 */     return null;
/*     */   }
/*     */ 
/*     */   public LkgFuncFolder getParentFolder() {
/* 251 */     return this.parentFolder;
/*     */   }
/*     */ 
/*     */   public void setParentFolder(LkgFuncFolder parentFolder) {
/* 255 */     this.parentFolder = parentFolder;
/*     */   }
/*     */ 
/*     */   public Set<LkgFunc> getFunctions() {
/* 259 */     return this.functions;
/*     */   }
/*     */ 
/*     */   public void setFunctions(Set<LkgFunc> functions) {
/* 263 */     this.functions = functions;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 268 */     int prime = 31;
/* 269 */     int result = 1;
/* 270 */     result = 31 * result + (this.adminId == null ? 0 : this.adminId.hashCode());
/* 271 */     result = 31 * result + (this.adminName == null ? 0 : this.adminName.hashCode());
/*     */ 
/* 273 */     result = 31 * result + (this.adminTime == null ? 0 : this.adminTime.hashCode());
/*     */ 
/* 275 */     result = 31 * result + (this.folderId == null ? 0 : this.folderId.hashCode());
/*     */ 
/* 277 */     result = 31 * result + (this.folderName == null ? 0 : this.folderName.hashCode());
/*     */ 
/* 279 */     result = 31 * result + (this.functions == null ? 0 : this.functions.hashCode());
/*     */ 
/* 281 */     result = 31 * result + (this.levelId == null ? 0 : this.levelId.hashCode());
/* 282 */     result = 31 * result + (this.mainUrl == null ? 0 : this.mainUrl.hashCode());
/* 283 */     result = 31 * result + (this.menuOrder == null ? 0 : this.menuOrder.hashCode());
/*     */ 
/* 285 */     result = 31 * result + (this.menuUrl == null ? 0 : this.menuUrl.hashCode());
/* 286 */     result = 31 * result + (this.menuWidth == null ? 0 : this.menuWidth.hashCode());
/*     */ 
/* 288 */     result = 31 * result + (this.noValidateUrl == null ? 0 : this.noValidateUrl.hashCode());
/*     */ 
/* 290 */     result = 31 * result + (this.parentFolder == null ? 0 : this.parentFolder.hashCode());
/*     */ 
/* 292 */     result = 31 * result + (this.parentId == null ? 0 : this.parentId.hashCode());
/*     */ 
/* 294 */     result = 31 * result + (this.priorId == null ? 0 : this.priorId.hashCode());
/* 295 */     result = 31 * result + (this.remark == null ? 0 : this.remark.hashCode());
/* 296 */     result = 31 * result + (this.sysId == null ? 0 : this.sysId.hashCode());
/* 297 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 302 */     if (this == obj)
/* 303 */       return true;
/* 304 */     if (obj == null)
/* 305 */       return false;
/* 306 */     if (getClass() != obj.getClass())
/* 307 */       return false;
/* 308 */     LkgFuncFolder other = (LkgFuncFolder)obj;
/* 309 */     if (this.adminId == null) {
/* 310 */       if (other.adminId != null)
/* 311 */         return false;
/* 312 */     } else if (!this.adminId.equals(other.adminId))
/* 313 */       return false;
/* 314 */     if (this.adminName == null) {
/* 315 */       if (other.adminName != null)
/* 316 */         return false;
/* 317 */     } else if (!this.adminName.equals(other.adminName))
/* 318 */       return false;
/* 319 */     if (this.adminTime == null) {
/* 320 */       if (other.adminTime != null)
/* 321 */         return false;
/* 322 */     } else if (!this.adminTime.equals(other.adminTime))
/* 323 */       return false;
/* 324 */     if (this.folderId == null) {
/* 325 */       if (other.folderId != null)
/* 326 */         return false;
/* 327 */     } else if (!this.folderId.equals(other.folderId))
/* 328 */       return false;
/* 329 */     if (this.folderName == null) {
/* 330 */       if (other.folderName != null)
/* 331 */         return false;
/* 332 */     } else if (!this.folderName.equals(other.folderName))
/* 333 */       return false;
/* 334 */     if (this.functions == null) {
/* 335 */       if (other.functions != null)
/* 336 */         return false;
/* 337 */     } else if (!this.functions.equals(other.functions))
/* 338 */       return false;
/* 339 */     if (this.levelId == null) {
/* 340 */       if (other.levelId != null)
/* 341 */         return false;
/* 342 */     } else if (!this.levelId.equals(other.levelId))
/* 343 */       return false;
/* 344 */     if (this.mainUrl == null) {
/* 345 */       if (other.mainUrl != null)
/* 346 */         return false;
/* 347 */     } else if (!this.mainUrl.equals(other.mainUrl))
/* 348 */       return false;
/* 349 */     if (this.menuOrder == null) {
/* 350 */       if (other.menuOrder != null)
/* 351 */         return false;
/* 352 */     } else if (!this.menuOrder.equals(other.menuOrder))
/* 353 */       return false;
/* 354 */     if (this.menuUrl == null) {
/* 355 */       if (other.menuUrl != null)
/* 356 */         return false;
/* 357 */     } else if (!this.menuUrl.equals(other.menuUrl))
/* 358 */       return false;
/* 359 */     if (this.menuWidth == null) {
/* 360 */       if (other.menuWidth != null)
/* 361 */         return false;
/* 362 */     } else if (!this.menuWidth.equals(other.menuWidth))
/* 363 */       return false;
/* 364 */     if (this.noValidateUrl == null) {
/* 365 */       if (other.noValidateUrl != null)
/* 366 */         return false;
/* 367 */     } else if (!this.noValidateUrl.equals(other.noValidateUrl))
/* 368 */       return false;
/* 369 */     if (this.parentFolder == null) {
/* 370 */       if (other.parentFolder != null)
/* 371 */         return false;
/* 372 */     } else if (!this.parentFolder.equals(other.parentFolder))
/* 373 */       return false;
/* 374 */     if (this.parentId == null) {
/* 375 */       if (other.parentId != null)
/* 376 */         return false;
/* 377 */     } else if (!this.parentId.equals(other.parentId))
/* 378 */       return false;
/* 379 */     if (this.priorId == null) {
/* 380 */       if (other.priorId != null)
/* 381 */         return false;
/* 382 */     } else if (!this.priorId.equals(other.priorId))
/* 383 */       return false;
/* 384 */     if (this.remark == null) {
/* 385 */       if (other.remark != null)
/* 386 */         return false;
/* 387 */     } else if (!this.remark.equals(other.remark))
/* 388 */       return false;
/* 389 */     if (this.sysId == null) {
/* 390 */       if (other.sysId != null)
/* 391 */         return false;
/* 392 */     } else if (!this.sysId.equals(other.sysId))
/* 393 */       return false;
/* 394 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgFuncFolder
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserRole;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LkgJob
/*     */   implements Serializable, IUserRole
/*     */ {
/*     */   private static final long serialVersionUID = 8083811153258973143L;
/*     */   private String jobId;
/*     */   private String jobName;
/*     */   private String remark;
/*     */   private String adminId;
/*     */   private String adminName;
/*     */   private String adminTime;
/*     */ 
/*     */   public LkgJob()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgJob(String jobId)
/*     */   {
/*  34 */     this.jobId = jobId;
/*     */   }
/*     */ 
/*     */   public LkgJob(String jobId, String jobName, String remark, String adminId, String adminName, String adminTime)
/*     */   {
/*  40 */     this.jobId = jobId;
/*  41 */     this.jobName = jobName;
/*  42 */     this.remark = remark;
/*  43 */     this.adminId = adminId;
/*  44 */     this.adminName = adminName;
/*  45 */     this.adminTime = adminTime;
/*     */   }
/*     */ 
/*     */   public String getJobId()
/*     */   {
/*  51 */     return this.jobId;
/*     */   }
/*     */ 
/*     */   public void setJobId(String jobId) {
/*  55 */     this.jobId = jobId;
/*     */   }
/*     */ 
/*     */   public String getJobName() {
/*  59 */     return this.jobName;
/*     */   }
/*     */ 
/*     */   public void setJobName(String jobName) {
/*  63 */     this.jobName = jobName;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/*  67 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/*  71 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getAdminId() {
/*  75 */     return this.adminId;
/*     */   }
/*     */ 
/*     */   public void setAdminId(String adminId) {
/*  79 */     this.adminId = adminId;
/*     */   }
/*     */ 
/*     */   public String getAdminName() {
/*  83 */     return this.adminName;
/*     */   }
/*     */ 
/*     */   public void setAdminName(String adminName) {
/*  87 */     this.adminName = adminName;
/*     */   }
/*     */ 
/*     */   public String getAdminTime() {
/*  91 */     return this.adminTime;
/*     */   }
/*     */ 
/*     */   public void setAdminTime(String adminTime) {
/*  95 */     this.adminTime = adminTime;
/*     */   }
/*     */ 
/*     */   public String getParentId()
/*     */   {
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */   public String getRoleId() {
/* 104 */     return getJobId();
/*     */   }
/*     */ 
/*     */   public String getRoleName() {
/* 108 */     return getJobName();
/*     */   }
/*     */ 
/*     */   public String getClassifyId()
/*     */   {
/* 113 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgJob
 * JD-Core Version:    0.6.2
 */
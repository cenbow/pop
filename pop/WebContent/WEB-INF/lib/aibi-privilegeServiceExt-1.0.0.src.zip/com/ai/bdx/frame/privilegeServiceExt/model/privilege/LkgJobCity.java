/*    */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class LkgJobCity
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 4080436106595078936L;
/*    */   private LkgJobCityId id;
/*    */   private String funcId;
/*    */   private String depId;
/*    */   private String adminId;
/*    */   private String adminName;
/*    */   private String adminTime;
/*    */ 
/*    */   public LkgJobCity()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LkgJobCity(LkgJobCityId id)
/*    */   {
/* 33 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public LkgJobCity(LkgJobCityId id, String funcId, String depId, String adminId, String adminName, String adminTime)
/*    */   {
/* 39 */     this.id = id;
/* 40 */     this.funcId = funcId;
/* 41 */     this.depId = depId;
/* 42 */     this.adminId = adminId;
/* 43 */     this.adminName = adminName;
/* 44 */     this.adminTime = adminTime;
/*    */   }
/*    */ 
/*    */   public LkgJobCityId getId()
/*    */   {
/* 50 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(LkgJobCityId id) {
/* 54 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getFuncId() {
/* 58 */     return this.funcId;
/*    */   }
/*    */ 
/*    */   public void setFuncId(String funcId) {
/* 62 */     this.funcId = funcId;
/*    */   }
/*    */ 
/*    */   public String getDepId() {
/* 66 */     return this.depId;
/*    */   }
/*    */ 
/*    */   public void setDepId(String depId) {
/* 70 */     this.depId = depId;
/*    */   }
/*    */ 
/*    */   public String getAdminId() {
/* 74 */     return this.adminId;
/*    */   }
/*    */ 
/*    */   public void setAdminId(String adminId) {
/* 78 */     this.adminId = adminId;
/*    */   }
/*    */ 
/*    */   public String getAdminName() {
/* 82 */     return this.adminName;
/*    */   }
/*    */ 
/*    */   public void setAdminName(String adminName) {
/* 86 */     this.adminName = adminName;
/*    */   }
/*    */ 
/*    */   public String getAdminTime() {
/* 90 */     return this.adminTime;
/*    */   }
/*    */ 
/*    */   public void setAdminTime(String adminTime) {
/* 94 */     this.adminTime = adminTime;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgJobCity
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class LkgJobCityId
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -5873320002940072377L;
/*    */   private String jobId;
/*    */   private String cityId;
/*    */ 
/*    */   public LkgJobCityId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LkgJobCityId(String jobId, String cityId)
/*    */   {
/* 29 */     this.jobId = jobId;
/* 30 */     this.cityId = cityId;
/*    */   }
/*    */ 
/*    */   public String getJobId()
/*    */   {
/* 36 */     return this.jobId;
/*    */   }
/*    */ 
/*    */   public void setJobId(String jobId) {
/* 40 */     this.jobId = jobId;
/*    */   }
/*    */ 
/*    */   public String getCityId() {
/* 44 */     return this.cityId;
/*    */   }
/*    */ 
/*    */   public void setCityId(String cityId) {
/* 48 */     this.cityId = cityId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 53 */     if (this == other) {
/* 54 */       return true;
/*    */     }
/* 56 */     if (other == null) {
/* 57 */       return false;
/*    */     }
/* 59 */     if (!(other instanceof LkgJobCityId)) {
/* 60 */       return false;
/*    */     }
/* 62 */     LkgJobCityId castOther = (LkgJobCityId)other;
/*    */ 
/* 64 */     return ((getJobId() == castOther.getJobId()) || ((getJobId() != null) && (castOther.getJobId() != null) && (getJobId().equals(castOther.getJobId())))) && ((getCityId() == castOther.getCityId()) || ((getCityId() != null) && (castOther.getCityId() != null) && (getCityId().equals(castOther.getCityId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 75 */     int result = 17;
/*    */ 
/* 77 */     result = 37 * result + (getJobId() == null ? 0 : getJobId().hashCode());
/*    */ 
/* 79 */     result = 37 * result + (getCityId() == null ? 0 : getCityId().hashCode());
/*    */ 
/* 81 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgJobCityId
 * JD-Core Version:    0.6.2
 */
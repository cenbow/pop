/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LkgJobFunc
/*     */   implements Serializable
/*     */ {
/*     */   private LkgJobFuncId id;
/*     */   private String operateFlag;
/*     */   private String rightFlag;
/*     */   private String back1Flag;
/*     */   private String back2Flag;
/*     */   private String back3Flag;
/*     */   private String back4Flag;
/*     */   private String back5Flag;
/*     */   private String back6Flag;
/*     */   private String adminId;
/*     */   private String adminName;
/*     */   private String adminTime;
/*     */ 
/*     */   public LkgJobFunc()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgJobFunc(LkgJobFuncId id)
/*     */   {
/*  35 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public LkgJobFunc(LkgJobFuncId id, String operateFlag, String rightFlag, String back1Flag, String back2Flag, String back3Flag, String back4Flag, String back5Flag, String back6Flag, String adminId, String adminName, String adminTime)
/*     */   {
/*  43 */     this.id = id;
/*  44 */     this.operateFlag = operateFlag;
/*  45 */     this.rightFlag = rightFlag;
/*  46 */     this.back1Flag = back1Flag;
/*  47 */     this.back2Flag = back2Flag;
/*  48 */     this.back3Flag = back3Flag;
/*  49 */     this.back4Flag = back4Flag;
/*  50 */     this.back5Flag = back5Flag;
/*  51 */     this.back6Flag = back6Flag;
/*  52 */     this.adminId = adminId;
/*  53 */     this.adminName = adminName;
/*  54 */     this.adminTime = adminTime;
/*     */   }
/*     */ 
/*     */   public LkgJobFuncId getId()
/*     */   {
/*  60 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(LkgJobFuncId id) {
/*  64 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getOperateFlag() {
/*  68 */     return this.operateFlag;
/*     */   }
/*     */ 
/*     */   public void setOperateFlag(String operateFlag) {
/*  72 */     this.operateFlag = operateFlag;
/*     */   }
/*     */ 
/*     */   public String getRightFlag() {
/*  76 */     return this.rightFlag;
/*     */   }
/*     */ 
/*     */   public void setRightFlag(String rightFlag) {
/*  80 */     this.rightFlag = rightFlag;
/*     */   }
/*     */ 
/*     */   public String getBack1Flag() {
/*  84 */     return this.back1Flag;
/*     */   }
/*     */ 
/*     */   public void setBack1Flag(String back1Flag) {
/*  88 */     this.back1Flag = back1Flag;
/*     */   }
/*     */ 
/*     */   public String getBack2Flag() {
/*  92 */     return this.back2Flag;
/*     */   }
/*     */ 
/*     */   public void setBack2Flag(String back2Flag) {
/*  96 */     this.back2Flag = back2Flag;
/*     */   }
/*     */ 
/*     */   public String getBack3Flag() {
/* 100 */     return this.back3Flag;
/*     */   }
/*     */ 
/*     */   public void setBack3Flag(String back3Flag) {
/* 104 */     this.back3Flag = back3Flag;
/*     */   }
/*     */ 
/*     */   public String getBack4Flag() {
/* 108 */     return this.back4Flag;
/*     */   }
/*     */ 
/*     */   public void setBack4Flag(String back4Flag) {
/* 112 */     this.back4Flag = back4Flag;
/*     */   }
/*     */ 
/*     */   public String getBack5Flag() {
/* 116 */     return this.back5Flag;
/*     */   }
/*     */ 
/*     */   public void setBack5Flag(String back5Flag) {
/* 120 */     this.back5Flag = back5Flag;
/*     */   }
/*     */ 
/*     */   public String getBack6Flag() {
/* 124 */     return this.back6Flag;
/*     */   }
/*     */ 
/*     */   public void setBack6Flag(String back6Flag) {
/* 128 */     this.back6Flag = back6Flag;
/*     */   }
/*     */ 
/*     */   public String getAdminId() {
/* 132 */     return this.adminId;
/*     */   }
/*     */ 
/*     */   public void setAdminId(String adminId) {
/* 136 */     this.adminId = adminId;
/*     */   }
/*     */ 
/*     */   public String getAdminName() {
/* 140 */     return this.adminName;
/*     */   }
/*     */ 
/*     */   public void setAdminName(String adminName) {
/* 144 */     this.adminName = adminName;
/*     */   }
/*     */ 
/*     */   public String getAdminTime() {
/* 148 */     return this.adminTime;
/*     */   }
/*     */ 
/*     */   public void setAdminTime(String adminTime) {
/* 152 */     this.adminTime = adminTime;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgJobFunc
 * JD-Core Version:    0.6.2
 */
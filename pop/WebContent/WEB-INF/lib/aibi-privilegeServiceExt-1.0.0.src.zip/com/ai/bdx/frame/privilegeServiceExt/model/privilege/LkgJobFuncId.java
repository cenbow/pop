/*    */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class LkgJobFuncId
/*    */   implements Serializable
/*    */ {
/*    */   private String jobId;
/*    */   private String funcId;
/*    */ 
/*    */   public LkgJobFuncId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LkgJobFuncId(String jobId, String funcId)
/*    */   {
/* 25 */     this.jobId = jobId;
/* 26 */     this.funcId = funcId;
/*    */   }
/*    */ 
/*    */   public String getJobId()
/*    */   {
/* 32 */     return this.jobId;
/*    */   }
/*    */ 
/*    */   public void setJobId(String jobId) {
/* 36 */     this.jobId = jobId;
/*    */   }
/*    */ 
/*    */   public String getFuncId() {
/* 40 */     return this.funcId;
/*    */   }
/*    */ 
/*    */   public void setFuncId(String funcId) {
/* 44 */     this.funcId = funcId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 49 */     if (this == other) {
/* 50 */       return true;
/*    */     }
/* 52 */     if (other == null) {
/* 53 */       return false;
/*    */     }
/* 55 */     if (!(other instanceof LkgJobFuncId)) {
/* 56 */       return false;
/*    */     }
/* 58 */     LkgJobFuncId castOther = (LkgJobFuncId)other;
/*    */ 
/* 60 */     return ((getJobId() == castOther.getJobId()) || ((getJobId() != null) && (castOther.getJobId() != null) && (getJobId().equals(castOther.getJobId())))) && ((getFuncId() == castOther.getFuncId()) || ((getFuncId() != null) && (castOther.getFuncId() != null) && (getFuncId().equals(castOther.getFuncId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 71 */     int result = 17;
/*    */ 
/* 73 */     result = 37 * result + (getJobId() == null ? 0 : getJobId().hashCode());
/*    */ 
/* 75 */     result = 37 * result + (getFuncId() == null ? 0 : getFuncId().hashCode());
/*    */ 
/* 77 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgJobFuncId
 * JD-Core Version:    0.6.2
 */
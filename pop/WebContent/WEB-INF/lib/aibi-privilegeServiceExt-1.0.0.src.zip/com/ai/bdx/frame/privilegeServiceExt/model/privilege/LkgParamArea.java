/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.ICity;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LkgParamArea
/*     */   implements Serializable, ICity
/*     */ {
/*     */   private String provId;
/*     */   private String cityId;
/*     */   private String countryId;
/*     */   private String areaId;
/*     */   private String sub1AreaId;
/*     */   private String sub2AreaId;
/*     */   private String provName;
/*     */   private String cityName;
/*     */   private String countryName;
/*     */   private String areaName;
/*     */   private String sub1AreaName;
/*     */   private String sub2AreaName;
/*     */   private String cityIdNew;
/*     */   private String countryIdNew;
/*     */   private String areaIdNew;
/*     */ 
/*     */   public LkgParamArea()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgParamArea(String provId, String cityId, String countryId, String areaId, String sub1AreaId, String sub2AreaId, String provName, String cityName, String countryName, String areaName, String sub1AreaName, String sub2AreaName, String cityIdNew, String countryIdNew, String areaIdNew)
/*     */   {
/*  42 */     this.provId = provId;
/*  43 */     this.cityId = cityId;
/*  44 */     this.countryId = countryId;
/*  45 */     this.areaId = areaId;
/*  46 */     this.sub1AreaId = sub1AreaId;
/*  47 */     this.sub2AreaId = sub2AreaId;
/*  48 */     this.provName = provName;
/*  49 */     this.cityName = cityName;
/*  50 */     this.countryName = countryName;
/*  51 */     this.areaName = areaName;
/*  52 */     this.sub1AreaName = sub1AreaName;
/*  53 */     this.sub2AreaName = sub2AreaName;
/*  54 */     this.countryIdNew = countryIdNew;
/*  55 */     this.areaIdNew = areaIdNew;
/*  56 */     this.cityIdNew = cityIdNew;
/*     */   }
/*     */ 
/*     */   public String getProvId()
/*     */   {
/*  62 */     return this.provId;
/*     */   }
/*     */ 
/*     */   public void setProvId(String provId) {
/*  66 */     this.provId = provId;
/*     */   }
/*     */ 
/*     */   public String getCityId() {
/*  70 */     return this.cityId;
/*     */   }
/*     */ 
/*     */   public void setCityId(String cityId) {
/*  74 */     this.cityId = cityId;
/*     */   }
/*     */ 
/*     */   public String getCountryId() {
/*  78 */     return this.countryId;
/*     */   }
/*     */ 
/*     */   public void setCountryId(String countryId) {
/*  82 */     this.countryId = countryId;
/*     */   }
/*     */ 
/*     */   public String getAreaId() {
/*  86 */     return this.areaId;
/*     */   }
/*     */ 
/*     */   public void setAreaId(String areaId) {
/*  90 */     this.areaId = areaId;
/*     */   }
/*     */ 
/*     */   public String getSub1AreaId() {
/*  94 */     return this.sub1AreaId;
/*     */   }
/*     */ 
/*     */   public void setSub1AreaId(String sub1AreaId) {
/*  98 */     this.sub1AreaId = sub1AreaId;
/*     */   }
/*     */ 
/*     */   public String getSub2AreaId() {
/* 102 */     return this.sub2AreaId;
/*     */   }
/*     */ 
/*     */   public void setSub2AreaId(String sub2AreaId) {
/* 106 */     this.sub2AreaId = sub2AreaId;
/*     */   }
/*     */ 
/*     */   public String getProvName() {
/* 110 */     return this.provName;
/*     */   }
/*     */ 
/*     */   public void setProvName(String provName) {
/* 114 */     this.provName = provName;
/*     */   }
/*     */ 
/*     */   public void setCityName(String cityName)
/*     */   {
/* 119 */     this.cityName = cityName;
/*     */   }
/*     */ 
/*     */   public String getCountryName() {
/* 123 */     return this.countryName;
/*     */   }
/*     */ 
/*     */   public void setCountryName(String countryName) {
/* 127 */     this.countryName = countryName;
/*     */   }
/*     */ 
/*     */   public String getAreaName() {
/* 131 */     return this.areaName;
/*     */   }
/*     */ 
/*     */   public void setAreaName(String areaName) {
/* 135 */     this.areaName = areaName;
/*     */   }
/*     */ 
/*     */   public String getSub1AreaName() {
/* 139 */     return this.sub1AreaName;
/*     */   }
/*     */ 
/*     */   public void setSub1AreaName(String sub1AreaName) {
/* 143 */     this.sub1AreaName = sub1AreaName;
/*     */   }
/*     */ 
/*     */   public String getSub2AreaName() {
/* 147 */     return this.sub2AreaName;
/*     */   }
/*     */ 
/*     */   public void setSub2AreaName(String sub2AreaName) {
/* 151 */     this.sub2AreaName = sub2AreaName;
/*     */   }
/*     */ 
/*     */   public String getCityName()
/*     */   {
/* 156 */     return this.cityName;
/*     */   }
/*     */ 
/*     */   public String getDmCityId() {
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDmCountyId() {
/* 164 */     return this.countryId;
/*     */   }
/*     */ 
/*     */   public String getDmDeptId() {
/* 168 */     return this.areaId;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/* 172 */     return this.provId;
/*     */   }
/*     */ 
/*     */   public int getSortNum() {
/* 176 */     return 0;
/*     */   }
/*     */ 
/*     */   public String getDmTypeCode()
/*     */   {
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDmTypeId()
/*     */   {
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */   public String getCountryIdNew() {
/* 192 */     return this.countryIdNew;
/*     */   }
/*     */ 
/*     */   public void setCountryIdNew(String countryIdNew) {
/* 196 */     this.countryIdNew = countryIdNew;
/*     */   }
/*     */ 
/*     */   public String getAreaIdNew() {
/* 200 */     return this.areaIdNew;
/*     */   }
/*     */ 
/*     */   public void setAreaIdNew(String areaIdNew) {
/* 204 */     this.areaIdNew = areaIdNew;
/*     */   }
/*     */ 
/*     */   public String getCityIdNew() {
/* 208 */     return this.cityIdNew;
/*     */   }
/*     */ 
/*     */   public void setCityIdNew(String cityIdNew) {
/* 212 */     this.cityIdNew = cityIdNew;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgParamArea
 * JD-Core Version:    0.6.2
 */
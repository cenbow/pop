/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.cache.service.IdAndName;
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ 
/*     */ public class LkgStaff
/*     */   implements Serializable, IdAndName, IUser
/*     */ {
/*     */   private static final long serialVersionUID = -4287913024688962118L;
/*     */   private String staffId;
/*     */   private String staffName;
/*     */   private String staffPwd;
/*     */   private String sex;
/*     */   private String age;
/*     */   private String nation;
/*     */   private String staffNum;
/*     */   private String certificateId;
/*     */   private String provId;
/*     */   private String cityId;
/*     */   private String countryId;
/*     */   private String areaId;
/*     */   private String sub1AreaId;
/*     */   private String sub2AreaId;
/*     */   private String dataLevel;
/*     */   private String depId;
/*     */   private String postId;
/*     */   private String phone;
/*     */   private String email;
/*     */   private String commAddress;
/*     */   private String postCode;
/*     */   private String leaderId;
/*     */   private String groupId;
/*     */   private String postType;
/*     */   private String remark;
/*     */   private String adminId;
/*     */   private String adminName;
/*     */   private String adminTime;
/*     */   private String pwdTime;
/*     */   private String headPic;
/*     */   private String getpwdType;
/*     */   private String staffTactLevel;
/*     */   private String loginTag;
/*     */   private String status;
/*     */ 
/*     */   public LkgStaff()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgStaff(String staffId)
/*     */   {
/*  63 */     this.staffId = staffId;
/*     */   }
/*     */ 
/*     */   public LkgStaff(String staffId, String staffName, String staffPwd, String sex, String age, String nation, String staffNum, String certificateId, String provId, String cityId, String countryId, String areaId, String sub1AreaId, String sub2AreaId, String dataLevel, String depId, String postId, String phone, String email, String commAddress, String postCode, String leaderId, String groupId, String postType, String remark, String adminId, String adminName, String adminTime, String pwdTime, String headPic, String getpwdType, String staffTactLevel, String loginTag)
/*     */   {
/*  77 */     this.staffId = staffId;
/*  78 */     this.staffName = staffName;
/*  79 */     this.staffPwd = staffPwd;
/*  80 */     this.sex = sex;
/*  81 */     this.age = age;
/*  82 */     this.nation = nation;
/*  83 */     this.staffNum = staffNum;
/*  84 */     this.certificateId = certificateId;
/*  85 */     this.provId = provId;
/*  86 */     this.cityId = cityId;
/*  87 */     this.countryId = countryId;
/*  88 */     this.areaId = areaId;
/*  89 */     this.sub1AreaId = sub1AreaId;
/*  90 */     this.sub2AreaId = sub2AreaId;
/*  91 */     this.dataLevel = dataLevel;
/*  92 */     this.depId = depId;
/*  93 */     this.postId = postId;
/*  94 */     this.phone = phone;
/*  95 */     this.email = email;
/*  96 */     this.commAddress = commAddress;
/*  97 */     this.postCode = postCode;
/*  98 */     this.leaderId = leaderId;
/*  99 */     this.groupId = groupId;
/* 100 */     this.postType = postType;
/* 101 */     this.remark = remark;
/* 102 */     this.adminId = adminId;
/* 103 */     this.adminName = adminName;
/* 104 */     this.adminTime = adminTime;
/* 105 */     this.pwdTime = pwdTime;
/* 106 */     this.headPic = headPic;
/* 107 */     this.getpwdType = getpwdType;
/* 108 */     this.staffTactLevel = staffTactLevel;
/* 109 */     this.loginTag = loginTag;
/*     */   }
/*     */ 
/*     */   public String getStaffId()
/*     */   {
/* 115 */     return this.staffId;
/*     */   }
/*     */ 
/*     */   public void setStaffId(String staffId) {
/* 119 */     this.staffId = staffId;
/*     */   }
/*     */ 
/*     */   public String getStaffName() {
/* 123 */     return this.staffName;
/*     */   }
/*     */ 
/*     */   public void setStaffName(String staffName) {
/* 127 */     this.staffName = staffName;
/*     */   }
/*     */ 
/*     */   public String getStaffPwd() {
/* 131 */     return this.staffPwd;
/*     */   }
/*     */ 
/*     */   public void setStaffPwd(String staffPwd) {
/* 135 */     this.staffPwd = staffPwd;
/*     */   }
/*     */ 
/*     */   public String getSex() {
/* 139 */     return this.sex;
/*     */   }
/*     */ 
/*     */   public void setSex(String sex) {
/* 143 */     this.sex = sex;
/*     */   }
/*     */ 
/*     */   public String getAge() {
/* 147 */     return this.age;
/*     */   }
/*     */ 
/*     */   public void setAge(String age) {
/* 151 */     this.age = age;
/*     */   }
/*     */ 
/*     */   public String getNation() {
/* 155 */     return this.nation;
/*     */   }
/*     */ 
/*     */   public void setNation(String nation) {
/* 159 */     this.nation = nation;
/*     */   }
/*     */ 
/*     */   public String getStaffNum() {
/* 163 */     return this.staffNum;
/*     */   }
/*     */ 
/*     */   public void setStaffNum(String staffNum) {
/* 167 */     this.staffNum = staffNum;
/*     */   }
/*     */ 
/*     */   public String getCertificateId() {
/* 171 */     return this.certificateId;
/*     */   }
/*     */ 
/*     */   public void setCertificateId(String certificateId) {
/* 175 */     this.certificateId = certificateId;
/*     */   }
/*     */ 
/*     */   public String getProvId() {
/* 179 */     return this.provId;
/*     */   }
/*     */ 
/*     */   public void setProvId(String provId) {
/* 183 */     this.provId = provId;
/*     */   }
/*     */ 
/*     */   public String getCityId() {
/* 187 */     return this.cityId;
/*     */   }
/*     */ 
/*     */   public void setCityId(String cityId) {
/* 191 */     this.cityId = cityId;
/*     */   }
/*     */ 
/*     */   public String getCountryId() {
/* 195 */     return this.countryId;
/*     */   }
/*     */ 
/*     */   public void setCountryId(String countryId) {
/* 199 */     this.countryId = countryId;
/*     */   }
/*     */ 
/*     */   public String getAreaId() {
/* 203 */     return this.areaId;
/*     */   }
/*     */ 
/*     */   public void setAreaId(String areaId) {
/* 207 */     this.areaId = areaId;
/*     */   }
/*     */ 
/*     */   public String getSub1AreaId() {
/* 211 */     return this.sub1AreaId;
/*     */   }
/*     */ 
/*     */   public void setSub1AreaId(String sub1AreaId) {
/* 215 */     this.sub1AreaId = sub1AreaId;
/*     */   }
/*     */ 
/*     */   public String getSub2AreaId() {
/* 219 */     return this.sub2AreaId;
/*     */   }
/*     */ 
/*     */   public void setSub2AreaId(String sub2AreaId) {
/* 223 */     this.sub2AreaId = sub2AreaId;
/*     */   }
/*     */ 
/*     */   public String getDataLevel() {
/* 227 */     return this.dataLevel;
/*     */   }
/*     */ 
/*     */   public void setDataLevel(String dataLevel) {
/* 231 */     this.dataLevel = dataLevel;
/*     */   }
/*     */ 
/*     */   public String getDepId() {
/* 235 */     return this.depId;
/*     */   }
/*     */ 
/*     */   public void setDepId(String depId) {
/* 239 */     this.depId = depId;
/*     */   }
/*     */ 
/*     */   public String getPostId() {
/* 243 */     return this.postId;
/*     */   }
/*     */ 
/*     */   public void setPostId(String postId) {
/* 247 */     this.postId = postId;
/*     */   }
/*     */ 
/*     */   public String getPhone() {
/* 251 */     return this.phone;
/*     */   }
/*     */ 
/*     */   public void setPhone(String phone) {
/* 255 */     this.phone = phone;
/*     */   }
/*     */ 
/*     */   public String getEmail() {
/* 259 */     return this.email;
/*     */   }
/*     */ 
/*     */   public void setEmail(String email) {
/* 263 */     this.email = email;
/*     */   }
/*     */ 
/*     */   public String getCommAddress() {
/* 267 */     return this.commAddress;
/*     */   }
/*     */ 
/*     */   public void setCommAddress(String commAddress) {
/* 271 */     this.commAddress = commAddress;
/*     */   }
/*     */ 
/*     */   public String getPostCode() {
/* 275 */     return this.postCode;
/*     */   }
/*     */ 
/*     */   public void setPostCode(String postCode) {
/* 279 */     this.postCode = postCode;
/*     */   }
/*     */ 
/*     */   public String getLeaderId() {
/* 283 */     return this.leaderId;
/*     */   }
/*     */ 
/*     */   public void setLeaderId(String leaderId) {
/* 287 */     this.leaderId = leaderId;
/*     */   }
/*     */ 
/*     */   public String getGroupId() {
/* 291 */     return this.groupId;
/*     */   }
/*     */ 
/*     */   public void setGroupId(String groupId) {
/* 295 */     this.groupId = groupId;
/*     */   }
/*     */ 
/*     */   public String getPostType() {
/* 299 */     return this.postType;
/*     */   }
/*     */ 
/*     */   public void setPostType(String postType) {
/* 303 */     this.postType = postType;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 307 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/* 311 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getAdminId() {
/* 315 */     return this.adminId;
/*     */   }
/*     */ 
/*     */   public void setAdminId(String adminId) {
/* 319 */     this.adminId = adminId;
/*     */   }
/*     */ 
/*     */   public String getAdminName() {
/* 323 */     return this.adminName;
/*     */   }
/*     */ 
/*     */   public void setAdminName(String adminName) {
/* 327 */     this.adminName = adminName;
/*     */   }
/*     */ 
/*     */   public String getAdminTime() {
/* 331 */     return this.adminTime;
/*     */   }
/*     */ 
/*     */   public void setAdminTime(String adminTime) {
/* 335 */     this.adminTime = adminTime;
/*     */   }
/*     */ 
/*     */   public String getPwdTime() {
/* 339 */     return this.pwdTime;
/*     */   }
/*     */ 
/*     */   public void setPwdTime(String pwdTime) {
/* 343 */     this.pwdTime = pwdTime;
/*     */   }
/*     */ 
/*     */   public String getHeadPic() {
/* 347 */     return this.headPic;
/*     */   }
/*     */ 
/*     */   public void setHeadPic(String headPic) {
/* 351 */     this.headPic = headPic;
/*     */   }
/*     */ 
/*     */   public String getGetpwdType() {
/* 355 */     return this.getpwdType;
/*     */   }
/*     */ 
/*     */   public void setGetpwdType(String getpwdType) {
/* 359 */     this.getpwdType = getpwdType;
/*     */   }
/*     */ 
/*     */   public String getStaffTactLevel() {
/* 363 */     return this.staffTactLevel;
/*     */   }
/*     */ 
/*     */   public void setStaffTactLevel(String staffTactLevel) {
/* 367 */     this.staffTactLevel = staffTactLevel;
/*     */   }
/*     */ 
/*     */   public String getLoginTag() {
/* 371 */     return this.loginTag;
/*     */   }
/*     */ 
/*     */   public void setLoginTag(String loginTag) {
/* 375 */     this.loginTag = loginTag;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 379 */     return getStaffName();
/*     */   }
/*     */ 
/*     */   public Object getPrimaryKey() {
/* 383 */     return getStaffId();
/*     */   }
/*     */ 
/*     */   public String getCityid() {
/* 387 */     return getCityId();
/*     */   }
/*     */ 
/*     */   public int getDepartmentid() {
/* 391 */     return (getDepId() == null) || ("".equals(getDepId())) ? -1 : Integer.valueOf(getDepId()).intValue();
/*     */   }
/*     */ 
/*     */   public String getLoginId() {
/* 395 */     return getStaffId();
/*     */   }
/*     */ 
/*     */   public String getMobilePhone() {
/* 399 */     return getPhone();
/*     */   }
/*     */ 
/*     */   public String getUserid() {
/* 403 */     return getStaffId();
/*     */   }
/*     */ 
/*     */   public String getUsername() {
/* 407 */     return getStaffName();
/*     */   }
/*     */ 
/*     */   public String getDomainType()
/*     */   {
/* 413 */     return null;
/*     */   }
/*     */ 
/*     */   public Integer getDutyid()
/*     */   {
/* 418 */     return null;
/*     */   }
/*     */ 
/*     */   public List<String> getRoleidList()
/*     */   {
/* 423 */     return null;
/*     */   }
/*     */ 
/*     */   public void setStatus(String status) {
/* 427 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public String getStatus() {
/* 431 */     return this.status;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaff
 * JD-Core Version:    0.6.2
 */
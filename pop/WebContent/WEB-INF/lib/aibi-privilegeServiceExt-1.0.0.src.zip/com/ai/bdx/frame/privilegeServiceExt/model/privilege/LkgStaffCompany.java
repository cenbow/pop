/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.privilege.cache.service.IdAndName;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LkgStaffCompany
/*     */   implements Serializable, IdAndName, IUserCompany
/*     */ {
/*     */   private static final long serialVersionUID = -6945896746431944014L;
/*     */   private Integer deptid;
/*     */   private Integer parentid;
/*     */   private String title;
/*     */   private String notes;
/*     */   private String serviceCode;
/*     */   private Integer sortnum;
/*     */   private String status;
/*     */   private String deleteTime;
/*     */ 
/*     */   public LkgStaffCompany()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgStaffCompany(Integer deptid, Integer parentid, String title, Integer sortnum, String status)
/*     */   {
/*  37 */     this.deptid = deptid;
/*  38 */     this.parentid = parentid;
/*  39 */     this.title = title;
/*  40 */     this.sortnum = sortnum;
/*  41 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public LkgStaffCompany(Integer deptid, Integer parentid, String title, String notes, String serviceCode, Integer sortnum, String status, String deleteTime)
/*     */   {
/*  48 */     this.deptid = deptid;
/*  49 */     this.parentid = parentid;
/*  50 */     this.title = title;
/*  51 */     this.notes = notes;
/*  52 */     this.serviceCode = serviceCode;
/*  53 */     this.sortnum = sortnum;
/*  54 */     this.status = status;
/*  55 */     this.deleteTime = deleteTime;
/*     */   }
/*     */ 
/*     */   public Integer getDeptid()
/*     */   {
/*  61 */     return this.deptid;
/*     */   }
/*     */ 
/*     */   public void setDeptid(Integer deptid) {
/*  65 */     this.deptid = deptid;
/*     */   }
/*     */ 
/*     */   public Integer getParentid() {
/*  69 */     return this.parentid;
/*     */   }
/*     */ 
/*     */   public void setParentid(Integer parentid) {
/*  73 */     this.parentid = parentid;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/*  77 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setTitle(String title) {
/*  81 */     this.title = title;
/*     */   }
/*     */ 
/*     */   public String getNotes() {
/*  85 */     return this.notes;
/*     */   }
/*     */ 
/*     */   public void setNotes(String notes) {
/*  89 */     this.notes = notes;
/*     */   }
/*     */ 
/*     */   public String getServiceCode() {
/*  93 */     return this.serviceCode;
/*     */   }
/*     */ 
/*     */   public void setServiceCode(String serviceCode) {
/*  97 */     this.serviceCode = serviceCode;
/*     */   }
/*     */ 
/*     */   public Integer getSortnum() {
/* 101 */     return this.sortnum;
/*     */   }
/*     */ 
/*     */   public void setSortnum(Integer sortnum) {
/* 105 */     this.sortnum = sortnum;
/*     */   }
/*     */ 
/*     */   public String getStatus() {
/* 109 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(String status) {
/* 113 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public String getDeleteTime() {
/* 117 */     return this.deleteTime;
/*     */   }
/*     */ 
/*     */   public void setDeleteTime(String deleteTime) {
/* 121 */     this.deleteTime = deleteTime;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 125 */     return getTitle();
/*     */   }
/*     */ 
/*     */   public Object getPrimaryKey() {
/* 129 */     return getDeptid();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaffCompany
 * JD-Core Version:    0.6.2
 */
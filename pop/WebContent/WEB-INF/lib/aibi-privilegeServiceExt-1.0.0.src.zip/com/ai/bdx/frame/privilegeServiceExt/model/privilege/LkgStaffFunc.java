/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LkgStaffFunc
/*     */   implements Serializable
/*     */ {
/*     */   private LkgStaffFuncId id;
/*     */   private String operateFlag;
/*     */   private String rightFlag;
/*     */   private String back1Flag;
/*     */   private String back2Flag;
/*     */   private String back3Flag;
/*     */   private String back4Flag;
/*     */   private String back5Flag;
/*     */   private String back6Flag;
/*     */   private String dataFlag;
/*     */   private String adminId;
/*     */   private String adminName;
/*     */   private String adminTime;
/*     */ 
/*     */   public LkgStaffFunc()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgStaffFunc(LkgStaffFuncId id, String operateFlag, String rightFlag)
/*     */   {
/*  36 */     this.id = id;
/*  37 */     this.operateFlag = operateFlag;
/*  38 */     this.rightFlag = rightFlag;
/*     */   }
/*     */ 
/*     */   public LkgStaffFunc(LkgStaffFuncId id, String operateFlag, String rightFlag, String back1Flag, String back2Flag, String back3Flag, String back4Flag, String back5Flag, String back6Flag, String dataFlag, String adminId, String adminName, String adminTime)
/*     */   {
/*  47 */     this.id = id;
/*  48 */     this.operateFlag = operateFlag;
/*  49 */     this.rightFlag = rightFlag;
/*  50 */     this.back1Flag = back1Flag;
/*  51 */     this.back2Flag = back2Flag;
/*  52 */     this.back3Flag = back3Flag;
/*  53 */     this.back4Flag = back4Flag;
/*  54 */     this.back5Flag = back5Flag;
/*  55 */     this.back6Flag = back6Flag;
/*  56 */     this.dataFlag = dataFlag;
/*  57 */     this.adminId = adminId;
/*  58 */     this.adminName = adminName;
/*  59 */     this.adminTime = adminTime;
/*     */   }
/*     */ 
/*     */   public LkgStaffFuncId getId()
/*     */   {
/*  65 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(LkgStaffFuncId id) {
/*  69 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getOperateFlag() {
/*  73 */     return this.operateFlag;
/*     */   }
/*     */ 
/*     */   public void setOperateFlag(String operateFlag) {
/*  77 */     this.operateFlag = operateFlag;
/*     */   }
/*     */ 
/*     */   public String getRightFlag() {
/*  81 */     return this.rightFlag;
/*     */   }
/*     */ 
/*     */   public void setRightFlag(String rightFlag) {
/*  85 */     this.rightFlag = rightFlag;
/*     */   }
/*     */ 
/*     */   public String getBack1Flag() {
/*  89 */     return this.back1Flag;
/*     */   }
/*     */ 
/*     */   public void setBack1Flag(String back1Flag) {
/*  93 */     this.back1Flag = back1Flag;
/*     */   }
/*     */ 
/*     */   public String getBack2Flag() {
/*  97 */     return this.back2Flag;
/*     */   }
/*     */ 
/*     */   public void setBack2Flag(String back2Flag) {
/* 101 */     this.back2Flag = back2Flag;
/*     */   }
/*     */ 
/*     */   public String getBack3Flag() {
/* 105 */     return this.back3Flag;
/*     */   }
/*     */ 
/*     */   public void setBack3Flag(String back3Flag) {
/* 109 */     this.back3Flag = back3Flag;
/*     */   }
/*     */ 
/*     */   public String getBack4Flag() {
/* 113 */     return this.back4Flag;
/*     */   }
/*     */ 
/*     */   public void setBack4Flag(String back4Flag) {
/* 117 */     this.back4Flag = back4Flag;
/*     */   }
/*     */ 
/*     */   public String getBack5Flag() {
/* 121 */     return this.back5Flag;
/*     */   }
/*     */ 
/*     */   public void setBack5Flag(String back5Flag) {
/* 125 */     this.back5Flag = back5Flag;
/*     */   }
/*     */ 
/*     */   public String getBack6Flag() {
/* 129 */     return this.back6Flag;
/*     */   }
/*     */ 
/*     */   public void setBack6Flag(String back6Flag) {
/* 133 */     this.back6Flag = back6Flag;
/*     */   }
/*     */ 
/*     */   public String getDataFlag() {
/* 137 */     return this.dataFlag;
/*     */   }
/*     */ 
/*     */   public void setDataFlag(String dataFlag) {
/* 141 */     this.dataFlag = dataFlag;
/*     */   }
/*     */ 
/*     */   public String getAdminId() {
/* 145 */     return this.adminId;
/*     */   }
/*     */ 
/*     */   public void setAdminId(String adminId) {
/* 149 */     this.adminId = adminId;
/*     */   }
/*     */ 
/*     */   public String getAdminName() {
/* 153 */     return this.adminName;
/*     */   }
/*     */ 
/*     */   public void setAdminName(String adminName) {
/* 157 */     this.adminName = adminName;
/*     */   }
/*     */ 
/*     */   public String getAdminTime() {
/* 161 */     return this.adminTime;
/*     */   }
/*     */ 
/*     */   public void setAdminTime(String adminTime) {
/* 165 */     this.adminTime = adminTime;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaffFunc
 * JD-Core Version:    0.6.2
 */
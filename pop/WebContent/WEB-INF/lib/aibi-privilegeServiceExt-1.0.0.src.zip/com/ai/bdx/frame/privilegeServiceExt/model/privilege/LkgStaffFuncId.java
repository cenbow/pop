/*    */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class LkgStaffFuncId
/*    */   implements Serializable
/*    */ {
/*    */   private String staffId;
/*    */   private String funcId;
/*    */ 
/*    */   public LkgStaffFuncId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LkgStaffFuncId(String staffId, String funcId)
/*    */   {
/* 25 */     this.staffId = staffId;
/* 26 */     this.funcId = funcId;
/*    */   }
/*    */ 
/*    */   public String getStaffId()
/*    */   {
/* 32 */     return this.staffId;
/*    */   }
/*    */ 
/*    */   public void setStaffId(String staffId) {
/* 36 */     this.staffId = staffId;
/*    */   }
/*    */ 
/*    */   public String getFuncId() {
/* 40 */     return this.funcId;
/*    */   }
/*    */ 
/*    */   public void setFuncId(String funcId) {
/* 44 */     this.funcId = funcId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 49 */     if (this == other) {
/* 50 */       return true;
/*    */     }
/* 52 */     if (other == null) {
/* 53 */       return false;
/*    */     }
/* 55 */     if (!(other instanceof LkgStaffFuncId)) {
/* 56 */       return false;
/*    */     }
/* 58 */     LkgStaffFuncId castOther = (LkgStaffFuncId)other;
/*    */ 
/* 60 */     return ((getStaffId() == castOther.getStaffId()) || ((getStaffId() != null) && (castOther.getStaffId() != null) && (getStaffId().equals(castOther.getStaffId())))) && ((getFuncId() == castOther.getFuncId()) || ((getFuncId() != null) && (castOther.getFuncId() != null) && (getFuncId().equals(castOther.getFuncId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 72 */     int result = 17;
/*    */ 
/* 74 */     result = 37 * result + (getStaffId() == null ? 0 : getStaffId().hashCode());
/*    */ 
/* 76 */     result = 37 * result + (getFuncId() == null ? 0 : getFuncId().hashCode());
/*    */ 
/* 78 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaffFuncId
 * JD-Core Version:    0.6.2
 */
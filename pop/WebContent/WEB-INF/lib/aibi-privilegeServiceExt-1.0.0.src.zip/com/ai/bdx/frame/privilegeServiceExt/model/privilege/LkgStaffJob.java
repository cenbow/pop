/*    */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class LkgStaffJob
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 3216617051173133603L;
/*    */   private LkgStaffJobId id;
/*    */   private String adminId;
/*    */   private String adminName;
/*    */   private String adminTime;
/*    */ 
/*    */   public LkgStaffJob()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LkgStaffJob(LkgStaffJobId id)
/*    */   {
/* 31 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public LkgStaffJob(LkgStaffJobId id, String adminId, String adminName, String adminTime)
/*    */   {
/* 37 */     this.id = id;
/* 38 */     this.adminId = adminId;
/* 39 */     this.adminName = adminName;
/* 40 */     this.adminTime = adminTime;
/*    */   }
/*    */ 
/*    */   public LkgStaffJobId getId()
/*    */   {
/* 46 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(LkgStaffJobId id) {
/* 50 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getAdminId() {
/* 54 */     return this.adminId;
/*    */   }
/*    */ 
/*    */   public void setAdminId(String adminId) {
/* 58 */     this.adminId = adminId;
/*    */   }
/*    */ 
/*    */   public String getAdminName() {
/* 62 */     return this.adminName;
/*    */   }
/*    */ 
/*    */   public void setAdminName(String adminName) {
/* 66 */     this.adminName = adminName;
/*    */   }
/*    */ 
/*    */   public String getAdminTime() {
/* 70 */     return this.adminTime;
/*    */   }
/*    */ 
/*    */   public void setAdminTime(String adminTime) {
/* 74 */     this.adminTime = adminTime;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaffJob
 * JD-Core Version:    0.6.2
 */
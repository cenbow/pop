/*    */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class LkgStaffJobId
/*    */   implements Serializable
/*    */ {
/*    */   private String staffId;
/*    */   private String jobId;
/*    */ 
/*    */   public LkgStaffJobId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LkgStaffJobId(String staffId, String jobId)
/*    */   {
/* 25 */     this.staffId = staffId;
/* 26 */     this.jobId = jobId;
/*    */   }
/*    */ 
/*    */   public String getStaffId()
/*    */   {
/* 32 */     return this.staffId;
/*    */   }
/*    */ 
/*    */   public void setStaffId(String staffId) {
/* 36 */     this.staffId = staffId;
/*    */   }
/*    */ 
/*    */   public String getJobId() {
/* 40 */     return this.jobId;
/*    */   }
/*    */ 
/*    */   public void setJobId(String jobId) {
/* 44 */     this.jobId = jobId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 49 */     if (this == other) {
/* 50 */       return true;
/*    */     }
/* 52 */     if (other == null) {
/* 53 */       return false;
/*    */     }
/* 55 */     if (!(other instanceof LkgStaffJobId)) {
/* 56 */       return false;
/*    */     }
/* 58 */     LkgStaffJobId castOther = (LkgStaffJobId)other;
/*    */ 
/* 60 */     return ((getStaffId() == castOther.getStaffId()) || ((getStaffId() != null) && (castOther.getStaffId() != null) && (getStaffId().equals(castOther.getStaffId())))) && ((getJobId() == castOther.getJobId()) || ((getJobId() != null) && (castOther.getJobId() != null) && (getJobId().equals(castOther.getJobId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 72 */     int result = 17;
/*    */ 
/* 74 */     result = 37 * result + (getStaffId() == null ? 0 : getStaffId().hashCode());
/*    */ 
/* 76 */     result = 37 * result + (getJobId() == null ? 0 : getJobId().hashCode());
/*    */ 
/* 78 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaffJobId
 * JD-Core Version:    0.6.2
 */
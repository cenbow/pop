/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserScope;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LkgStaffScope
/*     */   implements Serializable, IUserScope
/*     */ {
/*     */   private String staffId;
/*     */   private String provScope;
/*     */   private String cityScope;
/*     */   private String countryScope;
/*     */   private String areaScope;
/*     */   private String sub1AreaScope;
/*     */   private String sub2AreaScope;
/*     */   private String adminId;
/*     */   private String adminName;
/*     */   private String adminTime;
/*     */ 
/*     */   public LkgStaffScope()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgStaffScope(String staffId)
/*     */   {
/*  33 */     this.staffId = staffId;
/*     */   }
/*     */ 
/*     */   public LkgStaffScope(String staffId, String provScope, String cityScope, String countryScope, String adminId, String adminName, String adminTime, String areaScope, String sub1AreaScope, String sub2AreaScope)
/*     */   {
/*  41 */     this.staffId = staffId;
/*  42 */     this.provScope = provScope;
/*  43 */     this.cityScope = cityScope;
/*  44 */     this.countryScope = countryScope;
/*  45 */     this.adminId = adminId;
/*  46 */     this.adminName = adminName;
/*  47 */     this.adminTime = adminTime;
/*  48 */     this.areaScope = areaScope;
/*  49 */     this.sub1AreaScope = sub1AreaScope;
/*  50 */     this.sub2AreaScope = sub2AreaScope;
/*     */   }
/*     */ 
/*     */   public String getStaffId()
/*     */   {
/*  55 */     return this.staffId;
/*     */   }
/*     */ 
/*     */   public void setStaffId(String staffId) {
/*  59 */     this.staffId = staffId;
/*     */   }
/*     */ 
/*     */   public String getProvScope() {
/*  63 */     return this.provScope;
/*     */   }
/*     */ 
/*     */   public void setProvScope(String provScope) {
/*  67 */     this.provScope = provScope;
/*     */   }
/*     */ 
/*     */   public String getCityScope() {
/*  71 */     return this.cityScope;
/*     */   }
/*     */ 
/*     */   public void setCityScope(String cityScope) {
/*  75 */     this.cityScope = cityScope;
/*     */   }
/*     */ 
/*     */   public String getCountryScope() {
/*  79 */     return this.countryScope;
/*     */   }
/*     */ 
/*     */   public void setCountryScope(String countryScope) {
/*  83 */     this.countryScope = countryScope;
/*     */   }
/*     */ 
/*     */   public String getAdminId() {
/*  87 */     return this.adminId;
/*     */   }
/*     */ 
/*     */   public void setAdminId(String adminId) {
/*  91 */     this.adminId = adminId;
/*     */   }
/*     */ 
/*     */   public String getAdminName() {
/*  95 */     return this.adminName;
/*     */   }
/*     */ 
/*     */   public void setAdminName(String adminName) {
/*  99 */     this.adminName = adminName;
/*     */   }
/*     */ 
/*     */   public String getAdminTime() {
/* 103 */     return this.adminTime;
/*     */   }
/*     */ 
/*     */   public void setAdminTime(String adminTime) {
/* 107 */     this.adminTime = adminTime;
/*     */   }
/*     */ 
/*     */   public String getAreaScope() {
/* 111 */     return this.areaScope;
/*     */   }
/*     */ 
/*     */   public void setAreaScope(String areaScope) {
/* 115 */     this.areaScope = areaScope;
/*     */   }
/*     */ 
/*     */   public String getSub1AreaScope() {
/* 119 */     return this.sub1AreaScope;
/*     */   }
/*     */ 
/*     */   public void setSub1AreaScope(String sub1AreaScope) {
/* 123 */     this.sub1AreaScope = sub1AreaScope;
/*     */   }
/*     */ 
/*     */   public String getSub2AreaScope() {
/* 127 */     return this.sub2AreaScope;
/*     */   }
/*     */ 
/*     */   public void setSub2AreaScope(String sub2AreaScope) {
/* 131 */     this.sub2AreaScope = sub2AreaScope;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaffScope
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LkgSys
/*     */   implements Serializable
/*     */ {
/*     */   private String sysId;
/*     */   private String sysName;
/*     */   private String sysMenuUrl;
/*     */   private String image1Url;
/*     */   private String image2Url;
/*     */   private String image3Url;
/*     */   private String remark;
/*     */   private String sysOrder;
/*     */   private String adminId;
/*     */   private String adminName;
/*     */   private String adminTime;
/*     */   private String sysType;
/*     */   private String noValidateUrl;
/*     */ 
/*     */   public LkgSys()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgSys(String sysId, String sysType)
/*     */   {
/*  36 */     this.sysId = sysId;
/*  37 */     this.sysType = sysType;
/*     */   }
/*     */ 
/*     */   public LkgSys(String sysId, String sysName, String sysMenuUrl, String image1Url, String image2Url, String image3Url, String remark, String sysOrder, String adminId, String adminName, String adminTime, String sysType, String noValidateUrl)
/*     */   {
/*  45 */     this.sysId = sysId;
/*  46 */     this.sysName = sysName;
/*  47 */     this.sysMenuUrl = sysMenuUrl;
/*  48 */     this.image1Url = image1Url;
/*  49 */     this.image2Url = image2Url;
/*  50 */     this.image3Url = image3Url;
/*  51 */     this.remark = remark;
/*  52 */     this.sysOrder = sysOrder;
/*  53 */     this.adminId = adminId;
/*  54 */     this.adminName = adminName;
/*  55 */     this.adminTime = adminTime;
/*  56 */     this.sysType = sysType;
/*  57 */     this.noValidateUrl = noValidateUrl;
/*     */   }
/*     */ 
/*     */   public String getSysId()
/*     */   {
/*  63 */     return this.sysId;
/*     */   }
/*     */ 
/*     */   public void setSysId(String sysId) {
/*  67 */     this.sysId = sysId;
/*     */   }
/*     */ 
/*     */   public String getSysName() {
/*  71 */     return this.sysName;
/*     */   }
/*     */ 
/*     */   public void setSysName(String sysName) {
/*  75 */     this.sysName = sysName;
/*     */   }
/*     */ 
/*     */   public String getSysMenuUrl() {
/*  79 */     return this.sysMenuUrl;
/*     */   }
/*     */ 
/*     */   public void setSysMenuUrl(String sysMenuUrl) {
/*  83 */     this.sysMenuUrl = sysMenuUrl;
/*     */   }
/*     */ 
/*     */   public String getImage1Url() {
/*  87 */     return this.image1Url;
/*     */   }
/*     */ 
/*     */   public void setImage1Url(String image1Url) {
/*  91 */     this.image1Url = image1Url;
/*     */   }
/*     */ 
/*     */   public String getImage2Url() {
/*  95 */     return this.image2Url;
/*     */   }
/*     */ 
/*     */   public void setImage2Url(String image2Url) {
/*  99 */     this.image2Url = image2Url;
/*     */   }
/*     */ 
/*     */   public String getImage3Url() {
/* 103 */     return this.image3Url;
/*     */   }
/*     */ 
/*     */   public void setImage3Url(String image3Url) {
/* 107 */     this.image3Url = image3Url;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 111 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/* 115 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getSysOrder() {
/* 119 */     return this.sysOrder;
/*     */   }
/*     */ 
/*     */   public void setSysOrder(String sysOrder) {
/* 123 */     this.sysOrder = sysOrder;
/*     */   }
/*     */ 
/*     */   public String getAdminId() {
/* 127 */     return this.adminId;
/*     */   }
/*     */ 
/*     */   public void setAdminId(String adminId) {
/* 131 */     this.adminId = adminId;
/*     */   }
/*     */ 
/*     */   public String getAdminName() {
/* 135 */     return this.adminName;
/*     */   }
/*     */ 
/*     */   public void setAdminName(String adminName) {
/* 139 */     this.adminName = adminName;
/*     */   }
/*     */ 
/*     */   public String getAdminTime() {
/* 143 */     return this.adminTime;
/*     */   }
/*     */ 
/*     */   public void setAdminTime(String adminTime) {
/* 147 */     this.adminTime = adminTime;
/*     */   }
/*     */ 
/*     */   public String getSysType() {
/* 151 */     return this.sysType;
/*     */   }
/*     */ 
/*     */   public void setSysType(String sysType) {
/* 155 */     this.sysType = sysType;
/*     */   }
/*     */ 
/*     */   public String getNoValidateUrl() {
/* 159 */     return this.noValidateUrl;
/*     */   }
/*     */ 
/*     */   public void setNoValidateUrl(String noValidateUrl) {
/* 163 */     this.noValidateUrl = noValidateUrl;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgSys
 * JD-Core Version:    0.6.2
 */
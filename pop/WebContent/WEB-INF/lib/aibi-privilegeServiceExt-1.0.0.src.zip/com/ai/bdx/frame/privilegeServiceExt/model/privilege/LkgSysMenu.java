/*    */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class LkgSysMenu
/*    */   implements Serializable
/*    */ {
/*    */   private LkgSysMenuId id;
/*    */   private String recDate;
/*    */ 
/*    */   public LkgSysMenu()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LkgSysMenu(LkgSysMenuId id)
/*    */   {
/* 25 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public LkgSysMenu(LkgSysMenuId id, String recDate)
/*    */   {
/* 30 */     this.id = id;
/* 31 */     this.recDate = recDate;
/*    */   }
/*    */ 
/*    */   public LkgSysMenuId getId()
/*    */   {
/* 37 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(LkgSysMenuId id) {
/* 41 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getRecDate() {
/* 45 */     return this.recDate;
/*    */   }
/*    */ 
/*    */   public void setRecDate(String recDate) {
/* 49 */     this.recDate = recDate;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgSysMenu
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class LkgSysMenuId
/*    */   implements Serializable
/*    */ {
/*    */   private String funcId;
/*    */   private String staffId;
/*    */ 
/*    */   public LkgSysMenuId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LkgSysMenuId(String funcId, String staffId)
/*    */   {
/* 25 */     this.funcId = funcId;
/* 26 */     this.staffId = staffId;
/*    */   }
/*    */ 
/*    */   public String getFuncId()
/*    */   {
/* 32 */     return this.funcId;
/*    */   }
/*    */ 
/*    */   public void setFuncId(String funcId) {
/* 36 */     this.funcId = funcId;
/*    */   }
/*    */ 
/*    */   public String getStaffId() {
/* 40 */     return this.staffId;
/*    */   }
/*    */ 
/*    */   public void setStaffId(String staffId) {
/* 44 */     this.staffId = staffId;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 49 */     if (this == other) {
/* 50 */       return true;
/*    */     }
/* 52 */     if (other == null) {
/* 53 */       return false;
/*    */     }
/* 55 */     if (!(other instanceof LkgSysMenuId)) {
/* 56 */       return false;
/*    */     }
/* 58 */     LkgSysMenuId castOther = (LkgSysMenuId)other;
/*    */ 
/* 60 */     return ((getFuncId() == castOther.getFuncId()) || ((getFuncId() != null) && (castOther.getFuncId() != null) && (getFuncId().equals(castOther.getFuncId())))) && ((getStaffId() == castOther.getStaffId()) || ((getStaffId() != null) && (castOther.getStaffId() != null) && (getStaffId().equals(castOther.getStaffId()))));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 72 */     int result = 17;
/*    */ 
/* 74 */     result = 37 * result + (getFuncId() == null ? 0 : getFuncId().hashCode());
/*    */ 
/* 76 */     result = 37 * result + (getStaffId() == null ? 0 : getStaffId().hashCode());
/*    */ 
/* 78 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgSysMenuId
 * JD-Core Version:    0.6.2
 */
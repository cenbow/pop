/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserGroup;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class LkgUserGroup
/*     */   implements Serializable, IUserGroup
/*     */ {
/*     */   private static final long serialVersionUID = -1345601730364713233L;
/*     */   private String groupId;
/*     */   private String groupName;
/*     */   private String validFlag;
/*     */   private String upperGroupId;
/*     */   private String dataLevel;
/*     */   private String remark;
/*     */ 
/*     */   public LkgUserGroup()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LkgUserGroup(String groupId)
/*     */   {
/*  32 */     this.groupId = groupId;
/*     */   }
/*     */ 
/*     */   public LkgUserGroup(String groupId, String groupName, String validFlag, String upperGroupId, String dataLevel, String remark)
/*     */   {
/*  38 */     this.groupId = groupId;
/*  39 */     this.groupName = groupName;
/*  40 */     this.validFlag = validFlag;
/*  41 */     this.upperGroupId = upperGroupId;
/*  42 */     this.dataLevel = dataLevel;
/*  43 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getGroupId()
/*     */   {
/*  49 */     return this.groupId;
/*     */   }
/*     */ 
/*     */   public void setGroupId(String groupId) {
/*  53 */     this.groupId = groupId;
/*     */   }
/*     */ 
/*     */   public String getGroupName() {
/*  57 */     return this.groupName;
/*     */   }
/*     */ 
/*     */   public void setGroupName(String groupName) {
/*  61 */     this.groupName = groupName;
/*     */   }
/*     */ 
/*     */   public String getValidFlag() {
/*  65 */     return this.validFlag;
/*     */   }
/*     */ 
/*     */   public void setValidFlag(String validFlag) {
/*  69 */     this.validFlag = validFlag;
/*     */   }
/*     */ 
/*     */   public String getUpperGroupId() {
/*  73 */     return this.upperGroupId;
/*     */   }
/*     */ 
/*     */   public void setUpperGroupId(String upperGroupId) {
/*  77 */     this.upperGroupId = upperGroupId;
/*     */   }
/*     */ 
/*     */   public String getDataLevel() {
/*  81 */     return this.dataLevel;
/*     */   }
/*     */ 
/*     */   public void setDataLevel(String dataLevel) {
/*  85 */     this.dataLevel = dataLevel;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/*  89 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/*  93 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getGroupid() {
/*  97 */     return getGroupId();
/*     */   }
/*     */ 
/*     */   public String getGroupname() {
/* 101 */     return getGroupName();
/*     */   }
/*     */ 
/*     */   public String getParentid() {
/* 105 */     return getUpperGroupId();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgUserGroup
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.ICity;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class TdCitycode
/*     */   implements Serializable, ICity
/*     */ {
/*     */   private static final long serialVersionUID = -2519489912121305306L;
/*     */   private String cityCode;
/*     */   private String cityName;
/*     */   private String eparchyId;
/*     */   private String remark;
/*     */   private String orderId;
/*     */ 
/*     */   public TdCitycode()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TdCitycode(String cityCode)
/*     */   {
/*  36 */     this.cityCode = cityCode;
/*     */   }
/*     */ 
/*     */   public TdCitycode(String cityCode, String cityName, String eparchyId, String orderId)
/*     */   {
/*  41 */     this.cityCode = cityCode;
/*  42 */     this.cityName = cityName;
/*  43 */     this.eparchyId = eparchyId;
/*  44 */     this.orderId = orderId;
/*     */   }
/*     */ 
/*     */   public String getCityCode()
/*     */   {
/*  50 */     return this.cityCode;
/*     */   }
/*     */ 
/*     */   public void setCityCode(String cityCode) {
/*  54 */     this.cityCode = cityCode;
/*     */   }
/*     */ 
/*     */   public String getCityName() {
/*  58 */     return this.cityName;
/*     */   }
/*     */ 
/*     */   public void setCityName(String cityName) {
/*  62 */     this.cityName = cityName;
/*     */   }
/*     */ 
/*     */   public String getEparchyId() {
/*  66 */     return this.eparchyId;
/*     */   }
/*     */ 
/*     */   public void setEparchyId(String eparchyId) {
/*  70 */     this.eparchyId = eparchyId;
/*     */   }
/*     */ 
/*     */   public String getOrderId() {
/*  74 */     return this.orderId;
/*     */   }
/*     */ 
/*     */   public void setOrderId(String orderId) {
/*  78 */     this.orderId = orderId;
/*     */   }
/*     */ 
/*     */   public String getCityId() {
/*  82 */     return getCityCode();
/*     */   }
/*     */ 
/*     */   public String getDmCityId() {
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDmCountyId() {
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDmDeptId() {
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/*  98 */     return getEparchyId();
/*     */   }
/*     */ 
/*     */   public int getSortNum() {
/* 102 */     return Integer.parseInt(getOrderId());
/*     */   }
/*     */ 
/*     */   public String getDmTypeCode()
/*     */   {
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDmTypeId()
/*     */   {
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 118 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/* 122 */     this.remark = remark;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.TdCitycode
 * JD-Core Version:    0.6.2
 */
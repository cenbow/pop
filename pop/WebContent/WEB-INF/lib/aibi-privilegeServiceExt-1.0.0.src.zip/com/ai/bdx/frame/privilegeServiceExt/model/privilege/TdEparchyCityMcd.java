/*     */ package com.ai.bdx.frame.privilegeServiceExt.model.privilege;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.ICity;
/*     */ import com.asiainfo.biframe.privilege.cache.service.IdAndName;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class TdEparchyCityMcd
/*     */   implements Serializable, IdAndName, ICity
/*     */ {
/*     */   private static final long serialVersionUID = 207168765566022067L;
/*     */   private String areaCode;
/*     */   private String eparchyId;
/*     */   private String eparchyCode;
/*     */   private String eparchyName;
/*     */   private String rehandleFlag;
/*     */   private String freqFlag;
/*     */   private String orderId;
/*     */   private String remark;
/*     */ 
/*     */   public TdEparchyCityMcd()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TdEparchyCityMcd(String eparchyId, String eparchyCode)
/*     */   {
/*  40 */     this.eparchyId = eparchyId;
/*  41 */     this.eparchyCode = eparchyCode;
/*     */   }
/*     */ 
/*     */   public TdEparchyCityMcd(String areaCode, String eparchyId, String eparchyCode, String eparchyName, String rehandleFlag, String freqFlag, String orderId, String remark)
/*     */   {
/*  47 */     this.eparchyId = eparchyId;
/*  48 */     this.eparchyCode = eparchyCode;
/*  49 */     this.eparchyName = eparchyName;
/*  50 */     this.rehandleFlag = rehandleFlag;
/*  51 */     this.freqFlag = freqFlag;
/*  52 */     this.orderId = orderId;
/*  53 */     this.areaCode = areaCode;
/*  54 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getAreaCode()
/*     */   {
/*  59 */     return this.areaCode;
/*     */   }
/*     */ 
/*     */   public void setAreaCode(String areaCode) {
/*  63 */     this.areaCode = areaCode;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/*  67 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/*  71 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getEparchyId() {
/*  75 */     return this.eparchyId;
/*     */   }
/*     */ 
/*     */   public void setEparchyId(String eparchyId) {
/*  79 */     this.eparchyId = eparchyId;
/*     */   }
/*     */ 
/*     */   public String getEparchyCode() {
/*  83 */     return this.eparchyCode;
/*     */   }
/*     */ 
/*     */   public void setEparchyCode(String eparchyCode) {
/*  87 */     this.eparchyCode = eparchyCode;
/*     */   }
/*     */ 
/*     */   public String getEparchyName() {
/*  91 */     return this.eparchyName;
/*     */   }
/*     */ 
/*     */   public void setEparchyName(String eparchyName) {
/*  95 */     this.eparchyName = eparchyName;
/*     */   }
/*     */ 
/*     */   public String getRehandleFlag() {
/*  99 */     return this.rehandleFlag;
/*     */   }
/*     */ 
/*     */   public void setRehandleFlag(String rehandleFlag) {
/* 103 */     this.rehandleFlag = rehandleFlag;
/*     */   }
/*     */ 
/*     */   public String getOrderId() {
/* 107 */     return this.orderId;
/*     */   }
/*     */ 
/*     */   public void setOrderId(String orderId) {
/* 111 */     this.orderId = orderId;
/*     */   }
/*     */ 
/*     */   public String getFreqFlag() {
/* 115 */     return this.freqFlag;
/*     */   }
/*     */ 
/*     */   public void setFreqFlag(String freqFlag) {
/* 119 */     this.freqFlag = freqFlag;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 123 */     return getCityName();
/*     */   }
/*     */ 
/*     */   public Object getPrimaryKey() {
/* 127 */     return getCityId();
/*     */   }
/*     */ 
/*     */   public String getCityId() {
/* 131 */     if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) {
/* 132 */       return getEparchyCode();
/*     */     }
/* 134 */     return getEparchyId();
/*     */   }
/*     */ 
/*     */   public String getCityName() {
/* 138 */     return getEparchyName();
/*     */   }
/*     */ 
/*     */   public String getDmCityId() {
/* 142 */     return getEparchyCode();
/*     */   }
/*     */ 
/*     */   public String getDmCountyId() {
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDmDeptId() {
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */   public int getSortNum() {
/* 158 */     return Integer.parseInt(getOrderId());
/*     */   }
/*     */ 
/*     */   public String getDmTypeCode()
/*     */   {
/* 164 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDmTypeId()
/*     */   {
/* 170 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.model.privilege.TdEparchyCityMcd
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.privilegeServiceExt.service;

import com.asiainfo.biframe.privilege.IMenuItem;
import com.asiainfo.biframe.privilege.IUserRight;
import com.asiainfo.biframe.privilege.IUserRole;
import java.util.List;

public abstract interface ILkgRoleAdminService
{
  public abstract List<IUserRight> getAllRights(int paramInt1, int paramInt2);

  public abstract List<IUserRole> filterRoleByType(List<IUserRole> paramList, int paramInt1, int paramInt2);

  public abstract List<IUserRight> getRightsByRoleIdList(List<String> paramList, int paramInt1, int paramInt2, boolean paramBoolean);

  public abstract IMenuItem getMenuItemById(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.ILkgRoleAdminService
 * JD-Core Version:    0.6.2
 */
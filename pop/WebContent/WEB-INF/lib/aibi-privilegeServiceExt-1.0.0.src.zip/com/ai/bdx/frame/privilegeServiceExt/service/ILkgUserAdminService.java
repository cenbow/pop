package com.ai.bdx.frame.privilegeServiceExt.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.ICity;
import com.asiainfo.biframe.privilege.IMenuItem;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.IUserCompany;
import com.asiainfo.biframe.privilege.IUserGroup;
import com.asiainfo.biframe.privilege.IUserRight;
import com.asiainfo.biframe.privilege.IUserRole;
import java.util.List;

public abstract interface ILkgUserAdminService
{
  public abstract List<IUser> getAllUser()
    throws ServiceException;

  public abstract List getUsersOfDepartment(int paramInt);

  public abstract List<IUserCompany> getAllUserCompany()
    throws ServiceException;

  public abstract List<IUserRight> getRight(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
    throws ServiceException;

  public abstract IUser getUser(String paramString)
    throws ServiceException;

  public abstract IUserCompany getUserCompanyById(String paramString);

  public abstract String getUserDmCity(String paramString1, String paramString2)
    throws ServiceException;

  public abstract List<ICity> getAllCity()
    throws ServiceException;

  public abstract List<ICity> getAllCounty()
    throws ServiceException;

  public abstract List<ICity> getSubCitysById(String paramString)
    throws ServiceException;

  public abstract List<ICity> getCityByUser(String paramString)
    throws ServiceException;

  public abstract ICity getCityById(String paramString)
    throws ServiceException;

  public abstract String getDmCity(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean);

  public abstract IMenuItem getMenuItemById(String paramString);

  public abstract IUserGroup getGroupObject(String paramString);

  public abstract String getSensitiveLevel(String paramString)
    throws ServiceException;

  public abstract boolean isAdminUser(String paramString);

  public abstract List<IUserRole> getAllRoles(String paramString);

  public abstract List<IUserCompany> getSubCompanyById(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserAdminService
 * JD-Core Version:    0.6.2
 */
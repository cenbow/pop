package com.ai.bdx.frame.privilegeServiceExt.service;

import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.ICity;
import java.util.List;

public abstract interface ILkgUserCityService
{
  public abstract String getDmCity(String paramString1, String paramString2);

  public abstract List<ICity> getAllCity()
    throws ServiceException;

  public abstract List<ICity> getAllCounty()
    throws ServiceException;

  public abstract ICity getCityById(String paramString);

  public abstract List<ICity> getSubCitysById(String paramString)
    throws ServiceException;

  public abstract List<ICity> getCitysByUserId(String paramString)
    throws ServiceException;

  public abstract String getDmCity(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserCityService
 * JD-Core Version:    0.6.2
 */
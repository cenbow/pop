package com.ai.bdx.frame.privilegeServiceExt.service;

import com.asiainfo.biframe.privilege.IUserCompany;
import java.util.List;

public abstract interface ILkgUserCompanyService
{
  public abstract List<IUserCompany> getAllDept();

  public abstract IUserCompany getUserCompany(String paramString);

  public abstract List<IUserCompany> getSubCompanyById(String paramString);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserCompanyService
 * JD-Core Version:    0.6.2
 */
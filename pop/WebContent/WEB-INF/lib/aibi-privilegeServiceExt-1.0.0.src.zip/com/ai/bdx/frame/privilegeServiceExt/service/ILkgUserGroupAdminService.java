package com.ai.bdx.frame.privilegeServiceExt.service;

import java.util.List;

public abstract interface ILkgUserGroupAdminService
{
  public abstract List getUsersByGroupId(String paramString);

  public abstract List getRightByGroup(String paramString, int paramInt1, int paramInt2, boolean paramBoolean);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserGroupAdminService
 * JD-Core Version:    0.6.2
 */
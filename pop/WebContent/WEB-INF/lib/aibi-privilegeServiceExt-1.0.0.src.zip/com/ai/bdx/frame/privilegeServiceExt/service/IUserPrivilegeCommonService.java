package com.ai.bdx.frame.privilegeServiceExt.service;

import com.ai.bdx.frame.privilegeServiceExt.bean.TreeNode;
import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgFuncFolder;
import com.asiainfo.biframe.exception.ServiceException;
import com.asiainfo.biframe.privilege.ICity;
import com.asiainfo.biframe.privilege.IMenuItem;
import com.asiainfo.biframe.privilege.IUser;
import com.asiainfo.biframe.privilege.IUserCompany;
import com.asiainfo.biframe.privilege.IUserRight;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

public abstract interface IUserPrivilegeCommonService
{
  public abstract IUser getUser(String paramString)
    throws ServiceException;

  public abstract List getUsersByCompany(String paramString)
    throws ServiceException;

  public abstract List<IUserCompany> getAllUserCompany()
    throws ServiceException;

  public abstract List<IUserCompany> getSubUserCompanyByPId(String paramString)
    throws ServiceException;

  public abstract List<IUserCompany> getAllSubCompanyByPId(String paramString)
    throws ServiceException;

  public abstract IUserCompany getUserCompanyById(String paramString);

  public abstract String getUserDmCity(String paramString1, String paramString2)
    throws ServiceException;

  public abstract String getUserDmCity(String paramString)
    throws ServiceException;

  public abstract String getUserDmCounty(String paramString)
    throws ServiceException;

  public abstract String getUserDmDept(String paramString)
    throws ServiceException;

  public abstract String getUserDmAll(String paramString)
    throws ServiceException;

  public abstract List getAllUser()
    throws ServiceException;

  public abstract List<IUserRight> getRight(String paramString, int paramInt1, int paramInt2)
    throws ServiceException;

  public abstract List<ICity> getAllCity()
    throws ServiceException;

  public abstract List<ICity> getSubCity(String paramString)
    throws ServiceException;

  public abstract List<ICity> getAllCityByUser(String paramString)
    throws ServiceException;

  public abstract ICity getCityById(String paramString)
    throws ServiceException;

  public abstract List<IMenuItem> getAllMenuItem(String paramString)
    throws ServiceException;

  public abstract List<IMenuItem> getSubDirectlyMenuItem(String paramString1, String paramString2)
    throws ServiceException;

  public abstract List<IMenuItem> getSubAllMenuItem(String paramString1, String paramString2)
    throws ServiceException;

  public abstract List<IUser> getAllGroupUsersByUserId(String paramString)
    throws ServiceException;

  public abstract boolean isAdminUser(String paramString);

  public abstract String getCityNamesByIds(String paramString);

  public abstract boolean isCityAdminUser(String paramString);

  public abstract boolean isCityAdminGroup(String paramString);

  public abstract ICity getUserActualCity(String paramString);

  public abstract List<TreeNode> getMenuTree(HttpServletRequest paramHttpServletRequest, String paramString1, String paramString2)
    throws Exception;

  public abstract List<IMenuItem> getDirectlySubMenuItems(String paramString1, String paramString2)
    throws Exception;

  public abstract List<IMenuItem> getAllSubMenuItems(String paramString1, String paramString2)
    throws Exception;

  public abstract String getUserCityPolicyCache(String paramString)
    throws Exception;

  public abstract boolean isUserAdmin(String paramString1, String paramString2)
    throws Exception;

  public abstract List getUserMenuPolicyCache(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract List getUserSubMenuPolicy(HttpServletRequest paramHttpServletRequest, String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract List getUserDmCityList(String paramString)
    throws Exception;

  public abstract List getUserCityList(String paramString)
    throws Exception;

  public abstract List getUserCityObj(String paramString)
    throws Exception;

  public abstract List<LkgFuncFolder> getSubAllFuncFolder(String paramString1, String paramString2);

  public abstract List<IUser> getUserList(List<String> paramList)
    throws ServiceException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService
 * JD-Core Version:    0.6.2
 */
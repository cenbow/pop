/*     */ package com.ai.bdx.frame.privilegeServiceExt.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IRoleRightMapDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgRoleAdminService;
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import com.asiainfo.biframe.privilege.IUserRight;
/*     */ import com.asiainfo.biframe.privilege.IUserRole;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class LkgRoleAdminServiceImpl
/*     */   implements ILkgRoleAdminService
/*     */ {
/*  18 */   private static Logger log = LogManager.getLogger();
/*     */   private IRoleRightMapDao roleRightDao;
/*     */ 
/*     */   public IRoleRightMapDao getRoleRightDao()
/*     */   {
/*  25 */     return this.roleRightDao;
/*     */   }
/*     */ 
/*     */   public void setRoleRightDao(IRoleRightMapDao roleRightDao) {
/*  29 */     this.roleRightDao = roleRightDao;
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getAllRights(int roleType, int resourceType)
/*     */   {
/*     */     try
/*     */     {
/*  42 */       List paramList = new ArrayList();
/*  43 */       paramList.add(Integer.valueOf(roleType));
/*  44 */       return getRoleRightDao().getRightsByRoles(paramList);
/*     */     } catch (Exception e) {
/*  46 */       e.printStackTrace();
/*  47 */       log.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*     */     }
/*     */ 
/*  51 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail"));
/*     */   }
/*     */ 
/*     */   public List<IUserRole> filterRoleByType(List<IUserRole> roleList, int roleType, int resourceType)
/*     */   {
/*  76 */     return roleList;
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getRightsByRoleIdList(List<String> roleIdList, int roleType, int resourceType, boolean isDistinctControlType)
/*     */   {
/*     */     try
/*     */     {
/*  96 */       if ((roleIdList == null) || (roleIdList.isEmpty())) {
/*  97 */         return new ArrayList();
/*     */       }
/*  99 */       return getRoleRightDao().getRightsByRoles(roleIdList);
/*     */     } catch (Exception e) {
/* 101 */       e.printStackTrace();
/* 102 */       log.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*     */     }
/*     */ 
/* 107 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail"));
/*     */   }
/*     */ 
/*     */   public IMenuItem getMenuItemById(String memuItemId)
/*     */   {
/* 112 */     return getRoleRightDao().getMenuItemById(memuItemId);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.impl.LkgRoleAdminServiceImpl
 * JD-Core Version:    0.6.2
 */
/*    */ package com.ai.bdx.frame.privilegeServiceExt.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.IRoleRightMapDao;
/*    */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgRoleAdminService;
/*    */ import com.asiainfo.biframe.privilege.IMenuItem;
/*    */ import com.asiainfo.biframe.privilege.IUserRight;
/*    */ import com.asiainfo.biframe.privilege.IUserRole;
/*    */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class LkgRoleMenuServiceImpl
/*    */   implements ILkgRoleAdminService
/*    */ {
/* 23 */   private static Logger log = LogManager.getLogger();
/*    */   private IRoleRightMapDao roleRightDao;
/*    */ 
/*    */   public IRoleRightMapDao getRoleRightDao()
/*    */   {
/* 27 */     return this.roleRightDao;
/*    */   }
/*    */ 
/*    */   public void setRoleRightDao(IRoleRightMapDao roleRightDao) {
/* 31 */     this.roleRightDao = roleRightDao;
/*    */   }
/*    */ 
/*    */   public List<IUserRole> filterRoleByType(List<IUserRole> roleList, int roleType, int resourceType)
/*    */   {
/* 36 */     return roleList;
/*    */   }
/*    */ 
/*    */   public List<IUserRight> getAllRights(int roleType, int resourceType) {
/* 40 */     return getRoleRightDao().getMenuItems();
/*    */   }
/*    */ 
/*    */   public List<IUserRight> getRightsByRoleIdList(List<String> roleIdList, int roleType, int resourceType, boolean isDistinctControlType)
/*    */   {
/*    */     try {
/* 46 */       if ((roleIdList == null) || (roleIdList.isEmpty())) {
/* 47 */         return new ArrayList();
/*    */       }
/* 49 */       return getRoleRightDao().getRightsByRoles(roleIdList);
/*    */     } catch (Exception e) {
/* 51 */       e.printStackTrace();
/* 52 */       log.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*    */     }
/*    */ 
/* 57 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail"));
/*    */   }
/*    */ 
/*    */   public IMenuItem getMenuItemById(String memuItemId)
/*    */   {
/* 62 */     return this.roleRightDao.getMenuItemById(memuItemId);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.impl.LkgRoleMenuServiceImpl
 * JD-Core Version:    0.6.2
 */
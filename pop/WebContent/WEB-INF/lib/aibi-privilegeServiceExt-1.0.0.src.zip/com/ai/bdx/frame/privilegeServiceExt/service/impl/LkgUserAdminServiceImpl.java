/*     */ package com.ai.bdx.frame.privilegeServiceExt.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IGroupRoleMapDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserGroupMapDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserRoleDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserRoleMapDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserUserDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaff;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgRoleAdminService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserAdminService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserCityService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserCompanyService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.util.PrivilegeListUtil;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.ICity;
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.privilege.IUserGroup;
/*     */ import com.asiainfo.biframe.privilege.IUserRight;
/*     */ import com.asiainfo.biframe.privilege.IUserRole;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.model.SearchCondition;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class LkgUserAdminServiceImpl
/*     */   implements ILkgUserAdminService
/*     */ {
/*  34 */   private static Logger log = LogManager.getLogger();
/*     */   private ILkgUserCityService userCityService;
/*     */   private ILkgUserCompanyService userCompanyService;
/*     */   private ILkgRoleAdminService roleAdminService;
/*     */   private IUserUserDao userUserDao;
/*     */   private IUserGroupMapDao userGroupMapDao;
/*     */   private IUserRoleDao userRoleDao;
/*     */   private IGroupRoleMapDao groupRoleMapDao;
/*     */   private IUserRoleMapDao userRoleMapDao;
/*     */ 
/*     */   public IUserRoleMapDao getUserRoleMapDao()
/*     */   {
/*  46 */     return this.userRoleMapDao;
/*     */   }
/*     */ 
/*     */   public void setUserRoleMapDao(IUserRoleMapDao userRoleMapDao) {
/*  50 */     this.userRoleMapDao = userRoleMapDao;
/*     */   }
/*     */ 
/*     */   public IGroupRoleMapDao getGroupRoleMapDao() {
/*  54 */     return this.groupRoleMapDao;
/*     */   }
/*     */ 
/*     */   public void setGroupRoleMapDao(IGroupRoleMapDao groupRoleMapDao) {
/*  58 */     this.groupRoleMapDao = groupRoleMapDao;
/*     */   }
/*     */ 
/*     */   public IUserRoleDao getUserRoleDao() {
/*  62 */     return this.userRoleDao;
/*     */   }
/*     */ 
/*     */   public void setUserRoleDao(IUserRoleDao userRoleDao) {
/*  66 */     this.userRoleDao = userRoleDao;
/*     */   }
/*     */ 
/*     */   public ILkgUserCityService getUserCityService() {
/*  70 */     return this.userCityService;
/*     */   }
/*     */ 
/*     */   public void setUserCityService(ILkgUserCityService userCityService) {
/*  74 */     this.userCityService = userCityService;
/*     */   }
/*     */ 
/*     */   public IUserUserDao getUserUserDao() {
/*  78 */     return this.userUserDao;
/*     */   }
/*     */ 
/*     */   public void setUserUserDao(IUserUserDao userUserDao) {
/*  82 */     this.userUserDao = userUserDao;
/*     */   }
/*     */ 
/*     */   public ILkgUserCompanyService getUserCompanyService() {
/*  86 */     return this.userCompanyService;
/*     */   }
/*     */ 
/*     */   public void setUserCompanyService(ILkgUserCompanyService userCompanyService) {
/*  90 */     this.userCompanyService = userCompanyService;
/*     */   }
/*     */ 
/*     */   public IUserGroupMapDao getUserGroupMapDao() {
/*  94 */     return this.userGroupMapDao;
/*     */   }
/*     */ 
/*     */   public void setUserGroupMapDao(IUserGroupMapDao userGroupMapDao) {
/*  98 */     this.userGroupMapDao = userGroupMapDao;
/*     */   }
/*     */ 
/*     */   public ILkgRoleAdminService getRoleAdminService() {
/* 102 */     return this.roleAdminService;
/*     */   }
/*     */ 
/*     */   public void setRoleAdminService(ILkgRoleAdminService roleAdminService) {
/* 106 */     this.roleAdminService = roleAdminService;
/*     */   }
/*     */ 
/*     */   public List<ICity> getAllCity()
/*     */     throws ServiceException
/*     */   {
/* 116 */     return getUserCityService().getAllCity();
/*     */   }
/*     */ 
/*     */   public List<ICity> getAllCounty()
/*     */     throws ServiceException
/*     */   {
/* 126 */     return getUserCityService().getAllCounty();
/*     */   }
/*     */ 
/*     */   public List<IUser> getAllUser()
/*     */     throws ServiceException
/*     */   {
/* 136 */     return getUserUserDao().listUsers();
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getAllUserCompany()
/*     */     throws ServiceException
/*     */   {
/* 146 */     return getUserCompanyService().getAllDept();
/*     */   }
/*     */ 
/*     */   public ICity getCityById(String cityId)
/*     */     throws ServiceException
/*     */   {
/* 157 */     return getUserCityService().getCityById(cityId);
/*     */   }
/*     */ 
/*     */   public List<ICity> getCityByUser(String userId)
/*     */     throws ServiceException
/*     */   {
/* 168 */     return getUserCityService().getCitysByUserId(userId);
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getRight(String userId, int roleType, int resourceType, boolean isDistinctControlType)
/*     */     throws ServiceException
/*     */   {
/* 182 */     log.debug("in getRight");
/*     */     try {
/* 184 */       if (isAdminUser(userId)) {
/* 185 */         log.debug("is adminUser");
/* 186 */         return getRoleAdminService().getAllRights(roleType, resourceType);
/*     */       }
/* 188 */       List roleList = getAllRoles(userId, roleType, resourceType);
/* 189 */       List roleIdList = PrivilegeListUtil.convertToNewList(roleList, "RoleId");
/*     */ 
/* 192 */       List rightList = getRoleAdminService().getRightsByRoleIdList(roleIdList, roleType, resourceType, isDistinctControlType);
/*     */ 
/* 197 */       log.debug("end getRight");
/* 198 */       return rightList;
/*     */     } catch (Exception e) {
/* 200 */       e.printStackTrace();
/* 201 */       log.error("getResourceDefineBeanRight " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*     */     }
/*     */ 
/* 205 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserAuthFail") + userId);
/*     */   }
/*     */ 
/*     */   public List<ICity> getSubCitysById(String parentCityId)
/*     */     throws ServiceException
/*     */   {
/* 219 */     return getUserCityService().getSubCitysById(parentCityId);
/*     */   }
/*     */ 
/*     */   public IUser getUser(String userId)
/*     */     throws ServiceException
/*     */   {
/* 230 */     log.debug("in findUser");
/* 231 */     IUser user = getUserUserDao().findById(userId);
/* 232 */     return user;
/*     */   }
/*     */ 
/*     */   public IUserCompany getUserCompanyById(String companyId)
/*     */   {
/* 242 */     return getUserCompanyService().getUserCompany(companyId);
/*     */   }
/*     */ 
/*     */   public String getUserDmCity(String userId, String dmType)
/*     */     throws ServiceException
/*     */   {
/* 258 */     return getUserCityService().getDmCity(userId, dmType);
/*     */   }
/*     */ 
/*     */   public List getUsersOfDepartment(int departmentid)
/*     */   {
/* 269 */     SearchCondition condition = new SearchCondition();
/* 270 */     condition.setQueryDepartmentid(departmentid);
/* 271 */     condition.setQueryStatus(Integer.valueOf("0").intValue());
/*     */ 
/* 273 */     return getUserUserDao().findAll(condition);
/*     */   }
/*     */ 
/*     */   private List<IUserGroup> getUserGroupByUserId(List<String> userIds) {
/* 277 */     return getUserGroupMapDao().getGroupByUserId(userIds);
/*     */   }
/*     */ 
/*     */   public boolean isAdminUser(String userid)
/*     */   {
/* 286 */     boolean flag = false;
/* 287 */     List roleList = getAllRoles(userid);
/* 288 */     if ((roleList != null) && (!roleList.isEmpty())) {
/* 289 */       for (IUserRole role : roleList) {
/* 290 */         if ("10001".equals(role.getRoleId())) {
/* 291 */           flag = true;
/* 292 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 296 */     return flag;
/*     */   }
/*     */ 
/*     */   private String getGroup(String userid)
/*     */   {
/*     */     try
/*     */     {
/* 306 */       IUserGroup group = getGroupObject(userid);
/* 307 */       if (group == null) {
/* 308 */         return null;
/*     */       }
/* 310 */       return group.getGroupid();
/*     */     } catch (Exception e) {
/* 312 */       e.printStackTrace();
/* 313 */     }throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserGroupFail"));
/*     */   }
/*     */ 
/*     */   public IUserGroup getGroupObject(String userid)
/*     */   {
/*     */     try
/*     */     {
/* 325 */       List list = getUserGroupMapDao().getGroupByUserId(userid);
/* 326 */       if ((list != null) && (list.size() > 0)) {
/* 327 */         return (IUserGroup)list.get(0);
/*     */       }
/* 329 */       return null;
/*     */     } catch (Exception e) {
/* 331 */       e.printStackTrace();
/*     */     }
/* 333 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserGroupFail"));
/*     */   }
/*     */ 
/*     */   public List<IUserRole> getAllRoles(String userId)
/*     */   {
/* 343 */     log.debug("in getAllRoles");
/*     */ 
/* 347 */     List roleListByGroup = getRolesByGroupId(getGroup(userId));
/* 348 */     List roleListByUser = getRolesByUserId(userId);
/* 349 */     List list = StringUtil.getDistinctList(new List[] { roleListByGroup, roleListByUser });
/* 350 */     log.debug("----------last role size=" + list.size());
/* 351 */     log.debug("end getAllRoles");
/* 352 */     return list;
/*     */   }
/*     */ 
/*     */   private List<IUserRole> getAllRoles(String userId, int roleType, int resourceType)
/*     */   {
/* 363 */     List allRoleList = getAllRoles(userId);
/*     */ 
/* 365 */     return getRoleAdminService().filterRoleByType(allRoleList, roleType, resourceType);
/*     */   }
/*     */ 
/*     */   private List<IUserRole> getRolesByGroupId(String groupId)
/*     */   {
/* 374 */     return getGroupRoleMapDao().findRoleListByGroupId(groupId);
/*     */   }
/*     */ 
/*     */   private List<IUserRole> getRolesByUserId(String userId)
/*     */   {
/* 386 */     return getUserRoleMapDao().getRolesByUserId(userId);
/*     */   }
/*     */ 
/*     */   private String getUserCity(String userid) {
/* 390 */     IUser user = getUser(userid);
/* 391 */     if (user == null) {
/* 392 */       return "";
/*     */     }
/* 394 */     return user.getCityid();
/*     */   }
/*     */ 
/*     */   public String getDmCity(String userId, String resourceId, String dmType, String dbType, boolean isShow) {
/* 398 */     return getUserCityService().getDmCity(userId, dmType);
/*     */   }
/*     */ 
/*     */   public IMenuItem getMenuItemById(String memuItemId) {
/* 402 */     return getRoleAdminService().getMenuItemById(memuItemId);
/*     */   }
/*     */ 
/*     */   private LkgStaff findEntityById(String id) {
/* 406 */     return getUserUserDao().findEntityById(id);
/*     */   }
/*     */ 
/*     */   public String getSensitiveLevel(String userId) throws ServiceException {
/*     */     try {
/* 411 */       log.debug("in getSensitiveLevel");
/* 412 */       if (StringUtils.isBlank(userId)) {
/* 413 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.user") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.cannotQuerySensitiveLevel") + "!");
/*     */       }
/*     */ 
/* 419 */       LkgStaff user = findEntityById(userId);
/* 420 */       if (user == null) {
/* 421 */         throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.userNotExistNoLevel") + "!");
/*     */       }
/*     */ 
/* 426 */       log.debug("end getSensitiveLevel");
/* 427 */       return user.getStaffTactLevel();
/*     */     } catch (Exception e) {
/* 429 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryLevelFail") + "", e);
/*     */     }
/*     */ 
/* 432 */     throw new ServiceException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.queryLevelFail") + "");
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getSubCompanyById(String companyId)
/*     */   {
/* 440 */     return getUserCompanyService().getSubCompanyById(companyId);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.impl.LkgUserAdminServiceImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.privilegeServiceExt.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserCityDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserScope;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserCityService;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.ICity;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class LkgUserCityServiceImpl
/*     */   implements ILkgUserCityService
/*     */ {
/*  19 */   private static Logger log = LogManager.getLogger();
/*     */   private IUserCityDao userCityDao;
/*     */ 
/*     */   public IUserCityDao getUserCityDao()
/*     */   {
/*  23 */     return this.userCityDao;
/*     */   }
/*     */ 
/*     */   public void setUserCityDao(IUserCityDao userCityDao) {
/*  27 */     this.userCityDao = userCityDao;
/*     */   }
/*     */ 
/*     */   public String getDmCity(String userId, String dmType)
/*     */   {
/*  40 */     String returnValue = "";
/*  41 */     IUserScope userScope = getUserCityDao().getUserScope(userId);
/*  42 */     if ("-1".equals(dmType)) {
/*  43 */       returnValue = userScope.getProvScope();
/*  44 */     } else if ("CITY".equals(dmType)) {
/*  45 */       returnValue = userScope.getCityScope();
/*  46 */       if ("anhui".equals(Configure.getInstance().getProperty("PROVINCE")))
/*  47 */         if (returnValue.equals("V")) {
/*  48 */           List citys = getAllCity();
/*  49 */           StringBuffer sb = new StringBuffer();
/*  50 */           for (ICity city : citys) {
/*  51 */             if (sb.length() > 0) {
/*  52 */               sb.append(",");
/*     */             }
/*  54 */             sb.append(city.getCityId());
/*     */           }
/*  56 */           returnValue = sb.toString();
/*     */         } else {
/*  58 */           returnValue = getUserCityDao().getCityByOldId(returnValue).getCityId();
/*     */         }
/*     */     }
/*  61 */     else if ("COUNTY".equals(dmType)) {
/*  62 */       returnValue = userScope.getCountryScope();
/*  63 */       if ("anhui".equals(Configure.getInstance().getProperty("PROVINCE")))
/*  64 */         returnValue = getUserCityDao().getCountryIdByOldId(userScope.getCountryScope());
/*     */     }
/*  66 */     else if ("DEPT".equals(dmType)) {
/*  67 */       returnValue = userScope.getAreaScope();
/*     */     } else {
/*  69 */       returnValue = "";
/*     */     }
/*  71 */     return returnValue;
/*     */   }
/*     */ 
/*     */   public List<ICity> getAllCity()
/*     */     throws ServiceException
/*     */   {
/*  81 */     return getUserCityDao().getAllCity();
/*     */   }
/*     */ 
/*     */   public List<ICity> getAllCounty()
/*     */     throws ServiceException
/*     */   {
/*  91 */     return getUserCityDao().getAllCounty();
/*     */   }
/*     */ 
/*     */   public ICity getCityById(String cityId)
/*     */   {
/* 102 */     return getUserCityDao().getCityById(cityId);
/*     */   }
/*     */ 
/*     */   public List<ICity> getSubCitysById(String parentCityId)
/*     */     throws ServiceException
/*     */   {
/* 113 */     return getUserCityDao().getCityByParentId(parentCityId);
/*     */   }
/*     */ 
/*     */   public List<ICity> getCitysByUserId(String userId)
/*     */     throws ServiceException
/*     */   {
/* 119 */     log.debug("获取用户权限地市开始：");
/* 120 */     Map queryMap = new HashMap();
/*     */     try {
/* 122 */       IUserScope userScope = getUserCityDao().getUserScope(userId);
/*     */ 
/* 124 */       if (userScope != null) {
/* 125 */         String prov = userScope.getProvScope();
/* 126 */         String city = userScope.getCityScope();
/* 127 */         String country = userScope.getCountryScope();
/*     */ 
/* 129 */         if (("290".equals(prov)) && ("290".equals(city)) && ("0000".equals(country))) {
/* 130 */           queryMap.put("prov", prov);
/* 131 */         } else if (("290".equals(prov)) && ("0000".equals(country))) {
/* 132 */           String newCity = getUserCityDao().getCityByOldId(city).getCityId();
/* 133 */           queryMap.put("city", newCity);
/*     */         }
/* 135 */         if ("anhui".equals(Configure.getInstance().getProperty("PROVINCE")))
/* 136 */           if (("V".equals(prov)) && ("V".equals(city)) && ("0000".equals(country))) {
/* 137 */             queryMap.put("prov", prov);
/*     */           } else {
/* 139 */             String newCity = getUserCityDao().getCityByOldId(city).getCityId();
/* 140 */             queryMap.put("city", newCity);
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 145 */       log.error("", e);
/*     */     }
/*     */ 
/* 148 */     return getUserCityDao().getCitysByUserId(queryMap);
/*     */   }
/*     */ 
/*     */   public String getDmCity(String userId, String resourceId, String dmType, String dbType, boolean isShow) {
/* 152 */     return getDmCity(userId, dbType);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.impl.LkgUserCityServiceImpl
 * JD-Core Version:    0.6.2
 */
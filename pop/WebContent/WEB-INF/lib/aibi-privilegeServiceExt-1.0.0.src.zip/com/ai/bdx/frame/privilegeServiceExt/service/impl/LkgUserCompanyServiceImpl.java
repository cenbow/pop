/*    */ package com.ai.bdx.frame.privilegeServiceExt.service.impl;
/*    */ 
/*    */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserDeptDao;
/*    */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserCompanyService;
/*    */ import com.asiainfo.biframe.exception.BaseRuntimeException;
/*    */ import com.asiainfo.biframe.privilege.IUserCompany;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class LkgUserCompanyServiceImpl
/*    */   implements ILkgUserCompanyService
/*    */ {
/* 15 */   private static Logger log = LogManager.getLogger();
/*    */   private IUserDeptDao userDeptDao;
/*    */ 
/*    */   public IUserDeptDao getUserDeptDao()
/*    */   {
/* 19 */     return this.userDeptDao;
/*    */   }
/*    */ 
/*    */   public void setUserDeptDao(IUserDeptDao userDeptDao) {
/* 23 */     this.userDeptDao = userDeptDao;
/*    */   }
/*    */ 
/*    */   public List<IUserCompany> getAllDept() {
/*    */     try {
/* 28 */       return getUserDeptDao().getDeptAll();
/*    */     } catch (Exception e) {
/* 30 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getAllDeptFail") + "", e);
/*    */ 
/* 33 */       throw new BaseRuntimeException(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getAllDeptFail") + ":" + e.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public IUserCompany getUserCompany(String deptId)
/*    */   {
/*    */     try
/*    */     {
/* 41 */       return getUserDeptDao().getDeptById(deptId);
/*    */     } catch (Exception e) {
/* 43 */       log.error("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.byDept") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getDeptFail") + "", e);
/*    */ 
/* 45 */       throw new BaseRuntimeException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.byDept") + "id" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getDeptFail") + ":" + e.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public List<IUserCompany> getSubCompanyById(String companyId)
/*    */   {
/* 55 */     return getUserDeptDao().getSubCompanyById(companyId);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.impl.LkgUserCompanyServiceImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.privilegeServiceExt.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserGroupMapDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.IUserRoleDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgRoleAdminService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserAdminService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserGroupAdminService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.util.PrivilegeListUtil;
/*     */ import com.asiainfo.biframe.privilege.IUserRight;
/*     */ import com.asiainfo.biframe.privilege.IUserRole;
/*     */ import com.asiainfo.biframe.privilege.base.util.SpringUtil;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.exception.SysmanageException;
/*     */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class LkgUserGroupAdminServiceImpl
/*     */   implements ILkgUserGroupAdminService
/*     */ {
/*  23 */   private static Logger log = LogManager.getLogger();
/*     */   private IUserGroupMapDao userGroupMapDao;
/*     */   private IUserRoleDao userRoleDao;
/*     */ 
/*     */   public IUserRoleDao getUserRoleDao()
/*     */   {
/*  28 */     return this.userRoleDao;
/*     */   }
/*     */ 
/*     */   public void setUserRoleDao(IUserRoleDao userRoleDao) {
/*  32 */     this.userRoleDao = userRoleDao;
/*     */   }
/*     */ 
/*     */   public IUserGroupMapDao getUserGroupMapDao() {
/*  36 */     return this.userGroupMapDao;
/*     */   }
/*     */ 
/*     */   public void setUserGroupMapDao(IUserGroupMapDao userGroupMapDao) {
/*  40 */     this.userGroupMapDao = userGroupMapDao;
/*     */   }
/*     */ 
/*     */   public List getUsersByGroupId(String groupId)
/*     */   {
/*  51 */     log.debug("in getUserByGroupId");
/*     */     try {
/*  53 */       return getUserGroupMapDao().findAllUserByGId(groupId);
/*     */     } catch (Exception e) {
/*  55 */       e.printStackTrace();
/*     */     }
/*  57 */     throw new SysmanageException("" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getUserByConditionFail") + "");
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getRightByGroup(String groupId, int roleType, int resourceType, boolean isDistinctControlType)
/*     */   {
/*     */     try
/*     */     {
/*  64 */       if (isAdminGroup(groupId)) {
/*  65 */         return getRoleAdminService().getAllRights(roleType, resourceType);
/*     */       }
/*     */ 
/*  68 */       List roleList = getRoleListByGroupId(groupId);
/*  69 */       if ((roleList == null) || (roleList.size() == 0)) {
/*  70 */         return new ArrayList();
/*     */       }
/*     */ 
/*  73 */       List roleIdList = PrivilegeListUtil.convertToNewList(roleList, "RoleId");
/*     */ 
/*  75 */       return getRoleAdminService().getRightsByRoleIdList(roleIdList, roleType, resourceType, isDistinctControlType);
/*     */     }
/*     */     catch (Exception e) {
/*  78 */       e.printStackTrace();
/*  79 */       log.error("getRightByGroup " + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.exceptionOccur") + "", e);
/*     */     }
/*     */ 
/*  83 */     throw new SysmanageException(groupId + "" + LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.getGroupRightFail") + "");
/*     */   }
/*     */ 
/*     */   private boolean isAdminGroup(String groupId)
/*     */   {
/*  89 */     return "1".equals(groupId);
/*     */   }
/*     */ 
/*     */   private ILkgRoleAdminService getRoleAdminService() {
/*  93 */     return (ILkgRoleAdminService)SpringUtil.getBean("lkg_roleAdminService");
/*     */   }
/*     */ 
/*     */   private ILkgUserAdminService getUserAdminService() {
/*  97 */     return (ILkgUserAdminService)SpringUtil.getBean("lkg_userAdminService");
/*     */   }
/*     */ 
/*     */   public List<IUserRole> getRoleListByGroupId(String groupId) {
/* 101 */     if (isAdminGroup(groupId)) {
/* 102 */       return getUserRoleDao().findAllRoles();
/*     */     }
/* 104 */     return getUserRoleDao().findRoleListByGroupId(groupId);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.impl.LkgUserGroupAdminServiceImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.privilegeServiceExt.service.impl;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.bean.TreeNode;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.dao.ILkgFuncFolderDao;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgFuncFolder;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.model.privilege.LkgStaffCompany;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.IUserPrivilegeCommonService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.util.DataSourceFactory;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.util.PrivilegeListUtil;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.util.SysMenuMaintain;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.ICity;
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*     */ import com.asiainfo.biframe.privilege.IUserRight;
/*     */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*     */ import com.asiainfo.biframe.privilege.model.SysMenuItem;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.impl.ListService;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import com.mysql.jdbc.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.lang.NumberUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ 
/*     */ public class UserPrivilegeCommonServiceImpl
/*     */   implements IUserPrivilegeCommonService
/*     */ {
/*  48 */   private static Logger log = LogManager.getLogger();
/*     */   private IUserPrivilegeService userPrivilegeService;
/*     */   private ILkgFuncFolderDao lkgFuncFolderDao;
/*     */ 
/*     */   public IUserPrivilegeService getUserPrivilegeService()
/*     */   {
/*  54 */     return this.userPrivilegeService;
/*     */   }
/*     */ 
/*     */   public void setLkgFuncFolderDao(ILkgFuncFolderDao lkgFuncFolderDao) {
/*  58 */     this.lkgFuncFolderDao = lkgFuncFolderDao;
/*     */   }
/*     */ 
/*     */   public void setUserPrivilegeService(IUserPrivilegeService userPrivilegeService) {
/*  62 */     this.userPrivilegeService = userPrivilegeService;
/*     */   }
/*     */ 
/*     */   public List getAllUser() throws ServiceException {
/*  66 */     return this.userPrivilegeService.getAllUsers();
/*     */   }
/*     */ 
/*     */   public List getUsersByCompany(String companyId) throws ServiceException {
/*  70 */     if ((companyId == null) || ("".equals(companyId)) || (!NumberUtils.isNumber(companyId))) {
/*  71 */       return new ArrayList();
/*     */     }
/*     */ 
/*  74 */     return this.userPrivilegeService.getUsersOfDepartment(Integer.parseInt(companyId));
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getAllUserCompany() throws ServiceException {
/*  78 */     return this.userPrivilegeService.getAllUserCompany();
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getRight(String userId, int roleType, int resourceType) throws ServiceException {
/*  82 */     return this.userPrivilegeService.getRight(userId, roleType, resourceType);
/*     */   }
/*     */ 
/*     */   public IUser getUser(String userId) throws ServiceException {
/*  86 */     return this.userPrivilegeService.getUser(userId);
/*     */   }
/*     */ 
/*     */   public List<IUser> getAllGroupUsersByUserId(String userId) throws ServiceException {
/*  90 */     List allUsers = new ArrayList();
/*  91 */     IUser user = this.userPrivilegeService.getUser(userId);
/*  92 */     if (user != null) {
/*  93 */       String groupId = user.getGroupId();
/*  94 */       allUsers = this.userPrivilegeService.getUsersByGroupId(groupId);
/*     */     }
/*     */ 
/*  97 */     log.debug("users in the group includes [" + userId + "] is :" + allUsers.size());
/*     */ 
/*  99 */     return allUsers;
/*     */   }
/*     */ 
/*     */   public IUserCompany getUserCompanyById(String companyId)
/*     */   {
/* 104 */     return this.userPrivilegeService.getUserCompanyById(companyId);
/*     */   }
/*     */ 
/*     */   public String getUserDmCity(String userId, String dmType) throws ServiceException {
/* 108 */     return this.userPrivilegeService.getUserDmCity(userId, dmType);
/*     */   }
/*     */ 
/*     */   public List<ICity> getAllCity() throws ServiceException {
/* 112 */     return this.userPrivilegeService.getAllCity();
/*     */   }
/*     */ 
/*     */   public List<ICity> getSubCity(String cityId) throws ServiceException {
/* 116 */     return this.userPrivilegeService.getSubCitysById(cityId);
/*     */   }
/*     */ 
/*     */   public List<ICity> getAllCityByUser(String userId) throws ServiceException {
/* 120 */     List list = new ArrayList();
/*     */     try {
/* 122 */       list = this.userPrivilegeService.getCityByUser(userId);
/*     */     } catch (Exception e) {
/* 124 */       log.error(e);
/*     */     }
/* 126 */     return list;
/*     */   }
/*     */ 
/*     */   public ICity getCityById(String cityId) throws ServiceException {
/* 130 */     return this.userPrivilegeService.getCityByCityID(cityId);
/*     */   }
/*     */ 
/*     */   public List<IMenuItem> getAllMenuItem(String userId) throws ServiceException {
/* 134 */     return this.userPrivilegeService.getAllMenuItem(userId);
/*     */   }
/*     */ 
/*     */   public List<IMenuItem> getSubDirectlyMenuItem(String userId, String menuId)
/*     */     throws ServiceException
/*     */   {
/* 145 */     if (NumberUtils.isNumber(menuId)) {
/* 146 */       return this.userPrivilegeService.getSubMenuItemById(Integer.valueOf(Integer.parseInt(menuId)), userId, false);
/*     */     }
/* 148 */     log.debug("menuId is invalid.");
/*     */ 
/* 150 */     return new ArrayList();
/*     */   }
/*     */ 
/*     */   public List<IMenuItem> getSubAllMenuItem(String userId, String menuId) throws ServiceException
/*     */   {
/* 155 */     return getSubMenuItemById(userId, menuId, true);
/*     */   }
/*     */ 
/*     */   public String getUserDmAll(String userId) throws ServiceException {
/* 159 */     return this.userPrivilegeService.getUserDmCity(userId, "-1");
/*     */   }
/*     */ 
/*     */   public String getUserDmCity(String userId) throws ServiceException {
/* 163 */     return this.userPrivilegeService.getUserDmCity(userId, "CITY");
/*     */   }
/*     */ 
/*     */   public String getUserDmCounty(String userId) throws ServiceException {
/* 167 */     return this.userPrivilegeService.getUserDmCity(userId, "COUNTY");
/*     */   }
/*     */ 
/*     */   public String getUserDmDept(String userId) throws ServiceException {
/* 171 */     return this.userPrivilegeService.getUserDmCity(userId, "DEPT");
/*     */   }
/*     */ 
/*     */   private List<IMenuItem> getSubMenuItemById(String userId, String menuId, boolean flag)
/*     */     throws ServiceException
/*     */   {
/* 183 */     if (NumberUtils.isNumber(menuId)) {
/* 184 */       Sqlca sqlca = null;
/*     */       try {
/* 186 */         sqlca = new Sqlca(new ConnectionEx());
/* 187 */         List subMenuIdList = SysMenuMaintain.getSubMenuItem(sqlca, menuId, flag);
/*     */ 
/* 189 */         if (StringUtil.isNotEmpty(userId)) {
/* 190 */           boolean isOnlyFolder = subMenuIdList.isEmpty();
/* 191 */           if (subMenuIdList.isEmpty()) {
/* 192 */             subMenuIdList.add(menuId);
/*     */           }
/* 194 */           List resourceList = this.userPrivilegeService.getRight(userId, 1, Integer.parseInt("50"));
/* 195 */           List idList = PrivilegeListUtil.convertToNewList(resourceList, "ResourceId");
/* 196 */           subMenuIdList.retainAll(idList);
/* 197 */           List list = PrivilegeListUtil.getMenu(subMenuIdList, resourceList, flag, isOnlyFolder);
/* 198 */           return foreachMenuItemList(list);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 202 */         throw new ServiceException(e.getMessage());
/*     */       } finally {
/* 204 */         if (sqlca != null) {
/* 205 */           sqlca.closeAll();
/*     */         }
/*     */       }
/*     */     }
/* 209 */     log.debug("menuId is invalid.");
/* 210 */     return new ArrayList();
/*     */   }
/*     */ 
/*     */   private List<IMenuItem> foreachMenuItemList(List list) {
/* 214 */     List result = new ArrayList();
/*     */ 
/* 217 */     Collections.sort(list, new Comparator() {
/*     */       public int compare(Object arg0, Object arg1) {
/* 219 */         SysMenuItemBean item0 = (SysMenuItemBean)arg0;
/* 220 */         SysMenuItemBean item1 = (SysMenuItemBean)arg1;
/* 221 */         return new Integer(item0.getMENUITEMID()).compareTo(new Integer(item1.getMENUITEMID()));
/*     */       }
/*     */     });
/* 224 */     Iterator it = list.iterator();
/* 225 */     while (it.hasNext()) {
/* 226 */       SysMenuItemBean smi = (SysMenuItemBean)it.next();
/* 227 */       SysMenuItem menuItem = new SysMenuItem();
/* 228 */       menuItem.setMenuItemId(Integer.valueOf(smi.getMENUITEMID()));
/* 229 */       menuItem.setMenuItemTitle(smi.getMENUITEMTITLE());
/* 230 */       menuItem.setParentId(Integer.valueOf(smi.getPARENTID()));
/* 231 */       menuItem.setMenuType(Integer.valueOf(smi.getMENUTYPE()));
/* 232 */       menuItem.setUrl(smi.getURL());
/* 233 */       menuItem.setAccessToken(Integer.valueOf(smi.getACCESSTOKEN()));
/* 234 */       menuItem.setApplicationId(smi.getApplicationId());
/* 235 */       menuItem.setUrlPort(smi.getURLPORT());
/* 236 */       menuItem.setUrlTarget(smi.getURLTARGET());
/* 237 */       menuItem.setResourceType(Integer.valueOf(smi.getRESTYPE()));
/* 238 */       menuItem.setResId(smi.getRESID());
/* 239 */       menuItem.setSortNum(Integer.valueOf(smi.getSORTNUM()));
/* 240 */       menuItem.setFolderOrNot(StringUtil.isEmpty(menuItem.getUrl()));
/* 241 */       menuItem.setOperationType("-1");
/* 242 */       result.add(menuItem);
/*     */     }
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean isAdminUser(String userid) {
/* 248 */     return this.userPrivilegeService.isAdminUser(userid);
/*     */   }
/*     */ 
/*     */   public boolean isCityAdminUser(String userid)
/*     */   {
/* 257 */     IUser user = this.userPrivilegeService.getUser(userid);
/* 258 */     return isCityAdminGroup(user.getGroupId());
/*     */   }
/*     */ 
/*     */   public boolean isCityAdminGroup(String groupId)
/*     */   {
/* 267 */     String cityGroupId = Configure.getInstance().getProperty("CITY_ADMIN_GROUP_ID");
/* 268 */     if ((StringUtil.isNotEmpty(cityGroupId)) && (StringUtil.isNotEmpty(groupId)) && (cityGroupId.equals(groupId))) {
/* 269 */       return true;
/*     */     }
/* 271 */     return false;
/*     */   }
/*     */ 
/*     */   public String getCityNamesByIds(String cityIds)
/*     */   {
/* 276 */     StringBuffer cityNames = new StringBuffer();
/* 277 */     if (StringUtil.isNotEmpty(cityIds)) {
/* 278 */       List cIds = StringUtils.split(cityIds, ",", true);
/* 279 */       List citys = getAllCity();
/* 280 */       for (ICity city : citys) {
/* 281 */         if ((cIds.contains(city.getCityId())) && 
/* 282 */           (StringUtil.isNotEmpty(city.getCityName()))) {
/* 283 */           cityNames.append(city.getCityName()).append(",");
/*     */         }
/*     */       }
/*     */ 
/* 287 */       if (cityNames.length() > 0) {
/* 288 */         cityNames.deleteCharAt(cityNames.length() - 1);
/*     */       }
/*     */     }
/* 291 */     return cityNames.toString();
/*     */   }
/*     */ 
/*     */   public ICity getUserActualCity(String cityId) {
/* 295 */     ICity actualCity = getCityById(cityId);
/* 296 */     if ((actualCity != null) && (((StringUtil.isNotEmpty(actualCity.getDmCountyId())) && (!"-1".equals(actualCity.getDmCountyId()))) || ((StringUtil.isNotEmpty(actualCity.getDmDeptId())) && (!"-1".equals(actualCity.getDmDeptId())))))
/*     */     {
/* 299 */       actualCity = getUserActualCity(actualCity.getParentId());
/*     */     }
/* 301 */     return actualCity;
/*     */   }
/*     */ 
/*     */   public List<TreeNode> getMenuTree(HttpServletRequest request, String userId, String menuId) throws Exception {
/* 305 */     List list = new ArrayList();
/*     */ 
/* 307 */     String subject = "";
/* 308 */     if (request.getParameter("subject") != null) {
/* 309 */       subject = String.valueOf(request.getParameter("subject"));
/*     */     }
/*     */ 
/* 312 */     List subList = getSubAllMenuItem(userId, menuId);
/* 313 */     for (Iterator it = subList.iterator(); it.hasNext(); ) {
/* 314 */       IMenuItem menuItem = (IMenuItem)it.next();
/*     */ 
/* 316 */       String selfId = "" + menuItem.getMenuItemId();
/*     */ 
/* 318 */       TreeNode node = new TreeNode();
/* 319 */       node.setPid(menuItem.getParentId() + "");
/* 320 */       String oldURL = menuItem.getUrl();
/* 321 */       if ((oldURL != null) && (oldURL.trim().length() > 0)) {
/* 322 */         if (("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE"))) && ("9101".equals(menuId)) && (request.getRequestURL().indexOf("10.131.66.235") > 0))
/*     */         {
/* 324 */           oldURL = oldURL.replace("10.131.34.134", "10.131.66.235");
/*     */         }
/* 326 */         if (oldURL.toLowerCase().indexOf("_summary.jsp") >= 0) {
/* 327 */           node.setHref(request.getContextPath() + oldURL);
/* 328 */         } else if (oldURL.toLowerCase().indexOf("http://") >= 0) {
/* 329 */           node.setHref(oldURL);
/* 330 */           node.setIcon(request.getContextPath() + "/mpm/assets/images/yxnode.gif");
/*     */         } else {
/* 332 */           if (oldURL.indexOf("?") > 0)
/* 333 */             node.setHref(request.getContextPath() + oldURL + "&subject=" + subject);
/*     */           else {
/* 335 */             node.setHref(request.getContextPath() + oldURL + "?subject=" + subject);
/*     */           }
/* 337 */           node.setIcon(request.getContextPath() + "/mpm/assets/images/yxnode.gif");
/*     */         }
/*     */       }
/* 340 */       node.setText(menuItem.getMenuItemTitle());
/* 341 */       node.setQtip(menuItem.getMenuItemTitle());
/* 342 */       node.setId(selfId);
/*     */ 
/* 344 */       list.add(node);
/*     */     }
/*     */ 
/* 347 */     return list;
/*     */   }
/*     */ 
/*     */   public List<IMenuItem> getDirectlySubMenuItems(String userId, String menuId) throws Exception
/*     */   {
/* 352 */     List list = getSubDirectlyMenuItem(userId, menuId);
/* 353 */     return list;
/*     */   }
/*     */ 
/*     */   public List<IMenuItem> getAllSubMenuItems(String userId, String menuId)
/*     */     throws Exception
/*     */   {
/* 359 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUserCityPolicyCache(String userId) throws Exception
/*     */   {
/* 364 */     String cityIds = "'cityId'";
/*     */     try {
/* 366 */       IUser user = getUser(userId);
/* 367 */       String str_Roles = "";
/*     */ 
/* 369 */       if ((user != null) && (isUserAdmin(userId, user.getGroupId())))
/* 370 */         return null;
/* 371 */       if (user == null) {
/* 372 */         return cityIds;
/*     */       }
/*     */ 
/* 375 */       List list = getRight(userId, 0, Integer.parseInt("5"));
/*     */ 
/* 378 */       StringBuffer sb = new StringBuffer();
/*     */ 
/* 380 */       for (Iterator rightIt = list.iterator(); rightIt.hasNext(); ) {
/* 381 */         IUserRight right = (IUserRight)rightIt.next();
/* 382 */         String resourceId = right.getResourceId();
/* 383 */         sb.append("'").append(resourceId).append("'").append(",");
/*     */       }
/* 385 */       if (sb.length() > 0)
/* 386 */         cityIds = sb.toString().substring(0, sb.length() - 1);
/*     */       else
/* 388 */         cityIds = "";
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 392 */       log.error("", e);
/* 393 */       throw new Exception(e);
/*     */     }
/* 395 */     return cityIds;
/*     */   }
/*     */ 
/*     */   public boolean isUserAdmin(String userId, String groupId) throws Exception
/*     */   {
/* 400 */     boolean res = false;
/*     */     try {
/* 402 */       if ((groupId != null) && (groupId.equals("1"))) {
/* 403 */         res = true;
/*     */       }
/* 405 */       if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE")))
/* 406 */         res = isAdminUser(userId);
/*     */     }
/*     */     catch (Exception e) {
/* 409 */       log.error("", e);
/* 410 */       throw new Exception(e);
/*     */     }
/* 412 */     return res;
/*     */   }
/*     */ 
/*     */   public List getUserMenuPolicyCache(String menuId, String userId, String groupId) throws Exception
/*     */   {
/* 417 */     List result = new ArrayList();
/* 418 */     Sqlca sqlca = null;
/*     */     try {
/* 420 */       sqlca = new Sqlca(new ConnectionEx());
/* 421 */       List resourceList = getRight(userId, 1, Integer.parseInt("50"));
/*     */ 
/* 423 */       List idList = ListService.convertToNewList(resourceList, "ResourceId");
/* 424 */       List list = ListService.getMenu(sqlca, idList);
/* 425 */       Iterator it = list.iterator();
/* 426 */       while (it.hasNext()) {
/* 427 */         SysMenuItemBean smi = (SysMenuItemBean)it.next();
/* 428 */         int _parentid = smi.getPARENTID();
/* 429 */         if (menuId.equals(_parentid + ""))
/* 430 */           result.add(smi);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 434 */       log.error("", e);
/* 435 */       throw new Exception(e);
/*     */     } finally {
/* 437 */       if (sqlca != null) {
/* 438 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 441 */     return result;
/*     */   }
/*     */ 
/*     */   public List getUserSubMenuPolicy(HttpServletRequest request, String menuId, String userId, String groupId)
/*     */     throws Exception
/*     */   {
/* 447 */     List result = new ArrayList();
/* 448 */     Sqlca sqlca = null;
/* 449 */     TreeNode treeNode = null;
/* 450 */     Iterator it = null;
/*     */     try {
/* 452 */       sqlca = new Sqlca(new ConnectionEx());
/* 453 */       List resourceList = getRight(userId, 1, Integer.parseInt("50"));
/*     */ 
/* 455 */       List idList = ListService.convertToNewList(resourceList, "ResourceId");
/* 456 */       List list = ListService.getMenu(sqlca, idList);
/* 457 */       it = list.iterator();
/* 458 */       String topIds = "";
/* 459 */       int parentid = 0;
/* 460 */       String id = "";
/*     */ 
/* 462 */       while (it.hasNext()) {
/* 463 */         SysMenuItemBean smi = (SysMenuItemBean)it.next();
/* 464 */         parentid = smi.getPARENTID();
/* 465 */         id = String.valueOf(smi.getMENUITEMID());
/*     */ 
/* 467 */         if (menuId.equals(id)) {
/* 468 */           treeNode = new TreeNode();
/* 469 */           treeNode.setId(id);
/* 470 */           treeNode.setPid("-1");
/* 471 */           treeNode.setText(smi.getMENUITEMTITLE());
/*     */ 
/* 473 */           String strUrl = "";
/* 474 */           String subject = request.getParameter("subject");
/* 475 */           if ((subject != null) && (subject.trim().length() > 0) && (subject.equals("traffic")))
/* 476 */             strUrl = smi.getURL() + "&subject=" + subject;
/*     */           else {
/* 478 */             strUrl = smi.getURL();
/*     */           }
/*     */ 
/* 481 */           int pos = -1;
/* 482 */           if ((pos = strUrl.indexOf(".jsp")) >= 0) {
/* 483 */             strUrl = strUrl.substring(0, pos) + "_summary.jsp";
/*     */           }
/* 485 */           treeNode.setHref(request.getContextPath() + strUrl);
/* 486 */           treeNode.setQtip("");
/* 487 */           treeNode.setExpanded(true);
/* 488 */           result.add(treeNode);
/*     */         }
/*     */       }
/*     */ 
/* 492 */       it = list.iterator();
/* 493 */       while (it.hasNext()) {
/* 494 */         SysMenuItemBean smi = (SysMenuItemBean)it.next();
/* 495 */         parentid = smi.getPARENTID();
/* 496 */         id = String.valueOf(smi.getMENUITEMID());
/* 497 */         if (menuId.equals(String.valueOf(parentid))) {
/* 498 */           topIds = topIds + "[" + id + "]";
/* 499 */           treeNode = new TreeNode();
/* 500 */           treeNode.setId(id);
/* 501 */           treeNode.setPid(String.valueOf(parentid));
/* 502 */           treeNode.setText(smi.getMENUITEMTITLE());
/* 503 */           if ((smi.getURL() != null) && (smi.getURL().length() > 0)) {
/* 504 */             treeNode.setHref(request.getContextPath() + smi.getURL());
/* 505 */             treeNode.setIcon(request.getContextPath() + "/mpm/images/yxnode.gif");
/*     */           }
/* 507 */           treeNode.setExpanded(true);
/* 508 */           result.add(treeNode);
/*     */         }
/*     */       }
/*     */ 
/* 512 */       it = list.iterator();
/* 513 */       while (it.hasNext()) {
/* 514 */         SysMenuItemBean smi = (SysMenuItemBean)it.next();
/* 515 */         parentid = smi.getPARENTID();
/* 516 */         id = String.valueOf(smi.getMENUITEMID());
/* 517 */         if (topIds.indexOf("[" + parentid + "]") >= 0) {
/* 518 */           treeNode = new TreeNode();
/* 519 */           treeNode.setId(id);
/* 520 */           treeNode.setPid(String.valueOf(parentid));
/* 521 */           treeNode.setText(smi.getMENUITEMTITLE());
/* 522 */           if ((smi.getURL() != null) && (smi.getURL().toLowerCase().indexOf("http://") >= 0))
/* 523 */             treeNode.setHref(smi.getURL());
/*     */           else {
/* 525 */             treeNode.setHref(request.getContextPath() + smi.getURL());
/*     */           }
/* 527 */           treeNode.setIcon(request.getContextPath() + "/mpm/images/yxnode.gif");
/* 528 */           treeNode.setExpanded(true);
/* 529 */           result.add(treeNode);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 533 */       log.error("", e);
/* 534 */       throw new Exception(e);
/*     */     } finally {
/* 536 */       if (sqlca != null) {
/* 537 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 540 */     return result;
/*     */   }
/*     */ 
/*     */   public List getUserDmCityList(String userId) throws Exception
/*     */   {
/* 545 */     List list = new ArrayList();
/*     */     try
/*     */     {
/* 548 */       Iterator it = getAllCityByUser(userId).iterator();
/*     */ 
/* 550 */       while (it.hasNext()) {
/* 551 */         ICity obj = (ICity)it.next();
/* 552 */         if ((!obj.getCityId().equals("0")) && (!obj.getParentId().equals("0")) && (((obj.getDmCountyId() == null) && (obj.getDmDeptId() == null)) || ((obj.getDmCountyId().equals("-1")) && (obj.getDmDeptId().equals("-1"))) || ((obj.getDmCountyId().length() == 0) && (obj.getDmDeptId().length() == 0))))
/*     */         {
/* 559 */           list.add(new LabelValueBean(obj.getCityName(), obj.getCityId()));
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 563 */       log.error("", e);
/* 564 */       throw new Exception(e);
/*     */     }
/* 566 */     return list;
/*     */   }
/*     */ 
/*     */   public List getUserCityList(String userId) throws Exception
/*     */   {
/* 571 */     List list = new ArrayList();
/* 572 */     List userCityList = getAllCityByUser(userId);
/* 573 */     if (userCityList != null) {
/* 574 */       for (ICity city : userCityList) {
/* 575 */         list.add(new LabelValueBean(city.getCityName(), city.getCityId()));
/*     */       }
/*     */     }
/* 578 */     return list;
/*     */   }
/*     */ 
/*     */   public List getUserCityObj(String userId) throws Exception {
/* 582 */     List list = new ArrayList();
/*     */     try {
/* 584 */       log.debug("==userId=={}", new Object[] { userId });
/* 585 */       list = getAllCityByUser(userId);
/*     */     }
/*     */     catch (Exception e) {
/* 588 */       log.error("", e);
/* 589 */       throw new Exception(e);
/*     */     }
/* 591 */     return list;
/*     */   }
/*     */ 
/*     */   public List<LkgFuncFolder> getSubAllFuncFolder(String userId, String topFolderId)
/*     */   {
/* 596 */     Sqlca sqlca = null;
/*     */     try {
/* 598 */       sqlca = new Sqlca(new ConnectionEx());
/*     */     } catch (Exception e) {
/* 600 */       e.printStackTrace();
/*     */     }
/* 602 */     List folderIds = new ArrayList();
/* 603 */     folderIds.add(topFolderId);
/* 604 */     folderIds.addAll(SysMenuMaintain.getSubMenuItem(sqlca, topFolderId, false));
/* 605 */     List allRoleList = this.userPrivilegeService.getUserRole(userId, null);
/* 606 */     List folderist = this.lkgFuncFolderDao.findByTopIdAndRoles(folderIds, allRoleList);
/* 607 */     return folderist;
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getSubUserCompanyByPId(String companyId) throws ServiceException
/*     */   {
/* 612 */     return getSubUserCompanyByPId(null, companyId);
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getSubUserCompanyByPId(JdbcTemplate jdbcTemplate, String companyId) throws ServiceException
/*     */   {
/* 617 */     List list = new ArrayList();
/* 618 */     if ((companyId == null) || ("".equals(companyId)) || (!NumberUtils.isNumber(companyId))) {
/* 619 */       return list;
/*     */     }
/* 621 */     if (jdbcTemplate == null) {
/* 622 */       String jndiCiBack = Configure.getInstance().getProperty("JDBC_AIOMNI");
/* 623 */       DataSource ds = DataSourceFactory.getDataSource(jndiCiBack);
/* 624 */       jdbcTemplate = new JdbcTemplate(ds);
/*     */     }
/*     */ 
/* 627 */     String sql = null;
/* 628 */     if ("beijing".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE")))
/* 629 */       sql = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE STATUS=? AND PARENTID = ? ORDER BY SORTNUM,DEP_ID desc";
/* 630 */     else if ("anhui".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE")))
/* 631 */       sql = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE STATUS=? AND PARENTID = ? ORDER BY SORTNUM,DEP_ID desc";
/* 632 */     else if ("shaanxi".equalsIgnoreCase(Configure.getInstance().getProperty("PROVINCE")))
/* 633 */       sql = " SELECT DEPTID as DEP_ID,TITLE as DEP_NAME FROM LKG_STAFF_COMPANY WHERE STATUS=? AND PARENTID = ? ORDER BY SORTNUM,DEP_ID desc";
/*     */     else {
/* 635 */       sql = "select t.deptid as DEP_ID,t.title as DEP_NAME from user_company t where t.status=? and t.parentid=? order by t.sortnum,DEP_ID desc";
/*     */     }
/* 637 */     List result = jdbcTemplate.queryForList(sql, new Object[] { "0", removeComma(companyId) });
/* 638 */     for (Map row : result) {
/* 639 */       IUserCompany comp = new LkgStaffCompany(Integer.valueOf(Integer.parseInt(row.get("DEP_ID").toString())), Integer.valueOf(Integer.parseInt(companyId)), row.get("DEP_NAME").toString(), Integer.valueOf(0), null);
/* 640 */       list.add(comp);
/*     */     }
/* 642 */     return list;
/*     */   }
/*     */ 
/*     */   private String removeComma(String str)
/*     */   {
/* 647 */     if (StringUtil.isEmpty(str)) {
/* 648 */       return "";
/*     */     }
/* 650 */     String rs = str.replaceAll("'", "");
/* 651 */     rs = rs.trim();
/* 652 */     if (rs.indexOf(",") == 0) {
/* 653 */       rs = rs.substring(1);
/*     */     }
/* 655 */     return rs;
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getAllSubCompanyByPId(String companyId)
/*     */     throws ServiceException
/*     */   {
/* 661 */     List list = getSubUserCompanyByPId(companyId);
/* 662 */     List subList = new ArrayList();
/* 663 */     for (IUserCompany iUserCompany : list) {
/* 664 */       subList.addAll(getSubUserCompanyByPId(iUserCompany.getDeptid() + ""));
/*     */     }
/* 666 */     list.addAll(subList);
/* 667 */     return list;
/*     */   }
/*     */ 
/*     */   public List<IUser> getUserList(List<String> userIds) throws ServiceException
/*     */   {
/* 672 */     return this.userPrivilegeService.getUserList(userIds);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.service.impl.UserPrivilegeCommonServiceImpl
 * JD-Core Version:    0.6.2
 */
package com.ai.bdx.frame.privilegeServiceExt.util;

public class Constant
{
  public static final String SYS_ADMIN_GROUP = "1";
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.util.Constant
 * JD-Core Version:    0.6.2
 */
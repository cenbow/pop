/*     */ package com.ai.bdx.frame.privilegeServiceExt.util;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.Connection;
/*     */ import java.util.Hashtable;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.datasource.DriverManagerDataSource;
/*     */ 
/*     */ public class DataSourceFactory
/*     */ {
/*  24 */   private static final Logger log = LogManager.getLogger();
/*  25 */   private static Hashtable<String, DataSource> dss = new Hashtable();
/*     */ 
/*     */   public static DataSource getDataSource(String jndi)
/*     */   {
/*  37 */     if (!dss.containsKey(jndi)) {
/*  38 */       addDataSource(jndi, null);
/*     */     }
/*  40 */     return (DataSource)dss.get(jndi);
/*     */   }
/*     */ 
/*     */   public static DataSource getDataSource(String jndi, String url)
/*     */   {
/*  49 */     if (!dss.containsKey(jndi)) {
/*  50 */       addDataSource(jndi, url);
/*     */     }
/*  52 */     return (DataSource)dss.get(jndi);
/*     */   }
/*     */ 
/*     */   private static void addDataSource(String jndi, String url) {
/*     */     try {
/*  57 */       DataSource ds = null;
/*  58 */       if (StringUtil.isEmpty(url)) {
/*  59 */         Context ctx = new InitialContext();
/*  60 */         String app_server_type = Configure.getInstance().getProperty("APP_SERVER_TYPE");
/*  61 */         Context envContext = null;
/*  62 */         if ((app_server_type != null) && (("weblogic".equalsIgnoreCase(app_server_type)) || ("websphere".equalsIgnoreCase(app_server_type))))
/*     */         {
/*  65 */           envContext = ctx;
/*     */         }
/*  67 */         else envContext = (Context)ctx.lookup("java:comp/env");
/*     */ 
/*  69 */         if (StringUtil.isNotEmpty(jndi)) {
/*  70 */           String strDbJndi = jndi;
/*  71 */           if (strDbJndi.startsWith("java:comp/env/")) {
/*  72 */             strDbJndi = strDbJndi.substring(14);
/*     */           }
/*  74 */           ds = (DataSource)envContext.lookup(strDbJndi);
/*     */         }
/*     */       } else {
/*  77 */         int index = url.indexOf("?");
/*  78 */         String jdbcUrl = url.substring(0, index);
/*  79 */         String[] params = url.substring(index + 1).split("&");
/*  80 */         DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
/*  81 */         if (jdbcUrl.contains("voltdb"))
/*  82 */           driverManagerDataSource.setDriverClassName("org.voltdb.jdbc.Driver");
/*     */         else {
/*  84 */           throw new Exception("The jdbc url[" + url + "] is not supported!");
/*     */         }
/*  86 */         driverManagerDataSource.setUrl(jdbcUrl);
/*  87 */         driverManagerDataSource.setUsername(params[0].split("=")[1]);
/*  88 */         driverManagerDataSource.setPassword(params[1].split("=")[1]);
/*  89 */         ds = driverManagerDataSource;
/*     */       }
/*  91 */       if (ds != null)
/*  92 */         dss.put(jndi, ds);
/*     */       else
/*  94 */         throw new Exception("can't find new datasource!" + jndi);
/*     */     }
/*     */     catch (Exception e) {
/*  97 */       log.error("addDataSource(" + jndi + "),error", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Connection getConnection(String jndi)
/*     */   {
/* 107 */     DataSource ds = getDataSource(jndi);
/* 108 */     return DataSourceUtils.getConnection(ds);
/*     */   }
/*     */ 
/*     */   public static void closeConnection(String jndi, Connection conn)
/*     */   {
/* 117 */     if ((StringUtil.isNotEmpty(jndi)) && (conn != null)) {
/* 118 */       DataSource ds = getDataSource(jndi);
/* 119 */       if (ds != null)
/* 120 */         DataSourceUtils.releaseConnection(conn, ds);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.util.DataSourceFactory
 * JD-Core Version:    0.6.2
 */
/*     */ package com.ai.bdx.frame.privilegeServiceExt.util;
/*     */ 
/*     */ import com.asiainfo.biframe.privilege.IUserRight;
/*     */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class PrivilegeListUtil
/*     */ {
/*  20 */   private static Logger log = LogManager.getLogger();
/*     */ 
/*     */   public static List<String> convertToNewList(List list, String fieldName) throws Exception {
/*  23 */     List returnList = new ArrayList();
/*  24 */     if ((list == null) || (list.size() == 0))
/*  25 */       return returnList;
/*     */     try
/*     */     {
/*  28 */       for (int i = 0; i < list.size(); i++) {
/*  29 */         Class cls = list.get(i).getClass();
/*  30 */         Method method = cls.getMethod("get" + fieldName, null);
/*  31 */         Object retObj = method.invoke(list.get(i), null);
/*  32 */         if (retObj != null)
/*     */         {
/*  35 */           returnList.add(String.valueOf(retObj));
/*     */         }
/*     */       }
/*     */     } catch (Exception e) { e.printStackTrace();
/*  39 */       throw e;
/*     */     }
/*     */ 
/*  42 */     return returnList;
/*     */   }
/*     */ 
/*     */   public static List getMenu(List<String> folderIds, List<IUserRight> menuList, boolean isContainEmptyDir, boolean isOnlyFolder)
/*     */     throws Exception
/*     */   {
/*  55 */     List returnList = new ArrayList();
/*  56 */     if ((folderIds == null) || (folderIds.size() == 0)) {
/*  57 */       return returnList;
/*     */     }
/*     */ 
/*  61 */     for (IUserRight userRight : menuList) {
/*  62 */       String rightId = userRight.getResourceId();
/*  63 */       Integer rightParent = Integer.valueOf(userRight.getResourceType());
/*  64 */       if (rightId.equals("911001")) {
/*  65 */         log.debug(rightId);
/*     */       }
/*  67 */       if ((!isOnlyFolder) && (folderIds.contains(rightId))) {
/*  68 */         SysMenuItemBean smi = new SysMenuItemBean();
/*  69 */         smi.setMENUITEMID(Integer.parseInt(rightId));
/*  70 */         smi.setMENUITEMTITLE(userRight.getOperationName());
/*  71 */         smi.setPARENTID(userRight.getResourceType());
/*  72 */         smi.setURL(userRight.getRightId());
/*  73 */         smi.setPIC1("");
/*  74 */         smi.setPIC2("");
/*  75 */         smi.setURLTARGET("");
/*  76 */         smi.setMENUTYPE(1);
/*  77 */         smi.setACCESSTOKEN(0);
/*  78 */         smi.setRESID("");
/*  79 */         smi.setURLPORT("");
/*  80 */         smi.setApplicationId("");
/*  81 */         smi.setSORTNUM(0);
/*  82 */         returnList.add(smi);
/*     */       }
/*  85 */       else if ((isContainEmptyDir) && 
/*  86 */         (folderIds.contains(rightParent.toString()))) {
/*  87 */         SysMenuItemBean smi = new SysMenuItemBean();
/*  88 */         smi.setMENUITEMID(Integer.parseInt(rightId));
/*  89 */         smi.setMENUITEMTITLE(userRight.getOperationName());
/*  90 */         smi.setPARENTID(userRight.getResourceType());
/*  91 */         smi.setURL(userRight.getRightId());
/*  92 */         smi.setPIC1("");
/*  93 */         smi.setPIC2("");
/*  94 */         smi.setURLTARGET("");
/*  95 */         smi.setMENUTYPE(1);
/*  96 */         smi.setACCESSTOKEN(0);
/*  97 */         smi.setRESID("");
/*  98 */         smi.setURLPORT("");
/*  99 */         smi.setApplicationId("");
/* 100 */         smi.setSORTNUM(0);
/* 101 */         returnList.add(smi);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 107 */     return returnList;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.util.PrivilegeListUtil
 * JD-Core Version:    0.6.2
 */
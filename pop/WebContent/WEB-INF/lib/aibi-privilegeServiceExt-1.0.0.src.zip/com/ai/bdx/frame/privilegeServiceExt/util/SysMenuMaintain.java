/*    */ package com.ai.bdx.frame.privilegeServiceExt.util;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SysMenuMaintain
/*    */ {
/*    */   public static List<String> getSubMenuItem(Sqlca sqlca, String menuItemId, boolean isCascade)
/*    */   {
/* 18 */     List list = new ArrayList();
/*    */     try {
/* 20 */       sqlca = new Sqlca(sqlca.getConnection());
/*    */ 
/* 22 */       String strSql = "SELECT FOLDER_ID FROM LKG_FUNC_FOLDER WHERE PARENT_ID=? ORDER BY FOLDER_ID";
/* 23 */       String isSuite = Configure.getInstance().getProperty("IS_SUITE_PRIVILEGE");
/* 24 */       if ("true".equalsIgnoreCase(isSuite)) {
/* 25 */         strSql = "SELECT MENUITEMID as FOLDER_ID FROM SYS_MENU_ITEM WHERE PARENTID= ?";
/*    */       }
/* 27 */       sqlca.execute(strSql, new String[] { menuItemId });
/* 28 */       List menuList = new ArrayList();
/* 29 */       while (sqlca.next()) {
/* 30 */         menuList.add(sqlca.getString("FOLDER_ID"));
/*    */       }
/* 32 */       list.addAll(menuList);
/* 33 */       sqlca.close();
/*    */ 
/* 35 */       if (isCascade) {
/* 36 */         for (int i = 0; i < menuList.size(); i++) {
/* 37 */           list.addAll(getSubMenuItem(sqlca, (String)menuList.get(i), isCascade));
/*    */         }
/*    */       }
/*    */ 
/* 41 */       if (null != sqlca) {
/* 42 */         sqlca.close();
/*    */       }
/*    */ 
/* 51 */       if (null != sqlca)
/* 52 */         sqlca.close();
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 45 */       ex.printStackTrace();
/*    */ 
/* 47 */       if (null != sqlca) {
/* 48 */         sqlca.close();
/*    */       }
/*    */ 
/* 51 */       if (null != sqlca)
/* 52 */         sqlca.close();
/*    */     }
/*    */     finally
/*    */     {
/* 51 */       if (null != sqlca) {
/* 52 */         sqlca.close();
/*    */       }
/*    */     }
/* 55 */     return list;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.ai.bdx.frame.privilegeServiceExt.util.SysMenuMaintain
 * JD-Core Version:    0.6.2
 */
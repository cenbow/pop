/*    */ package com.asiainfo.biframe.privilege.base.listener;
/*    */ 
/*    */ import com.asiainfo.biframe.manager.context.ContextManager;
/*    */ import com.asiainfo.biframe.service.IActivator;
/*    */ import com.asiainfo.biframe.utils.config.Configure;
/*    */ import com.asiainfo.biframe.utils.i18n.LocaleUtil;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class PrivilegeActivatorImpl
/*    */   implements IActivator
/*    */ {
/* 13 */   private static Logger log = LogManager.getLogger();
/*    */ 
/*    */   public void start(ContextManager context) throws Exception {
/*    */     try {
/* 17 */       log.debug(" begin PrivilegeActivatorImpl");
/*    */ 
/* 19 */       String confFilePath = context.getServletContextEvent().getServletContext().getRealPath("/WEB-INF/classes/config/aibi_privilegeService/privilege.properties");
/*    */ 
/* 21 */       Configure.getInstance().addConfFileName("AIBI_PRIVILEGE_PROPERTIES", confFilePath);
/*    */ 
/* 32 */       log.debug(" end PrivilegeActivatorImpl");
/*    */     } catch (Exception e) {
/* 34 */       log.error(LocaleUtil.getLocaleMessage("privilegeService", "privilegeService.java.loadActivatorFail"), e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void stop(ContextManager context)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.base.listener.PrivilegeActivatorImpl
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.privilege.sysmanage.publish;
/*     */ 
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserAdminService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserCityService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.service.ILkgUserGroupAdminService;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.util.PrivilegeListUtil;
/*     */ import com.ai.bdx.frame.privilegeServiceExt.util.SysMenuMaintain;
/*     */ import com.asiainfo.biframe.exception.ServiceException;
/*     */ import com.asiainfo.biframe.privilege.ICity;
/*     */ import com.asiainfo.biframe.privilege.IGroupRoleMap;
/*     */ import com.asiainfo.biframe.privilege.IMenuItem;
/*     */ import com.asiainfo.biframe.privilege.ISysResourceType;
/*     */ import com.asiainfo.biframe.privilege.IUser;
/*     */ import com.asiainfo.biframe.privilege.IUserApplication;
/*     */ import com.asiainfo.biframe.privilege.IUserCompany;
/*     */ import com.asiainfo.biframe.privilege.IUserDuty;
/*     */ import com.asiainfo.biframe.privilege.IUserExt;
/*     */ import com.asiainfo.biframe.privilege.IUserExtInfo;
/*     */ import com.asiainfo.biframe.privilege.IUserGroup;
/*     */ import com.asiainfo.biframe.privilege.IUserPreferForm;
/*     */ import com.asiainfo.biframe.privilege.IUserPrivilegeService;
/*     */ import com.asiainfo.biframe.privilege.IUserRight;
/*     */ import com.asiainfo.biframe.privilege.IUserRightApply;
/*     */ import com.asiainfo.biframe.privilege.IUserRole;
/*     */ import com.asiainfo.biframe.privilege.menu.bean.SysMenuItemBean;
/*     */ import com.asiainfo.biframe.privilege.model.SysMenuItem;
/*     */ import com.asiainfo.biframe.privilege.sysmanage.service.impl.ListService;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.ConnectionEx;
/*     */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.NumberUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts.util.LabelValueBean;
/*     */ 
/*     */ public class LkgPrivilegeServiceImpl
/*     */   implements IUserPrivilegeService
/*     */ {
/*  47 */   private static final Logger log = LogManager.getLogger();
/*     */   private ILkgUserAdminService userAdminService;
/*     */   private ILkgUserGroupAdminService userGroupAdminService;
/*     */   private ILkgUserCityService userCityService;
/*     */ 
/*     */   public void setUserAdminService(ILkgUserAdminService userAdminService)
/*     */   {
/*  54 */     this.userAdminService = userAdminService;
/*     */   }
/*     */ 
/*     */   public ILkgUserAdminService getUserAdminService() {
/*  58 */     return this.userAdminService;
/*     */   }
/*     */ 
/*     */   public ILkgUserGroupAdminService getUserGroupAdminService() {
/*  62 */     return this.userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public void setUserGroupAdminService(ILkgUserGroupAdminService userGroupAdminService) {
/*  66 */     this.userGroupAdminService = userGroupAdminService;
/*     */   }
/*     */ 
/*     */   public ILkgUserCityService getUserCityService() {
/*  70 */     return this.userCityService;
/*     */   }
/*     */ 
/*     */   public void setUserCityService(ILkgUserCityService userCityService) {
/*  74 */     this.userCityService = userCityService;
/*     */   }
/*     */ 
/*     */   public Collection<IUserApplication> getAllApplications() throws ServiceException
/*     */   {
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   public List<ICity> getAllCity()
/*     */     throws ServiceException
/*     */   {
/*  88 */     return getUserAdminService().getAllCity();
/*     */   }
/*     */ 
/*     */   public String getAllCityID(String arg0, boolean arg1) throws ServiceException
/*     */   {
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IMenuItem> getAllMenuItem(String userId)
/*     */     throws ServiceException
/*     */   {
/* 102 */     List result = new ArrayList();
/* 103 */     Sqlca sqlca = null;
/*     */     try {
/* 105 */       sqlca = new Sqlca(new ConnectionEx());
/* 106 */       List resourceList = getUserAdminService().getRight(userId, 1, Integer.parseInt("50"), true);
/* 107 */       List idList = ListService.convertToNewList(resourceList, "ResourceId");
/* 108 */       List list = ListService.getMenu(sqlca, idList);
/* 109 */       Iterator it = list.iterator();
/* 110 */       while (it.hasNext()) {
/* 111 */         SysMenuItemBean smi = (SysMenuItemBean)it.next();
/* 112 */         SysMenuItem menuItem = new SysMenuItem();
/* 113 */         menuItem.setMenuItemId(Integer.valueOf(smi.getMENUITEMID()));
/* 114 */         menuItem.setMenuItemTitle(smi.getMENUITEMTITLE());
/* 115 */         menuItem.setParentId(Integer.valueOf(smi.getPARENTID()));
/* 116 */         menuItem.setMenuType(Integer.valueOf(smi.getMENUTYPE()));
/* 117 */         menuItem.setUrl(smi.getURL());
/* 118 */         menuItem.setAccessToken(Integer.valueOf(smi.getACCESSTOKEN()));
/* 119 */         menuItem.setApplicationId(smi.getApplicationId());
/* 120 */         menuItem.setUrlPort(smi.getURLPORT());
/* 121 */         menuItem.setUrlTarget(smi.getURLTARGET());
/* 122 */         menuItem.setResourceType(Integer.valueOf(smi.getRESTYPE()));
/* 123 */         menuItem.setResId(smi.getRESID());
/* 124 */         result.add(menuItem);
/*     */       }
/*     */     } catch (Exception e) {
/* 127 */       throw new ServiceException(e.getMessage());
/*     */     } finally {
/* 129 */       if (sqlca != null) {
/* 130 */         sqlca.closeAll();
/*     */       }
/*     */     }
/* 133 */     return result;
/*     */   }
/*     */ 
/*     */   public List<IUserRole> getAllRoles(String arg0, int arg1, int arg2) throws ServiceException
/*     */   {
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserGroup> getAllSubGroupsByUserId(String arg0) throws ServiceException
/*     */   {
/* 143 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUser> getAllSubUsersByUserId(String arg0) throws ServiceException
/*     */   {
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getAllUserCompany()
/*     */     throws ServiceException
/*     */   {
/* 157 */     return getUserAdminService().getAllUserCompany();
/*     */   }
/*     */ 
/*     */   public List<IUserGroup> getAllUserGroup() throws ServiceException
/*     */   {
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserRole> getAllUserRole() throws ServiceException
/*     */   {
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUser> getAllUsers()
/*     */     throws ServiceException
/*     */   {
/* 177 */     return getUserAdminService().getAllUser();
/*     */   }
/*     */ 
/*     */   public ICity getCityByCityID(String cityId)
/*     */     throws ServiceException
/*     */   {
/* 187 */     return getUserAdminService().getCityById(cityId);
/*     */   }
/*     */ 
/*     */   public List<ICity> getCityByUser(String userId)
/*     */     throws ServiceException
/*     */   {
/* 197 */     return getUserAdminService().getCityByUser(userId);
/*     */   }
/*     */ 
/*     */   public String getDmCity(String userId, String resourceId, String dmType, String dbType) throws ServiceException {
/* 201 */     return getUserAdminService().getDmCity(userId, resourceId, dmType, dbType, true);
/*     */   }
/*     */ 
/*     */   public IUserGroup getGroupObject(String userId) throws ServiceException {
/* 205 */     return getUserAdminService().getGroupObject(userId);
/*     */   }
/*     */ 
/*     */   public List<IGroupRoleMap> getGroupRoleMapList() throws ServiceException
/*     */   {
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUser> getMapUsers(String arg0, int arg1, String arg2) throws ServiceException
/*     */   {
/* 215 */     return null;
/*     */   }
/*     */ 
/*     */   public IMenuItem getMeunItemById(Integer memuItemId) throws ServiceException {
/* 219 */     return getUserAdminService().getMenuItemById(memuItemId.toString());
/*     */   }
/*     */ 
/*     */   public List<String> getPreferDescListByPreferType(String arg0, String arg1) throws ServiceException
/*     */   {
/* 224 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getPrivacyRights(String arg0)
/*     */   {
/* 229 */     return null;
/*     */   }
/*     */ 
/*     */   public String getResourceName(int arg0, int arg1, String arg2) throws ServiceException
/*     */   {
/* 234 */     return null;
/*     */   }
/*     */ 
/*     */   public ISysResourceType getResourceTypeByRoleRes(int arg0, int arg1) throws ServiceException
/*     */   {
/* 239 */     return null;
/*     */   }
/*     */ 
/*     */   public List<LabelValueBean> getResourceTypeByRoleType(int arg0) throws ServiceException {
/* 243 */     return new ArrayList();
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getRight(String userId, int resourceType) throws ServiceException {
/* 247 */     return getUserAdminService().getRight(userId, 1, resourceType, false);
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getRight(String userId, int roleType, int resourceType)
/*     */     throws ServiceException
/*     */   {
/* 259 */     return getUserAdminService().getRight(userId, roleType, resourceType, false);
/*     */   }
/*     */ 
/*     */   public List<LabelValueBean> getRoleType() throws ServiceException {
/* 263 */     return ListService.getRoleTypeBeanList();
/*     */   }
/*     */ 
/*     */   public String getShowDmCity(String userId, String resourceId, String dmType, String dbType) throws ServiceException {
/* 267 */     return getUserAdminService().getDmCity(userId, resourceId, dmType, dbType, false);
/*     */   }
/*     */ 
/*     */   public List<ICity> getSubCitysById(String cityId)
/*     */     throws ServiceException
/*     */   {
/* 276 */     return getUserAdminService().getSubCitysById(cityId);
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getSubCompanyById(String companyId) throws ServiceException {
/* 280 */     return getUserAdminService().getSubCompanyById(companyId);
/*     */   }
/*     */ 
/*     */   public List<IMenuItem> getSubMenuItemById(Integer menuItemId, String userId, boolean isCascade) {
/* 284 */     List menuItems = new ArrayList();
/* 285 */     if (NumberUtils.isNumber(menuItemId.toString())) {
/* 286 */       Sqlca sqlca = null;
/*     */       try {
/* 288 */         sqlca = new Sqlca(new ConnectionEx());
/* 289 */         log.debug("获取权限菜单开始：" + menuItemId.toString());
/* 290 */         List subMenuIdList = SysMenuMaintain.getSubMenuItem(sqlca, menuItemId.toString(), isCascade);
/* 291 */         log.debug("========subMenuIdList============：" + subMenuIdList);
/* 292 */         Map rightOperationMap = new HashMap();
/*     */ 
/* 294 */         if (StringUtil.isNotEmpty(userId)) {
/* 295 */           boolean isOnlyFolder = subMenuIdList.isEmpty();
/* 296 */           if (subMenuIdList.isEmpty()) {
/* 297 */             subMenuIdList.add(menuItemId);
/*     */           }
/* 299 */           List resourceList = getUserAdminService().getRight(userId, 1, Integer.parseInt("50"), false);
/*     */ 
/* 301 */           List idList = PrivilegeListUtil.convertToNewList(resourceList, "ResourceId");
/* 302 */           subMenuIdList.retainAll(idList);
/* 303 */           List list = PrivilegeListUtil.getMenu(subMenuIdList, resourceList, isCascade, isOnlyFolder);
/* 304 */           for (int i = 0; i < list.size(); i++) {
/* 305 */             log.debug(Integer.valueOf(((SysMenuItemBean)list.get(i)).getMENUITEMID()));
/*     */           }
/* 307 */           log.debug("获取权限菜单结束：");
/* 308 */           return foreachMenuItemList(list);
/*     */         }
/*     */       } catch (Exception e) {
/* 311 */         throw new ServiceException(e.getMessage());
/*     */       } finally {
/* 313 */         if (sqlca != null) {
/* 314 */           sqlca.closeAll();
/*     */         }
/*     */       }
/*     */     }
/* 318 */     log.debug("menuId is invalid.");
/* 319 */     return new ArrayList();
/*     */   }
/*     */ 
/*     */   public IUser getUser(String userId)
/*     */     throws ServiceException
/*     */   {
/* 330 */     IUser user = getUserAdminService().getUser(userId);
/* 331 */     return user;
/*     */   }
/*     */ 
/*     */   public long getUserAmount()
/*     */   {
/* 336 */     return 0L;
/*     */   }
/*     */ 
/*     */   public IUserCompany getUserCompanyById(String companyId)
/*     */     throws ServiceException
/*     */   {
/* 345 */     return getUserAdminService().getUserCompanyById(companyId);
/*     */   }
/*     */ 
/*     */   public List<IUserCompany> getUserCompanyByName(String arg0) throws ServiceException
/*     */   {
/* 350 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUserCurrentCity(String arg0) throws ServiceException
/*     */   {
/* 355 */     return null;
/*     */   }
/*     */ 
/*     */   public IUserCompany getUserDept(String arg0) throws ServiceException
/*     */   {
/* 360 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUserDmCity(String userId, String dmType)
/*     */     throws ServiceException
/*     */   {
/* 371 */     return getUserCityService().getDmCity(userId, dmType);
/*     */   }
/*     */ 
/*     */   public IUserDuty getUserDutyById(String arg0) throws ServiceException
/*     */   {
/* 376 */     return null;
/*     */   }
/*     */ 
/*     */   public IUserExt getUserExt(String arg0) throws ServiceException
/*     */   {
/* 381 */     return null;
/*     */   }
/*     */ 
/*     */   public IUserGroup getUserGroupById(String arg0) throws ServiceException
/*     */   {
/* 386 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserGroup> getUserGroupByUserId(List<String> arg0) throws ServiceException
/*     */   {
/* 391 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserPreferForm> getUserPreferList(String arg0) throws ServiceException
/*     */   {
/* 396 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserRole> getUserRole(String userId, String arg1) throws ServiceException
/*     */   {
/* 401 */     return this.userAdminService.getAllRoles(userId);
/*     */   }
/*     */ 
/*     */   public IUserRole getUserRoleById(String arg0) throws ServiceException
/*     */   {
/* 406 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUserSensitiveLevel(String userId) throws ServiceException {
/* 410 */     return getUserAdminService().getSensitiveLevel(userId);
/*     */   }
/*     */ 
/*     */   public List<IUser> getUsersByGroupId(String groupId)
/*     */     throws ServiceException
/*     */   {
/* 417 */     return getUserGroupAdminService().getUsersByGroupId(groupId);
/*     */   }
/*     */ 
/*     */   public List<IUser> getUsersByPage(String arg0, String arg1)
/*     */   {
/* 422 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUser> getUsersOfDepartment(int arg0)
/*     */     throws ServiceException
/*     */   {
/* 432 */     return getUserAdminService().getUsersOfDepartment(arg0);
/*     */   }
/*     */ 
/*     */   public List<IUserGroup> getValidChildGroups(String arg0) throws ServiceException
/*     */   {
/* 437 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean haveOperRight(String arg0, String arg1, String arg2)
/*     */   {
/* 442 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean haveOperateRight(String arg0, int arg1, String arg2, String arg3) throws ServiceException
/*     */   {
/* 447 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean haveRightByUserId(String arg0, IUserRight arg1) throws ServiceException
/*     */   {
/* 452 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean haveRightByUserId(String arg0, int arg1, String arg2) throws ServiceException
/*     */   {
/* 457 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean haveRightByUserId(String arg0, int arg1, int arg2, String arg3) throws ServiceException
/*     */   {
/* 462 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isAdminUser(String userId) throws ServiceException {
/* 466 */     return getUserAdminService().isAdminUser(userId);
/*     */   }
/*     */ 
/*     */   public boolean isPwdChangedByOthers(String arg0)
/*     */   {
/* 471 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isPwdNeedChange(String arg0)
/*     */   {
/* 476 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isUserLegal(String arg0, String arg1)
/*     */   {
/* 481 */     return false;
/*     */   }
/*     */ 
/*     */   public void saveUserPrefer(String arg0, String arg1, String arg2)
/*     */     throws ServiceException
/*     */   {
/*     */   }
/*     */ 
/*     */   public String userIdDecryption(String arg0) throws ServiceException
/*     */   {
/* 491 */     return null;
/*     */   }
/*     */ 
/*     */   public String userIdEncryption(String arg0) throws ServiceException
/*     */   {
/* 496 */     return null;
/*     */   }
/*     */ 
/*     */   private List<IMenuItem> foreachMenuItemList(List list) {
/* 500 */     List result = new ArrayList();
/*     */ 
/* 503 */     Collections.sort(list, new Comparator() {
/*     */       public int compare(Object arg0, Object arg1) {
/* 505 */         SysMenuItemBean item0 = (SysMenuItemBean)arg0;
/* 506 */         SysMenuItemBean item1 = (SysMenuItemBean)arg1;
/* 507 */         return new Integer(item0.getMENUITEMID()).compareTo(new Integer(item1.getMENUITEMID()));
/*     */       }
/*     */     });
/* 510 */     Iterator it = list.iterator();
/* 511 */     while (it.hasNext()) {
/* 512 */       SysMenuItemBean smi = (SysMenuItemBean)it.next();
/* 513 */       SysMenuItem menuItem = new SysMenuItem();
/* 514 */       menuItem.setMenuItemId(Integer.valueOf(smi.getMENUITEMID()));
/* 515 */       menuItem.setMenuItemTitle(smi.getMENUITEMTITLE());
/* 516 */       menuItem.setParentId(Integer.valueOf(smi.getPARENTID()));
/* 517 */       menuItem.setMenuType(Integer.valueOf(smi.getMENUTYPE()));
/* 518 */       menuItem.setUrl(smi.getURL());
/* 519 */       menuItem.setAccessToken(Integer.valueOf(smi.getACCESSTOKEN()));
/* 520 */       menuItem.setApplicationId(smi.getApplicationId());
/* 521 */       menuItem.setUrlPort(smi.getURLPORT());
/* 522 */       menuItem.setUrlTarget(smi.getURLTARGET());
/* 523 */       menuItem.setResourceType(Integer.valueOf(smi.getRESTYPE()));
/* 524 */       menuItem.setResId(smi.getRESID());
/* 525 */       menuItem.setSortNum(Integer.valueOf(smi.getSORTNUM()));
/* 526 */       menuItem.setFolderOrNot(StringUtil.isEmpty(menuItem.getUrl()));
/* 527 */       menuItem.setOperationType("-1");
/* 528 */       result.add(menuItem);
/*     */     }
/* 530 */     return result;
/*     */   }
/*     */ 
/*     */   public ICity getCityByDmCity(String arg0, String arg1) throws ServiceException
/*     */   {
/* 535 */     return null;
/*     */   }
/*     */ 
/*     */   public IUserDuty getUserDutyByUser(IUser arg0) throws ServiceException
/*     */   {
/* 540 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean addPublishMenu(int arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String[] arg6)
/*     */   {
/* 547 */     return false;
/*     */   }
/*     */ 
/*     */   public String decryption(String arg0)
/*     */   {
/* 553 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean deletePublishMenu(String arg0, String arg1)
/*     */   {
/* 559 */     return false;
/*     */   }
/*     */ 
/*     */   public void doAffirmApply(String arg0, String arg1)
/*     */     throws ServiceException
/*     */   {
/*     */   }
/*     */ 
/*     */   public String doCreateApply(String arg0, String arg1, String arg2, String arg3, List<IUserRight> arg4)
/*     */     throws ServiceException
/*     */   {
/* 572 */     return null;
/*     */   }
/*     */ 
/*     */   public String encryption(String arg0)
/*     */   {
/* 578 */     return null;
/*     */   }
/*     */ 
/*     */   public IUserRightApply getApplyById(String arg0)
/*     */     throws ServiceException
/*     */   {
/* 584 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IMenuItem> getMenuItemList(String arg0, Map<String, String> arg1)
/*     */     throws ServiceException
/*     */   {
/* 590 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUser> getPagedUser(int arg0, int arg1)
/*     */   {
/* 596 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserGroup> getPagedUserGroup(int arg0, int arg1)
/*     */   {
/* 602 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserRole> getPagedUserRole(int arg0, int arg1)
/*     */   {
/* 607 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getRightByOperation(String arg0, int arg1, int arg2, String arg3) throws ServiceException
/*     */   {
/* 612 */     return null;
/*     */   }
/*     */ 
/*     */   public List getRightsByRes(int arg0, int arg1)
/*     */   {
/* 617 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserRight> getShowTreeRight(String arg0, int arg1)
/*     */   {
/* 623 */     return null;
/*     */   }
/*     */ 
/*     */   public Collection<IUserRight> getTempRightsByApplyId(String arg0)
/*     */     throws ServiceException
/*     */   {
/* 629 */     return null;
/*     */   }
/*     */ 
/*     */   public List getUserByTime(String arg0, String arg1)
/*     */   {
/* 635 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUserExtInfo> getUserExtInfo(String arg0)
/*     */     throws Exception
/*     */   {
/* 641 */     return null;
/*     */   }
/*     */ 
/*     */   public IUserGroup getUserGroup(String arg0, String arg1)
/*     */   {
/* 647 */     return null;
/*     */   }
/*     */ 
/*     */   public long getUserGroupAmount()
/*     */   {
/* 653 */     return 0L;
/*     */   }
/*     */ 
/*     */   public List getUserGroupByTime(String arg0, String arg1)
/*     */   {
/* 659 */     return null;
/*     */   }
/*     */ 
/*     */   public List<IUser> getUserList(List<String> arg0)
/*     */     throws ServiceException
/*     */   {
/* 665 */     return null;
/*     */   }
/*     */ 
/*     */   public long getUserRoleAmount()
/*     */   {
/* 671 */     return 0L;
/*     */   }
/*     */ 
/*     */   public List getUserRoleByTime(String arg0, String arg1)
/*     */   {
/* 677 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean modPublishMenu(int arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String[] arg6)
/*     */   {
/* 684 */     return false;
/*     */   }
/*     */ 
/*     */   public String queryFolderList(int arg0)
/*     */   {
/* 690 */     return null;
/*     */   }
/*     */ 
/*     */   public void saveRight(String arg0, int arg1, int arg2, String arg3, int arg4, String arg5)
/*     */     throws ServiceException
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.asiainfo.biframe.privilege.sysmanage.publish.LkgPrivilegeServiceImpl
 * JD-Core Version:    0.6.2
 */
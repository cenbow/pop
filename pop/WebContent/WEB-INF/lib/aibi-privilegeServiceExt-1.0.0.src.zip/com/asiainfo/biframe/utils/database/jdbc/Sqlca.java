/*      */ package com.asiainfo.biframe.utils.database.jdbc;
/*      */ 
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.string.DES;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.PrintStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Vector;
/*      */ import org.apache.logging.log4j.LogManager;
/*      */ import org.apache.logging.log4j.Logger;
/*      */ 
/*      */ public class Sqlca
/*      */ {
/* 1813 */   private static Logger log = LogManager.getLogger(Sqlca.class);
/* 1814 */   protected final String NULL_STRING = "";
/*      */   protected boolean unicodeToGB;
/*      */   protected boolean gbToUnicode;
/*      */   protected int sqlCode;
/*      */   protected String sqlNotice;
/*      */   protected int sqlRows;
/*      */   protected Connection connection;
/*      */   protected ConnectionEx connectionEx;
/*      */   protected ResultSet sqlResultSet;
/*      */   protected boolean sqlAutoCommit;
/*      */   protected boolean sqlAutoRollback;
/*      */   protected String strSqlType;
/*      */   protected String strSQL;
/*      */   protected boolean lastNullFlag;
/*      */   protected Statement statement;
/*      */   protected String strDBMS;
/* 1831 */   private static int openCount = 0;
/*      */   protected Statement batchStatement;
/* 1833 */   static int g_nCount = 0;
/*      */   protected PreparedStatement preStat;
/*      */ 
/*      */   private Sqlca()
/*      */   {
/*   34 */     this.unicodeToGB = true;
/*   35 */     this.gbToUnicode = true;
/*   36 */     this.sqlRows = 0;
/*   37 */     this.connection = null;
/*   38 */     this.connectionEx = null;
/*   39 */     this.strSqlType = "UNKNOWN";
/*   40 */     this.strSQL = null;
/*   41 */     this.lastNullFlag = false;
/*   42 */     this.statement = null;
/*   43 */     this.strDBMS = null;
/*   44 */     this.batchStatement = null;
/*   45 */     this.sqlCode = 0;
/*   46 */     this.sqlResultSet = null;
/*   47 */     this.sqlNotice = null;
/*   48 */     this.preStat = null;
/*   49 */     this.sqlAutoRollback = false;
/*   50 */     this.sqlAutoCommit = false;
/*      */   }
/*      */ 
/*      */   public Sqlca(Connection newConnection) throws Exception {
/*   54 */     this();
/*   55 */     this.connection = newConnection;
/*      */     try {
/*   57 */       if (this.connection != null) {
/*   58 */         setAutoCommit(this.sqlAutoCommit);
/*      */       }
/*   60 */       if ((this.connection != null) && (this.connection.getTransactionIsolation() < 1))
/*   61 */         this.connection.setTransactionIsolation(2);
/*      */     }
/*      */     catch (Exception e) {
/*   64 */       throw e;
/*      */     }
/*   66 */     this.gbToUnicode = Boolean.valueOf(Configure.getInstance().getProperty("KPI_DB_CHARSET")).booleanValue();
/*   67 */     this.unicodeToGB = Boolean.valueOf(Configure.getInstance().getProperty("KPI_DB_CHARSET")).booleanValue();
/*      */   }
/*      */ 
/*      */   public Sqlca(ConnectionEx conn) throws Exception {
/*   71 */     this();
/*   72 */     this.connection = conn.getConnection();
/*   73 */     this.connectionEx = conn;
/*      */     try {
/*   75 */       if (this.connection != null) {
/*   76 */         setAutoCommit(this.sqlAutoCommit);
/*      */       }
/*   78 */       if (this.connection != null)
/*   79 */         this.connection.setTransactionIsolation(2);
/*      */     }
/*      */     catch (Exception e) {
/*   82 */       throw e;
/*      */     }
/*   84 */     this.gbToUnicode = Boolean.valueOf(Configure.getInstance().getProperty("KPI_DB_CHARSET")).booleanValue();
/*   85 */     this.unicodeToGB = Boolean.valueOf(Configure.getInstance().getProperty("KPI_DB_CHARSET")).booleanValue();
/*      */   }
/*      */ 
/*      */   public Sqlca(ConnectionEx conn, boolean bGBToUnicode, boolean bUnicodeToGB) throws Exception {
/*   89 */     this();
/*   90 */     this.connection = conn.getConnection();
/*   91 */     this.connectionEx = conn;
/*      */     try {
/*   93 */       if (this.connection != null) {
/*   94 */         setAutoCommit(this.sqlAutoCommit);
/*      */       }
/*   96 */       if (this.connection != null)
/*   97 */         this.connection.setTransactionIsolation(2);
/*      */     }
/*      */     catch (Exception e) {
/*  100 */       throw e;
/*      */     }
/*  102 */     this.gbToUnicode = bGBToUnicode;
/*  103 */     this.unicodeToGB = bUnicodeToGB;
/*      */   }
/*      */ 
/*      */   public void setAutoCommit(boolean bAuto) throws Exception {
/*  107 */     this.sqlAutoCommit = bAuto;
/*  108 */     if (this.connection == null)
/*  109 */       Failure("did not get a connection to the database", 0);
/*      */     try
/*      */     {
/*  112 */       this.connection.setAutoCommit(this.sqlAutoCommit);
/*      */     } catch (SQLException e) {
/*  114 */       sqlFailure("automatic commit of property failed!", e, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setAutoRollback(boolean autoRollbackWhensqlFailure) throws Exception {
/*  119 */     this.sqlAutoRollback = autoRollbackWhensqlFailure;
/*      */   }
/*      */ 
/*      */   public void setConnection(Connection newConnection) throws Exception {
/*  123 */     this.connection = newConnection;
/*      */   }
/*      */ 
/*      */   public void setUnicodeToGB(boolean bFlag) {
/*  127 */     this.unicodeToGB = bFlag;
/*      */   }
/*      */ 
/*      */   public void setGBToUnicode(boolean bFlag) {
/*  131 */     this.gbToUnicode = bFlag;
/*      */   }
/*      */ 
/*      */   public Connection getConnection() {
/*  135 */     return this.connection;
/*      */   }
/*      */ 
/*      */   public void setSql(String sqlStr) throws Exception
/*      */   {
/*  140 */     if (this.connection == null) {
/*  141 */       Failure("did not get a connection to the database!", 0);
/*      */     }
/*  143 */     if ((sqlStr == null) || (sqlStr.trim().length() < 1)) {
/*  144 */       Failure("sql statement is empty!", 0);
/*      */     }
/*  146 */     this.strSQL = sqlStr;
/*  147 */     this.sqlCode = 0;
/*  148 */     this.sqlRows = 0;
/*  149 */     this.sqlNotice = null;
/*  150 */     sqlStr = sqlStr.trim();
/*  151 */     this.strSqlType = sqlStr.substring(0, 4).toUpperCase();
/*  152 */     if (this.strSqlType.equals("SELE"))
/*  153 */       this.strSqlType = "SELECT";
/*  154 */     else if (this.strSqlType.equals("WITH"))
/*  155 */       this.strSqlType = "SELECT";
/*  156 */     else if (this.strSqlType.equals("DELE"))
/*  157 */       this.strSqlType = "DELETE";
/*  158 */     else if (this.strSqlType.equals("UPDA"))
/*  159 */       this.strSqlType = "UPDATE";
/*  160 */     else if (this.strSqlType.equals("INSE"))
/*  161 */       this.strSqlType = "INSERT";
/*      */     else {
/*  163 */       this.strSqlType = "UNKNOWN";
/*      */     }
/*  165 */     close();
/*  166 */     openCount += 1;
/*  167 */     String strType = getDBMSType();
/*  168 */     if (strType.equalsIgnoreCase("SQLSERVER")) {
/*  169 */       this.connection.setAutoCommit(true);
/*      */     }
/*  171 */     this.statement = this.connection.createStatement();
/*      */   }
/*      */ 
/*      */   protected int execute() throws Exception {
/*  175 */     this.sqlRows = 0;
/*  176 */     if (this.statement == null) {
/*  177 */       this.sqlRows = -1;
/*  178 */       Failure("there is no enforceable SQL!", 0);
/*      */     }
/*      */     try {
/*  181 */       if (this.strSqlType.equals("SELECT"))
/*  182 */         this.sqlResultSet = this.statement.executeQuery(this.strSQL);
/*      */       else
/*  184 */         this.sqlRows = this.statement.executeUpdate(this.strSQL);
/*      */     }
/*      */     catch (SQLException e) {
/*  187 */       this.sqlRows = -1;
/*  188 */       sqlFailure(new StringBuilder().append("execute SQL:\n  ").append(this.strSQL).append(" error!").toString(), e, 0);
/*      */ 
/*  190 */       return -1;
/*      */     }
/*  192 */     return this.sqlRows;
/*      */   }
/*      */ 
/*      */   public int execute(String strSQL)
/*      */     throws Exception
/*      */   {
/*  205 */     if (this.unicodeToGB) {
/*  206 */       strSQL = unicodeToGB(strSQL);
/*      */     }
/*  208 */     setSql(strSQL);
/*  209 */     return execute();
/*      */   }
/*      */ 
/*      */   public void addBatch(String sql) throws Exception {
/*      */     try {
/*  214 */       if (this.batchStatement == null) {
/*  215 */         this.batchStatement = this.connection.createStatement();
/*      */       }
/*  217 */       this.batchStatement.addBatch(sql);
/*      */     } catch (Exception e) {
/*  219 */       log.error(e.getMessage(), e);
/*  220 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int[] executeBatch() throws Exception {
/*      */     try {
/*  226 */       if (this.batchStatement == null)
/*  227 */         return null;
/*      */     }
/*      */     catch (Exception e) {
/*  230 */       log.error(e.getMessage(), e);
/*  231 */       throw e;
/*      */     }
/*  233 */     return this.batchStatement.executeBatch();
/*      */   }
/*      */ 
/*      */   public int getSqlRows() {
/*  237 */     return this.sqlRows;
/*      */   }
/*      */ 
/*      */   protected void sqlFailure(String notice, SQLException e, int flag) throws Exception {
/*  241 */     this.sqlCode = (-e.getErrorCode());
/*  242 */     this.sqlNotice = new StringBuilder().append("sql statement").append(this.strSQL).append("\n").append(notice).append("\n").append("  error code :").append(Integer.valueOf(this.sqlCode).toString()).append(";\n").append("  error message:").append(GBToUnicode(e.getMessage())).append("\n").toString();
/*      */ 
/*  245 */     throw new Exception(new StringBuilder().append("SQL Error:").append(this.sqlNotice).append(GBToUnicode(new StringBuilder().append(notice).append(e.getMessage()).toString())).toString());
/*      */   }
/*      */ 
/*      */   public void closeAll()
/*      */   {
/*      */     try {
/*  251 */       close();
/*  252 */       if (this.batchStatement != null) {
/*  253 */         this.batchStatement.close();
/*  254 */         this.batchStatement = null;
/*      */       }
/*  256 */       if (null != this.connectionEx) {
/*  257 */         if (!this.connectionEx.isClosed()) {
/*  258 */           this.connectionEx.close();
/*      */         }
/*  260 */         this.connectionEx = null;
/*  261 */       } else if (null != this.connection) {
/*  262 */         if (!this.connection.isClosed()) {
/*  263 */           this.connection.close();
/*      */         }
/*  265 */         this.connection = null;
/*      */       }
/*      */     } catch (Exception e) {
/*  268 */       log.error(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void close() {
/*      */     try {
/*  274 */       commit();
/*      */     } catch (Exception e) {
/*  276 */       log.error(e.getMessage(), e);
/*      */     }
/*      */ 
/*  279 */     this.sqlNotice = null;
/*      */     try {
/*  281 */       if (this.sqlResultSet != null) {
/*  282 */         this.sqlResultSet.close();
/*  283 */         this.sqlResultSet = null;
/*      */       }
/*  285 */       if (this.statement != null) {
/*  286 */         openCount -= 1;
/*  287 */         this.statement.close();
/*  288 */         this.statement = null;
/*      */       }
/*  290 */       if (this.preStat != null) {
/*  291 */         openCount -= 1;
/*  292 */         this.preStat.close();
/*  293 */         this.preStat = null;
/*      */       }
/*      */     } catch (Exception e) {
/*  296 */       log.error(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void Failure(String notice, int flag) throws Exception
/*      */   {
/*  302 */     this.sqlCode = 50;
/*  303 */     this.sqlNotice = notice;
/*  304 */     if ((flag == 1) && (this.sqlAutoRollback) && (!this.strSqlType.equals("SELECT")))
/*      */       try {
/*  306 */         this.connection.rollback();
/*      */       }
/*      */       catch (SQLException e1) {
/*      */       }
/*  310 */     throw new Exception(this.sqlNotice);
/*      */   }
/*      */ 
/*      */   private String unicodeToGB(String strIn) {
/*  314 */     if (!this.unicodeToGB) {
/*  315 */       return strIn;
/*      */     }
/*  317 */     String strOut = null;
/*  318 */     if ((strIn == null) || (strIn.trim().equals("")))
/*  319 */       return strIn;
/*      */     try
/*      */     {
/*  322 */       byte[] b = strIn.getBytes("GBK");
/*  323 */       strOut = new String(b, "ISO8859_1");
/*      */     } catch (Exception e) {
/*  325 */       strOut = strIn;
/*      */     }
/*  327 */     return strOut;
/*      */   }
/*      */ 
/*      */   private String GBToUnicode(String strIn)
/*      */   {
/*  332 */     if (!this.gbToUnicode) {
/*  333 */       return strIn;
/*      */     }
/*  335 */     String strOut = null;
/*  336 */     if ((strIn == null) || (strIn.trim().equals("")))
/*  337 */       return strIn;
/*      */     try
/*      */     {
/*  340 */       byte[] b = strIn.getBytes("ISO8859_1");
/*  341 */       strOut = new String(b, "GBK");
/*      */     } catch (Exception e) {
/*  343 */       strOut = strIn;
/*      */     }
/*  345 */     return strOut;
/*      */   }
/*      */ 
/*      */   public ResultSetMetaData getMetaData() throws Exception {
/*  349 */     return this.sqlResultSet.getMetaData();
/*      */   }
/*      */ 
/*      */   public boolean next() throws Exception {
/*  353 */     return this.sqlResultSet.next();
/*      */   }
/*      */ 
/*      */   public void commit() throws Exception {
/*      */     try {
/*  358 */       if ((this.connection != null) && (!this.connection.isClosed()))
/*  359 */         this.connection.commit();
/*      */     }
/*      */     catch (Exception e) {
/*  362 */       log.error(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void rollback() throws Exception {
/*  367 */     this.connection.rollback();
/*      */   }
/*      */ 
/*      */   public void setDBMSType(String dbType) {
/*  371 */     this.strDBMS = dbType;
/*      */   }
/*      */ 
/*      */   public String getDBMSType() throws Exception {
/*  375 */     if (null == this.strDBMS) {
/*  376 */       DatabaseMetaData m = this.connection.getMetaData();
/*  377 */       this.strDBMS = m.getDatabaseProductName();
/*  378 */       this.strDBMS = this.strDBMS.toUpperCase();
/*  379 */       if (this.strDBMS.indexOf("MYSQL") >= 0)
/*  380 */         this.strDBMS = "MYSQL";
/*  381 */       else if (this.strDBMS.indexOf("ORACLE") >= 0)
/*  382 */         this.strDBMS = "ORACLE";
/*  383 */       else if (this.strDBMS.indexOf("POSTGRESQL") >= 0)
/*  384 */         this.strDBMS = "POSTGRESQL";
/*  385 */       else if (this.strDBMS.indexOf("ACCESS") >= 0)
/*  386 */         this.strDBMS = "ACESS";
/*  387 */       else if (this.strDBMS.indexOf("SQL SERVER") >= 0)
/*  388 */         this.strDBMS = "SQLSERVER";
/*  389 */       else if (this.strDBMS.indexOf("DB2") >= 0)
/*  390 */         this.strDBMS = "DB2";
/*  391 */       else if (this.strDBMS.indexOf("TERA") >= 0)
/*  392 */         this.strDBMS = "TERA";
/*  393 */       else if (this.strDBMS.indexOf("SYBASE") >= 0)
/*  394 */         this.strDBMS = "SYBASE";
/*  395 */       else if (this.strDBMS.indexOf("ADAPTIVE") >= 0)
/*  396 */         this.strDBMS = "SYBASE";
/*  397 */       else if (this.strDBMS.indexOf("GBASE") >= 0)
/*  398 */         this.strDBMS = "MYSQL";
/*      */       else {
/*  400 */         throw new Exception("does not support the database type!");
/*      */       }
/*      */     }
/*  403 */     return this.strDBMS.toUpperCase();
/*      */   }
/*      */ 
/*      */   public String getString(int columnIndex) throws Exception {
/*  407 */     String retValue = null;
/*  408 */     if (this.sqlResultSet == null) {
/*  409 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  413 */       retValue = this.sqlResultSet.getString(columnIndex);
/*  414 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  416 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong!").toString(), e, 0);
/*      */     }
/*      */ 
/*  419 */     if ((this.lastNullFlag) || (null == retValue))
/*  420 */       retValue = "";
/*      */     else {
/*  422 */       retValue = retValue.trim();
/*      */     }
/*  424 */     return GBToUnicode(retValue);
/*      */   }
/*      */ 
/*      */   public String getString(String columnName) throws Exception {
/*  428 */     String retValue = null;
/*  429 */     if (this.sqlResultSet == null) {
/*  430 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  434 */       retValue = this.sqlResultSet.getString(columnName);
/*  435 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  437 */       sqlFailure(new StringBuilder().append("take out ").append(columnName).append(" value is wrong!").toString(), e, 0);
/*      */     }
/*      */ 
/*  440 */     if ((this.lastNullFlag) || (null == retValue))
/*  441 */       retValue = "";
/*      */     else {
/*  443 */       retValue = retValue.trim();
/*      */     }
/*  445 */     return GBToUnicode(retValue);
/*      */   }
/*      */ 
/*      */   public String getClob(int columnIndex) throws Exception {
/*  449 */     String strRet = null;
/*  450 */     Clob retValue = null;
/*  451 */     if (this.sqlResultSet == null) {
/*  452 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  456 */       retValue = this.sqlResultSet.getClob(columnIndex);
/*  457 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  459 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong!").toString(), e, 0);
/*      */     }
/*      */ 
/*  462 */     if ((this.lastNullFlag) || (null == retValue))
/*  463 */       strRet = "";
/*      */     else {
/*  465 */       strRet = clobToString(retValue);
/*      */     }
/*  467 */     return GBToUnicode(strRet);
/*      */   }
/*      */ 
/*      */   public String getClob(String columnName) throws Exception {
/*  471 */     String strRet = null;
/*  472 */     Clob retValue = null;
/*  473 */     if (this.sqlResultSet == null) {
/*  474 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  478 */       retValue = this.sqlResultSet.getClob(columnName);
/*  479 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  481 */       sqlFailure(new StringBuilder().append("take out ").append(columnName).append("value is wrong!").toString(), e, 0);
/*      */     }
/*      */ 
/*  484 */     if ((this.lastNullFlag) || (null == retValue))
/*  485 */       strRet = "";
/*      */     else {
/*  487 */       strRet = clobToString(retValue);
/*      */     }
/*  489 */     return GBToUnicode(strRet);
/*      */   }
/*      */ 
/*      */   private String clobToString(Clob clob) throws Exception {
/*  493 */     StringBuffer content = new StringBuffer();
/*      */     try {
/*  495 */       String s = "";
/*  496 */       BufferedReader br = new BufferedReader(clob.getCharacterStream());
/*  497 */       while ((s = br.readLine()) != null) {
/*  498 */         content.append(s);
/*      */       }
/*  500 */       return content.toString(); } catch (Exception e) {
/*      */     }
/*  502 */     throw new Exception("-------get value failed--------");
/*      */   }
/*      */ 
/*      */   public int getInt(int columnIndex) throws Exception
/*      */   {
/*  507 */     int retValue = -1;
/*  508 */     if (this.sqlResultSet == null) {
/*  509 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  513 */       retValue = this.sqlResultSet.getInt(columnIndex);
/*  514 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  516 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append(" value is wrong!").toString(), e, 0);
/*      */     }
/*      */ 
/*  519 */     return retValue;
/*      */   }
/*      */ 
/*      */   public int getInt(String columnName) throws Exception {
/*  523 */     if (this.sqlResultSet == null) {
/*  524 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     int retValue;
/*      */     try
/*      */     {
/*  529 */       retValue = this.sqlResultSet.getInt(columnName);
/*  530 */       this.lastNullFlag = false;
/*  531 */       if (this.sqlResultSet.wasNull())
/*  532 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  535 */       sqlFailure(new StringBuilder().append("take out ").append(columnName).append(" value error!").toString(), e, 0);
/*      */ 
/*  537 */       return 0;
/*      */     }
/*  539 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Integer getInteger(int columnIndex) throws Exception {
/*  543 */     Integer retValue = null;
/*  544 */     if (this.sqlResultSet == null) {
/*  545 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  549 */       int tempVar = this.sqlResultSet.getInt(columnIndex);
/*  550 */       this.lastNullFlag = false;
/*  551 */       if (this.sqlResultSet.wasNull()) {
/*  552 */         this.lastNullFlag = true;
/*  553 */         retValue = null;
/*      */       } else {
/*  555 */         retValue = Integer.valueOf(tempVar);
/*      */       }
/*      */     } catch (SQLException e) {
/*  558 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append(" value error!").toString(), e, 0);
/*      */     }
/*      */ 
/*  561 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Integer getInteger(String columnName) throws Exception {
/*  565 */     Integer retValue = null;
/*  566 */     if (this.sqlResultSet == null) {
/*  567 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  571 */       int tempVar = this.sqlResultSet.getInt(columnName);
/*  572 */       this.lastNullFlag = false;
/*  573 */       if (this.sqlResultSet.wasNull()) {
/*  574 */         this.lastNullFlag = true;
/*  575 */         retValue = null;
/*      */       } else {
/*  577 */         retValue = Integer.valueOf(tempVar);
/*      */       }
/*      */     } catch (SQLException e) {
/*  580 */       sqlFailure(new StringBuilder().append("take out ").append(columnName).append(" value error!").toString(), e, 0);
/*      */     }
/*      */ 
/*  583 */     return retValue;
/*      */   }
/*      */ 
/*      */   public long getLong(int columnIndex) throws Exception {
/*  587 */     long retValue = 0L;
/*  588 */     if (this.sqlResultSet == null) {
/*  589 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  593 */       retValue = this.sqlResultSet.getLong(columnIndex);
/*  594 */       this.lastNullFlag = false;
/*  595 */       if (this.sqlResultSet.wasNull())
/*  596 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  599 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append(" value error!").toString(), e, 0);
/*      */ 
/*  601 */       return 0L;
/*      */     }
/*  603 */     return retValue;
/*      */   }
/*      */ 
/*      */   public long getLong(String columnName) throws Exception {
/*  607 */     if (this.sqlResultSet == null) {
/*  608 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     long retValue;
/*      */     try
/*      */     {
/*  613 */       retValue = this.sqlResultSet.getLong(columnName);
/*  614 */       this.lastNullFlag = false;
/*  615 */       if (this.sqlResultSet.wasNull())
/*  616 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  619 */       sqlFailure(new StringBuilder().append("take out ").append(columnName).append(" value error!").toString(), e, 0);
/*      */ 
/*  621 */       return 0L;
/*      */     }
/*  623 */     return retValue;
/*      */   }
/*      */ 
/*      */   public double getDouble(int columnIndex) throws Exception {
/*  627 */     double retValue = 0.0D;
/*  628 */     if (this.sqlResultSet == null) {
/*  629 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  633 */       retValue = this.sqlResultSet.getDouble(columnIndex);
/*  634 */       this.lastNullFlag = false;
/*  635 */       if (this.sqlResultSet.wasNull())
/*  636 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  639 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append(" value error!").toString(), e, 0);
/*      */     }
/*      */ 
/*  642 */     return retValue;
/*      */   }
/*      */ 
/*      */   public double getDouble(String columnName) throws Exception {
/*  646 */     if (this.sqlResultSet == null) {
/*  647 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     double retValue;
/*      */     try
/*      */     {
/*  652 */       retValue = this.sqlResultSet.getDouble(columnName);
/*  653 */       this.lastNullFlag = false;
/*  654 */       if (this.sqlResultSet.wasNull())
/*  655 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  658 */       sqlFailure(new StringBuilder().append("take out ").append(columnName).append(" value error!").toString(), e, 0);
/*      */ 
/*  660 */       return 0.0D;
/*      */     }
/*  662 */     return retValue;
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(int columnIndex) throws Exception {
/*  666 */     boolean retValue = false;
/*  667 */     if (this.sqlResultSet == null) {
/*  668 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  672 */       retValue = this.sqlResultSet.getBoolean(columnIndex);
/*  673 */       this.lastNullFlag = false;
/*  674 */       if (this.sqlResultSet.wasNull())
/*  675 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  678 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append(" value error!").toString(), e, 0);
/*      */     }
/*      */ 
/*  681 */     return retValue;
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(String columnName) throws Exception {
/*  685 */     boolean retValue = false;
/*  686 */     if (this.sqlResultSet == null) {
/*  687 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  691 */       retValue = this.sqlResultSet.getBoolean(columnName);
/*  692 */       this.lastNullFlag = false;
/*  693 */       if (this.sqlResultSet.wasNull())
/*  694 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  697 */       sqlFailure(new StringBuilder().append("take out ").append(columnName).append(" value error!").toString(), e, 0);
/*      */     }
/*      */ 
/*  700 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Date getDate(int columnIndex) throws Exception {
/*  704 */     Date retValue = null;
/*  705 */     if (this.sqlResultSet == null) {
/*  706 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  710 */       Timestamp tmp = this.sqlResultSet.getTimestamp(columnIndex);
/*  711 */       if (tmp != null)
/*  712 */         retValue = new Date(tmp.getTime());
/*      */       else {
/*  714 */         retValue = null;
/*      */       }
/*  716 */       this.lastNullFlag = false;
/*  717 */       if (this.sqlResultSet.wasNull()) {
/*  718 */         retValue = null;
/*  719 */         this.lastNullFlag = true;
/*      */       }
/*      */     } catch (SQLException e) {
/*  722 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append(" value error!").toString(), e, 0);
/*      */     }
/*      */ 
/*  725 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Date getDate(String columnName) throws Exception {
/*  729 */     Date retValue = null;
/*  730 */     if (this.sqlResultSet == null) {
/*  731 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  735 */       Timestamp tmp = this.sqlResultSet.getTimestamp(columnName);
/*  736 */       if (tmp != null)
/*  737 */         retValue = new Date(tmp.getTime());
/*      */       else {
/*  739 */         retValue = null;
/*      */       }
/*  741 */       this.lastNullFlag = false;
/*  742 */       if (this.sqlResultSet.wasNull())
/*  743 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  746 */       sqlFailure(new StringBuilder().append("take out ").append(columnName).append(" value error!").toString(), e, 0);
/*      */     }
/*      */ 
/*  749 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex) throws Exception {
/*  753 */     Timestamp retValue = null;
/*  754 */     if (this.sqlResultSet == null) {
/*  755 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  759 */       retValue = this.sqlResultSet.getTimestamp(columnIndex);
/*  760 */       this.lastNullFlag = false;
/*  761 */       if (this.sqlResultSet.wasNull()) {
/*  762 */         retValue = null;
/*  763 */         this.lastNullFlag = true;
/*      */       }
/*      */     } catch (SQLException e) {
/*  766 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append(" value error!").toString(), e, 0);
/*      */     }
/*      */ 
/*  769 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName) throws Exception {
/*  773 */     Timestamp retValue = null;
/*  774 */     if (this.sqlResultSet == null) {
/*  775 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     try
/*      */     {
/*  779 */       retValue = this.sqlResultSet.getTimestamp(columnName);
/*  780 */       this.lastNullFlag = false;
/*  781 */       if (this.sqlResultSet.wasNull()) {
/*  782 */         retValue = null;
/*  783 */         this.lastNullFlag = true;
/*      */       }
/*      */     } catch (SQLException e) {
/*  786 */       sqlFailure(new StringBuilder().append("take the first ").append(columnName).append(" value error!").toString(), e, 0);
/*      */     }
/*      */ 
/*  789 */     return retValue;
/*      */   }
/*      */ 
/*      */   public float getFloat(int columnIndex) throws Exception {
/*  793 */     if (this.sqlResultSet == null) {
/*  794 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     float retValue;
/*      */     try
/*      */     {
/*  799 */       retValue = this.sqlResultSet.getFloat(columnIndex);
/*  800 */       this.lastNullFlag = false;
/*  801 */       if (this.sqlResultSet.wasNull())
/*  802 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  805 */       sqlFailure(new StringBuilder().append("take the first ").append(columnIndex).append(" value error!").toString(), e, 0);
/*      */ 
/*  807 */       return 0.0F;
/*      */     }
/*  809 */     return retValue;
/*      */   }
/*      */ 
/*      */   public float getFloat(String columnName) throws Exception {
/*  813 */     if (this.sqlResultSet == null) {
/*  814 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */     float retValue;
/*      */     try
/*      */     {
/*  819 */       retValue = this.sqlResultSet.getFloat(columnName);
/*  820 */       this.lastNullFlag = false;
/*  821 */       if (this.sqlResultSet.wasNull())
/*  822 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  825 */       sqlFailure(new StringBuilder().append("take out ").append(columnName).append(" value error!!").toString(), e, 0);
/*      */ 
/*  828 */       return 0.0F;
/*      */     }
/*  830 */     return retValue;
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(int columnIndex) throws Exception {
/*  834 */     if (this.sqlResultSet == null) {
/*  835 */       throw new Exception(new StringBuilder().append("take the first ").append(columnIndex).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */ 
/*  838 */     BigDecimal retValue = this.sqlResultSet.getBigDecimal(columnIndex);
/*  839 */     this.lastNullFlag = false;
/*  840 */     if (this.sqlResultSet.wasNull()) {
/*  841 */       retValue = null;
/*  842 */       this.lastNullFlag = true;
/*      */     }
/*  844 */     return retValue;
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(String columnName) throws Exception {
/*  848 */     if (this.sqlResultSet == null) {
/*  849 */       throw new Exception(new StringBuilder().append("take out ").append(columnName).append("value is wrong! because the result set to a null value").toString());
/*      */     }
/*      */ 
/*  852 */     BigDecimal retValue = this.sqlResultSet.getBigDecimal(columnName);
/*  853 */     this.lastNullFlag = false;
/*  854 */     if (this.sqlResultSet.wasNull()) {
/*  855 */       retValue = null;
/*  856 */       this.lastNullFlag = true;
/*      */     }
/*  858 */     return retValue;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public String[][] getMatrix()
/*      */   {
/*  867 */     if (this.sqlResultSet == null) {
/*  868 */       return (String[][])null;
/*      */     }
/*  870 */     int colnum = 0;
/*  871 */     Vector table = new Vector();
/*      */     try {
/*  873 */       colnum = this.sqlResultSet.getMetaData().getColumnCount();
/*      */       String[] row;
/*  875 */       for (; next(); table.addElement(row)) {
/*  876 */         row = new String[colnum];
/*  877 */         for (int i = 0; i < colnum; i++) {
/*  878 */           row[i] = getString(i + 1);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  884 */       System.err.println(new StringBuilder().append("Execute err : ").append(ex.getMessage()).toString());
/*  885 */       return (String[][])null;
/*      */     }
/*  887 */     String[][] matrix = new String[table.size() + 1][colnum];
/*  888 */     for (int col = 0; col < colnum; col++) {
/*  889 */       matrix[0][col] = new StringBuilder().append("Filed").append(col).toString();
/*      */     }
/*      */ 
/*  892 */     for (int rowl = 1; rowl < matrix.length; rowl++) {
/*  893 */       matrix[rowl] = ((String[])(String[])table.elementAt(rowl - 1));
/*      */     }
/*      */ 
/*  896 */     return matrix;
/*      */   }
/*      */ 
/*      */   public String getSql2TimeStamp(String strDateStr, String strH, String strM, String strS) throws Exception {
/*  900 */     if ((null == strDateStr) || (strDateStr.length() < 1)) {
/*  901 */       return null;
/*      */     }
/*  903 */     if (strDateStr.indexOf("0000-00-00") >= 0) {
/*  904 */       return "null";
/*      */     }
/*  906 */     String strType = getDBMSType();
/*  907 */     String strRet = "";
/*  908 */     if (strType.equalsIgnoreCase("MYSQL")) {
/*  909 */       strRet = new StringBuilder().append("'").append(strDateStr).append(" ").append(strH).append(":").append(strM).append(":").append(strS).append("'").toString();
/*      */     }
/*  911 */     else if (strType.equalsIgnoreCase("DB2")) {
/*  912 */       strRet = new StringBuilder().append("timestamp('").append(strDateStr).append(" ").append(strH).append(":").append(strM).append(":").append(strS).append("')").toString();
/*      */     }
/*  914 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("POSTGRESQL"))) {
/*  915 */       strRet = new StringBuilder().append("to_date('").append(strDateStr).append(" ").append(strH).append(":").append(strM).append(":").append(strS).append("','YYYY-mm-dd hh24:mi:ss')").toString();
/*      */     }
/*  917 */     else if (strType.equalsIgnoreCase("ACESS"))
/*  918 */       strRet = new StringBuilder().append("'").append(strDateStr).append("'").toString();
/*  919 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/*  920 */       strRet = new StringBuilder().append("CONVERT(Datetime,'").append(strDateStr).append(" ").append(strH).append(":").append(strM).append(":").append(strS).append("',20)").toString();
/*      */     }
/*  922 */     else if (strType.equalsIgnoreCase("TERA"))
/*  923 */       strRet = new StringBuilder().append(strDateStr).append(" (FORMAT 'YYYY-MM-DD')").toString();
/*  924 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/*  925 */       strRet = new StringBuilder().append("cast('").append(strDateStr).append(" ").append(strH).append(":").append(strM).append(":").append(strS).append("' as Datetime)").toString();
/*      */     }
/*      */     else {
/*  928 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/*  930 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2TimeStamp(Date date) throws Exception {
/*  934 */     SimpleDateFormat dFormat = new SimpleDateFormat("yyyy-MM-dd");
/*  935 */     SimpleDateFormat dFormat2 = new SimpleDateFormat("HH");
/*  936 */     SimpleDateFormat dFormat3 = new SimpleDateFormat("mm");
/*  937 */     SimpleDateFormat dFormat4 = new SimpleDateFormat("ss");
/*  938 */     return getSql2TimeStamp(dFormat.format(date), dFormat2.format(date), dFormat3.format(date), dFormat4.format(date));
/*      */   }
/*      */ 
/*      */   public String getSql2Date(String strDateStr, String splitStr)
/*      */     throws Exception
/*      */   {
/*  944 */     if ((null == strDateStr) || (strDateStr.length() < 1)) {
/*  945 */       return null;
/*      */     }
/*  947 */     if (strDateStr.indexOf("0000-00-00") >= 0) {
/*  948 */       return "null";
/*      */     }
/*  950 */     String strType = getDBMSType();
/*  951 */     String strRet = "";
/*  952 */     int i = strDateStr.indexOf(" ");
/*  953 */     if (i > 0) {
/*  954 */       strDateStr = strDateStr.substring(0, i);
/*      */     }
/*  956 */     if (strType.equalsIgnoreCase("MYSQL"))
/*  957 */       strRet = new StringBuilder().append("'").append(strDateStr).append("'").toString();
/*  958 */     else if (strType.equalsIgnoreCase("DB2"))
/*  959 */       strRet = new StringBuilder().append("date('").append(strDateStr).append("')").toString();
/*  960 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("POSTGRESQL"))) {
/*  961 */       if ("-".equals(splitStr)) {
/*  962 */         strRet = new StringBuilder().append("to_date('").append(strDateStr).append("','YYYY-mm-dd')").toString();
/*      */       }
/*      */       else {
/*  965 */         strRet = new StringBuilder().append("to_date('").append(strDateStr).append("','YYYY/mm/dd')").toString();
/*      */       }
/*      */     }
/*  968 */     else if (strType.equalsIgnoreCase("ACESS"))
/*  969 */       strRet = new StringBuilder().append("'").append(strDateStr).append("'").toString();
/*  970 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/*  971 */       if ("-".equals(splitStr)) {
/*  972 */         strRet = new StringBuilder().append("convert(varchar(10), convert(datetime,'").append(strDateStr).append("'), 111)").toString();
/*      */       }
/*      */       else {
/*  975 */         strRet = new StringBuilder().append("CONVERT(Datetime,'").append(strDateStr).append("',20)").toString();
/*      */       }
/*      */     }
/*  978 */     else if (strType.equalsIgnoreCase("TERA")) {
/*  979 */       if ("-".equals(splitStr)) {
/*  980 */         strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as date FORMAT 'YYYY-MM-DD')").toString();
/*      */       }
/*      */       else {
/*  983 */         strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as date FORMAT 'YYYY/MM/DD')").toString();
/*      */       }
/*      */     }
/*  986 */     else if (strType.equalsIgnoreCase("SYBASE"))
/*  987 */       strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as Date)").toString();
/*      */     else {
/*  989 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/*  991 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2DateYYYYMMDD(String strDateStr) throws Exception
/*      */   {
/*  996 */     if ((null == strDateStr) || (strDateStr.length() < 1)) {
/*  997 */       return null;
/*      */     }
/*  999 */     if (strDateStr.indexOf("000000") >= 0) {
/* 1000 */       return "null";
/*      */     }
/* 1002 */     String strType = getDBMSType();
/* 1003 */     String strRet = "";
/* 1004 */     int i = strDateStr.indexOf(" ");
/* 1005 */     if (i > 0) {
/* 1006 */       strDateStr = strDateStr.substring(0, i);
/*      */     }
/* 1008 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1009 */       strRet = new StringBuilder().append("'").append(strDateStr).append("'").toString();
/* 1010 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1011 */       strRet = new StringBuilder().append("date('").append(strDateStr).append("')").toString();
/* 1012 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("POSTGRESQL")))
/* 1013 */       strRet = new StringBuilder().append("to_date('").append(strDateStr).append("','YYYYmmdd')").toString();
/* 1014 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1015 */       strRet = new StringBuilder().append("'").append(strDateStr).append("'").toString();
/* 1016 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/* 1017 */       strRet = new StringBuilder().append("convert(varchar, convert(datetime, '").append(strDateStr).append("'), 112)").toString();
/*      */     }
/* 1019 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1020 */       strRet = new StringBuilder().append(strDateStr).append(" (FORMAT 'YYYYMMDD')").toString();
/* 1021 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 1022 */       strRet = new StringBuilder().append("cast('").append(strDateStr).append("' as Date)").toString();
/*      */     else {
/* 1024 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1026 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2ColumnName(String colName) throws Exception {
/* 1030 */     String strType = getDBMSType();
/* 1031 */     String strRet = "";
/* 1032 */     if (strType.equalsIgnoreCase("MYSQL")) {
/* 1033 */       strRet = new StringBuilder().append("Date_Format(").append(colName).append(",'%Y-%m-%d %H:%i:%s')").toString();
/*      */     }
/* 1035 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("POSTGRESQL"))) {
/* 1036 */       strRet = new StringBuilder().append("to_char(").append(colName).append(",'YYYY-mm-dd hh24:mi:ss')").toString();
/*      */     }
/* 1038 */     else if (strType.equalsIgnoreCase("DB2")) {
/* 1039 */       strRet = new StringBuilder().append("ts_fmt(").append(colName).append(",'yyyy-mm-dd hh:mi:ss')").toString();
/*      */     }
/* 1041 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1042 */       strRet = colName;
/* 1043 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 1044 */       strRet = new StringBuilder().append("CONVERT(Varchar,").append(colName).append(",120)").toString();
/* 1045 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1046 */       strRet = new StringBuilder().append(colName).append(" (FORMAT 'YYYY-MM-DD')").toString();
/* 1047 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 1048 */       strRet = new StringBuilder().append("convert(char(10),").append(colName).append(",23) || ' ' || convert(char(8),").append(colName).append(",108)").toString();
/*      */     }
/*      */     else {
/* 1051 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1053 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2DateTimeNow() throws Exception {
/* 1057 */     String strType = getDBMSType();
/* 1058 */     String strRet = "";
/* 1059 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1060 */       strRet = "now()";
/* 1061 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1062 */       strRet = "sysdate";
/* 1063 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1064 */       strRet = "date()+time()";
/* 1065 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 1066 */       strRet = "getdate()";
/* 1067 */     else if (strType.equalsIgnoreCase("POSTGRESQL"))
/* 1068 */       strRet = "current_timestamp";
/* 1069 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1070 */       strRet = "current timestamp";
/* 1071 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1072 */       strRet = "cast((date (format 'yyyy-mm-dd' )) as char(10)) ||' '|| time";
/* 1073 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 1074 */       strRet = "getdate()";
/*      */     else {
/* 1076 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1078 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2DateNow() throws Exception {
/* 1082 */     String strType = getDBMSType();
/* 1083 */     String strRet = "";
/* 1084 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1085 */       strRet = "now()";
/* 1086 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1087 */       strRet = "sysdate";
/* 1088 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1089 */       strRet = "date()";
/* 1090 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 1091 */       strRet = "getdate()";
/* 1092 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1093 */       strRet = "current date";
/* 1094 */     else if (strType.equalsIgnoreCase("POSTGRESQL"))
/* 1095 */       strRet = "current_date";
/* 1096 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1097 */       strRet = "cast((date (format 'yyyy-mm-dd' )) as char(10)) ||' '|| time";
/* 1098 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 1099 */       strRet = "getdate()";
/*      */     else {
/* 1101 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1103 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String escapeString(String str) throws Exception {
/* 1107 */     if ((str == null) || (str.length() < 1)) {
/* 1108 */       return "";
/*      */     }
/* 1110 */     String strType = getDBMSType();
/* 1111 */     String strRet = "";
/* 1112 */     for (int i = 0; i < str.length(); i++) {
/* 1113 */       char c = str.charAt(i);
/* 1114 */       if (c == '\'') {
/* 1115 */         if (strType.equalsIgnoreCase("MYSQL")) {
/* 1116 */           strRet = new StringBuilder().append(strRet).append("\\'").toString();
/*      */         }
/* 1119 */         else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("DB2")) || (strType.equalsIgnoreCase("TERA")) || (strType.equalsIgnoreCase("SYBASE")))
/*      */         {
/* 1121 */           strRet = new StringBuilder().append(strRet).append("''").toString();
/*      */         }
/* 1123 */         else strRet = new StringBuilder().append(strRet).append(c).toString();
/*      */ 
/*      */       }
/* 1127 */       else if (c == '"') {
/* 1128 */         if (strType.equalsIgnoreCase("MYSQL")) {
/* 1129 */           strRet = new StringBuilder().append(strRet).append("\\\"").toString();
/*      */         }
/* 1132 */         else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("DB2")) || (strType.equalsIgnoreCase("TERA")) || (strType.equalsIgnoreCase("SYBASE")))
/*      */         {
/* 1134 */           strRet = new StringBuilder().append(strRet).append("\"").toString();
/*      */         }
/* 1136 */         else strRet = new StringBuilder().append(strRet).append(c).toString();
/*      */ 
/*      */       }
/* 1140 */       else if (c == '\\') {
/* 1141 */         if (strType.equalsIgnoreCase("MYSQL"))
/* 1142 */           strRet = new StringBuilder().append(strRet).append("\\\\").toString();
/*      */         else
/* 1144 */           strRet = new StringBuilder().append(strRet).append(c).toString();
/*      */       }
/*      */       else {
/* 1147 */         strRet = new StringBuilder().append(strRet).append(c).toString();
/*      */       }
/*      */     }
/*      */ 
/* 1151 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlLimit(String strSql, int limitnum) throws Exception
/*      */   {
/* 1156 */     String strType = getDBMSType();
/* 1157 */     String strRet = "";
/* 1158 */     if (strType.equalsIgnoreCase("MYSQL")) {
/* 1159 */       strRet = new StringBuilder().append(strSql).append(" limit ").append(limitnum).toString();
/* 1160 */     } else if (strType.equalsIgnoreCase("ORACLE")) {
/* 1161 */       limitnum++;
/* 1162 */       strRet = new StringBuilder().append("select * from (").append(strSql).append(") where ROWNUM<").append(limitnum).toString();
/*      */     }
/* 1164 */     else if (strType.equalsIgnoreCase("DB2")) {
/* 1165 */       strRet = new StringBuilder().append(strSql).append("fetch first ").append(limitnum).append(" rows only").toString();
/*      */     }
/* 1167 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 1168 */       strRet = new StringBuilder().append("select top ").append(limitnum).append(" * from(").append(strSql).append(") a").toString();
/*      */     }
/* 1170 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/* 1171 */       strRet = new StringBuilder().append("select top ").append(limitnum).append(" * from(").append(strSql).append(") a").toString();
/*      */     }
/* 1173 */     else if ("TERA".equalsIgnoreCase(strType)) {
/* 1174 */       StringBuffer buffer = new StringBuffer(strSql.length() + 100);
/* 1175 */       buffer.append(strSql);
/* 1176 */       int orderByIndex = buffer.toString().toLowerCase().lastIndexOf("order by");
/* 1177 */       if (orderByIndex > 0) {
/* 1178 */         String orderBy = buffer.substring(orderByIndex);
/* 1179 */         buffer.insert(orderByIndex, " QUALIFY row_number() OVER( ");
/* 1180 */         buffer.append(" ) ");
/* 1181 */         buffer.append(new StringBuilder().append(" between 1 and ").append(limitnum).toString());
/* 1182 */         buffer.append(orderBy);
/*      */       } else {
/* 1184 */         buffer.append(new StringBuilder().append(" QUALIFY sum(1) over (rows unbounded preceding) between 1 and ").append(limitnum).toString());
/*      */       }
/*      */ 
/* 1188 */       strRet = buffer.toString();
/*      */     } else {
/* 1190 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 1192 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String getCountTotalSql(String table, String strPrimaryKey, String condition, String tail) {
/* 1196 */     if (table == null) {
/* 1197 */       return "";
/*      */     }
/* 1199 */     String sql = new StringBuilder().append("select count(").append(strPrimaryKey).append(") from ").toString();
/* 1200 */     sql = new StringBuilder().append(sql).append(table).append("    ").toString();
/* 1201 */     if ((condition != null) && (!condition.equals(""))) {
/* 1202 */       sql = new StringBuilder().append(sql).append("where ").append(condition).toString();
/*      */     }
/* 1204 */     if ((tail != null) && (!tail.equals(""))) {
/* 1205 */       sql = new StringBuilder().append(sql).append(tail).toString();
/*      */     }
/* 1207 */     return sql;
/*      */   }
/*      */ 
/*      */   public static String getCountTotalSql(String sql, String primaryKey)
/*      */   {
/* 1212 */     StringBuffer countSQL = new StringBuffer();
/* 1213 */     if ((primaryKey == null) || (primaryKey.length() < 1)) {
/* 1214 */       primaryKey = "*";
/*      */     }
/* 1216 */     countSQL.append(new StringBuilder().append("select count(").append(primaryKey).append(") from ( ").toString());
/* 1217 */     countSQL.append(sql);
/* 1218 */     countSQL.append(" ) tt");
/* 1219 */     return countSQL.toString();
/*      */   }
/*      */ 
/*      */   public String getPagedSql(String srcSql, int currPage, int pageSize) throws Exception {
/* 1223 */     String dbType = getDBMSType();
/* 1224 */     int begin = (currPage - 1) * pageSize;
/* 1225 */     int end = begin + pageSize;
/* 1226 */     String strRet = srcSql;
/* 1227 */     if (dbType.equals("MYSQL")) {
/* 1228 */       strRet = new StringBuilder().append(srcSql).append(" limit ").append(begin).append(",").append(pageSize).toString();
/*      */     }
/* 1232 */     else if (dbType.equals("POSTGRESQL")) {
/* 1233 */       strRet = new StringBuilder().append(srcSql).append(" limit ").append(pageSize).append(" offset ").append(begin).toString();
/*      */     }
/* 1237 */     else if (dbType.equals("ORACLE")) {
/* 1238 */       end++;
/* 1239 */       strRet = new StringBuilder().append("SELECT * FROM (SELECT ROWNUM AS NUMROW, c.* from (").append(srcSql).append(") c) WHERE NUMROW >").append(begin).append(" AND NUMROW <").append(end).toString();
/*      */     }
/* 1241 */     else if (dbType.equals("DB2")) {
/* 1242 */       StringBuffer rownumber = new StringBuffer(50).append(" rownumber() over(");
/* 1243 */       int orderByIndex = srcSql.toLowerCase().indexOf("order by");
/*      */ 
/* 1245 */       if (orderByIndex > 0) {
/* 1246 */         String strOrder = srcSql.substring(orderByIndex);
/* 1247 */         String[] arryStr = strOrder.split(" ");
/*      */ 
/* 1249 */         StringBuilder sb = new StringBuilder();
/* 1250 */         for (int i = 0; i < arryStr.length; i++) {
/* 1251 */           if (arryStr[i].lastIndexOf(".") > -1) {
/* 1252 */             String[] arrStr = arryStr[i].split(",");
/* 1253 */             arryStr[i] = "";
/* 1254 */             for (int j = 0; j < arrStr.length; j++) {
/* 1255 */               arrStr[j] = arrStr[j].substring(arrStr[j].lastIndexOf(".") + 1);
/*      */               int tmp343_341 = i;
/*      */               String[] tmp343_339 = arryStr; tmp343_339[tmp343_341] = new StringBuilder().append(tmp343_339[tmp343_341]).append(arrStr[j]).toString();
/* 1257 */               if (j != arrStr.length - 1)
/*      */               {
/*      */                 int tmp381_379 = i;
/*      */                 String[] tmp381_377 = arryStr; tmp381_377[tmp381_379] = new StringBuilder().append(tmp381_377[tmp381_379]).append(",").toString();
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/* 1263 */           sb.append(arryStr[i]).append(" ");
/*      */         }
/* 1265 */         rownumber.append(sb.toString());
/*      */       }
/* 1267 */       rownumber.append(") as row_,");
/* 1268 */       StringBuffer pagingSelect = new StringBuffer(srcSql.length() + 100).append("select * from ( ").append(" select ").append(rownumber.toString()).append("temp_.* from (").append(srcSql).append(" ) as temp_").append(" ) as temp2_").append(new StringBuilder().append(" where row_  between ").append(begin).append("+1 and ").append(end).toString());
/*      */ 
/* 1278 */       strRet = pagingSelect.toString();
/* 1279 */     } else if ((!dbType.equals("SYBASE")) && ("TERA".equalsIgnoreCase(dbType))) {
/* 1280 */       StringBuffer buffer = new StringBuffer(srcSql.length() + 100);
/* 1281 */       buffer.append(srcSql);
/* 1282 */       int orderByIndex = buffer.toString().toLowerCase().lastIndexOf("order by");
/* 1283 */       if (orderByIndex > 0) {
/* 1284 */         String orderBy = buffer.substring(orderByIndex);
/* 1285 */         buffer.insert(orderByIndex, " QUALIFY row_number() OVER( ");
/* 1286 */         buffer.append(" ) ");
/* 1287 */         buffer.append(new StringBuilder().append(" between ").append(begin).append(" and ").append(end).toString());
/*      */ 
/* 1289 */         buffer.append(orderBy);
/*      */       } else {
/* 1291 */         buffer.append(new StringBuilder().append(" QUALIFY sum(1) over (rows unbounded preceding) between ").append(begin).append(" and ").append(end).toString());
/*      */       }
/*      */ 
/* 1294 */       strRet = buffer.toString();
/*      */     }
/* 1296 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getPagedSql(String sql, String column, String strPrimaryKey, int curpage, int pagesize) throws Exception
/*      */   {
/* 1301 */     String strDBType = getDBMSType();
/* 1302 */     StringBuffer buffer = null;
/* 1303 */     buffer = new StringBuffer();
/* 1304 */     if ("ORACLE".equalsIgnoreCase(strDBType)) {
/* 1305 */       buffer.append("select * from ( ");
/* 1306 */       buffer.append("select ").append(column).append(" rownum as my_rownum from( ");
/* 1307 */       buffer.append(sql).append(") ");
/* 1308 */       int pageAll = pagesize * curpage + pagesize;
/* 1309 */       buffer.append(new StringBuilder().append("where rownum <= ").append(pageAll).append(") a ").toString());
/* 1310 */       buffer.append(new StringBuilder().append("where a.my_rownum > ").append(pagesize * curpage).toString());
/* 1311 */     } else if ("DB2".equalsIgnoreCase(strDBType)) {
/* 1312 */       buffer.append("select * from ( ");
/* 1313 */       buffer.append("select ").append(column).append(new StringBuilder().append("  rownumber() over (order by ").append(strPrimaryKey).append(") as my_rownum from( ").toString());
/*      */ 
/* 1317 */       buffer.append(sql).append(") as temp ");
/* 1318 */       buffer.append(new StringBuilder().append("fetch first ").append(pagesize * curpage + pagesize).append(" rows only) as a ").toString());
/*      */ 
/* 1320 */       buffer.append(new StringBuilder().append("where a.my_rownum > ").append(pagesize * curpage).toString());
/* 1321 */     } else if ("TERA".equalsIgnoreCase(strDBType)) {
/* 1322 */       buffer.append(sql);
/* 1323 */       int orderByIndex = buffer.toString().toLowerCase().lastIndexOf("order by");
/* 1324 */       if (orderByIndex > 0) {
/* 1325 */         String orderBy = buffer.substring(orderByIndex);
/* 1326 */         buffer.insert(orderByIndex, " QUALIFY row_number() OVER( ");
/* 1327 */         buffer.append(" ) ");
/* 1328 */         buffer.append(new StringBuilder().append(" between ").append(pagesize * curpage).append(" and ").append(pagesize * curpage + pagesize).toString());
/*      */ 
/* 1330 */         buffer.append(orderBy);
/*      */       } else {
/* 1332 */         buffer.append(new StringBuilder().append(" QUALIFY sum(1) over (rows unbounded preceding) between ").append(pagesize * curpage).append(" and ").append(pagesize * curpage + pagesize).toString());
/*      */       }
/*      */     }
/*      */ 
/* 1336 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   private static int getAfterSelectInsertPoint(String sql) {
/* 1340 */     return 16 + (sql.startsWith("select distinct") ? 15 : 6);
/*      */   }
/*      */ 
/*      */   public String getSqlSubString(String strColName, int pos, int len) throws Exception {
/* 1344 */     String strType = getDBMSType();
/* 1345 */     String strRet = "";
/* 1346 */     if ((strType.equalsIgnoreCase("MYSQL")) || (strType.equalsIgnoreCase("SYBASE"))) {
/* 1347 */       if (len == -1) {
/* 1348 */         strRet = new StringBuilder().append("substring(").append(strColName).append(",").append(pos).append(")").toString();
/*      */       }
/*      */       else {
/* 1351 */         strRet = new StringBuilder().append("substring(").append(strColName).append(",").append(pos).append(",").append(len).append(")").toString();
/*      */       }
/*      */     }
/* 1354 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("DB2")) || (strType.equalsIgnoreCase("POSTGRESQL")))
/*      */     {
/* 1356 */       if (len == -1) {
/* 1357 */         strRet = new StringBuilder().append("substr(").append(strColName).append(",").append(pos).append(")").toString();
/*      */       }
/*      */       else {
/* 1360 */         strRet = new StringBuilder().append("substr(").append(strColName).append(",").append(pos).append(",").append(len).append(")").toString();
/*      */       }
/*      */     }
/* 1363 */     else if (strType.equalsIgnoreCase("TERA")) {
/* 1364 */       if (len == -1) {
/* 1365 */         strRet = new StringBuilder().append("substring(").append(strColName).append(" form ").append(pos).append(")").toString();
/*      */       }
/*      */       else {
/* 1368 */         strRet = new StringBuilder().append("substring(").append(strColName).append(" from ").append(pos).append(" for ").append(len).append(")").toString();
/*      */       }
/*      */     }
/*      */     else {
/* 1372 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 1374 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlSubDate(String interv) throws Exception {
/* 1378 */     String strType = getDBMSType();
/* 1379 */     String strRet = "";
/* 1380 */     if (strType.equalsIgnoreCase("MYSQL")) {
/* 1381 */       strRet = new StringBuilder().append("SUBDATE(now(),INTERVAL ").append(interv).append(" minute)").toString();
/*      */     }
/* 1383 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1384 */       strRet = new StringBuilder().append("(sysdate-").append(interv).append("/(24*60))").toString();
/* 1385 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1386 */       strRet = new StringBuilder().append("(current timestamp-").append(interv).append(" minute)").toString();
/* 1387 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 1388 */       strRet = new StringBuilder().append("dateadd(mi,-").append(interv).append(",getdate())").toString();
/*      */     else {
/* 1390 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1392 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlAddDate(String interv, String unit) throws Exception
/*      */   {
/* 1397 */     String strRet = "";
/* 1398 */     String strType = getDBMSType();
/* 1399 */     unit = unit.trim().toUpperCase();
/* 1400 */     interv = interv.trim();
/* 1401 */     if (!interv.startsWith("-")) {
/* 1402 */       interv = new StringBuilder().append("+").append(interv).toString();
/*      */     }
/* 1404 */     if (strType.equalsIgnoreCase("MYSQL")) {
/* 1405 */       strRet = new StringBuilder().append("ADDDATE(now(),INTERVAL ").append(interv).append(" ").append(unit).append(")").toString();
/*      */     }
/* 1407 */     else if (strType.equalsIgnoreCase("ORACLE")) {
/* 1408 */       if (unit.compareTo("MINUTE") == 0)
/* 1409 */         strRet = new StringBuilder().append("(sysdate").append(interv).append("/(24*60))").toString();
/* 1410 */       else if (unit.compareTo("SECOND") == 0)
/* 1411 */         strRet = new StringBuilder().append("(sysdate").append(interv).append("/(24*60*60))").toString();
/* 1412 */       else if (unit.compareTo("HOUR") == 0)
/* 1413 */         strRet = new StringBuilder().append("(sysdate").append(interv).append("/24)").toString();
/* 1414 */       else if (unit.compareTo("DAY") == 0)
/* 1415 */         strRet = new StringBuilder().append("(sysdate").append(interv).append(")").toString();
/* 1416 */       else if (unit.compareTo("MONTH") == 0)
/* 1417 */         strRet = new StringBuilder().append("(add_months(sysdate,").append(interv).append("))").toString();
/* 1418 */       else if (unit.compareTo("YEAR") == 0) {
/* 1419 */         strRet = new StringBuilder().append("(add_months(sysdate,(").append(interv).append("*12)))").toString();
/*      */       }
/*      */     }
/* 1422 */     else if (strType.equalsIgnoreCase("DB2")) {
/* 1423 */       strRet = new StringBuilder().append("(current timestamp ").append(interv).append(" ").append(unit).append(")").toString();
/*      */     }
/* 1425 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 1426 */       if (unit.compareTo("MINUTE") == 0)
/* 1427 */         strRet = new StringBuilder().append("dateadd(mi,").append(interv).append(",getdate())").toString();
/* 1428 */       else if (unit.compareTo("SECOND") == 0)
/* 1429 */         strRet = new StringBuilder().append("dateadd(ss,").append(interv).append(",getdate())").toString();
/* 1430 */       else if (unit.compareTo("HOUR") == 0)
/* 1431 */         strRet = new StringBuilder().append("dateadd(hh,").append(interv).append(",getdate())").toString();
/* 1432 */       else if (unit.compareTo("DAY") == 0)
/* 1433 */         strRet = new StringBuilder().append("dateadd(dd,").append(interv).append(",getdate())").toString();
/* 1434 */       else if (unit.compareTo("MONTH") == 0)
/* 1435 */         strRet = new StringBuilder().append("dateadd(mm,").append(interv).append(",getdate())").toString();
/* 1436 */       else if (unit.compareTo("YEAR") == 0)
/* 1437 */         strRet = new StringBuilder().append("dateadd(yy,").append(interv).append(",getdate())").toString();
/*      */     }
/*      */     else {
/* 1440 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1442 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlDateAddMonth(String monthNum) throws Exception {
/* 1446 */     String strType = getDBMSType();
/* 1447 */     String strRet = "";
/* 1448 */     if (strType.equalsIgnoreCase("MYSQL")) {
/* 1449 */       strRet = new StringBuilder().append("DATE_ADD(curdate(),INTERVAL ").append(monthNum).append(" month)").toString();
/*      */     }
/* 1451 */     else if (strType.equalsIgnoreCase("ORACLE")) {
/* 1452 */       strRet = new StringBuilder().append("to_char(add_months(sysdate,").append(monthNum).append("),'YYYY-mm-dd')").toString();
/*      */     }
/* 1454 */     else if (strType.equalsIgnoreCase("DB2")) {
/* 1455 */       strRet = new StringBuilder().append("char((current date + ").append(monthNum).append(" month))").toString();
/*      */     }
/* 1457 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 1458 */       strRet = new StringBuilder().append("dateadd(mm,").append(monthNum).append(",getdate())").toString();
/* 1459 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1460 */       strRet = new StringBuilder().append("add_months(date,").append(monthNum).append(")").toString();
/*      */     else {
/* 1462 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1464 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlEncrypt(String strPwd) throws Exception {
/* 1468 */     StringBuffer strRet = new StringBuffer();
/* 1469 */     strRet.append("'");
/* 1470 */     strRet.append(DES.encrypt(strPwd));
/* 1471 */     strRet.append("'");
/* 1472 */     return strRet.toString();
/*      */   }
/*      */ 
/*      */   public String getSql_intTochar(String strColName) throws Exception
/*      */   {
/* 1477 */     String strType = getDBMSType();
/* 1478 */     String strRet = "";
/* 1479 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1480 */       strRet = strColName;
/* 1481 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1482 */       strRet = new StringBuilder().append("cast(").append(strColName).append(" as varchar2(32))").toString();
/* 1483 */     else if (strType.equalsIgnoreCase("POSTGRESQL"))
/* 1484 */       strRet = new StringBuilder().append("cast(").append(strColName).append(" as varchar)").toString();
/* 1485 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1486 */       strRet = new StringBuilder().append("rtrim(char(").append(strColName).append("))").toString();
/* 1487 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 1488 */       strRet = new StringBuilder().append("convert(char,").append(strColName).append(")").toString();
/* 1489 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 1490 */       strRet = new StringBuilder().append("cast(").append(strColName).append(" as varchar(12))").toString();
/* 1491 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1492 */       strRet = new StringBuilder().append("cast(").append(strColName).append(" as varchar(12))").toString();
/*      */     else {
/* 1494 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 1496 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql_charToint(String strColName) throws Exception
/*      */   {
/* 1501 */     String strType = getDBMSType();
/* 1502 */     String strRet = "";
/* 1503 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1504 */       strRet = strColName;
/* 1505 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("TERA")) || (strType.equalsIgnoreCase("POSTGRESQL")))
/*      */     {
/* 1507 */       strRet = new StringBuilder().append("cast(").append(strColName).append(" as integer)").toString();
/* 1508 */     } else if (strType.equalsIgnoreCase("DB2"))
/* 1509 */       strRet = new StringBuilder().append("int(").append(strColName).append(")").toString();
/* 1510 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 1511 */       strRet = new StringBuilder().append("convert(int,").append(strColName).append(")").toString();
/* 1512 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 1513 */       strRet = new StringBuilder().append("cast(").append(strColName).append(" as integer)").toString();
/*      */     else {
/* 1515 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 1517 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql_charToDouble(String strColName) throws Exception
/*      */   {
/* 1522 */     String strType = getDBMSType();
/* 1523 */     String strRet = "";
/* 1524 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1525 */       strRet = strColName;
/* 1526 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("POSTGRESQL")))
/* 1527 */       strRet = new StringBuilder().append("cast(").append(strColName).append(" as numeric)").toString();
/* 1528 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1529 */       strRet = new StringBuilder().append("double(").append(strColName).append(")").toString();
/*      */     else {
/* 1531 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 1533 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlRound(String str1, String str2) throws Exception {
/* 1537 */     String strType = getDBMSType();
/* 1538 */     String strRet = "";
/* 1539 */     if (strType.equalsIgnoreCase("TERA")) {
/* 1540 */       strRet = new StringBuilder().append(" cast ((").append(str1).append(") as decimal(10,").append(str2).append(")) ").toString();
/*      */     }
/*      */     else {
/* 1543 */       strRet = new StringBuilder().append(" round(").append(str1).append(",").append(str2).append(") ").toString();
/*      */     }
/*      */ 
/* 1546 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlNotEqual() throws Exception {
/* 1550 */     String strType = getDBMSType();
/* 1551 */     String strRet = "";
/* 1552 */     if (strType.equalsIgnoreCase("TERA"))
/* 1553 */       strRet = "<>";
/*      */     else {
/* 1555 */       strRet = "!=";
/*      */     }
/* 1557 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlNvl(String str1, String str2) throws Exception {
/* 1561 */     String strType = getDBMSType();
/* 1562 */     String strRet = "";
/* 1563 */     if (strType.equalsIgnoreCase("DB2")) {
/* 1564 */       strRet = new StringBuilder().append("value(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/* 1566 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("POSTGRESQL")))
/* 1567 */       strRet = new StringBuilder().append("nvl(").append(str1).append(",").append(str2).append(")").toString();
/* 1568 */     else if (strType.equalsIgnoreCase("MYSQL")) {
/* 1569 */       strRet = new StringBuilder().append("ifnull(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/* 1571 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 1572 */       strRet = new StringBuilder().append("isnull(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/* 1574 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/* 1575 */       strRet = new StringBuilder().append("isnull(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/* 1577 */     else if (strType.equalsIgnoreCase("TERA")) {
/* 1578 */       strRet = new StringBuilder().append("COALESCE(").append(str1).append(",").append(str2).append(")").toString();
/*      */     }
/*      */     else {
/* 1581 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 1583 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getCreateAsTableSql(String newtable, String templettable) throws Exception {
/* 1587 */     String ss = "";
/* 1588 */     String strDBType = getDBMSType();
/* 1589 */     if (("ORACLE".equalsIgnoreCase(strDBType)) || ("POSTGRESQL".equalsIgnoreCase(strDBType))) {
/* 1590 */       ss = new StringBuilder().append("create table ").append(newtable).append(" as select * from ").append(templettable).append(" where 1=2").toString();
/*      */     }
/* 1592 */     else if ("DB2".equalsIgnoreCase(strDBType)) {
/* 1593 */       ss = new StringBuilder().append("create table ").append(newtable).append(" like ").append(templettable).toString();
/*      */     }
/* 1595 */     else if ("TERA".equalsIgnoreCase(strDBType)) {
/* 1596 */       ss = new StringBuilder().append("create table ").append(newtable).append(" as ").append(templettable).append(" with no data").toString();
/*      */     }
/*      */ 
/* 1599 */     return ss;
/*      */   }
/*      */ 
/*      */   public String getCreateAsTableSql(String newtable, String templettable, String tableSpace) throws Exception {
/* 1603 */     String ss = getCreateAsTableSql(newtable, templettable);
/* 1604 */     if ((tableSpace == null) || (tableSpace.length() < 1)) {
/* 1605 */       return ss;
/*      */     }
/* 1607 */     String strDBType = getDBMSType();
/* 1608 */     if (("ORACLE".equalsIgnoreCase(strDBType)) || ("POSTGRESQL".equalsIgnoreCase(strDBType))) {
/* 1609 */       ss = ss.replaceAll(newtable, new StringBuilder().append(newtable).append(" tablespace ").append(tableSpace).toString());
/*      */     }
/* 1611 */     else if ("DB2".equalsIgnoreCase(strDBType)) {
/* 1612 */       ss = new StringBuilder().append(ss).append(" in ").append(tableSpace).toString();
/*      */     }
/* 1614 */     return ss;
/*      */   }
/*      */ 
/*      */   public String getCreateTableInTableSpaceSql(String tableDDLSql, String tableSpace) throws Exception
/*      */   {
/* 1619 */     if ((tableSpace == null) || (tableSpace.length() < 1)) {
/* 1620 */       return tableDDLSql;
/*      */     }
/* 1622 */     String strDBType = getDBMSType();
/* 1623 */     if (("ORACLE".equalsIgnoreCase(strDBType)) || ("POSTGRESQL".equalsIgnoreCase(strDBType))) {
/* 1624 */       tableDDLSql = new StringBuilder().append(tableDDLSql).append(" tablespace ").append(tableSpace).toString();
/*      */     }
/* 1626 */     else if ("DB2".equalsIgnoreCase(strDBType)) {
/* 1627 */       tableDDLSql = new StringBuilder().append(tableDDLSql).append(" in ").append(tableSpace).toString();
/*      */     }
/* 1629 */     return tableDDLSql;
/*      */   }
/*      */ 
/*      */   public String getCreateIndexInTableSpaceSql(String createIndexSql, String tableSpace) throws Exception
/*      */   {
/* 1634 */     if ((tableSpace == null) || (tableSpace.length() < 1)) {
/* 1635 */       return createIndexSql;
/*      */     }
/* 1637 */     String strDBType = getDBMSType();
/* 1638 */     if ("ORACLE".equalsIgnoreCase(strDBType)) {
/* 1639 */       createIndexSql = new StringBuilder().append(createIndexSql).append(" using index tablespace ").append(tableSpace).toString();
/*      */     }
/* 1641 */     else if ("DB2".equalsIgnoreCase(strDBType));
/* 1644 */     return createIndexSql;
/*      */   }
/*      */ 
/*      */   public String getCheckTableIsExistSql(String tableName) throws Exception {
/* 1648 */     String strSql = "";
/* 1649 */     String strDBType = getDBMSType();
/* 1650 */     if (strDBType.equals("DB2")) {
/* 1651 */       strSql = new StringBuilder().append("select count(*) from syscat.tables where tabname='").append(tableName.toUpperCase()).append("'").toString();
/*      */     }
/* 1653 */     else if (strDBType.equals("ORACLE")) {
/* 1654 */       strSql = new StringBuilder().append("select count(*) from TAB where tname='").append(tableName.toUpperCase()).append("'").toString();
/*      */     }
/* 1656 */     else if (strDBType.equals("TERA")) {
/* 1657 */       strSql = new StringBuilder().append("select count(*) from dbc.tables where tablename='").append(tableName.toUpperCase()).append("'").toString();
/*      */     }
/* 1659 */     else if (strDBType.equals("GBASE")) {
/* 1660 */       strSql = new StringBuilder().append("SELECT count(*) FROM information_schema.TABLES WHERE upper(TABLE_NAME)=upper('").append(tableName.toUpperCase()).append("')").toString();
/*      */     }
/*      */ 
/* 1664 */     return strSql;
/*      */   }
/*      */ 
/*      */   public String getSql_dateTochar(String strColName, String mask) throws Exception
/*      */   {
/* 1669 */     String strRet = "";
/* 1670 */     strRet = new StringBuilder().append("substr(").append(getSql2ColumnName(strColName)).append(",1,").append(mask.trim().length()).append(")").toString();
/*      */ 
/* 1672 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlOptimizeStart(String tablename, String cpuParallelSize) throws Exception {
/* 1676 */     String strRet = "";
/* 1677 */     String strDBType = getDBMSType();
/* 1678 */     if (strDBType.equalsIgnoreCase("ORACLE")) {
/* 1679 */       strRet = new StringBuilder().append("select /*+ parallel( ").append(tablename).append(" ,").append(cpuParallelSize).append(") */ ").toString();
/*      */     }
/*      */     else {
/* 1682 */       strRet = "select ";
/*      */     }
/* 1684 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlOptimizeEnd() throws Exception {
/* 1688 */     String strRet = "";
/* 1689 */     String strDBType = getDBMSType();
/* 1690 */     if (strDBType.equalsIgnoreCase("ORACLE")) {
/* 1691 */       strRet = ",row_number() over( order by 100) ";
/*      */     }
/* 1693 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlNolog(String tablename) throws Exception {
/* 1697 */     String strRet = "";
/* 1698 */     String strDBType = getDBMSType();
/* 1699 */     if (strDBType.equalsIgnoreCase("ORACLE")) {
/* 1700 */       strRet = new StringBuilder().append("alter table ").append(tablename).append(" nologging").toString();
/*      */     }
/* 1702 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlOptimizeInsert() throws Exception {
/* 1706 */     String strRet = "";
/* 1707 */     String strDBType = getDBMSType();
/* 1708 */     if (strDBType.equalsIgnoreCase("ORACLE"))
/* 1709 */       strRet = "insert /*+append*/ into ";
/*      */     else {
/* 1711 */       strRet = "insert into ";
/*      */     }
/* 1713 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getCreateTableSql(String dataspace, String db2schemasuff, String dataspaceindex, String partitionKey) throws Exception
/*      */   {
/* 1718 */     String strRet = "";
/* 1719 */     String dbType = getDBMSType();
/* 1720 */     if ((dbType.equalsIgnoreCase("ORACLE")) || (dbType.equalsIgnoreCase("POSTGRESQL"))) {
/* 1721 */       strRet = new StringBuilder().append(" tablespace  ").append(dataspace).toString();
/* 1722 */     } else if (dbType.equalsIgnoreCase("DB2")) {
/* 1723 */       strRet = new StringBuilder().append(db2schemasuff).append(dataspace).append(dataspaceindex).toString();
/* 1724 */       if ((null != partitionKey) && (!"".equals(partitionKey))) {
/* 1725 */         strRet = new StringBuilder().append(strRet).append(" PARTITIONING KEY (").append(partitionKey).append(") USING HASHING").toString();
/*      */       }
/*      */ 
/* 1728 */       strRet = new StringBuilder().append(strRet).append(" NOT LOGGED INITIALLY ").toString();
/*      */     }
/* 1730 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlIsNull(String strColName, boolean isNull) throws Exception {
/* 1734 */     String strRet = "";
/* 1735 */     String dbType = getDBMSType();
/* 1736 */     if (isNull) {
/* 1737 */       strRet = new StringBuilder().append(strColName).append(" is null").toString();
/* 1738 */       if (dbType.equalsIgnoreCase("DB2"))
/* 1739 */         strRet = new StringBuilder().append(strRet).append(" or ").append(strColName).append("=''").toString();
/*      */     }
/*      */     else
/*      */     {
/* 1743 */       strRet = new StringBuilder().append(strColName).append(" is not null").toString();
/* 1744 */       if (dbType.equalsIgnoreCase("DB2")) {
/* 1745 */         strRet = new StringBuilder().append(strRet).append(" and not ").append(strColName).append("=''").toString();
/*      */       }
/*      */     }
/*      */ 
/* 1749 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlSystables() throws Exception {
/* 1753 */     String strRet = "select * from(";
/* 1754 */     String dbType = getDBMSType();
/* 1755 */     if (dbType.equalsIgnoreCase("ORACLE")) {
/* 1756 */       strRet = new StringBuilder().append(strRet).append("select owner tabschema,table_name tabname,comments remarks From All_Tab_Comments").toString();
/*      */ 
/* 1759 */       strRet = new StringBuilder().append(strRet).append(") where 1=1").toString();
/* 1760 */       strRet = new StringBuilder().append(strRet).append(" and tabschema not like 'SYS%'").toString();
/* 1761 */     } else if (dbType.equalsIgnoreCase("DB2")) {
/* 1762 */       strRet = new StringBuilder().append(strRet).append("select tabschema,tabname,remarks from syscat.tables").toString();
/*      */ 
/* 1764 */       strRet = new StringBuilder().append(strRet).append(")as ta where 1=1").toString();
/* 1765 */       strRet = new StringBuilder().append(strRet).append(" and tabschema not like 'SYSIBM%'").toString();
/* 1766 */     } else if (dbType.equalsIgnoreCase("MYSQL")) {
/* 1767 */       strRet = new StringBuilder().append(strRet).append("select table_schema tabschema,table_name tabname,table_comment remarks from information_schema.tables").toString();
/*      */ 
/* 1771 */       strRet = new StringBuilder().append(strRet).append(")as ta where 1=1").toString();
/* 1772 */       strRet = new StringBuilder().append(strRet).append(" and tabschema='").append(getDatabaseName()).append("'").toString();
/*      */     }
/*      */ 
/* 1775 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getDatabaseName() throws Exception {
/* 1779 */     String dbname = "";
/* 1780 */     String dbType = getDBMSType();
/* 1781 */     String url = this.connection.getMetaData().getURL();
/* 1782 */     if (dbType.equalsIgnoreCase("MYSQL")) {
/* 1783 */       int s = url.indexOf("/", 13) + 1;
/* 1784 */       int e = url.indexOf("?");
/* 1785 */       dbname = url.substring(s, e).toLowerCase();
/* 1786 */       log.debug(dbname);
/*      */     }
/* 1788 */     return dbname;
/*      */   }
/*      */ 
/*      */   public String getSqlConcat(String strColNames) throws Exception {
/* 1792 */     String strRet = "";
/* 1793 */     String dbType = getDBMSType();
/* 1794 */     String[] names = strColNames.split(",");
/* 1795 */     if (dbType.equalsIgnoreCase("MYSQL")) {
/* 1796 */       for (int i = 0; i < names.length; i++) {
/* 1797 */         if (i == 0)
/* 1798 */           strRet = names[0];
/*      */         else {
/* 1800 */           strRet = new StringBuilder().append("CONCAT(").append(strRet).append(",").append(names[i]).append(")").toString();
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/* 1805 */     else if (dbType.equalsIgnoreCase("DB2"))
/* 1806 */       strRet = strColNames.replaceAll(",", "||");
/* 1807 */     else if (dbType.equalsIgnoreCase("ORACLE")) {
/* 1808 */       strRet = strColNames.replaceAll(",", "||");
/*      */     }
/* 1810 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/* 1836 */     String strOrder = "ORDER BY comm.EDIT_DATE,comm.ABC DESC";
/* 1837 */     strOrder = strOrder.replaceAll("*.", "");
/* 1838 */     log.debug(strOrder);
/*      */   }
/*      */ 
/*      */   public int execute(String strSQL, Object[] args)
/*      */     throws Exception
/*      */   {
/* 1846 */     if (this.unicodeToGB) {
/* 1847 */       strSQL = unicodeToGB(strSQL);
/*      */     }
/* 1849 */     setSql(strSQL, args);
/* 1850 */     return preparedStatementExecute();
/*      */   }
/*      */ 
/*      */   public void setSql(String sqlStr, Object[] args) throws Exception
/*      */   {
/* 1855 */     if (this.connection == null) {
/* 1856 */       Failure("did not get a connection to the database!", 0);
/*      */     }
/* 1858 */     if ((sqlStr == null) || (sqlStr.trim().length() < 1)) {
/* 1859 */       Failure("sql preStat is empty!", 0);
/*      */     }
/* 1861 */     this.strSQL = sqlStr;
/* 1862 */     this.sqlCode = 0;
/* 1863 */     this.sqlRows = 0;
/* 1864 */     this.sqlNotice = null;
/* 1865 */     sqlStr = sqlStr.trim();
/* 1866 */     this.strSqlType = sqlStr.substring(0, 4).toUpperCase();
/* 1867 */     if (this.strSqlType.equals("SELE"))
/* 1868 */       this.strSqlType = "SELECT";
/* 1869 */     else if (this.strSqlType.equals("WITH"))
/* 1870 */       this.strSqlType = "SELECT";
/* 1871 */     else if (this.strSqlType.equals("DELE"))
/* 1872 */       this.strSqlType = "DELETE";
/* 1873 */     else if (this.strSqlType.equals("UPDA"))
/* 1874 */       this.strSqlType = "UPDATE";
/* 1875 */     else if (this.strSqlType.equals("INSE"))
/* 1876 */       this.strSqlType = "INSERT";
/*      */     else {
/* 1878 */       this.strSqlType = "UNKNOWN";
/*      */     }
/* 1880 */     close();
/* 1881 */     openCount += 1;
/* 1882 */     String strType = getDBMSType();
/* 1883 */     if (strType.equalsIgnoreCase("SQLSERVER")) {
/* 1884 */       this.connection.setAutoCommit(true);
/*      */     }
/* 1886 */     this.preStat = this.connection.prepareStatement(sqlStr);
/*      */ 
/* 1888 */     if ((args != null) && (args.length > 0))
/* 1889 */       for (int i = 0; i < args.length; i++)
/* 1890 */         this.preStat.setObject(i + 1, args[i]);
/*      */   }
/*      */ 
/*      */   protected int preparedStatementExecute()
/*      */     throws Exception
/*      */   {
/* 1896 */     this.sqlRows = 0;
/* 1897 */     if (this.preStat == null) {
/* 1898 */       this.sqlRows = -1;
/* 1899 */       Failure("there is no enforceable SQL!", 0);
/*      */     }
/*      */     try {
/* 1902 */       if (this.strSqlType.equals("SELECT"))
/* 1903 */         this.sqlResultSet = this.preStat.executeQuery();
/*      */       else
/* 1905 */         this.sqlRows = this.preStat.executeUpdate();
/*      */     }
/*      */     catch (SQLException e) {
/* 1908 */       this.sqlRows = -1;
/* 1909 */       sqlFailure(new StringBuilder().append("execute SQL:\n  ").append(this.strSQL).append(" error!").toString(), e, 0);
/*      */ 
/* 1911 */       return -1;
/*      */     }
/* 1913 */     return this.sqlRows;
/*      */   }
/*      */ 
/*      */   public void addBatch(String sql, Object[] args)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1924 */       if (this.preStat == null) {
/* 1925 */         this.preStat = this.connection.prepareStatement(sql);
/*      */       }
/*      */ 
/* 1928 */       if ((args != null) && (args.length > 0)) {
/* 1929 */         for (int i = 0; i < args.length; i++) {
/* 1930 */           this.preStat.setObject(i + 1, args[i]);
/*      */         }
/*      */       }
/* 1933 */       this.preStat.addBatch();
/*      */     } catch (Exception e) {
/* 1935 */       log.error(e.getMessage(), e);
/* 1936 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int[] preparedStatementExecuteBatch()
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1947 */       if (this.preStat == null)
/* 1948 */         return null;
/*      */     }
/*      */     catch (Exception e) {
/* 1951 */       log.error(e.getMessage(), e);
/* 1952 */       throw e;
/*      */     }
/* 1954 */     return this.preStat.executeBatch();
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-privilegeServiceExt-1.0.0.jar
 * Qualified Name:     com.asiainfo.biframe.utils.database.jdbc.Sqlca
 * JD-Core Version:    0.6.2
 */
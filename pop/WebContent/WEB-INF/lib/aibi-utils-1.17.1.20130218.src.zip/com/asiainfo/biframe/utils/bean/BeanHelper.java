/*     */ package com.asiainfo.biframe.utils.bean;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BeanHelper
/*     */ {
/*  34 */   private static Log log = LogFactory.getLog(BeanHelper.class);
/*     */ 
/*  37 */   private List<String> excludeFields = new ArrayList();
/*     */ 
/*     */   public BeanHelper()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BeanHelper(List _excludeFields)
/*     */   {
/*  51 */     this.excludeFields = _excludeFields;
/*     */ 
/*  53 */     this.excludeFields.add("class");
/*  54 */     this.excludeFields.add("parent");
/*     */   }
/*     */ 
/*     */   public Map beanToMap(Object bean)
/*     */     throws IntrospectionException
/*     */   {
/*  66 */     Map map = new HashMap();
/*  67 */     BeanInfo bi = Introspector.getBeanInfo(bean.getClass());
/*  68 */     PropertyDescriptor[] pds = bi.getPropertyDescriptors();
/*  69 */     for (int i = 0; i < pds.length; i++) {
/*  70 */       String propName = pds[i].getName();
/*     */ 
/*  72 */       if (!this.excludeFields.contains(propName))
/*     */       {
/*     */         try
/*     */         {
/*  76 */           String propValue = BeanUtils.getSimpleProperty(bean, propName);
/*  77 */           if (StringUtil.isNotEmpty(propValue))
/*  78 */             map.put(propName, propValue);
/*     */         } catch (Exception e) {
/*     */         }
/*     */       }
/*     */     }
/*  83 */     return map;
/*     */   }
/*     */ 
/*     */   public static void printMap(Map map)
/*     */   {
/*  93 */     StringBuffer sb = new StringBuffer("");
/*     */ 
/*  95 */     Iterator it = map.keySet().iterator();
/*  96 */     while (it.hasNext()) {
/*  97 */       String key = (String)it.next();
/*  98 */       String value = (String)map.get(key);
/*  99 */       sb.append("[" + key + "]=[" + value + "]");
/*     */     }
/*     */ 
/* 102 */     log.debug("---------" + sb);
/*     */   }
/*     */ 
/*     */   public List<String> getExcludeFields() {
/* 106 */     return this.excludeFields;
/*     */   }
/*     */ 
/*     */   public void setExcludeFields(List<String> excludeFields) {
/* 110 */     this.excludeFields = excludeFields;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.bean.BeanHelper
 * JD-Core Version:    0.6.2
 */
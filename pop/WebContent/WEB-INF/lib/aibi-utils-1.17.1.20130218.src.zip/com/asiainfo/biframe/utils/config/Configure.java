/*     */ package com.asiainfo.biframe.utils.config;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class Configure
/*     */ {
/*     */   public static final String URL_PATH = "URL_PATH";
/*  43 */   private static Log log = LogFactory.getLog(Configure.class);
/*     */ 
/*  45 */   private static Configure configure = new Configure();
/*     */   private static final String DEFAULT_CONFIG_TYPE = "ASIAINFO_PROPERTIES";
/*  51 */   private static Map<String, Long> modifiedTimeMap = new HashMap();
/*     */ 
/*  54 */   private static Map<String, String> fileNameMap = new HashMap();
/*     */ 
/*  57 */   private static Map<String, String> absPathMap = new HashMap();
/*     */ 
/*  60 */   private static Map<String, Properties> configMap = new HashMap();
/*     */ 
/*     */   public static Configure getInstance()
/*     */   {
/*  77 */     return configure;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setConfFileName(String fileName)
/*     */     throws Exception
/*     */   {
/*  91 */     initProperties("ASIAINFO_PROPERTIES", fileName);
/*     */   }
/*     */ 
/*     */   public void addConfFileName(String configType, String fileName)
/*     */     throws Exception
/*     */   {
/* 109 */     initProperties(configType, fileName);
/*     */   }
/*     */ 
/*     */   public String getProperty(String strKey)
/*     */   {
/*     */     try
/*     */     {
/* 123 */       return getProperty("ASIAINFO_PROPERTIES", strKey);
/*     */     } catch (Exception e) {
/* 125 */       e.printStackTrace();
/* 126 */     }return null;
/*     */   }
/*     */ 
/*     */   public String getProperty(String configType, String strKey)
/*     */     throws Exception
/*     */   {
/* 146 */     if (StringUtil.isEmpty(configType)) {
/* 147 */       throw new Exception("----Configure--err-------:configType is null");
/*     */     }
/*     */     try
/*     */     {
/* 151 */       if (configMap.get(configType) == null) {
/* 152 */         throw new Exception("----Configure--err-------:configType[" + configType + "]is not initialized");
/*     */       }
/*     */ 
/* 155 */       File fileObj = new File((String)fileNameMap.get(configType));
/*     */ 
/* 157 */       if (fileObj.lastModified() > ((Long)modifiedTimeMap.get(configType)).longValue()) {
/* 158 */         initProperties(configType, (String)fileNameMap.get(configType));
/*     */       }
/*     */ 
/* 161 */       Properties properties = (Properties)configMap.get(configType);
/* 162 */       return StringUtil.obj2Str(properties.getProperty(strKey));
/*     */     } catch (Exception excep) {
/* 164 */       excep.printStackTrace();
/* 165 */     }return "";
/*     */   }
/*     */ 
/*     */   public String getWebUrl(String key)
/*     */     throws Exception
/*     */   {
/* 177 */     return getProperty("URL_PATH", key);
/*     */   }
/*     */ 
/*     */   public Map<String, String> getWebUrlMap()
/*     */   {
/* 185 */     Map map = new HashMap();
/* 186 */     Properties props = (Properties)configMap.get("URL_PATH");
/* 187 */     Enumeration enums = props.propertyNames();
/* 188 */     String name = null;
/* 189 */     while (enums.hasMoreElements()) {
/* 190 */       name = (String)enums.nextElement();
/* 191 */       map.put(name, props.getProperty(name, ""));
/*     */     }
/* 193 */     return map;
/*     */   }
/*     */ 
/*     */   private synchronized boolean initProperties(String configType, String fileName)
/*     */     throws Exception
/*     */   {
/* 211 */     if (StringUtil.isEmpty(configType)) {
/* 212 */       throw new Exception("----Configure--err-------:configType is null");
/*     */     }
/* 214 */     if (StringUtil.isEmpty(fileName)) {
/* 215 */       throw new Exception("----Configure--err-------:fileName is null");
/*     */     }
/* 217 */     Properties props = new Properties();
/* 218 */     File fileObj = new File(fileName);
/* 219 */     String absPathStr = fileObj.getAbsolutePath();
/* 220 */     log.debug("fileName:" + fileName + "\r\n Absolute Path:" + absPathStr);
/* 221 */     if (!fileObj.exists()) {
/* 222 */       throw new Exception("parameter file not found:" + fileName + "\r\nAbsolute Path:" + absPathStr);
/*     */     }
/*     */ 
/* 225 */     FileInputStream fis = new FileInputStream(fileName);
/* 226 */     props.load(fis);
/* 227 */     fis.close();
/*     */ 
/* 229 */     modifiedTimeMap.put(configType, Long.valueOf(fileObj.lastModified()));
/* 230 */     fileNameMap.put(configType, fileName);
/* 231 */     absPathMap.put(configType, absPathStr);
/* 232 */     configMap.put(configType, props);
/* 233 */     return true;
/*     */   }
/*     */ 
/*     */   public String getAbsPath()
/*     */   {
/* 243 */     return getAbsPath("ASIAINFO_PROPERTIES");
/*     */   }
/*     */ 
/*     */   public String getAbsPath(String configType)
/*     */   {
/* 253 */     return (String)absPathMap.get(configType);
/*     */   }
/*     */ 
/*     */   public Properties getPropFile(String configType) {
/* 257 */     Properties properties = (Properties)configMap.get(configType);
/* 258 */     return properties;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.config.Configure
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.database.jdbc;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Hashtable;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.sql.DataSource;
/*     */ 
/*     */ public class AiomniConnectionFactory
/*     */ {
/*  27 */   private static Hashtable dss = new Hashtable();
/*     */   private DataSource ds;
/*     */ 
/*     */   public static AiomniConnectionFactory getInstance()
/*     */   {
/*  38 */     String mysql_jndiname = Configure.getInstance().getProperty("JDBC_AIOMNI");
/*  39 */     if (mysql_jndiname.indexOf("java:comp/env/") >= 0) {
/*  40 */       mysql_jndiname = mysql_jndiname.substring(new String("java:comp/env/").length());
/*     */     }
/*  42 */     return getInstance(mysql_jndiname);
/*     */   }
/*     */ 
/*     */   public static AiomniConnectionFactory getInstance(String jndi)
/*     */   {
/*  54 */     if (!dss.containsKey(jndi)) {
/*  55 */       addDataSource(jndi);
/*     */     }
/*  57 */     return (AiomniConnectionFactory)dss.get(jndi);
/*     */   }
/*     */ 
/*     */   public AiomniConnectionFactory(DataSource ds)
/*     */   {
/*  65 */     this.ds = ds;
/*     */   }
/*     */ 
/*     */   private static void addDataSource(String jndi)
/*     */   {
/*     */     try
/*     */     {
/*  77 */       Context ctx = new InitialContext();
/*     */ 
/*  81 */       String app_server_type = Configure.getInstance().getProperty("APP_SERVER_TYPE");
/*  82 */       Context envContext = null;
/*  83 */       if ((app_server_type != null) && (("weblogic".equalsIgnoreCase(app_server_type)) || ("websphere".equalsIgnoreCase(app_server_type))))
/*  84 */         envContext = ctx;
/*     */       else {
/*  86 */         envContext = (Context)ctx.lookup("java:comp/env");
/*     */       }
/*     */ 
/*  89 */       if (envContext == null) {
/*  90 */         throw new Exception("Boom - No Context");
/*     */       }
/*  92 */       if (jndi != null) {
/*  93 */         String strDbJndi = jndi;
/*  94 */         if (strDbJndi.startsWith("java:comp/env/"))
/*  95 */           strDbJndi = strDbJndi.substring(14);
/*  96 */         DataSource ds = (DataSource)envContext.lookup(strDbJndi);
/*  97 */         if (ds != null)
/*  98 */           dss.put(jndi, new AiomniConnectionFactory(ds));
/*     */         else
/* 100 */           throw new Exception("can't find new datasource!");
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 104 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */   {
/*     */     try
/*     */     {
/* 117 */       if (this.ds != null) {
/* 118 */         Connection conn = this.ds.getConnection();
/* 119 */         if (conn != null)
/* 120 */           return conn;
/*     */       }
/*     */     }
/*     */     catch (SQLException ex) {
/* 124 */       ex.printStackTrace();
/*     */     }
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */   public void destory()
/*     */   {
/* 133 */     dss.clear();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.database.jdbc.AiomniConnectionFactory
 * JD-Core Version:    0.6.2
 */
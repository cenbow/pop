/*     */ package com.asiainfo.biframe.utils.database.jdbc;
/*     */ 
/*     */ import COM.ibm.db2.jdbc.app.DB2Driver;
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.mysql.jdbc.Driver;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URL;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import oracle.jdbc.driver.OracleDriver;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import sun.jdbc.odbc.JdbcOdbcDriver;
/*     */ 
/*     */ public class ConnectionEx
/*     */ {
/*  35 */   private static Log log = LogFactory.getLog(ConnectionEx.class);
/*     */   public static final String DBMS_ORACLE = "ORACLE";
/*     */   public static final String DBMS_ODBC = "ODBC";
/*     */   public static final String DBMS_ACESS = "ACESS";
/*     */   public static final String DBMS_MYSQL = "MYSQL";
/*     */   public static final String DBMS_DB2 = "DB2";
/*     */   public static final String DBMS_SQLSERVER = "SQLSERVER";
/*     */   public static final String DBMS_TERA = "TERA";
/*     */   public static final String DBMS_SYBASE = "SYBASE";
/*  47 */   protected Connection m_Connection = null;
/*     */ 
/*  51 */   private String strConnectURL = "jdbc:odbc:BrioAccess";
/*  52 */   private String strDriver = "com.mysql.jdbc.Driver";
/*  53 */   private String strDBMSType = "odbc";
/*  54 */   private String strUser = "";
/*  55 */   private String strPassword = "";
/*  56 */   protected static Hashtable hashPool = new Hashtable();
/*  57 */   protected boolean bInitFromPool = true;
/*     */ 
/*     */   public Connection getConnection()
/*     */   {
/*  65 */     return this.m_Connection;
/*     */   }
/*     */ 
/*     */   public static ConnectionEx getConnection(String jndiName)
/*     */     throws Exception
/*     */   {
/*  77 */     return new ConnectionEx(jndiName);
/*     */   }
/*     */ 
/*     */   public ConnectionEx(String strDBType, String user, String strPwd, String strUrl, boolean bPool)
/*     */     throws Exception
/*     */   {
/*  94 */     this.bInitFromPool = bPool;
/*  95 */     this.strConnectURL = strUrl;
/*  96 */     this.strDBMSType = strDBType;
/*  97 */     this.strUser = user;
/*  98 */     this.strPassword = strPwd;
/*  99 */     connect();
/*     */   }
/*     */ 
/*     */   public ConnectionEx(ConnectionEx connectEx)
/*     */   {
/* 107 */     this.m_Connection = connectEx.m_Connection;
/*     */   }
/*     */ 
/*     */   public ConnectionEx(Connection connect)
/*     */   {
/* 115 */     this.m_Connection = connect;
/*     */   }
/*     */ 
/*     */   public ConnectionEx()
/*     */     throws Exception
/*     */   {
/* 123 */     Connection conn = null;
/*     */     try {
/* 125 */       conn = AiomniConnectionFactory.getInstance().getConnection();
/*     */     }
/*     */     catch (Exception e) {
/* 128 */       e.printStackTrace();
/*     */     }
/* 130 */     synchronized (this) {
/* 131 */       this.m_Connection = conn;
/*     */     }
/*     */   }
/*     */ 
/*     */   public ConnectionEx(String strJDBC_NAME)
/*     */     throws Exception
/*     */   {
/* 141 */     String strDataSourceName = Configure.getInstance().getProperty(strJDBC_NAME);
/* 142 */     if ((strDataSourceName == null) || (strDataSourceName.length() < 1))
/*     */     {
/* 144 */       throw new Exception("JDBC Connection Configuration: '" + strJDBC_NAME + " ' does not exist, or configuration errors");
/*     */     }
/* 146 */     Connection conn = null;
/*     */     try
/*     */     {
/* 149 */       conn = AiomniConnectionFactory.getInstance(strDataSourceName).getConnection();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 153 */       e.printStackTrace();
/*     */     }
/* 155 */     synchronized (this)
/*     */     {
/* 157 */       this.m_Connection = conn;
/*     */     }
/*     */   }
/*     */ 
/*     */   public ConnectionEx(String moduleName, String path, String strJDBC_NAME)
/*     */     throws Exception
/*     */   {
/* 169 */     Configure.getInstance().addConfFileName(moduleName, Thread.currentThread().getContextClassLoader().getResource(path).getFile());
/* 170 */     String strDataSourceName = Configure.getInstance().getProperty(moduleName, strJDBC_NAME);
/* 171 */     if ((strDataSourceName == null) || (strDataSourceName.length() < 1))
/*     */     {
/* 173 */       throw new Exception("JDBC Connection Configuration: '" + strJDBC_NAME + " ' does not exist, or configuration errors");
/*     */     }
/* 175 */     Connection conn = null;
/*     */     try
/*     */     {
/* 178 */       conn = AiomniConnectionFactory.getInstance(strDataSourceName).getConnection();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 182 */       e.printStackTrace();
/*     */     }
/* 184 */     synchronized (this)
/*     */     {
/* 186 */       this.m_Connection = conn;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static ConnectionEx getReportServerConnection()
/*     */     throws Exception
/*     */   {
/* 198 */     String strType = Configure.getInstance().getProperty("REPORT_DBTYPE");
/* 199 */     String strUrl = Configure.getInstance().getProperty("REPORT_URL");
/* 200 */     String strUser = Configure.getInstance().getProperty("REPORT_USERNAME");
/* 201 */     String strPwd = Configure.getInstance().getProperty("REPORT_PASSWORD");
/* 202 */     if ((null == strType) || (strType.trim().length() < 1))
/*     */     {
/* 205 */       throw new Exception("--------err not found the database configuration parameter:[REPORT_DBTYPE]");
/*     */     }
/*     */ 
/* 209 */     return new ConnectionEx(strType, strUser, strPwd, strUrl, true);
/*     */   }
/*     */ 
/*     */   protected int connect()
/*     */   {
/* 219 */     if (this.bInitFromPool)
/*     */     {
/* 221 */       String strKey = this.strDBMSType + this.strConnectURL + this.strUser + this.strPassword;
/* 222 */       strKey = strKey.toUpperCase();
/* 223 */       DbConnectionBroker myBroker = null;
/* 224 */       synchronized (this)
/*     */       {
/* 226 */         myBroker = (DbConnectionBroker)hashPool.get(strKey);
/*     */       }
/* 228 */       if (null == myBroker)
/*     */       {
/*     */         try
/*     */         {
/* 232 */           if (this.strDBMSType.equalsIgnoreCase("ORACLE"))
/*     */           {
/* 234 */             this.strDriver = "oracle.jdbc.driver.OracleDriver";
/*     */           }
/* 236 */           else if (this.strDBMSType.equalsIgnoreCase("ODBC"))
/*     */           {
/* 238 */             this.strDriver = "sun.jdbc.odbc.JdbcOdbcDriver";
/*     */           }
/* 240 */           else if (this.strDBMSType.equalsIgnoreCase("DB2"))
/*     */           {
/* 242 */             this.strDriver = "COM.ibm.db2.jdbc.app.DB2Driver";
/*     */           }
/* 244 */           else if (this.strDBMSType.equalsIgnoreCase("MYSQL"))
/*     */           {
/* 246 */             this.strDriver = "com.mysql.jdbc.Driver";
/*     */           }
/* 248 */           else if (this.strDBMSType.equalsIgnoreCase("SYBASE"))
/*     */           {
/* 250 */             this.strDriver = "com.sybase.jdbc2.jdbc.SybDriver";
/*     */           }
/*     */ 
/* 253 */           log.debug("Connecting to database : " + this.strConnectURL + "[" + this.strDBMSType + "]" + this.strDriver);
/*     */ 
/* 255 */           myBroker = new DbConnectionBroker(this.strDriver, this.strConnectURL, this.strUser, this.strPassword, 3, 10, 1.0D);
/*     */ 
/* 258 */           hashPool.put(strKey, myBroker);
/*     */         }
/*     */         catch (Exception excep)
/*     */         {
/* 262 */           excep.printStackTrace();
/* 263 */           hashPool.remove(strKey);
/* 264 */           return 1;
/*     */         }
/*     */       }
/* 267 */       this.m_Connection = myBroker.getConnection();
/* 268 */       return 0;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 274 */       if (this.strDBMSType.equalsIgnoreCase("MYSQL"))
/*     */       {
/* 276 */         return connectMySQL();
/*     */       }
/* 278 */       if (this.strDBMSType.equalsIgnoreCase("ODBC"))
/*     */       {
/* 280 */         return connectODBC();
/*     */       }
/* 282 */       if (this.strDBMSType.equalsIgnoreCase("ORACLE"))
/*     */       {
/* 284 */         return connectOracle();
/*     */       }
/* 286 */       if (this.strDBMSType.equalsIgnoreCase("DB2"))
/*     */       {
/* 288 */         return connectDB2();
/*     */       }
/*     */ 
/* 293 */       return -1;
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/* 298 */       excep.printStackTrace();
/* 299 */       this.m_Connection = null;
/* 300 */     }return -1;
/*     */   }
/*     */ 
/*     */   public void commit()
/*     */     throws Exception
/*     */   {
/* 312 */     if (null != this.m_Connection)
/*     */     {
/* 314 */       this.m_Connection.commit();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected int connectMySQL()
/*     */     throws Exception
/*     */   {
/* 327 */     if (!this.strDBMSType.equalsIgnoreCase("MYSQL"))
/*     */     {
/* 329 */       return -1;
/*     */     }
/* 331 */     Properties info = new Properties();
/* 332 */     info.put("USER", this.strUser);
/* 333 */     info.put("PASSWORD", this.strPassword);
/* 334 */     InetAddress ina = InetAddress.getLocalHost();
/* 335 */     String hostname = ina.getHostName();
/* 336 */     info.put("HOSTNAME", hostname);
/* 337 */     info.put("APPLICATIONNAME", "kpi");
/*     */ 
/* 339 */     this.strDriver = "com.mysql.jdbc.Driver";
/* 340 */     Driver mydriver = (Driver)Class.forName(this.strDriver).newInstance();
/* 341 */     DriverManager.registerDriver(mydriver);
/* 342 */     this.m_Connection = DriverManager.getConnection(this.strConnectURL, info);
/*     */ 
/* 344 */     return 0;
/*     */   }
/*     */ 
/*     */   protected int connectDB2()
/*     */     throws Exception
/*     */   {
/* 355 */     this.strDriver = "COM.ibm.db2.jdbc.app.DB2Driver";
/* 356 */     DB2Driver mydriver = (DB2Driver)Class.forName(this.strDriver).newInstance();
/* 357 */     DriverManager.registerDriver(mydriver);
/* 358 */     this.m_Connection = DriverManager.getConnection(this.strConnectURL, this.strUser, this.strPassword);
/*     */ 
/* 360 */     return 0;
/*     */   }
/*     */ 
/*     */   protected int connectAccess()
/*     */     throws Exception
/*     */   {
/* 371 */     throw new Exception("drive type not supported ");
/*     */   }
/*     */ 
/*     */   protected int connectOracle()
/*     */     throws Exception
/*     */   {
/* 382 */     this.strDriver = "oracle.jdbc.driver.OracleDriver";
/* 383 */     OracleDriver mydriver = (OracleDriver)Class.forName(this.strDriver).newInstance();
/* 384 */     DriverManager.registerDriver(mydriver);
/* 385 */     this.m_Connection = DriverManager.getConnection(this.strConnectURL, this.strUser, this.strPassword);
/*     */ 
/* 387 */     return 0;
/*     */   }
/*     */ 
/*     */   protected int connectODBC()
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 400 */       this.strDriver = "sun.jdbc.odbc.JdbcOdbcDriver";
/* 401 */       JdbcOdbcDriver mydriver = (JdbcOdbcDriver)Class.forName(this.strDriver).newInstance();
/*     */ 
/* 403 */       DriverManager.registerDriver(mydriver);
/*     */ 
/* 405 */       this.m_Connection = DriverManager.getConnection(this.strConnectURL, this.strUser, this.strPassword);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 412 */       ex.printStackTrace();
/* 413 */       throw ex;
/*     */     }
/* 415 */     return 0;
/*     */   }
/*     */ 
/*     */   public void rollback()
/*     */     throws Exception
/*     */   {
/* 424 */     if (null != this.m_Connection)
/*     */     {
/* 426 */       this.m_Connection.rollback();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*     */     try
/*     */     {
/* 437 */       if (null != this.m_Connection) {
/* 438 */         this.m_Connection.close();
/* 439 */         this.m_Connection = null;
/*     */       }
/*     */     } catch (Exception e) {
/* 442 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isClosed()
/*     */     throws Exception
/*     */   {
/* 452 */     if (null == this.m_Connection) {
/* 453 */       return true;
/*     */     }
/*     */ 
/* 456 */     return this.m_Connection.isClosed();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.database.jdbc.ConnectionEx
 * JD-Core Version:    0.6.2
 */
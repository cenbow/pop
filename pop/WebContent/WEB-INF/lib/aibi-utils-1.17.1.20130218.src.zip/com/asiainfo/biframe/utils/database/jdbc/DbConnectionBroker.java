/*     */ package com.asiainfo.biframe.utils.database.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DbConnectionBroker
/*     */   implements Runnable
/*     */ {
/*  28 */   private static Log log = LogFactory.getLog(DbConnectionBroker.class);
/*     */   private Thread runner;
/*     */   private Connection[] m_aryConnectionPool;
/*     */   private int[] m_aryConnectionStatus;
/*     */   private long[] m_aryLockTime;
/*     */   private long[] m_aryCreateDate;
/*     */   private String[] m_aryConnectionID;
/*     */   private String m_strDriver;
/*     */   private String m_strUrl;
/*     */   private String m_strUser;
/*     */   private String m_strPassword;
/*     */   private int m_nCurrConnections;
/*     */   private int m_nConnLast;
/*     */   private int m_nMinConns;
/*     */   private int m_nMaxConns;
/*     */   private int m_nMaxConnMSec;
/*  39 */   private SQLWarning currSQLWarning = null;
/*  40 */   private final int DEFAULTMAXCHECKOUTSECONDS = 60;
/*     */ 
/*     */   public DbConnectionBroker(String dbDriver, String strUrl, String strUser, String strPwd, int minConns, int maxConns, double maxConnTime)
/*     */     throws Exception
/*     */   {
/*  46 */     this.m_aryConnectionPool = new Connection[maxConns];
/*  47 */     this.m_aryConnectionStatus = new int[maxConns];
/*  48 */     this.m_aryLockTime = new long[maxConns];
/*  49 */     this.m_aryCreateDate = new long[maxConns];
/*  50 */     this.m_aryConnectionID = new String[maxConns];
/*  51 */     this.m_nCurrConnections = minConns;
/*  52 */     this.m_nMaxConns = maxConns;
/*  53 */     this.m_strDriver = dbDriver;
/*  54 */     this.m_strUrl = strUrl;
/*  55 */     this.m_strUser = strUser;
/*  56 */     this.m_strPassword = strPwd;
/*  57 */     this.m_nMaxConnMSec = ((int)(maxConnTime * 86400000.0D));
/*  58 */     if (this.m_nMaxConnMSec < 30000)
/*     */     {
/*  60 */       this.m_nMaxConnMSec = 30000;
/*     */     }
/*  62 */     for (int n = 0; n < this.m_aryConnectionPool.length; n++)
/*     */     {
/*  64 */       this.m_aryConnectionPool[n] = null;
/*     */     }
/*     */ 
/*  67 */     boolean bPoolinitOK = false;
/*  68 */     int initTimes = 20;
/*     */     try
/*     */     {
/*  71 */       for (int i = 1; (!bPoolinitOK) && (i < initTimes); i++)
/*     */       {
/*     */         try
/*     */         {
/*  75 */           for (int j = 0; j < this.m_nCurrConnections; j++)
/*     */           {
/*  77 */             if (null == this.m_aryConnectionPool[j])
/*  78 */               createConn(j);
/*     */           }
/*  80 */           bPoolinitOK = true;
/*     */         }
/*     */         catch (SQLException e)
/*     */         {
/*  85 */           log.error("", e);
/*     */           try
/*     */           {
/*  88 */             Thread.sleep(1000L);
/*     */           }
/*     */           catch (InterruptedException e1)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/*  95 */       if (!bPoolinitOK)
/*     */       {
/*  97 */         throw new Exception("initialize the database connection pool error ");
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 102 */       throw e;
/*     */     }
/*     */ 
/* 105 */     this.runner = new Thread(this);
/* 106 */     this.runner.start();
/*     */   }
/*     */ 
/*     */   private void createConn(int i)
/*     */     throws Exception
/*     */   {
/* 117 */     Driver mydriver = (Driver)Class.forName(this.m_strDriver).newInstance();
/* 118 */     DriverManager.registerDriver(mydriver);
/* 119 */     this.m_aryConnectionPool[i] = DriverManager.getConnection(this.m_strUrl, this.m_strUser, this.m_strPassword);
/* 120 */     this.m_aryConnectionStatus[i] = 0;
/* 121 */     this.m_aryConnectionID[i] = this.m_aryConnectionPool[i].toString();
/* 122 */     this.m_aryLockTime[i] = 0L;
/* 123 */     this.m_aryCreateDate[i] = new Date().getTime();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 128 */     boolean forever = true;
/* 129 */     Statement stmt = null;
/* 130 */     String currCatalog = null;
/* 131 */     long maxCheckoutMillis = 60000L;
/* 132 */     while (forever)
/*     */     {
/*     */       try
/*     */       {
/* 136 */         Thread.sleep(20000L);
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/*     */       }
/* 141 */       for (int i = 0; i < this.m_nCurrConnections; i++)
/*     */       {
/* 143 */         long age = System.currentTimeMillis() - this.m_aryCreateDate[i];
/*     */         try
/*     */         {
/* 146 */           synchronized (this.m_aryConnectionStatus)
/*     */           {
/* 148 */             if (this.m_aryConnectionStatus[i] > 0)
/*     */             {
/* 150 */               long timeInUse = System.currentTimeMillis() - this.m_aryLockTime[i];
/* 151 */               if (maxCheckoutMillis != 0L)
/*     */               {
/* 153 */                 if (timeInUse > maxCheckoutMillis)
/*     */                 {
/* 155 */                   throw new SQLException();
/*     */                 }
/*     */ 
/*     */               }
/*     */ 
/*     */               try
/*     */               {
/* 198 */                 if (stmt != null)
/*     */                 {
/* 200 */                   stmt.close();
/*     */                 }
/*     */               }
/*     */               catch (SQLException e1)
/*     */               {
/*     */               }
/*     */             }
/* 160 */             this.m_aryConnectionStatus[i] = 2;
/*     */           }
/* 162 */           if (age > this.m_nMaxConnMSec)
/*     */           {
/* 164 */             throw new SQLException();
/*     */           }
/*     */ 
/* 167 */           stmt = this.m_aryConnectionPool[i].createStatement();
/* 168 */           this.m_aryConnectionStatus[i] = 0;
/* 169 */           if (this.m_aryConnectionPool[i].isClosed())
/*     */           {
/* 171 */             throw new SQLException();
/*     */           }
/*     */         }
/*     */         catch (SQLException e)
/*     */         {
/* 176 */           log.error("", e);
/*     */           try
/*     */           {
/* 180 */             this.m_aryConnectionPool[i].close();
/*     */           }
/*     */           catch (SQLException e0)
/*     */           {
/*     */           }
/*     */           try
/*     */           {
/* 187 */             createConn(i);
/*     */           }
/*     */           catch (Exception e1)
/*     */           {
/* 191 */             this.m_aryConnectionStatus[i] = 0;
/*     */           }
/*     */         }
/*     */         finally
/*     */         {
/*     */           try
/*     */           {
/* 198 */             if (stmt != null)
/*     */             {
/* 200 */               stmt.close();
/*     */             }
/*     */           }
/*     */           catch (SQLException e1)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */   {
/* 226 */     Connection retConnection = null;
/* 227 */     int nCurrentID = -1;
/* 228 */     for (int outerloop = 1; outerloop <= 10; outerloop++)
/*     */     {
/*     */       try
/*     */       {
/* 232 */         int loop = 0;
/* 233 */         int roundRobin = this.m_nConnLast + 1;
/* 234 */         if (roundRobin >= this.m_nCurrConnections)
/*     */         {
/* 236 */           roundRobin = 0;
/*     */         }
/*     */         do
/*     */         {
/* 240 */           synchronized (this.m_aryConnectionStatus)
/*     */           {
/* 242 */             if ((this.m_aryConnectionStatus[roundRobin] < 1) && (!this.m_aryConnectionPool[roundRobin].isClosed()))
/*     */             {
/* 245 */               retConnection = this.m_aryConnectionPool[roundRobin];
/* 246 */               this.m_aryConnectionStatus[roundRobin] = 1;
/* 247 */               this.m_aryLockTime[roundRobin] = System.currentTimeMillis();
/* 248 */               this.m_nConnLast = roundRobin;
/* 249 */               nCurrentID = roundRobin;
/* 250 */               break;
/*     */             }
/*     */ 
/* 254 */             loop++;
/* 255 */             roundRobin++;
/* 256 */             if (roundRobin >= this.m_nCurrConnections)
/*     */             {
/* 258 */               roundRobin = 0;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 263 */           if (nCurrentID >= 0) break;  } while (loop < this.m_nCurrConnections);
/*     */       }
/*     */       catch (SQLException e1)
/*     */       {
/* 267 */         log.error("", e1);
/*     */       }
/* 269 */       if (nCurrentID >= 0)
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 276 */       synchronized (this)
/*     */       {
/* 278 */         if (this.m_nCurrConnections < this.m_nMaxConns)
/*     */         {
/*     */           try
/*     */           {
/* 282 */             createConn(this.m_nCurrConnections);
/* 283 */             this.m_nCurrConnections += 1;
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 292 */         Thread.sleep(1000L);
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/* 299 */     return retConnection;
/*     */   }
/*     */ 
/*     */   public int idOfConnection(Connection conn)
/*     */   {
/*     */     String tag;
/*     */     try
/*     */     {
/* 312 */       tag = conn.toString();
/*     */     }
/*     */     catch (NullPointerException e1)
/*     */     {
/* 316 */       tag = "none";
/*     */     }
/* 318 */     int match = -1;
/* 319 */     for (int i = 0; i < this.m_nCurrConnections; i++)
/*     */     {
/* 321 */       if (this.m_aryConnectionID[i].equals(tag))
/*     */       {
/* 323 */         match = i;
/* 324 */         break;
/*     */       }
/*     */     }
/* 327 */     return match;
/*     */   }
/*     */ 
/*     */   public boolean freeConnection(Connection conn)
/*     */   {
/* 336 */     int thisconn = idOfConnection(conn);
/* 337 */     if (thisconn >= 0)
/*     */     {
/* 339 */       this.m_aryConnectionStatus[thisconn] = 0;
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 347 */         conn.close();
/*     */       }
/*     */       catch (Exception excep)
/*     */       {
/*     */       }
/*     */     }
/* 353 */     return thisconn >= 0;
/*     */   }
/*     */ 
/*     */   public void destroy(int millis)
/*     */     throws SQLException
/*     */   {
/* 397 */     this.runner.interrupt();
/*     */     try
/*     */     {
/* 401 */       this.runner.join(millis);
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/*     */     }
/*     */ 
/* 412 */     long startTime = System.currentTimeMillis();
/*     */     int useCount;
/* 418 */     while (((useCount = getUseCount()) > 0) && (System.currentTimeMillis() - startTime <= millis))
/*     */     {
/*     */       try
/*     */       {
/* 422 */         Thread.sleep(500L);
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/* 429 */     for (int i = 0; i < this.m_nCurrConnections; i++)
/*     */     {
/*     */       try
/*     */       {
/* 433 */         this.m_aryConnectionPool[i].close();
/*     */       }
/*     */       catch (Exception e1)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */     try
/*     */     {
/* 453 */       destroy(10000);
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getUseCount() {
/* 461 */     int useCount = 0;
/* 462 */     synchronized (this.m_aryConnectionStatus)
/*     */     {
/* 464 */       for (int i = 0; i < this.m_nCurrConnections; i++)
/*     */       {
/* 466 */         if (this.m_aryConnectionStatus[i] > 0)
/*     */         {
/* 468 */           useCount++;
/*     */         }
/*     */       }
/*     */     }
/* 472 */     return useCount;
/*     */   }
/*     */ 
/*     */   public void finalize() {
/* 476 */     for (int i = 0; (null != this.m_aryConnectionPool) && (i < this.m_aryConnectionPool.length); i++)
/*     */     {
/* 478 */       Connection connect = this.m_aryConnectionPool[i];
/*     */       try
/*     */       {
/* 481 */         connect.close();
/*     */       }
/*     */       catch (Exception excep)
/*     */       {
/*     */       }
/* 486 */       this.m_aryConnectionPool[i] = null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.database.jdbc.DbConnectionBroker
 * JD-Core Version:    0.6.2
 */
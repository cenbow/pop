/*      */ package com.asiainfo.biframe.utils.database.jdbc;
/*      */ 
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.string.DES;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.PrintStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Vector;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class Sqlca
/*      */ {
/*   36 */   private static Log log = LogFactory.getLog(Sqlca.class);
/*      */ 
/*   38 */   protected final String NULL_STRING = "";
/*      */ 
/*   40 */   protected boolean unicodeToGB = true;
/*   41 */   protected boolean gbToUnicode = true;
/*      */ 
/*   43 */   protected int sqlCode = 0;
/*   44 */   protected String sqlNotice = null;
/*   45 */   protected int sqlRows = -1;
/*   46 */   protected Connection connection = null;
/*   47 */   protected ConnectionEx connectionEx = null;
/*   48 */   protected ResultSet sqlResultSet = null;
/*   49 */   protected boolean sqlAutoCommit = false;
/*   50 */   protected boolean sqlAutoRollback = false;
/*   51 */   protected String strSqlType = "UNKNOWN";
/*   52 */   protected String strSQL = null;
/*   53 */   protected boolean lastNullFlag = false;
/*   54 */   protected Statement statement = null;
/*   55 */   protected String strDBMS = null;
/*   56 */   private static int openCount = 0;
/*   57 */   protected Statement batchStatement = null;
/*      */ 
/*  443 */   static int g_nCount = 0;
/*      */ 
/*      */   protected Sqlca()
/*      */   {
/*   69 */     this.sqlCode = 0;
/*   70 */     this.sqlResultSet = null;
/*   71 */     this.sqlNotice = null;
/*   72 */     this.sqlAutoRollback = false;
/*   73 */     this.sqlAutoCommit = true;
/*   74 */     this.sqlRows = 0;
/*      */   }
/*      */ 
/*      */   public Sqlca(Connection newConnection)
/*      */     throws Exception
/*      */   {
/*   84 */     this();
/*   85 */     this.connection = newConnection;
/*      */     try {
/*   87 */       if (this.connection != null) {
/*   88 */         setAutoCommit(this.sqlAutoCommit);
/*      */       }
/*      */ 
/*   91 */       if ((this.connection != null) && (this.connection.getTransactionIsolation() < 1))
/*   92 */         this.connection.setTransactionIsolation(2);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*   96 */       throw e;
/*      */     }
/*   98 */     this.gbToUnicode = Boolean.valueOf(Configure.getInstance().getProperty("KPI_DB_CHARSET")).booleanValue();
/*      */ 
/*  101 */     this.unicodeToGB = Boolean.valueOf(Configure.getInstance().getProperty("KPI_DB_CHARSET")).booleanValue();
/*      */   }
/*      */ 
/*      */   public Sqlca(ConnectionEx conn)
/*      */     throws Exception
/*      */   {
/*  113 */     this();
/*  114 */     this.connection = conn.getConnection();
/*  115 */     this.connectionEx = conn;
/*      */     try
/*      */     {
/*  118 */       if (this.connection != null) {
/*  119 */         setAutoCommit(this.sqlAutoCommit);
/*      */       }
/*      */ 
/*  127 */       if (this.connection != null)
/*  128 */         this.connection.setTransactionIsolation(2);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  132 */       throw e;
/*      */     }
/*  134 */     this.gbToUnicode = Boolean.valueOf(Configure.getInstance().getProperty("KPI_DB_CHARSET")).booleanValue();
/*      */ 
/*  137 */     this.unicodeToGB = Boolean.valueOf(Configure.getInstance().getProperty("KPI_DB_CHARSET")).booleanValue();
/*      */   }
/*      */ 
/*      */   public Sqlca(ConnectionEx conn, boolean bGBToUnicode, boolean bUnicodeToGB)
/*      */     throws Exception
/*      */   {
/*  159 */     this();
/*  160 */     this.connection = conn.getConnection();
/*  161 */     this.connectionEx = conn;
/*      */     try
/*      */     {
/*  164 */       if (this.connection != null) {
/*  165 */         setAutoCommit(this.sqlAutoCommit);
/*      */       }
/*      */ 
/*  168 */       if (this.connection != null)
/*  169 */         this.connection.setTransactionIsolation(2);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  173 */       throw e;
/*      */     }
/*  175 */     this.gbToUnicode = bGBToUnicode;
/*  176 */     this.unicodeToGB = bUnicodeToGB;
/*      */   }
/*      */ 
/*      */   public void setAutoCommit(boolean bAuto)
/*      */     throws Exception
/*      */   {
/*  191 */     this.sqlAutoCommit = bAuto;
/*  192 */     if (this.connection == null)
/*  193 */       Failure("did not get a connection to the database", 0);
/*      */     try
/*      */     {
/*  196 */       this.connection.setAutoCommit(this.sqlAutoCommit);
/*      */     } catch (SQLException e) {
/*  198 */       sqlFailure("automatic commit of property failed!", e, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setAutoRollback(boolean autoRollbackWhensqlFailure)
/*      */     throws Exception
/*      */   {
/*  216 */     this.sqlAutoRollback = autoRollbackWhensqlFailure;
/*      */   }
/*      */ 
/*      */   public void setConnection(Connection newConnection)
/*      */     throws Exception
/*      */   {
/*  228 */     this.connection = newConnection;
/*      */   }
/*      */ 
/*      */   public void setUnicodeToGB(boolean bFlag)
/*      */   {
/*  239 */     this.unicodeToGB = bFlag;
/*      */   }
/*      */ 
/*      */   public void setGBToUnicode(boolean bFlag)
/*      */   {
/*  250 */     this.gbToUnicode = bFlag;
/*      */   }
/*      */ 
/*      */   public Connection getConnection()
/*      */   {
/*  260 */     return this.connection;
/*      */   }
/*      */ 
/*      */   public void setSql(String sqlStr)
/*      */     throws Exception
/*      */   {
/*  272 */     if (this.connection == null) {
/*  273 */       Failure("did not get a connection to the database!", 0);
/*      */     }
/*      */ 
/*  276 */     if ((sqlStr == null) || (sqlStr.trim().length() < 1)) {
/*  277 */       Failure("sql statement is empty!", 0);
/*      */     }
/*      */ 
/*  280 */     this.strSQL = sqlStr;
/*  281 */     this.sqlCode = 0;
/*  282 */     this.sqlRows = 0;
/*  283 */     this.sqlNotice = null;
/*      */ 
/*  285 */     sqlStr = sqlStr.trim();
/*  286 */     this.strSqlType = sqlStr.substring(0, 4).toUpperCase();
/*  287 */     if (this.strSqlType.equals("SELE"))
/*  288 */       this.strSqlType = "SELECT";
/*  289 */     else if (this.strSqlType.equals("WITH"))
/*  290 */       this.strSqlType = "SELECT";
/*  291 */     else if (this.strSqlType.equals("DELE"))
/*  292 */       this.strSqlType = "DELETE";
/*  293 */     else if (this.strSqlType.equals("UPDA"))
/*  294 */       this.strSqlType = "UPDATE";
/*  295 */     else if (this.strSqlType.equals("INSE"))
/*  296 */       this.strSqlType = "INSERT";
/*      */     else {
/*  298 */       this.strSqlType = "UNKNOWN";
/*      */     }
/*      */ 
/*  301 */     close();
/*  302 */     openCount += 1;
/*      */ 
/*  304 */     String strType = getDBMSType();
/*  305 */     if (strType.equalsIgnoreCase("SQLSERVER"))
/*  306 */       this.connection.setAutoCommit(true);
/*  307 */     this.statement = this.connection.createStatement();
/*      */   }
/*      */ 
/*      */   protected int execute()
/*      */     throws Exception
/*      */   {
/*  338 */     this.sqlRows = 0;
/*  339 */     if (this.statement == null) {
/*  340 */       this.sqlRows = -1;
/*  341 */       Failure("there is no enforceable SQL!", 0);
/*      */     }
/*      */     try {
/*  344 */       if (this.strSqlType.equals("SELECT"))
/*  345 */         this.sqlResultSet = this.statement.executeQuery(this.strSQL);
/*      */       else
/*  347 */         this.sqlRows = this.statement.executeUpdate(this.strSQL);
/*      */     }
/*      */     catch (SQLException e) {
/*  350 */       this.sqlRows = -1;
/*  351 */       sqlFailure("execute SQL:\n  " + this.strSQL + " error!", e, 0);
/*  352 */       return -1;
/*      */     }
/*  354 */     return this.sqlRows;
/*      */   }
/*      */ 
/*      */   public int execute(String strSQL)
/*      */     throws Exception
/*      */   {
/*  366 */     if (this.unicodeToGB == true) {
/*  367 */       strSQL = unicodeToGB(strSQL);
/*      */     }
/*  369 */     setSql(strSQL);
/*  370 */     return execute();
/*      */   }
/*      */ 
/*      */   public void addBatch(String sql)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/*  381 */       if (this.batchStatement == null)
/*  382 */         this.batchStatement = this.connection.createStatement();
/*  383 */       this.batchStatement.addBatch(sql);
/*      */     } catch (Exception e) {
/*  385 */       e.printStackTrace();
/*  386 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/*  397 */       if (this.batchStatement == null)
/*  398 */         return null;
/*  399 */       return this.batchStatement.executeBatch();
/*      */     } catch (Exception e) {
/*  401 */       e.printStackTrace();
/*  402 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getSqlRows()
/*      */   {
/*  419 */     return this.sqlRows;
/*      */   }
/*      */ 
/*      */   protected void sqlFailure(String notice, SQLException e, int flag)
/*      */     throws Exception
/*      */   {
/*  426 */     this.sqlCode = (-e.getErrorCode());
/*  427 */     this.sqlNotice = ("sql statement" + this.strSQL + "\n" + notice + "\n" + "  error code :" + new Integer(this.sqlCode).toString() + ";\n" + "  error message:" + GBToUnicode(e.getMessage()) + "\n");
/*      */ 
/*  437 */     throw new Exception("SQL Error:" + this.sqlNotice + GBToUnicode(new StringBuilder().append(notice).append(e.getMessage()).toString()));
/*      */   }
/*      */ 
/*      */   public void closeAll()
/*      */   {
/*      */     try
/*      */     {
/*  451 */       close();
/*      */ 
/*  456 */       if (this.batchStatement != null) {
/*  457 */         this.batchStatement.close();
/*  458 */         this.batchStatement = null;
/*      */       }
/*      */ 
/*  461 */       if (null != this.connectionEx) {
/*  462 */         this.connectionEx.close();
/*      */       }
/*  465 */       else if (null != this.connection) {
/*  466 */         if (!this.connection.isClosed())
/*  467 */           this.connection.close();
/*  468 */         this.connection = null;
/*      */       }
/*      */ 
/*  472 */       this.connectionEx = null;
/*      */     } catch (Exception e) {
/*  474 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*  482 */     this.sqlNotice = null;
/*      */     try {
/*  484 */       if (this.sqlResultSet != null) {
/*  485 */         this.sqlResultSet.close();
/*  486 */         this.sqlResultSet = null;
/*      */       }
/*  488 */       if (this.statement != null) {
/*  489 */         openCount -= 1;
/*      */ 
/*  492 */         this.statement.close();
/*  493 */         this.statement = null;
/*      */       }
/*      */     } catch (Exception e) {
/*  496 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void Failure(String notice, int flag)
/*      */     throws Exception
/*      */   {
/*  510 */     this.sqlCode = 50;
/*  511 */     this.sqlNotice = notice;
/*  512 */     if ((flag == 1) && (this.sqlAutoRollback) && (!this.strSqlType.equals("SELECT")))
/*      */       try {
/*  514 */         this.connection.rollback();
/*      */       }
/*      */       catch (SQLException e1) {
/*      */       }
/*  518 */     throw new Exception(this.sqlNotice);
/*      */   }
/*      */ 
/*      */   private String unicodeToGB(String strIn)
/*      */   {
/*  528 */     if (!this.unicodeToGB) {
/*  529 */       return strIn;
/*      */     }
/*  531 */     String strOut = null;
/*  532 */     if ((strIn == null) || (strIn.trim().equals("")))
/*  533 */       return strIn;
/*      */     try
/*      */     {
/*  536 */       byte[] b = strIn.getBytes("GBK");
/*  537 */       strOut = new String(b, "ISO8859_1");
/*      */     } catch (Exception e) {
/*  539 */       strOut = strIn;
/*      */     }
/*  541 */     return strOut;
/*      */   }
/*      */ 
/*      */   private String GBToUnicode(String strIn)
/*      */   {
/*  551 */     if (!this.gbToUnicode) {
/*  552 */       return strIn;
/*      */     }
/*  554 */     String strOut = null;
/*  555 */     if ((strIn == null) || (strIn.trim().equals("")))
/*  556 */       return strIn;
/*      */     try
/*      */     {
/*  559 */       byte[] b = strIn.getBytes("ISO8859_1");
/*  560 */       strOut = new String(b, "GBK");
/*      */     } catch (Exception e) {
/*  562 */       strOut = strIn;
/*      */     }
/*  564 */     return strOut;
/*      */   }
/*      */ 
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws Exception
/*      */   {
/*  576 */     return this.sqlResultSet.getMetaData();
/*      */   }
/*      */ 
/*      */   public boolean next()
/*      */     throws Exception
/*      */   {
/*  585 */     return this.sqlResultSet.next();
/*      */   }
/*      */ 
/*      */   public void commit()
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/*  599 */       this.connection.commit();
/*      */     } catch (Exception e) {
/*  601 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void rollback()
/*      */     throws Exception
/*      */   {
/*  611 */     this.connection.rollback();
/*      */   }
/*      */ 
/*      */   public void setDBMSType(String dbType)
/*      */   {
/*  622 */     this.strDBMS = dbType;
/*      */   }
/*      */ 
/*      */   public String getDBMSType()
/*      */     throws Exception
/*      */   {
/*  634 */     if (null == this.strDBMS) {
/*  635 */       DatabaseMetaData m = this.connection.getMetaData();
/*  636 */       this.strDBMS = m.getDatabaseProductName();
/*  637 */       this.strDBMS = this.strDBMS.toUpperCase();
/*  638 */       if (this.strDBMS.indexOf("MYSQL") >= 0)
/*  639 */         this.strDBMS = "MYSQL";
/*  640 */       else if (this.strDBMS.indexOf("ORACLE") >= 0)
/*  641 */         this.strDBMS = "ORACLE";
/*  642 */       else if (this.strDBMS.indexOf("ACCESS") >= 0)
/*  643 */         this.strDBMS = "ACESS";
/*  644 */       else if (this.strDBMS.indexOf("SQL SERVER") >= 0)
/*  645 */         this.strDBMS = "SQLSERVER";
/*  646 */       else if (this.strDBMS.indexOf("DB2") >= 0)
/*  647 */         this.strDBMS = "DB2";
/*  648 */       else if (this.strDBMS.indexOf("TERA") >= 0)
/*  649 */         this.strDBMS = "TERA";
/*  650 */       else if (this.strDBMS.indexOf("SYBASE") >= 0)
/*  651 */         this.strDBMS = "SYBASE";
/*  652 */       else if (this.strDBMS.indexOf("ADAPTIVE") >= 0)
/*  653 */         this.strDBMS = "SYBASE";
/*      */       else {
/*  655 */         throw new Exception("does not support the database type!");
/*      */       }
/*      */     }
/*  658 */     return this.strDBMS;
/*      */   }
/*      */ 
/*      */   public String getString(int columnIndex)
/*      */     throws Exception
/*      */   {
/*  673 */     String retValue = null;
/*  674 */     if (this.sqlResultSet == null)
/*  675 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/*  678 */       retValue = this.sqlResultSet.getString(columnIndex);
/*  679 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  681 */       sqlFailure("take the first " + columnIndex + "value is wrong!", e, 0);
/*      */     }
/*  683 */     if ((this.lastNullFlag) || (null == retValue))
/*  684 */       retValue = "";
/*      */     else {
/*  686 */       retValue = retValue.trim();
/*      */     }
/*  688 */     return GBToUnicode(retValue);
/*      */   }
/*      */ 
/*      */   public String getString(String columnName)
/*      */     throws Exception
/*      */   {
/*  702 */     String retValue = null;
/*  703 */     if (this.sqlResultSet == null)
/*  704 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/*  707 */       retValue = this.sqlResultSet.getString(columnName);
/*  708 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  710 */       sqlFailure("take out " + columnName + " value is wrong!", e, 0);
/*      */     }
/*  712 */     if ((this.lastNullFlag) || (null == retValue))
/*  713 */       retValue = "";
/*      */     else {
/*  715 */       retValue = retValue.trim();
/*      */     }
/*  717 */     return GBToUnicode(retValue);
/*      */   }
/*      */ 
/*      */   public String getClob(int columnIndex)
/*      */     throws Exception
/*      */   {
/*  731 */     String strRet = null;
/*  732 */     Clob retValue = null;
/*  733 */     if (this.sqlResultSet == null)
/*  734 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/*  737 */       retValue = this.sqlResultSet.getClob(columnIndex);
/*  738 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  740 */       sqlFailure("take the first " + columnIndex + "value is wrong!", e, 0);
/*      */     }
/*  742 */     if ((this.lastNullFlag) || (null == retValue))
/*  743 */       strRet = "";
/*      */     else {
/*  745 */       strRet = clobToString(retValue);
/*      */     }
/*  747 */     return GBToUnicode(strRet);
/*      */   }
/*      */ 
/*      */   public String getClob(String columnName)
/*      */     throws Exception
/*      */   {
/*  761 */     String strRet = null;
/*  762 */     Clob retValue = null;
/*  763 */     if (this.sqlResultSet == null)
/*  764 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/*  767 */       retValue = this.sqlResultSet.getClob(columnName);
/*  768 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  770 */       sqlFailure("take out " + columnName + "value is wrong!", e, 0);
/*      */     }
/*  772 */     if ((this.lastNullFlag) || (null == retValue))
/*  773 */       strRet = "";
/*      */     else {
/*  775 */       strRet = clobToString(retValue);
/*      */     }
/*  777 */     return GBToUnicode(strRet);
/*      */   }
/*      */ 
/*      */   private String clobToString(Clob clob) throws Exception
/*      */   {
/*  782 */     StringBuffer content = new StringBuffer();
/*      */     try {
/*  784 */       String s = "";
/*  785 */       BufferedReader br = new BufferedReader(clob.getCharacterStream());
/*      */ 
/*  788 */       while ((s = br.readLine()) != null) {
/*  789 */         content.append(s);
/*      */       }
/*  791 */       return content.toString(); } catch (Exception e) {
/*      */     }
/*  793 */     throw new Exception("-------get value failed--------");
/*      */   }
/*      */ 
/*      */   public int getInt(int columnIndex)
/*      */     throws Exception
/*      */   {
/*  807 */     int retValue = -1;
/*  808 */     if (this.sqlResultSet == null)
/*  809 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/*  812 */       retValue = this.sqlResultSet.getInt(columnIndex);
/*  813 */       this.lastNullFlag = this.sqlResultSet.wasNull();
/*      */     } catch (SQLException e) {
/*  815 */       sqlFailure("take the first " + columnIndex + " value is wrong!", e, 0);
/*      */     }
/*  817 */     return retValue;
/*      */   }
/*      */ 
/*      */   public int getInt(String columnName)
/*      */     throws Exception
/*      */   {
/*  831 */     if (this.sqlResultSet == null)
/*  832 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     int retValue;
/*      */     try {
/*  835 */       retValue = this.sqlResultSet.getInt(columnName);
/*  836 */       this.lastNullFlag = false;
/*  837 */       if (this.sqlResultSet.wasNull())
/*  838 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  841 */       sqlFailure("take out " + columnName + " value error!", e, 0);
/*  842 */       return 0;
/*      */     }
/*  844 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Integer getInteger(int columnIndex)
/*      */     throws Exception
/*      */   {
/*  858 */     Integer retValue = null;
/*  859 */     if (this.sqlResultSet == null)
/*  860 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/*  863 */       int tempVar = this.sqlResultSet.getInt(columnIndex);
/*  864 */       this.lastNullFlag = false;
/*  865 */       if (this.sqlResultSet.wasNull()) {
/*  866 */         this.lastNullFlag = true;
/*  867 */         retValue = null;
/*      */       } else {
/*  869 */         retValue = new Integer(tempVar);
/*      */       }
/*      */     } catch (SQLException e) {
/*  872 */       sqlFailure("take the first " + columnIndex + " value error!", e, 0);
/*      */     }
/*  874 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Integer getInteger(String columnName)
/*      */     throws Exception
/*      */   {
/*  888 */     Integer retValue = null;
/*  889 */     if (this.sqlResultSet == null)
/*  890 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/*  893 */       int tempVar = this.sqlResultSet.getInt(columnName);
/*  894 */       this.lastNullFlag = false;
/*  895 */       if (this.sqlResultSet.wasNull()) {
/*  896 */         this.lastNullFlag = true;
/*  897 */         retValue = null;
/*      */       } else {
/*  899 */         retValue = new Integer(tempVar);
/*      */       }
/*      */     } catch (SQLException e) {
/*  902 */       sqlFailure("take out " + columnName + " value error!", e, 0);
/*      */     }
/*  904 */     return retValue;
/*      */   }
/*      */ 
/*      */   public long getLong(int columnIndex)
/*      */     throws Exception
/*      */   {
/*  918 */     long retValue = 0L;
/*  919 */     if (this.sqlResultSet == null)
/*  920 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/*  923 */       retValue = this.sqlResultSet.getLong(columnIndex);
/*  924 */       this.lastNullFlag = false;
/*  925 */       if (this.sqlResultSet.wasNull())
/*  926 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  929 */       sqlFailure("take the first " + columnIndex + " value error!", e, 0);
/*  930 */       return 0L;
/*      */     }
/*  932 */     return retValue;
/*      */   }
/*      */ 
/*      */   public long getLong(String columnName)
/*      */     throws Exception
/*      */   {
/*  946 */     if (this.sqlResultSet == null)
/*  947 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     long retValue;
/*      */     try {
/*  950 */       retValue = this.sqlResultSet.getLong(columnName);
/*  951 */       this.lastNullFlag = false;
/*  952 */       if (this.sqlResultSet.wasNull())
/*  953 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  956 */       sqlFailure("take out " + columnName + " value error!", e, 0);
/*  957 */       return 0L;
/*      */     }
/*  959 */     return retValue;
/*      */   }
/*      */ 
/*      */   public double getDouble(int columnIndex)
/*      */     throws Exception
/*      */   {
/*  972 */     double retValue = 0.0D;
/*  973 */     if (this.sqlResultSet == null)
/*  974 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/*  977 */       retValue = this.sqlResultSet.getDouble(columnIndex);
/*  978 */       this.lastNullFlag = false;
/*  979 */       if (this.sqlResultSet.wasNull())
/*  980 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/*  983 */       sqlFailure("take the first " + columnIndex + " value error!", e, 0);
/*      */     }
/*  985 */     return retValue;
/*      */   }
/*      */ 
/*      */   public double getDouble(String columnName)
/*      */     throws Exception
/*      */   {
/*  999 */     if (this.sqlResultSet == null)
/* 1000 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     double retValue;
/*      */     try {
/* 1003 */       retValue = this.sqlResultSet.getDouble(columnName);
/* 1004 */       this.lastNullFlag = false;
/* 1005 */       if (this.sqlResultSet.wasNull())
/* 1006 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/* 1009 */       sqlFailure("take out " + columnName + " value error!", e, 0);
/* 1010 */       return 0.0D;
/*      */     }
/* 1012 */     return retValue;
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(int columnIndex)
/*      */     throws Exception
/*      */   {
/* 1025 */     boolean retValue = false;
/* 1026 */     if (this.sqlResultSet == null)
/* 1027 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/* 1030 */       retValue = this.sqlResultSet.getBoolean(columnIndex);
/* 1031 */       this.lastNullFlag = false;
/* 1032 */       if (this.sqlResultSet.wasNull())
/* 1033 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/* 1036 */       sqlFailure("take the first " + columnIndex + " value error!", e, 0);
/*      */     }
/* 1038 */     return retValue;
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(String columnName)
/*      */     throws Exception
/*      */   {
/* 1050 */     boolean retValue = false;
/* 1051 */     if (this.sqlResultSet == null)
/* 1052 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/* 1055 */       retValue = this.sqlResultSet.getBoolean(columnName);
/* 1056 */       this.lastNullFlag = false;
/* 1057 */       if (this.sqlResultSet.wasNull())
/* 1058 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/* 1061 */       sqlFailure("take out " + columnName + " value error!", e, 0);
/*      */     }
/* 1063 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Date getDate(int columnIndex)
/*      */     throws Exception
/*      */   {
/* 1076 */     Date retValue = null;
/* 1077 */     if (this.sqlResultSet == null)
/* 1078 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/* 1081 */       Timestamp tmp = this.sqlResultSet.getTimestamp(columnIndex);
/* 1082 */       if (tmp != null)
/* 1083 */         retValue = new Date(tmp.getTime());
/*      */       else {
/* 1085 */         retValue = null;
/*      */       }
/* 1087 */       this.lastNullFlag = false;
/* 1088 */       if (this.sqlResultSet.wasNull()) {
/* 1089 */         retValue = null;
/* 1090 */         this.lastNullFlag = true;
/*      */       }
/*      */     } catch (SQLException e) {
/* 1093 */       sqlFailure("take the first " + columnIndex + " value error!", e, 0);
/*      */     }
/* 1095 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Date getDate(String columnName)
/*      */     throws Exception
/*      */   {
/* 1109 */     Date retValue = null;
/* 1110 */     if (this.sqlResultSet == null)
/* 1111 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/* 1114 */       Timestamp tmp = this.sqlResultSet.getTimestamp(columnName);
/* 1115 */       if (tmp != null)
/* 1116 */         retValue = new Date(tmp.getTime());
/*      */       else {
/* 1118 */         retValue = null;
/*      */       }
/* 1120 */       this.lastNullFlag = false;
/* 1121 */       if (this.sqlResultSet.wasNull())
/* 1122 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/* 1125 */       sqlFailure("take out " + columnName + " value error!", e, 0);
/*      */     }
/* 1127 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex)
/*      */     throws Exception
/*      */   {
/* 1140 */     Timestamp retValue = null;
/* 1141 */     if (this.sqlResultSet == null)
/* 1142 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/* 1145 */       retValue = this.sqlResultSet.getTimestamp(columnIndex);
/* 1146 */       this.lastNullFlag = false;
/* 1147 */       if (this.sqlResultSet.wasNull()) {
/* 1148 */         retValue = null;
/* 1149 */         this.lastNullFlag = true;
/*      */       }
/*      */     } catch (SQLException e) {
/* 1152 */       sqlFailure("take the first " + columnIndex + " value error!", e, 0);
/*      */     }
/* 1154 */     return retValue;
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName)
/*      */     throws Exception
/*      */   {
/* 1168 */     Timestamp retValue = null;
/* 1169 */     if (this.sqlResultSet == null)
/* 1170 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     try
/*      */     {
/* 1173 */       retValue = this.sqlResultSet.getTimestamp(columnName);
/* 1174 */       this.lastNullFlag = false;
/* 1175 */       if (this.sqlResultSet.wasNull()) {
/* 1176 */         retValue = null;
/* 1177 */         this.lastNullFlag = true;
/*      */       }
/*      */     } catch (SQLException e) {
/* 1180 */       sqlFailure("take the first " + columnName + " value error!", e, 0);
/*      */     }
/* 1182 */     return retValue;
/*      */   }
/*      */ 
/*      */   public float getFloat(int columnIndex)
/*      */     throws Exception
/*      */   {
/* 1196 */     if (this.sqlResultSet == null)
/* 1197 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     float retValue;
/*      */     try {
/* 1200 */       retValue = this.sqlResultSet.getFloat(columnIndex);
/* 1201 */       this.lastNullFlag = false;
/* 1202 */       if (this.sqlResultSet.wasNull())
/* 1203 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/* 1206 */       sqlFailure("take the first " + columnIndex + " value error!", e, 0);
/* 1207 */       return 0.0F;
/*      */     }
/* 1209 */     return retValue;
/*      */   }
/*      */ 
/*      */   public float getFloat(String columnName)
/*      */     throws Exception
/*      */   {
/* 1223 */     if (this.sqlResultSet == null)
/* 1224 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     float retValue;
/*      */     try {
/* 1227 */       retValue = this.sqlResultSet.getFloat(columnName);
/* 1228 */       this.lastNullFlag = false;
/* 1229 */       if (this.sqlResultSet.wasNull())
/* 1230 */         this.lastNullFlag = true;
/*      */     }
/*      */     catch (SQLException e) {
/* 1233 */       sqlFailure("take out " + columnName + " value error!!", e, 0);
/* 1234 */       return 0.0F;
/*      */     }
/* 1236 */     return retValue;
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(int columnIndex)
/*      */     throws Exception
/*      */   {
/* 1251 */     if (this.sqlResultSet == null) {
/* 1252 */       throw new Exception("take the first " + columnIndex + "value is wrong! because the result set to a null value");
/*      */     }
/* 1254 */     BigDecimal retValue = this.sqlResultSet.getBigDecimal(columnIndex);
/* 1255 */     this.lastNullFlag = false;
/* 1256 */     if (this.sqlResultSet.wasNull()) {
/* 1257 */       retValue = null;
/* 1258 */       this.lastNullFlag = true;
/*      */     }
/* 1260 */     return retValue;
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(String columnName)
/*      */     throws Exception
/*      */   {
/* 1273 */     if (this.sqlResultSet == null) {
/* 1274 */       throw new Exception("take out " + columnName + "value is wrong! because the result set to a null value");
/*      */     }
/* 1276 */     BigDecimal retValue = this.sqlResultSet.getBigDecimal(columnName);
/* 1277 */     this.lastNullFlag = false;
/* 1278 */     if (this.sqlResultSet.wasNull()) {
/* 1279 */       retValue = null;
/* 1280 */       this.lastNullFlag = true;
/*      */     }
/* 1282 */     return retValue;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public String[][] getMatrix()
/*      */   {
/* 1291 */     if (this.sqlResultSet == null) {
/* 1292 */       return (String[][])null;
/*      */     }
/* 1294 */     int colnum = 0;
/* 1295 */     Vector table = new Vector();
/*      */     try {
/* 1297 */       colnum = this.sqlResultSet.getMetaData().getColumnCount();
/* 1298 */       while (next()) {
/* 1299 */         String[] row = new String[colnum];
/* 1300 */         for (int i = 0; i < colnum; i++) {
/* 1301 */           row[i] = getString(i + 1);
/*      */         }
/* 1303 */         table.addElement(row);
/*      */       }
/*      */     } catch (Exception ex) {
/* 1306 */       System.err.println("Execute err : " + ex.getMessage());
/* 1307 */       return (String[][])null;
/*      */     }
/* 1309 */     String[][] matrix = new String[table.size() + 1][colnum];
/*      */ 
/* 1311 */     for (int col = 0; col < colnum; col++) {
/* 1312 */       matrix[0][col] = ("Filed" + col);
/*      */     }
/*      */ 
/* 1315 */     for (int rowl = 1; rowl < matrix.length; rowl++) {
/* 1316 */       matrix[rowl] = ((String[])(String[])table.elementAt(rowl - 1));
/*      */     }
/* 1318 */     return matrix;
/*      */   }
/*      */ 
/*      */   public String getSql2TimeStamp(String strDateStr, String strH, String strM, String strS)
/*      */     throws Exception
/*      */   {
/* 1336 */     if ((null == strDateStr) || (strDateStr.length() < 1)) {
/* 1337 */       return null;
/*      */     }
/* 1339 */     if (strDateStr.indexOf("0000-00-00") >= 0) {
/* 1340 */       return "null";
/*      */     }
/* 1342 */     String strType = getDBMSType();
/* 1343 */     String strRet = "";
/* 1344 */     if (strType.equalsIgnoreCase("MYSQL")) {
/* 1345 */       strRet = "'" + strDateStr + " " + strH + ":" + strM + ":" + strS + "'";
/*      */     }
/* 1347 */     else if (strType.equalsIgnoreCase("DB2")) {
/* 1348 */       strRet = "timestamp('" + strDateStr + " " + strH + ":" + strM + ":" + strS + "')";
/*      */     }
/* 1350 */     else if (strType.equalsIgnoreCase("ORACLE")) {
/* 1351 */       strRet = "to_date('" + strDateStr + " " + strH + ":" + strM + ":" + strS + "','YYYY-mm-dd hh24:mi:ss')";
/*      */     }
/* 1353 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1354 */       strRet = "'" + strDateStr + "'";
/* 1355 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/* 1356 */       strRet = "CONVERT(Datetime,'" + strDateStr + " " + strH + ":" + strM + ":" + strS + "',20)";
/*      */     }
/* 1358 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1359 */       strRet = strDateStr + " (FORMAT 'YYYY-MM-DD')";
/* 1360 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 1361 */       strRet = "cast('" + strDateStr + " " + strH + ":" + strM + ":" + strS + "' as Datetime)";
/*      */     }
/*      */     else {
/* 1364 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1366 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2TimeStamp(Date date)
/*      */     throws Exception
/*      */   {
/* 1380 */     SimpleDateFormat dFormat = new SimpleDateFormat("yyyy-MM-dd");
/*      */ 
/* 1382 */     SimpleDateFormat dFormat2 = new SimpleDateFormat("HH");
/*      */ 
/* 1384 */     SimpleDateFormat dFormat3 = new SimpleDateFormat("mm");
/*      */ 
/* 1386 */     SimpleDateFormat dFormat4 = new SimpleDateFormat("ss");
/*      */ 
/* 1388 */     return getSql2TimeStamp(dFormat.format(date), dFormat2.format(date), dFormat3.format(date), dFormat4.format(date));
/*      */   }
/*      */ 
/*      */   public String getSql2Date(String strDateStr, String splitStr)
/*      */     throws Exception
/*      */   {
/* 1408 */     if ((null == strDateStr) || (strDateStr.length() < 1)) {
/* 1409 */       return null;
/*      */     }
/* 1411 */     if (strDateStr.indexOf("0000-00-00") >= 0) {
/* 1412 */       return "null";
/*      */     }
/* 1414 */     String strType = getDBMSType();
/* 1415 */     String strRet = "";
/* 1416 */     int i = strDateStr.indexOf(" ");
/* 1417 */     if (i > 0) {
/* 1418 */       strDateStr = strDateStr.substring(0, i);
/*      */     }
/*      */ 
/* 1421 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1422 */       strRet = "'" + strDateStr + "'";
/* 1423 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1424 */       strRet = "date('" + strDateStr + "')";
/* 1425 */     else if (strType.equalsIgnoreCase("ORACLE")) {
/* 1426 */       if ("-".equals(splitStr))
/* 1427 */         strRet = "to_date('" + strDateStr + "','YYYY-mm-dd')";
/*      */       else
/* 1429 */         strRet = "to_date('" + strDateStr + "','YYYY/mm/dd')";
/*      */     }
/* 1431 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1432 */       strRet = "'" + strDateStr + "'";
/* 1433 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/*      */     {
/* 1436 */       if ("-".equals(splitStr)) {
/* 1437 */         strRet = "convert(varchar(10), convert(datetime,'" + strDateStr + "'), 111)";
/*      */       }
/*      */       else
/* 1440 */         strRet = "CONVERT(Datetime,'" + strDateStr + "',20)";
/*      */     }
/* 1442 */     else if (strType.equalsIgnoreCase("TERA")) {
/* 1443 */       if ("-".equals(splitStr)) {
/* 1444 */         strRet = "cast('" + strDateStr + "' as date FORMAT 'YYYY-MM-DD')";
/*      */       }
/*      */       else {
/* 1447 */         strRet = "cast('" + strDateStr + "' as date FORMAT 'YYYY/MM/DD')";
/*      */       }
/*      */     }
/* 1450 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 1451 */       strRet = "cast('" + strDateStr + "' as Date)";
/*      */     else {
/* 1453 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1455 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2DateYYYYMMDD(String strDateStr)
/*      */     throws Exception
/*      */   {
/* 1466 */     if ((null == strDateStr) || (strDateStr.length() < 1)) {
/* 1467 */       return null;
/*      */     }
/* 1469 */     if (strDateStr.indexOf("000000") >= 0) {
/* 1470 */       return "null";
/*      */     }
/* 1472 */     String strType = getDBMSType();
/* 1473 */     String strRet = "";
/* 1474 */     int i = strDateStr.indexOf(" ");
/* 1475 */     if (i > 0)
/* 1476 */       strDateStr = strDateStr.substring(0, i);
/* 1477 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1478 */       strRet = "'" + strDateStr + "'";
/* 1479 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1480 */       strRet = "date('" + strDateStr + "')";
/* 1481 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1482 */       strRet = "to_date('" + strDateStr + "','YYYYmmdd')";
/* 1483 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1484 */       strRet = "'" + strDateStr + "'";
/* 1485 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/*      */     {
/* 1488 */       strRet = "convert(varchar, convert(datetime, '" + strDateStr + "'), 112)";
/*      */     }
/* 1490 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1491 */       strRet = strDateStr + " (FORMAT 'YYYYMMDD')";
/* 1492 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 1493 */       strRet = "cast('" + strDateStr + "' as Date)";
/*      */     else {
/* 1495 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1497 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2ColumnName(String colName)
/*      */     throws Exception
/*      */   {
/* 1510 */     String strType = getDBMSType();
/* 1511 */     String strRet = "";
/* 1512 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1513 */       strRet = "Date_Format(" + colName + ",'%Y-%m-%d %H:%i:%s')";
/* 1514 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1515 */       strRet = "to_char(" + colName + ",'YYYY-mm-dd hh24:mi:ss')";
/* 1516 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1517 */       strRet = "ts_fmt(" + colName + ",'yyyy-mm-dd hh:mi:ss')";
/* 1518 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1519 */       strRet = colName;
/* 1520 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 1521 */       strRet = "CONVERT(Varchar," + colName + ",120)";
/* 1522 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1523 */       strRet = colName + " (FORMAT 'YYYY-MM-DD')";
/* 1524 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 1525 */       strRet = "convert(char(10)," + colName + ",23) || ' ' || convert(char(8)," + colName + ",108)";
/*      */     }
/*      */     else {
/* 1528 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 1530 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2DateTimeNow()
/*      */     throws Exception
/*      */   {
/* 1542 */     String strType = getDBMSType();
/* 1543 */     String strRet = "";
/* 1544 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1545 */       strRet = "now()";
/* 1546 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1547 */       strRet = "sysdate";
/* 1548 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1549 */       strRet = "date()+time()";
/* 1550 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 1551 */       strRet = "getdate()";
/* 1552 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1553 */       strRet = "current timestamp";
/* 1554 */     else if (strType.equalsIgnoreCase("TERA"))
/* 1555 */       strRet = "cast((date (format 'yyyy-mm-dd' )) as char(10)) ||' '|| time";
/* 1556 */     else if (strType.equalsIgnoreCase("SYBASE"))
/*      */     {
/* 1558 */       strRet = "getdate()";
/*      */     }
/* 1560 */     else throw new Exception("can't get the current date of the function definition");
/*      */ 
/* 1562 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql2DateNow()
/*      */     throws Exception
/*      */   {
/* 1573 */     String strType = getDBMSType();
/* 1574 */     String strRet = "";
/* 1575 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 1576 */       strRet = "curdate()";
/* 1577 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 1578 */       strRet = "sysdate";
/* 1579 */     else if (strType.equalsIgnoreCase("ACESS"))
/* 1580 */       strRet = "date()";
/* 1581 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 1582 */       strRet = "getdate()";
/* 1583 */     else if (strType.equalsIgnoreCase("DB2"))
/* 1584 */       strRet = "current date";
/* 1585 */     else if (strType.equalsIgnoreCase("TERA")) {
/* 1586 */       strRet = "cast((date (format 'yyyy-mm-dd' )) as char(10)) ||' '|| time";
/*      */     }
/* 1588 */     else if (strType.equalsIgnoreCase("SYBASE"))
/*      */     {
/* 1590 */       strRet = "getdate()";
/*      */     }
/* 1592 */     else throw new Exception("can't get the current date of the function definition");
/*      */ 
/* 1594 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String escapeString(String str)
/*      */     throws Exception
/*      */   {
/* 1605 */     if ((str == null) || (str.length() < 1))
/* 1606 */       return "";
/* 1607 */     String strType = getDBMSType();
/* 1608 */     String strRet = "";
/* 1609 */     for (int i = 0; i < str.length(); i++) {
/* 1610 */       char c = str.charAt(i);
/* 1611 */       if (c == '\'') {
/* 1612 */         if (strType.equalsIgnoreCase("MYSQL"))
/* 1613 */           strRet = strRet + "\\'";
/* 1614 */         else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("DB2")) || (strType.equalsIgnoreCase("TERA")) || (strType.equalsIgnoreCase("SYBASE")))
/*      */         {
/* 1618 */           strRet = strRet + "''";
/*      */         }
/*      */         else
/*      */         {
/* 1625 */           strRet = strRet + c;
/*      */         } } else if (c == '"') {
/* 1627 */         if (strType.equalsIgnoreCase("MYSQL"))
/* 1628 */           strRet = strRet + "\\\"";
/* 1629 */         else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("DB2")) || (strType.equalsIgnoreCase("TERA")) || (strType.equalsIgnoreCase("SYBASE")))
/*      */         {
/* 1633 */           strRet = strRet + "\"";
/*      */         }
/*      */         else
/*      */         {
/* 1640 */           strRet = strRet + c;
/*      */         } } else if (c == '\\') {
/* 1642 */         if (strType.equalsIgnoreCase("MYSQL")) {
/* 1643 */           strRet = strRet + "\\\\";
/*      */         }
/*      */         else
/*      */         {
/* 1653 */           strRet = strRet + c;
/*      */         }
/*      */       } else strRet = strRet + c;
/*      */     }
/* 1657 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlLimit(String strSql, int limitnum)
/*      */     throws Exception
/*      */   {
/* 1670 */     String strType = getDBMSType();
/* 1671 */     String strRet = "";
/* 1672 */     if (strType.equalsIgnoreCase("MYSQL")) {
/* 1673 */       strRet = strSql + " limit " + limitnum;
/* 1674 */     } else if (strType.equalsIgnoreCase("ORACLE")) {
/* 1675 */       limitnum++;
/*      */ 
/* 1677 */       strRet = "select * from (" + strSql + ") where ROWNUM<" + limitnum;
/* 1678 */     } else if (strType.equalsIgnoreCase("DB2")) {
/* 1679 */       strRet = strSql + "fetch first " + limitnum + " rows only";
/* 1680 */     } else if (strType.equalsIgnoreCase("SYBASE")) {
/* 1681 */       strRet = "select top " + limitnum + " * from(" + strSql + ") a";
/*      */     }
/* 1684 */     else if (strType.equalsIgnoreCase("SQLSERVER")) {
/* 1685 */       strRet = "select top " + limitnum + " * from(" + strSql + ") a";
/*      */     }
/* 1688 */     else if ("TERA".equalsIgnoreCase(strType)) {
/* 1689 */       StringBuffer buffer = new StringBuffer(strSql.length() + 100);
/* 1690 */       buffer.append(strSql);
/* 1691 */       int orderByIndex = buffer.toString().toLowerCase().lastIndexOf("order by");
/*      */ 
/* 1693 */       if (orderByIndex > 0)
/*      */       {
/* 1697 */         String orderBy = buffer.substring(orderByIndex);
/*      */ 
/* 1704 */         buffer.insert(orderByIndex, " QUALIFY row_number() OVER( ");
/* 1705 */         buffer.append(" ) ");
/* 1706 */         buffer.append(" between 1 and " + limitnum);
/* 1707 */         buffer.append(orderBy);
/*      */       }
/*      */       else {
/* 1710 */         buffer.append(" QUALIFY sum(1) over (rows unbounded preceding) between 1 and " + limitnum);
/*      */       }
/*      */ 
/* 1714 */       strRet = buffer.toString();
/*      */     } else {
/* 1716 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 1718 */     return strRet;
/*      */   }
/*      */ 
/*      */   public static String getCountTotalSql(String table, String strPrimaryKey, String condition, String tail)
/*      */   {
/* 1732 */     if (table == null) {
/* 1733 */       return "";
/*      */     }
/* 1735 */     String sql = "select count(" + strPrimaryKey + ") from ";
/* 1736 */     sql = sql + table + "    ";
/* 1737 */     if ((condition != null) && (!condition.equals(""))) {
/* 1738 */       sql = sql + "where " + condition;
/*      */     }
/* 1740 */     if ((tail != null) && (!tail.equals(""))) {
/* 1741 */       sql = sql + tail;
/*      */     }
/* 1743 */     return sql;
/*      */   }
/*      */ 
/*      */   public static String getCountTotalSql(String sql, String primaryKey)
/*      */   {
/* 1756 */     StringBuffer countSQL = new StringBuffer();
/* 1757 */     if ((primaryKey == null) || (primaryKey.length() < 1))
/* 1758 */       primaryKey = "*";
/* 1759 */     countSQL.append("select count(" + primaryKey + ") from ( ");
/* 1760 */     countSQL.append(sql);
/* 1761 */     countSQL.append(" ) tt");
/* 1762 */     return countSQL.toString();
/*      */   }
/*      */ 
/*      */   public String getPagedSql(String srcSql, int currPage, int pageSize)
/*      */     throws Exception
/*      */   {
/* 1779 */     String dbType = getDBMSType();
/* 1780 */     int begin = (currPage - 1) * pageSize;
/* 1781 */     int end = begin + pageSize;
/* 1782 */     String strRet = srcSql;
/* 1783 */     if (dbType.equals("MYSQL")) {
/* 1784 */       strRet = srcSql + " limit " + begin + "," + pageSize;
/* 1785 */     } else if (dbType.equals("ORACLE")) {
/* 1786 */       end++;
/* 1787 */       strRet = "SELECT * FROM (SELECT ROWNUM AS NUMROW, c.* from (" + srcSql + ") c) WHERE NUMROW >" + begin + " AND NUMROW <" + end;
/*      */     }
/* 1790 */     else if (dbType.equals("DB2"))
/*      */     {
/* 1808 */       StringBuffer rownumber = new StringBuffer(50).append(" rownumber() over(");
/* 1809 */       int orderByIndex = srcSql.toLowerCase().indexOf("order by");
/* 1810 */       if (orderByIndex > 0) {
/* 1811 */         String strOrder = srcSql.substring(orderByIndex);
/* 1812 */         String[] arryStr = strOrder.split(" ");
/* 1813 */         StringBuilder sb = new StringBuilder();
/* 1814 */         for (int i = 0; i < arryStr.length; i++) {
/* 1815 */           if (arryStr[i].lastIndexOf(".") > -1) {
/* 1816 */             String[] arrStr = arryStr[i].split(",");
/* 1817 */             arryStr[i] = "";
/* 1818 */             for (int j = 0; j < arrStr.length; j++) {
/* 1819 */               arrStr[j] = arrStr[j].substring(arrStr[j].lastIndexOf(".") + 1);
/*      */               int tmp294_292 = i;
/*      */               String[] tmp294_290 = arryStr; tmp294_290[tmp294_292] = (tmp294_290[tmp294_292] + arrStr[j]);
/* 1821 */               if (j != arrStr.length - 1)
/*      */               {
/*      */                 int tmp332_330 = i;
/*      */                 String[] tmp332_328 = arryStr; tmp332_328[tmp332_330] = (tmp332_328[tmp332_330] + ",");
/*      */               }
/*      */             }
/*      */           }
/* 1825 */           sb.append(arryStr[i]).append(" ");
/*      */         }
/* 1827 */         rownumber.append(sb.toString());
/*      */       }
/* 1829 */       rownumber.append(") as row_,");
/* 1830 */       StringBuffer pagingSelect = new StringBuffer(srcSql.length() + 100).append("select * from ( ").append(" select ").append(rownumber.toString()).append("temp_.* from (").append(srcSql).append(" ) as temp_").append(" ) as temp2_").append(" where row_  between " + begin + "+1 and " + end);
/*      */ 
/* 1839 */       strRet = pagingSelect.toString();
/*      */     }
/* 1841 */     else if (!dbType.equals("SYBASE"))
/*      */     {
/* 1844 */       if ("TERA".equalsIgnoreCase(dbType)) {
/* 1845 */         StringBuffer buffer = new StringBuffer(srcSql.length() + 100);
/* 1846 */         buffer.append(srcSql);
/* 1847 */         int orderByIndex = buffer.toString().toLowerCase().lastIndexOf("order by");
/*      */ 
/* 1849 */         if (orderByIndex > 0)
/*      */         {
/* 1853 */           String orderBy = buffer.substring(orderByIndex);
/*      */ 
/* 1860 */           buffer.insert(orderByIndex, " QUALIFY row_number() OVER( ");
/* 1861 */           buffer.append(" ) ");
/* 1862 */           buffer.append(" between " + begin + " and " + end);
/* 1863 */           buffer.append(orderBy);
/*      */         }
/*      */         else {
/* 1866 */           buffer.append(" QUALIFY sum(1) over (rows unbounded preceding) between " + begin + " and " + end);
/*      */         }
/*      */ 
/* 1870 */         strRet = buffer.toString();
/*      */       }
/*      */     }
/* 1872 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getPagedSql(String sql, String column, String strPrimaryKey, int curpage, int pagesize)
/*      */     throws Exception
/*      */   {
/* 1893 */     String strDBType = getDBMSType();
/* 1894 */     StringBuffer buffer = null;
/* 1895 */     buffer = new StringBuffer();
/* 1896 */     if ("ORACLE".equalsIgnoreCase(strDBType)) {
/* 1897 */       buffer.append("select * from ( ");
/* 1898 */       buffer.append("select ").append(column).append(" rownum as my_rownum from( ");
/*      */ 
/* 1900 */       buffer.append(sql).append(") ");
/* 1901 */       int pageAll = pagesize * curpage + pagesize;
/* 1902 */       buffer.append("where rownum <= " + pageAll + ") a ");
/* 1903 */       buffer.append("where a.my_rownum > " + pagesize * curpage);
/* 1904 */     } else if ("DB2".equalsIgnoreCase(strDBType)) {
/* 1905 */       buffer.append("select * from ( ");
/* 1906 */       buffer.append("select ").append(column).append("  rownumber() over (order by " + strPrimaryKey + ") as my_rownum from( ");
/*      */ 
/* 1909 */       buffer.append(sql).append(") as temp ");
/* 1910 */       buffer.append("fetch first " + (pagesize * curpage + pagesize) + " rows only) as a ");
/*      */ 
/* 1912 */       buffer.append("where a.my_rownum > " + pagesize * curpage);
/*      */     }
/* 1929 */     else if ("TERA".equalsIgnoreCase(strDBType)) {
/* 1930 */       buffer.append(sql);
/* 1931 */       int orderByIndex = buffer.toString().toLowerCase().lastIndexOf("order by");
/*      */ 
/* 1933 */       if (orderByIndex > 0)
/*      */       {
/* 1937 */         String orderBy = buffer.substring(orderByIndex);
/*      */ 
/* 1944 */         buffer.insert(orderByIndex, " QUALIFY row_number() OVER( ");
/* 1945 */         buffer.append(" ) ");
/* 1946 */         buffer.append(" between " + pagesize * curpage + " and " + (pagesize * curpage + pagesize));
/*      */ 
/* 1948 */         buffer.append(orderBy);
/*      */       }
/*      */       else {
/* 1951 */         buffer.append(" QUALIFY sum(1) over (rows unbounded preceding) between " + pagesize * curpage + " and " + (pagesize * curpage + pagesize));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1987 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   private static int getAfterSelectInsertPoint(String sql)
/*      */   {
/* 1997 */     return 16 + (sql.startsWith("select distinct") ? 15 : 6);
/*      */   }
/*      */ 
/*      */   public String getSqlSubString(String strColName, int pos, int len)
/*      */     throws Exception
/*      */   {
/* 2015 */     String strType = getDBMSType();
/* 2016 */     String strRet = "";
/* 2017 */     if ((strType.equalsIgnoreCase("MYSQL")) || (strType.equalsIgnoreCase("SYBASE")))
/*      */     {
/* 2019 */       if (len == -1)
/* 2020 */         strRet = "substring(" + strColName + "," + pos + ")";
/*      */       else {
/* 2022 */         strRet = "substring(" + strColName + "," + pos + "," + len + ")";
/*      */       }
/*      */     }
/* 2025 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("DB2")))
/*      */     {
/* 2027 */       if (len == -1)
/* 2028 */         strRet = "substr(" + strColName + "," + pos + ")";
/*      */       else
/* 2030 */         strRet = "substr(" + strColName + "," + pos + "," + len + ")";
/*      */     }
/* 2032 */     else if (strType.equalsIgnoreCase("TERA")) {
/* 2033 */       if (len == -1)
/* 2034 */         strRet = "substring(" + strColName + " form " + pos + ")";
/*      */       else {
/* 2036 */         strRet = "substring(" + strColName + " from " + pos + " for " + len + ")";
/*      */       }
/*      */     }
/*      */     else {
/* 2040 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 2042 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlSubDate(String interv)
/*      */     throws Exception
/*      */   {
/* 2055 */     String strType = getDBMSType();
/* 2056 */     String strRet = "";
/*      */ 
/* 2058 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 2059 */       strRet = "SUBDATE(now(),INTERVAL " + interv + " minute)";
/* 2060 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 2061 */       strRet = "(sysdate-" + interv + "/(24*60))";
/* 2062 */     else if (strType.equalsIgnoreCase("DB2"))
/* 2063 */       strRet = "(current timestamp-" + interv + " minute)";
/* 2064 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 2065 */       strRet = "dateadd(mi,-" + interv + ",getdate())";
/*      */     else {
/* 2067 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 2069 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlAddDate(String interv, String unit)
/*      */     throws Exception
/*      */   {
/* 2083 */     String strRet = "";
/* 2084 */     String strType = getDBMSType();
/* 2085 */     unit = unit.trim().toUpperCase();
/* 2086 */     interv = interv.trim();
/* 2087 */     if (!interv.startsWith("-"))
/* 2088 */       interv = "+" + interv;
/* 2089 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 2090 */       strRet = "ADDDATE(now(),INTERVAL " + interv + " " + unit + ")";
/* 2091 */     else if (strType.equalsIgnoreCase("ORACLE")) {
/* 2092 */       if (unit.compareTo("MINUTE") == 0)
/* 2093 */         strRet = "(sysdate" + interv + "/(24*60))";
/* 2094 */       else if (unit.compareTo("SECOND") == 0)
/* 2095 */         strRet = "(sysdate" + interv + "/(24*60*60))";
/* 2096 */       else if (unit.compareTo("HOUR") == 0)
/* 2097 */         strRet = "(sysdate" + interv + "/24)";
/* 2098 */       else if (unit.compareTo("DAY") == 0)
/* 2099 */         strRet = "(sysdate" + interv + ")";
/* 2100 */       else if (unit.compareTo("MONTH") == 0)
/* 2101 */         strRet = "(add_months(sysdate," + interv + "))";
/* 2102 */       else if (unit.compareTo("YEAR") == 0)
/* 2103 */         strRet = "(add_months(sysdate,(" + interv + "*12)))";
/* 2104 */     } else if (strType.equalsIgnoreCase("DB2"))
/* 2105 */       strRet = "(current timestamp " + interv + " " + unit + ")";
/* 2106 */     else if (strType.equalsIgnoreCase("SYBASE")) {
/* 2107 */       if (unit.compareTo("MINUTE") == 0)
/* 2108 */         strRet = "dateadd(mi," + interv + ",getdate())";
/* 2109 */       else if (unit.compareTo("SECOND") == 0)
/* 2110 */         strRet = "dateadd(ss," + interv + ",getdate())";
/* 2111 */       else if (unit.compareTo("HOUR") == 0)
/* 2112 */         strRet = "dateadd(hh," + interv + ",getdate())";
/* 2113 */       else if (unit.compareTo("DAY") == 0)
/* 2114 */         strRet = "dateadd(dd," + interv + ",getdate())";
/* 2115 */       else if (unit.compareTo("MONTH") == 0)
/* 2116 */         strRet = "dateadd(mm," + interv + ",getdate())";
/* 2117 */       else if (unit.compareTo("YEAR") == 0)
/* 2118 */         strRet = "dateadd(yy," + interv + ",getdate())";
/*      */     }
/* 2120 */     else throw new Exception("can't get the current date of the function definition");
/*      */ 
/* 2123 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlDateAddMonth(String monthNum)
/*      */     throws Exception
/*      */   {
/* 2134 */     String strType = getDBMSType();
/* 2135 */     String strRet = "";
/*      */ 
/* 2137 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 2138 */       strRet = "DATE_ADD(curdate(),INTERVAL " + monthNum + " month)";
/* 2139 */     else if (strType.equalsIgnoreCase("ORACLE")) {
/* 2140 */       strRet = "to_char(add_months(sysdate," + monthNum + "),'YYYY-mm-dd')";
/*      */     }
/* 2142 */     else if (strType.equalsIgnoreCase("DB2"))
/* 2143 */       strRet = "char((current date + " + monthNum + " month))";
/* 2144 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 2145 */       strRet = "dateadd(mm," + monthNum + ",getdate())";
/* 2146 */     else if (strType.equalsIgnoreCase("TERA"))
/* 2147 */       strRet = "add_months(date," + monthNum + ")";
/*      */     else {
/* 2149 */       throw new Exception("can't get the current date of the function definition");
/*      */     }
/* 2151 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlEncrypt(String strPwd)
/*      */     throws Exception
/*      */   {
/* 2168 */     StringBuffer strRet = new StringBuffer();
/* 2169 */     strRet.append("'");
/* 2170 */     strRet.append(DES.encrypt(strPwd));
/* 2171 */     strRet.append("'");
/* 2172 */     return strRet.toString();
/*      */   }
/*      */ 
/*      */   public String getSql_intTochar(String strColName) throws Exception {
/* 2176 */     String strType = getDBMSType();
/* 2177 */     String strRet = "";
/*      */ 
/* 2179 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 2180 */       strRet = strColName;
/* 2181 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 2182 */       strRet = "cast(" + strColName + " as varchar2(32))";
/* 2183 */     else if (strType.equalsIgnoreCase("DB2"))
/* 2184 */       strRet = "rtrim(char(" + strColName + "))";
/* 2185 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 2186 */       strRet = "convert(char," + strColName + ")";
/* 2187 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/*      */     {
/* 2190 */       strRet = "cast(" + strColName + " as varchar(12))";
/* 2191 */     } else if (strType.equalsIgnoreCase("TERA"))
/* 2192 */       strRet = "cast(" + strColName + " as varchar(12))";
/*      */     else {
/* 2194 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 2196 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql_charToint(String strColName) throws Exception {
/* 2200 */     String strType = getDBMSType();
/* 2201 */     String strRet = "";
/*      */ 
/* 2203 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 2204 */       strRet = strColName;
/* 2205 */     else if ((strType.equalsIgnoreCase("ORACLE")) || (strType.equalsIgnoreCase("TERA")))
/*      */     {
/* 2207 */       strRet = "cast(" + strColName + " as integer)";
/* 2208 */     } else if (strType.equalsIgnoreCase("DB2"))
/* 2209 */       strRet = "int(" + strColName + ")";
/* 2210 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 2211 */       strRet = "convert(int," + strColName + ")";
/* 2212 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 2213 */       strRet = "cast(" + strColName + " as integer)";
/*      */     else {
/* 2215 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 2217 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSql_charToDouble(String strColName)
/*      */     throws Exception
/*      */   {
/* 2228 */     String strType = getDBMSType();
/* 2229 */     String strRet = "";
/*      */ 
/* 2231 */     if (strType.equalsIgnoreCase("MYSQL"))
/* 2232 */       strRet = strColName;
/* 2233 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 2234 */       strRet = "cast(" + strColName + " as numeric)";
/* 2235 */     else if (strType.equalsIgnoreCase("DB2"))
/* 2236 */       strRet = "double(" + strColName + ")";
/*      */     else {
/* 2238 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 2240 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlRound(String str1, String str2)
/*      */     throws Exception
/*      */   {
/* 2254 */     String strType = getDBMSType();
/* 2255 */     String strRet = "";
/*      */ 
/* 2258 */     if (strType.equalsIgnoreCase("TERA"))
/* 2259 */       strRet = " cast ((" + str1 + ") as decimal(10," + str2 + ")) ";
/*      */     else {
/* 2261 */       strRet = " round(" + str1 + "," + str2 + ") ";
/*      */     }
/* 2263 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlNotEqual()
/*      */     throws Exception
/*      */   {
/* 2273 */     String strType = getDBMSType();
/* 2274 */     String strRet = "";
/*      */ 
/* 2276 */     if (strType.equalsIgnoreCase("TERA"))
/* 2277 */       strRet = "<>";
/*      */     else {
/* 2279 */       strRet = "!=";
/*      */     }
/* 2281 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlNvl(String str1, String str2)
/*      */     throws Exception
/*      */   {
/* 2293 */     String strType = getDBMSType();
/* 2294 */     String strRet = "";
/*      */ 
/* 2296 */     if (strType.equalsIgnoreCase("DB2"))
/* 2297 */       strRet = "value(" + str1 + "," + str2 + ")";
/* 2298 */     else if (strType.equalsIgnoreCase("ORACLE"))
/* 2299 */       strRet = "nvl(" + str1 + "," + str2 + ")";
/* 2300 */     else if (strType.equalsIgnoreCase("MYSQL"))
/* 2301 */       strRet = "ifnull(" + str1 + "," + str2 + ")";
/* 2302 */     else if (strType.equalsIgnoreCase("SYBASE"))
/* 2303 */       strRet = "isnull(" + str1 + "," + str2 + ")";
/* 2304 */     else if (strType.equalsIgnoreCase("SQLSERVER"))
/* 2305 */       strRet = "isnull(" + str1 + "," + str2 + ")";
/* 2306 */     else if (strType.equalsIgnoreCase("TERA"))
/* 2307 */       strRet = "COALESCE(" + str1 + "," + str2 + ")";
/*      */     else {
/* 2309 */       throw new Exception("function definition can not be achieved");
/*      */     }
/* 2311 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getCreateAsTableSql(String newtable, String templettable)
/*      */     throws Exception
/*      */   {
/* 2324 */     String ss = "";
/* 2325 */     String strDBType = getDBMSType();
/* 2326 */     if ("ORACLE".equalsIgnoreCase(strDBType)) {
/* 2327 */       ss = "create table " + newtable + " as select * from " + templettable + " where 1=2";
/*      */     }
/* 2329 */     else if ("DB2".equalsIgnoreCase(strDBType))
/* 2330 */       ss = "create table " + newtable + " like " + templettable;
/* 2331 */     else if ("TERA".equalsIgnoreCase(strDBType))
/*      */     {
/* 2334 */       ss = "create table " + newtable + " as " + templettable + " with no data";
/*      */     }
/*      */ 
/* 2337 */     return ss;
/*      */   }
/*      */ 
/*      */   public String getCreateAsTableSql(String newtable, String templettable, String tableSpace)
/*      */     throws Exception
/*      */   {
/* 2351 */     String ss = getCreateAsTableSql(newtable, templettable);
/* 2352 */     if ((tableSpace == null) || (tableSpace.length() < 1))
/* 2353 */       return ss;
/* 2354 */     String strDBType = getDBMSType();
/* 2355 */     if ("ORACLE".equalsIgnoreCase(strDBType)) {
/* 2356 */       ss = ss.replaceAll(newtable, newtable + " tablespace " + tableSpace);
/*      */     }
/* 2359 */     else if ("DB2".equalsIgnoreCase(strDBType)) {
/* 2360 */       ss = ss + " in " + tableSpace;
/*      */     }
/* 2362 */     return ss;
/*      */   }
/*      */ 
/*      */   public String getCreateTableInTableSpaceSql(String tableDDLSql, String tableSpace)
/*      */     throws Exception
/*      */   {
/* 2377 */     if ((tableSpace == null) || (tableSpace.length() < 1))
/* 2378 */       return tableDDLSql;
/* 2379 */     String strDBType = getDBMSType();
/* 2380 */     if ("ORACLE".equalsIgnoreCase(strDBType))
/* 2381 */       tableDDLSql = tableDDLSql + " tablespace " + tableSpace;
/* 2382 */     else if ("DB2".equalsIgnoreCase(strDBType)) {
/* 2383 */       tableDDLSql = tableDDLSql + " in " + tableSpace;
/*      */     }
/* 2385 */     return tableDDLSql;
/*      */   }
/*      */ 
/*      */   public String getCreateIndexInTableSpaceSql(String createIndexSql, String tableSpace)
/*      */     throws Exception
/*      */   {
/* 2399 */     if ((tableSpace == null) || (tableSpace.length() < 1))
/* 2400 */       return createIndexSql;
/* 2401 */     String strDBType = getDBMSType();
/* 2402 */     if ("ORACLE".equalsIgnoreCase(strDBType))
/* 2403 */       createIndexSql = createIndexSql + " using index tablespace " + tableSpace;
/* 2404 */     else if (!"DB2".equalsIgnoreCase(strDBType));
/* 2407 */     return createIndexSql;
/*      */   }
/*      */ 
/*      */   public String getCheckTableIsExistSql(String tableName)
/*      */     throws Exception
/*      */   {
/* 2418 */     String strSql = "";
/* 2419 */     String strDBType = getDBMSType();
/* 2420 */     if (strDBType.equals("DB2")) {
/* 2421 */       strSql = "select count(*) from syscat.tables where tabname='" + tableName.toUpperCase() + "'";
/*      */     }
/* 2423 */     else if (strDBType.equals("ORACLE")) {
/* 2424 */       strSql = "select count(*) from TAB where tname='" + tableName.toUpperCase() + "'";
/*      */     }
/* 2426 */     else if (strDBType.equals("TERA")) {
/* 2427 */       strSql = "select count(*) from dbc.tables where tablename='" + tableName.toUpperCase() + "'";
/*      */     }
/*      */ 
/* 2430 */     return strSql;
/*      */   }
/*      */ 
/*      */   public String getSql_dateTochar(String strColName, String mask)
/*      */     throws Exception
/*      */   {
/* 2445 */     String strRet = "";
/* 2446 */     strRet = "substr(" + getSql2ColumnName(strColName) + ",1," + mask.trim().length() + ")";
/*      */ 
/* 2448 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlOptimizeStart(String tablename, String cpuParallelSize)
/*      */     throws Exception
/*      */   {
/* 2464 */     String strRet = "";
/* 2465 */     String strDBType = getDBMSType();
/*      */ 
/* 2467 */     if (strDBType.equalsIgnoreCase("ORACLE")) {
/* 2468 */       strRet = "select /*+ parallel( " + tablename + " ," + cpuParallelSize + ") */ ";
/*      */     }
/*      */     else
/*      */     {
/* 2472 */       strRet = "select ";
/*      */     }
/* 2474 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlOptimizeEnd()
/*      */     throws Exception
/*      */   {
/* 2484 */     String strRet = "";
/* 2485 */     String strDBType = getDBMSType();
/*      */ 
/* 2487 */     if (strDBType.equalsIgnoreCase("ORACLE")) {
/* 2488 */       strRet = ",row_number() over( order by 100) ";
/*      */     }
/* 2490 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlNolog(String tablename)
/*      */     throws Exception
/*      */   {
/* 2502 */     String strRet = "";
/* 2503 */     String strDBType = getDBMSType();
/*      */ 
/* 2505 */     if (strDBType.equalsIgnoreCase("ORACLE")) {
/* 2506 */       strRet = "alter table " + tablename + " nologging";
/*      */     }
/* 2508 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlOptimizeInsert()
/*      */     throws Exception
/*      */   {
/* 2518 */     String strRet = "";
/* 2519 */     String strDBType = getDBMSType();
/*      */ 
/* 2521 */     if (strDBType.equalsIgnoreCase("ORACLE"))
/* 2522 */       strRet = "insert /*+append*/ into ";
/*      */     else {
/* 2524 */       strRet = "insert into ";
/*      */     }
/* 2526 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getCreateTableSql(String dataspace, String db2schemasuff, String dataspaceindex, String partitionKey)
/*      */     throws Exception
/*      */   {
/* 2541 */     String strRet = "";
/* 2542 */     String dbType = getDBMSType();
/* 2543 */     if (dbType.equalsIgnoreCase("ORACLE")) {
/* 2544 */       strRet = " tablespace  " + dataspace;
/* 2545 */     } else if (dbType.equalsIgnoreCase("DB2"))
/*      */     {
/* 2547 */       strRet = db2schemasuff + dataspace + dataspaceindex;
/* 2548 */       if ((null != partitionKey) && (!"".equals(partitionKey))) {
/* 2549 */         strRet = strRet + " PARTITIONING KEY (" + partitionKey + ") USING HASHING";
/*      */       }
/*      */ 
/* 2552 */       strRet = strRet + " NOT LOGGED INITIALLY ";
/*      */     }
/* 2554 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlIsNull(String strColName, boolean isNull)
/*      */     throws Exception
/*      */   {
/* 2569 */     String strRet = "";
/* 2570 */     String dbType = getDBMSType();
/* 2571 */     if (isNull) {
/* 2572 */       strRet = strColName + " is null";
/* 2573 */       if (dbType.equalsIgnoreCase("DB2"))
/* 2574 */         strRet = strRet + " or " + strColName + "=''";
/*      */     }
/*      */     else {
/* 2577 */       strRet = strColName + " is not null";
/* 2578 */       if (dbType.equalsIgnoreCase("DB2")) {
/* 2579 */         strRet = strRet + " and not " + strColName + "=''";
/*      */       }
/*      */     }
/* 2582 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getSqlSystables()
/*      */     throws Exception
/*      */   {
/* 2592 */     String strRet = "select * from(";
/* 2593 */     String dbType = getDBMSType();
/* 2594 */     if (dbType.equalsIgnoreCase("ORACLE")) {
/* 2595 */       strRet = strRet + "select owner tabschema,table_name tabname,comments remarks From All_Tab_Comments";
/* 2596 */       strRet = strRet + ") where 1=1";
/* 2597 */       strRet = strRet + " and tabschema not like 'SYS%'";
/* 2598 */     } else if (dbType.equalsIgnoreCase("DB2")) {
/* 2599 */       strRet = strRet + "select tabschema,tabname,remarks from syscat.tables";
/* 2600 */       strRet = strRet + ")as ta where 1=1";
/* 2601 */       strRet = strRet + " and tabschema not like 'SYSIBM%'";
/* 2602 */     } else if (dbType.equalsIgnoreCase("MYSQL")) {
/* 2603 */       strRet = strRet + "select table_schema tabschema,table_name tabname,table_comment remarks from information_schema.tables";
/* 2604 */       strRet = strRet + ")as ta where 1=1";
/* 2605 */       strRet = strRet + " and tabschema='" + getDatabaseName() + "'";
/*      */     }
/* 2607 */     return strRet;
/*      */   }
/*      */ 
/*      */   public String getDatabaseName()
/*      */     throws Exception
/*      */   {
/* 2617 */     String dbname = "";
/* 2618 */     String dbType = getDBMSType();
/* 2619 */     String url = this.connection.getMetaData().getURL();
/* 2620 */     if (dbType.equalsIgnoreCase("MYSQL")) {
/* 2621 */       int s = url.indexOf("/", 13) + 1;
/* 2622 */       int e = url.indexOf("?");
/* 2623 */       dbname = url.substring(s, e).toLowerCase();
/* 2624 */       log.debug(dbname);
/*      */     }
/* 2626 */     return dbname;
/*      */   }
/*      */ 
/*      */   public String getSqlConcat(String strColNames)
/*      */     throws Exception
/*      */   {
/* 2638 */     String strRet = "";
/* 2639 */     String dbType = getDBMSType();
/* 2640 */     String[] names = strColNames.split(",");
/* 2641 */     if (dbType.equalsIgnoreCase("MYSQL")) {
/* 2642 */       for (int i = 0; i < names.length; i++) {
/* 2643 */         if (i == 0)
/* 2644 */           strRet = names[0];
/*      */         else
/* 2646 */           strRet = "CONCAT(" + strRet + "," + names[i] + ")";
/*      */       }
/*      */     }
/* 2649 */     else if (dbType.equalsIgnoreCase("DB2"))
/* 2650 */       strRet = strColNames.replaceAll(",", "||");
/* 2651 */     else if (dbType.equalsIgnoreCase("ORACLE")) {
/* 2652 */       strRet = strColNames.replaceAll(",", "||");
/*      */     }
/*      */ 
/* 2655 */     return strRet;
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.database.jdbc.Sqlca
 * JD-Core Version:    0.6.2
 */
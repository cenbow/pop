/*     */ package com.asiainfo.biframe.utils.database.jdbc;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SqlcaPst extends Sqlca
/*     */ {
/*  35 */   private static Log log = LogFactory.getLog(SqlcaPst.class);
/*     */ 
/*  37 */   protected PreparedStatement m_PreparedStatement = null;
/*  38 */   protected PreparedStatement batchPreparedStateMent = null;
/*     */ 
/*     */   public SqlcaPst()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public SqlcaPst(Connection newConnection)
/*     */     throws Exception
/*     */   {
/*  56 */     super(newConnection);
/*     */   }
/*     */ 
/*     */   public SqlcaPst(Connection newConnection, String sqlStatement)
/*     */     throws Exception
/*     */   {
/*  69 */     super(newConnection);
/*  70 */     setSql(sqlStatement);
/*     */   }
/*     */ 
/*     */   public SqlcaPst(ConnectionEx conn)
/*     */     throws Exception
/*     */   {
/*  80 */     super(conn);
/*     */   }
/*     */ 
/*     */   public SqlcaPst(ConnectionEx conn, boolean bGBToUnicode, boolean bUnicodeToGB)
/*     */     throws Exception
/*     */   {
/*  98 */     super(conn, bGBToUnicode, bUnicodeToGB);
/*     */   }
/*     */ 
/*     */   public SqlcaPst(Connection conn, boolean bGBToUnicode, boolean bUnicodeToGB)
/*     */     throws Exception
/*     */   {
/* 115 */     super(conn);
/* 116 */     this.unicodeToGB = bGBToUnicode;
/* 117 */     this.gbToUnicode = bUnicodeToGB;
/*     */   }
/*     */ 
/*     */   public void setSql(String sqlStatement)
/*     */     throws Exception
/*     */   {
/* 129 */     if (this.connection == null)
/*     */     {
/* 131 */       Failure("没有获得到数据库的连接!", 0);
/*     */     }
/*     */ 
/* 134 */     this.strSQL = sqlStatement;
/* 135 */     this.sqlCode = 0;
/* 136 */     this.sqlRows = 0;
/* 137 */     this.sqlNotice = null;
/*     */ 
/* 139 */     sqlStatement = sqlStatement.trim();
/* 140 */     this.strSqlType = sqlStatement.substring(0, 4).toUpperCase();
/* 141 */     if (this.strSqlType.equals("SELE"))
/*     */     {
/* 143 */       this.strSqlType = "SELECT";
/*     */     }
/* 145 */     else if (this.strSqlType.equals("WITH"))
/*     */     {
/* 147 */       this.strSqlType = "SELECT";
/*     */     }
/* 149 */     else if (this.strSqlType.equals("DELE"))
/*     */     {
/* 151 */       this.strSqlType = "DELETE";
/*     */     }
/* 153 */     else if (this.strSqlType.equals("UPDA"))
/*     */     {
/* 155 */       this.strSqlType = "UPDATE";
/*     */     }
/* 157 */     else if (this.strSqlType.equals("INSE"))
/*     */     {
/* 159 */       this.strSqlType = "INSERT";
/*     */     }
/*     */     else
/*     */     {
/* 163 */       this.strSqlType = "UNKNOWN";
/*     */     }
/*     */ 
/* 166 */     close();
/*     */ 
/* 168 */     String strType = getDBMSType();
/* 169 */     if (strType.equalsIgnoreCase("SQLSERVER"))
/* 170 */       this.connection.setAutoCommit(true);
/* 171 */     this.m_PreparedStatement = this.connection.prepareStatement(sqlStatement);
/*     */   }
/*     */ 
/*     */   public int execute()
/*     */     throws Exception
/*     */   {
/* 192 */     this.sqlRows = 0;
/* 193 */     if (this.m_PreparedStatement == null)
/*     */     {
/* 195 */       this.sqlRows = -1;
/* 196 */       Failure("没有可执行的SQL!", 0);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 201 */       if (this.strSqlType.equals("SELECT"))
/*     */       {
/* 203 */         this.sqlResultSet = this.m_PreparedStatement.executeQuery();
/*     */       }
/*     */       else
/*     */       {
/* 207 */         this.sqlRows = this.m_PreparedStatement.executeUpdate();
/*     */       }
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 212 */       this.sqlRows = -1;
/* 213 */       sqlFailure("执行SQL:\n  " + this.strSQL + "出错!", e, 0);
/* 214 */       return -1;
/*     */     }
/* 216 */     return this.sqlRows;
/*     */   }
/*     */ 
/*     */   public void closeAll()
/*     */   {
/*     */     try {
/* 222 */       super.closeAll();
/* 223 */       close();
/*     */ 
/* 228 */       if (this.batchPreparedStateMent != null)
/*     */       {
/* 230 */         this.batchPreparedStateMent.close();
/* 231 */         this.batchPreparedStateMent = null;
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 237 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 247 */     super.close();
/*     */     try
/*     */     {
/* 250 */       if (this.m_PreparedStatement != null)
/*     */       {
/* 252 */         this.m_PreparedStatement.close();
/* 253 */         this.m_PreparedStatement = null;
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 258 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addBatch(String sql)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 273 */       if (this.batchPreparedStateMent == null)
/* 274 */         this.batchPreparedStateMent = this.connection.prepareStatement(sql);
/* 275 */       this.batchPreparedStateMent.addBatch();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 279 */       e.printStackTrace();
/* 280 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int[] executeBatch()
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 294 */       if (this.batchPreparedStateMent == null)
/* 295 */         return null;
/* 296 */       return this.batchPreparedStateMent.executeBatch();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 300 */       e.printStackTrace();
/* 301 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void Failure(String notice, int flag)
/*     */     throws Exception
/*     */   {
/* 314 */     this.sqlCode = 50;
/* 315 */     this.sqlNotice = notice;
/* 316 */     if ((flag == 1) && (this.sqlAutoRollback) && (!this.strSqlType.equals("SELECT")))
/*     */     {
/*     */       try
/*     */       {
/* 320 */         this.connection.rollback();
/*     */       }
/*     */       catch (SQLException e1)
/*     */       {
/*     */       }
/*     */     }
/* 326 */     throw new Exception(this.sqlNotice);
/*     */   }
/*     */ 
/*     */   public void setBlob(int index, Blob blob) {
/*     */     try {
/* 331 */       if (blob == null)
/* 332 */         this.m_PreparedStatement.setNull(index, 2004);
/*     */       else
/* 334 */         this.m_PreparedStatement.setBlob(index, blob);
/*     */     }
/*     */     catch (SQLException e) {
/* 337 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setClob(int index, Clob clob) {
/*     */     try {
/* 343 */       if (clob == null)
/* 344 */         this.m_PreparedStatement.setNull(index, 2005);
/*     */       else
/* 346 */         this.m_PreparedStatement.setClob(index, clob);
/*     */     }
/*     */     catch (SQLException e) {
/* 349 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setString(int index, String value) {
/*     */     try {
/* 355 */       if (StringUtil.isEmpty(value))
/* 356 */         this.m_PreparedStatement.setNull(index, 12);
/*     */       else
/* 358 */         this.m_PreparedStatement.setString(index, value);
/*     */     }
/*     */     catch (SQLException e) {
/* 361 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDate(int index, java.sql.Date value) {
/*     */     try {
/* 367 */       if (null == value)
/* 368 */         this.m_PreparedStatement.setNull(index, 91);
/*     */       else
/* 370 */         this.m_PreparedStatement.setDate(index, value);
/*     */     }
/*     */     catch (SQLException e) {
/* 373 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDate(int index, java.util.Date value) {
/*     */     try {
/* 379 */       if (null == value)
/* 380 */         this.m_PreparedStatement.setNull(index, 91);
/*     */       else
/* 382 */         this.m_PreparedStatement.setDate(index, new java.sql.Date(value.getTime()));
/*     */     }
/*     */     catch (SQLException e) {
/* 385 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setTimestamp(int index, Timestamp value) {
/*     */     try {
/* 391 */       if (null == value)
/* 392 */         this.m_PreparedStatement.setNull(index, 91);
/*     */       else
/* 394 */         this.m_PreparedStatement.setTimestamp(index, value);
/*     */     }
/*     */     catch (SQLException e) {
/* 397 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setInteger(int index, Integer value) {
/*     */     try {
/* 403 */       if (null == value)
/* 404 */         this.m_PreparedStatement.setNull(index, 4);
/*     */       else
/* 406 */         this.m_PreparedStatement.setInt(index, value.intValue());
/*     */     }
/*     */     catch (SQLException e) {
/* 409 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setInteger(int index, String value) {
/*     */     try {
/* 415 */       if (StringUtil.isEmpty(value))
/* 416 */         this.m_PreparedStatement.setNull(index, 4);
/*     */       else
/* 418 */         this.m_PreparedStatement.setInt(index, Integer.valueOf(value).intValue());
/*     */     }
/*     */     catch (SQLException e) {
/* 421 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setLong(int index, Long value) {
/*     */     try {
/* 427 */       if (null == value)
/* 428 */         this.m_PreparedStatement.setNull(index, 2);
/*     */       else
/* 430 */         this.m_PreparedStatement.setLong(index, value.longValue());
/*     */     }
/*     */     catch (SQLException e) {
/* 433 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setLong(int index, String value)
/*     */   {
/*     */     try {
/* 440 */       if (StringUtil.isEmpty(value))
/* 441 */         this.m_PreparedStatement.setNull(index, 2);
/*     */       else
/* 443 */         this.m_PreparedStatement.setLong(index, Long.valueOf(value).longValue());
/*     */     }
/*     */     catch (SQLException e) {
/* 446 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setList(int index, List list)
/*     */   {
/*     */     try {
/* 453 */       if ((list == null) || (list.size() == 0)) {
/* 454 */         this.m_PreparedStatement.setString(index, "");
/*     */       } else {
/* 456 */         String listStr = "";
/* 457 */         for (int i = 0; i < list.size(); i++) {
/* 458 */           listStr = listStr + "," + list.get(i) + "";
/*     */         }
/* 460 */         listStr = listStr.substring(1);
/* 461 */         this.m_PreparedStatement.setString(index, listStr);
/*     */       }
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 466 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.database.jdbc.SqlcaPst
 * JD-Core Version:    0.6.2
 */
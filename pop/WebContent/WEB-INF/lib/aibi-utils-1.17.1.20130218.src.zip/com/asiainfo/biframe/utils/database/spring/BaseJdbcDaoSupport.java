/*      */ package com.asiainfo.biframe.utils.database.spring;
/*      */ 
/*      */ import com.asiainfo.biframe.utils.config.Configure;
/*      */ import com.asiainfo.biframe.utils.database.jdbc.Sqlca;
/*      */ import com.asiainfo.biframe.utils.string.StringEncoding;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import edu.emory.mathcs.backport.java.util.Arrays;
/*      */ import java.io.PrintStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.naming.NamingException;
/*      */ import javax.sql.DataSource;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.springframework.dao.DataAccessException;
/*      */ import org.springframework.jdbc.core.JdbcTemplate;
/*      */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*      */ import org.springframework.jndi.JndiTemplate;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ public class BaseJdbcDaoSupport extends JdbcDaoSupport
/*      */ {
/*   54 */   private static Logger log = Logger.getLogger(BaseJdbcDaoSupport.class);
/*      */ 
/*   59 */   private static SimpleDateFormat timeformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*   60 */   private static SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
/*      */ 
/*   64 */   private String jndiName = "";
/*      */ 
/*   68 */   private Map encodingMap = new HashMap();
/*      */ 
/*   72 */   private String curEncoding = "";
/*      */ 
/*   76 */   public final String[] delimeter = { ";", "," };
/*      */ 
/*      */   public void setDbEncoding(String _dbEncoding)
/*      */   {
/*   84 */     this.curEncoding = _dbEncoding;
/*      */   }
/*      */ 
/*      */   public List queryPageList(String sqlStr, int currPage, int pageSize)
/*      */     throws UnsupportedEncodingException, SQLException
/*      */   {
/*  102 */     int pagesizeint = pageSize;
/*  103 */     int currpageint = currPage;
/*  104 */     int startNum = pagesizeint * currpageint + 1;
/*  105 */     int endNum = pagesizeint * currpageint + pagesizeint;
/*  106 */     return queryLimitedList(sqlStr, startNum, endNum);
/*      */   }
/*      */ 
/*      */   public List queryLimitedList(String sqlStr, int startNum, int endNum)
/*      */     throws UnsupportedEncodingException, SQLException
/*      */   {
/*  121 */     List result = new LinkedList();
/*  122 */     sqlStr = StringEncoding.convert2Db(sqlStr, this.curEncoding);
/*  123 */     this.logger.debug("-----queryLimitedList,this=" + this + ",sql=[" + sqlStr + "]");
/*      */ 
/*  125 */     int rowIndex = 0;
/*      */ 
/*  127 */     PreparedStatement ps = null;
/*  128 */     ResultSet rs = null;
/*  129 */     Connection conn = null;
/*      */     try {
/*  131 */       conn = getJdbcTemplate().getDataSource().getConnection();
/*  132 */       ps = conn.prepareStatement(sqlStr);
/*  133 */       rs = ps.executeQuery();
/*  134 */       while (rs.next()) {
/*  135 */         rowIndex++;
/*  136 */         if (rowIndex >= startNum)
/*      */         {
/*  139 */           result.add(mapRow(rs));
/*  140 */           if (rowIndex >= endNum)
/*  141 */             break;
/*      */         }
/*      */       }
/*      */     } catch (SQLException e) {
/*  145 */       e.printStackTrace();
/*  146 */       throw e;
/*      */     } finally {
/*      */       try {
/*  149 */         if (null != rs) {
/*  150 */           rs.close();
/*      */         }
/*  152 */         if (null != ps) {
/*  153 */           ps.close();
/*      */         }
/*  155 */         if (null != conn)
/*  156 */           conn.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  159 */         e.printStackTrace();
/*  160 */         throw e;
/*      */       }
/*      */     }
/*  163 */     return result;
/*      */   }
/*      */ 
/*      */   public int getColumnCount(String sqlStr)
/*      */     throws UnsupportedEncodingException, SQLException
/*      */   {
/*  175 */     sqlStr = StringEncoding.convert2Db(sqlStr, this.curEncoding);
/*  176 */     this.logger.debug("-----queryLimitedList,this=" + this + ",sql=[" + sqlStr + "]");
/*  177 */     PreparedStatement ps = null;
/*  178 */     ResultSet rs = null;
/*  179 */     Connection conn = null;
/*      */     try {
/*  181 */       conn = getJdbcTemplate().getDataSource().getConnection();
/*  182 */       ps = conn.prepareStatement(sqlStr);
/*  183 */       rs = ps.executeQuery();
/*  184 */       return rs.getMetaData().getColumnCount();
/*      */     } catch (SQLException e) {
/*  186 */       e.printStackTrace();
/*  187 */       throw e;
/*      */     } finally {
/*      */       try {
/*  190 */         if (null != rs) {
/*  191 */           rs.close();
/*      */         }
/*  193 */         if (null != ps) {
/*  194 */           ps.close();
/*      */         }
/*  196 */         if (null != conn)
/*  197 */           conn.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  200 */         e.printStackTrace();
/*  201 */         throw e;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void queryRowSizeCallBackList(String sqlStr, int maxRowSize, IJdbcCallbackService jdbcCallbackService)
/*      */     throws Exception
/*      */   {
/*  214 */     List result = new LinkedList();
/*  215 */     sqlStr = StringEncoding.convert2Db(sqlStr, getCurEncoding());
/*  216 */     int index = 1;
/*  217 */     this.logger.debug("-----queryLimitedList,this=" + this + ",sql=[" + sqlStr + "]");
/*      */ 
/*  219 */     long rowIndex = 0L;
/*      */ 
/*  221 */     PreparedStatement ps = null;
/*  222 */     ResultSet rs = null;
/*  223 */     Connection conn = null;
/*      */     try {
/*  225 */       conn = getJdbcTemplate().getDataSource().getConnection();
/*  226 */       ps = conn.prepareStatement(sqlStr);
/*  227 */       rs = ps.executeQuery();
/*      */ 
/*  231 */       while (rs.next()) {
/*  232 */         rowIndex += 1L;
/*  233 */         result.add(mapRow(rs));
/*  234 */         if (rowIndex == maxRowSize * index) {
/*  235 */           jdbcCallbackService.callback(result, index);
/*  236 */           result.clear();
/*  237 */           index++;
/*  238 */           this.logger.debug("queryRowSizeCallBackList index=========================" + index);
/*      */         }
/*      */       }
/*  241 */       if (result.size() > 0)
/*      */       {
/*  243 */         jdbcCallbackService.callback(result, index);
/*      */       }
/*      */ 
/*  246 */       jdbcCallbackService.queryDone();
/*      */     } catch (SQLException e) {
/*  248 */       e.printStackTrace();
/*  249 */       throw e;
/*      */     } finally {
/*      */       try {
/*  252 */         if (null != rs) {
/*  253 */           rs.close();
/*      */         }
/*  255 */         if (null != ps) {
/*  256 */           ps.close();
/*      */         }
/*  258 */         if (null != conn)
/*  259 */           conn.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  262 */         e.printStackTrace();
/*  263 */         throw e;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<Map<String, String>> queryRowSizeCallBackList(String sqlStr, int maxRowSize, IJdbcCallbackService jdbcCallbackService, boolean bool) throws Exception {
/*  269 */     List result = new LinkedList();
/*  270 */     List columnParam = new ArrayList();
/*  271 */     sqlStr = StringEncoding.convert2Db(sqlStr, getCurEncoding());
/*  272 */     int index = 1;
/*  273 */     this.logger.debug("-----queryLimitedList,this=" + this + ",sql=[" + sqlStr + "]");
/*      */ 
/*  275 */     long rowIndex = 0L;
/*      */ 
/*  277 */     PreparedStatement ps = null;
/*  278 */     ResultSet rs = null;
/*  279 */     Connection conn = null;
/*      */     try {
/*  281 */       conn = getJdbcTemplate().getDataSource().getConnection();
/*  282 */       ps = conn.prepareStatement(sqlStr);
/*  283 */       rs = ps.executeQuery();
/*  284 */       boolean flag = true;
/*  285 */       while (rs.next()) {
/*  286 */         if (flag) {
/*  287 */           ResultSetMetaData md = rs.getMetaData();
/*  288 */           int colCount = md.getColumnCount() + 1;
/*  289 */           int type = -1;
/*  290 */           int length = -1;
/*  291 */           String columnName = "";
/*  292 */           for (int i = 1; i < colCount; i++) {
/*  293 */             Map row = new LinkedHashMap();
/*  294 */             type = md.getColumnType(i);
/*  295 */             length = md.getColumnDisplaySize(i);
/*  296 */             columnName = md.getColumnName(i);
/*  297 */             row.put("ColumnCode", columnName);
/*  298 */             row.put("ColumnLength", length + "");
/*  299 */             if ((type == 2) || (type == 3) || (type == -5) || (type == 8) || (type == 6) || (type == 4) || (type == 7))
/*      */             {
/*  303 */               row.put("ColumnType", getType(type));
/*      */             }
/*  305 */             else if (type == 93)
/*      */             {
/*  307 */               row.put("ColumnType", getType(type));
/*  308 */             } else if (type == 91) {
/*  309 */               row.put("ColumnType", getType(type));
/*      */             }
/*      */             else {
/*  312 */               row.put("ColumnType", getType(type));
/*      */             }
/*  314 */             columnParam.add(row);
/*      */           }
/*  316 */           flag = false;
/*      */         }
/*  318 */         rowIndex += 1L;
/*  319 */         result.add(mapRow(rs));
/*  320 */         if (rowIndex == maxRowSize * index) {
/*  321 */           jdbcCallbackService.callback(result, index);
/*  322 */           result.clear();
/*  323 */           index++;
/*  324 */           this.logger.debug("queryRowSizeCallBackList index=========================" + index);
/*      */         }
/*      */       }
/*  327 */       boolean b = result.size() > 0;
/*  328 */       if (b) {
/*  329 */         jdbcCallbackService.callback(result, index);
/*      */       }
/*      */ 
/*  332 */       jdbcCallbackService.queryDone();
/*      */     } catch (SQLException e) {
/*  334 */       e.printStackTrace();
/*  335 */       throw e;
/*      */     } finally {
/*      */       try {
/*  338 */         if (null != rs) {
/*  339 */           rs.close();
/*      */         }
/*  341 */         if (null != ps) {
/*  342 */           ps.close();
/*      */         }
/*  344 */         if (null != conn)
/*  345 */           conn.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  348 */         e.printStackTrace();
/*  349 */         throw e;
/*      */       }
/*      */     }
/*  352 */     return columnParam;
/*      */   }
/*      */ 
/*      */   public String getType(int type) {
/*  356 */     String typeName = "";
/*  357 */     switch (type) {
/*      */     case 2:
/*  359 */       typeName = "NUMERIC";
/*  360 */       break;
/*      */     case 3:
/*  362 */       typeName = "DECIMAL";
/*  363 */       break;
/*      */     case -5:
/*  365 */       typeName = "BIGINT";
/*  366 */       break;
/*      */     case 8:
/*  368 */       typeName = "DOUBLE";
/*  369 */       break;
/*      */     case 6:
/*  371 */       typeName = "FLOAT";
/*  372 */       break;
/*      */     case 4:
/*  374 */       typeName = "INTEGER";
/*  375 */       break;
/*      */     case 7:
/*  377 */       typeName = "REAL";
/*  378 */       break;
/*      */     case 93:
/*  380 */       typeName = "TIMESTAMP";
/*  381 */       break;
/*      */     case 91:
/*  383 */       typeName = "DATE";
/*  384 */       break;
/*      */     default:
/*  386 */       typeName = this.curEncoding;
/*      */     }
/*      */ 
/*  389 */     return typeName;
/*      */   }
/*      */ 
/*      */   public List queryAllList(String sqlStr) throws UnsupportedEncodingException, SQLException {
/*  393 */     List result = new LinkedList();
/*  394 */     sqlStr = StringEncoding.convert2Db(sqlStr, this.curEncoding);
/*  395 */     this.logger.debug("-----queryAllList,this=" + this + ",sql=[" + sqlStr + "]");
/*      */ 
/*  399 */     PreparedStatement ps = null;
/*  400 */     ResultSet rs = null;
/*  401 */     Connection conn = null;
/*      */     try {
/*  403 */       conn = getJdbcTemplate().getDataSource().getConnection();
/*  404 */       ps = conn.prepareStatement(sqlStr);
/*  405 */       rs = ps.executeQuery();
/*  406 */       while (rs.next())
/*  407 */         result.add(mapRow(rs));
/*      */     }
/*      */     catch (SQLException e) {
/*  410 */       e.printStackTrace();
/*  411 */       throw e;
/*      */     } finally {
/*      */       try {
/*  414 */         if (null != rs) {
/*  415 */           rs.close();
/*      */         }
/*  417 */         if (null != ps) {
/*  418 */           ps.close();
/*      */         }
/*  420 */         if (null != conn)
/*  421 */           conn.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  424 */         e.printStackTrace();
/*  425 */         throw e;
/*      */       }
/*      */     }
/*  428 */     return result;
/*      */   }
/*      */ 
/*      */   public Object mapRow(ResultSet rs)
/*      */     throws SQLException, UnsupportedEncodingException
/*      */   {
/*  441 */     ResultSetMetaData md = rs.getMetaData();
/*  442 */     int colCount = md.getColumnCount() + 1;
/*  443 */     Map row = new LinkedHashMap();
/*  444 */     int type = -1;
/*  445 */     for (int i = 1; i < colCount; i++) {
/*  446 */       type = md.getColumnType(i);
/*  447 */       if ((type == 2) || (type == 3) || (type == -5) || (type == 8) || (type == 6) || (type == 4) || (type == 7))
/*      */       {
/*  450 */         if (null == rs.getObject(md.getColumnName(i)))
/*  451 */           row.put(md.getColumnName(i), "");
/*      */         else {
/*  453 */           row.put(md.getColumnName(i), rs.getObject(md.getColumnName(i)));
/*      */         }
/*      */       }
/*  456 */       else if (type == 93) {
/*  457 */         if (rs.getTimestamp(i) != null)
/*  458 */           row.put(md.getColumnName(i), timeformat.format(rs.getTimestamp(i)));
/*      */         else
/*  460 */           row.put(md.getColumnName(i), "");
/*      */       }
/*  462 */       else if (type == 91) {
/*  463 */         if (rs.getDate(i) != null)
/*  464 */           row.put(md.getColumnName(i), dateformat.format(rs.getDate(i)));
/*      */         else
/*  466 */           row.put(md.getColumnName(i), "");
/*      */       }
/*      */       else {
/*  469 */         row.put(md.getColumnName(i), StringEncoding.convert2GBK(rs.getObject(md.getColumnName(i)), this.curEncoding));
/*      */       }
/*      */     }
/*      */ 
/*  473 */     return row;
/*      */   }
/*      */ 
/*      */   public int queryForInt(String sql)
/*      */   {
/*  484 */     log.debug("-----queryForInt,this=" + this);
/*  485 */     sql = StringEncoding.convert2Db(sql, this.curEncoding);
/*  486 */     return super.getJdbcTemplate().queryForInt(sql);
/*      */   }
/*      */ 
/*      */   private void convert(List list)
/*      */     throws SQLException
/*      */   {
/*  497 */     for (int i = 0; i < list.size(); i++) {
/*  498 */       Map map = (Map)list.get(i);
/*      */ 
/*  500 */       Iterator it = map.keySet().iterator();
/*  501 */       while (it.hasNext()) {
/*  502 */         String key = (String)it.next();
/*  503 */         String value = StringEncoding.convert2GBK(String.valueOf(map.get(key)), this.curEncoding);
/*      */ 
/*  505 */         map.put(key, value);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public List queryForList(String sql)
/*      */     throws SQLException
/*      */   {
/*  521 */     sql = StringEncoding.convert2Db(sql, this.curEncoding);
/*  522 */     log.debug("queryForList:" + new Date());
/*  523 */     List list = super.getJdbcTemplate().queryForList(sql);
/*  524 */     log.debug("queryForList:" + new Date());
/*      */ 
/*  527 */     if (!StringEncoding.isGBK(this.curEncoding)) {
/*  528 */       convert(list);
/*      */     }
/*  530 */     return list;
/*      */   }
/*      */ 
/*      */   public DataSource getDataSourceFromJndi(String jndiName)
/*      */     throws NamingException
/*      */   {
/*  542 */     Assert.hasText(jndiName, "JNDI name can not be empty ");
/*      */ 
/*  544 */     log.debug("jndiName:" + jndiName);
/*  545 */     String prefix = "java:comp/env/";
/*  546 */     String app_server_type = Configure.getInstance().getProperty("APP_SERVER_TYPE");
/*  547 */     if (app_server_type == null) {
/*  548 */       log.warn("app_server_type is null, set to tomcat!!!");
/*  549 */       app_server_type = "tomcat";
/*      */     }
/*  551 */     log.debug("prefix:" + prefix);
/*  552 */     log.debug("app_server_type:" + app_server_type);
/*      */ 
/*  554 */     if (needPrefix(app_server_type)) {
/*  555 */       if (!jndiName.startsWith(prefix)) {
/*  556 */         jndiName = prefix + jndiName;
/*  557 */         log.debug("jndiName1:" + jndiName);
/*      */       }
/*      */     }
/*  560 */     else if (jndiName.startsWith(prefix)) {
/*  561 */       jndiName = jndiName.substring(prefix.length());
/*  562 */       log.debug("jndiName2:" + jndiName);
/*      */     }
/*      */     try
/*      */     {
/*  566 */       return (DataSource)new JndiTemplate().lookup(jndiName); } catch (NamingException ex) {
/*      */     }
/*  568 */     throw new NamingException("Search JNDI Data Source Error:[" + jndiName + "]");
/*      */   }
/*      */ 
/*      */   private boolean needPrefix(String serverType)
/*      */   {
/*  578 */     if (serverType == null) {
/*  579 */       log.warn("serverType is null, return true!!!");
/*  580 */       return true;
/*      */     }
/*  582 */     boolean result = true;
/*  583 */     String[] noPrefixServers = { "weblogic", "websphere" };
/*  584 */     List list = Arrays.asList(noPrefixServers);
/*  585 */     if (list.contains(serverType.toLowerCase())) {
/*  586 */       result = false;
/*      */     }
/*  588 */     return result;
/*      */   }
/*      */ 
/*      */   public String getSqlColumnType(String sqlString)
/*      */     throws Exception
/*      */   {
/*  602 */     StringBuffer sb = new StringBuffer();
/*  603 */     sb.append("select * from (");
/*  604 */     sb.append(sqlString);
/*  605 */     if ("ORACLE".equals(getDbType()))
/*  606 */       sb.append(")  where 1=2");
/*      */     else {
/*  608 */       sb.append(") as ta where 1=2");
/*      */     }
/*  610 */     log.debug("----sql=" + sb.toString());
/*      */ 
/*  612 */     PreparedStatement ps = null;
/*  613 */     ResultSet rs = null;
/*  614 */     Connection conn = null;
/*  615 */     ResultSetMetaData md = null;
/*  616 */     StringBuffer sbType = new StringBuffer();
/*      */     try {
/*  618 */       conn = getJdbcTemplate().getDataSource().getConnection();
/*  619 */       ps = conn.prepareStatement(sb.toString());
/*  620 */       rs = ps.executeQuery();
/*  621 */       md = rs.getMetaData();
/*  622 */       int colCount = md.getColumnCount();
/*  623 */       for (int i = 0; i < colCount; i++) {
/*  624 */         int type = md.getColumnType(i + 1);
/*  625 */         sbType.append(md.getColumnName(i + 1).toLowerCase());
/*  626 */         if ((type == 2) || (type == 3) || (type == -5) || (type == 8) || (type == 6) || (type == 4) || (type == 7) || (type == 5))
/*      */         {
/*  630 */           sbType.append(":number");
/*  631 */         } else if ((type == 91) || (type == 92) || (type == 93))
/*      */         {
/*  633 */           sbType.append(":date");
/*      */         }
/*  635 */         else sbType.append(":varchar");
/*      */ 
/*  637 */         if (i + 1 < colCount)
/*  638 */           sbType.append(",");
/*      */       }
/*      */     }
/*      */     catch (SQLException e) {
/*  642 */       throw e;
/*      */     } finally {
/*      */       try {
/*  645 */         if (null != rs) {
/*  646 */           rs.close();
/*      */         }
/*  648 */         if (null != ps) {
/*  649 */           ps.close();
/*      */         }
/*  651 */         if (null != conn)
/*  652 */           conn.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  655 */         throw e;
/*      */       }
/*      */     }
/*      */ 
/*  659 */     return sbType.toString();
/*      */   }
/*      */ 
/*      */   public String getDatabaseType(String jndiName)
/*      */     throws NamingException, SQLException
/*      */   {
/*  672 */     String dbType = "";
/*  673 */     DataSource ds = getDataSourceFromJndi(jndiName);
/*  674 */     Connection connection = null;
/*      */     try {
/*  676 */       connection = ds.getConnection();
/*  677 */       dbType = connection.getMetaData().getDatabaseProductName();
/*      */     } catch (Exception ex) {
/*  679 */       ex.printStackTrace();
/*      */     } finally {
/*  681 */       if (connection != null) {
/*  682 */         connection.close();
/*      */       }
/*      */     }
/*  685 */     log.debug("jndiName=[" + jndiName + "],dbType=[" + dbType + "]");
/*  686 */     return dbType;
/*      */   }
/*      */ 
/*      */   public int queryForCountByTable(String tableName)
/*      */   {
/*  696 */     Assert.hasText(tableName, "table name can not be empty");
/*      */ 
/*  698 */     log.debug("-----queryForCountByTable,this=" + this);
/*  699 */     int count = 0;
/*  700 */     String sql = "select count(*) cnt from " + tableName;
/*  701 */     count = getJdbcTemplate().queryForInt(sql);
/*  702 */     log.debug("queryForCount sql=" + sql + ", count=" + count);
/*  703 */     return count;
/*      */   }
/*      */ 
/*      */   public int queryForCount(String sql)
/*      */   {
/*  713 */     Assert.hasText(sql, "sql can not be empty");
/*      */ 
/*  715 */     log.debug("-----queryForCount,this=" + this);
/*  716 */     int count = 0;
/*  717 */     String viewName = "view_" + System.currentTimeMillis();
/*      */     try {
/*  719 */       int idx = StringUtil.getPosNotIn(sql, "order by", '(', ')');
/*  720 */       if (idx > 0) {
/*  721 */         sql = " " + sql.substring(0, idx);
/*      */       }
/*      */ 
/*  724 */       idx = StringUtil.getPosNotIn(sql, "fetch first", '(', ')');
/*  725 */       if (idx > 0) {
/*  726 */         int idx2 = StringUtil.getPosNotIn(sql, "rows only", '(', ')');
/*  727 */         if (idx2 > idx) {
/*  728 */           String countStr = sql.substring(idx + "fetch first".length(), idx2);
/*  729 */           return Integer.parseInt(countStr.trim());
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  733 */       e.printStackTrace();
/*      */     }
/*  735 */     getJdbcTemplate().execute("create view " + viewName + " as " + sql);
/*  736 */     count = getJdbcTemplate().queryForInt("select count(*) from " + viewName);
/*      */ 
/*  738 */     getJdbcTemplate().execute("drop view " + viewName);
/*  739 */     log.debug("------------------queryForCount sql=" + sql + ", count=" + count);
/*      */ 
/*  741 */     return count;
/*      */   }
/*      */ 
/*      */   public boolean validateTable(String tableName)
/*      */   {
/*  748 */     String sql = "SELECT 1 FROM " + tableName;
/*  749 */     return verifyJNDI(sql);
/*      */   }
/*      */ 
/*      */   public int getMaxTableId(String idCol, String tableName)
/*      */   {
/*  764 */     Map map = null;
/*  765 */     Sqlca sqlca = null;
/*  766 */     StringBuffer sb = new StringBuffer("select max(");
/*      */     try {
/*  768 */       sqlca = new Sqlca(getConnection());
/*  769 */       sb.append(sqlca.getSql_charToint(idCol));
/*  770 */       sb.append(") mid from ");
/*  771 */       sb.append(tableName);
/*  772 */       map = super.getJdbcTemplate().queryForMap(sb.toString());
/*      */     }
/*      */     catch (Exception e) {
/*  775 */       e.printStackTrace();
/*      */     } finally {
/*  777 */       if (sqlca != null)
/*      */       {
/*  779 */         sqlca.closeAll();
/*      */       }
/*      */     }
/*  782 */     if ((null == map) || (null == map.get("MID"))) {
/*  783 */       return 1;
/*      */     }
/*  785 */     return Integer.valueOf(map.get("MID").toString()).intValue();
/*      */   }
/*      */ 
/*      */   public boolean verifyJNDI(String sql)
/*      */   {
/*  801 */     log.debug("-------testSql," + new Date());
/*  802 */     log.debug("-------jnidName," + getJndiName());
/*  803 */     Assert.hasText(getJndiName());
/*  804 */     boolean ret = false;
/*  805 */     String[] jndis = parseJndiNames();
/*  806 */     log.debug("-------jndis.length," + jndis.length);
/*      */     try
/*      */     {
/*  809 */       if (jndis.length == 1)
/*      */       {
/*  811 */         if (!StringUtils.hasText(this.curEncoding)) {
/*  812 */           this.curEncoding = (this.encodingMap.get(jndis[0]) == null ? "" : String.valueOf(this.encodingMap.get(jndis[0])));
/*      */         }
/*      */ 
/*  815 */         DataSource ds = getDataSourceFromJndi(jndis[0]);
/*  816 */         setDataSource(ds);
/*  817 */         return true;
/*      */       }
/*      */ 
/*  820 */       sql = StringEncoding.convert2Db(sql, this.curEncoding);
/*      */ 
/*  822 */       for (int i = 0; i < jndis.length; i++) {
/*  823 */         String jndi = jndis[i].trim();
/*  824 */         log.debug("baseDao,jndi=[" + jndi + "]" + new Date());
/*  825 */         DataSource ds = getDataSourceFromJndi(jndi);
/*  826 */         log.debug("baseDao,jndi=[" + jndi + "]" + new Date());
/*  827 */         setDataSource(ds);
/*      */ 
/*  830 */         if (!StringUtils.hasText(this.curEncoding)) {
/*  831 */           this.curEncoding = (this.encodingMap.get(jndi) == null ? "" : String.valueOf(this.encodingMap.get(jndi)));
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/*  836 */           log.debug("before execute," + new Date());
/*  837 */           getJdbcTemplate().execute(sql);
/*  838 */           log.debug("after execute," + new Date());
/*  839 */           setJndiName(jndi);
/*  840 */           log.debug("jndi:[" + jndi + "],dbEncoding=[" + this.curEncoding + "],sql [" + sql + "] Testing completed ." + new Date());
/*      */         }
/*      */         catch (DataAccessException ex)
/*      */         {
/*  845 */           log.warn("jndi:[" + jndi + "],sql [" + sql + "]  execution error ...");
/*      */         }
/*      */       }
/*  848 */       ret = true;
/*      */     } catch (Exception e) {
/*  850 */       log.warn("sql [" + sql + "] *NOT* valid." + e.getMessage());
/*  851 */       e.printStackTrace();
/*      */     }
/*  853 */     return ret;
/*      */   }
/*      */ 
/*      */   private String[] parseJndiNames()
/*      */   {
/*  862 */     Assert.hasText(this.jndiName, "JNDI data source is not configured !!!");
/*      */ 
/*  864 */     String[] jndis = { this.jndiName };
/*  865 */     if (this.jndiName.indexOf(this.delimeter[0]) > 0)
/*  866 */       jndis = this.jndiName.split(this.delimeter[0]);
/*  867 */     else if (this.jndiName.indexOf(this.delimeter[1]) > 0) {
/*  868 */       jndis = this.jndiName.split(this.delimeter[1]);
/*      */     }
/*  870 */     return jndis;
/*      */   }
/*      */ 
/*      */   public void setJndiName(String jndiName)
/*      */   {
/*  881 */     this.jndiName = jndiName;
/*      */   }
/*      */ 
/*      */   public String getJndiName()
/*      */   {
/*  891 */     return this.jndiName;
/*      */   }
/*      */ 
/*      */   public void setDbEncoding(Map encodingMap)
/*      */   {
/*  902 */     this.encodingMap = encodingMap;
/*      */   }
/*      */ 
/*      */   public Map getDbEncoding()
/*      */   {
/*  912 */     return this.encodingMap;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  917 */     return "{jndiName:" + this.jndiName + ",dbEncoding:" + this.curEncoding + "}";
/*      */   }
/*      */ 
/*      */   public String getCurEncoding()
/*      */   {
/*  928 */     return this.curEncoding;
/*      */   }
/*      */ 
/*      */   public void setCurEncoding(String curEncoding)
/*      */   {
/*  939 */     this.curEncoding = curEncoding;
/*      */   }
/*      */ 
/*      */   public boolean connectDb(String jndiName)
/*      */   {
/*  950 */     setJndiName(jndiName);
/*      */ 
/*  953 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean connectDb(String jndiName, String curEncoding) throws NamingException
/*      */   {
/*  958 */     setJndiName(jndiName);
/*  959 */     setCurEncoding(curEncoding);
/*  960 */     setDataSource(getDataSourceFromJndi(jndiName));
/*  961 */     return false;
/*      */   }
/*      */ 
/*      */   public String getDbType()
/*      */   {
/*  970 */     Connection conn = null;
/*      */     try {
/*  972 */       conn = getJdbcTemplate().getDataSource().getConnection();
/*  973 */       DatabaseMetaData metaData = conn.getMetaData();
/*  974 */       String dbname = metaData.getDatabaseProductName().toUpperCase();
/*      */       String str1;
/*  975 */       if (dbname.contains("DB2"))
/*  976 */         return "DB2";
/*  977 */       if (dbname.contains("ORACLE"))
/*  978 */         return "ORACLE";
/*      */     } catch (SQLException ex) {
/*      */     }
/*      */     finally {
/*  982 */       if (conn != null)
/*      */         try {
/*  984 */           conn.close();
/*      */         }
/*      */         catch (Exception ex) {
/*      */         }
/*      */     }
/*  989 */     return "unknown";
/*      */   }
/*      */ 
/*      */   public static void main(String[] args) throws Exception {
/*  993 */     String str = "";
/*  994 */     String sql = "select * from user_user fetch first 2000 rows only";
/*  995 */     int idx = StringUtil.getPosNotIn(sql, "fetch first", '(', ')');
/*  996 */     if (idx > 0) {
/*  997 */       int idx2 = StringUtil.getPosNotIn(sql, "rows only", '(', ')');
/*  998 */       str = sql.substring(idx + "fetch first".length(), idx2);
/*      */     }
/* 1000 */     System.out.println("[" + Integer.parseInt(str.trim()) + "]");
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.database.spring.BaseJdbcDaoSupport
 * JD-Core Version:    0.6.2
 */
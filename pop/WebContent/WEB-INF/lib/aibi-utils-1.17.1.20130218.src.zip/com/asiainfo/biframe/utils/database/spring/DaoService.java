/*     */ package com.asiainfo.biframe.utils.database.spring;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class DaoService
/*     */ {
/*     */   public static final String para_jndiName = "jndi";
/*     */   public static final String para_dbEncoding = "dbEncoding";
/*  25 */   private static Logger log = Logger.getLogger(DaoService.class);
/*     */ 
/*  27 */   private BaseJdbcDaoSupport baseDao = new BaseJdbcDaoSupport();
/*     */   private String jndiName;
/*  36 */   private Map encodingMap = new HashMap();
/*     */ 
/*     */   public Map getDbEncoding()
/*     */   {
/*  45 */     return this.encodingMap;
/*     */   }
/*     */ 
/*     */   public String getJndiName()
/*     */   {
/*  54 */     return this.jndiName;
/*     */   }
/*     */ 
/*     */   public void setDaoSupport(BaseJdbcDaoSupport baseDao) {
/*  58 */     this.baseDao = baseDao;
/*     */   }
/*     */ 
/*     */   public BaseJdbcDaoSupport getDaoSupport()
/*     */   {
/*  67 */     return this.baseDao;
/*     */   }
/*     */ 
/*     */   public void setJndiName(String _jndiName)
/*     */   {
/*  77 */     this.jndiName = _jndiName;
/*  78 */     this.baseDao.setJndiName(_jndiName);
/*     */   }
/*     */ 
/*     */   public void setDbEncoding(Map _encodingMap)
/*     */   {
/*  87 */     this.encodingMap = _encodingMap;
/*  88 */     this.baseDao.setDbEncoding(_encodingMap);
/*     */   }
/*     */ 
/*     */   public void setDbEncoding(String _dbEncoding)
/*     */   {
/*  97 */     this.baseDao.setDbEncoding(_dbEncoding);
/*     */   }
/*     */ 
/*     */   public Map getEncodingMap() {
/* 101 */     return this.encodingMap;
/*     */   }
/*     */ 
/*     */   public void setEncodingMap(Map encodingMap) {
/* 105 */     this.encodingMap = encodingMap;
/*     */   }
/*     */ 
/*     */   public void initialService(Map parameter)
/*     */   {
/* 115 */     if ((parameter != null) && (parameter.get("jndi") != null) && (StringUtils.hasText((String)parameter.get("jndi"))) && (!((String)parameter.get("jndi")).trim().equals("null")))
/*     */     {
/* 119 */       log.info("in parameter, jndi=[" + parameter.get("jndi") + "],dbEncoding=[" + parameter.get("dbEncoding") + "]");
/* 120 */       String jndiName = (String)parameter.get("jndi");
/* 121 */       setJndiName(jndiName);
/* 122 */       log.info("set jndi from tag=[" + jndiName + "]");
/*     */ 
/* 125 */       String dbEncoding = String.valueOf(parameter.get("dbEncoding"));
/* 126 */       if (StringUtils.hasText(dbEncoding)) {
/* 127 */         setDbEncoding(dbEncoding);
/* 128 */         log.info("set dbEncoding from tag=[" + dbEncoding + "]");
/*     */       } else {
/* 130 */         dbEncoding = String.valueOf(getEncodingMap().get(jndiName));
/* 131 */         log.info("set dbEncoding from spring=[" + dbEncoding + "]");
/* 132 */         setDbEncoding(dbEncoding);
/*     */       }
/*     */     } else {
/* 135 */       log.info("set jndi from spring=[" + this.jndiName + "]");
/* 136 */       setJndiName(this.jndiName);
/*     */     }
/*     */ 
/* 139 */     setDbEncoding(this.encodingMap);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.database.spring.DaoService
 * JD-Core Version:    0.6.2
 */
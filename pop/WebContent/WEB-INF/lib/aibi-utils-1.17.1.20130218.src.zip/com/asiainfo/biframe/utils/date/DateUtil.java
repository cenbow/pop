/*      */ package com.asiainfo.biframe.utils.date;
/*      */ 
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Vector;
/*      */ 
/*      */ public class DateUtil
/*      */ {
/*      */   public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
/*      */   public static final String YYYYMMDD_HHMMSS = "yyyyMMdd_HHmmss";
/*      */   public static final String YYYYMMDD_HHMM = "yyyyMMdd HHmm";
/*      */   public static final String YYYY_MM_DD = "yyyy-MM-dd";
/*      */   public static final String YYYY_MM = "yyyy-MM";
/*      */   public static final String YYYYMMDD = "yyyyMMdd";
/*      */   public static final String YYYYMM = "yyyyMM";
/*      */   public static final String YYYY = "yyyy";
/*      */   public static final String MM_dd = "MM-dd";
/*      */   public static final String MMdd = "MMdd";
/*      */   public static final String MM = "MM";
/*      */   public static final String HH_mm = "HH:mm";
/*      */   public static final String HHmm = "HHmm";
/*      */ 
/*      */   public static String date2String(java.util.Date dDate, String sFormat)
/*      */   {
/*  110 */     if (dDate == null) {
/*  111 */       return "";
/*      */     }
/*  113 */     if (StringUtil.isEmpty(sFormat)) {
/*  114 */       sFormat = "yyyy-MM-dd";
/*      */     }
/*  116 */     SimpleDateFormat sdf = new SimpleDateFormat(sFormat);
/*  117 */     return sdf.format(dDate);
/*      */   }
/*      */ 
/*      */   public static java.util.Date string2Date(String str, String format)
/*      */   {
/*  133 */     if (StringUtil.isEmpty(str)) {
/*  134 */       return null;
/*      */     }
/*  136 */     java.util.Date result = null;
/*  137 */     if (StringUtil.isEmpty(format))
/*  138 */       return string2Date(str);
/*      */     try
/*      */     {
/*  141 */       DateFormat mFormat = new SimpleDateFormat(format);
/*  142 */       result = mFormat.parse(str);
/*      */     } catch (Exception e) {
/*  144 */       e.printStackTrace();
/*      */     }
/*  146 */     return result;
/*      */   }
/*      */ 
/*      */   public static java.util.Date string2Date(String s)
/*      */   {
/*  159 */     if (StringUtil.isEmpty(s)) {
/*  160 */       return null;
/*      */     }
/*  162 */     java.util.Date result = null;
/*      */     try {
/*  164 */       DateFormat format = null;
/*  165 */       if (s.length() > 15)
/*  166 */         format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  167 */       else if (s.length() > 8)
/*  168 */         format = new SimpleDateFormat("yyyy-MM-dd");
/*  169 */       else if (s.length() > 4)
/*  170 */         format = new SimpleDateFormat("yyyy-MM");
/*      */       else {
/*  172 */         format = new SimpleDateFormat("yyyy");
/*      */       }
/*  174 */       result = format.parse(s);
/*      */     } catch (Exception e) {
/*  176 */       e.printStackTrace();
/*      */     }
/*  178 */     return result;
/*      */   }
/*      */ 
/*      */   public static java.sql.Date str2SqlDate(String str, String sFormat)
/*      */   {
/*  192 */     java.util.Date date = string2Date(str, sFormat);
/*  193 */     java.sql.Date sqlDate = new java.sql.Date(date.getTime());
/*  194 */     return sqlDate;
/*      */   }
/*      */ 
/*      */   public static String getCurrentYearMonth()
/*      */   {
/*  204 */     String res = "";
/*  205 */     Calendar caldTmp = Calendar.getInstance();
/*  206 */     caldTmp.setTime(new java.util.Date());
/*  207 */     if (caldTmp.get(2) + 1 < 10) {
/*  208 */       res = caldTmp.get(1) + "0" + (caldTmp.get(2) + 1);
/*      */     }
/*      */     else {
/*  211 */       res = caldTmp.get(1) + "" + (caldTmp.get(2) + 1);
/*      */     }
/*  213 */     return res;
/*      */   }
/*      */ 
/*      */   public static String getCurrentMonth()
/*      */   {
/*  222 */     return getFormatCurrentTime("MM");
/*      */   }
/*      */ 
/*      */   public static String getCurrentYear()
/*      */   {
/*  231 */     return getFormatCurrentTime("yyyy");
/*      */   }
/*      */ 
/*      */   public static String getFormatCurrentTime(String format)
/*      */   {
/*  244 */     return date2String(new java.util.Date(), format);
/*      */   }
/*      */ 
/*      */   public static java.util.Date addMonths(java.util.Date dateInput, int numberOfMonth)
/*      */   {
/*  259 */     if (dateInput == null) {
/*  260 */       return null;
/*      */     }
/*  262 */     Calendar c = Calendar.getInstance();
/*  263 */     c.setTime(dateInput);
/*  264 */     c.add(2, numberOfMonth);
/*  265 */     return c.getTime();
/*      */   }
/*      */ 
/*      */   public static java.util.Date addSecond(java.util.Date dInput, int numberOfSecond)
/*      */   {
/*  280 */     if (dInput == null) {
/*  281 */       return null;
/*      */     }
/*  283 */     Calendar c = Calendar.getInstance();
/*  284 */     c.setTime(dInput);
/*  285 */     c.add(13, numberOfSecond);
/*  286 */     return c.getTime();
/*      */   }
/*      */ 
/*      */   public static java.util.Date nextDate(java.util.Date date, int day)
/*      */   {
/*  297 */     if (date == null) {
/*  298 */       return null;
/*      */     }
/*  300 */     Calendar calendar = Calendar.getInstance();
/*  301 */     calendar.setTime(date);
/*  302 */     calendar.set(5, calendar.get(5) + day);
/*  303 */     return calendar.getTime();
/*      */   }
/*      */ 
/*      */   public static boolean isLeapYear(int theYear)
/*      */   {
/*  316 */     return ((theYear % 4 == 0) && (theYear % 100 != 0)) || (theYear % 400 == 0);
/*      */   }
/*      */ 
/*      */   public static int dateDiff(String type, java.util.Date fromDate, java.util.Date toDate)
/*      */   {
/*  332 */     Calendar fromCalendar = Calendar.getInstance();
/*  333 */     fromCalendar.setTime(fromDate);
/*      */ 
/*  335 */     Calendar toCalendar = Calendar.getInstance();
/*  336 */     toCalendar.setTime(toDate);
/*      */ 
/*  338 */     int fromDay = fromCalendar.get(6);
/*  339 */     int toDay = toCalendar.get(6);
/*  340 */     int fromMonth = fromCalendar.get(2);
/*  341 */     int toMonth = toCalendar.get(2);
/*  342 */     int fromYear = fromCalendar.get(1);
/*  343 */     int toYear = toCalendar.get(1);
/*  344 */     int fromHour = fromCalendar.get(11);
/*  345 */     int toHour = toCalendar.get(11);
/*  346 */     int fromMinute = fromCalendar.get(12);
/*  347 */     int toMinute = toCalendar.get(12);
/*  348 */     int fromSecond = fromCalendar.get(13);
/*  349 */     int toSecond = toCalendar.get(13);
/*      */ 
/*  351 */     int day = 0;
/*  352 */     int month = 0;
/*  353 */     int minute = 0;
/*  354 */     int second = 0;
/*  355 */     int hour = 0;
/*      */ 
/*  357 */     for (int i = fromYear; i < toYear; i++)
/*      */     {
/*      */       int noOfDay;
/*      */       int noOfDay;
/*  359 */       if (isLeapYear(i))
/*  360 */         noOfDay = 366;
/*      */       else
/*  362 */         noOfDay = 365;
/*  363 */       day += noOfDay;
/*  364 */       hour += noOfDay * 24;
/*  365 */       minute += noOfDay * 24 * 60;
/*  366 */       second += minute * 60;
/*  367 */       month += 12;
/*      */     }
/*  369 */     int daydiff = toDay - (fromDay - day);
/*  370 */     int hourdiff = toHour - (fromHour - hour) + daydiff * 24;
/*  371 */     int minutediff = toMinute - (fromMinute - minute) + hourdiff * 60;
/*  372 */     int secdiff = toSecond - (fromSecond - second) + minutediff * 60;
/*  373 */     if (type.equalsIgnoreCase("yyyy"))
/*  374 */       return toYear - fromYear;
/*  375 */     if (type.equalsIgnoreCase("m"))
/*  376 */       return toMonth - (fromMonth - month);
/*  377 */     if (type.equalsIgnoreCase("d"))
/*  378 */       return daydiff;
/*  379 */     if (type.equalsIgnoreCase("h"))
/*  380 */       return hourdiff;
/*  381 */     if (type.equalsIgnoreCase("n"))
/*  382 */       return minutediff;
/*  383 */     if (type.equalsIgnoreCase("s")) {
/*  384 */       return secdiff;
/*      */     }
/*  386 */     return 0;
/*      */   }
/*      */ 
/*      */   public static int dateDiffNoTime(java.util.Date fromDate, java.util.Date toDate)
/*      */   {
/*  402 */     Calendar fromCalendar = Calendar.getInstance();
/*  403 */     fromCalendar.setTime(fromDate);
/*      */ 
/*  405 */     Calendar toCalendar = Calendar.getInstance();
/*  406 */     toCalendar.setTime(toDate);
/*      */ 
/*  408 */     int fromDay = fromCalendar.get(6);
/*  409 */     int toDay = toCalendar.get(6);
/*  410 */     int fromMonth = fromCalendar.get(2);
/*  411 */     int toMonth = toCalendar.get(2);
/*  412 */     int fromYear = fromCalendar.get(1);
/*  413 */     int toYear = toCalendar.get(1);
/*      */ 
/*  416 */     int fromDateVal = fromYear * 10000 + fromMonth * 100 + fromDay * 1;
/*      */ 
/*  418 */     int toDateVal = toYear * 10000 + toMonth * 100 + toDay * 1;
/*      */ 
/*  420 */     return fromDateVal - toDateVal;
/*      */   }
/*      */ 
/*      */   public static String getFirstDateOfMonth(String strYYYYMMDD)
/*      */   {
/*  432 */     Calendar caldTmp = Calendar.getInstance();
/*      */ 
/*  434 */     caldTmp.set(getIntYearOfDate(strYYYYMMDD), getIntMonthOfDate(strYYYYMMDD) - 1, 1);
/*      */ 
/*  436 */     return date2String(caldTmp.getTime(), "yyyy-MM-dd");
/*      */   }
/*      */ 
/*      */   public static String getLastDateOfMonth(String strYYYYMMDD)
/*      */   {
/*  448 */     Calendar caldTmp = Calendar.getInstance();
/*      */ 
/*  450 */     caldTmp.set(getIntYearOfDate(strYYYYMMDD), getIntMonthOfDate(strYYYYMMDD) - 1, 1);
/*      */ 
/*  453 */     caldTmp.add(2, 1);
/*      */ 
/*  455 */     caldTmp.add(5, -1);
/*  456 */     return date2String(caldTmp.getTime(), "yyyy-MM-dd");
/*      */   }
/*      */ 
/*      */   public static String getMondayOfThisWeek(String strYYYYMMDD)
/*      */   {
/*  470 */     Calendar caldTmp = Calendar.getInstance();
/*      */ 
/*  472 */     caldTmp.set(getIntYearOfDate(strYYYYMMDD), getIntMonthOfDate(strYYYYMMDD) - 1, getIntDayOfDate(strYYYYMMDD));
/*      */ 
/*  475 */     int nDayOfWeek = caldTmp.get(7);
/*      */ 
/*  477 */     caldTmp.add(5, -(caldTmp.get(7) - 1));
/*      */ 
/*  482 */     if (nDayOfWeek == 1)
/*  483 */       caldTmp.add(5, -6);
/*      */     else {
/*  485 */       caldTmp.add(5, 1);
/*      */     }
/*  487 */     return date2String(caldTmp.getTime(), "yyyy-MM-dd");
/*      */   }
/*      */ 
/*      */   public static String getSundayOfThisWeek(String strYYYYMMDD)
/*      */   {
/*  501 */     String strThisWeekFirstDate = getMondayOfThisWeek(strYYYYMMDD);
/*  502 */     return date2String(getOffsetDate(strThisWeekFirstDate, 6, "day"), "yyyy-MM-dd");
/*      */   }
/*      */ 
/*      */   public static String getMondayOfWeek(String strYYYYMMDD, int weekIndex)
/*      */   {
/*  516 */     int nYear = 0;
/*  517 */     int nMonth = 0;
/*  518 */     int nDay = 0;
/*  519 */     Calendar caldTmp = Calendar.getInstance();
/*  520 */     nYear = getIntYearOfDate(strYYYYMMDD);
/*  521 */     nMonth = getIntMonthOfDate(strYYYYMMDD);
/*  522 */     nDay = getIntDayOfDate(strYYYYMMDD);
/*  523 */     caldTmp.set(nYear, nMonth - 1, 1);
/*      */ 
/*  527 */     int dayOfWeek = caldTmp.get(7);
/*      */ 
/*  529 */     if ((dayOfWeek == 1) || (dayOfWeek == 2)) {
/*  530 */       caldTmp.set(4, weekIndex);
/*      */     }
/*      */     else {
/*  533 */       caldTmp.set(4, weekIndex + 1);
/*      */     }
/*      */ 
/*  536 */     caldTmp.set(7, 2);
/*      */ 
/*  538 */     String tmpDate = date2String(caldTmp.getTime(), "yyyy-MM-dd");
/*      */ 
/*  543 */     return tmpDate;
/*      */   }
/*      */ 
/*      */   public static int getWeekCountOfMonth(String strYYYYMMDD)
/*      */   {
/*  555 */     int res = 1;
/*      */ 
/*  558 */     String lastDate = getLastDateOfMonth(strYYYYMMDD);
/*      */ 
/*  560 */     res = getWeekIndexOfMonth(lastDate);
/*  561 */     return res;
/*      */   }
/*      */ 
/*      */   public static int getDaysOfMonth(int yyyy, int mm)
/*      */   {
/*  576 */     Calendar iCal = Calendar.getInstance();
/*  577 */     iCal.set(yyyy, mm, 1);
/*  578 */     iCal.add(5, -1);
/*  579 */     return iCal.get(5);
/*      */   }
/*      */ 
/*      */   public static int getDaysOfCurMonth()
/*      */   {
/*  587 */     int curyear = new Integer(getCurrentYear()).intValue();
/*  588 */     int curMonth = new Integer(getCurrentMonth()).intValue();
/*  589 */     int[] mArray = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
/*      */ 
/*  592 */     if ((curyear % 400 == 0) || ((curyear % 100 != 0) && (curyear % 4 == 0)))
/*      */     {
/*  594 */       mArray[1] = 29;
/*      */     }
/*  596 */     return mArray[(curMonth - 1)];
/*      */   }
/*      */ 
/*      */   public static int getDayIndexOfWeek(int yyyy, int mm, int dd)
/*      */   {
/*  612 */     Calendar iCal = Calendar.getInstance();
/*  613 */     iCal.set(yyyy, mm - 1, dd - 1);
/*  614 */     return iCal.get(7);
/*      */   }
/*      */ 
/*      */   public static int getDayIndexOfWeek(String strYYYYMMDD)
/*      */   {
/*  626 */     int res = 1;
/*  627 */     int nYear = 0;
/*  628 */     int nMonth = 0;
/*  629 */     int nDay = 0;
/*  630 */     Calendar caldTmp = Calendar.getInstance();
/*  631 */     nYear = getIntYearOfDate(strYYYYMMDD);
/*  632 */     nMonth = getIntMonthOfDate(strYYYYMMDD);
/*  633 */     nDay = getIntDayOfDate(strYYYYMMDD);
/*  634 */     caldTmp.set(nYear, nMonth - 1, nDay);
/*      */ 
/*  636 */     res = caldTmp.get(7) - 1;
/*      */ 
/*  638 */     if (res == 0)
/*  639 */       res = 7;
/*  640 */     return res;
/*      */   }
/*      */ 
/*      */   public static int getWeekIndexOfMonth(String strYYYYMMDD)
/*      */   {
/*  653 */     Calendar caldTmp = Calendar.getInstance();
/*      */ 
/*  656 */     caldTmp.setFirstDayOfWeek(2);
/*  657 */     caldTmp.set(getIntYearOfDate(strYYYYMMDD), getIntMonthOfDate(strYYYYMMDD) - 1, getIntDayOfDate(strYYYYMMDD));
/*      */ 
/*  660 */     int nWeekOfMonth = caldTmp.get(4);
/*      */ 
/*  669 */     int nDateDiffNoTime = 0;
/*      */ 
/*  671 */     String strFirstDayOfThisMonth = getFirstDateOfMonth(strYYYYMMDD);
/*      */ 
/*  674 */     String strLastDateOfPreMonth = date2String(getOffsetDate(strFirstDayOfThisMonth, -1, "day"), "yyyy-MM-dd");
/*      */ 
/*  677 */     String strSundayOfLastWeekOfPreMonth = getSundayOfThisWeek(strLastDateOfPreMonth);
/*      */ 
/*  680 */     java.util.Date dParam = string2Date(strYYYYMMDD, "yyyy-MM-dd");
/*  681 */     java.util.Date dSundayOfLastWeekOfPreMonth = string2Date(strSundayOfLastWeekOfPreMonth);
/*  682 */     nDateDiffNoTime = dateDiffNoTime(dParam, dSundayOfLastWeekOfPreMonth);
/*      */ 
/*  684 */     if (nDateDiffNoTime <= 0) {
/*  685 */       return 0;
/*      */     }
/*      */ 
/*  689 */     String strSundayOfFirstDayOfThisMonth = getSundayOfThisWeek(strFirstDayOfThisMonth);
/*      */ 
/*  691 */     java.util.Date dTmp = string2Date(strYYYYMMDD, "yyyy-MM-dd");
/*  692 */     String strStdYYYYMMDD = date2String(dTmp, "yyyy-MM-dd");
/*  693 */     if (strStdYYYYMMDD.compareToIgnoreCase(strSundayOfFirstDayOfThisMonth) == 0)
/*      */     {
/*  696 */       return nWeekOfMonth;
/*      */     }
/*      */ 
/*  700 */     java.util.Date dFistDayOfThisMonth = string2Date(strFirstDayOfThisMonth, "yyyy-MM-dd");
/*      */ 
/*  702 */     nDateDiffNoTime = dateDiffNoTime(dFistDayOfThisMonth, dSundayOfLastWeekOfPreMonth);
/*      */ 
/*  704 */     if (nDateDiffNoTime > 0) {
/*  705 */       return nWeekOfMonth;
/*      */     }
/*  707 */     return nWeekOfMonth - 1;
/*      */   }
/*      */ 
/*      */   public static int getIntYearOfDate(String strYYYYMMDD)
/*      */   {
/*  724 */     return Integer.parseInt(strYYYYMMDD.substring(0, 4));
/*      */   }
/*      */ 
/*      */   public static int getIntMonthOfDate(String strYYYYMMDD)
/*      */   {
/*  736 */     String strIntervalMark = "";
/*  737 */     if (strYYYYMMDD.indexOf("/") > 0)
/*  738 */       strIntervalMark = "/";
/*  739 */     else if (strYYYYMMDD.indexOf("-") > 0) {
/*  740 */       strIntervalMark = "-";
/*      */     }
/*      */ 
/*  743 */     String strMonth = "";
/*  744 */     String strTmp = "";
/*  745 */     int nFirstMarkNum = 0;
/*  746 */     int nSecondMarkNum = 0;
/*  747 */     nFirstMarkNum = strYYYYMMDD.indexOf(strIntervalMark);
/*  748 */     strTmp = strYYYYMMDD.substring(nFirstMarkNum + 1);
/*  749 */     nSecondMarkNum = nFirstMarkNum + strTmp.indexOf(strIntervalMark);
/*  750 */     if ("".equals(strIntervalMark))
/*      */     {
/*  752 */       strMonth = strYYYYMMDD.substring(4, 6);
/*      */     }
/*  754 */     else strMonth = strYYYYMMDD.substring(nFirstMarkNum + 1, nSecondMarkNum + 1);
/*      */ 
/*  757 */     return Integer.parseInt(strMonth);
/*      */   }
/*      */ 
/*      */   public static int getIntDayOfDate(String strYYYYMMDD)
/*      */   {
/*  769 */     String strIntervalMark = "";
/*  770 */     if (strYYYYMMDD.indexOf(" ") > 0)
/*  771 */       strYYYYMMDD = strYYYYMMDD.substring(0, strYYYYMMDD.indexOf(" "));
/*  772 */     if (strYYYYMMDD.indexOf("/") > 0)
/*  773 */       strIntervalMark = "/";
/*  774 */     else if (strYYYYMMDD.indexOf("-") > 0) {
/*  775 */       strIntervalMark = "-";
/*      */     }
/*      */ 
/*  778 */     String strDay = "";
/*  779 */     int nLastMarkNum = 0;
/*  780 */     nLastMarkNum = strYYYYMMDD.lastIndexOf(strIntervalMark);
/*      */ 
/*  782 */     if (strIntervalMark.compareTo("") == 0)
/*      */     {
/*  784 */       strDay = strYYYYMMDD.substring(6);
/*      */     }
/*  786 */     else strDay = strYYYYMMDD.substring(nLastMarkNum + 1);
/*      */ 
/*  788 */     return Integer.parseInt(strDay);
/*      */   }
/*      */ 
/*      */   public static String getMonthName(int mm)
/*      */   {
/*  801 */     if (mm == 1)
/*  802 */       return "jan";
/*  803 */     if (mm == 2)
/*  804 */       return "feb";
/*  805 */     if (mm == 3)
/*  806 */       return "mar";
/*  807 */     if (mm == 4)
/*  808 */       return "apr";
/*  809 */     if (mm == 5)
/*  810 */       return "may";
/*  811 */     if (mm == 6)
/*  812 */       return "jun";
/*  813 */     if (mm == 7)
/*  814 */       return "jul";
/*  815 */     if (mm == 8)
/*  816 */       return "aug";
/*  817 */     if (mm == 9)
/*  818 */       return "sep";
/*  819 */     if (mm == 10)
/*  820 */       return "oct";
/*  821 */     if (mm == 11)
/*  822 */       return "nov";
/*  823 */     if (mm == 12) {
/*  824 */       return "dec";
/*      */     }
/*  826 */     return null;
/*      */   }
/*      */ 
/*      */   public static Vector sortDateVectorAsc(Vector vDate)
/*      */   {
/*  839 */     Vector vSortedDate = new Vector();
/*      */ 
/*  841 */     int nSmallestIndex = 0;
/*  842 */     while (vDate.size() > 0) {
/*  843 */       java.util.Date dDate = getSmallestDate(vDate);
/*  844 */       if (dDate != null) {
/*  845 */         vSortedDate.addElement(dDate);
/*      */       }
/*      */     }
/*  848 */     return vSortedDate;
/*      */   }
/*      */ 
/*      */   private static java.util.Date getSmallestDate(Vector vDate)
/*      */   {
/*  860 */     int nDeleteIndex = -1;
/*  861 */     java.util.Date dDate = getDateObj(2999, 12, 31);
/*  862 */     for (int i = 0; i < vDate.size(); i++) {
/*  863 */       java.util.Date dPrevDate = dDate;
/*  864 */       java.util.Date dCurrDate = (java.util.Date)vDate.elementAt(i);
/*  865 */       if (dCurrDate.before(dPrevDate)) {
/*  866 */         dDate = dCurrDate;
/*  867 */         nDeleteIndex = i;
/*      */       }
/*      */     }
/*  870 */     if (nDeleteIndex > -1) {
/*  871 */       return (java.util.Date)vDate.remove(nDeleteIndex);
/*      */     }
/*  873 */     return null;
/*      */   }
/*      */ 
/*      */   public static java.util.Date trimMillis(java.util.Date dDate)
/*      */   {
/*  885 */     if (dDate == null) {
/*  886 */       return null;
/*      */     }
/*  888 */     Calendar cal = Calendar.getInstance();
/*  889 */     cal.setTime(dDate);
/*  890 */     cal.set(14, 0);
/*  891 */     return cal.getTime();
/*      */   }
/*      */ 
/*      */   public static java.util.Date getOffsetDate(String strYYYYMMDD, int nOffsetNum, String strOffsetUnit)
/*      */   {
/*  909 */     int nYear = 0;
/*  910 */     int nMonth = 0;
/*  911 */     int nDay = 0;
/*  912 */     Calendar caldTmp = Calendar.getInstance();
/*  913 */     nYear = getIntYearOfDate(strYYYYMMDD);
/*  914 */     nMonth = getIntMonthOfDate(strYYYYMMDD);
/*  915 */     nDay = getIntDayOfDate(strYYYYMMDD);
/*  916 */     caldTmp.set(nYear, nMonth - 1, nDay);
/*      */ 
/*  918 */     if ("day".equalsIgnoreCase(strOffsetUnit))
/*  919 */       caldTmp.add(5, nOffsetNum);
/*  920 */     else if ("week".equalsIgnoreCase(strOffsetUnit))
/*  921 */       caldTmp.add(5, nOffsetNum * 7);
/*  922 */     else if ("month".equalsIgnoreCase(strOffsetUnit))
/*  923 */       caldTmp.add(2, nOffsetNum);
/*  924 */     else if ("year".equalsIgnoreCase(strOffsetUnit)) {
/*  925 */       caldTmp.add(1, nOffsetNum);
/*      */     }
/*  927 */     else if ("hour".equalsIgnoreCase(strOffsetUnit)) {
/*  928 */       caldTmp.add(10, nOffsetNum);
/*      */     }
/*      */ 
/*  932 */     return caldTmp.getTime();
/*      */   }
/*      */ 
/*      */   public static String[] getDayList(String beginDate, String endDate)
/*      */   {
/*  946 */     ArrayList theList = new ArrayList();
/*      */ 
/*  949 */     int beginYear = getIntYearOfDate(beginDate);
/*  950 */     int endYear = getIntYearOfDate(endDate);
/*      */ 
/*  952 */     int beginMonth = getIntMonthOfDate(beginDate) - 1;
/*  953 */     int endMonth = getIntMonthOfDate(endDate) - 1;
/*  954 */     int beginDay = getIntDayOfDate(beginDate);
/*  955 */     int endDay = getIntDayOfDate(endDate);
/*      */ 
/*  957 */     GregorianCalendar bCal = new GregorianCalendar(beginYear, beginMonth, beginDay);
/*      */ 
/*  959 */     GregorianCalendar eCal = new GregorianCalendar(endYear, endMonth, endDay);
/*      */ 
/*  961 */     java.util.Date eDate = eCal.getTime();
/*  962 */     java.util.Date bDate = bCal.getTime();
/*      */ 
/*  965 */     while (bDate.compareTo(eDate) <= 0) {
/*  966 */       String tmpDate = date2String(bDate, "yyyy-MM-dd");
/*      */ 
/*  969 */       theList.add(tmpDate);
/*      */ 
/*  971 */       bCal.add(5, 1);
/*  972 */       bDate = bCal.getTime();
/*      */     }
/*  974 */     String[] res = new String[theList.size()];
/*  975 */     res = (String[])theList.toArray(res);
/*  976 */     return res;
/*      */   }
/*      */ 
/*      */   public static String[] getWeekList(String beginDate, String endDate, int beginWeek, int endWeek)
/*      */   {
/*  992 */     ArrayList theList = new ArrayList();
/*      */ 
/*  995 */     int beginYear = getIntYearOfDate(beginDate);
/*  996 */     int endYear = getIntYearOfDate(endDate);
/*      */ 
/*  998 */     int beginMonth = getIntMonthOfDate(beginDate) - 1;
/*  999 */     int endMonth = getIntMonthOfDate(endDate) - 1;
/*      */ 
/* 1001 */     int beginDay = 10;
/* 1002 */     int endDay = 10;
/*      */ 
/* 1004 */     GregorianCalendar bCal = new GregorianCalendar(beginYear, beginMonth, beginDay);
/*      */ 
/* 1006 */     GregorianCalendar eCal = new GregorianCalendar(endYear, endMonth, endDay);
/*      */ 
/* 1008 */     java.util.Date eDate = eCal.getTime();
/* 1009 */     java.util.Date bDate = bCal.getTime();
/*      */ 
/* 1012 */     while (bDate.compareTo(eDate) < 0) {
/* 1013 */       String tmpDate = date2String(bDate, "yyyy-MM-dd");
/*      */ 
/* 1015 */       int weekCntOfMonth = getWeekCountOfMonth(tmpDate);
/*      */ 
/* 1017 */       for (int tmpInt = beginWeek; tmpInt <= weekCntOfMonth; tmpInt++) {
/* 1018 */         String tmpStr = tmpDate.substring(0, 7) + "|" + tmpInt;
/* 1019 */         theList.add(tmpStr);
/*      */       }
/*      */ 
/* 1023 */       beginWeek = 1;
/*      */ 
/* 1026 */       bCal.add(2, 1);
/* 1027 */       bDate = bCal.getTime();
/*      */     }
/*      */ 
/* 1031 */     if (bDate.compareTo(eDate) == 0) {
/* 1032 */       String tmpDate = date2String(bDate, "yyyy-MM-dd");
/*      */ 
/* 1034 */       int weekCntOfMonth = getWeekCountOfMonth(tmpDate);
/*      */ 
/* 1036 */       if (endWeek > weekCntOfMonth)
/* 1037 */         endWeek = weekCntOfMonth;
/* 1038 */       for (int tmpInt = beginWeek; tmpInt <= endWeek; tmpInt++) {
/* 1039 */         String tmpStr = tmpDate.substring(0, 7) + "|" + tmpInt;
/* 1040 */         theList.add(tmpStr);
/*      */       }
/*      */     }
/*      */ 
/* 1044 */     String[] res = new String[theList.size()];
/* 1045 */     res = (String[])theList.toArray(res);
/* 1046 */     return res;
/*      */   }
/*      */ 
/*      */   public static String[] getMonthList(String beginDate, String endDate)
/*      */   {
/* 1058 */     ArrayList theList = new ArrayList();
/*      */ 
/* 1061 */     int beginYear = getIntYearOfDate(beginDate);
/* 1062 */     int endYear = getIntYearOfDate(endDate);
/*      */ 
/* 1064 */     int beginMonth = getIntMonthOfDate(beginDate) - 1;
/* 1065 */     int endMonth = getIntMonthOfDate(endDate) - 1;
/*      */ 
/* 1067 */     int beginDay = 10;
/* 1068 */     int endDay = 10;
/*      */ 
/* 1070 */     GregorianCalendar bCal = new GregorianCalendar(beginYear, beginMonth, beginDay);
/*      */ 
/* 1072 */     GregorianCalendar eCal = new GregorianCalendar(endYear, endMonth, endDay);
/*      */ 
/* 1074 */     java.util.Date eDate = eCal.getTime();
/* 1075 */     java.util.Date bDate = bCal.getTime();
/*      */ 
/* 1078 */     while (bDate.compareTo(eDate) <= 0) {
/* 1079 */       String tmpDate = date2String(bDate, "yyyy-MM-dd");
/* 1080 */       String tmpStr = tmpDate.substring(0, 7);
/*      */ 
/* 1082 */       theList.add(tmpStr);
/*      */ 
/* 1085 */       bCal.add(2, 1);
/* 1086 */       bDate = bCal.getTime();
/*      */     }
/*      */ 
/* 1089 */     String[] res = new String[theList.size()];
/* 1090 */     res = (String[])theList.toArray(res);
/* 1091 */     return res;
/*      */   }
/*      */ 
/*      */   public static String[] getYearList(String beginDate, String endDate)
/*      */   {
/* 1104 */     ArrayList theList = new ArrayList();
/*      */ 
/* 1107 */     int beginYear = getIntYearOfDate(beginDate);
/* 1108 */     int endYear = getIntYearOfDate(endDate);
/*      */ 
/* 1110 */     int beginMonth = 10;
/* 1111 */     int endMonth = 10;
/* 1112 */     int beginDay = 10;
/* 1113 */     int endDay = 10;
/*      */ 
/* 1115 */     GregorianCalendar bCal = new GregorianCalendar(beginYear, beginMonth, beginDay);
/*      */ 
/* 1117 */     GregorianCalendar eCal = new GregorianCalendar(endYear, endMonth, endDay);
/*      */ 
/* 1119 */     java.util.Date eDate = eCal.getTime();
/* 1120 */     java.util.Date bDate = bCal.getTime();
/*      */ 
/* 1123 */     while (bDate.compareTo(eDate) <= 0) {
/* 1124 */       String tmpDate = date2String(bDate, "yyyy-MM-dd");
/* 1125 */       String tmpStr = tmpDate.substring(0, 4);
/*      */ 
/* 1127 */       theList.add(tmpStr);
/*      */ 
/* 1130 */       bCal.add(1, 1);
/* 1131 */       bDate = bCal.getTime();
/*      */     }
/*      */ 
/* 1134 */     String[] res = new String[theList.size()];
/* 1135 */     res = (String[])theList.toArray(res);
/* 1136 */     return res;
/*      */   }
/*      */ 
/*      */   public static String formatDate(String date)
/*      */   {
/* 1148 */     String res = "";
/* 1149 */     if (date == null) {
/* 1150 */       return res;
/*      */     }
/*      */     try
/*      */     {
/* 1154 */       if (date.length() == 5)
/*      */       {
/* 1156 */         int month = Integer.parseInt(date.substring(0, 2));
/* 1157 */         int day = Integer.parseInt(date.substring(3));
/* 1158 */         res = month + "-" + day;
/*      */       }
/* 1161 */       else if (date.length() == 7) {
/* 1162 */         int year = Integer.parseInt(date.substring(0, 4));
/* 1163 */         int month = Integer.parseInt(date.substring(5));
/* 1164 */         res = year + "-" + month;
/*      */       }
/*      */     } catch (Exception e) {
/* 1167 */       res = date;
/*      */     }
/* 1169 */     return res;
/*      */   }
/*      */ 
/*      */   public static String formatDateToCN(String date)
/*      */   {
/* 1181 */     String res = "";
/* 1182 */     if (date == null) {
/* 1183 */       return res;
/*      */     }
/*      */     try
/*      */     {
/* 1187 */       if (date.length() == 5) {
/* 1188 */         int month = Integer.parseInt(date.substring(0, 2));
/* 1189 */         int day = Integer.parseInt(date.substring(3));
/* 1190 */         res = month + "月" + day + "日";
/*      */       }
/* 1193 */       else if (date.length() == 7) {
/* 1194 */         int year = Integer.parseInt(date.substring(0, 4));
/* 1195 */         int month = Integer.parseInt(date.substring(5, 7));
/* 1196 */         res = year + "年" + month + "月";
/*      */       }
/* 1199 */       else if (date.length() == 10) {
/* 1200 */         int year = Integer.parseInt(date.substring(0, 4));
/* 1201 */         int month = Integer.parseInt(date.substring(5, 7));
/* 1202 */         int day = Integer.parseInt(date.substring(8));
/* 1203 */         res = year + "年" + month + "月" + day + "日";
/*      */       } else {
/* 1205 */         res = date;
/*      */       }
/*      */     } catch (Exception e) { res = date; }
/*      */ 
/* 1209 */     return res;
/*      */   }
/*      */ 
/*      */   public static java.util.Date getDateObj(int year, int month, int day)
/*      */   {
/* 1226 */     int mon = month - 1;
/*      */ 
/* 1229 */     Calendar rightNow = Calendar.getInstance();
/*      */     int ye;
/*      */     int ye;
/* 1230 */     if ((year >= 0) && (year < 80)) {
/* 1231 */       ye = year + 2000;
/*      */     }
/*      */     else
/*      */     {
/*      */       int ye;
/* 1232 */       if (year > 100)
/* 1233 */         ye = year;
/*      */       else
/* 1235 */         ye = year + 1900; 
/*      */     }
/* 1236 */     rightNow.set(11, 0);
/* 1237 */     rightNow.set(12, 0);
/* 1238 */     rightNow.set(13, 0);
/* 1239 */     rightNow.set(ye, mon, day);
/* 1240 */     java.util.Date db = rightNow.getTime();
/* 1241 */     return db;
/*      */   }
/*      */ 
/*      */   public static java.util.Date getDateObj(String argsDate, String split)
/*      */   {
/* 1254 */     String[] temp = argsDate.split(split);
/* 1255 */     int year = new Integer(temp[0]).intValue();
/* 1256 */     int month = new Integer(temp[1]).intValue();
/* 1257 */     int day = new Integer(temp[2]).intValue();
/* 1258 */     return getDateObj(year, month, day);
/*      */   }
/*      */ 
/*      */   public static String addMonth(String str, int i)
/*      */   {
/* 1271 */     String issue = str;
/* 1272 */     int n_year = Integer.parseInt(issue) / 100;
/* 1273 */     int n_month = Integer.parseInt(issue) % 100;
/* 1274 */     int aY = i / 12;
/* 1275 */     int aM = i % 12;
/* 1276 */     n_year += aY;
/* 1277 */     n_month += aM;
/* 1278 */     if (n_month > 12) {
/* 1279 */       n_year += 1;
/* 1280 */       n_month -= 12;
/*      */     }
/* 1282 */     if (n_month < 0) {
/* 1283 */       n_year -= 1;
/* 1284 */       n_month = 12 + n_month;
/*      */     }
/* 1286 */     if (n_month < 10) {
/* 1287 */       issue = Integer.toString(n_year).trim() + '0' + Integer.toString(n_month).trim();
/*      */     }
/*      */     else {
/* 1290 */       issue = Integer.toString(n_year).trim() + Integer.toString(n_month).trim();
/*      */     }
/*      */ 
/* 1294 */     return issue;
/*      */   }
/*      */ 
/*      */   public static boolean verifyDate(int yyyy, int MM, int dd)
/*      */   {
/* 1308 */     boolean flag = false;
/* 1309 */     if ((MM >= 1) && (MM <= 12) && (dd >= 1) && (dd <= 31)) {
/* 1310 */       if ((MM == 4) || (MM == 6) || (MM == 9) || (MM == 11)) {
/* 1311 */         if (dd <= 30)
/* 1312 */           flag = true;
/*      */       }
/* 1314 */       else if (MM == 2) {
/* 1315 */         if (((yyyy % 100 != 0) && (yyyy % 4 == 0)) || (yyyy % 400 == 0)) {
/* 1316 */           if (dd <= 29)
/* 1317 */             flag = true;
/*      */         }
/* 1319 */         else if (dd <= 28)
/* 1320 */           flag = true;
/*      */       }
/*      */       else {
/* 1323 */         flag = true;
/*      */       }
/*      */     }
/*      */ 
/* 1327 */     return flag;
/*      */   }
/*      */ 
/*      */   public static String getToday()
/*      */   {
/* 1336 */     return date2String(new java.util.Date(), "yyyy-MM-dd");
/*      */   }
/*      */ 
/*      */   public static java.sql.Date getStepDay(java.sql.Date date, int step)
/*      */   {
/* 1347 */     Calendar calendar = Calendar.getInstance();
/* 1348 */     calendar.setTime(date);
/* 1349 */     calendar.add(6, step);
/* 1350 */     return new java.sql.Date(calendar.getTime().getTime());
/*      */   }
/*      */ 
/*      */   public static java.sql.Date getStepMonth(java.util.Date date, int intBetween)
/*      */   {
/* 1361 */     Calendar calo = Calendar.getInstance();
/* 1362 */     calo.setTime(date);
/* 1363 */     calo.add(2, intBetween);
/* 1364 */     return new java.sql.Date(calo.getTime().getTime());
/*      */   }
/*      */ 
/*      */   public static java.sql.Date getStepYear(java.util.Date date, int intBetween)
/*      */   {
/* 1375 */     Calendar calo = Calendar.getInstance();
/* 1376 */     calo.setTime(date);
/* 1377 */     calo.add(1, intBetween);
/* 1378 */     return new java.sql.Date(calo.getTime().getTime());
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.date.DateUtil
 * JD-Core Version:    0.6.2
 */
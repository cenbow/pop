/*     */ package com.asiainfo.biframe.utils.date;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Calendar;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class HolidayUtil
/*     */ {
/*     */   private static final int DAY_DIFF = 30;
/*     */   private static final int START_YEAR = 1900;
/*     */   private static final int END_YEAR = 2050;
/*     */   private static final int BASE_INDEX = 1900;
/*  57 */   private static final long[] lunarInfo = { 19416L, 19168L, 42352L, 21717L, 53856L, 55632L, 91476L, 22176L, 39632L, 21970L, 19168L, 42422L, 42192L, 53840L, 119381L, 46400L, 54944L, 44450L, 38320L, 84343L, 18800L, 42160L, 46261L, 27216L, 27968L, 109396L, 11104L, 38256L, 21234L, 18800L, 25958L, 54432L, 59984L, 28309L, 23248L, 11104L, 100067L, 37600L, 116951L, 51536L, 54432L, 120998L, 46416L, 22176L, 107956L, 9680L, 37584L, 53938L, 43344L, 46423L, 27808L, 46416L, 86869L, 19872L, 42416L, 83315L, 21168L, 43432L, 59728L, 27296L, 44710L, 43856L, 19296L, 43748L, 42352L, 21088L, 62051L, 55632L, 23383L, 22176L, 38608L, 19925L, 19152L, 42192L, 54484L, 53840L, 54616L, 46400L, 46752L, 103846L, 38320L, 18864L, 43380L, 42160L, 45690L, 27216L, 27968L, 44870L, 43872L, 38256L, 19189L, 18800L, 25776L, 29859L, 59984L, 27480L, 21952L, 43872L, 38613L, 37600L, 51552L, 55636L, 54432L, 55888L, 30034L, 22176L, 43959L, 9680L, 37584L, 51893L, 43344L, 46240L, 47780L, 44368L, 21977L, 19360L, 42416L, 86390L, 21168L, 43312L, 31060L, 27296L, 44368L, 23378L, 19296L, 42726L, 42208L, 53856L, 60005L, 54576L, 23200L, 30371L, 38608L, 19415L, 19152L, 42192L, 118966L, 53840L, 54560L, 56645L, 46496L, 22224L, 21938L, 18864L, 42359L, 42160L, 43600L, 111189L, 27936L, 44448L, 84835L };
/*     */ 
/*  81 */   private Properties m_Prop = null;
/*  82 */   private static String m_strFileName = "config/aibi_utils/holidays.properties";
/*  83 */   private String m_strAbsPath = null;
/*  84 */   private long m_lastModifiedTime = 0L;
/*  85 */   private File m_file = null;
/*  86 */   private static HolidayUtil m_Instance = new HolidayUtil();
/*     */ 
/*     */   public static HolidayUtil getInstance()
/*     */   {
/*  95 */     return m_Instance;
/*     */   }
/*     */ 
/*     */   public String getProperty(String strKey)
/*     */   {
/*     */     try
/*     */     {
/* 107 */       if ((this.m_Prop == null) || (this.m_file.lastModified() > this.m_lastModifiedTime)) {
/* 108 */         init();
/*     */       }
/* 110 */       String str = this.m_Prop.getProperty(strKey);
/* 111 */       if (null != str) {
/* 112 */         str = str.trim();
/*     */       }
/*     */ 
/* 115 */       if ((str != null) && (!"".equals(str)));
/* 116 */       return new String(str.getBytes("ISO8859_1"));
/*     */     }
/*     */     catch (Exception excep)
/*     */     {
/* 120 */       excep.printStackTrace();
/* 121 */       this.m_Prop = null;
/* 122 */     }return "";
/*     */   }
/*     */ 
/*     */   private synchronized boolean init()
/*     */     throws Exception
/*     */   {
/* 133 */     if ((this.m_Prop == null) || (this.m_file.lastModified() > this.m_lastModifiedTime)) {
/* 134 */       if (null != this.m_Prop) {
/* 135 */         this.m_Prop.clear();
/*     */       }
/* 137 */       this.m_Prop = new Properties();
/* 138 */       if (null == this.m_file) {
/* 139 */         this.m_file = new File(m_strFileName);
/*     */       }
/* 141 */       this.m_lastModifiedTime = this.m_file.lastModified();
/* 142 */       this.m_strAbsPath = this.m_file.getAbsolutePath();
/* 143 */       if (!this.m_file.exists()) {
/* 144 */         throw new Exception("参数文件找不到：相对路径:" + m_strFileName + "\r\n绝对路径:" + this.m_strAbsPath);
/*     */       }
/*     */ 
/* 147 */       FileInputStream fis = new FileInputStream(m_strFileName);
/* 148 */       this.m_Prop.load(fis);
/* 149 */       fis.close();
/*     */     }
/* 151 */     return true;
/*     */   }
/*     */ 
/*     */   public String getAbsPath() {
/* 155 */     return this.m_strAbsPath;
/*     */   }
/*     */ 
/*     */   public String getFileName() {
/* 159 */     return m_strFileName;
/*     */   }
/*     */ 
/*     */   public void setFileName(String fileName)
/*     */   {
/* 169 */     m_strFileName = fileName;
/*     */   }
/*     */ 
/*     */   protected void finalize() {
/* 173 */     if (null != this.m_Prop)
/* 174 */       this.m_Prop.clear();
/*     */   }
/*     */ 
/*     */   public String getLunar(int nYear, int nMonth, int nDays)
/*     */   {
/* 190 */     String result = "";
/*     */ 
/* 192 */     Calendar todayCal = Calendar.getInstance();
/* 193 */     Calendar baseCal = Calendar.getInstance();
/*     */ 
/* 195 */     baseCal.set(1900, 0, 1);
/* 196 */     todayCal.set(nYear, nMonth - 1, nDays);
/*     */ 
/* 198 */     long offset = (todayCal.getTimeInMillis() - baseCal.getTimeInMillis()) / 86400000L - 30L;
/*     */ 
/* 201 */     long temp = 0L;
/* 202 */     int i = 0;
/*     */ 
/* 204 */     for (i = 1900; (i < 2050) && (offset > 0L); i++) {
/* 205 */       temp = lYearDays(i);
/* 206 */       offset -= temp;
/*     */     }
/*     */ 
/* 209 */     if (offset < 0L) {
/* 210 */       offset += temp;
/* 211 */       i--;
/*     */     }
/*     */ 
/* 214 */     int year = i;
/*     */ 
/* 216 */     int leap = leapMonth(i);
/*     */ 
/* 218 */     boolean isLeap = false;
/*     */ 
/* 220 */     for (i = 1; (i < 13) && (offset > 0L); i++) {
/* 221 */       if ((leap > 0) && (i == leap + 1) && (!isLeap)) {
/* 222 */         i--;
/* 223 */         isLeap = true;
/* 224 */         temp = leapDays(year);
/*     */       } else {
/* 226 */         temp = monthDays(year, i);
/*     */       }
/* 228 */       if ((isLeap == true) && (i == leap + 1))
/* 229 */         isLeap = false;
/* 230 */       offset -= temp;
/*     */     }
/*     */ 
/* 233 */     if ((offset == 0L) && (leap > 0) && (i == leap + 1)) {
/* 234 */       if (isLeap) {
/* 235 */         isLeap = false;
/*     */       } else {
/* 237 */         isLeap = true;
/* 238 */         i--;
/*     */       }
/*     */     }
/* 241 */     if (offset < 0L) {
/* 242 */       offset += temp;
/* 243 */       i--;
/*     */     }
/*     */ 
/* 246 */     int month = i;
/* 247 */     int day = (int)offset + 1;
/* 248 */     result = result + getFormatDate(year, month, day);
/*     */ 
/* 250 */     return result;
/*     */   }
/*     */ 
/*     */   public Vector<String> getSolarHolidays(int nYear, int nMonth, int nDays)
/*     */   {
/* 264 */     Vector result = new Vector();
/* 265 */     String key = "";
/* 266 */     if (nMonth < 10)
/* 267 */       key = key + "0" + nMonth;
/*     */     else {
/* 269 */       key = key + nMonth;
/*     */     }
/* 271 */     if (nDays < 10)
/* 272 */       key = key + "0" + nDays;
/*     */     else {
/* 274 */       key = key + nDays;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 282 */       key = "1." + key;
/* 283 */       String values = getProperty(key);
/* 284 */       if ((values == null) || ("".equals(values)))
/* 285 */         return null;
/* 286 */       values = values + ",";
/*     */ 
/* 288 */       while ((values != null) && (!"".equals(values))) {
/* 289 */         String value = values.substring(0, values.indexOf(","));
/* 290 */         values = values.substring(values.indexOf(",") + 1);
/* 291 */         if ((value != null) && (!"".equals(value)))
/* 292 */           result.add(getFormatDate(nYear, nMonth, nDays) + " " + value);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/* 298 */     if (result.size() == 0)
/* 299 */       return null;
/* 300 */     return result;
/*     */   }
/*     */ 
/*     */   public Vector<String> getLunarHolidays(int nYear, int nMonth, int nDays)
/*     */   {
/* 314 */     Vector result = new Vector();
/* 315 */     String lunarStr = getLunar(nYear, nMonth, nDays);
/* 316 */     if ((lunarStr == null) || ("".equals(lunarStr)))
/* 317 */       return null;
/* 318 */     lunarStr = lunarStr.substring(lunarStr.indexOf("-") + 1);
/*     */ 
/* 320 */     String month = lunarStr.substring(0, lunarStr.indexOf("-"));
/* 321 */     String day = lunarStr.substring(lunarStr.indexOf("-") + 1);
/*     */ 
/* 323 */     String key = month + day;
/*     */     try
/*     */     {
/* 331 */       key = "2." + key;
/* 332 */       String values = getProperty(key);
/* 333 */       if ((values == null) || ("".equals(values)))
/* 334 */         return null;
/* 335 */       values = values + ",";
/*     */ 
/* 337 */       while ((values != null) && (!"".equals(values))) {
/* 338 */         String value = values.substring(0, values.indexOf(","));
/* 339 */         values = values.substring(values.indexOf(",") + 1);
/* 340 */         if ((value != null) && (!"".equals(value)))
/* 341 */           result.add(getFormatDate(nYear, nMonth, nDays) + " " + value);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/* 347 */     if (result.size() == 0)
/* 348 */       return null;
/* 349 */     return result;
/*     */   }
/*     */ 
/*     */   public Vector<String> getWeekdayHolidays(int nYear, int nMonth, int nDays)
/*     */   {
/* 365 */     Vector result = new Vector();
/*     */ 
/* 367 */     Calendar cal = Calendar.getInstance();
/* 368 */     cal.set(nYear, nMonth - 1, nDays);
/* 369 */     int nWeekOfMonth = cal.get(8);
/* 370 */     int nDayOfWeek = cal.get(7) - 1;
/*     */ 
/* 372 */     String key = "";
/* 373 */     if (nMonth < 10)
/* 374 */       key = key + "0" + nMonth;
/*     */     else
/* 376 */       key = key + nMonth;
/* 377 */     key = key + nWeekOfMonth;
/* 378 */     key = key + nDayOfWeek;
/* 379 */     System.out.println("key=" + key);
/*     */     try
/*     */     {
/* 386 */       key = "3." + key;
/* 387 */       String values = getProperty(key);
/* 388 */       if ((values == null) || ("".equals(values)))
/* 389 */         return null;
/* 390 */       values = values + ",";
/*     */ 
/* 392 */       while ((values != null) && (!"".equals(values))) {
/* 393 */         String value = values.substring(0, values.indexOf(","));
/* 394 */         values = values.substring(values.indexOf(",") + 1);
/* 395 */         if ((value != null) && (!"".equals(value)))
/* 396 */           result.add(getFormatDate(nYear, nMonth, nDays) + " " + value);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/* 402 */     if (result.size() == 0)
/* 403 */       return null;
/* 404 */     return result;
/*     */   }
/*     */ 
/*     */   public Vector<String> getLunarMonthLastDayHolidays(int nYear, int nMonth, int nDays)
/*     */   {
/* 419 */     Vector result = new Vector();
/*     */ 
/* 421 */     String lunarStr = getLunar(nYear, nMonth, nDays);
/* 422 */     if ((lunarStr == null) || ("".equals(lunarStr))) {
/* 423 */       return null;
/*     */     }
/* 425 */     String year = lunarStr.substring(0, lunarStr.indexOf("-"));
/* 426 */     lunarStr = lunarStr.substring(lunarStr.indexOf("-") + 1);
/* 427 */     String month = lunarStr.substring(0, lunarStr.indexOf("-"));
/* 428 */     String day = lunarStr.substring(lunarStr.indexOf("-") + 1);
/*     */ 
/* 430 */     int daysOfMonth = 0;
/* 431 */     daysOfMonth = monthDays(Integer.parseInt(year), Integer.parseInt(month));
/*     */ 
/* 433 */     if (Integer.parseInt(day) == daysOfMonth) {
/* 434 */       if (Integer.parseInt(month) == 12) {
/* 435 */         year = "" + (Integer.parseInt(year) + 1);
/* 436 */         month = "01";
/*     */       }
/* 438 */       else if (Integer.parseInt(month) + 1 < 10) {
/* 439 */         month = "0" + (Integer.parseInt(month) + 1);
/*     */       } else {
/* 441 */         month = "" + (Integer.parseInt(month) + 1);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 446 */       return null;
/*     */     }
/* 448 */     day = "00";
/* 449 */     String key = "";
/*     */ 
/* 451 */     key = key + month + day;
/*     */     try
/*     */     {
/* 460 */       key = "4." + key;
/* 461 */       String values = getProperty(key);
/* 462 */       if ((values == null) || ("".equals(values)))
/* 463 */         return null;
/* 464 */       values = values + ",";
/*     */ 
/* 466 */       while ((values != null) && (!"".equals(values))) {
/* 467 */         String value = values.substring(0, values.indexOf(","));
/* 468 */         values = values.substring(values.indexOf(",") + 1);
/* 469 */         if ((value != null) && (!"".equals(value)))
/* 470 */           result.add(getFormatDate(nYear, nMonth, nDays) + " " + value);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/* 476 */     if (result.size() == 0)
/* 477 */       return null;
/* 478 */     return result;
/*     */   }
/*     */ 
/*     */   public Vector<String> getHolidays(int nYear, int nMonth, int nDays)
/*     */   {
/* 493 */     Vector result = new Vector();
/*     */ 
/* 495 */     Vector tmp = null;
/* 496 */     tmp = getSolarHolidays(nYear, nMonth, nDays);
/* 497 */     if ((tmp != null) && (tmp.size() > 0)) {
/* 498 */       result.addAll(tmp);
/*     */     }
/*     */ 
/* 501 */     tmp = getLunarHolidays(nYear, nMonth, nDays);
/* 502 */     if ((tmp != null) && (tmp.size() > 0)) {
/* 503 */       result.addAll(tmp);
/*     */     }
/*     */ 
/* 506 */     tmp = getWeekdayHolidays(nYear, nMonth, nDays);
/* 507 */     if ((tmp != null) && (tmp.size() > 0)) {
/* 508 */       result.addAll(tmp);
/*     */     }
/*     */ 
/* 511 */     tmp = getLunarMonthLastDayHolidays(nYear, nMonth, nDays);
/* 512 */     if ((tmp != null) && (tmp.size() > 0)) {
/* 513 */       result.addAll(tmp);
/*     */     }
/*     */ 
/* 516 */     if (result.size() == 0)
/* 517 */       return null;
/* 518 */     return result;
/*     */   }
/*     */ 
/*     */   public Vector<String> getHolidays(String fromDate, String toDate)
/*     */   {
/* 532 */     Vector result = new Vector();
/* 533 */     if ((fromDate == null) || ("".equals(fromDate)))
/* 534 */       return null;
/* 535 */     if ((toDate == null) || ("".equals(toDate))) {
/* 536 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 540 */       int fromYear = Integer.parseInt(fromDate.substring(0, fromDate.indexOf("-")));
/*     */ 
/* 542 */       String temp = fromDate.substring(fromDate.indexOf("-") + 1);
/* 543 */       int fromMonth = Integer.parseInt(temp.substring(0, temp.indexOf("-")));
/*     */ 
/* 545 */       int fromDay = Integer.parseInt(temp.substring(temp.indexOf("-") + 1));
/*     */ 
/* 547 */       if ((fromYear == 0) || (fromMonth == 0) || (fromDay == 0)) {
/* 548 */         return null;
/*     */       }
/* 550 */       int toYear = Integer.parseInt(toDate.substring(0, toDate.indexOf("-")));
/*     */ 
/* 552 */       temp = toDate.substring(toDate.indexOf("-") + 1);
/* 553 */       int toMonth = Integer.parseInt(temp.substring(0, temp.indexOf("-")));
/*     */ 
/* 555 */       int toDay = Integer.parseInt(temp.substring(temp.indexOf("-") + 1));
/* 556 */       if ((toYear == 0) || (toMonth == 0) || (toDay == 0)) {
/* 557 */         return null;
/*     */       }
/* 559 */       Calendar fromCal = Calendar.getInstance();
/* 560 */       Calendar toCal = Calendar.getInstance();
/* 561 */       fromCal.set(fromYear, fromMonth - 1, fromDay);
/* 562 */       toCal.set(toYear, toMonth - 1, toDay);
/*     */ 
/* 564 */       while (toCal.getTimeInMillis() - fromCal.getTimeInMillis() >= 0L) {
/* 565 */         Vector tmp = getHolidays(fromCal.get(1), fromCal.get(2) + 1, fromCal.get(5));
/*     */ 
/* 567 */         fromCal.add(5, 1);
/* 568 */         if ((tmp != null) && (tmp.size() != 0))
/*     */         {
/* 570 */           result.addAll(tmp);
/*     */         }
/*     */       }
/* 573 */       if (result.size() == 0)
/* 574 */         return null;
/* 575 */       return result;
/*     */     } catch (Exception e) {
/*     */     }
/* 578 */     return null;
/*     */   }
/*     */ 
/*     */   private String getFormatDate(int nYear, int nMonth, int nDay)
/*     */   {
/* 594 */     String result = "";
/*     */ 
/* 596 */     result = result + nYear + "-";
/*     */ 
/* 598 */     if (nMonth < 10)
/* 599 */       result = result + "0" + nMonth + "-";
/*     */     else {
/* 601 */       result = result + nMonth + "-";
/*     */     }
/* 603 */     if (nDay < 10)
/* 604 */       result = result + "0" + nDay;
/*     */     else {
/* 606 */       result = result + nDay;
/*     */     }
/* 608 */     return result;
/*     */   }
/*     */ 
/*     */   private int lYearDays(int nYear)
/*     */   {
/* 619 */     int sum = 348;
/* 620 */     for (int i = 1; i < 13; i++) {
/* 621 */       sum += ((lunarInfo[(nYear - 1900)] & 65536 >> i) > 0L ? 1 : 0);
/*     */     }
/* 623 */     return sum + leapDays(nYear);
/*     */   }
/*     */ 
/*     */   private int leapDays(int nYear)
/*     */   {
/* 634 */     if (leapMonth(nYear) > 0) {
/* 635 */       return (lunarInfo[(nYear - 1900)] & 0x10000) > 0L ? 30 : 29;
/*     */     }
/* 637 */     return 0;
/*     */   }
/*     */ 
/*     */   private int leapMonth(int nYear)
/*     */   {
/* 648 */     return (int)(lunarInfo[(nYear - 1900)] & 0xF);
/*     */   }
/*     */ 
/*     */   private int monthDays(int nYear, int nMonth)
/*     */   {
/* 660 */     return (lunarInfo[(nYear - 1900)] & 65536 >> nMonth) > 0L ? 30 : 29;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.date.HolidayUtil
 * JD-Core Version:    0.6.2
 */
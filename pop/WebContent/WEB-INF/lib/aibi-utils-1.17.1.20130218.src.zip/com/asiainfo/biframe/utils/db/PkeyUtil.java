/*    */ package com.asiainfo.biframe.utils.db;
/*    */ 
/*    */ import org.hibernate.id.UUIDHexGenerator;
/*    */ 
/*    */ public class PkeyUtil
/*    */ {
/*    */   public static String generateHexUUID()
/*    */   {
/* 37 */     return new UUIDHexGenerator().generate(null, null).toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.db.PkeyUtil
 * JD-Core Version:    0.6.2
 */
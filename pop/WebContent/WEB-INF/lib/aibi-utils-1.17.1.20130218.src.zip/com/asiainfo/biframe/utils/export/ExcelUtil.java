/*     */ package com.asiainfo.biframe.utils.export;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigDecimal;
/*     */ import jxl.SheetSettings;
/*     */ import jxl.Workbook;
/*     */ import jxl.format.Alignment;
/*     */ import jxl.format.Border;
/*     */ import jxl.format.BorderLineStyle;
/*     */ import jxl.format.Colour;
/*     */ import jxl.write.Label;
/*     */ import jxl.write.Number;
/*     */ import jxl.write.WritableCell;
/*     */ import jxl.write.WritableCellFormat;
/*     */ import jxl.write.WritableFont;
/*     */ import jxl.write.WritableSheet;
/*     */ import jxl.write.WritableWorkbook;
/*     */ import jxl.write.WriteException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ExcelUtil
/*     */ {
/*  36 */   private static Log log = LogFactory.getLog(ExcelUtil.class);
/*     */ 
/*     */   protected static WritableWorkbook createExcel(OutputStream os)
/*     */   {
/*  47 */     WritableWorkbook book = null;
/*     */     try {
/*  49 */       book = Workbook.createWorkbook(os);
/*     */     } catch (IOException e) {
/*  51 */       e.printStackTrace();
/*     */     }
/*  53 */     return book;
/*     */   }
/*     */ 
/*     */   protected static WritableWorkbook createExcel(File file)
/*     */   {
/*  63 */     OutputStream os = null;
/*     */     try {
/*  65 */       os = new FileOutputStream(file);
/*     */     } catch (FileNotFoundException e) {
/*  67 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  70 */     return createExcel(os);
/*     */   }
/*     */ 
/*     */   protected static WritableSheet addExcelSheet(WritableWorkbook book, String sheetName)
/*     */   {
/*  82 */     WritableSheet ws = null;
/*  83 */     if ((null == sheetName) || (sheetName.trim().length() < 1)) {
/*  84 */       sheetName = "sheet" + (book.getNumberOfSheets() + 1);
/*     */     }
/*  86 */     ws = book.createSheet(sheetName, book.getNumberOfSheets());
/*  87 */     ws.getSettings().setDefaultColumnWidth(15);
/*  88 */     return ws;
/*     */   }
/*     */ 
/*     */   protected static WritableCell createCellTextHeader(int colIndex, int rowIndex, String str)
/*     */   {
/* 103 */     WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.ARIAL, 11, WritableFont.BOLD));
/*     */     try {
/* 105 */       format.setAlignment(Alignment.CENTRE);
/* 106 */       format.setBorder(Border.ALL, BorderLineStyle.THIN);
/* 107 */       format.setBackground(Colour.LIGHT_GREEN);
/* 108 */       format.setWrap(true);
/* 109 */       format.setLocked(true);
/*     */     } catch (WriteException e) {
/* 111 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 114 */     return createCellTextHeader(colIndex, rowIndex, str, format);
/*     */   }
/*     */ 
/*     */   private static WritableCell createCellTextHeader(int colIndex, int rowIndex, String str, WritableCellFormat format)
/*     */   {
/* 129 */     return new Label(colIndex, rowIndex, str, format);
/*     */   }
/*     */ 
/*     */   protected static WritableCell createCell(int colIndex, int rowIndex, Object obj)
/*     */   {
/* 142 */     if (null == obj)
/* 143 */       return createCellText(colIndex, rowIndex, "");
/* 144 */     if (((obj instanceof Integer)) || ((obj instanceof Double)) || ((obj instanceof BigDecimal)) || ((obj instanceof Float)))
/*     */     {
/* 146 */       return createCellNumber(colIndex, rowIndex, obj.toString());
/*     */     }
/* 148 */     return createCellText(colIndex, rowIndex, obj.toString());
/*     */   }
/*     */ 
/*     */   private static WritableCell createCellNumber(int colIndex, int rowIndex, String str)
/*     */   {
/* 163 */     WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.ARIAL, 10));
/*     */     try
/*     */     {
/* 166 */       format.setAlignment(Alignment.RIGHT);
/* 167 */       format.setBorder(Border.ALL, BorderLineStyle.THIN);
/*     */     } catch (WriteException e) {
/* 169 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 172 */     return new Number(colIndex, rowIndex, getNumber(str, 0.0D), format);
/*     */   }
/*     */ 
/*     */   private static WritableCell createCellText(int colIndex, int rowIndex, String str)
/*     */   {
/* 187 */     WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.ARIAL, 10));
/*     */     try {
/* 189 */       format.setAlignment(Alignment.LEFT);
/* 190 */       format.setBorder(Border.ALL, BorderLineStyle.THIN);
/*     */     } catch (WriteException e) {
/* 192 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 195 */     return new Label(colIndex, rowIndex, str, format);
/*     */   }
/*     */ 
/*     */   private static double getNumber(String str, double defNum)
/*     */   {
/*     */     try
/*     */     {
/* 208 */       return Double.parseDouble(str);
/*     */     } catch (NumberFormatException e) {
/* 210 */       log.debug(" !!error!! ExcelUtil.getNumber(" + str + ")");
/*     */     }
/* 212 */     return defNum;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.ExcelUtil
 * JD-Core Version:    0.6.2
 */
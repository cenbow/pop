/*     */ package com.asiainfo.biframe.utils.export;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.htmlparser.parserapplications.StringExtractor;
/*     */ import org.htmlparser.util.ParserException;
/*     */ 
/*     */ public class ExportExcelFromTable
/*     */ {
/*  58 */   private static Logger log = Logger.getLogger(ExportExcelFromTable.class);
/*     */ 
/*     */   public static void exportExcel(String filePath, String exportFileName, HttpServletResponse response) throws Exception {
/*  61 */     if (response != null) {
/*  62 */       File file = new File(filePath);
/*  63 */       if (file.exists())
/*     */       {
/*  65 */         InputStream fis = new BufferedInputStream(new FileInputStream(filePath));
/*  66 */         byte[] buffer = new byte[fis.available()];
/*  67 */         fis.read(buffer);
/*  68 */         fis.close();
/*     */ 
/*  70 */         response.reset();
/*     */ 
/*  73 */         response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(exportFileName, "UTF-8") + "\"");
/*     */ 
/*  75 */         response.addHeader("Content-Length", "" + file.length());
/*  76 */         OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
/*  77 */         response.setContentType("application/octet-stream");
/*  78 */         toClient.write(buffer);
/*  79 */         toClient.flush();
/*  80 */         toClient.close();
/*     */       }
/*     */       else {
/*  83 */         log.error("FileNotFound! file path is:[" + filePath + "]");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void createExcelFromUrl(String url, String excelFilePath, String excelFileName)
/*     */     throws Exception
/*     */   {
/* 106 */     createExcelFromUrl(url, false, excelFilePath, excelFileName);
/*     */   }
/*     */ 
/*     */   public static void createExcelFromUrl(String url, boolean onlyContentText, String excelFilePath, String excelFileName) throws Exception {
/* 110 */     String str = "";
/* 111 */     if (onlyContentText) {
/* 112 */       str = getHtmlContentText(url);
/*     */     }
/*     */     else {
/* 115 */       str = getHtmlSourceCode(url);
/*     */     }
/*     */ 
/* 118 */     File filePath = new File(excelFilePath);
/* 119 */     if (!filePath.exists()) {
/* 120 */       filePath.mkdirs();
/*     */     }
/*     */ 
/* 123 */     File fileName = new File(excelFilePath + File.separator + excelFileName);
/* 124 */     if (!fileName.exists()) {
/* 125 */       fileName.createNewFile();
/*     */     }
/* 127 */     FileOutputStream writerStream = new FileOutputStream(fileName, false);
/* 128 */     BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(writerStream, "GBK"));
/* 129 */     writer.write(str);
/* 130 */     writer.close();
/* 131 */     writerStream.close();
/*     */   }
/*     */ 
/*     */   public static String getHtmlSourceCode(String strUrl) throws Exception {
/* 135 */     URL url = new URL(strUrl);
/* 136 */     BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"));
/* 137 */     String s = "";
/* 138 */     StringBuffer sb = new StringBuffer("");
/* 139 */     while ((s = br.readLine()) != null) {
/* 140 */       sb.append(s).append("\r\n");
/*     */     }
/* 142 */     br.close();
/* 143 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String getHtmlContentText(String strUrl) {
/* 147 */     StringExtractor se = new StringExtractor(strUrl);
/* 148 */     String text = "";
/*     */     try {
/* 150 */       text = se.extractStrings(false);
/*     */     } catch (ParserException e) {
/* 152 */       e.printStackTrace();
/*     */     }
/* 154 */     return text;
/*     */   }
/*     */ 
/*     */   public static void initProxy()
/*     */   {
/* 163 */     System.setProperty("http.proxyType", "4");
/* 164 */     System.setProperty("http.proxyPort", Integer.toString(8080));
/* 165 */     System.setProperty("http.proxyHost", "proxy.asiainfo-linkage.com");
/* 166 */     System.setProperty("http.proxyUser", "kebin");
/* 167 */     System.setProperty("http.proxyPassword", "520-linxilei");
/* 168 */     System.setProperty("http.proxySet", "true");
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.ExportExcelFromTable
 * JD-Core Version:    0.6.2
 */
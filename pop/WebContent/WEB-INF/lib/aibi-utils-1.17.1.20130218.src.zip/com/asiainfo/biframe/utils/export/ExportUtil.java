/*      */ package com.asiainfo.biframe.utils.export;
/*      */ 
/*      */ import com.asiainfo.biframe.utils.bean.BeanHelper;
/*      */ import com.asiainfo.biframe.utils.export.excelhelper.DownloadFactory;
/*      */ import com.asiainfo.biframe.utils.string.StringUtil;
/*      */ import com.lowagie.text.Document;
/*      */ import com.lowagie.text.Paragraph;
/*      */ import com.lowagie.text.Table;
/*      */ import common.Logger;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipOutputStream;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.Workbook;
/*      */ import jxl.biff.DisplayFormat;
/*      */ import jxl.format.Alignment;
/*      */ import jxl.format.Border;
/*      */ import jxl.format.BorderLineStyle;
/*      */ import jxl.format.Colour;
/*      */ import jxl.write.Label;
/*      */ import jxl.write.Number;
/*      */ import jxl.write.NumberFormat;
/*      */ import jxl.write.NumberFormats;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableCellFormat;
/*      */ import jxl.write.WritableFont;
/*      */ import jxl.write.WritableFont.FontName;
/*      */ import jxl.write.WritableSheet;
/*      */ import jxl.write.WritableWorkbook;
/*      */ import org.apache.commons.collections.map.CaseInsensitiveMap;
/*      */ 
/*      */ public class ExportUtil
/*      */ {
/*   67 */   private static final Logger logger = Logger.getLogger(ExportUtil.class);
/*      */   private WritableWorkbook wwb;
/*      */   private WritableSheet ws;
/*      */   public static final int DATA_TYPE_INT = 1;
/*      */   public static final int DATA_TYPE_DOUBLE = 2;
/*      */   public static final int DATA_TYPE_PERSENT = 3;
/*      */   public static final int DATA_TYPE_ACCOUNT = 4;
/*      */   public static final int DATA_TYPE_STRING = 5;
/*      */   public static final int DATA_TYPE_DATE = 6;
/*      */   public static final int DATA_TYPE_TIME = 7;
/*      */ 
/*      */   public static void exportExcelNoPage(OutputStream os, String sheetName, List dataList, String titleString)
/*      */     throws Exception
/*      */   {
/*  105 */     WritableWorkbook book = ExcelUtil.createExcel(os);
/*      */ 
/*  107 */     WritableSheet ws = ExcelUtil.addExcelSheet(book, sheetName);
/*      */ 
/*  110 */     Map titleMap = getTitleMap(titleString);
/*      */ 
/*  112 */     int rowIndex = 0;
/*      */ 
/*  114 */     if (titleMap.size() != 0) {
/*  115 */       Iterator colKey = titleMap.keySet().iterator();
/*      */ 
/*  117 */       int colIndex = 0;
/*  118 */       while (colKey.hasNext()) {
/*  119 */         Object key = colKey.next();
/*      */ 
/*  121 */         ws.addCell(ExcelUtil.createCellTextHeader(colIndex, rowIndex, (String)titleMap.get(key)));
/*      */ 
/*  123 */         colIndex++;
/*      */       }
/*  125 */       rowIndex++;
/*      */ 
/*  127 */       ws.getSettings().setVerticalFreeze(1);
/*      */     }
/*      */ 
/*  133 */     int dataSize = 0;
/*  134 */     if (null != dataList) {
/*  135 */       dataSize = dataList.size();
/*      */     }
/*  137 */     BeanHelper beanHelper = new BeanHelper();
/*  138 */     for (int i = 0; i < dataSize; i++) {
/*  139 */       Object o = dataList.get(i);
/*      */       Map map;
/*      */       Map map;
/*  141 */       if (!(o instanceof Map))
/*  142 */         map = beanHelper.beanToMap(o);
/*      */       else {
/*  144 */         map = (Map)dataList.get(i);
/*      */       }
/*  146 */       CaseInsensitiveMap imap = new CaseInsensitiveMap(map);
/*      */ 
/*  148 */       int colIndex = 0;
/*  149 */       Iterator colKey = titleMap.keySet().iterator();
/*  150 */       while (colKey.hasNext()) {
/*  151 */         Object key = colKey.next();
/*      */ 
/*  153 */         ws.addCell(ExcelUtil.createCell(colIndex, rowIndex, imap.get(key)));
/*      */ 
/*  155 */         colIndex++;
/*      */       }
/*  157 */       rowIndex++;
/*      */     }
/*  159 */     book.write();
/*  160 */     book.close();
/*      */   }
/*      */ 
/*      */   public static void exportExcelWithPage(OutputStream os, String sheetName, List dataList, String titleString, int pageSize)
/*      */     throws Exception
/*      */   {
/*  182 */     WritableWorkbook book = ExcelUtil.createExcel(os);
/*      */ 
/*  185 */     if ((null == dataList) || (dataList.size() < 1))
/*      */     {
/*  187 */       WritableSheet ws = ExcelUtil.addExcelSheet(book, sheetName);
/*      */ 
/*  189 */       book.write();
/*  190 */       book.close();
/*      */     }
/*      */ 
/*  194 */     int dataSize = dataList.size();
/*      */ 
/*  196 */     if (pageSize < 1) {
/*  197 */       pageSize = dataSize;
/*      */     }
/*  199 */     int startIndex = 0;
/*  200 */     int endIndex = 0;
/*  201 */     int leftCount = dataSize % pageSize;
/*  202 */     int pageCount = dataSize / pageSize;
/*      */ 
/*  204 */     if (leftCount > 0) {
/*  205 */       pageCount++;
/*      */     }
/*  207 */     for (int count = 0; count < pageCount; count++) {
/*  208 */       String newSheetName = "";
/*  209 */       if ((null == sheetName) || (sheetName.trim().length() < 1))
/*  210 */         newSheetName = "sheet" + (count + 1);
/*      */       else {
/*  212 */         newSheetName = sheetName + (count + 1);
/*      */       }
/*      */ 
/*  215 */       WritableSheet ws = ExcelUtil.addExcelSheet(book, newSheetName);
/*      */ 
/*  218 */       Map titleMap = getTitleMap(titleString);
/*      */ 
/*  220 */       int rowIndex = 0;
/*      */ 
/*  222 */       if (titleMap.size() != 0) {
/*  223 */         Iterator colKey = titleMap.keySet().iterator();
/*      */ 
/*  225 */         int colIndex = 0;
/*  226 */         while (colKey.hasNext()) {
/*  227 */           Object key = colKey.next();
/*      */ 
/*  229 */           ws.addCell(ExcelUtil.createCellTextHeader(colIndex, rowIndex, (String)titleMap.get(key)));
/*      */ 
/*  231 */           colIndex++;
/*      */         }
/*  233 */         rowIndex++;
/*      */ 
/*  235 */         ws.getSettings().setVerticalFreeze(1);
/*      */       }
/*      */ 
/*  241 */       startIndex = pageSize * count;
/*  242 */       endIndex = pageSize * (count + 1) >= dataSize ? dataSize : pageSize * (count + 1);
/*      */ 
/*  244 */       for (int m = startIndex; m < endIndex; m++) {
/*  245 */         Map map = (Map)dataList.get(m);
/*      */ 
/*  247 */         int colIndex = 0;
/*  248 */         Iterator colKey = titleMap.keySet().iterator();
/*  249 */         while (colKey.hasNext()) {
/*  250 */           Object key = colKey.next();
/*      */ 
/*  252 */           ws.addCell(ExcelUtil.createCell(colIndex, rowIndex, map.get(key)));
/*      */ 
/*  254 */           colIndex++;
/*      */         }
/*  256 */         rowIndex++;
/*      */       }
/*      */     }
/*      */ 
/*  260 */     book.write();
/*  261 */     book.close();
/*      */   }
/*      */ 
/*      */   public static void exportTxt(OutputStream os, List dataList, String titleString)
/*      */     throws Exception
/*      */   {
/*  278 */     StringBuffer fileContent = new StringBuffer();
/*      */ 
/*  281 */     Map titleMap = getTitleMap(titleString);
/*  282 */     int rowStartIndex = 0;
/*      */ 
/*  284 */     if (titleMap.size() != 0)
/*      */     {
/*  288 */       Iterator colKey = titleMap.keySet().iterator();
/*  289 */       int colIndex = 0;
/*  290 */       while (colKey.hasNext()) {
/*  291 */         Object key = colKey.next();
/*      */ 
/*  293 */         fileContent.append((String)titleMap.get(key));
/*  294 */         fileContent.append(",");
/*  295 */         colIndex++;
/*      */       }
/*  297 */       if ((fileContent.length() > 0) && (fileContent.charAt(fileContent.length() - 1) == ','))
/*      */       {
/*  299 */         fileContent.deleteCharAt(fileContent.length() - 1);
/*  300 */         fileContent.append("\r\n");
/*      */       }
/*  302 */       rowStartIndex++;
/*      */     }
/*      */ 
/*  305 */     BeanHelper beanHelper = new BeanHelper();
/*      */ 
/*  307 */     for (int i = 0; (null != dataList) && (i < dataList.size()); i++) {
/*  308 */       Object o = dataList.get(i);
/*      */       Map map;
/*      */       Map map;
/*  310 */       if (!(o instanceof Map))
/*  311 */         map = beanHelper.beanToMap(o);
/*      */       else {
/*  313 */         map = (Map)dataList.get(i);
/*      */       }
/*  315 */       CaseInsensitiveMap imap = new CaseInsensitiveMap(map);
/*      */ 
/*  317 */       int colIndex = 0;
/*  318 */       Iterator colKey = titleMap.keySet().iterator();
/*  319 */       while (colKey.hasNext()) {
/*  320 */         Object key = colKey.next();
/*      */ 
/*  322 */         fileContent.append(null == imap.get(key) ? "" : imap.get(key));
/*  323 */         fileContent.append(",");
/*  324 */         colIndex++;
/*      */       }
/*  326 */       if ((fileContent.length() > 0) && (fileContent.charAt(fileContent.length() - 1) == ','))
/*      */       {
/*  328 */         fileContent.deleteCharAt(fileContent.length() - 1);
/*  329 */         fileContent.append("\r\n");
/*      */       }
/*  331 */       rowStartIndex++;
/*      */     }
/*  333 */     os.write(fileContent.toString().getBytes());
/*      */   }
/*      */ 
/*      */   public static void exportTxtWithHeaders(String fileName, List<Map<String, String>> dataList, String[] headers, String[] exportColumns, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/*  346 */     FileOutputStream fOut = new FileOutputStream(fileName);
/*  347 */     if ((dataList == null) || (dataList.size() == 0)) {
/*  348 */       fOut.write("No data to export!".getBytes("GBK"));
/*      */     }
/*      */     else {
/*  351 */       if ((exportColumns == null) || (exportColumns.length == 0)) {
/*  352 */         Map hm = (Map)dataList.iterator().next();
/*  353 */         Set set = hm.keySet();
/*  354 */         exportColumns = new String[set.size()];
/*  355 */         set.toArray(exportColumns);
/*      */       }
/*      */ 
/*  359 */       StringBuffer fileContent = new StringBuffer();
/*  360 */       if (((headers == null) || (headers.length == 0)) && 
/*  361 */         (exportColumns != null) && (exportColumns.length > 0)) {
/*  362 */         headers = exportColumns;
/*      */       }
/*      */ 
/*  365 */       for (int i = 0; i < headers.length; i++) {
/*  366 */         fileContent.append(headers[i]);
/*  367 */         fileContent.append(",");
/*      */       }
/*  369 */       if ((fileContent.length() > 0) && (fileContent.charAt(fileContent.length() - 1) == ',')) {
/*  370 */         fileContent.deleteCharAt(fileContent.length() - 1);
/*  371 */         fileContent.append("\r\n");
/*      */       }
/*      */ 
/*  375 */       for (Map map : dataList) {
/*  376 */         for (String key : exportColumns) {
/*  377 */           String tmp = null == map.get(key) ? "" : String.valueOf(map.get(key));
/*      */ 
/*  380 */           if ((tmp.indexOf("\"") >= 0) && (tmp.indexOf(",") >= 0)) {
/*  381 */             tmp = tmp.replaceAll("\"", "\"\"");
/*  382 */             tmp = "\"" + tmp + "\"";
/*      */           }
/*  385 */           else if (tmp.indexOf(",") >= 0) {
/*  386 */             tmp = "\"" + tmp + "\"";
/*      */           }
/*      */ 
/*  391 */           fileContent.append(tmp);
/*  392 */           fileContent.append(",");
/*      */         }
/*  394 */         if ((fileContent.length() > 0) && (fileContent.charAt(fileContent.length() - 1) == ',')) {
/*  395 */           fileContent.deleteCharAt(fileContent.length() - 1);
/*  396 */           fileContent.append("\r\n");
/*      */         }
/*      */       }
/*  399 */       fOut.write(fileContent.toString().getBytes("GBK"));
/*      */     }
/*  401 */     fOut.flush();
/*  402 */     fOut.close();
/*  403 */     logger.info(fileName + " generated!");
/*      */ 
/*  405 */     new DownloadFactory().downloadfile(response, fileName);
/*      */   }
/*      */ 
/*      */   public static void exportPdf(OutputStream os, List dataList, String titleString)
/*      */     throws Exception
/*      */   {
/*  423 */     Document doc = PdfUtil.createPdf(os);
/*      */ 
/*  426 */     Table pdfTable = null;
/*      */ 
/*  429 */     Map titleMap = getTitleMap(titleString);
/*  430 */     int rowStartIndex = 0;
/*      */ 
/*  432 */     if (titleMap.size() != 0)
/*      */     {
/*  434 */       pdfTable = PdfUtil.createTable(titleMap.size());
/*      */ 
/*  436 */       Iterator colKey = titleMap.keySet().iterator();
/*  437 */       int colIndex = 0;
/*  438 */       while (colKey.hasNext()) {
/*  439 */         Object key = colKey.next();
/*      */ 
/*  441 */         pdfTable.addCell(PdfUtil.createCellHeader(titleMap.get(key)), rowStartIndex, colIndex);
/*      */ 
/*  443 */         colIndex++;
/*      */       }
/*  445 */       rowStartIndex++;
/*  446 */     } else if ((dataList != null) && (dataList.size() > 0))
/*      */     {
/*  448 */       pdfTable = PdfUtil.createTable(((Map)dataList.get(0)).size());
/*      */     }
/*  450 */     if (null == pdfTable) {
/*  451 */       doc.add(new Paragraph("No data!"));
/*      */     } else {
/*  453 */       BeanHelper beanHelper = new BeanHelper();
/*      */ 
/*  455 */       for (int i = 0; (null != dataList) && (i < dataList.size()); i++) {
/*  456 */         Object o = dataList.get(i);
/*      */         Map map;
/*      */         Map map;
/*  458 */         if (!(o instanceof Map))
/*  459 */           map = beanHelper.beanToMap(o);
/*      */         else {
/*  461 */           map = (Map)dataList.get(i);
/*      */         }
/*  463 */         CaseInsensitiveMap imap = new CaseInsensitiveMap(map);
/*  464 */         int colIndex = 0;
/*  465 */         Iterator colKey = titleMap.keySet().iterator();
/*  466 */         while (colKey.hasNext()) {
/*  467 */           Object key = colKey.next();
/*      */ 
/*  469 */           pdfTable.addCell(PdfUtil.createCell(imap.get(key)), rowStartIndex, colIndex);
/*      */ 
/*  471 */           colIndex++;
/*      */         }
/*  473 */         rowStartIndex++;
/*      */       }
/*  475 */       doc.add(pdfTable);
/*      */     }
/*  477 */     doc.close();
/*      */   }
/*      */ 
/*      */   public static void exportPdfWithHeaders(String fileName, List<Map<String, String>> dataList, String[] headers, String[] exportColumns, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/*  490 */     FileOutputStream fOut = new FileOutputStream(fileName);
/*  491 */     Document doc = PdfUtil.createPdf(fOut);
/*  492 */     Table pdfTable = null;
/*      */     int rowStartIndex;
/*      */     int colIndex;
/*  493 */     if ((dataList == null) || (dataList.size() == 0))
/*      */     {
/*  495 */       if (((headers == null) || (headers.length == 0)) && 
/*  496 */         (exportColumns != null) && (exportColumns.length > 0)) {
/*  497 */         headers = exportColumns;
/*      */       }
/*      */ 
/*  500 */       int length = headers.length;
/*  501 */       pdfTable = PdfUtil.createTable(length);
/*  502 */       int rowStartIndex = 0;
/*  503 */       int colIndex = 0;
/*  504 */       for (String header : headers) {
/*  505 */         pdfTable.addCell(PdfUtil.createCellHeader(header), rowStartIndex, colIndex);
/*  506 */         colIndex++;
/*      */       }
/*      */     }
/*      */     else {
/*  510 */       if ((exportColumns == null) || (exportColumns.length == 0)) {
/*  511 */         Map hm = (Map)dataList.iterator().next();
/*  512 */         Set set = hm.keySet();
/*  513 */         exportColumns = new String[set.size()];
/*  514 */         set.toArray(exportColumns);
/*      */       }
/*      */ 
/*  517 */       rowStartIndex = 0;
/*  518 */       colIndex = 0;
/*      */ 
/*  520 */       if (((headers == null) || (headers.length == 0)) && 
/*  521 */         (exportColumns != null) && (exportColumns.length > 0)) {
/*  522 */         headers = exportColumns;
/*      */       }
/*      */ 
/*  525 */       int length = headers.length > exportColumns.length ? headers.length : exportColumns.length;
/*  526 */       pdfTable = PdfUtil.createTable(length);
/*  527 */       for (String header : headers) {
/*  528 */         pdfTable.addCell(PdfUtil.createCellHeader(header), rowStartIndex, colIndex);
/*  529 */         colIndex++;
/*      */       }
/*  531 */       rowStartIndex++;
/*      */ 
/*  534 */       for (Map map : dataList) {
/*  535 */         colIndex = 0;
/*  536 */         for (String key : exportColumns) {
/*  537 */           String content = null == map.get(key) ? "" : String.valueOf(map.get(key));
/*  538 */           pdfTable.addCell(PdfUtil.createCell(map.get(key)), rowStartIndex, colIndex);
/*  539 */           colIndex++;
/*      */         }
/*  541 */         rowStartIndex++;
/*      */       }
/*      */     }
/*      */ 
/*  545 */     doc.add(pdfTable);
/*  546 */     doc.close();
/*  547 */     fOut.flush();
/*  548 */     fOut.close();
/*  549 */     logger.info(fileName + " generated!");
/*      */ 
/*  552 */     new DownloadFactory().downloadfile(response, fileName);
/*      */   }
/*      */ 
/*      */   private static Map getTitleMap(String titleString)
/*      */   {
/*  564 */     Map titleMap = new LinkedHashMap();
/*  565 */     if ((null == titleString) || (titleString.indexOf(";") < 0)) {
/*  566 */       return titleMap;
/*      */     }
/*  568 */     String[] items = titleString.split(";");
/*  569 */     for (int i = 0; i < items.length; i++) {
/*  570 */       String[] title = items[i].split(":");
/*  571 */       titleMap.put(title[0], title[1]);
/*      */     }
/*  573 */     return titleMap;
/*      */   }
/*      */ 
/*      */   public static synchronized void exportXLSFile(List arrayData, String strFileName)
/*      */     throws Exception
/*      */   {
/*  589 */     File f = new File(strFileName);
/*  590 */     f.createNewFile();
/*  591 */     WritableWorkbook wwb = Workbook.createWorkbook(new FileOutputStream(f));
/*      */ 
/*  593 */     WritableSheet ws = wwb.createSheet("sheet1", 0);
/*  594 */     Vector vectdata = (Vector)arrayData.get(arrayData.size() - 1);
/*  595 */     for (int j = 0; j < vectdata.size(); j++) {
/*  596 */       Label labelC = new Label(j, 0, String.valueOf(vectdata.elementAt(j)));
/*      */ 
/*  598 */       ws.addCell(labelC);
/*      */     }
/*  600 */     for (int i = 0; i < arrayData.size() - 1; i++) {
/*  601 */       vectdata = (Vector)arrayData.get(i);
/*  602 */       for (int j = 0; j < vectdata.size(); j++) {
/*  603 */         Label labelC = new Label(j, i + 1, String.valueOf(vectdata.elementAt(j)));
/*      */ 
/*  605 */         ws.addCell(labelC);
/*      */       }
/*      */     }
/*  608 */     wwb.write();
/*  609 */     wwb.close();
/*      */   }
/*      */ 
/*      */   public static synchronized void exportCSVFile(List datalist, String strFileName, String strTitle, String strTitleID)
/*      */   {
/*      */     try
/*      */     {
/*  629 */       PrintWriter pw = new PrintWriter(new FileOutputStream(strFileName));
/*  630 */       pw.println(strTitle);
/*  631 */       Vector vect = StringUtil.getVector(strTitleID, ",");
/*  632 */       Iterator iter = datalist.iterator();
/*      */ 
/*  635 */       while (iter.hasNext()) {
/*  636 */         String m_strValue = "";
/*  637 */         Map map = (Map)iter.next();
/*  638 */         for (int i = 0; i < vect.size(); i++) {
/*  639 */           String m_strTitleID = (String)vect.elementAt(i);
/*  640 */           Object tmpObj = map.get(m_strTitleID);
/*  641 */           String tmpStr = tmpObj == null ? "" : tmpObj.toString();
/*  642 */           if (tmpStr.indexOf(",") > 0) {
/*  643 */             tmpStr = tmpStr.replaceAll(",", "|");
/*      */           }
/*  645 */           m_strValue = m_strValue + tmpStr + ",";
/*      */         }
/*  647 */         if (m_strValue.length() > 0) {
/*  648 */           m_strValue = m_strValue.substring(0, m_strValue.lastIndexOf(","));
/*      */         }
/*  650 */         pw.println(m_strValue);
/*      */       }
/*  652 */       pw.close();
/*      */     } catch (Exception ex) {
/*  654 */       ex.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static synchronized void exportCSVFile(Vector arrayData, String strFileName)
/*      */     throws Exception
/*      */   {
/*  671 */     PrintWriter pw = new PrintWriter(new FileOutputStream(strFileName));
/*  672 */     Vector vectdata = (Vector)arrayData.get(arrayData.size() - 1);
/*  673 */     for (int j = 0; j < vectdata.size(); j++) {
/*  674 */       pw.print(String.valueOf(vectdata.elementAt(j)));
/*  675 */       if (j == vectdata.size() - 1)
/*  676 */         pw.println();
/*      */       else {
/*  678 */         pw.print(",");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  683 */     for (int i = 0; i < arrayData.size() - 1; i++) {
/*  684 */       vectdata = (Vector)arrayData.get(i);
/*  685 */       for (int j = 0; j < vectdata.size(); j++) {
/*  686 */         Object tmpObj = vectdata.elementAt(j);
/*  687 */         String tmpStr = tmpObj == null ? "" : String.valueOf(tmpObj);
/*  688 */         pw.print(tmpStr);
/*  689 */         if (j == vectdata.size() - 1)
/*  690 */           pw.println();
/*      */         else {
/*  692 */           pw.print(",");
/*      */         }
/*      */       }
/*      */     }
/*  696 */     pw.close();
/*      */   }
/*      */ 
/*      */   public static synchronized Vector exportCSVFile(List arrayData, String strFileName, int nMaxCols)
/*      */     throws Exception
/*      */   {
/*  715 */     int nFileNum = 1;
/*  716 */     if (nMaxCols == -1) {
/*  717 */       nMaxCols = arrayData.size() - 1;
/*      */     }
/*  719 */     if (arrayData.size() - 1 > nMaxCols) {
/*  720 */       nFileNum = (arrayData.size() - 1) / nMaxCols + 1;
/*      */     }
/*      */ 
/*  723 */     Vector vectGenFileName = new Vector();
/*  724 */     int nPos = strFileName.lastIndexOf(".");
/*  725 */     String strFileNamePreFix = strFileName.substring(0, nPos);
/*  726 */     String strFileNameNFix = strFileName.substring(nPos);
/*      */ 
/*  728 */     for (int k = 0; k < nFileNum; k++)
/*      */     {
/*      */       String strTmpFileName;
/*      */       String strTmpFileName;
/*  729 */       if (nFileNum != 1)
/*  730 */         strTmpFileName = strFileNamePreFix + "_" + k + strFileNameNFix;
/*      */       else {
/*  732 */         strTmpFileName = strFileName;
/*      */       }
/*  734 */       vectGenFileName.addElement(strTmpFileName);
/*  735 */       PrintWriter pw = new PrintWriter(new FileOutputStream(strTmpFileName));
/*      */ 
/*  737 */       Vector vectdata = (Vector)arrayData.get(arrayData.size() - 1);
/*  738 */       for (int j = 0; j < vectdata.size(); j++) {
/*  739 */         pw.print(String.valueOf(vectdata.elementAt(j)));
/*  740 */         if (j == vectdata.size() - 1)
/*  741 */           pw.println();
/*      */         else
/*  743 */           pw.print(",");
/*      */       }
/*  745 */       int loopEnd = nMaxCols;
/*  746 */       int loopBegin = k * nMaxCols;
/*  747 */       if (k == nFileNum - 1) {
/*  748 */         loopEnd = arrayData.size() - 1;
/*      */       }
/*      */ 
/*  753 */       for (int i = loopBegin; i < loopEnd; i++) {
/*  754 */         vectdata = (Vector)arrayData.get(i);
/*  755 */         for (int j = 0; j < vectdata.size(); j++) {
/*  756 */           Object tmpObj = vectdata.elementAt(j);
/*  757 */           String tmpStr = tmpObj == null ? "" : String.valueOf(tmpObj);
/*  758 */           pw.print(tmpStr);
/*  759 */           if (j == vectdata.size() - 1)
/*  760 */             pw.println();
/*      */           else {
/*  762 */             pw.print(",");
/*      */           }
/*      */         }
/*      */       }
/*  766 */       pw.close();
/*      */     }
/*      */ 
/*  769 */     return vectGenFileName;
/*      */   }
/*      */ 
/*      */   public static synchronized void zipFile(String zipName)
/*      */     throws Exception
/*      */   {
/*  781 */     FileOutputStream dest = new FileOutputStream(zipName);
/*  782 */     ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(dest));
/*      */ 
/*  785 */     String filename = "";
/*  786 */     String path = "";
/*  787 */     if (zipName.indexOf("/") > -1)
/*  788 */       filename = zipName.substring(zipName.lastIndexOf("/") + 1);
/*  789 */     else if (zipName.indexOf("\\") > -1) {
/*  790 */       filename = zipName.substring(zipName.lastIndexOf("\\") + 1);
/*      */     }
/*  792 */     path = zipName.substring(0, zipName.indexOf(filename));
/*      */ 
/*  794 */     File f = new File(path);
/*  795 */     String[] files = f.list();
/*  796 */     byte[] data = new byte[1024];
/*  797 */     for (int i = 0; i < files.length; i++) {
/*  798 */       File fl = new File(path + File.separator + files[i]);
/*  799 */       if ((StringUtil.isNotEmpty(filename)) && (!StringUtil.stringEquals(filename, files[i])) && (fl.isFile()))
/*      */       {
/*  802 */         FileInputStream fi = new FileInputStream(path + File.separator + files[i]);
/*      */ 
/*  806 */         ZipEntry entry = new ZipEntry(files[i]);
/*  807 */         out.putNextEntry(entry);
/*      */         int count;
/*  809 */         while ((count = fi.read(data)) != -1) {
/*  810 */           out.write(data, 0, count);
/*      */         }
/*  812 */         fi.close();
/*      */       }
/*      */     }
/*  815 */     out.flush();
/*  816 */     out.close();
/*      */   }
/*      */ 
/*      */   public void beginExportExcel(String fileName, String sheetName)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/*  834 */       File f = new File(fileName);
/*  835 */       f.createNewFile();
/*      */ 
/*  837 */       this.wwb = Workbook.createWorkbook(new FileOutputStream(f));
/*  838 */       this.ws = this.wwb.createSheet(sheetName, 0);
/*      */     } catch (Exception e) {
/*  840 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addCell(int x, int y, String cellValue, boolean needFormat)
/*      */   {
/*      */     try
/*      */     {
/*  857 */       if (this.ws == null)
/*      */         return;
/*      */       Label labelC;
/*      */       Label labelC;
/*  861 */       if (needFormat) {
/*  862 */         WritableFont font1 = new WritableFont(WritableFont.TAHOMA, 9, WritableFont.BOLD);
/*      */ 
/*  864 */         WritableCellFormat format1 = new WritableCellFormat(font1);
/*      */ 
/*  866 */         labelC = new Label(y, x, cellValue, format1);
/*      */       } else {
/*  868 */         labelC = new Label(y, x, cellValue);
/*  869 */       }this.ws.addCell(labelC);
/*      */     } catch (Exception e) {
/*  871 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addStrCell(int x, int y, String cellValue, WritableFont.FontName fontName, int fontSize, boolean isBold, Alignment align, Colour color, Border border)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/*  891 */       if (this.ws == null) {
/*  892 */         return;
/*      */       }
/*  894 */       if (fontName == null)
/*  895 */         fontName = WritableFont.TAHOMA;
/*  896 */       if (align == null)
/*  897 */         align = Alignment.LEFT;
/*  898 */       if (color == null)
/*  899 */         color = Colour.WHITE;
/*  900 */       if (border == null)
/*  901 */         border = Border.NONE;
/*      */       WritableFont wf;
/*      */       WritableFont wf;
/*  903 */       if (isBold)
/*  904 */         wf = new WritableFont(fontName, fontSize, WritableFont.BOLD);
/*      */       else {
/*  906 */         wf = new WritableFont(fontName, fontSize, WritableFont.NO_BOLD);
/*      */       }
/*  908 */       WritableCellFormat wcf = new WritableCellFormat(wf);
/*  909 */       wcf.setAlignment(align);
/*  910 */       wcf.setBackground(color);
/*  911 */       wcf.setBorder(border, BorderLineStyle.THIN);
/*  912 */       WritableCell labelC = new Label(y, x, cellValue, wcf);
/*      */ 
/*  914 */       this.ws.addCell(labelC);
/*      */     } catch (Exception e) {
/*  916 */       e.printStackTrace();
/*  917 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addDataCell(int x, int y, String cellValue, int dataType)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/*  935 */       if (this.ws == null)
/*  936 */         return;
/*  937 */       WritableCell labelC = null;
/*      */ 
/*  939 */       DisplayFormat df = null;
/*  940 */       if (dataType == 1)
/*      */       {
/*  942 */         df = NumberFormats.THOUSANDS_INTEGER;
/*  943 */       } else if (dataType == 2)
/*      */       {
/*  945 */         df = NumberFormats.THOUSANDS_FLOAT;
/*  946 */       } else if (dataType == 3)
/*      */       {
/*  948 */         df = NumberFormats.PERCENT_FLOAT;
/*  949 */       } else if (dataType == 4)
/*      */       {
/*  951 */         df = NumberFormats.ACCOUNTING_FLOAT;
/*      */       }
/*  953 */       else labelC = new Label(y, x, cellValue);
/*      */ 
/*  955 */       if (df != null) {
/*  956 */         WritableCellFormat wcf = new WritableCellFormat(df);
/*  957 */         if ((cellValue == null) || (cellValue.length() == 0)) {
/*  958 */           cellValue = "0";
/*      */         }
/*  960 */         double numberC = Double.parseDouble(cellValue);
/*  961 */         labelC = new Number(y, x, numberC, wcf);
/*      */       }
/*  963 */       this.ws.addCell(labelC);
/*      */     } catch (Exception e) {
/*  965 */       e.printStackTrace();
/*  966 */       throw e;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void mergeCell(int x1, int y1, int x2, int y2)
/*      */   {
/*      */     try
/*      */     {
/*  984 */       if (this.ws == null)
/*  985 */         return;
/*  986 */       this.ws.mergeCells(x1, y1, x2, y2);
/*      */     } catch (Exception e) {
/*  988 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void endExportExcel()
/*      */   {
/*      */     try
/*      */     {
/*  998 */       if (this.wwb == null)
/*  999 */         return;
/* 1000 */       this.wwb.write();
/* 1001 */       this.wwb.close();
/*      */     } catch (Exception e) {
/* 1003 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void exportExcelByVector(Vector vect, String strFileName, String sheetName)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1025 */       File f = new File(strFileName);
/* 1026 */       f.createNewFile();
/*      */ 
/* 1028 */       WritableWorkbook wwb = Workbook.createWorkbook(new FileOutputStream(f));
/*      */ 
/* 1030 */       WritableSheet ws = wwb.createSheet(sheetName, 0);
/*      */ 
/* 1034 */       NumberFormat nf = new NumberFormat("#,##0");
/* 1035 */       NumberFormat nfP = new NumberFormat("0.00%");
/* 1036 */       WritableCellFormat wcfN = new WritableCellFormat(nf);
/* 1037 */       WritableCellFormat wcfNP = new WritableCellFormat(nfP);
/*      */ 
/* 1039 */       int rowCnt = vect.size();
/*      */ 
/* 1041 */       for (int i = 0; i < rowCnt; i++) {
/* 1042 */         Vector subvect = (Vector)vect.elementAt(i);
/* 1043 */         for (int j = 0; j < subvect.size(); j++) { String cellValue = (String)subvect.elementAt(j);
/* 1045 */           double numberC = 0.0D;
/*      */           WritableCell cellW;
/*      */           try { WritableCellFormat wcFormat = wcfN;
/* 1048 */             String strNum = cellValue;
/* 1049 */             if (strNum.indexOf(",") > 0)
/* 1050 */               strNum = strNum.replaceAll(",", "");
/* 1051 */             boolean bPercent = false;
/* 1052 */             if (strNum.indexOf("%") > 0) {
/* 1053 */               bPercent = true;
/* 1054 */               strNum = strNum.substring(0, strNum.indexOf("%"));
/* 1055 */               wcFormat = wcfNP;
/*      */             }
/* 1057 */             numberC = Double.parseDouble(strNum);
/* 1058 */             if (bPercent) {
/* 1059 */               numberC /= 100.0D;
/*      */             }
/* 1061 */             cellW = new Number(j, i, numberC, wcFormat);
/*      */           } catch (Exception ex) {
/* 1063 */             cellW = new Label(j, i, cellValue);
/*      */           }
/*      */ 
/* 1066 */           ws.addCell(cellW);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1071 */       wwb.write();
/*      */ 
/* 1073 */       wwb.close();
/*      */     } catch (Exception e) {
/* 1075 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void exportExcelByVectorOfExceed(Vector vect, String strFileName, String sheetName)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1095 */       File f = new File(strFileName);
/* 1096 */       f.createNewFile();
/* 1097 */       WritableWorkbook wwb = Workbook.createWorkbook(new FileOutputStream(f));
/*      */ 
/* 1099 */       int vs = (vect.size() - 1) / 65000;
/* 1100 */       int vc = (vect.size() - 1) % 65000;
/* 1101 */       if ((vc > 0) || (vect.size() == 1))
/* 1102 */         vs++;
/* 1103 */       WritableSheet[] ws = new WritableSheet[vs];
/* 1104 */       for (int i = vs - 1; i >= 0; i--) {
/* 1105 */         ws[i] = wwb.createSheet(sheetName + i, i - 1);
/*      */       }
/*      */ 
/* 1108 */       NumberFormat nf = new NumberFormat("#,##0");
/* 1109 */       NumberFormat nfP = new NumberFormat("0.00%");
/* 1110 */       WritableCellFormat wcfN = new WritableCellFormat(nf);
/* 1111 */       WritableCellFormat wcfNP = new WritableCellFormat(nfP);
/*      */ 
/* 1113 */       for (int s = 0; s < vs; s++) {
/* 1114 */         int rowCnt = 0;
/* 1115 */         if (vs == 1)
/* 1116 */           rowCnt = vect.size() - 1;
/* 1117 */         else if (s != vs - 1)
/* 1118 */           rowCnt = 65000 * (s + 1);
/*      */         else {
/* 1120 */           rowCnt = vc;
/*      */         }
/*      */ 
/* 1123 */         Vector subvect = (Vector)vect.elementAt(0);
/* 1124 */         for (int j = 0; j < subvect.size(); j++) {
/* 1125 */           String cellValue = (String)subvect.elementAt(j);
/* 1126 */           WritableCell cellW = new Label(j, 0, cellValue);
/* 1127 */           ws[s].addCell(cellW);
/*      */         }
/*      */ 
/* 1130 */         for (int i = 1; i <= rowCnt; i++) {
/* 1131 */           subvect = (Vector)vect.elementAt(i + s * 6500);
/* 1132 */           for (int j = 0; j < subvect.size(); j++) { String cellValue = (String)subvect.elementAt(j);
/* 1134 */             double numberC = 0.0D;
/*      */             WritableCell cellW;
/*      */             try { WritableCellFormat wcFormat = wcfN;
/* 1137 */               String strNum = cellValue;
/* 1138 */               if (strNum.indexOf(",") > 0)
/* 1139 */                 strNum = strNum.replaceAll(",", "");
/* 1140 */               boolean bPercent = false;
/* 1141 */               if (strNum.indexOf("%") > 0) {
/* 1142 */                 bPercent = true;
/* 1143 */                 strNum = strNum.substring(0, strNum.indexOf("%"));
/*      */ 
/* 1145 */                 wcFormat = wcfNP;
/*      */               }
/* 1147 */               numberC = Double.parseDouble(strNum);
/* 1148 */               if (bPercent) {
/* 1149 */                 numberC /= 100.0D;
/*      */               }
/* 1151 */               cellW = new Number(j, i, numberC, wcFormat);
/*      */             } catch (Exception ex)
/*      */             {
/* 1154 */               cellW = new Label(j, i, cellValue);
/*      */             }
/*      */ 
/* 1157 */             ws[s].addCell(cellW);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1162 */       wwb.write();
/*      */ 
/* 1164 */       wwb.close();
/*      */     } catch (Exception e) {
/* 1166 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.ExportUtil
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.export;
/*     */ 
/*     */ import com.lowagie.text.Cell;
/*     */ import com.lowagie.text.Chapter;
/*     */ import com.lowagie.text.Chunk;
/*     */ import com.lowagie.text.Document;
/*     */ import com.lowagie.text.DocumentException;
/*     */ import com.lowagie.text.Font;
/*     */ import com.lowagie.text.PageSize;
/*     */ import com.lowagie.text.Paragraph;
/*     */ import com.lowagie.text.Table;
/*     */ import com.lowagie.text.pdf.BaseFont;
/*     */ import com.lowagie.text.pdf.PdfWriter;
/*     */ import java.awt.Color;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ public class PdfUtil
/*     */ {
/*  37 */   private static BaseFont BaseFont_ZH = null;
/*     */ 
/*     */   protected static Document createPdf(OutputStream os)
/*     */   {
/*  55 */     Document pdfDoc = null;
/*     */ 
/*  57 */     pdfDoc = new Document(PageSize.A4, 10.0F, 10.0F, 40.0F, 20.0F);
/*     */     try
/*     */     {
/*  60 */       PdfWriter writer = PdfWriter.getInstance(pdfDoc, os);
/*  61 */       pdfDoc.open();
/*     */     } catch (DocumentException e) {
/*  63 */       e.printStackTrace();
/*     */     }
/*  65 */     return pdfDoc;
/*     */   }
/*     */ 
/*     */   protected static Document createPdf(File file)
/*     */   {
/*  77 */     OutputStream os = null;
/*     */     try {
/*  79 */       os = new FileOutputStream(file);
/*     */     } catch (FileNotFoundException e) {
/*  81 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  84 */     return createPdf(os);
/*     */   }
/*     */ 
/*     */   protected static Paragraph addParagraph(Document doc)
/*     */   {
/*  95 */     Font subsectFont = new Font(BaseFont_ZH, 0.0F, 0, new Color(255, 255, 255));
/*  96 */     Paragraph paragraph = new Paragraph("", subsectFont);
/*  97 */     return paragraph;
/*     */   }
/*     */ 
/*     */   protected static Table createTable(int columnSize)
/*     */   {
/* 109 */     Table table = null;
/*     */     try {
/* 111 */       table = new Table(columnSize);
/* 112 */       table.setBorder(0);
/* 113 */       table.setDefaultHorizontalAlignment(1);
/* 114 */       table.setDefaultVerticalAlignment(1);
/* 115 */       table.setPadding(2.0F);
/*     */     } catch (Exception e) {
/* 117 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 120 */     return table;
/*     */   }
/*     */ 
/*     */   protected static Chapter addPdfChapter(Document doc, String chapterName)
/*     */   {
/* 133 */     Font subsectFont = new Font(BaseFont_ZH, 12.0F, 3, new Color(0, 0, 0));
/*     */ 
/* 135 */     Paragraph cTitle = new Paragraph(chapterName, subsectFont);
/* 136 */     Chapter chapter = new Chapter(cTitle, 0);
/* 137 */     chapter.setBookmarkOpen(false);
/* 138 */     chapter.setNumberDepth(0);
/*     */ 
/* 140 */     return chapter;
/*     */   }
/*     */ 
/*     */   protected static Cell createCell(Object obj)
/*     */   {
/* 152 */     if (null == obj)
/* 153 */       return createCellText("");
/* 154 */     if (((obj instanceof Integer)) || ((obj instanceof Double)) || ((obj instanceof BigDecimal)) || ((obj instanceof Float)))
/*     */     {
/* 156 */       return createCellNumber(obj.toString());
/*     */     }
/* 158 */     return createCellText(obj.toString());
/*     */   }
/*     */ 
/*     */   protected static Cell createCellHeader(Object obj)
/*     */   {
/* 171 */     Cell cell = null;
/*     */     try {
/* 173 */       Font font_header = new Font(BaseFont_ZH, 10.0F, 1, new Color(0, 0, 0));
/* 174 */       cell = new Cell(new Chunk(obj.toString(), font_header));
/* 175 */       cell.setBackgroundColor(Color.lightGray);
/* 176 */       cell.setHorizontalAlignment(1);
/* 177 */       cell.setVerticalAlignment(5);
/*     */     } catch (Exception e) {
/* 179 */       e.printStackTrace();
/*     */     }
/* 181 */     return cell;
/*     */   }
/*     */ 
/*     */   private static Cell createCellText(String obj) {
/* 185 */     Cell cell = null;
/*     */     try {
/* 187 */       cell = new Cell(new Chunk(obj.toString(), new Font(BaseFont_ZH, 9.0F, 0, new Color(0, 0, 0))));
/*     */ 
/* 189 */       cell.setHorizontalAlignment(0);
/* 190 */       cell.setVerticalAlignment(8);
/*     */     } catch (Exception e) {
/* 192 */       e.printStackTrace();
/*     */     }
/* 194 */     return cell;
/*     */   }
/*     */ 
/*     */   private static Cell createCellNumber(String obj) {
/* 198 */     Cell cell = null;
/*     */     try {
/* 200 */       cell = new Cell(new Chunk(obj.toString(), new Font(BaseFont_ZH, 9.0F, 0, new Color(0, 0, 0))));
/*     */ 
/* 202 */       cell.setHorizontalAlignment(2);
/* 203 */       cell.setVerticalAlignment(8);
/* 204 */       cell.setNoWrap(true);
/*     */     } catch (Exception e) {
/* 206 */       e.printStackTrace();
/*     */     }
/* 208 */     return cell;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  40 */       BaseFont_ZH = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", true);
/*     */     } catch (Exception e) {
/*  42 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.PdfUtil
 * JD-Core Version:    0.6.2
 */
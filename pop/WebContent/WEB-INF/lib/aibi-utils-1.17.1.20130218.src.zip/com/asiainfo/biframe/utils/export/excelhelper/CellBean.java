/*    */ package com.asiainfo.biframe.utils.export.excelhelper;
/*    */ 
/*    */ public class CellBean
/*    */ {
/*    */   private int rowindex;
/*    */   private int colindex;
/*    */   private int rowlength;
/*    */   private int collength;
/*    */   private String value;
/*    */ 
/*    */   public CellBean()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CellBean(int rowindex, int colindex, String value, int rowlength, int collength)
/*    */   {
/* 10 */     this.rowindex = rowindex;
/* 11 */     this.colindex = colindex;
/* 12 */     this.value = value;
/* 13 */     this.rowlength = rowlength;
/* 14 */     this.collength = collength;
/*    */   }
/*    */   public CellBean(int rowindex, int colindex, String value) {
/* 17 */     this.rowindex = rowindex;
/* 18 */     this.colindex = colindex;
/* 19 */     this.value = value;
/* 20 */     this.rowlength = 1;
/* 21 */     this.collength = 1;
/*    */   }
/*    */ 
/*    */   public int getRowindex()
/*    */   {
/* 42 */     return this.rowindex;
/*    */   }
/*    */ 
/*    */   public void setRowindex(int rowindex) {
/* 46 */     this.rowindex = rowindex;
/*    */   }
/*    */ 
/*    */   public int getColindex() {
/* 50 */     return this.colindex;
/*    */   }
/*    */ 
/*    */   public void setColindex(int colindex) {
/* 54 */     this.colindex = colindex;
/*    */   }
/*    */ 
/*    */   public int getRowlength() {
/* 58 */     return this.rowlength;
/*    */   }
/*    */ 
/*    */   public void setRowlength(int rowlength) {
/* 62 */     this.rowlength = rowlength;
/*    */   }
/*    */ 
/*    */   public int getCollength() {
/* 66 */     return this.collength;
/*    */   }
/*    */ 
/*    */   public void setCollength(int collength) {
/* 70 */     this.collength = collength;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 74 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String value) {
/* 78 */     this.value = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.CellBean
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.export.excelhelper;
/*    */ 
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.BufferedOutputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.net.URLEncoder;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class DownloadFactory
/*    */ {
/*    */   public void downloadfile(HttpServletResponse response, String fileName)
/*    */     throws FileNotFoundException
/*    */   {
/*    */     try
/*    */     {
/* 21 */       if (response == null) {
/* 22 */         return;
/*    */       }
/*    */ 
/* 25 */       File file = new File(fileName);
/*    */ 
/* 27 */       String filename = file.getName();
/*    */ 
/* 32 */       InputStream fis = new BufferedInputStream(new FileInputStream(fileName));
/* 33 */       byte[] buffer = new byte[fis.available()];
/* 34 */       fis.read(buffer);
/* 35 */       fis.close();
/*    */ 
/* 37 */       response.reset();
/*    */ 
/* 39 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(filename, "UTF-8") + "\"");
/*    */ 
/* 42 */       response.addHeader("Content-Length", "" + file.length());
/* 43 */       OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
/* 44 */       response.setContentType("application/octet-stream");
/* 45 */       toClient.write(buffer);
/* 46 */       toClient.flush();
/* 47 */       toClient.close();
/*    */     } catch (IOException ex) {
/* 49 */       ex.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.DownloadFactory
 * JD-Core Version:    0.6.2
 */
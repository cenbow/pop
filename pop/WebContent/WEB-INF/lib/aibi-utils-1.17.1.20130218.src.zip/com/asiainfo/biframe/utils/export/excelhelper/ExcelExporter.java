/*     */ package com.asiainfo.biframe.utils.export.excelhelper;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ public class ExcelExporter
/*     */   implements IExcelExporter
/*     */ {
/*  25 */   private static final Logger logger = Logger.getLogger(ExcelExporter.class);
/*     */   private static final String DEFAULTSHEETNAME = "sheet-1";
/*  28 */   private static final String DEFAULTPATH = System.getProperty("user.home") + File.separatorChar + "TEMPEXCELFILE" + File.separatorChar;
/*     */ 
/*  30 */   private String FileName = "";
/*  31 */   private String SheetName = "";
/*  32 */   private String DirPath = "";
/*     */ 
/*  34 */   private final String fileNotFoundMsg = "The file to download not found";
/*  35 */   private final String downloadMsg = "Download failed";
/*     */ 
/*  37 */   private ExcelFactory excelFactory = new ExcelFactory();
/*  38 */   private DownloadFactory downloadFactory = new DownloadFactory();
/*     */ 
/*     */   public ExcelFactory getExcelFactory() {
/*  41 */     return this.excelFactory;
/*     */   }
/*     */ 
/*     */   public void setExcelFactory(ExcelFactory excelFactory) {
/*  45 */     this.excelFactory = excelFactory;
/*     */   }
/*     */ 
/*     */   public DownloadFactory getDownloadFactory() {
/*  49 */     return this.downloadFactory;
/*     */   }
/*     */ 
/*     */   public void setDownloadFactory(DownloadFactory downloadFactory) {
/*  53 */     this.downloadFactory = downloadFactory;
/*     */   }
/*     */ 
/*     */   public void exportExcelByHM(String sheetName, Collection<Map<String, String>> dataset, String[] headers, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/*  63 */       String fileName = exportToFileByHM(null, null, sheetName, dataset, headers);
/*  64 */       this.downloadFactory.downloadfile(response, fileName);
/*     */     } catch (FileNotFoundException fnfe) {
/*  66 */       logger.error("The file to download not found");
/*  67 */       logger.debug("ExcelExporter.expoertExcelByHM():", fnfe);
/*     */     } catch (IOException ioe) {
/*  69 */       logger.error("Download failed");
/*  70 */       logger.debug("ExcelExporter.expoertExcelByHM():", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByHM(String sheetName, Collection<Map<String, String>> dataset, List<CellBean> headerList, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/*  80 */       String fileName = exportToFileByHM(null, null, sheetName, dataset, headerList);
/*  81 */       this.downloadFactory.downloadfile(response, fileName);
/*     */     } catch (FileNotFoundException fnfe) {
/*  83 */       logger.error("The file to download not found");
/*  84 */       logger.debug("ExcelExporter.expoertExcelByHM():", fnfe);
/*     */     } catch (IOException ioe) {
/*  86 */       logger.error("Download failed");
/*  87 */       logger.debug("ExcelExporter.expoertExcelByHM():", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByHMWithHeaders(String fileName, Collection<Map<String, String>> dataset, String[] headers, String[] exportColumns, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/*  99 */       String downloadFileName = exportToFileByHMWithHeaders(null, fileName, null, dataset, headers, exportColumns);
/* 100 */       this.downloadFactory.downloadfile(response, downloadFileName);
/*     */     } catch (FileNotFoundException fnfe) {
/* 102 */       logger.error("The file to download not found");
/* 103 */       logger.debug("ExcelExporter.expoertExcelByHM():", fnfe);
/*     */     } catch (IOException ioe) {
/* 105 */       logger.error("Download failed");
/* 106 */       logger.debug("ExcelExporter.expoertExcelByHM():", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByHMWithHeaders(String fileName, Collection<Map<String, String>> dataset, String[] headers, String[] exportColumns, HttpServletResponse response, String colFmt)
/*     */   {
/* 119 */     if (colFmt == null)
/* 120 */       exportExcelByHMWithHeaders(fileName, dataset, headers, exportColumns, response);
/*     */     else
/*     */       try {
/* 123 */         String downloadFileName = null;
/* 124 */         initial(null, fileName, null);
/* 125 */         HSSFWorkbook workbook = this.excelFactory.createWorkbookByHMWithHeaders(this.SheetName, dataset, headers, exportColumns, colFmt);
/* 126 */         POIExcelHelper.save(workbook, this.DirPath, this.FileName);
/* 127 */         downloadFileName = this.DirPath + this.FileName;
/* 128 */         this.downloadFactory.downloadfile(response, downloadFileName);
/*     */       } catch (FileNotFoundException fnfe) {
/* 130 */         logger.error("The file to download not found");
/* 131 */         logger.debug("ExcelExporter.expoertExcelByHM():", fnfe);
/*     */       } catch (IOException ioe) {
/* 133 */         logger.error("Download failed");
/* 134 */         logger.debug("ExcelExporter.expoertExcelByHM():", ioe);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void exportExcelByHMWithHeaders(String fileName, Collection<Map<String, String>> dataset, List<CellBean> headerList, String[] exportColumns, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/* 145 */       String downloadFileName = exportToFileByHMWithHeaders(null, fileName, null, dataset, headerList, exportColumns);
/* 146 */       this.downloadFactory.downloadfile(response, downloadFileName);
/*     */     } catch (FileNotFoundException fnfe) {
/* 148 */       logger.error("The file to download not found");
/* 149 */       logger.debug("ExcelExporter.expoertExcelByHM():", fnfe);
/*     */     } catch (IOException ioe) {
/* 151 */       logger.error("Download failed");
/* 152 */       logger.debug("ExcelExporter.expoertExcelByHM():", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByHMWithHeaders(String fileName, Collection<Map<String, String>> dataset, List<CellBean> headerList, String[] exportColumns, HttpServletResponse response, String colFmt)
/*     */   {
/*     */     try
/*     */     {
/* 166 */       String downloadFileName = exportToFileByHMWithHeaders(null, fileName, null, dataset, headerList, exportColumns, colFmt);
/* 167 */       this.downloadFactory.downloadfile(response, downloadFileName);
/*     */     } catch (FileNotFoundException fnfe) {
/* 169 */       logger.error("The file to download not found");
/* 170 */       logger.debug("ExcelExporter.expoertExcelByHM():", fnfe);
/*     */     } catch (IOException ioe) {
/* 172 */       logger.error("Download failed");
/* 173 */       logger.debug("ExcelExporter.expoertExcelByHM():", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByL(String sheetName, Collection<List<String>> dataset, String[] headers, HttpServletResponse response)
/*     */   {
/* 182 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/*     */     try {
/* 184 */       String fileName = exportToFileByL(null, null, sheetName, dataset, headers);
/* 185 */       this.downloadFactory.downloadfile(response, fileName);
/*     */     } catch (FileNotFoundException fnfe) {
/* 187 */       logger.error("The file to download not found");
/* 188 */       logger.debug("ExcelExporter.exportExcelByL():", fnfe);
/*     */     } catch (IOException ioe) {
/* 190 */       logger.error("Download failed");
/* 191 */       logger.debug("ExcelExporter.exportExcelByL():", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByL(String sheetName, Collection<List<String>> dataset, List<CellBean> headerList, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/* 203 */       String fileName = exportToFileByL(null, null, sheetName, dataset, headerList);
/* 204 */       this.downloadFactory.downloadfile(response, fileName);
/*     */     } catch (FileNotFoundException fnfe) {
/* 206 */       logger.error("The file to download not found");
/* 207 */       logger.debug("ExcelExporter.exportExcelByL():", fnfe);
/*     */     } catch (IOException ioe) {
/* 209 */       logger.error("Download failed");
/* 210 */       logger.debug("ExcelExporter.exportExcelByL():", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelMSheetByL(String fileName, List<SheetLBean> sheets, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/* 221 */       String tempFileName = exportMSheetToFileByL(null, fileName, sheets);
/* 222 */       this.downloadFactory.downloadfile(response, tempFileName);
/*     */     } catch (FileNotFoundException fnfe) {
/* 224 */       logger.error("The file to download not found");
/* 225 */       logger.debug("ExcelExporter.exportExcelByL():", fnfe);
/*     */     } catch (IOException ioe) {
/* 227 */       logger.error("Download failed");
/* 228 */       logger.debug("ExcelExporter.exportExcelByL():", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String exportToFileByHM(String dir, String fileName, String sheetName, Collection<Map<String, String>> dataset, String[] selExportColumns)
/*     */     throws IOException
/*     */   {
/* 242 */     initial(dir, fileName, sheetName);
/* 243 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookByHM(this.SheetName, dataset, selExportColumns);
/* 244 */     POIExcelHelper.save(workbook, this.DirPath, this.FileName);
/* 245 */     return this.DirPath + this.FileName;
/*     */   }
/*     */ 
/*     */   private String exportToFileByHM(String dir, String fileName, String sheetName, Collection<Map<String, String>> dataset, List<CellBean> headerList)
/*     */     throws IOException
/*     */   {
/* 258 */     initial(dir, fileName, sheetName);
/* 259 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookByHM(this.SheetName, dataset, headerList);
/* 260 */     POIExcelHelper.save(workbook, this.DirPath, this.FileName);
/* 261 */     return this.DirPath + this.FileName;
/*     */   }
/*     */ 
/*     */   public String exportToFileByHMWithHeaders(String dir, String fileName, String sheetName, Collection<Map<String, String>> dataset, String[] headers, String[] exportColumns)
/*     */     throws IOException
/*     */   {
/* 279 */     initial(dir, fileName, sheetName);
/* 280 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookByHMWithHeaders(this.SheetName, dataset, headers, exportColumns);
/* 281 */     POIExcelHelper.save(workbook, this.DirPath, this.FileName);
/* 282 */     return this.DirPath + this.FileName;
/*     */   }
/*     */ 
/*     */   public OutputStream exportToStreamByHMWithHeaders(String dir, String fileName, String sheetName, Collection<Map<String, String>> dataset, String[] headers, String[] exportColumns)
/*     */     throws IOException
/*     */   {
/* 299 */     initial(dir, fileName, sheetName);
/* 300 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookByHMWithHeaders(this.SheetName, dataset, headers, exportColumns);
/* 301 */     return POIExcelHelper.saveToStream(workbook, this.DirPath, this.FileName);
/*     */   }
/*     */ 
/*     */   public String exportToFileByHMWithHeaders(String dir, String fileName, String sheetName, Collection<Map<String, String>> dataset, List<CellBean> headerList, String[] exportColumns)
/*     */     throws IOException
/*     */   {
/* 318 */     initial(dir, fileName, sheetName);
/* 319 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookByHMWithHeaders(this.SheetName, dataset, headerList, exportColumns);
/* 320 */     POIExcelHelper.save(workbook, this.DirPath, this.FileName);
/* 321 */     return this.DirPath + this.FileName;
/*     */   }
/*     */ 
/*     */   public String exportToFileByHMWithHeaders(String dir, String fileName, String sheetName, Collection<Map<String, String>> dataset, List<CellBean> headerList, String[] exportColumns, String colFmt)
/*     */     throws IOException
/*     */   {
/* 338 */     initial(dir, fileName, sheetName);
/* 339 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookByHMWithHeaders(this.SheetName, dataset, headerList, exportColumns, colFmt);
/* 340 */     POIExcelHelper.save(workbook, this.DirPath, this.FileName);
/* 341 */     return this.DirPath + this.FileName;
/*     */   }
/*     */ 
/*     */   public OutputStream exportToStreamByHMWithHeaders(String dir, String fileName, String sheetName, Collection<Map<String, String>> dataset, List<CellBean> headerList, String[] exportColumns)
/*     */     throws IOException
/*     */   {
/* 358 */     initial(dir, fileName, sheetName);
/* 359 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookByHMWithHeaders(this.SheetName, dataset, headerList, exportColumns);
/* 360 */     return POIExcelHelper.saveToStream(workbook, this.DirPath, this.FileName);
/*     */   }
/*     */ 
/*     */   private String exportToFileByL(String dir, String fileName, String sheetName, Collection<List<String>> dataset, String[] selExportColumns)
/*     */     throws IOException
/*     */   {
/* 372 */     initial(dir, fileName, sheetName);
/* 373 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookByL(this.SheetName, dataset, selExportColumns);
/* 374 */     POIExcelHelper.save(workbook, this.DirPath, fileName);
/* 375 */     return this.DirPath + this.FileName;
/*     */   }
/*     */ 
/*     */   private String exportToFileByL(String dir, String fileName, String sheetName, Collection<List<String>> dataset, List<CellBean> headerList)
/*     */     throws IOException
/*     */   {
/* 387 */     initial(dir, fileName, sheetName);
/* 388 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookByL(this.SheetName, dataset, headerList);
/* 389 */     POIExcelHelper.save(workbook, this.DirPath, this.FileName);
/* 390 */     return this.DirPath + this.FileName;
/*     */   }
/*     */ 
/*     */   private String exportMSheetToFileByL(String dir, String fileName, List<SheetLBean> sheets) throws IOException {
/* 394 */     initial(dir, fileName, null);
/* 395 */     HSSFWorkbook workbook = this.excelFactory.createWorkbookMSheetByL(sheets);
/* 396 */     POIExcelHelper.save(workbook, this.DirPath, this.FileName);
/* 397 */     return this.DirPath + this.FileName;
/*     */   }
/*     */ 
/*     */   private void initial(String dir, String fileName, String sheetName)
/*     */   {
/* 407 */     logger.debug("dir=[" + dir + "],fileName=[" + fileName + "],sheetName=[" + sheetName + "]");
/* 408 */     int pos = 0;
/* 409 */     if (fileName != null) {
/* 410 */       pos = fileName.lastIndexOf(File.separatorChar);
/* 411 */       if (pos > 0) {
/* 412 */         this.DirPath = "";
/* 413 */         this.FileName = fileName;
/*     */       }
/*     */     } else {
/* 416 */       if ((dir == null) || (dir.trim().equals("")))
/* 417 */         this.DirPath = DEFAULTPATH;
/*     */       else {
/* 419 */         this.DirPath = dir;
/*     */       }
/* 421 */       if ((fileName == null) || (fileName.trim().equals(""))) {
/* 422 */         this.FileName = (sheetName + ".xls");
/*     */       }
/*     */     }
/*     */ 
/* 426 */     if ((sheetName == null) || (sheetName.trim().equals("")))
/*     */       try {
/* 428 */         pos = pos > 0 ? pos : 0;
/*     */ 
/* 430 */         int p = fileName.lastIndexOf(".");
/* 431 */         int len = Math.min(p - pos, 30);
/* 432 */         this.SheetName = fileName.substring(pos + 1, pos + 1 + len);
/*     */       } catch (Exception ex) {
/* 434 */         this.SheetName = "sheet-1";
/*     */       }
/*     */     else {
/* 437 */       this.SheetName = sheetName;
/*     */     }
/* 439 */     logger.debug("DirPath=[" + this.DirPath + "],FileName=[" + this.FileName + "],SheetName=[" + this.SheetName + "]");
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.ExcelExporter
 * JD-Core Version:    0.6.2
 */
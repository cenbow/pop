/*     */ package com.asiainfo.biframe.utils.export.excelhelper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ public class ExcelFactory
/*     */ {
/*  16 */   private short DEFAULTCOLUMNWIDTH = 15;
/*     */   private static final String DEFAULTSHEETNAME = "sheet-1";
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByL(String sheetName, Collection<List<String>> dataset, String[] selExportColumns)
/*     */   {
/*  33 */     HSSFWorkbook workbook = new HSSFWorkbook();
/*  34 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*  35 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/*  36 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), selExportColumns);
/*     */ 
/*  38 */     POIExcelHelper.parseDataByL(sheet, dataset, POIExcelHelper.getDefaultFootStyle(workbook));
/*     */ 
/*  40 */     return workbook;
/*     */   }
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByL(String sheetName, Collection<List<String>> dataset, List<CellBean> headerList)
/*     */   {
/*  56 */     HSSFWorkbook workbook = new HSSFWorkbook();
/*  57 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*  58 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/*  59 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), headerList);
/*     */ 
/*  61 */     int headerRowSize = getHeadRowSize(headerList);
/*  62 */     POIExcelHelper.parseDataByL(sheet, dataset, headerRowSize, POIExcelHelper.getDefaultFootStyle(workbook));
/*     */ 
/*  64 */     return workbook;
/*     */   }
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByHM(String sheetName, Collection<Map<String, String>> list, String[] selExportColumns)
/*     */   {
/*  74 */     HSSFWorkbook workbook = new HSSFWorkbook();
/*  75 */     if ((sheetName == null) || (sheetName.equals(""))) {
/*  76 */       sheetName = "sheet-1";
/*     */     }
/*  78 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*     */ 
/*  80 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/*  81 */     if ((list == null) || (list.size() == 0)) {
/*  82 */       return workbook;
/*     */     }
/*     */ 
/*  85 */     String[] exportColumns = null;
/*  86 */     if (selExportColumns != null) {
/*  87 */       exportColumns = selExportColumns;
/*     */     } else {
/*  89 */       Map hm = (Map)list.iterator().next();
/*  90 */       Set set = hm.keySet();
/*  91 */       exportColumns = new String[set.size()];
/*  92 */       set.toArray(exportColumns);
/*     */     }
/*     */ 
/*  95 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), exportColumns);
/*  96 */     POIExcelHelper.parseDataByHM(sheet, list, POIExcelHelper.getDefaultFootStyle(workbook), exportColumns);
/*     */ 
/*  98 */     return workbook;
/*     */   }
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByHM(String sheetName, Collection<Map<String, String>> dataset, List<CellBean> headerList)
/*     */   {
/* 109 */     HSSFWorkbook workbook = new HSSFWorkbook();
/* 110 */     if ((sheetName == null) || (sheetName.equals(""))) {
/* 111 */       sheetName = "sheet-1";
/*     */     }
/* 113 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*     */ 
/* 115 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/* 116 */     if ((dataset == null) || (dataset.size() == 0)) {
/* 117 */       return workbook;
/*     */     }
/*     */ 
/* 120 */     List headerNameList = new ArrayList();
/* 121 */     Map hm = (Map)dataset.iterator().next();
/* 122 */     Set set = hm.keySet();
/* 123 */     for (CellBean cb : headerList) {
/* 124 */       String value = cb.getValue();
/* 125 */       if (set.contains(value)) {
/* 126 */         headerNameList.add(value);
/*     */       }
/*     */     }
/* 129 */     String[] exportColumns = new String[headerNameList.size()];
/* 130 */     exportColumns = (String[])headerNameList.toArray(exportColumns);
/*     */ 
/* 132 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), headerList);
/* 133 */     int headerRowSize = getHeadRowSize(headerList);
/* 134 */     POIExcelHelper.parseDataByHM(sheet, dataset, POIExcelHelper.getDefaultFootStyle(workbook), exportColumns, headerRowSize);
/* 135 */     return workbook;
/*     */   }
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByHMWithHeaders(String sheetName, Collection<Map<String, String>> list, String[] headers, String[] exportColumns)
/*     */   {
/* 150 */     HSSFWorkbook workbook = new HSSFWorkbook();
/* 151 */     if ((sheetName == null) || (sheetName.equals(""))) {
/* 152 */       sheetName = "sheet-1";
/*     */     }
/* 154 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*     */ 
/* 156 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/* 157 */     if ((list == null) || (list.size() == 0)) {
/* 158 */       return workbook;
/*     */     }
/*     */ 
/* 161 */     if ((headers == null) || (headers.length == 0)) {
/* 162 */       if (exportColumns != null) {
/* 163 */         headers = exportColumns;
/*     */       } else {
/* 165 */         Map hm = (Map)list.iterator().next();
/* 166 */         Set set = hm.keySet();
/* 167 */         headers = new String[set.size()];
/* 168 */         set.toArray(headers);
/*     */       }
/*     */     }
/* 171 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), headers);
/* 172 */     POIExcelHelper.parseDataByHM(sheet, list, POIExcelHelper.getDefaultFootStyle(workbook), exportColumns);
/*     */ 
/* 174 */     return workbook;
/*     */   }
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByHMWithHeaders(String sheetName, Collection<Map<String, String>> list, String[] headers, String[] exportColumns, String colFmt)
/*     */   {
/* 188 */     HSSFWorkbook workbook = new HSSFWorkbook();
/* 189 */     if ((sheetName == null) || (sheetName.equals(""))) {
/* 190 */       sheetName = "sheet-1";
/*     */     }
/* 192 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*     */ 
/* 194 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/*     */ 
/* 196 */     if ((headers == null) || (headers.length == 0)) {
/* 197 */       if (exportColumns != null) {
/* 198 */         headers = exportColumns;
/*     */       } else {
/* 200 */         Map hm = (Map)list.iterator().next();
/* 201 */         Set set = hm.keySet();
/* 202 */         headers = new String[set.size()];
/* 203 */         set.toArray(headers);
/*     */       }
/*     */     }
/* 206 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), headers);
/* 207 */     if ((list == null) || (list.size() == 0)) {
/* 208 */       return workbook;
/*     */     }
/* 210 */     POIExcelHelper.parseDataByHM(sheet, list, POIExcelHelper.getDefaultFootStyle(workbook), exportColumns, 1, colFmt, workbook);
/*     */ 
/* 212 */     return workbook;
/*     */   }
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByHMWithHeaders(String sheetName, Collection<Map<String, String>> dataset, List<CellBean> headerList, String[] exportColumns)
/*     */   {
/* 227 */     HSSFWorkbook workbook = new HSSFWorkbook();
/* 228 */     if ((sheetName == null) || (sheetName.equals(""))) {
/* 229 */       sheetName = "sheet-1";
/*     */     }
/* 231 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*     */ 
/* 233 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/* 234 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), headerList);
/* 235 */     if ((dataset == null) || (dataset.size() == 0)) {
/* 236 */       return workbook;
/*     */     }
/*     */ 
/* 239 */     int headerRowSize = getHeadRowSize(headerList);
/* 240 */     POIExcelHelper.parseDataByHM(sheet, dataset, POIExcelHelper.getDefaultFootStyle(workbook), exportColumns, headerRowSize);
/* 241 */     return workbook;
/*     */   }
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByHMWithHeaders(String sheetName, Collection<Map<String, String>> dataset, List<CellBean> headerList, String[] exportColumns, String colFmt)
/*     */   {
/* 256 */     HSSFWorkbook workbook = new HSSFWorkbook();
/* 257 */     if ((sheetName == null) || (sheetName.equals(""))) {
/* 258 */       sheetName = "sheet-1";
/*     */     }
/* 260 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*     */ 
/* 262 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/* 263 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), headerList);
/* 264 */     if ((dataset == null) || (dataset.size() == 0)) {
/* 265 */       return workbook;
/*     */     }
/*     */ 
/* 268 */     int headerRowSize = getHeadRowSize(headerList);
/* 269 */     POIExcelHelper.parseDataByHM(sheet, dataset, POIExcelHelper.getDefaultFootStyle(workbook), exportColumns, headerRowSize, colFmt, workbook);
/* 270 */     return workbook;
/*     */   }
/*     */ 
/*     */   private int getHeadRowSize(List<CellBean> headerList)
/*     */   {
/* 279 */     int rowSize = 1;
/* 280 */     for (CellBean cellBean : headerList) {
/* 281 */       if (cellBean.getRowindex() + 1 > rowSize) {
/* 282 */         rowSize = cellBean.getRowindex() + 1;
/*     */       }
/*     */     }
/* 285 */     return rowSize;
/*     */   }
/*     */ 
/*     */   public HSSFWorkbook createWorkbookMSheetByL(List<SheetLBean> sheets)
/*     */   {
/* 290 */     HSSFWorkbook workbook = new HSSFWorkbook();
/* 291 */     for (SheetLBean aSheet : sheets) {
/* 292 */       HSSFSheet sheet = workbook.createSheet(aSheet.getSheetName());
/* 293 */       sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/* 294 */       String[] selExportColumns = aSheet.getHeaders();
/* 295 */       Collection dataset = aSheet.getDataset();
/* 296 */       if (selExportColumns != null) {
/* 297 */         POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), selExportColumns);
/*     */ 
/* 299 */         POIExcelHelper.parseDataByL(sheet, dataset, POIExcelHelper.getDefaultFootStyle(workbook));
/*     */       }
/*     */       else {
/* 302 */         List headerList = aSheet.getHeaderList();
/* 303 */         POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), headerList);
/*     */ 
/* 305 */         int headerRowSize = getHeadRowSize(headerList);
/* 306 */         POIExcelHelper.parseDataByL(sheet, dataset, headerRowSize, POIExcelHelper.getDefaultFootStyle(workbook));
/*     */       }
/*     */     }
/*     */ 
/* 310 */     return workbook;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.ExcelFactory
 * JD-Core Version:    0.6.2
 */
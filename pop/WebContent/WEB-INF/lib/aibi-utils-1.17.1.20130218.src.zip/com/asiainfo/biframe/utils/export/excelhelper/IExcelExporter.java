package com.asiainfo.biframe.utils.export.excelhelper;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;

public abstract interface IExcelExporter
{
  public abstract void exportExcelByHM(String paramString, Collection<Map<String, String>> paramCollection, String[] paramArrayOfString, HttpServletResponse paramHttpServletResponse);

  public abstract void exportExcelByHM(String paramString, Collection<Map<String, String>> paramCollection, List<CellBean> paramList, HttpServletResponse paramHttpServletResponse);

  public abstract void exportExcelByHMWithHeaders(String paramString, Collection<Map<String, String>> paramCollection, String[] paramArrayOfString1, String[] paramArrayOfString2, HttpServletResponse paramHttpServletResponse);

  public abstract void exportExcelByHMWithHeaders(String paramString1, Collection<Map<String, String>> paramCollection, String[] paramArrayOfString1, String[] paramArrayOfString2, HttpServletResponse paramHttpServletResponse, String paramString2);

  public abstract void exportExcelByHMWithHeaders(String paramString, Collection<Map<String, String>> paramCollection, List<CellBean> paramList, String[] paramArrayOfString, HttpServletResponse paramHttpServletResponse);

  public abstract void exportExcelByL(String paramString, Collection<List<String>> paramCollection, String[] paramArrayOfString, HttpServletResponse paramHttpServletResponse);

  public abstract void exportExcelByL(String paramString, Collection<List<String>> paramCollection, List<CellBean> paramList, HttpServletResponse paramHttpServletResponse);

  public abstract void exportExcelMSheetByL(String paramString, List<SheetLBean> paramList, HttpServletResponse paramHttpServletResponse);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.IExcelExporter
 * JD-Core Version:    0.6.2
 */
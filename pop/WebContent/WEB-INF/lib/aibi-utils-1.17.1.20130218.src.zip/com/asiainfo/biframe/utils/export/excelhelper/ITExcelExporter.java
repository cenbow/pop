package com.asiainfo.biframe.utils.export.excelhelper;

import java.util.Collection;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

public abstract interface ITExcelExporter<T>
{
  public abstract void exportExcelByObj(String paramString1, String[] paramArrayOfString1, Collection<T> paramCollection, String[] paramArrayOfString2, String paramString2, HttpServletResponse paramHttpServletResponse);

  public abstract void exportExcelByObj(String paramString1, List<CellBean> paramList, Collection<T> paramCollection, String[] paramArrayOfString, String paramString2, HttpServletResponse paramHttpServletResponse);
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.ITExcelExporter
 * JD-Core Version:    0.6.2
 */
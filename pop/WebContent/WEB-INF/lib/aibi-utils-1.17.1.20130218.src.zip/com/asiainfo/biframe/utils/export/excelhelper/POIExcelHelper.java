/*     */ package com.asiainfo.biframe.utils.export.excelhelper;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCellStyle;
/*     */ import org.apache.poi.hssf.usermodel.HSSFDataFormat;
/*     */ import org.apache.poi.hssf.usermodel.HSSFFont;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRichTextString;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.hssf.util.Region;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class POIExcelHelper
/*     */ {
/*  31 */   public static Logger logger = Logger.getLogger(POIExcelHelper.class);
/*     */ 
/*     */   public static void createCell(HSSFRow row, int id, String value, HSSFCellStyle style)
/*     */   {
/*  42 */     HSSFCell cell = row.createCell((short)id);
/*  43 */     if (value == null) {
/*  44 */       value = "";
/*     */     }
/*  46 */     Pattern p = Pattern.compile("^\\d+(\\.\\d+)?$");
/*  47 */     Matcher matcher = p.matcher(value);
/*  48 */     if (matcher.matches())
/*     */     {
/*  50 */       cell.setCellValue(Double.parseDouble(value));
/*     */     } else {
/*  52 */       cell.setCellType(1);
/*  53 */       cell.setCellValue(new HSSFRichTextString(value));
/*     */     }
/*  55 */     if (style != null)
/*  56 */       cell.setCellStyle(style);
/*     */   }
/*     */ 
/*     */   public static void createCell(HSSFRow row, int id, String value, HSSFCellStyle style, String colFmt, HSSFCellStyle styleNumber)
/*     */   {
/*  71 */     HSSFCell cell = row.createCell((short)id);
/*  72 */     if (value == null) {
/*  73 */       value = "";
/*     */     }
/*  75 */     Pattern p = Pattern.compile("^\\d+(\\.\\d+)?$");
/*  76 */     Matcher matcher = p.matcher(value);
/*  77 */     if (matcher.matches())
/*     */     {
/*  79 */       cell.setCellValue(Double.parseDouble(value));
/*     */     }
/*  82 */     else if ("number".equals(colFmt))
/*     */     {
/*     */       try {
/*  85 */         cell.setCellValue(Double.parseDouble(value.replaceAll(",", "")));
/*     */       } catch (Exception e) {
/*  87 */         cell.setCellType(1);
/*  88 */         cell.setCellValue(new HSSFRichTextString(value));
/*     */       }
/*     */     } else {
/*  91 */       cell.setCellType(1);
/*  92 */       cell.setCellValue(new HSSFRichTextString(value));
/*     */     }
/*     */ 
/*  95 */     if (("number".equals(colFmt)) && (styleNumber != null))
/*  96 */       cell.setCellStyle(styleNumber);
/*  97 */     else if (style != null)
/*  98 */       cell.setCellStyle(style);
/*     */   }
/*     */ 
/*     */   public static void parseTitle(HSSFSheet sheet, HSSFCellStyle style, String[] selExportColumns)
/*     */   {
/* 110 */     HSSFRow titlerow = sheet.createRow(0);
/*     */ 
/* 112 */     for (int i = 0; i < selExportColumns.length; i++)
/* 113 */       createCell(titlerow, i, selExportColumns[i], style);
/*     */   }
/*     */ 
/*     */   public static void parseTitle(HSSFSheet sheet, HSSFCellStyle style, List<CellBean> headerList)
/*     */   {
/* 124 */     if (headerList == null) {
/* 125 */       return;
/*     */     }
/* 127 */     for (int i = 0; i < headerList.size(); i++) {
/* 128 */       CellBean cellBean = (CellBean)headerList.get(i);
/* 129 */       createUnitCell(sheet, style, cellBean);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void createUnitCell(HSSFSheet sheet, HSSFCellStyle style, CellBean cellBean)
/*     */   {
/* 140 */     int rowindex = cellBean.getRowindex();
/* 141 */     int colindex = cellBean.getColindex();
/*     */ 
/* 145 */     HSSFRow titlerow = sheet.getRow(rowindex);
/* 146 */     if (titlerow == null) {
/* 147 */       titlerow = sheet.createRow((short)rowindex);
/*     */     }
/*     */ 
/* 151 */     createCell(titlerow, colindex, cellBean.getValue(), style);
/*     */ 
/* 153 */     Region region = new Region(rowindex, (short)colindex, rowindex + cellBean.getRowlength() - 1, (short)(colindex + cellBean.getCollength() - 1));
/* 154 */     sheet.addMergedRegion(region);
/* 155 */     setRegionStyle(sheet, region, style);
/*     */   }
/*     */ 
/*     */   public static void parseDataByHM(HSSFSheet sheet, Collection<Map<String, String>> dataset, HSSFCellStyle style, String[] selExportColumns)
/*     */   {
/* 175 */     parseDataByHM(sheet, dataset, style, selExportColumns, 1);
/*     */   }
/*     */ 
/*     */   public static void parseDataByHM(HSSFSheet sheet, Collection<Map<String, String>> dataset, HSSFCellStyle style, String[] selExportColumns, int headerRowSize)
/*     */   {
/* 192 */     if (selExportColumns == null) {
/* 193 */       parseDataByHM(sheet, dataset, style);
/*     */     } else {
/* 195 */       Iterator itera = dataset.iterator();
/* 196 */       int index = headerRowSize;
/* 197 */       while (itera.hasNext()) {
/* 198 */         Map hm = (Map)itera.next();
/* 199 */         HSSFRow row = sheet.createRow(index);
/* 200 */         Iterator iter = hm.keySet().iterator();
/* 201 */         int j = 0;
/* 202 */         while (iter.hasNext()) {
/* 203 */           String value = String.valueOf(hm.get(iter.next()));
/* 204 */           createCell(row, j, value, style);
/* 205 */           j++;
/*     */         }
/*     */ 
/* 210 */         index++;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void parseDataByHM(HSSFSheet sheet, Collection<Map<String, String>> dataset, HSSFCellStyle style, String[] selExportColumns, int headerRowSize, String colFmt, HSSFWorkbook workbook)
/*     */   {
/* 230 */     if (StringUtils.isEmpty(colFmt)) {
/* 231 */       parseDataByHM(sheet, dataset, style, selExportColumns, headerRowSize);
/* 232 */     } else if (selExportColumns == null) {
/* 233 */       parseDataByHM(sheet, dataset, style, colFmt, workbook);
/*     */     }
/*     */     else {
/* 236 */       Iterator iteraFmt = dataset.iterator();
/* 237 */       String[] colFmts = null;
/* 238 */       HSSFCellStyle styleNumber = null;
/* 239 */       String pattern = null;
/* 240 */       Map styleMap = new LinkedHashMap();
/*     */       try {
/* 242 */         obj = new JSONObject(colFmt.toLowerCase());
/* 243 */         if (iteraFmt.hasNext()) {
/* 244 */           Map map = (Map)iteraFmt.next();
/* 245 */           if ((map != null) && (map.keySet().size() > 0)) {
/* 246 */             colFmts = new String[map.keySet().size()];
/* 247 */             k = 0;
/* 248 */             for (String key : map.keySet()) {
/* 249 */               JSONObject objson = (JSONObject)obj.get(key.toLowerCase());
/* 250 */               colFmts[k] = objson.getString("dt");
/* 251 */               pattern = objson.getString("pt");
/* 252 */               if ("number".equals(colFmts[k])) {
/* 253 */                 styleNumber = getDefaultNumberStyle(workbook);
/* 254 */                 if ((pattern != null) && (!"".equals(pattern))) {
/* 255 */                   styleNumber.setDataFormat(workbook.createDataFormat().getFormat(pattern));
/*     */                 }
/* 257 */                 styleMap.put(Integer.valueOf(k), styleNumber);
/*     */               }
/* 259 */               k++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (JSONException e)
/*     */       {
/*     */         JSONObject obj;
/*     */         int k;
/* 264 */         logger.error("excel单元格格式化类型封装出错: " + e.getStackTrace(), e);
/*     */       }
/*     */ 
/* 267 */       Iterator itera = dataset.iterator();
/* 268 */       int index = headerRowSize;
/* 269 */       while (itera.hasNext()) {
/* 270 */         Map hm = (Map)itera.next();
/* 271 */         HSSFRow row = sheet.createRow(index);
/* 272 */         Iterator iter = hm.keySet().iterator();
/* 273 */         int j = 0;
/* 274 */         while (iter.hasNext()) {
/* 275 */           String value = String.valueOf(hm.get(iter.next()));
/* 276 */           createCell(row, j, value, style, colFmts[j], (HSSFCellStyle)styleMap.get(Integer.valueOf(j)));
/* 277 */           j++;
/*     */         }
/* 279 */         index++;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void parseDataByHM(HSSFSheet sheet, Collection<Map<String, String>> dataset, HSSFCellStyle style)
/*     */   {
/* 293 */     Iterator itera = dataset.iterator();
/* 294 */     int index = 0;
/* 295 */     while (itera.hasNext()) {
/* 296 */       Map hm = (Map)itera.next();
/* 297 */       HSSFRow row = sheet.createRow(index + 1);
/* 298 */       Iterator iter = hm.keySet().iterator();
/* 299 */       int j = 0;
/* 300 */       while (iter.hasNext()) {
/* 301 */         String value = String.valueOf(hm.get(iter.next()));
/* 302 */         createCell(row, j, value, style);
/* 303 */         j++;
/*     */       }
/* 305 */       index++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void parseDataByHM(HSSFSheet sheet, Collection<Map<String, String>> dataset, HSSFCellStyle style, String colFmt, HSSFWorkbook workbook)
/*     */   {
/* 320 */     Iterator iteraFmt = dataset.iterator();
/* 321 */     String[] colFmts = null;
/* 322 */     HSSFCellStyle styleNumber = null;
/* 323 */     String pattern = null;
/* 324 */     Map styleMap = new LinkedHashMap();
/*     */     try {
/* 326 */       obj = new JSONObject(colFmt.toLowerCase());
/* 327 */       if (iteraFmt.hasNext()) {
/* 328 */         Map map = (Map)iteraFmt.next();
/* 329 */         if ((map != null) && (map.keySet().size() > 0)) {
/* 330 */           colFmts = new String[map.keySet().size()];
/* 331 */           k = 0;
/* 332 */           for (String key : map.keySet()) {
/* 333 */             JSONObject objson = (JSONObject)obj.get(key.toLowerCase());
/* 334 */             colFmts[k] = objson.getString("dt");
/* 335 */             pattern = objson.getString("pt");
/* 336 */             if ("number".equals(colFmts[k])) {
/* 337 */               styleNumber = getDefaultNumberStyle(workbook);
/* 338 */               if ((pattern != null) && (!"".equals(pattern))) {
/* 339 */                 styleNumber.setDataFormat(workbook.createDataFormat().getFormat(pattern));
/*     */               }
/* 341 */               styleMap.put(Integer.valueOf(k), styleNumber);
/*     */             }
/* 343 */             k++;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (JSONException e)
/*     */     {
/*     */       JSONObject obj;
/*     */       int k;
/* 348 */       logger.error("excel单元格格式化类型封装出错: " + e.getStackTrace(), e);
/*     */     }
/*     */ 
/* 351 */     Iterator itera = dataset.iterator();
/* 352 */     int index = 0;
/* 353 */     while (itera.hasNext()) {
/* 354 */       Map hm = (Map)itera.next();
/* 355 */       HSSFRow row = sheet.createRow(index + 1);
/* 356 */       Iterator iter = hm.keySet().iterator();
/* 357 */       int j = 0;
/* 358 */       while (iter.hasNext()) {
/* 359 */         String value = String.valueOf(hm.get(iter.next()));
/* 360 */         createCell(row, j, value, style, colFmts[j], (HSSFCellStyle)styleMap.get(Integer.valueOf(j)));
/* 361 */         j++;
/*     */       }
/* 363 */       index++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void parseDataByL(HSSFSheet sheet, Collection<List<String>> dataset, HSSFCellStyle style)
/*     */   {
/* 378 */     parseDataByL(sheet, dataset, 1, style);
/*     */   }
/*     */ 
/*     */   public static void parseDataByL(HSSFSheet sheet, Collection<List<String>> dataset, int headerRowSize, HSSFCellStyle style)
/*     */   {
/* 393 */     Iterator itera = dataset.iterator();
/* 394 */     int index = headerRowSize;
/* 395 */     while (itera.hasNext()) {
/* 396 */       List tempList = (List)itera.next();
/* 397 */       HSSFRow row = sheet.createRow(index);
/* 398 */       for (int j = 0; j < tempList.size(); j++) {
/* 399 */         String value = (String)tempList.get(j);
/* 400 */         createCell(row, j, value, style);
/*     */       }
/* 402 */       index++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static HSSFCellStyle getDefaultStyle(HSSFWorkbook workbook)
/*     */   {
/* 408 */     HSSFFont font = workbook.createFont();
/*     */ 
/* 410 */     font.setColor((short)12);
/*     */ 
/* 412 */     font.setFontHeight((short)200);
/*     */ 
/* 414 */     font.setFontName("Arial");
/*     */ 
/* 417 */     font.setBoldweight((short)700);
/*     */ 
/* 419 */     HSSFCellStyle style = workbook.createCellStyle();
/*     */ 
/* 421 */     style.setAlignment((short)1);
/* 422 */     style.setAlignment((short)2);
/* 423 */     style.setFont(font);
/*     */ 
/* 425 */     style.setFillForegroundColor((short)22);
/* 426 */     style.setFillPattern((short)1);
/* 427 */     style.setBorderBottom((short)1);
/* 428 */     style.setBorderLeft((short)1);
/* 429 */     style.setBorderRight((short)1);
/* 430 */     style.setBorderTop((short)1);
/*     */ 
/* 432 */     return style;
/*     */   }
/*     */ 
/*     */   public static HSSFCellStyle getDefaultFootStyle(HSSFWorkbook workbook) {
/* 436 */     HSSFFont font = workbook.createFont();
/* 437 */     font.setColor((short)8);
/* 438 */     font.setFontHeight((short)200);
/* 439 */     font.setFontName("Arial");
/*     */ 
/* 441 */     font.setBoldweight((short)400);
/*     */ 
/* 443 */     HSSFCellStyle style = workbook.createCellStyle();
/* 444 */     style.setAlignment((short)1);
/* 445 */     style.setAlignment((short)1);
/* 446 */     style.setFont(font);
/* 447 */     style.setFillForegroundColor((short)9);
/* 448 */     style.setFillPattern((short)1);
/* 449 */     style.setBorderBottom((short)1);
/* 450 */     style.setBorderLeft((short)1);
/* 451 */     style.setBorderRight((short)1);
/* 452 */     style.setBorderTop((short)1);
/* 453 */     return style;
/*     */   }
/*     */ 
/*     */   public static HSSFCellStyle getDefaultNumberStyle(HSSFWorkbook workbook)
/*     */   {
/* 463 */     HSSFFont font = workbook.createFont();
/* 464 */     font.setColor((short)8);
/* 465 */     font.setFontHeight((short)200);
/* 466 */     font.setFontName("Arial");
/*     */ 
/* 468 */     font.setBoldweight((short)400);
/*     */ 
/* 470 */     HSSFCellStyle style = workbook.createCellStyle();
/* 471 */     style.setAlignment((short)1);
/* 472 */     style.setAlignment((short)1);
/* 473 */     style.setFont(font);
/* 474 */     style.setFillForegroundColor((short)9);
/* 475 */     style.setFillPattern((short)1);
/* 476 */     style.setBorderBottom((short)1);
/* 477 */     style.setBorderLeft((short)1);
/* 478 */     style.setBorderRight((short)1);
/* 479 */     style.setBorderTop((short)1);
/* 480 */     return style;
/*     */   }
/*     */ 
/*     */   public static void save(HSSFWorkbook workbook, String dir, String filename)
/*     */     throws IOException
/*     */   {
/* 492 */     dir = dir == null ? "" : dir;
/* 493 */     if ((dir != null) && (!dir.equals("")) && 
/* 494 */       (!dir.endsWith("\\"))) {
/* 495 */       dir = dir + "\\";
/*     */     }
/* 497 */     logger.debug("out put dir: " + dir);
/* 498 */     File outdir = new File(dir);
/* 499 */     if (!outdir.exists()) {
/* 500 */       outdir.mkdirs();
/*     */     }
/* 502 */     FileOutputStream fOut = new FileOutputStream(dir + filename);
/* 503 */     workbook.write(fOut);
/* 504 */     fOut.flush();
/* 505 */     fOut.close();
/* 506 */     logger.info(dir + filename + " generated!");
/*     */   }
/*     */ 
/*     */   public static OutputStream saveToStream(HSSFWorkbook workbook, String dir, String filename)
/*     */     throws IOException
/*     */   {
/* 516 */     dir = dir == null ? "" : dir;
/* 517 */     if ((dir != null) && (!dir.equals("")) && 
/* 518 */       (!dir.endsWith("\\"))) {
/* 519 */       dir = dir + "\\";
/*     */     }
/* 521 */     logger.debug("out put dir: " + dir);
/* 522 */     File outdir = new File(dir);
/* 523 */     if (!outdir.exists()) {
/* 524 */       outdir.mkdirs();
/*     */     }
/* 526 */     FileOutputStream fOut = new FileOutputStream(dir + filename);
/* 527 */     workbook.write(fOut);
/* 528 */     fOut.flush();
/* 529 */     return fOut;
/*     */   }
/*     */ 
/*     */   private static void setRegionStyle(HSSFSheet sheet, Region region, HSSFCellStyle cs)
/*     */   {
/* 535 */     for (int i = region.getRowFrom(); i <= region.getRowTo(); i++) {
/* 536 */       HSSFRow row = sheet.getRow(i);
/* 537 */       if (row == null) {
/* 538 */         row = sheet.createRow(i);
/*     */       }
/* 540 */       for (int j = region.getColumnFrom(); j <= region.getColumnTo(); j++) {
/* 541 */         HSSFCell cell = row.getCell((short)j);
/* 542 */         if (cell == null) {
/* 543 */           cell = row.createCell((short)j);
/*     */         }
/* 545 */         cell.setCellStyle(cs);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws IOException {
/* 551 */     HSSFWorkbook workbook = new HSSFWorkbook();
/* 552 */     HSSFSheet sheet = workbook.createSheet("sheetName");
/* 553 */     HSSFRow titlerow = sheet.createRow(0);
/* 554 */     createCell(titlerow, 0, "表头1", getDefaultStyle(workbook));
/* 555 */     Region r1 = new Region(0, (short)0, 1, (short)0);
/* 556 */     sheet.addMergedRegion(r1);
/* 557 */     setRegionStyle(sheet, r1, getDefaultStyle(workbook));
/* 558 */     createCell(titlerow, 1, "表头2", getDefaultStyle(workbook));
/* 559 */     Region r2 = new Region(0, (short)1, 0, (short)2);
/* 560 */     sheet.addMergedRegion(r2);
/* 561 */     setRegionStyle(sheet, r2, getDefaultStyle(workbook));
/* 562 */     createCell(titlerow, 3, "表头3", getDefaultStyle(workbook));
/* 563 */     Region r3 = new Region(0, (short)3, 1, (short)3);
/* 564 */     sheet.addMergedRegion(r3);
/* 565 */     setRegionStyle(sheet, r3, getDefaultStyle(workbook));
/* 566 */     titlerow = sheet.createRow(1);
/*     */ 
/* 568 */     createCell(titlerow, 1, "表头2.1", getDefaultStyle(workbook));
/* 569 */     createCell(titlerow, 2, "表头2.2", getDefaultStyle(workbook));
/* 570 */     String dirPath = System.getProperty("user.home") + "\\TEMPEXCELFILE";
/* 571 */     save(workbook, dirPath, "1.xls");
/*     */ 
/* 573 */     CellBean cellBean1 = new CellBean();
/* 574 */     cellBean1.setRowindex(0);
/* 575 */     cellBean1.setColindex(0);
/* 576 */     cellBean1.setRowlength(2);
/* 577 */     cellBean1.setCollength(1);
/* 578 */     cellBean1.setValue("表头1");
/*     */ 
/* 580 */     CellBean cellBean2 = new CellBean();
/* 581 */     cellBean2.setRowindex(0);
/* 582 */     cellBean2.setColindex(1);
/* 583 */     cellBean2.setRowlength(1);
/* 584 */     cellBean2.setCollength(3);
/* 585 */     cellBean2.setValue("表头2");
/*     */ 
/* 587 */     CellBean cellBean21 = new CellBean();
/* 588 */     cellBean21.setRowindex(1);
/* 589 */     cellBean21.setColindex(1);
/* 590 */     cellBean21.setRowlength(1);
/* 591 */     cellBean21.setCollength(1);
/* 592 */     cellBean21.setValue("表头2.1");
/*     */ 
/* 594 */     CellBean cellBean22 = new CellBean();
/* 595 */     cellBean22.setRowindex(1);
/* 596 */     cellBean22.setColindex(2);
/* 597 */     cellBean22.setRowlength(1);
/* 598 */     cellBean22.setCollength(1);
/* 599 */     cellBean22.setValue("表头2.2");
/*     */ 
/* 601 */     CellBean cellBean23 = new CellBean();
/* 602 */     cellBean23.setRowindex(1);
/* 603 */     cellBean23.setColindex(3);
/* 604 */     cellBean23.setRowlength(1);
/* 605 */     cellBean23.setCollength(1);
/* 606 */     cellBean23.setValue("表头2.3");
/*     */ 
/* 608 */     CellBean cellBean3 = new CellBean();
/* 609 */     cellBean3.setRowindex(0);
/* 610 */     cellBean3.setColindex(4);
/* 611 */     cellBean3.setRowlength(2);
/* 612 */     cellBean3.setCollength(1);
/* 613 */     cellBean3.setValue("表头3");
/*     */ 
/* 615 */     List cellBeanList = new ArrayList();
/* 616 */     cellBeanList.add(cellBean1);
/* 617 */     cellBeanList.add(cellBean2);
/* 618 */     cellBeanList.add(cellBean21);
/* 619 */     cellBeanList.add(cellBean22);
/* 620 */     cellBeanList.add(cellBean23);
/* 621 */     cellBeanList.add(cellBean3);
/*     */ 
/* 623 */     HSSFWorkbook workbook2 = new HSSFWorkbook();
/* 624 */     HSSFSheet sheet2 = workbook2.createSheet("sheetName");
/* 625 */     parseTitle(sheet2, getDefaultStyle(workbook2), cellBeanList);
/* 626 */     save(workbook2, dirPath, "合并.xls");
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.POIExcelHelper
 * JD-Core Version:    0.6.2
 */
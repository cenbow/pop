/*    */ package com.asiainfo.biframe.utils.export.excelhelper;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SheetLBean
/*    */ {
/*    */   private String sheetName;
/*    */   private Collection<List<String>> dataset;
/*    */   private String[] headers;
/*    */   private List<CellBean> headerList;
/*    */ 
/*    */   public String getSheetName()
/*    */   {
/* 26 */     return this.sheetName;
/*    */   }
/*    */   public void setSheetName(String sheetName) {
/* 29 */     this.sheetName = sheetName;
/*    */   }
/*    */   public Collection<List<String>> getDataset() {
/* 32 */     return this.dataset;
/*    */   }
/*    */   public void setDataset(Collection<List<String>> dataset) {
/* 35 */     this.dataset = dataset;
/*    */   }
/*    */   public String[] getHeaders() {
/* 38 */     return this.headers;
/*    */   }
/*    */   public void setHeaders(String[] headers) {
/* 41 */     this.headers = headers;
/*    */   }
/*    */   public List<CellBean> getHeaderList() {
/* 44 */     return this.headerList;
/*    */   }
/*    */   public void setHeaderList(List<CellBean> headerList) {
/* 47 */     this.headerList = headerList;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.SheetLBean
 * JD-Core Version:    0.6.2
 */
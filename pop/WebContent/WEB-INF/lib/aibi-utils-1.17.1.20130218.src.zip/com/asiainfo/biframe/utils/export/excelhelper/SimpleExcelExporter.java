/*     */ package com.asiainfo.biframe.utils.export.excelhelper;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ public class SimpleExcelExporter
/*     */   implements IExcelExporter
/*     */ {
/*  17 */   private static final Logger logger = Logger.getLogger(SimpleExcelExporter.class);
/*     */ 
/*  19 */   private final String ioMsg = "IO exception occurred when downloading xls data";
/*  20 */   private final String closeMsg = "Close output stream failed";
/*  21 */   private final String encodingMsg = "Encoding in header not supported";
/*     */ 
/*  23 */   private ExcelFactory excelFactory = new ExcelFactory();
/*     */ 
/*     */   public ExcelFactory getExcelFactory() {
/*  26 */     return this.excelFactory;
/*     */   }
/*     */ 
/*     */   public void setExcelFactory(ExcelFactory excelFactory) {
/*  30 */     this.excelFactory = excelFactory;
/*     */   }
/*     */ 
/*     */   public void exportExcelByHM(String sheetName, Collection<Map<String, String>> list, String[] headers, HttpServletResponse response)
/*     */   {
/*  43 */     response.reset();
/*  44 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/*  45 */     OutputStream os = null;
/*     */     try {
/*  47 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(new StringBuilder().append(sheetName).append(".xls").toString(), "UTF-8") + "\"");
/*     */ 
/*  49 */       os = response.getOutputStream();
/*     */ 
/*  52 */       if (this.excelFactory == null) {
/*  53 */         this.excelFactory = new ExcelFactory();
/*     */       }
/*     */ 
/*  57 */       HSSFWorkbook workbook = this.excelFactory.createWorkbookByHM(sheetName, list, headers);
/*  58 */       workbook.write(os);
/*     */     } catch (IOException ie) {
/*  60 */       logger.error("IO exception occurred when downloading xls data");
/*  61 */       logger.debug("SimpleExcelExporter.exportExcelByHM():", ie);
/*     */     } finally {
/*     */       try {
/*  64 */         os.flush();
/*  65 */         os.close();
/*     */       } catch (IOException ie) {
/*  67 */         logger.error("Close output stream failed");
/*  68 */         logger.debug("SimpleExcelExporter.exportExcelByHM():", ie);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByHM(String sheetName, Collection<Map<String, String>> list, List<CellBean> headerList, HttpServletResponse response)
/*     */   {
/*  83 */     response.reset();
/*  84 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/*  85 */     OutputStream os = null;
/*     */     try {
/*  87 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(new StringBuilder().append(sheetName).append(".xls").toString(), "UTF-8") + "\"");
/*     */ 
/*  90 */       os = response.getOutputStream();
/*  91 */       HSSFWorkbook workbook = this.excelFactory.createWorkbookByHM(sheetName, list, headerList);
/*  92 */       workbook.write(os);
/*     */     } catch (IOException ie) {
/*  94 */       logger.error("IO exception occurred when downloading xls data");
/*  95 */       logger.debug("SimpleExcelExporter.exportExcelByHM():", ie);
/*     */     } finally {
/*     */       try {
/*  98 */         os.flush();
/*  99 */         os.close();
/*     */       } catch (IOException ie) {
/* 101 */         logger.error("Close output stream failed");
/* 102 */         logger.debug("SimpleExcelExporter.exportExcelByHM():", ie);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByHMWithHeaders(String fileName, Collection<Map<String, String>> list, String[] headers, String[] exportColumns, HttpServletResponse response) {
/* 108 */     response.reset();
/* 109 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/* 110 */     OutputStream os = null;
/*     */     try {
/* 112 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(new StringBuilder().append(fileName).append(".xls").toString(), "UTF-8") + "\"");
/*     */ 
/* 114 */       os = response.getOutputStream();
/*     */ 
/* 116 */       if (this.excelFactory == null) {
/* 117 */         this.excelFactory = new ExcelFactory();
/*     */       }
/*     */ 
/* 120 */       HSSFWorkbook workbook = this.excelFactory.createWorkbookByHMWithHeaders(fileName, list, headers, exportColumns);
/* 121 */       workbook.write(os);
/*     */     } catch (IOException ie) {
/* 123 */       logger.error("IO exception occurred when downloading xls data");
/* 124 */       logger.debug("SimpleExcelExporter.exportExcelByHM():", ie);
/*     */     } finally {
/*     */       try {
/* 127 */         os.flush();
/* 128 */         os.close();
/*     */       } catch (IOException ie) {
/* 130 */         logger.error("Close output stream failed");
/* 131 */         logger.debug("SimpleExcelExporter.exportExcelByHM():", ie);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByHMWithHeaders(String fileName, Collection<Map<String, String>> list, List<CellBean> headerList, String[] exportColumns, HttpServletResponse response) {
/* 137 */     response.reset();
/* 138 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/* 139 */     OutputStream os = null;
/*     */     try {
/* 141 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(new StringBuilder().append(fileName).append(".xls").toString(), "UTF-8") + "\"");
/*     */ 
/* 143 */       os = response.getOutputStream();
/* 144 */       HSSFWorkbook workbook = this.excelFactory.createWorkbookByHMWithHeaders(fileName, list, headerList, exportColumns);
/* 145 */       workbook.write(os);
/*     */     } catch (IOException ie) {
/* 147 */       logger.error("IO exception occurred when downloading xls data");
/* 148 */       logger.debug("SimpleExcelExporter.exportExcelByHM():", ie);
/*     */     } finally {
/*     */       try {
/* 151 */         os.flush();
/* 152 */         os.close();
/*     */       } catch (IOException ie) {
/* 154 */         logger.error("Close output stream failed");
/* 155 */         logger.debug("SimpleExcelExporter.exportExcelByHM():", ie);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByL(String sheetName, Collection<List<String>> list, String[] headers, HttpServletResponse response)
/*     */   {
/* 172 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/* 173 */     OutputStream os = null;
/*     */     try {
/* 175 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(new StringBuilder().append(sheetName).append(".xls").toString(), "UTF-8") + "\"");
/*     */ 
/* 177 */       os = response.getOutputStream();
/* 178 */       HSSFWorkbook workbook = this.excelFactory.createWorkbookByL(sheetName, list, headers);
/* 179 */       workbook.write(os);
/*     */     } catch (UnsupportedEncodingException uee) {
/* 181 */       logger.error("Encoding in header not supported");
/* 182 */       logger.debug("SimpleExcelExporter.exportExcelByL():", uee);
/*     */     } catch (IOException ie) {
/* 184 */       logger.error("IO exception occurred when downloading xls data");
/* 185 */       logger.debug("SimpleExcelExporter.exportExcelByL():", ie);
/*     */     } finally {
/*     */       try {
/* 188 */         os.flush();
/* 189 */         os.close();
/*     */       } catch (IOException ie) {
/* 191 */         logger.error("Close output stream failed");
/* 192 */         logger.debug("SimpleExcelExporter.exportExcelByL():", ie);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByL(String sheetName, Collection<List<String>> list, List<CellBean> headerList, HttpServletResponse response)
/*     */   {
/* 209 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/* 210 */     OutputStream os = null;
/*     */     try {
/* 212 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(new StringBuilder().append(sheetName).append(".xls").toString(), "UTF-8") + "\"");
/*     */ 
/* 215 */       os = response.getOutputStream();
/* 216 */       HSSFWorkbook workbook = this.excelFactory.createWorkbookByL(sheetName, list, headerList);
/* 217 */       workbook.write(os);
/*     */     } catch (UnsupportedEncodingException uee) {
/* 219 */       logger.error("Encoding in header not supported");
/* 220 */       logger.debug("SimpleExcelExporter.exportExcelByL():", uee);
/*     */     } catch (IOException ie) {
/* 222 */       logger.error("IO exception occurred when downloading xls data");
/* 223 */       logger.debug("SimpleExcelExporter.exportExcelByL():", ie);
/*     */     } finally {
/*     */       try {
/* 226 */         os.flush();
/* 227 */         os.close();
/*     */       } catch (IOException ie) {
/* 229 */         logger.error("Close output stream failed");
/* 230 */         logger.debug("SimpleExcelExporter.exportExcelByL():", ie);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelMSheetByL(String fileName, List<SheetLBean> sheets, HttpServletResponse response) {
/* 236 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/* 237 */     OutputStream os = null;
/*     */     try {
/* 239 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(new StringBuilder().append(fileName).append(".xls").toString(), "UTF-8") + "\"");
/*     */ 
/* 242 */       os = response.getOutputStream();
/* 243 */       HSSFWorkbook workbook = this.excelFactory.createWorkbookMSheetByL(sheets);
/* 244 */       workbook.write(os);
/*     */     } catch (UnsupportedEncodingException uee) {
/* 246 */       logger.error("Encoding in header not supported");
/* 247 */       logger.debug("SimpleExcelExporter.exportExcelByL():", uee);
/*     */     } catch (IOException ie) {
/* 249 */       logger.error("IO exception occurred when downloading xls data");
/* 250 */       logger.debug("SimpleExcelExporter.exportExcelByL():", ie);
/*     */     } finally {
/*     */       try {
/* 253 */         os.flush();
/* 254 */         os.close();
/*     */       } catch (IOException ie) {
/* 256 */         logger.error("Close output stream failed");
/* 257 */         logger.debug("SimpleExcelExporter.exportExcelByL():", ie);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exportExcelByHMWithHeaders(String fileName, Collection<Map<String, String>> dataset, String[] headers, String[] exportColumns, HttpServletResponse response, String colFmt)
/*     */   {
/* 270 */     exportExcelByHMWithHeaders(fileName, dataset, headers, exportColumns, response);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.SimpleExcelExporter
 * JD-Core Version:    0.6.2
 */
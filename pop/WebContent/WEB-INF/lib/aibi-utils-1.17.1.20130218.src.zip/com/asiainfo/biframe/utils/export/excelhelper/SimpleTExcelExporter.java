/*    */ package com.asiainfo.biframe.utils.export.excelhelper;
/*    */ 
/*    */ import common.Logger;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*    */ 
/*    */ public class SimpleTExcelExporter<T>
/*    */   implements ITExcelExporter<T>
/*    */ {
/* 16 */   private static final Logger logger = Logger.getLogger(SimpleTExcelExporter.class);
/* 17 */   private final String ioMsg = "IO exception occurred when downloading xls data";
/* 18 */   private final String closeMsg = "Close output stream failed";
/* 19 */   private final String encodingMsg = "Encoding in header not supported";
/*    */   private TExcelFactory<T> tExcelFactory;
/*    */ 
/*    */   public TExcelFactory<T> getTExcelFactory()
/*    */   {
/* 24 */     return this.tExcelFactory;
/*    */   }
/*    */ 
/*    */   public void setTExcelFactory(TExcelFactory<T> excelFactory) {
/* 28 */     this.tExcelFactory = excelFactory;
/*    */   }
/*    */ 
/*    */   public void exportExcelByObj(String sheetName, String[] headers, Collection<T> dataset, String[] methodNames, String pattern, HttpServletResponse response)
/*    */   {
/* 44 */     response.reset();
/* 45 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/* 46 */     OutputStream os = null;
/*    */     try {
/* 48 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(new StringBuilder().append(sheetName).append(".xls").toString(), "UTF-8") + "\"");
/*    */ 
/* 51 */       os = response.getOutputStream();
/* 52 */       if (this.tExcelFactory == null) {
/* 53 */         this.tExcelFactory = new TExcelFactory();
/*    */       }
/* 55 */       HSSFWorkbook workbook = this.tExcelFactory.createWorkbookByObj(sheetName, headers, dataset, methodNames, pattern);
/* 56 */       workbook.write(os);
/*    */     } catch (UnsupportedEncodingException uee) {
/* 58 */       logger.error("Encoding in header not supported");
/* 59 */       logger.debug("SimpleExcelExporter.exportExcelByL():", uee);
/*    */     }
/*    */     catch (IOException ie) {
/* 62 */       logger.error("IO exception occurred when downloading xls data");
/* 63 */       logger.debug("SimpleTExcelExporter.exportExcelByObj():", ie);
/*    */     } finally {
/*    */       try {
/* 66 */         os.flush();
/* 67 */         os.close();
/*    */       } catch (IOException ie) {
/* 69 */         logger.error("Close output stream failed");
/* 70 */         logger.debug("SimpleTExcelExporter.exportExcelByObj():", ie);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public void exportExcelByObj(String sheetName, List<CellBean> headerList, Collection<T> dataset, String[] methodNames, String pattern, HttpServletResponse response)
/*    */   {
/* 89 */     response.reset();
/* 90 */     response.setContentType("application/vnd.ms-excel; charset=GBK");
/* 91 */     OutputStream os = null;
/*    */     try {
/* 93 */       response.addHeader("content-disposition", "attachment;filename=\"" + URLEncoder.encode(new StringBuilder().append(sheetName).append(".xls").toString(), "UTF-8") + "\"");
/*    */ 
/* 96 */       os = response.getOutputStream();
/* 97 */       if (this.tExcelFactory == null) {
/* 98 */         this.tExcelFactory = new TExcelFactory();
/*    */       }
/* 100 */       HSSFWorkbook workbook = this.tExcelFactory.createWorkbookByObj(sheetName, headerList, dataset, methodNames, pattern);
/* 101 */       workbook.write(os);
/*    */     } catch (IOException ie) {
/* 103 */       logger.error("IO exception occurred when downloading xls data");
/* 104 */       logger.debug("SimpleTExcelExporter.exportExcelByObj():", ie);
/*    */     } finally {
/*    */       try {
/* 107 */         os.flush();
/* 108 */         os.close();
/*    */       } catch (IOException ie) {
/* 110 */         logger.error("Close output stream failed");
/* 111 */         logger.debug("SimpleTExcelExporter.exportExcelByObj():", ie);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.SimpleTExcelExporter
 * JD-Core Version:    0.6.2
 */
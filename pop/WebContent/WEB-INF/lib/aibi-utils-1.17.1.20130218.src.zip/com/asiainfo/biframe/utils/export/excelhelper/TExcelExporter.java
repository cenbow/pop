/*     */ package com.asiainfo.biframe.utils.export.excelhelper;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ public class TExcelExporter<T>
/*     */   implements ITExcelExporter<T>
/*     */ {
/*     */   private static final String DEFAULTSHEETNAME = "sheet-1";
/*  16 */   private final String fileNotFoundMsg = "The file to download not found";
/*  17 */   private final String downloadMsg = "Download failed";
/*     */ 
/*  19 */   private static final Logger logger = Logger.getLogger(TExcelExporter.class);
/*     */   private TExcelFactory<T> tExcelFactory;
/*     */   private DownloadFactory downloadFactory;
/*     */ 
/*     */   public TExcelFactory<T> getTExcelFactory()
/*     */   {
/*  26 */     return this.tExcelFactory;
/*     */   }
/*     */ 
/*     */   public void setTExcelFactory(TExcelFactory<T> excelFactory) {
/*  30 */     this.tExcelFactory = excelFactory;
/*     */   }
/*     */ 
/*     */   public DownloadFactory getDownloadFactory() {
/*  34 */     return this.downloadFactory;
/*     */   }
/*     */ 
/*     */   public void setDownloadFactory(DownloadFactory downloadFactory) {
/*  38 */     this.downloadFactory = downloadFactory;
/*     */   }
/*     */ 
/*     */   public void exportExcelByObj(String sheetName, String[] headers, Collection<T> dataset, String[] methodNames, String pattern, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/*  47 */       String fileName = exportToFileByObj(null, null, sheetName, headers, dataset, methodNames, pattern);
/*  48 */       this.downloadFactory.downloadfile(response, fileName);
/*     */     } catch (FileNotFoundException fnfe) {
/*  50 */       logger.error("The file to download not found");
/*  51 */       logger.debug("ExcelExporter.exportExcelByL():", fnfe);
/*     */     } catch (IOException ioe) {
/*  53 */       logger.error("Download failed");
/*  54 */       logger.debug("ExcelExporter.exportExcelByL():", ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String exportToFileByObj(String dir, String fileName, String sheetName, String[] headers, Collection<T> dataset, String[] methodNames, String pattern)
/*     */     throws IOException
/*     */   {
/*  72 */     String dirPath = "";
/*  73 */     if ((dir == null) || (dir.equals("")))
/*  74 */       dirPath = System.getProperty("user.home") + "\\TEMPEXCELFILE";
/*     */     else {
/*  76 */       dirPath = dir;
/*     */     }
/*  78 */     if ((fileName == null) || (fileName.equals(""))) {
/*  79 */       fileName = sheetName + ".xls";
/*     */     }
/*  81 */     if ((sheetName == null) || (sheetName.equals(""))) {
/*  82 */       sheetName = fileName.substring(0, fileName.lastIndexOf("."));
/*     */     }
/*  84 */     if (this.tExcelFactory == null) {
/*  85 */       this.tExcelFactory = new TExcelFactory();
/*     */     }
/*  87 */     HSSFWorkbook workbook = this.tExcelFactory.createWorkbookByObj(sheetName, headers, dataset, methodNames, pattern);
/*  88 */     POIExcelHelper.save(workbook, dirPath, fileName);
/*  89 */     return dirPath + fileName;
/*     */   }
/*     */ 
/*     */   public String exportToFileByObj(String dir, String fileName, String sheetName, List<CellBean> headerList, Collection<T> dataset, String[] methodNames, String pattern)
/*     */     throws IOException
/*     */   {
/* 106 */     String dirPath = "";
/* 107 */     if ((dir == null) || (dir.equals("")))
/* 108 */       dirPath = System.getProperty("user.home") + "\\TEMPEXCELFILE";
/*     */     else {
/* 110 */       dirPath = dir;
/*     */     }
/* 112 */     if ((fileName == null) || (fileName.equals(""))) {
/* 113 */       fileName = sheetName + ".xls";
/*     */     }
/* 115 */     if ((sheetName == null) || (sheetName.equals(""))) {
/* 116 */       sheetName = fileName.substring(0, fileName.lastIndexOf("."));
/*     */     }
/*     */ 
/* 119 */     if (this.tExcelFactory == null) {
/* 120 */       this.tExcelFactory = new TExcelFactory();
/*     */     }
/* 122 */     HSSFWorkbook workbook = this.tExcelFactory.createWorkbookByObj(sheetName, headerList, dataset, methodNames, pattern);
/* 123 */     POIExcelHelper.save(workbook, dirPath, fileName);
/* 124 */     return dirPath + fileName;
/*     */   }
/*     */ 
/*     */   public void exportExcelByObj(String sheetName, List<CellBean> headerList, Collection<T> dataset, String[] methodNames, String pattern, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/* 134 */       String fileName = exportToFileByObj(null, null, sheetName, headerList, dataset, methodNames, pattern);
/* 135 */       this.downloadFactory.downloadfile(response, fileName);
/*     */     } catch (FileNotFoundException fnfe) {
/* 137 */       logger.error("The file to download not found");
/* 138 */       logger.debug("ExcelExporter.exportExcelByL():", fnfe);
/*     */     } catch (IOException ioe) {
/* 140 */       logger.error("Download failed");
/* 141 */       logger.debug("ExcelExporter.exportExcelByL():", ioe);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.TExcelExporter
 * JD-Core Version:    0.6.2
 */
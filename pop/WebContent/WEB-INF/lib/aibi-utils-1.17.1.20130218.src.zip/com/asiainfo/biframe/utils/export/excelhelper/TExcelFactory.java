/*     */ package com.asiainfo.biframe.utils.export.excelhelper;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCellStyle;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ public class TExcelFactory<T>
/*     */ {
/*  21 */   private short DEFAULTCOLUMNWIDTH = 15;
/*     */ 
/*  23 */   private String DEFAULTDATEPATTERN = "yyyy-MM-dd";
/*     */ 
/*  25 */   private static final Logger logger = Logger.getLogger(TExcelFactory.class);
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByObj(String sheetName, String[] headers, Collection<T> dataset, String[] methodNames, String pattern)
/*     */   {
/*  40 */     HSSFWorkbook workbook = new HSSFWorkbook();
/*     */ 
/*  42 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*     */ 
/*  44 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/*     */ 
/*  46 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), headers);
/*  47 */     parseDataByObj(sheet, dataset, methodNames, POIExcelHelper.getDefaultFootStyle(workbook), pattern);
/*  48 */     return workbook;
/*     */   }
/*     */ 
/*     */   public HSSFWorkbook createWorkbookByObj(String sheetName, List<CellBean> headerList, Collection<T> dataset, String[] methodNames, String pattern)
/*     */   {
/*  63 */     HSSFWorkbook workbook = new HSSFWorkbook();
/*     */ 
/*  65 */     HSSFSheet sheet = workbook.createSheet(sheetName);
/*     */ 
/*  67 */     sheet.setDefaultColumnWidth(this.DEFAULTCOLUMNWIDTH);
/*     */ 
/*  69 */     POIExcelHelper.parseTitle(sheet, POIExcelHelper.getDefaultStyle(workbook), headerList);
/*  70 */     int headerRowSize = getHeadRowSize(headerList);
/*  71 */     parseDataByObj(sheet, dataset, methodNames, POIExcelHelper.getDefaultFootStyle(workbook), pattern, headerRowSize);
/*  72 */     return workbook;
/*     */   }
/*     */ 
/*     */   public void parseDataByObj(HSSFSheet sheet, Collection<T> dataset, String[] methodNames, HSSFCellStyle style, String pattern)
/*     */   {
/*  84 */     parseDataByObj(sheet, dataset, methodNames, style, pattern, 1);
/*     */   }
/*     */ 
/*     */   public void parseDataByObj(HSSFSheet sheet, Collection<T> dataset, String[] methodNames, HSSFCellStyle style, String pattern, int headerRosSize)
/*     */   {
/*  98 */     Iterator it = dataset.iterator();
/*  99 */     int index = headerRosSize;
/* 100 */     while (it.hasNext()) {
/* 101 */       HSSFRow row = sheet.createRow(index);
/* 102 */       Object t = it.next();
/* 103 */       if (methodNames == null) {
/* 104 */         methodNames = getMethodNames(t);
/*     */       }
/* 106 */       for (short i = 0; i < methodNames.length; i = (short)(i + 1)) {
/*     */         try {
/* 108 */           Class tCls = t.getClass();
/* 109 */           Method getMethod = tCls.getMethod(methodNames[i], new Class[0]);
/* 110 */           Object value = getMethod.invoke(t, new Object[0]);
/*     */ 
/* 112 */           String textValue = null;
/* 113 */           if ((value instanceof Boolean)) {
/* 114 */             boolean bValue = ((Boolean)value).booleanValue();
/* 115 */             textValue = "1";
/* 116 */             if (!bValue)
/* 117 */               textValue = "0";
/*     */           }
/* 119 */           else if ((value instanceof Date)) {
/* 120 */             Date date = (Date)value;
/* 121 */             if (pattern == null) {
/* 122 */               pattern = this.DEFAULTDATEPATTERN;
/*     */             }
/* 124 */             SimpleDateFormat sdf = new SimpleDateFormat(pattern);
/* 125 */             textValue = sdf.format(date);
/*     */           }
/* 128 */           else if (value == null) {
/* 129 */             textValue = "";
/*     */           } else {
/* 131 */             textValue = value.toString();
/*     */           }
/*     */ 
/* 135 */           if (textValue != null)
/* 136 */             POIExcelHelper.createCell(row, i, textValue, style);
/*     */         }
/*     */         catch (SecurityException se) {
/* 139 */           logger.error("reflect failed!");
/* 140 */           logger.debug("TExcelFactory.parseDataByObj():", se);
/*     */         } catch (NoSuchMethodException nme) {
/* 142 */           logger.error("reflect failed, maybe method not found!");
/* 143 */           logger.debug("TExcelFactory.parseDataByObj():", nme);
/*     */         } catch (IllegalArgumentException iae) {
/* 145 */           logger.error("reflect failed, maybe parameter invalid!");
/* 146 */           logger.debug("TExcelFactory.parseDataByObj():", iae);
/*     */         } catch (IllegalAccessException iae) {
/* 148 */           logger.error("reflect failed, access denied!");
/* 149 */           logger.debug("TExcelFactory.parseDataByObj():", iae);
/*     */         } catch (InvocationTargetException ite) {
/* 151 */           logger.error("reflect failed, return object invalid!");
/* 152 */           logger.debug("TExcelFactory.parseDataByObj():", ite);
/*     */         }
/*     */       }
/* 155 */       index++;
/*     */     }
/*     */   }
/*     */ 
/*     */   private String[] getMethodNames(T t)
/*     */   {
/* 167 */     Field[] fields = t.getClass().getDeclaredFields();
/* 168 */     String[] methodNames = new String[fields.length];
/* 169 */     for (int i = 0; i < fields.length; i++) {
/* 170 */       Field field = fields[i];
/* 171 */       String fieldName = field.getName();
/* 172 */       String prefix = "get";
/* 173 */       if (field.getType().equals(Boolean.TYPE)) {
/* 174 */         prefix = "is";
/*     */       }
/* 176 */       String getMethodName = prefix + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
/*     */ 
/* 179 */       methodNames[i] = getMethodName;
/*     */     }
/* 181 */     return methodNames;
/*     */   }
/*     */ 
/*     */   private int getHeadRowSize(List<CellBean> headerList)
/*     */   {
/* 190 */     int rowSize = 1;
/* 191 */     for (CellBean cellBean : headerList) {
/* 192 */       if (cellBean.getRowindex() + 1 > rowSize) {
/* 193 */         rowSize = cellBean.getRowindex() + 1;
/*     */       }
/*     */     }
/* 196 */     return rowSize;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.export.excelhelper.TExcelFactory
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.file;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ public class FileOperation
/*    */ {
/*    */   public static void generateFile(String path, String fileName, CharSequence content, String encode)
/*    */     throws FileNotFoundException, UnsupportedEncodingException
/*    */   {
/* 33 */     File dirFile = new File(path);
/* 34 */     if (!dirFile.exists()) {
/* 35 */       dirFile.mkdirs();
/*    */     }
/*    */ 
/* 39 */     File jsp = new File(dirFile, fileName);
/*    */ 
/* 42 */     PrintWriter printWriter = null;
/* 43 */     printWriter = new PrintWriter(jsp);
/*    */     try {
/* 45 */       printWriter = new PrintWriter(jsp, encode);
/* 46 */       printWriter.println(content);
/*    */     } catch (FileNotFoundException e) {
/* 48 */       throw new RuntimeException("Can not find the file " + jsp);
/*    */     } catch (UnsupportedEncodingException e) {
/* 50 */       throw new RuntimeException("UnsupportedEncoding " + encode);
/*    */     } finally {
/* 52 */       if (printWriter != null)
/* 53 */         printWriter.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception
/*    */   {
/* 59 */     String path = "c:\\wwww\\hehe\\lala";
/* 60 */     String fileName = "test.jsp";
/* 61 */     generateFile(path, fileName, "我爱世界杯", "UTF-8");
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.file.FileOperation
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.ftp;
/*    */ 
/*    */ import sun.net.NetworkClient;
/*    */ import sun.net.ftp.FtpClient;
/*    */ 
/*    */ public class CustomFtpClient extends FtpClient
/*    */ {
/*    */   private CustomFtpClient()
/*    */   {
/*    */   }
/*    */ 
/*    */   protected CustomFtpClient(String encodingStr)
/*    */   {
/* 26 */     NetworkClient.encoding = encodingStr;
/*    */   }
/*    */ 
/*    */   protected void setEncoding(String encodingStr)
/*    */   {
/* 36 */     NetworkClient.encoding = encodingStr;
/*    */   }
/*    */ 
/*    */   protected String getEncoding()
/*    */   {
/* 45 */     return NetworkClient.encoding;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.ftp.CustomFtpClient
 * JD-Core Version:    0.6.2
 */
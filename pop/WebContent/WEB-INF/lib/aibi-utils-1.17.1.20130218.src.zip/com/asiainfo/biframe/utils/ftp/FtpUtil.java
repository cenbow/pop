/*     */ package com.asiainfo.biframe.utils.ftp;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import sun.net.TelnetInputStream;
/*     */ import sun.net.TelnetOutputStream;
/*     */ 
/*     */ public class FtpUtil
/*     */ {
/*  47 */   private String serverIp = "";
/*     */ 
/*  49 */   private String userName = "";
/*     */ 
/*  51 */   private String password = "";
/*     */ 
/*  53 */   private String path = "";
/*     */ 
/*  55 */   private int serverPort = -1;
/*     */ 
/*  57 */   private String encoding = "GBK";
/*     */ 
/*  59 */   protected CustomFtpClient ftpClient = null;
/*     */ 
/*  71 */   OutputStream os = null;
/*     */ 
/*  73 */   FileInputStream is = null;
/*     */ 
/*     */   public CustomFtpClient getFtpClient()
/*     */   {
/*  63 */     return this.ftpClient;
/*     */   }
/*     */ 
/*     */   public void setFtpClient(CustomFtpClient ftpClient)
/*     */   {
/*  68 */     this.ftpClient = ftpClient;
/*     */   }
/*     */ 
/*     */   public FtpUtil()
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  83 */       this.serverIp = Configure.getInstance().getProperty("PLANDEMO_FTP_SERVER");
/*     */ 
/*  85 */       this.userName = Configure.getInstance().getProperty("PLANDEMO_FTP_USERNAME");
/*     */ 
/*  87 */       this.password = Configure.getInstance().getProperty("PLANDEMO_FTP_PASSWORD");
/*     */ 
/*  89 */       this.path = Configure.getInstance().getProperty("PLANDEMO_FTP_DIR");
/*  90 */       this.encoding = StringUtil.obj2Str(Configure.getInstance().getProperty("PLANDEMO_FTP_ENCODING"), "GBK");
/*     */     } catch (Exception ex) {
/*  92 */       ex.getMessage();
/*     */     }
/*     */   }
/*     */ 
/*     */   public FtpUtil(String ip, String name, String pwd, String encodingStr, String defPath, int port)
/*     */   {
/* 111 */     this.serverIp = ip;
/* 112 */     this.userName = name;
/* 113 */     this.password = pwd;
/* 114 */     this.encoding = StringUtil.obj2Str(encodingStr, "GBK");
/* 115 */     this.path = defPath;
/* 116 */     this.serverPort = port;
/*     */   }
/*     */ 
/*     */   public String connectServer()
/*     */   {
/*     */     try
/*     */     {
/* 127 */       this.ftpClient = new CustomFtpClient(this.encoding);
/* 128 */       if (this.serverPort > 0)
/* 129 */         this.ftpClient.openServer(this.serverIp, this.serverPort);
/*     */       else {
/* 131 */         this.ftpClient.openServer(this.serverIp);
/*     */       }
/*     */ 
/* 134 */       this.ftpClient.login(this.userName, this.password);
/* 135 */       if ((this.path != null) && (this.path.trim().length() > 0)) {
/* 136 */         cdMkdir(this.path);
/*     */       }
/* 138 */       this.ftpClient.binary();
/* 139 */       return "true";
/*     */     } catch (Exception ex) {
/* 141 */       ex.printStackTrace();
/* 142 */     }return "connection error or the server there is no such path !";
/*     */   }
/*     */ 
/*     */   public String connectServer(String hostPath)
/*     */   {
/*     */     try
/*     */     {
/* 156 */       this.ftpClient = new CustomFtpClient(this.encoding);
/* 157 */       if (this.serverPort > 0)
/* 158 */         this.ftpClient.openServer(this.serverIp, this.serverPort);
/*     */       else {
/* 160 */         this.ftpClient.openServer(this.serverIp);
/*     */       }
/* 162 */       this.ftpClient.login(this.userName, this.password);
/*     */ 
/* 165 */       if ((hostPath != null) && (hostPath.trim().length() > 0)) {
/* 166 */         this.ftpClient.cd(hostPath);
/*     */       }
/* 168 */       this.ftpClient.binary();
/* 169 */       return "true";
/*     */     } catch (Exception ex) {
/* 171 */       ex.printStackTrace();
/* 172 */     }return "connection error or the server there is no such path !";
/*     */   }
/*     */ 
/*     */   public void closeConnect()
/*     */   {
/*     */     try
/*     */     {
/* 183 */       if (this.is != null) {
/* 184 */         this.is.close();
/*     */       }
/* 186 */       if (this.os != null) {
/* 187 */         this.os.close();
/*     */       }
/* 189 */       if ((this.ftpClient != null) && (this.ftpClient.serverIsOpen()))
/* 190 */         this.ftpClient.closeServer();
/*     */     }
/*     */     catch (Exception ex) {
/* 193 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public long downloadFile(String filename, String newfilename)
/*     */   {
/* 208 */     TelnetInputStream is = null;
/* 209 */     FileOutputStream os = null;
/* 210 */     long result = 0L;
/*     */     try {
/* 212 */       is = this.ftpClient.get(filename);
/* 213 */       File outfile = new File(newfilename);
/* 214 */       os = new FileOutputStream(outfile);
/* 215 */       bytes = new byte[1024];
/*     */       int c;
/* 217 */       while ((c = is.read(bytes)) != -1) {
/* 218 */         os.write(bytes, 0, c);
/* 219 */         result += c;
/*     */       }
/* 221 */       return result;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */       byte[] bytes;
/* 223 */       e.printStackTrace();
/* 224 */       return -1L;
/*     */     } finally {
/*     */       try {
/* 227 */         if (is != null) {
/* 228 */           is.close();
/*     */         }
/* 230 */         if (os != null)
/* 231 */           os.close();
/*     */       }
/*     */       catch (IOException e) {
/* 234 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getFileSize(String filename)
/*     */   {
/* 247 */     TelnetInputStream is = null;
/* 248 */     long result = 0L;
/*     */     try {
/* 250 */       is = this.ftpClient.get(filename);
/* 251 */       byte[] bytes = new byte[1024];
/*     */ 
/* 253 */       while ((c = is.read(bytes)) != -1) {
/* 254 */         result += c;
/*     */       }
/* 256 */       return result;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */       int c;
/* 258 */       e.printStackTrace();
/* 259 */       return -1L;
/*     */     } finally {
/*     */       try {
/* 262 */         if (is != null) {
/* 263 */           is.close();
/*     */         }
/* 265 */         if (this.os != null)
/* 266 */           this.os.close();
/*     */       }
/*     */       catch (IOException e) {
/* 269 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean upload(String filename)
/*     */   {
/* 285 */     String newname = "";
/* 286 */     if (filename.indexOf("/") > -1)
/* 287 */       newname = filename.substring(filename.lastIndexOf("/") + 1);
/* 288 */     else if (filename.indexOf("\\") > -1)
/* 289 */       newname = filename.substring(filename.lastIndexOf("\\") + 1);
/*     */     else {
/* 291 */       newname = filename;
/*     */     }
/* 293 */     return upload(filename, newname);
/*     */   }
/*     */ 
/*     */   public boolean upload(String fileName, String newName)
/*     */   {
/*     */     try
/*     */     {
/* 310 */       File file_in = new File(fileName);
/* 311 */       if (!file_in.exists()) {
/* 312 */         throw new Exception("This file or folder[" + file_in.getName() + "] incorrect or does not exist !");
/*     */       }
/* 314 */       if (file_in.isDirectory())
/* 315 */         upload(file_in.getPath(), newName, this.ftpClient.pwd());
/*     */       else {
/* 317 */         uploadFile(file_in.getPath(), newName);
/*     */       }
/*     */ 
/* 320 */       if (this.is != null) {
/* 321 */         this.is.close();
/*     */       }
/* 323 */       if (this.os != null) {
/* 324 */         this.os.close();
/*     */       }
/* 326 */       return true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       boolean bool;
/* 328 */       e.printStackTrace();
/* 329 */       System.err.println("Exception e in Ftp upload(): " + e.toString());
/* 330 */       return false;
/*     */     } finally {
/*     */       try {
/* 333 */         if (this.is != null) {
/* 334 */           this.is.close();
/*     */         }
/* 336 */         if (this.os != null)
/* 337 */           this.os.close();
/*     */       }
/*     */       catch (IOException e) {
/* 340 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void upload(String fileName, String newName, String path)
/*     */     throws Exception
/*     */   {
/* 355 */     File file_in = new File(fileName);
/* 356 */     if (!file_in.exists()) {
/* 357 */       throw new Exception("This file or folder[" + file_in.getName() + "] incorrect or does not exist !");
/*     */     }
/* 359 */     if (file_in.isDirectory()) {
/* 360 */       if (!isDirExist(newName)) {
/* 361 */         createDir(newName);
/*     */       }
/* 363 */       this.ftpClient.cd(newName);
/* 364 */       File[] sourceFile = file_in.listFiles();
/* 365 */       for (int i = 0; i < sourceFile.length; i++)
/* 366 */         if (sourceFile[i].exists())
/*     */         {
/* 369 */           if (sourceFile[i].isDirectory()) {
/* 370 */             upload(sourceFile[i].getPath(), sourceFile[i].getName(), path + File.separator + newName);
/*     */           }
/*     */           else
/* 373 */             uploadFile(sourceFile[i].getPath(), sourceFile[i].getName());
/*     */         }
/*     */     }
/*     */     else
/*     */     {
/* 378 */       uploadFile(file_in.getPath(), newName);
/*     */     }
/* 380 */     this.ftpClient.cd(path);
/*     */   }
/*     */ 
/*     */   public long uploadFile(String filename, String newname)
/*     */     throws Exception
/*     */   {
/* 396 */     TelnetOutputStream os = null;
/* 397 */     FileInputStream is = null;
/* 398 */     long result = 0L;
/*     */     try {
/* 400 */       File file_in = new File(filename);
/* 401 */       if (!file_in.exists()) {
/* 402 */         return -1L;
/*     */       }
/* 404 */       os = this.ftpClient.put(newname);
/* 405 */       is = new FileInputStream(file_in);
/* 406 */       byte[] bytes = new byte[1024];
/*     */       int c;
/* 408 */       while ((c = is.read(bytes)) != -1) {
/* 409 */         os.write(bytes, 0, c);
/* 410 */         result += c;
/*     */       }
/* 412 */       return result;
/*     */     } finally {
/* 414 */       if (is != null) {
/* 415 */         is.close();
/*     */       }
/* 417 */       if (os != null)
/* 418 */         os.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isDirExist(String dir)
/*     */   {
/* 430 */     String pwd = "";
/*     */     try {
/* 432 */       pwd = this.ftpClient.pwd();
/* 433 */       this.ftpClient.cd(dir);
/* 434 */       this.ftpClient.cd(pwd);
/*     */     } catch (Exception e) {
/* 436 */       return false;
/*     */     }
/* 438 */     return true;
/*     */   }
/*     */ 
/*     */   public void cdMkdir(String path)
/*     */     throws IOException
/*     */   {
/* 448 */     if ((path != null) && (path.trim().length() > 0)) {
/* 449 */       path = path.trim();
/* 450 */       if (!isDirExist(path))
/*     */       {
/* 452 */         createDir(path);
/*     */       }
/*     */ 
/* 455 */       this.ftpClient.cd(path);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean createDir(String dir)
/*     */   {
/*     */     try
/*     */     {
/* 466 */       this.ftpClient.ascii();
/* 467 */       StringTokenizer s = new StringTokenizer(dir, "/");
/* 468 */       s.countTokens();
/* 469 */       String pathName = this.ftpClient.pwd();
/* 470 */       while (s.hasMoreElements()) {
/* 471 */         pathName = pathName + "/" + (String)s.nextElement();
/*     */         try {
/* 473 */           this.ftpClient.sendServer("MKD " + pathName + "\r\n");
/*     */         } catch (Exception e) {
/* 475 */           e.printStackTrace();
/* 476 */           return false;
/*     */         }
/* 478 */         this.ftpClient.readServerResponse();
/*     */       }
/* 480 */       this.ftpClient.binary();
/* 481 */       return true;
/*     */     } catch (IOException e1) {
/* 483 */       e1.printStackTrace();
/*     */     }
/* 485 */     return false;
/*     */   }
/*     */ 
/*     */   public List<String> getFileList(String subPath)
/*     */   {
/* 498 */     if ((subPath == null) || (subPath.trim().length() < 1)) {
/* 499 */       return getFileList();
/*     */     }
/* 501 */     List list = new ArrayList();
/*     */     try
/*     */     {
/* 504 */       BufferedReader dis = new BufferedReader(new InputStreamReader(this.ftpClient.nameList(subPath), this.ftpClient.getEncoding()));
/* 505 */       String filename = "";
/* 506 */       while ((filename = dis.readLine()) != null)
/* 507 */         list.add(filename);
/*     */     }
/*     */     catch (IOException e) {
/* 510 */       e.printStackTrace();
/*     */     }
/* 512 */     return list;
/*     */   }
/*     */ 
/*     */   public List<String> getFileList()
/*     */   {
/* 524 */     List list = new ArrayList();
/*     */     try
/*     */     {
/* 527 */       BufferedReader dis = new BufferedReader(new InputStreamReader(this.ftpClient.list()));
/* 528 */       String filename = "";
/* 529 */       while ((filename = dis.readLine()) != null)
/* 530 */         list.add(filename);
/*     */     }
/*     */     catch (IOException e) {
/* 533 */       e.printStackTrace();
/*     */     }
/* 535 */     return list;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 539 */     String ip = "10.1.20.140";
/* 540 */     String name = "king";
/* 541 */     String pwd = "king";
/* 542 */     String encodingStr = null;
/* 543 */     String defPath = null;
/* 544 */     int port = 2121;
/* 545 */     FtpUtil ft = new FtpUtil(ip, name, pwd, encodingStr, defPath, port);
/* 546 */     System.out.println(ft.connectServer());
/* 547 */     ft.upload("c:/test.xls");
/* 548 */     ft.closeConnect();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.ftp.FtpUtil
 * JD-Core Version:    0.6.2
 */
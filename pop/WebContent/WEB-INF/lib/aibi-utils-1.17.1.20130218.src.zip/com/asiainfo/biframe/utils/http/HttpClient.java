/*    */ package com.asiainfo.biframe.utils.http;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.Socket;
/*    */ import java.net.URL;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class HttpClient
/*    */ {
/* 35 */   private static Log log = LogFactory.getLog(HttpClient.class);
/*    */ 
/*    */   public static String getURL(String in)
/*    */     throws Exception
/*    */   {
/* 50 */     URL url = new URL(in);
/* 51 */     String protocol = url.getProtocol();
/* 52 */     if (!protocol.equals("http"))
/* 53 */       throw new IllegalArgumentException("Only support HTTP protocol.");
/*    */     String host;
/* 55 */     if ((host = url.getHost()) == null)
/* 56 */       throw new IllegalArgumentException("Invalid host specified.");
/*    */     int port;
/* 59 */     if ((port = url.getPort()) == -1)
/* 60 */       port = 80;
/*    */     String filename;
/* 63 */     if ((filename = url.getFile()) == "") {
/* 64 */       filename = "/";
/*    */     }
/*    */ 
/* 67 */     Socket socket = new Socket(host, port);
/*    */ 
/* 70 */     InputStream from = socket.getInputStream();
/* 71 */     PrintWriter to = new PrintWriter(socket.getOutputStream());
/*    */ 
/* 73 */     to.print("GET " + filename + " HTTP/1.0\n");
/* 74 */     to.print("Accept: */*\n");
/* 75 */     to.print("Accept-Language: zh-cn\n");
/* 76 */     to.print("Accept-Encoding: gzip, deflate\n");
/* 77 */     to.print("User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)\n");
/*    */ 
/* 79 */     to.print("Host: " + url.getHost() + "\n");
/* 80 */     to.print("Connection: Keep-Alive\n\n");
/* 81 */     to.flush();
/*    */ 
/* 84 */     byte[] buf = new byte[4096];
/*    */ 
/* 86 */     String str = "";
/*    */     int bytes_read;
/* 87 */     while ((bytes_read = from.read(buf)) != -1) {
/* 88 */       str = str + new String(buf, 0, bytes_read);
/*    */     }
/* 90 */     log.debug("-------------result for url:[" + in + "]" + str);
/* 91 */     socket.close();
/* 92 */     return str;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.http.HttpClient
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.http;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.string.StringUtil;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ResponseEncodingUtil
/*    */ {
/* 34 */   private static Logger log = Logger.getLogger(ResponseEncodingUtil.class);
/*    */ 
/*    */   public static String encodingFileName(String fileName, String charset)
/*    */   {
/* 39 */     String returnFileName = "";
/*    */     try {
/* 41 */       returnFileName = URLEncoder.encode(fileName, "UTF-8");
/* 42 */       returnFileName = StringUtil.replaceAll(returnFileName, "+", "%20");
/* 43 */       if (returnFileName.length() > 150) {
/* 44 */         returnFileName = new String(fileName.getBytes(charset), "ISO8859-1");
/*    */ 
/* 46 */         returnFileName = StringUtil.replaceAll(returnFileName, " ", "%20");
/*    */       }
/*    */     }
/*    */     catch (UnsupportedEncodingException e) {
/* 50 */       e.printStackTrace();
/* 51 */       log.info("Don't support this encoding ...");
/*    */     }
/* 53 */     return returnFileName;
/*    */   }
/*    */ 
/*    */   public static String getGuessCharset(String clientLanguage) {
/* 57 */     clientLanguage = clientLanguage.toLowerCase();
/*    */     String result;
/*    */     String result;
/* 60 */     if (clientLanguage.indexOf("zh-cn") > 0) {
/* 61 */       result = "GBK";
/*    */     }
/*    */     else
/*    */     {
/*    */       String result;
/* 64 */       if (clientLanguage.indexOf("zh-tw") > 0) {
/* 65 */         result = "BIG5";
/*    */       }
/*    */       else
/*    */       {
/*    */         String result;
/* 68 */         if (clientLanguage.indexOf("jp") > 0) {
/* 69 */           result = "SJIS";
/*    */         }
/*    */         else
/*    */         {
/* 73 */           result = "ISO-8859-1";
/*    */         }
/*    */       }
/*    */     }
/* 75 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.http.ResponseEncodingUtil
 * JD-Core Version:    0.6.2
 */
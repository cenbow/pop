/*     */ package com.asiainfo.biframe.utils.i18n;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import jxl.Cell;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ import jxl.write.Label;
/*     */ import jxl.write.WritableSheet;
/*     */ import jxl.write.WritableWorkbook;
/*     */ import jxl.write.WriteException;
/*     */ import jxl.write.biff.RowsExceededException;
/*     */ 
/*     */ public class ExcelAndProperties
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  23 */     exportProToExcel("c:\\i18", "c:\\i18");
/*     */   }
/*     */ 
/*     */   public static void exportProToExcel(String sourcePath, String destPath)
/*     */   {
/*  38 */     File fileDir = new File(sourcePath);
/*  39 */     File[] fileArray = fileDir.listFiles();
/*     */ 
/*  42 */     Set fileSet = new HashSet();
/*     */ 
/*  45 */     FileInputStream zhFileInputStream = null;
/*  46 */     FileInputStream enFileInputStream = null;
/*     */ 
/*  49 */     WritableWorkbook excelbook = null;
/*     */ 
/*  52 */     for (int i = 0; i < fileArray.length; i++)
/*  53 */       if (!fileArray[i].isDirectory())
/*     */       {
/*  55 */         String fileName = fileArray[i].getName();
/*  56 */         String baseName = fileName.substring(0, fileName.indexOf("."));
/*  57 */         if (!fileSet.contains(baseName))
/*     */         {
/*  59 */           fileSet.add(baseName);
/*  60 */           String filePath = fileArray[i].getAbsolutePath();
/*     */           try
/*     */           {
/*  64 */             excelbook = Workbook.createWorkbook(new File(destPath + "\\" + baseName + ".xls"));
/*  65 */             WritableSheet excelSheet = excelbook.createSheet("词汇对照表" + fileName, 1);
/*     */ 
/*  67 */             Properties properties = new Properties();
/*  68 */             Properties properties_en = new Properties();
/*     */ 
/*  71 */             if (fileName.indexOf(".properties") != -1) {
/*  72 */               enFileInputStream = new FileInputStream(filePath);
/*  73 */               zhFileInputStream = new FileInputStream(filePath.replaceFirst(".properties", ".txt"));
/*     */             } else {
/*  75 */               zhFileInputStream = new FileInputStream(filePath);
/*  76 */               enFileInputStream = new FileInputStream(filePath.replaceFirst(".txt", ".properties"));
/*     */             }
/*  78 */             properties.load(zhFileInputStream);
/*  79 */             properties_en.load(enFileInputStream);
/*     */ 
/*  81 */             int j = 0;
/*  82 */             Set keySet = properties.keySet();
/*  83 */             excelSheet.addCell(new Label(0, 0, "key"));
/*  84 */             excelSheet.addCell(new Label(1, 0, "中文"));
/*  85 */             excelSheet.addCell(new Label(2, 0, "English"));
/*  86 */             for (Iterator i$ = keySet.iterator(); i$.hasNext(); ) { Object key = i$.next();
/*  87 */               excelSheet.addCell(new Label(0, j + 1, (String)key));
/*  88 */               excelSheet.addCell(new Label(1, j + 1, new String(properties.getProperty((String)key).getBytes("ISO-8859-1"), "UTF-8")));
/*  89 */               excelSheet.addCell(new Label(2, j + 1, properties_en.getProperty((String)key)));
/*  90 */               j++;
/*     */             }
/*  92 */             excelbook.write();
/*     */           } catch (IOException e) {
/*  94 */             e.printStackTrace();
/*     */           } catch (RowsExceededException e) {
/*  96 */             e.printStackTrace();
/*     */           } catch (WriteException e) {
/*  98 */             e.printStackTrace();
/*     */           } finally {
/*     */             try {
/* 101 */               if (excelbook != null) {
/* 102 */                 excelbook.close();
/* 103 */                 excelbook = null;
/*     */               }
/* 105 */               if (zhFileInputStream != null)
/* 106 */                 zhFileInputStream.close();
/* 107 */               if (enFileInputStream != null)
/* 108 */                 enFileInputStream.close();
/*     */             } catch (Exception e) {
/* 110 */               e.printStackTrace();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void exportExcelToProp(String sourcePath, String destPath)
/*     */   {
/* 128 */     String key = null;
/* 129 */     String zhValue = null;
/* 130 */     String enValue = null;
/*     */ 
/* 133 */     PrintWriter zhPrintWriter = null;
/* 134 */     PrintWriter enPrintWriter = null;
/*     */ 
/* 137 */     File fileDir = new File(sourcePath);
/* 138 */     File[] fileArray = fileDir.listFiles();
/*     */ 
/* 141 */     Workbook wb = null;
/* 142 */     for (int i = 0; i < fileArray.length; i++) {
/* 143 */       String fileName = fileArray[i].getName();
/* 144 */       if ((!fileArray[i].isDirectory()) && (fileName.indexOf(".xls") != -1))
/*     */       {
/* 146 */         File file = fileArray[i].getAbsoluteFile();
/*     */         try {
/* 148 */           wb = Workbook.getWorkbook(file);
/* 149 */           Sheet sheet = wb.getSheet(0);
/*     */ 
/* 151 */           zhPrintWriter = new PrintWriter(new File(destPath + "\\" + fileName.replace(".xls", ".txt")));
/* 152 */           enPrintWriter = new PrintWriter(new File(destPath + "\\" + fileName.replace(".xls", ".properties")));
/*     */ 
/* 155 */           for (int j = 1; j < sheet.getRows(); j++) {
/* 156 */             key = sheet.getCell(0, j).getContents();
/* 157 */             zhValue = sheet.getCell(1, j).getContents();
/* 158 */             enValue = sheet.getCell(2, j).getContents();
/* 159 */             zhPrintWriter.println(key + "=" + zhValue);
/* 160 */             enPrintWriter.println(key + "=" + enValue);
/*     */           }
/*     */         } catch (Exception e) {
/* 163 */           e.printStackTrace();
/*     */         } finally {
/* 165 */           if (zhPrintWriter != null)
/* 166 */             zhPrintWriter.close();
/* 167 */           if (enPrintWriter != null)
/* 168 */             enPrintWriter.close();
/* 169 */           if (wb != null)
/* 170 */             wb.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.i18n.ExcelAndProperties
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.i18n;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class FileUtils
/*     */ {
/*     */   public static void main(String[] arg)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static String getStreamCode(InputStream is)
/*     */   {
/*  17 */     String charset = null;
/*  18 */     byte[] first3Bytes = new byte[3];
/*     */     try
/*     */     {
/*  21 */       is.mark(0);
/*  22 */       int read = is.read(first3Bytes, 0, 3);
/*  23 */       if (read != -1) {
/*  24 */         if ((first3Bytes[0] == -1) && (first3Bytes[1] == -2)) {
/*  25 */           charset = "UTF-16LE";
/*  26 */         } else if ((first3Bytes[0] == -2) && (first3Bytes[1] == -1))
/*     */         {
/*  28 */           charset = "UTF-16BE";
/*  29 */         } else if ((first3Bytes[0] == -17) && (first3Bytes[1] == -69) && (first3Bytes[2] == -65))
/*     */         {
/*  32 */           charset = "UTF-8";
/*     */         } else {
/*  34 */           is.reset();
/*     */ 
/*  36 */           while ((read = is.read()) != -1)
/*     */           {
/*  38 */             if (read < 240)
/*     */             {
/*  40 */               if ((128 > read) || (read > 191))
/*     */               {
/*  42 */                 if ((192 <= read) && (read <= 223)) {
/*  43 */                   read = is.read();
/*  44 */                   if ((128 > read) || (read > 191))
/*     */                   {
/*     */                     break;
/*     */                   }
/*     */                 }
/*  49 */                 else if ((224 <= read) && (read <= 239)) {
/*  50 */                   read = is.read();
/*  51 */                   if ((128 <= read) && (read <= 191)) {
/*  52 */                     read = is.read();
/*  53 */                     if ((128 <= read) && (read <= 191)) {
/*  54 */                       charset = "UTF-8";
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  66 */       if (null == charset)
/*  67 */         charset = "GBK";
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  71 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  74 */     return charset;
/*     */   }
/*     */ 
/*     */   public static String getFileCode(File file)
/*     */   {
/*  79 */     InputStream is = null;
/*  80 */     String code = null;
/*     */     try {
/*  82 */       is = new BufferedInputStream(new FileInputStream(file));
/*  83 */       code = getStreamCode(is);
/*  84 */       is.close();
/*     */     } catch (Exception e) {
/*  86 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  89 */     return code;
/*     */   }
/*     */ 
/*     */   public static void deleteAll(File f) {
/*  93 */     if (!f.exists()) {
/*  94 */       return;
/*     */     }
/*  96 */     if (f.isFile()) {
/*  97 */       f.delete();
/*     */     } else {
/*  99 */       File[] files = f.listFiles();
/* 100 */       for (int i = 0; i < files.length; i++)
/* 101 */         deleteAll(files[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getFileSuffix(File f)
/*     */   {
/* 109 */     String name = f.getName();
/*     */ 
/* 111 */     return name.substring(name.lastIndexOf(".") + 1);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.i18n.FileUtils
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.i18n;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ public class GetChinessWords
/*     */ {
/*  15 */   public HashSet<String> fileType = new HashSet();
/*  16 */   public HashSet<String> continueChar = new HashSet();
/*     */ 
/*  19 */   public int fileCount = 0;
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  29 */     String path = "c:\\portal\\";
/*     */ 
/*  31 */     String outFile = "c:\\chiness.txt";
/*     */ 
/*  39 */     GetChinessWords gcw = new GetChinessWords();
/*     */ 
/*  42 */     gcw.addContinueChar('0'); gcw.addContinueChar('1'); gcw.addContinueChar('2'); gcw.addContinueChar('3'); gcw.addContinueChar('4');
/*  43 */     gcw.addContinueChar('5'); gcw.addContinueChar('6'); gcw.addContinueChar('7'); gcw.addContinueChar('8'); gcw.addContinueChar('9');
/*  44 */     gcw.addContinueChar(' '); gcw.addContinueChar('\\'); gcw.addContinueChar(','); gcw.addContinueChar('.'); gcw.addContinueChar('?');
/*  45 */     gcw.addContinueChar('!'); gcw.addContinueChar(';'); gcw.addContinueChar('='); gcw.addContinueChar('{'); gcw.addContinueChar('}');
/*  46 */     gcw.addContinueChar('['); gcw.addContinueChar(']');
/*     */ 
/*  50 */     gcw.addFileType("java");
/*  51 */     gcw.addFileType("jsp");
/*     */ 
/*  63 */     System.out.println("start......!");
/*  64 */     File result = gcw.getChiness(new File(path));
/*     */ 
/*  66 */     File f = new File(outFile);
/*  67 */     if (f.exists()) {
/*  68 */       f.delete();
/*     */     }
/*  70 */     result.renameTo(f);
/*     */ 
/*  72 */     System.out.println("finish!");
/*     */   }
/*     */ 
/*     */   public void addContinueChar(char c)
/*     */   {
/*  79 */     this.continueChar.add(c + "");
/*     */   }
/*     */ 
/*     */   public void addFileType(String fileType)
/*     */   {
/*  84 */     if (null != fileType)
/*  85 */       this.fileType.add(fileType.toLowerCase());
/*     */   }
/*     */ 
/*     */   public File getChiness(File file)
/*     */   {
/*  91 */     if (!file.exists()) {
/*  92 */       System.out.println("not exists " + file.getName());
/*  93 */       System.exit(0);
/*     */     }
/*     */ 
/*  96 */     File tmpfile = null;
/*     */     try
/*     */     {
/*  99 */       tmpfile = File.createTempFile("chiness", "tmp");
/* 100 */       OutputStream out = new FileOutputStream(tmpfile, true);
/* 101 */       OutputStreamWriter osw = new OutputStreamWriter(out, "GBK");
/*     */ 
/* 103 */       getChinessFolder(file, osw);
/*     */ 
/* 105 */       osw.close();
/* 106 */       out.close();
/*     */     }
/*     */     catch (IOException e) {
/* 109 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 112 */     return tmpfile;
/*     */   }
/*     */ 
/*     */   private void getChinessFolder(File file, OutputStreamWriter osw)
/*     */   {
/*     */     try {
/* 118 */       if (file.isFile()) {
/* 119 */         if (this.fileType.contains(FileUtils.getFileSuffix(file).toLowerCase())) {
/* 120 */           StringBuffer sb = getChinessWords(file);
/* 121 */           if (sb.length() > 0) {
/* 122 */             osw.write(file.getAbsolutePath());
/* 123 */             osw.write("\r\n");
/* 124 */             osw.write(sb.toString());
/*     */           }
/*     */         }
/*     */       } else {
/* 128 */         File[] files = file.listFiles();
/*     */ 
/* 130 */         for (int i = 0; i < files.length; i++)
/* 131 */           if (files[i].isFile())
/*     */           {
/* 133 */             if (this.fileType.contains(FileUtils.getFileSuffix(files[i]).toLowerCase())) {
/* 134 */               StringBuffer sb = getChinessWords(files[i]);
/* 135 */               if (sb.length() > 0) {
/* 136 */                 osw.write(files[i].getAbsolutePath());
/* 137 */                 osw.write("\r\n");
/* 138 */                 osw.write(sb.toString());
/*     */               }
/*     */             }
/*     */           }
/*     */           else
/* 143 */             getChinessFolder(files[i], osw);
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 148 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public StringBuffer getChinessWords(File file)
/*     */   {
/* 155 */     String line = null;
/* 156 */     StringBuffer sb = new StringBuffer();
/*     */     try
/*     */     {
/* 160 */       String fileCode = FileUtils.getFileCode(file);
/* 161 */       InputStreamReader read = new InputStreamReader(new FileInputStream(file), fileCode);
/* 162 */       BufferedReader br = new BufferedReader(read);
/* 163 */       boolean lastCharChiness = false;
/* 164 */       boolean commentArea = false;
/*     */ 
/* 167 */       while ((line = br.readLine()) != null)
/*     */       {
/* 170 */         char[] chars = line.toCharArray();
/*     */ 
/* 173 */         for (int i = 0; i < chars.length; i++)
/*     */         {
/* 175 */           byte[] bytes = ("" + chars[i]).getBytes("GBK");
/*     */ 
/* 177 */           if (('/' == chars[i]) && (i + 1 < chars.length)) {
/* 178 */             if ('/' == chars[(i + 1)]) break;
/* 179 */             if ('*' == chars[(i + 1)]) {
/* 180 */               commentArea = true;
/*     */             }
/*     */           }
/*     */ 
/* 184 */           if (('<' == chars[i]) && (i + 3 < chars.length) && 
/* 185 */             ('!' == chars[(i + 1)]) && ('-' == chars[(i + 2)]) && ('-' == chars[(i + 3)])) {
/* 186 */             commentArea = true;
/*     */           }
/*     */ 
/* 192 */           if ((lastCharChiness) && (this.continueChar.contains(chars[i] + ""))) {
/* 193 */             if (('\\' == chars[i]) && (i + 1 < chars.length) && (chars[(i + 1)] == 'n')) {
/* 194 */               sb.append(chars[i]);
/* 195 */               sb.append(chars[(i + 1)]);
/* 196 */               i++;
/* 197 */               continue;
/*     */             }
/* 199 */             sb.append(chars[i]);
/*     */           }
/* 202 */           else if ((bytes.length == 2) && (!commentArea)) {
/* 203 */             int[] ints = new int[2];
/* 204 */             bytes[0] &= 255;
/* 205 */             bytes[1] &= 255;
/* 206 */             if ((ints[0] >= 129) && (ints[0] <= 254) && (ints[1] >= 64) && (ints[1] <= 254))
/*     */             {
/* 208 */               if ((lastCharChiness) && (i == 0)) {
/* 209 */                 sb.append("\r\n");
/*     */               }
/* 211 */               sb.append(chars[i]);
/*     */ 
/* 213 */               lastCharChiness = true;
/*     */             } else {
/* 215 */               System.out.println("chars[i]:" + chars[i]);
/*     */             }
/* 217 */           } else if ((lastCharChiness) && (!commentArea)) {
/* 218 */             sb.append("\r\n");
/* 219 */             lastCharChiness = false;
/*     */           }
/*     */ 
/* 223 */           if (('*' == chars[i]) && (i + 1 < chars.length) && ('/' == chars[(i + 1)])) {
/* 224 */             commentArea = false;
/*     */           }
/*     */ 
/* 227 */           if (('-' == chars[i]) && (i + 2 < chars.length) && 
/* 228 */             ('-' == chars[(i + 1)]) && ('>' == chars[(i + 2)])) {
/* 229 */             commentArea = false;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 234 */         if (lastCharChiness) {
/* 235 */           sb.append("\r\n");
/* 236 */           lastCharChiness = false;
/*     */         }
/*     */       }
/*     */ 
/* 240 */       if (lastCharChiness) {
/* 241 */         sb.append("\r\n");
/* 242 */         lastCharChiness = false;
/*     */       }
/*     */     } catch (IOException e) {
/* 245 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 248 */     return sb;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.i18n.GetChinessWords
 * JD-Core Version:    0.6.2
 */
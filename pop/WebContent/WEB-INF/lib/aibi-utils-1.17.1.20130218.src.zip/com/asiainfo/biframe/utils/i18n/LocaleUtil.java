/*     */ package com.asiainfo.biframe.utils.i18n;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class LocaleUtil
/*     */ {
/*  34 */   private static Logger log = Logger.getLogger(LocaleUtil.class);
/*     */ 
/*  38 */   private static final ThreadLocal<Locale> currentLoacal = new ThreadLocal();
/*     */ 
/*  44 */   private static Map<String, String[]> sysLocaleInfoMap = new HashMap();
/*     */ 
/*     */   public static ThreadLocal<Locale> getCurrentloacal()
/*     */   {
/*  41 */     return currentLoacal;
/*     */   }
/*     */ 
/*     */   public static void addSysLocale(String sysCodeSet, String filePathSet, String fileNameSet, String fileTypeSet, String defaultLanguageSet)
/*     */   {
/*  61 */     if ((sysCodeSet == null) || (sysCodeSet.trim().length() < 1)) {
/*  62 */       log.error("----SysCode can't be null!");
/*  63 */       throw new NullPointerException("----SysCode can't be null!");
/*     */     }
/*  65 */     nullValueWarn(filePathSet, "i18n filePath");
/*  66 */     nullValueWarn(fileNameSet, "i18n fileName");
/*  67 */     if ((defaultLanguageSet == null) || (defaultLanguageSet.trim().length() < 1)) {
/*  68 */       defaultLanguageSet = "en";
/*     */     }
/*  70 */     if ((fileTypeSet == null) || (fileTypeSet.trim().length() < 1)) {
/*  71 */       fileTypeSet = ".properties";
/*     */     }
/*  73 */     String[] localeInfo = new String[4];
/*  74 */     localeInfo[0] = filePathSet;
/*  75 */     localeInfo[1] = fileNameSet;
/*  76 */     localeInfo[2] = fileTypeSet;
/*  77 */     localeInfo[3] = defaultLanguageSet;
/*     */ 
/*  79 */     sysLocaleInfoMap.put(sysCodeSet.trim().toUpperCase(), localeInfo);
/*     */   }
/*     */ 
/*     */   private static void nullValueWarn(String inputStr, String inputDesc) {
/*  83 */     if ((inputStr == null) || (inputStr.trim().length() < 1))
/*  84 */       log.error(inputDesc + " is null!");
/*     */   }
/*     */ 
/*     */   public static String getLocaleMessage(String sysCode, String key)
/*     */   {
/* 100 */     ResourceBundle bundle = null;
/* 101 */     if (sysCode == null) {
/* 102 */       log.error("sysCode can't be null!");
/* 103 */       return null;
/*     */     }
/* 105 */     String[] localeInfo = (String[])sysLocaleInfoMap.get(sysCode.trim().toUpperCase());
/*     */ 
/* 107 */     if (currentLoacal.get() == null) {
/* 108 */       currentLoacal.set(new Locale(localeInfo[3]));
/*     */     }
/* 110 */     Locale value = (Locale)currentLoacal.get();
/*     */     try {
/* 112 */       bundle = ResourceBundle.getBundle(localeInfo[0] + localeInfo[1], value);
/*     */     } catch (MissingResourceException e) {
/* 114 */       bundle = ResourceBundle.getBundle(localeInfo[0] + localeInfo[1], Locale.ENGLISH);
/*     */     }
/* 116 */     String result = "";
/*     */     try {
/* 118 */       result = bundle.getString(key);
/*     */     } catch (Exception e) {
/* 120 */       log.error("--Country--" + value.getCountry() + "-----Language:" + value.getLanguage() + "---fileName---" + localeInfo[0] + localeInfo[1] + ", key[" + key + "] not found!");
/*     */ 
/* 122 */       log.error(e.getMessage());
/*     */     }
/*     */ 
/* 125 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getLocaleMessage(String sysCode, String key, Object[] messageArgs)
/*     */   {
/* 139 */     String result = getLocaleMessage(sysCode, key);
/* 140 */     if ((key != null) && (messageArgs != null))
/* 141 */       result = MessageFormat.format(result, (Object[])messageArgs);
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getLocaleMessage(String sysCode, String key, String messageArg)
/*     */   {
/* 156 */     String result = getLocaleMessage(sysCode, key);
/* 157 */     if ((key != null) && (messageArg != null))
/* 158 */       result = MessageFormat.format(result, new Object[] { messageArg });
/* 159 */     return result;
/*     */   }
/*     */ 
/*     */   public static Locale getLocale()
/*     */   {
/* 164 */     return (Locale)currentLoacal.get();
/*     */   }
/*     */ 
/*     */   public static void setLocale(Locale locale)
/*     */   {
/* 175 */     currentLoacal.set(locale);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.i18n.LocaleUtil
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.i18n;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ public class SetChinessKeys
/*     */ {
/*  15 */   public static int count = 0;
/*     */ 
/*  91 */   private HashMap<String, String> keyMap = new HashMap();
/*  92 */   private HashSet<String> fileType = new HashSet();
/*  93 */   public HashSet<String> continueChar = new HashSet();
/*     */ 
/*  95 */   private HashMap<String, String> wordPrefix = new HashMap();
/*  96 */   private HashMap<String, String> wordSuffix = new HashMap();
/*     */ 
/*     */   public static void main(String[] arg)
/*     */   {
/*     */     try
/*     */     {
/*  20 */       SetChinessKeys sck = new SetChinessKeys();
/*     */ 
/*  25 */       String keyFile = "D:\\work\\5.1\\i18\\PrivilegeAdmin\\aiomni3_dev\\appfront\\src\\main\\webapp\\aibi_privilege\\js\\locale\\privilegeAdmin.txt";
/*     */ 
/*  28 */       String sourceFolder = "D:\\work\\5.1\\i18\\PrivilegeAdmin\\aiomni3_dev\\appfront\\src\\main\\webapp\\";
/*     */ 
/*  32 */       String resultFolder = "c:\\test";
/*     */ 
/*  34 */       String moduleName = "aibi_privilegeAdmin";
/*     */ 
/*  45 */       sck.addContinueChar('!');
/*     */ 
/*  59 */       sck.setWordTemplate("jsp", "<%=LocaleUtil.getLocaleMessage(\"" + moduleName + "\",\"", "\");%>");
/*     */ 
/*  61 */       sck.addFileType("js");
/*  62 */       sck.setWordTemplate("js", "\"+" + moduleName + "_messageBundle.", "+\"");
/*     */ 
/*  77 */       sck.loadKeyMap(new File(keyFile));
/*     */ 
/*  79 */       File source = new File(sourceFolder);
/*  80 */       File target = new File(resultFolder);
/*     */ 
/*  82 */       System.out.println("start......!");
/*  83 */       sck.replaceChinessWithKey(source, target);
/*  84 */       System.out.println("finish!");
/*     */     } catch (Exception e) {
/*  86 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setWordTemplate(String type, String wordPrefix, String wordSuffix)
/*     */   {
/*  99 */     this.wordPrefix.put(type, wordPrefix);
/* 100 */     this.wordSuffix.put(type, wordSuffix);
/*     */   }
/*     */ 
/*     */   public void addFileType(String fileType) {
/* 104 */     if (null != fileType)
/* 105 */       this.fileType.add(fileType.toLowerCase());
/*     */   }
/*     */ 
/*     */   public void addContinueChar(char c) {
/* 109 */     this.continueChar.add(c + "");
/*     */   }
/*     */ 
/*     */   public void loadKeyMap(File file) {
/* 113 */     if ((!file.exists()) || (!file.isFile()))
/* 114 */       System.exit(0);
/*     */     try
/*     */     {
/* 117 */       String fileCode = FileUtils.getFileCode(file);
/* 118 */       InputStreamReader read = new InputStreamReader(new FileInputStream(file), fileCode);
/* 119 */       BufferedReader br = new BufferedReader(read);
/* 120 */       String line = null;
/* 121 */       while ((line = br.readLine()) != null) {
/* 122 */         String[] key_value = line.split("=");
/* 123 */         if (key_value.length >= 2)
/*     */         {
/* 126 */           this.keyMap.put(key_value[1].trim(), key_value[0].trim());
/*     */         }
/*     */       }
/*     */     } catch (IOException e) {
/* 130 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void replaceChinessWithKey(File source, File target)
/*     */   {
/* 136 */     if (!source.exists()) {
/* 137 */       System.out.println("not exists " + source.getName());
/* 138 */       System.exit(0);
/*     */     }
/* 140 */     String targetName = target.getAbsolutePath() + File.separator + source.getName();
/* 141 */     File f = new File(targetName);
/*     */ 
/* 143 */     if (f.exists()) {
/* 144 */       FileUtils.deleteAll(f);
/*     */     }
/* 146 */     if (source.isDirectory()) {
/* 147 */       f.mkdirs();
/*     */     }
/*     */ 
/* 150 */     replaceFolder(source, f.getAbsolutePath());
/*     */   }
/*     */ 
/*     */   private void replaceFolder(File source, String currentFolder)
/*     */   {
/* 156 */     String type = null;
/* 157 */     if (source.isFile()) {
/* 158 */       type = FileUtils.getFileSuffix(source).toLowerCase();
/* 159 */       if ((this.fileType.contains(type)) || (this.fileType.contains("*")))
/* 160 */         replaceFile(source, currentFolder, type);
/*     */     }
/*     */     else {
/* 163 */       File[] files = source.listFiles();
/*     */ 
/* 165 */       for (int i = 0; i < files.length; i++)
/* 166 */         if (files[i].isFile()) {
/* 167 */           type = FileUtils.getFileSuffix(files[i]).toLowerCase();
/* 168 */           if ((this.fileType.contains(type)) || (this.fileType.contains("*"))) {
/* 169 */             System.out.println("file name:" + files[i].getAbsolutePath());
/* 170 */             replaceFile(files[i], currentFolder, type);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 175 */           String currentFolderChildFolder = currentFolder + File.separator + files[i].getName();
/* 176 */           File newChildFolder = new File(currentFolderChildFolder);
/* 177 */           if (!newChildFolder.exists()) {
/* 178 */             newChildFolder.mkdirs();
/*     */           }
/* 180 */           replaceFolder(files[i], currentFolderChildFolder);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void replaceFile(File source, String currentFolder, String type)
/*     */   {
/* 193 */     String newFileName = currentFolder + File.separator + source.getName();
/* 194 */     File newFile = new File(newFileName);
/*     */     try
/*     */     {
/* 198 */       newFile.createNewFile();
/*     */ 
/* 200 */       OutputStream out = new FileOutputStream(newFile, true);
/* 201 */       OutputStreamWriter osw = new OutputStreamWriter(out, "UTF-8");
/*     */ 
/* 204 */       String fileCode = FileUtils.getFileCode(source);
/* 205 */       InputStreamReader read = new InputStreamReader(new FileInputStream(source), fileCode);
/* 206 */       BufferedReader br = new BufferedReader(read);
/*     */ 
/* 208 */       boolean lastCharChiness = false;
/* 209 */       boolean commentArea = false;
/* 210 */       String line = null;
/* 211 */       String typeReal = type;
/* 212 */       boolean isFixImport = false;
/*     */ 
/* 214 */       while ((line = br.readLine()) != null)
/*     */       {
/* 217 */         String newLine = line;
/* 218 */         StringBuffer word = new StringBuffer();
/*     */ 
/* 221 */         if (line.indexOf("<%") > 0) {
/* 222 */           typeReal = "java";
/*     */         }
/*     */ 
/* 225 */         char[] chars = line.toCharArray();
/*     */ 
/* 228 */         for (int i = 0; i < chars.length; i++)
/*     */         {
/* 230 */           byte[] bytes = ("" + chars[i]).getBytes("GBK");
/*     */ 
/* 232 */           if (('/' == chars[i]) && (i + 1 < chars.length)) {
/* 233 */             if ('/' == chars[(i + 1)]) break;
/* 234 */             if ('*' == chars[(i + 1)]) {
/* 235 */               commentArea = true;
/*     */             }
/*     */           }
/*     */ 
/* 239 */           if (('<' == chars[i]) && (i + 3 < chars.length) && 
/* 240 */             ('!' == chars[(i + 1)]) && ('-' == chars[(i + 2)]) && ('-' == chars[(i + 3)])) {
/* 241 */             commentArea = true;
/*     */           }
/*     */ 
/* 248 */           if ((lastCharChiness) && (this.continueChar.contains(chars[i] + "")))
/*     */           {
/* 250 */             if (('\\' == chars[i]) && (i + 1 < chars.length) && (chars[(i + 1)] == 'n')) {
/* 251 */               word.append(chars[i]);
/* 252 */               word.append(chars[(i + 1)]);
/* 253 */               i++;
/* 254 */               continue;
/*     */             }
/* 256 */             word.append(chars[i]);
/*     */           }
/* 258 */           else if ((bytes.length == 2) && (!commentArea)) {
/* 259 */             int[] ints = new int[2];
/* 260 */             bytes[0] &= 255;
/* 261 */             bytes[1] &= 255;
/* 262 */             if ((ints[0] >= 129) && (ints[0] <= 254) && (ints[1] >= 64) && (ints[1] <= 254))
/*     */             {
/* 264 */               word.append(chars[i]);
/*     */ 
/* 266 */               lastCharChiness = true;
/*     */             } else {
/* 268 */               System.out.println("chars[i]:" + chars[i]);
/*     */             }
/* 270 */           } else if ((lastCharChiness) && (!commentArea)) {
/* 271 */             lastCharChiness = false;
/*     */ 
/* 274 */             newLine = replaceWord(newLine, word.toString(), typeReal);
/*     */ 
/* 276 */             word = new StringBuffer();
/*     */           }
/*     */ 
/* 281 */           if (('*' == chars[i]) && (i + 1 < chars.length) && ('/' == chars[(i + 1)])) {
/* 282 */             commentArea = false;
/*     */           }
/*     */ 
/* 285 */           if (('-' == chars[i]) && (i + 2 < chars.length) && 
/* 286 */             ('-' == chars[(i + 1)]) && ('>' == chars[(i + 2)])) {
/* 287 */             commentArea = false;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 294 */         if (("java".equals(typeReal)) && (line.indexOf("%>") > 0)) {
/* 295 */           typeReal = type;
/*     */         }
/*     */ 
/* 299 */         if (lastCharChiness) {
/* 300 */           newLine = replaceWord(newLine, word.toString(), typeReal);
/* 301 */           lastCharChiness = false;
/*     */         }
/*     */ 
/* 305 */         if (!isFixImport) {
/* 306 */           if (("java".equals(type)) && (line.indexOf("package com") >= 0)) {
/* 307 */             isFixImport = true;
/* 308 */             osw.write(newLine);
/* 309 */             osw.write("\r\n");
/* 310 */             osw.write("import com.asiainfo.biframe.utils.i18n.LocaleUtil;");
/* 311 */             osw.write("\r\n");
/* 312 */           } else if ("jsp".equals(type)) {
/* 313 */             isFixImport = true;
/*     */ 
/* 316 */             osw.write("\r\n");
/* 317 */             osw.write(newLine);
/* 318 */             osw.write("\r\n");
/*     */           }
/*     */           else {
/* 321 */             osw.write(newLine);
/* 322 */             osw.write("\r\n");
/*     */           }
/*     */         } else {
/* 325 */           osw.write(newLine);
/* 326 */           osw.write("\r\n");
/*     */         }
/*     */       }
/*     */ 
/* 330 */       osw.close();
/* 331 */       out.close();
/*     */     }
/*     */     catch (IOException e) {
/* 334 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private String replaceWord(String line, String word, String type)
/*     */   {
/* 340 */     String value = (String)this.keyMap.get(word);
/*     */ 
/* 342 */     if ((null == value) || (value.length() == 0)) {
/* 343 */       return line;
/*     */     }
/* 345 */     StringBuffer replacement = new StringBuffer();
/*     */ 
/* 347 */     String prefix = (String)this.wordPrefix.get(type);
/* 348 */     String suffix = (String)this.wordSuffix.get(type);
/*     */ 
/* 350 */     if (null != prefix) {
/* 351 */       replacement.append(prefix);
/*     */     }
/* 353 */     replacement.append(value);
/* 354 */     if (null != suffix) {
/* 355 */       replacement.append(suffix);
/*     */     }
/*     */ 
/* 359 */     System.out.println(++count + "\treplace[" + word + "] to [" + replacement + "]");
/*     */ 
/* 361 */     return line.replaceAll(word, replacement.toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.i18n.SetChinessKeys
 * JD-Core Version:    0.6.2
 */
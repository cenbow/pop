/*     */ package com.asiainfo.biframe.utils.i18n;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class StrutsLocaleFilter
/*     */   implements Filter
/*     */ {
/*  35 */   private static Logger log = Logger.getLogger(StrutsLocaleFilter.class);
/*     */ 
/*  37 */   protected boolean _localeEnable = true;
/*     */   protected String[] _excludedUrls;
/*     */   protected FilterConfig localeFilter;
/*  41 */   private final String _testFileName = "config/aibi_core/core-appresources";
/*     */ 
/*  43 */   private final Locale _defaultLocale = Locale.ENGLISH;
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  52 */     if (this._localeEnable) {
/*     */       try {
/*  54 */         HttpServletRequest req = (HttpServletRequest)request;
/*  55 */         String requestUrl = req.getRequestURL().toString();
/*  56 */         if ((this._excludedUrls != null) && (this._excludedUrls.length > 0)) {
/*  57 */           for (String exUrl : this._excludedUrls) {
/*  58 */             if (requestUrl.endsWith(exUrl)) {
/*  59 */               chain.doFilter(request, response);
/*  60 */               return;
/*     */             }
/*     */           }
/*     */         }
/*  64 */         log.info("[StrutsLocaleFilter] request url=" + req.getRequestURL());
/*     */ 
/*  67 */         Locale locale = req.getLocale();
/*  68 */         log.debug("[StrutsLocaleFilter] locale=" + locale);
/*  69 */         if (locale != null) {
/*  70 */           if ((locale.getCountry() == null) || (locale.getCountry().trim().length() < 1))
/*  71 */             locale = new Locale(locale.getLanguage());
/*     */           else
/*  73 */             locale = new Locale(locale.getLanguage(), locale.getCountry());
/*     */         }
/*     */         else {
/*  76 */           String language = Configure.getInstance().getProperty("LOCALE_LANGUAGE_DEFAULT");
/*  77 */           String country = Configure.getInstance().getProperty("LOCALE_COUNTRY_DEFAULT");
/*  78 */           locale = new Locale(language, country);
/*     */         }
/*     */ 
/*  82 */         if (!resourceExist(locale)) {
/*  83 */           log.warn("[StrutsLocaleFilter] " + locale + " not exists, switch to defaultLocale......");
/*  84 */           locale = this._defaultLocale;
/*     */         }
/*  86 */         log.info("in StrutsLocaleFilter doFilter locale.getLanguage():" + locale.getLanguage() + "  locale.getCountry():" + locale.getCountry());
/*  87 */         log.info("in StrutsLocaleFilter doFilter LocaleUtil.getCurrentloacal()" + LocaleUtil.getCurrentloacal());
/*  88 */         log.info("in StrutsLocaleFilter doFilter locale" + locale);
/*  89 */         LocaleUtil.setLocale(locale);
/*  90 */         req.getSession().setAttribute("org.apache.struts.action.LOCALE", locale);
/*     */ 
/*  92 */         chain.doFilter(request, response);
/*     */       } catch (Exception e) {
/*  94 */         e.printStackTrace();
/*  95 */         log.error("[StrutsLocaleFilter] error:[set locale by filter]");
/*     */       }
/*     */     } else {
/*  98 */       log.info("[StrutsLocaleFilter] localeEnable is false");
/*  99 */       chain.doFilter(request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/* 108 */     this.localeFilter = filterConfig;
/* 109 */     loadFilterSetting();
/*     */   }
/*     */ 
/*     */   private void loadFilterSetting()
/*     */   {
/* 116 */     String localeEnableStr = this.localeFilter.getInitParameter("localeEnable");
/* 117 */     if ((localeEnableStr != null) && ("false".equalsIgnoreCase(localeEnableStr)))
/* 118 */       this._localeEnable = false;
/*     */     else {
/* 120 */       this._localeEnable = true;
/*     */     }
/* 122 */     String excludedUrl = this.localeFilter.getInitParameter("excludedUrl");
/* 123 */     if ((excludedUrl != null) && (excludedUrl.trim().length() > 0))
/* 124 */       this._excludedUrls = excludedUrl.split(";");
/*     */   }
/*     */ 
/*     */   private boolean resourceExist(Locale locale)
/*     */   {
/* 134 */     boolean result = true;
/* 135 */     if (locale == null) {
/* 136 */       result = false;
/*     */     }
/*     */ 
/* 140 */     String suffix = "";
/* 141 */     if ((locale.getCountry() == null) || (locale.getCountry().trim().length() < 1))
/* 142 */       suffix = "_" + locale.getLanguage();
/*     */     else {
/* 144 */       suffix = "_" + locale.getLanguage() + "_" + locale.getCountry();
/*     */     }
/* 146 */     String testFileName = "config/aibi_core/core-appresources" + suffix + ".properties";
/* 147 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 148 */     URL testUrl = classLoader.getResource(testFileName);
/* 149 */     if (testUrl == null) {
/* 150 */       result = false;
/*     */     }
/*     */ 
/* 153 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.i18n.StrutsLocaleFilter
 * JD-Core Version:    0.6.2
 */
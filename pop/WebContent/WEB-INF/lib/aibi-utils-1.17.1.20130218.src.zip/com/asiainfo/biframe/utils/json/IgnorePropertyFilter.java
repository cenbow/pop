/*    */ package com.asiainfo.biframe.utils.json;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.sf.json.util.PropertyFilter;
/*    */ 
/*    */ public class IgnorePropertyFilter
/*    */   implements PropertyFilter
/*    */ {
/*  9 */   private List ignorePro = null;
/*    */ 
/*    */   IgnorePropertyFilter(List filterProperty) {
/* 12 */     this.ignorePro = filterProperty;
/*    */   }
/*    */ 
/*    */   public boolean apply(Object source, String name, Object value) {
/* 16 */     if (this.ignorePro.contains(name)) {
/* 17 */       return true;
/*    */     }
/* 19 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.json.IgnorePropertyFilter
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.json;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.export.excelhelper.CellBean;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.sf.json.JSON;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONObject;
/*     */ import net.sf.json.JsonConfig;
/*     */ import net.sf.json.util.PropertyFilter;
/*     */ import net.sf.json.xml.XMLSerializer;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ 
/*     */ public class JsonUtil
/*     */ {
/*     */   public static JSONObject Object2Json(Object o)
/*     */   {
/*  40 */     return JSONObject.fromObject(o);
/*     */   }
/*     */ 
/*     */   public static JSONArray Object2Json(List o)
/*     */   {
/*  50 */     return JSONArray.fromObject(o);
/*     */   }
/*     */ 
/*     */   public static JSONObject Object2Json(Object o, List filter)
/*     */   {
/*  62 */     JsonConfig jsonConfig = new JsonConfig();
/*  63 */     jsonConfig.setJsonPropertyFilter(new IgnorePropertyFilter(filter));
/*  64 */     return JSONObject.fromObject(o, jsonConfig);
/*     */   }
/*     */ 
/*     */   public static JSONArray Object2Json(List list, List filter)
/*     */   {
/*  77 */     JsonConfig jsonConfig = new JsonConfig();
/*  78 */     jsonConfig.setJsonPropertyFilter(new IgnorePropertyFilter(filter));
/*  79 */     return JSONArray.fromObject(list, jsonConfig);
/*     */   }
/*     */ 
/*     */   public static JSONObject Object2Json(Object obj, PropertyFilter propertyFilter)
/*     */   {
/*  92 */     JsonConfig jsonConfig = new JsonConfig();
/*  93 */     jsonConfig.setJsonPropertyFilter(propertyFilter);
/*  94 */     return JSONObject.fromObject(obj, jsonConfig);
/*     */   }
/*     */ 
/*     */   public static JSONArray Object2Json(List list, PropertyFilter propertyFilter)
/*     */   {
/* 106 */     JsonConfig jsonConfig = new JsonConfig();
/* 107 */     jsonConfig.setJsonPropertyFilter(propertyFilter);
/* 108 */     return JSONArray.fromObject(list, jsonConfig);
/*     */   }
/*     */ 
/*     */   public static String Object2JsonString(Object o)
/*     */   {
/* 121 */     return Object2Json(o).toString();
/*     */   }
/*     */ 
/*     */   public static String Object2JsonString(List o)
/*     */   {
/* 134 */     return Object2Json(o).toString();
/*     */   }
/*     */ 
/*     */   public static String Object2JsonString(Object o, List filter)
/*     */   {
/* 147 */     return Object2Json(o, filter).toString();
/*     */   }
/*     */ 
/*     */   public static String Object2JsonString(List list, List filter)
/*     */   {
/* 160 */     return Object2Json(list, filter).toString();
/*     */   }
/*     */ 
/*     */   public static Object JsonString2Bean(String js, Class c)
/*     */   {
/* 174 */     JSONObject jo = JSONObject.fromObject(js);
/* 175 */     List cellList = new ArrayList();
/* 176 */     if ((jo.containsKey("headers")) && (jo.getJSONArray("headers").size() > 0)) {
/* 177 */       JSONArray jarr = jo.getJSONArray("headers");
/* 178 */       for (int i = 0; i < jarr.size(); i++) {
/* 179 */         JSONObject jobj = (JSONObject)jarr.get(i);
/* 180 */         Map map1 = (Map)JSONObject.toBean(jobj, Map.class);
/* 181 */         CellBean cellbean = new CellBean();
/*     */         try {
/* 183 */           BeanUtils.copyProperties(cellbean, map1);
/* 184 */           cellList.add(cellbean);
/*     */         } catch (IllegalAccessException e) {
/* 186 */           e.printStackTrace();
/*     */         } catch (InvocationTargetException e) {
/* 188 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/* 192 */     Map map = (Map)JSONObject.toBean(jo, Map.class);
/* 193 */     if (cellList.size() > 0) {
/* 194 */       map.put("headers", cellList);
/*     */     }
/* 196 */     Object bean = null;
/*     */     try {
/* 198 */       bean = c.newInstance();
/* 199 */       BeanUtils.copyProperties(bean, map);
/*     */     }
/*     */     catch (InstantiationException e) {
/* 202 */       e.printStackTrace();
/*     */     } catch (IllegalAccessException e) {
/* 204 */       e.printStackTrace();
/*     */     } catch (InvocationTargetException e) {
/* 206 */       e.printStackTrace();
/*     */     }
/* 208 */     return bean;
/*     */   }
/*     */ 
/*     */   public static String JsonString2Xml(String s)
/*     */   {
/* 223 */     XMLSerializer xml = new XMLSerializer();
/* 224 */     String xmlString = xml.write(Object2Json(s));
/* 225 */     return xmlString;
/*     */   }
/*     */ 
/*     */   public static String Xml2JsonString(String s)
/*     */   {
/* 236 */     XMLSerializer xml = new XMLSerializer();
/* 237 */     JSON js = xml.read(s);
/* 238 */     return js.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.json.JsonUtil
 * JD-Core Version:    0.6.2
 */
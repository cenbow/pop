/*    */ package com.asiainfo.biframe.utils.log;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class LogUtil
/*    */ {
/*    */   public static void error(Logger log, String msg)
/*    */   {
/* 16 */     StringBuffer sb = new StringBuffer("*************************************************\n");
/* 17 */     sb.append(msg).append("\n*************************************************");
/* 18 */     log.error(sb);
/*    */   }
/*    */ 
/*    */   public static void warn(Logger log, String msg) {
/* 22 */     StringBuffer sb = new StringBuffer("-------------------------------------------------\n");
/* 23 */     sb.append(msg).append("\n-------------------------------------------------");
/* 24 */     log.error(sb);
/*    */   }
/*    */ 
/*    */   public static void cost(Logger log, String msg, Date beginTime) {
/* 28 */     StringBuffer sb = new StringBuffer(msg);
/* 29 */     sb.append(" costs [" + (new Date().getTime() - beginTime.getTime()) / 1000.0D + "] seconds");
/* 30 */     log.debug(sb);
/*    */   }
/*    */ 
/*    */   public static void printMap(Logger log, Map map) {
/* 34 */     Iterator it = map.keySet().iterator();
/* 35 */     while (it.hasNext()) {
/* 36 */       Object key = it.next();
/* 37 */       log.debug(key + "=" + map.get(key));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.log.LogUtil
 * JD-Core Version:    0.6.2
 */
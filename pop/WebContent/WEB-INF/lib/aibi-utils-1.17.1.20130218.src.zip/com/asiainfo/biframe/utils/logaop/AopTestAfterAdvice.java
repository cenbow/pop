/*    */ package com.asiainfo.biframe.utils.logaop;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.springframework.aop.AfterReturningAdvice;
/*    */ 
/*    */ public class AopTestAfterAdvice
/*    */   implements AfterReturningAdvice
/*    */ {
/* 10 */   private static final Logger log = Logger.getLogger(AopTestAfterAdvice.class);
/*    */ 
/*    */   public void afterReturning(Object returnValue, Method method, Object[] args, Object target)
/*    */   {
/* 14 */     String str = (String)args[0];
/* 15 */     log.debug("**This is the aop  post-notification methods :" + method.getName());
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.logaop.AopTestAfterAdvice
 * JD-Core Version:    0.6.2
 */
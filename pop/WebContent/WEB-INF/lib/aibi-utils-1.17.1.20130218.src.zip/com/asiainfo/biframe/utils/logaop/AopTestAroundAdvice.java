/*    */ package com.asiainfo.biframe.utils.logaop;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Date;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class AopTestAroundAdvice
/*    */   implements MethodInterceptor
/*    */ {
/* 12 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public Object invoke(MethodInvocation invocation) throws Exception {
/* 15 */     String fullClassName = invocation.getThis().getClass().getName();
/* 16 */     String className = StringUtils.substringAfterLast(fullClassName, ".");
/*    */ 
/* 18 */     String methodName = invocation.getMethod().getName();
/* 19 */     String name = className + ":" + methodName;
/*    */ 
/* 21 */     long showTime = System.currentTimeMillis();
/*    */     try {
/* 23 */       Date beginTime = new Date();
/* 24 */       this.logger.debug("--aop--" + showTime + "--start Method :" + name);
/*    */ 
/* 26 */       Object res = invocation.proceed();
/*    */ 
/* 31 */       Date endTime = new Date();
/* 32 */       long time = endTime.getTime() - beginTime.getTime();
/* 33 */       this.logger.debug("--aop--" + showTime + "--end of the method:" + name + ", used :" + time + " ms");
/*    */ 
/* 35 */       return res;
/*    */     } catch (Throwable e) {
/* 37 */       this.logger.error("***aop--" + showTime + "--implementation of the interceptor implementation of the exception  :" + name);
/* 38 */       throw new Exception("call around notification error", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.logaop.AopTestAroundAdvice
 * JD-Core Version:    0.6.2
 */
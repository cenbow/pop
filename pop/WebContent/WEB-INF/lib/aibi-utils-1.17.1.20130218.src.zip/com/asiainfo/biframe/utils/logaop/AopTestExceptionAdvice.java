/*    */ package com.asiainfo.biframe.utils.logaop;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ import org.springframework.aop.ThrowsAdvice;
/*    */ 
/*    */ public class AopTestExceptionAdvice
/*    */   implements ThrowsAdvice
/*    */ {
/*  8 */   private static final Logger log = Logger.getLogger(AopTestExceptionAdvice.class);
/*    */ 
/*    */   public void afterThrowing(Exception sx) {
/* 11 */     log.debug("This is the aop throw an exception notification method:" + sx.getMessage());
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.logaop.AopTestExceptionAdvice
 * JD-Core Version:    0.6.2
 */
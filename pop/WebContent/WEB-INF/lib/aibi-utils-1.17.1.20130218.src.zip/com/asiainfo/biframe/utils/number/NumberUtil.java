/*     */ package com.asiainfo.biframe.utils.number;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.DecimalFormat;
/*     */ 
/*     */ public class NumberUtil
/*     */ {
/*  20 */   public static String DEFAULT_FORMAT_PATTERN = "#,##0.00";
/*  21 */   public static String DEFAULT_NO_VALID_DATA = "-";
/*     */ 
/*     */   public static String numberFormat(int formatNum, char appendChar, int length)
/*     */   {
/*  30 */     String result = "";
/*  31 */     StringBuffer format = new StringBuffer();
/*  32 */     for (int i = 0; i < length; i++) {
/*  33 */       format.append(String.valueOf(appendChar));
/*     */     }
/*  35 */     DecimalFormat decimalFormat = new DecimalFormat(format.toString());
/*  36 */     result = decimalFormat.format(formatNum);
/*  37 */     return result;
/*     */   }
/*     */ 
/*     */   public static double roundNumber(double value, int scale)
/*     */   {
/*  51 */     if (scale < 0) {
/*  52 */       throw new IllegalArgumentException("The scale must be a positive integer or zero");
/*     */     }
/*     */ 
/*  55 */     BigDecimal b = new BigDecimal(Double.toString(value));
/*  56 */     BigDecimal one = new BigDecimal("1");
/*  57 */     return b.divide(one, scale, 4).doubleValue();
/*     */   }
/*     */ 
/*     */   public static String formatNumber(Object obj, String formatPattern, int fractionLen, int integerLen)
/*     */   {
/*  70 */     String res = "";
/*  71 */     DecimalFormat theFormat = null;
/*     */     try {
/*  73 */       if ((formatPattern == null) || (formatPattern.length() < 1))
/*  74 */         theFormat = new DecimalFormat(DEFAULT_FORMAT_PATTERN);
/*     */       else
/*  76 */         theFormat = new DecimalFormat(formatPattern);
/*  77 */       if (fractionLen >= 0)
/*  78 */         theFormat.setMaximumFractionDigits(fractionLen);
/*  79 */       if (integerLen > 0)
/*  80 */         theFormat.setMaximumIntegerDigits(integerLen);
/*  81 */       if ((obj instanceof String)) {
/*  82 */         obj = new Double((String)obj);
/*     */       }
/*  84 */       if (obj.equals(new Double(4.9E-324D)))
/*  85 */         return DEFAULT_NO_VALID_DATA;
/*  86 */       res = theFormat.format(obj);
/*     */     }
/*     */     catch (Exception e) {
/*  89 */       res = (String)obj;
/*     */     }
/*  91 */     return res;
/*     */   }
/*     */ 
/*     */   public static String formatNumber(Object obj, String formatPattern, int fractionLen, int integerLen, int dataUnit)
/*     */   {
/* 110 */     String res = "";
/* 111 */     if ((obj instanceof String)) {
/* 112 */       obj = new Double((String)obj);
/*     */     }
/* 114 */     if (obj.equals(new Double(4.9E-324D))) {
/* 115 */       return DEFAULT_NO_VALID_DATA;
/*     */     }
/* 117 */     obj = new Double(convertValue(((Double)obj).doubleValue(), dataUnit));
/*     */ 
/* 119 */     if (((Double)obj).doubleValue() == 0.0D)
/* 120 */       return "0";
/* 121 */     res = formatNumber(obj, formatPattern, fractionLen, integerLen) + getUnit(dataUnit);
/* 122 */     return res;
/*     */   }
/*     */ 
/*     */   public static String getUnit(int unit)
/*     */   {
/* 135 */     float dataUnit = (float)Math.pow(10.0D, unit);
/* 136 */     if (dataUnit == 0.01D)
/*     */     {
/* 138 */       return "%";
/*     */     }
/* 140 */     if (dataUnit == 1.0F)
/* 141 */       return "";
/* 142 */     if (dataUnit == 10.0F)
/* 143 */       return "十";
/* 144 */     if (dataUnit == 100.0F)
/* 145 */       return "百";
/* 146 */     if (dataUnit == 1000.0F)
/* 147 */       return "千";
/* 148 */     if (dataUnit == 10000.0F)
/* 149 */       return "万";
/* 150 */     if (dataUnit == 100000.0F)
/* 151 */       return "十万";
/* 152 */     if (dataUnit == 1000000.0F)
/* 153 */       return "百万";
/* 154 */     if (dataUnit == 10000000.0F)
/* 155 */       return "千万";
/* 156 */     if (dataUnit == 1.0E+008F)
/* 157 */       return "亿";
/* 158 */     return "";
/*     */   }
/*     */ 
/*     */   public static double convertValue(double value, int dataUnit)
/*     */   {
/* 169 */     return value / Math.pow(10.0D, dataUnit);
/*     */   }
/*     */ 
/*     */   public static String formatNum2String(int num, String pattern)
/*     */   {
/* 181 */     if (pattern == null) {
/* 182 */       pattern = "";
/*     */     }
/* 184 */     DecimalFormat format = new DecimalFormat(pattern);
/* 185 */     return format.format(num);
/*     */   }
/*     */ 
/*     */   public static String formatNum2String(double num, String pattern)
/*     */   {
/* 196 */     if (pattern == null) {
/* 197 */       pattern = "";
/*     */     }
/* 199 */     DecimalFormat format = new DecimalFormat(pattern);
/* 200 */     return format.format(num);
/*     */   }
/*     */ 
/*     */   public static String formatNum2String(long num, String pattern)
/*     */   {
/* 212 */     if (pattern == null) {
/* 213 */       pattern = "";
/*     */     }
/* 215 */     DecimalFormat format = new DecimalFormat(pattern);
/* 216 */     return format.format(num);
/*     */   }
/*     */ 
/*     */   public static String formatNum2String(BigDecimal num, String pattern)
/*     */   {
/* 228 */     if (pattern == null) {
/* 229 */       pattern = "";
/*     */     }
/* 231 */     DecimalFormat format = new DecimalFormat(pattern);
/* 232 */     return format.format(num.doubleValue());
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.number.NumberUtil
 * JD-Core Version:    0.6.2
 */
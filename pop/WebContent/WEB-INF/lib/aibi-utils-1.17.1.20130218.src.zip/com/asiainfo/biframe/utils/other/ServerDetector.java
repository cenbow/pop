/*     */ package com.asiainfo.biframe.utils.other;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class ServerDetector
/*     */ {
/*     */   public static final String GERONIMO_CLASS = "/org/apache/geronimo/system/main/Daemon.class";
/*     */   public static final String JBOSS_CLASS = "/org/jboss/Main.class";
/*     */   public static final String JETTY_CLASS = "/org/mortbay/jetty/Server.class";
/*     */   public static final String JONAS_CLASS = "/org/objectweb/jonas/server/Server.class";
/*     */   public static final String OC4J_CLASS = "/oracle/jsp/oc4jutil/Oc4jUtil.class";
/*     */   public static final String ORION_CLASS = "/com/evermind/server/ApplicationServer.class";
/*     */   public static final String PRAMATI_CLASS = "/com/pramati/Server.class";
/*     */   public static final String RESIN_CLASS = "/com/caucho/server/resin/Resin.class";
/*     */   public static final String REXIP_CLASS = "/com/tcc/Main.class";
/*     */   public static final String SUN7_CLASS = "/com/iplanet/ias/tools/cli/IasAdminMain.class";
/*     */   public static final String SUN8_CLASS = "/com/sun/enterprise/cli/framework/CLIMain.class";
/*     */   public static final String TOMCAT_CLASS = "/org/apache/catalina/startup/Bootstrap.class";
/*     */   public static final String WEBLOGIC_CLASS = "/weblogic/Server.class";
/*     */   public static final String WEBSPHERE_CLASS = "/com/ibm/websphere/product/VersionInfo.class";
/* 323 */   private static ServerDetector _instance = new ServerDetector();
/*     */   private String _serverId;
/*     */   private Boolean _geronimo;
/*     */   private Boolean _jBoss;
/*     */   private Boolean _jetty;
/*     */   private Boolean _jonas;
/*     */   private Boolean _oc4j;
/*     */   private Boolean _orion;
/*     */   private Boolean _resin;
/*     */   private Boolean _tomcat;
/*     */   private Boolean _webLogic;
/*     */   private Boolean _webSphere;
/*     */ 
/*     */   public static String getServerId()
/*     */   {
/*  54 */     ServerDetector sd = _instance;
/*     */ 
/*  56 */     if (sd._serverId == null) {
/*  57 */       if (isGeronimo())
/*  58 */         sd._serverId = "geronimo";
/*  59 */       else if (isJBoss())
/*  60 */         sd._serverId = "jboss";
/*  61 */       else if (isJOnAS())
/*  62 */         sd._serverId = "jonas";
/*  63 */       else if (isOC4J())
/*  64 */         sd._serverId = "oc4j";
/*  65 */       else if (isOrion())
/*  66 */         sd._serverId = "orion";
/*  67 */       else if (isResin())
/*  68 */         sd._serverId = "resin";
/*  69 */       else if (isWebLogic())
/*  70 */         sd._serverId = "weblogic";
/*  71 */       else if (isWebSphere()) {
/*  72 */         sd._serverId = "websphere";
/*     */       }
/*     */ 
/*  75 */       if (isJetty()) {
/*  76 */         if (sd._serverId == null)
/*  77 */           sd._serverId = "jetty";
/*     */         else
/*  79 */           sd._serverId += "-jetty";
/*     */       }
/*  81 */       else if (isTomcat()) {
/*  82 */         if (sd._serverId == null)
/*  83 */           sd._serverId = "tomcat";
/*     */         else {
/*  85 */           sd._serverId += "-tomcat";
/*     */         }
/*     */       }
/*  88 */       if (sd._serverId == null) {
/*  89 */         sd._serverId = "tomcat";
/*     */ 
/*  91 */         System.out.println("warning:server is not detected, set to tomcat......");
/*     */       }
/*     */     }
/*     */ 
/*  95 */     return sd._serverId;
/*     */   }
/*     */ 
/*     */   public static boolean isGeronimo()
/*     */   {
/* 105 */     ServerDetector sd = _instance;
/*     */ 
/* 107 */     if (sd._geronimo == null) {
/* 108 */       Class c = sd.getClass();
/*     */ 
/* 110 */       if (c.getResource("/org/apache/geronimo/system/main/Daemon.class") != null)
/* 111 */         sd._geronimo = Boolean.TRUE;
/*     */       else {
/* 113 */         sd._geronimo = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 117 */     return sd._geronimo.booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean isJBoss()
/*     */   {
/* 127 */     ServerDetector sd = _instance;
/*     */ 
/* 129 */     if (sd._jBoss == null) {
/* 130 */       Class c = sd.getClass();
/*     */ 
/* 132 */       if (c.getResource("/org/jboss/Main.class") != null)
/* 133 */         sd._jBoss = Boolean.TRUE;
/*     */       else {
/* 135 */         sd._jBoss = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 139 */     return sd._jBoss.booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean isJetty()
/*     */   {
/* 149 */     ServerDetector sd = _instance;
/*     */ 
/* 151 */     if (sd._jetty == null) {
/* 152 */       Class c = sd.getClass();
/*     */ 
/* 154 */       if (c.getResource("/org/mortbay/jetty/Server.class") != null)
/* 155 */         sd._jetty = Boolean.TRUE;
/*     */       else {
/* 157 */         sd._jetty = Boolean.FALSE;
/*     */       }
/*     */     }
/* 160 */     return sd._jetty.booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean isJOnAS()
/*     */   {
/* 170 */     ServerDetector sd = _instance;
/*     */ 
/* 172 */     if (sd._jonas == null) {
/* 173 */       Class c = sd.getClass();
/*     */ 
/* 175 */       if (c.getResource("/org/objectweb/jonas/server/Server.class") != null)
/* 176 */         sd._jonas = Boolean.TRUE;
/*     */       else {
/* 178 */         sd._jonas = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 182 */     return sd._jonas.booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean isOC4J()
/*     */   {
/* 192 */     ServerDetector sd = _instance;
/*     */ 
/* 194 */     if (sd._oc4j == null) {
/* 195 */       Class c = sd.getClass();
/*     */ 
/* 197 */       if (c.getResource("/oracle/jsp/oc4jutil/Oc4jUtil.class") != null)
/* 198 */         sd._oc4j = Boolean.TRUE;
/*     */       else {
/* 200 */         sd._oc4j = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 204 */     return sd._oc4j.booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean isOrion()
/*     */   {
/* 214 */     ServerDetector sd = _instance;
/*     */ 
/* 216 */     if (sd._orion == null) {
/* 217 */       Class c = sd.getClass();
/*     */ 
/* 219 */       if (c.getResource("/com/evermind/server/ApplicationServer.class") != null)
/* 220 */         sd._orion = Boolean.TRUE;
/*     */       else {
/* 222 */         sd._orion = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 226 */     return sd._orion.booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean isResin()
/*     */   {
/* 237 */     ServerDetector sd = _instance;
/*     */ 
/* 239 */     if (sd._resin == null) {
/* 240 */       Class c = sd.getClass();
/*     */ 
/* 242 */       if (c.getResource("/com/caucho/server/resin/Resin.class") != null)
/* 243 */         sd._resin = Boolean.TRUE;
/*     */       else {
/* 245 */         sd._resin = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 249 */     return sd._resin.booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean isTomcat()
/*     */   {
/* 260 */     ServerDetector sd = _instance;
/* 261 */     if (isJBoss()) {
/* 262 */       sd._tomcat = Boolean.FALSE;
/* 263 */     } else if (sd._tomcat == null) {
/* 264 */       Class c = sd.getClass();
/*     */ 
/* 266 */       if (c.getResource("/org/apache/catalina/startup/Bootstrap.class") != null)
/* 267 */         sd._tomcat = Boolean.TRUE;
/*     */       else {
/* 269 */         sd._tomcat = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 273 */     return sd._tomcat.booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean isWebLogic()
/*     */   {
/* 283 */     ServerDetector sd = _instance;
/*     */ 
/* 285 */     if (sd._webLogic == null) {
/* 286 */       Class c = sd.getClass();
/*     */ 
/* 288 */       if (c.getResource("/weblogic/Server.class") != null)
/* 289 */         sd._webLogic = Boolean.TRUE;
/*     */       else {
/* 291 */         sd._webLogic = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 295 */     return sd._webLogic.booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean isWebSphere()
/*     */   {
/* 305 */     ServerDetector sd = _instance;
/*     */ 
/* 307 */     if (sd._webSphere == null) {
/* 308 */       Class c = sd.getClass();
/*     */ 
/* 310 */       if (c.getResource("/com/ibm/websphere/product/VersionInfo.class") != null)
/* 311 */         sd._webSphere = Boolean.TRUE;
/*     */       else {
/* 313 */         sd._webSphere = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 317 */     return sd._webSphere.booleanValue();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.other.ServerDetector
 * JD-Core Version:    0.6.2
 */
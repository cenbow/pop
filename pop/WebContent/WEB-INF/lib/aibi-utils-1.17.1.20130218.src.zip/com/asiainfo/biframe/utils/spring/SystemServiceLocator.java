/*    */ package com.asiainfo.biframe.utils.spring;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*    */ 
/*    */ public class SystemServiceLocator
/*    */ {
/* 22 */   private static Log log = LogFactory.getLog(SystemServiceLocator.class);
/*    */   private static SystemServiceLocator instance;
/*    */   private static BeanFactory factory;
/*    */ 
/*    */   private SystemServiceLocator()
/*    */   {
/*    */   }
/*    */ 
/*    */   private SystemServiceLocator(ServletContext context)
/*    */   {
/*    */     try
/*    */     {
/* 38 */       factory = WebApplicationContextUtils.getWebApplicationContext(context);
/*    */ 
/* 40 */       log.info("--------->>SystemServiceLocator init successful by web...");
/*    */     } catch (Exception e) {
/* 42 */       log.debug(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static SystemServiceLocator getWebInstance(ServletContext context)
/*    */   {
/* 54 */     if (instance == null) {
/* 55 */       instance = new SystemServiceLocator(context);
/*    */     }
/* 57 */     return instance;
/*    */   }
/*    */ 
/*    */   public static SystemServiceLocator getInstance()
/*    */   {
/* 67 */     if (instance == null) {
/* 68 */       instance = new SystemServiceLocator();
/*    */     }
/* 70 */     return instance;
/*    */   }
/*    */ 
/*    */   public Object getService(String serviceId)
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 84 */       Object obj = null;
/* 85 */       if ((factory != null) && (serviceId != null) && (serviceId.length() > 1));
/* 87 */       return factory.getBean(serviceId);
/*    */     }
/*    */     catch (Exception e) {
/* 90 */       log.debug("------Get bean by  name [" + serviceId + "] error !");
/* 91 */     }throw new Exception("---------Get bean by  name [" + serviceId + "] error !");
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.spring.SystemServiceLocator
 * JD-Core Version:    0.6.2
 */
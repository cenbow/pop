/*    */ package com.asiainfo.biframe.utils.string;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import sun.misc.BASE64Decoder;
/*    */ import sun.misc.BASE64Encoder;
/*    */ 
/*    */ public final class Base64
/*    */ {
/*    */   public static String encode(String s)
/*    */   {
/* 36 */     if (s == null)
/* 37 */       return null;
/* 38 */     return new BASE64Encoder().encode(s.getBytes());
/*    */   }
/*    */ 
/*    */   public static String decode(String s)
/*    */   {
/* 50 */     if (s == null)
/* 51 */       return null;
/* 52 */     BASE64Decoder decoder = new BASE64Decoder();
/*    */     try {
/* 54 */       byte[] b = decoder.decodeBuffer(s);
/* 55 */       return new String(b); } catch (Exception e) {
/*    */     }
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */   public static void main(String[] aa)
/*    */   {
/* 62 */     String pwd1 = "Wangbt777";
/* 63 */     System.out.println(encode(pwd1));
/*    */ 
/* 65 */     String pwd2 = "V2FuZ2J0Nzc3";
/* 66 */     System.out.println(decode(pwd2));
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.string.Base64
 * JD-Core Version:    0.6.2
 */
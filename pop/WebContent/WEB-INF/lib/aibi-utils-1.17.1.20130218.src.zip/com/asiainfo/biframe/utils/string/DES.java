/*     */ package com.asiainfo.biframe.utils.string;
/*     */ 
/*     */ import com.sun.crypto.provider.SunJCE;
/*     */ import java.io.PrintStream;
/*     */ import java.security.Security;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ public class DES
/*     */ {
/*  33 */   public static int _DES = 1;
/*  34 */   public static int _DESede = 2;
/*  35 */   public static int _Blowfish = 3;
/*     */   private Cipher p_Cipher;
/*     */   private SecretKey p_Key;
/*     */   private String p_Algorithm;
/*     */   private static DES _instance;
/*  41 */   private static String hexKey = "B5584A5D9B61C23BE52CA1168C9110894C4FE9ABC8E9F251";
/*     */ 
/*     */   private void selectAlgorithm(int al) {
/*  44 */     switch (al) {
/*     */     case 1:
/*     */     default:
/*  47 */       this.p_Algorithm = "DES";
/*  48 */       break;
/*     */     case 2:
/*  50 */       this.p_Algorithm = "DESede";
/*  51 */       break;
/*     */     case 3:
/*  53 */       this.p_Algorithm = "Blowfish";
/*     */     }
/*     */   }
/*     */ 
/*     */   public DES(int algorithm)
/*     */     throws Exception
/*     */   {
/*  63 */     selectAlgorithm(algorithm);
/*  64 */     Security.addProvider(new SunJCE());
/*  65 */     this.p_Cipher = Cipher.getInstance(this.p_Algorithm);
/*     */   }
/*     */ 
/*     */   private byte[] getKey() {
/*  69 */     return checkKey().getEncoded();
/*     */   }
/*     */ 
/*     */   private SecretKey checkKey() {
/*     */     try {
/*  74 */       if (this.p_Key == null) {
/*  75 */         KeyGenerator keygen = KeyGenerator.getInstance(this.p_Algorithm);
/*     */ 
/*  81 */         this.p_Key = keygen.generateKey();
/*     */       }
/*     */     } catch (Exception nsae) {
/*     */     }
/*  85 */     return this.p_Key;
/*     */   }
/*     */ 
/*     */   private void setKey(byte[] enckey) {
/*  89 */     this.p_Key = new SecretKeySpec(enckey, this.p_Algorithm);
/*     */   }
/*     */ 
/*     */   private byte[] encode(byte[] data) throws Exception {
/*  93 */     this.p_Cipher.init(1, checkKey());
/*  94 */     return this.p_Cipher.doFinal(data);
/*     */   }
/*     */ 
/*     */   private byte[] decode(byte[] encdata, byte[] enckey) throws Exception {
/*  98 */     setKey(enckey);
/*  99 */     this.p_Cipher.init(2, this.p_Key);
/* 100 */     return this.p_Cipher.doFinal(encdata);
/*     */   }
/*     */ 
/*     */   private String byte2hex(byte[] b) {
/* 104 */     String hs = "";
/* 105 */     String stmp = "";
/* 106 */     for (int i = 0; i < b.length; i++) {
/* 107 */       stmp = Integer.toHexString(b[i] & 0xFF);
/* 108 */       if (stmp.length() == 1)
/* 109 */         hs = hs + "0" + stmp;
/*     */       else {
/* 111 */         hs = hs + stmp;
/*     */       }
/*     */     }
/* 114 */     return hs.toUpperCase();
/*     */   }
/*     */ 
/*     */   private byte[] hex2byte(String hex) throws IllegalArgumentException {
/* 118 */     if (hex.length() % 2 != 0) {
/* 119 */       System.out.println("hex:" + hex + "\nlength:" + hex.length());
/* 120 */       throw new IllegalArgumentException();
/*     */     }
/* 122 */     char[] arr = hex.toCharArray();
/* 123 */     byte[] b = new byte[hex.length() / 2];
/* 124 */     int i = 0; int j = 0; for (int l = hex.length(); i < l; j++) {
/* 125 */       String swap = "" + arr[(i++)] + arr[i];
/* 126 */       int byteint = Integer.parseInt(swap, 16) & 0xFF;
/* 127 */       b[j] = new Integer(byteint).byteValue();
/*     */ 
/* 124 */       i++;
/*     */     }
/*     */ 
/* 129 */     return b;
/*     */   }
/*     */ 
/*     */   public static String encrypt(String s)
/*     */     throws Exception
/*     */   {
/* 143 */     if (null == _instance) {
/* 144 */       _instance = new DES(_DESede);
/*     */     }
/*     */ 
/* 147 */     _instance.setKey(_instance.hex2byte(hexKey));
/*     */ 
/* 149 */     byte[] enc = _instance.encode(s.getBytes());
/* 150 */     String hexenc = _instance.byte2hex(enc);
/* 151 */     return hexenc;
/*     */   }
/*     */ 
/*     */   public static String decrypt(String s)
/*     */     throws Exception
/*     */   {
/* 163 */     if (null == _instance) {
/* 164 */       _instance = new DES(_DESede);
/*     */     }
/* 166 */     return new String(_instance.decode(_instance.hex2byte(s), _instance.hex2byte(hexKey)));
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception
/*     */   {
/* 171 */     String pwd = "ED2705F227C3C80B";
/* 172 */     System.out.println(decrypt(pwd));
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.string.DES
 * JD-Core Version:    0.6.2
 */
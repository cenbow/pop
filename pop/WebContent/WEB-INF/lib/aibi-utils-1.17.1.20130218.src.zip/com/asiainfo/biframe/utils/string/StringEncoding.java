/*     */ package com.asiainfo.biframe.utils.string;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public class StringEncoding
/*     */ {
/*     */   public static String convertCode(String s, String oldCharName, String newCharName)
/*     */   {
/*  41 */     if (StringUtil.isEmpty(s))
/*  42 */       return "";
/*     */     try
/*     */     {
/*  45 */       return new String(s.getBytes(oldCharName), newCharName);
/*     */     } catch (UnsupportedEncodingException e) {
/*  47 */       e.printStackTrace();
/*  48 */     }return null;
/*     */   }
/*     */ 
/*     */   public static String convert2Db(String s, String dbEncoding)
/*     */   {
/*  62 */     if ((StringUtil.isEmpty(s)) || (isGBK(dbEncoding)))
/*  63 */       return s;
/*     */     try
/*     */     {
/*  66 */       return new String(s.getBytes("GBK"), dbEncoding);
/*     */     } catch (UnsupportedEncodingException e) {
/*  68 */       e.printStackTrace();
/*  69 */     }return "";
/*     */   }
/*     */ 
/*     */   public static String convert2GBK(String s, String dbEncoding)
/*     */   {
/*  83 */     if (StringUtil.isEmpty(s))
/*  84 */       return "";
/*  85 */     if (isGBK(dbEncoding))
/*  86 */       return s;
/*     */     try
/*     */     {
/*  89 */       return new String(s.getBytes(dbEncoding), "GBK");
/*     */     } catch (UnsupportedEncodingException e) {
/*  91 */       e.printStackTrace();
/*  92 */     }return null;
/*     */   }
/*     */ 
/*     */   public static String convert2GBK(Object obj, String dbEncoding)
/*     */   {
/* 106 */     if (null == obj)
/* 107 */       return "";
/* 108 */     if (isGBK(dbEncoding))
/* 109 */       return StringUtil.obj2Str(obj);
/*     */     try
/*     */     {
/* 112 */       return new String(StringUtil.obj2Str(obj).getBytes(dbEncoding), "GBK");
/*     */     } catch (UnsupportedEncodingException e) {
/* 114 */       e.printStackTrace();
/* 115 */     }return null;
/*     */   }
/*     */ 
/*     */   public static String ISO2GBK(String str)
/*     */   {
/* 127 */     if (str == null)
/*     */     {
/* 129 */       return null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 134 */       byte[] b = str.getBytes("ISO-8859-1");
/* 135 */       return new String(b, "GBK");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 142 */       e.printStackTrace();
/*     */     }
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */   public static String GBK2ISO(String str)
/*     */   {
/* 154 */     if (str == null)
/*     */     {
/* 156 */       return null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 161 */       byte[] b = str.getBytes("GBK");
/* 162 */       return new String(b, "ISO-8859-1");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 169 */       e.printStackTrace();
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean isGBK(String dbEncoding)
/*     */   {
/* 182 */     if ((StringUtil.isEmpty(dbEncoding)) || (dbEncoding.equalsIgnoreCase("null")) || (dbEncoding.equalsIgnoreCase("gbk")) || (dbEncoding.equalsIgnoreCase("gb2312")))
/*     */     {
/* 186 */       return true;
/*     */     }
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */   public static String ascii2Native(String str)
/*     */   {
/* 201 */     StringBuffer buffer = new StringBuffer();
/*     */     try
/*     */     {
/* 204 */       ByteArrayOutputStream fos = new ByteArrayOutputStream(str.getBytes().length);
/* 205 */       Writer out = new OutputStreamWriter(fos, "UTF8");
/* 206 */       out.write(str);
/* 207 */       out.close();
/* 208 */       ByteArrayInputStream fis = new ByteArrayInputStream(fos.toByteArray());
/*     */ 
/* 210 */       InputStreamReader isr = new InputStreamReader(fis, "UTF8");
/* 211 */       Reader in = new BufferedReader(isr);
/*     */       int ch;
/* 214 */       while ((ch = in.read()) > -1) {
/* 215 */         buffer.append((char)ch);
/*     */       }
/*     */ 
/* 218 */       in.close();
/*     */ 
/* 220 */       return buffer.toString();
/*     */     } catch (IOException e) {
/* 222 */       e.printStackTrace();
/* 223 */     }return null;
/*     */   }
/*     */ 
/*     */   public static String ascii2NativeByTempFile(String str)
/*     */   {
/* 235 */     StringBuffer buffer = new StringBuffer();
/*     */     try
/*     */     {
/* 238 */       File file = File.createTempFile("fjcy", "tmp");
/* 239 */       FileOutputStream fos = new FileOutputStream(file);
/* 240 */       Writer out = new OutputStreamWriter(fos, "UTF8");
/* 241 */       out.write(str);
/* 242 */       out.close();
/* 243 */       FileInputStream fis = new FileInputStream(file);
/* 244 */       InputStreamReader isr = new InputStreamReader(fis, "UTF8");
/* 245 */       Reader in = new BufferedReader(isr);
/*     */       int ch;
/* 247 */       while ((ch = in.read()) > -1) {
/* 248 */         buffer.append((char)ch);
/*     */       }
/* 250 */       in.close();
/* 251 */       return buffer.toString();
/*     */     } catch (IOException e) {
/* 253 */       e.printStackTrace();
/* 254 */     }return null;
/*     */   }
/*     */ 
/*     */   public static String native2Ascii(String str)
/*     */   {
/* 266 */     String output = "";
/*     */ 
/* 268 */     char[] ca = str.toCharArray();
/*     */ 
/* 271 */     for (int x = 0; x < ca.length; x++) {
/* 272 */       char a = ca[x];
/* 273 */       if (a > 'ÿ')
/* 274 */         output = output + "\\u" + Integer.toHexString(a);
/*     */       else {
/* 276 */         output = output + a;
/*     */       }
/*     */     }
/*     */ 
/* 280 */     return output;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.string.StringEncoding
 * JD-Core Version:    0.6.2
 */
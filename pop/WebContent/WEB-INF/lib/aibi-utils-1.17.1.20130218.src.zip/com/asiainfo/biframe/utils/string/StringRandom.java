/*     */ package com.asiainfo.biframe.utils.string;
/*     */ 
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Random;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class StringRandom
/*     */ {
/*  37 */   private Integer length = new Integer(8);
/*     */   private String randomstr;
/*  41 */   private boolean allchars = false;
/*     */   private HashMap hmap;
/*  45 */   private ArrayList lower = null;
/*     */ 
/*  47 */   private ArrayList upper = null;
/*     */ 
/*  49 */   private char[] single = null;
/*     */ 
/*  51 */   private int singlecount = 0;
/*     */ 
/*  53 */   private boolean singles = false;
/*     */ 
/*  55 */   private String algorithm = null;
/*     */ 
/*  57 */   private String provider = null;
/*     */ 
/*  59 */   private boolean secure = false;
/*     */ 
/*  61 */   private Random random = null;
/*     */ 
/*  63 */   private SecureRandom secrandom = null;
/*     */ 
/*     */   private final void generateRandomObject()
/*     */     throws Exception
/*     */   {
/*  73 */     if (this.secure)
/*     */       try
/*     */       {
/*  76 */         if (this.provider != null)
/*     */         {
/*  78 */           this.random = SecureRandom.getInstance(this.algorithm, this.provider);
/*     */         }
/*  80 */         else this.random = SecureRandom.getInstance(this.algorithm); 
/*     */       }
/*  82 */       catch (NoSuchAlgorithmException ne) { throw new Exception(ne.getMessage());
/*     */       } catch (NoSuchProviderException pe) {
/*  84 */         throw new Exception(pe.getMessage());
/*     */       }
/*     */     else
/*  87 */       this.random = new Random();
/*     */   }
/*     */ 
/*     */   private final void generaterandom()
/*     */   {
/*  97 */     if (this.allchars) {
/*  98 */       for (int i = 0; i < this.length.intValue(); i++) {
/*  99 */         this.randomstr += new Character((char)(34 + (int)(getFloat() * 93.0F))).toString();
/*     */       }
/*     */ 
/*     */     }
/* 103 */     else if (this.singles)
/*     */     {
/* 105 */       if (this.upper.size() == 3)
/*     */       {
/* 110 */         for (int i = 0; i < this.length.intValue(); i++)
/*     */         {
/* 117 */           if ((int)(getFloat() * 100.0F) % 2 == 0)
/*     */           {
/* 120 */             if ((int)(getFloat() * 100.0F) % 2 == 0)
/*     */             {
/* 122 */               this.randomstr += randomSingle().toString();
/*     */             }
/*     */             else {
/* 125 */               this.randomstr += randomChar((Character)this.lower.get(2), (Character)this.upper.get(2)).toString();
/*     */             }
/*     */ 
/*     */           }
/* 132 */           else if ((int)(getFloat() * 100.0F) % 2 == 0)
/*     */           {
/* 134 */             this.randomstr += randomChar((Character)this.lower.get(1), (Character)this.upper.get(1)).toString();
/*     */           }
/*     */           else
/*     */           {
/* 140 */             this.randomstr += randomChar((Character)this.lower.get(0), (Character)this.upper.get(0)).toString();
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/* 146 */       else if (this.upper.size() == 2)
/*     */       {
/* 151 */         for (int i = 0; i < this.length.intValue(); i++)
/*     */         {
/* 156 */           if ((int)(getFloat() * 100.0F) % 2 == 0)
/*     */           {
/* 159 */             this.randomstr += randomSingle().toString();
/* 160 */           } else if ((int)(getFloat() * 100.0F) % 2 == 0)
/*     */           {
/* 163 */             this.randomstr += randomChar((Character)this.lower.get(1), (Character)this.upper.get(1)).toString();
/*     */           }
/*     */           else
/*     */           {
/* 169 */             this.randomstr += randomChar((Character)this.lower.get(0), (Character)this.upper.get(0)).toString();
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 174 */       else if (this.upper.size() == 1)
/*     */       {
/* 177 */         for (int i = 0; i < this.length.intValue(); i++) {
/* 178 */           if ((int)getFloat() * 100 % 2 == 0)
/*     */           {
/* 180 */             this.randomstr += randomSingle().toString();
/*     */           }
/*     */           else {
/* 183 */             this.randomstr += randomChar((Character)this.lower.get(0), (Character)this.upper.get(0)).toString();
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 189 */         for (int i = 0; i < this.length.intValue(); i++) {
/* 190 */           this.randomstr += randomSingle().toString();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/* 195 */     else if (this.upper.size() == 3)
/*     */     {
/* 198 */       for (int i = 0; i < this.length.intValue(); i++)
/*     */       {
/* 200 */         if ((int)(getFloat() * 100.0F) % 2 == 0)
/*     */         {
/* 203 */           this.randomstr += randomChar((Character)this.lower.get(2), (Character)this.upper.get(2)).toString();
/*     */         }
/* 206 */         else if ((int)(getFloat() * 100.0F) % 2 == 0)
/*     */         {
/* 209 */           this.randomstr += randomChar((Character)this.lower.get(1), (Character)this.upper.get(1)).toString();
/*     */         }
/*     */         else
/*     */         {
/* 215 */           this.randomstr += randomChar((Character)this.lower.get(0), (Character)this.upper.get(0)).toString();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/* 220 */     else if (this.upper.size() == 2)
/*     */     {
/* 223 */       for (int i = 0; i < this.length.intValue(); i++) {
/* 224 */         if ((int)(getFloat() * 100.0F) % 2 == 0)
/*     */         {
/* 226 */           this.randomstr += randomChar((Character)this.lower.get(1), (Character)this.upper.get(1)).toString();
/*     */         }
/*     */         else
/*     */         {
/* 231 */           this.randomstr += randomChar((Character)this.lower.get(0), (Character)this.upper.get(0)).toString();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 238 */       for (int i = 0; i < this.length.intValue(); i++)
/*     */       {
/* 240 */         this.randomstr += randomChar((Character)this.lower.get(0), (Character)this.upper.get(0)).toString();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final Character randomSingle()
/*     */   {
/* 254 */     return new Character(this.single[((int)(getFloat() * this.singlecount - 1.0F))]);
/*     */   }
/*     */ 
/*     */   private final Character randomChar(Character lower, Character upper)
/*     */   {
/* 270 */     char low = lower.charValue();
/* 271 */     char up = upper.charValue();
/*     */ 
/* 274 */     int tempval = (int)(low + getFloat() * (up - low));
/*     */ 
/* 277 */     return new Character((char)tempval);
/*     */   }
/*     */ 
/*     */   public String getRandom()
/*     */     throws Exception
/*     */   {
/* 288 */     generateRandomObject();
/* 289 */     this.randomstr = "";
/* 290 */     generaterandom();
/* 291 */     if (this.hmap != null) {
/* 292 */       while (this.hmap.containsKey(this.randomstr))
/*     */       {
/* 295 */         generaterandom();
/*     */       }
/* 297 */       this.hmap.put(this.randomstr, null);
/*     */     }
/* 299 */     return this.randomstr;
/*     */   }
/*     */ 
/*     */   public final void setRanges(ArrayList low, ArrayList up)
/*     */   {
/* 313 */     this.lower = low;
/* 314 */     this.upper = up;
/*     */   }
/*     */ 
/*     */   public final void setHmap(HashMap map)
/*     */   {
/* 325 */     this.hmap = map;
/*     */   }
/*     */ 
/*     */   public final void setLength(String value)
/*     */   {
/* 337 */     this.length = new Integer(value);
/*     */   }
/*     */ 
/*     */   public void setLength(int count)
/*     */   {
/* 349 */     this.length = new Integer(count);
/*     */   }
/*     */ 
/*     */   public final void setAlgorithm(String value)
/*     */   {
/* 361 */     this.algorithm = value;
/* 362 */     this.secure = true;
/*     */   }
/*     */ 
/*     */   public final void setProvider(String value)
/*     */   {
/* 373 */     this.provider = value;
/*     */   }
/*     */ 
/*     */   public final void setAllchars(boolean value)
/*     */   {
/* 384 */     this.allchars = value;
/*     */   }
/*     */ 
/*     */   public final void setSingle(char[] chars, int value)
/*     */   {
/* 397 */     this.single = chars;
/* 398 */     this.singlecount = value;
/* 399 */     this.singles = true;
/*     */   }
/*     */ 
/*     */   private final float getFloat()
/*     */   {
/* 410 */     if (this.random == null) {
/* 411 */       return this.secrandom.nextFloat();
/*     */     }
/* 413 */     return this.random.nextFloat();
/*     */   }
/*     */ 
/*     */   public final void setCharset(String value)
/*     */   {
/* 426 */     boolean more = true;
/*     */ 
/* 430 */     this.lower = new ArrayList(3);
/* 431 */     this.upper = new ArrayList(3);
/*     */ 
/* 434 */     if (value.compareToIgnoreCase("all") == 0) {
/* 435 */       this.allchars = true;
/*     */ 
/* 438 */       more = false;
/* 439 */     } else if ((value.charAt(1) == '-') && (value.charAt(0) != '\\'))
/*     */     {
/* 441 */       while ((more) && (value.charAt(1) == '-'))
/*     */       {
/* 443 */         if (value.charAt(0) == '\\')
/*     */         {
/*     */           break;
/*     */         }
/* 447 */         this.lower.add(new Character(value.charAt(0)));
/* 448 */         this.upper.add(new Character(value.charAt(2)));
/*     */ 
/* 452 */         if (value.length() <= 3) {
/* 453 */           more = false;
/*     */         }
/*     */         else
/*     */         {
/* 458 */           value = value.substring(3);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 463 */     if (more) {
/* 464 */       this.single = new char[30];
/*     */ 
/* 466 */       StringTokenizer tokens = new StringTokenizer(value);
/* 467 */       while (tokens.hasMoreTokens())
/*     */       {
/* 469 */         String token = tokens.nextToken();
/* 470 */         if (token.length() > 1)
/*     */         {
/* 472 */           this.single[(this.singlecount++)] = '-';
/*     */         }
/*     */ 
/* 475 */         this.single[(this.singlecount++)] = token.charAt(0);
/*     */       }
/*     */     }
/*     */ 
/* 479 */     if ((this.lower == null) && (this.single == null))
/* 480 */       setCharset("a-zA-Z0-9");
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.string.StringRandom
 * JD-Core Version:    0.6.2
 */
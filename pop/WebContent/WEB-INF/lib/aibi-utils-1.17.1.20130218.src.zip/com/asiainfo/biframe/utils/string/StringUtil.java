/*      */ package com.asiainfo.biframe.utils.string;
/*      */ 
/*      */ import com.asiainfo.biframe.utils.date.DateUtil;
/*      */ import java.io.PrintStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.security.MessageDigest;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.NumberFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ public class StringUtil
/*      */ {
/*      */   private static final String DEFAULT_FILTERED_CHAR = "`~\\:;\"'<,>./";
/*   39 */   private static final String[] DEFAULT_INVALID_STR = { "script", "and ", "or ", "union ", "between ", "\"", "\\", "\\t", "insert|values", "select|from", "update|set", "delete|from", "drop", "where", "alter" };
/*      */ 
/*      */   public static boolean isEmpty(Object str)
/*      */   {
/*   52 */     return (str == null) || (String.valueOf(str).trim().length() < 1);
/*      */   }
/*      */ 
/*      */   public static boolean isNotEmpty(Object str)
/*      */   {
/*   63 */     return !isEmpty(str);
/*      */   }
/*      */ 
/*      */   public static boolean isEmpty(String str)
/*      */   {
/*   74 */     return (str == null) || (str.trim().length() < 1);
/*      */   }
/*      */ 
/*      */   public static boolean isNotEmpty(String str)
/*      */   {
/*   85 */     return !isEmpty(str);
/*      */   }
/*      */ 
/*      */   public static String obj2Str(Object obj)
/*      */   {
/*   96 */     return obj == null ? "" : obj.toString().trim();
/*      */   }
/*      */ 
/*      */   public static String obj2Str(Object obj, String defaultValue)
/*      */   {
/*  108 */     return obj == null ? defaultValue : obj.toString().trim();
/*      */   }
/*      */ 
/*      */   public static Integer string2Integer(String str)
/*      */   {
/*  119 */     if (isNotEmpty(str)) {
/*      */       try {
/*  121 */         return new Integer(str.trim());
/*      */       } catch (NumberFormatException e) {
/*  123 */         e.printStackTrace();
/*      */       }
/*      */     }
/*  126 */     return null;
/*      */   }
/*      */ 
/*      */   public static Integer string2Integer(String str, Integer defaultValue)
/*      */   {
/*  137 */     if (isNotEmpty(str)) {
/*      */       try {
/*  139 */         return new Integer(str.trim());
/*      */       } catch (NumberFormatException e) {
/*  141 */         e.printStackTrace();
/*  142 */         return defaultValue;
/*      */       }
/*      */     }
/*  145 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public static Long string2Long(String str)
/*      */   {
/*  156 */     if (isNotEmpty(str)) {
/*      */       try {
/*  158 */         return new Long(str.trim());
/*      */       } catch (NumberFormatException e) {
/*  160 */         e.printStackTrace();
/*      */       }
/*      */     }
/*  163 */     return null;
/*      */   }
/*      */ 
/*      */   public static Long string2Long(String str, Long defaultValue)
/*      */   {
/*  175 */     if (isNotEmpty(str)) {
/*      */       try {
/*  177 */         return new Long(str.trim());
/*      */       } catch (NumberFormatException e) {
/*  179 */         e.printStackTrace();
/*  180 */         return defaultValue;
/*      */       }
/*      */     }
/*  183 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public static Double stringToDouble(String str)
/*      */   {
/*  194 */     if (isNotEmpty(str)) {
/*      */       try {
/*  196 */         return new Double(str.trim());
/*      */       } catch (NumberFormatException e) {
/*  198 */         e.printStackTrace();
/*      */       }
/*      */     }
/*  201 */     return null;
/*      */   }
/*      */ 
/*      */   public static Double stringToDouble(String str, Double defaultValue)
/*      */   {
/*  213 */     if (isNotEmpty(str)) {
/*      */       try {
/*  215 */         return new Double(str.trim());
/*      */       } catch (NumberFormatException e) {
/*  217 */         e.printStackTrace();
/*  218 */         return defaultValue;
/*      */       }
/*      */     }
/*  221 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public static BigDecimal string2BigDecimal(String str)
/*      */   {
/*  232 */     if (isNotEmpty(str)) {
/*      */       try {
/*  234 */         return new BigDecimal(str);
/*      */       } catch (NumberFormatException e) {
/*  236 */         e.printStackTrace();
/*      */       }
/*      */     }
/*  239 */     return null;
/*      */   }
/*      */ 
/*      */   public static BigDecimal string2BigDecimal(String str, BigDecimal defaultValue)
/*      */   {
/*  251 */     if (isNotEmpty(str)) {
/*      */       try {
/*  253 */         return new BigDecimal(str);
/*      */       } catch (NumberFormatException e) {
/*  255 */         e.printStackTrace();
/*  256 */         return defaultValue;
/*      */       }
/*      */     }
/*  259 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public static boolean isDecimal(String str)
/*      */   {
/*  270 */     boolean res = true;
/*  271 */     if (isEmpty(str))
/*  272 */       return false;
/*      */     try
/*      */     {
/*  275 */       new BigDecimal(str);
/*      */     } catch (NumberFormatException e) {
/*  277 */       res = false;
/*      */     }
/*  279 */     return res;
/*      */   }
/*      */ 
/*      */   public static String numberFormat(String value)
/*      */   {
/*  291 */     if (!isEmpty(value)) {
/*  292 */       NumberFormat format = NumberFormat.getInstance();
/*  293 */       return format.format(Double.parseDouble(value));
/*      */     }
/*  295 */     return null;
/*      */   }
/*      */ 
/*      */   public static boolean isChinese(char c)
/*      */   {
/*  310 */     Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
/*  311 */     if ((ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS) || (ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS) || (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A) || (ub == Character.UnicodeBlock.GENERAL_PUNCTUATION) || (ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION) || (ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS))
/*      */     {
/*  317 */       return true;
/*      */     }
/*  319 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isChinese(String str)
/*      */   {
/*  330 */     if (isEmpty(str)) {
/*  331 */       return false;
/*      */     }
/*  333 */     char[] ch = str.toCharArray();
/*  334 */     for (int i = 0; i < ch.length; i++) {
/*  335 */       char c = ch[i];
/*  336 */       if (isChinese(c) == true) {
/*  337 */         return true;
/*      */       }
/*      */     }
/*  340 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean stringEquals(String str1, String str2)
/*      */   {
/*  352 */     if ((isEmpty(str1)) && (isEmpty(str2))) {
/*  353 */       return true;
/*      */     }
/*      */ 
/*  356 */     if (isNotEmpty(str1)) {
/*  357 */       return str1.equals(str2);
/*      */     }
/*      */ 
/*  360 */     return false;
/*      */   }
/*      */ 
/*      */   public static String array2Str(Object[] strArray)
/*      */   {
/*  371 */     String str = "";
/*  372 */     for (int i = 0; i < strArray.length; i++) {
/*  373 */       str = str + strArray[i].toString() + ",";
/*      */     }
/*  375 */     if (str.length() > 0)
/*  376 */       str = str.substring(0, str.length() - 1);
/*  377 */     return str;
/*      */   }
/*      */ 
/*      */   public static String[] str2Array(String str)
/*      */   {
/*  387 */     Vector vect = getVector(str, ",");
/*  388 */     int num = vect.size();
/*  389 */     String[] strArray = new String[num];
/*  390 */     for (int i = 0; i < num; i++)
/*      */     {
/*  392 */       strArray[i] = ((String)vect.elementAt(i));
/*      */     }
/*  394 */     return strArray;
/*      */   }
/*      */ 
/*      */   public static Set commaString2Set(String commaString, String split)
/*      */   {
/*  404 */     Set s = new HashSet();
/*  405 */     if (isNotEmpty(commaString)) {
/*  406 */       String[] arr = commaString.split(split);
/*  407 */       for (int i = 0; i < arr.length; i++) {
/*  408 */         s.add(arr[i].trim());
/*      */       }
/*      */     }
/*  411 */     return s;
/*      */   }
/*      */ 
/*      */   public static Set commaString2Set(String commaString)
/*      */   {
/*  420 */     return commaString2Set(commaString, ",");
/*      */   }
/*      */ 
/*      */   public static List<String> string2List(String str, String splitStr, boolean removeComma)
/*      */   {
/*  433 */     List list = new ArrayList();
/*  434 */     int pos = str.indexOf(splitStr);
/*  435 */     boolean hasSplit = false;
/*  436 */     if (pos >= 0) {
/*  437 */       hasSplit = true;
/*      */     }
/*  439 */     while (pos >= 0) {
/*  440 */       String obj = str.substring(0, pos);
/*  441 */       if (removeComma) {
/*  442 */         obj = obj.substring(1, obj.length() - 1);
/*      */       }
/*  444 */       list.add(obj);
/*  445 */       str = str.substring(pos + 1, str.length());
/*  446 */       pos = str.indexOf(splitStr);
/*      */     }
/*  448 */     if (hasSplit) {
/*  449 */       if (removeComma) {
/*  450 */         str = str.substring(1, str.length() - 1);
/*      */       }
/*  452 */       list.add(str);
/*      */     }
/*  454 */     return list;
/*      */   }
/*      */ 
/*      */   public static boolean contains(String str, String target, int pos, char begin, char end)
/*      */     throws Exception
/*      */   {
/*  474 */     int b = str.indexOf(begin);
/*  475 */     int e = str.indexOf(end);
/*  476 */     if ((b < 0) || (e < 0)) {
/*  477 */       return false;
/*      */     }
/*      */ 
/*  480 */     int len = target.length();
/*  481 */     System.out.println(str.length() + ":" + pos + ":" + len);
/*  482 */     String s = str.substring(pos, pos + len);
/*  483 */     if (!s.equalsIgnoreCase(target)) {
/*  484 */       throw new Exception("string['" + target + "]location:[" + pos + "]Unspecified error");
/*      */     }
/*      */ 
/*  487 */     String frontStr = str.substring(0, pos);
/*  488 */     String backStr = str.substring(pos + len + 1);
/*      */ 
/*  491 */     int endCount = 0;
/*  492 */     int beginCount = 0;
/*      */ 
/*  494 */     boolean existBegin = false;
/*  495 */     for (int i = 0; i < frontStr.length(); i++) {
/*  496 */       char c = frontStr.charAt(i);
/*  497 */       if (c == begin) {
/*  498 */         beginCount++;
/*      */       }
/*  500 */       if (c == end) {
/*  501 */         endCount++;
/*      */       }
/*      */     }
/*  504 */     if (beginCount - endCount > 0) {
/*  505 */       existBegin = true;
/*      */     }
/*      */ 
/*  508 */     endCount = 0;
/*  509 */     beginCount = 0;
/*      */ 
/*  511 */     boolean existEnd = false;
/*  512 */     for (int i = 0; i < backStr.length(); i++) {
/*  513 */       char c = backStr.charAt(i);
/*  514 */       if (c == begin) {
/*  515 */         beginCount++;
/*      */       }
/*  517 */       if (c == end) {
/*  518 */         endCount++;
/*      */       }
/*      */     }
/*  521 */     if (endCount - beginCount > 0) {
/*  522 */       existEnd = true;
/*      */     }
/*  524 */     return (existBegin) && (existEnd);
/*      */   }
/*      */ 
/*      */   public static int getPosNotIn(String str, String target, char begin, char end)
/*      */     throws Exception
/*      */   {
/*  539 */     String opStr = str;
/*  540 */     int pos = 0;
/*  541 */     int modify = 0;
/*  542 */     boolean inIf = false;
/*  543 */     while (opStr.toLowerCase().indexOf(target.toLowerCase()) >= 0) {
/*  544 */       System.out.println("opStr=[" + opStr + "]");
/*  545 */       pos = opStr.toLowerCase().indexOf(target.toLowerCase());
/*  546 */       if (!contains(str, target, pos + modify, begin, end)) {
/*  547 */         inIf = true;
/*  548 */         break;
/*      */       }
/*  550 */       opStr = opStr.substring(pos + target.length());
/*  551 */       modify += pos + target.length();
/*  552 */       System.out.println("modify=" + modify);
/*      */     }
/*      */ 
/*  555 */     if (!inIf) {
/*  556 */       return -1;
/*      */     }
/*  558 */     pos = modify + pos;
/*  559 */     System.out.println(str.substring(pos, pos + target.length()) + " found,pos=[" + pos + "],modify=[" + modify + "]");
/*      */ 
/*  561 */     return pos;
/*      */   }
/*      */ 
/*      */   public static String replaceAllBlank(String s)
/*      */   {
/*  574 */     if (isEmpty(s)) {
/*  575 */       return "";
/*      */     }
/*  577 */     return s.replaceAll("\\s", "");
/*      */   }
/*      */ 
/*      */   public static String replaceAll(String source, String oldString, String newString)
/*      */   {
/*  588 */     if ((source == null) || (source.equals(""))) {
/*  589 */       return "";
/*      */     }
/*  591 */     StringBuffer output = new StringBuffer();
/*      */ 
/*  593 */     int lengthOfSource = source.length();
/*  594 */     int lengthOfOld = oldString.length();
/*      */ 
/*  596 */     int posStart = 0;
/*      */     int pos;
/*  599 */     while ((pos = source.indexOf(oldString, posStart)) >= 0) {
/*  600 */       output.append(source.substring(posStart, pos));
/*      */ 
/*  602 */       output.append(newString);
/*  603 */       posStart = pos + lengthOfOld;
/*      */     }
/*      */ 
/*  606 */     if (posStart < lengthOfSource) {
/*  607 */       output.append(source.substring(posStart));
/*      */     }
/*      */ 
/*  610 */     return output.toString();
/*      */   }
/*      */ 
/*      */   public static String arr2CommaString(String[] s)
/*      */   {
/*  621 */     if ((s == null) || (s.length < 1)) {
/*  622 */       return "";
/*      */     }
/*  624 */     String result = s[0];
/*  625 */     if (s.length > 1) {
/*  626 */       for (int i = 1; i < s.length; i++) {
/*  627 */         result = result + "," + s[i];
/*      */       }
/*      */     }
/*  630 */     return result;
/*      */   }
/*      */ 
/*      */   public static String list2StringWithSplit(List list, String splitStr)
/*      */   {
/*  643 */     if ((list == null) || (list.size() < 1)) {
/*  644 */       return null;
/*      */     }
/*  646 */     StringBuffer buf = new StringBuffer();
/*  647 */     Iterator iter = list.iterator();
/*  648 */     while (iter.hasNext()) {
/*  649 */       buf.append(splitStr);
/*  650 */       buf.append((String)iter.next());
/*      */     }
/*  652 */     return buf.toString().substring(1);
/*      */   }
/*      */ 
/*      */   public static String list2StringWithComma(Collection list, String splitStr)
/*      */   {
/*  664 */     if ((list == null) || (list.size() < 1)) {
/*  665 */       return null;
/*      */     }
/*  667 */     StringBuffer buf = new StringBuffer();
/*  668 */     Iterator iter = list.iterator();
/*  669 */     while (iter.hasNext()) {
/*  670 */       buf.append(splitStr);
/*  671 */       buf.append("'");
/*  672 */       buf.append((String)iter.next());
/*  673 */       buf.append("'");
/*      */     }
/*      */ 
/*  676 */     return buf.toString().substring(1);
/*      */   }
/*      */ 
/*      */   public static String filterStr(String src, String filterChar)
/*      */   {
/*  687 */     if (isEmpty(src))
/*  688 */       return "";
/*  689 */     src = src.trim();
/*  690 */     if ((filterChar == null) || (filterChar.length() < 0)) {
/*  691 */       filterChar = "`~\\:;\"'<,>./";
/*      */     }
/*  693 */     int len = filterChar.length();
/*  694 */     for (int i = 0; i < len; i++) {
/*  695 */       src = src.replaceAll("\\" + String.valueOf(filterChar.charAt(i)), "");
/*      */     }
/*  697 */     return src;
/*      */   }
/*      */ 
/*      */   public static boolean isContainInvalidStr(String src, String invalidStr)
/*      */   {
/*  708 */     boolean res = false;
/*  709 */     if (isEmpty(src)) {
/*  710 */       return res;
/*      */     }
/*      */ 
/*  713 */     if ((invalidStr != null) && (invalidStr.length() > 0)) {
/*  714 */       res = src.indexOf(invalidStr) >= 0;
/*      */     }
/*      */     else
/*      */     {
/*  718 */       int len = DEFAULT_INVALID_STR.length;
/*  719 */       src = src.toLowerCase();
/*      */ 
/*  723 */       for (int i = 0; i < len; i++) {
/*  724 */         String tmpInvalidStr = DEFAULT_INVALID_STR[i];
/*      */ 
/*  727 */         if (tmpInvalidStr.indexOf("|") >= 0) {
/*  728 */           boolean tmpBol = false;
/*  729 */           String[] tmpArr = tmpInvalidStr.split("[|]");
/*  730 */           for (int j = 0; j < tmpArr.length; j++)
/*      */           {
/*  733 */             if (src.indexOf(tmpArr[j]) >= 0) {
/*  734 */               System.out.println("invalid str [" + tmpArr[j] + "] exist,");
/*      */ 
/*  736 */               tmpBol = true;
/*      */             }
/*      */             else
/*      */             {
/*  740 */               tmpBol = false;
/*  741 */               break;
/*      */             }
/*      */           }
/*  744 */           if (tmpBol) {
/*  745 */             res = true;
/*  746 */             break;
/*      */           }
/*      */ 
/*      */         }
/*  751 */         else if (src.indexOf(tmpInvalidStr) >= 0) {
/*  752 */           System.out.println("invalid str [" + tmpInvalidStr + "] exist, quit");
/*      */ 
/*  754 */           res = true;
/*  755 */           break;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  761 */     return res;
/*      */   }
/*      */ 
/*      */   public static String convertComma2Db(String str)
/*      */   {
/*  772 */     int pos = str.indexOf("'");
/*  773 */     int pos1 = 0;
/*  774 */     while (pos != -1) {
/*  775 */       str = str.substring(0, pos1 + pos) + "'" + str.substring(pos + pos1, str.length());
/*      */ 
/*  777 */       pos1 = pos1 + pos + 2;
/*  778 */       pos = str.substring(pos1, str.length()).indexOf("'");
/*      */     }
/*  780 */     return str;
/*      */   }
/*      */ 
/*      */   public static String addInvertedComma(String source)
/*      */   {
/*  791 */     if (isEmpty(source))
/*  792 */       return null;
/*  793 */     source = "'" + source.trim();
/*  794 */     int pos = source.indexOf(",");
/*  795 */     int len = source.length();
/*  796 */     while (pos != -1) {
/*  797 */       source = source.substring(0, pos) + "','" + source.substring(pos + 1, len);
/*      */ 
/*  799 */       len += 2;
/*  800 */       pos += 2;
/*  801 */       if (source.substring(pos).indexOf(",") == -1) break;
/*  802 */       pos = source.substring(pos).indexOf(",") + pos;
/*      */     }
/*      */ 
/*  806 */     source = source + "'";
/*  807 */     return source;
/*      */   }
/*      */ 
/*      */   public static Vector<Vector<String>> getVectorBySegment(String str, String beginStr, String endStr, String splitStr)
/*      */   {
/*  828 */     Vector vect = new Vector();
/*  829 */     String strTemp = "";
/*  830 */     int bpos = str.indexOf(beginStr);
/*  831 */     int epos = str.indexOf(endStr);
/*  832 */     while ((bpos >= 0) && (epos > 0)) {
/*  833 */       strTemp = str.substring(bpos + 1, epos);
/*  834 */       Vector subvect = getVector(strTemp, splitStr);
/*  835 */       vect.addElement(subvect);
/*  836 */       str = str.substring(epos + 1, str.length());
/*  837 */       bpos = str.indexOf(beginStr);
/*  838 */       epos = str.indexOf(endStr);
/*      */     }
/*  840 */     return vect;
/*      */   }
/*      */ 
/*      */   public static Vector<String> getVector(String str, String splitStr)
/*      */   {
/*  853 */     Vector vect = new Vector();
/*  854 */     int pos = str.indexOf(splitStr);
/*  855 */     int len = splitStr.length();
/*  856 */     while (pos >= 0) {
/*  857 */       vect.addElement(str.substring(0, pos));
/*  858 */       str = str.substring(pos + len, str.length());
/*  859 */       pos = str.indexOf(splitStr);
/*      */     }
/*  861 */     vect.addElement(str.substring(0, str.length()));
/*  862 */     return vect;
/*      */   }
/*      */ 
/*      */   public static String addChar4Len(String str, String strspace, int strlen)
/*      */   {
/*  963 */     if ((str == null) || (str.length() < 1) || (strspace == null) || (strspace.length() < 1))
/*  964 */       return str;
/*  965 */     while (str.length() < strlen) {
/*  966 */       if (str.length() + strspace.length() > strlen) {
/*  967 */         return str;
/*      */       }
/*  969 */       str = strspace + str;
/*      */     }
/*  971 */     return str;
/*      */   }
/*      */ 
/*      */   public static String list2String(Collection collection, String separator, boolean addComma)
/*      */   {
/*  985 */     String str = "";
/*  986 */     if ((null == collection) || (collection.size() < 1)) {
/*  987 */       return str;
/*      */     }
/*  989 */     if ((null == separator) || (separator.length() < 1)) {
/*  990 */       separator = ",";
/*      */     }
/*  992 */     Iterator it = collection.iterator();
/*  993 */     while (it.hasNext()) {
/*  994 */       str = str + (addComma ? "'" : "") + obj2Str(it.next(), "") + (addComma ? "'" : "") + separator;
/*      */     }
/*      */ 
/*  997 */     if (str.length() > 0) {
/*  998 */       str = str.substring(0, str.length() - 1);
/*      */     }
/* 1000 */     return str;
/*      */   }
/*      */ 
/*      */   public static List<Object> getDistinctList(List[] lists)
/*      */   {
/* 1011 */     List retList = new ArrayList();
/* 1012 */     Map map = new HashMap();
/* 1013 */     for (int i = 0; i < lists.length; i++) {
/* 1014 */       List list = lists[i];
/* 1015 */       if (list != null)
/*      */       {
/* 1018 */         for (int j = 0; j < list.size(); j++) {
/* 1019 */           if (list.get(j) != null)
/* 1020 */             map.put(list.get(j), list.get(j));
/*      */         }
/*      */       }
/*      */     }
/* 1024 */     Iterator it = map.keySet().iterator();
/* 1025 */     while (it.hasNext()) {
/* 1026 */       retList.add(it.next());
/*      */     }
/* 1028 */     return retList;
/*      */   }
/*      */ 
/*      */   public static String getGender(String iDCard)
/*      */   {
/* 1048 */     int gender = 3;
/* 1049 */     if (iDCard.length() == 15) {
/* 1050 */       gender = new Integer(iDCard.substring(14, 15)).intValue() % 2;
/* 1051 */     } else if (iDCard.length() == 18) {
/* 1052 */       int number17 = new Integer(iDCard.substring(16, 17)).intValue();
/* 1053 */       gender = number17 % 2;
/*      */     }
/* 1055 */     if (gender == 1)
/* 1056 */       return "1";
/* 1057 */     if (gender == 0) {
/* 1058 */       return "2";
/*      */     }
/* 1060 */     return "";
/*      */   }
/*      */ 
/*      */   public static boolean checkEmail(String emailStr)
/*      */   {
/* 1072 */     if (isEmpty(emailStr)) {
/* 1073 */       return false;
/*      */     }
/* 1075 */     return emailStr.matches("[-_.a-zA-Z0-9]+@[-_a-zA-Z0-9]+.[a-zA-Z]+");
/*      */   }
/*      */ 
/*      */   public static boolean checkStr(String v)
/*      */   {
/* 1086 */     if (isEmpty(v)) {
/* 1087 */       return false;
/*      */     }
/* 1089 */     return v.matches("[a-zA-Z0-9_]*");
/*      */   }
/*      */ 
/*      */   public static String encryptMD5(String value)
/*      */     throws Exception
/*      */   {
/* 1101 */     String result = "";
/* 1102 */     if (isEmpty(value))
/* 1103 */       return "";
/*      */     try
/*      */     {
/* 1106 */       MessageDigest messageDigest = MessageDigest.getInstance("MD5");
/* 1107 */       messageDigest.update(value.getBytes());
/* 1108 */       result = byte2hex(messageDigest.digest());
/*      */     } catch (Exception e) {
/* 1110 */       e.printStackTrace();
/* 1111 */       throw new Exception(e.getMessage());
/*      */     }
/* 1113 */     return result;
/*      */   }
/*      */ 
/*      */   private static String byte2hex(byte[] bytes) {
/* 1117 */     String result = "";
/* 1118 */     String stmp = "";
/* 1119 */     for (int n = 0; n < bytes.length; n++) {
/* 1120 */       stmp = Integer.toHexString(bytes[n] & 0xFF);
/* 1121 */       if (stmp.length() == 1)
/* 1122 */         result = result + "0" + stmp;
/*      */       else {
/* 1124 */         result = result + stmp;
/*      */       }
/*      */     }
/* 1127 */     return result.toUpperCase();
/*      */   }
/*      */ 
/*      */   public static String formatString(String value, String mask)
/*      */   {
/* 1138 */     String result = value;
/*      */     try {
/* 1140 */       if ((StringUtils.hasText(value)) && (StringUtils.hasText(mask)))
/* 1141 */         if ((mask.indexOf("yyyy") >= 0) || (mask.indexOf("MM") >= 0) || (mask.indexOf("dd") >= 0) || (mask.indexOf("HH") >= 0) || (mask.indexOf("mm") >= 0))
/*      */         {
/* 1143 */           Date date = DateUtil.string2Date(value, mask);
/* 1144 */           result = DateUtil.date2String(date, mask);
/* 1145 */         } else if ((mask.indexOf('.') > 0) || (mask.indexOf('#') >= 0) || (mask.indexOf('0') >= 0)) {
/* 1146 */           Double d = Double.valueOf(value);
/* 1147 */           DecimalFormat df = new DecimalFormat(mask);
/* 1148 */           result = df.format(d);
/*      */         }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1153 */       e.printStackTrace();
/*      */     }
/* 1155 */     return result;
/*      */   }
/*      */ 
/*      */   public static String format4InvertedComma(String sourceString) {
/* 1159 */     return sourceString.replaceAll("'", "''");
/*      */   }
/*      */ 
/*      */   public static void main(String[] args) {
/* 1163 */     String testStr = "aa;bb;cc|dd;ee;ff";
/* 1164 */     Vector v = getVector(testStr, "|");
/* 1165 */     for (int i = 0; i < v.size(); i++) {
/* 1166 */       System.out.println(v.get(i));
/*      */     }
/*      */ 
/* 1169 */     String strPath = "file:/crmtest/product/suite400/webapp/WEB-INF/lib/aibi-waterMark-1.2.0-SNAPSHOT.jar!/META-INF/MANIFEST.MF";
/* 1170 */     strPath = strPath.substring(5, strPath.indexOf("!"));
/* 1171 */     System.out.println(strPath);
/* 1172 */     strPath = strPath.substring(0, strPath.lastIndexOf("/") + 1);
/* 1173 */     System.out.println(strPath);
/*      */   }
/*      */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.string.StringUtil
 * JD-Core Version:    0.6.2
 */
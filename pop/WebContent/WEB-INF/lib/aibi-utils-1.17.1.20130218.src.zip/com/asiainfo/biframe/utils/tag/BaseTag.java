/*     */ package com.asiainfo.biframe.utils.tag;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class BaseTag extends BodyTagSupport
/*     */ {
/*  24 */   protected static Logger log = Logger.getLogger(BaseTag.class);
/*     */   private static final long serialVersionUID = 1L;
/*  26 */   public final String defaultLabelWidth = "60";
/*  27 */   public final String defaultWidth = "200";
/*  28 */   public final String defaultDropHeight = "280";
/*  29 */   public final String defaultFormat = "Y-m-d";
/*     */   private String dataUrl;
/*     */   private String compId;
/*  32 */   private String childItems = "";
/*  33 */   private String EXT_JS_KEY = "EXTJS";
/*     */ 
/*  35 */   private String JQTable_JS_KEY = "JQTableJS";
/*     */ 
/*  37 */   private Map<String, String> dicParameter = new LinkedHashMap();
/*  38 */   private Map<String, String> dicJndi = new LinkedHashMap();
/*     */   protected String id;
/*  49 */   protected String accesskey = null;
/*     */ 
/*  54 */   protected String tabindex = null;
/*     */ 
/*  61 */   protected boolean indexed = false;
/*     */ 
/*  68 */   private String onclick = null;
/*     */ 
/*  73 */   private String onrightclick = null;
/*     */ 
/*  78 */   private String ondblclick = null;
/*     */ 
/*  83 */   private String onmouseover = null;
/*     */ 
/*  88 */   private String onmouseout = null;
/*     */ 
/*  93 */   private String onmousemove = null;
/*     */ 
/*  98 */   private String onmousedown = null;
/*     */ 
/* 103 */   private String onmouseup = null;
/*     */ 
/* 110 */   private String onkeydown = null;
/*     */ 
/* 115 */   private String onkeyup = null;
/*     */ 
/* 120 */   private String onkeypress = null;
/*     */ 
/* 127 */   private String onselect = null;
/*     */ 
/* 132 */   private String onchange = null;
/*     */ 
/* 139 */   private String onblur = null;
/*     */ 
/* 144 */   private String onfocus = null;
/*     */ 
/* 149 */   private boolean disabled = false;
/*     */ 
/* 154 */   protected boolean doDisabled = true;
/*     */ 
/* 159 */   private boolean readonly = false;
/*     */ 
/* 164 */   protected boolean doReadonly = false;
/*     */ 
/* 171 */   private String style = null;
/*     */ 
/* 176 */   private String styleClass = null;
/*     */ 
/* 181 */   private String styleId = null;
/*     */ 
/* 188 */   private String alt = null;
/*     */ 
/* 193 */   private String altKey = null;
/*     */ 
/* 198 */   private String bundle = null;
/*     */ 
/* 203 */   private String title = null;
/*     */ 
/* 208 */   private String lang = null;
/*     */ 
/* 213 */   private String dir = null;
/*     */ 
/* 218 */   private String titleKey = null;
/*     */ 
/*     */   public Map<String, String> getDicParameter() {
/* 221 */     return this.dicParameter;
/*     */   }
/*     */ 
/*     */   public void setDicParameter(Map dicParameter) {
/* 225 */     this.dicParameter = dicParameter;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getDicJndi() {
/* 229 */     return this.dicJndi;
/*     */   }
/*     */ 
/*     */   public void setDicJndi(Map<String, String> dicJndi) {
/* 233 */     this.dicJndi = dicJndi;
/*     */   }
/*     */ 
/*     */   public String getChildItems() {
/* 237 */     return this.childItems;
/*     */   }
/*     */ 
/*     */   public void setChildItems(String childItems) {
/* 241 */     this.childItems = childItems;
/*     */   }
/*     */ 
/*     */   public void appendChildItems(String str) {
/* 245 */     this.childItems += str;
/*     */   }
/*     */ 
/*     */   public void appendPageScript(StringBuffer sub)
/*     */   {
/* 255 */     StringBuffer sb = getPageScript();
/* 256 */     sb.append(sub);
/*     */   }
/*     */ 
/*     */   public void appendPageScript(String sub)
/*     */   {
/* 266 */     StringBuffer sb = getPageScript();
/* 267 */     sb.append(sub);
/*     */   }
/*     */ 
/*     */   public StringBuffer getPageScript()
/*     */   {
/* 274 */     StringBuffer sb = (StringBuffer)this.pageContext.getAttribute(this.EXT_JS_KEY);
/*     */ 
/* 276 */     if (sb == null) {
/* 277 */       sb = new StringBuffer();
/* 278 */       this.pageContext.setAttribute(this.EXT_JS_KEY, sb);
/*     */     }
/* 280 */     return sb;
/*     */   }
/*     */ 
/*     */   public void releasePageScript()
/*     */   {
/* 287 */     if (this.pageContext.getAttribute(this.EXT_JS_KEY) != null)
/* 288 */       this.pageContext.removeAttribute(this.EXT_JS_KEY);
/*     */   }
/*     */ 
/*     */   public void appendJQTableScript(String sub)
/*     */   {
/* 296 */     StringBuffer sb = getJQTableScript();
/* 297 */     sb.append(sub);
/*     */   }
/*     */ 
/*     */   public StringBuffer getJQTableScript()
/*     */   {
/* 304 */     StringBuffer sb = (StringBuffer)this.pageContext.getAttribute(this.JQTable_JS_KEY);
/* 305 */     if (sb == null) {
/* 306 */       sb = new StringBuffer();
/* 307 */       this.pageContext.setAttribute(this.JQTable_JS_KEY, sb);
/*     */     }
/* 309 */     return sb;
/*     */   }
/*     */ 
/*     */   public void releaseJQTableScript()
/*     */   {
/* 316 */     if (this.pageContext.getAttribute(this.JQTable_JS_KEY) != null)
/* 317 */       this.pageContext.removeAttribute(this.JQTable_JS_KEY);
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/* 329 */     return 1;
/*     */   }
/*     */ 
/*     */   public void doInitBody()
/*     */     throws JspException
/*     */   {
/*     */   }
/*     */ 
/*     */   public int doAfterBody()
/*     */     throws JspException
/*     */   {
/* 349 */     return 0;
/*     */   }
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/* 358 */     log.debug("do end Tag...");
/*     */ 
/* 360 */     return 6;
/*     */   }
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 365 */     HttpServletRequest request = (HttpServletRequest)this.pageContext.getRequest();
/* 366 */     return request.getContextPath();
/*     */   }
/*     */ 
/*     */   public String getId()
/*     */   {
/* 376 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String id)
/*     */   {
/* 381 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public void setAccesskey(String accessKey)
/*     */   {
/* 388 */     this.accesskey = accessKey;
/*     */   }
/*     */ 
/*     */   public String getAccesskey()
/*     */   {
/* 395 */     return this.accesskey;
/*     */   }
/*     */ 
/*     */   public void setTabindex(String tabIndex)
/*     */   {
/* 402 */     this.tabindex = tabIndex;
/*     */   }
/*     */ 
/*     */   public String getTabindex()
/*     */   {
/* 409 */     return this.tabindex;
/*     */   }
/*     */ 
/*     */   public void setIndexed(boolean indexed)
/*     */   {
/* 419 */     this.indexed = indexed;
/*     */   }
/*     */ 
/*     */   public boolean getIndexed()
/*     */   {
/* 427 */     return this.indexed;
/*     */   }
/*     */ 
/*     */   public void setOnclick(String onClick)
/*     */   {
/* 436 */     this.onclick = onClick;
/*     */   }
/*     */ 
/*     */   public String getOnclick()
/*     */   {
/* 443 */     return this.onclick;
/*     */   }
/*     */ 
/*     */   public void setOndblclick(String onDblClick)
/*     */   {
/* 450 */     this.ondblclick = onDblClick;
/*     */   }
/*     */ 
/*     */   public String getOndblclick()
/*     */   {
/* 457 */     return this.ondblclick;
/*     */   }
/*     */ 
/*     */   public void setOnrightclick(String onrightclick)
/*     */   {
/* 464 */     this.onrightclick = onrightclick;
/*     */   }
/*     */ 
/*     */   public String getOnrightclick()
/*     */   {
/* 471 */     return this.onrightclick;
/*     */   }
/*     */ 
/*     */   public void setOnmousedown(String onMouseDown)
/*     */   {
/* 478 */     this.onmousedown = onMouseDown;
/*     */   }
/*     */ 
/*     */   public String getOnmousedown()
/*     */   {
/* 485 */     return this.onmousedown;
/*     */   }
/*     */ 
/*     */   public void setOnmouseup(String onMouseUp)
/*     */   {
/* 492 */     this.onmouseup = onMouseUp;
/*     */   }
/*     */ 
/*     */   public String getOnmouseup()
/*     */   {
/* 499 */     return this.onmouseup;
/*     */   }
/*     */ 
/*     */   public void setOnmousemove(String onMouseMove)
/*     */   {
/* 506 */     this.onmousemove = onMouseMove;
/*     */   }
/*     */ 
/*     */   public String getOnmousemove()
/*     */   {
/* 513 */     return this.onmousemove;
/*     */   }
/*     */ 
/*     */   public void setOnmouseover(String onMouseOver)
/*     */   {
/* 520 */     this.onmouseover = onMouseOver;
/*     */   }
/*     */ 
/*     */   public String getOnmouseover()
/*     */   {
/* 527 */     return this.onmouseover;
/*     */   }
/*     */ 
/*     */   public void setOnmouseout(String onMouseOut)
/*     */   {
/* 534 */     this.onmouseout = onMouseOut;
/*     */   }
/*     */ 
/*     */   public String getOnmouseout()
/*     */   {
/* 541 */     return this.onmouseout;
/*     */   }
/*     */ 
/*     */   public void setOnkeydown(String onKeyDown)
/*     */   {
/* 550 */     this.onkeydown = onKeyDown;
/*     */   }
/*     */ 
/*     */   public String getOnkeydown()
/*     */   {
/* 557 */     return this.onkeydown;
/*     */   }
/*     */ 
/*     */   public void setOnkeyup(String onKeyUp)
/*     */   {
/* 564 */     this.onkeyup = onKeyUp;
/*     */   }
/*     */ 
/*     */   public String getOnkeyup()
/*     */   {
/* 571 */     return this.onkeyup;
/*     */   }
/*     */ 
/*     */   public void setOnkeypress(String onKeyPress)
/*     */   {
/* 578 */     this.onkeypress = onKeyPress;
/*     */   }
/*     */ 
/*     */   public String getOnkeypress()
/*     */   {
/* 585 */     return this.onkeypress;
/*     */   }
/*     */ 
/*     */   public void setOnchange(String onChange)
/*     */   {
/* 594 */     this.onchange = onChange;
/*     */   }
/*     */ 
/*     */   public String getOnchange()
/*     */   {
/* 601 */     return this.onchange;
/*     */   }
/*     */ 
/*     */   public void setOnselect(String onSelect)
/*     */   {
/* 608 */     this.onselect = onSelect;
/*     */   }
/*     */ 
/*     */   public String getOnselect()
/*     */   {
/* 615 */     return this.onselect;
/*     */   }
/*     */ 
/*     */   public void setOnblur(String onBlur)
/*     */   {
/* 624 */     this.onblur = onBlur;
/*     */   }
/*     */ 
/*     */   public String getOnblur()
/*     */   {
/* 631 */     return this.onblur;
/*     */   }
/*     */ 
/*     */   public void setOnfocus(String onFocus)
/*     */   {
/* 638 */     this.onfocus = onFocus;
/*     */   }
/*     */ 
/*     */   public String getOnfocus()
/*     */   {
/* 645 */     return this.onfocus;
/*     */   }
/*     */ 
/*     */   public void setDisabled(boolean disabled)
/*     */   {
/* 652 */     this.disabled = disabled;
/*     */   }
/*     */ 
/*     */   public boolean getDisabled()
/*     */   {
/* 659 */     return this.disabled;
/*     */   }
/*     */ 
/*     */   public void setReadonly(boolean readonly)
/*     */   {
/* 666 */     this.readonly = readonly;
/*     */   }
/*     */ 
/*     */   public boolean getReadonly()
/*     */   {
/* 673 */     return this.readonly;
/*     */   }
/*     */ 
/*     */   public void setStyle(String style)
/*     */   {
/* 682 */     this.style = style;
/*     */   }
/*     */ 
/*     */   public String getStyle()
/*     */   {
/* 689 */     return this.style;
/*     */   }
/*     */ 
/*     */   public void setStyleClass(String styleClass)
/*     */   {
/* 696 */     this.styleClass = styleClass;
/*     */   }
/*     */ 
/*     */   public String getStyleClass()
/*     */   {
/* 703 */     return this.styleClass;
/*     */   }
/*     */ 
/*     */   public void setStyleId(String styleId)
/*     */   {
/* 710 */     this.styleId = styleId;
/*     */   }
/*     */ 
/*     */   public String getStyleId()
/*     */   {
/* 717 */     return this.styleId;
/*     */   }
/*     */ 
/*     */   public String getAlt()
/*     */   {
/* 726 */     return this.alt;
/*     */   }
/*     */ 
/*     */   public void setAlt(String alt)
/*     */   {
/* 733 */     this.alt = alt;
/*     */   }
/*     */ 
/*     */   public String getAltKey()
/*     */   {
/* 740 */     return this.altKey;
/*     */   }
/*     */ 
/*     */   public void setAltKey(String altKey)
/*     */   {
/* 747 */     this.altKey = altKey;
/*     */   }
/*     */ 
/*     */   public String getBundle()
/*     */   {
/* 754 */     return this.bundle;
/*     */   }
/*     */ 
/*     */   public void setBundle(String bundle)
/*     */   {
/* 761 */     this.bundle = bundle;
/*     */   }
/*     */ 
/*     */   public String getTitle()
/*     */   {
/* 768 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setTitle(String title)
/*     */   {
/* 775 */     this.title = title;
/*     */   }
/*     */ 
/*     */   public String getTitleKey()
/*     */   {
/* 782 */     return this.titleKey;
/*     */   }
/*     */ 
/*     */   public void setTitleKey(String titleKey)
/*     */   {
/* 789 */     this.titleKey = titleKey;
/*     */   }
/*     */ 
/*     */   public String getLang()
/*     */   {
/* 797 */     return this.lang;
/*     */   }
/*     */ 
/*     */   public void setLang(String lang)
/*     */   {
/* 805 */     this.lang = lang;
/*     */   }
/*     */ 
/*     */   public String getDir()
/*     */   {
/* 813 */     return this.dir;
/*     */   }
/*     */ 
/*     */   public void setDir(String dir)
/*     */   {
/* 821 */     this.dir = dir;
/*     */   }
/*     */ 
/*     */   public void release()
/*     */   {
/* 832 */     this.id = null;
/* 833 */     this.accesskey = null;
/* 834 */     this.alt = null;
/* 835 */     this.altKey = null;
/* 836 */     this.bundle = null;
/* 837 */     this.dir = null;
/* 838 */     this.indexed = false;
/* 839 */     this.lang = null;
/* 840 */     this.onclick = null;
/* 841 */     this.ondblclick = null;
/* 842 */     this.onrightclick = null;
/* 843 */     this.onmouseover = null;
/* 844 */     this.onmouseout = null;
/* 845 */     this.onmousemove = null;
/* 846 */     this.onmousedown = null;
/* 847 */     this.onmouseup = null;
/* 848 */     this.onkeydown = null;
/* 849 */     this.onkeyup = null;
/* 850 */     this.onkeypress = null;
/* 851 */     this.onselect = null;
/* 852 */     this.onchange = null;
/* 853 */     this.onblur = null;
/* 854 */     this.onfocus = null;
/* 855 */     this.disabled = false;
/* 856 */     this.readonly = false;
/* 857 */     this.style = null;
/* 858 */     this.styleClass = null;
/* 859 */     this.styleId = null;
/* 860 */     this.tabindex = null;
/* 861 */     this.title = null;
/* 862 */     this.titleKey = null;
/* 863 */     this.dicParameter = new LinkedHashMap();
/* 864 */     super.release();
/*     */   }
/*     */ 
/*     */   public String getDataUrl() {
/* 868 */     return this.dataUrl;
/*     */   }
/*     */ 
/*     */   public void setDataUrl(String dataUrl) {
/* 872 */     this.dataUrl = dataUrl;
/*     */   }
/*     */ 
/*     */   public String getCompId() {
/* 876 */     return this.compId;
/*     */   }
/*     */ 
/*     */   public void setCompId(String compId) {
/* 880 */     this.compId = compId;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.tag.BaseTag
 * JD-Core Version:    0.6.2
 */
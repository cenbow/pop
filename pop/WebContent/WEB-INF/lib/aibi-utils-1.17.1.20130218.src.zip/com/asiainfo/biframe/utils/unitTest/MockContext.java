/*     */ package com.asiainfo.biframe.utils.unitTest;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContextEvent;
/*     */ import javax.servlet.ServletContextListener;
/*     */ import org.springframework.core.io.FileSystemResourceLoader;
/*     */ import org.springframework.mock.web.MockServletContext;
/*     */ import org.springframework.web.context.ContextLoaderListener;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ public class MockContext
/*     */ {
/*  30 */   private static String webappDirectory = "src/main/webapp";
/*     */ 
/*  33 */   private static MockServletContext servletContext = null;
/*     */ 
/*  36 */   private static Map<String, String> parameterMap = new HashMap();
/*     */ 
/*  39 */   private static List<ServletContextListener> listenerList = new ArrayList();
/*     */ 
/*  42 */   private static boolean initialized = false;
/*     */ 
/*     */   public static void initialize()
/*     */   {
/*  51 */     if (initialized) {
/*  52 */       System.out.println("MockContext skip init");
/*  53 */       return;
/*     */     }
/*     */ 
/*  56 */     servletContext = new MockServletContext(webappDirectory, new FileSystemResourceLoader());
/*     */ 
/*  59 */     for (Object key : parameterMap.keySet())
/*     */     {
/*  61 */       servletContext.addInitParameter((String)key, (String)parameterMap.get(key));
/*     */     }
/*     */ 
/*  64 */     ServletContextEvent event = new ServletContextEvent(servletContext);
/*     */ 
/*  67 */     for (ServletContextListener contextListener : listenerList)
/*     */     {
/*  69 */       contextListener.contextInitialized(event);
/*     */     }
/*     */ 
/*  72 */     initialized = true;
/*     */   }
/*     */ 
/*     */   public static MockServletContext getServletContext()
/*     */   {
/*  80 */     return servletContext;
/*     */   }
/*     */ 
/*     */   public static void setWebappDirectory(String dir)
/*     */   {
/*  89 */     webappDirectory = dir;
/*     */   }
/*     */ 
/*     */   public static void addParameter(String paraName, String value)
/*     */   {
/*  99 */     parameterMap.put(paraName, value);
/*     */   }
/*     */ 
/*     */   public static void addListener(ServletContextListener scl)
/*     */   {
/* 108 */     listenerList.add(scl);
/*     */   }
/*     */ 
/*     */   public static void addSpringListener(String location)
/*     */   {
/* 117 */     parameterMap.put("contextConfigLocation", location);
/* 118 */     listenerList.add(new ContextLoaderListener());
/*     */   }
/*     */ 
/*     */   public static Object getBean(String beanName)
/*     */   {
/* 129 */     return WebApplicationContextUtils.getWebApplicationContext(servletContext).getBean(beanName);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.unitTest.MockContext
 * JD-Core Version:    0.6.2
 */
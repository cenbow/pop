/*    */ package com.asiainfo.biframe.utils.unitTest;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import javax.naming.NamingException;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.jdbc.datasource.DriverManagerDataSource;
/*    */ import org.springframework.mock.jndi.SimpleNamingContextBuilder;
/*    */ 
/*    */ public class MockDataSource
/*    */ {
/* 18 */   private static boolean initialized = false;
/*    */ 
/* 21 */   private static SimpleNamingContextBuilder builder = new SimpleNamingContextBuilder();
/*    */ 
/*    */   public static void addDataSource(String driverClassName, String url, String username, String password, String jndiName)
/*    */   {
/* 33 */     DataSource ds = new DriverManagerDataSource(driverClassName, url, username, password);
/* 34 */     builder.bind(jndiName, ds);
/*    */   }
/*    */ 
/*    */   public static void initialize()
/*    */   {
/* 42 */     if (initialized) {
/* 43 */       System.out.println("MockDataSource skip init");
/* 44 */       return;
/*    */     }
/*    */     try {
/* 47 */       builder.activate();
/* 48 */       initialized = true;
/*    */     }
/*    */     catch (IllegalStateException e) {
/* 51 */       e.printStackTrace();
/*    */     }
/*    */     catch (NamingException e) {
/* 54 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.unitTest.MockDataSource
 * JD-Core Version:    0.6.2
 */
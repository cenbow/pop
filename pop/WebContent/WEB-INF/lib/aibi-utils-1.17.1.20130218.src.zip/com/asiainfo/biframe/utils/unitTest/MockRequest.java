/*    */ package com.asiainfo.biframe.utils.unitTest;
/*    */ 
/*    */ import org.springframework.mock.web.MockHttpServletRequest;
/*    */ import org.springframework.mock.web.MockHttpServletResponse;
/*    */ 
/*    */ public class MockRequest
/*    */ {
/* 15 */   private static MockHttpServletRequest request = new MockHttpServletRequest();
/* 16 */   private static MockHttpServletResponse response = new MockHttpServletResponse();
/*    */ 
/*    */   public static MockHttpServletRequest getRequest() {
/* 19 */     return request;
/*    */   }
/*    */ 
/*    */   public static MockHttpServletResponse getResponse() {
/* 23 */     return response;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.unitTest.MockRequest
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.unitTest;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.support.FileSystemXmlApplicationContext;
/*    */ 
/*    */ public class MockSpring
/*    */ {
/*    */   private static ApplicationContext ac;
/*    */ 
/*    */   public static void setConfigFilePath(String configFilePath)
/*    */   {
/* 19 */     String[] paths = { configFilePath };
/* 20 */     setConfigFilePath(paths);
/*    */   }
/*    */ 
/*    */   public static Object getBean(String beanName)
/*    */   {
/* 29 */     return ac.getBean(beanName);
/*    */   }
/*    */ 
/*    */   public static void setConfigFilePath(String[] configFilePath)
/*    */   {
/* 37 */     if (ac == null)
/* 38 */       ac = new FileSystemXmlApplicationContext(configFilePath);
/*    */     else
/* 40 */       System.out.println("MockSpring skip init");
/*    */   }
/*    */ 
/*    */   public static ApplicationContext getApplicationContext()
/*    */   {
/* 50 */     return ac;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.unitTest.MockSpring
 * JD-Core Version:    0.6.2
 */
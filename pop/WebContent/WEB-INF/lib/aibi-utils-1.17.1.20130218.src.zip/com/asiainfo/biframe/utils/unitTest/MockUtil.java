/*    */ package com.asiainfo.biframe.utils.unitTest;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.net.URL;
/*    */ 
/*    */ public class MockUtil
/*    */ {
/* 11 */   private static String webappPath = null;
/*    */ 
/*    */   public static String calWebappPath() {
/* 14 */     if (webappPath == null) {
/* 15 */       System.out.println("calWebappPath only");
/* 16 */       String path = Thread.currentThread().getContextClassLoader().getResource("").getPath();
/* 17 */       System.out.println("SuitePath:" + path);
/* 18 */       path = path.substring(0, path.indexOf("/target/"));
/* 19 */       File file = new File(path + "/target/");
/* 20 */       String[] fileNames = file.list();
/* 21 */       for (String fileName : fileNames) {
/* 22 */         if ((fileName.indexOf("aibi-") == 0) && (!fileName.contains(".jar")) && (!fileName.contains(".war"))) {
/* 23 */           webappPath = "target/" + fileName;
/* 24 */           break;
/*    */         }
/*    */       }
/* 27 */       File fileSource = new File(path + "/" + webappPath + "/WEB-INF/classes/config");
/* 28 */       File fileTarget = new File(path + "/target/test-classes/config");
/*    */       try
/*    */       {
/* 40 */         copyDirectory(fileSource, fileTarget);
/*    */       } catch (IOException ioe) {
/* 42 */         ioe.printStackTrace();
/*    */       }
/* 44 */       System.out.println("webappPath:" + webappPath);
/*    */     }
/*    */ 
/* 47 */     return webappPath;
/*    */   }
/*    */ 
/*    */   static void copyDirectory(File srcDir, File dstDir) throws IOException {
/* 51 */     if (srcDir.isDirectory()) {
/* 52 */       if (!dstDir.exists()) {
/* 53 */         dstDir.mkdir();
/*    */       }
/*    */ 
/* 57 */       String[] children = srcDir.list();
/* 58 */       for (int i = 0; i < children.length; i++) {
/* 59 */         copyDirectory(new File(srcDir, children[i]), new File(dstDir, children[i]));
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 64 */       copyFile(srcDir, dstDir);
/*    */     }
/*    */   }
/*    */ 
/*    */   static void copyFile(File src, File dst) throws IOException {
/* 69 */     InputStream in = new FileInputStream(src);
/* 70 */     OutputStream out = new FileOutputStream(dst);
/*    */ 
/* 72 */     byte[] buf = new byte[1024];
/*    */     int len;
/* 74 */     while ((len = in.read(buf)) > 0) {
/* 75 */       out.write(buf, 0, len);
/*    */     }
/* 77 */     in.close();
/* 78 */     out.close();
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.unitTest.MockUtil
 * JD-Core Version:    0.6.2
 */
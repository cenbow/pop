/*    */ package com.asiainfo.biframe.utils.upload.apache;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class DownloadFileServlet extends HttpServlet
/*    */ {
/*    */   private static final long serialVersionUID = 56890894234786L;
/* 30 */   private static Logger log = Logger.getLogger(DownloadFileServlet.class);
/*    */ 
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 36 */     String filename = request.getParameter("file");
/*    */ 
/* 39 */     response.setContentType("text/x-msdownload;charset=GBK");
/*    */ 
/* 41 */     String downFileName = new String(filename.getBytes("ISO8859-1"), "utf-8");
/*    */ 
/* 44 */     response.setHeader("Content-Disposition", "attachment; filename=" + new String(downFileName.getBytes("GBK"), "ISO8859-1"));
/*    */ 
/* 46 */     log.debug("---------download file name:[" + downFileName + "]");
/*    */ 
/* 48 */     String filePathname = UploadUtil.getDownloadPath() + File.separator + downFileName;
/*    */ 
/* 51 */     OutputStream outputStream = response.getOutputStream();
/* 52 */     InputStream inputStream = new FileInputStream(filePathname);
/* 53 */     byte[] buffer = new byte[1024];
/* 54 */     int i = -1;
/* 55 */     while ((i = inputStream.read(buffer)) != -1) {
/* 56 */       outputStream.write(buffer, 0, i);
/*    */     }
/* 58 */     outputStream.flush();
/* 59 */     log.debug("---------download file success:[" + downFileName + "]");
/* 60 */     outputStream.close();
/* 61 */     inputStream.close();
/*    */   }
/*    */ 
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*    */   {
/* 66 */     doPost(request, response);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.upload.apache.DownloadFileServlet
 * JD-Core Version:    0.6.2
 */
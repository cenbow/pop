/*     */ package com.asiainfo.biframe.utils.upload.apache;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UploadFileServlet extends HttpServlet
/*     */ {
/*  42 */   private static Logger log = Logger.getLogger(UploadFileServlet.class);
/*     */   private static final long serialVersionUID = 56890894234786L;
/*     */ 
/*     */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  49 */     request.setCharacterEncoding("UTF-8");
/*     */ 
/*  51 */     PrintWriter out = null;
/*     */ 
/*  53 */     boolean isMultipart = ServletFileUpload.isMultipartContent(request);
/*     */ 
/*  55 */     if (isMultipart == true) {
/*  56 */       log.debug("----------->>upload file types ");
/*     */       try
/*     */       {
/*  59 */         response.setContentType("text/json; charset=utf-8");
/*  60 */         out = response.getWriter();
/*     */ 
/*  62 */         DiskFileItemFactory factory = new DiskFileItemFactory();
/*  63 */         factory.setSizeThreshold(4096);
/*  64 */         factory.setRepository(new File(UploadUtil.getUploadPath()));
/*     */ 
/*  66 */         ServletFileUpload upload = new ServletFileUpload(factory);
/*  67 */         if (UploadUtil.getMaxFileSize() > 0L) {
/*  68 */           upload.setSizeMax(UploadUtil.getMaxFileSize());
/*     */         }
/*     */ 
/*  72 */         List fileItems = upload.parseRequest(request);
/*  73 */         Iterator iter = fileItems.iterator();
/*     */ 
/*  75 */         while (iter.hasNext()) {
/*  76 */           FileItem item = (FileItem)iter.next();
/*  77 */           if (item.isFormField())
/*     */           {
/*  79 */             String name = item.getFieldName();
/*  80 */             String value = item.getString();
/*  81 */             log.debug("------debug------->>form with the domain name :" + name + "form field value :" + value);
/*     */           }
/*     */           else
/*     */           {
/*  86 */             String fileName = item.getName();
/*  87 */             log.debug("---------file name:[" + fileName + "]");
/*  88 */             if (StringUtil.isNotEmpty(fileName)) {
/*  89 */               File fullFile = new File(fileName);
/*  90 */               File fileOnServer = new File(UploadUtil.getUploadPath(), fullFile.getName());
/*     */ 
/*  92 */               item.write(fileOnServer);
/*  93 */               log.debug("------------------file[" + fileOnServer.getName() + "]upload successful ");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/*  99 */         throw new ServletException("-------file upload failed--------------");
/*     */       }
/*     */     } else {
/* 102 */       log.debug("----------the enctype must be multipart/form-data");
/*     */     }
/*     */     try {
/* 105 */       out.write("SUCCESS");
/*     */     } catch (Exception e) {
/*     */     } finally {
/*     */       try {
/* 109 */         if (out != null) {
/* 110 */           out.flush();
/* 111 */           out.close();
/*     */         }
/*     */       } catch (Exception e1) {
/* 114 */         e1.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 122 */     doPost(request, response);
/*     */   }
/*     */ 
/*     */   public void init() throws ServletException
/*     */   {
/* 127 */     File uploadFile = new File(UploadUtil.getUploadPath());
/* 128 */     if (!uploadFile.exists())
/* 129 */       uploadFile.mkdirs();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.upload.apache.UploadFileServlet
 * JD-Core Version:    0.6.2
 */
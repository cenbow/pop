/*    */ package com.asiainfo.biframe.utils.upload.apache;
/*    */ 
/*    */ public final class UploadUtil
/*    */ {
/*    */   private static String uploadPath;
/*    */   private static String downloadPath;
/* 19 */   private static long maxFileSize = -1L;
/*    */ 
/*    */   public static String getUploadPath()
/*    */   {
/* 26 */     return uploadPath;
/*    */   }
/*    */ 
/*    */   public static void setUploadPath(String uploadPath)
/*    */   {
/* 34 */     uploadPath = uploadPath;
/*    */   }
/*    */ 
/*    */   public static String getDownloadPath()
/*    */   {
/* 44 */     return downloadPath;
/*    */   }
/*    */ 
/*    */   public static void setDownloadPath(String downloadPath)
/*    */   {
/* 54 */     downloadPath = downloadPath;
/*    */   }
/*    */ 
/*    */   public static long getMaxFileSize()
/*    */   {
/* 63 */     return maxFileSize;
/*    */   }
/*    */ 
/*    */   public static void setMaxFileSize(long maxFileSize)
/*    */   {
/* 72 */     maxFileSize = maxFileSize;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.upload.apache.UploadUtil
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.upload.struts;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.struts.upload.FormFile;
/*     */ 
/*     */ public class FileUploadManager
/*     */ {
/*  33 */   private static final Logger logger = Logger.getLogger(FileUploadManager.class);
/*     */ 
/*     */   protected boolean commitUploadFile(String srcDirName, String processID)
/*     */   {
/*  45 */     int index = srcDirName.lastIndexOf("/", srcDirName.length() - 2);
/*  46 */     String prefix = srcDirName.substring(0, index + 1);
/*  47 */     logger.debug("revised directory name:" + prefix + processID);
/*  48 */     return renameTempDir(srcDirName, prefix + processID);
/*     */   }
/*     */ 
/*     */   protected String[] getUploadedFileList(String dirPath)
/*     */   {
/*  60 */     File dir = new File(dirPath);
/*  61 */     if ((dir.exists()) && 
/*  62 */       (dir.isDirectory())) {
/*  63 */       String[] fileList = dir.list();
/*  64 */       for (int i = 0; i < fileList.length; i++) {
/*  65 */         fileList[i] = (dirPath + "/" + fileList[i]);
/*     */       }
/*  67 */       return fileList;
/*     */     }
/*     */ 
/*  70 */     return null;
/*     */   }
/*     */ 
/*     */   private boolean renameTempDir(String srcDirName, String destDirName)
/*     */   {
/*  85 */     File srcDir = new File(srcDirName);
/*  86 */     if (srcDir.isDirectory()) {
/*  87 */       File destDir = new File(destDirName);
/*  88 */       if (destDir.exists()) {
/*  89 */         logger.warn("destination directory " + destDirName + " already exists ");
/*  90 */         return false;
/*     */       }
/*  92 */       srcDir.renameTo(destDir);
/*  93 */       logger.debug("modify the directory name success :source directory " + srcDirName + " -destination directory" + destDirName);
/*  94 */       return true;
/*     */     }
/*  96 */     logger.warn("modify the directory name fails :source directory" + srcDirName + " is not a valid directory");
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */   protected UploadFileBean upload(FormFile[] formFiles, UploadFileBean uploadFileBean, String baseDirName)
/*     */     throws Exception
/*     */   {
/* 114 */     if (uploadFileBean == null) {
/* 115 */       uploadFileBean = new UploadFileBean();
/*     */     }
/* 117 */     if (StringUtil.isEmpty(uploadFileBean.getUploadFileDirName())) {
/* 118 */       uploadFileBean.setUploadFileDirName(createDir(baseDirName, ""));
/*     */     }
/*     */ 
/* 121 */     logger.debug("upload files size=" + formFiles.length);
/* 122 */     for (int i = 0; i < formFiles.length; i++) {
/* 123 */       String fileName = uploadFile(formFiles[i], uploadFileBean);
/* 124 */       if ((fileName != null) && 
/* 125 */         (!uploadFileBean.isFileUploaded(fileName))) {
/* 126 */         uploadFileBean.addFileName(fileName);
/*     */       }
/*     */     }
/*     */ 
/* 130 */     return uploadFileBean;
/*     */   }
/*     */ 
/*     */   private String createDir(String baseDirName, String subDirName)
/*     */     throws Exception
/*     */   {
/* 145 */     String tempDirName = baseDirName + subDirName + "/";
/* 146 */     File dir = new File(tempDirName);
/* 147 */     boolean dirExist = true;
/* 148 */     if (!dir.exists()) {
/* 149 */       dirExist = dir.mkdirs();
/*     */     }
/* 151 */     if (!dirExist) {
/* 152 */       throw new Exception("Failed to create temporary directory:" + tempDirName);
/*     */     }
/* 154 */     return tempDirName;
/*     */   }
/*     */ 
/*     */   protected UploadFileBean deleteUploadFile(String fileName, UploadFileBean uploadFileBean)
/*     */     throws Exception
/*     */   {
/* 168 */     uploadFileBean.removeFileName(fileName);
/* 169 */     deleteFile(uploadFileBean.getUploadFileDirName() + fileName);
/* 170 */     return uploadFileBean;
/*     */   }
/*     */ 
/*     */   private void deleteFile(String path)
/*     */   {
/* 181 */     logger.debug("delete files:" + path);
/* 182 */     File f = new File(path);
/*     */     try {
/* 184 */       f.delete();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private String uploadFile(FormFile formFile, UploadFileBean uploadFileBean)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 201 */       long fileSize = formFile.getFileSize();
/* 202 */       if (fileSize == 0L) {
/* 203 */         return null;
/*     */       }
/* 205 */       String localFilePath = getSavedFileName(uploadFileBean.getUploadFileDirName(), formFile.getFileName());
/*     */ 
/* 207 */       FileOutputStream fos = new FileOutputStream(localFilePath);
/* 208 */       InputStream is = formFile.getInputStream();
/* 209 */       byte[] buffer = new byte[1024];
/* 210 */       for (int bytesRead = 0; (bytesRead = is.read(buffer)) != -1; ) {
/* 211 */         fos.write(buffer, 0, bytesRead);
/*     */       }
/* 213 */       fos.close();
/* 214 */       logger.debug(formFile.getFileName() + "uploaded to the " + localFilePath);
/* 215 */       formFile.destroy();
/* 216 */       return formFile.getFileName();
/*     */     } catch (FileNotFoundException ex) {
/* 218 */       logger.debug("The uploaded file does not exist:" + ex.getMessage());
/* 219 */       throw new Exception("The uploaded file does not exist", ex);
/*     */     } catch (IOException ex) {
/* 221 */       logger.debug("file upload exception:" + ex.getMessage());
/* 222 */       throw new Exception("file upload exception", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String[] getUploadedFileList(String baseDirName, String processID)
/*     */   {
/* 234 */     String prefix = baseDirName + processID;
/* 235 */     File dir = new File(prefix);
/* 236 */     if ((dir.exists()) && 
/* 237 */       (dir.isDirectory())) {
/* 238 */       String[] fileList = dir.list();
/* 239 */       for (int i = 0; i < fileList.length; i++) {
/* 240 */         fileList[i] = (prefix + "/" + fileList[i]);
/*     */       }
/* 242 */       return fileList;
/*     */     }
/*     */ 
/* 245 */     return null;
/*     */   }
/*     */ 
/*     */   private String getSavedFileName(String dirName, String uploadFileName)
/*     */   {
/* 260 */     uploadFileName = uploadFileName.substring(uploadFileName.lastIndexOf("\\") + 1);
/*     */ 
/* 262 */     uploadFileName = uploadFileName.substring(uploadFileName.lastIndexOf("/") + 1);
/*     */ 
/* 264 */     return dirName + uploadFileName;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.upload.struts.FileUploadManager
 * JD-Core Version:    0.6.2
 */
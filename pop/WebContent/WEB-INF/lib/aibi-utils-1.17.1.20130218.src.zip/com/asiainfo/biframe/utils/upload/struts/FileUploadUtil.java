/*    */ package com.asiainfo.biframe.utils.upload.struts;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.struts.upload.FormFile;
/*    */ 
/*    */ public class FileUploadUtil
/*    */ {
/* 19 */   protected static final Logger logger = Logger.getLogger(FileUploadUtil.class);
/*    */   private FileUploadManager fileUploadManager;
/* 23 */   private static FileUploadUtil instance = new FileUploadUtil();
/*    */ 
/*    */   public static FileUploadUtil getInstance() {
/* 26 */     return instance;
/*    */   }
/*    */ 
/*    */   private FileUploadUtil()
/*    */   {
/* 31 */     this.fileUploadManager = new FileUploadManager();
/*    */   }
/*    */ 
/*    */   public UploadFileBean uploadFiles(FormFile[] formFiles, String uploadFolder)
/*    */     throws Exception
/*    */   {
/* 42 */     UploadFileBean returnUploadFileBean = new UploadFileBean();
/*    */     try
/*    */     {
/* 45 */       createFileFolder(uploadFolder);
/*    */ 
/* 48 */       returnUploadFileBean = this.fileUploadManager.upload(formFiles, null, uploadFolder);
/*    */     } catch (Exception ex) {
/* 50 */       logger.error("Uploading file failed!" + ex.getMessage());
/* 51 */       throw new Exception("Uploading file failed!", ex);
/*    */     }
/* 53 */     return returnUploadFileBean;
/*    */   }
/*    */ 
/*    */   private void createFileFolder(String fileFolder)
/*    */   {
/* 61 */     File file = new File(fileFolder);
/* 62 */     if (!file.exists()) {
/* 63 */       file.mkdirs();
/* 64 */       logger.debug("\n = the mkdirs is:" + file.getAbsolutePath() + "\n " + file.getPath() + "\n" + file.getName());
/*    */     }
/* 67 */     else if (file.isFile()) {
/* 68 */       file.delete();
/* 69 */       file.mkdirs();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.upload.struts.FileUploadUtil
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.upload.struts;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class UploadFileBean
/*    */ {
/* 16 */   private String uploadFileDirName = null;
/*    */   private List uploadFileNames;
/*    */ 
/*    */   public String getUploadFileDirName()
/*    */   {
/* 25 */     return this.uploadFileDirName;
/*    */   }
/*    */ 
/*    */   public void setUploadFileDirName(String uploadFileDirName) {
/* 29 */     this.uploadFileDirName = uploadFileDirName;
/*    */   }
/*    */ 
/*    */   public List getUploadFileNames() {
/* 33 */     if (this.uploadFileNames == null) {
/* 34 */       this.uploadFileNames = new ArrayList();
/*    */     }
/* 36 */     return this.uploadFileNames;
/*    */   }
/*    */ 
/*    */   public void setUploadFileNames(List uploadFileNames) {
/* 40 */     this.uploadFileNames = uploadFileNames;
/*    */   }
/*    */ 
/*    */   public boolean isFileUploaded(String fileName)
/*    */   {
/* 51 */     return getUploadFileNames().contains(fileName);
/*    */   }
/*    */ 
/*    */   public void removeFileName(String fileName)
/*    */   {
/* 61 */     getUploadFileNames().remove(fileName);
/*    */   }
/*    */ 
/*    */   public void addFileName(String fileName)
/*    */   {
/* 71 */     getUploadFileNames().add(fileName);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.upload.struts.UploadFileBean
 * JD-Core Version:    0.6.2
 */
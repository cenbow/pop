/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlRootElement(name="BodyReq")
/*    */ public class BodyReq
/*    */ {
/*    */ 
/*    */   @XmlElement(name="ReqData", required=true)
/*    */   private ReqData reqData;
/*    */ 
/*    */   public ReqData getReqData()
/*    */   {
/* 43 */     return this.reqData;
/*    */   }
/*    */ 
/*    */   public void setReqData(ReqData reqData) {
/* 47 */     this.reqData = reqData;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.BodyReq
 * JD-Core Version:    0.6.2
 */
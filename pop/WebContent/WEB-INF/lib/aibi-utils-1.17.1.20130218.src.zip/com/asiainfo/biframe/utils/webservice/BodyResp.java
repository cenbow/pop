/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlRootElement(name="BodyResp")
/*    */ public class BodyResp
/*    */ {
/*    */ 
/*    */   @XmlElement(name="RespData", required=true)
/*    */   private RespData respData;
/*    */ 
/*    */   public RespData getRespData()
/*    */   {
/* 43 */     return this.respData;
/*    */   }
/*    */ 
/*    */   public void setRespData(RespData respData) {
/* 47 */     this.respData = respData;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.BodyResp
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ 
/*    */ public class DataRow
/*    */ {
/*    */   private List<String> dataColumns;
/*    */ 
/*    */   @XmlElement(name="Column")
/*    */   public List<String> getDataColumns()
/*    */   {
/* 41 */     return this.dataColumns;
/*    */   }
/*    */ 
/*    */   public void setDataColumns(List<String> dataColumns) {
/* 45 */     this.dataColumns = dataColumns;
/*    */   }
/*    */ 
/*    */   public void addDataColumn(String column) {
/* 49 */     if (this.dataColumns == null) {
/* 50 */       this.dataColumns = new ArrayList();
/*    */     }
/*    */ 
/* 53 */     this.dataColumns.add(column);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.DataRow
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlElementWrapper;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlType(name="", propOrder={"totalRecord", "dataHeader", "dataRows"})
/*    */ @XmlRootElement(name="DataSet")
/*    */ public class DataSet
/*    */   implements ResponseContent
/*    */ {
/*    */   private int totalRecord;
/*    */   private List<String> dataHeader;
/*    */   private List<DataRow> dataRows;
/*    */ 
/*    */   @XmlElement(name="TotalRecord")
/*    */   public int getTotalRecord()
/*    */   {
/* 49 */     return this.totalRecord;
/*    */   }
/*    */ 
/*    */   public void setTotalRecord(int totalRecord) {
/* 53 */     this.totalRecord = totalRecord;
/*    */   }
/*    */   @XmlElementWrapper(name="DataHeader")
/*    */   @XmlElement(name="Column")
/*    */   public List<String> getDataHeader() {
/* 59 */     return this.dataHeader;
/*    */   }
/*    */ 
/*    */   public void setDataHeader(List<String> dataHeader) {
/* 63 */     this.dataHeader = dataHeader;
/*    */   }
/*    */   @XmlElementWrapper(name="DataRows")
/*    */   @XmlElement(name="Row")
/*    */   public List<DataRow> getDataRows() {
/* 69 */     return this.dataRows;
/*    */   }
/*    */ 
/*    */   public void setDataRows(List<DataRow> dataRows) {
/* 73 */     this.dataRows = dataRows;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.DataSet
 * JD-Core Version:    0.6.2
 */
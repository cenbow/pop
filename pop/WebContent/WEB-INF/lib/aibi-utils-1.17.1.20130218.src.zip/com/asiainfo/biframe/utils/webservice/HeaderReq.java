/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"user", "system", "route"})
/*    */ @XmlRootElement(name="HeaderReq")
/*    */ public class HeaderReq
/*    */ {
/*    */ 
/*    */   @XmlElement(name="User")
/*    */   private User user;
/*    */ 
/*    */   @XmlElement(name="System")
/*    */   private System system;
/*    */ 
/*    */   @XmlElement(name="Route", required=false)
/*    */   private Route route;
/*    */ 
/*    */   public User getUser()
/*    */   {
/* 51 */     return this.user;
/*    */   }
/*    */ 
/*    */   public void setUser(User user) {
/* 55 */     this.user = user;
/*    */   }
/*    */ 
/*    */   public System getSystem() {
/* 59 */     return this.system;
/*    */   }
/*    */ 
/*    */   public void setSystem(System system) {
/* 63 */     this.system = system;
/*    */   }
/*    */ 
/*    */   public Route getRoute() {
/* 67 */     return this.route;
/*    */   }
/*    */ 
/*    */   public void setRoute(Route route) {
/* 71 */     this.route = route;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.HeaderReq
 * JD-Core Version:    0.6.2
 */
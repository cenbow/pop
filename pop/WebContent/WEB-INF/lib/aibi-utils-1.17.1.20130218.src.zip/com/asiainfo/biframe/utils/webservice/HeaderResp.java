/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"respResult", "respTime", "respCode", "respDesc", "tokenCode"})
/*    */ @XmlRootElement(name="HeaderResp")
/*    */ public class HeaderResp
/*    */ {
/*    */ 
/*    */   @XmlElement(name="RespResult")
/*    */   private int respResult;
/*    */ 
/*    */   @XmlElement(name="RespTime")
/*    */   private String respTime;
/*    */ 
/*    */   @XmlElement(name="RespCode")
/*    */   private String respCode;
/*    */ 
/*    */   @XmlElement(name="RespDesc")
/*    */   private String respDesc;
/*    */ 
/*    */   @XmlElement(name="TokenCode")
/*    */   private String tokenCode;
/*    */ 
/*    */   public int getRespResult()
/*    */   {
/* 58 */     return this.respResult;
/*    */   }
/*    */ 
/*    */   public void setRespResult(int respResult) {
/* 62 */     this.respResult = respResult;
/*    */   }
/*    */ 
/*    */   public String getRespTime() {
/* 66 */     return this.respTime;
/*    */   }
/*    */ 
/*    */   public void setRespTime(String respTime) {
/* 70 */     this.respTime = respTime;
/*    */   }
/*    */ 
/*    */   public String getRespCode() {
/* 74 */     return this.respCode;
/*    */   }
/*    */ 
/*    */   public void setRespCode(String respCode) {
/* 78 */     this.respCode = respCode;
/*    */   }
/*    */ 
/*    */   public String getRespDesc() {
/* 82 */     return this.respDesc;
/*    */   }
/*    */ 
/*    */   public void setRespDesc(String respDesc) {
/* 86 */     this.respDesc = respDesc;
/*    */   }
/*    */ 
/*    */   public String getTokenCode() {
/* 90 */     return this.tokenCode;
/*    */   }
/*    */ 
/*    */   public void setTokenCode(String tokenCode) {
/* 94 */     this.tokenCode = tokenCode;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.HeaderResp
 * JD-Core Version:    0.6.2
 */
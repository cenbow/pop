package com.asiainfo.biframe.utils.webservice;

import com.asiainfo.biframe.utils.webservice.uniTouch.BsEmailPushR;
import com.asiainfo.biframe.utils.webservice.uniTouch.BsTask;
import com.asiainfo.biframe.utils.webservice.uniTouch.EmailModel;
import java.util.List;
import javax.jws.WebService;

@WebService(targetNamespace="http://com.asiainfo.suite/unitouch")
public abstract interface ITaskEmailService
{
  public abstract void save(BsTask paramBsTask, List<BsEmailPushR> paramList)
    throws Exception;

  public abstract void saveContentDiff(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3)
    throws Exception;

  public abstract void saveContentSame(String paramString1, String[] paramArrayOfString, String paramString2, String paramString3)
    throws Exception;

  public abstract void saveImmediateTask(String paramString, EmailModel paramEmailModel)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.ITaskEmailService
 * JD-Core Version:    0.6.2
 */
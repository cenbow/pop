package com.asiainfo.biframe.utils.webservice;

import com.asiainfo.biframe.utils.webservice.uniTouch.BsSmsPushR;
import com.asiainfo.biframe.utils.webservice.uniTouch.BsTask;
import java.util.List;
import javax.jws.WebService;

@WebService(targetNamespace="http://com.asiainfo.suite/unitouch")
public abstract interface ITaskSmsService
{
  public abstract void save(BsTask paramBsTask, List<BsSmsPushR> paramList)
    throws Exception;

  public abstract void saveContentDiff(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2)
    throws Exception;

  public abstract void saveContentSame(String paramString1, String[] paramArrayOfString, String paramString2)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.ITaskSmsService
 * JD-Core Version:    0.6.2
 */
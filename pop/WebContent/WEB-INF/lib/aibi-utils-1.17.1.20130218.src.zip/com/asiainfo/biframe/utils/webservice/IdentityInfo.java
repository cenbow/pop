/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlRootElement(name="IdentityInfo")
/*    */ public class IdentityInfo
/*    */ {
/*    */ 
/*    */   @XmlElement(name="ClientID")
/*    */   private String clientID;
/*    */ 
/*    */   @XmlElement(name="PassWord")
/*    */   private String passWord;
/*    */ 
/*    */   public IdentityInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public IdentityInfo(String clientID, String passWord)
/*    */   {
/* 51 */     this.clientID = clientID;
/* 52 */     this.passWord = passWord;
/*    */   }
/*    */ 
/*    */   public String getClientID() {
/* 56 */     return this.clientID;
/*    */   }
/*    */ 
/*    */   public String getPassWord() {
/* 60 */     return this.passWord;
/*    */   }
/*    */ 
/*    */   public void setClientID(String clientID) {
/* 64 */     this.clientID = clientID;
/*    */   }
/*    */ 
/*    */   public void setPassWord(String passWord) {
/* 68 */     this.passWord = passWord;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.IdentityInfo
 * JD-Core Version:    0.6.2
 */
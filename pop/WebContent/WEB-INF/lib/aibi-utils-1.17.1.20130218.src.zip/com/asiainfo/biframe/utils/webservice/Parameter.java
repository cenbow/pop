/*     */ package com.asiainfo.biframe.utils.webservice;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlElementWrapper;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ 
/*     */ @XmlRootElement
/*     */ @XmlType(name="", propOrder={"name", "value", "mapValue", "listValue", "listMapValue"})
/*     */ public class Parameter
/*     */ {
/*     */   private String name;
/*     */   private String value;
/*     */   private Map<String, String> mapValue;
/*     */   private List<String> listValue;
/*     */   private List<Map<String, String>> listMapValue;
/*     */ 
/*     */   public Parameter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Parameter(String name)
/*     */   {
/*  59 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  63 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  67 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getValue() {
/*  71 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(String value) {
/*  75 */     this.value = value;
/*     */   }
/*     */   @XmlElement(name="map")
/*     */   @XmlJavaTypeAdapter(XmlMapAdapter.class)
/*     */   public Map<String, String> getMapValue() {
/*  81 */     return this.mapValue;
/*     */   }
/*     */ 
/*     */   public void setMapValue(Map<String, String> mapValue) {
/*  85 */     this.mapValue = mapValue;
/*     */   }
/*     */   @XmlElementWrapper(name="list")
/*     */   @XmlElement(name="value")
/*     */   public List<String> getListValue() {
/*  91 */     return this.listValue;
/*     */   }
/*     */ 
/*     */   public void setListValue(List<String> listValue) {
/*  95 */     this.listValue = listValue;
/*     */   }
/* 102 */   @XmlElementWrapper(name="list")
/*     */   @XmlElement(name="map")
/*     */   @XmlJavaTypeAdapter(XmlMapAdapter.class)
/*     */   public List<Map<String, String>> getListMapValue() { return this.listMapValue; }
/*     */ 
/*     */   public void setListMapValue(List<Map<String, String>> listMapValue)
/*     */   {
/* 106 */     this.listMapValue = listMapValue;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.Parameter
 * JD-Core Version:    0.6.2
 */
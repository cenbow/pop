/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ public class Parameters
/*    */   implements RequestContent
/*    */ {
/*    */   private List<Parameter> parameter;
/*    */ 
/*    */   public List<Parameter> getParameter()
/*    */   {
/* 40 */     return this.parameter;
/*    */   }
/*    */ 
/*    */   public void setParameter(List<Parameter> parameter) {
/* 44 */     this.parameter = parameter;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.Parameters
 * JD-Core Version:    0.6.2
 */
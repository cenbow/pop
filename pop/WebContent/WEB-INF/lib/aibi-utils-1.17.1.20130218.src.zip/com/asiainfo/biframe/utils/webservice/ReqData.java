/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlAnyElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlRootElement(name="ReqData")
/*    */ public class ReqData
/*    */ {
/*    */ 
/*    */   @XmlAnyElement
/*    */   private List<Object> requestContent;
/*    */ 
/*    */   public List<Object> getRequestContent()
/*    */   {
/* 46 */     return this.requestContent;
/*    */   }
/*    */ 
/*    */   public void setRequestContent(List<Object> requestContent) {
/* 50 */     this.requestContent = requestContent;
/*    */   }
/*    */ 
/*    */   public void addRequestContent(RequestContent[] contents) {
/* 54 */     if ((contents != null) && (contents.length > 0)) {
/* 55 */       if (this.requestContent == null) {
/* 56 */         this.requestContent = new ArrayList();
/*    */       }
/*    */ 
/* 59 */       for (RequestContent rc : contents)
/* 60 */         if (rc != null)
/* 61 */           this.requestContent.add(rc);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.ReqData
 * JD-Core Version:    0.6.2
 */
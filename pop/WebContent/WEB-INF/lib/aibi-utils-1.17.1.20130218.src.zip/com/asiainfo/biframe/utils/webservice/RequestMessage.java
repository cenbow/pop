/*     */ package com.asiainfo.biframe.utils.webservice;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="", propOrder={"headerReq", "bodyReq"})
/*     */ @XmlRootElement(name="Message")
/*     */ public class RequestMessage
/*     */ {
/*     */ 
/*     */   @XmlElement(name="HeaderReq", required=true)
/*     */   private HeaderReq headerReq;
/*     */ 
/*     */   @XmlElement(name="BodyReq", required=true)
/*     */   private BodyReq bodyReq;
/*     */ 
/*     */   public HeaderReq getHeaderReq()
/*     */   {
/*  48 */     return this.headerReq;
/*     */   }
/*     */ 
/*     */   public void setHeaderReq(HeaderReq headerReq) {
/*  52 */     this.headerReq = headerReq;
/*     */   }
/*     */ 
/*     */   public BodyReq getBodyReq() {
/*  56 */     return this.bodyReq;
/*     */   }
/*     */ 
/*     */   public void setBodyReq(BodyReq bodyReq) {
/*  60 */     this.bodyReq = bodyReq;
/*     */   }
/*     */ 
/*     */   public ReqData getRequestData() {
/*  64 */     if (this.bodyReq == null) {
/*  65 */       return null;
/*     */     }
/*     */ 
/*  68 */     return this.bodyReq.getReqData();
/*     */   }
/*     */ 
/*     */   public String getClientID() {
/*  72 */     if (this.headerReq == null) {
/*  73 */       return null;
/*     */     }
/*     */ 
/*  76 */     User user = this.headerReq.getUser();
/*  77 */     if (user == null) {
/*  78 */       return null;
/*     */     }
/*     */ 
/*  81 */     IdentityInfo idinfo = user.getIdentityInfo();
/*  82 */     return idinfo == null ? null : idinfo.getClientID();
/*     */   }
/*     */ 
/*     */   public String getPassWord() {
/*  86 */     if (this.headerReq == null) {
/*  87 */       return null;
/*     */     }
/*     */ 
/*  90 */     User user = this.headerReq.getUser();
/*  91 */     if (user == null) {
/*  92 */       return null;
/*     */     }
/*     */ 
/*  95 */     IdentityInfo idinfo = user.getIdentityInfo();
/*  96 */     return idinfo == null ? null : idinfo.getPassWord();
/*     */   }
/*     */ 
/*     */   public String getTokenCode() {
/* 100 */     if (this.headerReq == null) {
/* 101 */       return null;
/*     */     }
/*     */ 
/* 104 */     User user = this.headerReq.getUser();
/* 105 */     if (user == null) {
/* 106 */       return null;
/*     */     }
/*     */ 
/* 109 */     TokenInfo tk = user.getTokenInfo();
/* 110 */     return tk == null ? null : tk.getTokenCode();
/*     */   }
/*     */ 
/*     */   public int getReqSource() {
/* 114 */     if (this.headerReq == null) {
/* 115 */       return 0;
/*     */     }
/*     */ 
/* 118 */     System sys = this.headerReq.getSystem();
/* 119 */     if (sys == null) {
/* 120 */       return 0;
/*     */     }
/*     */ 
/* 123 */     return sys.getReqSource();
/*     */   }
/*     */ 
/*     */   public String getReqTime() {
/* 127 */     if (this.headerReq == null) {
/* 128 */       return null;
/*     */     }
/*     */ 
/* 131 */     System sys = this.headerReq.getSystem();
/* 132 */     if (sys == null) {
/* 133 */       return null;
/*     */     }
/*     */ 
/* 136 */     return sys.getReqTime();
/*     */   }
/*     */ 
/*     */   public String getReqVersion() {
/* 140 */     if (this.headerReq == null) {
/* 141 */       return null;
/*     */     }
/*     */ 
/* 144 */     System sys = this.headerReq.getSystem();
/* 145 */     if (sys == null) {
/* 146 */       return null;
/*     */     }
/*     */ 
/* 149 */     return sys.getReqVersion();
/*     */   }
/*     */ 
/*     */   public String getRouteType() {
/* 153 */     if (this.headerReq == null) {
/* 154 */       return null;
/*     */     }
/*     */ 
/* 157 */     Route r = this.headerReq.getRoute();
/* 158 */     if (r == null) {
/* 159 */       return null;
/*     */     }
/*     */ 
/* 162 */     return r.getRouteType();
/*     */   }
/*     */ 
/*     */   public String getRouteId() {
/* 166 */     if (this.headerReq == null) {
/* 167 */       return null;
/*     */     }
/*     */ 
/* 170 */     Route r = this.headerReq.getRoute();
/* 171 */     if (r == null) {
/* 172 */       return null;
/*     */     }
/*     */ 
/* 175 */     return r.getRouteId();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.RequestMessage
 * JD-Core Version:    0.6.2
 */
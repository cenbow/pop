/*     */ package com.asiainfo.biframe.utils.webservice;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ 
/*     */ public class RequestMessageBuilder
/*     */ {
/*     */   private RequestMessage message;
/*     */   private ReqData reqData;
/*     */   private IdentityInfo identityInfo;
/*     */   private TokenInfo tokenInfo;
/*     */   private System system;
/*     */   private Route route;
/*     */ 
/*     */   public RequestMessageBuilder()
/*     */   {
/*  53 */     this((RequestContent[])null);
/*     */   }
/*     */ 
/*     */   public RequestMessageBuilder(RequestContent[] contents) {
/*  57 */     this.identityInfo = new IdentityInfo();
/*  58 */     this.tokenInfo = new TokenInfo();
/*     */ 
/*  60 */     User user = new User();
/*  61 */     user.setTokenInfo(this.tokenInfo);
/*  62 */     user.setIdentityInfo(this.identityInfo);
/*     */ 
/*  64 */     this.system = new System();
/*  65 */     this.route = new Route();
/*     */ 
/*  67 */     HeaderReq headerReq = new HeaderReq();
/*  68 */     headerReq.setUser(user);
/*  69 */     headerReq.setSystem(this.system);
/*  70 */     headerReq.setRoute(this.route);
/*     */ 
/*  72 */     BodyReq bodyReq = new BodyReq();
/*  73 */     this.reqData = new ReqData();
/*  74 */     this.reqData.addRequestContent(contents);
/*  75 */     bodyReq.setReqData(this.reqData);
/*     */ 
/*  77 */     this.message = new RequestMessage();
/*  78 */     this.message.setHeaderReq(headerReq);
/*  79 */     this.message.setBodyReq(bodyReq);
/*     */   }
/*     */ 
/*     */   public String createRequestMessage() throws JAXBException {
/*  83 */     JAXBContext context = null;
/*  84 */     StringWriter sw = new StringWriter();
/*     */ 
/*  86 */     List cclazz = new ArrayList();
/*  87 */     cclazz.add(RequestMessage.class);
/*     */ 
/*  89 */     List rccl = this.reqData.getRequestContent();
/*     */     Iterator i$;
/*  90 */     if ((rccl != null) && (rccl.size() > 0)) {
/*  91 */       for (i$ = rccl.iterator(); i$.hasNext(); ) { Object object = i$.next();
/*  92 */         cclazz.add(object.getClass());
/*     */       }
/*     */     }
/*  95 */     context = JAXBContext.newInstance((Class[])cclazz.toArray(new Class[0]));
/*  96 */     Marshaller m = context.createMarshaller();
/*     */ 
/*  99 */     m.marshal(this.message, sw);
/*     */ 
/* 101 */     return sw.toString();
/*     */   }
/*     */ 
/*     */   public void setClientID(String clientID) {
/* 105 */     this.identityInfo.setClientID(clientID);
/*     */   }
/*     */ 
/*     */   public void setPassWord(String passWord) {
/* 109 */     this.identityInfo.setPassWord(passWord);
/*     */   }
/*     */ 
/*     */   public void setTokenCode(String tokenCode) {
/* 113 */     this.tokenInfo.setTokenCode(tokenCode);
/*     */   }
/*     */ 
/*     */   public void setReqSource(int reqSource) {
/* 117 */     this.system.setReqSource(reqSource);
/*     */   }
/*     */ 
/*     */   public void setReqTime(String reqTime) {
/* 121 */     this.system.setReqTime(reqTime);
/*     */   }
/*     */ 
/*     */   public void setReqVersion(String reqVersion) {
/* 125 */     this.system.setReqVersion(reqVersion);
/*     */   }
/*     */ 
/*     */   public void addRequestContent(RequestContent[] content) {
/* 129 */     this.reqData.addRequestContent(content);
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.RequestMessageBuilder
 * JD-Core Version:    0.6.2
 */
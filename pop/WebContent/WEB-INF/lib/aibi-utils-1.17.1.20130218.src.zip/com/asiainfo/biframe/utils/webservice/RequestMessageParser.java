/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import java.io.StringReader;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.Binder;
/*    */ import javax.xml.bind.JAXBContext;
/*    */ import javax.xml.bind.JAXBException;
/*    */ import javax.xml.bind.Unmarshaller;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public class RequestMessageParser
/*    */ {
/*    */   private RequestMessage rquestMessage;
/* 37 */   private ReqData reqData = new ReqData();
/*    */ 
/*    */   public RequestMessage parseRequestMessage(String xml) throws JAXBException {
/* 40 */     this.rquestMessage = messageBinding(xml);
/* 41 */     return this.rquestMessage;
/*    */   }
/*    */ 
/*    */   public ReqData parseRequestData(String xml, Class<? extends RequestContent>[] contentClass)
/*    */     throws JAXBException
/*    */   {
/* 47 */     this.rquestMessage = parseRequestMessage(xml);
/* 48 */     ReqData requestData = this.rquestMessage.getRequestData();
/*    */     Binder binder;
/*    */     Iterator i$;
/* 49 */     if ((requestData != null) && (requestData.getRequestContent() != null))
/*    */     {
/* 51 */       JAXBContext context = JAXBContext.newInstance(contentClass);
/* 52 */       binder = context.createBinder();
/* 53 */       for (i$ = requestData.getRequestContent().iterator(); i$.hasNext(); ) { Object rc = i$.next();
/* 54 */         this.reqData.addRequestContent(new RequestContent[] { (RequestContent)binder.unmarshal((Node)rc) });
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 59 */     return this.reqData;
/*    */   }
/*    */ 
/*    */   private RequestMessage messageBinding(String xml) throws JAXBException {
/* 63 */     JAXBContext context = JAXBContext.newInstance(new Class[] { RequestMessage.class });
/* 64 */     Unmarshaller um = context.createUnmarshaller();
/* 65 */     return (RequestMessage)um.unmarshal(new StringReader(xml));
/*    */   }
/*    */ 
/*    */   public RequestMessage getRquestMessage() {
/* 69 */     return this.rquestMessage;
/*    */   }
/*    */ 
/*    */   public ReqData getRequestData() {
/* 73 */     return this.reqData;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.RequestMessageParser
 * JD-Core Version:    0.6.2
 */
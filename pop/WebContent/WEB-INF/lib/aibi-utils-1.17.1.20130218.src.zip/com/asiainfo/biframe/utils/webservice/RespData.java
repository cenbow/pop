/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlAnyElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlRootElement(name="RespData")
/*    */ public class RespData
/*    */ {
/*    */ 
/*    */   @XmlAnyElement
/*    */   private List<Object> responseContent;
/*    */ 
/*    */   public List<Object> getResponseContent()
/*    */   {
/* 46 */     return this.responseContent;
/*    */   }
/*    */ 
/*    */   public void setResponseContent(List<Object> responseContent) {
/* 50 */     this.responseContent = responseContent;
/*    */   }
/*    */ 
/*    */   public void addResponseContent(ResponseContent[] contents) {
/* 54 */     if ((contents != null) && (contents.length > 0)) {
/* 55 */       if (this.responseContent == null) {
/* 56 */         this.responseContent = new ArrayList();
/*    */       }
/*    */ 
/* 59 */       for (ResponseContent rc : contents)
/* 60 */         if (rc != null)
/* 61 */           this.responseContent.add(rc);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void clearResponseContent()
/*    */   {
/* 68 */     if (this.responseContent != null) {
/* 69 */       this.responseContent.clear();
/*    */     }
/*    */ 
/* 72 */     this.responseContent = null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.RespData
 * JD-Core Version:    0.6.2
 */
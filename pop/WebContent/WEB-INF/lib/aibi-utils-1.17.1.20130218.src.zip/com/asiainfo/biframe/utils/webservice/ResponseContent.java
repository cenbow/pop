package com.asiainfo.biframe.utils.webservice;

public abstract interface ResponseContent
{
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.ResponseContent
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.webservice;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="", propOrder={"headerResp", "bodyResp"})
/*     */ @XmlRootElement(name="Message")
/*     */ public class ResponseMessage
/*     */ {
/*     */ 
/*     */   @XmlElement(name="HeaderResp")
/*     */   private HeaderResp headerResp;
/*     */ 
/*     */   @XmlElement(name="BodyResp", required=true)
/*     */   private BodyResp bodyResp;
/*     */ 
/*     */   public HeaderResp getHeaderResp()
/*     */   {
/*  48 */     return this.headerResp;
/*     */   }
/*     */ 
/*     */   public void setHeaderResp(HeaderResp headerResp) {
/*  52 */     this.headerResp = headerResp;
/*     */   }
/*     */ 
/*     */   public BodyResp getBodyResp() {
/*  56 */     return this.bodyResp;
/*     */   }
/*     */ 
/*     */   public void setBodyResp(BodyResp bodyResp) {
/*  60 */     this.bodyResp = bodyResp;
/*     */   }
/*     */ 
/*     */   public RespData getResponseData() {
/*  64 */     if (this.bodyResp == null) {
/*  65 */       return null;
/*     */     }
/*  67 */     return this.bodyResp.getRespData();
/*     */   }
/*     */ 
/*     */   public int getRespResult() {
/*  71 */     if (this.headerResp == null) {
/*  72 */       return 0;
/*     */     }
/*  74 */     return this.headerResp.getRespResult();
/*     */   }
/*     */ 
/*     */   public String getRespTime() {
/*  78 */     if (this.headerResp == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     return this.headerResp.getRespTime();
/*     */   }
/*     */ 
/*     */   public String getRespCode() {
/*  85 */     if (this.headerResp == null) {
/*  86 */       return null;
/*     */     }
/*  88 */     return this.headerResp.getRespCode();
/*     */   }
/*     */ 
/*     */   public String getRespDesc() {
/*  92 */     if (this.headerResp == null) {
/*  93 */       return null;
/*     */     }
/*  95 */     return this.headerResp.getRespDesc();
/*     */   }
/*     */ 
/*     */   public String getTokenCode() {
/*  99 */     if (this.headerResp == null) {
/* 100 */       return null;
/*     */     }
/* 102 */     return this.headerResp.getTokenCode();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.ResponseMessage
 * JD-Core Version:    0.6.2
 */
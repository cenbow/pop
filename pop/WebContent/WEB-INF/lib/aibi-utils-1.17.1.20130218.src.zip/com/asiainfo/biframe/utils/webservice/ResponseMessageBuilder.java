/*     */ package com.asiainfo.biframe.utils.webservice;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.date.DateUtil;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ResponseMessageBuilder
/*     */ {
/*  45 */   private static final Logger log = Logger.getLogger(ResponseMessageBuilder.class);
/*     */   private ResponseMessage message;
/*     */   private HeaderResp headerResp;
/*     */   private RespData respData;
/*     */ 
/*     */   public ResponseMessageBuilder()
/*     */   {
/*  55 */     this((ResponseContent[])null);
/*     */   }
/*     */ 
/*     */   public ResponseMessageBuilder(ResponseContent[] contents) {
/*  59 */     this.message = new ResponseMessage();
/*     */ 
/*  61 */     this.headerResp = new HeaderResp();
/*  62 */     this.message.setHeaderResp(this.headerResp);
/*     */ 
/*  64 */     BodyResp bodyResp = new BodyResp();
/*  65 */     this.respData = new RespData();
/*  66 */     this.respData.addResponseContent(contents);
/*  67 */     bodyResp.setRespData(this.respData);
/*     */ 
/*  69 */     this.message.setBodyResp(bodyResp);
/*     */   }
/*     */ 
/*     */   public String createResponseMessage()
/*     */   {
/*  79 */     JAXBContext context = null;
/*  80 */     StringWriter sw = new StringWriter();
/*     */     try {
/*  82 */       if (this.headerResp.getRespTime() == null) {
/*  83 */         this.headerResp.setRespTime(DateUtil.date2String(new Date(), "yyyyMMddHHmmss"));
/*     */       }
/*     */ 
/*  87 */       List cclazz = new ArrayList();
/*  88 */       cclazz.add(ResponseMessage.class);
/*     */ 
/*  90 */       List rccl = this.respData.getResponseContent();
/*     */       Iterator i$;
/*  91 */       if ((rccl != null) && (rccl.size() > 0)) {
/*  92 */         for (i$ = rccl.iterator(); i$.hasNext(); ) { Object object = i$.next();
/*  93 */           cclazz.add(object.getClass());
/*     */         }
/*     */       }
/*  96 */       context = JAXBContext.newInstance((Class[])cclazz.toArray(new Class[0]));
/*  97 */       Marshaller m = context.createMarshaller();
/*     */ 
/* 100 */       m.marshal(this.message, sw);
/*     */     } catch (JAXBException e) {
/* 102 */       log.error("构建响应消息时出现异常:" + e.getMessage(), e);
/*     */     }
/*     */ 
/* 105 */     return sw.toString();
/*     */   }
/*     */ 
/*     */   public void setRespResult(int respResult) {
/* 109 */     this.headerResp.setRespResult(respResult);
/*     */   }
/*     */ 
/*     */   public void setRespTime(String respTime) {
/* 113 */     this.headerResp.setRespTime(respTime);
/*     */   }
/*     */ 
/*     */   public void setRespCode(String respCode) {
/* 117 */     this.headerResp.setRespCode(respCode);
/*     */   }
/*     */ 
/*     */   public void setRespDesc(String respDesc) {
/* 121 */     this.headerResp.setRespDesc(respDesc);
/*     */   }
/*     */ 
/*     */   public void setTokenCode(String tokenCode) {
/* 125 */     this.headerResp.setTokenCode(tokenCode);
/*     */   }
/*     */ 
/*     */   public void addResponseContent(ResponseContent[] content) {
/* 129 */     this.respData.addResponseContent(content);
/*     */   }
/*     */ 
/*     */   public void clearResponseContent() {
/* 133 */     this.respData.clearResponseContent();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.ResponseMessageBuilder
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import java.io.StringReader;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.Binder;
/*    */ import javax.xml.bind.JAXBContext;
/*    */ import javax.xml.bind.JAXBException;
/*    */ import javax.xml.bind.Unmarshaller;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public class ResponseMessageParser
/*    */ {
/*    */   private ResponseMessage responseMessage;
/* 43 */   private RespData respData = new RespData();
/*    */ 
/*    */   public ResponseMessage parseResponseMessage(String xml) throws JAXBException
/*    */   {
/* 47 */     this.responseMessage = messageBinding(xml);
/* 48 */     return this.responseMessage;
/*    */   }
/*    */ 
/*    */   public RespData parseResponseData(String xml, Class<? extends ResponseContent>[] contentClass)
/*    */     throws JAXBException
/*    */   {
/* 54 */     this.responseMessage = messageBinding(xml);
/* 55 */     RespData responseData = this.responseMessage.getResponseData();
/*    */     Binder binder;
/*    */     Iterator i$;
/* 56 */     if ((responseData != null) && (responseData.getResponseContent() != null)) {
/* 57 */       JAXBContext context = JAXBContext.newInstance(contentClass);
/* 58 */       binder = context.createBinder();
/* 59 */       for (i$ = responseData.getResponseContent().iterator(); i$.hasNext(); ) { Object rc = i$.next();
/* 60 */         ResponseContent c = (ResponseContent)binder.unmarshal((Node)rc);
/*    */ 
/* 62 */         this.respData.addResponseContent(new ResponseContent[] { c });
/*    */       }
/*    */     }
/*    */ 
/* 66 */     return this.respData;
/*    */   }
/*    */ 
/*    */   private ResponseMessage messageBinding(String xml) throws JAXBException {
/* 70 */     JAXBContext context = JAXBContext.newInstance(new Class[] { ResponseMessage.class });
/* 71 */     Unmarshaller um = context.createUnmarshaller();
/* 72 */     return (ResponseMessage)um.unmarshal(new StringReader(xml));
/*    */   }
/*    */ 
/*    */   public ResponseMessage getResponseMessage() {
/* 76 */     return this.responseMessage;
/*    */   }
/*    */ 
/*    */   public RespData getResponseData() {
/* 80 */     return this.respData;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.ResponseMessageParser
 * JD-Core Version:    0.6.2
 */
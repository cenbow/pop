/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"routeType", "routeId"})
/*    */ @XmlRootElement(name="Route")
/*    */ public class Route
/*    */ {
/*    */ 
/*    */   @XmlElement(name="RouteType")
/*    */   private String routeType;
/*    */ 
/*    */   @XmlElement(name="RouteId")
/*    */   private String routeId;
/*    */ 
/*    */   public String getRouteType()
/*    */   {
/* 48 */     return this.routeType;
/*    */   }
/*    */ 
/*    */   public void setRouteType(String routeType) {
/* 52 */     this.routeType = routeType;
/*    */   }
/*    */ 
/*    */   public String getRouteId() {
/* 56 */     return this.routeId;
/*    */   }
/*    */ 
/*    */   public void setRouteId(String routeId) {
/* 60 */     this.routeId = routeId;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.Route
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"reqSource", "reqTime", "reqVersion"})
/*    */ @XmlRootElement(name="System")
/*    */ public class System
/*    */ {
/*    */ 
/*    */   @XmlElement(name="ReqSource")
/*    */   private int reqSource;
/*    */ 
/*    */   @XmlElement(name="ReqTime")
/*    */   private String reqTime;
/*    */ 
/*    */   @XmlElement(name="ReqVersion")
/*    */   private String reqVersion;
/*    */ 
/*    */   public int getReqSource()
/*    */   {
/* 51 */     return this.reqSource;
/*    */   }
/*    */ 
/*    */   public void setReqSource(int reqSource) {
/* 55 */     this.reqSource = reqSource;
/*    */   }
/*    */ 
/*    */   public String getReqTime() {
/* 59 */     return this.reqTime;
/*    */   }
/*    */ 
/*    */   public void setReqTime(String reqTime) {
/* 63 */     this.reqTime = reqTime;
/*    */   }
/*    */ 
/*    */   public String getReqVersion() {
/* 67 */     return this.reqVersion;
/*    */   }
/*    */ 
/*    */   public void setReqVersion(String reqVersion) {
/* 71 */     this.reqVersion = reqVersion;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.System
 * JD-Core Version:    0.6.2
 */
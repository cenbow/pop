/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlRootElement(name="User")
/*    */ public class User
/*    */ {
/*    */ 
/*    */   @XmlElement(name="IdentityInfo")
/*    */   private IdentityInfo identityInfo;
/*    */ 
/*    */   @XmlElement(name="TokenInfo")
/*    */   private TokenInfo tokenInfo;
/*    */ 
/*    */   public IdentityInfo getIdentityInfo()
/*    */   {
/* 46 */     return this.identityInfo;
/*    */   }
/*    */ 
/*    */   public void setIdentityInfo(IdentityInfo identityInfo) {
/* 50 */     this.identityInfo = identityInfo;
/*    */   }
/*    */ 
/*    */   public TokenInfo getTokenInfo() {
/* 54 */     return this.tokenInfo;
/*    */   }
/*    */ 
/*    */   public void setTokenInfo(TokenInfo tokenInfo) {
/* 58 */     this.tokenInfo = tokenInfo;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.User
 * JD-Core Version:    0.6.2
 */
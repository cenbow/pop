package com.asiainfo.biframe.utils.webservice;

public abstract interface WebServiceClientCallback
{
  public abstract String process(String paramString)
    throws Exception;

  public abstract RequestContent[] getRequestContent();

  public abstract Class<ResponseContent>[] getResponseContentType();
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.WebServiceClientCallback
 * JD-Core Version:    0.6.2
 */
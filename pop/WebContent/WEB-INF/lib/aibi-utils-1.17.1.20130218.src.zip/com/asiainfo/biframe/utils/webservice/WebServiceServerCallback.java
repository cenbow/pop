package com.asiainfo.biframe.utils.webservice;

public abstract interface WebServiceServerCallback
{
  public abstract Class<RequestContent>[] getRequestContentType();

  public abstract ResponseContent[] process(ReqData paramReqData)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.WebServiceServerCallback
 * JD-Core Version:    0.6.2
 */
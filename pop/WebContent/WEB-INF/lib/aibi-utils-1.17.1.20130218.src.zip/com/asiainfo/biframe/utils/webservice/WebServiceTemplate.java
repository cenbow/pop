/*     */ package com.asiainfo.biframe.utils.webservice;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.ws.WebServiceException;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ 
/*     */ public class WebServiceTemplate
/*     */ {
/*  40 */   private static final Logger LOG = Logger.getLogger(WebServiceTemplate.class);
/*     */ 
/*     */   public String execute(String xmlRequest, WebServiceServerCallback callback)
/*     */   {
/*  52 */     LOG.debug("服务请求消息为:" + xmlRequest);
/*     */ 
/*  55 */     String respMessage = null;
/*  56 */     if (StringUtil.isEmpty(xmlRequest)) {
/*  57 */       respMessage = createErrorMessage(905, "MessageErr", "服务消息错误:请求消息不能为空");
/*     */     }
/*     */     else {
/*  60 */       respMessage = doExecute(xmlRequest, callback);
/*     */     }
/*     */ 
/*  63 */     LOG.debug("服务响应消息为:" + respMessage);
/*  64 */     return respMessage;
/*     */   }
/*     */ 
/*     */   private String doExecute(String xmlRequest, WebServiceServerCallback callback)
/*     */   {
/*  77 */     ResponseMessageBuilder rmb = new ResponseMessageBuilder();
/*     */     try
/*     */     {
/*  80 */       RequestMessageParser rmp = new RequestMessageParser();
/*  81 */       rmp.parseRequestData(xmlRequest, callback.getRequestContentType());
/*     */ 
/*  84 */       ReqData reqData = rmp.getRequestData();
/*  85 */       if (reqData != null) {
/*  86 */         ResponseContent[] cr = callback.process(reqData);
/*     */ 
/*  89 */         rmb.addResponseContent(cr);
/*  90 */         rmb.setRespResult(0);
/*     */       }
/*     */       else {
/*  93 */         rmb.clearResponseContent();
/*  94 */         rmb.setRespResult(905);
/*  95 */         rmb.setRespCode("MessageErr");
/*  96 */         rmb.setRespDesc("服务消息错误:请求消息找不到<ReqData></ReqData>元素");
/*     */       }
/*     */     } catch (JAXBException e) {
/*  99 */       LOG.error("请求消息解析异常", e);
/*     */ 
/* 101 */       rmb.clearResponseContent();
/* 102 */       rmb.setRespResult(905);
/* 103 */       rmb.setRespCode("MessageErr");
/* 104 */       rmb.setRespDesc("服务消息错误:请求消息格式错误," + parseExceptionMessage(e));
/*     */     } catch (DataAccessException e) {
/* 106 */       String message = "数据库访问异常:" + parseExceptionMessage(e);
/* 107 */       LOG.error(message, e);
/*     */ 
/* 109 */       rmb.clearResponseContent();
/* 110 */       rmb.setRespResult(901);
/* 111 */       rmb.setRespCode("Sqlcode");
/* 112 */       rmb.setRespDesc(message);
/*     */     } catch (Exception e) {
/* 114 */       LOG.error("服务执行异常", e);
/*     */ 
/* 116 */       rmb.clearResponseContent();
/* 117 */       rmb.setRespResult(999);
/* 118 */       rmb.setRespCode("OtherErr");
/* 119 */       rmb.setRespDesc(parseExceptionMessage(e));
/*     */     }
/* 121 */     return rmb.createResponseMessage();
/*     */   }
/*     */ 
/*     */   private String createErrorMessage(int code, String message, String desc)
/*     */   {
/* 135 */     ResponseMessageBuilder rmb = new ResponseMessageBuilder();
/* 136 */     rmb.setRespResult(code);
/* 137 */     rmb.setRespCode(message);
/* 138 */     rmb.setRespDesc(desc);
/* 139 */     return rmb.createResponseMessage();
/*     */   }
/*     */ 
/*     */   public RespData execute(WebServiceClientCallback callback)
/*     */     throws Exception
/*     */   {
/* 152 */     return execute(null, callback);
/*     */   }
/*     */ 
/*     */   public RespData execute(RequestMessageBuilder rmb, WebServiceClientCallback callback)
/*     */     throws Exception
/*     */   {
/* 167 */     if (callback == null) {
/* 168 */       String msg = "WebServiceClientCallback参数不能为空";
/* 169 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */ 
/* 172 */     if (rmb == null)
/*     */     {
/* 174 */       rmb = new RequestMessageBuilder();
/*     */     }
/*     */ 
/* 178 */     rmb.addRequestContent(callback.getRequestContent());
/*     */ 
/* 181 */     String reqMsg = rmb.createRequestMessage();
/* 182 */     LOG.debug("服务请求消息为:" + reqMsg);
/* 183 */     String respMsg = callback.process(reqMsg);
/* 184 */     LOG.debug("服务响应消息为:" + respMsg);
/*     */ 
/* 187 */     Class[] respDataType = callback.getResponseContentType();
/*     */ 
/* 191 */     ResponseMessageParser rmp = new ResponseMessageParser();
/*     */ 
/* 193 */     rmp.parseResponseData(respMsg, respDataType);
/* 194 */     ResponseMessage rmObj = rmp.getResponseMessage();
/*     */ 
/* 197 */     if (rmObj.getRespResult() == 0) {
/* 198 */       return rmp.getResponseData();
/*     */     }
/* 200 */     throw new WebServiceException(rmObj.getRespDesc());
/*     */   }
/*     */ 
/*     */   private String parseExceptionMessage(Throwable e)
/*     */   {
/* 213 */     String message = e.getMessage();
/* 214 */     if ((message == null) && (e.getCause() != null)) {
/* 215 */       message = parseExceptionMessage(e.getCause());
/*     */     }
/*     */ 
/* 218 */     return message;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.WebServiceTemplate
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*    */ 
/*    */ public class XmlMapAdapter extends XmlAdapter<XmlMapType, Map<String, String>>
/*    */ {
/*    */   public XmlMapType marshal(Map<String, String> mapBean)
/*    */     throws Exception
/*    */   {
/* 47 */     if (mapBean == null) {
/* 48 */       return null;
/*    */     }
/*    */ 
/* 51 */     Set entrySet = mapBean.entrySet();
/* 52 */     List mes = new ArrayList(entrySet.size());
/*    */ 
/* 54 */     for (Map.Entry ent : entrySet) {
/* 55 */       mes.add(new XmlMapEntryType((String)ent.getKey(), (String)ent.getValue()));
/*    */     }
/*    */ 
/* 58 */     XmlMapType mapType = new XmlMapType();
/* 59 */     mapType.setEntries(mes);
/* 60 */     return mapType;
/*    */   }
/*    */ 
/*    */   public Map<String, String> unmarshal(XmlMapType mapType)
/*    */     throws Exception
/*    */   {
/* 72 */     if (mapType == null) {
/* 73 */       return null;
/*    */     }
/*    */ 
/* 76 */     Map mapBean = null;
/* 77 */     List ens = mapType.getEntries();
/* 78 */     if ((ens != null) && (ens.size() > 0)) {
/* 79 */       mapBean = new HashMap(ens.size());
/* 80 */       for (XmlMapEntryType met : ens) {
/* 81 */         mapBean.put(met.getKey(), met.getValue());
/*    */       }
/*    */     }
/*    */ 
/* 85 */     return mapBean;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.XmlMapAdapter
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAttribute;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name="entry")
/*    */ public class XmlMapEntryType
/*    */ {
/*    */   private String key;
/*    */   private String value;
/*    */ 
/*    */   public XmlMapEntryType()
/*    */   {
/*    */   }
/*    */ 
/*    */   public XmlMapEntryType(String key, String value)
/*    */   {
/* 45 */     this.key = key;
/* 46 */     this.value = value;
/*    */   }
/*    */ 
/*    */   @XmlAttribute
/*    */   public String getKey() {
/* 51 */     return this.key;
/*    */   }
/*    */ 
/*    */   public void setKey(String key) {
/* 55 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 59 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String value) {
/* 63 */     this.value = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.XmlMapEntryType
 * JD-Core Version:    0.6.2
 */
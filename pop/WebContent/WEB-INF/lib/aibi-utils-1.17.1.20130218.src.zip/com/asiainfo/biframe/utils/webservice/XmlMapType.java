/*    */ package com.asiainfo.biframe.utils.webservice;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name="map")
/*    */ public class XmlMapType
/*    */ {
/*    */   private List<XmlMapEntryType> entries;
/*    */ 
/*    */   @XmlElement(name="entry")
/*    */   public List<XmlMapEntryType> getEntries()
/*    */   {
/* 43 */     return this.entries;
/*    */   }
/*    */ 
/*    */   public void setEntries(List<XmlMapEntryType> entries) {
/* 47 */     this.entries = entries;
/*    */   }
/*    */ 
/*    */   public void addEntry(XmlMapEntryType entry) {
/* 51 */     if (this.entries == null) {
/* 52 */       this.entries = new ArrayList();
/*    */     }
/* 54 */     this.entries.add(entry);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.XmlMapType
 * JD-Core Version:    0.6.2
 */
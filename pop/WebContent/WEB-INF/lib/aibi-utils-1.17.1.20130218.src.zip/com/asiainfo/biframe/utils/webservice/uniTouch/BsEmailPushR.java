/*    */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class BsEmailPushR
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -3918333584675628411L;
/*    */   private Long id;
/*    */   private String taskId;
/*    */   private String msisdn;
/*    */   private String content;
/*    */   private String title;
/*    */   private Integer status;
/*    */   private String channelId;
/*    */   private Integer sendCount;
/*    */   private String attachPath;
/*    */   private String fileName;
/*    */ 
/*    */   public Long getId()
/*    */   {
/* 18 */     return this.id;
/*    */   }
/*    */   public void setId(Long id) {
/* 21 */     this.id = id;
/*    */   }
/*    */   public String getTaskId() {
/* 24 */     return this.taskId;
/*    */   }
/*    */   public void setTaskId(String taskId) {
/* 27 */     this.taskId = taskId;
/*    */   }
/*    */   public String getMsisdn() {
/* 30 */     return this.msisdn;
/*    */   }
/*    */   public void setMsisdn(String msisdn) {
/* 33 */     this.msisdn = msisdn;
/*    */   }
/*    */   public String getContent() {
/* 36 */     return this.content;
/*    */   }
/*    */   public void setContent(String content) {
/* 39 */     this.content = content;
/*    */   }
/*    */   public String getTitle() {
/* 42 */     return this.title;
/*    */   }
/*    */   public void setTitle(String title) {
/* 45 */     this.title = title;
/*    */   }
/*    */   public Integer getStatus() {
/* 48 */     return this.status;
/*    */   }
/*    */   public void setStatus(Integer status) {
/* 51 */     this.status = status;
/*    */   }
/*    */   public String getChannelId() {
/* 54 */     return this.channelId;
/*    */   }
/*    */   public void setChannelId(String channelId) {
/* 57 */     this.channelId = channelId;
/*    */   }
/*    */   public Integer getSendCount() {
/* 60 */     return this.sendCount;
/*    */   }
/*    */   public void setSendCount(Integer sendCount) {
/* 63 */     this.sendCount = sendCount;
/*    */   }
/*    */   public String getAttachPath() {
/* 66 */     return this.attachPath;
/*    */   }
/*    */   public void setAttachPath(String attachPath) {
/* 69 */     this.attachPath = attachPath;
/*    */   }
/*    */   public String getFileName() {
/* 72 */     return this.fileName;
/*    */   }
/*    */   public void setFileName(String fileName) {
/* 75 */     this.fileName = fileName;
/*    */   }
/*    */   public String[] getContentArray() {
/* 78 */     String[] re = { this.content, this.fileName };
/* 79 */     return re;
/*    */   }
/*    */   public String getSubject() {
/* 82 */     return this.title;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.BsEmailPushR
 * JD-Core Version:    0.6.2
 */
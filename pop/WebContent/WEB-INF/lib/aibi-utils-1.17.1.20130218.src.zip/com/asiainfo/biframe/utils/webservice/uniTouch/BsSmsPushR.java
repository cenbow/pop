/*    */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*    */ 
/*    */ public class BsSmsPushR
/*    */ {
/*    */   private Long id;
/*    */   private String taskId;
/*    */   private String channelId;
/*    */   private String msisdn;
/*    */   private String subject;
/*    */   private Integer sendCount;
/*    */   private Integer status;
/*    */ 
/*    */   public Long getId()
/*    */   {
/* 24 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(Long id) {
/* 28 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getTaskId() {
/* 32 */     return this.taskId;
/*    */   }
/*    */ 
/*    */   public void setTaskId(String taskId) {
/* 36 */     this.taskId = taskId;
/*    */   }
/*    */ 
/*    */   public String getChannelId() {
/* 40 */     return this.channelId;
/*    */   }
/*    */ 
/*    */   public void setChannelId(String channelId) {
/* 44 */     this.channelId = channelId;
/*    */   }
/*    */ 
/*    */   public String getMsisdn() {
/* 48 */     return this.msisdn;
/*    */   }
/*    */ 
/*    */   public void setMsisdn(String msisdn) {
/* 52 */     this.msisdn = msisdn;
/*    */   }
/*    */ 
/*    */   public String getSubject() {
/* 56 */     return this.subject;
/*    */   }
/*    */ 
/*    */   public void setSubject(String subject) {
/* 60 */     this.subject = subject;
/*    */   }
/*    */ 
/*    */   public Integer getSendCount() {
/* 64 */     return this.sendCount;
/*    */   }
/*    */ 
/*    */   public void setSendCount(Integer sendCount) {
/* 68 */     this.sendCount = sendCount;
/*    */   }
/*    */ 
/*    */   public Integer getStatus() {
/* 72 */     return this.status;
/*    */   }
/*    */ 
/*    */   public void setStatus(Integer status) {
/* 76 */     this.status = status;
/*    */   }
/*    */ 
/*    */   public String[] getContentArray()
/*    */   {
/* 81 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.BsSmsPushR
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ 
/*     */ public class BsTask
/*     */   implements Serializable
/*     */ {
/*     */   private String id;
/*     */   private String sysId;
/*     */   private String subsysId;
/*     */   private String outId;
/*     */   private String channelType;
/*     */   private String channelId;
/*     */   private String name;
/*     */   private Integer status;
/*     */   private Integer taskLevel;
/*     */   private Date startDate;
/*     */   private Date endDate;
/*     */   private Integer startTime;
/*     */   private Integer endTime;
/*     */   private Integer control;
/*     */   private String creator;
/*     */   private Timestamp createDate;
/*     */   private Integer taskType;
/*     */   private String cityId;
/*     */   private String isTestTask;
/*     */   private String subject;
/*     */   private String url;
/*     */   private File file;
/*     */   private String filePath;
/*     */   private String createMonth;
/*     */   private Long count;
/*     */   private String objId;
/*     */   private String parentId;
/*     */   private String importType;
/*     */   private String content;
/*     */   private String attachPath;
/*     */ 
/*     */   public String getAttachPath()
/*     */   {
/*  57 */     return this.attachPath;
/*     */   }
/*     */ 
/*     */   public void setAttachPath(String attachPath) {
/*  61 */     this.attachPath = attachPath;
/*     */   }
/*     */ 
/*     */   public String getImportType() {
/*  65 */     return this.importType;
/*     */   }
/*     */ 
/*     */   public void setImportType(String importType) {
/*  69 */     this.importType = importType;
/*     */   }
/*     */ 
/*     */   public String getCityId() {
/*  73 */     return this.cityId;
/*     */   }
/*     */ 
/*     */   public void setCityId(String cityId) {
/*  77 */     this.cityId = cityId;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/*  81 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setParentId(String parentId) {
/*  85 */     this.parentId = parentId;
/*     */   }
/*     */ 
/*     */   public String getObjId() {
/*  89 */     return this.objId;
/*     */   }
/*     */ 
/*     */   public void setObjId(String objId) {
/*  93 */     this.objId = objId;
/*     */   }
/*     */ 
/*     */   public Long getCount() {
/*  97 */     return this.count;
/*     */   }
/*     */ 
/*     */   public void setCount(Long count) {
/* 101 */     this.count = count;
/*     */   }
/*     */ 
/*     */   public String getCreateMonth() {
/* 105 */     return this.createMonth;
/*     */   }
/*     */ 
/*     */   public void setCreateMonth(String createMonth) {
/* 109 */     this.createMonth = createMonth;
/*     */   }
/*     */ 
/*     */   public String getFilePath() {
/* 113 */     return this.filePath;
/*     */   }
/*     */ 
/*     */   public void setFilePath(String filePath) {
/* 117 */     this.filePath = filePath;
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/* 121 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) {
/* 125 */     this.subject = subject;
/*     */   }
/*     */ 
/*     */   public String getUrl() {
/* 129 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setUrl(String url) {
/* 133 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public File getFile() {
/* 137 */     return this.file;
/*     */   }
/*     */ 
/*     */   public void setFile(File file) {
/* 141 */     this.file = file;
/*     */   }
/*     */ 
/*     */   public Integer getTaskType()
/*     */   {
/* 147 */     return this.taskType;
/*     */   }
/*     */ 
/*     */   public void setTaskType(Integer taskType) {
/* 151 */     this.taskType = taskType;
/*     */   }
/*     */ 
/*     */   public String getCreator() {
/* 155 */     return this.creator;
/*     */   }
/*     */ 
/*     */   public void setCreator(String creator) {
/* 159 */     this.creator = creator;
/*     */   }
/*     */ 
/*     */   @XmlJavaTypeAdapter(TimestampAdapter.class)
/*     */   public Timestamp getCreateDate() {
/* 164 */     return this.createDate;
/*     */   }
/*     */ 
/*     */   public void setCreateDate(Timestamp createDate) {
/* 168 */     this.createDate = createDate;
/*     */   }
/*     */ 
/*     */   public String getOutId() {
/* 172 */     return this.outId;
/*     */   }
/*     */ 
/*     */   public void setOutId(String outId) {
/* 176 */     this.outId = outId;
/*     */   }
/*     */ 
/*     */   public String getId() {
/* 180 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String id) {
/* 184 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getSubsysId() {
/* 188 */     return this.subsysId;
/*     */   }
/*     */ 
/*     */   public void setSubsysId(String subsysId) {
/* 192 */     this.subsysId = subsysId;
/*     */   }
/*     */ 
/*     */   public String getChannelType() {
/* 196 */     return this.channelType;
/*     */   }
/*     */ 
/*     */   public void setChannelType(String channelType) {
/* 200 */     this.channelType = channelType;
/*     */   }
/*     */ 
/*     */   public String getChannelId() {
/* 204 */     return this.channelId;
/*     */   }
/*     */ 
/*     */   public void setChannelId(String channelId) {
/* 208 */     this.channelId = channelId;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 212 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 216 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public Integer getStatus() {
/* 220 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(Integer status) {
/* 224 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public Integer getTaskLevel()
/*     */   {
/* 230 */     return this.taskLevel;
/*     */   }
/*     */ 
/*     */   public void setTaskLevel(Integer taskLevel) {
/* 234 */     this.taskLevel = taskLevel;
/*     */   }
/*     */ 
/*     */   @XmlJavaTypeAdapter(DateSqlAdapter.class)
/*     */   public Date getStartDate() {
/* 239 */     return this.startDate;
/*     */   }
/*     */ 
/*     */   public void setStartDate(Date startDate) {
/* 243 */     this.startDate = startDate;
/*     */   }
/*     */ 
/*     */   @XmlJavaTypeAdapter(DateSqlAdapter.class)
/*     */   public Date getEndDate() {
/* 248 */     return this.endDate;
/*     */   }
/*     */ 
/*     */   public void setEndDate(Date endDate) {
/* 252 */     this.endDate = endDate;
/*     */   }
/*     */ 
/*     */   public Integer getStartTime() {
/* 256 */     return this.startTime;
/*     */   }
/*     */ 
/*     */   public void setStartTime(Integer startTime) {
/* 260 */     this.startTime = startTime;
/*     */   }
/*     */ 
/*     */   public Integer getEndTime() {
/* 264 */     return this.endTime;
/*     */   }
/*     */ 
/*     */   public void setEndTime(Integer endTime) {
/* 268 */     this.endTime = endTime;
/*     */   }
/*     */ 
/*     */   public Integer getControl() {
/* 272 */     return this.control;
/*     */   }
/*     */ 
/*     */   public void setControl(Integer control) {
/* 276 */     this.control = control;
/*     */   }
/*     */ 
/*     */   public String getSysId() {
/* 280 */     return this.sysId;
/*     */   }
/*     */ 
/*     */   public void setSysId(String sysId) {
/* 284 */     this.sysId = sysId;
/*     */   }
/*     */ 
/*     */   public String getContent() {
/* 288 */     return this.content;
/*     */   }
/*     */ 
/*     */   public void setContent(String content) {
/* 292 */     this.content = content;
/*     */   }
/*     */ 
/*     */   public String getIsTestTask() {
/* 296 */     return this.isTestTask;
/*     */   }
/*     */ 
/*     */   public void setIsTestTask(String isTestTask) {
/* 300 */     this.isTestTask = isTestTask;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.BsTask
 * JD-Core Version:    0.6.2
 */
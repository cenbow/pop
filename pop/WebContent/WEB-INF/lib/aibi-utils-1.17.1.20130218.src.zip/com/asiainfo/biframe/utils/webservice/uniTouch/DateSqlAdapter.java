/*    */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*    */ 
/*    */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*    */ 
/*    */ public class DateSqlAdapter extends XmlAdapter<java.util.Date, java.sql.Date>
/*    */ {
/*    */   public java.util.Date marshal(java.sql.Date v)
/*    */     throws Exception
/*    */   {
/*  9 */     return new java.util.Date(v.getTime());
/*    */   }
/*    */ 
/*    */   public java.sql.Date unmarshal(java.util.Date v) throws Exception
/*    */   {
/* 14 */     return new java.sql.Date(v.getTime());
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.DateSqlAdapter
 * JD-Core Version:    0.6.2
 */
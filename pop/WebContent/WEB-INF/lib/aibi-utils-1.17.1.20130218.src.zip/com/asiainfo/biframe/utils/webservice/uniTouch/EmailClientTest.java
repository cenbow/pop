/*    */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class EmailClientTest
/*    */ {
/*    */   private static final String url = "http://10.1.251.189:28051/uniTouch/services/InstantPushImpl";
/*    */ 
/*    */   public static void main(String[] agrs)
/*    */     throws Exception
/*    */   {
/*  9 */     String phoens = "chenhui2@asiainfo.com;hanxh@asiainfo.com";
/* 10 */     String content = "风雨送春归，飞雪迎春到。\r\n已是悬崖百丈冰，犹有花枝俏。\r\n俏也不争春，只把春来报。\r\n待到山花烂漫时，你我丛中笑\r\n";
/* 11 */     String filePath = "";
/* 12 */     TaskModel model = new TaskModel();
/* 13 */     model.setSysId("AI-CITY");
/* 14 */     model.setSubsysId("999");
/* 15 */     model.setCreator("Admin");
/* 16 */     model.setSubject("你的邮箱中病毒了，请及时和相关人员联系");
/* 17 */     model.setContent(content);
/* 18 */     model.setPhones(phoens);
/* 19 */     UniTouchClient ic = UniTouchClient.getInstance("http://10.1.251.189:28051/uniTouch/services/InstantPushImpl");
/* 20 */     String result = null;
/*    */     try
/*    */     {
/* 23 */       result = ic.sendMailRequest(model, filePath);
/*    */     } catch (Exception e) {
/* 25 */       e.printStackTrace();
/*    */     }
/* 27 */     if (result.equals("0"))
/* 28 */       System.out.println("提交数据成功");
/*    */     else
/* 30 */       System.out.println("提交数据失败");
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.EmailClientTest
 * JD-Core Version:    0.6.2
 */
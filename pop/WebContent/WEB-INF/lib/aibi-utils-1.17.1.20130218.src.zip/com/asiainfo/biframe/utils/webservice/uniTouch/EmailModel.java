/*     */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*     */ 
/*     */ import java.io.File;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.FileDataSource;
/*     */ 
/*     */ public class EmailModel
/*     */ {
/*     */   private String[] adresses;
/*     */   private String subject;
/*     */   private String content;
/*     */   private DataHandler[] dataHandlers;
/*     */   private String[] attachNames;
/*     */ 
/*     */   public EmailModel()
/*     */   {
/*     */   }
/*     */ 
/*     */   public EmailModel(String[] adresses, String subject, String content, DataHandler[] dataHandlers, String[] attachNames)
/*     */   {
/*  74 */     this.adresses = adresses;
/*  75 */     this.subject = subject;
/*  76 */     this.content = content;
/*  77 */     this.dataHandlers = dataHandlers;
/*  78 */     this.attachNames = attachNames;
/*     */   }
/*     */ 
/*     */   public EmailModel(String[] adresses, String subject, String content, File[] files)
/*     */   {
/*  84 */     this.adresses = adresses;
/*  85 */     this.subject = subject;
/*  86 */     this.content = content;
/*  87 */     if ((files != null) && (files.length > 0)) {
/*  88 */       this.dataHandlers = new DataHandler[files.length];
/*  89 */       this.attachNames = new String[files.length];
/*  90 */       for (int i = 0; i < files.length; i++) {
/*  91 */         this.attachNames[i] = files[i].getName();
/*  92 */         this.dataHandlers[i] = new DataHandler(new FileDataSource(files[i]));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public EmailModel(String[] adresses, String subject, String content, String[] fileNames)
/*     */   {
/* 100 */     this.adresses = adresses;
/* 101 */     this.subject = subject;
/* 102 */     this.content = content;
/* 103 */     if ((fileNames != null) && (fileNames.length > 0)) {
/* 104 */       this.dataHandlers = new DataHandler[fileNames.length];
/* 105 */       this.attachNames = new String[fileNames.length];
/* 106 */       for (int i = 0; i < fileNames.length; i++) {
/* 107 */         File file = new File(fileNames[i]);
/* 108 */         if (!file.exists()) {
/* 109 */           throw new RuntimeException("File not found !" + file);
/*     */         }
/* 111 */         this.attachNames[i] = file.getName();
/* 112 */         this.dataHandlers[i] = new DataHandler(new FileDataSource(file));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getAdresses()
/*     */   {
/* 124 */     return this.adresses;
/*     */   }
/*     */ 
/*     */   public void setAdresses(String[] adresses)
/*     */   {
/* 134 */     this.adresses = adresses;
/*     */   }
/*     */ 
/*     */   public String getSubject()
/*     */   {
/* 144 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject)
/*     */   {
/* 154 */     this.subject = subject;
/*     */   }
/*     */ 
/*     */   public String getContent()
/*     */   {
/* 164 */     return this.content;
/*     */   }
/*     */ 
/*     */   public void setContent(String content)
/*     */   {
/* 174 */     this.content = content;
/*     */   }
/*     */ 
/*     */   public DataHandler[] getDataHandlers()
/*     */   {
/* 184 */     return this.dataHandlers;
/*     */   }
/*     */ 
/*     */   public void setDataHandlers(DataHandler[] dataHandlers)
/*     */   {
/* 194 */     this.dataHandlers = dataHandlers;
/*     */   }
/*     */ 
/*     */   public String[] getAttachNames()
/*     */   {
/* 201 */     return this.attachNames;
/*     */   }
/*     */ 
/*     */   public void setAttachNames(String[] attachNames)
/*     */   {
/* 209 */     this.attachNames = attachNames;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.EmailModel
 * JD-Core Version:    0.6.2
 */
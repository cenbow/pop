package com.asiainfo.biframe.utils.webservice.uniTouch;

import javax.jws.WebService;

@WebService(targetNamespace="http://com.asiainfo.suite/unitouch")
public abstract interface ITaskMmsService
{
  public abstract void saveImmediateTask(String paramString, MmsModel paramMmsModel)
    throws Exception;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.ITaskMmsService
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*     */ 
/*     */ import java.io.File;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.FileDataSource;
/*     */ 
/*     */ public class MmsModel
/*     */ {
/*     */   private String[] phones;
/*     */   private String subject;
/*     */   private DataHandler dataHandler;
/*     */ 
/*     */   public MmsModel()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MmsModel(String[] phones, String subject, DataHandler dataHandler)
/*     */   {
/*  67 */     this.phones = phones;
/*  68 */     this.subject = subject;
/*  69 */     this.dataHandler = dataHandler;
/*     */   }
/*     */ 
/*     */   public MmsModel(String[] phones, String subject, File fileName)
/*     */   {
/*  81 */     this.phones = phones;
/*  82 */     this.subject = subject;
/*  83 */     this.dataHandler = new DataHandler(new FileDataSource(fileName));
/*     */   }
/*     */ 
/*     */   public MmsModel(String[] phones, String subject, String fileName)
/*     */   {
/*  95 */     this.phones = phones;
/*  96 */     this.subject = subject;
/*  97 */     this.dataHandler = new DataHandler(new FileDataSource(fileName));
/*     */   }
/*     */ 
/*     */   public String[] getPhones() {
/* 101 */     return this.phones;
/*     */   }
/*     */ 
/*     */   public void setPhones(String[] phones) {
/* 105 */     this.phones = phones;
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/* 109 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) {
/* 113 */     this.subject = subject;
/*     */   }
/*     */ 
/*     */   public DataHandler getDataHandler() {
/* 117 */     return this.dataHandler;
/*     */   }
/*     */ 
/*     */   public void setDataHandler(DataHandler dataHandler) {
/* 121 */     this.dataHandler = dataHandler;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.MmsModel
 * JD-Core Version:    0.6.2
 */
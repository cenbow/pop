/*     */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*     */ 
/*     */ public class TaskModel
/*     */ {
/*     */   private String sysId;
/*     */   private String subsysId;
/*     */   private String channelId;
/*     */   private String id;
/*     */   private String name;
/*     */   private String creator;
/*     */   private String startDate;
/*     */   private String endDate;
/*     */   private String startTime;
/*     */   private String endTime;
/*     */   private String subject;
/*     */   private String type;
/*     */   private String content;
/*     */   private String phones;
/*     */ 
/*     */   public String getPhones()
/*     */   {
/*  33 */     return this.phones;
/*     */   }
/*     */   public void setPhones(String phoens) {
/*  36 */     this.phones = phoens;
/*     */   }
/*     */   public String getChannelId() {
/*  39 */     return this.channelId;
/*     */   }
/*     */   public void setChannelId(String channelId) {
/*  42 */     this.channelId = channelId;
/*     */   }
/*     */   public String getContent() {
/*  45 */     return this.content;
/*     */   }
/*     */   public void setContent(String content) {
/*  48 */     this.content = content;
/*     */   }
/*     */   public String getSysId() {
/*  51 */     return this.sysId;
/*     */   }
/*     */   public void setSysId(String sysId) {
/*  54 */     this.sysId = sysId;
/*     */   }
/*     */   public String getSubsysId() {
/*  57 */     return this.subsysId;
/*     */   }
/*     */   public void setSubsysId(String subsysId) {
/*  60 */     this.subsysId = subsysId;
/*     */   }
/*     */   public String getId() {
/*  63 */     return this.id;
/*     */   }
/*     */   public void setId(String id) {
/*  66 */     this.id = id;
/*     */   }
/*     */   public String getName() {
/*  69 */     return this.name;
/*     */   }
/*     */   public void setName(String name) {
/*  72 */     this.name = name;
/*     */   }
/*     */   public String getCreator() {
/*  75 */     return this.creator;
/*     */   }
/*     */   public void setCreator(String creator) {
/*  78 */     this.creator = creator;
/*     */   }
/*     */   public String getStartDate() {
/*  81 */     return this.startDate;
/*     */   }
/*     */   public void setStartDate(String startDate) {
/*  84 */     this.startDate = startDate;
/*     */   }
/*     */   public String getEndDate() {
/*  87 */     return this.endDate;
/*     */   }
/*     */   public void setEndDate(String endDate) {
/*  90 */     this.endDate = endDate;
/*     */   }
/*     */   public String getStartTime() {
/*  93 */     return this.startTime;
/*     */   }
/*     */   public void setStartTime(String startTime) {
/*  96 */     this.startTime = startTime;
/*     */   }
/*     */   public String getEndTime() {
/*  99 */     return this.endTime;
/*     */   }
/*     */   public void setEndTime(String endTime) {
/* 102 */     this.endTime = endTime;
/*     */   }
/*     */   public String getSubject() {
/* 105 */     return this.subject;
/*     */   }
/*     */   public void setSubject(String subject) {
/* 108 */     this.subject = subject;
/*     */   }
/*     */   public String getType() {
/* 111 */     return this.type;
/*     */   }
/*     */   public void setType(String type) {
/* 114 */     this.type = type;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.TaskModel
 * JD-Core Version:    0.6.2
 */
/*    */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*    */ 
/*    */ import java.sql.Timestamp;
/*    */ import java.util.Date;
/*    */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*    */ 
/*    */ public class TimestampAdapter extends XmlAdapter<Date, Timestamp>
/*    */ {
/*    */   public Date marshal(Timestamp v)
/*    */     throws Exception
/*    */   {
/* 11 */     return new Date(v.getTime());
/*    */   }
/*    */ 
/*    */   public Timestamp unmarshal(Date v) throws Exception
/*    */   {
/* 16 */     return new Timestamp(v.getTime());
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.TimestampAdapter
 * JD-Core Version:    0.6.2
 */
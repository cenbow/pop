/*     */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.config.Configure;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.URL;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UniTouchClient
/*     */   implements IUniTouchClient
/*     */ {
/*  37 */   private static Logger log = Logger.getLogger(UniTouchClient.class);
/*     */ 
/*  39 */   private static IUniTouchClient iuniTouchClient = null;
/*     */ 
/*  42 */   private static UniTouchClient uniTouchClient = new UniTouchClient();
/*     */ 
/*     */   public static void main(String[] args) {
/*  45 */     UniTouchClient client = getInstance("wsurl");
/*     */     try {
/*  47 */       TaskModel taskModel = new TaskModel();
/*  48 */       taskModel.setSubsysId("KKP");
/*  49 */       taskModel.setSubject("sms mary ");
/*  50 */       client.sendSmsRequest(taskModel, "1521045");
/*     */ 
/*  52 */       taskModel = new TaskModel();
/*  53 */       taskModel.setSubsysId("KKP");
/*  54 */       taskModel.setPhones("a@com;b@com");
/*  55 */       taskModel.setContent("welcome");
/*  56 */       taskModel.setSubject("title");
/*  57 */       client.sendMailRequest(taskModel, "1521045");
/*     */     } catch (Exception e) {
/*  59 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static UniTouchClient getInstance(String url)
/*     */   {
/*  67 */     log.debug("----UniTouchClient-----url-->>[" + url + "]");
/*  68 */     IUniTouchClient client = null;
/*     */     try {
/*  70 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */ 
/*  72 */       URL configUrl = classLoader.getResource("config/aibi_utils/utils.properties");
/*     */ 
/*  74 */       String filePath = configUrl.getFile();
/*  75 */       log.debug("----UniTouchClient-----config path-->>[" + filePath + "]");
/*     */ 
/*  77 */       Configure.getInstance().addConfFileName("utils", filePath);
/*  78 */       String className = Configure.getInstance().getProperty("utils", "UniTouchClient_ImplClassName");
/*     */ 
/*  80 */       log.debug("----UniTouchClient-----className-->>[" + className + "]");
/*     */ 
/*  83 */       Constructor[] cts = Class.forName(className).getDeclaredConstructors();
/*     */ 
/*  85 */       client = (IUniTouchClient)cts[0].newInstance(new Object[] { url });
/*  86 */       iuniTouchClient = client;
/*     */     } catch (Exception e) {
/*  88 */       log.error("create IUniTouchClient with error: " + e.getMessage());
/*     */     }
/*  90 */     return uniTouchClient;
/*     */   }
/*     */ 
/*     */   public String sendMailRequest(TaskModel model, String filePath)
/*     */     throws Exception
/*     */   {
/* 105 */     return iuniTouchClient.sendMailRequest(model, filePath);
/*     */   }
/*     */ 
/*     */   public String sendSmsRequest(TaskModel model, String phones)
/*     */     throws Exception
/*     */   {
/* 119 */     String re = null;
/*     */     try {
/* 121 */       re = iuniTouchClient.sendSmsRequest(model, phones);
/*     */     } catch (Exception e) {
/* 123 */       log.error("UniTouchClient.sendSmsRequest() fail:" + e.getMessage());
/*     */     }
/*     */ 
/* 126 */     return re;
/*     */   }
/*     */ 
/*     */   public String sendMmsRequest(TaskModel taskMmodel, MmsModel mmsModel) throws Exception
/*     */   {
/* 131 */     return iuniTouchClient.sendMmsRequest(taskMmodel, mmsModel);
/*     */   }
/*     */ 
/*     */   public String sendEmailRequest(TaskModel taskModel, EmailModel emailModel)
/*     */     throws Exception
/*     */   {
/* 146 */     return iuniTouchClient.sendEmailRequest(taskModel, emailModel);
/*     */   }
/*     */ 
/*     */   public String sendSmsTask(TaskModel model, String phones)
/*     */     throws Exception
/*     */   {
/* 160 */     String re = null;
/*     */     try {
/* 162 */       re = iuniTouchClient.sendSmsTask(model, phones);
/*     */     } catch (Exception e) {
/* 164 */       log.error("UniTouchClient.sendSmsTask() fail:" + e.getMessage());
/*     */     }
/*     */ 
/* 167 */     return re;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.UniTouchClient
 * JD-Core Version:    0.6.2
 */
/*     */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.string.StringUtil;
/*     */ import java.io.File;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.FileDataSource;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.apache.axiom.om.OMAbstractFactory;
/*     */ import org.apache.axiom.om.OMElement;
/*     */ import org.apache.axiom.om.OMFactory;
/*     */ import org.apache.axiom.om.OMNamespace;
/*     */ import org.apache.axiom.om.OMText;
/*     */ import org.apache.axis2.AxisFault;
/*     */ import org.apache.axis2.addressing.EndpointReference;
/*     */ import org.apache.axis2.client.Options;
/*     */ import org.apache.axis2.client.ServiceClient;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UniTouchClientImpl
/*     */   implements IUniTouchClient
/*     */ {
/*  48 */   private static Logger log = Logger.getLogger(UniTouchClientImpl.class);
/*     */   private String serviceUrl;
/*  52 */   private String namespace = "http://com/asiainfo/instantsend/xsd";
/*     */ 
/*     */   public UniTouchClientImpl(String url)
/*     */   {
/*  56 */     this.serviceUrl = url;
/*     */   }
/*     */ 
/*     */   public String sendMailRequest(TaskModel model, String filePath)
/*     */     throws Exception
/*     */   {
/*  71 */     long time = System.currentTimeMillis();
/*  72 */     String result = "9";
/*     */     try {
/*  74 */       OMElement data = buildMailUploadEnvelope(model, filePath);
/*  75 */       Options options = buildOptions();
/*  76 */       ServiceClient sender = new ServiceClient();
/*  77 */       sender.setOptions(options);
/*  78 */       OMElement ome = sender.sendReceive(data);
/*  79 */       log.info(ome);
/*  80 */       result = ome.getFirstChildWithName(new QName(this.namespace, "code")).getText();
/*     */ 
/*  82 */       log.info("uploading file takes " + (System.currentTimeMillis() - time) + " ms ");
/*     */     }
/*     */     catch (Exception e) {
/*  85 */       e.printStackTrace();
/*  86 */       log.error("", e);
/*     */     }
/*  88 */     log.info("--sendMailRequest--result----" + result);
/*  89 */     return result;
/*     */   }
/*     */ 
/*     */   private OMElement buildMailUploadEnvelope(TaskModel model, String filePath) {
/*  93 */     OMFactory fac = OMAbstractFactory.getOMFactory();
/*  94 */     OMNamespace omNs = fac.createOMNamespace(this.namespace, "email");
/*  95 */     OMElement data = fac.createOMElement("instantEmailInfo", omNs);
/*     */ 
/*  97 */     OMElement sysId = fac.createOMElement("sysId", omNs);
/*  98 */     sysId.addChild(fac.createOMText(sysId, model.getSysId()));
/*  99 */     data.addChild(sysId);
/*     */ 
/* 101 */     OMElement subsysId = fac.createOMElement("subsysId", omNs);
/* 102 */     subsysId.addChild(fac.createOMText(subsysId, model.getSubsysId()));
/* 103 */     data.addChild(subsysId);
/*     */ 
/* 105 */     OMElement channelId = fac.createOMElement("channelId", omNs);
/* 106 */     channelId.addChild(fac.createOMText(channelId, "EMAIL1"));
/* 107 */     data.addChild(channelId);
/*     */ 
/* 109 */     OMElement title = fac.createOMElement("title", omNs);
/* 110 */     title.addChild(fac.createOMText(title, model.getSubject()));
/* 111 */     data.addChild(title);
/*     */ 
/* 113 */     OMElement content = fac.createOMElement("content", omNs);
/* 114 */     content.addChild(fac.createOMText(content, model.getContent()));
/* 115 */     data.addChild(content);
/*     */ 
/* 117 */     OMElement creator = fac.createOMElement("creator", omNs);
/* 118 */     creator.addChild(fac.createOMText(creator, model.getCreator()));
/* 119 */     data.addChild(creator);
/*     */ 
/* 121 */     OMElement list = fac.createOMElement("phones", omNs);
/* 122 */     list.addChild(fac.createOMText(list, model.getPhones()));
/* 123 */     data.addChild(list);
/*     */ 
/* 125 */     String name = "";
/* 126 */     if (StringUtil.isNotEmpty(filePath)) {
/* 127 */       name = filePath.substring(filePath.indexOf(File.separator) + 1);
/*     */     }
/* 129 */     OMElement fileName = fac.createOMElement("fileName", omNs);
/* 130 */     fileName.addChild(fac.createOMText(fileName, name));
/* 131 */     data.addChild(fileName);
/*     */ 
/* 133 */     if (StringUtil.isEmpty(filePath)) {
/* 134 */       OMElement file = fac.createOMElement("attach", omNs);
/* 135 */       file.addChild(fac.createOMText(file, ""));
/* 136 */       data.addChild(file);
/*     */     } else {
/* 138 */       OMElement file = fac.createOMElement("attach", omNs);
/* 139 */       FileDataSource mmsFileSource = new FileDataSource(filePath);
/* 140 */       DataHandler dh = new DataHandler(mmsFileSource);
/* 141 */       OMText mmsData = fac.createOMText(dh, true);
/* 142 */       file.addChild(mmsData);
/* 143 */       data.addChild(file);
/*     */     }
/*     */ 
/* 146 */     return data;
/*     */   }
/*     */ 
/*     */   public String sendSmsRequest(TaskModel model, String phones)
/*     */     throws XMLStreamException
/*     */   {
/* 160 */     long time = System.currentTimeMillis();
/* 161 */     String result = "9";
/*     */     try {
/* 163 */       OMElement data = buildSmsUploadEnvelope(model, phones);
/* 164 */       Options options = buildOptions();
/* 165 */       ServiceClient sender = new ServiceClient();
/* 166 */       sender.setOptions(options);
/* 167 */       OMElement ome = sender.sendReceive(data);
/*     */ 
/* 170 */       result = ome.getFirstChildWithName(new QName(this.namespace, "code")).getText();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 176 */       log.error("", e);
/*     */     }
/* 178 */     return result;
/*     */   }
/*     */ 
/*     */   private OMElement buildSmsUploadEnvelope(TaskModel model, String phones) {
/* 182 */     OMFactory fac = OMAbstractFactory.getOMFactory();
/* 183 */     OMNamespace omNs = fac.createOMNamespace(this.namespace, "mms");
/* 184 */     OMElement data = fac.createOMElement("instantSmsInfo", omNs);
/*     */ 
/* 186 */     OMElement sysId = fac.createOMElement("sysId", omNs);
/* 187 */     sysId.addChild(fac.createOMText(sysId, model.getSysId()));
/* 188 */     data.addChild(sysId);
/*     */ 
/* 190 */     OMElement subsysId = fac.createOMElement("subsysId", omNs);
/* 191 */     subsysId.addChild(fac.createOMText(subsysId, model.getSubsysId()));
/* 192 */     data.addChild(subsysId);
/*     */ 
/* 194 */     OMElement channelId = fac.createOMElement("channelId", omNs);
/* 195 */     channelId.addChild(fac.createOMText(channelId, model.getChannelId()));
/* 196 */     data.addChild(channelId);
/*     */ 
/* 198 */     OMElement content = fac.createOMElement("content", omNs);
/* 199 */     content.addChild(fac.createOMText(content, model.getContent()));
/* 200 */     data.addChild(content);
/*     */ 
/* 202 */     OMElement startTime = fac.createOMElement("startTime", omNs);
/* 203 */     startTime.addChild(fac.createOMText(startTime, model.getStartTime()));
/* 204 */     data.addChild(startTime);
/*     */ 
/* 206 */     OMElement endTime = fac.createOMElement("endTime", omNs);
/* 207 */     endTime.addChild(fac.createOMText(endTime, model.getEndTime()));
/* 208 */     data.addChild(endTime);
/*     */ 
/* 210 */     OMElement creator = fac.createOMElement("creator", omNs);
/* 211 */     creator.addChild(fac.createOMText(creator, model.getCreator()));
/* 212 */     data.addChild(creator);
/*     */ 
/* 214 */     OMElement list = fac.createOMElement("phones", omNs);
/* 215 */     list.addChild(fac.createOMText(list, phones));
/* 216 */     data.addChild(list);
/*     */ 
/* 218 */     return data;
/*     */   }
/*     */ 
/*     */   public String sendMmsTextFileRequest(TaskModel model, String phones)
/*     */     throws Exception
/*     */   {
/* 232 */     long time = System.currentTimeMillis();
/* 233 */     String result = "9";
/*     */     try {
/* 235 */       OMElement data = buildMmsTextFileUploadEnvelope(model, phones);
/* 236 */       Options options = buildOptions();
/* 237 */       ServiceClient sender = new ServiceClient();
/* 238 */       sender.setOptions(options);
/* 239 */       OMElement ome = sender.sendReceive(data);
/*     */ 
/* 241 */       result = ome.getFirstChildWithName(new QName(this.namespace, "code")).getText();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 246 */       log.error("", e);
/*     */     }
/* 248 */     return result;
/*     */   }
/*     */ 
/*     */   private OMElement buildMmsTextFileUploadEnvelope(TaskModel model, String phones)
/*     */   {
/* 253 */     OMFactory fac = OMAbstractFactory.getOMFactory();
/* 254 */     OMNamespace omNs = fac.createOMNamespace(this.namespace, "mms");
/* 255 */     OMElement data = fac.createOMElement("instantMmsStrInfo", omNs);
/*     */ 
/* 257 */     OMElement sysId = fac.createOMElement("sysId", omNs);
/* 258 */     sysId.addChild(fac.createOMText(sysId, model.getSysId()));
/* 259 */     data.addChild(sysId);
/*     */ 
/* 261 */     OMElement subsysId = fac.createOMElement("subsysId", omNs);
/* 262 */     subsysId.addChild(fac.createOMText(subsysId, model.getSubsysId()));
/* 263 */     data.addChild(subsysId);
/*     */ 
/* 265 */     OMElement channelId = fac.createOMElement("channelId", omNs);
/* 266 */     channelId.addChild(fac.createOMText(channelId, model.getChannelId()));
/* 267 */     data.addChild(channelId);
/*     */ 
/* 269 */     OMElement startTime = fac.createOMElement("startTime", omNs);
/* 270 */     startTime.addChild(fac.createOMText(startTime, model.getStartTime()));
/* 271 */     data.addChild(startTime);
/*     */ 
/* 273 */     OMElement endTime = fac.createOMElement("endTime", omNs);
/* 274 */     endTime.addChild(fac.createOMText(endTime, model.getEndTime()));
/* 275 */     data.addChild(endTime);
/*     */ 
/* 277 */     OMElement subject = fac.createOMElement("subject", omNs);
/* 278 */     subject.addChild(fac.createOMText(subject, model.getSubject()));
/* 279 */     data.addChild(subject);
/*     */ 
/* 281 */     OMElement list = fac.createOMElement("phones", omNs);
/* 282 */     list.addChild(fac.createOMText(list, phones));
/* 283 */     data.addChild(list);
/*     */ 
/* 285 */     OMElement creator = fac.createOMElement("creator", omNs);
/* 286 */     creator.addChild(fac.createOMText(creator, ""));
/* 287 */     data.addChild(creator);
/*     */ 
/* 289 */     OMElement content = fac.createOMElement("content", omNs);
/* 290 */     content.addChild(fac.createOMText(content, model.getContent()));
/* 291 */     data.addChild(content);
/*     */ 
/* 293 */     return data;
/*     */   }
/*     */ 
/*     */   public String sendMmsStrRequest(TaskModel model, String phones)
/*     */     throws XMLStreamException
/*     */   {
/* 307 */     long time = System.currentTimeMillis();
/* 308 */     String result = "9";
/*     */     try
/*     */     {
/* 311 */       OMElement data = buildMmsStrUploadEnvelope(model, phones);
/* 312 */       Options options = buildOptions();
/* 313 */       ServiceClient sender = new ServiceClient();
/* 314 */       sender.setOptions(options);
/* 315 */       OMElement ome = sender.sendReceive(data);
/* 316 */       log.info(ome);
/* 317 */       result = ome.getFirstChildWithName(new QName(this.namespace, "code")).getText();
/*     */ 
/* 319 */       log.info("uploading file takes " + (System.currentTimeMillis() - time) + " ms ");
/*     */     }
/*     */     catch (Exception e) {
/* 322 */       log.error("", e);
/*     */     }
/* 324 */     return result;
/*     */   }
/*     */ 
/*     */   private OMElement buildMmsStrUploadEnvelope(TaskModel model, String phones) {
/* 328 */     OMFactory fac = OMAbstractFactory.getOMFactory();
/* 329 */     OMNamespace omNs = fac.createOMNamespace(this.namespace, "mms");
/* 330 */     OMElement data = fac.createOMElement("instantMmsStrInfo", omNs);
/*     */ 
/* 332 */     OMElement sysId = fac.createOMElement("sysId", omNs);
/* 333 */     sysId.addChild(fac.createOMText(sysId, model.getSysId()));
/* 334 */     data.addChild(sysId);
/*     */ 
/* 336 */     OMElement subsysId = fac.createOMElement("subsysId", omNs);
/* 337 */     subsysId.addChild(fac.createOMText(subsysId, model.getSubsysId()));
/* 338 */     data.addChild(subsysId);
/*     */ 
/* 340 */     OMElement channelId = fac.createOMElement("channelId", omNs);
/* 341 */     channelId.addChild(fac.createOMText(channelId, model.getChannelId()));
/* 342 */     data.addChild(channelId);
/*     */ 
/* 344 */     OMElement startTime = fac.createOMElement("startTime", omNs);
/* 345 */     startTime.addChild(fac.createOMText(startTime, model.getStartTime()));
/* 346 */     data.addChild(startTime);
/*     */ 
/* 348 */     OMElement endTime = fac.createOMElement("endTime", omNs);
/* 349 */     endTime.addChild(fac.createOMText(endTime, model.getEndTime()));
/* 350 */     data.addChild(endTime);
/*     */ 
/* 352 */     OMElement subject = fac.createOMElement("subject", omNs);
/* 353 */     subject.addChild(fac.createOMText(subject, model.getSubject()));
/* 354 */     data.addChild(subject);
/*     */ 
/* 356 */     OMElement list = fac.createOMElement("phones", omNs);
/* 357 */     list.addChild(fac.createOMText(list, phones));
/* 358 */     data.addChild(list);
/*     */ 
/* 360 */     OMElement content = fac.createOMElement("content", omNs);
/* 361 */     content.addChild(fac.createOMText(content, model.getContent()));
/* 362 */     data.addChild(content);
/*     */ 
/* 364 */     return data;
/*     */   }
/*     */ 
/*     */   public String sendMmsFileRequest(String phones, File mmsFile, TaskModel model)
/*     */     throws Exception
/*     */   {
/* 379 */     long time = System.currentTimeMillis();
/* 380 */     String result = "9";
/*     */     try {
/* 382 */       OMElement data = buildMmsFileUploadEnvelope(phones, mmsFile, model);
/* 383 */       Options options = buildOptions();
/* 384 */       ServiceClient sender = new ServiceClient();
/* 385 */       sender.setOptions(options);
/* 386 */       OMElement ome = sender.sendReceive(data);
/* 387 */       log.info(ome);
/* 388 */       result = ome.getFirstChildWithName(new QName(this.namespace, "code")).getText();
/*     */ 
/* 390 */       log.info("uploading file takes " + (System.currentTimeMillis() - time) + " ms ");
/*     */     }
/*     */     catch (Exception e) {
/* 393 */       log.error("", e);
/*     */     }
/* 395 */     return result;
/*     */   }
/*     */ 
/*     */   private OMElement buildMmsFileUploadEnvelope(String phones, File mmsFile, TaskModel model)
/*     */   {
/* 400 */     OMFactory fac = OMAbstractFactory.getOMFactory();
/* 401 */     OMNamespace omNs = fac.createOMNamespace(this.namespace, "mms");
/* 402 */     OMElement data = fac.createOMElement("instantMmsInfo", omNs);
/*     */ 
/* 404 */     OMElement sysId = fac.createOMElement("sysId", omNs);
/* 405 */     sysId.addChild(fac.createOMText(sysId, model.getSysId()));
/* 406 */     data.addChild(sysId);
/*     */ 
/* 408 */     OMElement subsysId = fac.createOMElement("subsysId", omNs);
/* 409 */     subsysId.addChild(fac.createOMText(subsysId, model.getSubsysId()));
/* 410 */     data.addChild(subsysId);
/*     */ 
/* 412 */     OMElement channelId = fac.createOMElement("channelId", omNs);
/* 413 */     channelId.addChild(fac.createOMText(channelId, model.getChannelId()));
/* 414 */     data.addChild(channelId);
/*     */ 
/* 416 */     OMElement content = fac.createOMElement("subject", omNs);
/* 417 */     content.addChild(fac.createOMText(content, model.getSubject()));
/* 418 */     data.addChild(content);
/*     */ 
/* 420 */     OMElement startTime = fac.createOMElement("startTime", omNs);
/* 421 */     startTime.addChild(fac.createOMText(startTime, model.getStartTime()));
/* 422 */     data.addChild(startTime);
/*     */ 
/* 424 */     OMElement endTime = fac.createOMElement("endTime", omNs);
/* 425 */     endTime.addChild(fac.createOMText(endTime, model.getEndTime()));
/* 426 */     data.addChild(endTime);
/*     */ 
/* 428 */     OMElement mmsFileE = fac.createOMElement("content", omNs);
/* 429 */     FileDataSource mmsFileSource = new FileDataSource(mmsFile);
/* 430 */     DataHandler mmsFileEDH = new DataHandler(mmsFileSource);
/* 431 */     OMText mmsData = fac.createOMText(mmsFileEDH, true);
/* 432 */     mmsFileE.addChild(mmsData);
/* 433 */     data.addChild(mmsFileE);
/*     */ 
/* 435 */     OMElement creator = fac.createOMElement("creator", omNs);
/* 436 */     creator.addChild(fac.createOMText(creator, model.getCreator()));
/* 437 */     data.addChild(creator);
/*     */ 
/* 439 */     OMElement list = fac.createOMElement("phones", omNs);
/* 440 */     list.addChild(fac.createOMText(list, phones));
/* 441 */     data.addChild(list);
/*     */ 
/* 443 */     return data;
/*     */   }
/*     */ 
/*     */   public String sendTaskSmsRequest(TaskModel model, String phones)
/*     */     throws Exception
/*     */   {
/* 457 */     long time = System.currentTimeMillis();
/* 458 */     String result = "9";
/*     */     try {
/* 460 */       OMElement data = buildTaskUploadEnvelope(model, phones);
/* 461 */       Options options = buildOptions();
/* 462 */       ServiceClient sender = new ServiceClient();
/* 463 */       sender.setOptions(options);
/* 464 */       OMElement ome = sender.sendReceive(data);
/* 465 */       log.info(ome);
/* 466 */       result = ome.getFirstChildWithName(new QName(this.namespace, "code")).getText();
/*     */ 
/* 468 */       log.info("uploading file takes " + (System.currentTimeMillis() - time) + " ms ");
/*     */     }
/*     */     catch (Exception e) {
/* 471 */       log.error("", e);
/*     */     }
/* 473 */     return result;
/*     */   }
/*     */ 
/*     */   private OMElement buildTaskUploadEnvelope(TaskModel model, String phones) {
/* 477 */     OMFactory fac = OMAbstractFactory.getOMFactory();
/* 478 */     OMNamespace omNs = fac.createOMNamespace(this.namespace, "sms");
/* 479 */     OMElement data = fac.createOMElement("batchSmsListInfo", omNs);
/*     */ 
/* 481 */     OMElement sysId = fac.createOMElement("sysId", omNs);
/* 482 */     sysId.addChild(fac.createOMText(sysId, model.getSysId()));
/* 483 */     data.addChild(sysId);
/*     */ 
/* 485 */     OMElement subsysId = fac.createOMElement("subsysId", omNs);
/* 486 */     subsysId.addChild(fac.createOMText(subsysId, model.getSubsysId()));
/* 487 */     data.addChild(subsysId);
/*     */ 
/* 489 */     OMElement outId = fac.createOMElement("id", omNs);
/* 490 */     outId.addChild(fac.createOMText(outId, model.getId()));
/* 491 */     data.addChild(outId);
/*     */ 
/* 493 */     OMElement name = fac.createOMElement("name", omNs);
/* 494 */     name.addChild(fac.createOMText(name, model.getName()));
/* 495 */     data.addChild(name);
/*     */ 
/* 497 */     OMElement channelId = fac.createOMElement("channelId", omNs);
/* 498 */     channelId.addChild(fac.createOMText(channelId, "SMS1"));
/* 499 */     data.addChild(channelId);
/*     */ 
/* 501 */     OMElement creator = fac.createOMElement("creator", omNs);
/* 502 */     creator.addChild(fac.createOMText(creator, model.getCreator()));
/* 503 */     data.addChild(creator);
/*     */ 
/* 505 */     OMElement startDate = fac.createOMElement("startDate", omNs);
/* 506 */     startDate.addChild(fac.createOMText(startDate, model.getStartDate()));
/* 507 */     data.addChild(startDate);
/*     */ 
/* 509 */     OMElement endDate = fac.createOMElement("endDate", omNs);
/* 510 */     endDate.addChild(fac.createOMText(endDate, model.getEndDate()));
/* 511 */     data.addChild(endDate);
/*     */ 
/* 513 */     OMElement startTime = fac.createOMElement("startTime", omNs);
/* 514 */     startTime.addChild(fac.createOMText(startTime, model.getStartTime()));
/* 515 */     data.addChild(startTime);
/*     */ 
/* 517 */     OMElement endTime = fac.createOMElement("endTime", omNs);
/* 518 */     endTime.addChild(fac.createOMText(endTime, model.getEndTime()));
/* 519 */     data.addChild(endTime);
/*     */ 
/* 521 */     OMElement content = fac.createOMElement("subject", omNs);
/* 522 */     content.addChild(fac.createOMText(content, model.getSubject()));
/* 523 */     data.addChild(content);
/*     */ 
/* 525 */     OMElement type = fac.createOMElement("type", omNs);
/* 526 */     type.addChild(fac.createOMText(type, model.getType()));
/* 527 */     data.addChild(type);
/*     */ 
/* 529 */     OMElement list = fac.createOMElement("phones", omNs);
/* 530 */     list.addChild(fac.createOMText(list, phones));
/* 531 */     data.addChild(list);
/*     */ 
/* 533 */     return data;
/*     */   }
/*     */ 
/*     */   public String sendTaskMmsRequest(String phones, File mmsFile, TaskModel model)
/*     */     throws Exception
/*     */   {
/* 548 */     long time = System.currentTimeMillis();
/* 549 */     String result = "9";
/*     */     try {
/* 551 */       OMElement data = buildTaskMmsUploadEnvelope(phones, mmsFile, model);
/* 552 */       Options options = buildOptions();
/* 553 */       ServiceClient sender = new ServiceClient();
/* 554 */       sender.setOptions(options);
/* 555 */       OMElement ome = sender.sendReceive(data);
/* 556 */       log.info(ome);
/* 557 */       result = ome.getFirstChildWithName(new QName(this.namespace, "code")).getText();
/*     */ 
/* 559 */       log.info("uploading file takes " + (System.currentTimeMillis() - time) + " ms ");
/*     */     }
/*     */     catch (Exception e) {
/* 562 */       log.error("", e);
/*     */     }
/* 564 */     return result;
/*     */   }
/*     */ 
/*     */   private OMElement buildTaskMmsUploadEnvelope(String phones, File mmsFile, TaskModel model)
/*     */   {
/* 569 */     OMFactory fac = OMAbstractFactory.getOMFactory();
/* 570 */     OMNamespace omNs = fac.createOMNamespace(this.namespace, "mms");
/* 571 */     OMElement data = fac.createOMElement("batchMmsListInfo", omNs);
/*     */ 
/* 573 */     OMElement sysId = fac.createOMElement("sysId", omNs);
/* 574 */     sysId.addChild(fac.createOMText(sysId, model.getSysId()));
/* 575 */     data.addChild(sysId);
/*     */ 
/* 577 */     OMElement subsysId = fac.createOMElement("subsysId", omNs);
/* 578 */     subsysId.addChild(fac.createOMText(subsysId, model.getSubsysId()));
/* 579 */     data.addChild(subsysId);
/*     */ 
/* 581 */     OMElement outId = fac.createOMElement("id", omNs);
/* 582 */     outId.addChild(fac.createOMText(outId, model.getId()));
/* 583 */     data.addChild(outId);
/*     */ 
/* 585 */     OMElement name = fac.createOMElement("name", omNs);
/* 586 */     name.addChild(fac.createOMText(name, model.getName()));
/* 587 */     data.addChild(name);
/*     */ 
/* 589 */     OMElement channelId = fac.createOMElement("channelId", omNs);
/* 590 */     channelId.addChild(fac.createOMText(channelId, "MMS1"));
/* 591 */     data.addChild(channelId);
/*     */ 
/* 593 */     OMElement creator = fac.createOMElement("creator", omNs);
/* 594 */     creator.addChild(fac.createOMText(creator, model.getCreator()));
/* 595 */     data.addChild(creator);
/*     */ 
/* 597 */     OMElement startDate = fac.createOMElement("startDate", omNs);
/* 598 */     startDate.addChild(fac.createOMText(startDate, model.getStartDate()));
/* 599 */     data.addChild(startDate);
/*     */ 
/* 601 */     OMElement endDate = fac.createOMElement("endDate", omNs);
/* 602 */     endDate.addChild(fac.createOMText(endDate, model.getEndDate()));
/* 603 */     data.addChild(endDate);
/*     */ 
/* 605 */     OMElement startTime = fac.createOMElement("startTime", omNs);
/* 606 */     startTime.addChild(fac.createOMText(startTime, model.getStartTime()));
/* 607 */     data.addChild(startTime);
/*     */ 
/* 609 */     OMElement endTime = fac.createOMElement("endTime", omNs);
/* 610 */     endTime.addChild(fac.createOMText(endTime, model.getEndTime()));
/* 611 */     data.addChild(endTime);
/*     */ 
/* 613 */     OMElement content = fac.createOMElement("subject", omNs);
/* 614 */     content.addChild(fac.createOMText(content, model.getSubject()));
/* 615 */     data.addChild(content);
/*     */ 
/* 617 */     OMElement type = fac.createOMElement("type", omNs);
/* 618 */     type.addChild(fac.createOMText(type, model.getType()));
/* 619 */     data.addChild(type);
/*     */ 
/* 621 */     OMElement list = fac.createOMElement("phones", omNs);
/* 622 */     list.addChild(fac.createOMText(list, phones));
/* 623 */     data.addChild(list);
/*     */ 
/* 625 */     OMElement mmsFileE = fac.createOMElement("content", omNs);
/* 626 */     FileDataSource mmsFileSource = new FileDataSource(mmsFile);
/* 627 */     DataHandler mmsFileEDH = new DataHandler(mmsFileSource);
/* 628 */     OMText mmsData = fac.createOMText(mmsFileEDH, true);
/* 629 */     mmsFileE.addChild(mmsData);
/* 630 */     data.addChild(mmsFileE);
/*     */ 
/* 632 */     return data;
/*     */   }
/*     */ 
/*     */   private Options buildOptions() throws AxisFault {
/* 636 */     Options options = new Options();
/* 637 */     options.setSoapVersionURI("http://schemas.xmlsoap.org/soap/envelope/");
/* 638 */     EndpointReference targetEPR = new EndpointReference(getServiceUrl());
/*     */ 
/* 640 */     options.setTo(targetEPR);
/*     */ 
/* 642 */     options.setProperty("enableMTOM", "true");
/*     */ 
/* 644 */     options.setTransportInProtocol("http");
/* 645 */     options.setTimeOutInMilliSeconds(600000000L);
/* 646 */     return options;
/*     */   }
/*     */ 
/*     */   public String getServiceUrl() {
/* 650 */     return this.serviceUrl;
/*     */   }
/*     */ 
/*     */   public String getNamespace() {
/* 654 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace) {
/* 658 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public void setServiceUrl(String serviceUrl) {
/* 662 */     this.serviceUrl = serviceUrl;
/*     */   }
/*     */ 
/*     */   public String sendMmsRequest(TaskModel taskMmodel, MmsModel mmsModel) throws Exception
/*     */   {
/* 667 */     throw new UnsupportedOperationException("彩信发送没有实现");
/*     */   }
/*     */ 
/*     */   public String sendEmailRequest(TaskModel model, EmailModel emailModel)
/*     */     throws Exception
/*     */   {
/* 676 */     throw new UnsupportedOperationException("邮件发送没有实现");
/*     */   }
/*     */ 
/*     */   public String sendSmsTask(TaskModel model, String phones) throws Exception {
/* 680 */     throw new UnsupportedOperationException("短信发送没有实现");
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.UniTouchClientImpl
 * JD-Core Version:    0.6.2
 */
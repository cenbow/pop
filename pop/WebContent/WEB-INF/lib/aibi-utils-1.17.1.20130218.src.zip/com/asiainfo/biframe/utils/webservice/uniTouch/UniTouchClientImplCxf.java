/*     */ package com.asiainfo.biframe.utils.webservice.uniTouch;
/*     */ 
/*     */ import com.asiainfo.biframe.utils.webservice.ITaskEmailService;
/*     */ import com.asiainfo.biframe.utils.webservice.ITaskSmsService;
/*     */ import java.io.PrintStream;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*     */ 
/*     */ public class UniTouchClientImplCxf
/*     */   implements IUniTouchClient
/*     */ {
/*  38 */   private static final String pubDao = null;
/*     */ 
/*  40 */   private static Logger log = Logger.getLogger(UniTouchClientImplCxf.class);
/*     */   private String serviceUrl;
/*  44 */   private static ClassPathXmlApplicationContext springContext = new ClassPathXmlApplicationContext("config/aibi_utils/unitouch.xm");
/*     */ 
/*  48 */   private String namespace = "http://com.asiainfo.suite/unitouch";
/*     */ 
/*     */   public UniTouchClientImplCxf(String url)
/*     */   {
/*  52 */     this.serviceUrl = url;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/*  56 */     UniTouchClientImplCxf cxf = new UniTouchClientImplCxf("");
/*     */     try {
/*  58 */       cxf.sendSmsRequest(new TaskModel(), "133");
/*     */     } catch (Exception e) {
/*  60 */       throw new RuntimeException("");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String sendMailRequest(TaskModel model, String filePath)
/*     */     throws Exception
/*     */   {
/*  77 */     String result = "9";
/*  78 */     ITaskEmailService taskEmailService = null;
/*  79 */     taskEmailService = (ITaskEmailService)springContext.getBean("utils_uniTouchClientEmail");
/*     */ 
/*  81 */     String phones = model.getPhones();
/*  82 */     log.debug("phones:" + phones);
/*  83 */     String[] p3 = null;
/*  84 */     if (phones.indexOf(";") < 0)
/*  85 */       p3 = new String[] { phones };
/*     */     else {
/*  87 */       p3 = phones.split(";");
/*     */     }
/*  89 */     taskEmailService.saveContentSame(model.getSubsysId(), p3, model.getContent(), model.getSubject());
/*     */ 
/*  91 */     result = "0";
/*  92 */     return result;
/*     */   }
/*     */ 
/*     */   public String sendSmsRequest(TaskModel model, String phones)
/*     */     throws Exception
/*     */   {
/* 106 */     String result = "9";
/* 107 */     ITaskSmsService taskSmsService = null;
/* 108 */     taskSmsService = (ITaskSmsService)springContext.getBean("utils_uniTouchClientSms");
/*     */ 
/* 110 */     log.debug("phones:" + phones);
/* 111 */     String[] p3 = null;
/* 112 */     if (phones.indexOf(";") < 0)
/* 113 */       p3 = new String[] { phones };
/*     */     else {
/* 115 */       p3 = phones.split(";");
/*     */     }
/* 117 */     taskSmsService.saveContentSame(model.getSubsysId(), p3, model.getSubject());
/*     */ 
/* 119 */     result = "0";
/* 120 */     return result;
/*     */   }
/*     */ 
/*     */   public String sendMmsRequest(TaskModel taskMmodel, MmsModel mmsModel) throws Exception
/*     */   {
/* 125 */     if ((taskMmodel != null) && (mmsModel != null)) {
/* 126 */       ITaskMmsService service = (ITaskMmsService)springContext.getBean("utils_uniTouchClientMms");
/*     */ 
/* 128 */       service.saveImmediateTask(taskMmodel.getSubsysId(), mmsModel);
/*     */     }
/* 130 */     return "0";
/*     */   }
/*     */ 
/*     */   public String sendEmailRequest(TaskModel taskModel, EmailModel emailModel)
/*     */     throws Exception
/*     */   {
/* 139 */     if ((taskModel != null) && (emailModel != null)) {
/* 140 */       ITaskEmailService service = (ITaskEmailService)springContext.getBean("utils_uniTouchClientEmail");
/*     */ 
/* 142 */       log.info("这里取到的service是：" + service);
/* 143 */       System.out.println("这里取到的service是：" + service);
/* 144 */       service.saveImmediateTask(taskModel.getSubsysId(), emailModel);
/*     */     }
/* 146 */     return "0";
/*     */   }
/*     */ 
/*     */   public String getServiceUrl() {
/* 150 */     return this.serviceUrl;
/*     */   }
/*     */ 
/*     */   public String getNamespace() {
/* 154 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace) {
/* 158 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public void setServiceUrl(String serviceUrl) {
/* 162 */     this.serviceUrl = serviceUrl;
/*     */   }
/*     */ 
/*     */   public String sendSmsTask(TaskModel model, String phones)
/*     */     throws Exception
/*     */   {
/* 175 */     String result = "9";
/* 176 */     ITaskSmsService taskSmsService = null;
/* 177 */     taskSmsService = (ITaskSmsService)springContext.getBean("utils_uniTouchClientSms");
/*     */ 
/* 179 */     log.debug("phones:" + phones);
/* 180 */     BsTask bsTask = new BsTask();
/* 181 */     DateFormat df = new SimpleDateFormat("YYYY-MM-DD");
/* 182 */     df.setLenient(false);
/* 183 */     java.util.Date timeDate = df.parse(model.getStartDate());
/* 184 */     java.util.Date timeDate2 = df.parse(model.getEndDate());
/* 185 */     java.sql.Date dateTime = new java.sql.Date(timeDate.getTime());
/* 186 */     java.sql.Date dateTime2 = new java.sql.Date(timeDate2.getTime());
/* 187 */     bsTask.setStartDate(dateTime);
/* 188 */     bsTask.setEndDate(dateTime2);
/* 189 */     bsTask.setStartTime(Integer.valueOf(Integer.parseInt(model.getStartTime())));
/* 190 */     bsTask.setEndTime(Integer.valueOf(Integer.parseInt(model.getEndTime())));
/* 191 */     List bsSmsPushRs = null;
/* 192 */     bsSmsPushRs = new LinkedList();
/* 193 */     BsSmsPushR bsSmsPushR = new BsSmsPushR();
/*     */ 
/* 195 */     bsSmsPushR.setStatus(Integer.valueOf(0));
/* 196 */     bsSmsPushR.setId(Long.valueOf(Long.parseLong(model.getId())));
/* 197 */     bsSmsPushR.setMsisdn(phones);
/* 198 */     bsSmsPushR.setTaskId(model.getId());
/* 199 */     bsSmsPushR.setSubject(model.getSubject());
/* 200 */     bsSmsPushR.setSendCount(Integer.valueOf(0));
/*     */ 
/* 202 */     bsSmsPushRs.add(bsSmsPushR);
/*     */ 
/* 204 */     taskSmsService.save(bsTask, bsSmsPushRs);
/* 205 */     result = "0";
/* 206 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.uniTouch.UniTouchClientImplCxf
 * JD-Core Version:    0.6.2
 */
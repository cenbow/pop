/*    */ package com.asiainfo.biframe.utils.webservice.unitouchup;
/*    */ 
/*    */ import com.asiainfo.biframe.utils.webservice.unitouchup.client.IEmailTaskService;
/*    */ import com.asiainfo.biframe.utils.webservice.unitouchup.client.IMmsTaskService;
/*    */ import com.asiainfo.biframe.utils.webservice.unitouchup.client.ISmsTaskService;
/*    */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*    */ 
/*    */ public class UnitouchUpServiceFactory
/*    */ {
/* 17 */   private static UnitouchUpServiceFactory unitouchUpServiceFactory = new UnitouchUpServiceFactory();
/*    */ 
/* 19 */   private ClassPathXmlApplicationContext springContext = new ClassPathXmlApplicationContext("config/aibi_utils/unitouchUp.xml");
/*    */ 
/*    */   public static UnitouchUpServiceFactory getInstance()
/*    */   {
/* 26 */     return unitouchUpServiceFactory;
/*    */   }
/*    */ 
/*    */   public ISmsTaskService getUnitouchUpSmsService()
/*    */   {
/* 38 */     return (ISmsTaskService)this.springContext.getBean("utils_unitouchUpSmsService");
/*    */   }
/*    */ 
/*    */   public IMmsTaskService getUnitouchUpMmsService()
/*    */   {
/* 51 */     return (IMmsTaskService)this.springContext.getBean("utils_unitouchUpMmsService");
/*    */   }
/*    */ 
/*    */   public IEmailTaskService getUnitouchUpEmailService()
/*    */   {
/* 64 */     return (IEmailTaskService)this.springContext.getBean("utils_unitouchUpEmailService");
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.unitouchup.UnitouchUpServiceFactory
 * JD-Core Version:    0.6.2
 */
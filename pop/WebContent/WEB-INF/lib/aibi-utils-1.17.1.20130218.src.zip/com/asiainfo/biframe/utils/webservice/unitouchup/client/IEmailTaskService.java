package com.asiainfo.biframe.utils.webservice.unitouchup.client;

import com.asiainfo.biframe.utils.webservice.unitouchup.model.EmailMessage;
import com.asiainfo.biframe.utils.webservice.unitouchup.model.ImmediateTask;
import com.asiainfo.biframe.utils.webservice.unitouchup.model.TaskOperationException;
import com.asiainfo.biframe.utils.webservice.unitouchup.model.TimingTask;
import javax.activation.DataHandler;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(name="EmailTaskService", targetNamespace="http://suite.ailk.com/EmailTaskService")
public abstract interface IEmailTaskService
{
  @WebMethod
  @WebResult(name="taskId", targetNamespace="")
  public abstract String createImmediateTask(@WebParam(name="immediateTask", targetNamespace="") ImmediateTask paramImmediateTask, @WebParam(name="message", targetNamespace="") EmailMessage paramEmailMessage, @WebParam(name="adresses", targetNamespace="") String[] paramArrayOfString)
    throws TaskOperationException;

  @WebMethod
  @WebResult(name="taskId", targetNamespace="")
  public abstract String createTimingTask(@WebParam(name="timingTask", targetNamespace="") TimingTask paramTimingTask, @WebParam(name="message", targetNamespace="") EmailMessage paramEmailMessage, @WebParam(name="adresses", targetNamespace="") String[] paramArrayOfString)
    throws TaskOperationException;

  @WebMethod
  @WebResult(name="taskId", targetNamespace="")
  public abstract String createSingleListTimingTask(@WebParam(name="timingTask", targetNamespace="") TimingTask paramTimingTask, @WebParam(name="message", targetNamespace="") EmailMessage paramEmailMessage, @WebParam(name="pushList", targetNamespace="") DataHandler paramDataHandler)
    throws TaskOperationException;
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.unitouchup.client.IEmailTaskService
 * JD-Core Version:    0.6.2
 */
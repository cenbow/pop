/*    */ package com.asiainfo.biframe.utils.webservice.unitouchup.model;
/*    */ 
/*    */ import javax.activation.DataHandler;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="emailMessage", propOrder={"attachDatas", "attachNames", "content", "subject"})
/*    */ public class EmailMessage
/*    */ {
/*    */ 
/*    */   @XmlElement(nillable=true)
/*    */   private DataHandler[] attachDatas;
/*    */ 
/*    */   @XmlElement(nillable=true)
/*    */   private String[] attachNames;
/*    */   private String content;
/*    */   private String subject;
/*    */ 
/*    */   public DataHandler[] getAttachDatas()
/*    */   {
/* 35 */     return this.attachDatas;
/*    */   }
/*    */ 
/*    */   public void setAttachDatas(DataHandler[] attachDatas) {
/* 39 */     this.attachDatas = attachDatas;
/*    */   }
/*    */ 
/*    */   public String[] getAttachNames() {
/* 43 */     return this.attachNames;
/*    */   }
/*    */ 
/*    */   public void setAttachNames(String[] attachNames) {
/* 47 */     this.attachNames = attachNames;
/*    */   }
/*    */ 
/*    */   public String getContent() {
/* 51 */     return this.content;
/*    */   }
/*    */ 
/*    */   public void setContent(String value) {
/* 55 */     this.content = value;
/*    */   }
/*    */ 
/*    */   public String getSubject() {
/* 59 */     return this.subject;
/*    */   }
/*    */ 
/*    */   public void setSubject(String value) {
/* 63 */     this.subject = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.unitouchup.model.EmailMessage
 * JD-Core Version:    0.6.2
 */
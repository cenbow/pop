package com.asiainfo.biframe.utils.webservice.unitouchup.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="immediateTask")
public class ImmediateTask extends Task
{
}

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.unitouchup.model.ImmediateTask
 * JD-Core Version:    0.6.2
 */
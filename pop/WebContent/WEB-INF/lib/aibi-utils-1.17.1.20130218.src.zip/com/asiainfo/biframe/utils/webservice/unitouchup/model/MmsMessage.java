/*    */ package com.asiainfo.biframe.utils.webservice.unitouchup.model;
/*    */ 
/*    */ import javax.activation.DataHandler;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class MmsMessage
/*    */ {
/*    */   private DataHandler content;
/*    */   private String referenceId;
/*    */   private String subject;
/*    */ 
/*    */   public DataHandler getContent()
/*    */   {
/* 20 */     return this.content;
/*    */   }
/*    */ 
/*    */   public void setContent(DataHandler value) {
/* 24 */     this.content = value;
/*    */   }
/*    */ 
/*    */   public String getReferenceId() {
/* 28 */     return this.referenceId;
/*    */   }
/*    */ 
/*    */   public void setReferenceId(String value) {
/* 32 */     this.referenceId = value;
/*    */   }
/*    */ 
/*    */   public String getSubject() {
/* 36 */     return this.subject;
/*    */   }
/*    */ 
/*    */   public void setSubject(String value) {
/* 40 */     this.subject = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.unitouchup.model.MmsMessage
 * JD-Core Version:    0.6.2
 */
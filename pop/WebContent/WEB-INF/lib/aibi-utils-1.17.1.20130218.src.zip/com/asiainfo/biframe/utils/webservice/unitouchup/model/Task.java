/*    */ package com.asiainfo.biframe.utils.webservice.unitouchup.model;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlSeeAlso;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlSeeAlso({TimingTask.class, ImmediateTask.class})
/*    */ public abstract class Task
/*    */ {
/*    */   private String channelId;
/*    */   private String createrId;
/*    */   private String createrName;
/*    */   private int level;
/*    */   private String name;
/*    */   private String productId;
/*    */ 
/*    */   public String getChannelId()
/*    */   {
/* 34 */     return this.channelId;
/*    */   }
/*    */ 
/*    */   public void setChannelId(String value) {
/* 38 */     this.channelId = value;
/*    */   }
/*    */ 
/*    */   public String getCreaterId() {
/* 42 */     return this.createrId;
/*    */   }
/*    */ 
/*    */   public void setCreaterId(String value) {
/* 46 */     this.createrId = value;
/*    */   }
/*    */ 
/*    */   public String getCreaterName() {
/* 50 */     return this.createrName;
/*    */   }
/*    */ 
/*    */   public void setCreaterName(String value) {
/* 54 */     this.createrName = value;
/*    */   }
/*    */ 
/*    */   public int getLevel() {
/* 58 */     return this.level;
/*    */   }
/*    */ 
/*    */   public void setLevel(int value) {
/* 62 */     this.level = value;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 66 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String value) {
/* 70 */     this.name = value;
/*    */   }
/*    */ 
/*    */   public String getProductId() {
/* 74 */     return this.productId;
/*    */   }
/*    */ 
/*    */   public void setProductId(String value) {
/* 78 */     this.productId = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.unitouchup.model.Task
 * JD-Core Version:    0.6.2
 */
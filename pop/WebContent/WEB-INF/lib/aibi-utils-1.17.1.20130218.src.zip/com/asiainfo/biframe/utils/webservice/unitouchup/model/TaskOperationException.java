/*    */ package com.asiainfo.biframe.utils.webservice.unitouchup.model;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="TaskOperationException")
/*    */ public class TaskOperationException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public TaskOperationException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TaskOperationException(String message, Throwable cause)
/*    */   {
/* 28 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public TaskOperationException(String message) {
/* 32 */     super(message);
/*    */   }
/*    */ 
/*    */   public TaskOperationException(Throwable cause) {
/* 36 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.unitouchup.model.TaskOperationException
 * JD-Core Version:    0.6.2
 */
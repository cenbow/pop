/*    */ package com.asiainfo.biframe.utils.webservice.unitouchup.model;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class TimingTask extends Task
/*    */ {
/*    */   private String beginDate;
/*    */   private String beginTime;
/*    */   private boolean dispatch;
/*    */   private String endDate;
/*    */   private String endTime;
/*    */   private int pushModel;
/*    */ 
/*    */   public String getBeginDate()
/*    */   {
/* 32 */     return this.beginDate;
/*    */   }
/*    */ 
/*    */   public void setBeginDate(String value) {
/* 36 */     this.beginDate = value;
/*    */   }
/*    */ 
/*    */   public String getBeginTime() {
/* 40 */     return this.beginTime;
/*    */   }
/*    */ 
/*    */   public void setBeginTime(String value) {
/* 44 */     this.beginTime = value;
/*    */   }
/*    */ 
/*    */   public boolean isDispatch() {
/* 48 */     return this.dispatch;
/*    */   }
/*    */ 
/*    */   public void setDispatch(boolean value) {
/* 52 */     this.dispatch = value;
/*    */   }
/*    */ 
/*    */   public String getEndDate() {
/* 56 */     return this.endDate;
/*    */   }
/*    */ 
/*    */   public void setEndDate(String value) {
/* 60 */     this.endDate = value;
/*    */   }
/*    */ 
/*    */   public String getEndTime() {
/* 64 */     return this.endTime;
/*    */   }
/*    */ 
/*    */   public void setEndTime(String value) {
/* 68 */     this.endTime = value;
/*    */   }
/*    */ 
/*    */   public int getPushModel() {
/* 72 */     return this.pushModel;
/*    */   }
/*    */ 
/*    */   public void setPushModel(int value) {
/* 76 */     this.pushModel = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.webservice.unitouchup.model.TimingTask
 * JD-Core Version:    0.6.2
 */
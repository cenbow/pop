/*     */ package com.asiainfo.biframe.utils.xml;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.dom4j.Attribute;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentHelper;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.io.SAXReader;
/*     */ 
/*     */ public class XmlReaderUtil
/*     */ {
/*     */   private Document doc;
/*     */   private Element rootNode;
/*     */ 
/*     */   public XmlReaderUtil(String xml)
/*     */     throws Exception
/*     */   {
/* 103 */     if ((xml == null) || (xml.trim().length() < 1)) {
/* 104 */       throw new Exception("--err------>>>xml file name or xml string is null!");
/*     */     }
/* 106 */     if (xml.charAt(0) == '<') {
/* 107 */       this.doc = DocumentHelper.parseText(xml);
/*     */     } else {
/* 109 */       SAXReader reader = new SAXReader();
/*     */       try {
/* 111 */         this.doc = reader.read(new File(xml));
/*     */       }
/*     */       catch (Exception e) {
/* 114 */         URL url = Thread.currentThread().getContextClassLoader().getResource(xml);
/*     */ 
/* 116 */         if (url == null) {
/* 117 */           throw e;
/*     */         }
/* 119 */         this.doc = reader.read(url.toString());
/*     */       }
/*     */     }
/*     */ 
/* 123 */     this.doc.normalize();
/*     */ 
/* 125 */     if (this.doc != null) {
/* 126 */       this.rootNode = this.doc.getRootElement();
/*     */     }
/* 128 */     if ((this.doc == null) || (this.rootNode == null))
/* 129 */       throw new Exception("----err-----xml initialization failed, please check the xml document format");
/*     */   }
/*     */ 
/*     */   public Element getConfigNode(String nodePath)
/*     */     throws Exception
/*     */   {
/* 155 */     if ((nodePath == null) || (nodePath.trim().length() < 1)) {
/* 156 */       throw new Exception("----err----input node path is empty ");
/*     */     }
/*     */ 
/* 159 */     Object result = this.doc.selectSingleNode(nodePath);
/* 160 */     return result == null ? null : (Element)result;
/*     */   }
/*     */ 
/*     */   public List<Element> getConfigNodeList(String nodePath)
/*     */     throws Exception
/*     */   {
/* 192 */     if ((nodePath == null) || (nodePath.trim().length() < 1)) {
/* 193 */       throw new Exception("----err----input node, the path is incorrect ");
/*     */     }
/*     */ 
/* 196 */     return this.doc.selectNodes(nodePath);
/*     */   }
/*     */ 
/*     */   public List<Element> getConfigNodeList(Element fixNode, String subNodePath)
/*     */     throws Exception
/*     */   {
/* 230 */     if (fixNode == null) {
/* 231 */       return getConfigNodeList(subNodePath);
/*     */     }
/* 233 */     if ((subNodePath == null) || (subNodePath.trim().length() < 1)) {
/* 234 */       return fixNode.elements();
/*     */     }
/* 236 */     return fixNode.selectNodes(subNodePath);
/*     */   }
/*     */ 
/*     */   public Element getConfigNode(Element fixNode, String nodePath, String subNodeName, String subNodeValue)
/*     */     throws Exception
/*     */   {
/* 275 */     if ((nodePath == null) || (nodePath.trim().length() < 1)) {
/* 276 */       throw new Exception("----err----input sub-node path is incorrect ");
/*     */     }
/*     */ 
/* 279 */     if ((subNodeName == null) || (subNodeName.trim().length() < 1) || (subNodeValue == null) || (subNodeValue.trim().length() < 1)) {
/* 280 */       throw new Exception("----err----input sub-node information is incorrect ");
/*     */     }
/* 282 */     List list = null;
/* 283 */     if (fixNode == null)
/* 284 */       list = this.doc.selectNodes(nodePath);
/*     */     else {
/* 286 */       list = fixNode.selectNodes(nodePath);
/*     */     }
/* 288 */     if ((list == null) || (list.size() < 1)) {
/* 289 */       throw new Exception("----err----not found in the node information");
/*     */     }
/* 291 */     for (Iterator i$ = list.iterator(); i$.hasNext(); ) { element = (Element)i$.next();
/* 292 */       List subList = element.elements();
/* 293 */       for (Element subElement : subList)
/* 294 */         if ((subElement != null) && (subElement.getNodeType() == 1) && (subNodeName.equals(subElement.getName())))
/*     */         {
/* 297 */           if (subNodeValue.equals(subElement.getTextTrim()))
/* 298 */             return element;
/*     */         }
/*     */     }
/*     */     Element element;
/* 303 */     throw new Exception("----err----does not exist in the attribute name and attribute value of the node");
/*     */   }
/*     */ 
/*     */   public Element getConfigNode(String nodePath, String subNodeName, String subNodeValue)
/*     */     throws Exception
/*     */   {
/* 337 */     return getConfigNode(null, nodePath, subNodeName, subNodeValue);
/*     */   }
/*     */ 
/*     */   public String getPropertyValue(Element fixNode, String subNodeName)
/*     */     throws Exception
/*     */   {
/* 361 */     if (fixNode == null) {
/* 362 */       throw new Exception("----err----the specified node is empty");
/*     */     }
/* 364 */     return fixNode.elementText(subNodeName);
/*     */   }
/*     */ 
/*     */   public List<String> getPropertyValueList(Element fixNode, String subNodeName)
/*     */     throws Exception
/*     */   {
/* 388 */     if (fixNode == null) {
/* 389 */       throw new Exception("----err---the specified node is empty");
/*     */     }
/* 391 */     List resultList = new ArrayList();
/* 392 */     List list = fixNode.elements(subNodeName);
/* 393 */     for (Element e : list) {
/* 394 */       resultList.add(e.getText());
/*     */     }
/* 396 */     return resultList;
/*     */   }
/*     */ 
/*     */   public String getAttrValue(Element fixNode, String attrName)
/*     */     throws Exception
/*     */   {
/* 412 */     if (fixNode == null) {
/* 413 */       throw new Exception("----err----the specified node is empty");
/*     */     }
/* 415 */     return fixNode.attributeValue("attrName");
/*     */   }
/*     */ 
/*     */   public List<Attribute> getAttributes(Element fixNode)
/*     */     throws Exception
/*     */   {
/* 433 */     if (fixNode == null) {
/* 434 */       throw new Exception("----err----the specified node is empty");
/*     */     }
/* 436 */     return fixNode.attributes();
/*     */   }
/*     */ 
/*     */   public Element getRootNode()
/*     */   {
/* 447 */     return this.rootNode;
/*     */   }
/*     */ 
/*     */   public Document getDocument()
/*     */   {
/* 457 */     return this.doc;
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.xml.XmlReaderUtil
 * JD-Core Version:    0.6.2
 */
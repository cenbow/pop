/*     */ package com.asiainfo.biframe.utils.xml;
/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentHelper;
/*     */ import org.dom4j.io.OutputFormat;
/*     */ import org.dom4j.io.XMLWriter;
/*     */ 
/*     */ public class XmlWriterUtil
/*     */ {
/*     */   public Document createNewDocument()
/*     */   {
/*  71 */     Document document = DocumentHelper.createDocument();
/*  72 */     return document;
/*     */   }
/*     */ 
/*     */   public void saveXmlFile(Document doc, String fileName)
/*     */     throws IOException
/*     */   {
/*  84 */     XMLWriter writer = new XMLWriter(new FileWriter(fileName));
/*  85 */     writer.write(doc);
/*  86 */     writer.close();
/*     */   }
/*     */ 
/*     */   public void saveXmlFile(Document doc, String fileName, String encoding)
/*     */     throws IOException
/*     */   {
/*  98 */     if ((encoding == null) || (encoding.trim().length() < 1)) {
/*  99 */       encoding = "GBK";
/*     */     }
/* 101 */     OutputFormat format = OutputFormat.createPrettyPrint();
/* 102 */     format.setEncoding(encoding);
/* 103 */     XMLWriter writer = new XMLWriter(new FileOutputStream(fileName), format);
/* 104 */     writer.write(doc);
/* 105 */     writer.close();
/*     */   }
/*     */ }

/* Location:           C:\Users\lify\Desktop\新建文件夹\aibi-utils-1.17.1.20130218.jar
 * Qualified Name:     com.asiainfo.biframe.utils.xml.XmlWriterUtil
 * JD-Core Version:    0.6.2
 */